<?php
/**
 * Subscription Plans Configuration
 */

return [
    'free' => [
        'name' => 'Free',
        'slug' => 'free',
        'price' => 0,
        'billing_cycle' => 'lifetime',
        'features' => [
            'pages' => 1,
            'custom_domains' => 0,
            'blog_posts' => 0,
            'storage_mb' => 100,
            'bandwidth_gb' => 5,
            'ssl' => false,
            'analytics' => false,
            'custom_code' => false,
        ],
    ],
    
    'pro' => [
        'name' => 'Pro',
        'slug' => 'pro',
        'price' => 29,
        'billing_cycle' => 'monthly',
        'features' => [
            'pages' => 10,
            'custom_domains' => 3,
            'blog_posts' => 100,
            'storage_mb' => 5000,
            'bandwidth_gb' => 100,
            'ssl' => true,
            'analytics' => true,
            'custom_code' => false,
        ],
    ],
    
    'business' => [
        'name' => 'Business',
        'slug' => 'business',
        'price' => 99,
        'billing_cycle' => 'monthly',
        'features' => [
            'pages' => -1, // unlimited
            'custom_domains' => -1, // unlimited
            'blog_posts' => -1, // unlimited
            'storage_mb' => 50000,
            'bandwidth_gb' => 1000,
            'ssl' => true,
            'analytics' => true,
            'custom_code' => true,
        ],
    ],
];
