<?php
/**
 * Permissions Configuration
 */

return [
    'roles' => [
        'qupa_member' => [
            'name' => 'QUPA Member',
            'capabilities' => [
                'read' => true,
                'qupa_manage_pages' => true,
                'qupa_manage_domains' => true,
                'qupa_view_billing' => true,
            ],
        ],
    ],
    
    'capabilities' => [
        'qupa_manage_pages' => 'Manage QUPA Pages',
        'qupa_manage_domains' => 'Manage Custom Domains',
        'qupa_view_billing' => 'View Billing Information',
        'qupa_manage_blog' => 'Manage Blog Posts',
    ],
    
    'feature_permissions' => [
        'custom_domain' => ['qupa_manage_domains'],
        'blog' => ['qupa_manage_blog'],
        'billing' => ['qupa_view_billing'],
    ],
];
