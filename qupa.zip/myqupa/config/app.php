<?php
/**
 * Application Configuration
 */

return [
    'version' => QUPA_VERSION,
    
    'plugin' => [
        'name' => 'Quantum Page',
        'slug' => 'quantum-page',
        'text_domain' => 'quantum-page',
    ],
    
    'cpt' => [
        'page' => 'qupa_page',
        'post' => 'qupa_post',
    ],
    
    'database' => [
        'tables' => [
            'domains' => 'qupa_domains',
            'subscriptions' => 'qupa_subscriptions',
            'entitlements' => 'qupa_entitlements',
        ],
    ],
    
    'cache' => [
        'enabled' => true,
        'ttl' => 3600, // 1 hour
        'domain_resolution_ttl' => 86400, // 24 hours
    ],
    
    'features' => [
        'custom_domain' => true,
        'blog' => true,
        'billing' => true,
        'payments' => true,
    ],
    
    'editor' => [
        'allowed_blocks' => [
            'core/paragraph',
            'core/heading',
            'core/image',
            'core/list',
            'core/quote',
            'core/button',
            'core/columns',
            'core/group',
            'core/spacer',
            // Kadence blocks will be added when available
        ],
        'disable_custom_html' => true,
    ],
];
