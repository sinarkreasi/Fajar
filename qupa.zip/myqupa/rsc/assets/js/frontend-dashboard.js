/**
 * Frontend Dashboard JavaScript
 */

(function () {
    'use strict';

    // Active navigation highlighting
    function highlightActiveNav() {
        const currentPath = window.location.pathname;
        const navItems = document.querySelectorAll('.nav-item');

        navItems.forEach(item => {
            const href = item.getAttribute('href');
            if (currentPath === href || currentPath.startsWith(href + '/')) {
                item.classList.add('active');
            } else {
                item.classList.remove('active');
            }
        });
    }

    // Initialize on DOM ready
    document.addEventListener('DOMContentLoaded', function () {
        highlightActiveNav();
    });

})();
