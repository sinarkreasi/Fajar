<?php
require_once QUPA_PLUGIN_DIR . 'rsc/views/frontend/layout.php';
qupa_frontend_header('Billing', 'billing');
?>

<header class="header">
    <h1>Billing & Subscription</h1>
</header>

<div class="content">
    <div class="section">
        <h2>Current Plan</h2>
        <div style="padding: 2rem; background: linear-gradient(135deg, #EEF2FF 0%, #E0E7FF 100%); border-radius: 1rem; margin-top: 1rem;">
            <h3 style="font-size: 2rem; margin: 0 0 0.5rem 0; color: var(--primary);">
                <?php echo esc_html($currentPlan['name'] ?? 'Free'); ?>
            </h3>
            <p style="font-size: 1.25rem; color: var(--text-muted); margin: 0;">
                <?php 
                $price = $currentPlan['price'] ?? 0;
                if ($price > 0) {
                    printf('$%d / %s', $price, $currentPlan['billing_cycle'] ?? 'month');
                } else {
                    echo 'Free Forever';
                }
                ?>
            </p>
        </div>
    </div>
    
    <div class="section" style="margin-top: 2rem;">
        <h2>Usage Statistics</h2>
        <div class="stats-grid" style="margin-top: 1rem;">
            <?php foreach ($stats as $feature => $data): ?>
                <div class="stat-card">
                    <div class="stat-info">
                        <h3><?php echo esc_html(ucwords(str_replace('_', ' ', $feature))); ?></h3>
                        <p class="stat-value"><?php echo esc_html($data['used']); ?></p>
                        <p class="stat-limit">
                            of <?php echo $data['limit'] === -1 ? 'Unlimited' : esc_html($data['limit']); ?>
                        </p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <div class="section" style="margin-top: 2rem;">
        <h2>Available Plans</h2>
        <div class="pages-grid" style="margin-top: 1rem;">
            <?php foreach ($plans as $slug => $plan): ?>
                <div class="page-card <?php echo $slug === ($currentPlan['slug'] ?? 'free') ? 'active-plan' : ''; ?>">
                    <div class="page-card-header">
                        <h4><?php echo esc_html($plan['name']); ?></h4>
                        <?php if ($slug === ($currentPlan['slug'] ?? 'free')): ?>
                            <span class="status status-publish">Current</span>
                        <?php endif; ?>
                    </div>
                    <p style="font-size: 1.5rem; font-weight: 700; margin: 1rem 0; color: var(--primary);">
                        <?php 
                        if ($plan['price'] > 0) {
                            printf('$%d / %s', $plan['price'], $plan['billing_cycle']);
                        } else {
                            echo 'Free';
                        }
                        ?>
                    </p>
                    <ul style="list-style: none; padding: 0; margin: 1rem 0;">
                        <?php foreach ($plan['features'] as $feature => $value): ?>
                            <li style="padding: 0.5rem 0; border-bottom: 1px solid var(--border);">
                                <?php 
                                $featureName = ucwords(str_replace('_', ' ', $feature));
                                if ($value === true) {
                                    echo '✓ ' . esc_html($featureName);
                                } elseif ($value === false) {
                                    echo '✗ ' . esc_html($featureName);
                                } elseif ($value === -1) {
                                    echo '∞ ' . esc_html($featureName);
                                } else {
                                    echo esc_html($value) . ' ' . esc_html($featureName);
                                }
                                ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                    <?php if ($slug !== ($currentPlan['slug'] ?? 'free')): ?>
                        <button class="btn btn-primary" style="width: 100%;">Upgrade to <?php echo esc_html($plan['name']); ?></button>
                    <?php else: ?>
                        <button class="btn btn-outline" style="width: 100%;" disabled>Current Plan</button>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<style>
.active-plan {
    border: 2px solid var(--primary);
    background: #F9FAFB;
}
</style>

<?php qupa_frontend_footer(); ?>
