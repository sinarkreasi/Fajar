<?php
require_once QUPA_PLUGIN_DIR . 'rsc/views/frontend/layout.php';
qupa_frontend_header('Domains', 'domains');
?>

<header class="header">
    <h1>Custom Domains</h1>
</header>

<div class="content">
    <div class="section">
        <h2>Your Domains</h2>
        
        <?php if (empty($domains)): ?>
            <div class="empty-state">
                <svg width="64" height="64" viewBox="0 0 20 20" fill="#D1D5DB">
                    <path d="M10 12a2 2 0 100-4 2 2 0 000 4z"/>
                    <path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd"/>
                </svg>
                <h3>No custom domains yet</h3>
                <p>Add a custom domain to make your pages accessible via your own domain</p>
            </div>
        <?php else: ?>
            <div class="pages-grid">
                <?php foreach ($domains as $domain): ?>
                    <div class="page-card">
                        <div class="page-card-header">
                            <h4><?php echo esc_html($domain->domain); ?></h4>
                            <span class="status status-<?php echo $domain->is_verified ? 'publish' : 'draft'; ?>">
                                <?php echo $domain->is_verified ? 'Verified' : 'Pending'; ?>
                            </span>
                        </div>
                        <p class="page-date">
                            Points to: <?php echo esc_html(get_the_title($domain->page_id)); ?>
                        </p>
                        <p class="page-date">
                            SSL: <?php echo esc_html(ucfirst($domain->ssl_status)); ?>
                        </p>
                        <div class="page-actions">
                            <button class="btn btn-sm">Verify DNS</button>
                            <button class="btn btn-sm btn-outline">Delete</button>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    
    <div class="section" style="margin-top: 2rem;">
        <h2>Add New Domain</h2>
        <p style="color: var(--text-muted); margin-bottom: 1rem;">Map a custom domain to one of your pages</p>
        
        <form style="max-width: 600px;">
            <div style="margin-bottom: 1rem;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Domain Name</label>
                <input type="text" placeholder="example.com" style="width: 100%; padding: 0.75rem; border: 1px solid var(--border); border-radius: 0.5rem;">
                <p style="font-size: 0.875rem; color: var(--text-muted); margin-top: 0.5rem;">Enter your domain without http:// or www</p>
            </div>
            
            <div style="margin-bottom: 1rem;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Select Page</label>
                <select style="width: 100%; padding: 0.75rem; border: 1px solid var(--border); border-radius: 0.5rem;">
                    <option>Select a page...</option>
                    <?php
                    $pageModel = new \QUPA\Models\Page();
                    $userPages = $pageModel->findByUser(get_current_user_id());
                    foreach ($userPages as $page):
                    ?>
                        <option value="<?php echo $page->ID; ?>"><?php echo esc_html($page->post_title); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <button type="submit" class="btn btn-primary">Add Domain</button>
        </form>
    </div>
</div>

<?php qupa_frontend_footer(); ?>
