<?php
/**
 * Base Frontend View
 * 
 * Provides common layout wrapper for all frontend views
 */

function qupa_frontend_header($title = 'Dashboard', $currentPage = 'dashboard') {
    global $plan, $stats;
    
    // Check if user is logged in
    if (!is_user_logged_in()) {
        require_once QUPA_PLUGIN_DIR . 'rsc/views/frontend/auth.php';
        exit;
    }
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo esc_html($title); ?> - Quantum Page</title>
    <link rel="stylesheet" href="<?php echo QUPA_PLUGIN_URL; ?>rsc/assets/css/frontend-dashboard.css">
</head>
<body class="qupa-frontend-dashboard">
    <div class="dashboard-wrapper">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="logo">
                <h1>Quantum Page</h1>
            </div>
            
            <nav class="nav">
                <a href="/dash" class="nav-item <?php echo $currentPage === 'dashboard' ? 'active' : ''; ?>">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                        <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"/>
                    </svg>
                    <span>Dashboard</span>
                </a>
                <a href="/dash/pages" class="nav-item <?php echo $currentPage === 'pages' ? 'active' : ''; ?>">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                        <path d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4z"/>
                    </svg>
                    <span>My Pages</span>
                </a>
                <a href="/dash/domains" class="nav-item <?php echo $currentPage === 'domains' ? 'active' : ''; ?>">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                        <path d="M10 12a2 2 0 100-4 2 2 0 000 4z"/>
                        <path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd"/>
                    </svg>
                    <span>Domains</span>
                </a>
                <a href="/dash/billing" class="nav-item <?php echo $currentPage === 'billing' ? 'active' : ''; ?>">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                        <path d="M4 4a2 2 0 00-2 2v1h16V6a2 2 0 00-2-2H4z"/>
                        <path fill-rule="evenodd" d="M18 9H2v5a2 2 0 002 2h12a2 2 0 002-2V9zM4 13a1 1 0 011-1h1a1 1 0 110 2H5a1 1 0 01-1-1zm5-1a1 1 0 100 2h1a1 1 0 100-2H9z" clip-rule="evenodd"/>
                    </svg>
                    <span>Billing</span>
                </a>
            </nav>
            
            <div class="sidebar-footer">
                <div class="user-info">
                    <div class="user-avatar">
                        <?php echo get_avatar(get_current_user_id(), 32); ?>
                    </div>
                    <div class="user-details">
                        <div class="user-name"><?php echo wp_get_current_user()->display_name; ?></div>
                        <div class="user-plan"><?php echo esc_html($plan['name'] ?? 'Free'); ?> Plan</div>
                    </div>
                </div>
                <a href="<?php echo wp_logout_url('/'); ?>" class="logout-btn">
                    <svg width="16" height="16" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M3 3a1 1 0 00-1 1v12a1 1 0 102 0V4a1 1 0 00-1-1zm10.293 9.293a1 1 0 001.414 1.414l3-3a1 1 0 000-1.414l-3-3a1 1 0 10-1.414 1.414L14.586 9H7a1 1 0 100 2h7.586l-1.293 1.293z" clip-rule="evenodd"/>
                    </svg>
                </a>
            </div>
        </aside>
        
        <!-- Main Content -->
        <main class="main-content">
<?php
}

function qupa_frontend_footer() {
?>
        </main>
    </div>
    
    <script src="<?php echo QUPA_PLUGIN_URL; ?>rsc/assets/js/frontend-dashboard.js"></script>
</body>
</html>
<?php
}
