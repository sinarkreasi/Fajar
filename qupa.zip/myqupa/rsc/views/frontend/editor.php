<?php
// Check if user is logged in
if (!is_user_logged_in()) {
    require_once QUPA_PLUGIN_DIR . 'rsc/views/frontend/auth.php';
    exit;
}

// Get page data
$pageId = $page->ID ?? 0;
$pageTitle = $page->post_title ?? '';
$pageContent = $page->post_content ?? '';
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Edit Page - Quantum Page</title>
    <link rel="stylesheet" href="<?php echo QUPA_PLUGIN_URL; ?>rsc/assets/css/frontend-dashboard.css">
    <?php wp_enqueue_script('wp-block-library'); ?>
    <?php wp_enqueue_style('wp-block-library'); ?>
    <?php wp_head(); ?>
    <style>
        .editor-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }
        
        .editor-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid var(--border);
        }
        
        .editor-title {
            flex: 1;
            margin-right: 2rem;
        }
        
        .editor-title input {
            width: 100%;
            font-size: 2rem;
            font-weight: 700;
            border: none;
            padding: 0.5rem;
            border-radius: 0.5rem;
        }
        
        .editor-title input:focus {
            outline: 2px solid var(--primary);
        }
        
        .editor-actions {
            display: flex;
            gap: 1rem;
        }
        
        .editor-content {
            background: white;
            border: 1px solid var(--border);
            border-radius: 1rem;
            padding: 2rem;
            min-height: 500px;
        }
        
        .editor-content textarea {
            width: 100%;
            min-height: 400px;
            border: none;
            font-size: 1rem;
            line-height: 1.6;
            resize: vertical;
            font-family: inherit;
        }
        
        .editor-content textarea:focus {
            outline: none;
        }
        
        .editor-sidebar {
            position: fixed;
            right: 0;
            top: 0;
            width: 300px;
            height: 100vh;
            background: white;
            border-left: 1px solid var(--border);
            padding: 2rem;
            overflow-y: auto;
        }
        
        .editor-main {
            margin-right: 300px;
        }
    </style>
</head>
<body>
    <div class="editor-main">
        <div class="editor-container">
            <div class="editor-header">
                <div class="editor-title">
                    <input type="text" id="page-title" value="<?php echo esc_attr($pageTitle); ?>" placeholder="Page Title">
                </div>
                <div class="editor-actions">
                    <a href="/dash/pages" class="btn btn-outline">
                        ← Back
                    </a>
                    <button class="btn btn-primary" id="save-page">
                        Save Page
                    </button>
                    <button class="btn btn-primary" id="publish-page">
                        Publish
                    </button>
                </div>
            </div>
            
            <div class="editor-content">
                <textarea id="page-content" placeholder="Start writing your page content..."><?php echo esc_textarea($pageContent); ?></textarea>
            </div>
        </div>
    </div>
    
    <div class="editor-sidebar">
        <h3>Page Settings</h3>
        
        <div style="margin-top: 1.5rem;">
            <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Status</label>
            <select id="page-status" style="width: 100%; padding: 0.5rem; border: 1px solid var(--border); border-radius: 0.5rem;">
                <option value="draft" <?php selected($page->post_status ?? 'draft', 'draft'); ?>>Draft</option>
                <option value="publish" <?php selected($page->post_status ?? 'draft', 'publish'); ?>>Published</option>
            </select>
        </div>
        
        <div style="margin-top: 1.5rem;">
            <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">SEO Title</label>
            <input type="text" id="seo-title" placeholder="SEO Title" style="width: 100%; padding: 0.5rem; border: 1px solid var(--border); border-radius: 0.5rem;">
        </div>
        
        <div style="margin-top: 1.5rem;">
            <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Meta Description</label>
            <textarea id="meta-description" placeholder="Meta description for SEO" style="width: 100%; padding: 0.5rem; border: 1px solid var(--border); border-radius: 0.5rem; min-height: 80px;"></textarea>
        </div>
        
        <div style="margin-top: 1.5rem;">
            <button class="btn btn-outline" style="width: 100%;" id="preview-page">
                👁 Preview
            </button>
        </div>
        
        <div style="margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid var(--border);">
            <button class="btn btn-outline" style="width: 100%; color: var(--danger);" id="delete-page">
                🗑 Delete Page
            </button>
        </div>
    </div>
    
    <script>
        const pageId = <?php echo $pageId; ?>;
        
        // Save page
        document.getElementById('save-page').addEventListener('click', async () => {
            const title = document.getElementById('page-title').value;
            const content = document.getElementById('page-content').value;
            const status = document.getElementById('page-status').value;
            
            const response = await fetch('/wp-json/wp/v2/qupa_page/' + pageId, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-WP-Nonce': '<?php echo wp_create_nonce('wp_rest'); ?>'
                },
                body: JSON.stringify({
                    title: title,
                    content: content,
                    status: status
                })
            });
            
            if (response.ok) {
                alert('✓ Page saved successfully!');
            } else {
                alert('✗ Failed to save page');
            }
        });
        
        // Publish page
        document.getElementById('publish-page').addEventListener('click', async () => {
            document.getElementById('page-status').value = 'publish';
            document.getElementById('save-page').click();
        });
        
        // Preview page
        document.getElementById('preview-page').addEventListener('click', () => {
            window.open('/?p=' + pageId + '&preview=true', '_blank');
        });
        
        // Delete page
        document.getElementById('delete-page').addEventListener('click', async () => {
            if (!confirm('Are you sure you want to delete this page?')) return;
            
            const response = await fetch('/wp-json/wp/v2/qupa_page/' + pageId, {
                method: 'DELETE',
                headers: {
                    'X-WP-Nonce': '<?php echo wp_create_nonce('wp_rest'); ?>'
                }
            });
            
            if (response.ok) {
                alert('✓ Page deleted');
                window.location.href = '/dash/pages';
            } else {
                alert('✗ Failed to delete page');
            }
        });
        
        // Auto-save every 30 seconds
        setInterval(() => {
            document.getElementById('save-page').click();
        }, 30000);
    </script>
    
    <?php wp_footer(); ?>
</body>
</html>
