<?php
// Check if user is logged in
if (!is_user_logged_in()) {
    require_once QUPA_PLUGIN_DIR . 'rsc/views/frontend/auth.php';
    exit;
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard - Quantum Page</title>
    <link rel="stylesheet" href="<?php echo QUPA_PLUGIN_URL; ?>rsc/assets/css/frontend-dashboard.css">
</head>
<body class="qupa-frontend-dashboard">
    <div class="dashboard-wrapper">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="logo">
                <h1>Quantum Page</h1>
            </div>
            
            <nav class="nav">
                <a href="/dash" class="nav-item active">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                        <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"/>
                    </svg>
                    <span>Dashboard</span>
                </a>
                <a href="/dash/pages" class="nav-item">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                        <path d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4z"/>
                    </svg>
                    <span>My Pages</span>
                </a>
                <a href="/dash/domains" class="nav-item">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                        <path d="M10 12a2 2 0 100-4 2 2 0 000 4z"/>
                        <path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd"/>
                    </svg>
                    <span>Domains</span>
                </a>
                <a href="/dash/billing" class="nav-item">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                        <path d="M4 4a2 2 0 00-2 2v1h16V6a2 2 0 00-2-2H4z"/>
                        <path fill-rule="evenodd" d="M18 9H2v5a2 2 0 002 2h12a2 2 0 002-2V9zM4 13a1 1 0 011-1h1a1 1 0 110 2H5a1 1 0 01-1-1zm5-1a1 1 0 100 2h1a1 1 0 100-2H9z" clip-rule="evenodd"/>
                    </svg>
                    <span>Billing</span>
                </a>
            </nav>
            
            <div class="sidebar-footer">
                <div class="user-info">
                    <div class="user-avatar">
                        <?php echo get_avatar(get_current_user_id(), 32); ?>
                    </div>
                    <div class="user-details">
                        <div class="user-name"><?php echo wp_get_current_user()->display_name; ?></div>
                        <div class="user-plan"><?php echo esc_html($plan['name'] ?? 'Free'); ?> Plan</div>
                    </div>
                </div>
                <a href="<?php echo wp_logout_url('/'); ?>" class="logout-btn">
                    <svg width="16" height="16" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M3 3a1 1 0 00-1 1v12a1 1 0 102 0V4a1 1 0 00-1-1zm10.293 9.293a1 1 0 001.414 1.414l3-3a1 1 0 000-1.414l-3-3a1 1 0 10-1.414 1.414L14.586 9H7a1 1 0 100 2h7.586l-1.293 1.293z" clip-rule="evenodd"/>
                    </svg>
                </a>
            </div>
        </aside>
        
        <!-- Main Content -->
        <main class="main-content">
            <header class="header">
                <h1>Dashboard</h1>
                <a href="/dash/pages/create" class="btn btn-primary">
                    <svg width="16" height="16" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clip-rule="evenodd"/>
                    </svg>
                    Create New Page
                </a>
            </header>
            
            <div class="content">
                <!-- Stats Grid -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-icon" style="background: #EEF2FF;">
                            <svg width="24" height="24" viewBox="0 0 20 20" fill="#6366F1">
                                <path d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4z"/>
                            </svg>
                        </div>
                        <div class="stat-info">
                            <h3>Pages</h3>
                            <p class="stat-value"><?php echo count($pages ?? []); ?></p>
                            <p class="stat-limit">
                                <?php 
                                $limit = $stats['pages']['limit'] ?? 0;
                                echo $limit === -1 ? 'Unlimited' : "of {$limit}";
                                ?>
                            </p>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon" style="background: #F0FDF4;">
                            <svg width="24" height="24" viewBox="0 0 20 20" fill="#22C55E">
                                <path d="M10 12a2 2 0 100-4 2 2 0 000 4z"/>
                                <path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd"/>
                            </svg>
                        </div>
                        <div class="stat-info">
                            <h3>Domains</h3>
                            <p class="stat-value"><?php echo $stats['custom_domains']['used'] ?? 0; ?></p>
                            <p class="stat-limit">
                                <?php 
                                $limit = $stats['custom_domains']['limit'] ?? 0;
                                echo $limit === -1 ? 'Unlimited' : "of {$limit}";
                                ?>
                            </p>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon" style="background: #FEF3C7;">
                            <svg width="24" height="24" viewBox="0 0 20 20" fill="#F59E0B">
                                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                            </svg>
                        </div>
                        <div class="stat-info">
                            <h3>Current Plan</h3>
                            <p class="stat-value"><?php echo esc_html($plan['name'] ?? 'Free'); ?></p>
                            <a href="/dash/billing" class="stat-link">Upgrade</a>
                        </div>
                    </div>
                </div>
                
                <!-- Recent Pages -->
                <div class="section">
                    <div class="section-header">
                        <h2>Recent Pages</h2>
                        <a href="/dash/pages" class="link">View all →</a>
                    </div>
                    
                    <?php if (empty($pages)): ?>
                        <div class="empty-state">
                            <svg width="64" height="64" viewBox="0 0 20 20" fill="#D1D5DB">
                                <path d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4z"/>
                            </svg>
                            <h3>No pages yet</h3>
                            <p>Create your first landing page to get started</p>
                            <a href="/dash/pages/create" class="btn btn-primary">Create Your First Page</a>
                        </div>
                    <?php else: ?>
                        <div class="pages-grid">
                            <?php foreach (array_slice($pages, 0, 6) as $page): ?>
                                <div class="page-card">
                                    <div class="page-card-header">
                                        <h4><?php echo esc_html($page->post_title ?: '(no title)'); ?></h4>
                                        <span class="status status-<?php echo esc_attr($page->post_status); ?>">
                                            <?php echo esc_html(ucfirst($page->post_status)); ?>
                                        </span>
                                    </div>
                                    <p class="page-date">
                                        Updated <?php echo human_time_diff(strtotime($page->post_modified), current_time('timestamp')); ?> ago
                                    </p>
                                    <div class="page-actions">
                                        <a href="/editor/<?php echo $page->ID; ?>" class="btn btn-sm">Edit</a>
                                        <?php if ($page->post_status === 'publish'): ?>
                                            <?php 
                                            $author = get_userdata($page->post_author);
                                            $pageUrl = '/' . $author->user_login . '/' . $page->post_name . '/';
                                            ?>
                                            <a href="<?php echo esc_url($pageUrl); ?>" class="btn btn-sm btn-outline" target="_blank">View</a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
    
    <script src="<?php echo QUPA_PLUGIN_URL; ?>rsc/assets/js/frontend-dashboard.js"></script>
</body>
</html>
