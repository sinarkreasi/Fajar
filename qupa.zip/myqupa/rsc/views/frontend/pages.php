<?php
require_once QUPA_PLUGIN_DIR . 'rsc/views/frontend/layout.php';
qupa_frontend_header('My Pages', 'pages');
?>

<header class="header">
    <h1>My Pages</h1>
    <button class="btn btn-primary" id="qupa-create-page-btn">
        <svg width="16" height="16" viewBox="0 0 20 20" fill="currentColor">
            <path fill-rule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clip-rule="evenodd"/>
        </svg>
        Create New Page
    </button>
</header>

<div class="content">
    <?php if (empty($pages)): ?>
        <div class="empty-state">
            <svg width="64" height="64" viewBox="0 0 20 20" fill="#D1D5DB">
                <path d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4z"/>
            </svg>
            <h3>No pages yet</h3>
            <p>Create your first landing page to get started</p>
            <button class="btn btn-primary" id="qupa-create-first-page">Create Your First Page</button>
        </div>
    <?php else: ?>
        <div class="pages-grid">
            <?php foreach ($pages as $page): ?>
                <div class="page-card">
                    <div class="page-card-header">
                        <h4><?php echo esc_html($page->post_title ?: '(no title)'); ?></h4>
                        <span class="status status-<?php echo esc_attr($page->post_status); ?>">
                            <?php echo esc_html(ucfirst($page->post_status)); ?>
                        </span>
                    </div>
                    <p class="page-date">
                        Updated <?php echo human_time_diff(strtotime($page->post_modified), current_time('timestamp')); ?> ago
                    </p>
                    <div class="page-actions">
                        <a href="/editor/<?php echo $page->ID; ?>" class="btn btn-sm">Edit</a>
                        <?php if ($page->post_status === 'publish'): ?>
                            <?php 
                            $author = get_userdata($page->post_author);
                            $pageUrl = '/' . $author->user_login . '/' . $page->post_name . '/';
                            ?>
                            <a href="<?php echo esc_url($pageUrl); ?>" class="btn btn-sm btn-outline" target="_blank">View</a>
                        <?php endif; ?>
                        <button class="btn btn-sm btn-outline qupa-delete-page" data-page-id="<?php echo $page->ID; ?>">Delete</button>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <div class="section" style="margin-top: 2rem;">
            <p style="color: var(--text-muted);">
                <?php 
                $used = count($pages);
                $limit = $stats['pages']['limit'] ?? 0;
                if ($limit === -1) {
                    printf('You have %d pages (Unlimited)', $used);
                } else {
                    printf('You have %d of %d pages', $used, $limit);
                }
                ?>
            </p>
        </div>
    <?php endif; ?>
</div>

<script>
// Simple page creation handler
document.querySelectorAll('#qupa-create-page-btn, #qupa-create-first-page').forEach(btn => {
    btn.addEventListener('click', () => {
        const title = prompt('Enter page title:');
        if (title) {
            window.location.href = '/dash/pages/create?title=' + encodeURIComponent(title);
        }
    });
});

// Delete page handler
document.querySelectorAll('.qupa-delete-page').forEach(btn => {
    btn.addEventListener('click', (e) => {
        if (confirm('Are you sure you want to delete this page?')) {
            const pageId = e.target.dataset.pageId;
            // Add AJAX delete here
            alert('Delete functionality coming soon');
        }
    });
});
</script>

<?php qupa_frontend_footer(); ?>
