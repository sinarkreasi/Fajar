<div class="wrap qupa-admin">
    <h1><?php echo esc_html__('Billing & Subscription', 'quantum-page'); ?></h1>
    
    <div class="qupa-billing-container">
        <div class="qupa-section">
            <h2><?php echo esc_html__('Current Plan', 'quantum-page'); ?></h2>
            <div class="qupa-current-plan">
                <h3><?php echo esc_html($currentPlan['name'] ?? 'Free'); ?></h3>
                <p class="qupa-plan-price">
                    <?php 
                    $price = $currentPlan['price'] ?? 0;
                    if ($price > 0) {
                        printf(esc_html__('$%d / %s', 'quantum-page'), $price, $currentPlan['billing_cycle'] ?? 'month');
                    } else {
                        echo esc_html__('Free Forever', 'quantum-page');
                    }
                    ?>
                </p>
            </div>
        </div>
        
        <div class="qupa-section">
            <h2><?php echo esc_html__('Usage Statistics', 'quantum-page'); ?></h2>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php echo esc_html__('Feature', 'quantum-page'); ?></th>
                        <th><?php echo esc_html__('Used', 'quantum-page'); ?></th>
                        <th><?php echo esc_html__('Limit', 'quantum-page'); ?></th>
                        <th><?php echo esc_html__('Available', 'quantum-page'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($stats as $feature => $data): ?>
                        <tr>
                            <td><strong><?php echo esc_html(ucwords(str_replace('_', ' ', $feature))); ?></strong></td>
                            <td><?php echo esc_html($data['used']); ?></td>
                            <td><?php echo $data['limit'] === -1 ? esc_html__('Unlimited', 'quantum-page') : esc_html($data['limit']); ?></td>
                            <td><?php echo $data['available'] === -1 ? esc_html__('Unlimited', 'quantum-page') : esc_html($data['available']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <div class="qupa-section">
            <h2><?php echo esc_html__('Available Plans', 'quantum-page'); ?></h2>
            <div class="qupa-plans-grid">
                <?php foreach ($plans as $slug => $plan): ?>
                    <div class="qupa-plan-card <?php echo $slug === ($currentPlan['slug'] ?? 'free') ? 'qupa-plan-current' : ''; ?>">
                        <h3><?php echo esc_html($plan['name']); ?></h3>
                        <p class="qupa-plan-price">
                            <?php 
                            if ($plan['price'] > 0) {
                                printf(esc_html__('$%d / %s', 'quantum-page'), $plan['price'], $plan['billing_cycle']);
                            } else {
                                echo esc_html__('Free', 'quantum-page');
                            }
                            ?>
                        </p>
                        <ul class="qupa-plan-features">
                            <?php foreach ($plan['features'] as $feature => $value): ?>
                                <li>
                                    <?php 
                                    $featureName = ucwords(str_replace('_', ' ', $feature));
                                    if ($value === true) {
                                        echo '✓ ' . esc_html($featureName);
                                    } elseif ($value === false) {
                                        echo '✗ ' . esc_html($featureName);
                                    } elseif ($value === -1) {
                                        echo '∞ ' . esc_html($featureName);
                                    } else {
                                        echo esc_html($value) . ' ' . esc_html($featureName);
                                    }
                                    ?>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                        <?php if ($slug !== ($currentPlan['slug'] ?? 'free')): ?>
                            <button class="button button-primary qupa-upgrade-plan" data-plan="<?php echo esc_attr($slug); ?>">
                                <?php echo esc_html__('Upgrade', 'quantum-page'); ?>
                            </button>
                        <?php else: ?>
                            <button class="button" disabled>
                                <?php echo esc_html__('Current Plan', 'quantum-page'); ?>
                            </button>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<style>
.qupa-billing-container .qupa-section {
    background: #fff;
    padding: 20px;
    margin-top: 20px;
    border: 1px solid #ddd;
    border-radius: 4px;
}

.qupa-current-plan {
    padding: 20px;
    background: #f0f6fc;
    border-radius: 4px;
}

.qupa-current-plan h3 {
    margin: 0 0 10px 0;
    font-size: 24px;
    color: #2271b1;
}

.qupa-plan-price {
    font-size: 18px;
    color: #666;
    margin: 0;
}

.qupa-plans-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin-top: 20px;
}

.qupa-plan-card {
    padding: 20px;
    border: 2px solid #ddd;
    border-radius: 4px;
    text-align: center;
}

.qupa-plan-current {
    border-color: #2271b1;
    background: #f0f6fc;
}

.qupa-plan-card h3 {
    margin: 0 0 10px 0;
    font-size: 20px;
}

.qupa-plan-features {
    list-style: none;
    padding: 0;
    margin: 20px 0;
    text-align: left;
}

.qupa-plan-features li {
    padding: 8px 0;
    border-bottom: 1px solid #eee;
}
</style>
