<div class="wrap qupa-admin">
    <h1><?php echo esc_html__('Quantum Page Dashboard', 'quantum-page'); ?></h1>
    
    <div class="qupa-dashboard-container">
        <div class="qupa-stats-grid">
            <div class="qupa-stat-card">
                <h3><?php echo esc_html__('Pages', 'quantum-page'); ?></h3>
                <p class="qupa-stat-value"><?php echo count($pages ?? []); ?></p>
                <p class="qupa-stat-limit">
                    <?php 
                    $limit = $stats['pages']['limit'] ?? 0;
                    echo $limit === -1 ? esc_html__('Unlimited', 'quantum-page') : sprintf(esc_html__('of %d', 'quantum-page'), $limit);
                    ?>
                </p>
            </div>
            
            <div class="qupa-stat-card">
                <h3><?php echo esc_html__('Domains', 'quantum-page'); ?></h3>
                <p class="qupa-stat-value"><?php echo $stats['custom_domains']['used'] ?? 0; ?></p>
                <p class="qupa-stat-limit">
                    <?php 
                    $limit = $stats['custom_domains']['limit'] ?? 0;
                    echo $limit === -1 ? esc_html__('Unlimited', 'quantum-page') : sprintf(esc_html__('of %d', 'quantum-page'), $limit);
                    ?>
                </p>
            </div>
            
            <div class="qupa-stat-card">
                <h3><?php echo esc_html__('Current Plan', 'quantum-page'); ?></h3>
                <p class="qupa-stat-value"><?php echo esc_html($plan['name'] ?? 'Free'); ?></p>
                <p class="qupa-stat-limit">
                    <a href="<?php echo admin_url('admin.php?page=qupa-billing'); ?>">
                        <?php echo esc_html__('Manage Plan', 'quantum-page'); ?>
                    </a>
                </p>
            </div>
        </div>
        
        <div class="qupa-section">
            <div class="qupa-section-header">
                <h2><?php echo esc_html__('Recent Pages', 'quantum-page'); ?></h2>
                <a href="<?php echo admin_url('admin.php?page=qupa-pages'); ?>" class="button button-primary">
                    <?php echo esc_html__('View All Pages', 'quantum-page'); ?>
                </a>
            </div>
            
            <?php if (empty($pages)): ?>
                <div class="qupa-empty-state">
                    <p><?php echo esc_html__('No pages yet. Create your first page!', 'quantum-page'); ?></p>
                    <a href="<?php echo admin_url('admin.php?page=qupa-pages'); ?>" class="button button-primary">
                        <?php echo esc_html__('Create Page', 'quantum-page'); ?>
                    </a>
                </div>
            <?php else: ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php echo esc_html__('Title', 'quantum-page'); ?></th>
                            <th><?php echo esc_html__('Status', 'quantum-page'); ?></th>
                            <th><?php echo esc_html__('Created', 'quantum-page'); ?></th>
                            <th><?php echo esc_html__('Actions', 'quantum-page'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach (array_slice($pages, 0, 5) as $page): ?>
                            <tr>
                                <td><strong><?php echo esc_html($page->post_title); ?></strong></td>
                                <td>
                                    <span class="qupa-status qupa-status-<?php echo esc_attr($page->post_status); ?>">
                                        <?php echo esc_html(ucfirst($page->post_status)); ?>
                                    </span>
                                </td>
                                <td><?php echo esc_html(date_i18n(get_option('date_format'), strtotime($page->post_date))); ?></td>
                                <td>
                                    <a href="<?php echo admin_url('post.php?post=' . $page->ID . '&action=edit'); ?>" class="button button-small">
                                        <?php echo esc_html__('Edit', 'quantum-page'); ?>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        
        <div class="qupa-section">
            <h2><?php echo esc_html__('Quick Actions', 'quantum-page'); ?></h2>
            <div class="qupa-quick-actions">
                <a href="<?php echo admin_url('admin.php?page=qupa-pages'); ?>" class="qupa-action-card">
                    <span class="dashicons dashicons-admin-page"></span>
                    <h3><?php echo esc_html__('Manage Pages', 'quantum-page'); ?></h3>
                    <p><?php echo esc_html__('Create and edit your landing pages', 'quantum-page'); ?></p>
                </a>
                
                <a href="<?php echo admin_url('admin.php?page=qupa-domains'); ?>" class="qupa-action-card">
                    <span class="dashicons dashicons-admin-site"></span>
                    <h3><?php echo esc_html__('Custom Domains', 'quantum-page'); ?></h3>
                    <p><?php echo esc_html__('Map custom domains to your pages', 'quantum-page'); ?></p>
                </a>
                
                <a href="<?php echo admin_url('admin.php?page=qupa-billing'); ?>" class="qupa-action-card">
                    <span class="dashicons dashicons-cart"></span>
                    <h3><?php echo esc_html__('Billing', 'quantum-page'); ?></h3>
                    <p><?php echo esc_html__('Manage your subscription plan', 'quantum-page'); ?></p>
                </a>
            </div>
        </div>
    </div>
</div>

<style>
.qupa-admin {
    margin: 20px 20px 0 0;
}

.qupa-dashboard-container {
    max-width: 1200px;
}

.qupa-stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin: 20px 0;
}

.qupa-stat-card {
    background: #fff;
    padding: 20px;
    border: 1px solid #ddd;
    border-radius: 4px;
    box-shadow: 0 1px 1px rgba(0,0,0,0.04);
}

.qupa-stat-card h3 {
    margin: 0 0 10px 0;
    font-size: 14px;
    color: #666;
    font-weight: 600;
}

.qupa-stat-value {
    font-size: 32px;
    font-weight: 700;
    color: #2271b1;
    margin: 10px 0;
}

.qupa-stat-limit {
    font-size: 13px;
    color: #666;
    margin: 0;
}

.qupa-section {
    background: #fff;
    padding: 20px;
    border: 1px solid #ddd;
    border-radius: 4px;
    margin: 20px 0;
    box-shadow: 0 1px 1px rgba(0,0,0,0.04);
}

.qupa-section h2 {
    margin-top: 0;
    font-size: 18px;
}

.qupa-section-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;
}

.qupa-section-header h2 {
    margin: 0;
}

.qupa-empty-state {
    text-align: center;
    padding: 40px;
    color: #666;
}

.qupa-empty-state p {
    margin-bottom: 20px;
}

.qupa-status {
    display: inline-block;
    padding: 3px 8px;
    border-radius: 3px;
    font-size: 12px;
    font-weight: 600;
}

.qupa-status-publish {
    background: #d4edda;
    color: #155724;
}

.qupa-status-draft {
    background: #fff3cd;
    color: #856404;
}

.qupa-quick-actions {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin-top: 20px;
}

.qupa-action-card {
    display: block;
    padding: 20px;
    border: 1px solid #ddd;
    border-radius: 4px;
    text-decoration: none;
    color: inherit;
    transition: all 0.2s;
}

.qupa-action-card:hover {
    border-color: #2271b1;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    transform: translateY(-2px);
}

.qupa-action-card .dashicons {
    font-size: 40px;
    width: 40px;
    height: 40px;
    color: #2271b1;
    margin-bottom: 10px;
}

.qupa-action-card h3 {
    margin: 10px 0;
    font-size: 16px;
    color: #2271b1;
}

.qupa-action-card p {
    margin: 0;
    font-size: 13px;
    color: #666;
}
</style>
