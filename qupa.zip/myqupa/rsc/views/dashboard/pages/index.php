<div class="wrap qupa-admin">
    <h1>
        <?php echo esc_html__('Pages', 'quantum-page'); ?>
        <a href="#" class="page-title-action" id="qupa-create-page">
            <?php echo esc_html__('Add New', 'quantum-page'); ?>
        </a>
    </h1>
    
    <div class="qupa-pages-container">
        <?php if (empty($pages)): ?>
            <div class="qupa-empty-state">
                <p><?php echo esc_html__('No pages yet. Create your first page!', 'quantum-page'); ?></p>
                <button class="button button-primary" id="qupa-create-first-page">
                    <?php echo esc_html__('Create Your First Page', 'quantum-page'); ?>
                </button>
            </div>
        <?php else: ?>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php echo esc_html__('Title', 'quantum-page'); ?></th>
                        <th><?php echo esc_html__('Status', 'quantum-page'); ?></th>
                        <th><?php echo esc_html__('Created', 'quantum-page'); ?></th>
                        <th><?php echo esc_html__('Modified', 'quantum-page'); ?></th>
                        <th><?php echo esc_html__('Actions', 'quantum-page'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($pages as $page): ?>
                        <tr>
                            <td>
                                <strong>
                                    <a href="<?php echo admin_url('post.php?post=' . $page->ID . '&action=edit'); ?>">
                                        <?php echo esc_html($page->post_title ?: __('(no title)', 'quantum-page')); ?>
                                    </a>
                                </strong>
                            </td>
                            <td>
                                <span class="qupa-status qupa-status-<?php echo esc_attr($page->post_status); ?>">
                                    <?php echo esc_html(ucfirst($page->post_status)); ?>
                                </span>
                            </td>
                            <td><?php echo esc_html(date_i18n(get_option('date_format'), strtotime($page->post_date))); ?></td>
                            <td><?php echo esc_html(date_i18n(get_option('date_format'), strtotime($page->post_modified))); ?></td>
                            <td>
                                <a href="<?php echo admin_url('post.php?post=' . $page->ID . '&action=edit'); ?>" class="button button-small">
                                    <?php echo esc_html__('Edit', 'quantum-page'); ?>
                                </a>
                                <a href="#" class="button button-small qupa-delete-page" data-page-id="<?php echo $page->ID; ?>">
                                    <?php echo esc_html__('Delete', 'quantum-page'); ?>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
        
        <div class="qupa-usage-info">
            <p>
                <?php 
                $used = count($pages);
                $limit = $stats['pages']['limit'] ?? 0;
                if ($limit === -1) {
                    printf(esc_html__('You have %d pages (Unlimited)', 'quantum-page'), $used);
                } else {
                    printf(esc_html__('You have %d of %d pages', 'quantum-page'), $used, $limit);
                }
                ?>
            </p>
        </div>
    </div>
</div>

<!-- Create Page Modal -->
<div id="qupa-create-modal" style="display:none;">
    <div class="qupa-modal-content">
        <h2><?php echo esc_html__('Create New Page', 'quantum-page'); ?></h2>
        <form id="qupa-create-form">
            <p>
                <label for="page-title"><?php echo esc_html__('Page Title', 'quantum-page'); ?></label>
                <input type="text" id="page-title" name="title" class="regular-text" required>
            </p>
            <p>
                <button type="submit" class="button button-primary">
                    <?php echo esc_html__('Create Page', 'quantum-page'); ?>
                </button>
                <button type="button" class="button qupa-close-modal">
                    <?php echo esc_html__('Cancel', 'quantum-page'); ?>
                </button>
            </p>
        </form>
    </div>
</div>

<style>
.qupa-pages-container {
    background: #fff;
    padding: 20px;
    margin-top: 20px;
    border: 1px solid #ddd;
    border-radius: 4px;
}

.qupa-empty-state {
    text-align: center;
    padding: 60px 20px;
}

.qupa-empty-state p {
    font-size: 16px;
    color: #666;
    margin-bottom: 20px;
}

.qupa-usage-info {
    margin-top: 20px;
    padding-top: 20px;
    border-top: 1px solid #ddd;
    color: #666;
}

.qupa-status {
    display: inline-block;
    padding: 3px 8px;
    border-radius: 3px;
    font-size: 12px;
    font-weight: 600;
}

.qupa-status-publish {
    background: #d4edda;
    color: #155724;
}

.qupa-status-draft {
    background: #fff3cd;
    color: #856404;
}

#qupa-create-modal {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.7);
    z-index: 100000;
    display: flex;
    align-items: center;
    justify-content: center;
}

.qupa-modal-content {
    background: #fff;
    padding: 30px;
    border-radius: 4px;
    max-width: 500px;
    width: 90%;
}

.qupa-modal-content h2 {
    margin-top: 0;
}

.qupa-modal-content label {
    display: block;
    margin-bottom: 5px;
    font-weight: 600;
}

.qupa-modal-content input[type="text"] {
    width: 100%;
}
</style>

<script>
jQuery(document).ready(function($) {
    // Create page button
    $('#qupa-create-page, #qupa-create-first-page').on('click', function(e) {
        e.preventDefault();
        $('#qupa-create-modal').show();
    });
    
    // Close modal
    $('.qupa-close-modal').on('click', function() {
        $('#qupa-create-modal').hide();
    });
    
    // Create page form
    $('#qupa-create-form').on('submit', function(e) {
        e.preventDefault();
        
        var title = $('#page-title').val();
        
        $.ajax({
            url: ajaxurl,
            method: 'POST',
            data: {
                action: 'qupa_create_page',
                title: title,
                nonce: '<?php echo wp_create_nonce('qupa_create_page'); ?>'
            },
            success: function(response) {
                if (response.success) {
                    window.location.href = '<?php echo admin_url('post.php?action=edit&post='); ?>' + response.data.page_id;
                } else {
                    alert(response.data.message || 'Failed to create page');
                }
            }
        });
    });
    
    // Delete page
    $('.qupa-delete-page').on('click', function(e) {
        e.preventDefault();
        
        if (!confirm('<?php echo esc_js(__('Are you sure you want to delete this page?', 'quantum-page')); ?>')) {
            return;
        }
        
        var pageId = $(this).data('page-id');
        
        $.ajax({
            url: ajaxurl,
            method: 'POST',
            data: {
                action: 'qupa_delete_page',
                page_id: pageId,
                nonce: '<?php echo wp_create_nonce('qupa_delete_page'); ?>'
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response.data.message || 'Failed to delete page');
                }
            }
        });
    });
});
</script>
