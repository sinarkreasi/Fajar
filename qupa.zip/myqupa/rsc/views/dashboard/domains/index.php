<div class="wrap qupa-admin">
    <h1><?php echo esc_html__('Custom Domains', 'quantum-page'); ?></h1>
    
    <div class="qupa-domains-container">
        <div class="qupa-section">
            <h2><?php echo esc_html__('Your Domains', 'quantum-page'); ?></h2>
            
            <?php if (empty($domains)): ?>
                <div class="qupa-empty-state">
                    <p><?php echo esc_html__('No custom domains configured yet.', 'quantum-page'); ?></p>
                </div>
            <?php else: ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php echo esc_html__('Domain', 'quantum-page'); ?></th>
                            <th><?php echo esc_html__('Page', 'quantum-page'); ?></th>
                            <th><?php echo esc_html__('Status', 'quantum-page'); ?></th>
                            <th><?php echo esc_html__('SSL', 'quantum-page'); ?></th>
                            <th><?php echo esc_html__('Actions', 'quantum-page'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($domains as $domain): ?>
                            <tr>
                                <td><strong><?php echo esc_html($domain->domain); ?></strong></td>
                                <td><?php echo esc_html(get_the_title($domain->page_id)); ?></td>
                                <td>
                                    <?php if ($domain->is_verified): ?>
                                        <span class="qupa-status qupa-status-verified">
                                            <?php echo esc_html__('Verified', 'quantum-page'); ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="qupa-status qupa-status-pending">
                                            <?php echo esc_html__('Pending', 'quantum-page'); ?>
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo esc_html(ucfirst($domain->ssl_status)); ?></td>
                                <td>
                                    <button class="button button-small qupa-verify-domain" data-domain-id="<?php echo $domain->id; ?>">
                                        <?php echo esc_html__('Verify', 'quantum-page'); ?>
                                    </button>
                                    <button class="button button-small qupa-delete-domain" data-domain-id="<?php echo $domain->id; ?>">
                                        <?php echo esc_html__('Delete', 'quantum-page'); ?>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        
        <div class="qupa-section">
            <h2><?php echo esc_html__('Add New Domain', 'quantum-page'); ?></h2>
            <p><?php echo esc_html__('Map a custom domain to one of your pages.', 'quantum-page'); ?></p>
            
            <form id="qupa-add-domain-form">
                <table class="form-table">
                    <tr>
                        <th><label for="domain"><?php echo esc_html__('Domain Name', 'quantum-page'); ?></label></th>
                        <td>
                            <input type="text" id="domain" name="domain" class="regular-text" placeholder="example.com" required>
                            <p class="description"><?php echo esc_html__('Enter your domain without http:// or www', 'quantum-page'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="page_id"><?php echo esc_html__('Page', 'quantum-page'); ?></label></th>
                        <td>
                            <select id="page_id" name="page_id" class="regular-text" required>
                                <option value=""><?php echo esc_html__('Select a page', 'quantum-page'); ?></option>
                                <?php
                                $pageModel = new \QUPA\Models\Page();
                                $userPages = $pageModel->findByUser(get_current_user_id());
                                foreach ($userPages as $page):
                                ?>
                                    <option value="<?php echo $page->ID; ?>">
                                        <?php echo esc_html($page->post_title); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button type="submit" class="button button-primary">
                        <?php echo esc_html__('Add Domain', 'quantum-page'); ?>
                    </button>
                </p>
            </form>
        </div>
    </div>
</div>

<style>
.qupa-domains-container .qupa-section {
    background: #fff;
    padding: 20px;
    margin-top: 20px;
    border: 1px solid #ddd;
    border-radius: 4px;
}

.qupa-status-verified {
    background: #d4edda;
    color: #155724;
}

.qupa-status-pending {
    background: #fff3cd;
    color: #856404;
}
</style>

<script>
jQuery(document).ready(function($) {
    $('#qupa-add-domain-form').on('submit', function(e) {
        e.preventDefault();
        
        var domain = $('#domain').val();
        var pageId = $('#page_id').val();
        
        $.ajax({
            url: ajaxurl,
            method: 'POST',
            data: {
                action: 'qupa_add_domain',
                domain: domain,
                page_id: pageId,
                nonce: '<?php echo wp_create_nonce('qupa_add_domain'); ?>'
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response.data.message || 'Failed to add domain');
                }
            }
        });
    });
});
</script>
