# Quantum Page (QUPA)

A mini SaaS page builder for WordPress with Laravel-style MVC architecture.

## Features

- 🎨 **Gutenberg-based Editor** - Familiar block editor with preset templates
- 🌐 **Custom Domain Mapping** - Map custom domains to your pages
- 📝 **Blog Module** - Built-in blogging functionality
- 💳 **Subscription Plans** - Free, Pro, and Business tiers
- 🔒 **Security-First** - No raw HTML/JS, secure by design
- ⚡ **Performance-Optimized** - Cacheable public pages, optimized rendering
- 🧩 **Modular Architecture** - Extensible via modules

## Requirements

- WordPress >= 6.8
- PHP >= 8.2
- Composer (for autoloading)

## Installation

1. Upload the plugin to `/wp-content/plugins/myqupa/`
2. Run `composer install` in the plugin directory
3. Activate the plugin through WordPress admin
4. Navigate to `/dashboard` to start creating pages

## Architecture

### Folder Structure

```
quantum-page/
├── app/                    # Application code
│   ├── Controllers/        # Request handlers
│   ├── Models/            # Data models
│   ├── Services/          # Business logic
│   ├── Middleware/        # Request middleware
│   └── Providers/         # Service providers
├── boot/                  # Bootstrap
├── config/                # Configuration files
├── modules/               # Feature modules
├── routes/                # Route definitions
├── rsc/                   # Resources
│   ├── views/            # View templates
│   └── assets/           # CSS/JS assets
└── quantum-page.php       # Main plugin file
```

### MVC Pattern

**Models** (`app/Models/`)
- Represent data entities (Page, Post, Domain, etc.)
- Handle database operations
- User-scoped queries
- Cache integration

**Controllers** (`app/Controllers/`)
- Handle HTTP requests
- Validate input
- Check permissions
- Return responses

**Services** (`app/Services/`)
- Business logic layer
- Reusable functionality
- Cache management
- Domain resolution
- Billing logic

### Routing

Routes are defined in `routes/web.php` and `routes/api.php`:

```php
// Web route example
'/dashboard/pages' => [PageController::class, 'index']

// API route example
'/api/pages' => [PageController::class, 'store']
```

### Custom Post Types

- `qupa_page` - Landing pages
- `qupa_post` - Blog posts

### Database Tables

- `{prefix}_qupa_domains` - Custom domain mappings
- `{prefix}_qupa_subscriptions` - User subscriptions
- `{prefix}_qupa_entitlements` - Feature quotas

## Configuration

### Plans (`config/plans.php`)

Define subscription tiers and feature limits:

```php
'pro' => [
    'name' => 'Pro',
    'price' => 29,
    'features' => [
        'pages' => 10,
        'custom_domains' => 3,
        // ...
    ],
]
```

### Features (`config/app.php`)

Enable/disable features globally:

```php
'features' => [
    'custom_domain' => true,
    'blog' => true,
    'billing' => true,
]
```

## Module Development

Create a new module in `modules/your-module/`:

```php
namespace QUPA\Modules\YourModule;

class YourmoduleModule {
    public function __construct() {
        // Initialize your module
    }
}

new YourmoduleModule();
```

Enable the module in `config/app.php`:

```php
'features' => [
    'your_module' => true,
]
```

## API Endpoints

### Pages
- `POST /api/pages` - Create page
- `PUT /api/pages/{id}` - Update page
- `DELETE /api/pages/{id}/delete` - Delete page

### Domains
- `POST /api/domains` - Add domain
- `POST /api/domains/{id}/verify` - Verify DNS
- `DELETE /api/domains/{id}/delete` - Remove domain

### Billing
- `POST /api/billing/upgrade` - Upgrade plan
- `POST /api/billing/cancel` - Cancel subscription

### Webhooks
- `POST /webhook/midtrans` - Midtrans payment webhook
- `POST /webhook/paypal` - PayPal payment webhook

## Security

- No wp-admin access for members
- No raw HTML or JavaScript allowed
- Nonce verification on all forms
- User-scoped data queries
- Permission checks on all actions

## Performance

- Object caching for models
- Domain resolution caching (24h TTL)
- Cacheable public pages
- Minimal frontend assets
- Optimized database queries

## Development

### Autoloading

PSR-4 autoloading via Composer:

```json
{
    "autoload": {
        "psr-4": {
            "QUPA\\": "app/"
        }
    }
}
```

Run `composer dump-autoload` after adding new classes.

### Hooks

**Activation**: `qupa_activate`
**Deactivation**: `qupa_deactivate`
**Module Loaded**: `qupa_module_loaded_{module_name}`

## License

GPL v2 or later

## Support

For support and documentation, visit [quantumpage.io](https://quantumpage.io)
