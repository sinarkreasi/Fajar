<?php
/**
 * Application Bootstrap
 * 
 * This file initializes the Quantum Page application.
 * It loads configuration, registers providers, and sets up the routing system.
 */

namespace QUPA;

use QUPA\Providers\RouteServiceProvider;
use QUPA\Providers\ModuleServiceProvider;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Application Container
 */
class Application {
    
    /**
     * Application instance
     */
    private static ?Application $instance = null;
    
    /**
     * Configuration array
     */
    private array $config = [];
    
    /**
     * Service providers
     */
    private array $providers = [];
    
    /**
     * Get application instance
     */
    public static function getInstance(): Application {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->loadConfiguration();
        $this->registerProviders();
        $this->boot();
    }
    
    /**
     * Load configuration files
     */
    private function loadConfiguration(): void {
        $configPath = QUPA_PLUGIN_DIR . 'config/';
        
        $configFiles = [
            'app' => $configPath . 'app.php',
            'plans' => $configPath . 'plans.php',
            'permissions' => $configPath . 'permissions.php',
        ];
        
        foreach ($configFiles as $key => $file) {
            if (file_exists($file)) {
                $this->config[$key] = require $file;
            }
        }
    }
    
    /**
     * Get configuration value
     */
    public function config(string $key, mixed $default = null): mixed {
        $keys = explode('.', $key);
        $value = $this->config;
        
        foreach ($keys as $k) {
            if (!isset($value[$k])) {
                return $default;
            }
            $value = $value[$k];
        }
        
        return $value;
    }
    
    /**
     * Register service providers
     */
    private function registerProviders(): void {
        $this->providers = [
            new RouteServiceProvider($this),
            new ModuleServiceProvider($this),
            new \QUPA\Providers\AdminServiceProvider($this),
        ];
        
        foreach ($this->providers as $provider) {
            $provider->register();
        }
    }
    
    /**
     * Boot the application
     */
    private function boot(): void {
        foreach ($this->providers as $provider) {
            $provider->boot();
        }
        
        // Ensure database tables exist
        add_action('init', [$this, 'ensureTablesExist'], 1);
        
        // Register custom post types
        add_action('init', [$this, 'registerPostTypes']);
        
        // Register database tables
        add_action('qupa_activate', [$this, 'createDatabaseTables']);
    }
    
    /**
     * Ensure database tables exist (auto-create if missing)
     */
    public function ensureTablesExist(): void {
        global $wpdb;
        
        $tables = [
            $wpdb->prefix . 'qupa_domains',
            $wpdb->prefix . 'qupa_subscriptions',
            $wpdb->prefix . 'qupa_entitlements'
        ];
        
        $missing = false;
        foreach ($tables as $table) {
            if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {
                $missing = true;
                break;
            }
        }
        
        if ($missing) {
            $this->createDatabaseTables();
        }
    }
    
    /**
     * Register custom post types
     */
    public function registerPostTypes(): void {
        // Register qupa_page CPT
        register_post_type('qupa_page', [
            'labels' => [
                'name' => __('Pages', 'quantum-page'),
                'singular_name' => __('Page', 'quantum-page'),
                'add_new' => __('Add New', 'quantum-page'),
                'add_new_item' => __('Add New Page', 'quantum-page'),
                'edit_item' => __('Edit Page', 'quantum-page'),
                'view_item' => __('View Page', 'quantum-page'),
            ],
            'public' => true,
            'publicly_queryable' => true,
            'show_ui' => true,
            'show_in_menu' => false,
            'show_in_rest' => true,
            'supports' => ['title', 'editor', 'custom-fields'],
            'capability_type' => 'post',
            'map_meta_cap' => true,
            'rewrite' => false, // Disable default rewrite, we'll handle it custom
            'has_archive' => false,
        ]);
        
        // Register qupa_post CPT
        register_post_type('qupa_post', [
            'labels' => [
                'name' => __('Posts', 'quantum-page'),
                'singular_name' => __('Post', 'quantum-page'),
                'add_new' => __('Add New', 'quantum-page'),
                'add_new_item' => __('Add New Post', 'quantum-page'),
                'edit_item' => __('Edit Post', 'quantum-page'),
                'view_item' => __('View Post', 'quantum-page'),
            ],
            'public' => true,
            'publicly_queryable' => true,
            'show_ui' => true,
            'show_in_menu' => false,
            'show_in_rest' => true,
            'supports' => ['title', 'editor', 'custom-fields', 'thumbnail'],
            'capability_type' => 'post',
            'map_meta_cap' => true,
            'rewrite' => false,
            'has_archive' => false,
        ]);
    }
    
    /**
     * Create database tables
     */
    public function createDatabaseTables(): void {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        $prefix = $wpdb->prefix;
        
        // Domains table
        $sql_domains = "CREATE TABLE IF NOT EXISTS {$prefix}qupa_domains (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id bigint(20) UNSIGNED NOT NULL,
            page_id bigint(20) UNSIGNED NOT NULL,
            domain varchar(255) NOT NULL,
            is_verified tinyint(1) DEFAULT 0,
            ssl_status varchar(50) DEFAULT 'pending',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY domain (domain),
            KEY user_id (user_id),
            KEY page_id (page_id)
        ) $charset_collate;";
        
        // Subscriptions table
        $sql_subscriptions = "CREATE TABLE IF NOT EXISTS {$prefix}qupa_subscriptions (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id bigint(20) UNSIGNED NOT NULL,
            plan_slug varchar(50) NOT NULL,
            status varchar(50) DEFAULT 'active',
            started_at datetime DEFAULT CURRENT_TIMESTAMP,
            expires_at datetime NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY user_id (user_id)
        ) $charset_collate;";
        
        // Entitlements table
        $sql_entitlements = "CREATE TABLE IF NOT EXISTS {$prefix}qupa_entitlements (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id bigint(20) UNSIGNED NOT NULL,
            feature_key varchar(100) NOT NULL,
            quota_limit int(11) DEFAULT -1,
            quota_used int(11) DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY user_feature (user_id, feature_key)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_domains);
        dbDelta($sql_subscriptions);
        dbDelta($sql_entitlements);
        
        // Add capabilities to administrator role
        $admin_role = get_role('administrator');
        if ($admin_role) {
            $admin_role->add_cap('qupa_manage_pages');
            $admin_role->add_cap('qupa_manage_domains');
            $admin_role->add_cap('qupa_view_billing');
            $admin_role->add_cap('qupa_manage_blog');
        }
        
        // Add capabilities to all users for basic access
        $roles = ['subscriber', 'contributor', 'author', 'editor'];
        foreach ($roles as $role_name) {
            $role = get_role($role_name);
            if ($role) {
                $role->add_cap('qupa_manage_pages');
                $role->add_cap('qupa_manage_domains');
                $role->add_cap('qupa_view_billing');
            }
        }
    }
}

// Initialize the application
Application::getInstance();
