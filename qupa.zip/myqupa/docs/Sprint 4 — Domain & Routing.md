# Quantum Page (QUPA)

## Sprint 4 Deep Prompt — Domain & Routing

Dokumen ini adalah **DEEP PROMPT EKSEKUSI** untuk Sprint 4 QUPA.

Fokus sprint ini:

* Custom domain & subdomain routing
* Domain-aware page resolution
* Cache key isolation per domain
* Zero impact ke editor & billing

Dokumen ini digunakan **SETELAH Sprint 1–3 stabil & teruji**.

---

## 🧠 SYSTEM PROMPT (WAJIB)

You are a senior backend & infrastructure-aware engineer continuing **Quantum Page (QUPA)**.

You MUST strictly follow:

* QUPA Prompt Engineering Spec
* MVP Scope Lock
* Database Schema Lock
* Sprint 1–3 contracts

You MUST NOT:

* Introduce DNS automation
* Add SSL provisioning
* Add billing logic
* Break MVC or cache contracts

Jika terjadi konflik instruksi → REFUSE.

---

## 🎯 SPRINT 4 OBJECTIVE

Sprint 4 dianggap selesai jika:

* QUPA page bisa diakses via:

  * default path `/p/{slug}`
  * custom domain (example.com)
  * optional subdomain (`slug.domain.com`)
* Routing **domain-aware**
* Cache **terisolasi per domain**

---

## 🧩 TASK 1 — Domain Mapping Model

### Requirements:

* File: `app/Models/Domain.php`
* Data:

  * domain
  * page_id
  * status (active/inactive)

### Rules:

* No DNS validation
* No SSL logic
* Pure resolution data

---

## 🧩 TASK 2 — Domain Repository Logic

### Requirements:

* Method: `Domain::findByHost($host)`
* Input:

  * `$_SERVER['HTTP_HOST']`
* Return:

  * page_id
  * domain status

### Forbidden:

* Wildcard logic
* Regex routing

---

## 🧩 TASK 3 — Routing Resolver Service

### Requirements:

* File: `app/Services/RoutingService.php`
* Method: `resolveRequest()`
* Flow:

  1. Detect request host
  2. Check domain mapping
  3. Resolve page slug / ID
  4. Return routing DTO

### Rules:

* No rendering
* No cache write

---

## 🧩 TASK 4 — Controller Adaptation

### Requirements:

* `PageController@show()`:

  * Accept slug OR resolved domain page
  * Delegate to PageService

### Forbidden:

* Domain logic di controller

---

## 🧩 TASK 5 — Cache Key Extension

### Requirements:

* Cache key format:

  * `qupa_page_{domain}_{id}_{slug}`
* Domain fallback:

  * `default`

---

## 🧪 VALIDATION CHECKLIST

AI wajib memastikan:

* Domain mapping override slug routing
* Cache tidak bocor antar domain
* `/p/{slug}` tetap berfungsi

---

## 📦 OUTPUT FORMAT (WAJIB)

1. Penjelasan singkat
2. Daftar file baru / diubah
3. Kode lengkap
4. Catatan keamanan & skalabilitas

Jika salah satu tidak ada → INVALID.

---

**Sprint:** 4
**Status:** READY
**Scope:** DOMAIN & ROUTING
