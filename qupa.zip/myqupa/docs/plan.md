# Quantum Page (QUPA) – Prompt Engineering Spec

Dokumen ini adalah **PROMPT MASTER** untuk Coding AI / AI Engineer.
Digunakan sebagai **instruksi tunggal** untuk menghasilkan kode, struktur folder, dan arsitektur **Quantum Page (QUPA)**.

Produk: **Mini SaaS Page Builder berbasis WordPress**
Style: **Laravel-style (MVC Pattern)**

---

## 1. Global Instruction (WAJIB DIPATUHI)

You are building a WordPress plugin named **Quantum Page (QUPA)**.

Hard constraints:

* WordPress >= 6.8
* PHP >= 8.2
* Single WordPress install (NO multisite)
* SaaS-like architecture
* Performance-first
* Security-first
* Extensible via modules/add-ons

If a feature violates any locked requirement → **DO NOT IMPLEMENT**.

---

## 2. Naming & Prefix Convention (LOCKED)

* Plugin slug: `quantum-page`
* PHP namespace root: `QUPA\`
* Function prefix: `qupa_`
* Database meta keys: `_qupa_*`
* CPT:

  * `qupa_page`
  * `qupa_post`

---

## 3. Architecture Pattern (Laravel-inspired MVC)

### 3.1 Folder Structure (MANDATORY)

```
quantum-page/
├── app/
│   ├── Controllers/
│   │   ├── PageController.php
│   │   ├── EditorController.php
│   │   ├── DomainController.php
│   │   ├── BillingController.php
│   │   └── WebhookController.php
│   ├── Models/
│   │   ├── Page.php
│   │   ├── Post.php
│   │   ├── Domain.php
│   │   ├── Subscription.php
│   │   └── Entitlement.php
│   ├── Services/
│   │   ├── RendererService.php
│   │   ├── DomainResolver.php
│   │   ├── BillingService.php
│   │   └── CacheService.php
│   ├── Middleware/
│   │   ├── AuthGuard.php
│   │   └── PlanGuard.php
│   └── Providers/
│       ├── RouteServiceProvider.php
│       └── ModuleServiceProvider.php
│
├── modules/
│   ├── billing/
│   ├── custom-domain/
│   ├── blog/
│   └── payments/
│
├── routes/
│   ├── web.php
│   └── api.php
│
├── rsc/
│   ├── views/
│   │   ├── public/
│   │   └── dashboard/
│   └── assets/
│       ├── css/
│       └── js/
│
├── boot/
│   └── app.php
│
├── config/
│   ├── app.php
│   ├── plans.php
│   └── permissions.php
│
├── quantum-page.php
└── README.md
```

---

## 4. Routing System

### Rules:

* Custom router (DO NOT rely on WP page routing)
* Routes registered via `RouteServiceProvider`
* Pattern similar to Laravel

Examples:

* `/dashboard` → DashboardController
* `/editor/{page}` → EditorController
* `{host}` → PageController@render

---

## 5. Controller Rules

* Controllers handle:

  * request validation
  * permission check
  * response rendering

* Controllers MUST NOT:

  * run raw SQL
  * handle business logic directly

---

## 6. Model Rules

* Models represent CPT & core data
* No WP_Query inside Controller
* Model methods must be:

  * scoped by user_id
  * cached when possible

---

## 7. Service Layer (CORE)

### Mandatory Services:

* `RendererService`

  * Render public page
  * No theme usage

* `DomainResolver`

  * Resolve HTTP_HOST → page_id
  * Cache mapping

* `BillingService`

  * Handle plan logic
  * Feature flags only

* `CacheService`

  * Abstraction for object cache

---

## 8. Middleware

### AuthGuard

* Ensure user is authenticated

### PlanGuard

* Check entitlements before access

---

## 9. Editor System

* Gutenberg 기반
* Kadence Blocks
* Preset-based templates
* Allowed blocks whitelist
* No raw HTML

---

## 10. Billing & Payment

* Billing via subscription

* Payment gateways:

  * Midtrans
  * PayPal

* Webhook only

* Idempotent handling

---

## 11. Performance Rules

* Public pages must be cacheable
* Domain resolution cached
* No heavy frontend assets

---

## 12. Security Rules

* No wp-admin for members
* No raw HTML or JS
* No exposed internal IDs

---

## 13. Extension System

* Modules loaded via ModuleServiceProvider
* No direct coupling to core
* Feature flags mandatory

---

## 14. AI Output Expectations

When generating code:

* Follow folder structure exactly
* Use namespaces properly
* Comment code clearly
* Do NOT add unnecessary flexibility

---

## FINAL NOTE

If a requested feature:

* increases WordPress visibility
* breaks cacheability
* bypasses feature flags

→ **REJECT IT**.