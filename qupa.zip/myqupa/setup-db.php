<?php
/**
 * Manual Database Setup Script
 * 
 * Run this file once to create the required database tables
 * Access: /wp-content/plugins/myqupa/setup-db.php
 */

// Load WordPress
require_once('../../../wp-load.php');

// Check if user is admin
if (!current_user_can('administrator')) {
    die('Access denied. Administrator only.');
}

global $wpdb;

$charset_collate = $wpdb->get_charset_collate();
$prefix = $wpdb->prefix;

echo "<h1>Quantum Page - Database Setup</h1>";
echo "<p>Creating database tables...</p>";

// Domains table
$sql_domains = "CREATE TABLE IF NOT EXISTS {$prefix}qupa_domains (
    id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id bigint(20) UNSIGNED NOT NULL,
    page_id bigint(20) UNSIGNED NOT NULL,
    domain varchar(255) NOT NULL,
    is_verified tinyint(1) DEFAULT 0,
    ssl_status varchar(50) DEFAULT 'pending',
    created_at datetime DEFAULT CURRENT_TIMESTAMP,
    updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY domain (domain),
    KEY user_id (user_id),
    KEY page_id (page_id)
) $charset_collate;";

// Subscriptions table
$sql_subscriptions = "CREATE TABLE IF NOT EXISTS {$prefix}qupa_subscriptions (
    id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id bigint(20) UNSIGNED NOT NULL,
    plan_slug varchar(50) NOT NULL,
    status varchar(50) DEFAULT 'active',
    started_at datetime DEFAULT CURRENT_TIMESTAMP,
    expires_at datetime NULL,
    created_at datetime DEFAULT CURRENT_TIMESTAMP,
    updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY user_id (user_id)
) $charset_collate;";

// Entitlements table
$sql_entitlements = "CREATE TABLE IF NOT EXISTS {$prefix}qupa_entitlements (
    id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id bigint(20) UNSIGNED NOT NULL,
    feature_key varchar(100) NOT NULL,
    quota_limit int(11) DEFAULT -1,
    quota_used int(11) DEFAULT 0,
    created_at datetime DEFAULT CURRENT_TIMESTAMP,
    updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY user_feature (user_id, feature_key)
) $charset_collate;";

require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

echo "<h2>Creating Tables:</h2>";

// Create tables
$result1 = dbDelta($sql_domains);
echo "<p>✓ Domains table: " . (empty($result1) ? "Already exists" : "Created") . "</p>";

$result2 = dbDelta($sql_subscriptions);
echo "<p>✓ Subscriptions table: " . (empty($result2) ? "Already exists" : "Created") . "</p>";

$result3 = dbDelta($sql_entitlements);
echo "<p>✓ Entitlements table: " . (empty($result3) ? "Already exists" : "Created") . "</p>";

// Add capabilities
echo "<h2>Setting up Capabilities:</h2>";

$admin_role = get_role('administrator');
if ($admin_role) {
    $admin_role->add_cap('qupa_manage_pages');
    $admin_role->add_cap('qupa_manage_domains');
    $admin_role->add_cap('qupa_view_billing');
    $admin_role->add_cap('qupa_manage_blog');
    echo "<p>✓ Administrator capabilities added</p>";
}

$roles = ['subscriber', 'contributor', 'author', 'editor'];
foreach ($roles as $role_name) {
    $role = get_role($role_name);
    if ($role) {
        $role->add_cap('qupa_manage_pages');
        $role->add_cap('qupa_manage_domains');
        $role->add_cap('qupa_view_billing');
    }
}
echo "<p>✓ User capabilities added</p>";

// Verify tables exist
echo "<h2>Verification:</h2>";

$tables = [
    "{$prefix}qupa_domains",
    "{$prefix}qupa_subscriptions",
    "{$prefix}qupa_entitlements"
];

foreach ($tables as $table) {
    $exists = $wpdb->get_var("SHOW TABLES LIKE '$table'");
    if ($exists) {
        echo "<p style='color: green;'>✓ Table $table exists</p>";
    } else {
        echo "<p style='color: red;'>✗ Table $table NOT FOUND</p>";
    }
}

echo "<h2>Done!</h2>";
echo "<p><a href='" . admin_url('admin.php?page=qupa-dashboard') . "'>Go to Quantum Page Dashboard</a></p>";
echo "<p style='color: red;'><strong>IMPORTANT: Delete this file (setup-db.php) after setup is complete!</strong></p>";
