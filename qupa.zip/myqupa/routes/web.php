<?php
/**
 * Web Routes
 * 
 * Define web application routes
 */

use QUPA\Controllers\DashboardController;
use QUPA\Controllers\PageController;
use QUPA\Controllers\EditorController;
use QUPA\Controllers\DomainController;
use QUPA\Controllers\BillingController;

return [
    // Dashboard
    '/dash' => [DashboardController::class, 'index'],
    '/dashboard' => [DashboardController::class, 'index'], // Keep for backward compatibility
    
    // Pages
    '/dash/pages' => [PageController::class, 'index'],
    '/dash/pages/create' => [PageController::class, 'create'],
    '/dash/pages/{id}/edit' => [PageController::class, 'edit'],
    '/dashboard/pages' => [PageController::class, 'index'],
    '/dashboard/pages/create' => [PageController::class, 'create'],
    '/dashboard/pages/{id}/edit' => [PageController::class, 'edit'],
    
    // Editor
    '/editor/{id}' => [EditorController::class, 'show'],
    
    // Domains
    '/dash/domains' => [DomainController::class, 'index'],
    '/dashboard/domains' => [DomainController::class, 'index'],
    
    // Billing
    '/dash/billing' => [BillingController::class, 'index'],
    '/dashboard/billing' => [BillingController::class, 'index'],
];
