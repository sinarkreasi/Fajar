<?php
/**
 * API Routes
 * 
 * Define REST API and webhook routes
 */

use QUPA\Controllers\PageController;
use QUPA\Controllers\EditorController;
use QUPA\Controllers\DomainController;
use QUPA\Controllers\BillingController;
use QUPA\Controllers\WebhookController;

return [
    // Page API
    '/api/pages' => [PageController::class, 'store'],
    '/api/pages/{id}' => [PageController::class, 'update'],
    '/api/pages/{id}/delete' => [PageController::class, 'destroy'],
    
    // Editor API
    '/api/editor/{id}/save' => [EditorController::class, 'save'],
    
    // Domain API
    '/api/domains' => [DomainController::class, 'store'],
    '/api/domains/{id}/verify' => [DomainController::class, 'verify'],
    '/api/domains/{id}/delete' => [DomainController::class, 'destroy'],
    
    // Billing API
    '/api/billing/upgrade' => [BillingController::class, 'upgrade'],
    '/api/billing/cancel' => [BillingController::class, 'cancel'],
    
    // Webhooks
    '/webhook/midtrans' => [WebhookController::class, 'midtrans'],
    '/webhook/paypal' => [WebhookController::class, 'paypal'],
];
