<?php
/**
 * Plugin Name: QUPA (Quantum Page)
 * Plugin URI: https://quantumpage.io
 * Description: Mini SaaS Page Builder for digital creator.
 * Version: 1.0.0
 * Requires at least: 6.8
 * Requires PHP: 8.2
 * Author: Quantum Page Team
 * Author URI: https://quantumpage.io
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: quantum-page
 * Domain Path: /languages
 */

namespace QUPA;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('QUPA_VERSION', '1.0.0');
define('QUPA_PLUGIN_FILE', __FILE__);
define('QUPA_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('QUPA_PLUGIN_URL', plugin_dir_url(__FILE__));
define('QUPA_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Require Composer autoloader
if (file_exists(QUPA_PLUGIN_DIR . 'vendor/autoload.php')) {
    require_once QUPA_PLUGIN_DIR . 'vendor/autoload.php';
}

/**
 * Bootstrap the application
 */
function qupa_bootstrap() {
    require_once QUPA_PLUGIN_DIR . 'boot/app.php';
}

// Initialize plugin
add_action('plugins_loaded', __NAMESPACE__ . '\\qupa_bootstrap', 10);

/**
 * Plugin activation hook
 */
register_activation_hook(__FILE__, function() {
    // Check PHP version
    if (version_compare(PHP_VERSION, '8.2', '<')) {
        deactivate_plugins(plugin_basename(__FILE__));
        wp_die(
            __('Quantum Page requires PHP 8.2 or higher.', 'quantum-page'),
            __('Plugin Activation Error', 'quantum-page'),
            ['back_link' => true]
        );
    }
    
    // Check WordPress version
    global $wp_version;
    if (version_compare($wp_version, '6.8', '<')) {
        deactivate_plugins(plugin_basename(__FILE__));
        wp_die(
            __('Quantum Page requires WordPress 6.8 or higher.', 'quantum-page'),
            __('Plugin Activation Error', 'quantum-page'),
            ['back_link' => true]
        );
    }
    
    // Run activation tasks
    do_action('qupa_activate');
    
    // Flush rewrite rules
    flush_rewrite_rules();
});

/**
 * Plugin deactivation hook
 */
register_deactivation_hook(__FILE__, function() {
    do_action('qupa_deactivate');
    flush_rewrite_rules();
});
