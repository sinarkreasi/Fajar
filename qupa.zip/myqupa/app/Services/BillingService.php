<?php
/**
 * Billing Service
 * 
 * Handles plan logic and feature entitlements
 */

namespace QUPA\Services;

use QUPA\Models\Subscription;
use QUPA\Models\Entitlement;
use QUPA\Application;

class BillingService {
    
    private Subscription $subscription;
    private Entitlement $entitlement;
    
    public function __construct() {
        $this->subscription = new Subscription();
        $this->entitlement = new Entitlement();
    }
    
    /**
     * Check if user has access to a feature
     */
    public function hasFeature(int $userId, string $feature): bool {
        $plan = $this->subscription->getUserPlan($userId);
        
        $app = Application::getInstance();
        $featureFlags = $app->config('features', []);
        
        // Check if feature is globally enabled
        if (!($featureFlags[$feature] ?? false)) {
            return false;
        }
        
        // Check plan features
        return isset($plan['features'][$feature]) && $plan['features'][$feature] !== 0;
    }
    
    /**
     * Check if user can perform an action (quota check)
     */
    public function canPerformAction(int $userId, string $action): bool {
        return $this->entitlement->checkQuota($userId, $action);
    }
    
    /**
     * Record action (increment quota)
     */
    public function recordAction(int $userId, string $action): bool {
        if (!$this->canPerformAction($userId, $action)) {
            return false;
        }
        
        return $this->entitlement->incrementUsage($userId, $action);
    }
    
    /**
     * Revert action (decrement quota)
     */
    public function revertAction(int $userId, string $action): bool {
        return $this->entitlement->decrementUsage($userId, $action);
    }
    
    /**
     * Get user's current plan
     */
    public function getUserPlan(int $userId): array {
        return $this->subscription->getUserPlan($userId);
    }
    
    /**
     * Get usage statistics
     */
    public function getUsageStats(int $userId): array {
        return $this->entitlement->getUsageStats($userId);
    }
    
    /**
     * Upgrade user to a plan
     */
    public function upgradePlan(int $userId, string $planSlug): bool {
        $app = Application::getInstance();
        $plans = $app->config('plans');
        
        if (!isset($plans[$planSlug])) {
            return false;
        }
        
        // Update subscription
        $result = $this->subscription->upsert($userId, $planSlug, 'active');
        
        if ($result) {
            // Reinitialize entitlements
            $this->entitlement->initializeForUser($userId);
        }
        
        return $result;
    }
    
    /**
     * Cancel subscription
     */
    public function cancelSubscription(int $userId): bool {
        return $this->subscription->cancel($userId);
    }
    
    /**
     * Get available plans
     */
    public function getAvailablePlans(): array {
        $app = Application::getInstance();
        return $app->config('plans', []);
    }
}
