<?php
/**
 * Renderer Service
 * 
 * Renders public pages without theme
 */

namespace QUPA\Services;

use QUPA\Models\Page;

class RendererService {
    
    private Page $pageModel;
    
    public function __construct() {
        $this->pageModel = new Page();
    }
    
    /**
     * Render a page by ID
     */
    public function render(int $pageId): void {
        $page = $this->pageModel->find($pageId);
        
        if (!$page || $page->post_status !== 'publish') {
            $this->render404();
            return;
        }
        
        // Set up WordPress query
        global $wp_query;
        $wp_query->is_404 = false;
        $wp_query->is_singular = true;
        
        // Disable theme
        add_filter('template_include', '__return_false');
        
        // Output the page
        $this->outputPage($page);
        exit;
    }
    
    /**
     * Output page HTML
     */
    private function outputPage(\WP_Post $page): void {
        // Get page metadata
        $customCss = get_post_meta($page->ID, '_qupa_custom_css', true);
        $customJs = get_post_meta($page->ID, '_qupa_custom_js', true);
        $seoTitle = get_post_meta($page->ID, '_qupa_seo_title', true) ?: $page->post_title;
        $seoDescription = get_post_meta($page->ID, '_qupa_seo_description', true);
        
        // Start output
        header('Content-Type: text/html; charset=utf-8');
        
        ?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo esc_html($seoTitle); ?></title>
    <?php if ($seoDescription): ?>
    <meta name="description" content="<?php echo esc_attr($seoDescription); ?>">
    <?php endif; ?>
    
    <?php wp_head(); ?>
    
    <?php if ($customCss): ?>
    <style>
        <?php echo wp_kses_post($customCss); ?>
    </style>
    <?php endif; ?>
    
    <style>
        body.qupa-page {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            line-height: 1.6;
            color: #333;
            margin: 0;
            padding: 0;
        }
        #qupa-content {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }
    </style>
</head>
<body class="qupa-page">
    <div id="qupa-content">
        <?php
        $content = apply_filters('the_content', $page->post_content);
        if (empty(trim(strip_tags($content)))) {
            echo '<div style="text-align: center; padding: 4rem 2rem;">';
            echo '<h1>' . esc_html($page->post_title) . '</h1>';
            echo '<p style="color: #666;">This page is empty. Edit it to add content.</p>';
            echo '</div>';
        } else {
            echo $content;
        }
        ?>
    </div>
    
    <?php wp_footer(); ?>
    
    <?php if ($customJs): ?>
    <script>
        <?php echo wp_kses_post($customJs); ?>
    </script>
    <?php endif; ?>
</body>
</html>
        <?php
    }
    
    /**
     * Render 404 page
     */
    private function render404(): void {
        global $wp_query;
        $wp_query->set_404();
        status_header(404);
        
        ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>404 - Page Not Found</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            margin: 0;
            background: #f5f5f5;
        }
        .error-container {
            text-align: center;
            padding: 2rem;
        }
        h1 {
            font-size: 4rem;
            margin: 0;
            color: #333;
        }
        p {
            font-size: 1.2rem;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="error-container">
        <h1>404</h1>
        <p>Page not found</p>
    </div>
</body>
</html>
        <?php
        exit;
    }
    
    /**
     * Check if page is cacheable
     */
    public function isCacheable(\WP_Post $page): bool {
        // Pages are cacheable if they don't have dynamic content
        // This can be extended based on specific requirements
        return $page->post_status === 'publish';
    }
}
