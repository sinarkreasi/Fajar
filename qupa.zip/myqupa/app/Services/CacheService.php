<?php
/**
 * Cache Service
 * 
 * Abstraction layer for WordPress object cache
 */

namespace QUPA\Services;

use QUPA\Application;

class CacheService {
    
    /**
     * Get cache TTL from config
     */
    private function getTtl(): int {
        $app = Application::getInstance();
        return $app->config('cache.ttl', 3600);
    }
    
    /**
     * Check if caching is enabled
     */
    private function isEnabled(): bool {
        $app = Application::getInstance();
        return $app->config('cache.enabled', true);
    }
    
    /**
     * Get value from cache
     */
    public function get(string $key, mixed $default = null): mixed {
        if (!$this->isEnabled()) {
            return $default;
        }
        
        $value = wp_cache_get($key, 'qupa');
        return $value !== false ? $value : $default;
    }
    
    /**
     * Store value in cache
     */
    public function put(string $key, mixed $value, ?int $ttl = null): bool {
        if (!$this->isEnabled()) {
            return false;
        }
        
        $ttl = $ttl ?? $this->getTtl();
        return wp_cache_set($key, $value, 'qupa', $ttl);
    }
    
    /**
     * Remember value (get or compute and store)
     */
    public function remember(string $key, callable $callback, ?int $ttl = null): mixed {
        $value = $this->get($key);
        
        if ($value !== null) {
            return $value;
        }
        
        $value = $callback();
        $this->put($key, $value, $ttl);
        
        return $value;
    }
    
    /**
     * Forget (delete) cache key
     */
    public function forget(string $key): bool {
        return wp_cache_delete($key, 'qupa');
    }
    
    /**
     * Flush cache by prefix
     */
    public function flush(string $prefix): void {
        // WordPress doesn't support prefix-based flushing natively
        // This is a placeholder for future implementation with Redis/Memcached
        wp_cache_flush();
    }
}
