<?php
/**
 * Domain Resolver Service
 * 
 * Resolves HTTP_HOST to page_id with caching
 */

namespace QUPA\Services;

use QUPA\Models\Domain;
use QUPA\Application;

class DomainResolver {
    
    private CacheService $cache;
    private Domain $domainModel;
    
    public function __construct() {
        $this->cache = new CacheService();
        $this->domainModel = new Domain();
    }
    
    /**
     * Resolve domain to page ID
     */
    public function resolve(string $host): ?int {
        // Normalize host (remove www, port, etc.)
        $domain = $this->normalizeDomain($host);
        
        // Check cache first
        $cacheKey = 'qupa_domain_resolve_' . md5($domain);
        $app = Application::getInstance();
        $ttl = $app->config('cache.domain_resolution_ttl', 86400);
        
        return $this->cache->remember($cacheKey, function() use ($domain) {
            $domainRecord = $this->domainModel->findByDomain($domain);
            
            if (!$domainRecord || !$domainRecord->is_verified) {
                return null;
            }
            
            return (int) $domainRecord->page_id;
        }, $ttl);
    }
    
    /**
     * Normalize domain name
     */
    private function normalizeDomain(string $host): string {
        // Remove port
        $host = preg_replace('/:\d+$/', '', $host);
        
        // Remove www prefix
        $host = preg_replace('/^www\./', '', $host);
        
        // Convert to lowercase
        $host = strtolower($host);
        
        return $host;
    }
    
    /**
     * Clear domain cache
     */
    public function clearCache(string $domain): void {
        $domain = $this->normalizeDomain($domain);
        $cacheKey = 'qupa_domain_resolve_' . md5($domain);
        $this->cache->forget($cacheKey);
    }
    
    /**
     * Check if current request is for a custom domain
     */
    public function isCustomDomain(): bool {
        $host = $_SERVER['HTTP_HOST'] ?? '';
        $siteHost = parse_url(get_site_url(), PHP_URL_HOST);
        
        return $this->normalizeDomain($host) !== $this->normalizeDomain($siteHost);
    }
}
