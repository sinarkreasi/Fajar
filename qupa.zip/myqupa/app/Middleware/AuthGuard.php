<?php
/**
 * Auth Guard Middleware
 * 
 * Ensures user is authenticated
 */

namespace QUPA\Middleware;

class AuthGuard {
    
    /**
     * Handle the request
     */
    public function handle(callable $next): mixed {
        if (!is_user_logged_in()) {
            $this->redirectToLogin();
            return null;
        }
        
        return $next();
    }
    
    /**
     * Redirect to login page
     */
    private function redirectToLogin(): void {
        $loginUrl = wp_login_url($_SERVER['REQUEST_URI'] ?? '');
        wp_redirect($loginUrl);
        exit;
    }
}
