<?php
/**
 * Plan Guard Middleware
 * 
 * Checks feature entitlements before access
 */

namespace QUPA\Middleware;

use QUPA\Services\BillingService;

class PlanGuard {
    
    private BillingService $billing;
    private string $requiredFeature;
    
    /**
     * Constructor
     */
    public function __construct(string $requiredFeature) {
        $this->billing = new BillingService();
        $this->requiredFeature = $requiredFeature;
    }
    
    /**
     * Handle the request
     */
    public function handle(callable $next): mixed {
        $userId = get_current_user_id();
        
        if (!$this->billing->hasFeature($userId, $this->requiredFeature)) {
            $this->showUpgradePrompt();
            return null;
        }
        
        return $next();
    }
    
    /**
     * Show upgrade prompt
     */
    private function showUpgradePrompt(): void {
        wp_die(
            __('This feature requires a plan upgrade.', 'quantum-page'),
            __('Feature Not Available', 'quantum-page'),
            [
                'back_link' => true,
                'response' => 403,
            ]
        );
    }
}
