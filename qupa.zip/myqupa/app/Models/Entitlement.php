<?php
/**
 * Entitlement Model
 * 
 * Manages feature access and resource quotas
 */

namespace QUPA\Models;

class Entitlement {
    
    /**
     * Get entitlement for a feature
     */
    public function get(int $userId, string $featureKey): ?object {
        global $wpdb;
        $table = $wpdb->prefix . 'qupa_entitlements';
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table} WHERE user_id = %d AND feature_key = %s",
            $userId,
            $featureKey
        ));
    }
    
    /**
     * Initialize entitlements for a user based on their plan
     */
    public function initializeForUser(int $userId): void {
        $subscription = new Subscription();
        $plan = $subscription->getUserPlan($userId);
        
        foreach ($plan['features'] as $feature => $limit) {
            $this->upsert($userId, $feature, $limit, 0);
        }
    }
    
    /**
     * Create or update entitlement
     */
    public function upsert(int $userId, string $featureKey, int $quotaLimit, int $quotaUsed = 0): bool {
        global $wpdb;
        $table = $wpdb->prefix . 'qupa_entitlements';
        
        $existing = $this->get($userId, $featureKey);
        
        $data = [
            'quota_limit' => $quotaLimit,
            'quota_used' => $quotaUsed,
        ];
        
        if ($existing) {
            return $wpdb->update(
                $table,
                $data,
                ['user_id' => $userId, 'feature_key' => $featureKey]
            ) !== false;
        } else {
            $data['user_id'] = $userId;
            $data['feature_key'] = $featureKey;
            return $wpdb->insert($table, $data) !== false;
        }
    }
    
    /**
     * Check if user has quota available
     */
    public function checkQuota(int $userId, string $featureKey): bool {
        $entitlement = $this->get($userId, $featureKey);
        
        if (!$entitlement) {
            // Initialize if not exists
            $this->initializeForUser($userId);
            $entitlement = $this->get($userId, $featureKey);
            
            // If still null, return true (allow by default)
            if (!$entitlement) {
                return true;
            }
        }
        
        // -1 means unlimited
        if ($entitlement->quota_limit === -1 || $entitlement->quota_limit === '-1') {
            return true;
        }
        
        return $entitlement->quota_used < $entitlement->quota_limit;
    }
    
    /**
     * Increment quota usage
     */
    public function incrementUsage(int $userId, string $featureKey): bool {
        global $wpdb;
        $table = $wpdb->prefix . 'qupa_entitlements';
        
        return $wpdb->query($wpdb->prepare(
            "UPDATE {$table} SET quota_used = quota_used + 1 WHERE user_id = %d AND feature_key = %s",
            $userId,
            $featureKey
        )) !== false;
    }
    
    /**
     * Decrement quota usage
     */
    public function decrementUsage(int $userId, string $featureKey): bool {
        global $wpdb;
        $table = $wpdb->prefix . 'qupa_entitlements';
        
        return $wpdb->query($wpdb->prepare(
            "UPDATE {$table} SET quota_used = GREATEST(0, quota_used - 1) WHERE user_id = %d AND feature_key = %s",
            $userId,
            $featureKey
        )) !== false;
    }
    
    /**
     * Get usage statistics for a user
     */
    public function getUsageStats(int $userId): array {
        global $wpdb;
        $table = $wpdb->prefix . 'qupa_entitlements';
        
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table} WHERE user_id = %d",
            $userId
        ), ARRAY_A);
        
        $stats = [];
        foreach ($results as $row) {
            $stats[$row['feature_key']] = [
                'limit' => $row['quota_limit'],
                'used' => $row['quota_used'],
                'available' => $row['quota_limit'] === -1 ? -1 : ($row['quota_limit'] - $row['quota_used']),
            ];
        }
        
        return $stats;
    }
}
