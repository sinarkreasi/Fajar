<?php
/**
 * Domain Model
 * 
 * Manages custom domain mappings
 */

namespace QUPA\Models;

class Domain {
    
    /**
     * Get domain by hostname
     */
    public function findByDomain(string $domain): ?object {
        global $wpdb;
        $table = $wpdb->prefix . 'qupa_domains';
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table} WHERE domain = %s",
            $domain
        ));
    }
    
    /**
     * Get domains for a user
     */
    public function getByUser(int $userId): array {
        global $wpdb;
        $table = $wpdb->prefix . 'qupa_domains';
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table} WHERE user_id = %d ORDER BY created_at DESC",
            $userId
        ));
    }
    
    /**
     * Get domains for a page
     */
    public function getByPage(int $pageId): array {
        global $wpdb;
        $table = $wpdb->prefix . 'qupa_domains';
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table} WHERE page_id = %d",
            $pageId
        ));
    }
    
    /**
     * Create a domain mapping
     */
    public function create(int $userId, int $pageId, string $domain): int|false {
        global $wpdb;
        $table = $wpdb->prefix . 'qupa_domains';
        
        $result = $wpdb->insert($table, [
            'user_id' => $userId,
            'page_id' => $pageId,
            'domain' => $domain,
            'is_verified' => 0,
            'ssl_status' => 'pending',
        ]);
        
        return $result ? $wpdb->insert_id : false;
    }
    
    /**
     * Update domain verification status
     */
    public function updateVerification(int $domainId, bool $verified): bool {
        global $wpdb;
        $table = $wpdb->prefix . 'qupa_domains';
        
        return $wpdb->update(
            $table,
            ['is_verified' => $verified ? 1 : 0],
            ['id' => $domainId]
        ) !== false;
    }
    
    /**
     * Update SSL status
     */
    public function updateSslStatus(int $domainId, string $status): bool {
        global $wpdb;
        $table = $wpdb->prefix . 'qupa_domains';
        
        return $wpdb->update(
            $table,
            ['ssl_status' => $status],
            ['id' => $domainId]
        ) !== false;
    }
    
    /**
     * Delete a domain
     */
    public function delete(int $domainId): bool {
        global $wpdb;
        $table = $wpdb->prefix . 'qupa_domains';
        
        return $wpdb->delete($table, ['id' => $domainId]) !== false;
    }
    
    /**
     * Check if domain exists
     */
    public function exists(string $domain): bool {
        return $this->findByDomain($domain) !== null;
    }
}
