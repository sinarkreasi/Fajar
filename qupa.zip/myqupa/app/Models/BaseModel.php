<?php
/**
 * Base Model
 * 
 * Abstract base class for all models providing common CRUD operations,
 * user scoping, and cache integration.
 */

namespace QUPA\Models;

use QUPA\Services\CacheService;

abstract class BaseModel {
    
    /**
     * Cache service instance
     */
    protected CacheService $cache;
    
    /**
     * Post type for this model
     */
    protected string $postType;
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->cache = new CacheService();
    }
    
    /**
     * Find a post by ID
     */
    public function find(int $id): ?\WP_Post {
        $cacheKey = $this->getCacheKey('post', $id);
        
        return $this->cache->remember($cacheKey, function() use ($id) {
            $post = get_post($id);
            
            if (!$post || $post->post_type !== $this->postType) {
                return null;
            }
            
            return $post;
        });
    }
    
    /**
     * Find posts by user ID
     */
    public function findByUser(int $userId, array $args = []): array {
        $cacheKey = $this->getCacheKey('user_posts', $userId, md5(serialize($args)));
        
        return $this->cache->remember($cacheKey, function() use ($userId, $args) {
            $defaults = [
                'post_type' => $this->postType,
                'author' => $userId,
                'posts_per_page' => -1,
                'post_status' => 'any',
            ];
            
            $query = new \WP_Query(array_merge($defaults, $args));
            return $query->posts;
        });
    }
    
    /**
     * Create a new post
     */
    public function create(array $data): int|false {
        $defaults = [
            'post_type' => $this->postType,
            'post_status' => 'draft',
        ];
        
        $postData = array_merge($defaults, $data);
        $postId = wp_insert_post($postData);
        
        if ($postId && !is_wp_error($postId)) {
            $this->clearUserCache($postData['post_author'] ?? get_current_user_id());
            return $postId;
        }
        
        return false;
    }
    
    /**
     * Update a post
     */
    public function update(int $id, array $data): bool {
        $data['ID'] = $id;
        $result = wp_update_post($data);
        
        if ($result && !is_wp_error($result)) {
            $post = get_post($id);
            $this->clearCache($id);
            $this->clearUserCache($post->post_author);
            return true;
        }
        
        return false;
    }
    
    /**
     * Delete a post
     */
    public function delete(int $id, bool $force = false): bool {
        $post = get_post($id);
        
        if (!$post) {
            return false;
        }
        
        $result = wp_delete_post($id, $force);
        
        if ($result) {
            $this->clearCache($id);
            $this->clearUserCache($post->post_author);
            return true;
        }
        
        return false;
    }
    
    /**
     * Get meta value
     */
    public function getMeta(int $postId, string $key, bool $single = true): mixed {
        return get_post_meta($postId, '_qupa_' . $key, $single);
    }
    
    /**
     * Update meta value
     */
    public function updateMeta(int $postId, string $key, mixed $value): bool {
        $result = update_post_meta($postId, '_qupa_' . $key, $value);
        $this->clearCache($postId);
        return $result !== false;
    }
    
    /**
     * Delete meta value
     */
    public function deleteMeta(int $postId, string $key): bool {
        $result = delete_post_meta($postId, '_qupa_' . $key);
        $this->clearCache($postId);
        return $result;
    }
    
    /**
     * Get cache key
     */
    protected function getCacheKey(string $type, ...$parts): string {
        return 'qupa_' . $this->postType . '_' . $type . '_' . implode('_', $parts);
    }
    
    /**
     * Clear cache for a specific post
     */
    protected function clearCache(int $postId): void {
        $this->cache->forget($this->getCacheKey('post', $postId));
    }
    
    /**
     * Clear cache for a user's posts
     */
    protected function clearUserCache(int $userId): void {
        $this->cache->flush('qupa_' . $this->postType . '_user_posts_' . $userId);
    }
}
