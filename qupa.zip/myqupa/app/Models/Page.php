<?php
/**
 * Page Model
 * 
 * Represents a QUPA landing page (qupa_page CPT)
 */

namespace QUPA\Models;

class Page extends BaseModel {
    
    protected string $postType = 'qupa_page';
    
    /**
     * Get page with domain associations
     */
    public function getWithDomains(int $pageId): ?array {
        $page = $this->find($pageId);
        
        if (!$page) {
            return null;
        }
        
        global $wpdb;
        $table = $wpdb->prefix . 'qupa_domains';
        
        $domains = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table} WHERE page_id = %d",
            $pageId
        ));
        
        return [
            'page' => $page,
            'domains' => $domains,
        ];
    }
    
    /**
     * Get published pages for user
     */
    public function getPublishedByUser(int $userId): array {
        return $this->findByUser($userId, [
            'post_status' => 'publish',
        ]);
    }
    
    /**
     * Check if user can create more pages
     */
    public function canUserCreatePage(int $userId): bool {
        $entitlement = new Entitlement();
        return $entitlement->checkQuota($userId, 'pages');
    }
    
    /**
     * Publish a page
     */
    public function publish(int $pageId): bool {
        return $this->update($pageId, [
            'post_status' => 'publish',
        ]);
    }
    
    /**
     * Unpublish a page
     */
    public function unpublish(int $pageId): bool {
        return $this->update($pageId, [
            'post_status' => 'draft',
        ]);
    }
}
