<?php
/**
 * Subscription Model
 * 
 * Manages user subscription plans
 */

namespace QUPA\Models;

use QUPA\Application;

class Subscription {
    
    /**
     * Get subscription for a user
     */
    public function getByUser(int $userId): ?object {
        global $wpdb;
        $table = $wpdb->prefix . 'qupa_subscriptions';
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table} WHERE user_id = %d",
            $userId
        ));
    }
    
    /**
     * Create or update subscription
     */
    public function upsert(int $userId, string $planSlug, string $status = 'active', ?string $expiresAt = null): bool {
        global $wpdb;
        $table = $wpdb->prefix . 'qupa_subscriptions';
        
        $existing = $this->getByUser($userId);
        
        $data = [
            'plan_slug' => $planSlug,
            'status' => $status,
            'expires_at' => $expiresAt,
        ];
        
        if ($existing) {
            return $wpdb->update($table, $data, ['user_id' => $userId]) !== false;
        } else {
            $data['user_id'] = $userId;
            return $wpdb->insert($table, $data) !== false;
        }
    }
    
    /**
     * Get user's plan
     */
    public function getUserPlan(int $userId): array {
        $subscription = $this->getByUser($userId);
        
        if (!$subscription || $subscription->status !== 'active') {
            return $this->getDefaultPlan();
        }
        
        // Check expiration
        if ($subscription->expires_at && strtotime($subscription->expires_at) < time()) {
            return $this->getDefaultPlan();
        }
        
        $app = Application::getInstance();
        $plans = $app->config('plans');
        
        return $plans[$subscription->plan_slug] ?? $this->getDefaultPlan();
    }
    
    /**
     * Get default (free) plan
     */
    private function getDefaultPlan(): array {
        $app = Application::getInstance();
        $plans = $app->config('plans');
        return $plans['free'];
    }
    
    /**
     * Check if subscription is active
     */
    public function isActive(int $userId): bool {
        $subscription = $this->getByUser($userId);
        
        if (!$subscription) {
            return false;
        }
        
        if ($subscription->status !== 'active') {
            return false;
        }
        
        if ($subscription->expires_at && strtotime($subscription->expires_at) < time()) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Cancel subscription
     */
    public function cancel(int $userId): bool {
        global $wpdb;
        $table = $wpdb->prefix . 'qupa_subscriptions';
        
        return $wpdb->update(
            $table,
            ['status' => 'cancelled'],
            ['user_id' => $userId]
        ) !== false;
    }
}
