<?php
/**
 * Post Model
 * 
 * Represents a QUPA blog post (qupa_post CPT)
 */

namespace QUPA\Models;

class Post extends BaseModel {
    
    protected string $postType = 'qupa_post';
    
    /**
     * Get posts for a specific page
     */
    public function getByPage(int $pageId): array {
        $cacheKey = $this->getCacheKey('page_posts', $pageId);
        
        return $this->cache->remember($cacheKey, function() use ($pageId) {
            return $this->findByUser(get_current_user_id(), [
                'meta_query' => [
                    [
                        'key' => '_qupa_page_id',
                        'value' => $pageId,
                    ],
                ],
            ]);
        });
    }
    
    /**
     * Associate post with a page
     */
    public function associateWithPage(int $postId, int $pageId): bool {
        return $this->updateMeta($postId, 'page_id', $pageId);
    }
    
    /**
     * Get published posts
     */
    public function getPublished(int $userId, int $limit = 10): array {
        return $this->findByUser($userId, [
            'post_status' => 'publish',
            'posts_per_page' => $limit,
            'orderby' => 'date',
            'order' => 'DESC',
        ]);
    }
}
