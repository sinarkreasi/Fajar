<?php
/**
 * Domain Controller
 * 
 * Manages custom domain mappings
 */

namespace QUPA\Controllers;

use QUPA\Models\Domain;
use QUPA\Services\BillingService;
use QUPA\Services\DomainResolver;

class DomainController extends BaseController {
    
    private Domain $domainModel;
    private BillingService $billing;
    private DomainResolver $resolver;
    
    public function __construct() {
        $this->domainModel = new Domain();
        $this->billing = new BillingService();
        $this->resolver = new DomainResolver();
    }
    
    /**
     * List user's domains
     */
    public function index(): void {
        $userId = $this->getCurrentUserId();
        $domains = $this->domainModel->getByUser($userId);
        $plan = $this->billing->getUserPlan($userId);
        $stats = $this->billing->getUsageStats($userId);
        
        $this->view('frontend/domains', [
            'domains' => $domains,
            'plan' => $plan,
            'stats' => $stats,
        ]);
    }
    
    /**
     * Add a new domain
     */
    public function store(): void {
        $userId = $this->getCurrentUserId();
        
        // Check feature access
        if (!$this->billing->hasFeature($userId, 'custom_domain')) {
            $this->error('Custom domains not available in your plan.', 403);
            return;
        }
        
        // Check quota
        if (!$this->billing->canPerformAction($userId, 'custom_domains')) {
            $this->error('Domain limit reached. Please upgrade your plan.');
            return;
        }
        
        $domain = sanitize_text_field($_POST['domain'] ?? '');
        $pageId = intval($_POST['page_id'] ?? 0);
        
        if (empty($domain)) {
            $this->error('Domain is required.');
            return;
        }
        
        // Check if domain already exists
        if ($this->domainModel->exists($domain)) {
            $this->error('Domain already exists.');
            return;
        }
        
        $domainId = $this->domainModel->create($userId, $pageId, $domain);
        
        if ($domainId) {
            $this->billing->recordAction($userId, 'custom_domains');
            $this->success(['domain_id' => $domainId], 'Domain added successfully. Please configure DNS settings.');
        } else {
            $this->error('Failed to add domain.');
        }
    }
    
    /**
     * Verify domain DNS
     */
    public function verify(int $domainId): void {
        $domain = $this->domainModel->findByDomain($_POST['domain'] ?? '');
        
        if (!$domain || $domain->user_id != $this->getCurrentUserId()) {
            $this->error('Domain not found or access denied.', 403);
            return;
        }
        
        // Perform DNS verification (simplified)
        $verified = $this->verifyDns($domain->domain);
        
        if ($verified) {
            $this->domainModel->updateVerification($domainId, true);
            $this->resolver->clearCache($domain->domain);
            $this->success(null, 'Domain verified successfully.');
        } else {
            $this->error('DNS verification failed. Please check your DNS settings.');
        }
    }
    
    /**
     * Delete a domain
     */
    public function destroy(int $domainId): void {
        global $wpdb;
        $table = $wpdb->prefix . 'qupa_domains';
        
        $domain = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table} WHERE id = %d",
            $domainId
        ));
        
        if (!$domain || $domain->user_id != $this->getCurrentUserId()) {
            $this->error('Domain not found or access denied.', 403);
            return;
        }
        
        if ($this->domainModel->delete($domainId)) {
            $this->billing->revertAction($this->getCurrentUserId(), 'custom_domains');
            $this->resolver->clearCache($domain->domain);
            $this->success(null, 'Domain deleted successfully.');
        } else {
            $this->error('Failed to delete domain.');
        }
    }
    
    /**
     * Verify DNS (simplified implementation)
     */
    private function verifyDns(string $domain): bool {
        // In production, this would check DNS records
        // For now, return true for demonstration
        return true;
    }
}
