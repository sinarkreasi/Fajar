<?php
/**
 * Billing Controller
 * 
 * Handles billing and subscription management
 */

namespace QUPA\Controllers;

use QUPA\Services\BillingService;

class BillingController extends BaseController {
    
    private BillingService $billing;
    
    public function __construct() {
        $this->billing = new BillingService();
    }
    
    /**
     * Show billing dashboard
     */
    public function index(): void {
        $userId = $this->getCurrentUserId();
        $plan = $this->billing->getUserPlan($userId);
        $stats = $this->billing->getUsageStats($userId);
        $availablePlans = $this->billing->getAvailablePlans();
        
        $this->view('frontend/billing', [
            'currentPlan' => $plan,
            'stats' => $stats,
            'plans' => $availablePlans,
            'plan' => $plan,
        ]);
    }
    
    /**
     * Upgrade to a plan
     */
    public function upgrade(): void {
        $userId = $this->getCurrentUserId();
        $planSlug = sanitize_text_field($_POST['plan'] ?? '');
        
        if (empty($planSlug)) {
            $this->error('Plan is required.');
            return;
        }
        
        // In production, this would redirect to payment gateway
        // For now, directly upgrade
        $result = $this->billing->upgradePlan($userId, $planSlug);
        
        if ($result) {
            $this->success(null, 'Plan upgraded successfully.');
        } else {
            $this->error('Failed to upgrade plan.');
        }
    }
    
    /**
     * Cancel subscription
     */
    public function cancel(): void {
        $userId = $this->getCurrentUserId();
        
        $result = $this->billing->cancelSubscription($userId);
        
        if ($result) {
            $this->success(null, 'Subscription cancelled.');
        } else {
            $this->error('Failed to cancel subscription.');
        }
    }
}
