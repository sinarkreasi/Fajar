<?php
/**
 * Base Controller
 * 
 * Provides common functionality for all controllers
 */

namespace QUPA\Controllers;

abstract class BaseController {
    
    /**
     * Validate nonce
     */
    protected function validateNonce(string $action): bool {
        $nonce = $_REQUEST['_wpnonce'] ?? '';
        return wp_verify_nonce($nonce, $action);
    }
    
    /**
     * Check user permission
     */
    protected function checkPermission(string $capability): bool {
        return current_user_can($capability);
    }
    
    /**
     * Get current user ID
     */
    protected function getCurrentUserId(): int {
        return get_current_user_id();
    }
    
    /**
     * Render view
     */
    protected function view(string $view, array $data = []): void {
        extract($data);
        
        $viewPath = QUPA_PLUGIN_DIR . 'rsc/views/' . $view . '.php';
        
        if (!file_exists($viewPath)) {
            wp_die('View not found: ' . esc_html($view));
        }
        
        include $viewPath;
    }
    
    /**
     * JSON response
     */
    protected function json(array $data, int $statusCode = 200): void {
        wp_send_json($data, $statusCode);
    }
    
    /**
     * Success JSON response
     */
    protected function success(mixed $data = null, string $message = ''): void {
        $this->json([
            'success' => true,
            'message' => $message,
            'data' => $data,
        ]);
    }
    
    /**
     * Error JSON response
     */
    protected function error(string $message, int $code = 400): void {
        $this->json([
            'success' => false,
            'message' => $message,
        ], $code);
    }
    
    /**
     * Redirect
     */
    protected function redirect(string $url): void {
        wp_redirect($url);
        exit;
    }
}
