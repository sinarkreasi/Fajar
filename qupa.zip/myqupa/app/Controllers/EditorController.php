<?php
/**
 * Editor Controller
 * 
 * Handles Gutenberg editor interface
 */

namespace QUPA\Controllers;

use QUPA\Models\Page;

class EditorController extends BaseController {
    
    private Page $pageModel;
    
    public function __construct() {
        $this->pageModel = new Page();
    }
    
    /**
     * Show editor for a page
     */
    public function show(int $pageId): void {
        $page = $this->pageModel->find($pageId);
        
        if (!$page || $page->post_author != $this->getCurrentUserId()) {
            wp_die('Page not found or access denied.');
        }
        
        // Load Gutenberg editor
        $this->loadGutenbergEditor($page);
    }
    
    /**
     * Load Gutenberg editor
     */
    private function loadGutenbergEditor(\WP_Post $page): void {
        // Use frontend editor
        $this->view('frontend/editor', ['page' => $page]);
    }
    
    /**
     * Save page content
     */
    public function save(int $pageId): void {
        $page = $this->pageModel->find($pageId);
        
        if (!$page || $page->post_author != $this->getCurrentUserId()) {
            $this->error('Page not found or access denied.', 403);
            return;
        }
        
        $content = wp_kses_post($_POST['content'] ?? '');
        
        $result = $this->pageModel->update($pageId, [
            'post_content' => $content,
        ]);
        
        if ($result) {
            $this->success(null, 'Page saved successfully.');
        } else {
            $this->error('Failed to save page.');
        }
    }
}
