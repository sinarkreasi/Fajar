<?php
/**
 * Webhook Controller
 * 
 * Handles payment gateway webhooks
 */

namespace QUPA\Controllers;

use QUPA\Services\BillingService;

class WebhookController extends BaseController {
    
    private BillingService $billing;
    
    public function __construct() {
        $this->billing = new BillingService();
    }
    
    /**
     * Handle Midtrans webhook
     */
    public function midtrans(): void {
        $payload = file_get_contents('php://input');
        $data = json_decode($payload, true);
        
        // Verify signature (implement based on Midtrans docs)
        if (!$this->verifyMidtransSignature($data)) {
            $this->error('Invalid signature.', 401);
            return;
        }
        
        // Process webhook
        $this->processPayment($data);
    }
    
    /**
     * Handle PayPal webhook
     */
    public function paypal(): void {
        $payload = file_get_contents('php://input');
        $data = json_decode($payload, true);
        
        // Verify webhook (implement based on PayPal docs)
        if (!$this->verifyPayPalWebhook($data)) {
            $this->error('Invalid webhook.', 401);
            return;
        }
        
        // Process webhook
        $this->processPayment($data);
    }
    
    /**
     * Process payment (idempotent)
     */
    private function processPayment(array $data): void {
        $transactionId = $data['transaction_id'] ?? '';
        $userId = $data['user_id'] ?? 0;
        $planSlug = $data['plan'] ?? '';
        
        // Check if already processed (idempotency)
        if ($this->isProcessed($transactionId)) {
            $this->success(null, 'Already processed.');
            return;
        }
        
        // Upgrade plan
        $result = $this->billing->upgradePlan($userId, $planSlug);
        
        if ($result) {
            $this->markAsProcessed($transactionId);
            $this->success(null, 'Payment processed.');
        } else {
            $this->error('Failed to process payment.');
        }
    }
    
    /**
     * Verify Midtrans signature
     */
    private function verifyMidtransSignature(array $data): bool {
        // Implement signature verification
        return true;
    }
    
    /**
     * Verify PayPal webhook
     */
    private function verifyPayPalWebhook(array $data): bool {
        // Implement webhook verification
        return true;
    }
    
    /**
     * Check if transaction is already processed
     */
    private function isProcessed(string $transactionId): bool {
        return get_transient('qupa_tx_' . $transactionId) !== false;
    }
    
    /**
     * Mark transaction as processed
     */
    private function markAsProcessed(string $transactionId): void {
        set_transient('qupa_tx_' . $transactionId, true, WEEK_IN_SECONDS);
    }
}
