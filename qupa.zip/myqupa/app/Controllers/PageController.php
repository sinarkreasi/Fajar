<?php
/**
 * Page Controller
 * 
 * Handles page management and rendering
 */

namespace QUPA\Controllers;

use QUPA\Models\Page;
use QUPA\Services\RendererService;
use QUPA\Services\BillingService;

class PageController extends BaseController {
    
    private Page $pageModel;
    private RendererService $renderer;
    private BillingService $billing;
    
    public function __construct() {
        $this->pageModel = new Page();
        $this->renderer = new RendererService();
        $this->billing = new BillingService();
    }
    
    /**
     * List user's pages
     */
    public function index(): void {
        $userId = $this->getCurrentUserId();
        $pages = $this->pageModel->findByUser($userId);
        $stats = $this->billing->getUsageStats($userId);
        $plan = $this->billing->getUserPlan($userId);
        
        $this->view('frontend/pages', [
            'pages' => $pages,
            'stats' => $stats,
            'plan' => $plan,
        ]);
    }
    
    /**
     * Create a new page
     */
    public function create(): void {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->store();
            return;
        }
        
        $this->view('dashboard/pages/create');
    }
    
    /**
     * Store a new page
     */
    public function store(): void {
        $userId = $this->getCurrentUserId();
        
        // Check quota
        if (!$this->billing->canPerformAction($userId, 'pages')) {
            $this->error('Page limit reached. Please upgrade your plan.');
            return;
        }
        
        $title = sanitize_text_field($_POST['title'] ?? '');
        
        if (empty($title)) {
            $this->error('Title is required.');
            return;
        }
        
        $pageId = $this->pageModel->create([
            'post_title' => $title,
            'post_author' => $userId,
            'post_status' => 'draft',
        ]);
        
        if ($pageId) {
            $this->billing->recordAction($userId, 'pages');
            $this->success(['page_id' => $pageId], 'Page created successfully.');
        } else {
            $this->error('Failed to create page.');
        }
    }
    
    /**
     * Edit a page
     */
    public function edit(int $pageId): void {
        $page = $this->pageModel->find($pageId);
        
        if (!$page || $page->post_author != $this->getCurrentUserId()) {
            wp_die('Page not found or access denied.');
        }
        
        $this->view('dashboard/pages/edit', ['page' => $page]);
    }
    
    /**
     * Update a page
     */
    public function update(int $pageId): void {
        $page = $this->pageModel->find($pageId);
        
        if (!$page || $page->post_author != $this->getCurrentUserId()) {
            $this->error('Page not found or access denied.', 403);
            return;
        }
        
        $title = sanitize_text_field($_POST['title'] ?? '');
        $content = wp_kses_post($_POST['content'] ?? '');
        
        $result = $this->pageModel->update($pageId, [
            'post_title' => $title,
            'post_content' => $content,
        ]);
        
        if ($result) {
            $this->success(null, 'Page updated successfully.');
        } else {
            $this->error('Failed to update page.');
        }
    }
    
    /**
     * Delete a page
     */
    public function destroy(int $pageId): void {
        $page = $this->pageModel->find($pageId);
        
        if (!$page || $page->post_author != $this->getCurrentUserId()) {
            $this->error('Page not found or access denied.', 403);
            return;
        }
        
        if ($this->pageModel->delete($pageId)) {
            $this->billing->revertAction($this->getCurrentUserId(), 'pages');
            $this->success(null, 'Page deleted successfully.');
        } else {
            $this->error('Failed to delete page.');
        }
    }
    
    /**
     * Render public page
     */
    public function render(int $pageId): void {
        $this->renderer->render($pageId);
    }
}
