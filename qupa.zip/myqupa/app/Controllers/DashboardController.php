<?php
/**
 * Dashboard Controller
 * 
 * Handles main dashboard display
 */

namespace QUPA\Controllers;

use QUPA\Models\Page;
use QUPA\Services\BillingService;

class DashboardController extends BaseController {
    
    private Page $pageModel;
    private BillingService $billing;
    
    public function __construct() {
        $this->pageModel = new Page();
        $this->billing = new BillingService();
    }
    
    /**
     * Show main dashboard
     */
    public function index(): void {
        $userId = $this->getCurrentUserId();
        $pages = $this->pageModel->findByUser($userId);
        $stats = $this->billing->getUsageStats($userId);
        $plan = $this->billing->getUserPlan($userId);
        
        $this->view('frontend/dash', [
            'pages' => $pages,
            'stats' => $stats,
            'plan' => $plan,
        ]);
    }
}
