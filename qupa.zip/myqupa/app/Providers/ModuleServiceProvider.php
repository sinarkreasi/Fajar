<?php
/**
 * Module Service Provider
 * 
 * Loads and manages plugin modules
 */

namespace QUPA\Providers;

use QUPA\Application;

class ModuleServiceProvider {
    
    private Application $app;
    private array $modules = [];
    
    public function __construct(Application $app) {
        $this->app = $app;
    }
    
    /**
     * Register modules
     */
    public function register(): void {
        $this->discoverModules();
    }
    
    /**
     * Boot modules
     */
    public function boot(): void {
        foreach ($this->modules as $module) {
            if ($this->isModuleEnabled($module)) {
                $this->loadModule($module);
            }
        }
    }
    
    /**
     * Discover available modules
     */
    private function discoverModules(): void {
        $modulesPath = QUPA_PLUGIN_DIR . 'modules/';
        
        if (!is_dir($modulesPath)) {
            return;
        }
        
        $dirs = scandir($modulesPath);
        
        foreach ($dirs as $dir) {
            if ($dir === '.' || $dir === '..') {
                continue;
            }
            
            $modulePath = $modulesPath . $dir;
            
            if (is_dir($modulePath)) {
                $this->modules[] = $dir;
            }
        }
    }
    
    /**
     * Check if module is enabled
     */
    private function isModuleEnabled(string $module): bool {
        // Map module directory names to feature flags
        $featureMap = [
            'billing' => 'billing',
            'custom-domain' => 'custom_domain',
            'blog' => 'blog',
            'payments' => 'payments',
        ];
        
        $feature = $featureMap[$module] ?? null;
        
        if (!$feature) {
            return false;
        }
        
        return $this->app->config('features.' . $feature, false);
    }
    
    /**
     * Load a module
     */
    private function loadModule(string $module): void {
        $modulePath = QUPA_PLUGIN_DIR . 'modules/' . $module . '/';
        $moduleFile = $modulePath . ucfirst(str_replace('-', '', $module)) . 'Module.php';
        
        if (file_exists($moduleFile)) {
            require_once $moduleFile;
            
            // Call module init hook
            do_action('qupa_module_loaded_' . $module);
        }
    }
}
