<?php
/**
 * Route Service Provider
 * 
 * Registers and handles routing
 */

namespace QUPA\Providers;

use QUPA\Application;
use QUPA\Services\DomainResolver;
use QUPA\Controllers\PageController;

class RouteServiceProvider {
    
    private Application $app;
    private array $routes = [];
    
    public function __construct(Application $app) {
        $this->app = $app;
    }
    
    /**
     * Register routes
     */
    public function register(): void {
        // Load route files
        $this->loadRoutes();
    }
    
    /**
     * Boot the provider
     */
    public function boot(): void {
        // Handle custom routes on init (early)
        add_action('init', [$this, 'handleRoutes'], 999);
        
        // Handle user-based page URLs
        add_action('template_redirect', [$this, 'handleUserPages'], 5);
        
        // Handle custom domain routing
        add_action('template_redirect', [$this, 'handleCustomDomain'], 1);
    }
    
    /**
     * Handle user-based page URLs (/{username}/{page-slug})
     */
    public function handleUserPages(): void {
        $requestUri = $_SERVER['REQUEST_URI'] ?? '';
        $path = parse_url($requestUri, PHP_URL_PATH);
        $path = trim($path, '/');
        
        // Split path into parts
        $parts = explode('/', $path);
        
        // Check if it matches /{username}/{page-slug} pattern
        if (count($parts) === 2) {
            $username = $parts[0];
            $pageSlug = $parts[1];
            
            // Get user by username
            $user = get_user_by('login', $username);
            if (!$user) {
                return; // Not a user page, let WordPress handle it
            }
            
            // Find page by slug and user
            $args = [
                'post_type' => 'qupa_page',
                'name' => $pageSlug,
                'author' => $user->ID,
                'post_status' => 'publish',
                'posts_per_page' => 1,
            ];
            
            $query = new \WP_Query($args);
            
            if ($query->have_posts()) {
                $page = $query->posts[0];
                
                // Render the page
                $controller = new PageController();
                $controller->render($page->ID);
                exit;
            }
        }
    }
    
    /**
     * Handle custom routes
     */
    public function handleRoutes(): void {
        $requestUri = $_SERVER['REQUEST_URI'] ?? '';
        $path = parse_url($requestUri, PHP_URL_PATH);
        
        // Remove trailing slash
        $path = rtrim($path, '/');
        
        // Check if this is one of our routes
        foreach ($this->routes['web'] ?? [] as $pattern => $handler) {
            if ($this->matchRoute($pattern, $path, $matches)) {
                // Execute our route
                $this->executeRoute($handler, $matches);
                exit;
            }
        }
    }
    
    /**
     * Load route files
     */
    private function loadRoutes(): void {
        $webRoutes = QUPA_PLUGIN_DIR . 'routes/web.php';
        $apiRoutes = QUPA_PLUGIN_DIR . 'routes/api.php';
        
        if (file_exists($webRoutes)) {
            $this->routes['web'] = require $webRoutes;
        }
        
        if (file_exists($apiRoutes)) {
            $this->routes['api'] = require $apiRoutes;
        }
    }
    
    /**
     * Handle custom domain requests
     */
    public function handleCustomDomain(): void {
        $resolver = new DomainResolver();
        
        if (!$resolver->isCustomDomain()) {
            return;
        }
        
        $host = $_SERVER['HTTP_HOST'] ?? '';
        $pageId = $resolver->resolve($host);
        
        if ($pageId) {
            $controller = new PageController();
            $controller->render($pageId);
        }
    }
    
    
    /**
     * Match route pattern
     */
    private function matchRoute(string $pattern, string $path, &$matches): bool {
        // Convert route pattern to regex
        $regex = preg_replace('/\{(\w+)\}/', '(?P<$1>[^/]+)', $pattern);
        $regex = '#^' . $regex . '$#';
        
        return preg_match($regex, $path, $matches) === 1;
    }
    
    /**
     * Execute route handler
     */
    private function executeRoute(array $handler, array $matches): void {
        [$controller, $method] = $handler;
        
        // Extract parameters
        $params = array_filter($matches, 'is_string', ARRAY_FILTER_USE_KEY);
        
        // Instantiate controller
        $controllerInstance = new $controller();
        
        // Call method with parameters
        call_user_func_array([$controllerInstance, $method], array_values($params));
    }
}
