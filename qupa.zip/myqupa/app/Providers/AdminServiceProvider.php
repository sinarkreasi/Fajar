<?php
/**
 * Admin Service Provider
 * 
 * Registers WordPress admin menus and hooks
 */

namespace QUPA\Providers;

use QUPA\Application;
use QUPA\Controllers\DashboardController;
use QUPA\Controllers\PageController;
use QUPA\Controllers\DomainController;
use QUPA\Controllers\BillingController;

class AdminServiceProvider {
    
    private Application $app;
    
    public function __construct(Application $app) {
        $this->app = $app;
    }
    
    /**
     * Register admin hooks
     */
    public function register(): void {
        // Register admin menu
        add_action('admin_menu', [$this, 'registerMenu']);
        
        // Enqueue admin assets
        add_action('admin_enqueue_scripts', [$this, 'enqueueAssets']);
        
        // AJAX handlers
        add_action('wp_ajax_qupa_create_page', [$this, 'ajaxCreatePage']);
        add_action('wp_ajax_qupa_delete_page', [$this, 'ajaxDeletePage']);
        add_action('wp_ajax_qupa_add_domain', [$this, 'ajaxAddDomain']);
        add_action('wp_ajax_qupa_verify_domain', [$this, 'ajaxVerifyDomain']);
        add_action('wp_ajax_qupa_delete_domain', [$this, 'ajaxDeleteDomain']);
    }
    
    /**
     * Boot the provider
     */
    public function boot(): void {
        // Additional boot logic if needed
    }
    
    /**
     * Register admin menu
     */
    public function registerMenu(): void {
        // Main menu
        add_menu_page(
            __('Quantum Page', 'quantum-page'),
            __('My QUPA', 'quantum-page'),
            'manage_options',
            'qupa-dashboard',
            [$this, 'renderDashboard'],
            'dashicons-layout',
            30
        );
        
        // Dashboard submenu
        add_submenu_page(
            'qupa-dashboard',
            __('Dashboard', 'quantum-page'),
            __('Dashboard', 'quantum-page'),
            'manage_options',
            'qupa-dashboard',
            [$this, 'renderDashboard']
        );
        
        // Pages submenu
        add_submenu_page(
            'qupa-dashboard',
            __('Pages', 'quantum-page'),
            __('Pages', 'quantum-page'),
            'manage_options',
            'qupa-pages',
            [$this, 'renderPages']
        );
        
        // Domains submenu
        add_submenu_page(
            'qupa-dashboard',
            __('Domains', 'quantum-page'),
            __('Domains', 'quantum-page'),
            'manage_options',
            'qupa-domains',
            [$this, 'renderDomains']
        );
        
        // Billing submenu
        add_submenu_page(
            'qupa-dashboard',
            __('Billing', 'quantum-page'),
            __('Billing', 'quantum-page'),
            'manage_options',
            'qupa-billing',
            [$this, 'renderBilling']
        );
    }
    
    /**
     * Render dashboard page
     */
    public function renderDashboard(): void {
        $controller = new DashboardController();
        $controller->index();
    }
    
    /**
     * Render pages page
     */
    public function renderPages(): void {
        $controller = new PageController();
        $controller->index();
    }
    
    /**
     * Render domains page
     */
    public function renderDomains(): void {
        $controller = new DomainController();
        $controller->index();
    }
    
    /**
     * Render billing page
     */
    public function renderBilling(): void {
        $controller = new BillingController();
        $controller->index();
    }
    
    /**
     * Enqueue admin assets
     */
    public function enqueueAssets($hook): void {
        // Only load on our plugin pages
        if (strpos($hook, 'qupa-') === false) {
            return;
        }
        
        wp_enqueue_style(
            'qupa-dashboard',
            QUPA_PLUGIN_URL . 'rsc/assets/css/dashboard.css',
            [],
            QUPA_VERSION
        );
        
        wp_enqueue_script(
            'qupa-dashboard',
            QUPA_PLUGIN_URL . 'rsc/assets/js/dashboard.js',
            [],
            QUPA_VERSION,
            true
        );
    }
    
    /**
     * AJAX: Create page
     */
    public function ajaxCreatePage(): void {
        check_ajax_referer('qupa_create_page', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Permission denied']);
        }
        
        $controller = new PageController();
        $controller->store();
    }
    
    /**
     * AJAX: Delete page
     */
    public function ajaxDeletePage(): void {
        check_ajax_referer('qupa_delete_page', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Permission denied']);
        }
        
        $pageId = intval($_POST['page_id'] ?? 0);
        $controller = new PageController();
        $controller->destroy($pageId);
    }
    
    /**
     * AJAX: Add domain
     */
    public function ajaxAddDomain(): void {
        check_ajax_referer('qupa_add_domain', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Permission denied']);
        }
        
        $controller = new DomainController();
        $controller->store();
    }
    
    /**
     * AJAX: Verify domain
     */
    public function ajaxVerifyDomain(): void {
        check_ajax_referer('qupa_verify_domain', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Permission denied']);
        }
        
        $domainId = intval($_POST['domain_id'] ?? 0);
        $controller = new DomainController();
        $controller->verify($domainId);
    }
    
    /**
     * AJAX: Delete domain
     */
    public function ajaxDeleteDomain(): void {
        check_ajax_referer('qupa_delete_domain', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Permission denied']);
        }
        
        $domainId = intval($_POST['domain_id'] ?? 0);
        $controller = new DomainController();
        $controller->destroy($domainId);
    }
}
