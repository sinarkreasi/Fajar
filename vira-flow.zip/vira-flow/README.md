# Vira Flow

**Visual automation engine for WordPress sites and businesses**

Vira Flow is a professional-grade automation platform built specifically for WordPress. It provides a visual workflow builder that allows you to create powerful automations without writing code.

## Features

- **Visual Workflow Builder**: Drag-and-drop interface for creating complex automations
- **Event-Driven Architecture**: Asynchronous execution with queue-based processing
- **Extensible Node System**: Support for custom triggers, actions, and conditions
- **WordPress Native**: Built specifically for WordPress with proper security and performance
- **Extension System**: Modular architecture for adding new functionality
- **Execution Logging**: Detailed logs and monitoring for all workflow executions

## Requirements

- PHP 8.2 or higher
- WordPress 6.9 or higher
- Action Scheduler (included with WooCommerce or can be installed separately)

## Installation

1. Upload the `vira-flow` folder to your `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Navigate to 'Vira Flow' in your WordPress admin to get started

## Core Concepts

### Workflows
Workflows are the main automation units in Vira Flow. Each workflow consists of:
- **Nodes**: Individual steps in the automation (triggers, actions, conditions)
- **Connections**: Links between nodes that define the execution flow
- **Context**: Data that flows through the workflow during execution

### Node Types

#### Triggers
- **Webhook**: Triggered by HTTP requests to a unique URL
- **Schedule**: Triggered at specific times or intervals

#### Actions
- **HTTP Request**: Make HTTP requests to external APIs
- **Email**: Send emails using WordPress mail functions

#### Conditions
- **Compare**: Compare values with various operators
- **Exists**: Check if values exist or are empty

### Execution Engine
- All workflows run asynchronously via WordPress Action Scheduler
- Each execution is logged with detailed step information
- Failed executions can be retried with exponential backoff
- Execution context allows data to flow between nodes

## Extension Development

Vira Flow is built with extensibility in mind. You can create custom extensions to add new node types and functionality.

### Creating an Extension

1. Create a new folder in `/extensions/your-extension-name/`
2. Add an `extension.json` file with metadata
3. Create a `bootstrap.php` file for initialization
4. Implement your custom nodes and service providers

See the `extensions/example-extension/` folder for a complete example.

### Extension Structure

```
extensions/your-extension/
├── extension.json          # Extension metadata
├── bootstrap.php          # Extension initialization
└── src/
    ├── ServiceProvider.php # Extension service provider
    └── Nodes/             # Custom node implementations
        └── YourNode.php
```

## Security

Vira Flow implements multiple security layers:

- **Capability System**: Custom WordPress capabilities for access control
- **Nonce Verification**: All requests are protected with nonces
- **Input Sanitization**: All user input is sanitized and validated
- **Execution Sandbox**: Node execution is sandboxed to prevent security issues
- **Function Restrictions**: Limited set of allowed functions during execution

## Performance

- **Asynchronous Execution**: Workflows run in background via queue system
- **Optimized Database**: Custom tables with proper indexing
- **Memory Management**: Execution limits and cleanup procedures
- **Caching**: Strategic caching of workflow definitions and node metadata

## API

Vira Flow provides a comprehensive REST API:

- `GET /wp-json/vflow/v1/workflows` - List workflows
- `POST /wp-json/vflow/v1/workflows` - Create workflow
- `PUT /wp-json/vflow/v1/workflows/{id}` - Update workflow
- `DELETE /wp-json/vflow/v1/workflows/{id}` - Delete workflow
- `POST /wp-json/vflow/v1/workflows/{id}/execute` - Execute workflow
- `GET /wp-json/vflow/v1/executions` - List executions
- `GET /wp-json/vflow/v1/nodes` - List available nodes

## Development

### Building Admin UI

The admin interface is built with React. To build the assets:

```bash
cd resources/admin-ui
npm install
npm run build
```

For development:

```bash
npm run dev
```

### Database Schema

Vira Flow uses custom database tables:
- `vflow_workflows` - Workflow definitions
- `vflow_jobs` - Execution jobs
- `vflow_job_steps` - Individual step executions
- `vflow_logs` - System logs

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

GPL v2 or later

## Support

For support and documentation, visit [viraflow.com](https://viraflow.com)

---

**Vira Flow** - Automate your WordPress site with visual workflows.