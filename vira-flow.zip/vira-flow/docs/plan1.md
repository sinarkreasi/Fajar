# Vira Flow – Core Architecture & Product Prompt

## Role & Objective

You are acting as a **senior WordPress application architect and product engineer**.
Your task is to design and implement **Vira Flow**, a professional-grade **visual automation engine for WordPress**, comparable in UX spirit to tools like n8n or modern automation builders, but **WordPress native, business focused, lightweight, secure, and extensible**.

Vira Flow is **not** a simple plugin. It is an **application framework running on WordPress**.

---

## Product Definition

**Product name:** Vira Flow
**Prefix:** `vflow`
**Namespace:** `VFlow\\`
**Positioning:** Visual automation engine for WordPress sites and businesses
**Target users:** Business owners, marketers, admins, agencies, and developers

---

## Minimum Requirements (Hard Rules)

* PHP **8.2+**
* WordPress **6.9+**
* If requirements are not met:

  * Plugin must **not boot**
  * Only an admin notice is shown

* Avoid early too translation and inline JS CSS in template/views file  

---

## Non‑Negotiable Engineering Principles

1. **WordPress is the host platform, not the automation engine**
2. **Event‑driven and async‑first** execution
3. **No workflow logic inside request lifecycle**
4. **Schema‑first design** for workflows, nodes, and executions
5. **Laravel‑style architecture**, but fully WordPress‑compliant
6. **Addon / extension first class support**

---

## Core Architecture Overview

Admin UI (React)
→ Workflow Definition (JSON)
→ Queue Dispatcher
→ Background Execution Engine
→ Node Runtime (sandboxed)
→ Execution Logs

WordPress provides:

* Authentication
* Authorization
* UI host
* Ecosystem

Automation logic is isolated in the domain layer.

---

## Folder Structure (Laravel‑Style, WP‑Safe)

```
vira-flow/
├── app/
│   ├── Core/
│   │   ├── Application.php
│   │   ├── Container.php
│   │   └── Kernel.php
│   │
│   ├── Domain/
│   │   ├── Workflow/
│   │   │   ├── Workflow.php
│   │   │   ├── WorkflowRepository.php
│   │   │   └── WorkflowValidator.php
│   │   │
│   │   ├── Execution/
│   │   │   ├── Job.php
│   │   │   ├── Runner.php
│   │   │   ├── StepExecutor.php
│   │   │   └── ExecutionContext.php
│   │   │
│   │   └── Node/
│   │       ├── Contracts/
│   │       │   ├── TriggerInterface.php
│   │       │   ├── ActionInterface.php
│   │       │   └── ConditionInterface.php
│   │       ├── AbstractNode.php
│   │       └── NodeRegistry.php
│   │
│   ├── Infra/
│   │   ├── Database/
│   │   │   ├── Migrations/
│   │   │   └── Repositories/
│   │   ├── Queue/
│   │   │   ├── QueueInterface.php
│   │   │   ├── ActionSchedulerQueue.php
│   │   │   └── Dispatcher.php
│   │   ├── Assets/
│   │   │   └── AssetManager.php
│   │   └── Security/
│   │       ├── Capability.php
│   │       ├── Nonce.php
│   │       └── Sandbox.php
│   │
│   ├── Http/
│   │   ├── Controllers/
│   │   └── Requests/
│   │
│   ├── Providers/
│   │   ├── CoreServiceProvider.php
│   │   ├── NodeServiceProvider.php
│   │   └── ExtensionServiceProvider.php
│   │
│   └── Support/
│       ├── Arr.php
│       ├── Str.php
│       └── Logger.php
│
├── extensions/
│   └── example-extension/
│       ├── extension.json
│       ├── bootstrap.php
│       └── src/
│           ├── Nodes/
│           └── ServiceProvider.php
│
├── resources/
│   ├── admin-ui/
│   ├── views/
│   └── schemas/
│
├── database/
│   └── schema.sql
│
├── bootstrap/
│   ├── app.php
│   └── extensions.php
│
├── routes/
│   └── admin.php
│
├── vira-flow.php
└── composer.json
```

---

## Execution Engine Rules

* All workflows run via **queue** (no synchronous execution)
* One workflow run = one job
* Each node executes as an isolated step
* Step state is persisted (resume safe)
* Retry policy with exponential backoff

---

## Database Rules

* Use **custom tables only**
* Never rely on `postmeta` for workflow execution

Required tables:

* `vflow_workflows`
* `vflow_jobs`
* `vflow_job_steps`
* `vflow_logs`

Indexes must include:

* workflow_id
* status
* created_at

---

## Security Requirements

### Capabilities

Custom capabilities only:

* `vflow_manage`
* `vflow_execute`
* `vflow_view_logs`

### REST API

* Namespace: `/vflow/v1`
* Explicit permission callbacks
* Sanitization and validation required

### Nonce & Requests

* All POST, REST, and AJAX requests must verify:

  * Nonce
  * Capability
  * Input sanitization

### Node Sandbox

Nodes must not:

* Execute arbitrary PHP
* Access raw SQL
* Access filesystem directly

All access goes through the container and services.

---

## Internationalization (Critical)

* No early translation
* No translation calls before `plugins_loaded`
* No translated strings in:

  * root plugin file
  * static properties
  * class defaults

Text domain: `vflow`

---

## Asset Management Rules

### Forbidden

* Inline `<script>` or `<style>` in views
* Inline JS/CSS inside templates
* Asset enqueue inside view files

### Required

* Centralized asset loading via `AssetManager`
* Data passed to JS via `wp_localize_script` or controlled inline injection

---

## UI / UX Whiteboard Rules

### Canvas

* Soft light background
* Subtle grid
* Infinite pan & zoom

### Nodes

* Rounded rectangle
* Calm shadow
* Category‑based color accents:

  * Trigger: blue
  * Condition: purple
  * Action: green

### Connectors

* Smooth bezier curves
* Clear direction (left → right or top → bottom)

### Icons

* Outline / stroke SVG icons only
* Consistent size and stroke
* No emoji, no cartoon icons

---

## Core Feature Priority (v1)

### Mandatory

1. Workflow engine & execution core
2. Visual workflow builder (basic)
3. Webhook trigger + HTTP request action
4. Conditional logic
5. Execution logs

### First Integrations

1. **WooCommerce** (highest priority)
2. FluentCRM (marketing automation)
3. Tutor LMS (education vertical)

---

## Extension / Addon System

* Extensions live inside `/extensions`
* Each extension declares:

  * metadata (`extension.json`)
  * service provider
* Extensions may:

  * register nodes
  * add schemas
* Extensions may NOT:

  * bypass queue
  * enqueue assets directly
  * execute logic synchronously

---

## Final Guiding Principle

Vira Flow must feel like:

* a serious business product
* an application framework
* a premium WordPress solution

Not a typical WordPress plugin.
