# Vira Flow – Node Contract Specification

This document defines the **formal contract** for all nodes in Vira Flow.
It applies to **core nodes** and **all extensions / addons**.

The goal is to ensure:

* Predictable execution
* Safe sandboxing
* Extensibility without breaking core

---

## 1. Node Philosophy

A **node** is a single, isolated unit of execution inside a workflow.

Key rules:

* One node = one responsibility
* Nodes never control workflow flow directly
* Nodes never call other nodes
* Nodes never access WordPress globals directly

All interaction happens through the **Execution Context**.

---

## 2. Node Types

Vira Flow supports three node types:

1. **Trigger Node** – starts a workflow
2. **Condition Node** – controls branching logic
3. **Action Node** – performs an operation

Each type has a strict interface.

---

## 3. Common Node Metadata (Required)

All nodes must define metadata via a static method or schema file.

```json
{
  "key": "woocommerce.order.completed",
  "name": "Order Completed",
  "description": "Triggered when a WooCommerce order is completed",
  "category": "trigger",
  "icon": "order",
  "color": "blue",
  "version": "1.0.0"
}
```

Rules:

* `key` must be globally unique
* `category` must match node type
* `version` is required for backward compatibility

---

## 4. Base Node Contract

All nodes must extend `AbstractNode`.

### Required Methods

```php
abstract class AbstractNode {
    abstract public function meta(): array;
    abstract public function schema(): array;
}
```

---

## 5. Trigger Node Contract

Trigger nodes **start workflows**.
They do not receive input from previous nodes.

### Interface

```php
interface TriggerInterface {
    public function register(): void;
    public function payload(array $event): array;
}
```

### Rules

* Trigger registers itself via WordPress hooks or webhooks
* Trigger fires **asynchronously**
* Trigger must normalize raw event data

### Example Payload Output

```json
{
  "order_id": 123,
  "status": "completed",
  "customer_email": "john@example.com"
}
```

The payload becomes the **initial execution context**.

---

## 6. Action Node Contract

Action nodes **perform an operation**.
They always receive input from the execution context.

### Interface

```php
interface ActionInterface {
    public function execute(ExecutionContext $context): array;
}
```

### Rules

* Must be idempotent if possible
* Must throw controlled exceptions on failure
* Must return structured output

### Example Output

```json
{
  "email_sent": true,
  "message_id": "abc123"
}
```

Returned data is merged into the execution context.

---

## 7. Condition Node Contract

Condition nodes **evaluate logic** and determine the next path.

### Interface

```php
interface ConditionInterface {
    public function evaluate(ExecutionContext $context): string;
}
```

### Return Values

* `true`
* `false`
* or a named branch key (advanced)

### Example

```php
return $context->get('order_total') > 100 ? 'high_value' : 'normal';
```

---

## 8. Schema Definition (UI Contract)

Each node must expose a schema for UI rendering.

```json
{
  "fields": [
    {
      "key": "status",
      "type": "select",
      "label": "Order Status",
      "options": ["pending", "completed"],
      "required": true
    }
  ]
}
```

Rules:

* Schema drives UI only
* No logic inside schema
* Validation happens server‑side

---

## 9. Execution Context Rules

* Context is immutable per step
* New data is merged after node execution
* Nodes cannot mutate previous data directly

Access:

```php
$context->get('order_id');
$context->all();
```

---

## 10. Error Handling & Retry

* Nodes must throw `NodeExecutionException`
* Retry policy is defined per node
* Node must be safe to retry

---

## 11. Security Constraints

Nodes must NOT:

* Access `$wpdb` directly
* Read/write files
* Execute shell commands
* Evaluate arbitrary PHP

Allowed:

* Use services provided by container
* Use sanitized, validated context data

---

## 12. Versioning & Compatibility

* Node versions are immutable
* Breaking changes require new version
* Old workflows must continue working

---

## 13. Extension Node Rules

Addon nodes:

* Must follow this contract
* Must register via `NodeRegistry`
* May not override core nodes

Invalid nodes are rejected at registration time.

---

## 14. Design Goal (Final)

A node should feel like:

* predictable
* safe
* composable
* boring in the best way

If a node feels clever, it is probably wrong.