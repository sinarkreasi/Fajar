<?php

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define extension constants
define('VFLOW_EXAMPLE_EXTENSION_DIR', __DIR__);
define('VFLOW_EXAMPLE_EXTENSION_URL', plugin_dir_url(__FILE__));

// Autoload extension classes (simple autoloader for this example)
spl_autoload_register(function($class) {
    if (strpos($class, 'VFlow\\Extensions\\Example\\') === 0) {
        $relative_class = str_replace('VFlow\\Extensions\\Example\\', '', $class);
        $file = __DIR__ . '/src/' . str_replace('\\', '/', $relative_class) . '.php';
        
        if (file_exists($file)) {
            require_once $file;
        }
    }
});