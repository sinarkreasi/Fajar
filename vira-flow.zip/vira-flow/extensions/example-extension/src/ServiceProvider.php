<?php

namespace VFlow\Extensions\Example;

use VFlow\Core\Container;

/**
 * Example Extension Service Provider
 */
class ServiceProvider
{
    private Container $container;

    public function __construct(Container $container)
    {
        $this->container = $container;
    }

    /**
     * Register extension services
     */
    public function register(): void
    {
        // Register extension-specific services here
    }

    /**
     * Boot extension services
     */
    public function boot(): void
    {
        // Boot extension services here
        add_action('vflow_extension_booted', [$this, 'onExtensionBooted']);
    }

    /**
     * Handle extension booted event
     */
    public function onExtensionBooted(): void
    {
        // Extension is fully loaded and ready
    }
}