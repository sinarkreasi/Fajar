<?php

namespace VFlow\Extensions\Example\Nodes;

use VFlow\Domain\Node\AbstractNode;
use VFlow\Domain\Node\Contracts\ActionInterface;
use VFlow\Domain\Execution\ExecutionContext;

/**
 * Example Action Node - Updated for Formal Contract
 */
class ExampleAction extends AbstractNode implements ActionInterface
{
    public function getType(): string
    {
        return 'action';
    }

    public function meta(): array
    {
        return [
            'key' => 'example.log_message',
            'name' => 'Log Message',
            'description' => 'An example action node that logs messages',
            'category' => 'action',
            'icon' => 'admin-tools',
            'color' => '#10b981',
            'version' => '1.0.0'
        ];
    }

    public function schema(): array
    {
        return [
            'fields' => [
                [
                    'key' => 'message',
                    'type' => 'text',
                    'label' => 'Message',
                    'required' => true,
                    'placeholder' => 'Enter a message...',
                    'description' => 'The message to log'
                ],
                [
                    'key' => 'level',
                    'type' => 'select',
                    'label' => 'Log Level',
                    'required' => false,
                    'default' => 'info',
                    'options' => [
                        ['value' => 'debug', 'label' => 'Debug'],
                        ['value' => 'info', 'label' => 'Info'],
                        ['value' => 'warning', 'label' => 'Warning'],
                        ['value' => 'error', 'label' => 'Error']
                    ],
                    'description' => 'The log level for the message'
                ]
            ]
        ];
    }

    public function execute(ExecutionContext $context): array
    {
        $config = $this->sanitizeConfig($context->get('node_config', []));
        
        $message = $context->resolveVariables($config['message'] ?? '');
        $level = $config['level'] ?? 'info';
        
        // Log the message
        error_log("VFLOW EXAMPLE ACTION [{$level}]: {$message}");
        
        // Return result that will be merged into context
        return [
            'log_message' => $message,
            'log_level' => $level,
            'logged_at' => current_time('mysql'),
            'log_success' => true
        ];
    }
}