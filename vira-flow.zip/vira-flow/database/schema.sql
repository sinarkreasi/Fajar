-- Vira Flow Database Schema

-- Workflows table
CREATE TABLE IF NOT EXISTS `{prefix}vflow_workflows` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text,
  `definition` longtext NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'draft',
  `settings` longtext,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `created_at` (`created_at`)
) {charset_collate};

-- Jobs table
CREATE TABLE IF NOT EXISTS `{prefix}vflow_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `workflow_id` bigint(20) unsigned NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `context` longtext,
  `result` longtext,
  `error` text,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `started_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `workflow_id` (`workflow_id`),
  KEY `status` (`status`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `fk_vflow_jobs_workflow` FOREIGN KEY (`workflow_id`) REFERENCES `{prefix}vflow_workflows` (`id`) ON DELETE CASCADE
) {charset_collate};

-- Job steps table
CREATE TABLE IF NOT EXISTS `{prefix}vflow_job_steps` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `job_id` bigint(20) unsigned NOT NULL,
  `node_id` varchar(255) NOT NULL,
  `node_type` varchar(100) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `result` longtext,
  `error` text,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `job_id` (`job_id`),
  KEY `node_id` (`node_id`),
  KEY `status` (`status`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `fk_vflow_job_steps_job` FOREIGN KEY (`job_id`) REFERENCES `{prefix}vflow_jobs` (`id`) ON DELETE CASCADE
) {charset_collate};

-- Logs table
CREATE TABLE IF NOT EXISTS `{prefix}vflow_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `level` varchar(20) NOT NULL,
  `message` text NOT NULL,
  `context` longtext,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `level` (`level`),
  KEY `created_at` (`created_at`)
) {charset_collate};