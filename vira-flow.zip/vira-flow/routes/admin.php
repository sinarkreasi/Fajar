<?php

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Register REST API routes
add_action('rest_api_init', function() {
    $namespace = 'vflow/v1';

    // Workflow routes
    register_rest_route($namespace, '/workflows', [
        [
            'methods' => 'GET',
            'callback' => function($request) {
                return \VFlow\Http\Controllers\WorkflowController::index($request);
            },
            'permission_callback' => function() {
                return current_user_can('vflow_manage');
            }
        ],
        [
            'methods' => 'POST',
            'callback' => function($request) {
                return \VFlow\Http\Controllers\WorkflowController::store($request);
            },
            'permission_callback' => function() {
                return current_user_can('vflow_manage');
            }
        ]
    ]);

    register_rest_route($namespace, '/workflows/(?P<id>\d+)', [
        [
            'methods' => 'GET',
            'callback' => function($request) {
                return \VFlow\Http\Controllers\WorkflowController::show($request);
            },
            'permission_callback' => function() {
                return current_user_can('vflow_manage');
            }
        ],
        [
            'methods' => 'PUT',
            'callback' => function($request) {
                return \VFlow\Http\Controllers\WorkflowController::update($request);
            },
            'permission_callback' => function() {
                return current_user_can('vflow_manage');
            }
        ],
        [
            'methods' => 'DELETE',
            'callback' => function($request) {
                return \VFlow\Http\Controllers\WorkflowController::destroy($request);
            },
            'permission_callback' => function() {
                return current_user_can('vflow_manage');
            }
        ]
    ]);

    register_rest_route($namespace, '/workflows/(?P<id>\d+)/activate', [
        'methods' => 'POST',
        'callback' => function($request) {
            return \VFlow\Http\Controllers\WorkflowController::activate($request);
        },
        'permission_callback' => function() {
            return current_user_can('vflow_manage');
        }
    ]);

    register_rest_route($namespace, '/workflows/(?P<id>\d+)/deactivate', [
        'methods' => 'POST',
        'callback' => function($request) {
            return \VFlow\Http\Controllers\WorkflowController::deactivate($request);
        },
        'permission_callback' => function() {
            return current_user_can('vflow_manage');
        }
    ]);

    // Execution routes
    register_rest_route($namespace, '/executions', [
        'methods' => 'GET',
        'callback' => function($request) {
            return \VFlow\Http\Controllers\ExecutionController::index($request);
        },
        'permission_callback' => function() {
            return current_user_can('vflow_view_logs');
        }
    ]);

    // Node routes
    register_rest_route($namespace, '/nodes', [
        'methods' => 'GET',
        'callback' => function($request) {
            return \VFlow\Http\Controllers\NodeController::index($request);
        },
        'permission_callback' => function() {
            return current_user_can('vflow_manage');
        }
    ]);

    // Webhook routes (public)
    register_rest_route($namespace, '/webhook/(?P<id>[a-zA-Z0-9_-]+)', [
        'methods' => ['GET', 'POST', 'PUT', 'DELETE'],
        'callback' => function($request) {
            return \VFlow\Http\Controllers\WebhookController::handle($request);
        },
        'permission_callback' => '__return_true' // Public endpoint
    ]);
});