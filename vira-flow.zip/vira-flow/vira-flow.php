<?php
/**
 * Plugin Name: Vira Flow
 * Plugin URI: https://viraloka.com/product/vira-flow
 * Description: Visual automation engine for WordPress sites and businesses
 * Version: 1.0.0
 * Author: Viraloka
 * Author URI: https://viraloka.com
 * Text Domain: vflow
 * Domain Path: /languages
 * Requires at least: 6.9
 * Tested up to: 6.9
 * Requires PHP: 8.2
 * Network: false
 * License: GPL v2 or later
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('VFLOW_VERSION', '1.0.0');
define('VFLOW_PLUGIN_FILE', __FILE__);
define('VFLOW_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('VFLOW_PLUGIN_URL', plugin_dir_url(__FILE__));
define('VFLOW_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Check requirements before loading
if (!vflow_check_requirements()) {
    return;
}

// Simple PSR-4 autoloader
spl_autoload_register(function($class) {
    if (strpos($class, 'VFlow\\') === 0) {
        $relative_class = str_replace('VFlow\\', '', $class);
        $file = VFLOW_PLUGIN_DIR . 'app/' . str_replace('\\', '/', $relative_class) . '.php';
        
        if (file_exists($file)) {
            require_once $file;
        }
    }
});

// Bootstrap the application
require_once VFLOW_PLUGIN_DIR . 'bootstrap/app.php';

/**
 * Check if system requirements are met
 */
function vflow_check_requirements(): bool
{
    global $wp_version;
    
    $php_version = PHP_VERSION;
    $wp_version_required = '6.9';
    $php_version_required = '8.2';
    
    $errors = [];
    
    if (version_compare($php_version, $php_version_required, '<')) {
        $errors[] = sprintf(
            'PHP %s or higher is required. You are running %s.',
            $php_version_required,
            $php_version
        );
    }
    
    if (version_compare($wp_version, $wp_version_required, '<')) {
        $errors[] = sprintf(
            'WordPress %s or higher is required. You are running %s.',
            $wp_version_required,
            $wp_version
        );
    }
    
    if (!empty($errors)) {
        add_action('admin_notices', function() use ($errors) {
            echo '<div class="notice notice-error"><p>';
            echo '<strong>Vira Flow:</strong> ' . implode(' ', $errors);
            echo '</p></div>';
        });
        return false;
    }
    
    return true;
}

/**
 * Plugin activation hook
 */
register_activation_hook(__FILE__, function() {
    if (class_exists('VFlow\Core\Application')) {
        VFlow\Core\Application::getInstance()->activate();
    }
});

/**
 * Plugin deactivation hook
 */
register_deactivation_hook(__FILE__, function() {
    if (class_exists('VFlow\Core\Application')) {
        VFlow\Core\Application::getInstance()->deactivate();
    }
});