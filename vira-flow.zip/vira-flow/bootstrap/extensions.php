<?php

use VFlow\Core\Application;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Load and register extensions
 */
function vflow_load_extensions(): void
{
    $app = Application::getInstance();
    $extensions_dir = VFLOW_PLUGIN_DIR . 'extensions';
    
    if (!is_dir($extensions_dir)) {
        return;
    }
    
    $extensions = glob($extensions_dir . '/*/extension.json');
    
    foreach ($extensions as $config_file) {
        $extension_dir = dirname($config_file);
        $config = json_decode(file_get_contents($config_file), true);
        
        if (!$config || !isset($config['name'])) {
            continue;
        }
        
        // Load extension bootstrap
        $bootstrap_file = $extension_dir . '/bootstrap.php';
        if (file_exists($bootstrap_file)) {
            require_once $bootstrap_file;
        }
        
        // Register extension with application
        $app->registerExtension($config['name'], $config, $extension_dir);
    }
}

// Load extensions
vflow_load_extensions();