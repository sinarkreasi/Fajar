<?php

use VFlow\Core\Application;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Initialize the application when WordPress is ready
add_action('plugins_loaded', function() {
    $app = Application::getInstance();
    $app->boot();
}, 10);

// Load extensions after core is loaded
add_action('vflow_core_loaded', function() {
    require_once VFLOW_PLUGIN_DIR . 'bootstrap/extensions.php';
}, 10);