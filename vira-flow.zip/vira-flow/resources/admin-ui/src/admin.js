import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './components/App';
import './styles/admin.css';

// Initialize the admin app
document.addEventListener('DOMContentLoaded', function() {
    const container = document.getElementById('vflow-admin-app');
    if (container) {
        const root = createRoot(container);
        root.render(<App />);
    }
});