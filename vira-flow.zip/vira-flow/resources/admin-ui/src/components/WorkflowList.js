import React, { useState } from 'react';
import { __ } from '@wordpress/i18n';

const WorkflowList = ({ workflows, onEdit, onRefresh }) => {
    const [filter, setFilter] = useState('all');

    const filteredWorkflows = workflows.filter(workflow => {
        if (filter === 'all') return true;
        return workflow.status === filter;
    });

    const handleToggleStatus = async (workflow) => {
        try {
            const action = workflow.status === 'active' ? 'deactivate' : 'activate';
            await wp.apiFetch({
                path: `/vflow/v1/workflows/${workflow.id}/${action}`,
                method: 'POST',
                headers: {
                    'X-WP-Nonce': vflowAdmin.nonce
                }
            });
            onRefresh();
        } catch (error) {
            console.error('Failed to toggle workflow status:', error);
            alert(__('Failed to update workflow status', 'vflow'));
        }
    };

    const handleDelete = async (workflow) => {
        if (!confirm(__('Are you sure you want to delete this workflow?', 'vflow'))) {
            return;
        }

        try {
            await wp.apiFetch({
                path: `/vflow/v1/workflows/${workflow.id}`,
                method: 'DELETE',
                headers: {
                    'X-WP-Nonce': vflowAdmin.nonce
                }
            });
            onRefresh();
        } catch (error) {
            console.error('Failed to delete workflow:', error);
            alert(__('Failed to delete workflow', 'vflow'));
        }
    };

    const getStatusBadge = (status) => {
        const badges = {
            active: { class: 'success', text: __('Active', 'vflow') },
            inactive: { class: 'warning', text: __('Inactive', 'vflow') },
            draft: { class: 'secondary', text: __('Draft', 'vflow') }
        };
        
        const badge = badges[status] || badges.draft;
        
        return (
            <span className={`vflow-badge vflow-badge--${badge.class}`}>
                {badge.text}
            </span>
        );
    };

    return (
        <div className="vflow-workflow-list">
            <div className="vflow-filters">
                <select 
                    value={filter} 
                    onChange={(e) => setFilter(e.target.value)}
                    className="vflow-filter-select"
                >
                    <option value="all">{__('All Workflows', 'vflow')}</option>
                    <option value="active">{__('Active', 'vflow')}</option>
                    <option value="inactive">{__('Inactive', 'vflow')}</option>
                    <option value="draft">{__('Draft', 'vflow')}</option>
                </select>
            </div>

            {filteredWorkflows.length === 0 ? (
                <div className="vflow-empty-state">
                    <h3>{__('No workflows found', 'vflow')}</h3>
                    <p>{__('Create your first workflow to get started with automation.', 'vflow')}</p>
                </div>
            ) : (
                <div className="vflow-workflow-grid">
                    {filteredWorkflows.map(workflow => (
                        <div key={workflow.id} className="vflow-workflow-card">
                            <div className="vflow-workflow-card__header">
                                <h3>{workflow.name}</h3>
                                {getStatusBadge(workflow.status)}
                            </div>
                            
                            <div className="vflow-workflow-card__content">
                                <p>{workflow.description || __('No description', 'vflow')}</p>
                                <div className="vflow-workflow-card__meta">
                                    <span>{__('Created:', 'vflow')} {new Date(workflow.created_at).toLocaleDateString()}</span>
                                </div>
                            </div>
                            
                            <div className="vflow-workflow-card__actions">
                                <button 
                                    className="button button-small"
                                    onClick={() => onEdit(workflow)}
                                >
                                    {__('Edit', 'vflow')}
                                </button>
                                
                                <button 
                                    className={`button button-small ${workflow.status === 'active' ? 'button-secondary' : 'button-primary'}`}
                                    onClick={() => handleToggleStatus(workflow)}
                                >
                                    {workflow.status === 'active' ? __('Deactivate', 'vflow') : __('Activate', 'vflow')}
                                </button>
                                
                                <button 
                                    className="button button-small button-link-delete"
                                    onClick={() => handleDelete(workflow)}
                                >
                                    {__('Delete', 'vflow')}
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default WorkflowList;