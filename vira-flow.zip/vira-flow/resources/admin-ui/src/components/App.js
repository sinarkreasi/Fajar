import React, { useState, useEffect } from 'react';
import { __ } from '@wordpress/i18n';
import WorkflowList from './WorkflowList';
import WorkflowEditor from './WorkflowEditor';

const App = () => {
    const [currentView, setCurrentView] = useState('list');
    const [selectedWorkflow, setSelectedWorkflow] = useState(null);
    const [workflows, setWorkflows] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        loadWorkflows();
    }, []);

    const loadWorkflows = async () => {
        try {
            setLoading(true);
            const response = await wp.apiFetch({
                path: '/vflow/v1/workflows',
                headers: {
                    'X-WP-Nonce': vflowAdmin.nonce
                }
            });
            setWorkflows(response);
        } catch (error) {
            console.error('Failed to load workflows:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleCreateWorkflow = () => {
        setSelectedWorkflow(null);
        setCurrentView('editor');
    };

    const handleEditWorkflow = (workflow) => {
        setSelectedWorkflow(workflow);
        setCurrentView('editor');
    };

    const handleBackToList = () => {
        setCurrentView('list');
        setSelectedWorkflow(null);
        loadWorkflows();
    };

    if (loading) {
        return (
            <div className="vflow-loading">
                <div className="spinner is-active"></div>
                <p>{__('Loading workflows...', 'vflow')}</p>
            </div>
        );
    }

    return (
        <div className="vflow-admin">
            <div className="vflow-header">
                <h1>{__('Vira Flow', 'vflow')}</h1>
                {currentView === 'list' && (
                    <button 
                        className="button button-primary"
                        onClick={handleCreateWorkflow}
                    >
                        {__('Create Workflow', 'vflow')}
                    </button>
                )}
                {currentView === 'editor' && (
                    <button 
                        className="button"
                        onClick={handleBackToList}
                    >
                        {__('Back to Workflows', 'vflow')}
                    </button>
                )}
            </div>

            <div className="vflow-content">
                {currentView === 'list' && (
                    <WorkflowList 
                        workflows={workflows}
                        onEdit={handleEditWorkflow}
                        onRefresh={loadWorkflows}
                    />
                )}
                {currentView === 'editor' && (
                    <WorkflowEditor 
                        workflow={selectedWorkflow}
                        onSave={handleBackToList}
                        onCancel={handleBackToList}
                    />
                )}
            </div>
        </div>
    );
};

export default App;