import React, { useState, useEffect } from 'react';
import { __ } from '@wordpress/i18n';

const WorkflowEditor = ({ workflow, onSave, onCancel }) => {
    const [name, setName] = useState('');
    const [description, setDescription] = useState('');
    const [definition, setDefinition] = useState({ nodes: [], connections: [] });
    const [saving, setSaving] = useState(false);

    useEffect(() => {
        if (workflow) {
            setName(workflow.name);
            setDescription(workflow.description || '');
            setDefinition(workflow.definition || { nodes: [], connections: [] });
        } else {
            setName('');
            setDescription('');
            setDefinition({ nodes: [], connections: [] });
        }
    }, [workflow]);

    const handleSave = async () => {
        if (!name.trim()) {
            alert(__('Please enter a workflow name', 'vflow'));
            return;
        }

        try {
            setSaving(true);
            
            const data = {
                name: name.trim(),
                description: description.trim(),
                definition
            };

            if (workflow) {
                // Update existing workflow
                await wp.apiFetch({
                    path: `/vflow/v1/workflows/${workflow.id}`,
                    method: 'PUT',
                    data,
                    headers: {
                        'X-WP-Nonce': vflowAdmin.nonce
                    }
                });
            } else {
                // Create new workflow
                await wp.apiFetch({
                    path: '/vflow/v1/workflows',
                    method: 'POST',
                    data,
                    headers: {
                        'X-WP-Nonce': vflowAdmin.nonce
                    }
                });
            }

            onSave();
        } catch (error) {
            console.error('Failed to save workflow:', error);
            alert(__('Failed to save workflow', 'vflow'));
        } finally {
            setSaving(false);
        }
    };

    return (
        <div className="vflow-workflow-editor">
            <div className="vflow-editor-sidebar">
                <div className="vflow-form-group">
                    <label htmlFor="workflow-name">
                        {__('Workflow Name', 'vflow')}
                    </label>
                    <input
                        id="workflow-name"
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder={__('Enter workflow name...', 'vflow')}
                        className="regular-text"
                    />
                </div>

                <div className="vflow-form-group">
                    <label htmlFor="workflow-description">
                        {__('Description', 'vflow')}
                    </label>
                    <textarea
                        id="workflow-description"
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        placeholder={__('Enter workflow description...', 'vflow')}
                        rows="3"
                        className="large-text"
                    />
                </div>

                <div className="vflow-form-group">
                    <h4>{__('Available Nodes', 'vflow')}</h4>
                    <div className="vflow-node-palette">
                        <div className="vflow-node-category">
                            <h5>{__('Triggers', 'vflow')}</h5>
                            <div className="vflow-node-item" data-type="webhook">
                                {__('Webhook', 'vflow')}
                            </div>
                            <div className="vflow-node-item" data-type="schedule">
                                {__('Schedule', 'vflow')}
                            </div>
                        </div>
                        
                        <div className="vflow-node-category">
                            <h5>{__('Actions', 'vflow')}</h5>
                            <div className="vflow-node-item" data-type="http_request">
                                {__('HTTP Request', 'vflow')}
                            </div>
                            <div className="vflow-node-item" data-type="email">
                                {__('Send Email', 'vflow')}
                            </div>
                        </div>
                        
                        <div className="vflow-node-category">
                            <h5>{__('Conditions', 'vflow')}</h5>
                            <div className="vflow-node-item" data-type="compare">
                                {__('Compare', 'vflow')}
                            </div>
                        </div>
                    </div>
                </div>

                <div className="vflow-editor-actions">
                    <button 
                        className="button button-primary"
                        onClick={handleSave}
                        disabled={saving}
                    >
                        {saving ? __('Saving...', 'vflow') : __('Save Workflow', 'vflow')}
                    </button>
                    
                    <button 
                        className="button"
                        onClick={onCancel}
                        disabled={saving}
                    >
                        {__('Cancel', 'vflow')}
                    </button>
                </div>
            </div>

            <div className="vflow-editor-canvas">
                <div className="vflow-canvas-placeholder">
                    <h3>{__('Visual Workflow Builder', 'vflow')}</h3>
                    <p>{__('Drag nodes from the sidebar to build your workflow.', 'vflow')}</p>
                    <p><em>{__('Full visual editor coming in next update!', 'vflow')}</em></p>
                </div>
            </div>
        </div>
    );
};

export default WorkflowEditor;