<?php

namespace VFlow\Infra\Assets;

/**
 * Asset Manager
 */
class AssetManager
{
    private array $scripts = [];
    private array $styles = [];

    /**
     * Enqueue admin assets
     */
    public function enqueueAdminAssets(): void
    {
        // Enqueue React and dependencies
        wp_enqueue_script('react');
        wp_enqueue_script('react-dom');
        
        // Enqueue main admin script
        wp_enqueue_script(
            'vflow-admin',
            VFLOW_PLUGIN_URL . 'resources/admin-ui/dist/admin.js',
            ['react', 'react-dom', 'wp-api-fetch', 'wp-i18n'],
            VFLOW_VERSION,
            true
        );

        // Enqueue admin styles
        wp_enqueue_style(
            'vflow-admin',
            VFLOW_PLUGIN_URL . 'resources/admin-ui/dist/admin.css',
            [],
            VFLOW_VERSION
        );

        // Localize script with data
        wp_localize_script('vflow-admin', 'vflowAdmin', [
            'apiUrl' => rest_url('vflow/v1/'),
            'nonce' => wp_create_nonce('wp_rest'),
            'currentUser' => wp_get_current_user(),
            'capabilities' => [
                'manage' => current_user_can('vflow_manage'),
                'execute' => current_user_can('vflow_execute'),
                'viewLogs' => current_user_can('vflow_view_logs')
            ],
            'i18n' => [
                'workflows' => 'Workflows',
                'executions' => 'Executions',
                'createWorkflow' => 'Create Workflow',
                'editWorkflow' => 'Edit Workflow',
                'deleteWorkflow' => 'Delete Workflow',
                'activateWorkflow' => 'Activate Workflow',
                'deactivateWorkflow' => 'Deactivate Workflow'
            ]
        ]);

        // Set script translations
        wp_set_script_translations('vflow-admin', 'vflow');
    }

    /**
     * Enqueue frontend assets
     */
    public function enqueueFrontendAssets(): void
    {
        // Only enqueue if needed (e.g., for webhook endpoints)
        if ($this->shouldEnqueueFrontend()) {
            wp_enqueue_script(
                'vflow-frontend',
                VFLOW_PLUGIN_URL . 'resources/frontend/dist/frontend.js',
                ['wp-api-fetch'],
                VFLOW_VERSION,
                true
            );
        }
    }

    /**
     * Register a script
     */
    public function registerScript(string $handle, string $src, array $deps = [], ?string $version = null): void
    {
        $this->scripts[$handle] = [
            'src' => $src,
            'deps' => $deps,
            'version' => $version ?? VFLOW_VERSION
        ];
    }

    /**
     * Register a style
     */
    public function registerStyle(string $handle, string $src, array $deps = [], ?string $version = null): void
    {
        $this->styles[$handle] = [
            'src' => $src,
            'deps' => $deps,
            'version' => $version ?? VFLOW_VERSION
        ];
    }

    /**
     * Enqueue a registered script
     */
    public function enqueueScript(string $handle): void
    {
        if (isset($this->scripts[$handle])) {
            $script = $this->scripts[$handle];
            wp_enqueue_script($handle, $script['src'], $script['deps'], $script['version'], true);
        }
    }

    /**
     * Enqueue a registered style
     */
    public function enqueueStyle(string $handle): void
    {
        if (isset($this->styles[$handle])) {
            $style = $this->styles[$handle];
            wp_enqueue_style($handle, $style['src'], $style['deps'], $style['version']);
        }
    }

    /**
     * Add inline script data
     */
    public function addInlineScriptData(string $handle, string $objectName, array $data): void
    {
        wp_localize_script($handle, $objectName, $data);
    }

    /**
     * Add inline CSS
     */
    public function addInlineStyle(string $handle, string $css): void
    {
        wp_add_inline_style($handle, $css);
    }

    /**
     * Check if frontend assets should be enqueued
     */
    private function shouldEnqueueFrontend(): bool
    {
        // Check if we're on a page that needs frontend assets
        global $wp;
        
        // Check for webhook endpoints
        if (strpos($wp->request, 'vflow/webhook/') !== false) {
            return true;
        }

        return false;
    }

    /**
     * Get asset URL
     */
    public function getAssetUrl(string $path): string
    {
        return VFLOW_PLUGIN_URL . ltrim($path, '/');
    }

    /**
     * Get versioned asset URL
     */
    public function getVersionedAssetUrl(string $path): string
    {
        $url = $this->getAssetUrl($path);
        return add_query_arg('v', VFLOW_VERSION, $url);
    }
}