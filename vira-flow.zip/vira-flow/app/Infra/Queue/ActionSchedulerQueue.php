<?php

namespace VFlow\Infra\Queue;

/**
 * Action Scheduler Queue Implementation
 * Uses WordPress Action Scheduler for background job processing
 */
class ActionSchedulerQueue implements QueueInterface
{
    private const HOOK_PREFIX = 'vflow_queue_';

    public function __construct()
    {
        $this->registerHooks();
    }

    /**
     * Push a job to the queue
     */
    public function push(string $jobType, array $data, int $delay = 0): void
    {
        $hook = self::HOOK_PREFIX . $jobType;
        
        if ($delay > 0) {
            as_schedule_single_action(time() + $delay, $hook, [$data], 'vflow');
        } else {
            as_enqueue_async_action($hook, [$data], 'vflow');
        }
    }

    /**
     * Process pending jobs
     */
    public function process(): void
    {
        // Action Scheduler handles processing automatically
        // This method can be used to manually trigger processing if needed
        if (function_exists('as_get_scheduled_actions')) {
            $actions = as_get_scheduled_actions([
                'group' => 'vflow',
                'status' => 'pending',
                'per_page' => 10
            ]);
            
            foreach ($actions as $action) {
                do_action($action->get_hook(), ...$action->get_args());
            }
        }
    }

    /**
     * Get queue size
     */
    public function size(): int
    {
        if (!function_exists('as_get_scheduled_actions')) {
            return 0;
        }
        
        $actions = as_get_scheduled_actions([
            'group' => 'vflow',
            'status' => 'pending',
            'per_page' => -1
        ]);
        
        return count($actions);
    }

    /**
     * Clear all jobs
     */
    public function clear(): void
    {
        if (function_exists('as_unschedule_all_actions')) {
            as_unschedule_all_actions('', [], 'vflow');
        }
    }

    /**
     * Register queue hooks
     */
    private function registerHooks(): void
    {
        // Register workflow execution handler
        add_action(self::HOOK_PREFIX . 'workflow_execution', [$this, 'handleWorkflowExecution']);
    }

    /**
     * Handle workflow execution job
     */
    public function handleWorkflowExecution(array $data): void
    {
        $workflowId = $data['workflow_id'] ?? null;
        $context = $data['context'] ?? [];
        
        if (!$workflowId) {
            return;
        }
        
        // Get workflow
        global $wpdb;
        $workflow = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}vflow_workflows WHERE id = %d",
            $workflowId
        ), ARRAY_A);
        
        if (!$workflow || $workflow['status'] !== 'active') {
            return;
        }
        
        // Create job
        $job = new \VFlow\Domain\Execution\Job($workflowId, $context);
        
        // Save job
        $wpdb->insert($wpdb->prefix . 'vflow_jobs', [
            'workflow_id' => $workflowId,
            'status' => 'pending',
            'context' => wp_json_encode($context),
            'result' => wp_json_encode([]),
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql')
        ]);
        
        $job->setId($wpdb->insert_id);
        
        // Execute workflow
        $app = \VFlow\Core\Application::getInstance();
        $runner = $app->getContainer()->make('execution_runner');
        $definition = json_decode($workflow['definition'], true);
        
        $runner->execute($job, $definition);
    }
}