<?php

namespace VFlow\Infra\Queue;

/**
 * Queue Dispatcher
 */
class Dispatcher
{
    private QueueInterface $queue;

    public function __construct(QueueInterface $queue)
    {
        $this->queue = $queue;
    }

    /**
     * Dispatch a job to the queue
     */
    public function dispatch(string $jobType, array $data, int $delay = 0): void
    {
        $this->queue->push($jobType, $data, $delay);
    }

    /**
     * Dispatch workflow execution
     */
    public function dispatchWorkflowExecution(int $workflowId, array $context = []): void
    {
        $this->dispatch('workflow_execution', [
            'workflow_id' => $workflowId,
            'context' => $context,
            'dispatched_at' => current_time('mysql')
        ]);
    }

    /**
     * Dispatch delayed workflow execution
     */
    public function dispatchDelayedWorkflowExecution(int $workflowId, array $context, int $delaySeconds): void
    {
        $this->dispatch('workflow_execution', [
            'workflow_id' => $workflowId,
            'context' => $context,
            'dispatched_at' => current_time('mysql')
        ], $delaySeconds);
    }

    /**
     * Dispatch scheduled workflow execution
     */
    public function dispatchScheduledWorkflowExecution(int $workflowId, string $schedule): void
    {
        // Calculate next run time based on schedule
        $nextRun = $this->calculateNextRun($schedule);
        $delay = $nextRun - time();
        
        if ($delay > 0) {
            $this->dispatchDelayedWorkflowExecution($workflowId, [
                'trigger' => 'schedule',
                'schedule' => $schedule
            ], $delay);
        }
    }

    /**
     * Calculate next run time for schedule
     */
    private function calculateNextRun(string $schedule): int
    {
        switch ($schedule) {
            case 'hourly':
                return strtotime('+1 hour');
            case 'daily':
                return strtotime('+1 day');
            case 'weekly':
                return strtotime('+1 week');
            case 'monthly':
                return strtotime('+1 month');
            default:
                // Try to parse as cron expression or return next hour
                return strtotime('+1 hour');
        }
    }
}