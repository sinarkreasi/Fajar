<?php

namespace VFlow\Infra\Queue;

/**
 * Queue Interface
 */
interface QueueInterface
{
    /**
     * Push a job to the queue
     */
    public function push(string $jobType, array $data, int $delay = 0): void;

    /**
     * Process pending jobs
     */
    public function process(): void;

    /**
     * Get queue size
     */
    public function size(): int;

    /**
     * Clear all jobs
     */
    public function clear(): void;
}