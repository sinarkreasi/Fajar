<?php

namespace VFlow\Infra\Security;

/**
 * Execution Sandbox
 */
class Sandbox
{
    private array $allowedFunctions = [
        // String functions
        'strlen', 'substr', 'strpos', 'str_replace', 'trim', 'strtolower', 'strtoupper',
        // Array functions
        'array_merge', 'array_keys', 'array_values', 'count', 'in_array',
        // JSON functions
        'json_encode', 'json_decode',
        // WordPress functions
        'sanitize_text_field', 'sanitize_email', 'esc_html', 'esc_url',
        // Date functions
        'date', 'time', 'strtotime'
    ];

    private array $blockedFunctions = [
        // File system
        'file_get_contents', 'file_put_contents', 'fopen', 'fwrite', 'fread',
        'unlink', 'rmdir', 'mkdir', 'chmod', 'chown',
        // Execution
        'exec', 'shell_exec', 'system', 'passthru', 'eval',
        // Network
        'curl_exec', 'fsockopen', 'socket_create',
        // Database
        'mysql_query', 'mysqli_query', 'pg_query'
    ];

    /**
     * Execute code in sandbox
     */
    public function execute(callable $callback): mixed
    {
        // Set error handler
        $previousHandler = set_error_handler([$this, 'handleError']);
        
        // Set execution limits
        $previousTimeLimit = ini_get('max_execution_time');
        $previousMemoryLimit = ini_get('memory_limit');
        
        ini_set('max_execution_time', 30); // 30 seconds max
        ini_set('memory_limit', '128M'); // 128MB max
        
        try {
            // Execute the callback
            return $callback();
        } finally {
            // Restore settings
            set_error_handler($previousHandler);
            ini_set('max_execution_time', $previousTimeLimit);
            ini_set('memory_limit', $previousMemoryLimit);
        }
    }

    /**
     * Validate function call
     */
    public function validateFunctionCall(string $functionName): bool
    {
        // Check if function is blocked
        if (in_array($functionName, $this->blockedFunctions)) {
            return false;
        }

        // Check if function is explicitly allowed
        if (in_array($functionName, $this->allowedFunctions)) {
            return true;
        }

        // Check if it's a WordPress function
        if (strpos($functionName, 'wp_') === 0 || function_exists($functionName)) {
            // Additional checks for WordPress functions
            return $this->isWordPressFunctionSafe($functionName);
        }

        return false;
    }

    /**
     * Check if WordPress function is safe
     */
    private function isWordPressFunctionSafe(string $functionName): bool
    {
        $unsafeFunctions = [
            'wp_remote_get', 'wp_remote_post', 'wp_remote_request',
            'wp_mail', 'wp_redirect', 'wp_die',
            'delete_option', 'update_option', 'add_option',
            'wp_insert_post', 'wp_update_post', 'wp_delete_post'
        ];

        return !in_array($functionName, $unsafeFunctions);
    }

    /**
     * Sanitize input data
     */
    public function sanitizeInput($data): mixed
    {
        if (is_string($data)) {
            return sanitize_text_field($data);
        }

        if (is_array($data)) {
            return array_map([$this, 'sanitizeInput'], $data);
        }

        if (is_object($data)) {
            $sanitized = new \stdClass();
            foreach (get_object_vars($data) as $key => $value) {
                $sanitized->$key = $this->sanitizeInput($value);
            }
            return $sanitized;
        }

        return $data;
    }

    /**
     * Validate output data
     */
    public function validateOutput($data): bool
    {
        // Check for potentially dangerous content
        if (is_string($data)) {
            $dangerous = ['<script', 'javascript:', 'data:', 'vbscript:'];
            foreach ($dangerous as $pattern) {
                if (stripos($data, $pattern) !== false) {
                    return false;
                }
            }
        }

        if (is_array($data)) {
            foreach ($data as $value) {
                if (!$this->validateOutput($value)) {
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * Handle errors during execution
     */
    public function handleError(int $errno, string $errstr, string $errfile, int $errline): bool
    {
        // Log the error
        error_log("Vira Flow Sandbox Error: {$errstr} in {$errfile} on line {$errline}");
        
        // Don't execute PHP internal error handler
        return true;
    }

    /**
     * Get allowed functions
     */
    public function getAllowedFunctions(): array
    {
        return $this->allowedFunctions;
    }

    /**
     * Add allowed function
     */
    public function addAllowedFunction(string $functionName): void
    {
        if (!in_array($functionName, $this->allowedFunctions)) {
            $this->allowedFunctions[] = $functionName;
        }
    }

    /**
     * Remove allowed function
     */
    public function removeAllowedFunction(string $functionName): void
    {
        $key = array_search($functionName, $this->allowedFunctions);
        if ($key !== false) {
            unset($this->allowedFunctions[$key]);
        }
    }
}