<?php

namespace VFlow\Infra\Security;

/**
 * Capability Management
 */
class Capability
{
    private const CAPABILITIES = [
        'vflow_manage' => 'Manage Vira Flow workflows',
        'vflow_execute' => 'Execute Vira Flow workflows',
        'vflow_view_logs' => 'View Vira Flow execution logs'
    ];

    /**
     * Setup default capabilities
     */
    public function setupDefaultCapabilities(): void
    {
        $admin_role = get_role('administrator');
        
        if ($admin_role) {
            foreach (array_keys(self::CAPABILITIES) as $capability) {
                $admin_role->add_cap($capability);
            }
        }
    }

    /**
     * Remove capabilities
     */
    public function removeCapabilities(): void
    {
        $roles = wp_roles()->get_names();
        
        foreach ($roles as $role_name => $role_display) {
            $role = get_role($role_name);
            if ($role) {
                foreach (array_keys(self::CAPABILITIES) as $capability) {
                    $role->remove_cap($capability);
                }
            }
        }
    }

    /**
     * Check if current user has capability
     */
    public function can(string $capability): bool
    {
        return current_user_can($capability);
    }

    /**
     * Check if current user can manage workflows
     */
    public function canManage(): bool
    {
        return $this->can('vflow_manage');
    }

    /**
     * Check if current user can execute workflows
     */
    public function canExecute(): bool
    {
        return $this->can('vflow_execute');
    }

    /**
     * Check if current user can view logs
     */
    public function canViewLogs(): bool
    {
        return $this->can('vflow_view_logs');
    }

    /**
     * Get all capabilities
     */
    public function getCapabilities(): array
    {
        return self::CAPABILITIES;
    }

    /**
     * Add capability to role
     */
    public function addCapabilityToRole(string $roleName, string $capability): bool
    {
        if (!array_key_exists($capability, self::CAPABILITIES)) {
            return false;
        }

        $role = get_role($roleName);
        if (!$role) {
            return false;
        }

        $role->add_cap($capability);
        return true;
    }

    /**
     * Remove capability from role
     */
    public function removeCapabilityFromRole(string $roleName, string $capability): bool
    {
        $role = get_role($roleName);
        if (!$role) {
            return false;
        }

        $role->remove_cap($capability);
        return true;
    }

    /**
     * Get users with capability
     */
    public function getUsersWithCapability(string $capability): array
    {
        if (!array_key_exists($capability, self::CAPABILITIES)) {
            return [];
        }

        return get_users(['capability' => $capability]);
    }
}