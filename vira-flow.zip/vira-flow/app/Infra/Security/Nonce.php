<?php

namespace VFlow\Infra\Security;

/**
 * Nonce Management
 */
class Nonce
{
    private const ACTION_PREFIX = 'vflow_';

    /**
     * Create nonce for action
     */
    public function create(string $action): string
    {
        return wp_create_nonce(self::ACTION_PREFIX . $action);
    }

    /**
     * Verify nonce for action
     */
    public function verify(string $nonce, string $action): bool
    {
        return wp_verify_nonce($nonce, self::ACTION_PREFIX . $action) !== false;
    }

    /**
     * Create nonce field for forms
     */
    public function field(string $action, string $name = '_vflow_nonce'): string
    {
        return wp_nonce_field(self::ACTION_PREFIX . $action, $name, true, false);
    }

    /**
     * Verify nonce from request
     */
    public function verifyRequest(string $action, string $name = '_vflow_nonce'): bool
    {
        $nonce = $_REQUEST[$name] ?? '';
        return $this->verify($nonce, $action);
    }

    /**
     * Create AJAX nonce
     */
    public function createAjax(string $action): string
    {
        return wp_create_nonce(self::ACTION_PREFIX . 'ajax_' . $action);
    }

    /**
     * Verify AJAX nonce
     */
    public function verifyAjax(string $nonce, string $action): bool
    {
        return wp_verify_nonce($nonce, self::ACTION_PREFIX . 'ajax_' . $action) !== false;
    }

    /**
     * Check AJAX referer
     */
    public function checkAjaxReferer(string $action): bool
    {
        return check_ajax_referer(self::ACTION_PREFIX . 'ajax_' . $action, '_vflow_nonce', false) !== false;
    }

    /**
     * Get nonce for REST API
     */
    public function getRestNonce(): string
    {
        return wp_create_nonce('wp_rest');
    }

    /**
     * Verify REST nonce
     */
    public function verifyRestNonce(string $nonce): bool
    {
        return wp_verify_nonce($nonce, 'wp_rest') !== false;
    }
}