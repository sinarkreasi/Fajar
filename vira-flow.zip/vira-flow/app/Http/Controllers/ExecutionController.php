<?php

namespace VFlow\Http\Controllers;

use VFlow\Core\Application;
use WP_REST_Request;
use WP_REST_Response;

/**
 * Execution Controller
 */
class ExecutionController
{
    /**
     * Get all executions
     */
    public static function index(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;
        
        $page = max(1, (int) $request->get_param('page'));
        $per_page = min(100, max(1, (int) $request->get_param('per_page') ?: 20));
        $offset = ($page - 1) * $per_page;
        
        $workflow_id = $request->get_param('workflow_id');
        $status = $request->get_param('status');
        
        $where = ['1=1'];
        $params = [];
        
        if ($workflow_id) {
            $where[] = 'workflow_id = %d';
            $params[] = (int) $workflow_id;
        }
        
        if ($status) {
            $where[] = 'status = %s';
            $params[] = sanitize_text_field($status);
        }
        
        $table = $wpdb->prefix . 'vflow_jobs';
        $where_clause = implode(' AND ', $where);
        
        // Get total count
        $count_sql = "SELECT COUNT(*) FROM {$table} WHERE {$where_clause}";
        $total = $wpdb->get_var($params ? $wpdb->prepare($count_sql, ...$params) : $count_sql);
        
        // Get executions
        $sql = "SELECT * FROM {$table} WHERE {$where_clause} ORDER BY created_at DESC LIMIT %d OFFSET %d";
        $params[] = $per_page;
        $params[] = $offset;
        
        $executions = $wpdb->get_results($wpdb->prepare($sql, ...$params), ARRAY_A);
        
        // Format executions
        foreach ($executions as &$execution) {
            $execution['context'] = json_decode($execution['context'], true) ?: [];
            $execution['result'] = json_decode($execution['result'], true) ?: [];
            $execution['duration'] = null;
            
            if ($execution['started_at'] && $execution['completed_at']) {
                $start = strtotime($execution['started_at']);
                $end = strtotime($execution['completed_at']);
                $execution['duration'] = $end - $start;
            }
        }
        
        return new WP_REST_Response([
            'executions' => $executions,
            'pagination' => [
                'page' => $page,
                'per_page' => $per_page,
                'total' => (int) $total,
                'total_pages' => ceil($total / $per_page)
            ]
        ], 200);
    }

    /**
     * Get single execution
     */
    public static function show(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;
        
        $id = (int) $request->get_param('id');
        $table = $wpdb->prefix . 'vflow_jobs';
        
        $execution = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table} WHERE id = %d",
            $id
        ), ARRAY_A);
        
        if (!$execution) {
            return new WP_REST_Response(['error' => 'Execution not found'], 404);
        }
        
        // Format execution
        $execution['context'] = json_decode($execution['context'], true) ?: [];
        $execution['result'] = json_decode($execution['result'], true) ?: [];
        $execution['duration'] = null;
        
        if ($execution['started_at'] && $execution['completed_at']) {
            $start = strtotime($execution['started_at']);
            $end = strtotime($execution['completed_at']);
            $execution['duration'] = $end - $start;
        }
        
        return new WP_REST_Response($execution, 200);
    }

    /**
     * Get execution steps
     */
    public static function steps(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;
        
        $id = (int) $request->get_param('id');
        $table = $wpdb->prefix . 'vflow_job_steps';
        
        $steps = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table} WHERE job_id = %d ORDER BY created_at ASC",
            $id
        ), ARRAY_A);
        
        // Format steps
        foreach ($steps as &$step) {
            $step['result'] = json_decode($step['result'], true) ?: [];
        }
        
        return new WP_REST_Response($steps, 200);
    }
}