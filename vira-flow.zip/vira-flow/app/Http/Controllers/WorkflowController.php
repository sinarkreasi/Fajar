<?php

namespace VFlow\Http\Controllers;

use VFlow\Core\Application;
use VFlow\Domain\Workflow\Workflow;
use WP_REST_Request;
use WP_REST_Response;
use WP_Error;

/**
 * Workflow Controller
 */
class WorkflowController
{
    /**
     * Get all workflows
     */
    public static function index(WP_REST_Request $request): WP_REST_Response
    {
        $app = Application::getInstance();
        $repository = $app->getContainer()->make('workflow_repository');
        
        $status = $request->get_param('status');
        
        if ($status) {
            $workflows = $repository->findByStatus($status);
        } else {
            $workflows = $repository->findAll();
        }
        
        $data = array_map(function($workflow) {
            return $workflow->toArray();
        }, $workflows);
        
        return new WP_REST_Response($data, 200);
    }

    /**
     * Get single workflow
     */
    public static function show(WP_REST_Request $request): WP_REST_Response
    {
        $app = Application::getInstance();
        $repository = $app->getContainer()->make('workflow_repository');
        
        $id = (int) $request->get_param('id');
        $workflow = $repository->find($id);
        
        if (!$workflow) {
            return new WP_REST_Response(['error' => 'Workflow not found'], 404);
        }
        
        return new WP_REST_Response($workflow->toArray(), 200);
    }

    /**
     * Create new workflow
     */
    public static function store(WP_REST_Request $request): WP_REST_Response
    {
        $app = Application::getInstance();
        $repository = $app->getContainer()->make('workflow_repository');
        $validator = $app->getContainer()->make('workflow_validator');
        
        // Get data from either JSON or form params
        $data = $request->get_json_params() ?: $request->get_params();
        
        // Validate required fields
        if (empty($data['name'])) {
            return new WP_REST_Response(['error' => 'Name is required'], 400);
        }
        
        // Set default definition if not provided
        if (empty($data['definition'])) {
            $data['definition'] = ['nodes' => [], 'connections' => []];
        }
        
        // Validate workflow definition
        $errors = $validator->validate($data['definition']);
        if (!empty($errors)) {
            return new WP_REST_Response(['errors' => $errors], 400);
        }
        
        // Create workflow
        $workflow = new Workflow(
            sanitize_text_field($data['name']),
            sanitize_textarea_field($data['description'] ?? ''),
            $data['definition'],
            'draft',
            $data['settings'] ?? []
        );
        
        $workflow = $repository->save($workflow);
        
        return new WP_REST_Response($workflow->toArray(), 201);
    }

    /**
     * Update workflow
     */
    public static function update(WP_REST_Request $request): WP_REST_Response
    {
        $app = Application::getInstance();
        $repository = $app->getContainer()->make('workflow_repository');
        $validator = $app->getContainer()->make('workflow_validator');
        
        $id = (int) $request->get_param('id');
        $workflow = $repository->find($id);
        
        if (!$workflow) {
            return new WP_REST_Response(['error' => 'Workflow not found'], 404);
        }
        
        // Get data from either JSON or form params
        $data = $request->get_json_params() ?: $request->get_params();
        
        // Update fields
        if (isset($data['name'])) {
            $workflow->setName(sanitize_text_field($data['name']));
        }
        
        if (isset($data['description'])) {
            $workflow->setDescription(sanitize_textarea_field($data['description']));
        }
        
        if (isset($data['definition'])) {
            // Validate workflow definition
            $errors = $validator->validate($data['definition']);
            if (!empty($errors)) {
                return new WP_REST_Response(['errors' => $errors], 400);
            }
            
            $workflow->setDefinition($data['definition']);
        }
        
        if (isset($data['settings'])) {
            $workflow->setSettings($data['settings']);
        }
        
        $workflow = $repository->save($workflow);
        
        return new WP_REST_Response($workflow->toArray(), 200);
    }

    /**
     * Delete workflow
     */
    public static function destroy(WP_REST_Request $request): WP_REST_Response
    {
        $app = Application::getInstance();
        $repository = $app->getContainer()->make('workflow_repository');
        
        $id = (int) $request->get_param('id');
        $workflow = $repository->find($id);
        
        if (!$workflow) {
            return new WP_REST_Response(['error' => 'Workflow not found'], 404);
        }
        
        $repository->delete($id);
        
        return new WP_REST_Response(['message' => 'Workflow deleted'], 200);
    }

    /**
     * Activate workflow
     */
    public static function activate(WP_REST_Request $request): WP_REST_Response
    {
        $app = Application::getInstance();
        $repository = $app->getContainer()->make('workflow_repository');
        
        $id = (int) $request->get_param('id');
        $workflow = $repository->find($id);
        
        if (!$workflow) {
            return new WP_REST_Response(['error' => 'Workflow not found'], 404);
        }
        
        $workflow->activate();
        $workflow = $repository->save($workflow);
        
        return new WP_REST_Response($workflow->toArray(), 200);
    }

    /**
     * Deactivate workflow
     */
    public static function deactivate(WP_REST_Request $request): WP_REST_Response
    {
        $app = Application::getInstance();
        $repository = $app->getContainer()->make('workflow_repository');
        
        $id = (int) $request->get_param('id');
        $workflow = $repository->find($id);
        
        if (!$workflow) {
            return new WP_REST_Response(['error' => 'Workflow not found'], 404);
        }
        
        $workflow->deactivate();
        $workflow = $repository->save($workflow);
        
        return new WP_REST_Response($workflow->toArray(), 200);
    }

    /**
     * Execute workflow
     */
    public static function execute(WP_REST_Request $request): WP_REST_Response
    {
        $app = Application::getInstance();
        $kernel = $app->getContainer()->make('kernel');
        
        $id = (int) $request->get_param('id');
        $context = $request->get_json_params() ?: [];
        
        try {
            $kernel->executeWorkflow($id, $context);
            return new WP_REST_Response(['message' => 'Workflow execution queued'], 200);
        } catch (\Exception $e) {
            return new WP_REST_Response(['error' => $e->getMessage()], 500);
        }
    }
}