<?php

namespace VFlow\Http\Controllers;

use VFlow\Core\Application;
use WP_REST_Request;
use WP_REST_Response;

/**
 * Node Controller
 */
class NodeController
{
    /**
     * Get all available nodes
     */
    public static function index(WP_REST_Request $request): WP_REST_Response
    {
        $app = Application::getInstance();
        $registry = $app->getContainer()->make('node_registry');
        
        $category = $request->get_param('category');
        
        if ($category) {
            $nodes = $registry->getNodesByCategory($category);
        } else {
            $nodes = $registry->getAllNodes();
        }
        
        return new WP_REST_Response($nodes, 200);
    }

    /**
     * Get single node details
     */
    public static function show(WP_REST_Request $request): WP_REST_Response
    {
        $app = Application::getInstance();
        $registry = $app->getContainer()->make('node_registry');
        
        $type = $request->get_param('type');
        $node = $registry->get($type);
        
        if (!$node) {
            return new WP_REST_Response(['error' => 'Node not found'], 404);
        }
        
        return new WP_REST_Response($node->getMetadata(), 200);
    }
}