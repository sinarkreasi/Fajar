<?php

namespace VFlow\Http\Controllers;

use VFlow\Core\Application;
use WP_REST_Request;
use WP_REST_Response;

/**
 * Webhook Controller
 */
class WebhookController
{
    /**
     * Handle webhook request
     */
    public static function handle(WP_REST_Request $request): WP_REST_Response
    {
        $app = Application::getInstance();
        $kernel = $app->getContainer()->make('kernel');
        $logger = $app->getContainer()->make('logger');
        
        $webhookId = $request->get_param('id');
        $method = $request->get_method();
        
        // Get request data
        $headers = $request->get_headers();
        $body = $request->get_body();
        $params = $request->get_params();
        
        // Parse body based on content type
        $payload = [];
        $contentType = $headers['content_type'][0] ?? '';
        
        if (strpos($contentType, 'application/json') !== false) {
            $payload = json_decode($body, true) ?: [];
        } elseif (strpos($contentType, 'application/x-www-form-urlencoded') !== false) {
            parse_str($body, $payload);
        } else {
            $payload = $params;
        }
        
        // Add metadata to payload
        $payload['_webhook'] = [
            'id' => $webhookId,
            'method' => $method,
            'headers' => $headers,
            'raw_body' => $body,
            'received_at' => current_time('mysql')
        ];
        
        $logger->info("Webhook received", [
            'webhook_id' => $webhookId,
            'method' => $method,
            'payload_size' => strlen($body)
        ]);
        
        try {
            // Handle webhook
            $kernel->handleWebhook($webhookId, $payload);
            
            return new WP_REST_Response([
                'success' => true,
                'message' => 'Webhook processed'
            ], 200);
            
        } catch (\Exception $e) {
            $logger->error("Webhook processing failed", [
                'webhook_id' => $webhookId,
                'error' => $e->getMessage()
            ]);
            
            return new WP_REST_Response([
                'success' => false,
                'error' => 'Webhook processing failed'
            ], 500);
        }
    }
}