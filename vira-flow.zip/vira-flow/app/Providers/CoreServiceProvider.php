<?php

namespace VFlow\Providers;

use VFlow\Core\Container;
use VFlow\Core\Kernel;
use VFlow\Infra\Assets\AssetManager;
use VFlow\Infra\Queue\ActionSchedulerQueue;
use VFlow\Infra\Queue\Dispatcher;
use VFlow\Infra\Security\Capability;
use VFlow\Infra\Security\Nonce;
use VFlow\Infra\Security\Sandbox;
use VFlow\Support\Logger;

/**
 * Core Service Provider
 */
class CoreServiceProvider
{
    private Container $container;

    public function __construct(Container $container)
    {
        $this->container = $container;
    }

    /**
     * Register services
     */
    public function register(): void
    {
        $this->registerKernel();
        $this->registerQueue();
        $this->registerSecurity();
        $this->registerAssets();
        $this->registerLogger();
    }

    /**
     * Boot services
     */
    public function boot(): void
    {
        $this->setupCustomSchedules();
        $this->setupSecurityHooks();
    }

    /**
     * Register kernel
     */
    private function registerKernel(): void
    {
        $this->container->singleton('kernel', function($container) {
            return new Kernel($container);
        });
    }

    /**
     * Register queue services
     */
    private function registerQueue(): void
    {
        $this->container->singleton('queue', function() {
            return new ActionSchedulerQueue();
        });

        $this->container->singleton('queue_dispatcher', function($container) {
            return new Dispatcher($container->make('queue'));
        });
    }

    /**
     * Register security services
     */
    private function registerSecurity(): void
    {
        $this->container->singleton('capability', function() {
            return new Capability();
        });

        $this->container->singleton('nonce', function() {
            return new Nonce();
        });

        $this->container->singleton('sandbox', function() {
            return new Sandbox();
        });
    }

    /**
     * Register asset manager
     */
    private function registerAssets(): void
    {
        $this->container->singleton('asset_manager', function() {
            return new AssetManager();
        });
    }

    /**
     * Register logger
     */
    private function registerLogger(): void
    {
        $this->container->singleton('logger', function() {
            return new Logger();
        });
    }

    /**
     * Setup custom cron schedules
     */
    private function setupCustomSchedules(): void
    {
        add_filter('cron_schedules', function($schedules) {
            $schedules['vflow_queue_interval'] = [
                'interval' => 60, // 1 minute
                'display' => 'Every Minute (Vira Flow)'
            ];
            
            $schedules['vflow_cleanup_interval'] = [
                'interval' => 86400, // 24 hours
                'display' => 'Daily (Vira Flow)'
            ];
            
            return $schedules;
        });
    }

    /**
     * Setup security hooks
     */
    private function setupSecurityHooks(): void
    {
        // Add custom capabilities to admin role on plugin activation
        add_action('vflow_activated', function() {
            $capability = $this->container->make('capability');
            $capability->setupDefaultCapabilities();
        });
    }
}