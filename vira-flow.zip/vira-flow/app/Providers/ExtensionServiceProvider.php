<?php

namespace VFlow\Providers;

use VFlow\Core\Container;

/**
 * Extension Service Provider
 */
class ExtensionServiceProvider
{
    private Container $container;

    public function __construct(Container $container)
    {
        $this->container = $container;
    }

    /**
     * Register services
     */
    public function register(): void
    {
        // Extension services will be registered here
    }

    /**
     * Boot services
     */
    public function boot(): void
    {
        $this->setupExtensionHooks();
    }

    /**
     * Setup extension hooks
     */
    private function setupExtensionHooks(): void
    {
        // Hook for extensions to register their nodes
        add_action('vflow_extension_registered', [$this, 'loadExtensionNodes'], 10, 3);
        
        // Hook for extensions to register their services
        add_action('vflow_extension_registered', [$this, 'loadExtensionServices'], 10, 3);
    }

    /**
     * Load extension nodes
     */
    public function loadExtensionNodes(string $name, array $config, string $path): void
    {
        if (!isset($config['nodes'])) {
            return;
        }

        $registry = $this->container->make('node_registry');

        foreach ($config['nodes'] as $nodeConfig) {
            $type = $nodeConfig['type'] ?? 'action';
            $nodeId = $nodeConfig['id'];
            $className = $nodeConfig['class'];

            switch ($type) {
                case 'trigger':
                    $registry->registerTrigger($nodeId, $className);
                    break;
                case 'action':
                    $registry->registerAction($nodeId, $className);
                    break;
                case 'condition':
                    $registry->registerCondition($nodeId, $className);
                    break;
            }
        }
    }

    /**
     * Load extension services
     */
    public function loadExtensionServices(string $name, array $config, string $path): void
    {
        if (!isset($config['service_provider'])) {
            return;
        }

        $providerClass = $config['service_provider'];
        
        if (class_exists($providerClass)) {
            $provider = new $providerClass($this->container);
            
            if (method_exists($provider, 'register')) {
                $provider->register();
            }
            
            if (method_exists($provider, 'boot')) {
                $provider->boot();
            }
        }
    }
}