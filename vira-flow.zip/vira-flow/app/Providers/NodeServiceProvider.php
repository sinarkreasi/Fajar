<?php

namespace VFlow\Providers;

use VFlow\Core\Container;
use VFlow\Domain\Node\NodeRegistry;
use VFlow\Domain\Workflow\WorkflowRepository;
use VFlow\Domain\Workflow\WorkflowValidator;
use VFlow\Domain\Execution\Runner;
use VFlow\Domain\Execution\StepExecutor;

/**
 * Node Service Provider
 */
class NodeServiceProvider
{
    private Container $container;

    public function __construct(Container $container)
    {
        $this->container = $container;
    }

    /**
     * Register services
     */
    public function register(): void
    {
        $this->registerNodeRegistry();
        $this->registerWorkflowServices();
        $this->registerExecutionServices();
    }

    /**
     * Boot services
     */
    public function boot(): void
    {
        $this->registerCoreNodes();
    }

    /**
     * Register node registry
     */
    private function registerNodeRegistry(): void
    {
        $this->container->singleton('node_registry', function() {
            return new NodeRegistry();
        });
    }

    /**
     * Register workflow services
     */
    private function registerWorkflowServices(): void
    {
        $this->container->singleton('workflow_repository', function() {
            return new WorkflowRepository();
        });

        $this->container->singleton('workflow_validator', function() {
            return new WorkflowValidator();
        });
    }

    /**
     * Register execution services
     */
    private function registerExecutionServices(): void
    {
        $this->container->singleton('execution_runner', function($container) {
            return new Runner(
                $container->make('node_registry'),
                $container->make('logger')
            );
        });

        $this->container->singleton('step_executor', function($container) {
            return new StepExecutor(
                $container->make('sandbox'),
                $container->make('logger')
            );
        });
    }

    /**
     * Register core nodes
     */
    private function registerCoreNodes(): void
    {
        $registry = $this->container->make('node_registry');
        
        // Register core trigger nodes
        $registry->registerTrigger('webhook', 'VFlow\\Nodes\\Triggers\\WebhookTrigger');
        $registry->registerTrigger('schedule', 'VFlow\\Nodes\\Triggers\\ScheduleTrigger');
        
        // Register core action nodes
        $registry->registerAction('http_request', 'VFlow\\Nodes\\Actions\\HttpRequestAction');
        $registry->registerAction('email', 'VFlow\\Nodes\\Actions\\EmailAction');
        
        // Register core condition nodes
        $registry->registerCondition('compare', 'VFlow\\Nodes\\Conditions\\CompareCondition');
        $registry->registerCondition('exists', 'VFlow\\Nodes\\Conditions\\ExistsCondition');
        
        do_action('vflow_register_core_nodes', $registry);
    }
}