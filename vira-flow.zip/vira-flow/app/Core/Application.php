<?php

namespace VFlow\Core;

use VFlow\Providers\CoreServiceProvider;
use VFlow\Providers\NodeServiceProvider;
use VFlow\Providers\ExtensionServiceProvider;

/**
 * Main Application class - Singleton pattern
 */
class Application
{
    private static ?Application $instance = null;
    private Container $container;
    private array $providers = [];
    private array $extensions = [];
    private bool $booted = false;

    private function __construct()
    {
        $this->container = new Container();
        $this->registerCoreBindings();
    }

    public static function getInstance(): Application
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Boot the application
     */
    public function boot(): void
    {
        if ($this->booted) {
            return;
        }

        $this->registerServiceProviders();
        $this->bootServiceProviders();
        $this->setupHooks();
        
        $this->booted = true;
        
        // Fire core loaded action
        do_action('vflow_core_loaded');
    }

    /**
     * Get the container instance
     */
    public function getContainer(): Container
    {
        return $this->container;
    }

    /**
     * Register an extension
     */
    public function registerExtension(string $name, array $config, string $path): void
    {
        $this->extensions[$name] = [
            'config' => $config,
            'path' => $path
        ];
        
        do_action('vflow_extension_registered', $name, $config, $path);
    }

    /**
     * Get registered extensions
     */
    public function getExtensions(): array
    {
        return $this->extensions;
    }

    /**
     * Plugin activation
     */
    public function activate(): void
    {
        // Create database tables
        $this->createTables();
        
        // Set up capabilities
        $this->setupCapabilities();
        
        // Flush rewrite rules
        flush_rewrite_rules();
        
        do_action('vflow_activated');
    }

    /**
     * Plugin deactivation
     */
    public function deactivate(): void
    {
        // Clear scheduled events
        wp_clear_scheduled_hook('vflow_process_queue');
        
        // Flush rewrite rules
        flush_rewrite_rules();
        
        do_action('vflow_deactivated');
    }

    /**
     * Register core bindings
     */
    private function registerCoreBindings(): void
    {
        $this->container->singleton('app', function() {
            return $this;
        });
    }

    /**
     * Register service providers
     */
    private function registerServiceProviders(): void
    {
        $providers = [
            CoreServiceProvider::class,
            NodeServiceProvider::class,
            ExtensionServiceProvider::class,
        ];

        foreach ($providers as $provider) {
            $providerInstance = new $provider($this->container);
            $providerInstance->register();
            $this->providers[] = $providerInstance;
        }
    }

    /**
     * Boot service providers
     */
    private function bootServiceProviders(): void
    {
        foreach ($this->providers as $provider) {
            if (method_exists($provider, 'boot')) {
                $provider->boot();
            }
        }
    }

    /**
     * Setup WordPress hooks
     */
    private function setupHooks(): void
    {
        // Admin hooks
        if (is_admin()) {
            add_action('admin_menu', [$this, 'registerAdminMenu']);
            add_action('admin_enqueue_scripts', [$this, 'enqueueAdminAssets']);
        }

        // REST API
        add_action('rest_api_init', [$this, 'registerRestRoutes']);
        
        // Queue processing
        add_action('vflow_process_queue', [$this, 'processQueue']);
        
        // Schedule queue processing if not already scheduled
        if (!wp_next_scheduled('vflow_process_queue')) {
            wp_schedule_event(time(), 'vflow_queue_interval', 'vflow_process_queue');
        }
    }

    /**
     * Register admin menu
     */
    public function registerAdminMenu(): void
    {
        add_menu_page(
            'Vira Flow',
            'Vira Flow',
            'vflow_manage',
            'vflow',
            [$this, 'renderAdminPage'],
            'dashicons-networking',
            30
        );

        add_submenu_page(
            'vflow',
            'Workflows',
            'Workflows',
            'vflow_manage',
            'vflow',
            [$this, 'renderAdminPage']
        );

        add_submenu_page(
            'vflow',
            'Executions',
            'Executions',
            'vflow_view_logs',
            'vflow-executions',
            [$this, 'renderExecutionsPage']
        );
    }

    /**
     * Enqueue admin assets
     */
    public function enqueueAdminAssets($hook): void
    {
        if (strpos($hook, 'vflow') === false) {
            return;
        }

        $assetManager = $this->container->make('asset_manager');
        $assetManager->enqueueAdminAssets();
    }

    /**
     * Register REST API routes
     */
    public function registerRestRoutes(): void
    {
        $namespace = 'vflow/v1';

        // Workflow routes
        register_rest_route($namespace, '/workflows', [
            [
                'methods' => 'GET',
                'callback' => function($request) {
                    return \VFlow\Http\Controllers\WorkflowController::index($request);
                },
                'permission_callback' => function() {
                    return current_user_can('vflow_manage');
                }
            ],
            [
                'methods' => 'POST',
                'callback' => function($request) {
                    return \VFlow\Http\Controllers\WorkflowController::store($request);
                },
                'permission_callback' => function() {
                    return current_user_can('vflow_manage');
                }
            ]
        ]);

        register_rest_route($namespace, '/workflows/(?P<id>\d+)', [
            [
                'methods' => 'GET',
                'callback' => function($request) {
                    return \VFlow\Http\Controllers\WorkflowController::show($request);
                },
                'permission_callback' => function() {
                    return current_user_can('vflow_manage');
                }
            ],
            [
                'methods' => 'PUT',
                'callback' => function($request) {
                    return \VFlow\Http\Controllers\WorkflowController::update($request);
                },
                'permission_callback' => function() {
                    return current_user_can('vflow_manage');
                }
            ],
            [
                'methods' => 'DELETE',
                'callback' => function($request) {
                    return \VFlow\Http\Controllers\WorkflowController::destroy($request);
                },
                'permission_callback' => function() {
                    return current_user_can('vflow_manage');
                }
            ]
        ]);

        register_rest_route($namespace, '/workflows/(?P<id>\d+)/activate', [
            'methods' => 'POST',
            'callback' => function($request) {
                return \VFlow\Http\Controllers\WorkflowController::activate($request);
            },
            'permission_callback' => function() {
                return current_user_can('vflow_manage');
            }
        ]);

        register_rest_route($namespace, '/workflows/(?P<id>\d+)/deactivate', [
            'methods' => 'POST',
            'callback' => function($request) {
                return \VFlow\Http\Controllers\WorkflowController::deactivate($request);
            },
            'permission_callback' => function() {
                return current_user_can('vflow_manage');
            }
        ]);

        register_rest_route($namespace, '/workflows/(?P<id>\d+)/execute', [
            'methods' => 'POST',
            'callback' => function($request) {
                return \VFlow\Http\Controllers\WorkflowController::execute($request);
            },
            'permission_callback' => function() {
                return current_user_can('vflow_execute');
            }
        ]);

        // Execution routes
        register_rest_route($namespace, '/executions', [
            'methods' => 'GET',
            'callback' => function($request) {
                return \VFlow\Http\Controllers\ExecutionController::index($request);
            },
            'permission_callback' => function() {
                return current_user_can('vflow_view_logs');
            }
        ]);

        // Node routes
        register_rest_route($namespace, '/nodes', [
            'methods' => 'GET',
            'callback' => function($request) {
                return \VFlow\Http\Controllers\NodeController::index($request);
            },
            'permission_callback' => function() {
                return current_user_can('vflow_manage');
            }
        ]);
    }

    /**
     * Process queue
     */
    public function processQueue(): void
    {
        $queue = $this->container->make('queue');
        $queue->process();
    }

    /**
     * Render admin page
     */
    public function renderAdminPage(): void
    {
        // Check if React build exists
        $react_file = VFLOW_PLUGIN_DIR . 'resources/admin-ui/dist/admin.js';
        
        if (file_exists($react_file)) {
            echo '<div id="vflow-admin-app"></div>';
        } else {
            // Fallback HTML interface
            $this->renderFallbackAdminPage();
        }
    }

    /**
     * Render executions page
     */
    public function renderExecutionsPage(): void
    {
        // Check if React build exists
        $react_file = VFLOW_PLUGIN_DIR . 'resources/admin-ui/dist/admin.js';
        
        if (file_exists($react_file)) {
            echo '<div id="vflow-executions-app"></div>';
        } else {
            // Fallback HTML interface
            $this->renderFallbackExecutionsPage();
        }
    }

    /**
     * Render fallback admin page
     */
    private function renderFallbackAdminPage(): void
    {
        $repository = $this->container->make('workflow_repository');
        $workflows = $repository->findAll();
        
        ?>
        <div class="wrap">
            <h1>Vira Flow - Workflows</h1>
            
            <div class="notice notice-info">
                <p><strong>React UI not built yet.</strong> Run <code>npm install && npm run build</code> in <code>resources/admin-ui/</code> for the full interface.</p>
            </div>
            
            <a href="<?php echo admin_url('admin.php?page=vflow&action=create'); ?>" class="button button-primary">Create Workflow</a>
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Status</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($workflows)): ?>
                        <tr>
                            <td colspan="4">No workflows found. <a href="<?php echo admin_url('admin.php?page=vflow&action=create'); ?>">Create your first workflow</a></td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($workflows as $workflow): ?>
                            <tr>
                                <td><strong><?php echo esc_html($workflow->getName()); ?></strong><br>
                                    <small><?php echo esc_html($workflow->getDescription()); ?></small>
                                </td>
                                <td>
                                    <span class="status-<?php echo esc_attr($workflow->getStatus()); ?>">
                                        <?php echo ucfirst($workflow->getStatus()); ?>
                                    </span>
                                </td>
                                <td><?php echo esc_html($workflow->getCreatedAt()); ?></td>
                                <td>
                                    <a href="<?php echo admin_url('admin.php?page=vflow&action=edit&id=' . $workflow->getId()); ?>" class="button button-small">Edit</a>
                                    <?php if ($workflow->isActive()): ?>
                                        <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=vflow&action=deactivate&id=' . $workflow->getId()), 'vflow_action'); ?>" class="button button-small">Deactivate</a>
                                    <?php else: ?>
                                        <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=vflow&action=activate&id=' . $workflow->getId()), 'vflow_action'); ?>" class="button button-small button-primary">Activate</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
            
            <style>
                .status-active { color: #00a32a; font-weight: bold; }
                .status-inactive { color: #dba617; }
                .status-draft { color: #646970; }
            </style>
        </div>
        <?php
    }

    /**
     * Render fallback executions page
     */
    private function renderFallbackExecutionsPage(): void
    {
        global $wpdb;
        
        $table = $wpdb->prefix . 'vflow_jobs';
        $executions = $wpdb->get_results("SELECT * FROM {$table} ORDER BY created_at DESC LIMIT 20", ARRAY_A);
        
        ?>
        <div class="wrap">
            <h1>Vira Flow - Executions</h1>
            
            <div class="notice notice-info">
                <p><strong>React UI not built yet.</strong> Run <code>npm install && npm run build</code> in <code>resources/admin-ui/</code> for the full interface.</p>
            </div>
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Workflow</th>
                        <th>Status</th>
                        <th>Started</th>
                        <th>Duration</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($executions)): ?>
                        <tr>
                            <td colspan="5">No executions found.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($executions as $execution): ?>
                            <?php
                            $duration = null;
                            if ($execution['started_at'] && $execution['completed_at']) {
                                $start = strtotime($execution['started_at']);
                                $end = strtotime($execution['completed_at']);
                                $duration = $end - $start . 's';
                            }
                            ?>
                            <tr>
                                <td><?php echo esc_html($execution['id']); ?></td>
                                <td><?php echo esc_html($execution['workflow_id']); ?></td>
                                <td>
                                    <span class="status-<?php echo esc_attr($execution['status']); ?>">
                                        <?php echo ucfirst($execution['status']); ?>
                                    </span>
                                </td>
                                <td><?php echo esc_html($execution['started_at'] ?: 'Not started'); ?></td>
                                <td><?php echo esc_html($duration ?: '-'); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
            
            <style>
                .status-completed { color: #00a32a; font-weight: bold; }
                .status-failed { color: #d63638; font-weight: bold; }
                .status-running { color: #0073aa; font-weight: bold; }
                .status-pending { color: #dba617; }
            </style>
        </div>
        <?php
    }

    /**
     * Create database tables
     */
    private function createTables(): void
    {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Create workflows table
        $sql1 = "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}vflow_workflows` (
          `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
          `name` varchar(255) NOT NULL,
          `description` text,
          `definition` longtext NOT NULL,
          `status` varchar(20) NOT NULL DEFAULT 'draft',
          `settings` longtext,
          `created_at` datetime NOT NULL,
          `updated_at` datetime NOT NULL,
          PRIMARY KEY (`id`),
          KEY `status` (`status`),
          KEY `created_at` (`created_at`)
        ) $charset_collate;";
        
        // Create jobs table
        $sql2 = "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}vflow_jobs` (
          `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
          `workflow_id` bigint(20) unsigned NOT NULL,
          `status` varchar(20) NOT NULL DEFAULT 'pending',
          `context` longtext,
          `result` longtext,
          `error` text,
          `created_at` datetime NOT NULL,
          `updated_at` datetime NOT NULL,
          `started_at` datetime DEFAULT NULL,
          `completed_at` datetime DEFAULT NULL,
          PRIMARY KEY (`id`),
          KEY `workflow_id` (`workflow_id`),
          KEY `status` (`status`),
          KEY `created_at` (`created_at`)
        ) $charset_collate;";
        
        // Create job steps table
        $sql3 = "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}vflow_job_steps` (
          `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
          `job_id` bigint(20) unsigned NOT NULL,
          `node_id` varchar(255) NOT NULL,
          `node_type` varchar(100) NOT NULL,
          `status` varchar(20) NOT NULL DEFAULT 'pending',
          `result` longtext,
          `error` text,
          `created_at` datetime NOT NULL,
          PRIMARY KEY (`id`),
          KEY `job_id` (`job_id`),
          KEY `node_id` (`node_id`),
          KEY `status` (`status`),
          KEY `created_at` (`created_at`)
        ) $charset_collate;";
        
        // Create logs table
        $sql4 = "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}vflow_logs` (
          `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
          `level` varchar(20) NOT NULL,
          `message` text NOT NULL,
          `context` longtext,
          `created_at` datetime NOT NULL,
          PRIMARY KEY (`id`),
          KEY `level` (`level`),
          KEY `created_at` (`created_at`)
        ) $charset_collate;";
        
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql1);
        dbDelta($sql2);
        dbDelta($sql3);
        dbDelta($sql4);
    }

    /**
     * Setup capabilities
     */
    private function setupCapabilities(): void
    {
        $admin_role = get_role('administrator');
        if ($admin_role) {
            $admin_role->add_cap('vflow_manage');
            $admin_role->add_cap('vflow_execute');
            $admin_role->add_cap('vflow_view_logs');
        }
    }
}