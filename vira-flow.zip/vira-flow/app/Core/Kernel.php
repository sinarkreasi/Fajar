<?php

namespace VFlow\Core;

/**
 * Application Kernel - handles core application logic
 */
class Kernel
{
    private Container $container;

    public function __construct(Container $container)
    {
        $this->container = $container;
    }

    /**
     * Handle workflow execution request
     */
    public function executeWorkflow(int $workflowId, array $context = []): void
    {
        $dispatcher = $this->container->make('queue_dispatcher');
        $dispatcher->dispatch('workflow_execution', [
            'workflow_id' => $workflowId,
            'context' => $context,
            'triggered_at' => current_time('mysql')
        ]);
    }

    /**
     * Handle webhook trigger
     */
    public function handleWebhook(string $webhookId, array $payload): void
    {
        $workflowRepo = $this->container->make('workflow_repository');
        $workflows = $workflowRepo->findByTrigger('webhook', ['webhook_id' => $webhookId]);

        foreach ($workflows as $workflow) {
            $this->executeWorkflow($workflow->getId(), [
                'trigger' => 'webhook',
                'webhook_id' => $webhookId,
                'payload' => $payload
            ]);
        }
    }

    /**
     * Process scheduled workflows
     */
    public function processScheduledWorkflows(): void
    {
        $workflowRepo = $this->container->make('workflow_repository');
        $workflows = $workflowRepo->findScheduledWorkflows();

        foreach ($workflows as $workflow) {
            $this->executeWorkflow($workflow->getId(), [
                'trigger' => 'schedule',
                'scheduled_at' => current_time('mysql')
            ]);
        }
    }

    /**
     * Clean up old execution logs
     */
    public function cleanupLogs(int $daysToKeep = 30): void
    {
        global $wpdb;
        
        $cutoff_date = date('Y-m-d H:i:s', strtotime("-{$daysToKeep} days"));
        
        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$wpdb->prefix}vflow_logs WHERE created_at < %s",
            $cutoff_date
        ));
        
        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$wpdb->prefix}vflow_job_steps WHERE created_at < %s",
            $cutoff_date
        ));
        
        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$wpdb->prefix}vflow_jobs WHERE created_at < %s AND status IN ('completed', 'failed')",
            $cutoff_date
        ));
    }
}