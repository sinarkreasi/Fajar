<?php

namespace VFlow\Core;

use Closure;
use ReflectionClass;
use ReflectionParameter;

/**
 * Simple dependency injection container
 */
class Container
{
    private array $bindings = [];
    private array $instances = [];
    private array $singletons = [];

    /**
     * Bind a service to the container
     */
    public function bind(string $abstract, $concrete = null, bool $shared = false): void
    {
        if ($concrete === null) {
            $concrete = $abstract;
        }

        $this->bindings[$abstract] = [
            'concrete' => $concrete,
            'shared' => $shared
        ];
    }

    /**
     * Bind a singleton to the container
     */
    public function singleton(string $abstract, $concrete = null): void
    {
        $this->bind($abstract, $concrete, true);
    }

    /**
     * Register an existing instance as shared
     */
    public function instance(string $abstract, $instance): void
    {
        $this->instances[$abstract] = $instance;
    }

    /**
     * Resolve a service from the container
     */
    public function make(string $abstract, array $parameters = [])
    {
        // Return existing instance if it exists
        if (isset($this->instances[$abstract])) {
            return $this->instances[$abstract];
        }

        // Get the binding
        $binding = $this->bindings[$abstract] ?? null;
        
        if ($binding === null) {
            // Try to auto-resolve if class exists
            if (class_exists($abstract)) {
                return $this->build($abstract, $parameters);
            }
            
            throw new \Exception("Service [{$abstract}] not found in container");
        }

        $concrete = $binding['concrete'];
        $shared = $binding['shared'];

        // If it's a closure, call it
        if ($concrete instanceof Closure) {
            $instance = $concrete($this, $parameters);
        } else {
            $instance = $this->build($concrete, $parameters);
        }

        // Store as singleton if shared
        if ($shared) {
            $this->instances[$abstract] = $instance;
        }

        return $instance;
    }

    /**
     * Build a class instance with dependency injection
     */
    private function build(string $concrete, array $parameters = [])
    {
        $reflection = new ReflectionClass($concrete);

        if (!$reflection->isInstantiable()) {
            throw new \Exception("Class [{$concrete}] is not instantiable");
        }

        $constructor = $reflection->getConstructor();

        if ($constructor === null) {
            return new $concrete;
        }

        $dependencies = $this->resolveDependencies($constructor->getParameters(), $parameters);

        return $reflection->newInstanceArgs($dependencies);
    }

    /**
     * Resolve constructor dependencies
     */
    private function resolveDependencies(array $parameters, array $primitives = []): array
    {
        $dependencies = [];

        foreach ($parameters as $parameter) {
            $dependency = $this->resolveDependency($parameter, $primitives);
            $dependencies[] = $dependency;
        }

        return $dependencies;
    }

    /**
     * Resolve a single dependency
     */
    private function resolveDependency(ReflectionParameter $parameter, array $primitives)
    {
        $name = $parameter->getName();

        // Check if primitive value provided
        if (array_key_exists($name, $primitives)) {
            return $primitives[$name];
        }

        $type = $parameter->getType();

        if ($type === null) {
            if ($parameter->isDefaultValueAvailable()) {
                return $parameter->getDefaultValue();
            }
            
            throw new \Exception("Cannot resolve parameter [{$name}]");
        }

        $typeName = $type->getName();

        // Try to resolve from container
        try {
            return $this->make($typeName);
        } catch (\Exception $e) {
            if ($parameter->isDefaultValueAvailable()) {
                return $parameter->getDefaultValue();
            }
            
            throw $e;
        }
    }

    /**
     * Check if service is bound
     */
    public function bound(string $abstract): bool
    {
        return isset($this->bindings[$abstract]) || isset($this->instances[$abstract]);
    }
}