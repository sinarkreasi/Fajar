<?php

namespace VFlow\Support;

/**
 * Logger
 */
class Logger
{
    private const LOG_LEVELS = [
        'debug' => 0,
        'info' => 1,
        'warning' => 2,
        'error' => 3
    ];

    private string $logLevel;

    public function __construct(string $logLevel = 'info')
    {
        $this->logLevel = $logLevel;
    }

    /**
     * Log debug message
     */
    public function debug(string $message, array $context = []): void
    {
        $this->log('debug', $message, $context);
    }

    /**
     * Log info message
     */
    public function info(string $message, array $context = []): void
    {
        $this->log('info', $message, $context);
    }

    /**
     * Log warning message
     */
    public function warning(string $message, array $context = []): void
    {
        $this->log('warning', $message, $context);
    }

    /**
     * Log error message
     */
    public function error(string $message, array $context = []): void
    {
        $this->log('error', $message, $context);
    }

    /**
     * Log message
     */
    public function log(string $level, string $message, array $context = []): void
    {
        if (!$this->shouldLog($level)) {
            return;
        }

        // Format message
        $formattedMessage = $this->formatMessage($level, $message, $context);

        // Log to database
        $this->logToDatabase($level, $message, $context);

        // Log to WordPress debug log if enabled
        if (WP_DEBUG_LOG) {
            error_log($formattedMessage);
        }
    }

    /**
     * Check if level should be logged
     */
    private function shouldLog(string $level): bool
    {
        $currentLevel = self::LOG_LEVELS[$this->logLevel] ?? 1;
        $messageLevel = self::LOG_LEVELS[$level] ?? 1;

        return $messageLevel >= $currentLevel;
    }

    /**
     * Format log message
     */
    private function formatMessage(string $level, string $message, array $context): string
    {
        $timestamp = current_time('Y-m-d H:i:s');
        $contextStr = !empty($context) ? ' ' . wp_json_encode($context) : '';
        
        return "[{$timestamp}] VFLOW.{$level}: {$message}{$contextStr}";
    }

    /**
     * Log to database
     */
    private function logToDatabase(string $level, string $message, array $context): void
    {
        global $wpdb;

        $table = $wpdb->prefix . 'vflow_logs';

        $wpdb->insert($table, [
            'level' => $level,
            'message' => $message,
            'context' => wp_json_encode($context),
            'created_at' => current_time('mysql')
        ]);
    }

    /**
     * Get logs from database
     */
    public function getLogs(array $filters = []): array
    {
        global $wpdb;

        $table = $wpdb->prefix . 'vflow_logs';
        $where = ['1=1'];
        $params = [];

        // Apply filters
        if (!empty($filters['level'])) {
            $where[] = 'level = %s';
            $params[] = $filters['level'];
        }

        if (!empty($filters['from_date'])) {
            $where[] = 'created_at >= %s';
            $params[] = $filters['from_date'];
        }

        if (!empty($filters['to_date'])) {
            $where[] = 'created_at <= %s';
            $params[] = $filters['to_date'];
        }

        if (!empty($filters['search'])) {
            $where[] = 'message LIKE %s';
            $params[] = '%' . $wpdb->esc_like($filters['search']) . '%';
        }

        $limit = $filters['limit'] ?? 100;
        $offset = $filters['offset'] ?? 0;

        $sql = "SELECT * FROM {$table} WHERE " . implode(' AND ', $where) . 
               " ORDER BY created_at DESC LIMIT %d OFFSET %d";
        
        $params[] = $limit;
        $params[] = $offset;

        return $wpdb->get_results($wpdb->prepare($sql, ...$params), ARRAY_A);
    }

    /**
     * Clear old logs
     */
    public function clearOldLogs(int $daysToKeep = 30): int
    {
        global $wpdb;

        $table = $wpdb->prefix . 'vflow_logs';
        $cutoffDate = date('Y-m-d H:i:s', strtotime("-{$daysToKeep} days"));

        return $wpdb->query($wpdb->prepare(
            "DELETE FROM {$table} WHERE created_at < %s",
            $cutoffDate
        ));
    }

    /**
     * Set log level
     */
    public function setLogLevel(string $level): void
    {
        if (array_key_exists($level, self::LOG_LEVELS)) {
            $this->logLevel = $level;
        }
    }

    /**
     * Get current log level
     */
    public function getLogLevel(): string
    {
        return $this->logLevel;
    }
}