<?php

namespace VFlow\Domain\Workflow;

/**
 * Workflow Validator
 */
class WorkflowValidator
{
    /**
     * Validate workflow definition
     */
    public function validate(array $definition): array
    {
        $errors = [];
        
        // Allow empty workflows for initial creation
        if (empty($definition['nodes']) && empty($definition['connections'])) {
            return $errors; // Empty workflow is valid for drafts
        }
        
        // Check required fields only if nodes exist
        if (!empty($definition['nodes'])) {
            // Validate nodes
            $nodeErrors = $this->validateNodes($definition['nodes']);
            $errors = array_merge($errors, $nodeErrors);
            
            // Check for trigger node
            $hasTrigger = false;
            foreach ($definition['nodes'] as $node) {
                if (($node['type'] ?? '') === 'trigger') {
                    $hasTrigger = true;
                    break;
                }
            }
            
            if (!$hasTrigger) {
                $errors[] = 'Workflow must have at least one trigger node';
            }
        }
        
        // Validate connections only if they exist
        if (!empty($definition['connections'])) {
            $connectionErrors = $this->validateConnections($definition['connections'], $definition['nodes'] ?? []);
            $errors = array_merge($errors, $connectionErrors);
        }
        
        return $errors;
    }

    /**
     * Validate nodes
     */
    private function validateNodes(array $nodes): array
    {
        $errors = [];
        $nodeIds = [];
        
        foreach ($nodes as $index => $node) {
            $nodePrefix = sprintf(__('Node %d', 'vflow'), $index + 1);
            
            // Check required fields
            if (empty($node['id'])) {
                $errors[] = $nodePrefix . ': ' . __('Node ID is required', 'vflow');
                continue;
            }
            
            if (empty($node['type'])) {
                $errors[] = $nodePrefix . ': ' . __('Node type is required', 'vflow');
            }
            
            if (empty($node['node_type'])) {
                $errors[] = $nodePrefix . ': ' . __('Node type identifier is required', 'vflow');
            }
            
            // Check for duplicate IDs
            if (in_array($node['id'], $nodeIds)) {
                $errors[] = $nodePrefix . ': ' . __('Duplicate node ID', 'vflow');
            } else {
                $nodeIds[] = $node['id'];
            }
            
            // Validate node type
            if (!in_array($node['type'] ?? '', ['trigger', 'action', 'condition'])) {
                $errors[] = $nodePrefix . ': ' . __('Invalid node type', 'vflow');
            }
            
            // Validate position
            if (!isset($node['position']['x']) || !isset($node['position']['y'])) {
                $errors[] = $nodePrefix . ': ' . __('Node position is required', 'vflow');
            }
        }
        
        return $errors;
    }

    /**
     * Validate connections
     */
    private function validateConnections(array $connections, array $nodes): array
    {
        $errors = [];
        $nodeIds = array_column($nodes, 'id');
        
        foreach ($connections as $index => $connection) {
            $connectionPrefix = sprintf(__('Connection %d', 'vflow'), $index + 1);
            
            // Check required fields
            if (empty($connection['source'])) {
                $errors[] = $connectionPrefix . ': ' . __('Source node is required', 'vflow');
                continue;
            }
            
            if (empty($connection['target'])) {
                $errors[] = $connectionPrefix . ': ' . __('Target node is required', 'vflow');
                continue;
            }
            
            // Check if nodes exist
            if (!in_array($connection['source'], $nodeIds)) {
                $errors[] = $connectionPrefix . ': ' . __('Source node does not exist', 'vflow');
            }
            
            if (!in_array($connection['target'], $nodeIds)) {
                $errors[] = $connectionPrefix . ': ' . __('Target node does not exist', 'vflow');
            }
            
            // Check for self-connections
            if ($connection['source'] === $connection['target']) {
                $errors[] = $connectionPrefix . ': ' . __('Node cannot connect to itself', 'vflow');
            }
        }
        
        return $errors;
    }

    /**
     * Check if workflow has circular dependencies
     */
    public function hasCircularDependencies(array $definition): bool
    {
        $connections = $definition['connections'] ?? [];
        $graph = [];
        
        // Build adjacency list
        foreach ($connections as $connection) {
            $source = $connection['source'];
            $target = $connection['target'];
            
            if (!isset($graph[$source])) {
                $graph[$source] = [];
            }
            
            $graph[$source][] = $target;
        }
        
        // Check for cycles using DFS
        $visited = [];
        $recursionStack = [];
        
        foreach (array_keys($graph) as $node) {
            if ($this->hasCycleDFS($graph, $node, $visited, $recursionStack)) {
                return true;
            }
        }
        
        return false;
    }

    /**
     * DFS helper for cycle detection
     */
    private function hasCycleDFS(array $graph, string $node, array &$visited, array &$recursionStack): bool
    {
        if (isset($recursionStack[$node])) {
            return true; // Back edge found
        }
        
        if (isset($visited[$node])) {
            return false; // Already processed
        }
        
        $visited[$node] = true;
        $recursionStack[$node] = true;
        
        foreach ($graph[$node] ?? [] as $neighbor) {
            if ($this->hasCycleDFS($graph, $neighbor, $visited, $recursionStack)) {
                return true;
            }
        }
        
        unset($recursionStack[$node]);
        return false;
    }
}