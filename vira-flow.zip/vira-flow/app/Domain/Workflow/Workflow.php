<?php

namespace VFlow\Domain\Workflow;

/**
 * Workflow Domain Model
 */
class Workflow
{
    private ?int $id;
    private string $name;
    private string $description;
    private array $definition;
    private string $status;
    private array $settings;
    private string $createdAt;
    private string $updatedAt;

    public function __construct(
        string $name,
        string $description,
        array $definition,
        string $status = 'draft',
        array $settings = [],
        ?int $id = null,
        ?string $createdAt = null,
        ?string $updatedAt = null
    ) {
        $this->id = $id;
        $this->name = $name;
        $this->description = $description;
        $this->definition = $definition;
        $this->status = $status;
        $this->settings = $settings;
        $this->createdAt = $createdAt ?? current_time('mysql');
        $this->updatedAt = $updatedAt ?? current_time('mysql');
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function setId(int $id): void
    {
        $this->id = $id;
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function setName(string $name): void
    {
        $this->name = $name;
        $this->touch();
    }

    public function getDescription(): string
    {
        return $this->description;
    }

    public function setDescription(string $description): void
    {
        $this->description = $description;
        $this->touch();
    }

    public function getDefinition(): array
    {
        return $this->definition;
    }

    public function setDefinition(array $definition): void
    {
        $this->definition = $definition;
        $this->touch();
    }

    public function getStatus(): string
    {
        return $this->status;
    }

    public function setStatus(string $status): void
    {
        $this->status = $status;
        $this->touch();
    }

    public function getSettings(): array
    {
        return $this->settings;
    }

    public function setSettings(array $settings): void
    {
        $this->settings = $settings;
        $this->touch();
    }

    public function getCreatedAt(): string
    {
        return $this->createdAt;
    }

    public function getUpdatedAt(): string
    {
        return $this->updatedAt;
    }

    public function isActive(): bool
    {
        return $this->status === 'active';
    }

    public function activate(): void
    {
        $this->setStatus('active');
    }

    public function deactivate(): void
    {
        $this->setStatus('inactive');
    }

    public function getTriggerNodes(): array
    {
        $triggers = [];
        
        if (isset($this->definition['nodes'])) {
            foreach ($this->definition['nodes'] as $node) {
                if (($node['type'] ?? '') === 'trigger') {
                    $triggers[] = $node;
                }
            }
        }
        
        return $triggers;
    }

    public function getStartNode(): ?array
    {
        $triggers = $this->getTriggerNodes();
        return $triggers[0] ?? null;
    }

    public function toArray(): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'description' => $this->description,
            'definition' => $this->definition,
            'status' => $this->status,
            'settings' => $this->settings,
            'created_at' => $this->createdAt,
            'updated_at' => $this->updatedAt
        ];
    }

    private function touch(): void
    {
        $this->updatedAt = current_time('mysql');
    }
}