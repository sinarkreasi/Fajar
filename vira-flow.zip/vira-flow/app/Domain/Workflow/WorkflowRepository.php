<?php

namespace VFlow\Domain\Workflow;

/**
 * Workflow Repository
 */
class WorkflowRepository
{
    private string $table;

    public function __construct()
    {
        global $wpdb;
        $this->table = $wpdb->prefix . 'vflow_workflows';
    }

    /**
     * Find workflow by ID
     */
    public function find(int $id): ?Workflow
    {
        global $wpdb;
        
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->table} WHERE id = %d",
            $id
        ), ARRAY_A);
        
        if (!$row) {
            return null;
        }
        
        return $this->mapRowToWorkflow($row);
    }

    /**
     * Find all workflows
     */
    public function findAll(): array
    {
        global $wpdb;
        
        $rows = $wpdb->get_results(
            "SELECT * FROM {$this->table} ORDER BY created_at DESC",
            ARRAY_A
        );
        
        return array_map([$this, 'mapRowToWorkflow'], $rows);
    }

    /**
     * Find workflows by status
     */
    public function findByStatus(string $status): array
    {
        global $wpdb;
        
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->table} WHERE status = %s ORDER BY created_at DESC",
            $status
        ), ARRAY_A);
        
        return array_map([$this, 'mapRowToWorkflow'], $rows);
    }

    /**
     * Find workflows by trigger type
     */
    public function findByTrigger(string $triggerType, array $criteria = []): array
    {
        global $wpdb;
        
        $sql = "SELECT * FROM {$this->table} WHERE status = 'active' AND JSON_EXTRACT(definition, '$.nodes[0].node_type') = %s";
        $params = [$triggerType];
        
        // Add additional criteria if provided
        foreach ($criteria as $key => $value) {
            $sql .= " AND JSON_EXTRACT(definition, '$.nodes[0].config.{$key}') = %s";
            $params[] = $value;
        }
        
        $rows = $wpdb->get_results($wpdb->prepare($sql, ...$params), ARRAY_A);
        
        return array_map([$this, 'mapRowToWorkflow'], $rows);
    }

    /**
     * Find scheduled workflows that are due
     */
    public function findScheduledWorkflows(): array
    {
        global $wpdb;
        
        $now = current_time('mysql');
        
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->table} 
             WHERE status = 'active' 
             AND JSON_EXTRACT(definition, '$.nodes[0].node_type') = 'schedule'
             AND (
                 JSON_EXTRACT(settings, '$.next_run') IS NULL 
                 OR JSON_EXTRACT(settings, '$.next_run') <= %s
             )",
            $now
        ), ARRAY_A);
        
        return array_map([$this, 'mapRowToWorkflow'], $rows);
    }

    /**
     * Save workflow
     */
    public function save(Workflow $workflow): Workflow
    {
        global $wpdb;
        
        $data = [
            'name' => $workflow->getName(),
            'description' => $workflow->getDescription(),
            'definition' => wp_json_encode($workflow->getDefinition()),
            'status' => $workflow->getStatus(),
            'settings' => wp_json_encode($workflow->getSettings()),
            'updated_at' => current_time('mysql')
        ];
        
        if ($workflow->getId()) {
            // Update existing workflow
            $wpdb->update(
                $this->table,
                $data,
                ['id' => $workflow->getId()],
                ['%s', '%s', '%s', '%s', '%s', '%s'],
                ['%d']
            );
        } else {
            // Create new workflow
            $data['created_at'] = current_time('mysql');
            
            $wpdb->insert(
                $this->table,
                $data,
                ['%s', '%s', '%s', '%s', '%s', '%s', '%s']
            );
            
            $workflow->setId($wpdb->insert_id);
        }
        
        return $workflow;
    }

    /**
     * Delete workflow
     */
    public function delete(int $id): bool
    {
        global $wpdb;
        
        $result = $wpdb->delete(
            $this->table,
            ['id' => $id],
            ['%d']
        );
        
        return $result !== false;
    }

    /**
     * Map database row to Workflow object
     */
    private function mapRowToWorkflow(array $row): Workflow
    {
        return new Workflow(
            $row['name'] ?? '',
            $row['description'] ?? '',
            json_decode($row['definition'] ?? '{}', true) ?: [],
            $row['status'] ?? 'draft',
            json_decode($row['settings'] ?? '{}', true) ?: [],
            (int) ($row['id'] ?? 0),
            $row['created_at'] ?? current_time('mysql'),
            $row['updated_at'] ?? current_time('mysql')
        );
    }
}