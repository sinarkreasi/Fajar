<?php

namespace VFlow\Domain\Node;

use VFlow\Domain\Node\Contracts\TriggerInterface;
use VFlow\Domain\Node\Contracts\ActionInterface;
use VFlow\Domain\Node\Contracts\ConditionInterface;

/**
 * Node Registry - manages all available nodes
 */
class NodeRegistry
{
    private array $triggers = [];
    private array $actions = [];
    private array $conditions = [];
    private array $instances = [];

    /**
     * Register a trigger node
     */
    public function registerTrigger(string $id, string $className): void
    {
        $errors = $this->validateNodeClass($className, 'trigger');
        if (!empty($errors)) {
            error_log("Vira Flow: Failed to register trigger '{$id}': " . implode(', ', $errors));
            return;
        }
        
        $this->triggers[$id] = $className;
    }

    /**
     * Register an action node
     */
    public function registerAction(string $id, string $className): void
    {
        $errors = $this->validateNodeClass($className, 'action');
        if (!empty($errors)) {
            error_log("Vira Flow: Failed to register action '{$id}': " . implode(', ', $errors));
            return;
        }
        
        $this->actions[$id] = $className;
    }

    /**
     * Register a condition node
     */
    public function registerCondition(string $id, string $className): void
    {
        $errors = $this->validateNodeClass($className, 'condition');
        if (!empty($errors)) {
            error_log("Vira Flow: Failed to register condition '{$id}': " . implode(', ', $errors));
            return;
        }
        
        $this->conditions[$id] = $className;
    }

    /**
     * Get a node instance by ID
     */
    public function get(string $id): ?object
    {
        if (isset($this->instances[$id])) {
            return $this->instances[$id];
        }

        $className = $this->getClassName($id);
        if (!$className || !class_exists($className)) {
            return null;
        }

        $instance = new $className();
        $this->instances[$id] = $instance;

        return $instance;
    }

    /**
     * Get node class name by ID
     */
    private function getClassName(string $id): ?string
    {
        return $this->triggers[$id] 
            ?? $this->actions[$id] 
            ?? $this->conditions[$id] 
            ?? null;
    }

    /**
     * Get all registered triggers
     */
    public function getTriggers(): array
    {
        return $this->getNodesByType('trigger', $this->triggers);
    }

    /**
     * Get all registered actions
     */
    public function getActions(): array
    {
        return $this->getNodesByType('action', $this->actions);
    }

    /**
     * Get all registered conditions
     */
    public function getConditions(): array
    {
        return $this->getNodesByType('condition', $this->conditions);
    }

    /**
     * Get all nodes
     */
    public function getAllNodes(): array
    {
        return [
            'triggers' => $this->getTriggers(),
            'actions' => $this->getActions(),
            'conditions' => $this->getConditions()
        ];
    }

    /**
     * Get nodes by type with metadata
     */
    private function getNodesByType(string $type, array $nodes): array
    {
        $result = [];

        foreach ($nodes as $id => $className) {
            if (!class_exists($className)) {
                continue;
            }

            $instance = $this->get($id);
            if ($instance) {
                $result[] = $instance->getNodeInfo();
            }
        }

        return $result;
    }

    /**
     * Check if node exists
     */
    public function exists(string $id): bool
    {
        return isset($this->triggers[$id]) 
            || isset($this->actions[$id]) 
            || isset($this->conditions[$id]);
    }

    /**
     * Get node type by ID
     */
    public function getNodeType(string $id): ?string
    {
        if (isset($this->triggers[$id])) {
            return 'trigger';
        }
        
        if (isset($this->actions[$id])) {
            return 'action';
        }
        
        if (isset($this->conditions[$id])) {
            return 'condition';
        }
        
        return null;
    }

    /**
     * Validate node class against formal contract
     */
    private function validateNodeClass(string $className, string $expectedType): array
    {
        $errors = [];

        if (!class_exists($className)) {
            $errors[] = "Class {$className} does not exist";
            return $errors;
        }

        $reflection = new \ReflectionClass($className);

        // Check if it extends AbstractNode
        if (!$reflection->isSubclassOf(AbstractNode::class)) {
            $errors[] = "Class {$className} must extend AbstractNode";
        }

        // Check if it implements the correct interface
        $requiredInterface = match($expectedType) {
            'trigger' => TriggerInterface::class,
            'action' => ActionInterface::class,
            'condition' => ConditionInterface::class,
            default => null
        };

        if ($requiredInterface && !$reflection->implementsInterface($requiredInterface)) {
            $errors[] = "Class {$className} must implement {$requiredInterface}";
        }

        // Validate node instance if class is valid
        if (empty($errors)) {
            try {
                $instance = new $className();
                
                // Validate metadata
                $metaErrors = $instance->validateMeta();
                $errors = array_merge($errors, $metaErrors);
                
                // Validate schema
                $schemaErrors = $instance->validateSchema();
                $errors = array_merge($errors, $schemaErrors);
                
                // Validate type matches expected
                if ($instance->getType() !== $expectedType) {
                    $errors[] = "Node type '{$instance->getType()}' does not match expected '{$expectedType}'";
                }
                
            } catch (\Exception $e) {
                $errors[] = "Failed to instantiate node: " . $e->getMessage();
            }
        }

        return $errors;
    }

    /**
     * Get nodes by category
     */
    public function getNodesByCategory(string $category): array
    {
        $allNodes = $this->getAllNodes();
        $result = [];

        foreach ($allNodes as $type => $nodes) {
            foreach ($nodes as $node) {
                if (($node['category'] ?? 'general') === $category) {
                    $result[] = $node;
                }
            }
        }

        return $result;
    }
}