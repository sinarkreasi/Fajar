<?php

namespace VFlow\Domain\Node;

/**
 * Abstract Node Base Class - Formal Contract Implementation
 */
abstract class AbstractNode
{
    /**
     * Get node metadata (required)
     */
    abstract public function meta(): array;

    /**
     * Get node schema for UI (required)
     */
    abstract public function schema(): array;

    /**
     * Get node type (trigger, action, condition)
     */
    abstract public function getType(): string;

    /**
     * Validate node metadata
     */
    public function validateMeta(): array
    {
        $errors = [];
        $meta = $this->meta();
        
        $required = ['key', 'name', 'description', 'category', 'version'];
        foreach ($required as $field) {
            if (empty($meta[$field])) {
                $errors[] = "Missing required metadata field: {$field}";
            }
        }
        
        // Validate category matches type
        if (!empty($meta['category']) && $meta['category'] !== $this->getType()) {
            $errors[] = "Category '{$meta['category']}' does not match node type '{$this->getType()}'";
        }
        
        // Validate version format
        if (!empty($meta['version']) && !preg_match('/^\d+\.\d+\.\d+$/', $meta['version'])) {
            $errors[] = "Version must be in semver format (e.g., 1.0.0)";
        }
        
        return $errors;
    }

    /**
     * Validate node schema
     */
    public function validateSchema(): array
    {
        $errors = [];
        $schema = $this->schema();
        
        if (!isset($schema['fields']) || !is_array($schema['fields'])) {
            $errors[] = "Schema must contain 'fields' array";
            return $errors;
        }
        
        foreach ($schema['fields'] as $index => $field) {
            if (empty($field['key'])) {
                $errors[] = "Field {$index}: missing 'key'";
            }
            
            if (empty($field['type'])) {
                $errors[] = "Field {$index}: missing 'type'";
            }
            
            if (empty($field['label'])) {
                $errors[] = "Field {$index}: missing 'label'";
            }
        }
        
        return $errors;
    }

    /**
     * Get full node information
     */
    public function getNodeInfo(): array
    {
        return [
            'meta' => $this->meta(),
            'schema' => $this->schema(),
            'type' => $this->getType()
        ];
    }

    /**
     * Validate configuration against schema
     */
    public function validateConfig(array $config): array
    {
        $errors = [];
        $schema = $this->schema();
        
        foreach ($schema['fields'] ?? [] as $field) {
            $key = $field['key'];
            $required = $field['required'] ?? false;
            $type = $field['type'] ?? 'text';
            
            if ($required && (!isset($config[$key]) || $config[$key] === '')) {
                $errors[] = "Field '{$field['label']}' is required";
                continue;
            }
            
            if (!isset($config[$key])) {
                continue;
            }
            
            $value = $config[$key];
            
            // Type validation
            switch ($type) {
                case 'email':
                    if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
                        $errors[] = "Field '{$field['label']}' must be a valid email";
                    }
                    break;
                    
                case 'url':
                    if (!filter_var($value, FILTER_VALIDATE_URL)) {
                        $errors[] = "Field '{$field['label']}' must be a valid URL";
                    }
                    break;
                    
                case 'number':
                    if (!is_numeric($value)) {
                        $errors[] = "Field '{$field['label']}' must be a number";
                    }
                    break;
                    
                case 'select':
                    $options = array_column($field['options'] ?? [], 'value');
                    if (!in_array($value, $options)) {
                        $errors[] = "Field '{$field['label']}' has invalid value";
                    }
                    break;
            }
        }
        
        return $errors;
    }

    /**
     * Sanitize configuration values
     */
    protected function sanitizeConfig(array $config): array
    {
        $sanitized = [];
        $schema = $this->schema();
        
        foreach ($schema['fields'] ?? [] as $field) {
            $key = $field['key'];
            $type = $field['type'] ?? 'text';
            $value = $config[$key] ?? ($field['default'] ?? '');
            
            switch ($type) {
                case 'email':
                    $sanitized[$key] = sanitize_email($value);
                    break;
                case 'url':
                    $sanitized[$key] = esc_url_raw($value);
                    break;
                case 'number':
                    $sanitized[$key] = (float) $value;
                    break;
                case 'boolean':
                    $sanitized[$key] = (bool) $value;
                    break;
                case 'textarea':
                    $sanitized[$key] = sanitize_textarea_field($value);
                    break;
                default:
                    $sanitized[$key] = sanitize_text_field($value);
            }
        }
        
        return $sanitized;
    }
}