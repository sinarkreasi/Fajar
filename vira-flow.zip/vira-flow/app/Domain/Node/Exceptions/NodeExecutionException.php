<?php

namespace VFlow\Domain\Node\Exceptions;

/**
 * Node Execution Exception
 * 
 * Thrown when a node fails to execute properly.
 * This exception type enables proper retry logic and error handling.
 */
class NodeExecutionException extends \Exception
{
    private bool $retryable;
    private array $context;

    public function __construct(
        string $message,
        bool $retryable = true,
        array $context = [],
        int $code = 0,
        ?\Throwable $previous = null
    ) {
        parent::__construct($message, $code, $previous);
        $this->retryable = $retryable;
        $this->context = $context;
    }

    /**
     * Check if this error is retryable
     */
    public function isRetryable(): bool
    {
        return $this->retryable;
    }

    /**
     * Get error context data
     */
    public function getContext(): array
    {
        return $this->context;
    }

    /**
     * Create a non-retryable exception
     */
    public static function nonRetryable(string $message, array $context = []): self
    {
        return new self($message, false, $context);
    }

    /**
     * Create a retryable exception
     */
    public static function retryable(string $message, array $context = []): self
    {
        return new self($message, true, $context);
    }
}