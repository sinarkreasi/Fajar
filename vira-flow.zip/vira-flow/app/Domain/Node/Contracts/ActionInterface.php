<?php

namespace VFlow\Domain\Node\Contracts;

use VFlow\Domain\Execution\ExecutionContext;

/**
 * Action Node Interface - Formal Contract
 */
interface ActionInterface
{
    /**
     * Execute the action with the given context
     * Must return structured data that will be merged into context
     */
    public function execute(ExecutionContext $context): array;
}