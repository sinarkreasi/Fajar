<?php

namespace VFlow\Domain\Node\Contracts;

use VFlow\Domain\Execution\ExecutionContext;

/**
 * Condition Node Interface - Formal Contract
 */
interface ConditionInterface
{
    /**
     * Evaluate the condition and return the result
     * 
     * @return string 'true', 'false', or named branch key
     */
    public function evaluate(ExecutionContext $context): string;
}