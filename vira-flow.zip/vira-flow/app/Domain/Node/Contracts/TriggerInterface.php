<?php

namespace VFlow\Domain\Node\Contracts;

use VFlow\Domain\Execution\ExecutionContext;

/**
 * Trigger Node Interface - Formal Contract
 */
interface TriggerInterface
{
    /**
     * Register the trigger (setup hooks, webhooks, etc.)
     */
    public function register(): void;

    /**
     * Process raw event data into normalized payload
     * This becomes the initial execution context
     */
    public function payload(array $event): array;
}