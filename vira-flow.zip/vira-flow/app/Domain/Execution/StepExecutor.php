<?php

namespace VFlow\Domain\Execution;

use VFlow\Infra\Security\Sandbox;
use VFlow\Support\Logger;

/**
 * Step Executor - executes individual workflow steps
 */
class StepExecutor
{
    private Sandbox $sandbox;
    private Logger $logger;

    public function __construct(Sandbox $sandbox, Logger $logger)
    {
        $this->sandbox = $sandbox;
        $this->logger = $logger;
    }

    /**
     * Execute a workflow step safely
     */
    public function executeStep(callable $step, array $config, ExecutionContext $context): mixed
    {
        try {
            // Execute in sandbox
            return $this->sandbox->execute(function() use ($step, $config, $context) {
                return $step($config, $context);
            });
            
        } catch (\Exception $e) {
            $this->logger->error("Step execution failed", [
                'error' => $e->getMessage(),
                'config' => $config
            ]);
            
            throw $e;
        }
    }

    /**
     * Execute step with timeout
     */
    public function executeStepWithTimeout(
        callable $step,
        array $config,
        ExecutionContext $context,
        int $timeoutSeconds = 30
    ): mixed {
        $startTime = time();
        
        try {
            return $this->executeStep($step, $config, $context);
        } finally {
            $duration = time() - $startTime;
            
            if ($duration > $timeoutSeconds) {
                $this->logger->warning("Step execution exceeded timeout", [
                    'duration' => $duration,
                    'timeout' => $timeoutSeconds
                ]);
            }
        }
    }

    /**
     * Execute step with retry logic
     */
    public function executeStepWithRetry(
        callable $step,
        array $config,
        ExecutionContext $context,
        int $maxRetries = 3,
        int $delaySeconds = 1
    ): mixed {
        $attempt = 0;
        $lastException = null;
        
        while ($attempt < $maxRetries) {
            try {
                return $this->executeStep($step, $config, $context);
            } catch (\Exception $e) {
                $lastException = $e;
                $attempt++;
                
                if ($attempt < $maxRetries) {
                    $this->logger->warning("Step execution failed, retrying", [
                        'attempt' => $attempt,
                        'max_retries' => $maxRetries,
                        'error' => $e->getMessage()
                    ]);
                    
                    sleep($delaySeconds * $attempt); // Exponential backoff
                }
            }
        }
        
        throw $lastException;
    }

    /**
     * Validate step configuration
     */
    public function validateStepConfig(array $config, array $requiredFields = []): array
    {
        $errors = [];
        
        foreach ($requiredFields as $field) {
            if (!isset($config[$field]) || $config[$field] === '') {
                $errors[] = sprintf(__('Required field "%s" is missing', 'vflow'), $field);
            }
        }
        
        return $errors;
    }
}