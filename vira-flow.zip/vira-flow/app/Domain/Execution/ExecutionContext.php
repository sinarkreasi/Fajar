<?php

namespace VFlow\Domain\Execution;

/**
 * Execution Context - holds data during workflow execution
 */
class ExecutionContext
{
    private array $data;
    private array $nodeResults;

    public function __construct(array $initialData = [])
    {
        $this->data = $initialData;
        $this->nodeResults = [];
    }

    /**
     * Get a value from context
     */
    public function get(string $key, $default = null)
    {
        return $this->data[$key] ?? $default;
    }

    /**
     * Set a value in context
     */
    public function set(string $key, $value): void
    {
        $this->data[$key] = $value;
    }

    /**
     * Check if key exists in context
     */
    public function has(string $key): bool
    {
        return array_key_exists($key, $this->data);
    }

    /**
     * Get all context data
     */
    public function all(): array
    {
        return $this->data;
    }

    /**
     * Set node execution result
     */
    public function setNodeResult(string $nodeId, $result): void
    {
        $this->nodeResults[$nodeId] = $result;
    }

    /**
     * Get node execution result
     */
    public function getNodeResult(string $nodeId, $default = null)
    {
        return $this->nodeResults[$nodeId] ?? $default;
    }

    /**
     * Get all node results
     */
    public function getNodeResults(): array
    {
        return $this->nodeResults;
    }

    /**
     * Resolve variable references in a string
     * Supports: {{variable}}, {{node.result}}, {{node.nodeId.property}}
     */
    public function resolveVariables(string $template): string
    {
        return preg_replace_callback('/\{\{([^}]+)\}\}/', function($matches) {
            $variable = trim($matches[1]);
            
            // Handle node results: node.nodeId or node.nodeId.property
            if (strpos($variable, 'node.') === 0) {
                $parts = explode('.', $variable);
                if (count($parts) >= 2) {
                    $nodeId = $parts[1];
                    $nodeResult = $this->getNodeResult($nodeId);
                    
                    if (count($parts) === 2) {
                        return $this->formatValue($nodeResult);
                    } else {
                        // Navigate to nested property
                        $value = $nodeResult;
                        for ($i = 2; $i < count($parts); $i++) {
                            if (is_array($value) && isset($value[$parts[$i]])) {
                                $value = $value[$parts[$i]];
                            } else {
                                return $matches[0]; // Return original if not found
                            }
                        }
                        return $this->formatValue($value);
                    }
                }
            }
            
            // Handle regular context variables
            $value = $this->get($variable);
            return $this->formatValue($value);
            
        }, $template);
    }

    /**
     * Resolve variables in array values recursively
     */
    public function resolveArrayVariables(array $data): array
    {
        $resolved = [];
        
        foreach ($data as $key => $value) {
            if (is_string($value)) {
                $resolved[$key] = $this->resolveVariables($value);
            } elseif (is_array($value)) {
                $resolved[$key] = $this->resolveArrayVariables($value);
            } else {
                $resolved[$key] = $value;
            }
        }
        
        return $resolved;
    }

    /**
     * Format value for string replacement
     */
    private function formatValue($value): string
    {
        if (is_null($value)) {
            return '';
        }
        
        if (is_bool($value)) {
            return $value ? 'true' : 'false';
        }
        
        if (is_array($value) || is_object($value)) {
            return wp_json_encode($value);
        }
        
        return (string) $value;
    }

    /**
     * Convert context to array
     */
    public function toArray(): array
    {
        return [
            'data' => $this->data,
            'node_results' => $this->nodeResults
        ];
    }

    /**
     * Create context from array
     */
    public static function fromArray(array $data): self
    {
        $context = new self($data['data'] ?? []);
        $context->nodeResults = $data['node_results'] ?? [];
        return $context;
    }
}