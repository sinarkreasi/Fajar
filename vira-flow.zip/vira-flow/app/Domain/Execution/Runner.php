<?php

namespace VFlow\Domain\Execution;

use VFlow\Domain\Node\NodeRegistry;
use VFlow\Support\Logger;

/**
 * Workflow Execution Runner
 */
class Runner
{
    private NodeRegistry $nodeRegistry;
    private Logger $logger;

    public function __construct(NodeRegistry $nodeRegistry, Logger $logger)
    {
        $this->nodeRegistry = $nodeRegistry;
        $this->logger = $logger;
    }

    /**
     * Execute a workflow job
     */
    public function execute(Job $job, array $workflowDefinition): void
    {
        try {
            $job->markAsRunning();
            $this->saveJob($job);
            
            $this->logger->info("Starting job execution", [
                'job_id' => $job->getId(),
                'workflow_id' => $job->getWorkflowId()
            ]);
            
            $context = new ExecutionContext($job->getContext());
            $nodes = $workflowDefinition['nodes'] ?? [];
            $connections = $workflowDefinition['connections'] ?? [];
            
            // Find start node (trigger)
            $startNode = $this->findStartNode($nodes);
            if (!$startNode) {
                throw new \Exception('No trigger node found in workflow');
            }
            
            // Execute workflow from start node
            $this->executeNode($startNode, $nodes, $connections, $context, $job);
            
            // Mark job as completed
            $job->markAsCompleted($context->toArray());
            $this->saveJob($job);
            
            $this->logger->info("Job execution completed", [
                'job_id' => $job->getId(),
                'duration' => $job->getDuration()
            ]);
            
        } catch (\Exception $e) {
            $job->markAsFailed($e->getMessage());
            $this->saveJob($job);
            
            $this->logger->error("Job execution failed", [
                'job_id' => $job->getId(),
                'error' => $e->getMessage()
            ]);
        }
    }

    /**
     * Execute a single node
     */
    private function executeNode(
        array $node,
        array $allNodes,
        array $connections,
        ExecutionContext $context,
        Job $job
    ): void {
        $this->logger->debug("Executing node", [
            'node_id' => $node['id'],
            'node_type' => $node['node_type']
        ]);
        
        // Get node instance
        $nodeInstance = $this->nodeRegistry->get($node['node_type']);
        if (!$nodeInstance) {
            throw new \Exception("Node type not found: {$node['node_type']}");
        }
        
        // Execute node
        $nodeConfig = $node['config'] ?? [];
        $result = $nodeInstance->execute($nodeConfig, $context);
        
        // Store result in context
        $context->setNodeResult($node['id'], $result);
        
        // Save step
        $this->saveStep($job, $node, 'completed', $result);
        
        // Find next nodes
        $nextNodes = $this->findNextNodes($node['id'], $connections, $allNodes);
        
        // Execute next nodes
        foreach ($nextNodes as $nextNode) {
            // Check if it's a condition node
            if ($nextNode['type'] === 'condition') {
                $conditionResult = $this->evaluateCondition($nextNode, $context);
                if (!$conditionResult) {
                    continue; // Skip this branch
                }
            }
            
            $this->executeNode($nextNode, $allNodes, $connections, $context, $job);
        }
    }

    /**
     * Find start node (trigger)
     */
    private function findStartNode(array $nodes): ?array
    {
        foreach ($nodes as $node) {
            if (($node['type'] ?? '') === 'trigger') {
                return $node;
            }
        }
        return null;
    }

    /**
     * Find next nodes in the workflow
     */
    private function findNextNodes(string $nodeId, array $connections, array $allNodes): array
    {
        $nextNodeIds = [];
        
        foreach ($connections as $connection) {
            if ($connection['source'] === $nodeId) {
                $nextNodeIds[] = $connection['target'];
            }
        }
        
        $nextNodes = [];
        foreach ($allNodes as $node) {
            if (in_array($node['id'], $nextNodeIds)) {
                $nextNodes[] = $node;
            }
        }
        
        return $nextNodes;
    }

    /**
     * Evaluate condition node
     */
    private function evaluateCondition(array $node, ExecutionContext $context): bool
    {
        $nodeInstance = $this->nodeRegistry->get($node['node_type']);
        if (!$nodeInstance) {
            return false;
        }
        
        $nodeConfig = $node['config'] ?? [];
        return $nodeInstance->evaluate($nodeConfig, $context);
    }

    /**
     * Save job to database
     */
    private function saveJob(Job $job): void
    {
        global $wpdb;
        
        $table = $wpdb->prefix . 'vflow_jobs';
        
        $data = [
            'workflow_id' => $job->getWorkflowId(),
            'status' => $job->getStatus(),
            'context' => wp_json_encode($job->getContext()),
            'result' => wp_json_encode($job->getResult()),
            'error' => $job->getError(),
            'updated_at' => current_time('mysql'),
            'started_at' => $job->getStartedAt(),
            'completed_at' => $job->getCompletedAt()
        ];
        
        if ($job->getId()) {
            $wpdb->update($table, $data, ['id' => $job->getId()]);
        } else {
            $data['created_at'] = current_time('mysql');
            $wpdb->insert($table, $data);
            $job->setId($wpdb->insert_id);
        }
    }

    /**
     * Save execution step
     */
    private function saveStep(Job $job, array $node, string $status, $result): void
    {
        global $wpdb;
        
        $table = $wpdb->prefix . 'vflow_job_steps';
        
        $wpdb->insert($table, [
            'job_id' => $job->getId(),
            'node_id' => $node['id'],
            'node_type' => $node['node_type'],
            'status' => $status,
            'result' => wp_json_encode($result),
            'created_at' => current_time('mysql')
        ]);
    }
}