<?php

namespace VFlow\Domain\Execution;

/**
 * Execution Job Domain Model
 */
class Job
{
    private ?int $id;
    private int $workflowId;
    private string $status;
    private array $context;
    private array $result;
    private ?string $error;
    private string $createdAt;
    private string $updatedAt;
    private ?string $startedAt;
    private ?string $completedAt;

    public function __construct(
        int $workflowId,
        array $context = [],
        string $status = 'pending',
        array $result = [],
        ?string $error = null,
        ?int $id = null,
        ?string $createdAt = null,
        ?string $updatedAt = null,
        ?string $startedAt = null,
        ?string $completedAt = null
    ) {
        $this->id = $id;
        $this->workflowId = $workflowId;
        $this->status = $status;
        $this->context = $context;
        $this->result = $result;
        $this->error = $error;
        $this->createdAt = $createdAt ?? current_time('mysql');
        $this->updatedAt = $updatedAt ?? current_time('mysql');
        $this->startedAt = $startedAt;
        $this->completedAt = $completedAt;
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function setId(int $id): void
    {
        $this->id = $id;
    }

    public function getWorkflowId(): int
    {
        return $this->workflowId;
    }

    public function getStatus(): string
    {
        return $this->status;
    }

    public function setStatus(string $status): void
    {
        $this->status = $status;
        $this->touch();
        
        if ($status === 'running' && !$this->startedAt) {
            $this->startedAt = current_time('mysql');
        }
        
        if (in_array($status, ['completed', 'failed']) && !$this->completedAt) {
            $this->completedAt = current_time('mysql');
        }
    }

    public function getContext(): array
    {
        return $this->context;
    }

    public function setContext(array $context): void
    {
        $this->context = $context;
        $this->touch();
    }

    public function getResult(): array
    {
        return $this->result;
    }

    public function setResult(array $result): void
    {
        $this->result = $result;
        $this->touch();
    }

    public function getError(): ?string
    {
        return $this->error;
    }

    public function setError(?string $error): void
    {
        $this->error = $error;
        $this->touch();
    }

    public function getCreatedAt(): string
    {
        return $this->createdAt;
    }

    public function getUpdatedAt(): string
    {
        return $this->updatedAt;
    }

    public function getStartedAt(): ?string
    {
        return $this->startedAt;
    }

    public function getCompletedAt(): ?string
    {
        return $this->completedAt;
    }

    public function isPending(): bool
    {
        return $this->status === 'pending';
    }

    public function isRunning(): bool
    {
        return $this->status === 'running';
    }

    public function isCompleted(): bool
    {
        return $this->status === 'completed';
    }

    public function isFailed(): bool
    {
        return $this->status === 'failed';
    }

    public function markAsRunning(): void
    {
        $this->setStatus('running');
    }

    public function markAsCompleted(array $result = []): void
    {
        $this->setResult($result);
        $this->setStatus('completed');
    }

    public function markAsFailed(string $error): void
    {
        $this->setError($error);
        $this->setStatus('failed');
    }

    public function getDuration(): ?int
    {
        if (!$this->startedAt || !$this->completedAt) {
            return null;
        }
        
        $start = strtotime($this->startedAt);
        $end = strtotime($this->completedAt);
        
        return $end - $start;
    }

    public function toArray(): array
    {
        return [
            'id' => $this->id,
            'workflow_id' => $this->workflowId,
            'status' => $this->status,
            'context' => $this->context,
            'result' => $this->result,
            'error' => $this->error,
            'created_at' => $this->createdAt,
            'updated_at' => $this->updatedAt,
            'started_at' => $this->startedAt,
            'completed_at' => $this->completedAt,
            'duration' => $this->getDuration()
        ];
    }

    private function touch(): void
    {
        $this->updatedAt = current_time('mysql');
    }
}