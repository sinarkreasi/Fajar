<?php

namespace VFlow\Nodes\Actions;

use VFlow\Domain\Node\AbstractNode;
use VFlow\Domain\Node\Contracts\ActionInterface;
use VFlow\Domain\Execution\ExecutionContext;
use VFlow\Domain\Node\Exceptions\NodeExecutionException;

/**
 * Email Action - Formal Contract Implementation
 */
class EmailAction extends AbstractNode implements ActionInterface
{
    public function getType(): string
    {
        return 'action';
    }

    public function meta(): array
    {
        return [
            'key' => 'core.email',
            'name' => 'Send Email',
            'description' => 'Send emails using WordPress mail functions',
            'category' => 'action',
            'icon' => 'email',
            'color' => '#10b981',
            'version' => '1.0.0'
        ];
    }

    public function schema(): array
    {
        return [
            'fields' => [
                [
                    'key' => 'to',
                    'type' => 'email',
                    'label' => 'To Email',
                    'required' => true,
                    'placeholder' => 'user@example.com',
                    'description' => 'Recipient email address (supports variables)'
                ],
                [
                    'key' => 'subject',
                    'type' => 'text',
                    'label' => 'Subject',
                    'required' => true,
                    'placeholder' => 'Your order has been processed',
                    'description' => 'Email subject line (supports variables)'
                ],
                [
                    'key' => 'message',
                    'type' => 'textarea',
                    'label' => 'Message',
                    'required' => true,
                    'placeholder' => 'Hello {{customer_name}}, your order #{{order_id}} has been processed.',
                    'description' => 'Email message content (supports variables and HTML)'
                ],
                [
                    'key' => 'from_name',
                    'type' => 'text',
                    'label' => 'From Name',
                    'required' => false,
                    'placeholder' => 'Your Store Name',
                    'description' => 'Sender name (optional)'
                ],
                [
                    'key' => 'from_email',
                    'type' => 'email',
                    'label' => 'From Email',
                    'required' => false,
                    'placeholder' => 'noreply@yourstore.com',
                    'description' => 'Sender email address (optional)'
                ]
            ]
        ];
    }

    public function execute(ExecutionContext $context): array
    {
        $config = $this->sanitizeConfig($context->get('node_config', []));
        
        // Validate required fields
        $errors = $this->validateConfig($config);
        if (!empty($errors)) {
            throw NodeExecutionException::nonRetryable(
                'Email configuration validation failed: ' . implode(', ', $errors),
                ['config' => $config]
            );
        }
        
        $to = $context->resolveVariables($config['to']);
        $subject = $context->resolveVariables($config['subject']);
        $message = $context->resolveVariables($config['message']);
        
        $headers = ['Content-Type: text/html; charset=UTF-8'];
        
        // Set custom from name/email if provided
        if (!empty($config['from_name']) || !empty($config['from_email'])) {
            $from_name = $context->resolveVariables($config['from_name'] ?? get_bloginfo('name'));
            $from_email = $context->resolveVariables($config['from_email'] ?? get_option('admin_email'));
            $headers[] = "From: {$from_name} <{$from_email}>";
        }
        
        // Send email
        $sent = wp_mail($to, $subject, $message, $headers);
        
        if (!$sent) {
            throw NodeExecutionException::retryable(
                'Failed to send email',
                ['to' => $to, 'subject' => $subject]
            );
        }
        
        return [
            'email_sent' => true,
            'email_to' => $to,
            'email_subject' => $subject,
            'email_sent_at' => current_time('mysql')
        ];
    }
}