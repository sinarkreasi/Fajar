<?php

namespace VFlow\Nodes\Actions;

use VFlow\Domain\Node\AbstractNode;
use VFlow\Domain\Node\Contracts\ActionInterface;
use VFlow\Domain\Execution\ExecutionContext;
use VFlow\Domain\Node\Exceptions\NodeExecutionException;

/**
 * HTTP Request Action - Formal Contract Implementation
 */
class HttpRequestAction extends AbstractNode implements ActionInterface
{
    public function getType(): string
    {
        return 'action';
    }

    public function meta(): array
    {
        return [
            'key' => 'core.http_request',
            'name' => 'HTTP Request',
            'description' => 'Make HTTP requests to external APIs',
            'category' => 'action',
            'icon' => 'cloud',
            'color' => '#10b981',
            'version' => '1.0.0'
        ];
    }

    public function schema(): array
    {
        return [
            'fields' => [
                [
                    'key' => 'url',
                    'type' => 'url',
                    'label' => 'URL',
                    'required' => true,
                    'placeholder' => 'https://api.example.com/endpoint',
                    'description' => 'The URL to send the request to'
                ],
                [
                    'key' => 'method',
                    'type' => 'select',
                    'label' => 'HTTP Method',
                    'required' => true,
                    'default' => 'GET',
                    'options' => [
                        ['value' => 'GET', 'label' => 'GET'],
                        ['value' => 'POST', 'label' => 'POST'],
                        ['value' => 'PUT', 'label' => 'PUT'],
                        ['value' => 'DELETE', 'label' => 'DELETE']
                    ]
                ],
                [
                    'key' => 'headers',
                    'type' => 'textarea',
                    'label' => 'Headers (JSON)',
                    'required' => false,
                    'placeholder' => '{"Authorization": "Bearer token"}',
                    'description' => 'HTTP headers as JSON object'
                ],
                [
                    'key' => 'body',
                    'type' => 'textarea',
                    'label' => 'Request Body (JSON)',
                    'required' => false,
                    'placeholder' => '{"key": "value"}',
                    'description' => 'Request body as JSON (for POST/PUT)'
                ],
                [
                    'key' => 'timeout',
                    'type' => 'number',
                    'label' => 'Timeout (seconds)',
                    'required' => false,
                    'default' => 30,
                    'description' => 'Request timeout in seconds'
                ]
            ]
        ];
    }

    public function execute(ExecutionContext $context): array
    {
        $config = $this->sanitizeConfig($context->get('node_config', []));
        
        // Validate required fields
        $errors = $this->validateConfig($config);
        if (!empty($errors)) {
            throw NodeExecutionException::nonRetryable(
                'Configuration validation failed: ' . implode(', ', $errors),
                ['config' => $config]
            );
        }
        
        $url = $context->resolveVariables($config['url']);
        $method = $config['method'] ?? 'GET';
        $timeout = (int) ($config['timeout'] ?? 30);
        
        $args = [
            'method' => $method,
            'timeout' => $timeout,
            'headers' => []
        ];
        
        // Add headers
        if (!empty($config['headers'])) {
            $headers = json_decode($context->resolveVariables($config['headers']), true);
            if ($headers && is_array($headers)) {
                $args['headers'] = $headers;
            }
        }
        
        // Add body for POST/PUT
        if (in_array($method, ['POST', 'PUT']) && !empty($config['body'])) {
            $body = $context->resolveVariables($config['body']);
            $args['body'] = $body;
            $args['headers']['Content-Type'] = 'application/json';
        }
        
        // Make request
        $response = wp_remote_request($url, $args);
        
        if (is_wp_error($response)) {
            throw NodeExecutionException::retryable(
                'HTTP request failed: ' . $response->get_error_message(),
                ['url' => $url, 'method' => $method]
            );
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        $response_headers = wp_remote_retrieve_headers($response)->getAll();
        
        // Parse JSON response if possible
        $parsed_body = json_decode($response_body, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            $parsed_body = $response_body;
        }
        
        $success = $status_code >= 200 && $status_code < 300;
        
        if (!$success) {
            throw NodeExecutionException::retryable(
                "HTTP request returned status {$status_code}",
                [
                    'status_code' => $status_code,
                    'response_body' => $response_body,
                    'url' => $url
                ]
            );
        }
        
        return [
            'http_status_code' => $status_code,
            'http_response_body' => $parsed_body,
            'http_response_headers' => $response_headers,
            'http_success' => $success,
            'http_url' => $url,
            'http_method' => $method
        ];
    }
}