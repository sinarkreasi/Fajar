<?php

namespace VFlow\Nodes\Triggers;

use VFlow\Domain\Node\AbstractNode;
use VFlow\Domain\Node\Contracts\TriggerInterface;

/**
 * Schedule Trigger - Formal Contract Implementation
 */
class ScheduleTrigger extends AbstractNode implements TriggerInterface
{
    public function getType(): string
    {
        return 'trigger';
    }

    public function meta(): array
    {
        return [
            'key' => 'core.schedule',
            'name' => 'Schedule Trigger',
            'description' => 'Triggered at specific times or intervals',
            'category' => 'trigger',
            'icon' => 'clock',
            'color' => '#3b82f6',
            'version' => '1.0.0'
        ];
    }

    public function schema(): array
    {
        return [
            'fields' => [
                [
                    'key' => 'schedule_type',
                    'type' => 'select',
                    'label' => 'Schedule Type',
                    'required' => true,
                    'default' => 'hourly',
                    'options' => [
                        ['value' => 'hourly', 'label' => 'Every Hour'],
                        ['value' => 'daily', 'label' => 'Daily'],
                        ['value' => 'weekly', 'label' => 'Weekly'],
                        ['value' => 'monthly', 'label' => 'Monthly']
                    ]
                ],
                [
                    'key' => 'time',
                    'type' => 'text',
                    'label' => 'Time (HH:MM)',
                    'required' => false,
                    'placeholder' => '09:00',
                    'description' => 'Time of day for daily/weekly/monthly schedules'
                ]
            ]
        ];
    }

    public function register(): void
    {
        // Schedule triggers are registered via WordPress cron
        // This would be handled by the workflow engine
    }

    public function payload(array $event): array
    {
        return [
            'schedule_type' => $event['schedule_type'] ?? 'manual',
            'scheduled_time' => $event['scheduled_time'] ?? current_time('mysql'),
            'actual_time' => current_time('mysql'),
            'trigger_source' => 'schedule'
        ];
    }
}