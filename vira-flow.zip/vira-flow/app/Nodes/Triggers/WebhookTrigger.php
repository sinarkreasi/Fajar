<?php

namespace VFlow\Nodes\Triggers;

use VFlow\Domain\Node\AbstractNode;
use VFlow\Domain\Node\Contracts\TriggerInterface;

/**
 * Webhook Trigger - Formal Contract Implementation
 */
class WebhookTrigger extends AbstractNode implements TriggerInterface
{
    public function getType(): string
    {
        return 'trigger';
    }

    public function meta(): array
    {
        return [
            'key' => 'core.webhook',
            'name' => 'Webhook Trigger',
            'description' => 'Triggered when a webhook URL is called',
            'category' => 'trigger',
            'icon' => 'admin-links',
            'color' => '#3b82f6',
            'version' => '1.0.0'
        ];
    }

    public function schema(): array
    {
        return [
            'fields' => [
                [
                    'key' => 'webhook_id',
                    'type' => 'text',
                    'label' => 'Webhook ID',
                    'required' => true,
                    'placeholder' => 'my-webhook-id',
                    'description' => 'Unique identifier for this webhook'
                ],
                [
                    'key' => 'method',
                    'type' => 'select',
                    'label' => 'HTTP Method',
                    'required' => false,
                    'default' => 'POST',
                    'options' => [
                        ['value' => 'GET', 'label' => 'GET'],
                        ['value' => 'POST', 'label' => 'POST'],
                        ['value' => 'PUT', 'label' => 'PUT'],
                        ['value' => 'DELETE', 'label' => 'DELETE']
                    ]
                ]
            ]
        ];
    }

    public function register(): void
    {
        // Webhooks are automatically registered via REST API
        // URL: /wp-json/vflow/v1/webhook/{webhook_id}
        // No additional registration needed
    }

    public function payload(array $event): array
    {
        // Normalize webhook event data
        return [
            'webhook_id' => $event['webhook_id'] ?? '',
            'method' => $event['method'] ?? 'POST',
            'headers' => $event['headers'] ?? [],
            'body' => $event['body'] ?? [],
            'query' => $event['query'] ?? [],
            'received_at' => $event['received_at'] ?? current_time('mysql'),
            'ip_address' => $event['ip_address'] ?? $_SERVER['REMOTE_ADDR'] ?? '',
            'user_agent' => $event['user_agent'] ?? $_SERVER['HTTP_USER_AGENT'] ?? ''
        ];
    }
}