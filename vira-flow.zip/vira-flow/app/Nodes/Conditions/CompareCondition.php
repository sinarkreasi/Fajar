<?php

namespace VFlow\Nodes\Conditions;

use VFlow\Domain\Node\AbstractNode;
use VFlow\Domain\Node\Contracts\ConditionInterface;
use VFlow\Domain\Execution\ExecutionContext;

/**
 * Compare Condition - Formal Contract Implementation
 */
class CompareCondition extends AbstractNode implements ConditionInterface
{
    public function getType(): string
    {
        return 'condition';
    }

    public function meta(): array
    {
        return [
            'key' => 'core.compare',
            'name' => 'Compare Values',
            'description' => 'Compare two values with various operators',
            'category' => 'condition',
            'icon' => 'admin-generic',
            'color' => '#8b5cf6',
            'version' => '1.0.0'
        ];
    }

    public function schema(): array
    {
        return [
            'fields' => [
                [
                    'key' => 'value1',
                    'type' => 'text',
                    'label' => 'First Value',
                    'required' => true,
                    'placeholder' => '{{order_total}}',
                    'description' => 'First value to compare (supports variables)'
                ],
                [
                    'key' => 'operator',
                    'type' => 'select',
                    'label' => 'Operator',
                    'required' => true,
                    'default' => 'equals',
                    'options' => [
                        ['value' => 'equals', 'label' => 'Equals (=)'],
                        ['value' => 'not_equals', 'label' => 'Not Equals (≠)'],
                        ['value' => 'greater_than', 'label' => 'Greater Than (>)'],
                        ['value' => 'greater_than_or_equal', 'label' => 'Greater Than or Equal (≥)'],
                        ['value' => 'less_than', 'label' => 'Less Than (<)'],
                        ['value' => 'less_than_or_equal', 'label' => 'Less Than or Equal (≤)'],
                        ['value' => 'contains', 'label' => 'Contains'],
                        ['value' => 'not_contains', 'label' => 'Does Not Contain'],
                        ['value' => 'starts_with', 'label' => 'Starts With'],
                        ['value' => 'ends_with', 'label' => 'Ends With']
                    ]
                ],
                [
                    'key' => 'value2',
                    'type' => 'text',
                    'label' => 'Second Value',
                    'required' => true,
                    'placeholder' => '100',
                    'description' => 'Second value to compare (supports variables)'
                ]
            ]
        ];
    }

    public function evaluate(ExecutionContext $context): string
    {
        $config = $this->sanitizeConfig($context->get('node_config', []));
        
        $value1 = $context->resolveVariables($config['value1']);
        $value2 = $context->resolveVariables($config['value2']);
        $operator = $config['operator'] ?? 'equals';
        
        $result = $this->compareValues($value1, $value2, $operator);
        
        return $result ? 'true' : 'false';
    }

    private function compareValues($value1, $value2, string $operator): bool
    {
        switch ($operator) {
            case 'equals':
                return $value1 == $value2;
                
            case 'not_equals':
                return $value1 != $value2;
                
            case 'greater_than':
                return is_numeric($value1) && is_numeric($value2) && (float)$value1 > (float)$value2;
                
            case 'greater_than_or_equal':
                return is_numeric($value1) && is_numeric($value2) && (float)$value1 >= (float)$value2;
                
            case 'less_than':
                return is_numeric($value1) && is_numeric($value2) && (float)$value1 < (float)$value2;
                
            case 'less_than_or_equal':
                return is_numeric($value1) && is_numeric($value2) && (float)$value1 <= (float)$value2;
                
            case 'contains':
                return is_string($value1) && is_string($value2) && strpos($value1, $value2) !== false;
                
            case 'not_contains':
                return is_string($value1) && is_string($value2) && strpos($value1, $value2) === false;
                
            case 'starts_with':
                return is_string($value1) && is_string($value2) && strpos($value1, $value2) === 0;
                
            case 'ends_with':
                return is_string($value1) && is_string($value2) && substr($value1, -strlen($value2)) === $value2;
                
            default:
                return false;
        }
    }
}