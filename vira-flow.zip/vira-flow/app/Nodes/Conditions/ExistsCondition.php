<?php

namespace VFlow\Nodes\Conditions;

use VFlow\Domain\Node\AbstractNode;
use VFlow\Domain\Node\Contracts\ConditionInterface;
use VFlow\Domain\Execution\ExecutionContext;

/**
 * Exists Condition - Formal Contract Implementation
 */
class ExistsCondition extends AbstractNode implements ConditionInterface
{
    public function getType(): string
    {
        return 'condition';
    }

    public function meta(): array
    {
        return [
            'key' => 'core.exists',
            'name' => 'Value Exists',
            'description' => 'Check if a value exists or is empty',
            'category' => 'condition',
            'icon' => 'admin-generic',
            'color' => '#8b5cf6',
            'version' => '1.0.0'
        ];
    }

    public function schema(): array
    {
        return [
            'fields' => [
                [
                    'key' => 'value',
                    'type' => 'text',
                    'label' => 'Value to Check',
                    'required' => true,
                    'placeholder' => '{{customer_email}}',
                    'description' => 'Value to check for existence (supports variables)'
                ],
                [
                    'key' => 'check_type',
                    'type' => 'select',
                    'label' => 'Check Type',
                    'required' => true,
                    'default' => 'exists',
                    'options' => [
                        ['value' => 'exists', 'label' => 'Value Exists (not empty)'],
                        ['value' => 'not_exists', 'label' => 'Value Does Not Exist (empty)'],
                        ['value' => 'is_null', 'label' => 'Value is Null'],
                        ['value' => 'is_not_null', 'label' => 'Value is Not Null']
                    ]
                ]
            ]
        ];
    }

    public function evaluate(ExecutionContext $context): string
    {
        $config = $this->sanitizeConfig($context->get('node_config', []));
        
        $value = $context->resolveVariables($config['value']);
        $checkType = $config['check_type'] ?? 'exists';
        
        $result = $this->checkValue($value, $checkType);
        
        return $result ? 'true' : 'false';
    }

    private function checkValue($value, string $checkType): bool
    {
        switch ($checkType) {
            case 'exists':
                return !empty($value);
                
            case 'not_exists':
                return empty($value);
                
            case 'is_null':
                return is_null($value);
                
            case 'is_not_null':
                return !is_null($value);
                
            default:
                return false;
        }
    }
}