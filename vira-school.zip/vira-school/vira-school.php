<?php
/**
 * Plugin Name: Vira School
 * Plugin URI: https://viraloka.com/pro/vira-school
 * Description: School management system with teacher & student management, course management, attendance tracking, and more.
 * Version: 1.0.0
 * Author: Viraloka
 * Author URI: https://viraloka.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: vira-school
 * Domain Path: /languages
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('VIRA_SCHOOL_VERSION', '1.0.0');
define('VIRA_SCHOOL_PLUGIN_URL', plugin_dir_url(__FILE__));
define('VIRA_SCHOOL_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('VIRA_SCHOOL_PLUGIN_FILE', __FILE__);

require_once VIRA_SCHOOL_PLUGIN_PATH . 'includes/main.php';

// Initialize the plugin
new ViraSchoolPlugin();