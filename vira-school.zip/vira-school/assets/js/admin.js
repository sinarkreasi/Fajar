jQuery(document).ready(function($) {
    'use strict';
    
    // Delete student functionality
    $('.delete-student').on('click', function(e) {
        e.preventDefault();
        
        if (!confirm('Are you sure you want to delete this student?')) {
            return;
        }
        
        var studentId = $(this).data('id');
        var row = $(this).closest('tr');
        
        // Add loading state
        row.addClass('vira-school-loading');
        
        $.ajax({
            url: vira_school_admin_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'vira_school_delete_student',
                student_id: studentId,
                nonce: vira_school_admin_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    row.fadeOut(300, function() {
                        $(this).remove();
                    });
                    
                    // Show success message
                    showNotice(response.data.message, 'success');
                } else {
                    row.removeClass('vira-school-loading');
                    showNotice(response.data.message, 'error');
                }
            },
            error: function() {
                row.removeClass('vira-school-loading');
                showNotice('Error deleting student. Please try again.', 'error');
            }
        });
    });
    
    // Edit student functionality
    $('.edit-student').on('click', function(e) {
        e.preventDefault();
        var studentId = $(this).data('id');
        
        // TODO: Implement edit functionality in a future update
        alert('Edit functionality will be implemented in a future update.');
    });
    
    // Add student functionality
    $('.student-form').on('submit', function(e) {
        e.preventDefault();
        
        var form = $(this);
        var formData = form.serialize();
        
        // Add loading state to submit button
        var submitButton = form.find('input[type="submit"]');
        var originalText = submitButton.val();
        submitButton.val('Adding...').prop('disabled', true);
        
        $.ajax({
            url: vira_school_admin_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'vira_school_add_student',
                nonce: vira_school_admin_ajax.nonce,
                student_id: form.find('input[name="student_id"]').val(),
                first_name: form.find('input[name="first_name"]').val(),
                last_name: form.find('input[name="last_name"]').val(),
                email: form.find('input[name="email"]').val(),
                phone: form.find('input[name="phone"]').val(),
                date_of_birth: form.find('input[name="date_of_birth"]').val()
            },
            success: function(response) {
                if (response.success) {
                    // Reset form
                    form[0].reset();
                    
                    // Show success message
                    showNotice(response.data.message, 'success');
                    
                    // Reload page to show new student
                    location.reload();
                } else {
                    showNotice(response.data.message, 'error');
                }
            },
            error: function() {
                showNotice('Error adding student. Please try again.', 'error');
            },
            complete: function() {
                // Restore submit button
                submitButton.val(originalText).prop('disabled', false);
            }
        });
    });
    
    // Delete teacher functionality
    $('.delete-teacher').on('click', function(e) {
        e.preventDefault();
        
        if (!confirm('Are you sure you want to delete this teacher?')) {
            return;
        }
        
        var teacherId = $(this).data('id');
        var row = $(this).closest('tr');
        
        // Add loading state
        row.addClass('vira-school-loading');
        
        $.ajax({
            url: vira_school_admin_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'vira_school_delete_teacher',
                teacher_id: teacherId,
                nonce: vira_school_admin_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    row.fadeOut(300, function() {
                        $(this).remove();
                    });
                    
                    // Show success message
                    showNotice(response.data.message, 'success');
                } else {
                    row.removeClass('vira-school-loading');
                    showNotice(response.data.message, 'error');
                }
            },
            error: function() {
                row.removeClass('vira-school-loading');
                showNotice('Error deleting teacher. Please try again.', 'error');
            }
        });
    });
    
    // Edit teacher functionality
    $('.edit-teacher').on('click', function(e) {
        e.preventDefault();
        var teacherId = $(this).data('id');
        
        // TODO: Implement edit functionality in a future update
        alert('Edit functionality will be implemented in a future update.');
    });
    
    // Add teacher functionality
    $('.teacher-form').on('submit', function(e) {
        e.preventDefault();
        
        var form = $(this);
        var formData = form.serialize();
        
        // Add loading state to submit button
        var submitButton = form.find('input[type="submit"]');
        var originalText = submitButton.val();
        submitButton.val('Adding...').prop('disabled', true);
        
        $.ajax({
            url: vira_school_admin_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'vira_school_add_teacher',
                nonce: vira_school_admin_ajax.nonce,
                teacher_id: form.find('input[name="teacher_id"]').val(),
                first_name: form.find('input[name="first_name"]').val(),
                last_name: form.find('input[name="last_name"]').val(),
                email: form.find('input[name="email"]').val(),
                phone: form.find('input[name="phone"]').val(),
                department: form.find('input[name="department"]').val(),
                qualification: form.find('textarea[name="qualification"]').val(),
                hire_date: form.find('input[name="hire_date"]').val()
            },
            success: function(response) {
                if (response.success) {
                    // Reset form
                    form[0].reset();
                    
                    // Show success message
                    showNotice(response.data.message, 'success');
                    
                    // Reload page to show new teacher
                    location.reload();
                } else {
                    showNotice(response.data.message, 'error');
                }
            },
            error: function() {
                showNotice('Error adding teacher. Please try again.', 'error');
            },
            complete: function() {
                // Restore submit button
                submitButton.val(originalText).prop('disabled', false);
            }
        });
    });
    
    // Delete course functionality
    $('.delete-course').on('click', function(e) {
        e.preventDefault();
        
        if (!confirm('Are you sure you want to delete this course?')) {
            return;
        }
        
        var courseId = $(this).data('id');
        var row = $(this).closest('tr');
        
        // Add loading state
        row.addClass('vira-school-loading');
        
        $.ajax({
            url: vira_school_admin_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'vira_school_delete_course',
                course_id: courseId,
                nonce: vira_school_admin_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    row.fadeOut(300, function() {
                        $(this).remove();
                    });
                    
                    // Show success message
                    showNotice(response.data.message, 'success');
                } else {
                    row.removeClass('vira-school-loading');
                    showNotice(response.data.message, 'error');
                }
            },
            error: function() {
                row.removeClass('vira-school-loading');
                showNotice('Error deleting course. Please try again.', 'error');
            }
        });
    });
    
    // Edit course functionality
    $('.edit-course').on('click', function(e) {
        e.preventDefault();
        var courseId = $(this).data('id');
        
        // TODO: Implement edit functionality in a future update
        alert('Edit functionality will be implemented in a future update.');
    });
    
    // Add course functionality
    $('.course-form').on('submit', function(e) {
        e.preventDefault();
        
        var form = $(this);
        var formData = form.serialize();
        
        // Add loading state to submit button
        var submitButton = form.find('input[type="submit"]');
        var originalText = submitButton.val();
        submitButton.val('Adding...').prop('disabled', true);
        
        $.ajax({
            url: vira_school_admin_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'vira_school_add_course',
                nonce: vira_school_admin_ajax.nonce,
                course_name: form.find('input[name="course_name"]').val(),
                course_code: form.find('input[name="course_code"]').val(),
                description: form.find('textarea[name="description"]').val(),
                credits: form.find('input[name="credits"]').val()
            },
            success: function(response) {
                if (response.success) {
                    // Reset form
                    form[0].reset();
                    
                    // Show success message
                    showNotice(response.data.message, 'success');
                    
                    // Reload page to show new course
                    location.reload();
                } else {
                    showNotice(response.data.message, 'error');
                }
            },
            error: function() {
                showNotice('Error adding course. Please try again.', 'error');
            },
            complete: function() {
                // Restore submit button
                submitButton.val(originalText).prop('disabled', false);
            }
        });
    });
    
    // Delete class functionality
    $('.delete-class').on('click', function(e) {
        e.preventDefault();
        
        if (!confirm('Are you sure you want to delete this class?')) {
            return;
        }
        
        var classId = $(this).data('id');
        var row = $(this).closest('tr');
        
        // Add loading state
        row.addClass('vira-school-loading');
        
        $.ajax({
            url: vira_school_admin_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'vira_school_delete_class',
                class_id: classId,
                nonce: vira_school_admin_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    row.fadeOut(300, function() {
                        $(this).remove();
                    });
                    
                    // Show success message
                    showNotice(response.data.message, 'success');
                } else {
                    row.removeClass('vira-school-loading');
                    showNotice(response.data.message, 'error');
                }
            },
            error: function() {
                row.removeClass('vira-school-loading');
                showNotice('Error deleting class. Please try again.', 'error');
            }
        });
    });
    
    // Edit class functionality
    $('.edit-class').on('click', function(e) {
        e.preventDefault();
        var classId = $(this).data('id');
        
        // TODO: Implement edit functionality in a future update
        alert('Edit functionality will be implemented in a future update.');
    });
    
    // Add class functionality
    $('.class-form').on('submit', function(e) {
        e.preventDefault();
        
        var form = $(this);
        var formData = form.serialize();
        
        // Add loading state to submit button
        var submitButton = form.find('input[type="submit"]');
        var originalText = submitButton.val();
        submitButton.val('Adding...').prop('disabled', true);
        
        $.ajax({
            url: vira_school_admin_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'vira_school_add_class',
                nonce: vira_school_admin_ajax.nonce,
                class_name: form.find('input[name="class_name"]').val(),
                class_code: form.find('input[name="class_code"]').val(),
                description: form.find('textarea[name="description"]').val(),
                teacher_id: form.find('select[name="teacher_id"]').val(),
                max_students: form.find('input[name="max_students"]').val(),
                academic_year: form.find('input[name="academic_year"]').val()
            },
            success: function(response) {
                if (response.success) {
                    // Reset form
                    form[0].reset();
                    
                    // Show success message
                    showNotice(response.data.message, 'success');
                    
                    // Reload page to show new class
                    location.reload();
                } else {
                    showNotice(response.data.message, 'error');
                }
            },
            error: function() {
                showNotice('Error adding class. Please try again.', 'error');
            },
            complete: function() {
                // Restore submit button
                submitButton.val(originalText).prop('disabled', false);
            }
        });
    });
    
    // Form validation
    $('.student-form, .teacher-form, .course-form, .class-form').on('submit', function(e) {
        var form = $(this);
        var requiredFields = form.find('[required]');
        var isValid = true;
        
        requiredFields.each(function() {
            if (!$(this).val().trim()) {
                $(this).addClass('error');
                isValid = false;
            } else {
                $(this).removeClass('error');
            }
        });
        
        if (!isValid) {
            e.preventDefault();
            showNotice('Please fill in all required fields.', 'error');
            
            // Focus on first error field
            form.find('.error').first().focus();
        }
    });
    
    // Remove error class on input
    $('.student-form input, .teacher-form input, .course-form input, .class-form input, .class-form select').on('input', function() {
        $(this).removeClass('error');
    });
    
    // Show notice function
    function showNotice(message, type) {
        var noticeClass = type === 'success' ? 'notice-success' : 'notice-error';
        var notice = $('<div class="notice ' + noticeClass + ' vira-school-notice is-dismissible"><p>' + message + '</p></div>');
        
        $('.wrap h1').after(notice);
        
        // Auto-hide after 5 seconds
        setTimeout(function() {
            notice.fadeOut();
        }, 5000);
        
        // Make notice dismissible
        notice.on('click', '.notice-dismiss', function() {
            notice.fadeOut();
        });
    }
    
    // Dashboard stats animation
    if ($('.dashboard-stats').length) {
        $('.stat-box h3').each(function() {
            var $this = $(this);
            var countTo = parseInt($this.text());
            
            $({ countNum: 0 }).animate({
                countNum: countTo
            }, {
                duration: 1000,
                easing: 'swing',
                step: function() {
                    $this.text(Math.floor(this.countNum));
                },
                complete: function() {
                    $this.text(this.countNum);
                }
            });
        });
    }
    
    // Search functionality (if implemented)
    $('#student-search').on('keyup', function() {
        var value = $(this).val().toLowerCase();
        $('table tbody tr').filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
        });
    });
});