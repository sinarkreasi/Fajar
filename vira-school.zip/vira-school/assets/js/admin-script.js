/**
 * Vira School Admin JavaScript
 */

(function($) {
    'use strict';

    // Initialize when document is ready
    $(document).ready(function() {
        initializeViraSchool();
    });

    function initializeViraSchool() {
        // Initialize form handling
        initFormValidation();
        
        // Initialize AJAX handlers
        initAjaxHandlers();
        
        // Initialize UI enhancements
        initUIEnhancements();
        
        // Initialize tooltips and help text
        initHelpSystem();
    }

    function initFormValidation() {
        // Add form validation for student forms
        $('.student-form').on('submit', function(e) {
            if (!validateStudentForm($(this))) {
                e.preventDefault();
                showNotice('Please fill in all required fields correctly.', 'error');
            }
        });

        // Add form validation for teacher forms
        $('.teacher-form').on('submit', function(e) {
            if (!validateTeacherForm($(this))) {
                e.preventDefault();
                showNotice('Please fill in all required fields correctly.', 'error');
            }
        });

        // Add form validation for class forms
        $('.class-form').on('submit', function(e) {
            if (!validateClassForm($(this))) {
                e.preventDefault();
                showNotice('Please fill in all required fields correctly.', 'error');
            }
        });

        // Add form validation for course forms
        $('.course-form').on('submit', function(e) {
            if (!validateCourseForm($(this))) {
                e.preventDefault();
                showNotice('Please fill in all required fields correctly.', 'error');
            }
        });
    }

    function validateStudentForm($form) {
        var isValid = true;
        var studentId = $form.find('#student_id').val().trim();
        var firstName = $form.find('#first_name').val().trim();
        var lastName = $form.find('#last_name').val().trim();
        var email = $form.find('#email').val().trim();

        // Check required fields
        if (!studentId || !firstName || !lastName || !email) {
            isValid = false;
        }

        // Validate email format
        var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (email && !emailRegex.test(email)) {
            isValid = false;
            showNotice('Please enter a valid email address.', 'error');
        }

        return isValid;
    }

    function validateTeacherForm($form) {
        var isValid = true;
        var teacherId = $form.find('#teacher_id').val().trim();
        var firstName = $form.find('#first_name').val().trim();
        var lastName = $form.find('#last_name').val().trim();
        var email = $form.find('#email').val().trim();

        // Check required fields
        if (!teacherId || !firstName || !lastName || !email) {
            isValid = false;
        }

        // Validate email format
        var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (email && !emailRegex.test(email)) {
            isValid = false;
            showNotice('Please enter a valid email address.', 'error');
        }

        return isValid;
    }

    function validateClassForm($form) {
        var isValid = true;
        var className = $form.find('#class_name').val().trim();
        var classCode = $form.find('#class_code').val().trim();

        // Check required fields
        if (!className || !classCode) {
            isValid = false;
        }

        return isValid;
    }

    function validateCourseForm($form) {
        var isValid = true;
        var courseName = $form.find('#course_name').val().trim();
        var courseCode = $form.find('#course_code').val().trim();

        // Check required fields
        if (!courseName || !courseCode) {
            isValid = false;
        }

        return isValid;
    }

    function initAjaxHandlers() {
        // Handle edit button clicks (placeholder)
        $(document).on('click', '.edit-student, .edit-teacher, .edit-class, .edit-course', function(e) {
            e.preventDefault();
            var id = $(this).data('id');
            var type = $(this).hasClass('edit-student') ? 'student' : 
                      $(this).hasClass('edit-teacher') ? 'teacher' :
                      $(this).hasClass('edit-class') ? 'class' : 'course';
            
            showNotice('Edit functionality will be available in future updates.', 'info');
        });

        // Handle delete button clicks (placeholder)
        $(document).on('click', '.delete-student, .delete-teacher, .delete-class, .delete-course', function(e) {
            e.preventDefault();
            var id = $(this).data('id');
            var type = $(this).hasClass('delete-student') ? 'student' : 
                      $(this).hasClass('delete-teacher') ? 'teacher' :
                      $(this).hasClass('delete-class') ? 'class' : 'course';
            
            if (confirm('Are you sure you want to delete this ' + type + '?')) {
                showNotice('Delete functionality will be available in future updates.', 'info');
            }
        });
    }

    function initUIEnhancements() {
        // Add loading states to form submissions
        $('form').on('submit', function() {
            var $form = $(this);
            var $submitBtn = $form.find('input[type="submit"], button[type="submit"]');
            
            $submitBtn.prop('disabled', true);
            $submitBtn.val('Processing...');
            
            // Re-enable after a delay (in case of errors)
            setTimeout(function() {
                $submitBtn.prop('disabled', false);
                $submitBtn.val($submitBtn.data('original-value') || 'Submit');
            }, 5000);
        });

        // Auto-dismiss notices after 5 seconds
        setTimeout(function() {
            $('.notice.is-dismissible').fadeOut();
        }, 5000);

        // Add hover effects to stat boxes
        $('.stat-box, .info-card').hover(
            function() {
                $(this).addClass('hover-effect');
            },
            function() {
                $(this).removeClass('hover-effect');
            }
        );

        // Smooth scrolling for anchor links
        $('a[href^="#"]').on('click', function(e) {
            e.preventDefault();
            var target = this.hash;
            var $target = $(target);

            if ($target.length) {
                $('html, body').animate({
                    'scrollTop': $target.offset().top - 50
                }, 500, 'swing');
            }
        });
    }

    function initHelpSystem() {
        // Add tooltips to form fields
        $('input[required], select[required], textarea[required]').each(function() {
            $(this).attr('title', 'This field is required');
        });

        // Add help text for specific fields
        $('#student_id').attr('title', 'Enter a unique student ID (e.g., STU001)');
        $('#teacher_id').attr('title', 'Enter a unique teacher ID (e.g., TCH001)');
        $('#class_code').attr('title', 'Enter a short class code (e.g., G10A)');
        $('#course_code').attr('title', 'Enter a course code (e.g., MATH101)');
        $('#max_students').attr('title', 'Maximum number of students allowed in this class');
        $('#credits').attr('title', 'Number of credit hours for this course');
        $('#duration').attr('title', 'Duration of each class session in minutes');
    }

    function showNotice(message, type) {
        type = type || 'info';
        var noticeClass = 'notice notice-' + type + ' is-dismissible vira-notice';
        var notice = '<div class="' + noticeClass + '"><p>' + message + '</p></div>';
        
        // Remove existing notices of the same type
        $('.vira-notice').remove();
        
        // Add new notice
        $('.wrap').first().prepend(notice);
        
        // Auto-dismiss after 5 seconds
        setTimeout(function() {
            $('.vira-notice').fadeOut();
        }, 5000);
    }

    // Utility functions
    function formatNumber(num) {
        return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }

    function formatDate(dateString) {
        var date = new Date(dateString);
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }

    function formatTime(timeString) {
        var time = new Date('1970-01-01T' + timeString + 'Z');
        return time.toLocaleTimeString('en-US', {
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        });
    }

    // Export functions for global use
    window.ViraSchool = {
        showNotice: showNotice,
        formatNumber: formatNumber,
        formatDate: formatDate,
        formatTime: formatTime
    };

})(jQuery);
