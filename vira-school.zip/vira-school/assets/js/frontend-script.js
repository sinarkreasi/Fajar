/**
 * Vira School Frontend JavaScript
 * Interactive functionality for the school portal
 */

(function($) {
    'use strict';
    
    // Initialize when DOM is ready
    $(document).ready(function() {
        initPortal();
    });
    
    /**
     * Initialize portal functionality
     */
    function initPortal() {
        // Add smooth scrolling to portal cards
        addCardAnimations();
        
        // Handle portal interactions
        handlePortalInteractions();
        
        // Initialize stats counters
        initStatsCounters();
        
        // Add loading states
        addLoadingStates();
    }
    
    /**
     * Add card hover animations and interactions
     */
    function addCardAnimations() {
        $('.portal-card').each(function(index) {
            $(this).css({
                'animation-delay': (index * 0.1) + 's'
            });
        });
        
        // Add ripple effect to buttons
        $('.portal-button').on('click', function(e) {
            const button = $(this);
            const ripple = $('<span class="ripple"></span>');
            
            const rect = this.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            ripple.css({
                left: x + 'px',
                top: y + 'px'
            });
            
            button.append(ripple);
            
            setTimeout(function() {
                ripple.remove();
            }, 600);
        });
    }
    
    /**
     * Handle portal interactions
     */
    function handlePortalInteractions() {
        // Smooth expand/collapse for course details
        $('.course-item').on('click', function() {
            $(this).toggleClass('expanded');
        });
        
        // Attendance item interactions
        $('.attendance-item').on('click', function() {
            $(this).toggleClass('selected');
        });
        
        // Info item highlighting
        $('.info-item').on('mouseenter', function() {
            $(this).addClass('highlight');
        }).on('mouseleave', function() {
            $(this).removeClass('highlight');
        });
    }
    
    /**
     * Initialize animated stats counters
     */
    function initStatsCounters() {
        $('.stat-number').each(function() {
            const $this = $(this);
            const targetValue = parseInt($this.text());
            
            if (isNaN(targetValue)) return;
            
            $this.text('0');
            
            // Use Intersection Observer for better performance
            if ('IntersectionObserver' in window) {
                const observer = new IntersectionObserver(function(entries) {
                    entries.forEach(function(entry) {
                        if (entry.isIntersecting) {
                            animateCounter($this, targetValue);
                            observer.unobserve(entry.target);
                        }
                    });
                });
                
                observer.observe($this[0]);
            } else {
                // Fallback for older browsers
                animateCounter($this, targetValue);
            }
        });
    }
    
    /**
     * Animate counter from 0 to target value
     */
    function animateCounter($element, targetValue) {
        let currentValue = 0;
        const increment = targetValue / 30; // 30 steps
        const timer = setInterval(function() {
            currentValue += increment;
            
            if (currentValue >= targetValue) {
                currentValue = targetValue;
                clearInterval(timer);
            }
            
            $element.text(Math.floor(currentValue));
        }, 50);
    }
    
    /**
     * Add loading states and progressive enhancement
     */
    function addLoadingStates() {
        // Add loaded class after a short delay for smooth transitions
        setTimeout(function() {
            $('.vira-school-portal').addClass('loaded');
        }, 100);
        
        // Handle image loading for better UX
        $('.portal-card img').on('load', function() {
            $(this).addClass('loaded');
        });
    }
    
    /**
     * Utility function to show notifications
     */
    function showNotification(message, type = 'info') {
        const notification = $(`
            <div class="vira-notification vira-notification-${type}">
                <span class="notification-message">${message}</span>
                <button class="notification-close">&times;</button>
            </div>
        `);
        
        $('body').append(notification);
        
        // Show notification with animation
        setTimeout(function() {
            notification.addClass('show');
        }, 100);
        
        // Auto-hide after 5 seconds
        setTimeout(function() {
            hideNotification(notification);
        }, 5000);
        
        // Handle manual close
        notification.find('.notification-close').on('click', function() {
            hideNotification(notification);
        });
    }
    
    /**
     * Hide notification with animation
     */
    function hideNotification($notification) {
        $notification.removeClass('show');
        setTimeout(function() {
            $notification.remove();
        }, 300);
    }
    
    /**
     * Handle responsive behavior
     */
    function handleResponsive() {
        const $window = $(window);
        const $portal = $('.vira-school-portal');
        
        function updateLayout() {
            if ($window.width() < 768) {
                $portal.addClass('mobile-view');
            } else {
                $portal.removeClass('mobile-view');
            }
        }
        
        updateLayout();
        $window.on('resize', debounce(updateLayout, 250));
    }
    
    /**
     * Debounce function for performance
     */
    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = function() {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
    
    // Initialize responsive handling
    handleResponsive();
    
    // Global utility functions
    window.ViraSchool = window.ViraSchool || {};
    window.ViraSchool.showNotification = showNotification;
    window.ViraSchool.hideNotification = hideNotification;
    
})(jQuery);

// Additional CSS for JavaScript enhancements
const dynamicStyles = `
<style>
.ripple {
    position: absolute;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.6);
    transform: scale(0);
    animation: ripple-animation 0.6s linear;
    pointer-events: none;
}

@keyframes ripple-animation {
    to {
        transform: scale(4);
        opacity: 0;
    }
}

.vira-notification {
    position: fixed;
    top: 20px;
    right: 20px;
    background: white;
    padding: 15px 20px;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    z-index: 10000;
    transform: translateX(100%);
    transition: transform 0.3s ease;
    max-width: 300px;
}

.vira-notification.show {
    transform: translateX(0);
}

.vira-notification-info {
    border-left: 4px solid #4facfe;
}

.vira-notification-success {
    border-left: 4px solid #11998e;
}

.vira-notification-warning {
    border-left: 4px solid #ffd93d;
}

.vira-notification-error {
    border-left: 4px solid #ff6b6b;
}

.notification-close {
    background: none;
    border: none;
    font-size: 18px;
    color: #999;
    cursor: pointer;
    float: right;
    margin-left: 10px;
}

.course-item.expanded {
    transform: scale(1.02);
}

.info-item.highlight {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border-radius: 8px;
    padding-left: 15px;
    padding-right: 15px;
}

.attendance-item.selected {
    background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
    color: white;
}

.vira-school-portal:not(.loaded) .portal-card {
    opacity: 0;
    transform: translateY(30px);
}

.vira-school-portal.loaded .portal-card {
    opacity: 1;
    transform: translateY(0);
}

.mobile-view .portal-grid {
    grid-template-columns: 1fr !important;
}

.mobile-view .stat-grid {
    grid-template-columns: repeat(2, 1fr) !important;
}

@media (max-width: 480px) {
    .mobile-view .stat-grid {
        grid-template-columns: 1fr !important;
    }
    
    .vira-notification {
        right: 10px;
        left: 10px;
        max-width: none;
    }
}
</style>
`;

// Inject dynamic styles
document.head.insertAdjacentHTML('beforeend', dynamicStyles);
