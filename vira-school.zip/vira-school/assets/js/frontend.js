jQuery(document).ready(function($) {
    'use strict';
    
    // Initialize frontend functionality
    init();
    
    function init() {
        // Add any frontend initialization here
        initAttendanceColors();
        initResponsiveTables();
    }
    
    // Initialize attendance status colors
    function initAttendanceColors() {
        $('.attendance-table td').each(function() {
            var $cell = $(this);
            var status = $cell.text().toLowerCase().trim();
            
            if (status === 'present') {
                $cell.addClass('status-present');
            } else if (status === 'absent') {
                $cell.addClass('status-absent');
            } else if (status === 'late') {
                $cell.addClass('status-late');
            } else if (status === 'excused') {
                $cell.addClass('status-excused');
            }
        });
    }
    
    // Initialize responsive tables
    function initResponsiveTables() {
        $('.attendance-table, .students-table').each(function() {
            var $table = $(this);
            
            // Add responsive wrapper if not exists
            if (!$table.parent().hasClass('table-responsive')) {
                $table.wrap('<div class="table-responsive"></div>');
            }
        });
    }
    
    // Student profile interactions
    $('.vira-school-student-profile').on('click', '.student-info p', function() {
        $(this).addClass('highlight');
        setTimeout(function() {
            $('.student-info p').removeClass('highlight');
        }, 2000);
    });
    
    // Attendance statistics hover effects
    $('.attendance-stats .stat').hover(
        function() {
            $(this).addClass('stat-hover');
        },
        function() {
            $(this).removeClass('stat-hover');
        }
    );
    
    // Search functionality for frontend tables
    if ($('#vira-student-search').length) {
        $('#vira-student-search').on('keyup', function() {
            var value = $(this).val().toLowerCase();
            $('.students-table tbody tr').filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
            });
        });
    }
    
    // Print functionality
    if ($('.vira-print-btn').length) {
        $('.vira-print-btn').on('click', function(e) {
            e.preventDefault();
            window.print();
        });
    }
    
    // Export functionality (placeholder)
    if ($('.vira-export-btn').length) {
        $('.vira-export-btn').on('click', function(e) {
            e.preventDefault();
            var format = $(this).data('format') || 'csv';
            
            // TODO: Implement export functionality
            alert('Export to ' + format.toUpperCase() + ' will be implemented in a future update.');
        });
    }
    
    // Smooth scrolling for anchor links
    $('a[href^="#"]').on('click', function(e) {
        var target = $($(this).attr('href'));
        
        if (target.length) {
            e.preventDefault();
            $('html, body').animate({
                scrollTop: target.offset().top - 100
            }, 500);
        }
    });
});
