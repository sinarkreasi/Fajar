<?php
/**
 * Course management class for Vira School
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class ViraSchool_Course {
    
    /**
     * Get all courses
     */
    public static function get_all_courses($status = 'all') {
        global $wpdb;
        
        $where = '';
        if ($status !== 'all') {
            $where = $wpdb->prepare("WHERE status = %s", $status);
        }
        
        return $wpdb->get_results("SELECT * FROM {$wpdb->prefix}vira_courses $where ORDER BY created_at DESC");
    }
    
    /**
     * Get course by ID
     */
    public static function get_course($id) {
        global $wpdb;
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}vira_courses WHERE id = %d",
            $id
        ));
    }
    
    /**
     * Add new course
     */
    public static function add_course($data) {
        global $wpdb;
        
        $defaults = array(
            'status' => 'active',
            'credits' => 1,
            'duration' => 60
        );
        
        $data = wp_parse_args($data, $defaults);
        
        return $wpdb->insert(
            $wpdb->prefix . 'vira_courses',
            $data
        );
    }
    
    /**
     * Update course
     */
    public static function update_course($id, $data) {
        global $wpdb;
        
        return $wpdb->update(
            $wpdb->prefix . 'vira_courses',
            $data,
            array('id' => $id)
        );
    }
    
    /**
     * Delete course
     */
    public static function delete_course($id) {
        global $wpdb;
        
        return $wpdb->delete(
            $wpdb->prefix . 'vira_courses',
            array('id' => $id)
        );
    }
}
