<?php
/**
 * Database management class for Vira School
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class ViraSchool_Database {
    
    /**
     * Create plugin tables
     */
    public function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Students table
        $students_table = $wpdb->prefix . 'vira_students';
        $students_sql = "CREATE TABLE $students_table (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            student_id varchar(50) NOT NULL,
            first_name varchar(100) NOT NULL,
            last_name varchar(100) NOT NULL,
            email varchar(100) NOT NULL,
            phone varchar(20),
            date_of_birth date,
            address text,
            parent_name varchar(100),
            parent_phone varchar(20),
            parent_email varchar(100),
            enrollment_date datetime DEFAULT CURRENT_TIMESTAMP,
            status enum('active', 'inactive', 'graduated') DEFAULT 'active',
            class_id mediumint(9),
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY student_id (student_id)
        ) $charset_collate;";
        
        // Classes table
        $classes_table = $wpdb->prefix . 'vira_classes';
        $classes_sql = "CREATE TABLE $classes_table (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            class_name varchar(100) NOT NULL,
            class_code varchar(20) NOT NULL,
            description text,
            teacher_id mediumint(9),
            max_students int(5) DEFAULT 30,
            academic_year varchar(10),
            status enum('active', 'inactive') DEFAULT 'active',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY class_code (class_code)
        ) $charset_collate;";
        
        // Courses table
        $courses_table = $wpdb->prefix . 'vira_courses';
        $courses_sql = "CREATE TABLE $courses_table (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            course_name varchar(100) NOT NULL,
            course_code varchar(20) NOT NULL,
            description text,
            credits int(2) DEFAULT 1,
            teacher_id mediumint(9),
            class_id mediumint(9),
            schedule_day varchar(20),
            schedule_time time,
            duration int(3) DEFAULT 60,
            status enum('active', 'inactive') DEFAULT 'active',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY course_code (course_code)
        ) $charset_collate;";
        
        // Attendance table
        $attendance_table = $wpdb->prefix . 'vira_attendance';
        $attendance_sql = "CREATE TABLE $attendance_table (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            student_id mediumint(9) NOT NULL,
            course_id mediumint(9) NOT NULL,
            attendance_date date NOT NULL,
            status enum('present', 'absent', 'late', 'excused') DEFAULT 'present',
            notes text,
            marked_by mediumint(9),
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY unique_attendance (student_id, course_id, attendance_date)
        ) $charset_collate;";
        
        // Grades table
        $grades_table = $wpdb->prefix . 'vira_grades';
        $grades_sql = "CREATE TABLE $grades_table (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            student_id mediumint(9) NOT NULL,
            course_id mediumint(9) NOT NULL,
            assignment_name varchar(100) NOT NULL,
            assignment_type enum('quiz', 'exam', 'homework', 'project', 'participation') DEFAULT 'homework',
            grade decimal(5,2),
            max_grade decimal(5,2) DEFAULT 100.00,
            grade_date date,
            notes text,
            teacher_id mediumint(9),
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
        
        // Teachers table
        $teachers_table = $wpdb->prefix . 'vira_teachers';
        $teachers_sql = "CREATE TABLE $teachers_table (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            teacher_id varchar(50) NOT NULL,
            first_name varchar(100) NOT NULL,
            last_name varchar(100) NOT NULL,
            email varchar(100) NOT NULL,
            phone varchar(20),
            department varchar(100),
            qualification text,
            hire_date date,
            status enum('active', 'inactive') DEFAULT 'active',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY teacher_id (teacher_id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        
        dbDelta($students_sql);
        dbDelta($classes_sql);
        dbDelta($courses_sql);
        dbDelta($attendance_sql);
        dbDelta($grades_sql);
        dbDelta($teachers_sql);
    }
    
    /**
     * Get table name with prefix
     */
    public static function get_table_name($table) {
        global $wpdb;
        return $wpdb->prefix . 'vira_' . $table;
    }
    
    /**
     * Drop plugin tables (for uninstall)
     */
    public function drop_tables() {
        global $wpdb;
        
        $tables = array(
            'vira_attendance',
            'vira_grades',
            'vira_courses',
            'vira_students',
            'vira_classes',
            'vira_teachers'
        );
        
        foreach ($tables as $table) {
            $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}$table");
        }
    }
}
