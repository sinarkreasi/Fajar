<?php
/**
 * Admin interface class for Vira School
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class ViraSchool_Admin {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'admin_init'));
        add_action('wp_ajax_vira_school_add_student', array($this, 'ajax_add_student'));
        add_action('wp_ajax_vira_school_edit_student', array($this, 'ajax_edit_student'));
        add_action('wp_ajax_vira_school_delete_student', array($this, 'ajax_delete_student'));
        add_action('wp_ajax_vira_school_add_teacher', array($this, 'ajax_add_teacher'));
        add_action('wp_ajax_vira_school_edit_teacher', array($this, 'ajax_edit_teacher'));
        add_action('wp_ajax_vira_school_delete_teacher', array($this, 'ajax_delete_teacher'));
        add_action('wp_ajax_vira_school_add_course', array($this, 'ajax_add_course'));
        add_action('wp_ajax_vira_school_edit_course', array($this, 'ajax_edit_course'));
        add_action('wp_ajax_vira_school_delete_course', array($this, 'ajax_delete_course'));
        add_action('wp_ajax_vira_school_add_class', array($this, 'ajax_add_class'));
        add_action('wp_ajax_vira_school_edit_class', array($this, 'ajax_edit_class'));
        add_action('wp_ajax_vira_school_delete_class', array($this, 'ajax_delete_class'));
        
        // Enqueue admin styles and scripts
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        
        // Settings
        add_action('admin_init', array($this, 'register_settings'));
        
        // Check and create database tables if needed
        add_action('admin_init', array($this, 'check_database_tables'));
        
        // Admin notices
        add_action('admin_notices', array($this, 'admin_notices'));
    }
    
    /**
     * Check if database tables exist and create them if needed
     */
    public function check_database_tables() {
        global $wpdb;
        
        $tables_needed = array(
            'vira_students',
            'vira_teachers', 
            'vira_classes',
            'vira_courses',
            'vira_attendance',
            'vira_grades'
        );
        
        $missing_tables = array();
        
        foreach ($tables_needed as $table) {
            $table_name = $wpdb->prefix . $table;
            if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
                $missing_tables[] = $table;
            }
        }
        
        if (!empty($missing_tables)) {
            // Create missing tables
            $database = new ViraSchool_Database();
            $database->create_tables();
            
            // Set transient to show success message
            set_transient('vira_school_tables_created', true, 30);
        }
    }
    
    /**
     * Display admin notices
     */
    public function admin_notices() {
        if (get_transient('vira_school_tables_created')) {
            echo '<div class="notice notice-success is-dismissible"><p>' . __('Vira School database tables have been created successfully!', 'vira-school') . '</p></div>';
            delete_transient('vira_school_tables_created');
        }
    }
    
    /**
     * Enqueue admin assets
     */
    public function enqueue_admin_assets($hook) {
        // Only load on our plugin pages
        if (strpos($hook, 'vira-school') === false) {
            return;
        }
        
        wp_enqueue_style(
            'vira-school-admin',
            plugin_dir_url(dirname(__FILE__)) . 'assets/css/admin-style.css',
            array(),
            '1.0.0'
        );
        
        wp_enqueue_script(
            'vira-school-admin',
            plugin_dir_url(dirname(__FILE__)) . 'assets/js/admin-script.js',
            array('jquery'),
            '1.0.0',
            true
        );
        
        // Localize script with AJAX URL and nonce
        wp_localize_script('vira-school-admin', 'vira_school_admin_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('vira_school_admin_nonce')
        ));
    }
    
    /**
     * Register plugin settings
     */
    public function register_settings() {
        register_setting('vira_school_settings', 'vira_school_options');
        
        add_settings_section(
            'vira_school_general',
            __('General Settings', 'vira-school'),
            array($this, 'general_settings_callback'),
            'vira_school_settings'
        );
        
        add_settings_field(
            'school_name',
            __('School Name', 'vira-school'),
            array($this, 'school_name_callback'),
            'vira_school_settings',
            'vira_school_general'
        );
        
        add_settings_field(
            'school_address',
            __('School Address', 'vira-school'),
            array($this, 'school_address_callback'),
            'vira_school_settings',
            'vira_school_general'
        );
        
        add_settings_field(
            'academic_year',
            __('Current Academic Year', 'vira-school'),
            array($this, 'academic_year_callback'),
            'vira_school_settings',
            'vira_school_general'
        );
        
        add_settings_field(
            'student_portal_enabled',
            __('Enable Student Portal', 'vira-school'),
            array($this, 'student_portal_callback'),
            'vira_school_settings',
            'vira_school_general'
        );
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        // Main menu page
        add_menu_page(
            __('Vira School Management', 'vira-school'),
            __('Vira School', 'vira-school'),
            'manage_options',
            'vira-school',
            array($this, 'admin_page_dashboard'),
            'dashicons-welcome-learn-more',
            33
        );
        
        // Dashboard - rename the first submenu to avoid duplication
        add_submenu_page(
            'vira-school',
            __('Dashboard', 'vira-school'),
			'<span class="dashicons dashicons-performance" style="font-size: 16px; width: 16px; height: 16px;"></span> ' . __('Dashboard', 'vira-school'),
            'manage_options',
            'vira-school',
            array($this, 'admin_page_dashboard'),
        );
        
        // Students Management
        add_submenu_page(
            'vira-school',
            __('Students Management', 'vira-school'),
            '<span class="dashicons dashicons-groups" style="font-size: 16px; width: 16px; height: 16px;"></span> ' . __('Students', 'vira-school'),
            'manage_options',
            'vira-school-students',
            array($this, 'admin_page_students'),
            null,
            10
        );
        
        // Teachers Management
        add_submenu_page(
            'vira-school',
            __('Teachers Management', 'vira-school'),
            '<span class="dashicons dashicons-businessman" style="font-size: 16px; width: 16px; height: 16px;"></span> ' . __('Teachers', 'vira-school'),
            'manage_options',
            'vira-school-teachers',
            array($this, 'admin_page_teachers'),
            null,
            20
        );
        
        // Classes Management
        add_submenu_page(
            'vira-school',
            __('Classes Management', 'vira-school'),
            '<span class="dashicons dashicons-admin-multisite" style="font-size: 16px; width: 16px; height: 16px;"></span> ' . __('Classes', 'vira-school'),
            'manage_options',
            'vira-school-classes',
            array($this, 'admin_page_classes'),
            null,
            30
        );
        
        // Courses Management
        add_submenu_page(
            'vira-school',
            __('Courses Management', 'vira-school'),
            '<span class="dashicons dashicons-book-alt" style="font-size: 16px; width: 16px; height: 16px;"></span> ' . __('Courses', 'vira-school'),
            'manage_options',
            'vira-school-courses',
            array($this, 'admin_page_courses'),
            null,
            40
        );
        
        // Attendance Management
        add_submenu_page(
            'vira-school',
            __('Attendance Management', 'vira-school'),
            '<span class="dashicons dashicons-yes-alt" style="font-size: 16px; width: 16px; height: 16px;"></span> ' . __('Attendance', 'vira-school'),
            'manage_options',
            'vira-school-attendance',
            array($this, 'admin_page_attendance'),
            null,
            50
        );
        
        // Reports & Analytics
        add_submenu_page(
            'vira-school',
            __('Reports & Analytics', 'vira-school'),
            '<span class="dashicons dashicons-chart-bar" style="font-size: 16px; width: 16px; height: 16px;"></span> ' . __('Reports', 'vira-school'),
            'manage_options',
            'vira-school-reports',
            array($this, 'admin_page_reports'),
            null,
            60
        );
        
        // Student Portal (if enabled)
        $options = get_option('vira_school_options', array());
        if (isset($options['student_portal_enabled']) && $options['student_portal_enabled']) {
            add_submenu_page(
                'vira-school',
                __('Student Portal', 'vira-school'),
                '<span class="dashicons dashicons-admin-users" style="font-size: 16px; width: 16px; height: 16px;"></span> ' . __('Student Portal', 'vira-school'),
                'read',
                'vira-school-portal',
                array($this, 'admin_page_student_portal'),
                null,
                70
            );
        }
        
        // Settings
        add_submenu_page(
            'vira-school',
            __('Vira School Settings', 'vira-school'),
            '<span class="dashicons dashicons-admin-settings" style="font-size: 16px; width: 16px; height: 16px;"></span> ' . __('Settings', 'vira-school'),
            'manage_options',
            'vira-school-settings',
            array($this, 'admin_page_settings'),
            null,
            80
        );
    }
    
    /**
     * Admin initialization
     */
    public function admin_init() {
        wp_enqueue_script('jquery');
    }
    
    /**
     * Debug admin notice (temporary)
     */
    public function debug_admin_notice() {
        if (get_transient('vira_school_debug_shown')) {
            return;
        }
        
        echo '<div class="notice notice-info is-dismissible"><p>Vira School Admin class loaded successfully. Menu should be visible.</p></div>';
        set_transient('vira_school_debug_shown', true, 60); // Show only once per minute
    }
    
    /**
     * Dashboard page
     */
    public function admin_page_dashboard() {
        global $wpdb;
        
        // Get statistics with null checks
        $students_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}vira_students WHERE status = 'active'") ?: 0;
        $teachers_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}vira_teachers WHERE status = 'active'") ?: 0;
        $classes_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}vira_classes WHERE status = 'active'") ?: 0;
        $courses_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}vira_courses WHERE status = 'active'") ?: 0;
        
        ?>
        <div class="wrap">
                        
            <div class="vira-school-dashboard">
                <div class="dashboard-stats">
                    <div class="stat-box">
                        <h3><?php echo esc_html($students_count); ?></h3>
                        <p><?php _e('Active Students', 'vira-school'); ?></p>
                    </div>
                    <div class="stat-box">
                        <h3><?php echo esc_html($teachers_count); ?></h3>
                        <p><?php _e('Active Teachers', 'vira-school'); ?></p>
                    </div>
                    <div class="stat-box">
                        <h3><?php echo esc_html($classes_count); ?></h3>
                        <p><?php _e('Active Classes', 'vira-school'); ?></p>
                    </div>
                    <div class="stat-box">
                        <h3><?php echo esc_html($courses_count); ?></h3>
                        <p><?php _e('Active Courses', 'vira-school'); ?></p>
                    </div>
                </div>
                
                <div class="dashboard-quick-actions">
                    <h2><?php _e('Quick Actions', 'vira-school'); ?></h2>
                    <div class="quick-actions-grid">
                        <a href="<?php echo admin_url('admin.php?page=vira-school-students'); ?>" class="quick-action">
                            <span class="dashicons dashicons-groups"></span>
                            <?php _e('Manage Students', 'vira-school'); ?>
                        </a>
                        <a href="<?php echo admin_url('admin.php?page=vira-school-teachers'); ?>" class="quick-action">
                            <span class="dashicons dashicons-businessman"></span>
                            <?php _e('Manage Teachers', 'vira-school'); ?>
                        </a>
                        <a href="<?php echo admin_url('admin.php?page=vira-school-attendance'); ?>" class="quick-action">
                            <span class="dashicons dashicons-yes"></span>
                            <?php _e('Take Attendance', 'vira-school'); ?>
                        </a>
                        <a href="<?php echo admin_url('admin.php?page=vira-school-reports'); ?>" class="quick-action">
                            <span class="dashicons dashicons-chart-bar"></span>
                            <?php _e('View Reports', 'vira-school'); ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Students page
     */
    public function admin_page_students() {
        global $wpdb;
        
        // Handle form submission
        if (isset($_POST['action']) && $_POST['action'] === 'add_student' && wp_verify_nonce($_POST['_wpnonce'], 'vira_school_add_student')) {
            $this->handle_add_student();
        }
        
        // Get students
        $students = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}vira_students ORDER BY created_at DESC");
        
        ?>
        <div class="wrap">
                        
            <form method="post" class="student-form">
                <?php wp_nonce_field('vira_school_add_student'); ?>
                <input type="hidden" name="action" value="add_student">
                
                <table class="form-table">
                    <tr>
                        <th><label for="student_id"><?php _e('Student ID', 'vira-school'); ?></label></th>
                        <td><input type="text" id="student_id" name="student_id" required></td>
                    </tr>
                    <tr>
                        <th><label for="first_name"><?php _e('First Name', 'vira-school'); ?></label></th>
                        <td><input type="text" id="first_name" name="first_name" required></td>
                    </tr>
                    <tr>
                        <th><label for="last_name"><?php _e('Last Name', 'vira-school'); ?></label></th>
                        <td><input type="text" id="last_name" name="last_name" required></td>
                    </tr>
                    <tr>
                        <th><label for="email"><?php _e('Email', 'vira-school'); ?></label></th>
                        <td><input type="email" id="email" name="email" required></td>
                    </tr>
                    <tr>
                        <th><label for="phone"><?php _e('Phone', 'vira-school'); ?></label></th>
                        <td><input type="text" id="phone" name="phone"></td>
                    </tr>
                    <tr>
                        <th><label for="date_of_birth"><?php _e('Date of Birth', 'vira-school'); ?></label></th>
                        <td><input type="date" id="date_of_birth" name="date_of_birth"></td>
                    </tr>
                </table>
                
                <?php submit_button(__('Add Student', 'vira-school')); ?>
            </form>
            
            <hr>
            
            <h2><?php _e('Students List', 'vira-school'); ?></h2>
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e('Student ID', 'vira-school'); ?></th>
                        <th><?php _e('Name', 'vira-school'); ?></th>
                        <th><?php _e('Email', 'vira-school'); ?></th>
                        <th><?php _e('Phone', 'vira-school'); ?></th>
                        <th><?php _e('Status', 'vira-school'); ?></th>
                        <th><?php _e('Actions', 'vira-school'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($students)): ?>
                        <?php foreach ($students as $student): ?>
                            <tr>
                                <td><?php echo esc_html($student->student_id); ?></td>
                                <td><?php echo esc_html($student->first_name . ' ' . $student->last_name); ?></td>
                                <td><?php echo esc_html($student->email); ?></td>
                                <td><?php echo esc_html($student->phone); ?></td>
                                <td><?php echo esc_html(ucfirst($student->status)); ?></td>
                                <td>
                                    <button class="button button-secondary edit-student" data-id="<?php echo $student->id; ?>">
                                        <?php _e('Edit', 'vira-school'); ?>
                                    </button>
                                    <button class="button button-link-delete delete-student" data-id="<?php echo $student->id; ?>">
                                        <?php _e('Delete', 'vira-school'); ?>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6"><?php _e('No students found.', 'vira-school'); ?></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }
    
    /**
     * Handle add student form submission
     */
    private function handle_add_student() {
        global $wpdb;
        
        $student_data = array(
            'student_id' => sanitize_text_field($_POST['student_id']),
            'first_name' => sanitize_text_field($_POST['first_name']),
            'last_name' => sanitize_text_field($_POST['last_name']),
            'email' => sanitize_email($_POST['email']),
            'phone' => sanitize_text_field($_POST['phone']),
            'date_of_birth' => sanitize_text_field($_POST['date_of_birth'])
        );
        
        $result = $wpdb->insert(
            $wpdb->prefix . 'vira_students',
            $student_data
        );
        
        if ($result !== false) {
            echo '<div class="notice notice-success"><p>' . __('Student added successfully!', 'vira-school') . '</p></div>';
        } else {
            echo '<div class="notice notice-error"><p>' . __('Error adding student. Please try again.', 'vira-school') . '</p></div>';
        }
    }
    
    /**
     * Teachers page
     */
    public function admin_page_teachers() {
        global $wpdb;
        
        // Handle form submission
        if (isset($_POST['action']) && $_POST['action'] === 'add_teacher' && wp_verify_nonce($_POST['_wpnonce'], 'vira_school_add_teacher')) {
            $this->handle_add_teacher();
        }
        
        // Get teachers
        $teachers = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}vira_teachers ORDER BY created_at DESC");
        
        ?>
        <div class="wrap">
            <h1><?php _e('Teachers Management', 'vira-school'); ?></h1>
            
            <form method="post" class="teacher-form">
                <?php wp_nonce_field('vira_school_add_teacher'); ?>
                <input type="hidden" name="action" value="add_teacher">
                
                <table class="form-table">
                    <tr>
                        <th><label for="teacher_id"><?php _e('Teacher ID', 'vira-school'); ?></label></th>
                        <td><input type="text" id="teacher_id" name="teacher_id" required></td>
                    </tr>
                    <tr>
                        <th><label for="first_name"><?php _e('First Name', 'vira-school'); ?></label></th>
                        <td><input type="text" id="first_name" name="first_name" required></td>
                    </tr>
                    <tr>
                        <th><label for="last_name"><?php _e('Last Name', 'vira-school'); ?></label></th>
                        <td><input type="text" id="last_name" name="last_name" required></td>
                    </tr>
                    <tr>
                        <th><label for="email"><?php _e('Email', 'vira-school'); ?></label></th>
                        <td><input type="email" id="email" name="email" required></td>
                    </tr>
                    <tr>
                        <th><label for="phone"><?php _e('Phone', 'vira-school'); ?></label></th>
                        <td><input type="text" id="phone" name="phone"></td>
                    </tr>
                    <tr>
                        <th><label for="department"><?php _e('Department', 'vira-school'); ?></label></th>
                        <td><input type="text" id="department" name="department"></td>
                    </tr>
                    <tr>
                        <th><label for="qualification"><?php _e('Qualification', 'vira-school'); ?></label></th>
                        <td><textarea id="qualification" name="qualification" rows="3" cols="50"></textarea></td>
                    </tr>
                    <tr>
                        <th><label for="hire_date"><?php _e('Hire Date', 'vira-school'); ?></label></th>
                        <td><input type="date" id="hire_date" name="hire_date"></td>
                    </tr>
                </table>
                
                <?php submit_button(__('Add Teacher', 'vira-school')); ?>
            </form>
            
            <hr>
            
            <h2><?php _e('Teachers List', 'vira-school'); ?></h2>
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e('Teacher ID', 'vira-school'); ?></th>
                        <th><?php _e('Name', 'vira-school'); ?></th>
                        <th><?php _e('Email', 'vira-school'); ?></th>
                        <th><?php _e('Department', 'vira-school'); ?></th>
                        <th><?php _e('Status', 'vira-school'); ?></th>
                        <th><?php _e('Actions', 'vira-school'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($teachers)): ?>
                        <?php foreach ($teachers as $teacher): ?>
                            <tr>
                                <td><?php echo esc_html($teacher->teacher_id); ?></td>
                                <td><?php echo esc_html($teacher->first_name . ' ' . $teacher->last_name); ?></td>
                                <td><?php echo esc_html($teacher->email); ?></td>
                                <td><?php echo esc_html($teacher->department); ?></td>
                                <td><?php echo esc_html(ucfirst($teacher->status)); ?></td>
                                <td>
                                    <button class="button button-secondary edit-teacher" data-id="<?php echo $teacher->id; ?>">
                                        <?php _e('Edit', 'vira-school'); ?>
                                    </button>
                                    <button class="button button-link-delete delete-teacher" data-id="<?php echo $teacher->id; ?>">
                                        <?php _e('Delete', 'vira-school'); ?>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6"><?php _e('No teachers found.', 'vira-school'); ?></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }
    
    /**
     * Handle add teacher form submission
     */
    private function handle_add_teacher() {
        global $wpdb;
        
        $teacher_data = array(
            'teacher_id' => sanitize_text_field($_POST['teacher_id']),
            'first_name' => sanitize_text_field($_POST['first_name']),
            'last_name' => sanitize_text_field($_POST['last_name']),
            'email' => sanitize_email($_POST['email']),
            'phone' => sanitize_text_field($_POST['phone']),
            'department' => sanitize_text_field($_POST['department']),
            'qualification' => sanitize_textarea_field($_POST['qualification']),
            'hire_date' => sanitize_text_field($_POST['hire_date'])
        );
        
        $result = $wpdb->insert(
            $wpdb->prefix . 'vira_teachers',
            $teacher_data
        );
        
        if ($result !== false) {
            echo '<div class="notice notice-success"><p>' . __('Teacher added successfully!', 'vira-school') . '</p></div>';
        } else {
            echo '<div class="notice notice-error"><p>' . __('Error adding teacher. Please try again.', 'vira-school') . '</p></div>';
        }
    }
    
    /**
     * Classes page
     */
    public function admin_page_classes() {
        global $wpdb;
        
        // Handle form submission
        if (isset($_POST['action']) && $_POST['action'] === 'add_class' && wp_verify_nonce($_POST['_wpnonce'], 'vira_school_add_class')) {
            $this->handle_add_class();
        }
        
        // Get classes with teacher names
        $classes = $wpdb->get_results(
            "SELECT c.*, t.first_name, t.last_name 
             FROM {$wpdb->prefix}vira_classes c 
             LEFT JOIN {$wpdb->prefix}vira_teachers t ON c.teacher_id = t.id 
             ORDER BY c.created_at DESC"
        );
        
        // Get teachers for dropdown
        $teachers = $wpdb->get_results("SELECT id, first_name, last_name FROM {$wpdb->prefix}vira_teachers WHERE status = 'active'");
        
        ?>
        <div class="wrap">
            <h1><?php _e('Classes Management', 'vira-school'); ?></h1>
            
            <form method="post" class="class-form">
                <?php wp_nonce_field('vira_school_add_class'); ?>
                <input type="hidden" name="action" value="add_class">
                
                <table class="form-table">
                    <tr>
                        <th><label for="class_name"><?php _e('Class Name', 'vira-school'); ?></label></th>
                        <td><input type="text" id="class_name" name="class_name" required placeholder="e.g., Grade 10A"></td>
                    </tr>
                    <tr>
                        <th><label for="class_code"><?php _e('Class Code', 'vira-school'); ?></label></th>
                        <td><input type="text" id="class_code" name="class_code" required placeholder="e.g., G10A"></td>
                    </tr>
                    <tr>
                        <th><label for="description"><?php _e('Description', 'vira-school'); ?></label></th>
                        <td><textarea id="description" name="description" rows="3" cols="50"></textarea></td>
                    </tr>
                    <tr>
                        <th><label for="teacher_id"><?php _e('Class Teacher', 'vira-school'); ?></label></th>
                        <td>
                            <select id="teacher_id" name="teacher_id">
                                <option value=""><?php _e('Select Teacher', 'vira-school'); ?></option>
                                <?php foreach ($teachers as $teacher): ?>
                                    <option value="<?php echo $teacher->id; ?>">
                                        <?php echo esc_html($teacher->first_name . ' ' . $teacher->last_name); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="max_students"><?php _e('Max Students', 'vira-school'); ?></label></th>
                        <td><input type="number" id="max_students" name="max_students" value="30" min="1" max="100"></td>
                    </tr>
                    <tr>
                        <th><label for="academic_year"><?php _e('Academic Year', 'vira-school'); ?></label></th>
                        <td><input type="text" id="academic_year" name="academic_year" placeholder="e.g., 2024-2025"></td>
                    </tr>
                </table>
                
                <?php submit_button(__('Add Class', 'vira-school')); ?>
            </form>
            
            <hr>
            
            <h2><?php _e('Classes List', 'vira-school'); ?></h2>
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e('Class Code', 'vira-school'); ?></th>
                        <th><?php _e('Class Name', 'vira-school'); ?></th>
                        <th><?php _e('Class Teacher', 'vira-school'); ?></th>
                        <th><?php _e('Max Students', 'vira-school'); ?></th>
                        <th><?php _e('Academic Year', 'vira-school'); ?></th>
                        <th><?php _e('Status', 'vira-school'); ?></th>
                        <th><?php _e('Actions', 'vira-school'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($classes)): ?>
                        <?php foreach ($classes as $class): ?>
                            <tr>
                                <td><?php echo esc_html($class->class_code); ?></td>
                                <td><?php echo esc_html($class->class_name); ?></td>
                                <td><?php echo esc_html($class->first_name . ' ' . $class->last_name); ?></td>
                                <td><?php echo esc_html($class->max_students); ?></td>
                                <td><?php echo esc_html($class->academic_year); ?></td>
                                <td><?php echo esc_html(ucfirst($class->status)); ?></td>
                                <td>
                                    <button class="button button-secondary edit-class" data-id="<?php echo $class->id; ?>">
                                        <?php _e('Edit', 'vira-school'); ?>
                                    </button>
                                    <button class="button button-link-delete delete-class" data-id="<?php echo $class->id; ?>">
                                        <?php _e('Delete', 'vira-school'); ?>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7"><?php _e('No classes found.', 'vira-school'); ?></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }
    
    /**
     * Handle add class form submission
     */
    private function handle_add_class() {
        global $wpdb;
        
        $class_data = array(
            'class_name' => sanitize_text_field($_POST['class_name']),
            'class_code' => sanitize_text_field($_POST['class_code']),
            'description' => sanitize_textarea_field($_POST['description']),
            'teacher_id' => !empty($_POST['teacher_id']) ? intval($_POST['teacher_id']) : null,
            'max_students' => intval($_POST['max_students']),
            'academic_year' => sanitize_text_field($_POST['academic_year'])
        );
        
        $result = $wpdb->insert(
            $wpdb->prefix . 'vira_classes',
            $class_data
        );
        
        if ($result !== false) {
            echo '<div class="notice notice-success"><p>' . __('Class added successfully!', 'vira-school') . '</p></div>';
        } else {
            echo '<div class="notice notice-error"><p>' . __('Error adding class. Please try again.', 'vira-school') . '</p></div>';
        }
    }
    
    /**
     * Courses page
     */
    public function admin_page_courses() {
        global $wpdb;
        
        // Handle form submission
        if (isset($_POST['action']) && $_POST['action'] === 'add_course' && wp_verify_nonce($_POST['_wpnonce'], 'vira_school_add_course')) {
            $this->handle_add_course();
        }
        
        // Get courses with teacher and class names
        $courses = $wpdb->get_results(
            "SELECT c.*, t.first_name as teacher_first, t.last_name as teacher_last, cl.class_name
             FROM {$wpdb->prefix}vira_courses c 
             LEFT JOIN {$wpdb->prefix}vira_teachers t ON c.teacher_id = t.id 
             LEFT JOIN {$wpdb->prefix}vira_classes cl ON c.class_id = cl.id 
             ORDER BY c.created_at DESC"
        );
        
        // Get teachers and classes for dropdowns
        $teachers = $wpdb->get_results("SELECT id, first_name, last_name FROM {$wpdb->prefix}vira_teachers WHERE status = 'active'");
        $classes = $wpdb->get_results("SELECT id, class_name, class_code FROM {$wpdb->prefix}vira_classes WHERE status = 'active'");
        
        ?>
        <div class="wrap">
            <h1><?php _e('Courses Management', 'vira-school'); ?></h1>
            
            <form method="post" class="course-form">
                <?php wp_nonce_field('vira_school_add_course'); ?>
                <input type="hidden" name="action" value="add_course">
                
                <table class="form-table">
                    <tr>
                        <th><label for="course_name"><?php _e('Course Name', 'vira-school'); ?></label></th>
                        <td><input type="text" id="course_name" name="course_name" required placeholder="e.g., Mathematics"></td>
                    </tr>
                    <tr>
                        <th><label for="course_code"><?php _e('Course Code', 'vira-school'); ?></label></th>
                        <td><input type="text" id="course_code" name="course_code" required placeholder="e.g., MATH101"></td>
                    </tr>
                    <tr>
                        <th><label for="description"><?php _e('Description', 'vira-school'); ?></label></th>
                        <td><textarea id="description" name="description" rows="3" cols="50"></textarea></td>
                    </tr>
                    <tr>
                        <th><label for="credits"><?php _e('Credits', 'vira-school'); ?></label></th>
                        <td><input type="number" id="credits" name="credits" value="1" min="1" max="10"></td>
                    </tr>
                    <tr>
                        <th><label for="teacher_id"><?php _e('Teacher', 'vira-school'); ?></label></th>
                        <td>
                            <select id="teacher_id" name="teacher_id">
                                <option value=""><?php _e('Select Teacher', 'vira-school'); ?></option>
                                <?php foreach ($teachers as $teacher): ?>
                                    <option value="<?php echo $teacher->id; ?>">
                                        <?php echo esc_html($teacher->first_name . ' ' . $teacher->last_name); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="class_id"><?php _e('Class', 'vira-school'); ?></label></th>
                        <td>
                            <select id="class_id" name="class_id">
                                <option value=""><?php _e('Select Class', 'vira-school'); ?></option>
                                <?php foreach ($classes as $class): ?>
                                    <option value="<?php echo $class->id; ?>">
                                        <?php echo esc_html($class->class_name . ' (' . $class->class_code . ')'); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="schedule_day"><?php _e('Schedule Day', 'vira-school'); ?></label></th>
                        <td>
                            <select id="schedule_day" name="schedule_day">
                                <option value=""><?php _e('Select Day', 'vira-school'); ?></option>
                                <option value="Monday"><?php _e('Monday', 'vira-school'); ?></option>
                                <option value="Tuesday"><?php _e('Tuesday', 'vira-school'); ?></option>
                                <option value="Wednesday"><?php _e('Wednesday', 'vira-school'); ?></option>
                                <option value="Thursday"><?php _e('Thursday', 'vira-school'); ?></option>
                                <option value="Friday"><?php _e('Friday', 'vira-school'); ?></option>
                                <option value="Saturday"><?php _e('Saturday', 'vira-school'); ?></option>
                                <option value="Sunday"><?php _e('Sunday', 'vira-school'); ?></option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="schedule_time"><?php _e('Schedule Time', 'vira-school'); ?></label></th>
                        <td><input type="time" id="schedule_time" name="schedule_time"></td>
                    </tr>
                    <tr>
                        <th><label for="duration"><?php _e('Duration (minutes)', 'vira-school'); ?></label></th>
                        <td><input type="number" id="duration" name="duration" value="60" min="30" max="180"></td>
                    </tr>
                </table>
                
                <?php submit_button(__('Add Course', 'vira-school')); ?>
            </form>
            
            <hr>
            
            <h2><?php _e('Courses List', 'vira-school'); ?></h2>
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e('Course Code', 'vira-school'); ?></th>
                        <th><?php _e('Course Name', 'vira-school'); ?></th>
                        <th><?php _e('Teacher', 'vira-school'); ?></th>
                        <th><?php _e('Class', 'vira-school'); ?></th>
                        <th><?php _e('Credits', 'vira-school'); ?></th>
                        <th><?php _e('Schedule', 'vira-school'); ?></th>
                        <th><?php _e('Status', 'vira-school'); ?></th>
                        <th><?php _e('Actions', 'vira-school'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($courses)): ?>
                        <?php foreach ($courses as $course): ?>
                            <tr>
                                <td><?php echo esc_html($course->course_code); ?></td>
                                <td><?php echo esc_html($course->course_name); ?></td>
                                <td><?php echo esc_html($course->teacher_first . ' ' . $course->teacher_last); ?></td>
                                <td><?php echo esc_html($course->class_name); ?></td>
                                <td><?php echo esc_html($course->credits); ?></td>
                                <td>
                                    <?php if ($course->schedule_day && $course->schedule_time): ?>
                                        <?php echo esc_html($course->schedule_day . ' ' . date('g:i A', strtotime($course->schedule_time))); ?>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo esc_html(ucfirst($course->status)); ?></td>
                                <td>
                                    <button class="button button-secondary edit-course" data-id="<?php echo $course->id; ?>">
                                        <?php _e('Edit', 'vira-school'); ?>
                                    </button>
                                    <button class="button button-link-delete delete-course" data-id="<?php echo $course->id; ?>">
                                        <?php _e('Delete', 'vira-school'); ?>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8"><?php _e('No courses found.', 'vira-school'); ?></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }
    
    /**
     * Handle add course form submission
     */
    private function handle_add_course() {
        global $wpdb;
        
        $course_data = array(
            'course_name' => sanitize_text_field($_POST['course_name']),
            'course_code' => sanitize_text_field($_POST['course_code']),
            'description' => sanitize_textarea_field($_POST['description']),
            'credits' => intval($_POST['credits']),
            'teacher_id' => !empty($_POST['teacher_id']) ? intval($_POST['teacher_id']) : null,
            'class_id' => !empty($_POST['class_id']) ? intval($_POST['class_id']) : null,
            'schedule_day' => sanitize_text_field($_POST['schedule_day']),
            'schedule_time' => sanitize_text_field($_POST['schedule_time']),
            'duration' => intval($_POST['duration'])
        );
        
        $result = $wpdb->insert(
            $wpdb->prefix . 'vira_courses',
            $course_data
        );
        
        if ($result !== false) {
            echo '<div class="notice notice-success"><p>' . __('Course added successfully!', 'vira-school') . '</p></div>';
        } else {
            echo '<div class="notice notice-error"><p>' . __('Error adding course. Please try again.', 'vira-school') . '</p></div>';
        }
    }
    
    /**
     * Attendance page
     */
    public function admin_page_attendance() {
        global $wpdb;
        
        // Get current date
        $current_date = current_time('Y-m-d');
        
        // Get courses and classes for filters
        $courses = $wpdb->get_results("SELECT id, course_name, course_code FROM {$wpdb->prefix}vira_courses WHERE status = 'active'");
        $classes = $wpdb->get_results("SELECT id, class_name, class_code FROM {$wpdb->prefix}vira_classes WHERE status = 'active'");
        
        ?>
        <div class="wrap">
            <h1><?php _e('Attendance Management', 'vira-school'); ?></h1>
            
            <div class="attendance-filters">
                <form method="get" style="margin-bottom: 20px;">
                    <input type="hidden" name="page" value="vira-school-attendance">
                    <label for="attendance_date"><?php _e('Date:', 'vira-school'); ?></label>
                    <input type="date" id="attendance_date" name="date" value="<?php echo esc_attr($_GET['date'] ?? $current_date); ?>">
                    
                    <label for="course_filter"><?php _e('Course:', 'vira-school'); ?></label>
                    <select id="course_filter" name="course_id">
                        <option value=""><?php _e('Select Course', 'vira-school'); ?></option>
                        <?php foreach ($courses as $course): ?>
                            <option value="<?php echo $course->id; ?>" <?php selected($_GET['course_id'] ?? '', $course->id); ?>>
                                <?php echo esc_html($course->course_name . ' (' . $course->course_code . ')'); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    
                    <label for="class_filter"><?php _e('Class:', 'vira-school'); ?></label>
                    <select id="class_filter" name="class_id">
                        <option value=""><?php _e('Select Class', 'vira-school'); ?></option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?php echo $class->id; ?>" <?php selected($_GET['class_id'] ?? '', $class->id); ?>>
                                <?php echo esc_html($class->class_name . ' (' . $class->class_code . ')'); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    
                    <?php submit_button(__('Filter', 'vira-school'), 'secondary', 'filter', false); ?>
                </form>
            </div>
            
            <?php if (!empty($_GET['course_id']) || !empty($_GET['class_id'])): ?>
                <div class="attendance-taking">
                    <h2><?php _e('Take Attendance', 'vira-school'); ?></h2>
                    <p><?php _e('Select students and mark their attendance for the selected date and course/class.', 'vira-school'); ?></p>
                    
                    <!-- Attendance form would go here -->
                    <p><em><?php _e('Full attendance functionality will be implemented in the next update.', 'vira-school'); ?></em></p>
                </div>
            <?php else: ?>
                <div class="notice notice-info">
                    <p><?php _e('Please select a course or class to take attendance.', 'vira-school'); ?></p>
                </div>
            <?php endif; ?>
            
            <hr>
            
            <h2><?php _e('Recent Attendance Records', 'vira-school'); ?></h2>
            
            <?php
            // Get recent attendance records
            $recent_attendance = $wpdb->get_results(
                "SELECT a.*, s.first_name, s.last_name, s.student_id as student_number, c.course_name
                 FROM {$wpdb->prefix}vira_attendance a
                 JOIN {$wpdb->prefix}vira_students s ON a.student_id = s.id
                 JOIN {$wpdb->prefix}vira_courses c ON a.course_id = c.id
                 ORDER BY a.attendance_date DESC, a.created_at DESC
                 LIMIT 50"
            );
            ?>
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e('Date', 'vira-school'); ?></th>
                        <th><?php _e('Student', 'vira-school'); ?></th>
                        <th><?php _e('Course', 'vira-school'); ?></th>
                        <th><?php _e('Status', 'vira-school'); ?></th>
                        <th><?php _e('Notes', 'vira-school'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($recent_attendance)): ?>
                        <?php foreach ($recent_attendance as $record): ?>
                            <tr>
                                <td><?php echo esc_html($record->attendance_date); ?></td>
                                <td><?php echo esc_html($record->first_name . ' ' . $record->last_name . ' (' . $record->student_number . ')'); ?></td>
                                <td><?php echo esc_html($record->course_name); ?></td>
                                <td class="status-<?php echo esc_attr($record->status); ?>">
                                    <?php echo esc_html(ucfirst($record->status)); ?>
                                </td>
                                <td><?php echo esc_html($record->notes); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5"><?php _e('No attendance records found.', 'vira-school'); ?></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }
    
    /**
     * Reports page
     */
    public function admin_page_reports() {
        global $wpdb;
        
        // Get report data with null checks
        $student_stats = $wpdb->get_row(
            "SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
                SUM(CASE WHEN status = 'inactive' THEN 1 ELSE 0 END) as inactive,
                SUM(CASE WHEN status = 'graduated' THEN 1 ELSE 0 END) as graduated
             FROM {$wpdb->prefix}vira_students"
        );
        
        // Add fallback values if query fails
        if (!$student_stats) {
            $student_stats = (object) array(
                'total' => 0,
                'active' => 0,
                'inactive' => 0,
                'graduated' => 0
            );
        }
        
        $teacher_stats = $wpdb->get_row(
            "SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
                COUNT(DISTINCT department) as departments
             FROM {$wpdb->prefix}vira_teachers"
        );
        
        if (!$teacher_stats) {
            $teacher_stats = (object) array(
                'total' => 0,
                'active' => 0,
                'departments' => 0
            );
        }
        
        $attendance_stats = $wpdb->get_row(
            "SELECT 
                COUNT(*) as total_records,
                SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) as present,
                SUM(CASE WHEN status = 'absent' THEN 1 ELSE 0 END) as absent,
                SUM(CASE WHEN status = 'late' THEN 1 ELSE 0 END) as late
             FROM {$wpdb->prefix}vira_attendance
             WHERE attendance_date >= DATE_SUB(CURRENT_DATE, INTERVAL 30 DAY)"
        );
        
        if (!$attendance_stats) {
            $attendance_stats = (object) array(
                'total_records' => 0,
                'present' => 0,
                'absent' => 0,
                'late' => 0
            );
        }
        
        // Recent enrollments with null check
        $recent_students = $wpdb->get_results(
            "SELECT first_name, last_name, student_id, enrollment_date 
             FROM {$wpdb->prefix}vira_students 
             ORDER BY enrollment_date DESC 
             LIMIT 10"
        );
        
        if (!$recent_students) {
            $recent_students = array();
        }
        
        // Class sizes with null check
        $class_sizes = $wpdb->get_results(
            "SELECT c.class_name, c.max_students, COUNT(s.id) as current_students
             FROM {$wpdb->prefix}vira_classes c
             LEFT JOIN {$wpdb->prefix}vira_students s ON c.id = s.class_id AND s.status = 'active'
             WHERE c.status = 'active'
             GROUP BY c.id
             ORDER BY c.class_name"
        );
        
        if (!$class_sizes) {
            $class_sizes = array();
        }
        
        ?>
        <div class="wrap">
                        
            <div class="vira-reports-grid">
                <!-- Student Statistics -->
                <div class="report-section">
                    <h2><?php _e('Student Statistics', 'vira-school'); ?></h2>
                    <div class="stats-grid">
                        <div class="stat-item">
                            <span class="stat-number"><?php echo esc_html($student_stats->total ?: 0); ?></span>
                            <span class="stat-label"><?php _e('Total Students', 'vira-school'); ?></span>
                        </div>
                        <div class="stat-item active">
                            <span class="stat-number"><?php echo esc_html($student_stats->active ?: 0); ?></span>
                            <span class="stat-label"><?php _e('Active', 'vira-school'); ?></span>
                        </div>
                        <div class="stat-item inactive">
                            <span class="stat-number"><?php echo esc_html($student_stats->inactive ?: 0); ?></span>
                            <span class="stat-label"><?php _e('Inactive', 'vira-school'); ?></span>
                        </div>
                        <div class="stat-item graduated">
                            <span class="stat-number"><?php echo esc_html($student_stats->graduated ?: 0); ?></span>
                            <span class="stat-label"><?php _e('Graduated', 'vira-school'); ?></span>
                        </div>
                    </div>
                </div>
                
                <!-- Teacher Statistics -->
                <div class="report-section">
                    <h2><?php _e('Teacher Statistics', 'vira-school'); ?></h2>
                    <div class="stats-grid">
                        <div class="stat-item">
                            <span class="stat-number"><?php echo esc_html($teacher_stats->total ?: 0); ?></span>
                            <span class="stat-label"><?php _e('Total Teachers', 'vira-school'); ?></span>
                        </div>
                        <div class="stat-item active">
                            <span class="stat-number"><?php echo esc_html($teacher_stats->active ?: 0); ?></span>
                            <span class="stat-label"><?php _e('Active Teachers', 'vira-school'); ?></span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-number"><?php echo esc_html($teacher_stats->departments ?: 0); ?></span>
                            <span class="stat-label"><?php _e('Departments', 'vira-school'); ?></span>
                        </div>
                    </div>
                </div>
                
                <!-- Attendance Statistics (Last 30 Days) -->
                <div class="report-section">
                    <h2><?php _e('Attendance (Last 30 Days)', 'vira-school'); ?></h2>
                    <div class="stats-grid">
                        <div class="stat-item">
                            <span class="stat-number"><?php echo esc_html($attendance_stats->total_records ?: 0); ?></span>
                            <span class="stat-label"><?php _e('Total Records', 'vira-school'); ?></span>
                        </div>
                        <div class="stat-item present">
                            <span class="stat-number"><?php echo esc_html($attendance_stats->present ?: 0); ?></span>
                            <span class="stat-label"><?php _e('Present', 'vira-school'); ?></span>
                        </div>
                        <div class="stat-item absent">
                            <span class="stat-number"><?php echo esc_html($attendance_stats->absent ?: 0); ?></span>
                            <span class="stat-label"><?php _e('Absent', 'vira-school'); ?></span>
                        </div>
                        <div class="stat-item late">
                            <span class="stat-number"><?php echo esc_html($attendance_stats->late ?: 0); ?></span>
                            <span class="stat-label"><?php _e('Late', 'vira-school'); ?></span>
                        </div>
                    </div>
                    <?php if ($attendance_stats->total_records > 0): ?>
                        <div class="attendance-percentage">
                            <?php 
                            $attendance_rate = ($attendance_stats->present / $attendance_stats->total_records) * 100;
                            ?>
                            <p><strong><?php _e('Attendance Rate:', 'vira-school'); ?></strong> 
                            <span class="<?php echo $attendance_rate >= 90 ? 'good' : ($attendance_rate >= 75 ? 'average' : 'poor'); ?>">
                                <?php echo number_format($attendance_rate, 1); ?>%
                            </span></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="reports-tables">
                <!-- Recent Enrollments -->
                <div class="report-table-section">
                    <h2><?php _e('Recent Enrollments', 'vira-school'); ?></h2>
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th><?php _e('Student ID', 'vira-school'); ?></th>
                                <th><?php _e('Name', 'vira-school'); ?></th>
                                <th><?php _e('Enrollment Date', 'vira-school'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($recent_students)): ?>
                                <?php foreach ($recent_students as $student): ?>
                                    <tr>
                                        <td><?php echo esc_html($student->student_id); ?></td>
                                        <td><?php echo esc_html($student->first_name . ' ' . $student->last_name); ?></td>
                                        <td><?php echo esc_html(date('M j, Y', strtotime($student->enrollment_date))); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="3"><?php _e('No recent enrollments found.', 'vira-school'); ?></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Class Capacity Report -->
                <div class="report-table-section">
                    <h2><?php _e('Class Capacity Report', 'vira-school'); ?></h2>
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th><?php _e('Class Name', 'vira-school'); ?></th>
                                <th><?php _e('Current Students', 'vira-school'); ?></th>
                                <th><?php _e('Max Capacity', 'vira-school'); ?></th>
                                <th><?php _e('Utilization', 'vira-school'); ?></th>
                                <th><?php _e('Available Spots', 'vira-school'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($class_sizes)): ?>
                                <?php foreach ($class_sizes as $class): ?>
                                    <?php 
                                    $utilization = $class->max_students > 0 ? ($class->current_students / $class->max_students) * 100 : 0;
                                    $available = $class->max_students - $class->current_students;
                                    ?>
                                    <tr>
                                        <td><?php echo esc_html($class->class_name); ?></td>
                                        <td><?php echo esc_html($class->current_students); ?></td>
                                        <td><?php echo esc_html($class->max_students); ?></td>
                                        <td>
                                            <span class="utilization <?php echo $utilization >= 90 ? 'high' : ($utilization >= 70 ? 'medium' : 'low'); ?>">
                                                <?php echo number_format($utilization, 1); ?>%
                                            </span>
                                        </td>
                                        <td class="<?php echo $available <= 0 ? 'full' : 'available'; ?>">
                                            <?php echo esc_html($available); ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5"><?php _e('No classes found.', 'vira-school'); ?></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- Export Options -->
            <div class="export-section">
                <h2><?php _e('Export Data', 'vira-school'); ?></h2>
                <p><?php _e('Export functionality for detailed reports will be available in future updates.', 'vira-school'); ?></p>
                <div class="export-buttons">
                    <button class="button button-secondary" disabled>
                        <span class="dashicons dashicons-download"></span> <?php _e('Export Students (CSV)', 'vira-school'); ?>
                    </button>
                    <button class="button button-secondary" disabled>
                        <span class="dashicons dashicons-download"></span> <?php _e('Export Attendance (CSV)', 'vira-school'); ?>
                    </button>
                    <button class="button button-secondary" disabled>
                        <span class="dashicons dashicons-chart-bar"></span> <?php _e('Detailed Report (PDF)', 'vira-school'); ?>
                    </button>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Settings page
     */
    public function admin_page_settings() {
        // Handle form submission
        if (isset($_POST['submit'])) {
            check_admin_referer('vira_school_settings-options');
        }
        
        ?>
        <div class="wrap">
                       
            <form method="post" action="options.php">
                <?php
                settings_fields('vira_school_settings');
                do_settings_sections('vira_school_settings');
                submit_button(__('Save Settings', 'vira-school'));
                ?>
            </form>
        </div>
        <?php
    }
    
    /**
     * Student Portal page
     */
    public function admin_page_student_portal() {
        global $wpdb;
        
        // Check if Student Portal is enabled in settings
        $options = get_option('vira_school_options');
        if (empty($options['student_portal_enabled'])) {
            echo '<div class="wrap"><h1>' . __('Student Portal', 'vira-school') . '</h1>';
            echo '<div class="notice notice-warning"><p>' . __('Student Portal is currently disabled. Enable it in Settings.', 'vira-school') . '</p></div>';
            echo '</div>';
            return;
        }
        
        // Check if user is admin or a student
        $current_user = wp_get_current_user();
        $is_admin = current_user_can('manage_options');
        
        $student = null;
        if ($is_admin) {
            // Admin can view demo or select a student
            $student_id = isset($_GET['student_id']) ? intval($_GET['student_id']) : null;
            if ($student_id) {
                $student = $wpdb->get_row($wpdb->prepare(
                    "SELECT * FROM {$wpdb->prefix}vira_students WHERE id = %d",
                    $student_id
                ));
            } else {
                // Show admin options to select a student
                $this->show_admin_student_portal_selection();
                return;
            }
        } else {
            // Regular user - check if they are a student
            $student = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}vira_students WHERE email = %s AND status = 'active'",
                $current_user->user_email
            ));
        }
        
        if (!$student) {
            echo '<div class="wrap"><h1>' . __('Student Portal', 'vira-school') . '</h1>';
            if ($is_admin) {
                echo '<p>' . __('No student found with the specified ID.', 'vira-school') . '</p>';
            } else {
                echo '<p>' . __('Access denied. You are not registered as an active student.', 'vira-school') . '</p>';
            }
            echo '</div>';
            return;
        }
        
        // Get student's classes and courses
        $student_courses = $wpdb->get_results($wpdb->prepare(
            "SELECT c.*, t.first_name as teacher_first, t.last_name as teacher_last, cl.class_name
             FROM {$wpdb->prefix}vira_courses c
             LEFT JOIN {$wpdb->prefix}vira_teachers t ON c.teacher_id = t.id
             LEFT JOIN {$wpdb->prefix}vira_classes cl ON c.class_id = cl.id
             WHERE c.class_id = %d AND c.status = 'active'
             ORDER BY c.course_name",
            $student->class_id
        ));
        
        // Get attendance records
        $attendance_records = $wpdb->get_results($wpdb->prepare(
            "SELECT a.*, c.course_name, c.course_code
             FROM {$wpdb->prefix}vira_attendance a
             JOIN {$wpdb->prefix}vira_courses c ON a.course_id = c.id
             WHERE a.student_id = %d
             ORDER BY a.attendance_date DESC
             LIMIT 20",
            $student->id
        ));
        
        ?>
        <div class="wrap vira-student-portal">
            <h1><?php echo sprintf(__('Welcome, %s %s', 'vira-school'), esc_html($student->first_name), esc_html($student->last_name)); ?></h1>
            
            <div class="student-info-cards">
                <div class="info-card">
                    <h3><?php _e('Student Information', 'vira-school'); ?></h3>
                    <p><strong><?php _e('Student ID:', 'vira-school'); ?></strong> <?php echo esc_html($student->student_id); ?></p>
                    <p><strong><?php _e('Email:', 'vira-school'); ?></strong> <?php echo esc_html($student->email); ?></p>
                    <p><strong><?php _e('Phone:', 'vira-school'); ?></strong> <?php echo esc_html($student->phone); ?></p>
                    <p><strong><?php _e('Status:', 'vira-school'); ?></strong> <span class="status-<?php echo esc_attr($student->status); ?>"><?php echo esc_html(ucfirst($student->status)); ?></span></p>
                </div>
                
                <div class="info-card">
                    <h3><?php _e('Quick Stats', 'vira-school'); ?></h3>
                    <p><strong><?php _e('Total Courses:', 'vira-school'); ?></strong> <?php echo count($student_courses); ?></p>
                    <p><strong><?php _e('Attendance Records:', 'vira-school'); ?></strong> <?php echo count($attendance_records); ?></p>
                    <?php if (!empty($attendance_records)): ?>
                        <?php
                        $present_count = array_filter($attendance_records, function($record) { return $record->status === 'present'; });
                        $attendance_rate = (count($present_count) / count($attendance_records)) * 100;
                        ?>
                        <p><strong><?php _e('Attendance Rate:', 'vira-school'); ?></strong> 
                        <span class="<?php echo $attendance_rate >= 90 ? 'good' : ($attendance_rate >= 75 ? 'average' : 'poor'); ?>">
                            <?php echo number_format($attendance_rate, 1); ?>%
                        </span></p>
                    <?php endif; ?>
                </div>
            </div>
            
            <h2><?php _e('My Courses', 'vira-school'); ?></h2>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e('Course Code', 'vira-school'); ?></th>
                        <th><?php _e('Course Name', 'vira-school'); ?></th>
                        <th><?php _e('Teacher', 'vira-school'); ?></th>
                        <th><?php _e('Schedule', 'vira-school'); ?></th>
                        <th><?php _e('Credits', 'vira-school'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($student_courses)): ?>
                        <?php foreach ($student_courses as $course): ?>
                            <tr>
                                <td><?php echo esc_html($course->course_code); ?></td>
                                <td><?php echo esc_html($course->course_name); ?></td>
                                <td><?php echo esc_html($course->teacher_first . ' ' . $course->teacher_last); ?></td>
                                <td>
                                    <?php if ($course->schedule_day && $course->schedule_time): ?>
                                        <?php echo esc_html($course->schedule_day . ' ' . date('g:i A', strtotime($course->schedule_time))); ?>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo esc_html($course->credits); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5"><?php _e('No courses found.', 'vira-school'); ?></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            
            <h2><?php _e('Recent Attendance', 'vira-school'); ?></h2>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e('Date', 'vira-school'); ?></th>
                        <th><?php _e('Course', 'vira-school'); ?></th>
                        <th><?php _e('Status', 'vira-school'); ?></th>
                        <th><?php _e('Notes', 'vira-school'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($attendance_records)): ?>
                        <?php foreach ($attendance_records as $record): ?>
                            <tr>
                                <td><?php echo esc_html(date('M j, Y', strtotime($record->attendance_date))); ?></td>
                                <td><?php echo esc_html($record->course_name . ' (' . $record->course_code . ')'); ?></td>
                                <td class="status-<?php echo esc_attr($record->status); ?>">
                                    <?php echo esc_html(ucfirst($record->status)); ?>
                                </td>
                                <td><?php echo esc_html($record->notes); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4"><?php _e('No attendance records found.', 'vira-school'); ?></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }
    
    /**
     * General settings section callback
     */
    public function general_settings_callback() {
        echo '<p>' . __('Configure general settings for Vira School Management System.', 'vira-school') . '</p>';
    }
    
    /**
     * School name setting callback
     */
    public function school_name_callback() {
        $options = get_option('vira_school_options', array());
        $value = isset($options['school_name']) ? $options['school_name'] : '';
        echo '<input type="text" id="school_name" name="vira_school_options[school_name]" value="' . esc_attr($value) . '" class="regular-text" />';
        echo '<p class="description">' . __('Enter your school name.', 'vira-school') . '</p>';
    }
    
    /**
     * School address setting callback
     */
    public function school_address_callback() {
        $options = get_option('vira_school_options', array());
        $value = isset($options['school_address']) ? $options['school_address'] : '';
        echo '<textarea id="school_address" name="vira_school_options[school_address]" rows="3" cols="50">' . esc_textarea($value) . '</textarea>';
        echo '<p class="description">' . __('Enter your school address.', 'vira-school') . '</p>';
    }
    
    /**
     * Academic year setting callback
     */
    public function academic_year_callback() {
        $options = get_option('vira_school_options', array());
        $value = isset($options['academic_year']) ? $options['academic_year'] : date('Y') . '-' . (date('Y') + 1);
        echo '<input type="text" id="academic_year" name="vira_school_options[academic_year]" value="' . esc_attr($value) . '" class="regular-text" />';
        echo '<p class="description">' . __('Current academic year (e.g., 2024-2025).', 'vira-school') . '</p>';
    }
    
    /**
     * Student portal setting callback
     */
    public function student_portal_callback() {
        $options = get_option('vira_school_options', array());
        $value = isset($options['student_portal_enabled']) ? $options['student_portal_enabled'] : false;
        echo '<input type="checkbox" id="student_portal_enabled" name="vira_school_options[student_portal_enabled]" value="1" ' . checked($value, true, false) . ' />';
        echo '<label for="student_portal_enabled">' . __('Enable student portal access', 'vira-school') . '</label>';
        echo '<p class="description">' . __('Allow students to view their information and attendance records.', 'vira-school') . '</p>';
    }
    
    /**
     * AJAX handler for adding students
     */
    public function ajax_add_student() {
        // Check nonce for security
        check_ajax_referer('vira_school_admin_nonce', 'nonce');
        
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'vira-school'));
        }
        
        // Sanitize and validate input data
        $student_data = array(
            'student_id' => sanitize_text_field($_POST['student_id']),
            'first_name' => sanitize_text_field($_POST['first_name']),
            'last_name' => sanitize_text_field($_POST['last_name']),
            'email' => sanitize_email($_POST['email']),
            'phone' => sanitize_text_field($_POST['phone']),
            'date_of_birth' => sanitize_text_field($_POST['date_of_birth']),
            'status' => 'active'
        );
        
        // Insert student into database
        global $wpdb;
        $result = $wpdb->insert(
            $wpdb->prefix . 'vira_students',
            $student_data
        );
        
        if ($result !== false) {
            wp_send_json_success(array(
                'message' => __('Student added successfully!', 'vira-school'),
                'student_id' => $wpdb->insert_id
            ));
        } else {
            wp_send_json_error(array(
                'message' => __('Error adding student. Please try again.', 'vira-school')
            ));
        }
    }

    /**
     * AJAX handler for editing students
     */
    public function ajax_edit_student() {
        // Check nonce for security
        check_ajax_referer('vira_school_admin_nonce', 'nonce');
        
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'vira-school'));
        }
        
        // Get student ID
        $student_id = intval($_POST['student_id']);
        
        // Sanitize and validate input data
        $student_data = array(
            'student_id' => sanitize_text_field($_POST['student_id']),
            'first_name' => sanitize_text_field($_POST['first_name']),
            'last_name' => sanitize_text_field($_POST['last_name']),
            'email' => sanitize_email($_POST['email']),
            'phone' => sanitize_text_field($_POST['phone']),
            'date_of_birth' => sanitize_text_field($_POST['date_of_birth'])
        );
        
        // Update student in database
        global $wpdb;
        $result = $wpdb->update(
            $wpdb->prefix . 'vira_students',
            $student_data,
            array('id' => $student_id)
        );
        
        if ($result !== false) {
            wp_send_json_success(array(
                'message' => __('Student updated successfully!', 'vira-school')
            ));
        } else {
            wp_send_json_error(array(
                'message' => __('Error updating student. Please try again.', 'vira-school')
            ));
        }
    }
    
    /**
     * AJAX handler for deleting students
     */
    public function ajax_delete_student() {
        // Check nonce for security
        check_ajax_referer('vira_school_admin_nonce', 'nonce');
        
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'vira-school'));
        }
        
        // Get student ID
        $student_id = intval($_POST['student_id']);
        
        // Delete student from database
        global $wpdb;
        $result = $wpdb->delete(
            $wpdb->prefix . 'vira_students',
            array('id' => $student_id)
        );
        
        if ($result !== false) {
            wp_send_json_success(array(
                'message' => __('Student deleted successfully!', 'vira-school')
            ));
        } else {
            wp_send_json_error(array(
                'message' => __('Error deleting student. Please try again.', 'vira-school')
            ));
        }
    }
    
    /**
     * AJAX handler for adding teachers
     */
    public function ajax_add_teacher() {
        // Check nonce for security
        check_ajax_referer('vira_school_admin_nonce', 'nonce');
        
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'vira-school'));
        }
        
        // Sanitize and validate input data
        $teacher_data = array(
            'teacher_id' => sanitize_text_field($_POST['teacher_id']),
            'first_name' => sanitize_text_field($_POST['first_name']),
            'last_name' => sanitize_text_field($_POST['last_name']),
            'email' => sanitize_email($_POST['email']),
            'phone' => sanitize_text_field($_POST['phone']),
            'department' => sanitize_text_field($_POST['department']),
            'qualification' => sanitize_textarea_field($_POST['qualification']),
            'hire_date' => sanitize_text_field($_POST['hire_date']),
            'status' => 'active'
        );
        
        // Insert teacher into database
        global $wpdb;
        $result = $wpdb->insert(
            $wpdb->prefix . 'vira_teachers',
            $teacher_data
        );
        
        if ($result !== false) {
            wp_send_json_success(array(
                'message' => __('Teacher added successfully!', 'vira-school'),
                'teacher_id' => $wpdb->insert_id
            ));
        } else {
            wp_send_json_error(array(
                'message' => __('Error adding teacher. Please try again.', 'vira-school')
            ));
        }
    }

    /**
     * AJAX handler for editing teachers
     */
    public function ajax_edit_teacher() {
        // Check nonce for security
        check_ajax_referer('vira_school_admin_nonce', 'nonce');
        
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'vira-school'));
        }
        
        // Get teacher ID
        $teacher_id = intval($_POST['teacher_id']);
        
        // Sanitize and validate input data
        $teacher_data = array(
            'teacher_id' => sanitize_text_field($_POST['teacher_id']),
            'first_name' => sanitize_text_field($_POST['first_name']),
            'last_name' => sanitize_text_field($_POST['last_name']),
            'email' => sanitize_email($_POST['email']),
            'phone' => sanitize_text_field($_POST['phone']),
            'department' => sanitize_text_field($_POST['department']),
            'qualification' => sanitize_textarea_field($_POST['qualification']),
            'hire_date' => sanitize_text_field($_POST['hire_date'])
        );
        
        // Update teacher in database
        global $wpdb;
        $result = $wpdb->update(
            $wpdb->prefix . 'vira_teachers',
            $teacher_data,
            array('id' => $teacher_id)
        );
        
        if ($result !== false) {
            wp_send_json_success(array(
                'message' => __('Teacher updated successfully!', 'vira-school')
            ));
        } else {
            wp_send_json_error(array(
                'message' => __('Error updating teacher. Please try again.', 'vira-school')
            ));
        }
    }
    
    /**
     * AJAX handler for deleting teachers
     */
    public function ajax_delete_teacher() {
        // Check nonce for security
        check_ajax_referer('vira_school_admin_nonce', 'nonce');
        
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'vira-school'));
        }
        
        // Get teacher ID
        $teacher_id = intval($_POST['teacher_id']);
        
        // Delete teacher from database
        global $wpdb;
        $result = $wpdb->delete(
            $wpdb->prefix . 'vira_teachers',
            array('id' => $teacher_id)
        );
        
        if ($result !== false) {
            wp_send_json_success(array(
                'message' => __('Teacher deleted successfully!', 'vira-school')
            ));
        } else {
            wp_send_json_error(array(
                'message' => __('Error deleting teacher. Please try again.', 'vira-school')
            ));
        }
    }
    
    /**
     * AJAX handler for adding courses
     */
    public function ajax_add_course() {
        // Check nonce for security
        check_ajax_referer('vira_school_admin_nonce', 'nonce');
        
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'vira-school'));
        }
        
        // Sanitize and validate input data
        $course_data = array(
            'course_name' => sanitize_text_field($_POST['course_name']),
            'course_code' => sanitize_text_field($_POST['course_code']),
            'description' => sanitize_textarea_field($_POST['description']),
            'credits' => intval($_POST['credits']),
            'status' => 'active'
        );
        
        // Insert course into database
        global $wpdb;
        $result = $wpdb->insert(
            $wpdb->prefix . 'vira_courses',
            $course_data
        );
        
        if ($result !== false) {
            wp_send_json_success(array(
                'message' => __('Course added successfully!', 'vira-school'),
                'course_id' => $wpdb->insert_id
            ));
        } else {
            wp_send_json_error(array(
                'message' => __('Error adding course. Please try again.', 'vira-school')
            ));
        }
    }

    /**
     * AJAX handler for editing courses
     */
    public function ajax_edit_course() {
        // Check nonce for security
        check_ajax_referer('vira_school_admin_nonce', 'nonce');
        
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'vira-school'));
        }
        
        // Get course ID
        $course_id = intval($_POST['course_id']);
        
        // Sanitize and validate input data
        $course_data = array(
            'course_name' => sanitize_text_field($_POST['course_name']),
            'course_code' => sanitize_text_field($_POST['course_code']),
            'description' => sanitize_textarea_field($_POST['description']),
            'credits' => intval($_POST['credits'])
        );
        
        // Update course in database
        global $wpdb;
        $result = $wpdb->update(
            $wpdb->prefix . 'vira_courses',
            $course_data,
            array('id' => $course_id)
        );
        
        if ($result !== false) {
            wp_send_json_success(array(
                'message' => __('Course updated successfully!', 'vira-school')
            ));
        } else {
            wp_send_json_error(array(
                'message' => __('Error updating course. Please try again.', 'vira-school')
            ));
        }
    }
    
    /**
     * AJAX handler for deleting courses
     */
    public function ajax_delete_course() {
        // Check nonce for security
        check_ajax_referer('vira_school_admin_nonce', 'nonce');
        
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'vira-school'));
        }
        
        // Get course ID
        $course_id = intval($_POST['course_id']);
        
        // Delete course from database
        global $wpdb;
        $result = $wpdb->delete(
            $wpdb->prefix . 'vira_courses',
            array('id' => $course_id)
        );
        
        if ($result !== false) {
            wp_send_json_success(array(
                'message' => __('Course deleted successfully!', 'vira-school')
            ));
        } else {
            wp_send_json_error(array(
                'message' => __('Error deleting course. Please try again.', 'vira-school')
            ));
        }
    }
    
    /**
     * AJAX handler for adding classes
     */
    public function ajax_add_class() {
        // Check nonce for security
        check_ajax_referer('vira_school_admin_nonce', 'nonce');
        
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'vira-school'));
        }
        
        // Sanitize and validate input data
        $class_data = array(
            'class_name' => sanitize_text_field($_POST['class_name']),
            'class_code' => sanitize_text_field($_POST['class_code']),
            'description' => sanitize_textarea_field($_POST['description']),
            'teacher_id' => !empty($_POST['teacher_id']) ? intval($_POST['teacher_id']) : null,
            'max_students' => intval($_POST['max_students']),
            'academic_year' => sanitize_text_field($_POST['academic_year']),
            'status' => 'active'
        );
        
        // Insert class into database
        global $wpdb;
        $result = $wpdb->insert(
            $wpdb->prefix . 'vira_classes',
            $class_data
        );
        
        if ($result !== false) {
            wp_send_json_success(array(
                'message' => __('Class added successfully!', 'vira-school'),
                'class_id' => $wpdb->insert_id
            ));
        } else {
            wp_send_json_error(array(
                'message' => __('Error adding class. Please try again.', 'vira-school')
            ));
        }
    }
    
    /**
     * AJAX handler for editing classes
     */
    public function ajax_edit_class() {
        // Check nonce for security
        check_ajax_referer('vira_school_admin_nonce', 'nonce');
        
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'vira-school'));
        }
        
        // Get class ID
        $class_id = intval($_POST['class_id']);
        
        // Sanitize and validate input data
        $class_data = array(
            'class_name' => sanitize_text_field($_POST['class_name']),
            'class_code' => sanitize_text_field($_POST['class_code']),
            'description' => sanitize_textarea_field($_POST['description']),
            'teacher_id' => !empty($_POST['teacher_id']) ? intval($_POST['teacher_id']) : null,
            'max_students' => intval($_POST['max_students']),
            'academic_year' => sanitize_text_field($_POST['academic_year'])
        );
        
        // Update class in database
        global $wpdb;
        $result = $wpdb->update(
            $wpdb->prefix . 'vira_classes',
            $class_data,
            array('id' => $class_id)
        );
        
        if ($result !== false) {
            wp_send_json_success(array(
                'message' => __('Class updated successfully!', 'vira-school')
            ));
        } else {
            wp_send_json_error(array(
                'message' => __('Error updating class. Please try again.', 'vira-school')
            ));
        }
    }
    
    /**
     * AJAX handler for deleting classes
     */
    public function ajax_delete_class() {
        // Check nonce for security
        check_ajax_referer('vira_school_admin_nonce', 'nonce');
        
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'vira-school'));
        }
        
        // Get class ID
        $class_id = intval($_POST['class_id']);
        
        // Delete class from database
        global $wpdb;
        $result = $wpdb->delete(
            $wpdb->prefix . 'vira_classes',
            array('id' => $class_id)
        );
        
        if ($result !== false) {
            wp_send_json_success(array(
                'message' => __('Class deleted successfully!', 'vira-school')
            ));
        } else {
            wp_send_json_error(array(
                'message' => __('Error deleting class. Please try again.', 'vira-school')
            ));
        }
    }
    
    /**
     * Show admin options to select a student for portal preview
     */
    private function show_admin_student_portal_selection() {
        global $wpdb;
        
        $students = $wpdb->get_results(
            "SELECT id, student_id, first_name, last_name, email, status 
             FROM {$wpdb->prefix}vira_students 
             WHERE status = 'active' 
             ORDER BY first_name, last_name"
        );
        
        ?>
        <div class="wrap">
            <h1><?php _e('Student Portal - Admin Preview', 'vira-school'); ?></h1>
            
            <div class="notice notice-info">
                <p><?php _e('As an administrator, you can preview the student portal by selecting a student below.', 'vira-school'); ?></p>
            </div>
            
            <?php if (!empty($students)): ?>
                <h2><?php _e('Select a Student to Preview Portal', 'vira-school'); ?></h2>
                
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php _e('Student ID', 'vira-school'); ?></th>
                            <th><?php _e('Name', 'vira-school'); ?></th>
                            <th><?php _e('Email', 'vira-school'); ?></th>
                            <th><?php _e('Action', 'vira-school'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($students as $student): ?>
                            <tr>
                                <td><?php echo esc_html($student->student_id); ?></td>
                                <td><?php echo esc_html($student->first_name . ' ' . $student->last_name); ?></td>
                                <td><?php echo esc_html($student->email); ?></td>
                                <td>
                                    <a href="<?php echo admin_url('admin.php?page=vira-school-portal&student_id=' . $student->id); ?>" 
                                       class="button button-primary">
                                        <?php _e('View Portal', 'vira-school'); ?>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="notice notice-warning">
                    <p><?php _e('No active students found. Please add students first.', 'vira-school'); ?></p>
                    <p><a href="<?php echo admin_url('admin.php?page=vira-school-students'); ?>" class="button button-secondary">
                        <?php _e('Add Students', 'vira-school'); ?>
                    </a></p>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }
}
