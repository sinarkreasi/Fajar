<?php
/**
 * Student management class for Vira School
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class ViraSchool_Student {
    
    /**
     * Get all students
     */
    public static function get_all_students($status = 'all') {
        global $wpdb;
        
        $where = '';
        if ($status !== 'all') {
            $where = $wpdb->prepare("WHERE status = %s", $status);
        }
        
        return $wpdb->get_results("SELECT * FROM {$wpdb->prefix}vira_students $where ORDER BY created_at DESC");
    }
    
    /**
     * Get student by ID
     */
    public static function get_student($id) {
        global $wpdb;
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}vira_students WHERE id = %d",
            $id
        ));
    }
    
    /**
     * Get student by student ID
     */
    public static function get_student_by_student_id($student_id) {
        global $wpdb;
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}vira_students WHERE student_id = %s",
            $student_id
        ));
    }
    
    /**
     * Add new student
     */
    public static function add_student($data) {
        global $wpdb;
        
        $defaults = array(
            'status' => 'active',
            'enrollment_date' => current_time('mysql')
        );
        
        $data = wp_parse_args($data, $defaults);
        
        return $wpdb->insert(
            $wpdb->prefix . 'vira_students',
            $data
        );
    }
    
    /**
     * Update student
     */
    public static function update_student($id, $data) {
        global $wpdb;
        
        return $wpdb->update(
            $wpdb->prefix . 'vira_students',
            $data,
            array('id' => $id)
        );
    }
    
    /**
     * Delete student
     */
    public static function delete_student($id) {
        global $wpdb;
        
        return $wpdb->delete(
            $wpdb->prefix . 'vira_students',
            array('id' => $id)
        );
    }
    
    /**
     * Get students count
     */
    public static function get_students_count($status = 'active') {
        global $wpdb;
        
        return $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}vira_students WHERE status = %s",
            $status
        ));
    }
}
