<?php
/**
 * Main Vira School Plugin Class
 */
class ViraSchoolPlugin {

    /**
     * Constructor
     */
    public function __construct() {
        
        add_action('plugins_loaded', array($this, 'init'));
    }

    /**
     * Initialize the plugin
     */
    public function init() {
        // Load text domain for internationalization
        load_plugin_textdomain('vira-school', false, dirname(plugin_basename(VIRA_SCHOOL_PLUGIN_FILE)) . '/languages');

        // Include required files
        $this->includes();

        // Initialize hooks
        $this->init_hooks();
    }

    /**
     * Include required files
     */
    private function includes() {
        require_once VIRA_SCHOOL_PLUGIN_PATH . 'includes/class-database.php';
        require_once VIRA_SCHOOL_PLUGIN_PATH . 'includes/class-student.php';
        require_once VIRA_SCHOOL_PLUGIN_PATH . 'includes/class-course.php';
        require_once VIRA_SCHOOL_PLUGIN_PATH . 'includes/class-attendance.php';
        require_once VIRA_SCHOOL_PLUGIN_PATH . 'includes/class-admin.php';
        require_once VIRA_SCHOOL_PLUGIN_PATH . 'includes/class-frontend.php';
        require_once VIRA_SCHOOL_PLUGIN_PATH . 'includes/class-shortcodes.php';
    }

    /**
     * Initialize hooks
     */
    private function init_hooks() {
        register_activation_hook(VIRA_SCHOOL_PLUGIN_FILE, array($this, 'activate'));
        register_deactivation_hook(VIRA_SCHOOL_PLUGIN_FILE, array($this, 'deactivate'));
        
        add_action('init', array($this, 'init_classes'));
        
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));
    }

    /**
     * Initialize plugin classes
     */
    public function init_classes() {
        
        static $admin_initialized = false;
        if (is_admin() && !$admin_initialized) {
            new ViraSchool_Admin();
            $admin_initialized = true;
        }
        new ViraSchool_Frontend();
        new ViraSchool_Shortcodes();
        
    }

    /**
     * Enqueue frontend scripts and styles
     */
    public function enqueue_scripts() {
        // Enqueue basic frontend styles and scripts
        wp_enqueue_style('vira-school-style', VIRA_SCHOOL_PLUGIN_URL . 'assets/css/frontend.css', array(), VIRA_SCHOOL_VERSION);
        wp_enqueue_script('vira-school-script', VIRA_SCHOOL_PLUGIN_URL . 'assets/js/frontend.js', array('jquery'), VIRA_SCHOOL_VERSION, true);
        
        // Also enqueue the frontend-style.css which is used by shortcodes
        wp_enqueue_style('vira-school-frontend-style', VIRA_SCHOOL_PLUGIN_URL . 'assets/css/frontend-style.css', array(), VIRA_SCHOOL_VERSION);
        wp_enqueue_script('vira-school-frontend-script', VIRA_SCHOOL_PLUGIN_URL . 'assets/js/frontend-script.js', array('jquery'), VIRA_SCHOOL_VERSION, true);
        
        wp_localize_script('vira-school-script', 'vira_school_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('vira_school_nonce')
        ));
        
        // Also localize the frontend-script if needed
        wp_localize_script('vira-school-frontend-script', 'vira_school_frontend', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('vira_school_frontend_nonce')
        ));
    }

    /**
     * Enqueue admin scripts and styles
     */
    public function admin_enqueue_scripts() {
        // Admin styles
        wp_enqueue_style('vira-school-admin-style', VIRA_SCHOOL_PLUGIN_URL . 'assets/css/admin.css', array(), VIRA_SCHOOL_VERSION);
        
        // Admin scripts
        wp_enqueue_script('vira-school-admin-script', VIRA_SCHOOL_PLUGIN_URL . 'assets/js/admin.js', array('jquery'), VIRA_SCHOOL_VERSION, true);
        
        // Localize admin script with AJAX URL
        wp_localize_script('vira-school-admin-script', 'vira_school_admin_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('vira_school_admin_nonce')
        ));
    }

    /**
     * Plugin activation
     */
    public function activate() {
        $database = new ViraSchool_Database();
        $database->create_tables();
        
        // Create default capabilities
        $this->create_capabilities();
        
        flush_rewrite_rules();
        $this->add_custom_roles();
    }

    /**
     * Plugin deactivation
     */
    public function deactivate() {
        flush_rewrite_rules();
        $this->remove_custom_roles();
    }

    /**
     * Create custom capabilities
     */
    private function create_capabilities() {
        $admin_role = get_role('administrator');
        $capabilities = array(
            'manage_students',
            'manage_courses',
            'manage_attendance',
            'view_reports'
        );

        foreach ($capabilities as $capability) {
            $admin_role->add_cap($capability);
        }
    }

    /**
     * Add custom user roles
     */
    private function add_custom_roles() {
        add_role(
            'vira_teacher',
            __('Teacher', 'vira-school'),
            array(
                'read'         => true,
                'edit_posts'   => true,
                'upload_files' => true,
            )
        );
        add_role(
            'vira_student',
            __('Student', 'vira-school'),
            array(
                'read' => true,
            )
        );
        add_role(
            'vira_parent',
            __('Parent', 'vira-school'),
            array(
                'read' => true,
            )
        );
    }

    /**
     * Remove custom user roles
     */
    private function remove_custom_roles() {
        remove_role('vira_teacher');
        remove_role('vira_student');
        remove_role('vira_parent');
    }
}

// Initialize the plugin
new ViraSchoolPlugin();