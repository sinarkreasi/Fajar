<?php
/**
 * Shortcodes class for Vira School
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class ViraSchool_Shortcodes {
    
    /**
     * Constructor
     */
    public function __construct() {
        

        add_shortcode('vira_school', array($this, 'render_portal'));
        add_shortcode('vira_test', array($this, 'test_shortcode')); // Debug test
        add_shortcode('vira_student_profile', array($this, 'student_profile_shortcode'));
        add_shortcode('vira_student_attendance', array($this, 'student_attendance_shortcode'));
        add_shortcode('vira_students_list', array($this, 'students_list_shortcode'));
        

        // Enqueue frontend assets when shortcode is used
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_assets'));
    }
    
    /**
     * Debug test shortcode
     */
    public function test_shortcode($atts) {
        return '<div style="background: red; color: white; padding: 20px;">VIRA SCHOOL PLUGIN IS WORKING! Shortcode system is active.</div>';
    }
    
    /**
     * Student profile shortcode
     * Usage: [vira_student_profile student_id="STUDENT123"]
     */
    public function student_profile_shortcode($atts) {
        $atts = shortcode_atts(array(
            'student_id' => ''
        ), $atts);
        
        if (empty($atts['student_id'])) {
            return '<p>' . __('Student ID is required.', 'vira-school') . '</p>';
        }
        
        return ViraSchool_Frontend::display_student_profile($atts['student_id']);
    }
    
    /**
     * Student attendance shortcode
     * Usage: [vira_student_attendance student_id="STUDENT123" course_id="1"]
     */
    public function student_attendance_shortcode($atts) {
        $atts = shortcode_atts(array(
            'student_id' => '',
            'course_id' => null
        ), $atts);
        
        if (empty($atts['student_id'])) {
            return '<p>' . __('Student ID is required.', 'vira-school') . '</p>';
        }
        
        return ViraSchool_Frontend::display_student_attendance($atts['student_id'], $atts['course_id']);
    }
    
    /**
     * Students list shortcode
     * Usage: [vira_students_list status="active" limit="10"]
     */
    public function students_list_shortcode($atts) {
        $atts = shortcode_atts(array(
            'status' => 'active',
            'limit' => 10
        ), $atts);
        
        $students = ViraSchool_Student::get_all_students($atts['status']);
        
        if (empty($students)) {
            return '<p>' . __('No students found.', 'vira-school') . '</p>';
        }
        
        // Limit results
        $students = array_slice($students, 0, intval($atts['limit']));
        
        ob_start();
        ?>
        <div class="vira-school-students-list">
            <table class="students-table">
                <thead>
                    <tr>
                        <th><?php _e('Student ID', 'vira-school'); ?></th>
                        <th><?php _e('Name', 'vira-school'); ?></th>
                        <th><?php _e('Email', 'vira-school'); ?></th>
                        <th><?php _e('Status', 'vira-school'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($students as $student): ?>
                        <tr>
                            <td><?php echo esc_html($student->student_id); ?></td>
                            <td><?php echo esc_html($student->first_name . ' ' . $student->last_name); ?></td>
                            <td><?php echo esc_html($student->email); ?></td>
                            <td><?php echo esc_html(ucfirst($student->status)); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Enqueue frontend assets
     */
    public function enqueue_frontend_assets() {
        // Check if we're on a page that uses any of our shortcodes
        global $post;
        
        // Always enqueue - this ensures assets are available when needed
        // The previous conditional check was too restrictive
        wp_enqueue_style(
            'vira-school-frontend',
            plugin_dir_url(dirname(__FILE__)) . 'assets/css/frontend-style.css',
            array(),
            '1.0.0'
        );
        
        wp_enqueue_script(
            'vira-school-frontend',
            plugin_dir_url(dirname(__FILE__)) . 'assets/js/frontend-script.js',
            array('jquery'),
            '1.0.0',
            true
        );
    }
    
    /**
     * Render the portal shortcode
     */
    public function render_portal($atts = array()) {
        // Parse attributes
        $atts = shortcode_atts(array(
            'type' => 'auto', // auto, student, teacher, parent
            'class' => '',
            'style' => 'cards' // cards, list, minimal
        ), $atts);
        
        if (!is_user_logged_in()) {
            return $this->render_login_form();
        }
        
        $current_user = wp_get_current_user();
        $user_type = $this->determine_user_type($current_user, $atts['type']);

        // If a specific type is requested in the shortcode and it doesn't match the user's determined type,
        // or if the user type is 'auto' and no specific portal can be determined, deny access.
        if ($atts['type'] !== 'auto' && $atts['type'] !== $user_type) {
            return $this->render_access_denied();
        }

        switch ($user_type) {
            case 'student':
                return $this->render_student_portal($current_user, $atts);
            case 'teacher':
                return $this->render_teacher_portal($current_user, $atts);
            case 'parent':
                return $this->render_parent_portal($current_user, $atts);
            case 'admin':
                return $this->render_admin_portal($current_user, $atts);
            default:
                // If user_type is 'auto' and no specific role is matched, deny access.
                return $this->render_access_denied();
        }
    }
    
    /**
     * Determine user type based on database records and roles
     */
    private function determine_user_type($user, $force_type = 'auto') {
        global $wpdb;
        
        if ($force_type !== 'auto') {
            return $force_type;
        }
        
        // Check if user is admin
        if (user_can($user, 'manage_options')) {
            return 'admin';
        }
        
        // Check if user is a student
        $student = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}vira_students WHERE email = %s AND status = 'active'",
            $user->user_email
        ));
        
        if ($student) {
            return 'student';
        }
        
        // Check if user is a teacher
        $teacher = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}vira_teachers WHERE email = %s AND status = 'active'",
            $user->user_email
        ));
        
        if ($teacher) {
            return 'teacher';
        }
        
        // Check if user is a parent (assuming parent_email field in students table)
        $parent_student = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}vira_students WHERE parent_email = %s AND status = 'active'",
            $user->user_email
        ));
        
        if ($parent_student) {
            return 'parent';
        }
        
        return 'none';
    }
    
    /**
     * Render login form
     */
    private function render_login_form() {
        ob_start();
        ?>
        <div class="vira-school-portal login-required">
            <div class="portal-card welcome-card">
                <div class="card-header">
                    <h2><?php _e('🎓 Welcome to Vira School Portal', 'vira-school'); ?></h2>
                </div>
                <div class="card-content">
                    <p class="welcome-message"><?php _e('Please log in to access your personalized school portal.', 'vira-school'); ?></p>
                    
                    <div class="login-options">
                        <a href="<?php echo wp_login_url(get_permalink()); ?>" class="portal-button primary">
                            <span class="dashicons dashicons-unlock"></span>
                            <?php _e('Login to Portal', 'vira-school'); ?>
                        </a>
                    </div>
                    
                    <div class="portal-features">
                        <h4><?php _e('Portal Features:', 'vira-school'); ?></h4>
                        <ul class="feature-list">
                            <li>👨‍🎓 <?php _e('Student Dashboard & Grades', 'vira-school'); ?></li>
                            <li>👨‍🏫 <?php _e('Teacher Class Management', 'vira-school'); ?></li>
                            <li>👨‍👩‍👧‍👦 <?php _e('Parent Progress Tracking', 'vira-school'); ?></li>
                            <li>📊 <?php _e('Attendance & Reports', 'vira-school'); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render access denied message
     */
    private function render_access_denied() {
        ob_start();
        ?>
        <div class="vira-school-portal access-denied">
            <div class="portal-card error-card">
                <div class="card-header">
                    <h3>
                        <span class="card-icon">🚫</span>
                        <?php _e('Access Denied', 'vira-school'); ?>
                    </h3>
                </div>
                <div class="card-content">
                    <p><?php _e('Sorry, you don\'t have access to the school portal. Please contact the school administration if you believe this is an error.', 'vira-school'); ?></p>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    // ===== PORTAL RENDER METHODS =====
    
    private function render_student_portal($user, $atts) {
        global $wpdb;
        
        // Get student data
        $student = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}vira_students WHERE email = %s AND status = 'active'",
            $user->user_email
        ));
        
        if (!$student) {
            return $this->render_access_denied();
        }
        
        // Get student courses
        $courses = $this->get_student_courses($student->id);
        
        // Get attendance summary
        $attendance_summary = ViraSchool_Attendance::get_attendance_stats($student->id);
        $attendance_records = $this->get_student_attendance($student->id);
        
        ob_start();
        ?>
        <div class="vira-school-portal student-portal <?php echo esc_attr($atts['class']); ?>">
            <div class="portal-header">
                <h1 class="portal-welcome">
                    <?php echo sprintf(__('Welcome back, %s! 🎓', 'vira-school'), esc_html($student->first_name)); ?>
                </h1>
                <p class="portal-subtitle"><?php _e('Your learning journey continues here', 'vira-school'); ?></p>
            </div>
            
            <div class="portal-grid">
                <!-- Student Info Card -->
                <div class="portal-card student-info">
                    <div class="card-header">
                        <h3>
                            <span class="card-icon">👨‍🎓</span>
                            <?php _e('Student Information', 'vira-school'); ?>
                        </h3>
                    </div>
                    <div class="card-content">
                        <div class="info-item">
                            <strong><?php _e('Student ID:', 'vira-school'); ?></strong>
                            <span class="info-value"><?php echo esc_html($student->student_id); ?></span>
                        </div>
                        <div class="info-item">
                            <strong><?php _e('Email:', 'vira-school'); ?></strong>
                            <span class="info-value"><?php echo esc_html($student->email); ?></span>
                        </div>
                        <div class="info-item">
                            <strong><?php _e('Phone:', 'vira-school'); ?></strong>
                            <span class="info-value"><?php echo esc_html($student->phone); ?></span>
                        </div>
                        <div class="info-item">
                            <strong><?php _e('Date of Birth:', 'vira-school'); ?></strong>
                            <span class="info-value"><?php echo esc_html($student->date_of_birth); ?></span>
                        </div>
                        <div class="info-item">
                            <strong><?php _e('Status:', 'vira-school'); ?></strong>
                            <span class="status-badge status-<?php echo esc_attr($student->status); ?>">
                                <?php echo esc_html(ucfirst($student->status)); ?>
                            </span>
                        </div>
                    </div>
                </div>
                
                <!-- Quick Stats -->
                <div class="portal-card quick-stats">
                    <div class="card-header">
                        <h3>
                            <span class="card-icon">📊</span>
                            <?php _e('Quick Stats', 'vira-school'); ?>
                        </h3>
                    </div>
                    <div class="card-content">
                        <div class="stat-grid">
                            <div class="stat-item">
                                <div class="stat-number"><?php echo count($courses); ?></div>
                                <div class="stat-label"><?php _e('Courses', 'vira-school'); ?></div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-number"><?php echo $attendance_summary ? $attendance_summary->total_days : 0; ?></div>
                                <div class="stat-label"><?php _e('Attendance Records', 'vira-school'); ?></div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-number"><?php echo $this->calculate_attendance_rate($attendance_records); ?>%</div>
                                <div class="stat-label"><?php _e('Attendance Rate', 'vira-school'); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- My Courses -->
                <div class="portal-card courses-card full-width">
                    <div class="card-header">
                        <h3>
                            <span class="card-icon">📚</span>
                            <?php _e('My Courses', 'vira-school'); ?>
                        </h3>
                    </div>
                    <div class="card-content">
                        <?php if (!empty($courses)): ?>
                            <div class="courses-grid">
                                <?php foreach ($courses as $course): ?>
                                    <div class="course-item">
                                        <div class="course-header">
                                            <h4><?php echo esc_html($course->course_name); ?></h4>
                                        </div>
                                        <div class="course-details">
                                            <!-- Add course details here if available -->
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="empty-state">
                                <p><?php _e('No courses assigned.', 'vira-school'); ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Recent Attendance -->
                <div class="portal-card attendance-card full-width">
                    <div class="card-header">
                        <h3>
                            <span class="card-icon">✅</span>
                            <?php _e('Recent Attendance', 'vira-school'); ?>
                        </h3>
                    </div>
                    <div class="card-content">
                        <?php if (!empty($attendance_records)): ?>
                            <div class="attendance-list">
                                <?php foreach (array_slice($attendance_records, 0, 5) as $record): ?>
                                    <div class="attendance-item">
                                        <div class="attendance-date">
                                            <?php echo esc_html(date('M j, Y', strtotime($record->attendance_date))); ?>
                                        </div>
                                        <div class="attendance-course">
                                            <?php echo esc_html($record->course_name); ?>
                                        </div>
                                        <div class="attendance-status status-<?php echo esc_attr($record->status); ?>">
                                            <?php
                                            $status_icons = array(
                                                'present' => '✅',
                                                'absent' => '❌',
                                                'late' => '⏰',
                                                'excused' => '📝'
                                            );
                                            echo $status_icons[$record->status] ?? '❓';
                                            echo ' ' . esc_html(ucfirst($record->status));
                                            ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="empty-state">
                                <p><?php _e('No attendance records found.', 'vira-school'); ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    private function render_teacher_portal($user, $atts) {
        global $wpdb;
        
        // Get teacher data
        $teacher = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}vira_teachers WHERE email = %s AND status = 'active'",
            $user->user_email
        ));
        
        if (!$teacher) {
            return $this->render_access_denied();
        }
        
        // Get teacher courses
        $courses = ViraSchool_Course::get_all_courses();
        $classes = $this->get_teacher_classes($teacher->id);
        
        ob_start();
        ?>
        <div class="vira-school-portal teacher-portal <?php echo esc_attr($atts['class']); ?>">
            <div class="portal-header">
                <h1 class="portal-welcome">
                    <?php echo sprintf(__('Welcome, %s! 👨‍🏫', 'vira-school'), esc_html($teacher->first_name)); ?>
                </h1>
                <p class="portal-subtitle"><?php _e('Inspiring minds, shaping futures', 'vira-school'); ?></p>
            </div>
            
            <div class="portal-grid">
                <!-- Teacher Info -->
                <div class="portal-card teacher-info">
                    <div class="card-header">
                        <h3>
                            <span class="card-icon">👨‍🏫</span>
                            <?php _e('Teacher Information', 'vira-school'); ?>
                        </h3>
                    </div>
                    <div class="card-content">
                        <div class="info-item">
                            <strong><?php _e('Teacher ID:', 'vira-school'); ?></strong>
                            <span class="info-value"><?php echo esc_html($teacher->teacher_id); ?></span>
                        </div>
                        <div class="info-item">
                            <strong><?php _e('Name:', 'vira-school'); ?></strong>
                            <span class="info-value"><?php echo esc_html($teacher->first_name . ' ' . $teacher->last_name); ?></span>
                        </div>
                        <div class="info-item">
                            <strong><?php _e('Email:', 'vira-school'); ?></strong>
                            <span class="info-value"><?php echo esc_html($teacher->email); ?></span>
                        </div>
                        <div class="info-item">
                            <strong><?php _e('Phone:', 'vira-school'); ?></strong>
                            <span class="info-value"><?php echo esc_html($teacher->phone); ?></span>
                        </div>
                        <div class="info-item">
                            <strong><?php _e('Department:', 'vira-school'); ?></strong>
                            <span class="info-value"><?php echo esc_html($teacher->department); ?></span>
                        </div>
                        <div class="info-item">
                            <strong><?php _e('Status:', 'vira-school'); ?></strong>
                            <span class="status-badge status-<?php echo esc_attr($teacher->status); ?>">
                                <?php echo esc_html(ucfirst($teacher->status)); ?>
                            </span>
                        </div>
                    </div>
                </div>
                
                <!-- Teaching Stats -->
                <div class="portal-card teaching-stats">
                    <div class="card-header">
                        <h3>
                            <span class="card-icon">📈</span>
                            <?php _e('Teaching Overview', 'vira-school'); ?>
                        </h3>
                    </div>
                    <div class="card-content">
                        <div class="stat-grid">
                            <div class="stat-item">
                                <div class="stat-number"><?php echo count($courses); ?></div>
                                <div class="stat-label"><?php _e('Courses', 'vira-school'); ?></div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-number"><?php echo count($classes); ?></div>
                                <div class="stat-label"><?php _e('Classes', 'vira-school'); ?></div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-number"><?php echo $this->count_teacher_students($teacher->id); ?></div>
                                <div class="stat-label"><?php _e('Students', 'vira-school'); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- My Courses -->
                <div class="portal-card courses-card full-width">
                    <div class="card-header">
                        <h3>
                            <span class="card-icon">📚</span>
                            <?php _e('My Courses', 'vira-school'); ?>
                        </h3>
                    </div>
                    <div class="card-content">
                        <?php if (!empty($courses)): ?>
                            <div class="courses-grid">
                                <?php foreach ($courses as $course): ?>
                                    <div class="course-item teacher-course">
                                        <div class="course-header">
                                            <h4><?php echo esc_html($course->course_name); ?></h4>
                                            <span class="course-code"><?php echo esc_html($course->course_code); ?></span>
                                        </div>
                                        <div class="course-details">
                                            <p class="credits">
                                                <span class="dashicons dashicons-awards"></span>
                                                <?php echo sprintf(__('%d Credits', 'vira-school'), $course->credits); ?>
                                            </p>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="empty-state">
                                <p><?php _e('No courses assigned.', 'vira-school'); ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    private function render_parent_portal($user, $atts) {
        global $wpdb;
        
        // Get student data for parent
        $student = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}vira_students WHERE parent_email = %s AND status = 'active'",
            $user->user_email
        ));
        
        if (!$student) {
            return $this->render_access_denied();
        }
        
        // Get student attendance summary
        $attendance_summary = ViraSchool_Attendance::get_attendance_stats($student->id);
        $attendance_records = $this->get_student_attendance($student->id);
        $courses = $this->get_student_courses($student->id);
        
        ob_start();
        ?>
        <div class="vira-school-portal parent-portal <?php echo esc_attr($atts['class']); ?>">
            <div class="portal-header">
                <h1 class="portal-welcome">
                    <?php echo sprintf(__('Welcome, %s! 👨‍👩‍👧‍👦', 'vira-school'), esc_html($user->display_name)); ?>
                </h1>
                <p class="portal-subtitle"><?php _e('Stay connected with your child\'s education', 'vira-school'); ?></p>
            </div>
            
            <div class="portal-grid">
                <div class="portal-card child-card">
                    <div class="card-header">
                        <h3>
                            <span class="card-icon">👶</span>
                            <?php printf(__('Child: %s', 'vira-school'), esc_html($student->first_name . ' ' . $student->last_name)); ?>
                        </h3>
                    </div>
                    <div class="card-content">
                        <div class="child-stats">
                            <div class="stat-item">
                                <div class="stat-number"><?php echo count($courses); ?></div>
                                <div class="stat-label"><?php _e('Courses', 'vira-school'); ?></div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-number"><?php echo $attendance_summary ? $this->calculate_attendance_rate($attendance_records) : 0; ?>%</div>
                                <div class="stat-label"><?php _e('Attendance Rate', 'vira-school'); ?></div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-number"><?php echo $attendance_summary ? $attendance_summary->total_days : 0; ?></div>
                                <div class="stat-label"><?php _e('Total Days', 'vira-school'); ?></div>
                            </div>
                        </div>
                        <div class="child-info">
                            <p><strong><?php _e('Student ID:', 'vira-school'); ?></strong> <?php echo esc_html($student->student_id); ?></p>
                            <p><strong><?php _e('Email:', 'vira-school'); ?></strong> <?php echo esc_html($student->email); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    private function render_admin_portal($user, $atts) {
        // Get counts
        $students_count = ViraSchool_Student::get_students_count('active');
        $courses_count = ViraSchool_Course::get_all_courses('active');
        $courses_count = count($courses_count);
        
        ob_start();
        ?>
        <div class="vira-school-portal admin-portal <?php echo esc_attr($atts['class']); ?>">
            <div class="portal-header">
                <h1 class="portal-welcome">
                    <?php echo sprintf(__('Welcome, Administrator %s! 👨‍💼', 'vira-school'), esc_html($user->display_name)); ?>
                </h1>
                <p class="portal-subtitle"><?php _e('School management at your fingertips', 'vira-school'); ?></p>
            </div>
            
            <div class="portal-grid">
                <div class="portal-card widget-stats">
                    <div class="card-header">
                        <h3>
                            <span class="card-icon">📊</span>
                            <?php _e('Statistics', 'vira-school'); ?>
                        </h3>
                    </div>
                    <div class="card-content">
                        <div class="stat-grid">
                            <div class="stat-item">
                                <div class="stat-number"><?php echo esc_html($students_count); ?></div>
                                <div class="stat-label"><?php _e('Active Students', 'vira-school'); ?></div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-number"><?php echo esc_html($courses_count); ?></div>
                                <div class="stat-label"><?php _e('Active Courses', 'vira-school'); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="portal-card admin-actions full-width">
                    <div class="card-header">
                        <h3>
                            <span class="card-icon">🛠️</span>
                            <?php _e('Quick Actions', 'vira-school'); ?>
                        </h3>
                    </div>
                    <div class="card-content">
                        <div class="action-buttons">
                            <a href="<?php echo admin_url('admin.php?page=vira-school'); ?>" class="portal-button primary">
                                <span class="dashicons dashicons-dashboard"></span>
                                <?php _e('Admin Dashboard', 'vira-school'); ?>
                            </a>
                            <a href="<?php echo admin_url('admin.php?page=vira-school-students'); ?>" class="portal-button secondary">
                                <span class="dashicons dashicons-groups"></span>
                                <?php _e('Manage Students', 'vira-school'); ?>
                            </a>
                            <a href="<?php echo admin_url('admin.php?page=vira-school-teachers'); ?>" class="portal-button secondary">
                                <span class="dashicons dashicons-businessman"></span>
                                <?php _e('Manage Teachers', 'vira-school'); ?>
                            </a>
                            <a href="<?php echo admin_url('admin.php?page=vira-school-courses'); ?>" class="portal-button secondary">
                                <span class="dashicons dashicons-book-alt"></span>
                                <?php _e('Manage Courses', 'vira-school'); ?>
                            </a>
                            <a href="<?php echo admin_url('admin.php?page=vira-school-attendance'); ?>" class="portal-button secondary">
                                <span class="dashicons dashicons-yes"></span>
                                <?php _e('Manage Attendance', 'vira-school'); ?>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    // ===== HELPER METHODS =====
    
    private function get_student_courses($student_id) {
        global $wpdb;
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT DISTINCT c.* 
             FROM {$wpdb->prefix}vira_courses c
             JOIN {$wpdb->prefix}vira_attendance a ON c.id = a.course_id
             WHERE a.student_id = %d",
            $student_id
        ));
    }
    
    private function get_student_attendance($student_id) {
        return ViraSchool_Attendance::get_student_attendance_summary($student_id);
    }
    
    private function get_student_grades($student_id) {
        global $wpdb;
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT g.*, c.course_name
             FROM {$wpdb->prefix}vira_grades g
             JOIN {$wpdb->prefix}vira_courses c ON g.course_id = c.id
             WHERE g.student_id = %d
             ORDER BY g.grade_date DESC",
            $student_id
        ));
    }
    
    private function get_teacher_courses($teacher_id) {
        return ViraSchool_Course::get_all_courses();
    }
    
    private function get_teacher_classes($teacher_id) {
        global $wpdb;
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}vira_classes WHERE teacher_id = %d",
            $teacher_id
        ));
    }
    
    private function count_teacher_students($teacher_id) {
        global $wpdb;
        
        return $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(DISTINCT a.student_id)
             FROM {$wpdb->prefix}vira_attendance a
             JOIN {$wpdb->prefix}vira_courses c ON a.course_id = c.id
             WHERE c.teacher_id = %d",
            $teacher_id
        ));
    }
    
    private function get_student_class_name($class_id) {
        global $wpdb;
        
        $class = $wpdb->get_row($wpdb->prepare(
            "SELECT class_name FROM {$wpdb->prefix}vira_classes WHERE id = %d",
            $class_id
        ));
        
        return $class ? $class->class_name : __('No Class', 'vira-school');
    }
    
    private function calculate_attendance_rate($attendance_records) {
        if (empty($attendance_records)) {
            return 0;
        }
        
        $total = count($attendance_records);
        $present = 0;
        
        foreach ($attendance_records as $record) {
            if ($record->status == 'present' || $record->status == 'late') {
                $present++;
            }
        }
        
        return round(($present / $total) * 100, 2);
    }
}