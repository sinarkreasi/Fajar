<?php
/**
 * Attendance management class for Vira School
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class ViraSchool_Attendance {
    
    /**
     * Mark attendance
     */
    public static function mark_attendance($student_id, $course_id, $date, $status, $notes = '', $marked_by = null) {
        global $wpdb;
        
        if (!$marked_by) {
            $marked_by = get_current_user_id();
        }
        
        $data = array(
            'student_id' => $student_id,
            'course_id' => $course_id,
            'attendance_date' => $date,
            'status' => $status,
            'notes' => $notes,
            'marked_by' => $marked_by
        );
        
        // Check if attendance already exists for this date
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}vira_attendance 
             WHERE student_id = %d AND course_id = %d AND attendance_date = %s",
            $student_id, $course_id, $date
        ));
        
        if ($existing) {
            // Update existing record
            return $wpdb->update(
                $wpdb->prefix . 'vira_attendance',
                $data,
                array('id' => $existing->id)
            );
        } else {
            // Insert new record
            return $wpdb->insert(
                $wpdb->prefix . 'vira_attendance',
                $data
            );
        }
    }
    
    /**
     * Get attendance for a specific date and course
     */
    public static function get_attendance_by_course_date($course_id, $date) {
        global $wpdb;
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT a.*, s.first_name, s.last_name, s.student_id as student_number
             FROM {$wpdb->prefix}vira_attendance a
             JOIN {$wpdb->prefix}vira_students s ON a.student_id = s.id
             WHERE a.course_id = %d AND a.attendance_date = %s",
            $course_id, $date
        ));
    }
    
    /**
     * Get student attendance summary
     */
    public static function get_student_attendance_summary($student_id, $course_id = null, $start_date = null, $end_date = null) {
        global $wpdb;
        
        $where_conditions = array("a.student_id = %d");
        $params = array($student_id);
        
        if ($course_id) {
            $where_conditions[] = "a.course_id = %d";
            $params[] = $course_id;
        }
        
        if ($start_date) {
            $where_conditions[] = "a.attendance_date >= %s";
            $params[] = $start_date;
        }
        
        if ($end_date) {
            $where_conditions[] = "a.attendance_date <= %s";
            $params[] = $end_date;
        }
        
        $where_clause = implode(' AND ', $where_conditions);
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT a.*, c.course_name
             FROM {$wpdb->prefix}vira_attendance a
             JOIN {$wpdb->prefix}vira_courses c ON a.course_id = c.id
             WHERE $where_clause
             ORDER BY a.attendance_date DESC",
            $params
        ));
    }
    
    /**
     * Get attendance statistics
     */
    public static function get_attendance_stats($student_id, $course_id = null) {
        global $wpdb;
        
        $where_conditions = array("student_id = %d");
        $params = array($student_id);
        
        if ($course_id) {
            $where_conditions[] = "course_id = %d";
            $params[] = $course_id;
        }
        
        $where_clause = implode(' AND ', $where_conditions);
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT 
                COUNT(*) as total_days,
                SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) as present_days,
                SUM(CASE WHEN status = 'absent' THEN 1 ELSE 0 END) as absent_days,
                SUM(CASE WHEN status = 'late' THEN 1 ELSE 0 END) as late_days,
                SUM(CASE WHEN status = 'excused' THEN 1 ELSE 0 END) as excused_days
             FROM {$wpdb->prefix}vira_attendance
             WHERE $where_clause",
            $params
        ));
    }
}
