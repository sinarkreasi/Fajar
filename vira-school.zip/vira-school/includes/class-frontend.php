<?php
/**
 * Frontend functionality class for Vira School
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class ViraSchool_Frontend {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('init', array($this, 'init'));
    }
    
    /**
     * Initialize frontend functionality
     */
    public function init() {
        // Add any frontend-specific initialization here
    }
    
    /**
     * Display student profile
     */
    public static function display_student_profile($student_id) {
        $student = ViraSchool_Student::get_student_by_student_id($student_id);
        
        if (!$student) {
            return '<p>' . __('Student not found.', 'vira-school') . '</p>';
        }
        
        ob_start();
        ?>
        <div class="vira-school-student-profile">
            <h3><?php echo esc_html($student->first_name . ' ' . $student->last_name); ?></h3>
            <div class="student-info">
                <p><strong><?php _e('Student ID:', 'vira-school'); ?></strong> <?php echo esc_html($student->student_id); ?></p>
                <p><strong><?php _e('Email:', 'vira-school'); ?></strong> <?php echo esc_html($student->email); ?></p>
                <p><strong><?php _e('Phone:', 'vira-school'); ?></strong> <?php echo esc_html($student->phone); ?></p>
                <p><strong><?php _e('Date of Birth:', 'vira-school'); ?></strong> <?php echo esc_html($student->date_of_birth); ?></p>
                <p><strong><?php _e('Status:', 'vira-school'); ?></strong> <?php echo esc_html(ucfirst($student->status)); ?></p>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Display student attendance
     */
    public static function display_student_attendance($student_id, $course_id = null) {
        $student = ViraSchool_Student::get_student_by_student_id($student_id);
        
        if (!$student) {
            return '<p>' . __('Student not found.', 'vira-school') . '</p>';
        }
        
        $attendance = ViraSchool_Attendance::get_student_attendance_summary($student->id, $course_id);
        $stats = ViraSchool_Attendance::get_attendance_stats($student->id, $course_id);
        
        ob_start();
        ?>
        <div class="vira-school-attendance">
            <h3><?php _e('Attendance Summary', 'vira-school'); ?></h3>
            
            <?php if ($stats): ?>
                <div class="attendance-stats">
                    <div class="stat">
                        <strong><?php _e('Total Days:', 'vira-school'); ?></strong>
                        <?php echo esc_html($stats->total_days); ?>
                    </div>
                    <div class="stat">
                        <strong><?php _e('Present:', 'vira-school'); ?></strong>
                        <?php echo esc_html($stats->present_days); ?>
                    </div>
                    <div class="stat">
                        <strong><?php _e('Absent:', 'vira-school'); ?></strong>
                        <?php echo esc_html($stats->absent_days); ?>
                    </div>
                    <div class="stat">
                        <strong><?php _e('Late:', 'vira-school'); ?></strong>
                        <?php echo esc_html($stats->late_days); ?>
                    </div>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($attendance)): ?>
                <table class="attendance-table">
                    <thead>
                        <tr>
                            <th><?php _e('Date', 'vira-school'); ?></th>
                            <th><?php _e('Course', 'vira-school'); ?></th>
                            <th><?php _e('Status', 'vira-school'); ?></th>
                            <th><?php _e('Notes', 'vira-school'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($attendance as $record): ?>
                            <tr>
                                <td><?php echo esc_html($record->attendance_date); ?></td>
                                <td><?php echo esc_html($record->course_name); ?></td>
                                <td class="status-<?php echo esc_attr($record->status); ?>">
                                    <?php echo esc_html(ucfirst($record->status)); ?>
                                </td>
                                <td><?php echo esc_html($record->notes); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p><?php _e('No attendance records found.', 'vira-school'); ?></p>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }
}
