<?php
/**
 * Uninstall script for Vira School plugin
 * This file is executed when the plugin is deleted via the WordPress admin
 */

// If uninstall not called from WordPress, exit
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Include the database class
require_once plugin_dir_path(__FILE__) . 'includes/class-database.php';

// Remove all plugin data
vira_school_uninstall();

/**
 * Uninstall function
 */
function vira_school_uninstall() {
    global $wpdb;
    
    // Only proceed if user has the capability
    if (!current_user_can('activate_plugins')) {
        return;
    }
    
    // Drop all plugin tables
    $database = new ViraSchool_Database();
    $database->drop_tables();
    
    // Remove custom capabilities
    vira_school_remove_capabilities();
    
    // Remove plugin options (if any were added)
    delete_option('vira_school_version');
    delete_option('vira_school_settings');
    
    // Clear any cached data
    wp_cache_flush();
}

/**
 * Remove custom capabilities
 */
function vira_school_remove_capabilities() {
    $capabilities = array(
        'manage_students',
        'manage_courses',
        'manage_attendance',
        'view_reports'
    );
    
    // Remove capabilities from all roles
    global $wp_roles;
    
    if (!isset($wp_roles)) {
        $wp_roles = new WP_Roles();
    }
    
    foreach ($wp_roles->roles as $role_name => $role_data) {
        $role = get_role($role_name);
        if ($role) {
            foreach ($capabilities as $capability) {
                $role->remove_cap($capability);
            }
        }
    }
}
