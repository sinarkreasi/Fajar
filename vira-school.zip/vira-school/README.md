# Vira School Management Plugin

A comprehensive school management system for WordPress that helps educational institutions manage students, teachers, courses, attendance, and generate reports.

## Features

### Student Management
- Add, edit, and delete student records
- Student profile management
- Student status tracking (Active, Inactive, Graduated)
- Parent/Guardian information

### Teacher Management
- Teacher profile management
- Department assignment
- Qualification tracking

### Course Management
- Create and manage courses
- Course scheduling
- Credit system
- Class assignment

### Attendance Tracking
- Mark daily attendance
- Multiple attendance statuses (Present, Absent, Late, Excused)
- Attendance statistics and reports
- Course-wise attendance tracking

### Dashboard & Reports
- Administrative dashboard with key statistics
- Student attendance summary
- Comprehensive reporting system

## Installation

1. Download the plugin files
2. Upload to `/wp-content/plugins/vira-school/` directory
3. Activate the plugin through the 'Plugins' menu in WordPress
4. The plugin will automatically create the necessary database tables
5. Access the plugin via the 'Vira School' menu in WordPress admin

## Usage

### Admin Features

#### Dashboard
- View key statistics (total students, teachers, classes, courses)
- Quick action buttons for common tasks
- Overview of school data

#### Student Management
- Navigate to **Vira School > Students**
- Add new students with complete information
- View all students in a sortable table
- Edit or delete existing student records

#### Other Management Pages
- **Teachers**: Manage teacher profiles and information
- **Classes**: Create and manage class groups
- **Courses**: Set up course schedules and details
- **Attendance**: Track and manage student attendance
- **Reports**: Generate various reports

### Frontend Features

Use shortcodes to display school information on frontend pages:

#### Student Profile Shortcode
```
[vira_student_profile student_id="STUDENT123"]
```
Displays detailed student profile information.

#### Student Attendance Shortcode
```
[vira_student_attendance student_id="STUDENT123" course_id="1"]
```
Shows student attendance summary and records.

#### Students List Shortcode
```
[vira_students_list status="active" limit="10"]
```
Displays a list of students with optional filtering.

## Database Tables

The plugin creates the following database tables:

- `wp_vira_students` - Student information
- `wp_vira_teachers` - Teacher information  
- `wp_vira_classes` - Class/grade information
- `wp_vira_courses` - Course details and schedules
- `wp_vira_attendance` - Attendance records
- `wp_vira_grades` - Grade/assessment records

## User Capabilities

The plugin adds these custom capabilities:

- `manage_students` - Add, edit, delete students
- `manage_courses` - Manage courses and classes
- `manage_attendance` - Track attendance
- `view_reports` - Access reporting features

By default, these capabilities are assigned to Administrator users.

## Styling

The plugin includes responsive CSS for both admin and frontend display:

- Modern, clean admin interface
- Mobile-responsive design
- Color-coded attendance statuses
- Professional frontend styling

## Development

### File Structure
```
vira-school/
├── vira-school.php          # Main plugin file
├── includes/                # Core functionality classes
│   ├── class-database.php   # Database management
│   ├── class-admin.php      # Admin interface
│   ├── class-student.php    # Student management
│   ├── class-course.php     # Course management
│   ├── class-attendance.php # Attendance tracking
│   ├── class-frontend.php   # Frontend display
│   └── class-shortcodes.php # Shortcode handlers
├── assets/                  # CSS and JS files
│   ├── css/
│   │   ├── admin.css       # Admin styling
│   │   └── frontend.css    # Frontend styling
│   └── js/
│       ├── admin.js        # Admin JavaScript
│       └── frontend.js     # Frontend JavaScript
└── README.md               # This file
```

## Requirements

- WordPress 5.0 or higher
- PHP 7.0 or higher
- MySQL 5.6 or higher

## Support

For support and feature requests, please contact the plugin developer.

## Version History

### 1.0.0
- Initial release
- Student management system
- Basic attendance tracking
- Administrative dashboard
- Shortcode support
- Responsive design

## License

This plugin is licensed under the GPL v2 or later.

## Credits

Developed for educational institutions to streamline school management processes.
