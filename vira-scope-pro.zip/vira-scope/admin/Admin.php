<?php
/**
 * Admin functionality for Vira Scope.
 */

namespace ViraScope\Admin;

use ViraScope\Traits\Singleton;
use ViraScope\Services\TrendsService;
use ViraScope\Services\AIService;
use ViraScope\Helpers\CacheHelper;

if (!defined('ABSPATH')) {
    exit;
}

class Admin {

    use Singleton;

    public function init() {
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);
        add_action('wp_ajax_vrsc_get_trends', [$this, 'ajax_get_trends']);
        add_action('wp_ajax_vrsc_analyze_keyword', [$this, 'ajax_analyze_keyword']);
        add_action('wp_ajax_vrsc_get_stats', [$this, 'ajax_get_stats']);
        add_action('wp_ajax_vrsc_analyze_site_content', [$this, 'ajax_analyze_site_content']);
        add_action('wp_ajax_vrsc_clear_cache', [$this, 'ajax_clear_cache']);
        add_action('wp_ajax_vrsc_get_keyword_analysis', [$this, 'ajax_get_keyword_analysis']);
        add_action('wp_ajax_vrsc_test_ai_connection', [$this, 'ajax_test_ai_connection']);
        add_action('wp_ajax_vrsc_clear_all_cache', [$this, 'ajax_clear_all_cache']);
        add_action('wp_ajax_vrsc_get_content_types', [$this, 'ajax_get_content_types']);
        add_action('wp_ajax_vrsc_debug_content', [$this, 'ajax_debug_content']);
    }

    public function add_admin_menu() {
        add_menu_page(
            __('Vira Scope', 'vira-scope'),
            __('Vira Scope', 'vira-scope'),
            'manage_options',
            'vira-scope',
            [$this, 'dashboard_page'],
            'dashicons-chart-area',
            30
        );

        add_submenu_page(
            'vira-scope',
            __('Dashboard', 'vira-scope'),
            __('Dashboard', 'vira-scope'),
            'manage_options',
            'vira-scope',
            [$this, 'dashboard_page']
        );

        add_submenu_page(
            'vira-scope',
            __('Trends', 'vira-scope'),
            __('Trends', 'vira-scope'),
            'manage_options',
            'vira-scope-trends',
            [$this, 'trends_page']
        );

        add_submenu_page(
            'vira-scope',
            __('Settings', 'vira-scope'),
            __('Settings', 'vira-scope'),
            'manage_options',
            'vira-scope-settings',
            [$this, 'settings_page']
        );
    }

    public function enqueue_admin_assets($hook) {
        if (strpos($hook, 'vira-scope') === false) {
            return;
        }

        wp_enqueue_script(
            'vrsc-admin',
            VRSC_URL . 'admin/Assets/js/admin.js',
            ['jquery'],
            VRSC_VERSION,
            true
        );

        wp_enqueue_style(
            'vrsc-admin',
            VRSC_URL . 'admin/Assets/css/admin.css',
            [],
            VRSC_VERSION
        );

        wp_localize_script('vrsc-admin', 'vrsc_ajax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('vrsc_nonce'),
        ]);
    }

    public function dashboard_page() {
        include VRSC_PATH . 'admin/Views/dashboard.php';
    }

    public function trends_page() {
        include VRSC_PATH . 'admin/Views/trends.php';
    }

    public function settings_page() {
        include VRSC_PATH . 'admin/Views/settings.php';
    }

    public function ajax_get_trends() {
        check_ajax_referer('vrsc_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'vira-scope'));
        }

        $trends_service = new TrendsService();
        $trends = $trends_service->get_latest_trends();

        wp_send_json_success($trends);
    }

    public function ajax_analyze_keyword() {
        check_ajax_referer('vrsc_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'vira-scope'));
        }

        $keyword = sanitize_text_field($_POST['keyword'] ?? '');
        $force_refresh = isset($_POST['force_refresh']) && $_POST['force_refresh'] === '1';
        
        if (empty($keyword)) {
            wp_send_json_error(__('Keyword is required', 'vira-scope'));
        }

        $ai_service = new AIService();
        
        // Clear cache if force refresh is requested
        if ($force_refresh) {
            $cache_helper = new CacheHelper();
            $cache_key = 'vrsc_ai_analysis_' . md5($keyword);
            $cache_helper->delete($cache_key);
        }
        
        $analysis = $ai_service->analyze_keyword($keyword);

        // Add debug information if WP_DEBUG is enabled
        if (defined('WP_DEBUG') && WP_DEBUG) {
            $analysis['debug'] = [
                'keyword' => $keyword,
                'force_refresh' => $force_refresh,
                'gemini_key_set' => !empty(get_option('vrsc_gemini_api_key')),
                'openai_key_set' => !empty(get_option('vrsc_openai_api_key')),
                'gemini_model' => get_option('vrsc_gemini_model', 'gemini-2.5-flash')
            ];
        }

        wp_send_json_success($analysis);
    }

    public function ajax_get_stats() {
        check_ajax_referer('vrsc_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'vira-scope'));
        }

        global $wpdb;
        $trends_table = $wpdb->prefix . 'vrsc_trends';
        $cache_table = $wpdb->prefix . 'vrsc_cache';

        $total_trends = $wpdb->get_var("SELECT COUNT(*) FROM $trends_table");
        $hot_keywords = $wpdb->get_var("SELECT COUNT(*) FROM $trends_table WHERE trend_score >= 80");
        $ai_analyses = $wpdb->get_var("SELECT COUNT(*) FROM $trends_table WHERE ai_analysis IS NOT NULL AND ai_analysis != ''");
        
        // Calculate cache hit rate (simplified)
        $total_cache_requests = get_option('vrsc_cache_requests', 0);
        $cache_hits = get_option('vrsc_cache_hits', 0);
        $cache_rate = $total_cache_requests > 0 ? round(($cache_hits / $total_cache_requests) * 100) : 0;

        wp_send_json_success([
            'total_trends' => intval($total_trends),
            'hot_keywords' => intval($hot_keywords),
            'ai_analyses' => intval($ai_analyses),
            'cache_rate' => $cache_rate
        ]);
    }

    public function ajax_analyze_site_content() {
        check_ajax_referer('vrsc_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'vira-scope'));
        }

        $content_types = isset($_POST['content_types']) ? array_map('sanitize_text_field', $_POST['content_types']) : ['post', 'page'];
        $force_refresh = isset($_POST['force_refresh']) && $_POST['force_refresh'] === '1';

        // Debug logging
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Vira Scope: Starting content analysis for types: ' . implode(', ', $content_types));
            error_log('Vira Scope: Force refresh: ' . ($force_refresh ? 'yes' : 'no'));
        }

        try {
            $trends_service = new TrendsService();
            $analysis_results = $trends_service->analyze_site_content($content_types, $force_refresh);

            if (!is_array($analysis_results)) {
                throw new \UnexpectedValueException('Invalid analysis results payload.');
            }

            $total_keywords = 0;
            $total_processed = 0;
            $ai_analyzed = 0;

            $gemini_key = get_option('vrsc_gemini_api_key', '');
            $openai_key = get_option('vrsc_openai_api_key', '');
            $ai_enabled = !empty($gemini_key) || !empty($openai_key);

            $ai_service = $ai_enabled ? new AIService() : null;
            $batch_size = max(1, intval(get_option('vrsc_max_keywords_per_batch', 10)));

            foreach ($analysis_results as $content_type => $result) {
                $keywords = [];
                if (isset($result['keywords']) && is_array($result['keywords'])) {
                    $keywords = array_values(array_filter(array_map('sanitize_text_field', $result['keywords'])));
                }

                $total_keywords += count($keywords);
                $total_processed += isset($result['processed_count']) ? intval($result['processed_count']) : 0;

                if (!$ai_enabled || empty($keywords)) {
                    continue;
                }

                $keyword_batch = array_slice($keywords, 0, $batch_size);
                if (empty($keyword_batch)) {
                    continue;
                }

                $ai_results = $ai_service->batch_analyze_keywords($keyword_batch);
                if (!is_array($ai_results)) {
                    continue;
                }

                foreach ($ai_results as $keyword => $analysis) {
                    if (!is_array($analysis)) {
                        continue;
                    }

                    $trend_score = 50;
                    if (isset($analysis['gemini']['trend_score'])) {
                        $trend_score = floatval($analysis['gemini']['trend_score']);
                    } elseif (isset($analysis['openai']['trend_score'])) {
                        $trend_score = floatval($analysis['openai']['trend_score']);
                    }

                    $search_volume = 0;
                    if (isset($analysis['gemini']['search_volume_estimate'])) {
                        $search_volume = floatval($analysis['gemini']['search_volume_estimate']);
                    } elseif (isset($analysis['openai']['search_volume_estimate'])) {
                        $search_volume = floatval($analysis['openai']['search_volume_estimate']);
                    }

                    $trends_service->save_trend(
                        $keyword,
                        $trend_score,
                        $search_volume,
                        wp_json_encode($analysis)
                    );
                    $ai_analyzed++;
                }
            }

            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log(sprintf(
                    'Vira Scope: Content analysis completed. total_keywords=%d, total_processed=%d, ai_analyzed=%d, ai_enabled=%s',
                    $total_keywords,
                    $total_processed,
                    $ai_analyzed,
                    $ai_enabled ? 'yes' : 'no'
                ));
            }

            wp_send_json_success([
                'analysis_results' => $analysis_results,
                'total_keywords' => $total_keywords,
                'total_processed' => $total_processed,
                'ai_analyzed' => $ai_analyzed,
                'ai_enabled' => $ai_enabled,
                'content_types' => $content_types
            ]);
        } catch (\Throwable $e) {
            error_log('Vira Scope: Content analysis error - ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Vira Scope: Trace - ' . $e->getTraceAsString());
            }

            wp_send_json_error(__('Site content analysis failed. Please check debug logs for details.', 'vira-scope'));
        }
    }

    public function ajax_get_content_types() {
        check_ajax_referer('vrsc_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'vira-scope'));
        }

        // Get all public post types
        $post_types = get_post_types(['public' => true], 'objects');
        $available_types = [];
        
        foreach ($post_types as $post_type) {
            $count = wp_count_posts($post_type->name);
            $available_types[] = [
                'name' => $post_type->name,
                'label' => $post_type->label,
                'count' => $count->publish ?? 0
            ];
        }
        
        // Add taxonomies option
        $taxonomies = get_taxonomies(['public' => true], 'objects');
        $tax_count = 0;
        foreach ($taxonomies as $taxonomy) {
            $terms = get_terms(['taxonomy' => $taxonomy->name, 'hide_empty' => true]);
            $tax_count += count($terms);
        }
        
        $available_types[] = [
            'name' => 'taxonomies',
            'label' => 'Taxonomies (Categories, Tags, etc.)',
            'count' => $tax_count
        ];

        wp_send_json_success($available_types);
    }

    public function ajax_debug_content() {
        check_ajax_referer('vrsc_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'vira-scope'));
        }

        $debug_info = [];
        
        // Check posts
        $posts = get_posts(['post_type' => 'post', 'post_status' => 'publish', 'numberposts' => 5]);
        $debug_info['posts'] = [
            'total' => wp_count_posts('post')->publish,
            'sample_count' => count($posts),
            'sample_titles' => array_map(function($post) { return $post->post_title; }, $posts)
        ];
        
        // Check pages
        $pages = get_posts(['post_type' => 'page', 'post_status' => 'publish', 'numberposts' => 5]);
        $debug_info['pages'] = [
            'total' => wp_count_posts('page')->publish,
            'sample_count' => count($pages),
            'sample_titles' => array_map(function($post) { return $post->post_title; }, $pages)
        ];
        
        // Test keyword extraction on first post
        if (!empty($posts)) {
            $trends_service = new TrendsService();
            $test_content = $posts[0]->post_title . ' ' . $posts[0]->post_content;
            
            // Use reflection to access private method for testing
            $reflection = new ReflectionClass($trends_service);
            $method = $reflection->getMethod('extract_keywords');
            $method->setAccessible(true);
            $test_keywords = $method->invoke($trends_service, $test_content);
            
            $debug_info['keyword_test'] = [
                'post_title' => $posts[0]->post_title,
                'content_length' => strlen($test_content),
                'keywords_found' => count($test_keywords),
                'sample_keywords' => array_slice($test_keywords, 0, 10)
            ];
        }
        
        wp_send_json_success($debug_info);
    }

    public function ajax_clear_cache() {
        check_ajax_referer('vrsc_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'vira-scope'));
        }

        $cache_helper = new CacheHelper();
        $result = $cache_helper->flush();

        if ($result) {
            wp_send_json_success();
        } else {
            wp_send_json_error(__('Failed to clear cache', 'vira-scope'));
        }
    }

    public function ajax_get_keyword_analysis() {
        check_ajax_referer('vrsc_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'vira-scope'));
        }

        $keyword = sanitize_text_field($_POST['keyword'] ?? '');
        
        if (empty($keyword)) {
            wp_send_json_error(__('Keyword is required', 'vira-scope'));
        }

        $trends_service = new TrendsService();
        $trend = $trends_service->get_trend_by_keyword($keyword);

        if ($trend) {
            wp_send_json_success([
                'keyword' => $trend->keyword,
                'trend_score' => $trend->trend_score,
                'search_volume' => $trend->search_volume,
                'competition_level' => $trend->competition_level,
                'ai_analysis' => $trend->ai_analysis,
                'created_at' => $trend->created_at
            ]);
        } else {
            wp_send_json_error(__('No analysis found for this keyword', 'vira-scope'));
        }
    }

    public function ajax_test_ai_connection() {
        check_ajax_referer('vrsc_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'vira-scope'));
        }

        $ai_service = new AIService();
        
        // Test with a simple keyword
        $test_result = $ai_service->test_connection();

        if ($test_result['success']) {
            wp_send_json_success([
                'message' => __('AI connection successful', 'vira-scope'),
                'provider' => $test_result['provider'],
                'details' => $test_result['details']
            ]);
        } else {
            wp_send_json_error([
                'message' => __('AI connection failed', 'vira-scope'),
                'error' => $test_result['error'],
                'details' => $test_result['details']
            ]);
        }
    }

    public function ajax_clear_all_cache() {
        check_ajax_referer('vrsc_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'vira-scope'));
        }

        $cache_helper = new CacheHelper();
        $result = $cache_helper->flush();
        
        // Also clear WordPress transients
        global $wpdb;
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_vrsc_%' OR option_name LIKE '_transient_timeout_vrsc_%'");

        if ($result) {
            wp_send_json_success();
        } else {
            wp_send_json_error(__('Failed to clear cache', 'vira-scope'));
        }
    }
}