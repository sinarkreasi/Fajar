/* Vira Scope Admin JavaScript */

(function ($) {
    'use strict';

    const ViraScopeAdmin = {
        init: function () {
            this.bindEvents();
            this.loadDashboardStats();
        },

        bindEvents: function () {
            // Dashboard events
            $('#vrsc-analyze-site').on('click', this.analyzeSiteContent);
            $('#vrsc-refresh-trends').on('click', this.refreshTrends);
            $('#vrsc-clear-cache').on('click', this.clearCache);
            $('#vrsc-analyze-keyword').on('click', this.analyzeKeyword);

            // Trends page events
            $('#vrsc-apply-filters').on('click', this.applyFilters);
            $('#vrsc-reset-filters').on('click', this.resetFilters);
            $('#vrsc-refresh-trends-page').on('click', this.refreshTrendsPage);
            $('.vrsc-view-analysis').on('click', this.viewAnalysis);
            $('.vrsc-modal-close').on('click', this.closeModal);

            // Settings events
            $('#vrsc-test-ai-connection').on('click', this.testAIConnection);
            $('#vrsc-clear-all-cache').on('click', this.clearAllCache);

            // Modal events
            $(document).on('click', function (e) {
                if ($(e.target).hasClass('vrsc-modal')) {
                    ViraScopeAdmin.closeModal();
                }
            });

            // Enter key for keyword analysis
            $('#vrsc-keyword-input').on('keypress', function (e) {
                if (e.which === 13) {
                    ViraScopeAdmin.analyzeKeyword();
                }
            });
        },

        loadDashboardStats: function () {
            $.ajax({
                url: vrsc_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrsc_get_stats',
                    nonce: vrsc_ajax.nonce
                },
                success: function (response) {
                    if (response.success) {
                        $('#vrsc-total-trends').text(response.data.total_trends || 0);
                        $('#vrsc-hot-keywords').text(response.data.hot_keywords || 0);
                        $('#vrsc-ai-analyses').text(response.data.ai_analyses || 0);
                        $('#vrsc-cache-rate').text((response.data.cache_rate || 0) + '%');
                        $('#vrsc-total-trends-count').text(response.data.total_trends || 0);
                    }
                }
            });
        },

        analyzeSiteContent: function () {
            // Try to show modal, fallback to simple analysis if it fails
            try {
                ViraScopeAdmin.showContentAnalysisModal();
            } catch (error) {
                console.error('Modal failed, using simple analysis:', error);
                ViraScopeAdmin.runSimpleAnalysis();
            }
        },

        runSimpleAnalysis: function () {
            const $button = $('#vrsc-analyze-site');
            const originalText = $button.text();

            $button.prop('disabled', true).html('<span class="vrsc-spinner"></span>' + 'Analyzing...');

            $.ajax({
                url: vrsc_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrsc_analyze_site_content',
                    content_types: ['post', 'page'],
                    nonce: vrsc_ajax.nonce
                },
                success: function (response) {
                    if (response.success) {
                        ViraScopeAdmin.showNotice('Site content analysis completed successfully!', 'success');
                        ViraScopeAdmin.loadDashboardStats();
                    } else {
                        ViraScopeAdmin.showNotice(response.data || 'Analysis failed', 'error');
                    }
                },
                error: function () {
                    ViraScopeAdmin.showNotice('Network error occurred', 'error');
                },
                complete: function () {
                    $button.prop('disabled', false).text(originalText);
                }
            });
        },

        showContentAnalysisModal: function () {
            // Create modal HTML
            const modalHtml = `
                <div id="vrsc-content-analysis-modal" class="vrsc-modal" style="display: block;">
                    <div class="vrsc-modal-content" style="max-width: 600px;">
                        <div class="vrsc-modal-header">
                            <h2>Analyze Site Content</h2>
                            <span class="vrsc-modal-close">&times;</span>
                        </div>
                        <div class="vrsc-modal-body">
                            <p>Select the content types you want to analyze for trending keywords:</p>
                            
                            <div id="vrsc-content-types-loading" style="text-align: center; padding: 20px;">
                                <div class="vrsc-spinner"></div> Loading content types...
                            </div>
                            
                            <div id="vrsc-content-types-list" style="display: none;">
                                <!-- Content types will be loaded here -->
                            </div>
                            
                            <div id="vrsc-analysis-options" style="display: none; margin-top: 20px; padding-top: 20px; border-top: 1px solid #ddd;">
                                <label>
                                    <input type="checkbox" id="vrsc-force-refresh"> 
                                    Force refresh (re-analyze previously processed content)
                                </label>
                            </div>
                            
                            <div id="vrsc-analysis-progress" style="display: none; margin-top: 20px;">
                                <div class="vrsc-progress-bar" style="background: #f0f0f0; border-radius: 4px; overflow: hidden;">
                                    <div class="vrsc-progress-fill" style="background: #0073aa; height: 20px; width: 0%; transition: width 0.3s;"></div>
                                </div>
                                <p id="vrsc-progress-text">Preparing analysis...</p>
                            </div>
                            
                            <div id="vrsc-analysis-results" style="display: none; margin-top: 20px;">
                                <!-- Results will be shown here -->
                            </div>
                        </div>
                        <div class="vrsc-modal-footer" style="padding: 20px; border-top: 1px solid #ddd; text-align: right;">
                            <button type="button" class="button" id="vrsc-cancel-analysis">Cancel</button>
                            <button type="button" class="button button-primary" id="vrsc-start-analysis" disabled>Start Analysis</button>
                        </div>
                    </div>
                </div>
            `;

            // Remove existing modal if any
            $('#vrsc-content-analysis-modal').remove();

            // Add modal to page
            $('body').append(modalHtml);

            // Bind events
            $('.vrsc-modal-close').on('click', ViraScopeAdmin.closeContentAnalysisModal);
            $('#vrsc-cancel-analysis').on('click', ViraScopeAdmin.closeContentAnalysisModal);
            $('#vrsc-start-analysis').on('click', ViraScopeAdmin.startContentAnalysis);

            // Load content types with timeout fallback
            console.log('Loading content types...');
            ViraScopeAdmin.loadContentTypes();

            // Fallback if loading takes too long
            setTimeout(function () {
                if ($('#vrsc-content-types-loading').is(':visible')) {
                    console.log('Content types loading timeout, showing fallback');
                    ViraScopeAdmin.showContentTypesFallback();
                }
            }, 10000); // 10 second timeout
        },

        loadContentTypes: function () {
            console.log('AJAX URL:', vrsc_ajax.ajax_url);
            console.log('Nonce:', vrsc_ajax.nonce);

            $.ajax({
                url: vrsc_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrsc_get_content_types',
                    nonce: vrsc_ajax.nonce
                },
                success: function (response) {
                    console.log('Content types response:', response);
                    if (response.success) {
                        ViraScopeAdmin.displayContentTypes(response.data);
                    } else {
                        $('#vrsc-content-types-loading').html('<p style="color: red;">Failed to load content types: ' + (response.data || 'Unknown error') + '</p>');
                    }
                },
                error: function (xhr, status, error) {
                    console.error('AJAX error:', status, error);
                    $('#vrsc-content-types-loading').html('<p style="color: red;">Network error occurred: ' + error + '</p>');
                }
            });
        },

        displayContentTypes: function (contentTypes) {
            let html = '<div style="max-height: 300px; overflow-y: auto;">';

            contentTypes.forEach(function (type) {
                const disabled = type.count === 0 ? 'disabled' : '';
                const checkedDefault = ['post', 'page'].includes(type.name) && type.count > 0 ? 'checked' : '';

                html += `
                    <label style="display: block; padding: 8px 0; border-bottom: 1px solid #f0f0f0;">
                        <input type="checkbox" name="content_types[]" value="${type.name}" ${checkedDefault} ${disabled}> 
                        <strong>${type.label}</strong> 
                        <span style="color: #666;">(${type.count} items)</span>
                        ${type.count === 0 ? '<em style="color: #999;"> - No content available</em>' : ''}
                    </label>
                `;
            });

            html += '</div>';

            $('#vrsc-content-types-loading').hide();
            $('#vrsc-content-types-list').html(html).show();
            $('#vrsc-analysis-options').show();

            // Enable start button if any types are selected
            ViraScopeAdmin.updateStartButton();

            // Bind change event
            $('input[name="content_types[]"]').on('change', ViraScopeAdmin.updateStartButton);
        },

        updateStartButton: function () {
            const selectedTypes = $('input[name="content_types[]"]:checked').length;
            $('#vrsc-start-analysis').prop('disabled', selectedTypes === 0);
        },

        startContentAnalysis: function () {
            const selectedTypes = [];
            $('input[name="content_types[]"]:checked').each(function () {
                selectedTypes.push($(this).val());
            });

            const forceRefresh = $('#vrsc-force-refresh').is(':checked');

            // Hide content selection and show progress
            $('#vrsc-content-types-list, #vrsc-analysis-options, .vrsc-modal-footer').hide();
            $('#vrsc-analysis-progress').show();

            // Start analysis
            $.ajax({
                url: vrsc_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrsc_analyze_site_content',
                    content_types: selectedTypes,
                    force_refresh: forceRefresh ? '1' : '0',
                    nonce: vrsc_ajax.nonce
                },
                success: function (response) {
                    if (response.success) {
                        ViraScopeAdmin.displayAnalysisResults(response.data);
                    } else {
                        ViraScopeAdmin.showAnalysisError(response.data || 'Analysis failed');
                    }
                },
                error: function () {
                    ViraScopeAdmin.showAnalysisError('Network error occurred');
                }
            });
        },

        displayAnalysisResults: function (data) {
            $('#vrsc-analysis-progress').hide();

            let html = '<h3>Analysis Complete!</h3>';
            html += `<div class="vrsc-analysis-summary" style="background: #f0f8ff; padding: 15px; border-radius: 4px; margin-bottom: 20px;">`;
            html += `<p><strong>Total Keywords Found:</strong> ${data.total_keywords}</p>`;
            html += `<p><strong>Content Items Processed:</strong> ${data.total_processed}</p>`;
            html += `<p><strong>AI Analyzed Keywords:</strong> ${data.ai_analyzed}</p>`;
            html += `</div>`;

            html += '<h4>Results by Content Type:</h4>';
            html += '<div style="max-height: 200px; overflow-y: auto;">';

            Object.keys(data.analysis_results).forEach(function (contentType) {
                const result = data.analysis_results[contentType];
                if (result.keywords) {
                    html += `<div style="margin-bottom: 15px; padding: 10px; border: 1px solid #ddd; border-radius: 4px;">`;
                    html += `<h5 style="margin: 0 0 5px 0;">${contentType.charAt(0).toUpperCase() + contentType.slice(1)}</h5>`;
                    html += `<p style="margin: 0; color: #666;">`;
                    html += `${result.keywords.length} keywords found, ${result.processed_count} items processed`;
                    html += `</p>`;

                    if (result.keywords.length > 0) {
                        html += `<p style="margin: 5px 0 0 0; font-size: 12px;">`;
                        html += `<strong>Sample keywords:</strong> ${result.keywords.slice(0, 5).join(', ')}`;
                        if (result.keywords.length > 5) {
                            html += ` and ${result.keywords.length - 5} more...`;
                        }
                        html += `</p>`;
                    }
                    html += `</div>`;
                }
            });

            html += '</div>';

            html += `<div style="margin-top: 20px; text-align: center;">`;
            html += `<button type="button" class="button button-primary" id="vrsc-view-updated-trends">View Updated Trends</button>`;
            html += `<button type="button" class="button" id="vrsc-close-analysis-results" style="margin-left: 10px;">Close</button>`;
            html += `</div>`;

            $('#vrsc-analysis-results').html(html).show();

            // Bind new button events
            $('#vrsc-view-updated-trends').on('click', function () {
                ViraScopeAdmin.closeContentAnalysisModal();
                ViraScopeAdmin.loadDashboardStats();
            });
            $('#vrsc-close-analysis-results').on('click', ViraScopeAdmin.closeContentAnalysisModal);
        },

        showAnalysisError: function (message) {
            $('#vrsc-analysis-progress').hide();
            const errorHtml = `
                <div style="color: #d63638; background: #fcf0f1; padding: 15px; border-radius: 4px;">
                    <h4>Analysis Failed</h4>
                    <p>${message}</p>
                    <button type="button" class="button" id="vrsc-close-error">Close</button>
                </div>
            `;

            $('#vrsc-analysis-results').html(errorHtml).show();

            // Bind error close button
            $('#vrsc-close-error').on('click', ViraScopeAdmin.closeContentAnalysisModal);
        },

        showContentTypesFallback: function () {
            const fallbackTypes = [
                { name: 'post', label: 'Posts', count: '?' },
                { name: 'page', label: 'Pages', count: '?' },
                { name: 'taxonomies', label: 'Categories & Tags', count: '?' }
            ];

            $('#vrsc-content-types-loading').hide();
            ViraScopeAdmin.displayContentTypes(fallbackTypes);
        },

        closeContentAnalysisModal: function () {
            $('#vrsc-content-analysis-modal').remove();
        },

        refreshTrends: function () {
            const $button = $(this);
            const originalText = $button.text();

            $button.prop('disabled', true).html('<span class="vrsc-spinner"></span>' + 'Refreshing...');

            $.ajax({
                url: vrsc_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrsc_get_trends',
                    nonce: vrsc_ajax.nonce
                },
                success: function (response) {
                    if (response.success) {
                        location.reload();
                    } else {
                        ViraScopeAdmin.showNotice(response.data || 'Failed to refresh trends', 'error');
                    }
                },
                error: function () {
                    ViraScopeAdmin.showNotice('Network error occurred', 'error');
                },
                complete: function () {
                    $button.prop('disabled', false).text(originalText);
                }
            });
        },

        clearCache: function () {
            if (!confirm('Are you sure you want to clear the cache?')) {
                return;
            }

            const $button = $(this);
            const originalText = $button.text();

            $button.prop('disabled', true).html('<span class="vrsc-spinner"></span>' + 'Clearing...');

            $.ajax({
                url: vrsc_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrsc_clear_cache',
                    nonce: vrsc_ajax.nonce
                },
                success: function (response) {
                    if (response.success) {
                        ViraScopeAdmin.showNotice('Cache cleared successfully!', 'success');
                    } else {
                        ViraScopeAdmin.showNotice(response.data || 'Failed to clear cache', 'error');
                    }
                },
                error: function () {
                    ViraScopeAdmin.showNotice('Network error occurred', 'error');
                },
                complete: function () {
                    $button.prop('disabled', false).text(originalText);
                }
            });
        },

        analyzeKeyword: function () {
            const keyword = $('#vrsc-keyword-input').val().trim();

            if (!keyword) {
                ViraScopeAdmin.showNotice('Please enter a keyword to analyze', 'error');
                return;
            }

            const $button = $('#vrsc-analyze-keyword');
            const originalText = $button.text();

            $button.prop('disabled', true).html('<span class="vrsc-spinner"></span>' + 'Analyzing...');
            $('#vrsc-analysis-result').hide();

            $.ajax({
                url: vrsc_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrsc_analyze_keyword',
                    keyword: keyword,
                    nonce: vrsc_ajax.nonce
                },
                success: function (response) {
                    if (response.success) {
                        ViraScopeAdmin.displayAnalysisResult(response.data);
                    } else {
                        ViraScopeAdmin.showNotice(response.data || 'Analysis failed', 'error');
                    }
                },
                error: function () {
                    ViraScopeAdmin.showNotice('Network error occurred', 'error');
                },
                complete: function () {
                    $button.prop('disabled', false).text(originalText);
                }
            });
        },

        displayAnalysisResult: function (data) {
            let html = '<h4>Analysis Results</h4>';

            // Check for errors first
            if (data.error) {
                html += '<div class="vrsc-analysis-error" style="color: #d63638; background: #fcf0f1; padding: 10px; border-radius: 4px; margin: 10px 0;">';
                html += '<p><strong>Error:</strong> ' + data.error + '</p>';

                if (data.details && data.details.length > 0) {
                    html += '<p><strong>Details:</strong></p>';
                    html += '<ul>';
                    data.details.forEach(function (detail) {
                        html += '<li>' + detail + '</li>';
                    });
                    html += '</ul>';
                }

                html += '<p><em>Please check your API keys in <a href="' + (window.location.href.includes('admin.php') ? 'admin.php?page=vira-scope-settings' : 'admin.php?page=vira-scope-settings') + '">Settings</a>.</em></p>';
                html += '</div>';
            } else if (data.gemini || data.openai) {
                const analysis = data.gemini || data.openai;
                const provider = data.gemini ? 'Gemini' : 'OpenAI';

                html += '<div class="vrsc-analysis-summary">';
                html += '<p style="color: #00a32a; font-weight: 600;">✓ Analysis completed using ' + provider + '</p>';
                html += '<p><strong>Trend Score:</strong> ' + (analysis.trend_score || 'N/A') + '%</p>';
                html += '<p><strong>Search Volume:</strong> ' + (analysis.search_volume_estimate || 'N/A') + '</p>';
                html += '<p><strong>Competition:</strong> ' + (analysis.competition_level || 'N/A') + '</p>';
                html += '<p><strong>Trend Direction:</strong> ' + (analysis.trend_direction || 'N/A') + '</p>';

                if (analysis.summary) {
                    html += '<p><strong>Summary:</strong> ' + analysis.summary + '</p>';
                }

                if (analysis.opportunities && analysis.opportunities.length > 0) {
                    html += '<p><strong>Opportunities:</strong></p>';
                    html += '<ul>';
                    analysis.opportunities.forEach(function (opportunity) {
                        html += '<li>' + opportunity + '</li>';
                    });
                    html += '</ul>';
                }

                if (analysis.related_keywords && analysis.related_keywords.length > 0) {
                    html += '<p><strong>Related Keywords:</strong></p>';
                    html += '<div style="margin: 5px 0;">';
                    analysis.related_keywords.forEach(function (keyword) {
                        html += '<span style="background: #f0f0f1; padding: 2px 6px; margin: 2px; border-radius: 3px; font-size: 12px;">' + keyword + '</span> ';
                    });
                    html += '</div>';
                }

                html += '</div>';
            } else {
                html += '<div class="vrsc-analysis-warning" style="color: #b32d2e; background: #fcf9e8; padding: 10px; border-radius: 4px; margin: 10px 0;">';
                html += '<p>No analysis data available. This could mean:</p>';
                html += '<ul>';
                html += '<li>API keys are not configured properly</li>';
                html += '<li>AI service is temporarily unavailable</li>';
                html += '<li>The keyword could not be processed</li>';
                html += '</ul>';
                html += '<p><em>Please check your <a href="admin.php?page=vira-scope-settings">AI service configuration</a> and try again.</em></p>';
                html += '</div>';
            }

            $('#vrsc-analysis-result').html(html).show();
        },

        applyFilters: function () {
            const keyword = $('#vrsc-filter-keyword').val().toLowerCase();
            const minScore = parseInt($('#vrsc-filter-score').val()) || 0;
            const competition = $('#vrsc-filter-competition').val();
            const minWords = parseInt($('#vrsc-filter-words').val()) || 0;

            let visibleCount = 0;

            $('#vrsc-trends-tbody tr').each(function () {
                const $row = $(this);
                const rowKeywordData = $row.data('keyword');
                const rowScoreData = $row.data('score');
                const rowCompetitionData = $row.data('competition');

                // Skip rows without data (like "no trends" message row)
                if (!rowKeywordData) {
                    return;
                }

                const rowKeyword = String(rowKeywordData).toLowerCase();
                const rowScore = parseInt(rowScoreData) || 0;
                const rowCompetition = String(rowCompetitionData || '');
                const wordCount = rowKeyword.split(' ').length;

                let show = true;

                // Keyword filter
                if (keyword && rowKeyword.indexOf(keyword) === -1) {
                    show = false;
                }

                // Score filter
                if (rowScore < minScore) {
                    show = false;
                }

                // Competition filter
                if (competition && rowCompetition !== competition) {
                    show = false;
                }

                // Word count filter
                if (minWords > 0 && wordCount < minWords) {
                    show = false;
                }

                $row.toggle(show);
                if (show) visibleCount++;
            });

            // Show filter results
            ViraScopeAdmin.showFilterResults(visibleCount);
        },

        resetFilters: function () {
            $('#vrsc-filter-keyword').val('');
            $('#vrsc-filter-score').val('0');
            $('#vrsc-filter-competition').val('');
            $('#vrsc-filter-words').val('0');

            $('#vrsc-trends-tbody tr').show();
            ViraScopeAdmin.hideFilterResults();
        },

        refreshTrendsPage: function () {
            const $button = $(this);
            const originalText = $button.text();

            $button.prop('disabled', true).html('<span class="vrsc-spinner"></span>' + 'Refreshing...');

            // Reload the page to get fresh data
            window.location.reload();
        },

        showFilterResults: function (count) {
            let message = count + ' trend(s) match your filters';

            // Remove existing filter notice
            $('.vrsc-filter-notice').remove();

            // Add filter notice
            const notice = $('<div class="vrsc-filter-notice" style="background: #e7f3ff; border: 1px solid #72aee6; padding: 8px 12px; margin: 10px 0; border-radius: 4px;">' + message + '</div>');
            $('.vrsc-trends-table-container').before(notice);
        },

        hideFilterResults: function () {
            $('.vrsc-filter-notice').remove();
        },

        // Debug function for troubleshooting
        debug: function () {
            console.log('ViraScopeAdmin Debug Info:');
            console.log('- jQuery version:', $.fn.jquery);
            console.log('- AJAX URL:', vrsc_ajax?.ajax_url);
            console.log('- Nonce:', vrsc_ajax?.nonce);
            console.log('- Available methods:', Object.keys(this).filter(key => typeof this[key] === 'function'));
            console.log('- Global accessibility:', typeof window.ViraScopeAdmin !== 'undefined');
        },

        debugContent: function () {
            console.log('Running content debug...');

            $.ajax({
                url: vrsc_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrsc_debug_content',
                    nonce: vrsc_ajax.nonce
                },
                success: function (response) {
                    console.log('Content Debug Results:', response);
                    if (response.success) {
                        const data = response.data;
                        console.log('Posts:', data.posts);
                        console.log('Pages:', data.pages);
                        if (data.keyword_test) {
                            console.log('Keyword Test:', data.keyword_test);
                        }

                        // Show results in alert for easy viewing
                        let message = 'Content Debug Results:\\n\\n';
                        message += `Posts: ${data.posts.total} total, ${data.posts.sample_count} sampled\\n`;
                        message += `Pages: ${data.pages.total} total, ${data.pages.sample_count} sampled\\n`;
                        if (data.keyword_test) {
                            message += `\\nKeyword Test (${data.keyword_test.post_title}):\\n`;
                            message += `Content Length: ${data.keyword_test.content_length}\\n`;
                            message += `Keywords Found: ${data.keyword_test.keywords_found}\\n`;
                            message += `Sample Keywords: ${data.keyword_test.sample_keywords.join(', ')}`;
                        }

                        alert(message);
                    }
                },
                error: function (xhr, status, error) {
                    console.error('Debug content error:', error);
                }
            });
        },

        viewAnalysis: function () {
            const keyword = $(this).data('keyword');

            $('#vrsc-modal-title').text('Analysis for: ' + keyword);
            $('#vrsc-modal-body').html('<div class="vrsc-spinner"></div> Loading analysis...');
            $('#vrsc-analysis-modal').show();

            $.ajax({
                url: vrsc_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrsc_get_keyword_analysis',
                    keyword: keyword,
                    nonce: vrsc_ajax.nonce
                },
                success: function (response) {
                    if (response.success) {
                        ViraScopeAdmin.displayModalAnalysis(response.data);
                    } else {
                        $('#vrsc-modal-body').html('<p>Failed to load analysis data.</p>');
                    }
                },
                error: function () {
                    $('#vrsc-modal-body').html('<p>Network error occurred.</p>');
                }
            });
        },

        displayModalAnalysis: function (data) {
            let html = '';

            if (data.ai_analysis) {
                try {
                    const analysis = JSON.parse(data.ai_analysis);

                    html += '<div class="vrsc-modal-analysis">';
                    html += '<div class="vrsc-analysis-grid">';
                    html += '<div><strong>Trend Score:</strong> ' + (analysis.trend_score || data.trend_score) + '%</div>';
                    html += '<div><strong>Search Volume:</strong> ' + (analysis.search_volume_estimate || data.search_volume) + '</div>';
                    html += '<div><strong>Competition:</strong> ' + (analysis.competition_level || data.competition_level) + '</div>';
                    html += '<div><strong>Trend Direction:</strong> ' + (analysis.trend_direction || 'N/A') + '</div>';
                    html += '</div>';

                    if (analysis.summary) {
                        html += '<h4>Summary</h4>';
                        html += '<p>' + analysis.summary + '</p>';
                    }

                    if (analysis.opportunities && analysis.opportunities.length > 0) {
                        html += '<h4>Opportunities</h4>';
                        html += '<ul>';
                        analysis.opportunities.forEach(function (opportunity) {
                            html += '<li>' + opportunity + '</li>';
                        });
                        html += '</ul>';
                    }

                    if (analysis.related_keywords && analysis.related_keywords.length > 0) {
                        html += '<h4>Related Keywords</h4>';
                        html += '<div class="vrsc-related-keywords">';
                        analysis.related_keywords.forEach(function (keyword) {
                            html += '<span class="vrsc-keyword-tag">' + keyword + '</span>';
                        });
                        html += '</div>';
                    }

                    html += '</div>';
                } catch (e) {
                    html = '<p>Raw analysis data:</p><pre>' + data.ai_analysis + '</pre>';
                }
            } else {
                html = '<p>No detailed analysis available for this keyword.</p>';
            }

            $('#vrsc-modal-body').html(html);
        },

        closeModal: function () {
            $('.vrsc-modal').hide();
        },

        testAIConnection: function () {
            const $button = $(this);
            const originalText = $button.text();

            $button.prop('disabled', true).html('<span class="vrsc-spinner"></span>' + 'Testing...');

            $.ajax({
                url: vrsc_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrsc_test_ai_connection',
                    nonce: vrsc_ajax.nonce
                },
                success: function (response) {
                    if (response.success) {
                        let message = 'AI connection successful!';
                        if (response.data.provider) {
                            message += ' (Using ' + response.data.provider + ')';
                        }
                        ViraScopeAdmin.showNotice(message, 'success');
                    } else {
                        let errorMessage = 'AI connection failed';
                        if (response.data && response.data.error) {
                            errorMessage += ': ' + response.data.error;
                        }
                        if (response.data && response.data.details) {
                            console.log('AI Connection Error Details:', response.data.details);
                        }
                        ViraScopeAdmin.showNotice(errorMessage, 'error');
                    }
                },
                error: function () {
                    ViraScopeAdmin.showNotice('Network error occurred', 'error');
                },
                complete: function () {
                    $button.prop('disabled', false).text(originalText);
                }
            });
        },

        clearAllCache: function () {
            if (!confirm('Are you sure you want to clear all cache data?')) {
                return;
            }

            const $button = $(this);
            const originalText = $button.text();

            $button.prop('disabled', true).html('<span class="vrsc-spinner"></span>' + 'Clearing...');

            $.ajax({
                url: vrsc_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrsc_clear_all_cache',
                    nonce: vrsc_ajax.nonce
                },
                success: function (response) {
                    if (response.success) {
                        ViraScopeAdmin.showNotice('All cache cleared successfully!', 'success');
                    } else {
                        ViraScopeAdmin.showNotice(response.data || 'Failed to clear cache', 'error');
                    }
                },
                error: function () {
                    ViraScopeAdmin.showNotice('Network error occurred', 'error');
                },
                complete: function () {
                    $button.prop('disabled', false).text(originalText);
                }
            });
        },

        showNotice: function (message, type) {
            const noticeClass = type === 'success' ? 'notice-success' : 'notice-error';
            const $notice = $('<div class="notice ' + noticeClass + ' is-dismissible"><p>' + message + '</p></div>');

            $('.wrap h1').after($notice);

            setTimeout(function () {
                $notice.fadeOut(function () {
                    $(this).remove();
                });
            }, 5000);
        }
    };

    // Make ViraScopeAdmin globally accessible immediately
    window.ViraScopeAdmin = ViraScopeAdmin;

    // Initialize when document is ready
    $(document).ready(function () {
        // Ensure global access is available
        if (typeof window.ViraScopeAdmin === 'undefined') {
            window.ViraScopeAdmin = ViraScopeAdmin;
        }
        ViraScopeAdmin.init();
    });

})(jQuery);