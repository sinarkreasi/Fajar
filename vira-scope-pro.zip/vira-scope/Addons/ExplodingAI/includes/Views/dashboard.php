<?php
/**
 * Exploding AI Dashboard View
 *
 * File ini berfungsi sebagai tampilan (view) untuk halaman dashboard AI Trending Topics.
 */

// Mencegah akses langsung ke file.
if (!defined('ABSPATH')) {
    exit;
}

use ViraScope\Addons\ExplodingAI\Models\ExplodingAIModel;

// Persiapan data
$model = new ExplodingAIModel();
$stats = $model->get_statistics();
$recent_trends = $model->get_trends(['limit' => 10]);
$categories = $model->get_trending_categories();

$service_categories = (new \ViraScope\Addons\ExplodingAI\Services\ExplodingAIService())->get_available_categories();
$category_options = [];

foreach ($service_categories as $key => $label) {
    $category_options[$key] = [
        'label' => $label,
        'count' => 0,
    ];
}

foreach ($categories as $category) {
    $key = $category->category;
    if (!isset($category_options[$key])) {
        $category_options[$key] = [
            'label' => ucfirst($key),
            'count' => 0,
        ];
    }

    $category_options[$key]['count'] = intval($category->count);
}

// Terapkan praktik terbaik: Sanitasi dan default untuk data statistik
$total_trends = esc_html($stats['total_trends'] ?? 0);
$recent_trends_count = esc_html($stats['recent_trends'] ?? 0);
$avg_growth = esc_html(round($stats['avg_growth'] ?? 0, 1));
$exploding_count = esc_html($stats['exploding_count'] ?? 0);

?>

<div class="wrap">
    <h1><?php _e('AI Trending Topics', 'vira-scope'); ?></h1>

    <div class="exploding-ai-stats">
        <div class="stat-card">
            <h3><?php echo $total_trends; ?></h3>
            <p><?php _e('Total Trends', 'vira-scope'); ?></p>
        </div>
        <div class="stat-card">
            <h3><?php echo $recent_trends_count; ?></h3>
            <p><?php _e('Last 24 Hours', 'vira-scope'); ?></p>
        </div>
        <div class="stat-card">
            <h3><?php echo $avg_growth; ?>%</h3>
            <p><?php _e('Avg Growth', 'vira-scope'); ?></p>
        </div>
        <div class="stat-card">
            <h3><?php echo $exploding_count; ?></h3>
            <p><?php _e('Exploding Now', 'vira-scope'); ?></p>
        </div>
    </div>

    <hr>

    <div class="exploding-ai-controls">
        <button id="fetch-trends" class="button button-primary">
            <?php _e('Fetch New Trends', 'vira-scope'); ?>
        </button>
        <button id="refresh-data" class="button">
            <?php _e('Refresh All Data', 'vira-scope'); ?>
        </button>

        <div class="filter-controls">
            <select id="category-filter">
                <option value=""><?php _e('All Categories', 'vira-scope'); ?></option>
                <?php foreach ($category_options as $category_key => $category_data):
                    $count_value = isset($category_data['count']) ? (int) $category_data['count'] : 0;
                    $count_display = number_format_i18n($count_value);
                ?>
                    <option value="<?php echo esc_attr($category_key); ?>">
                        <?php echo esc_html($category_data['label']); ?> (<?php echo esc_html($count_display); ?>)
                    </option>
                <?php endforeach; ?>
            </select>

            <select id="stage-filter">
                <option value=""><?php _e('All Stages', 'vira-scope'); ?></option>
                <option value="Emerging"><?php _e('Emerging', 'vira-scope'); ?></option>
                <option value="Growing"><?php _e('Growing', 'vira-scope'); ?></option>
                <option value="Exploding"><?php _e('Exploding', 'vira-scope'); ?></option>
                <option value="Declining"><?php _e('Declining', 'vira-scope'); ?></option>
            </select>

            <input type="number" id="min-growth" placeholder="<?php _e('Min Growth %', 'vira-scope'); ?>" min="0" step="0.1">

            <button id="apply-filters" class="button"><?php _e('Apply Filters', 'vira-scope'); ?></button>
        </div>
    </div>

    <hr>

    <div class="exploding-ai-trends">
        <h2><?php _e('Recent Trends', 'vira-scope'); ?></h2>
        <div id="trends-container">
            <?php if (!empty($recent_trends)): ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php _e('Topic', 'vira-scope'); ?></th>
                            <th><?php _e('Growth', 'vira-scope'); ?></th>
                            <th><?php _e('Volume', 'vira-scope'); ?></th>
                            <th><?php _e('Stage', 'vira-scope'); ?></th>
                            <th><?php _e('Category', 'vira-scope'); ?></th>
                            <th><?php _e('Provider', 'vira-scope'); ?></th>
                            <th><?php _e('Date', 'vira-scope'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_trends as $trend): ?>
                            <tr>
                                <td>
                                    <strong><?php echo esc_html($trend->topic); ?></strong>
                                    <?php if (!empty($trend->short_description)): ?>
                                        <br><small><?php echo esc_html($trend->short_description); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php
                                    // Logika kelas pertumbuhan bisa diringkas di model atau helper, tapi tetap di sini
                                    $growth_class = 'growth-low';
                                    if ($trend->growth >= 100) {
                                        $growth_class = 'growth-exploding';
                                    } elseif ($trend->growth >= 50) {
                                        $growth_class = 'growth-high';
                                    } elseif ($trend->growth >= 20) {
                                        $growth_class = 'growth-medium';
                                    }
                                    ?>
                                    <span class="growth-badge <?php echo esc_attr($growth_class); ?>">
                                        <?php echo esc_html($trend->growth); ?>%
                                    </span>
                                </td>
                                <td><?php echo esc_html(number_format($trend->search_volume ?? 0)); ?></td>
                                <td>
                                    <span class="stage-badge stage-<?php echo esc_attr(strtolower($trend->trend_stage)); ?>">
                                        <?php echo esc_html($trend->trend_stage); ?>
                                    </span>
                                </td>
                                <td><?php echo esc_html(ucfirst($trend->category)); ?></td>
                                <td><?php echo esc_html(strtoupper($trend->ai_provider)); ?></td>
                                <td><?php echo esc_html(date('M j, Y H:i', strtotime($trend->created_at))); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="no-trends">
                    <p><?php _e('No trends available yet. Click "Fetch New Trends" to get started.', 'vira-scope'); ?></p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div id="loading-indicator" style="display: none;">
        <p><?php _e('Loading trends...', 'vira-scope'); ?></p>
    </div>

    <hr>

    <div class="exploding-ai-api-info">
        <h2><?php _e('API Endpoints', 'vira-scope'); ?></h2>
        <div class="api-endpoints">
            <div class="endpoint">
                <strong>GET</strong> <code>/wp-json/virascope/v1/exploding-ai/trends</code>
                <p><?php _e('Get all trends with filtering options', 'vira-scope'); ?></p>
            </div>
            <div class="endpoint">
                <strong>GET</strong> <code>/wp-json/virascope/v1/exploding-ai/trends/top</code>
                <p><?php _e('Get top trending topics', 'vira-scope'); ?></p>
            </div>
            <div class="endpoint">
                <strong>GET</strong> <code>/wp-json/virascope/v1/exploding-ai/trends/exploding</code>
                <p><?php _e('Get exploding trends (high growth)', 'vira-scope'); ?></p>
            </div>
            <div class="endpoint">
                <strong>GET</strong> <code>/wp-json/virascope/v1/exploding-ai/trends/search?q=term</code>
                <p><?php _e('Search trends by keyword', 'vira-scope'); ?></p>
            </div>
            <div class="endpoint">
                <strong>GET</strong> <code>/wp-json/virascope/v1/exploding-ai/stats</code>
                <p><?php _e('Get trend statistics', 'vira-scope'); ?></p>
            </div>
            <div class="endpoint">
                <strong>POST</strong> <code>/wp-json/virascope/v1/exploding-ai/fetch</code>
                <p><?php _e('Fetch new trends (admin only)', 'vira-scope'); ?></p>
            </div>
        </div>
    </div>
</div>