<?php
/**
 * Exploding AI Model - Database operations for AI trends
 */

namespace ViraScope\Addons\ExplodingAI\Models;

if (!defined('ABSPATH')) {
    exit;
}

class ExplodingAIModel {

    private $table_name;

    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'vrsc_trends_ai';
    }

    public function get_trends($args = []) {
        global $wpdb;

        $defaults = [
            'category' => '',
            'min_growth' => 0,
            'trend_stage' => '',
            'limit' => 20,
            'offset' => 0,
            'orderby' => 'growth',
            'order' => 'DESC'
        ];

        $args = wp_parse_args($args, $defaults);

        $where_conditions = ['1=1'];
        $where_values = [];

        if (!empty($args['category'])) {
            $where_conditions[] = 'category = %s';
            $where_values[] = $args['category'];
        }

        if ($args['min_growth'] > 0) {
            $where_conditions[] = 'growth >= %f';
            $where_values[] = $args['min_growth'];
        }

        if (!empty($args['trend_stage'])) {
            $where_conditions[] = 'trend_stage = %s';
            $where_values[] = $args['trend_stage'];
        }

        // Only get trends from last 7 days
        $where_conditions[] = 'created_at >= %s';
        $where_values[] = date('Y-m-d H:i:s', strtotime('-7 days'));

        $where_clause = implode(' AND ', $where_conditions);
        $orderby = sanitize_sql_orderby($args['orderby'] . ' ' . $args['order']);
        
        $sql = "SELECT * FROM {$this->table_name} WHERE {$where_clause} ORDER BY {$orderby} LIMIT %d OFFSET %d";
        $where_values[] = $args['limit'];
        $where_values[] = $args['offset'];

        if (!empty($where_values)) {
            $sql = $wpdb->prepare($sql, $where_values);
        }

        return $wpdb->get_results($sql);
    }

    public function get_trend_by_id($id) {
        global $wpdb;

        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE id = %d",
            $id
        ));
    }

    public function get_trending_categories() {
        global $wpdb;

        return $wpdb->get_results(
            "SELECT category, COUNT(*) as count, AVG(growth) as avg_growth 
             FROM {$this->table_name} 
             WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
             GROUP BY category 
             ORDER BY avg_growth DESC"
        );
    }

    public function get_top_trends($limit = 10) {
        global $wpdb;

        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->table_name} 
             WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
             ORDER BY growth DESC 
             LIMIT %d",
            $limit
        ));
    }

    public function get_exploding_trends($min_growth = 100, $limit = 20) {
        global $wpdb;

        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->table_name} 
             WHERE growth >= %f 
             AND trend_stage = 'Exploding'
             AND created_at >= DATE_SUB(NOW(), INTERVAL 48 HOUR)
             ORDER BY growth DESC 
             LIMIT %d",
            $min_growth,
            $limit
        ));
    }

    public function get_emerging_trends($max_growth = 50, $limit = 20) {
        global $wpdb;

        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->table_name} 
             WHERE growth <= %f 
             AND trend_stage = 'Emerging'
             AND created_at >= DATE_SUB(NOW(), INTERVAL 48 HOUR)
             ORDER BY growth DESC 
             LIMIT %d",
            $max_growth,
            $limit
        ));
    }

    public function search_trends($search_term, $limit = 20) {
        global $wpdb;

        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->table_name} 
             WHERE (topic LIKE %s OR short_description LIKE %s)
             AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
             ORDER BY growth DESC 
             LIMIT %d",
            '%' . $wpdb->esc_like($search_term) . '%',
            '%' . $wpdb->esc_like($search_term) . '%',
            $limit
        ));
    }

    public function get_statistics() {
        global $wpdb;

        $stats = [];

        // Total trends
        $stats['total_trends'] = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$this->table_name}"
        );

        // Trends in last 24 hours
        $stats['recent_trends'] = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$this->table_name} 
             WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)"
        );

        // Average growth
        $stats['avg_growth'] = $wpdb->get_var(
            "SELECT AVG(growth) FROM {$this->table_name} 
             WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)"
        );

        // Top category
        $top_category = $wpdb->get_row(
            "SELECT category, COUNT(*) as count FROM {$this->table_name} 
             WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
             GROUP BY category 
             ORDER BY count DESC 
             LIMIT 1"
        );
        $stats['top_category'] = $top_category ? $top_category->category : 'general';

        // Exploding trends count
        $stats['exploding_count'] = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$this->table_name} 
             WHERE trend_stage = 'Exploding' 
             AND created_at >= DATE_SUB(NOW(), INTERVAL 48 HOUR)"
        );

        return $stats;
    }

    public function delete_old_trends($days = 30) {
        global $wpdb;

        return $wpdb->query($wpdb->prepare(
            "DELETE FROM {$this->table_name} WHERE created_at < DATE_SUB(NOW(), INTERVAL %d DAY)",
            $days
        ));
    }

    public function save_trend($trend_data) {
        global $wpdb;

        $defaults = [
            'topic' => '',
            'growth' => 0,
            'search_volume' => 0,
            'trend_stage' => 'Emerging',
            'short_description' => '',
            'category' => 'general',
            'ai_provider' => 'gemini',
            'raw_data' => '{}'
        ];

        $trend_data = wp_parse_args($trend_data, $defaults);

        return $wpdb->insert(
            $this->table_name,
            $trend_data,
            ['%s', '%f', '%d', '%s', '%s', '%s', '%s', '%s']
        );
    }

    public function update_trend($id, $trend_data) {
        global $wpdb;

        return $wpdb->update(
            $this->table_name,
            $trend_data,
            ['id' => $id],
            ['%s', '%f', '%d', '%s', '%s', '%s', '%s', '%s'],
            ['%d']
        );
    }

    public function delete_trend($id) {
        global $wpdb;

        return $wpdb->delete(
            $this->table_name,
            ['id' => $id],
            ['%d']
        );
    }

    public function get_growth_distribution() {
        global $wpdb;

        return $wpdb->get_results(
            "SELECT 
                CASE 
                    WHEN growth >= 200 THEN 'Explosive (200%+)'
                    WHEN growth >= 100 THEN 'High (100-199%)'
                    WHEN growth >= 50 THEN 'Medium (50-99%)'
                    WHEN growth >= 20 THEN 'Low (20-49%)'
                    ELSE 'Minimal (0-19%)'
                END as growth_range,
                COUNT(*) as count
             FROM {$this->table_name} 
             WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
             GROUP BY growth_range
             ORDER BY MIN(growth) DESC"
        );
    }

    public function get_trends_by_provider() {
        global $wpdb;

        return $wpdb->get_results(
            "SELECT ai_provider, COUNT(*) as count, AVG(growth) as avg_growth
             FROM {$this->table_name} 
             WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
             GROUP BY ai_provider
             ORDER BY count DESC"
        );
    }
}