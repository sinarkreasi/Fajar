<?php
/**
 * Exploding AI API - REST endpoints for AI trends
 */

namespace ViraScope\Addons\ExplodingAI\API;

use ViraScope\Addons\ExplodingAI\Models\ExplodingAIModel;
use ViraScope\Addons\ExplodingAI\Services\ExplodingAIService;
use WP_REST_Request;
use WP_REST_Response;
use WP_Error;

if (!defined('ABSPATH')) {
    exit;
}

class ExplodingAIAPI {

    private $model;
    private $service;

    public function __construct() {
        $this->model = new ExplodingAIModel();
        $this->service = new ExplodingAIService();
        add_action('rest_api_init', [$this, 'register_routes']);
    }

    public function register_routes() {
        $namespace = 'virascope/v1';

        // Get trends with filtering
        register_rest_route($namespace, '/exploding-ai/trends', [
            'methods' => 'GET',
            'callback' => [$this, 'get_trends'],
            'permission_callback' => [$this, 'check_permissions'],
            'args' => [
                'category' => [
                    'type' => 'string',
                    'default' => '',
                    'sanitize_callback' => 'sanitize_text_field'
                ],
                'min_growth' => [
                    'type' => 'number',
                    'default' => 0,
                    'minimum' => 0
                ],
                'trend_stage' => [
                    'type' => 'string',
                    'default' => '',
                    'enum' => ['', 'Emerging', 'Growing', 'Exploding', 'Declining']
                ],
                'limit' => [
                    'type' => 'integer',
                    'default' => 20,
                    'minimum' => 1,
                    'maximum' => 100
                ],
                'offset' => [
                    'type' => 'integer',
                    'default' => 0,
                    'minimum' => 0
                ],
                'orderby' => [
                    'type' => 'string',
                    'default' => 'growth',
                    'enum' => ['growth', 'search_volume', 'created_at', 'topic']
                ],
                'order' => [
                    'type' => 'string',
                    'default' => 'DESC',
                    'enum' => ['ASC', 'DESC']
                ]
            ]
        ]);

        // Get single trend by ID
        register_rest_route($namespace, '/exploding-ai/trends/(?P<id>\d+)', [
            'methods' => 'GET',
            'callback' => [$this, 'get_trend'],
            'permission_callback' => [$this, 'check_permissions'],
            'args' => [
                'id' => [
                    'type' => 'integer',
                    'required' => true,
                    'minimum' => 1
                ]
            ]
        ]);

        // Get top trends
        register_rest_route($namespace, '/exploding-ai/trends/top', [
            'methods' => 'GET',
            'callback' => [$this, 'get_top_trends'],
            'permission_callback' => [$this, 'check_permissions'],
            'args' => [
                'limit' => [
                    'type' => 'integer',
                    'default' => 10,
                    'minimum' => 1,
                    'maximum' => 50
                ]
            ]
        ]);

        // Get exploding trends
        register_rest_route($namespace, '/exploding-ai/trends/exploding', [
            'methods' => 'GET',
            'callback' => [$this, 'get_exploding_trends'],
            'permission_callback' => [$this, 'check_permissions'],
            'args' => [
                'min_growth' => [
                    'type' => 'number',
                    'default' => 100,
                    'minimum' => 0
                ],
                'limit' => [
                    'type' => 'integer',
                    'default' => 20,
                    'minimum' => 1,
                    'maximum' => 50
                ]
            ]
        ]);

        // Get emerging trends
        register_rest_route($namespace, '/exploding-ai/trends/emerging', [
            'methods' => 'GET',
            'callback' => [$this, 'get_emerging_trends'],
            'permission_callback' => [$this, 'check_permissions'],
            'args' => [
                'max_growth' => [
                    'type' => 'number',
                    'default' => 50,
                    'minimum' => 0
                ],
                'limit' => [
                    'type' => 'integer',
                    'default' => 20,
                    'minimum' => 1,
                    'maximum' => 50
                ]
            ]
        ]);

        // Search trends
        register_rest_route($namespace, '/exploding-ai/trends/search', [
            'methods' => 'GET',
            'callback' => [$this, 'search_trends'],
            'permission_callback' => [$this, 'check_permissions'],
            'args' => [
                'q' => [
                    'type' => 'string',
                    'required' => true,
                    'minLength' => 2,
                    'sanitize_callback' => 'sanitize_text_field'
                ],
                'limit' => [
                    'type' => 'integer',
                    'default' => 20,
                    'minimum' => 1,
                    'maximum' => 50
                ]
            ]
        ]);

        // Get trending categories
        register_rest_route($namespace, '/exploding-ai/categories', [
            'methods' => 'GET',
            'callback' => [$this, 'get_trending_categories'],
            'permission_callback' => [$this, 'check_permissions']
        ]);

        // Get statistics
        register_rest_route($namespace, '/exploding-ai/stats', [
            'methods' => 'GET',
            'callback' => [$this, 'get_statistics'],
            'permission_callback' => [$this, 'check_permissions']
        ]);

        // Get growth distribution
        register_rest_route($namespace, '/exploding-ai/analytics/growth-distribution', [
            'methods' => 'GET',
            'callback' => [$this, 'get_growth_distribution'],
            'permission_callback' => [$this, 'check_permissions']
        ]);

        // Get trends by provider
        register_rest_route($namespace, '/exploding-ai/analytics/by-provider', [
            'methods' => 'GET',
            'callback' => [$this, 'get_trends_by_provider'],
            'permission_callback' => [$this, 'check_permissions']
        ]);

        // Fetch new trends (admin only)
        register_rest_route($namespace, '/exploding-ai/fetch', [
            'methods' => 'POST',
            'callback' => [$this, 'fetch_new_trends'],
            'permission_callback' => [$this, 'check_admin_permissions'],
            'args' => [
                'force' => [
                    'type' => 'boolean',
                    'default' => false
                ]
            ]
        ]);

        // Delete old trends (admin only)
        register_rest_route($namespace, '/exploding-ai/cleanup', [
            'methods' => 'DELETE',
            'callback' => [$this, 'cleanup_old_trends'],
            'permission_callback' => [$this, 'check_admin_permissions'],
            'args' => [
                'days' => [
                    'type' => 'integer',
                    'default' => 30,
                    'minimum' => 1,
                    'maximum' => 365
                ]
            ]
        ]);
    }

    public function get_trends(WP_REST_Request $request) {
        try {
            $args = [
                'category' => $request->get_param('category'),
                'min_growth' => $request->get_param('min_growth'),
                'trend_stage' => $request->get_param('trend_stage'),
                'limit' => $request->get_param('limit'),
                'offset' => $request->get_param('offset'),
                'orderby' => $request->get_param('orderby'),
                'order' => $request->get_param('order')
            ];

            $trends = $this->model->get_trends($args);
            
            return new WP_REST_Response([
                'success' => true,
                'data' => $trends,
                'total' => count($trends),
                'args' => $args
            ], 200);

        } catch (Exception $e) {
            return new WP_Error('fetch_error', $e->getMessage(), ['status' => 500]);
        }
    }

    public function get_trend(WP_REST_Request $request) {
        try {
            $id = $request->get_param('id');
            $trend = $this->model->get_trend_by_id($id);

            if (!$trend) {
                return new WP_Error('not_found', 'Trend not found', ['status' => 404]);
            }

            return new WP_REST_Response([
                'success' => true,
                'data' => $trend
            ], 200);

        } catch (Exception $e) {
            return new WP_Error('fetch_error', $e->getMessage(), ['status' => 500]);
        }
    }

    public function get_top_trends(WP_REST_Request $request) {
        try {
            $limit = $request->get_param('limit');
            $trends = $this->model->get_top_trends($limit);

            return new WP_REST_Response([
                'success' => true,
                'data' => $trends,
                'total' => count($trends)
            ], 200);

        } catch (Exception $e) {
            return new WP_Error('fetch_error', $e->getMessage(), ['status' => 500]);
        }
    }

    public function get_exploding_trends(WP_REST_Request $request) {
        try {
            $min_growth = $request->get_param('min_growth');
            $limit = $request->get_param('limit');
            $trends = $this->model->get_exploding_trends($min_growth, $limit);

            return new WP_REST_Response([
                'success' => true,
                'data' => $trends,
                'total' => count($trends),
                'min_growth' => $min_growth
            ], 200);

        } catch (Exception $e) {
            return new WP_Error('fetch_error', $e->getMessage(), ['status' => 500]);
        }
    }

    public function get_emerging_trends(WP_REST_Request $request) {
        try {
            $max_growth = $request->get_param('max_growth');
            $limit = $request->get_param('limit');
            $trends = $this->model->get_emerging_trends($max_growth, $limit);

            return new WP_REST_Response([
                'success' => true,
                'data' => $trends,
                'total' => count($trends),
                'max_growth' => $max_growth
            ], 200);

        } catch (Exception $e) {
            return new WP_Error('fetch_error', $e->getMessage(), ['status' => 500]);
        }
    }

    public function search_trends(WP_REST_Request $request) {
        try {
            $search_term = $request->get_param('q');
            $limit = $request->get_param('limit');
            $trends = $this->model->search_trends($search_term, $limit);

            return new WP_REST_Response([
                'success' => true,
                'data' => $trends,
                'total' => count($trends),
                'search_term' => $search_term
            ], 200);

        } catch (Exception $e) {
            return new WP_Error('search_error', $e->getMessage(), ['status' => 500]);
        }
    }

    public function get_trending_categories(WP_REST_Request $request) {
        try {
            $categories = $this->model->get_trending_categories();

            return new WP_REST_Response([
                'success' => true,
                'data' => $categories,
                'total' => count($categories)
            ], 200);

        } catch (Exception $e) {
            return new WP_Error('fetch_error', $e->getMessage(), ['status' => 500]);
        }
    }

    public function get_statistics(WP_REST_Request $request) {
        try {
            $stats = $this->model->get_statistics();

            return new WP_REST_Response([
                'success' => true,
                'data' => $stats
            ], 200);

        } catch (Exception $e) {
            return new WP_Error('fetch_error', $e->getMessage(), ['status' => 500]);
        }
    }

    public function get_growth_distribution(WP_REST_Request $request) {
        try {
            $distribution = $this->model->get_growth_distribution();

            return new WP_REST_Response([
                'success' => true,
                'data' => $distribution,
                'total' => count($distribution)
            ], 200);

        } catch (Exception $e) {
            return new WP_Error('fetch_error', $e->getMessage(), ['status' => 500]);
        }
    }

    public function get_trends_by_provider(WP_REST_Request $request) {
        try {
            $providers = $this->model->get_trends_by_provider();

            return new WP_REST_Response([
                'success' => true,
                'data' => $providers,
                'total' => count($providers)
            ], 200);

        } catch (Exception $e) {
            return new WP_Error('fetch_error', $e->getMessage(), ['status' => 500]);
        }
    }

    public function fetch_new_trends(WP_REST_Request $request) {
        try {
            $force = $request->get_param('force');
            $result = $this->service->fetch_trends($force);

            if ($result['success']) {
                return new WP_REST_Response([
                    'success' => true,
                    'message' => 'Trends fetched successfully',
                    'data' => $result
                ], 200);
            } else {
                return new WP_Error('fetch_failed', $result['message'], ['status' => 500]);
            }

        } catch (Exception $e) {
            return new WP_Error('fetch_error', $e->getMessage(), ['status' => 500]);
        }
    }

    public function cleanup_old_trends(WP_REST_Request $request) {
        try {
            $days = $request->get_param('days');
            $deleted = $this->model->delete_old_trends($days);

            return new WP_REST_Response([
                'success' => true,
                'message' => "Deleted {$deleted} old trends",
                'deleted_count' => $deleted,
                'days' => $days
            ], 200);

        } catch (Exception $e) {
            return new WP_Error('cleanup_error', $e->getMessage(), ['status' => 500]);
        }
    }

    public function check_permissions() {
        // Allow logged-in users to read trends
        return is_user_logged_in();
    }

    public function check_admin_permissions() {
        // Only admins can fetch new trends or cleanup
        return current_user_can('manage_options');
    }
}