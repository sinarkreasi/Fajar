<?php
/**
 * Exploding AI Service - Core trend discovery engine
 */

namespace ViraScope\Addons\ExplodingAI\Services;

use ViraScope\Services\AIService;
use ViraScope\Helpers\CacheHelper;

if (!defined('ABSPATH')) {
    exit;
}

class ExplodingAIService {

    private $ai_service;
    private $cache_helper;

    public function __construct() {
        $this->ai_service = new AIService();
        $this->cache_helper = new CacheHelper();
    }

    public function fetch_ai_trends($category = 'general', $limit = 20) {
        $cache_key = 'exploding_ai_trends_' . $category . '_' . $limit;
        $cached = $this->cache_helper->get($cache_key);

        if ($cached !== false) {
            return $cached;
        }

        // Build AI prompt for trend discovery
        $prompt = $this->build_trend_prompt($category, $limit);
        
        // Try to get trends from AI
        $ai_response = $this->get_ai_trends($prompt);
        
        if (!$ai_response) {
            return false;
        }

        // Parse and save trends
        $trends = $this->parse_ai_trends($ai_response, $category);
        
        if (!empty($trends)) {
            $this->save_trends($trends);
            $this->cache_helper->set($cache_key, $trends, 3600); // Cache for 1 hour
        }

        return $trends;
    }

    public function generate_forecast($keyword, $period = '3', $category = 'general') {
        $period = preg_replace('/[^0-9]/', '', (string) $period);
        $period = $period !== '' ? $period : '3';
        $keyword = trim($keyword);

        if (empty($keyword)) {
            return false;
        }

        $prompt = $this->build_forecast_prompt($keyword, $period, $category);
        $ai_response = $this->get_ai_trends($prompt);

        if (!$ai_response) {
            return false;
        }

        return $this->parse_forecast_response($ai_response, $keyword, $period, $category);
    }

    public function analyze_competitor($domain, $analysis_type = 'keywords') {
        $domain = trim($domain);

        if (empty($domain)) {
            return false;
        }

        $prompt = $this->build_competitor_prompt($domain, $analysis_type);
        $ai_response = $this->get_ai_trends($prompt);

        if (!$ai_response) {
            return false;
        }

        return $this->parse_competitor_response($ai_response, $domain, $analysis_type);
    }

    public function analyze_geo_trends($country, $region = '', $timeframe = '7d') {
        $country = strtoupper(preg_replace('/[^A-Z]/i', '', $country));
        $region = trim($region);
        $timeframe = trim($timeframe);

        if (empty($country)) {
            $country = 'US';
        }

        if (empty($timeframe)) {
            $timeframe = '7d';
        }

        $prompt = $this->build_geo_prompt($country, $region, $timeframe);
        $ai_response = $this->get_ai_trends($prompt);

        if (!$ai_response) {
            return false;
        }

        return $this->parse_geo_response($ai_response, $country, $region, $timeframe);
    }

    public function compare_geo_regions(array $regions, $timeframe = '7d') {
        $clean_regions = array_unique(array_filter(array_map(function ($region) {
            return strtoupper(preg_replace('/[^A-Z]/i', '', $region));
        }, $regions)));

        if (count($clean_regions) < 2) {
            return false;
        }

        $timeframe = trim($timeframe) ?: '7d';

        $prompt = $this->build_geo_compare_prompt($clean_regions, $timeframe);
        $ai_response = $this->get_ai_trends($prompt);

        if (!$ai_response) {
            return $this->generate_sample_geo_comparison($clean_regions, $timeframe);
        }

        $parsed = $this->parse_geo_compare_response($ai_response, $clean_regions, $timeframe);

        if (!$parsed) {
            return $this->generate_sample_geo_comparison($clean_regions, $timeframe);
        }

        return $parsed;
    }

    private function build_forecast_prompt($keyword, $period, $category) {
        $category_context = $this->get_category_context($category);
        $period_label = intval($period) === 1 ? '1 month' : intval($period) . ' months';

        return "You are an advanced trend forecasting system that predicts topic momentum using search and social signals.\n\n" .
               "Generate a detailed forecast for the topic \"{$keyword}\" over the next {$period_label}.\n" .
               "{$category_context}\n\n" .
               "Return strict JSON with the following structure:\n" .
               "{\n" .
               "  \"forecast\": {\n" .
               "    \"overview\": {\n" .
               "      \"trend_score\": number (0-100),\n" .
               "      \"confidence\": number (0-1),\n" .
               "      \"growth_outlook\": string,\n" .
               "      \"peak_period\": string\n" .
               "    },\n" .
               "    \"timeline\": [{\n" .
               "      \"label\": string,\n" .
               "      \"growth_index\": number,\n" .
               "      \"confidence\": number\n" .
               "    }],\n" .
               "    \"insights\": [{\n" .
               "      \"title\": string,\n" .
               "      \"description\": string\n" .
               "    }],\n" .
               "    \"opportunities\": [{\n" .
               "      \"window\": string,\n" .
               "      \"action\": string\n" .
               "    }],\n" .
               "    \"risks\": [{\n" .
               "      \"risk\": string,\n" .
               "      \"mitigation\": string\n" .
               "    }]\n" .
               "  }\n" .
               "}";
    }

    private function parse_forecast_response($ai_response, $keyword, $period, $category) {
        $payload = $this->extract_json($ai_response['content'] ?? '');

        if (empty($payload)) {
            return false;
        }

        if (isset($payload['forecast']) && is_array($payload['forecast'])) {
            $forecast = $payload['forecast'];
        } else {
            $forecast = $payload;
        }

        $overview = $forecast['overview'] ?? [];
        $timeline = $forecast['timeline'] ?? [];
        $insights = $forecast['insights'] ?? [];
        $opportunities = $forecast['opportunities'] ?? [];
        $risks = $forecast['risks'] ?? [];

        return [
            'keyword' => sanitize_text_field($keyword),
            'period' => sanitize_text_field($period),
            'category' => sanitize_text_field($category),
            'provider' => sanitize_text_field($ai_response['provider'] ?? ''),
            'generated_at' => current_time('mysql'),
            'overview' => [
                'trend_score' => isset($overview['trend_score']) ? floatval($overview['trend_score']) : null,
                'confidence' => isset($overview['confidence']) ? floatval($overview['confidence']) : null,
                'growth_outlook' => isset($overview['growth_outlook']) ? sanitize_text_field($overview['growth_outlook']) : '',
                'peak_period' => isset($overview['peak_period']) ? sanitize_text_field($overview['peak_period']) : ''
            ],
            'timeline' => $this->sanitize_timeline($timeline),
            'insights' => $this->sanitize_named_list($insights, ['title', 'description']),
            'opportunities' => $this->sanitize_named_list($opportunities, ['window', 'action']),
            'risks' => $this->sanitize_named_list($risks, ['risk', 'mitigation'])
        ];
    }

    private function build_competitor_prompt($domain, $analysis_type) {
        $analysis_type = strtolower($analysis_type);
        $valid_types = ['keywords', 'content', 'trends', 'backlinks', 'market_positioning', 'brand_authority'];
        if (!in_array($analysis_type, $valid_types, true)) {
            $analysis_type = 'keywords';
        }

        switch ($analysis_type) {
            case 'market_positioning':
                return $this->build_market_positioning_prompt($domain);
            case 'brand_authority':
                return $this->build_brand_authority_prompt($domain);
            default:
                return $this->build_standard_competitor_prompt($domain, $analysis_type);
        }
    }

    private function build_standard_competitor_prompt($domain, $analysis_type) {
        return "You are an SEO competitive intelligence analyst.\n\n" .
               "Evaluate the competitor domain {$domain} focusing on {$analysis_type}.\n" .
               "Return strict JSON with this structure:\n" .
               "{\n" .
               "  \"analysis\": {\n" .
               "    \"summary\": string,\n" .
               "    \"metrics\": {\n" .
               "      \"authority\": number (0-100),\n" .
               "      \"organic_traffic\": number,\n" .
               "      \"keyword_count\": number,\n" .
               "      \"trend_direction\": string\n" .
               "    },\n" .
               "    \"top_keywords\": [{\n" .
               "      \"keyword\": string,\n" .
               "      \"position\": number,\n" .
               "      \"volume\": number\n" .
               "    }],\n" .
               "    \"content_gaps\": [{\n" .
               "      \"topic\": string,\n" .
               "      \"opportunity\": string\n" .
               "    }],\n" .
               "    \"recommendations\": [{\n" .
               "      \"title\": string,\n" .
               "      \"action\": string\n" .
               "    }]\n" .
               "  }\n" .
               "}";
    }

    private function build_market_positioning_prompt($domain) {
        return "You are a go-to-market analyst specializing in brand positioning.\n\n" .
               "Build a positioning profile for {$domain}, grounded in recent public information, marketing messaging, customer reviews, and observable go-to-market tactics.\n" .
               "Return strict JSON with exactly this structure:\n" .
               "{\n" .
               "  \"analysis\": {\n" .
               "    \"summary\": string,\n" .
               "    \"positioning\": {\n" .
               "      \"archetype\": string,\n" .
               "      \"value_proposition\": string,\n" .
               "      \"brand_voice\": string,\n" .
               "      \"audience_segments\": [string],\n" .
               "      \"key_messages\": [string],\n" .
               "      \"positioning_axis\": [{\n" .
               "        \"axis\": string,\n" .
               "        \"placement\": string\n" .
               "      }]\n" .
               "    },\n" .
               "    \"competitive_landscape\": [{\n" .
               "      \"brand\": string,\n" .
               "      \"positioning\": string,\n" .
               "      \"differentiator\": string\n" .
               "    }],\n" .
               "    \"strategic_moves\": [{\n" .
               "      \"title\": string,\n" .
               "      \"action\": string\n" .
               "    }],\n" .
               "    \"growth_channels\": [{\n" .
               "      \"channel\": string,\n" .
               "      \"focus\": string\n" .
               "    }]\n" .
               "  }\n" .
               "}";
    }

    private function build_brand_authority_prompt($domain) {
        return "You are a brand intelligence analyst.\n\n" .
               "Evaluate the brand authority footprint for {$domain} using public performance indicators from SEO tools, social networks, review portals, and press coverage observed up to the current date.\n" .
               "Return strict JSON with exactly this structure:\n" .
               "{\n" .
               "  \"analysis\": {\n" .
               "    \"summary\": string,\n" .
               "    \"brand_scores\": {\n" .
               "      \"brand_equity\": number (0-100),\n" .
               "      \"share_of_voice\": number (0-100),\n" .
               "      \"awareness_index\": number (0-100),\n" .
               "      \"trust_index\": number (0-100)\n" .
               "    },\n" .
               "    \"authority_signals\": [{\n" .
               "      \"signal\": string,\n" .
               "      \"score\": number,\n" .
               "      \"trend\": string\n" .
               "    }],\n" .
               "    \"channel_performance\": [{\n" .
               "      \"channel\": string,\n" .
               "      \"followers\": number,\n" .
               "      \"engagement_rate\": number,\n" .
               "      \"note\": string\n" .
               "    }],\n" .
               "    \"earned_media\": [{\n" .
               "      \"outlet\": string,\n" .
               "      \"highlight\": string,\n" .
               "      \"date\": string\n" .
               "    }],\n" .
               "    \"recommendations\": [{\n" .
               "      \"title\": string,\n" .
               "      \"action\": string\n" .
               "    }]\n" .
               "  }\n" .
               "}";
    }

    private function parse_competitor_response($ai_response, $domain, $analysis_type) {
        $payload = $this->extract_json($ai_response['content'] ?? '');

        if (empty($payload)) {
            return false;
        }

        if (isset($payload['analysis']) && is_array($payload['analysis'])) {
            $analysis = $payload['analysis'];
        } else {
            $analysis = $payload;
        }

        $provider = sanitize_text_field($ai_response['provider'] ?? '');
        $analysis_type = sanitize_text_field($analysis_type);

        switch ($analysis_type) {
            case 'market_positioning':
                return $this->parse_market_positioning_analysis($analysis, $domain, $provider);
            case 'brand_authority':
                return $this->parse_brand_authority_analysis($analysis, $domain, $provider);
            default:
                return $this->parse_standard_competitor_analysis($analysis, $domain, $analysis_type, $provider);
        }
    }

    private function parse_standard_competitor_analysis(array $analysis, $domain, $analysis_type, $provider) {
        $metrics = $analysis['metrics'] ?? [];

        return [
            'domain' => sanitize_text_field($domain),
            'analysis_type' => sanitize_text_field($analysis_type),
            'provider' => $provider,
            'summary' => isset($analysis['summary']) ? sanitize_textarea_field($analysis['summary']) : '',
            'metrics' => [
                'authority' => isset($metrics['authority']) ? floatval($metrics['authority']) : null,
                'organic_traffic' => isset($metrics['organic_traffic']) ? floatval($metrics['organic_traffic']) : null,
                'keyword_count' => isset($metrics['keyword_count']) ? intval($metrics['keyword_count']) : null,
                'trend_direction' => isset($metrics['trend_direction']) ? sanitize_text_field($metrics['trend_direction']) : ''
            ],
            'top_keywords' => $this->sanitize_named_list($analysis['top_keywords'] ?? [], ['keyword', 'position', 'volume']),
            'content_gaps' => $this->sanitize_named_list($analysis['content_gaps'] ?? [], ['topic', 'opportunity']),
            'recommendations' => $this->sanitize_named_list($analysis['recommendations'] ?? [], ['title', 'action'])
        ];
    }

    private function parse_market_positioning_analysis(array $analysis, $domain, $provider) {
        $positioning = is_array($analysis['positioning'] ?? null) ? $analysis['positioning'] : [];

        return [
            'domain' => sanitize_text_field($domain),
            'analysis_type' => 'market_positioning',
            'provider' => $provider,
            'summary' => isset($analysis['summary']) ? sanitize_textarea_field($analysis['summary']) : '',
            'positioning' => [
                'archetype' => isset($positioning['archetype']) ? sanitize_text_field($positioning['archetype']) : '',
                'value_proposition' => isset($positioning['value_proposition']) ? sanitize_textarea_field($positioning['value_proposition']) : '',
                'brand_voice' => isset($positioning['brand_voice']) ? sanitize_textarea_field($positioning['brand_voice']) : '',
                'audience_segments' => $this->sanitize_string_list($positioning['audience_segments'] ?? []),
                'key_messages' => $this->sanitize_string_list($positioning['key_messages'] ?? []),
                'positioning_axis' => $this->sanitize_named_list($positioning['positioning_axis'] ?? [], ['axis', 'placement'])
            ],
            'competitive_landscape' => $this->sanitize_named_list($analysis['competitive_landscape'] ?? [], ['brand', 'positioning', 'differentiator']),
            'strategic_moves' => $this->sanitize_named_list($analysis['strategic_moves'] ?? [], ['title', 'action']),
            'growth_channels' => $this->sanitize_named_list($analysis['growth_channels'] ?? [], ['channel', 'focus'])
        ];
    }

    private function parse_brand_authority_analysis(array $analysis, $domain, $provider) {
        $brand_scores = is_array($analysis['brand_scores'] ?? null) ? $analysis['brand_scores'] : [];

        return [
            'domain' => sanitize_text_field($domain),
            'analysis_type' => 'brand_authority',
            'provider' => $provider,
            'summary' => isset($analysis['summary']) ? sanitize_textarea_field($analysis['summary']) : '',
            'brand_scores' => [
                'brand_equity' => isset($brand_scores['brand_equity']) ? floatval($brand_scores['brand_equity']) : null,
                'share_of_voice' => isset($brand_scores['share_of_voice']) ? floatval($brand_scores['share_of_voice']) : null,
                'awareness_index' => isset($brand_scores['awareness_index']) ? floatval($brand_scores['awareness_index']) : null,
                'trust_index' => isset($brand_scores['trust_index']) ? floatval($brand_scores['trust_index']) : null
            ],
            'authority_signals' => $this->sanitize_named_list($analysis['authority_signals'] ?? [], ['signal', 'score', 'trend']),
            'channel_performance' => $this->sanitize_named_list($analysis['channel_performance'] ?? [], ['channel', 'followers', 'engagement_rate', 'note']),
            'earned_media' => $this->sanitize_named_list($analysis['earned_media'] ?? [], ['outlet', 'highlight', 'date']),
            'recommendations' => $this->sanitize_named_list($analysis['recommendations'] ?? [], ['title', 'action'])
        ];
    }

    private function build_geo_prompt($country, $region, $timeframe) {
        $region_text = $region ? " (region: {$region})" : '';

        return "You are a geographic trend analyst.\n\n" .
               "Identify the top emerging topics in {$country}{$region_text} for timeframe {$timeframe}.\n" .
               "Return strict JSON with this structure:\n" .
               "{\n" .
               "  \"location\": {\n" .
               "    \"country\": string,\n" .
               "    \"region\": string\n" .
               "  },\n" .
               "  \"timeframe\": string,\n" .
               "  \"topics\": [{\n" .
               "    \"topic\": string,\n" .
               "    \"category\": string,\n" .
               "    \"growth\": number,\n" .
               "    \"volume\": number,\n" .
               "    \"momentum\": string\n" .
               "  }],\n" .
               "  \"insights\": [{\n" .
               "    \"title\": string,\n" .
               "    \"description\": string\n" .
               "  }]\n" .
               "}";
    }

    private function parse_geo_response($ai_response, $country, $region, $timeframe) {
        $payload = $this->extract_json($ai_response['content'] ?? '');

        if (empty($payload)) {
            return false;
        }

        return [
            'location' => [
                'country' => sanitize_text_field($payload['location']['country'] ?? $country),
                'region' => sanitize_text_field($payload['location']['region'] ?? $region)
            ],
            'timeframe' => sanitize_text_field($payload['timeframe'] ?? $timeframe),
            'provider' => sanitize_text_field($ai_response['provider'] ?? ''),
            'topics' => $this->sanitize_named_list($payload['topics'] ?? [], ['topic', 'category', 'growth', 'volume', 'momentum']),
            'insights' => $this->sanitize_named_list($payload['insights'] ?? [], ['title', 'description'])
        ];
    }

    private function build_geo_compare_prompt(array $regions, $timeframe) {
        $regions_list = implode(', ', $regions);

        return "You are comparing geographic trend performance.\n\n" .
               "Compare these regions: {$regions_list} over timeframe {$timeframe}.\n" .
               "Return strict JSON:\n" .
               "{\n" .
               "  \"comparison\": [{\n" .
               "    \"region\": string,\n" .
               "    \"top_topics\": [{\n" .
               "      \"topic\": string,\n" .
               "      \"growth\": number,\n" .
               "      \"volume\": number\n" .
               "    }],\n" .
               "    \"strengths\": [string],\n" .
               "    \"weaknesses\": [string]\n" .
               "  }]\n" .
               "}";
    }

    private function parse_geo_compare_response($ai_response, array $regions, $timeframe) {
        $payload = $this->extract_json($ai_response['content'] ?? '');

        if (empty($payload)) {
            return false;
        }

        $comparison = $payload['comparison'] ?? $payload;

        if (!$this->is_list($comparison)) {
            $comparison = [$comparison];
        }

        $results = [];
        foreach ($comparison as $entry) {
            $results[] = [
                'region' => sanitize_text_field($entry['region'] ?? ''),
                'top_topics' => $this->sanitize_named_list($entry['top_topics'] ?? [], ['topic', 'growth', 'volume']),
                'strengths' => $this->sanitize_string_list($entry['strengths'] ?? []),
                'weaknesses' => $this->sanitize_string_list($entry['weaknesses'] ?? [])
            ];
        }

        return [
            'timeframe' => sanitize_text_field($timeframe),
            'provider' => sanitize_text_field($ai_response['provider'] ?? ''),
            'regions' => $results
        ];
    }

    private function generate_sample_geo_comparison(array $regions, $timeframe) {
        $base_topics = [
            ['topic' => 'AI Adoption', 'growth' => 142, 'volume' => 54000],
            ['topic' => 'Sustainable Retail', 'growth' => 96, 'volume' => 31200],
            ['topic' => 'Creator Economy', 'growth' => 118, 'volume' => 28400]
        ];

        $strengths_pool = [
            'High mobile engagement',
            'Strong social media penetration',
            'Growing local commerce startups',
            'Rapid digital payment adoption'
        ];

        $weaknesses_pool = [
            'Limited long-form content output',
            'Fragmented analytics visibility',
            'Lower enterprise adoption rate',
            'Seasonal interest volatility'
        ];

        $results = [];
        $topic_count = count($base_topics);
        $strength_count = count($strengths_pool);
        $weakness_count = count($weaknesses_pool);

        foreach (array_values($regions) as $index => $region) {
            $topics = [];
            for ($i = 0; $i < $topic_count; $i++) {
                $topic = $base_topics[($index + $i) % $topic_count];
                $topics[] = [
                    'topic' => sprintf('%s (%s)', $topic['topic'], $region),
                    'growth' => $topic['growth'] + ($index * 7),
                    'volume' => $topic['volume'] + ($index * 3200)
                ];
            }

            $strengths = [
                $strengths_pool[$index % $strength_count],
                $strengths_pool[($index + 1) % $strength_count]
            ];

            $weaknesses = [
                $weaknesses_pool[$index % $weakness_count],
                $weaknesses_pool[($index + 2) % $weakness_count]
            ];

            $results[] = [
                'region' => sanitize_text_field($region),
                'top_topics' => $this->sanitize_named_list($topics, ['topic', 'growth', 'volume']),
                'strengths' => $this->sanitize_string_list($strengths),
                'weaknesses' => $this->sanitize_string_list($weaknesses)
            ];
        }

        return [
            'timeframe' => sanitize_text_field($timeframe),
            'provider' => 'sample',
            'regions' => $results
        ];
    }

    private function sanitize_timeline($timeline) {
        if (!is_array($timeline)) {
            return [];
        }

        $sanitized = [];
        foreach ($timeline as $entry) {
            if (!is_array($entry)) {
                continue;
            }

            $sanitized[] = [
                'label' => isset($entry['label']) ? sanitize_text_field($entry['label']) : '',
                'growth_index' => isset($entry['growth_index']) ? floatval($entry['growth_index']) : null,
                'confidence' => isset($entry['confidence']) ? floatval($entry['confidence']) : null
            ];
        }

        return $sanitized;
    }

    private function sanitize_named_list($items, array $keys) {
        if (!is_array($items)) {
            return [];
        }

        $list = [];
        foreach ($items as $item) {
            if (!is_array($item)) {
                $value = sanitize_textarea_field($item);
                if ($value !== '') {
                    $list[] = ['value' => $value];
                }
                continue;
            }

            $sanitized = [];
            foreach ($keys as $key) {
                if (!array_key_exists($key, $item)) {
                    continue;
                }

                $value = $item[$key];

                if (is_numeric($value)) {
                    $sanitized[$key] = strpos((string) $value, '.') !== false ? floatval($value) : intval($value);
                    continue;
                }

                $sanitized[$key] = sanitize_textarea_field($value);
            }

            if (!empty($sanitized)) {
                $list[] = $sanitized;
            }
        }

        return $list;
    }

    private function sanitize_string_list($items) {
        if (!is_array($items)) {
            return [];
        }

        $list = [];
        foreach ($items as $item) {
            $value = is_array($item) ? ($item['value'] ?? '') : $item;
            $value = sanitize_textarea_field($value);
            if ($value !== '') {
                $list[] = $value;
            }
        }

        return $list;
    }

    private function extract_json($content) {
        if (empty($content)) {
            return null;
        }

        $content = trim($content);
        $decoded = json_decode($content, true);
        if (json_last_error() === JSON_ERROR_NONE) {
            return $decoded;
        }

        if (preg_match('/\[[\s\S]*\]/', $content, $matches)) {
            $decoded = json_decode($matches[0], true);
            if (json_last_error() === JSON_ERROR_NONE) {
                return $decoded;
            }
        }

        if (preg_match('/\{[\s\S]*\}/', $content, $matches)) {
            $decoded = json_decode($matches[0], true);
            if (json_last_error() === JSON_ERROR_NONE) {
                return $decoded;
            }
        }

        return null;
    }

    private function is_list($array) {
        if (!is_array($array)) {
            return false;
        }

        return $array === [] || array_keys($array) === range(0, count($array) - 1);
    }

    private function build_trend_prompt($category, $limit) {
        $category_context = $this->get_category_context($category);
        
        return "You are a trend intelligence system like ExplodingTopics.com.
Analyze current emerging topics globally for the {$category} niche.
{$category_context}

Return a JSON array with exactly {$limit} items, each containing:
- topic (string): The trending topic/keyword
- growth (number): Growth percentage (0-500)
- search_volume (number): Estimated monthly search volume
- trend_stage (string): One of 'Emerging', 'Exploding', 'Stable'
- short_description (string): Brief explanation of why it's trending

Focus only on topics that have high online momentum and are not generic keywords.
Prioritize topics with real commercial or content potential.
DO NOT include any explanations, only return valid JSON array.

Example format:
[
  {
    \"topic\": \"AI content creation\",
    \"growth\": 245,
    \"search_volume\": 12000,
    \"trend_stage\": \"Exploding\",
    \"short_description\": \"Rapid adoption of AI tools for content generation\"
  }
]";
    }

    private function get_category_context($category) {
        $contexts = [
            'general' => 'Focus on broad trending topics across all industries and interests.',
            'technology' => 'Focus on tech trends, software, AI, gadgets, and digital innovations.',
            'business' => 'Focus on business trends, marketing, entrepreneurship, and industry developments.',
            'health' => 'Focus on health, wellness, fitness, medical innovations, and lifestyle trends.',
            'entertainment' => 'Focus on entertainment, media, gaming, streaming, and pop culture trends.',
            'education' => 'Focus on educational trends, online learning, skills development, and academic topics.',
            'finance' => 'Focus on financial trends, cryptocurrency, investing, and economic developments.',
            'lifestyle' => 'Focus on lifestyle trends, fashion, travel, food, and personal development.',
            'sports' => 'Focus on sports trends, fitness, athletics, and recreational activities.',
            'science' => 'Focus on scientific discoveries, research trends, and technological breakthroughs.'
        ];

        return $contexts[$category] ?? $contexts['general'];
    }

    private function get_ai_trends($prompt) {
        // Use the existing AI service from base plugin
        $gemini_key = get_option('vrsc_gemini_api_key', '');
        $openai_key = get_option('vrsc_openai_api_key', '');
        $preferred_provider = get_option('vrsc_ai_provider', 'gemini');

        if ($preferred_provider === 'gemini' && !empty($gemini_key)) {
            $result = $this->get_gemini_trends($prompt);
            if ($result) return $result;
        }

        if (!empty($openai_key)) {
            $result = $this->get_openai_trends($prompt);
            if ($result) return $result;
        }

        if ($preferred_provider === 'openai' && !empty($gemini_key)) {
            $result = $this->get_gemini_trends($prompt);
            if ($result) return $result;
        }

        return false;
    }

    private function get_gemini_trends($prompt) {
        $api_key = get_option('vrsc_gemini_api_key', '');
        $model = get_option('vrsc_gemini_model', 'gemini-2.5-flash');

        if (empty($api_key)) {
            return false;
        }

        $response = wp_remote_post('https://generativelanguage.googleapis.com/v1beta/models/' . $model . ':generateContent?key=' . $api_key, [
            'headers' => [
                'Content-Type' => 'application/json',
            ],
            'body' => json_encode([
                'contents' => [
                    [
                        'parts' => [
                            ['text' => $prompt]
                        ]
                    ]
                ]
            ]),
            'timeout' => 45
        ]);

        if (is_wp_error($response)) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Exploding AI Gemini Error: ' . $response->get_error_message());
            }
            return false;
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        if ($response_code !== 200) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Exploding AI Gemini HTTP Error ' . $response_code . ': ' . $body);
            }
            return false;
        }
        
        $data = json_decode($body, true);

        if (isset($data['candidates'][0]['content']['parts'][0]['text'])) {
            return [
                'content' => $data['candidates'][0]['content']['parts'][0]['text'],
                'provider' => 'gemini'
            ];
        }

        return false;
    }

    private function get_openai_trends($prompt) {
        $api_key = get_option('vrsc_openai_api_key', '');
        $model = get_option('vrsc_openai_model', 'gpt-4o');

        if (empty($api_key)) {
            return false;
        }

        $response = wp_remote_post('https://api.openai.com/v1/chat/completions', [
            'headers' => [
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json',
            ],
            'body' => json_encode([
                'model' => $model,
                'messages' => [
                    [
                        'role' => 'user',
                        'content' => $prompt
                    ]
                ],
                'max_tokens' => 2000,
                'temperature' => 0.7
            ]),
            'timeout' => 45
        ]);

        if (is_wp_error($response)) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Exploding AI OpenAI Error: ' . $response->get_error_message());
            }
            return false;
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        if ($response_code !== 200) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Exploding AI OpenAI HTTP Error ' . $response_code . ': ' . $body);
            }
            return false;
        }
        
        $data = json_decode($body, true);

        if (isset($data['choices'][0]['message']['content'])) {
            return [
                'content' => $data['choices'][0]['message']['content'],
                'provider' => 'openai'
            ];
        }

        return false;
    }

    private function parse_ai_trends($ai_response, $category) {
        $content = $ai_response['content'];
        $provider = $ai_response['provider'];

        $payload = $this->extract_json($content);

        if (empty($payload)) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Exploding AI: No JSON found in response: ' . $content);
            }
            return false;
        }

        $trends_data = $payload;
        if (isset($payload['trends']) && is_array($payload['trends'])) {
            $trends_data = $payload['trends'];
        }

        if (!$this->is_list($trends_data)) {
            // If a single trend object was returned, wrap it
            $trends_data = [$trends_data];
        }

        $trends = [];
        foreach ($trends_data as $trend_data) {
            if (!isset($trend_data['topic']) || !isset($trend_data['growth'])) {
                continue;
            }

            $trends[] = [
                'topic' => sanitize_text_field($trend_data['topic']),
                'growth' => floatval($trend_data['growth']),
                'search_volume' => intval($trend_data['search_volume'] ?? 0),
                'trend_stage' => sanitize_text_field($trend_data['trend_stage'] ?? 'Emerging'),
                'short_description' => sanitize_textarea_field($trend_data['short_description'] ?? ''),
                'category' => $category,
                'ai_provider' => $provider,
                'raw_data' => json_encode($trend_data)
            ];
        }

        return $trends;
    }

    private function save_trends($trends) {
        global $wpdb;
        $table = $wpdb->prefix . 'vrsc_trends_ai';

        foreach ($trends as $trend) {
            // Check if trend already exists (avoid duplicates)
            $existing = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM $table WHERE topic = %s AND category = %s AND created_at > %s",
                $trend['topic'],
                $trend['category'],
                date('Y-m-d H:i:s', strtotime('-24 hours'))
            ));

            if (!$existing) {
                $wpdb->insert($table, $trend, [
                    '%s', '%f', '%d', '%s', '%s', '%s', '%s', '%s'
                ]);
            }
        }
    }

    public function get_available_categories() {
        return [
            'general' => __('General', 'vira-scope'),
            'technology' => __('Technology', 'vira-scope'),
            'business' => __('Business', 'vira-scope'),
            'health' => __('Health & Wellness', 'vira-scope'),
            'entertainment' => __('Entertainment', 'vira-scope'),
            'education' => __('Education', 'vira-scope'),
            'finance' => __('Finance', 'vira-scope'),
            'lifestyle' => __('Lifestyle', 'vira-scope'),
            'sports' => __('Sports', 'vira-scope'),
            'science' => __('Science', 'vira-scope')
        ];
    }

    public function get_trend_stages() {
        return [
            'Emerging' => __('Emerging', 'vira-scope'),
            'Exploding' => __('Exploding', 'vira-scope'),
            'Stable' => __('Stable', 'vira-scope')
        ];
    }
}