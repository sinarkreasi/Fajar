# Exploding AI Topics Addon

A WordPress addon for ViraScope that tracks and analyzes trending AI topics using various AI providers.

## Features

- **Real-time Trend Tracking**: Fetch trending AI topics from multiple providers
- **REST API Endpoints**: Complete API for accessing trend data
- **Admin Dashboard**: User-friendly interface for managing trends
- **Advanced Filtering**: Filter by category, growth rate, trend stage
- **Analytics**: Growth distribution and provider statistics
- **Search Functionality**: Search trends by keywords

## Installation

1. Place the `ExplodingAI` folder in your `Addons` directory
2. The addon will auto-activate when the base ViraScope plugin is active
3. Navigate to **ViraScope > AI Topics** in your WordPress admin

## API Endpoints

All endpoints are prefixed with `/wp-json/virascope/v1/exploding-ai/`

### Public Endpoints (Requires Login)

#### Get All Trends
```
GET /trends
```

**Parameters:**
- `category` (string): Filter by category
- `min_growth` (number): Minimum growth percentage
- `trend_stage` (string): Filter by stage (Emerging, Growing, Exploding, Declining)
- `limit` (integer): Number of results (1-100, default: 20)
- `offset` (integer): Pagination offset
- `orderby` (string): Sort field (growth, search_volume, created_at, topic)
- `order` (string): Sort direction (ASC, DESC)

**Example:**
```bash
curl "https://yoursite.com/wp-json/virascope/v1/exploding-ai/trends?category=technology&min_growth=50&limit=10"
```

#### Get Single Trend
```
GET /trends/{id}
```

#### Get Top Trends
```
GET /trends/top?limit=10
```

#### Get Exploding Trends
```
GET /trends/exploding?min_growth=100&limit=20
```

#### Get Emerging Trends
```
GET /trends/emerging?max_growth=50&limit=20
```

#### Search Trends
```
GET /trends/search?q=artificial+intelligence&limit=20
```

#### Get Categories
```
GET /categories
```

#### Get Statistics
```
GET /stats
```

#### Get Growth Distribution
```
GET /analytics/growth-distribution
```

#### Get Trends by Provider
```
GET /analytics/by-provider
```

### Admin Endpoints (Requires Admin Rights)

#### Fetch New Trends
```
POST /fetch
```

**Parameters:**
- `force` (boolean): Force refresh even if recent data exists

#### Cleanup Old Trends
```
DELETE /cleanup?days=30
```

## Response Format

All successful responses follow this format:

```json
{
  "success": true,
  "data": [...],
  "total": 25,
  "additional_info": "..."
}
```

Error responses:

```json
{
  "code": "error_code",
  "message": "Error description",
  "data": {
    "status": 400
  }
}
```

## Database Schema

The addon creates a table `wp_vrsc_trends_ai` with the following structure:

- `id` - Primary key
- `topic` - Trend topic/title
- `growth` - Growth percentage
- `search_volume` - Search volume data
- `trend_stage` - Current stage (Emerging, Growing, Exploding, Declining)
- `short_description` - Brief description
- `category` - Topic category
- `ai_provider` - Source AI provider
- `raw_data` - JSON data from provider
- `created_at` - Creation timestamp
- `updated_at` - Last update timestamp

## Usage Examples

### JavaScript (Frontend)

```javascript
// Fetch top exploding trends
fetch('/wp-json/virascope/v1/exploding-ai/trends/exploding?limit=5')
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      console.log('Top exploding trends:', data.data);
    }
  });

// Search for AI trends
fetch('/wp-json/virascope/v1/exploding-ai/trends/search?q=machine+learning')
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      console.log('ML trends:', data.data);
    }
  });
```

### PHP (Backend)

```php
// Get trends using WordPress HTTP API
$response = wp_remote_get(home_url('/wp-json/virascope/v1/exploding-ai/trends/top'));
$data = json_decode(wp_remote_retrieve_body($response), true);

if ($data['success']) {
    foreach ($data['data'] as $trend) {
        echo "Topic: {$trend->topic} - Growth: {$trend->growth}%\n";
    }
}
```

### cURL

```bash
# Get technology trends with high growth
curl -H "Authorization: Bearer YOUR_TOKEN" \
  "https://yoursite.com/wp-json/virascope/v1/exploding-ai/trends?category=technology&min_growth=75"

# Fetch new trends (admin only)
curl -X POST \
  -H "Authorization: Bearer ADMIN_TOKEN" \
  "https://yoursite.com/wp-json/virascope/v1/exploding-ai/fetch"
```

## Admin Dashboard Features

- **Statistics Overview**: Total trends, recent activity, average growth
- **Real-time Filtering**: Filter by category, stage, growth rate
- **Search Functionality**: Find specific trends
- **Data Management**: Fetch new trends, refresh data, cleanup old entries
- **Visual Indicators**: Color-coded growth and stage badges

## Customization

### Adding New Categories

Categories are automatically detected from trend data, but you can customize the display in the dashboard view.

### Extending API

To add new endpoints, extend the `ExplodingAIAPI` class:

```php
// Add to ExplodingAIAPI::register_routes()
register_rest_route($namespace, '/custom-endpoint', [
    'methods' => 'GET',
    'callback' => [$this, 'custom_endpoint_handler'],
    'permission_callback' => [$this, 'check_permissions']
]);
```

### Custom Styling

Override the default styles by enqueueing your own CSS after the plugin's styles:

```php
wp_enqueue_style('custom-exploding-ai', 'path/to/custom.css', ['exploding-ai-admin']);
```

## Hooks and Filters

### Actions

- `exploding_ai_before_fetch` - Before fetching new trends
- `exploding_ai_after_fetch` - After fetching new trends
- `exploding_ai_trend_saved` - When a trend is saved

### Filters

- `exploding_ai_trend_data` - Modify trend data before saving
- `exploding_ai_api_response` - Modify API responses
- `exploding_ai_categories` - Customize available categories

## Requirements

- WordPress 5.0+
- PHP 7.4+
- ViraScope base plugin
- Active internet connection for AI provider APIs

## Support

For support and feature requests, please contact the ViraScope development team.