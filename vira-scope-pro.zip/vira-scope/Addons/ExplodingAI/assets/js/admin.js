/**
 * Exploding AI Admin JavaScript
 */

(function($) {
    'use strict';

    const ExplodingAI = {
        
        init: function() {
            this.bindEvents();
            this.initTooltips();
        },

        bindEvents: function() {
            // Dashboard specific events
            $(document).on('click', '#fetch-trends', this.fetchTrendsDashboard);
            $(document).on('click', '#refresh-data', this.refreshDataDashboard);
            $(document).on('click', '#apply-filters', this.applyFiltersDashboard);
            
            // General events
            $(document).on('click', '.fetch-trends', this.fetchTrends);
            $(document).on('click', '.refresh-data', this.refreshData);
            $(document).on('click', '.apply-filters', this.applyFilters);
            $(document).on('click', '#generate-forecast', this.generateForecast);
            $(document).on('click', '#analyze-competitor', this.analyzeCompetitor);
            $(document).on('click', '#add-to-watchlist', this.addToWatchlist);
            $(document).on('click', '.remove-from-watchlist', this.removeFromWatchlist);
            $(document).on('click', '#analyze-geo-trends', this.analyzeGeoTrends);
            $(document).on('click', '#compare-regions', this.compareRegions);
            
            // Real-time search
            $(document).on('input', '#trend-search', this.debounce(this.searchTrends, 500));
            
            // Quick filter buttons
            $(document).on('click', '.quick-filter', this.quickFilter);
            
            // Export functionality
            $(document).on('click', '#export-trends', this.exportTrends);
        },

        // Dashboard specific fetch trends
        fetchTrendsDashboard: function(e) {
            e.preventDefault();
            
            const button = $(this);
            const originalText = button.text();
            
            button.prop('disabled', true).text('Fetching...');
            
            $.post(ajaxurl, {
                action: 'exploding_ai_fetch_trends',
                nonce: exploding_ai_ajax.nonce,
                category: 'general',
                limit: 20
            })
            .done(function(response) {
                if (response.success) {
                    ExplodingAI.showNotice('success', 'Trends fetched successfully!');
                    setTimeout(() => location.reload(), 1500);
                } else {
                    ExplodingAI.showNotice('error', response.data || 'Failed to fetch trends');
                }
            })
            .fail(function() {
                ExplodingAI.showNotice('error', 'Network error occurred while fetching trends');
            })
            .always(function() {
                button.prop('disabled', false).text(originalText);
            });
        },

        fetchTrends: function(e) {
            e.preventDefault();
            
            const button = $(this);
            const originalText = button.text();
            
            button.prop('disabled', true)
                  .addClass('loading')
                  .text('Fetching...');
            
            const category = $('#category-select').val() || 'general';
            const limit = $('#limit-select').val() || 20;
            
            $.post(exploding_ai_ajax.ajax_url || ajaxurl, {
                action: 'exploding_ai_fetch_trends',
                nonce: exploding_ai_ajax.nonce,
                category: category,
                limit: limit
            })
            .done(function(response) {
                if (response.success) {
                    ExplodingAI.showNotice('success', `Fetched ${response.data.count} trends successfully!`);
                    ExplodingAI.updateTrendsDisplay(response.data.trends);
                    ExplodingAI.updateStats();
                } else {
                    ExplodingAI.showNotice('error', response.data || 'Failed to fetch trends');
                }
            })
            .fail(function() {
                ExplodingAI.showNotice('error', 'Network error occurred while fetching trends');
            })
            .always(function() {
                button.prop('disabled', false)
                      .removeClass('loading')
                      .text(originalText);
            });
        },

        // Dashboard specific refresh data
        refreshDataDashboard: function(e) {
            e.preventDefault();
            
            const button = $(this);
            const originalText = button.text();
            
            button.prop('disabled', true).text('Refreshing...');
            
            $.post(ajaxurl, {
                action: 'exploding_ai_refresh_data',
                nonce: exploding_ai_ajax.nonce
            })
            .done(function(response) {
                if (response.success) {
                    ExplodingAI.showNotice('success', 'Data refreshed successfully!');
                    setTimeout(() => location.reload(), 1500);
                } else {
                    ExplodingAI.showNotice('error', response.data || 'Failed to refresh data');
                }
            })
            .fail(function() {
                ExplodingAI.showNotice('error', 'Network error occurred while refreshing data');
            })
            .always(function() {
                button.prop('disabled', false).text(originalText);
            });
        },

        refreshData: function(e) {
            e.preventDefault();
            
            const button = $(this);
            const originalText = button.text();
            
            button.prop('disabled', true)
                  .addClass('loading')
                  .text('Refreshing...');
            
            $.post(exploding_ai_ajax.ajax_url || ajaxurl, {
                action: 'exploding_ai_refresh_data',
                nonce: exploding_ai_ajax.nonce
            })
            .done(function(response) {
                if (response.success) {
                    ExplodingAI.showNotice('success', response.data.message);
                    setTimeout(() => location.reload(), 1500);
                } else {
                    ExplodingAI.showNotice('error', response.data || 'Failed to refresh data');
                }
            })
            .fail(function() {
                ExplodingAI.showNotice('error', 'Network error occurred while refreshing data');
            })
            .always(function() {
                button.prop('disabled', false)
                      .removeClass('loading')
                      .text(originalText);
            });
        },

        // Dashboard specific apply filters
        applyFiltersDashboard: function(e) {
            e.preventDefault();
            
            const category = $('#category-filter').val();
            const stage = $('#stage-filter').val();
            const minGrowth = $('#min-growth').val();
            
            $('#loading-indicator').show();
            
            $.post(ajaxurl, {
                action: 'exploding_ai_get_trends',
                nonce: exploding_ai_ajax.nonce,
                category: category,
                trend_stage: stage,
                min_growth: minGrowth || 0
            })
            .done(function(response) {
                if (response.success) {
                    ExplodingAI.updateTrendsTable(response.data);
                } else {
                    ExplodingAI.showNotice('error', response.data || 'Failed to load trends');
                }
            })
            .fail(function() {
                ExplodingAI.showNotice('error', 'Network error occurred while loading trends');
            })
            .always(function() {
                $('#loading-indicator').hide();
            });
        },

        applyFilters: function(e) {
            e.preventDefault();
            
            const filters = {
                category: $('#category-filter').val(),
                trend_stage: $('#stage-filter').val(),
                min_growth: $('#min-growth').val() || 0,
                search: $('#trend-search').val()
            };
            
            ExplodingAI.loadTrends(filters);
        },

        loadTrends: function(filters = {}) {
            $('#loading-indicator').show();
            $('#trends-container').addClass('loading');
            
            $.post(exploding_ai_ajax.ajax_url || ajaxurl, {
                action: 'exploding_ai_get_trends',
                nonce: exploding_ai_ajax.nonce,
                ...filters
            })
            .done(function(response) {
                if (response.success) {
                    ExplodingAI.updateTrendsDisplay(response.data);
                } else {
                    ExplodingAI.showNotice('error', response.data || 'Failed to load trends');
                }
            })
            .fail(function() {
                ExplodingAI.showNotice('error', 'Network error occurred while loading trends');
            })
            .always(function() {
                $('#loading-indicator').hide();
                $('#trends-container').removeClass('loading');
            });
        },

        searchTrends: function() {
            const searchTerm = $(this).val();
            if (searchTerm.length >= 2) {
                ExplodingAI.loadTrends({ search: searchTerm });
            } else if (searchTerm.length === 0) {
                ExplodingAI.loadTrends();
            }
        },

        quickFilter: function(e) {
            e.preventDefault();
            
            const filter = $(this).data('filter');
            const value = $(this).data('value');
            
            // Update filter controls
            $(`#${filter}-filter`).val(value);
            
            // Apply filters
            ExplodingAI.applyFilters(e);
            
            // Update active state
            $('.quick-filter').removeClass('active');
            $(this).addClass('active');
        },

        updateTrendsDisplay: function(trends) {
            const container = $('#trends-container');
            
            if (!trends || trends.length === 0) {
                container.html(`
                    <div class="no-trends">
                        <p>No trends found matching your criteria.</p>
                    </div>
                `);
                return;
            }
            
            let tableHtml = `
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>Topic</th>
                            <th>Growth</th>
                            <th>Volume</th>
                            <th>Stage</th>
                            <th>Category</th>
                            <th>Provider</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
            `;
            
            trends.forEach(trend => {
                const growthClass = ExplodingAI.getGrowthClass(trend.growth);
                const stageClass = trend.trend_stage.toLowerCase();
                const date = new Date(trend.created_at).toLocaleDateString();
                
                tableHtml += `
                    <tr>
                        <td>
                            <strong>${ExplodingAI.escapeHtml(trend.topic)}</strong>
                            ${trend.short_description ? `<br><small>${ExplodingAI.escapeHtml(trend.short_description)}</small>` : ''}
                        </td>
                        <td>
                            <span class="growth-badge growth-${growthClass}">
                                ${trend.growth}%
                            </span>
                        </td>
                        <td>${ExplodingAI.numberFormat(trend.search_volume)}</td>
                        <td>
                            <span class="stage-badge stage-${stageClass}">
                                ${trend.trend_stage}
                            </span>
                        </td>
                        <td>${ExplodingAI.capitalize(trend.category)}</td>
                        <td>${trend.ai_provider.toUpperCase()}</td>
                        <td>${date}</td>
                    </tr>
                `;
            });
            
            tableHtml += '</tbody></table>';
            container.html(tableHtml);
        },

        // Alias for dashboard compatibility
        updateTrendsTable: function(trends) {
            this.updateTrendsDisplay(trends);
        },

        updateStats: function() {
            // Fetch updated statistics
            $.get('/wp-json/virascope/v1/exploding-ai/stats')
            .done(function(response) {
                if (response.success) {
                    const stats = response.data;
                    $('.stat-card').each(function() {
                        const statType = $(this).data('stat');
                        if (stats[statType] !== undefined) {
                            $(this).find('h3').text(stats[statType]);
                        }
                    });
                }
            });
        },

        exportTrends: function(e) {
            e.preventDefault();
            
            const filters = {
                category: $('#category-filter').val(),
                trend_stage: $('#stage-filter').val(),
                min_growth: $('#min-growth').val() || 0
            };
            
            // Create download link
            const params = new URLSearchParams(filters);
            const url = `/wp-json/virascope/v1/exploding-ai/trends?${params}&format=csv`;
            
            const link = document.createElement('a');
            link.href = url;
            link.download = `exploding-ai-trends-${new Date().toISOString().split('T')[0]}.csv`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        },

        generateForecast: function(e) {
            e.preventDefault();

            const keyword = $('#forecast-keyword').val().trim();
            const period = $('#forecast-period').val();
            const category = $('#forecast-category').val();
            const container = $('#forecast-results');

            if (!keyword) {
                alert(ExplodingAI.getString('enterKeyword'));
                return;
            }

            ExplodingAI.setLoadingState(container, ExplodingAI.getString('loading'));

            $.post(exploding_ai_ajax.ajax_url || ajaxurl, {
                action: 'exploding_ai_generate_forecast',
                nonce: exploding_ai_ajax.nonce,
                keyword: keyword,
                period: period,
                category: category
            })
            .done(function(response) {
                if (response.success && response.data) {
                    ExplodingAI.renderForecast(container, response.data);
                } else {
                    const message = response.data || ExplodingAI.getString('forecastError');
                    ExplodingAI.renderError(container, message);
                }
            })
            .fail(function() {
                ExplodingAI.renderError(container, ExplodingAI.getString('forecastError'));
            });
        },

        renderForecast: function(container, data) {
            const $container = container instanceof jQuery ? container : $(container);
            const overview = data.overview || {};
            const timeline = Array.isArray(data.timeline) ? data.timeline : [];
            const insights = Array.isArray(data.insights) ? data.insights : [];
            const opportunities = Array.isArray(data.opportunities) ? data.opportunities : [];
            const risks = Array.isArray(data.risks) ? data.risks : [];

            const confidence = overview.confidence !== null && overview.confidence !== undefined
                ? Math.round(parseFloat(overview.confidence) * 100)
                : null;

            const timelineHtml = timeline.reduce((html, point) => {
                const label = ExplodingAI.escapeHtml(point.label || '');
                const growth = point.growth_index !== null && point.growth_index !== undefined
                    ? `${ExplodingAI.numberFormat(point.growth_index)}%`
                    : '—';
                const pointConfidence = point.confidence !== null && point.confidence !== undefined
                    ? `${Math.round(parseFloat(point.confidence) * 100)}%`
                    : '—';
                return html + `
                    <li>
                        <span class="timeline-label">${label}</span>
                        <span class="timeline-growth">${growth}</span>
                        <span class="timeline-confidence">${pointConfidence}</span>
                    </li>
                `;
            }, '');

            const insightsHtml = insights.reduce((html, insight) => {
                const title = ExplodingAI.escapeHtml(insight.title || '');
                const description = ExplodingAI.escapeHtml(insight.description || '');
                return html + `
                    <li>
                        <strong>${title}</strong>
                        <p>${description}</p>
                    </li>
                `;
            }, '');

            const opportunitiesHtml = opportunities.reduce((html, item) => {
                const windowText = ExplodingAI.escapeHtml(item.window || '');
                const action = ExplodingAI.escapeHtml(item.action || '');
                return html + `
                    <li>
                        <strong>${windowText}</strong>
                        <p>${action}</p>
                    </li>
                `;
            }, '');

            const risksHtml = risks.reduce((html, item) => {
                const risk = ExplodingAI.escapeHtml(item.risk || '');
                const mitigation = ExplodingAI.escapeHtml(item.mitigation || '');
                return html + `
                    <li>
                        <strong>${risk}</strong>
                        <p>${mitigation}</p>
                    </li>
                `;
            }, '');

            $container.removeClass('is-loading').html(`
                <div class="forecast-generated">
                    <h3>${ExplodingAI.getString('forecastHeading')} "${ExplodingAI.escapeHtml(data.keyword)}"</h3>
                    <div class="forecast-overview">
                        <div class="forecast-metric">
                            <span class="metric-label">${ExplodingAI.escapeHtml(ExplodingAI.getString('trendScoreLabel', 'Trend Score'))}</span>
                            <span class="metric-value">${overview.trend_score !== null && overview.trend_score !== undefined ? ExplodingAI.numberFormat(overview.trend_score) : '—'}</span>
                        </div>
                        <div class="forecast-metric">
                            <span class="metric-label">${ExplodingAI.escapeHtml(ExplodingAI.getString('confidenceLabel', 'Confidence'))}</span>
                            <span class="metric-value">${confidence !== null ? `${confidence}%` : '—'}</span>
                        </div>
                        <div class="forecast-metric">
                            <span class="metric-label">${ExplodingAI.escapeHtml(ExplodingAI.getString('growthOutlookLabel', 'Growth Outlook'))}</span>
                            <span class="metric-value">${ExplodingAI.escapeHtml(overview.growth_outlook || '—')}</span>
                        </div>
                        <div class="forecast-metric">
                            <span class="metric-label">${ExplodingAI.escapeHtml(ExplodingAI.getString('peakPeriodLabel', 'Peak Period'))}</span>
                            <span class="metric-value">${ExplodingAI.escapeHtml(overview.peak_period || '—')}</span>
                        </div>
                    </div>
                    <div class="forecast-section">
                        <h4>${ExplodingAI.escapeHtml(ExplodingAI.getString('timelineHeading', 'Timeline Projection'))}</h4>
                        ${timeline.length ? `
                            <ul class="forecast-timeline">
                                <li class="timeline-header">
                                    <span>${ExplodingAI.escapeHtml(ExplodingAI.getString('periodHeader', 'Period'))}</span>
                                    <span>${ExplodingAI.escapeHtml(ExplodingAI.getString('growthHeader', 'Growth'))}</span>
                                    <span>${ExplodingAI.escapeHtml(ExplodingAI.getString('confidenceHeader', 'Confidence'))}</span>
                                </li>
                                ${timelineHtml}
                            </ul>
                        ` : `<p>${ExplodingAI.getString('noData')}</p>`}
                    </div>
                    <div class="forecast-section">
                        <h4>${ExplodingAI.escapeHtml(ExplodingAI.getString('insightsHeading', 'Key Insights'))}</h4>
                        ${insights.length ? `<ul class="insight-list">${insightsHtml}</ul>` : `<p>${ExplodingAI.getString('noData')}</p>`}
                    </div>
                    <div class="forecast-section">
                        <h4>${ExplodingAI.escapeHtml(ExplodingAI.getString('opportunitiesHeading', 'Opportunities'))}</h4>
                        ${opportunities.length ? `<ul class="insight-list">${opportunitiesHtml}</ul>` : `<p>${ExplodingAI.getString('noData')}</p>`}
                    </div>
                    <div class="forecast-section">
                        <h4>${ExplodingAI.escapeHtml(ExplodingAI.getString('risksHeading', 'Risks & Mitigation'))}</h4>
                        ${risks.length ? `<ul class="insight-list">${risksHtml}</ul>` : `<p>${ExplodingAI.getString('noData')}</p>`}
                    </div>
                </div>
            `);
        },

        analyzeCompetitor: function(e) {
            e.preventDefault();

            const domain = $('#competitor-domain').val().trim();
            const analysisType = $('#analysis-type').val();
            const container = $('#competitor-results');

            if (!domain) {
                alert(ExplodingAI.getString('enterDomain'));
                return;
            }

            ExplodingAI.setLoadingState(container, ExplodingAI.getString('loading'));

            $.post(exploding_ai_ajax.ajax_url || ajaxurl, {
                action: 'exploding_ai_competitor_analysis',
                nonce: exploding_ai_ajax.nonce,
                domain: domain,
                analysis_type: analysisType
            })
            .done(function(response) {
                if (response.success && response.data) {
                    ExplodingAI.renderCompetitorAnalysis(container, response.data);
                } else {
                    const message = response.data || ExplodingAI.getString('analysisError');
                    ExplodingAI.renderError(container, message);
                }
            })
            .fail(function() {
                ExplodingAI.renderError(container, ExplodingAI.getString('analysisError'));
            });
        },

        renderCompetitorAnalysis: function(container, data) {
            const $container = container instanceof jQuery ? container : $(container);
            const analysisType = (data.analysis_type || '').toLowerCase();

            if (analysisType === 'market_positioning') {
                ExplodingAI.renderMarketPositioning(container, data);
                return;
            }

            if (analysisType === 'brand_authority') {
                ExplodingAI.renderBrandAuthority(container, data);
                return;
            }

            const metrics = data.metrics || {};
            const topKeywords = Array.isArray(data.top_keywords) ? data.top_keywords : [];
            const contentGaps = Array.isArray(data.content_gaps) ? data.content_gaps : [];
            const recommendations = Array.isArray(data.recommendations) ? data.recommendations : [];

            const keywordItems = topKeywords.reduce((html, item) => {
                const keyword = ExplodingAI.escapeHtml(item.keyword || '');
                const position = item.position !== null && item.position !== undefined ? `#${ExplodingAI.numberFormat(item.position)}` : '—';
                const volume = item.volume !== null && item.volume !== undefined ? `${ExplodingAI.numberFormat(item.volume)}` : '—';
                return html + `
                    <tr>
                        <td>${keyword}</td>
                        <td>${position}</td>
                        <td>${volume}</td>
                    </tr>
                `;
            }, '');

            const gapsHtml = contentGaps.reduce((html, item) => {
                const topic = ExplodingAI.escapeHtml(item.topic || '');
                const opportunity = ExplodingAI.escapeHtml(item.opportunity || '');
                return html + `
                    <li>
                        <strong>${topic}</strong>
                        <p>${opportunity}</p>
                    </li>
                `;
            }, '');

            const recommendationsHtml = recommendations.reduce((html, item) => {
                const title = ExplodingAI.escapeHtml(item.title || '');
                const action = ExplodingAI.escapeHtml(item.action || '');
                return html + `
                    <li>
                        <strong>${title}</strong>
                        <p>${action}</p>
                    </li>
                `;
            }, '');

            $container.removeClass('is-loading').html(`
                <div class="analysis-generated">
                    <h3>${ExplodingAI.getString('analysisHeading')} ${ExplodingAI.escapeHtml(data.domain)}</h3>
                    <p class="analysis-summary">${ExplodingAI.escapeHtml(data.summary || '')}</p>
                    <div class="analysis-metrics">
                        <div class="metric">
                            <h4>${ExplodingAI.escapeHtml(ExplodingAI.getString('domainAuthorityLabel', 'Domain Authority'))}</h4>
                            <div class="score">${metrics.authority !== null && metrics.authority !== undefined ? ExplodingAI.numberFormat(metrics.authority) : '—'}</div>
                        </div>
                        <div class="metric">
                            <h4>${ExplodingAI.escapeHtml(ExplodingAI.getString('organicTrafficLabel', 'Organic Traffic'))}</h4>
                            <div class="score">${metrics.organic_traffic !== null && metrics.organic_traffic !== undefined ? ExplodingAI.numberFormat(metrics.organic_traffic) : '—'}</div>
                        </div>
                        <div class="metric">
                            <h4>${ExplodingAI.escapeHtml(ExplodingAI.getString('keywordCountLabel', 'Keyword Count'))}</h4>
                            <div class="score">${metrics.keyword_count !== null && metrics.keyword_count !== undefined ? ExplodingAI.numberFormat(metrics.keyword_count) : '—'}</div>
                        </div>
                        <div class="metric">
                            <h4>${ExplodingAI.escapeHtml(ExplodingAI.getString('trendDirectionLabel', 'Trend Direction'))}</h4>
                            <div class="score">${ExplodingAI.escapeHtml(metrics.trend_direction || '—')}</div>
                        </div>
                    </div>
                    <div class="analysis-section">
                        <h4>${ExplodingAI.escapeHtml(ExplodingAI.getString('topKeywordsHeading', 'Top Keywords'))}</h4>
                        ${topKeywords.length ? `
                            <table class="wp-list-table widefat fixed striped">
                                <thead>
                                    <tr>
                                        <th>${ExplodingAI.escapeHtml(ExplodingAI.getString('keywordLabel', 'Keyword'))}</th>
                                        <th>${ExplodingAI.escapeHtml(ExplodingAI.getString('positionLabel', 'Position'))}</th>
                                        <th>${ExplodingAI.escapeHtml(ExplodingAI.getString('volumeLabel', 'Volume'))}</th>
                                    </tr>
                                </thead>
                                <tbody>${keywordItems}</tbody>
                            </table>
                        ` : `<p>${ExplodingAI.getString('noData')}</p>`}
                    </div>
                    <div class="analysis-section">
                        <h4>${ExplodingAI.escapeHtml(ExplodingAI.getString('contentGapsHeading', 'Content Gaps'))}</h4>
                        ${contentGaps.length ? `<ul class="insight-list">${gapsHtml}</ul>` : `<p>${ExplodingAI.getString('noData')}</p>`}
                    </div>
                    <div class="analysis-section">
                        <h4>${ExplodingAI.escapeHtml(ExplodingAI.getString('recommendationsHeading', 'Recommended Actions'))}</h4>
                        ${recommendations.length ? `<ul class="insight-list">${recommendationsHtml}</ul>` : `<p>${ExplodingAI.getString('noData')}</p>`}
                    </div>
                </div>
            `);
        },

        renderMarketPositioning: function(container, data) {
            const $container = container instanceof jQuery ? container : $(container);
            const positioning = data.positioning || {};
            const audienceSegments = Array.isArray(positioning.audience_segments) ? positioning.audience_segments : [];
            const keyMessages = Array.isArray(positioning.key_messages) ? positioning.key_messages : [];
            const axis = Array.isArray(positioning.positioning_axis) ? positioning.positioning_axis : [];
            const competitiveLandscape = Array.isArray(data.competitive_landscape) ? data.competitive_landscape : [];
            const strategicMoves = Array.isArray(data.strategic_moves) ? data.strategic_moves : [];
            const growthChannels = Array.isArray(data.growth_channels) ? data.growth_channels : [];

            const listBuilder = (items) => items.reduce((html, item) => {
                const value = ExplodingAI.escapeHtml(item || '');
                return value ? html + `<li>${value}</li>` : html;
            }, '');

            const audiencesHtml = audienceSegments.length ? `<ul class="insight-list">${listBuilder(audienceSegments)}</ul>` : `<p>${ExplodingAI.getString('noData')}</p>`;
            const keyMessagesHtml = keyMessages.length ? `<ul class="insight-list">${listBuilder(keyMessages)}</ul>` : `<p>${ExplodingAI.getString('noData')}</p>`;

            const axisRows = axis.reduce((html, item) => {
                const axisName = ExplodingAI.escapeHtml(item.axis || '');
                const placement = ExplodingAI.escapeHtml(item.placement || '');
                if (!axisName && !placement) {
                    return html;
                }
                return html + `
                    <tr>
                        <td>${axisName || '—'}</td>
                        <td>${placement || '—'}</td>
                    </tr>
                `;
            }, '');

            const axisHtml = axisRows ? `
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>${ExplodingAI.escapeHtml(ExplodingAI.getString('axisLabel', 'Axis'))}</th>
                            <th>${ExplodingAI.escapeHtml(ExplodingAI.getString('placementLabel', 'Placement'))}</th>
                        </tr>
                    </thead>
                    <tbody>${axisRows}</tbody>
                </table>
            ` : `<p>${ExplodingAI.getString('noData')}</p>`;

            const competitorsHtml = competitiveLandscape.reduce((html, item) => {
                const brand = ExplodingAI.escapeHtml(item.brand || '');
                const position = ExplodingAI.escapeHtml(item.positioning || '');
                const differentiator = ExplodingAI.escapeHtml(item.differentiator || '');
                return html + `
                    <tr>
                        <td>${brand || '—'}</td>
                        <td>${position || '—'}</td>
                        <td>${differentiator || '—'}</td>
                    </tr>
                `;
            }, '');

            const competitorTable = competitorsHtml ? `
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>${ExplodingAI.escapeHtml(ExplodingAI.getString('brandLabel', 'Brand'))}</th>
                            <th>${ExplodingAI.escapeHtml(ExplodingAI.getString('positioningLabel', 'Positioning'))}</th>
                            <th>${ExplodingAI.escapeHtml(ExplodingAI.getString('differentiatorLabel', 'Differentiator'))}</th>
                        </tr>
                    </thead>
                    <tbody>${competitorsHtml}</tbody>
                </table>
            ` : `<p>${ExplodingAI.getString('noData')}</p>`;

            const strategicHtml = strategicMoves.reduce((html, item) => {
                const title = ExplodingAI.escapeHtml(item.title || '');
                const action = ExplodingAI.escapeHtml(item.action || '');
                return html + `
                    <li>
                        <strong>${title}</strong>
                        <p>${action}</p>
                    </li>
                `;
            }, '');

            const growthHtml = growthChannels.reduce((html, item) => {
                const channel = ExplodingAI.escapeHtml(item.channel || '');
                const focus = ExplodingAI.escapeHtml(item.focus || '');
                return html + `
                    <li>
                        <strong>${channel}</strong>
                        <p>${focus}</p>
                    </li>
                `;
            }, '');

            $container.removeClass('is-loading').html(`
                <div class="analysis-generated analysis-market-positioning">
                    <h3>${ExplodingAI.escapeHtml(ExplodingAI.getString('marketPositioningHeading', 'Market Positioning'))} ${ExplodingAI.escapeHtml(data.domain || '')}</h3>
                    <p class="analysis-summary">${ExplodingAI.escapeHtml(data.summary || '')}</p>
                    <div class="analysis-metrics">
                        <div class="metric">
                            <h4>${ExplodingAI.escapeHtml(ExplodingAI.getString('archetypeLabel', 'Positioning Archetype'))}</h4>
                            <div class="score">${ExplodingAI.escapeHtml(positioning.archetype || '—')}</div>
                        </div>
                        <div class="metric">
                            <h4>${ExplodingAI.escapeHtml(ExplodingAI.getString('valuePropLabel', 'Value Proposition'))}</h4>
                            <div class="score">${ExplodingAI.escapeHtml(positioning.value_proposition || '—')}</div>
                        </div>
                        <div class="metric">
                            <h4>${ExplodingAI.escapeHtml(ExplodingAI.getString('brandVoiceLabel', 'Brand Voice'))}</h4>
                            <div class="score">${ExplodingAI.escapeHtml(positioning.brand_voice || '—')}</div>
                        </div>
                    </div>
                    <div class="analysis-section">
                        <h4>${ExplodingAI.escapeHtml(ExplodingAI.getString('audienceSegmentsHeading', 'Audience Segments'))}</h4>
                        ${audiencesHtml}
                    </div>
                    <div class="analysis-section">
                        <h4>${ExplodingAI.escapeHtml(ExplodingAI.getString('keyMessagesHeading', 'Key Messages'))}</h4>
                        ${keyMessagesHtml}
                    </div>
                    <div class="analysis-section">
                        <h4>${ExplodingAI.escapeHtml(ExplodingAI.getString('positioningMatrixHeading', 'Positioning Matrix'))}</h4>
                        ${axisHtml}
                    </div>
                    <div class="analysis-section">
                        <h4>${ExplodingAI.escapeHtml(ExplodingAI.getString('competitiveLandscapeHeading', 'Competitive Landscape'))}</h4>
                        ${competitorTable}
                    </div>
                    <div class="analysis-section">
                        <h4>${ExplodingAI.escapeHtml(ExplodingAI.getString('strategicMovesHeading', 'Strategic Moves'))}</h4>
                        ${strategicHtml ? `<ul class="insight-list">${strategicHtml}</ul>` : `<p>${ExplodingAI.getString('noData')}</p>`}
                    </div>
                    <div class="analysis-section">
                        <h4>${ExplodingAI.escapeHtml(ExplodingAI.getString('growthChannelsHeading', 'Growth Channels'))}</h4>
                        ${growthHtml ? `<ul class="insight-list">${growthHtml}</ul>` : `<p>${ExplodingAI.getString('noData')}</p>`}
                    </div>
                </div>
            `);
        },

        renderBrandAuthority: function(container, data) {
            const $container = container instanceof jQuery ? container : $(container);
            const scores = data.brand_scores || {};
            const authoritySignals = Array.isArray(data.authority_signals) ? data.authority_signals : [];
            const channelPerformance = Array.isArray(data.channel_performance) ? data.channel_performance : [];
            const earnedMedia = Array.isArray(data.earned_media) ? data.earned_media : [];
            const recommendations = Array.isArray(data.recommendations) ? data.recommendations : [];

            const formatScore = (value, suffix = '') => (value !== null && value !== undefined && value !== '')
                ? `${ExplodingAI.numberFormat(value)}${suffix}`
                : '—';

            const signalsHtml = authoritySignals.reduce((html, item) => {
                const signal = ExplodingAI.escapeHtml(item.signal || '');
                const score = item.score !== null && item.score !== undefined ? ExplodingAI.numberFormat(item.score) : '—';
                const trend = ExplodingAI.escapeHtml(item.trend || '');
                return html + `
                    <li>
                        <strong>${signal}</strong>
                        <p>${ExplodingAI.escapeHtml(ExplodingAI.getString('scoreLabel', 'Score'))}: ${score} &middot; ${trend || '—'}</p>
                    </li>
                `;
            }, '');

            const channelRows = channelPerformance.reduce((html, item) => {
                const channel = ExplodingAI.escapeHtml(item.channel || '');
                const followers = item.followers !== null && item.followers !== undefined ? ExplodingAI.numberFormat(item.followers) : '—';
                const engagement = item.engagement_rate !== null && item.engagement_rate !== undefined ? `${ExplodingAI.numberFormat(item.engagement_rate)}%` : '—';
                const note = ExplodingAI.escapeHtml(item.note || '');
                return html + `
                    <tr>
                        <td>${channel || '—'}</td>
                        <td>${followers}</td>
                        <td>${engagement}</td>
                        <td>${note || '—'}</td>
                    </tr>
                `;
            }, '');

            const mediaHtml = earnedMedia.reduce((html, item) => {
                const outlet = ExplodingAI.escapeHtml(item.outlet || '');
                const highlight = ExplodingAI.escapeHtml(item.highlight || '');
                const date = ExplodingAI.escapeHtml(item.date || '');
                return html + `
                    <li>
                        <strong>${outlet}</strong>
                        <p>${highlight}</p>
                        <span class="meta">${date}</span>
                    </li>
                `;
            }, '');

            const recommendationsHtml = recommendations.reduce((html, item) => {
                const title = ExplodingAI.escapeHtml(item.title || '');
                const action = ExplodingAI.escapeHtml(item.action || '');
                return html + `
                    <li>
                        <strong>${title}</strong>
                        <p>${action}</p>
                    </li>
                `;
            }, '');

            $container.removeClass('is-loading').html(`
                <div class="analysis-generated analysis-brand-authority">
                    <h3>${ExplodingAI.escapeHtml(ExplodingAI.getString('brandAuthorityHeading', 'Brand Authority'))} ${ExplodingAI.escapeHtml(data.domain || '')}</h3>
                    <p class="analysis-summary">${ExplodingAI.escapeHtml(data.summary || '')}</p>
                    <div class="analysis-metrics">
                        <div class="metric">
                            <h4>${ExplodingAI.escapeHtml(ExplodingAI.getString('brandEquityLabel', 'Brand Equity'))}</h4>
                            <div class="score">${formatScore(scores.brand_equity)}</div>
                        </div>
                        <div class="metric">
                            <h4>${ExplodingAI.escapeHtml(ExplodingAI.getString('shareOfVoiceLabel', 'Share of Voice'))}</h4>
                            <div class="score">${formatScore(scores.share_of_voice, '%')}</div>
                        </div>
                        <div class="metric">
                            <h4>${ExplodingAI.escapeHtml(ExplodingAI.getString('awarenessIndexLabel', 'Awareness Index'))}</h4>
                            <div class="score">${formatScore(scores.awareness_index)}</div>
                        </div>
                        <div class="metric">
                            <h4>${ExplodingAI.escapeHtml(ExplodingAI.getString('trustIndexLabel', 'Trust Index'))}</h4>
                            <div class="score">${formatScore(scores.trust_index)}</div>
                        </div>
                    </div>
                    <div class="analysis-section">
                        <h4>${ExplodingAI.escapeHtml(ExplodingAI.getString('authoritySignalsHeading', 'Authority Signals'))}</h4>
                        ${signalsHtml ? `<ul class="insight-list">${signalsHtml}</ul>` : `<p>${ExplodingAI.getString('noData')}</p>`}
                    </div>
                    <div class="analysis-section">
                        <h4>${ExplodingAI.escapeHtml(ExplodingAI.getString('channelPerformanceHeading', 'Channel Performance'))}</h4>
                        ${channelRows ? `
                            <table class="wp-list-table widefat fixed striped">
                                <thead>
                                    <tr>
                                        <th>${ExplodingAI.escapeHtml(ExplodingAI.getString('channelLabel', 'Channel'))}</th>
                                        <th>${ExplodingAI.escapeHtml(ExplodingAI.getString('followersLabel', 'Followers'))}</th>
                                        <th>${ExplodingAI.escapeHtml(ExplodingAI.getString('engagementRateLabel', 'Engagement Rate'))}</th>
                                        <th>${ExplodingAI.escapeHtml(ExplodingAI.getString('noteLabel', 'Note'))}</th>
                                    </tr>
                                </thead>
                                <tbody>${channelRows}</tbody>
                            </table>
                        ` : `<p>${ExplodingAI.getString('noData')}</p>`}
                    </div>
                    <div class="analysis-section">
                        <h4>${ExplodingAI.escapeHtml(ExplodingAI.getString('earnedMediaHeading', 'Earned Media Highlights'))}</h4>
                        ${mediaHtml ? `<ul class="insight-list">${mediaHtml}</ul>` : `<p>${ExplodingAI.getString('noData')}</p>`}
                    </div>
                    <div class="analysis-section">
                        <h4>${ExplodingAI.escapeHtml(ExplodingAI.getString('recommendationsHeading', 'Recommended Actions'))}</h4>
                        ${recommendationsHtml ? `<ul class="insight-list">${recommendationsHtml}</ul>` : `<p>${ExplodingAI.getString('noData')}</p>`}
                    </div>
                </div>
            `);
        },

        addToWatchlist: function(e) {
            e.preventDefault();

            const input = $('#watchlist-domain');
            const domain = input.val().trim();
            if (!domain) {
                return;
            }

            const list = $('.watchlist-items');
            const item = $(`
                <div class="watchlist-item">
                    <span class="domain">${ExplodingAI.escapeHtml(domain)}</span>
                    <span class="status">${ExplodingAI.escapeHtml(ExplodingAI.getString('monitoringLabel', 'Monitoring'))}</span>
                    <button type="button" class="button-link remove-from-watchlist">${ExplodingAI.escapeHtml(ExplodingAI.getString('removeLabel', 'Remove'))}</button>
                </div>
            `);

            list.append(item);
            input.val('');
        },

        removeFromWatchlist: function(e) {
            e.preventDefault();
            $(this).closest('.watchlist-item').remove();
        },

        analyzeGeoTrends: function(e) {
            e.preventDefault();

            const country = $('#geo-country').val();
            const region = $('#geo-region').val().trim();
            const timeframe = $('#geo-timeframe').val();
            const container = $('#geo-results');

            ExplodingAI.setLoadingState(container, ExplodingAI.getString('loading'));

            $.post(exploding_ai_ajax.ajax_url || ajaxurl, {
                action: 'exploding_ai_geo_trends',
                nonce: exploding_ai_ajax.nonce,
                country: country,
                region: region,
                timeframe: timeframe
            })
            .done(function(response) {
                if (response.success && response.data) {
                    ExplodingAI.renderGeoTrends(container, response.data);
                } else {
                    const message = response.data || ExplodingAI.getString('geoError');
                    ExplodingAI.renderError(container, message);
                }
            })
            .fail(function() {
                ExplodingAI.renderError(container, ExplodingAI.getString('geoError'));
            });
        },

        renderGeoTrends: function(container, data) {
            const $container = container instanceof jQuery ? container : $(container);
            const topics = Array.isArray(data.topics) ? data.topics : [];
            const insights = Array.isArray(data.insights) ? data.insights : [];

            const topicsHtml = topics.reduce((html, topic) => {
                const name = ExplodingAI.escapeHtml(topic.topic || '');
                const category = ExplodingAI.escapeHtml(topic.category || '');
                const growth = topic.growth !== null && topic.growth !== undefined ? `${ExplodingAI.numberFormat(topic.growth)}%` : '—';
                const volume = topic.volume !== null && topic.volume !== undefined ? ExplodingAI.numberFormat(topic.volume) : '—';
                const momentum = ExplodingAI.escapeHtml(topic.momentum || '');
                return html + `
                    <div class="trending-topic">
                        <div class="topic-info">
                            <div class="topic-name">${name}</div>
                            <div class="topic-category">${category}</div>
                        </div>
                        <div class="topic-metrics">
                            <div class="metric">
                                <div class="metric-value">${growth}</div>
                            <div class="metric-label">${ExplodingAI.escapeHtml(ExplodingAI.getString('growthHeader', 'Growth'))}</div>
                            </div>
                            <div class="metric">
                                <div class="metric-value">${volume}</div>
                            <div class="metric-label">${ExplodingAI.escapeHtml(ExplodingAI.getString('volumeLabel', 'Volume'))}</div>
                            </div>
                            <div class="metric">
                                <div class="metric-value">${momentum}</div>
                            <div class="metric-label">${ExplodingAI.escapeHtml(ExplodingAI.getString('momentumLabel', 'Momentum'))}</div>
                            </div>
                        </div>
                    </div>
                `;
            }, '');

            const insightsHtml = insights.reduce((html, insight) => {
                const title = ExplodingAI.escapeHtml(insight.title || '');
                const description = ExplodingAI.escapeHtml(insight.description || '');
                return html + `
                    <li>
                        <strong>${title}</strong>
                        <p>${description}</p>
                    </li>
                `;
            }, '');

            const location = data.location || {};
            const country = ExplodingAI.escapeHtml(location.country || '');
            const region = ExplodingAI.escapeHtml(location.region || ExplodingAI.getString('regionLabel'));
            const timeframe = ExplodingAI.escapeHtml(data.timeframe || '');

            $container.removeClass('is-loading').html(`
                <div class="geo-analysis-generated">
                    <h3>${ExplodingAI.escapeHtml(ExplodingAI.getString('trendingHeading', 'Trending Topics in'))} ${country}</h3>
                    <p><strong>${ExplodingAI.getString('regionLabel')}:</strong> ${region || ExplodingAI.escapeHtml(ExplodingAI.getString('allRegionsLabel', 'All regions'))}</p>
                    <p><strong>${ExplodingAI.getString('timeframeLabel')}:</strong> ${timeframe}</p>
                    <div class="trending-topics-list">
                        ${topics.length ? topicsHtml : `<p>${ExplodingAI.getString('noData')}</p>`}
                    </div>
                    <div class="analysis-section">
                        <h4>${ExplodingAI.escapeHtml(ExplodingAI.getString('geoInsightsHeading', 'Insights'))}</h4>
                        ${insights.length ? `<ul class="insight-list">${insightsHtml}</ul>` : `<p>${ExplodingAI.getString('noData')}</p>`}
                    </div>
                </div>
            `);
        },

        compareRegions: function(e) {
            e.preventDefault();

            const selectedRegions = $('.region-checkboxes input:checked').map(function() {
                return $(this).val();
            }).get();

            if (selectedRegions.length < 2) {
                alert(ExplodingAI.getString('selectRegions'));
                return;
            }

            const timeframe = $('#geo-timeframe').val();
            const container = $('#comparison-results');

            ExplodingAI.setLoadingState(container, ExplodingAI.getString('loading'));

            $.post(exploding_ai_ajax.ajax_url || ajaxurl, {
                action: 'exploding_ai_geo_compare',
                nonce: exploding_ai_ajax.nonce,
                regions: selectedRegions,
                timeframe: timeframe
            })
            .done(function(response) {
                if (response.success && response.data) {
                    ExplodingAI.renderRegionComparison(container, response.data);
                } else {
                    const message = response.data || ExplodingAI.getString('compareError');
                    ExplodingAI.renderError(container, message);
                }
            })
            .fail(function() {
                ExplodingAI.renderError(container, ExplodingAI.getString('compareError'));
            });
        },

        renderRegionComparison: function(container, data) {
            const $container = container instanceof jQuery ? container : $(container);
            const regions = Array.isArray(data.regions) ? data.regions : [];

            const cards = regions.reduce((html, region) => {
                const name = ExplodingAI.escapeHtml(region.region || '');
                const topTopics = Array.isArray(region.top_topics) ? region.top_topics : [];
                const strengths = Array.isArray(region.strengths) ? region.strengths : [];
                const weaknesses = Array.isArray(region.weaknesses) ? region.weaknesses : [];

                const topicsHtml = topTopics.reduce((topicHtml, topic) => {
                    const topicName = ExplodingAI.escapeHtml(topic.topic || '');
                    const growth = topic.growth !== null && topic.growth !== undefined ? `${ExplodingAI.numberFormat(topic.growth)}%` : '—';
                    const volume = topic.volume !== null && topic.volume !== undefined ? ExplodingAI.numberFormat(topic.volume) : '—';
                    return topicHtml + `
                        <tr>
                            <td>${topicName}</td>
                            <td>${growth}</td>
                            <td>${volume}</td>
                        </tr>
                    `;
                }, '');

                const strengthsHtml = strengths.reduce((text, item) => {
                    return text + `<li>${ExplodingAI.escapeHtml(item)}</li>`;
                }, '');

                const weaknessesHtml = weaknesses.reduce((text, item) => {
                    return text + `<li>${ExplodingAI.escapeHtml(item)}</li>`;
                }, '');

                return html + `
                    <div class="region-card">
                        <h4>${name}</h4>
                        <div class="region-section">
                            <h5>${ExplodingAI.escapeHtml(ExplodingAI.getString('topTopicsHeading', 'Top Topics'))}</h5>
                            ${topTopics.length ? `
                                <table class="wp-list-table widefat fixed striped">
                                    <thead>
                                        <tr>
                                            <th>${ExplodingAI.escapeHtml(ExplodingAI.getString('topicLabel', 'Topic'))}</th>
                                            <th>${ExplodingAI.escapeHtml(ExplodingAI.getString('growthHeader', 'Growth'))}</th>
                                            <th>${ExplodingAI.escapeHtml(ExplodingAI.getString('volumeLabel', 'Volume'))}</th>
                                        </tr>
                                    </thead>
                                    <tbody>${topicsHtml}</tbody>
                                </table>
                            ` : `<p>${ExplodingAI.getString('noData')}</p>`}
                        </div>
                        <div class="region-section">
                            <h5>${ExplodingAI.escapeHtml(ExplodingAI.getString('strengthsHeading', 'Strengths'))}</h5>
                            ${strengths.length ? `<ul>${strengthsHtml}</ul>` : `<p>${ExplodingAI.getString('noData')}</p>`}
                        </div>
                        <div class="region-section">
                            <h5>${ExplodingAI.escapeHtml(ExplodingAI.getString('weaknessesHeading', 'Weaknesses'))}</h5>
                            ${weaknesses.length ? `<ul>${weaknessesHtml}</ul>` : `<p>${ExplodingAI.getString('noData')}</p>`}
                        </div>
                    </div>
                `;
            }, '');

            $container.removeClass('is-loading').html(`
                <div class="region-comparison-generated">
                    <h4>${ExplodingAI.escapeHtml(ExplodingAI.getString('regionComparisonHeading', 'Region Comparison'))}</h4>
                    <div class="region-comparison-grid">
                        ${regions.length ? cards : `<p>${ExplodingAI.getString('noData')}</p>`}
                    </div>
                </div>
            `);
        },

        renderError: function(container, message) {
            const $container = container instanceof jQuery ? container : $(container);
            $container.removeClass('is-loading').html(`
                <div class="vrsc-error">
                    <p>${ExplodingAI.escapeHtml(message)}</p>
                </div>
            `);
        },

        setLoadingState: function(container, message) {
            const $container = container instanceof jQuery ? container : $(container);
            $container.addClass('is-loading').html(`
                <div class="vrsc-loading">
                    <span class="spinner is-active"></span>
                    <p>${ExplodingAI.escapeHtml(message || '')}</p>
                </div>
            `);
        },

        getString: function(key, fallback) {
            const dict = exploding_ai_ajax.i18n || {};
            return dict[key] || fallback || key;
        },

        showNotice: function(type, message) {
            const notice = $(`
                <div class="notice notice-${type} is-dismissible">
                    <p>${message}</p>
                    <button type="button" class="notice-dismiss">
                        <span class="screen-reader-text">Dismiss this notice.</span>
                    </button>
                </div>
            `);
            
            $('.wrap h1').after(notice);
            
            // Auto-dismiss success notices
            if (type === 'success') {
                setTimeout(() => notice.fadeOut(), 5000);
            }
            
            // Handle dismiss button
            notice.find('.notice-dismiss').on('click', function() {
                notice.fadeOut();
            });
        },

        initTooltips: function() {
            // Add tooltips to badges and buttons
            $('.growth-badge, .stage-badge').each(function() {
                const element = $(this);
                const tooltip = ExplodingAI.getTooltipText(element);
                if (tooltip) {
                    element.attr('title', tooltip);
                }
            });
        },

        getTooltipText: function(element) {
            if (element.hasClass('growth-badge')) {
                const growth = parseFloat(element.text());
                if (growth >= 200) return 'Explosive growth - trending rapidly!';
                if (growth >= 100) return 'High growth - gaining significant traction';
                if (growth >= 50) return 'Medium growth - steady increase';
                if (growth >= 20) return 'Low growth - gradual rise';
                return 'Minimal growth - early stage';
            }
            
            if (element.hasClass('stage-badge')) {
                const stage = element.text().toLowerCase();
                const stages = {
                    'emerging': 'Just starting to gain attention',
                    'growing': 'Steadily increasing in popularity',
                    'exploding': 'Rapidly trending and viral',
                    'declining': 'Past peak, losing momentum'
                };
                return stages[stage] || '';
            }
            
            return '';
        },

        getGrowthClass: function(growth) {
            if (growth >= 100) return 'exploding';
            if (growth >= 50) return 'high';
            if (growth >= 20) return 'medium';
            return 'low';
        },

        escapeHtml: function(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        },

        capitalize: function(str) {
            return str.charAt(0).toUpperCase() + str.slice(1);
        },

        numberFormat: function(num) {
            return new Intl.NumberFormat().format(num);
        },

        debounce: function(func, wait) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func.apply(this, args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        }
    };

    // Initialize when document is ready
    $(document).ready(function() {
        ExplodingAI.init();
    });

    // Make ExplodingAI available globally
    window.ExplodingAI = ExplodingAI;

})(jQuery);