<?php
/**
 * Exploding Topics AI Mode Addon for Vira Scope
 * 
 * @package ViraScope\Addons\ExplodingAI
 * @version 1.0.0
 */

namespace ViraScope\Addons\ExplodingAI;

use ViraScope\Traits\Singleton;

if (!defined('ABSPATH')) {
    exit;
}

// Debug: Log that the addon file is being loaded
if (defined('WP_DEBUG') && WP_DEBUG) {
    error_log('ExplodingAI addon file loaded');
}

// Autoload classes
spl_autoload_register(function ($class) {
    if (strpos($class, 'ViraScope\\Addons\\ExplodingAI\\') === 0) {
        $class_file = str_replace('ViraScope\\Addons\\ExplodingAI\\', '', $class);
        $class_file = str_replace('\\', '/', $class_file);
        $file_path = __DIR__ . '/includes/' . $class_file . '.php';
        
        if (file_exists($file_path)) {
            require_once $file_path;
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("ExplodingAI: Loaded class {$class} from {$file_path}");
            }
        }
    }
});

class ExplodingAI {

    use Singleton;

    private $version = '1.0.0';

    public function init() {
        // Check if base plugin is active
        if (!class_exists('ViraScope\\Fajar')) {
            add_action('admin_notices', [$this, 'base_plugin_notice']);
            return;
        }

        $this->setup_hooks();
        $this->setup_database();
    }

    private function setup_hooks() {
        // Add admin menu with higher priority to ensure it runs after main menu
        add_action('admin_menu', [$this, 'add_admin_menu'], 100);
        
        // Enqueue assets
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);
        
        // Initialize REST API
        $this->init_api();
        
        // AJAX handlers
        add_action('wp_ajax_exploding_ai_fetch_trends', [$this, 'ajax_fetch_trends']);
        add_action('wp_ajax_exploding_ai_refresh_data', [$this, 'ajax_refresh_data']);
        add_action('wp_ajax_exploding_ai_get_trends', [$this, 'ajax_get_trends']);
        add_action('wp_ajax_exploding_ai_generate_forecast', [$this, 'ajax_generate_forecast']);
        add_action('wp_ajax_exploding_ai_competitor_analysis', [$this, 'ajax_competitor_analysis']);
        add_action('wp_ajax_exploding_ai_geo_trends', [$this, 'ajax_geo_trends']);
        add_action('wp_ajax_exploding_ai_geo_compare', [$this, 'ajax_geo_compare']);
        
        // Add to main Vira Scope dashboard
        add_action('vrsc_dashboard_widgets', [$this, 'add_dashboard_widget']);
        
        // Debug hook to check if addon is loaded
        add_action('admin_notices', [$this, 'debug_addon_loaded']);
        
        // Create sample data for testing (only in debug mode)
        add_action('wp_loaded', [$this, 'create_sample_data']);
    }

    private function setup_database() {
        // Create database table on activation
        add_action('wp_loaded', [$this, 'create_database_table']);
    }

    private function init_api() {
        // Initialize REST API endpoints
        new \ViraScope\Addons\ExplodingAI\API\ExplodingAIAPI();
    }

    public function create_database_table() {
        global $wpdb;

        $table_name = $wpdb->prefix . 'vrsc_trends_ai';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            topic varchar(255) NOT NULL,
            growth decimal(5,2) DEFAULT 0.00,
            search_volume int(11) DEFAULT 0,
            trend_stage varchar(20) DEFAULT 'Emerging',
            short_description text,
            category varchar(100) DEFAULT 'general',
            ai_provider varchar(20) DEFAULT 'gemini',
            raw_data longtext,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY topic_idx (topic),
            KEY growth_idx (growth),
            KEY trend_stage_idx (trend_stage),
            KEY category_idx (category),
            KEY created_at_idx (created_at)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);

        // Set version
        update_option('vrsc_exploding_ai_version', $this->version);
    }

    public function add_admin_menu() {
        add_submenu_page(
            'vira-scope',
            __('AI Topics', 'vira-scope'),
            __('AI Topics', 'vira-scope'),
            'manage_options',
            'vira-scope-ai-topics',
            [$this, 'dashboard_page']
        );
    }

    public function enqueue_admin_assets($hook) {
        if (strpos($hook, 'vira-scope-ai-topics') === false) {
            return;
        }

        wp_enqueue_script(
            'exploding-ai-admin',
            plugin_dir_url(__FILE__) . 'assets/js/admin.js',
            ['jquery'],
            $this->version,
            true
        );

        wp_enqueue_style(
            'exploding-ai-admin',
            plugin_dir_url(__FILE__) . 'assets/css/admin.css',
            [],
            $this->version
        );

        wp_localize_script('exploding-ai-admin', 'exploding_ai_ajax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('exploding_ai_nonce'),
            'rest_url' => rest_url('virascope/v1/exploding-ai/'),
            'rest_nonce' => wp_create_nonce('wp_rest'),
            'i18n' => [
                'enterKeyword' => __('Please enter a keyword to forecast', 'vira-scope'),
                'enterDomain' => __('Please enter a competitor domain', 'vira-scope'),
                'selectRegions' => __('Please select at least 2 regions to compare', 'vira-scope'),
                'forecastError' => __('Unable to generate forecast at this time.', 'vira-scope'),
                'analysisError' => __('Unable to analyze competitor at this time.', 'vira-scope'),
                'geoError' => __('Unable to load geographic trends at this time.', 'vira-scope'),
                'compareError' => __('Unable to compare the selected regions right now.', 'vira-scope'),
                'forecastHeading' => __('Forecast for', 'vira-scope'),
                'analysisHeading' => __('Analysis for', 'vira-scope'),
                'regionLabel' => __('Region', 'vira-scope'),
                'timeframeLabel' => __('Timeframe', 'vira-scope'),
                'loading' => __('Loading...', 'vira-scope'),
                'noData' => __('No data available for your request.', 'vira-scope'),
                'timelineHeading' => __('Timeline Projection', 'vira-scope'),
                'insightsHeading' => __('Key Insights', 'vira-scope'),
                'opportunitiesHeading' => __('Opportunities', 'vira-scope'),
                'risksHeading' => __('Risks & Mitigation', 'vira-scope'),
                'trendScoreLabel' => __('Trend Score', 'vira-scope'),
                'confidenceLabel' => __('Confidence', 'vira-scope'),
                'growthOutlookLabel' => __('Growth Outlook', 'vira-scope'),
                'peakPeriodLabel' => __('Peak Period', 'vira-scope'),
                'periodHeader' => __('Period', 'vira-scope'),
                'growthHeader' => __('Growth', 'vira-scope'),
                'confidenceHeader' => __('Confidence', 'vira-scope'),
                'topKeywordsHeading' => __('Top Keywords', 'vira-scope'),
                'contentGapsHeading' => __('Content Gaps', 'vira-scope'),
                'recommendationsHeading' => __('Recommended Actions', 'vira-scope'),
                'geoInsightsHeading' => __('Insights', 'vira-scope'),
                'topTopicsHeading' => __('Top Topics', 'vira-scope'),
                'strengthsHeading' => __('Strengths', 'vira-scope'),
                'weaknessesHeading' => __('Weaknesses', 'vira-scope'),
                'regionComparisonHeading' => __('Region Comparison', 'vira-scope'),
                'trendingHeading' => __('Trending Topics in', 'vira-scope'),
                'monitoringLabel' => __('Monitoring', 'vira-scope'),
                'removeLabel' => __('Remove', 'vira-scope'),
                'momentumLabel' => __('Momentum', 'vira-scope'),
                'volumeLabel' => __('Volume', 'vira-scope'),
                'topicLabel' => __('Topic', 'vira-scope'),
                'keywordLabel' => __('Keyword', 'vira-scope'),
                'positionLabel' => __('Position', 'vira-scope'),
                'domainAuthorityLabel' => __('Domain Authority', 'vira-scope'),
                'organicTrafficLabel' => __('Organic Traffic', 'vira-scope'),
                'keywordCountLabel' => __('Keyword Count', 'vira-scope'),
                'trendDirectionLabel' => __('Trend Direction', 'vira-scope'),
                'allRegionsLabel' => __('All regions', 'vira-scope')
            ]
        ]);
    }

    public function dashboard_page() {
        include __DIR__ . '/includes/Views/dashboard.php';
    }

    public function ajax_fetch_trends() {
        check_ajax_referer('exploding_ai_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'vira-scope'));
        }

        $category = sanitize_text_field($_POST['category'] ?? 'general');
        $limit = intval($_POST['limit'] ?? 20);

        $service = new \ViraScope\Addons\ExplodingAI\Services\ExplodingAIService();
        $trends = $service->fetch_ai_trends($category, $limit);

        if ($trends) {
            wp_send_json_success([
                'trends' => $trends,
                'count' => count($trends),
                'category' => $category
            ]);
        } else {
            wp_send_json_error(__('Failed to fetch trends from AI providers', 'vira-scope'));
        }
    }

    public function ajax_refresh_data() {
        check_ajax_referer('exploding_ai_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'vira-scope'));
        }

        // Clear cache and fetch fresh data
        $this->clear_cache();
        
        $service = new \ViraScope\Addons\ExplodingAI\Services\ExplodingAIService();
        $categories = ['general', 'technology', 'business', 'health', 'entertainment'];
        $total_trends = 0;

        foreach ($categories as $category) {
            $trends = $service->fetch_ai_trends($category, 10);
            if ($trends) {
                $total_trends += count($trends);
            }
        }

        wp_send_json_success([
            'message' => sprintf(__('Refreshed %d trends across %d categories', 'vira-scope'), $total_trends, count($categories)),
            'total_trends' => $total_trends
        ]);
    }

    public function ajax_get_trends() {
        check_ajax_referer('exploding_ai_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'vira-scope'));
        }

        $category = sanitize_text_field($_POST['category'] ?? '');
        $min_growth = floatval($_POST['min_growth'] ?? 0);
        $trend_stage = sanitize_text_field($_POST['trend_stage'] ?? '');

        $model = new \ViraScope\Addons\ExplodingAI\Models\ExplodingAIModel();
        $trends = $model->get_trends([
            'category' => $category,
            'min_growth' => $min_growth,
            'trend_stage' => $trend_stage,
            'limit' => 50
        ]);

        wp_send_json_success($trends);
    }

    public function ajax_generate_forecast() {
        check_ajax_referer('exploding_ai_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'vira-scope'));
        }

        $keyword = sanitize_text_field($_POST['keyword'] ?? '');
        $period = sanitize_text_field($_POST['period'] ?? '3');
        $category = sanitize_text_field($_POST['category'] ?? 'general');

        if (empty($keyword)) {
            wp_send_json_error(__('Please enter a keyword to forecast', 'vira-scope'));
        }

        $service = new \ViraScope\Addons\ExplodingAI\Services\ExplodingAIService();
        $forecast = $service->generate_forecast($keyword, $period, $category);

        if ($forecast) {
            wp_send_json_success($forecast);
        }

        wp_send_json_error(__('Unable to generate forecast at this time.', 'vira-scope'));
    }

    public function ajax_competitor_analysis() {
        check_ajax_referer('exploding_ai_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'vira-scope'));
        }

        $domain = sanitize_text_field($_POST['domain'] ?? '');
        $analysis_type = sanitize_text_field($_POST['analysis_type'] ?? 'keywords');

        if (empty($domain)) {
            wp_send_json_error(__('Please enter a competitor domain', 'vira-scope'));
        }

        $service = new \ViraScope\Addons\ExplodingAI\Services\ExplodingAIService();
        $analysis = $service->analyze_competitor($domain, $analysis_type);

        if ($analysis) {
            wp_send_json_success($analysis);
        }

        wp_send_json_error(__('Unable to analyze competitor at this time.', 'vira-scope'));
    }

    public function ajax_geo_trends() {
        check_ajax_referer('exploding_ai_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'vira-scope'));
        }

        $country = sanitize_text_field($_POST['country'] ?? 'US');
        $region = sanitize_text_field($_POST['region'] ?? '');
        $timeframe = sanitize_text_field($_POST['timeframe'] ?? '7d');

        $service = new \ViraScope\Addons\ExplodingAI\Services\ExplodingAIService();
        $trends = $service->analyze_geo_trends($country, $region, $timeframe);

        if ($trends) {
            wp_send_json_success($trends);
        }

        wp_send_json_error(__('Unable to load geographic trends at this time.', 'vira-scope'));
    }

    public function ajax_geo_compare() {
        check_ajax_referer('exploding_ai_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'vira-scope'));
        }

        $regions = isset($_POST['regions']) ? (array) $_POST['regions'] : [];
        $timeframe = sanitize_text_field($_POST['timeframe'] ?? '7d');

        $regions = array_filter(array_map('sanitize_text_field', $regions));

        if (count($regions) < 2) {
            wp_send_json_error(__('Please select at least 2 regions to compare', 'vira-scope'));
        }

        $service = new \ViraScope\Addons\ExplodingAI\Services\ExplodingAIService();
        $comparison = $service->compare_geo_regions($regions, $timeframe);

        if ($comparison) {
            wp_send_json_success($comparison);
        }

        wp_send_json_error(__('Unable to compare the selected regions right now.', 'vira-scope'));
    }

    public function create_sample_data() {
        // Only create sample data if no trends exist and we're in debug mode
        if (!defined('WP_DEBUG') || !WP_DEBUG) {
            return;
        }

        $model = new \ViraScope\Addons\ExplodingAI\Models\ExplodingAIModel();
        $existing = $model->get_trends(['limit' => 1]);
        
        if (!empty($existing)) {
            return; // Sample data already exists
        }

        // Create sample trends for testing
        $sample_trends = [
            [
                'topic' => 'AI-Powered Content Creation',
                'growth' => 145.5,
                'search_volume' => 12500,
                'trend_stage' => 'Exploding',
                'short_description' => 'Artificial intelligence tools for automated content generation',
                'category' => 'technology',
                'ai_provider' => 'gemini'
            ],
            [
                'topic' => 'Sustainable Fashion Trends',
                'growth' => 67.2,
                'search_volume' => 8900,
                'trend_stage' => 'Growing',
                'short_description' => 'Eco-friendly clothing and sustainable fashion practices',
                'category' => 'fashion',
                'ai_provider' => 'openai'
            ],
            [
                'topic' => 'Remote Work Tools',
                'growth' => 23.8,
                'search_volume' => 15600,
                'trend_stage' => 'Emerging',
                'short_description' => 'Digital tools and platforms for remote collaboration',
                'category' => 'business',
                'ai_provider' => 'claude'
            ],
            [
                'topic' => 'Plant-Based Nutrition',
                'growth' => 89.3,
                'search_volume' => 11200,
                'trend_stage' => 'Growing',
                'short_description' => 'Nutritional benefits and recipes for plant-based diets',
                'category' => 'health',
                'ai_provider' => 'gemini'
            ],
            [
                'topic' => 'Cryptocurrency Regulations',
                'growth' => 234.7,
                'search_volume' => 19800,
                'trend_stage' => 'Exploding',
                'short_description' => 'Government policies and regulations for digital currencies',
                'category' => 'finance',
                'ai_provider' => 'openai'
            ]
        ];

        foreach ($sample_trends as $trend) {
            $model->save_trend($trend);
        }
    }

    public function add_dashboard_widget() {
        $model = new \ViraScope\Addons\ExplodingAI\Models\ExplodingAIModel();
        $recent_trends = $model->get_trends(['limit' => 5]);
        
        echo '<div class="vrsc-card">';
        echo '<h2>' . __('AI Trending Topics', 'vira-scope') . '</h2>';
        
        if (!empty($recent_trends)) {
            echo '<div class="exploding-ai-widget">';
            foreach ($recent_trends as $trend) {
                $growth_class = $this->get_growth_class($trend->growth);
                echo '<div class="trend-item">';
                echo '<span class="trend-topic">' . esc_html($trend->topic) . '</span>';
                echo '<span class="trend-growth ' . $growth_class . '">' . esc_html($trend->growth) . '%</span>';
                echo '</div>';
            }
            echo '</div>';
        } else {
            echo '<p>' . __('No AI trends available. Click "Fetch Global Trends" to get started.', 'vira-scope') . '</p>';
        }
        
        echo '<p><a href="' . admin_url('admin.php?page=vira-scope-ai-topics') . '" class="button">' . __('View All AI Topics', 'vira-scope') . '</a></p>';
        echo '</div>';
    }

    private function get_growth_class($growth) {
        if ($growth >= 100) return 'growth-exploding';
        if ($growth >= 50) return 'growth-high';
        if ($growth >= 20) return 'growth-medium';
        return 'growth-low';
    }

    private function clear_cache() {
        global $wpdb;
        $table = $wpdb->prefix . 'vrsc_trends_ai';
        
        // Delete trends older than 24 hours
        $wpdb->query($wpdb->prepare(
            "DELETE FROM $table WHERE created_at < %s",
            date('Y-m-d H:i:s', strtotime('-24 hours'))
        ));
    }

    public function base_plugin_notice() {
        echo '<div class="notice notice-error"><p>' . 
             __('Exploding AI addon requires the base Vira Scope plugin to be installed and activated.', 'vira-scope') . 
             '</p></div>';
    }

    public function debug_addon_loaded() {
        if (current_user_can('manage_options') && isset($_GET['debug_exploding_ai'])) {
            global $menu, $submenu;
            echo '<div class="notice notice-info"><p>';
            echo '<strong>Exploding AI Debug Info:</strong><br>';
            echo 'Addon loaded: ' . (class_exists('ViraScope\\Addons\\ExplodingAI\\ExplodingAI') ? 'Yes' : 'No') . '<br>';
            echo 'ViraScope base class exists: ' . (class_exists('ViraScope\\Fajar') ? 'Yes' : 'No') . '<br>';
            echo 'Parent menu exists: ';
            
            $parent_exists = false;
            if (isset($menu)) {
                foreach ($menu as $menu_item) {
                    if (isset($menu_item[2]) && $menu_item[2] === 'vira-scope') {
                        $parent_exists = true;
                        break;
                    }
                }
            }
            echo $parent_exists ? 'Yes' : 'No';
            
            if (isset($submenu['vira-scope'])) {
                echo '<br>Submenu items: ' . count($submenu['vira-scope']);
            }
            
            echo '</p></div>';
        }
    }
}

// Initialize the addon immediately since it's loaded by the main plugin
if (class_exists('ViraScope\\Fajar')) {
    add_action('init', function() {
        \ViraScope\Addons\ExplodingAI\ExplodingAI::instance()->init();
    });
}