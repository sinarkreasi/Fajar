<?php
/**
 * Vira Scope Pro Addon
 * Advanced features for professional trend analysis
 */

namespace ViraScope\Addons\Pro;

use ViraScope\Traits\Singleton;

if (!defined('ABSPATH')) {
    exit;
}

// Debug: Log that the Pro addon file is being loaded
if (defined('WP_DEBUG') && WP_DEBUG) {
    error_log('ViraScopePro addon file loaded');
}

class ViraScopePro {

    use Singleton;

    private $version = '1.0.0';
    private $license_key;

    public function init() {
        // Debug logging
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('ViraScopePro: init() called');
        }
        
        // Check if base plugin is active
        if (!class_exists('ViraScope\\Fajar')) {
            add_action('admin_notices', [$this, 'base_plugin_notice']);
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('ViraScopePro: Base plugin not found');
            }
            return;
        }

        $this->license_key = get_option('vrsc_pro_license_key', '');
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('ViraScopePro: License key: ' . ($this->license_key ? 'exists' : 'empty'));
            error_log('ViraScopePro: is_licensed(): ' . ($this->is_licensed() ? 'true' : 'false'));
        }
        
        // Always add debug notice hook
        add_action('admin_notices', [$this, 'debug_pro_status']);
        
        if ($this->is_licensed()) {
            $this->setup_hooks();
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('ViraScopePro: Hooks setup completed');
            }
        } else {
            add_action('admin_notices', [$this, 'license_notice']);
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('ViraScopePro: License check failed, showing notice');
            }
        }
    }

    private function setup_hooks() {
        // Add Pro menu items
        add_action('admin_menu', [$this, 'add_pro_menus'], 75);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);
        
        // Add Pro features
        add_filter('vrsc_trend_analysis', [$this, 'enhance_trend_analysis'], 10, 2);
        add_action('vrsc_after_analysis', [$this, 'competitor_analysis']);
        
        // Add Pro shortcodes
        add_shortcode('vrsc_forecast', [$this, 'forecast_shortcode']);
        add_shortcode('vrsc_competitor_watch', [$this, 'competitor_shortcode']);
        add_shortcode('vrsc_geo_trends', [$this, 'geo_trends_shortcode']);
        
        // Schedule advanced analysis
        if (!wp_next_scheduled('vrsc_pro_advanced_analysis')) {
            wp_schedule_event(time(), 'daily', 'vrsc_pro_advanced_analysis');
        }
        add_action('vrsc_pro_advanced_analysis', [$this, 'run_advanced_analysis']);
    }

    public function add_pro_menus() {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('ViraScopePro: add_pro_menus() called');
        }

        $result1 = add_submenu_page(
            'vira-scope',
            __('Trend Forecasting', 'vira-scope'),
            __('Forecasting', 'vira-scope'),
            'manage_options',
            'vira-scope-forecasting',
            [$this, 'forecasting_page']
        );

        $result2 = add_submenu_page(
            'vira-scope',
            __('Competitor Watch', 'vira-scope'),
            __('Competitors', 'vira-scope'),
            'manage_options',
            'vira-scope-competitors',
            [$this, 'competitors_page']
        );

        $result3 = add_submenu_page(
            'vira-scope',
            __('Geo Trends', 'vira-scope'),
            __('Geo Analysis', 'vira-scope'),
            'manage_options',
            'vira-scope-geo',
            [$this, 'geo_page']
        );

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('ViraScopePro: Menu results - Forecasting: ' . ($result1 ? 'success' : 'failed'));
            error_log('ViraScopePro: Menu results - Competitors: ' . ($result2 ? 'success' : 'failed'));
            error_log('ViraScopePro: Menu results - Geo: ' . ($result3 ? 'success' : 'failed'));
        }
    }

    public function enqueue_admin_assets($hook) {
        $allowed_hooks = [
            'vira-scope_page_vira-scope-forecasting',
            'vira-scope_page_vira-scope-competitors',
            'vira-scope_page_vira-scope-geo'
        ];

        if (!in_array($hook, $allowed_hooks, true)) {
            return;
        }

        $handle = 'exploding-ai-admin';
        $version = defined('VRSC_VERSION') ? VRSC_VERSION : $this->version;

        wp_enqueue_style(
            $handle,
            VRSC_URL . 'Addons/ExplodingAI/assets/css/admin.css',
            [],
            $version
        );

        wp_enqueue_script(
            $handle,
            VRSC_URL . 'Addons/ExplodingAI/assets/js/admin.js',
            ['jquery'],
            $version,
            true
        );

        wp_localize_script($handle, 'exploding_ai_ajax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('exploding_ai_nonce'),
            'rest_url' => rest_url('virascope/v1/exploding-ai/'),
            'rest_nonce' => wp_create_nonce('wp_rest'),
            'i18n' => [
                'enterKeyword' => __('Please enter a keyword to forecast', 'vira-scope'),
                'enterDomain' => __('Please enter a competitor domain', 'vira-scope'),
                'selectRegions' => __('Please select at least 2 regions to compare', 'vira-scope'),
                'forecastError' => __('Unable to generate forecast at this time.', 'vira-scope'),
                'analysisError' => __('Unable to analyze competitor at this time.', 'vira-scope'),
                'geoError' => __('Unable to load geographic trends at this time.', 'vira-scope'),
                'compareError' => __('Unable to compare the selected regions right now.', 'vira-scope'),
                'forecastHeading' => __('Forecast for', 'vira-scope'),
                'analysisHeading' => __('Analysis for', 'vira-scope'),
                'regionLabel' => __('Region', 'vira-scope'),
                'timeframeLabel' => __('Timeframe', 'vira-scope'),
                'loading' => __('Loading...', 'vira-scope'),
                'noData' => __('No data available for your request.', 'vira-scope'),
                'timelineHeading' => __('Timeline Projection', 'vira-scope'),
                'insightsHeading' => __('Key Insights', 'vira-scope'),
                'opportunitiesHeading' => __('Opportunities', 'vira-scope'),
                'risksHeading' => __('Risks & Mitigation', 'vira-scope'),
                'trendScoreLabel' => __('Trend Score', 'vira-scope'),
                'confidenceLabel' => __('Confidence', 'vira-scope'),
                'growthOutlookLabel' => __('Growth Outlook', 'vira-scope'),
                'peakPeriodLabel' => __('Peak Period', 'vira-scope'),
                'periodHeader' => __('Period', 'vira-scope'),
                'growthHeader' => __('Growth', 'vira-scope'),
                'confidenceHeader' => __('Confidence', 'vira-scope'),
                'topKeywordsHeading' => __('Top Keywords', 'vira-scope'),
                'contentGapsHeading' => __('Content Gaps', 'vira-scope'),
                'recommendationsHeading' => __('Recommended Actions', 'vira-scope'),
                'geoInsightsHeading' => __('Insights', 'vira-scope'),
                'topTopicsHeading' => __('Top Topics', 'vira-scope'),
                'strengthsHeading' => __('Strengths', 'vira-scope'),
                'weaknessesHeading' => __('Weaknesses', 'vira-scope'),
                'regionComparisonHeading' => __('Region Comparison', 'vira-scope'),
                'trendingHeading' => __('Trending Topics in', 'vira-scope'),
                'monitoringLabel' => __('Monitoring', 'vira-scope'),
                'removeLabel' => __('Remove', 'vira-scope'),
                'momentumLabel' => __('Momentum', 'vira-scope'),
                'volumeLabel' => __('Volume', 'vira-scope'),
                'topicLabel' => __('Topic', 'vira-scope'),
                'keywordLabel' => __('Keyword', 'vira-scope'),
                'positionLabel' => __('Position', 'vira-scope'),
                'domainAuthorityLabel' => __('Domain Authority', 'vira-scope'),
                'organicTrafficLabel' => __('Organic Traffic', 'vira-scope'),
                'keywordCountLabel' => __('Keyword Count', 'vira-scope'),
                'trendDirectionLabel' => __('Trend Direction', 'vira-scope'),
                'allRegionsLabel' => __('All regions', 'vira-scope')
            ]
        ]);
    }

    public function enhance_trend_analysis($analysis, $keyword) {
        if (!$this->is_licensed()) {
            return $analysis;
        }

        // Add advanced metrics
        $analysis['pro_features'] = [
            'forecast_score' => $this->calculate_forecast_score($keyword),
            'competition_analysis' => $this->analyze_competition($keyword),
            'seasonal_patterns' => $this->detect_seasonal_patterns($keyword),
            'content_gaps' => $this->identify_content_gaps($keyword),
            'monetization_potential' => $this->assess_monetization($keyword)
        ];

        return $analysis;
    }

    public function competitor_analysis($keyword) {
        if (!$this->is_licensed()) {
            return;
        }

        // Analyze competitor keywords and strategies
        $competitors = $this->get_competitor_data($keyword);
        $this->save_competitor_insights($keyword, $competitors);
    }

    public function forecast_shortcode($atts) {
        if (!$this->is_licensed()) {
            return '<p>' . __('Pro license required for forecasting features.', 'vira-scope') . '</p>';
        }

        $atts = shortcode_atts([
            'keyword' => '',
            'months' => 3,
            'display' => 'chart'
        ], $atts, 'vrsc_forecast');

        ob_start();
        include VRSC_PATH . 'Addons/Pro/Views/forecast-shortcode.php';
        return ob_get_clean();
    }

    public function competitor_shortcode($atts) {
        if (!$this->is_licensed()) {
            return '<p>' . __('Pro license required for competitor analysis.', 'vira-scope') . '</p>';
        }

        $atts = shortcode_atts([
            'domain' => '',
            'limit' => 10
        ], $atts, 'vrsc_competitor_watch');

        ob_start();
        include VRSC_PATH . 'Addons/Pro/Views/competitor-shortcode.php';
        return ob_get_clean();
    }

    public function geo_trends_shortcode($atts) {
        if (!$this->is_licensed()) {
            return '<p>' . __('Pro license required for geo trends.', 'vira-scope') . '</p>';
        }

        $atts = shortcode_atts([
            'country' => 'US',
            'region' => '',
            'limit' => 10
        ], $atts, 'vrsc_geo_trends');

        ob_start();
        include VRSC_PATH . 'Addons/Pro/Views/geo-trends-shortcode.php';
        return ob_get_clean();
    }

    public function forecasting_page() {
        if (!$this->is_licensed()) {
            echo '<div class="wrap"><h1>License Required</h1><p>Please enter a valid Pro license key to access forecasting features.</p></div>';
            return;
        }
        
        include VRSC_PATH . 'Addons/Pro/Views/forecasting.php';
    }

    public function competitors_page() {
        if (!$this->is_licensed()) {
            echo '<div class="wrap"><h1>License Required</h1><p>Please enter a valid Pro license key to access competitor analysis.</p></div>';
            return;
        }
        
        include VRSC_PATH . 'Addons/Pro/Views/competitors.php';
    }

    public function geo_page() {
        if (!$this->is_licensed()) {
            echo '<div class="wrap"><h1>License Required</h1><p>Please enter a valid Pro license key to access geo trends.</p></div>';
            return;
        }
        
        include VRSC_PATH . 'Addons/Pro/Views/geo-trends.php';
    }

    public function run_advanced_analysis() {
        if (!$this->is_licensed()) {
            return;
        }

        // Run advanced AI analysis for Pro features
        $this->forecast_trending_topics();
        $this->update_competitor_data();
        $this->analyze_geo_trends();
    }

    private function calculate_forecast_score($keyword) {
        // Advanced forecasting algorithm
        return rand(60, 95); // Placeholder
    }

    private function analyze_competition($keyword) {
        // Competition analysis logic
        return [
            'difficulty' => rand(1, 100),
            'top_competitors' => ['example.com', 'competitor.com'],
            'content_gaps' => ['how-to guides', 'video content']
        ];
    }

    private function detect_seasonal_patterns($keyword) {
        // Seasonal pattern detection
        return [
            'peak_months' => ['December', 'January'],
            'low_months' => ['June', 'July'],
            'pattern_strength' => 'moderate'
        ];
    }

    private function identify_content_gaps($keyword) {
        // Content gap analysis
        return [
            'missing_topics' => ['beginner guides', 'advanced tutorials'],
            'content_types' => ['infographics', 'podcasts'],
            'opportunity_score' => rand(70, 90)
        ];
    }

    private function assess_monetization($keyword) {
        // Monetization potential assessment
        return [
            'commercial_intent' => rand(1, 10),
            'cpc_estimate' => '$' . number_format(rand(50, 500) / 100, 2),
            'affiliate_potential' => rand(1, 10)
        ];
    }

    private function get_competitor_data($keyword) {
        // Fetch competitor data
        return [];
    }

    private function save_competitor_insights($keyword, $competitors) {
        // Save competitor insights to database
    }

    private function forecast_trending_topics() {
        // AI-powered trend forecasting
    }

    private function update_competitor_data() {
        // Update competitor tracking data
    }

    private function analyze_geo_trends() {
        // Geographic trend analysis
    }

    private function is_licensed() {
        // License validation logic
        // For development/testing, always return true for now
        return true; // Temporarily bypass license check for testing
        
        // Original logic (commented out for testing):
        // if (defined('WP_DEBUG') && WP_DEBUG) {
        //     return true; // Allow in debug mode for testing
        // }
        // return !empty($this->license_key) && $this->validate_license($this->license_key);
    }

    private function validate_license($license_key) {
        // Validate license with remote server
        // This is a placeholder - implement actual license validation
        // For now, accept any key longer than 10 characters
        return strlen($license_key) > 10;
    }

    public function base_plugin_notice() {
        echo '<div class="notice notice-error"><p>' . 
             __('Vira Scope Pro requires the base Vira Scope plugin to be installed and activated.', 'vira-scope') . 
             '</p></div>';
    }

    public function license_notice() {
        echo '<div class="notice notice-warning"><p>' . 
             __('Please enter your Vira Scope Pro license key in the settings to unlock advanced features.', 'vira-scope') . 
             '</p></div>';
    }

    public function debug_pro_status() {
        if (current_user_can('manage_options') && isset($_GET['debug_pro'])) {
            echo '<div class="notice notice-info"><p>';
            echo '<strong>ViraScope Pro Debug Info:</strong><br>';
            echo 'Pro addon loaded: ' . (class_exists('ViraScope\\Addons\\Pro\\ViraScopePro') ? 'Yes' : 'No') . '<br>';
            echo 'Base class exists: ' . (class_exists('ViraScope\\Fajar') ? 'Yes' : 'No') . '<br>';
            echo 'License key: ' . ($this->license_key ? 'Set (' . strlen($this->license_key) . ' chars)' : 'Not set') . '<br>';
            echo 'Is licensed: ' . ($this->is_licensed() ? 'Yes' : 'No') . '<br>';
            echo 'WP_DEBUG: ' . (defined('WP_DEBUG') && WP_DEBUG ? 'Enabled' : 'Disabled') . '<br>';
            echo '</p></div>';
        }
    }
}

// Initialize the Pro addon
if (class_exists('ViraScope\\Fajar')) {
    add_action('init', function() {
        \ViraScope\Addons\Pro\ViraScopePro::instance()->init();
    });
}