<?php
/**
 * Pro Geo Trends Page
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap">
    <h1><?php _e('Geographic Trend Analysis', 'vira-scope'); ?></h1>
    
    <div class="vrsc-pro-feature">
        <div class="feature-header">
            <h2><?php _e('Location-Based Trend Intelligence', 'vira-scope'); ?></h2>
            <p><?php _e('Discover trending topics by geographic location and analyze regional search patterns.', 'vira-scope'); ?></p>
        </div>
        
        <div class="geo-controls">
            <div class="control-group">
                <label for="geo-country"><?php _e('Country:', 'vira-scope'); ?></label>
                <select id="geo-country">
                    <option value="US"><?php _e('United States', 'vira-scope'); ?></option>
                    <option value="GB"><?php _e('United Kingdom', 'vira-scope'); ?></option>
                    <option value="CA"><?php _e('Canada', 'vira-scope'); ?></option>
                    <option value="AU"><?php _e('Australia', 'vira-scope'); ?></option>
                    <option value="DE"><?php _e('Germany', 'vira-scope'); ?></option>
                    <option value="FR"><?php _e('France', 'vira-scope'); ?></option>
                    <option value="JP"><?php _e('Japan', 'vira-scope'); ?></option>
                    <option value="IN"><?php _e('India', 'vira-scope'); ?></option>
                    <option value="ID"><?php _e('Indonesia', 'vira-scope'); ?></option>
                </select>
            </div>
            
            <div class="control-group">
                <label for="geo-region"><?php _e('Region/State:', 'vira-scope'); ?></label>
                <input type="text" id="geo-region" placeholder="<?php _e('Optional: California, Texas, etc.', 'vira-scope'); ?>">
            </div>
            
            <div class="control-group">
                <label for="geo-timeframe"><?php _e('Timeframe:', 'vira-scope'); ?></label>
                <select id="geo-timeframe">
                    <option value="1d"><?php _e('Last 24 Hours', 'vira-scope'); ?></option>
                    <option value="7d" selected><?php _e('Last 7 Days', 'vira-scope'); ?></option>
                    <option value="30d"><?php _e('Last 30 Days', 'vira-scope'); ?></option>
                    <option value="90d"><?php _e('Last 3 Months', 'vira-scope'); ?></option>
                </select>
            </div>
            
            <button id="analyze-geo-trends" class="button button-primary">
                <?php _e('Analyze Geo Trends', 'vira-scope'); ?>
            </button>
        </div>
        
        <div id="geo-results" class="geo-results">
            <div class="geo-placeholder">
                <h3><?php _e('Geographic Trend Results', 'vira-scope'); ?></h3>
                <p><?php _e('Select a country and click "Analyze Geo Trends" to see location-specific trending topics.', 'vira-scope'); ?></p>
                
                <div class="sample-geo-features">
                    <h4><?php _e('Geo Analysis Features:', 'vira-scope'); ?></h4>
                    <div class="geo-features-grid">
                        <div class="geo-feature-item">
                            <h5><?php _e('Regional Hotspots', 'vira-scope'); ?></h5>
                            <p><?php _e('Identify trending regions for topics', 'vira-scope'); ?></p>
                        </div>
                        <div class="geo-feature-item">
                            <h5><?php _e('Local Search Patterns', 'vira-scope'); ?></h5>
                            <p><?php _e('Understand regional search behavior', 'vira-scope'); ?></p>
                        </div>
                        <div class="geo-feature-item">
                            <h5><?php _e('Cultural Trends', 'vira-scope'); ?></h5>
                            <p><?php _e('Discover location-specific interests', 'vira-scope'); ?></p>
                        </div>
                        <div class="geo-feature-item">
                            <h5><?php _e('Market Opportunities', 'vira-scope'); ?></h5>
                            <p><?php _e('Find untapped regional markets', 'vira-scope'); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="geo-comparison">
            <h3><?php _e('Multi-Region Comparison', 'vira-scope'); ?></h3>
            <div class="comparison-controls">
                <div class="region-selector">
                    <div class="region-checkboxes">
                        <label><input type="checkbox" value="US"> <?php _e('United States', 'vira-scope'); ?></label>
                        <label><input type="checkbox" value="GB"> <?php _e('United Kingdom', 'vira-scope'); ?></label>
                        <label><input type="checkbox" value="CA"> <?php _e('Canada', 'vira-scope'); ?></label>
                        <label><input type="checkbox" value="AU"> <?php _e('Australia', 'vira-scope'); ?></label>
                        <label><input type="checkbox" value="DE"> <?php _e('Germany', 'vira-scope'); ?></label>
                        <label><input type="checkbox" value="FR"> <?php _e('France', 'vira-scope'); ?></label>
                        <label><input type="checkbox" value="JP"> <?php _e('Japan', 'vira-scope'); ?></label>
                        <label><input type="checkbox" value="IN"> <?php _e('India', 'vira-scope'); ?></label>
                        <label><input type="checkbox" value="ID"> <?php _e('Indonesia', 'vira-scope'); ?></label>
                    </div>
                </div>
                <button id="compare-regions" class="button"><?php _e('Compare Regions', 'vira-scope'); ?></button>
            </div>
            
            <div id="comparison-results" class="comparison-results">
                <p><?php _e('Select regions to compare trending topics across different geographic locations.', 'vira-scope'); ?></p>
            </div>
        </div>
    </div>
</div>
