<?php
/**
 * Pro Forecasting Page
 */

if (!defined('ABSPATH')) {
    exit;
}

$exploding_ai_service = new \ViraScope\Addons\ExplodingAI\Services\ExplodingAIService();
$forecast_categories = $exploding_ai_service->get_available_categories();
?>

<div class="wrap">
    <h1><?php _e('Trend Forecasting', 'vira-scope'); ?></h1>
    
    <div class="vrsc-pro-feature">
        <div class="feature-header">
            <h2><?php _e('AI-Powered Trend Forecasting', 'vira-scope'); ?></h2>
            <p><?php _e('Predict future trending topics using advanced AI algorithms and historical data analysis.', 'vira-scope'); ?></p>
        </div>
        
        <div class="forecasting-controls">
            <div class="control-group">
                <label for="forecast-keyword"><?php _e('Keyword/Topic:', 'vira-scope'); ?></label>
                <input type="text" id="forecast-keyword" placeholder="<?php _e('Enter keyword to forecast', 'vira-scope'); ?>">
            </div>
            
            <div class="control-group">
                <label for="forecast-period"><?php _e('Forecast Period:', 'vira-scope'); ?></label>
                <select id="forecast-period">
                    <option value="1"><?php _e('1 Month', 'vira-scope'); ?></option>
                    <option value="3" selected><?php _e('3 Months', 'vira-scope'); ?></option>
                    <option value="6"><?php _e('6 Months', 'vira-scope'); ?></option>
                    <option value="12"><?php _e('1 Year', 'vira-scope'); ?></option>
                </select>
            </div>
            
            <div class="control-group">
                <label for="forecast-category"><?php _e('Category:', 'vira-scope'); ?></label>
                <select id="forecast-category">
                    <option value=""><?php _e('All Categories', 'vira-scope'); ?></option>
                    <?php foreach ($forecast_categories as $category_key => $category_label) : ?>
                        <option value="<?php echo esc_attr($category_key); ?>"><?php echo esc_html($category_label); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <button id="generate-forecast" class="button button-primary">
                <?php _e('Generate Forecast', 'vira-scope'); ?>
            </button>
        </div>
        
        <div id="forecast-results" class="forecast-results">
            <div class="forecast-placeholder">
                <h3><?php _e('Forecast Results', 'vira-scope'); ?></h3>
                <p><?php _e('Enter a keyword and click "Generate Forecast" to see AI-powered predictions.', 'vira-scope'); ?></p>
                
                <div class="sample-forecast">
                    <h4><?php _e('Sample Forecast Features:', 'vira-scope'); ?></h4>
                    <ul>
                        <li><?php _e('Trend trajectory prediction', 'vira-scope'); ?></li>
                        <li><?php _e('Peak timing estimation', 'vira-scope'); ?></li>
                        <li><?php _e('Seasonal pattern analysis', 'vira-scope'); ?></li>
                        <li><?php _e('Competition forecast', 'vira-scope'); ?></li>
                        <li><?php _e('Content opportunity windows', 'vira-scope'); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
