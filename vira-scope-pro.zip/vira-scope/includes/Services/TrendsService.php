<?php
/**
 * Trends Service for Vira Scope.
 */

namespace ViraScope\Services;

use ViraScope\Models\Trend;
use ViraScope\Helpers\CacheHelper;

if (!defined('ABSPATH')) {
    exit;
}

class TrendsService {

    private $cache_helper;

    public function __construct() {
        $this->cache_helper = new CacheHelper();
    }



    public function analyze_site_content($content_types = null, $force_refresh = false) {
        if ($content_types === null) {
            $content_types = ['post', 'page'];
        }

        $analysis_results = [];
        
        // Analyze posts by type
        foreach ($content_types as $post_type) {
            $analysis_results[$post_type] = $this->analyze_content_by_type($post_type, $force_refresh);
        }
        
        // Analyze taxonomies if requested
        if (in_array('taxonomies', $content_types)) {
            $analysis_results['taxonomies'] = $this->analyze_taxonomies($force_refresh);
        }
        
        return $analysis_results;
    }

    public function analyze_content_by_type($post_type, $force_refresh = false) {
        // First, get total count
        $total_posts = wp_count_posts($post_type);
        $total_published = $total_posts->publish ?? 0;
        
        // If no published posts, return early
        if ($total_published == 0) {
            return [
                'keywords' => [],
                'processed_count' => 0,
                'total_posts' => 0
            ];
        }

        $meta_query = [];
        if (!$force_refresh) {
            $meta_query = [
                [
                    'key' => '_vrsc_analyzed',
                    'compare' => 'NOT EXISTS'
                ]
            ];
        }

        $posts = get_posts([
            'post_type' => $post_type,
            'post_status' => 'publish',
            'numberposts' => 50, // Limit per type
            'meta_query' => $meta_query
        ]);

        // If no unanalyzed posts found and not force refresh, get some recent posts anyway
        if (empty($posts) && !$force_refresh) {
            $posts = get_posts([
                'post_type' => $post_type,
                'post_status' => 'publish',
                'numberposts' => 10, // Get fewer recent posts
                'orderby' => 'date',
                'order' => 'DESC'
            ]);
        }

        $keywords = [];
        $processed_count = 0;
        
        foreach ($posts as $post) {
            $content = $post->post_title . ' ' . $post->post_content . ' ' . $post->post_excerpt;
            
            // Skip if content is too short
            if (strlen(trim($content)) < 10) {
                continue;
            }
            
            $extracted = $this->extract_keywords($content);
            $keywords = array_merge($keywords, $extracted);
            
            // Mark as analyzed (only if not force refresh to avoid constant re-marking)
            if (!$force_refresh) {
                update_post_meta($post->ID, '_vrsc_analyzed', time());
            }
            $processed_count++;
        }

        return [
            'keywords' => array_unique($keywords),
            'processed_count' => $processed_count,
            'total_posts' => $total_published
        ];
    }

    public function analyze_taxonomies($force_refresh = false) {
        $taxonomies = get_taxonomies(['public' => true], 'names');
        $keywords = [];
        $processed_count = 0;
        
        foreach ($taxonomies as $taxonomy) {
            $terms = get_terms([
                'taxonomy' => $taxonomy,
                'hide_empty' => true,
                'number' => 100
            ]);
            
            foreach ($terms as $term) {
                $content = $term->name . ' ' . $term->description;
                $extracted = $this->extract_keywords($content);
                $keywords = array_merge($keywords, $extracted);
                $processed_count++;
            }
        }
        
        return [
            'keywords' => array_unique($keywords),
            'processed_count' => $processed_count,
            'taxonomies' => array_keys($taxonomies)
        ];
    }

    public function get_latest_trends($limit = 20, $min_keyword_length = 0) {
        $cache_key = 'vrsc_latest_trends_' . $limit . '_' . $min_keyword_length;
        $cached = $this->cache_helper->get($cache_key);

        if ($cached !== false) {
            return $cached;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'vrsc_trends';

        $where_clause = '';
        if ($min_keyword_length > 0) {
            $where_clause = $wpdb->prepare(' AND CHAR_LENGTH(keyword) - CHAR_LENGTH(REPLACE(keyword, " ", "")) + 1 >= %d', $min_keyword_length);
        }

        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table WHERE 1=1 $where_clause ORDER BY trend_score DESC, created_at DESC LIMIT %d",
            $limit
        ));

        $trends = [];
        foreach ($results as $result) {
            $trends[] = new Trend($result);
        }

        $this->cache_helper->set($cache_key, $trends, 300); // 5 minutes cache
        return $trends;
    }

    private function extract_keywords($content) {
        // Enhanced keyword extraction
        $content = strip_tags($content);
        $content = html_entity_decode($content);
        
        // Clean up content
        $content = preg_replace('/\s+/', ' ', $content); // Multiple spaces to single
        $content = trim($content);
        
        if (strlen($content) < 10) {
            return [];
        }
        
        $keywords = [];
        
        // Extract single words
        $words = str_word_count(strtolower($content), 1);
        
        // Enhanced stop words list
        $stop_words = [
            'the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by',
            'a', 'an', 'as', 'are', 'was', 'were', 'been', 'be', 'have', 'has', 'had',
            'do', 'does', 'did', 'will', 'would', 'could', 'should', 'may', 'might',
            'this', 'that', 'these', 'those', 'i', 'you', 'he', 'she', 'it', 'we', 'they',
            'my', 'your', 'his', 'her', 'its', 'our', 'their', 'me', 'him', 'them', 'us',
            'is', 'am', 'can', 'get', 'got', 'go', 'went', 'come', 'came', 'see', 'saw',
            'know', 'knew', 'think', 'thought', 'say', 'said', 'tell', 'told', 'ask',
            'asked', 'give', 'gave', 'take', 'took', 'make', 'made', 'use', 'used',
            'find', 'found', 'work', 'worked', 'call', 'called', 'try', 'tried',
            'need', 'want', 'like', 'look', 'looked', 'way', 'time', 'day', 'year',
            'new', 'first', 'last', 'long', 'great', 'little', 'own', 'other', 'old',
            'right', 'big', 'high', 'different', 'small', 'large', 'next', 'early',
            'young', 'important', 'few', 'public', 'bad', 'same', 'able'
        ];
        
        $filtered_words = array_diff($words, $stop_words);
        
        // Filter single words by length and add to keywords
        foreach ($filtered_words as $word) {
            if (strlen($word) >= 3 && strlen($word) <= 20 && !is_numeric($word)) {
                $keywords[] = $word;
            }
        }
        
        // Extract 2-word phrases
        $sentences = preg_split('/[.!?]+/', $content);
        foreach ($sentences as $sentence) {
            $sentence_words = str_word_count(strtolower($sentence), 1);
            for ($i = 0; $i < count($sentence_words) - 1; $i++) {
                $word1 = $sentence_words[$i];
                $word2 = $sentence_words[$i + 1];
                
                // Skip if either word is a stop word or too short
                if (in_array($word1, $stop_words) || in_array($word2, $stop_words)) {
                    continue;
                }
                if (strlen($word1) < 3 || strlen($word2) < 3) {
                    continue;
                }
                
                $phrase = $word1 . ' ' . $word2;
                if (strlen($phrase) <= 40) {
                    $keywords[] = $phrase;
                }
            }
        }
        
        // Extract 3-word phrases (more selective)
        foreach ($sentences as $sentence) {
            $sentence_words = str_word_count(strtolower($sentence), 1);
            for ($i = 0; $i < count($sentence_words) - 2; $i++) {
                $word1 = $sentence_words[$i];
                $word2 = $sentence_words[$i + 1];
                $word3 = $sentence_words[$i + 2];
                
                // More strict filtering for 3-word phrases
                if (in_array($word1, $stop_words) || in_array($word2, $stop_words) || in_array($word3, $stop_words)) {
                    continue;
                }
                if (strlen($word1) < 3 || strlen($word2) < 3 || strlen($word3) < 3) {
                    continue;
                }
                
                $phrase = $word1 . ' ' . $word2 . ' ' . $word3;
                if (strlen($phrase) <= 60) {
                    $keywords[] = $phrase;
                }
            }
        }
        
        // Remove duplicates and limit results
        $keywords = array_unique($keywords);
        
        // Sort by length (longer phrases first, then alphabetically)
        usort($keywords, function($a, $b) {
            $word_count_a = str_word_count($a);
            $word_count_b = str_word_count($b);
            
            if ($word_count_a != $word_count_b) {
                return $word_count_b - $word_count_a; // Longer phrases first
            }
            
            return strcmp($a, $b); // Alphabetical for same length
        });
        
        return array_slice($keywords, 0, 100); // Increased limit for better variety
    }

    public function save_trend($keyword, $trend_score, $search_volume = 0, $ai_analysis = '') {
        global $wpdb;
        $table = $wpdb->prefix . 'vrsc_trends';

        return $wpdb->insert(
            $table,
            [
                'keyword' => sanitize_text_field($keyword),
                'trend_score' => floatval($trend_score),
                'search_volume' => intval($search_volume),
                'ai_analysis' => sanitize_textarea_field($ai_analysis),
                'source' => 'internal'
            ],
            ['%s', '%f', '%d', '%s', '%s']
        );
    }

    public function get_trend_by_keyword($keyword) {
        global $wpdb;
        $table = $wpdb->prefix . 'vrsc_trends';

        $result = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE keyword = %s ORDER BY created_at DESC LIMIT 1",
            $keyword
        ));

        return $result ? new Trend($result) : null;
    }
}