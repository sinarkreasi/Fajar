/**
 * Xendit Payment Form Handler
 *
 * @package ViraStore_Xendit
 * @since 1.0.0
 */

(function($) {
    'use strict';

    // Xendit Payment Handler
    var ViraStoreXendit = {
        /**
         * Initialize the Xendit payment form
         */
        init: function() {
            // Detect if we're on checkout page or separate payment form
            this.isCheckoutPage = $('#vrstore-main-checkout-form').length > 0;
            
            if (this.isCheckoutPage) {
                // Initialize for ViraStore checkout form
                this.initCheckoutForm();
            } else {
                // Initialize for separate payment form (legacy)
                this.initPaymentForm();
            }
        },

        /**
         * Initialize for ViraStore checkout form
         */
        initCheckoutForm: function() {
            // Initialize variables for checkout form
            this.checkoutForm = $('#vrstore-main-checkout-form');
            this.paymentMethodSelect = $('#vrstore_payment_method');
            this.xenditContainer = $('.vrstore-xendit-form-container');
            this.paymentChannel = $('#xendit_payment_channel');
            this.methodFields = $('.vrstore-xendit-method-fields');
            
            // Bind checkout form events
            this.bindCheckoutEvents();
            
            // Initialize input formatting
            this.initInputFormatting();
            
            // Auto-hide Xendit fields on page load if not selected
            if (this.paymentMethodSelect.val() !== 'xendit') {
                this.xenditContainer.hide();
            } else {
                // If Xendit is already selected, show the container
                this.xenditContainer.show();
            }
        },

        /**
         * Initialize for separate payment form (legacy)
         */
        initPaymentForm: function() {
            // Initialize variables for legacy payment form
            this.form = $('#virastore-payment-form');
            this.submitBtn = this.form.find('#virastore-submit-payment');
            this.paymentMethodRadios = this.form.find('input[name="payment_method"]');
            this.xenditContainer = $('#xendit-payment-container');
            this.xenditMethods = $('#xendit-payment-methods');
            
            // Bind legacy form events
            this.bindEvents();
            
            // Initialize Xendit if it's selected
            this.initializeXenditIfSelected();
        },

        /**
         * Bind events for checkout form
         */
        bindCheckoutEvents: function() {
            var self = this;
            
            // Handle payment method selection change (checkout form)
            this.paymentMethodSelect.on('change', function() {
                var selectedMethod = $(this).val();
                if (selectedMethod === 'xendit') {
                    self.xenditContainer.show();
                } else {
                    self.xenditContainer.hide();
                    // Reset fields when switching away
                    self.methodFields.hide();
                    self.paymentChannel.val('');
                }
            });
            
            // Handle payment channel change (Xendit sub-methods)
            this.paymentChannel.on('change', function() {
                var channel = $(this).val();
                self.handlePaymentChannelChange(channel);
            });
        },

        /**
         * Handle payment channel change
         * 
         * @param {string} channel The selected payment channel
         */
        handlePaymentChannelChange: function(channel) {
            // Hide all method fields first
            this.methodFields.hide();
            
            // Show relevant fields based on selection
            if (channel === 'credit_card') {
                $('#vrstore-xendit-credit_card-fields').show();
            } else if (channel === 'bank_transfer') {
                $('#vrstore-xendit-bank_transfer-fields').show();
            } else if (channel === 'e_wallet') {
                $('#vrstore-xendit-e_wallet-fields').show();
            } else if (channel === 'retail') {
                $('#vrstore-xendit-retail-fields').show();
            }
        },

        /**
         * Initialize input formatting for credit card and phone inputs
         */
        initInputFormatting: function() {
            var self = this;
            
            // Format card number input
            $(document).on('input', '#xendit_card_number', function() {
                var value = $(this).val().replace(/\s+/g, '').replace(/[^0-9]/gi, '');
                var formattedValue = value.match(/.{1,4}/g);
                if (formattedValue) {
                    formattedValue = formattedValue.join(' ');
                } else {
                    formattedValue = value;
                }
                $(this).val(formattedValue);
            });
            
            // Format expiry date input (MM/YY)
            $(document).on('input', '#xendit_card_expiry', function() {
                var value = $(this).val().replace(/\D/g, '');
                if (value.length >= 2) {
                    value = value.substring(0, 2) + '/' + value.substring(2, 4);
                }
                $(this).val(value);
            });
            
            // Only allow numbers for CVC
            $(document).on('input', '#xendit_card_cvc', function() {
                $(this).val($(this).val().replace(/\D/g, ''));
            });
            
            // Only allow numbers for phone number
            $(document).on('input', '#xendit_phone_number', function() {
                $(this).val($(this).val().replace(/\D/g, ''));
            });
        },

        /**
         * Bind events for legacy payment form
         */
        bindEvents: function() {
            var self = this;
            
            // Payment method selection
            this.paymentMethodRadios.on('change', function() {
                self.handlePaymentMethodChange($(this).val());
            });
            
            // Form submission
            this.form.on('submit', function(e) {
                if (self.isXenditSelected()) {
                    e.preventDefault();
                    self.processXenditPayment();
                }
            });
            
            // Xendit payment method selection
            $(document).on('change', 'input[name="xendit_payment_channel"]', function() {
                self.handleXenditMethodChange($(this).val());
            });
        },

        /**
         * Initialize Xendit if it's selected as payment method (legacy)
         */
        initializeXenditIfSelected: function() {
            if (this.isXenditSelected()) {
                this.loadXenditMethods();
            }
        },

        /**
         * Check if Xendit is selected as payment method (legacy)
         * 
         * @return {boolean} True if Xendit is selected
         */
        isXenditSelected: function() {
            return this.paymentMethodRadios.filter(':checked').val() === 'xendit';
        },

        /**
         * Handle payment method change (legacy)
         * 
         * @param {string} method The selected payment method
         */
        handlePaymentMethodChange: function(method) {
            if (method === 'xendit') {
                this.xenditContainer.show();
                this.loadXenditMethods();
            } else {
                this.xenditContainer.hide();
            }
        },

        /**
         * Load available Xendit payment methods (legacy)
         */
        loadXenditMethods: function() {
            var self = this;
            
            // Show loading
            this.xenditMethods.html('<p>' + (virastore_xendit.loading_text || 'Loading...') + '</p>');
            
            // Get payment methods via AJAX
            $.ajax({
                url: virastore_xendit.ajax_url,
                type: 'POST',
                data: {
                    action: 'virastore_xendit_get_payment_methods',
                    nonce: virastore_xendit.nonce
                },
                success: function(response) {
                    if (response.success) {
                        self.xenditMethods.html(response.data.html);
                    } else {
                        self.xenditMethods.html('<p class="error">' + response.data.message + '</p>');
                    }
                },
                error: function() {
                    self.xenditMethods.html('<p class="error">' + (virastore_xendit.error_text || 'An error occurred') + '</p>');
                }
            });
        },

        /**
         * Handle Xendit payment method change (legacy)
         * 
         * @param {string} method The selected Xendit payment method
         */
        handleXenditMethodChange: function(method) {
            // Hide all method-specific fields
            $('.xendit-method-fields').hide();
            
            // Show the selected method fields
            $('#xendit-' + method + '-fields').show();
        },

        /**
         * Process Xendit payment (legacy)
         */
        processXenditPayment: function() {
            var self = this;
            var formData = this.form.serialize();
            
            // Disable submit button
            this.submitBtn.prop('disabled', true).text(virastore_xendit.processing_text || 'Processing...');
            
            // Process payment via AJAX
            $.ajax({
                url: virastore_xendit.ajax_url,
                type: 'POST',
                data: formData + '&action=virastore_xendit_process_payment&nonce=' + virastore_xendit.nonce,
                success: function(response) {
                    if (response.success) {
                        // Redirect to payment page if needed
                        if (response.data.redirect_url) {
                            window.location.href = response.data.redirect_url;
                        } else {
                            // Show success message and redirect to thank you page
                            window.location.href = response.data.return_url;
                        }
                    } else {
                        // Show error message
                        self.showError(response.data.message);
                        self.submitBtn.prop('disabled', false).text(virastore_xendit.submit_text || 'Pay Now');
                    }
                },
                error: function() {
                    self.showError(virastore_xendit.error_text || 'An error occurred');
                    self.submitBtn.prop('disabled', false).text(virastore_xendit.submit_text || 'Pay Now');
                }
            });
        },

        /**
         * Show error message
         * 
         * @param {string} message The error message
         */
        showError: function(message) {
            var errorDiv = $('#xendit-error-message');
            var form = this.isCheckoutPage ? this.checkoutForm : this.form;
            
            if (errorDiv.length === 0) {
                errorDiv = $('<div id="xendit-error-message" class="virastore-error vrstore-notice vrstore-notice-error" style="margin-bottom: 15px;"></div>');
                form.prepend(errorDiv);
            }
            
            errorDiv.html(message).show();
            
            // Scroll to error message
            $('html, body').animate({
                scrollTop: errorDiv.offset().top - 100
            }, 500);
        }
    };

    // Initialize on document ready
    $(document).ready(function() {
        ViraStoreXendit.init();
    });

})(jQuery);