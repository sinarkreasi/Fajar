/**
 * ViraStore Xendit Admin Scripts
 *
 * @package ViraStore_Xendit
 */

(function($) {
    'use strict';

    // Initialize when document is ready
    $(document).ready(function() {
        // Toggle payment method settings
        $('.virastore-xendit-payment-method-toggle').on('change', function() {
            var methodId = $(this).data('method');
            var $settings = $('#virastore-xendit-' + methodId + '-settings');
            
            if ($(this).is(':checked')) {
                $settings.show();
            } else {
                $settings.hide();
            }
        });

        // Initialize toggles on page load
        $('.virastore-xendit-payment-method-toggle').each(function() {
            var methodId = $(this).data('method');
            var $settings = $('#virastore-xendit-' + methodId + '-settings');
            
            if ($(this).is(':checked')) {
                $settings.show();
            } else {
                $settings.hide();
            }
        });

        // API key toggle
        $('#virastore_xendit_test_mode').on('change', function() {
            if ($(this).is(':checked')) {
                $('.virastore-xendit-live-key').hide();
                $('.virastore-xendit-test-key').show();
            } else {
                $('.virastore-xendit-live-key').show();
                $('.virastore-xendit-test-key').hide();
            }
        }).trigger('change');
    });

})(jQuery);