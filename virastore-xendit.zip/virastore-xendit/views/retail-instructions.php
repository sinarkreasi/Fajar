<?php
/**
 * Retail Payment Instructions Template
 *
 * @package ViraStore_Xendit
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Get order ID
$order_id = isset( $_GET['order_id'] ) ? intval( $_GET['order_id'] ) : 0;

if ( ! $order_id ) {
	return;
}

// Get retail details
$retail_outlet = get_post_meta( $order_id, '_xendit_retail_outlet', true );
$payment_code = get_post_meta( $order_id, '_xendit_payment_code', true );
$expiry = get_post_meta( $order_id, '_xendit_expiry', true );
$total = get_post_meta( $order_id, '_total', true );

// Format expiry date
$expiry_date = new DateTime( $expiry );
$expiry_formatted = $expiry_date->format( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) );

// Get retail outlet name
$retail_names = array(
	'ALFAMART'  => 'Alfamart',
	'INDOMARET' => 'Indomaret',
	'7ELEVEN'   => '7-Eleven',
	'LAWSON'    => 'Lawson',
);

$retail_name = isset( $retail_names[ strtoupper( $retail_outlet ) ] ) ? $retail_names[ strtoupper( $retail_outlet ) ] : strtoupper( $retail_outlet );

// Get retail logo
$retail_logo = VIRASTORE_XENDIT_PLUGIN_URL . 'assets/images/retail/' . strtolower( $retail_outlet ) . '.svg';
?>

<div class="virastore-payment-instructions xendit-retail-instructions">
	<h2><?php esc_html_e( 'Retail Payment Instructions', 'virastore-xendit' ); ?></h2>
	
	<div class="xendit-retail-details">
		<div class="xendit-retail-logo">
			<img src="<?php echo esc_url( $retail_logo ); ?>" alt="<?php echo esc_attr( $retail_name ); ?>">
		</div>
		
		<div class="xendit-retail-info">
			<h3><?php echo esc_html( $retail_name ); ?></h3>
			
			<div class="xendit-payment-code">
				<strong><?php esc_html_e( 'Payment Code:', 'virastore-xendit' ); ?></strong>
				<span><?php echo esc_html( $payment_code ); ?></span>
			</div>
			
			<div class="xendit-amount">
				<strong><?php esc_html_e( 'Amount:', 'virastore-xendit' ); ?></strong>
				<span><?php echo esc_html( number_format( $total, 0, ',', '.' ) ); ?></span>
			</div>
			
			<div class="xendit-expiry">
				<strong><?php esc_html_e( 'Expiry Date:', 'virastore-xendit' ); ?></strong>
				<span><?php echo esc_html( $expiry_formatted ); ?></span>
			</div>
		</div>
	</div>
	
	<div class="xendit-instructions-steps">
		<h3><?php esc_html_e( 'How to Pay', 'virastore-xendit' ); ?></h3>
		
		<?php if ( strtoupper( $retail_outlet ) === 'ALFAMART' ) : ?>
			<ol>
				<li><?php esc_html_e( 'Visit any Alfamart, Alfamidi, or Dan+Dan store near you', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Tell the cashier that you want to make a payment for Xendit', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Provide the cashier with your Payment Code', 'virastore-xendit' ); ?> (<?php echo esc_html( $payment_code ); ?>)</li>
				<li><?php esc_html_e( 'The cashier will confirm the payment details', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Make the payment of', 'virastore-xendit' ); ?> <?php echo esc_html( number_format( $total, 0, ',', '.' ) ); ?></li>
				<li><?php esc_html_e( 'Keep your payment receipt as proof of payment', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Your order will be processed after the payment is confirmed', 'virastore-xendit' ); ?></li>
			</ol>
		<?php elseif ( strtoupper( $retail_outlet ) === 'INDOMARET' ) : ?>
			<ol>
				<li><?php esc_html_e( 'Visit any Indomaret store near you', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Tell the cashier that you want to make a payment for Xendit', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Provide the cashier with your Payment Code', 'virastore-xendit' ); ?> (<?php echo esc_html( $payment_code ); ?>)</li>
				<li><?php esc_html_e( 'The cashier will confirm the payment details', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Make the payment of', 'virastore-xendit' ); ?> <?php echo esc_html( number_format( $total, 0, ',', '.' ) ); ?></li>
				<li><?php esc_html_e( 'Keep your payment receipt as proof of payment', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Your order will be processed after the payment is confirmed', 'virastore-xendit' ); ?></li>
			</ol>
		<?php else : ?>
			<ol>
				<li><?php esc_html_e( 'Visit any', 'virastore-xendit' ); ?> <?php echo esc_html( $retail_name ); ?> <?php esc_html_e( 'store near you', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Tell the cashier that you want to make a payment for Xendit', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Provide the cashier with your Payment Code', 'virastore-xendit' ); ?> (<?php echo esc_html( $payment_code ); ?>)</li>
				<li><?php esc_html_e( 'The cashier will confirm the payment details', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Make the payment of', 'virastore-xendit' ); ?> <?php echo esc_html( number_format( $total, 0, ',', '.' ) ); ?></li>
				<li><?php esc_html_e( 'Keep your payment receipt as proof of payment', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Your order will be processed after the payment is confirmed', 'virastore-xendit' ); ?></li>
			</ol>
		<?php endif; ?>
	</div>
	
	<div class="xendit-important-notes">
		<h3><?php esc_html_e( 'Important Notes', 'virastore-xendit' ); ?></h3>
		<ul>
			<li><?php esc_html_e( 'Please make the payment before the expiry date.', 'virastore-xendit' ); ?></li>
			<li><?php esc_html_e( 'A small convenience fee may be charged by the retail outlet.', 'virastore-xendit' ); ?></li>
			<li><?php esc_html_e( 'Your order will be processed after the payment is confirmed.', 'virastore-xendit' ); ?></li>
			<li><?php esc_html_e( 'If you have any questions, please contact our customer support.', 'virastore-xendit' ); ?></li>
		</ul>
	</div>
</div>