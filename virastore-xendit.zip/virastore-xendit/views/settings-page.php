<?php
/**
 * Xendit Settings Page
 *
 * @package ViraStore_Xendit
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Get current settings.
$test_mode = get_option( 'virastore_xendit_test_mode', 'yes' );
$test_api_key = get_option( 'virastore_xendit_test_api_key', '' );
$test_secret_key = get_option( 'virastore_xendit_test_secret_key', '' );
$live_api_key = get_option( 'virastore_xendit_live_api_key', '' );
$live_secret_key = get_option( 'virastore_xendit_live_secret_key', '' );
$payment_methods = get_option( 'virastore_xendit_payment_methods', array() );
?>

<div class="wrap">
	<h1><?php esc_html_e( 'Xendit Settings', 'virastore-xendit' ); ?></h1>

	<form method="post" action="options.php">
		<?php settings_fields( 'virastore_xendit_settings' ); ?>

		<table class="form-table">
			<tbody>
				<tr>
					<th scope="row">
						<label for="virastore_xendit_test_mode"><?php esc_html_e( 'Test Mode', 'virastore-xendit' ); ?></label>
					</th>
					<td>
						<input type="checkbox" id="virastore_xendit_test_mode" name="virastore_xendit_test_mode" value="yes" <?php checked( $test_mode, 'yes' ); ?> />
						<p class="description"><?php esc_html_e( 'Enable test mode to use Xendit sandbox environment.', 'virastore-xendit' ); ?></p>
					</td>
				</tr>

				<tr>
					<th scope="row" colspan="2">
						<h3><?php esc_html_e( 'Test Credentials', 'virastore-xendit' ); ?></h3>
					</th>
				</tr>

				<tr>
					<th scope="row">
						<label for="virastore_xendit_test_api_key"><?php esc_html_e( 'Test API Key', 'virastore-xendit' ); ?></label>
					</th>
					<td>
						<input type="text" id="virastore_xendit_test_api_key" name="virastore_xendit_test_api_key" value="<?php echo esc_attr( $test_api_key ); ?>" class="regular-text" />
						<p class="description"><?php esc_html_e( 'Enter your Xendit test API key.', 'virastore-xendit' ); ?></p>
					</td>
				</tr>

				<tr>
					<th scope="row">
						<label for="virastore_xendit_test_secret_key"><?php esc_html_e( 'Test Secret Key', 'virastore-xendit' ); ?></label>
					</th>
					<td>
						<input type="password" id="virastore_xendit_test_secret_key" name="virastore_xendit_test_secret_key" value="<?php echo esc_attr( $test_secret_key ); ?>" class="regular-text" />
						<p class="description"><?php esc_html_e( 'Enter your Xendit test secret key.', 'virastore-xendit' ); ?></p>
					</td>
				</tr>

				<tr>
					<th scope="row" colspan="2">
						<h3><?php esc_html_e( 'Live Credentials', 'virastore-xendit' ); ?></h3>
					</th>
				</tr>

				<tr>
					<th scope="row">
						<label for="virastore_xendit_live_api_key"><?php esc_html_e( 'Live API Key', 'virastore-xendit' ); ?></label>
					</th>
					<td>
						<input type="text" id="virastore_xendit_live_api_key" name="virastore_xendit_live_api_key" value="<?php echo esc_attr( $live_api_key ); ?>" class="regular-text" />
						<p class="description"><?php esc_html_e( 'Enter your Xendit live API key.', 'virastore-xendit' ); ?></p>
					</td>
				</tr>

				<tr>
					<th scope="row">
						<label for="virastore_xendit_live_secret_key"><?php esc_html_e( 'Live Secret Key', 'virastore-xendit' ); ?></label>
					</th>
					<td>
						<input type="password" id="virastore_xendit_live_secret_key" name="virastore_xendit_live_secret_key" value="<?php echo esc_attr( $live_secret_key ); ?>" class="regular-text" />
						<p class="description"><?php esc_html_e( 'Enter your Xendit live secret key.', 'virastore-xendit' ); ?></p>
					</td>
				</tr>

				<tr>
					<th scope="row" colspan="2">
						<h3><?php esc_html_e( 'Payment Methods', 'virastore-xendit' ); ?></h3>
					</th>
				</tr>

				<tr>
					<th scope="row">
						<label><?php esc_html_e( 'Enabled Payment Methods', 'virastore-xendit' ); ?></label>
					</th>
					<td>
						<fieldset>
							<legend class="screen-reader-text"><?php esc_html_e( 'Enabled Payment Methods', 'virastore-xendit' ); ?></legend>

							<label for="virastore_xendit_payment_methods_credit_card">
								<input type="checkbox" id="virastore_xendit_payment_methods_credit_card" name="virastore_xendit_payment_methods[credit_card]" value="on" <?php checked( isset( $payment_methods['credit_card'] ) ? $payment_methods['credit_card'] : '', 'on' ); ?> />
								<?php esc_html_e( 'Credit Card', 'virastore-xendit' ); ?>
							</label><br>

							<label for="virastore_xendit_payment_methods_bank_transfer">
								<input type="checkbox" id="virastore_xendit_payment_methods_bank_transfer" name="virastore_xendit_payment_methods[bank_transfer]" value="on" <?php checked( isset( $payment_methods['bank_transfer'] ) ? $payment_methods['bank_transfer'] : '', 'on' ); ?> />
								<?php esc_html_e( 'Bank Transfer', 'virastore-xendit' ); ?>
							</label><br>

							<label for="virastore_xendit_payment_methods_e_wallet">
								<input type="checkbox" id="virastore_xendit_payment_methods_e_wallet" name="virastore_xendit_payment_methods[e_wallet]" value="on" <?php checked( isset( $payment_methods['e_wallet'] ) ? $payment_methods['e_wallet'] : '', 'on' ); ?> />
								<?php esc_html_e( 'E-Wallet', 'virastore-xendit' ); ?>
							</label><br>

							<label for="virastore_xendit_payment_methods_retail">
								<input type="checkbox" id="virastore_xendit_payment_methods_retail" name="virastore_xendit_payment_methods[retail]" value="on" <?php checked( isset( $payment_methods['retail'] ) ? $payment_methods['retail'] : '', 'on' ); ?> />
								<?php esc_html_e( 'Retail Outlet', 'virastore-xendit' ); ?>
							</label><br>
						</fieldset>
						<p class="description"><?php esc_html_e( 'Select the payment methods you want to enable for Xendit.', 'virastore-xendit' ); ?></p>
					</td>
				</tr>

				<tr>
					<th scope="row" colspan="2">
						<h3><?php esc_html_e( 'Webhook Settings', 'virastore-xendit' ); ?></h3>
					</th>
				</tr>

				<tr>
					<th scope="row">
						<label><?php esc_html_e( 'Webhook URL', 'virastore-xendit' ); ?></label>
					</th>
					<td>
						<code><?php echo esc_url( add_query_arg( 'virastore_xendit_webhook', '1', site_url( '/' ) ) ); ?></code>
						<p class="description"><?php esc_html_e( 'Set this URL in your Xendit dashboard to receive payment notifications.', 'virastore-xendit' ); ?></p>
					</td>
				</tr>
			</tbody>
		</table>

		<?php submit_button(); ?>
	</form>

	<div class="xendit-instructions">
		<h3><?php esc_html_e( 'Setup Instructions', 'virastore-xendit' ); ?></h3>
		<ol>
			<li><?php esc_html_e( 'Sign up for a Xendit account at', 'virastore-xendit' ); ?> <a href="https://dashboard.xendit.co/register" target="_blank">https://dashboard.xendit.co/register</a>.</li>
			<li><?php esc_html_e( 'Get your API keys from the Xendit dashboard.', 'virastore-xendit' ); ?></li>
			<li><?php esc_html_e( 'Enter your API keys in the settings above.', 'virastore-xendit' ); ?></li>
			<li><?php esc_html_e( 'Set up the webhook URL in your Xendit dashboard to receive payment notifications.', 'virastore-xendit' ); ?></li>
			<li><?php esc_html_e( 'Enable the payment methods you want to offer to your customers.', 'virastore-xendit' ); ?></li>
		</ol>
	</div>
</div>