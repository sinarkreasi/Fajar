<?php
/**
 * Xendit Payment Form Template
 *
 * @package ViraStore_Xendit
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Get available payment methods.
$payment_methods = get_option( 'virastore_xendit_payment_methods', array() );
?>

<div id="xendit-payment-container" class="xendit-payment-container" style="<?php echo $payment_method !== 'xendit' ? 'display: none;' : ''; ?>">
	<div id="xendit-payment-methods" class="xendit-payment-methods">
		<?php if ( ! empty( $payment_methods ) ) : ?>
			<h4><?php esc_html_e( 'Select Payment Method', 'virastore-xendit' ); ?></h4>
			<ul>
				<?php if ( isset( $payment_methods['credit_card'] ) && $payment_methods['credit_card'] === 'on' ) : ?>
					<li>
						<label class="xendit-payment-method-label">
							<input type="radio" name="xendit_payment_channel" value="credit_card" checked>
							<span class="payment-method-name"><?php esc_html_e( 'Credit Card', 'virastore-xendit' ); ?></span>
					<img src="<?php echo esc_url( VIRASTORE_XENDIT_PLUGIN_URL . 'assets/images/credit-card.svg' ); ?>" alt="Credit Card">
						</label>
					</li>
				<?php endif; ?>
				
				<?php if ( isset( $payment_methods['bank_transfer'] ) && $payment_methods['bank_transfer'] === 'on' ) : ?>
					<li>
						<label class="xendit-payment-method-label">
							<input type="radio" name="xendit_payment_channel" value="bank_transfer">
							<span class="payment-method-name"><?php esc_html_e( 'Bank Transfer', 'virastore-xendit' ); ?></span>
					<img src="<?php echo esc_url( VIRASTORE_XENDIT_PLUGIN_URL . 'assets/images/bank-transfer.svg' ); ?>" alt="Bank Transfer">
						</label>
					</li>
				<?php endif; ?>
				
				<?php if ( isset( $payment_methods['e_wallet'] ) && $payment_methods['e_wallet'] === 'on' ) : ?>
					<li>
						<label class="xendit-payment-method-label">
							<input type="radio" name="xendit_payment_channel" value="e_wallet">
							<span class="payment-method-name"><?php esc_html_e( 'E-Wallet', 'virastore-xendit' ); ?></span>
					<img src="<?php echo esc_url( VIRASTORE_XENDIT_PLUGIN_URL . 'assets/images/e-wallet.svg' ); ?>" alt="E-Wallet">
						</label>
					</li>
				<?php endif; ?>
				
				<?php if ( isset( $payment_methods['retail'] ) && $payment_methods['retail'] === 'on' ) : ?>
					<li>
						<label class="xendit-payment-method-label">
							<input type="radio" name="xendit_payment_channel" value="retail">
							<span class="payment-method-name"><?php esc_html_e( 'Retail Outlet', 'virastore-xendit' ); ?></span>
					<img src="<?php echo esc_url( VIRASTORE_XENDIT_PLUGIN_URL . 'assets/images/retail.svg' ); ?>" alt="Retail Outlet">
						</label>
					</li>
				<?php endif; ?>
			</ul>
		<?php else : ?>
			<p class="xendit-error"><?php esc_html_e( 'No payment methods are currently available. Please try again later or contact the site administrator.', 'virastore-xendit' ); ?></p>
		<?php endif; ?>
	</div>
	
	<!-- Credit Card Fields -->
	<div id="xendit-credit_card-fields" class="xendit-method-fields">
		<div class="xendit-card-fields">
			<div class="xendit-form-row card-number-field">
				<label for="xendit-card-number"><?php esc_html_e( 'Card Number', 'virastore-xendit' ); ?></label>
				<input type="text" id="xendit-card-number" name="xendit_card_number" placeholder="1234 5678 9012 3456" autocomplete="cc-number">
			</div>
			
			<div class="xendit-form-row card-expiry-field">
				<label for="xendit-card-expiry"><?php esc_html_e( 'Expiry Date (MM/YY)', 'virastore-xendit' ); ?></label>
				<input type="text" id="xendit-card-expiry" name="xendit_card_expiry" placeholder="MM/YY" autocomplete="cc-exp">
			</div>
			
			<div class="xendit-form-row card-cvc-field">
				<label for="xendit-card-cvc"><?php esc_html_e( 'CVC', 'virastore-xendit' ); ?></label>
				<input type="text" id="xendit-card-cvc" name="xendit_card_cvc" placeholder="123" autocomplete="cc-csc">
			</div>
		</div>
	</div>
	
	<!-- Bank Transfer Fields -->
	<div id="xendit-bank_transfer-fields" class="xendit-method-fields" style="display: none;">
		<div class="xendit-form-row">
			<label><?php esc_html_e( 'Select Bank', 'virastore-xendit' ); ?></label>
			<div class="xendit-bank-list">
				<div class="xendit-bank-option">
					<input type="radio" name="xendit_bank" value="bca" id="xendit-bank-bca" checked>
					<label for="xendit-bank-bca">
						<img src="<?php echo esc_url( VIRASTORE_XENDIT_PLUGIN_URL . 'assets/images/banks/bca.svg' ); ?>" alt="BCA">
						<div>BCA</div>
					</label>
				</div>
				
				<div class="xendit-bank-option">
					<input type="radio" name="xendit_bank" value="bni" id="xendit-bank-bni">
					<label for="xendit-bank-bni">
						<img src="<?php echo esc_url( VIRASTORE_XENDIT_PLUGIN_URL . 'assets/images/banks/bni.svg' ); ?>" alt="BNI">
						<div>BNI</div>
					</label>
				</div>
				
				<div class="xendit-bank-option">
					<input type="radio" name="xendit_bank" value="bri" id="xendit-bank-bri">
					<label for="xendit-bank-bri">
						<img src="<?php echo esc_url( VIRASTORE_XENDIT_PLUGIN_URL . 'assets/images/banks/bri.svg' ); ?>" alt="BRI">
						<div>BRI</div>
					</label>
				</div>
				
				<div class="xendit-bank-option">
					<input type="radio" name="xendit_bank" value="mandiri" id="xendit-bank-mandiri">
					<label for="xendit-bank-mandiri">
						<img src="<?php echo esc_url( VIRASTORE_XENDIT_PLUGIN_URL . 'assets/images/banks/mandiri.svg' ); ?>" alt="Mandiri">
						<div>Mandiri</div>
					</label>
				</div>
				
				<div class="xendit-bank-option">
					<input type="radio" name="xendit_bank" value="permata" id="xendit-bank-permata">
					<label for="xendit-bank-permata">
						<img src="<?php echo esc_url( VIRASTORE_XENDIT_PLUGIN_URL . 'assets/images/banks/permata.svg' ); ?>" alt="Permata">
						<div>Permata</div>
					</label>
				</div>
			</div>
		</div>
	</div>
	
	<!-- E-Wallet Fields -->
	<div id="xendit-e_wallet-fields" class="xendit-method-fields" style="display: none;">
		<div class="xendit-form-row">
			<label><?php esc_html_e( 'Select E-Wallet', 'virastore-xendit' ); ?></label>
			<div class="xendit-ewallet-list">
				<div class="xendit-ewallet-option">
					<input type="radio" name="xendit_ewallet" value="ovo" id="xendit-ewallet-ovo" checked>
					<label for="xendit-ewallet-ovo">
						<img src="<?php echo esc_url( VIRASTORE_XENDIT_PLUGIN_URL . 'assets/images/ewallets/ovo.svg' ); ?>" alt="OVO">
						<div>OVO</div>
					</label>
				</div>
				
				<div class="xendit-ewallet-option">
					<input type="radio" name="xendit_ewallet" value="dana" id="xendit-ewallet-dana">
					<label for="xendit-ewallet-dana">
						<img src="<?php echo esc_url( VIRASTORE_XENDIT_PLUGIN_URL . 'assets/images/ewallets/dana.svg' ); ?>" alt="DANA">
						<div>DANA</div>
					</label>
				</div>
				
				<div class="xendit-ewallet-option">
					<input type="radio" name="xendit_ewallet" value="linkaja" id="xendit-ewallet-linkaja">
					<label for="xendit-ewallet-linkaja">
						<img src="<?php echo esc_url( VIRASTORE_XENDIT_PLUGIN_URL . 'assets/images/ewallets/linkaja.svg' ); ?>" alt="LinkAja">
						<div>LinkAja</div>
					</label>
				</div>
				
				<div class="xendit-ewallet-option">
					<input type="radio" name="xendit_ewallet" value="shopeepay" id="xendit-ewallet-shopeepay">
					<label for="xendit-ewallet-shopeepay">
						<img src="<?php echo esc_url( VIRASTORE_XENDIT_PLUGIN_URL . 'assets/images/ewallets/shopeepay.svg' ); ?>" alt="ShopeePay">
						<div>ShopeePay</div>
					</label>
				</div>
			</div>
		</div>
		
		<div class="xendit-form-row">
			<label for="xendit-phone-number"><?php esc_html_e( 'Phone Number', 'virastore-xendit' ); ?></label>
			<input type="text" id="xendit-phone-number" name="xendit_phone_number" placeholder="08123456789">
		</div>
	</div>
	
	<!-- Retail Outlet Fields -->
	<div id="xendit-retail-fields" class="xendit-method-fields" style="display: none;">
		<div class="xendit-form-row">
			<label><?php esc_html_e( 'Select Retail Outlet', 'virastore-xendit' ); ?></label>
			<div class="xendit-retail-list">
				<div class="xendit-retail-option">
					<input type="radio" name="xendit_retail" value="alfamart" id="xendit-retail-alfamart" checked>
					<label for="xendit-retail-alfamart">
						<img src="<?php echo esc_url( VIRASTORE_XENDIT_PLUGIN_URL . 'assets/images/retail/alfamart.svg' ); ?>" alt="Alfamart">
						<div>Alfamart</div>
					</label>
				</div>
				
				<div class="xendit-retail-option">
					<input type="radio" name="xendit_retail" value="indomaret" id="xendit-retail-indomaret">
					<label for="xendit-retail-indomaret">
						<img src="<?php echo esc_url( VIRASTORE_XENDIT_PLUGIN_URL . 'assets/images/retail/indomaret.svg' ); ?>" alt="Indomaret">
						<div>Indomaret</div>
					</label>
				</div>
			</div>
		</div>
	</div>
	
	<input type="hidden" name="xendit_payment" value="1">
</div>