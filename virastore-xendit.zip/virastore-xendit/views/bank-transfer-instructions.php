<?php
/**
 * Bank Transfer Instructions Template
 *
 * @package ViraStore_Xendit
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Get order ID
$order_id = isset( $_GET['order_id'] ) ? intval( $_GET['order_id'] ) : 0;

if ( ! $order_id ) {
	return;
}

// Get bank details
$bank_code = get_post_meta( $order_id, '_xendit_bank_code', true );
$va_number = get_post_meta( $order_id, '_xendit_va_number', true );
$va_expiry = get_post_meta( $order_id, '_xendit_va_expiry', true );
$total = get_post_meta( $order_id, '_total', true );

// Format expiry date
$expiry_date = new DateTime( $va_expiry );
$expiry_formatted = $expiry_date->format( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) );

// Get bank name
$bank_names = array(
	'BCA'     => 'Bank Central Asia (BCA)',
	'BNI'     => 'Bank Negara Indonesia (BNI)',
	'BRI'     => 'Bank Rakyat Indonesia (BRI)',
	'MANDIRI' => 'Bank Mandiri',
	'PERMATA' => 'Bank Permata',
);

$bank_name = isset( $bank_names[ strtoupper( $bank_code ) ] ) ? $bank_names[ strtoupper( $bank_code ) ] : strtoupper( $bank_code );

// Get bank logo
$bank_logo = VIRASTORE_XENDIT_PLUGIN_URL . 'assets/images/banks/' . strtolower( $bank_code ) . '.svg';
?>

<div class="virastore-payment-instructions xendit-bank-transfer-instructions">
	<h2><?php esc_html_e( 'Bank Transfer Payment Instructions', 'virastore-xendit' ); ?></h2>
	
	<div class="xendit-bank-details">
		<div class="xendit-bank-logo">
			<img src="<?php echo esc_url( $bank_logo ); ?>" alt="<?php echo esc_attr( $bank_name ); ?>">
		</div>
		
		<div class="xendit-bank-info">
			<h3><?php echo esc_html( $bank_name ); ?></h3>
			
			<div class="xendit-va-number">
				<strong><?php esc_html_e( 'Virtual Account Number:', 'virastore-xendit' ); ?></strong>
				<span><?php echo esc_html( $va_number ); ?></span>
			</div>
			
			<div class="xendit-amount">
				<strong><?php esc_html_e( 'Amount:', 'virastore-xendit' ); ?></strong>
				<span><?php echo esc_html( number_format( $total, 0, ',', '.' ) ); ?></span>
			</div>
			
			<div class="xendit-expiry">
				<strong><?php esc_html_e( 'Expiry Date:', 'virastore-xendit' ); ?></strong>
				<span><?php echo esc_html( $expiry_formatted ); ?></span>
			</div>
		</div>
	</div>
	
	<div class="xendit-instructions-steps">
		<h3><?php esc_html_e( 'How to Pay', 'virastore-xendit' ); ?></h3>
		
		<?php if ( strtoupper( $bank_code ) === 'BCA' ) : ?>
			<h4><?php esc_html_e( 'ATM BCA', 'virastore-xendit' ); ?></h4>
			<ol>
				<li><?php esc_html_e( 'Insert your BCA card and enter your PIN', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Select "Other Transactions"', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Select "Transfer"', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Select "To BCA Virtual Account"', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Enter the Virtual Account Number', 'virastore-xendit' ); ?> (<?php echo esc_html( $va_number ); ?>)</li>
				<li><?php esc_html_e( 'The payment details will appear on the screen', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Confirm the payment details and proceed with the payment', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Your transaction is complete', 'virastore-xendit' ); ?></li>
			</ol>
			
			<h4><?php esc_html_e( 'Mobile Banking BCA', 'virastore-xendit' ); ?></h4>
			<ol>
				<li><?php esc_html_e( 'Log in to your BCA Mobile Banking app', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Select "Transfer"', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Select "BCA Virtual Account"', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Enter the Virtual Account Number', 'virastore-xendit' ); ?> (<?php echo esc_html( $va_number ); ?>)</li>
				<li><?php esc_html_e( 'The payment details will appear on the screen', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Confirm the payment details and proceed with the payment', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Enter your PIN', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Your transaction is complete', 'virastore-xendit' ); ?></li>
			</ol>
		<?php elseif ( strtoupper( $bank_code ) === 'BNI' ) : ?>
			<h4><?php esc_html_e( 'ATM BNI', 'virastore-xendit' ); ?></h4>
			<ol>
				<li><?php esc_html_e( 'Insert your BNI card and enter your PIN', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Select "Other Menu"', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Select "Transfer"', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Select "Virtual Account"', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Enter the Virtual Account Number', 'virastore-xendit' ); ?> (<?php echo esc_html( $va_number ); ?>)</li>
				<li><?php esc_html_e( 'The payment details will appear on the screen', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Confirm the payment details and proceed with the payment', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Your transaction is complete', 'virastore-xendit' ); ?></li>
			</ol>
			
			<h4><?php esc_html_e( 'Mobile Banking BNI', 'virastore-xendit' ); ?></h4>
			<ol>
				<li><?php esc_html_e( 'Log in to your BNI Mobile Banking app', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Select "Transfer"', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Select "Virtual Account"', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Enter the Virtual Account Number', 'virastore-xendit' ); ?> (<?php echo esc_html( $va_number ); ?>)</li>
				<li><?php esc_html_e( 'The payment details will appear on the screen', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Confirm the payment details and proceed with the payment', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Enter your PIN', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Your transaction is complete', 'virastore-xendit' ); ?></li>
			</ol>
		<?php else : ?>
			<h4><?php esc_html_e( 'ATM Transfer', 'virastore-xendit' ); ?></h4>
			<ol>
				<li><?php esc_html_e( 'Insert your card and enter your PIN', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Select "Transfer" or "Payment"', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Select "Virtual Account" or "Other Bank Account"', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Enter the Virtual Account Number', 'virastore-xendit' ); ?> (<?php echo esc_html( $va_number ); ?>)</li>
				<li><?php esc_html_e( 'Enter the exact amount to be paid', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Confirm the payment details and proceed with the payment', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Your transaction is complete', 'virastore-xendit' ); ?></li>
			</ol>
			
			<h4><?php esc_html_e( 'Mobile Banking', 'virastore-xendit' ); ?></h4>
			<ol>
				<li><?php esc_html_e( 'Log in to your Mobile Banking app', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Select "Transfer" or "Payment"', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Select "Virtual Account" or "Other Bank Account"', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Enter the Virtual Account Number', 'virastore-xendit' ); ?> (<?php echo esc_html( $va_number ); ?>)</li>
				<li><?php esc_html_e( 'Enter the exact amount to be paid', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Confirm the payment details and proceed with the payment', 'virastore-xendit' ); ?></li>
				<li><?php esc_html_e( 'Your transaction is complete', 'virastore-xendit' ); ?></li>
			</ol>
		<?php endif; ?>
	</div>
	
	<div class="xendit-important-notes">
		<h3><?php esc_html_e( 'Important Notes', 'virastore-xendit' ); ?></h3>
		<ul>
			<li><?php esc_html_e( 'Please make the payment before the expiry date.', 'virastore-xendit' ); ?></li>
			<li><?php esc_html_e( 'Please pay the exact amount as shown above.', 'virastore-xendit' ); ?></li>
			<li><?php esc_html_e( 'Your order will be processed after the payment is confirmed.', 'virastore-xendit' ); ?></li>
			<li><?php esc_html_e( 'If you have any questions, please contact our customer support.', 'virastore-xendit' ); ?></li>
		</ul>
	</div>
</div>