# ViraStore Xendit Payment Gateway

A WordPress plugin that integrates Xendit payment gateway with ViraStore.

## Description

ViraStore Xendit is an addon for the ViraStore plugin that enables Xendit payment gateway integration. This plugin allows customers to pay for their purchases using various payment methods supported by Xendit, including:

- Credit/Debit Cards
- Bank Transfers (Virtual Accounts)
- E-Wallets (OVO, DANA, LinkAja, ShopeePay)
- Retail Outlets (Alfamart, Indomaret)

## Features

- Seamless integration with ViraStore
- Multiple payment methods
- Test mode for development and testing
- Webhook support for payment notifications
- Detailed payment instructions for customers
- Responsive payment form
- Internationalization support

## Requirements

- WordPress 5.6 or higher
- PHP 8.2 or higher
- ViraStore plugin installed and activated
- Xendit account

## Installation

1. Upload the `virastore-xendit` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to ViraStore > Settings > Xendit to configure the plugin

## Configuration

1. Create a Xendit account at [https://dashboard.xendit.co/register](https://dashboard.xendit.co/register)
2. Obtain your API keys from the Xendit dashboard
3. Enter your API keys in the plugin settings
4. Set up the webhook URL in your Xendit dashboard
5. Enable the payment methods you want to offer
6. Save your settings

## Frequently Asked Questions

### How do I get my Xendit API keys?

You can obtain your API keys from the Xendit dashboard. Log in to your Xendit account, go to Settings > API Keys, and copy your secret and public keys.

### How do I set up webhooks?

In your Xendit dashboard, go to Settings > Webhooks, and add the webhook URL provided in the plugin settings. Make sure to select all the relevant events for payment notifications.

### Which payment methods are supported?

The plugin supports Credit/Debit Cards, Bank Transfers (Virtual Accounts), E-Wallets (OVO, DANA, LinkAja, ShopeePay), and Retail Outlets (Alfamart, Indomaret).

## Support

For support, please contact the plugin author or create an issue on the plugin's GitHub repository.

## License

This plugin is licensed under the GPL v2 or later.

## Credits

Developed by ViraStore Team.