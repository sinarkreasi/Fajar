<?php
/**
 * Xendit Webhook Handler
 *
 * @package ViraStore_Xendit
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ViraStore_Xendit_Webhook_Handler Class
 *
 * Handles the webhook notifications from Xendit.
 *
 * @since 1.0.0
 */
class ViraStore_Xendit_Webhook_Handler {

	/**
	 * Constructor
	 */
	public function __construct() {
		add_action( 'init', array( $this, 'handle_webhook' ) );
	}

	/**
	 * Handle webhook request
	 */
	public function handle_webhook() {
		// Check if this is a webhook request
		if ( ! isset( $_GET['virastore_xendit_webhook'] ) || $_GET['virastore_xendit_webhook'] !== '1' ) {
			return;
		}

		// Get the request body
		$request_body = file_get_contents( 'php://input' );
		$data = json_decode( $request_body, true );

		// Verify the webhook data
		if ( ! $this->verify_webhook( $request_body, $_SERVER ) ) {
			status_header( 401 );
			die( 'Invalid webhook signature' );
		}

		// Process the webhook data
		$result = $this->process_webhook( $data );

		if ( $result ) {
			status_header( 200 );
			die( 'Webhook processed successfully' );
		} else {
			status_header( 400 );
			die( 'Failed to process webhook' );
		}
	}

	/**
	 * Verify webhook signature
	 *
	 * @param string $request_body Request body.
	 * @param array  $server_vars Server variables.
	 * @return bool
	 */
	private function verify_webhook( $request_body, $server_vars ) {
		// Get the webhook signature from the request headers
		$signature = isset( $server_vars['HTTP_X_CALLBACK_TOKEN'] ) ? $server_vars['HTTP_X_CALLBACK_TOKEN'] : '';

		if ( empty( $signature ) ) {
			return false;
		}

		// Get the webhook token from the settings
		$test_mode = get_option( 'virastore_xendit_test_mode', 'yes' ) === 'yes';
		$webhook_token = $test_mode ? 
			get_option( 'virastore_xendit_test_webhook_token', '' ) : 
			get_option( 'virastore_xendit_live_webhook_token', '' );

		if ( empty( $webhook_token ) ) {
			// If no webhook token is set, skip verification
			return true;
		}

		// Verify the signature
		return hash_equals( $webhook_token, $signature );
	}

	/**
	 * Process webhook data
	 *
	 * @param array $data Webhook data.
	 * @return bool
	 */
	private function process_webhook( $data ) {
		// Log the webhook data for debugging
		$this->log_webhook_data( $data );

		// Determine the webhook type
		$webhook_type = $this->get_webhook_type( $data );

		if ( ! $webhook_type ) {
			return false;
		}

		// Process based on webhook type
		switch ( $webhook_type ) {
			case 'credit_card_payment':
				return $this->process_credit_card_payment( $data );

			case 'virtual_account_payment':
				return $this->process_virtual_account_payment( $data );

			case 'ewallet_payment':
				return $this->process_ewallet_payment( $data );

			case 'retail_payment':
				return $this->process_retail_payment( $data );

			default:
				return false;
		}
	}

	/**
	 * Get webhook type
	 *
	 * @param array $data Webhook data.
	 * @return string|bool
	 */
	private function get_webhook_type( $data ) {
		// Check for credit card payment
		if ( isset( $data['credit_card_charge_id'] ) ) {
			return 'credit_card_payment';
		}

		// Check for virtual account payment
		if ( isset( $data['callback_virtual_account_id'] ) || isset( $data['payment_id'] ) && isset( $data['bank_code'] ) ) {
			return 'virtual_account_payment';
		}

		// Check for e-wallet payment
		if ( isset( $data['ewallet_type'] ) || isset( $data['data']['reference_id'] ) && strpos( $data['data']['reference_id'], 'virastore_order_' ) === 0 ) {
			return 'ewallet_payment';
		}

		// Check for retail payment
		if ( isset( $data['payment_code'] ) || isset( $data['retail_outlet_name'] ) ) {
			return 'retail_payment';
		}

		return false;
	}

	/**
	 * Process credit card payment webhook
	 *
	 * @param array $data Webhook data.
	 * @return bool
	 */
	private function process_credit_card_payment( $data ) {
		// Get the order ID from the external ID
		$external_id = isset( $data['external_id'] ) ? sanitize_text_field( $data['external_id'] ) : '';
		$order_id = $this->get_order_id_from_external_id( $external_id );

		if ( ! $order_id ) {
			return false;
		}

		// Get the payment status
		$status = isset( $data['status'] ) ? sanitize_text_field( $data['status'] ) : '';

		// Update the order status
		return $this->update_order_status( $order_id, $status );
	}

	/**
	 * Process virtual account payment webhook
	 *
	 * @param array $data Webhook data.
	 * @return bool
	 */
	private function process_virtual_account_payment( $data ) {
		// Get the order ID from the external ID
		$external_id = isset( $data['external_id'] ) ? sanitize_text_field( $data['external_id'] ) : '';
		$order_id = $this->get_order_id_from_external_id( $external_id );

		if ( ! $order_id ) {
			return false;
		}

		// Get the payment status
		$status = isset( $data['status'] ) ? sanitize_text_field( $data['status'] ) : 'PENDING';
		if ( isset( $data['payment_id'] ) && ! empty( $data['payment_id'] ) ) {
			$status = 'PAID';
		}

		// Update the order status
		return $this->update_order_status( $order_id, $status );
	}

	/**
	 * Process e-wallet payment webhook
	 *
	 * @param array $data Webhook data.
	 * @return bool
	 */
	private function process_ewallet_payment( $data ) {
		// Get the order ID from the reference ID
		$reference_id = isset( $data['data']['reference_id'] ) ? sanitize_text_field( $data['data']['reference_id'] ) : '';
		$order_id = $this->get_order_id_from_external_id( $reference_id );

		if ( ! $order_id ) {
			return false;
		}

		// Get the payment status
		$status = isset( $data['data']['status'] ) ? sanitize_text_field( $data['data']['status'] ) : '';

		// Update the order status
		return $this->update_order_status( $order_id, $status );
	}

	/**
	 * Process retail payment webhook
	 *
	 * @param array $data Webhook data.
	 * @return bool
	 */
	private function process_retail_payment( $data ) {
		// Get the order ID from the external ID
		$external_id = isset( $data['reference_id'] ) ? sanitize_text_field( $data['reference_id'] ) : '';
		$order_id = $this->get_order_id_from_external_id( $external_id );

		if ( ! $order_id ) {
			return false;
		}

		// Get the payment status
		$status = isset( $data['status'] ) ? sanitize_text_field( $data['status'] ) : '';

		// Update the order status
		return $this->update_order_status( $order_id, $status );
	}

	/**
	 * Get order ID from external ID
	 *
	 * @param string $external_id External ID.
	 * @return int|bool
	 */
	private function get_order_id_from_external_id( $external_id ) {
		if ( empty( $external_id ) ) {
			return false;
		}

		// Extract order ID from external_id (format: virastore_order_123)
		if ( strpos( $external_id, 'virastore_order_' ) === 0 ) {
			return intval( str_replace( 'virastore_order_', '', $external_id ) );
		}

		return false;
	}

	/**
	 * Update order status
	 *
	 * @param int    $order_id Order ID.
	 * @param string $status Payment status.
	 * @return bool
	 */
	private function update_order_status( $order_id, $status ) {
		if ( ! $order_id || empty( $status ) ) {
			return false;
		}

		// Map Xendit status to ViraStore status
		$virastore_status = $this->map_status( $status );

		if ( ! $virastore_status ) {
			return false;
		}

		// Use VRSTORE_Order class methods if available
		if ( class_exists( 'VRSTORE_Order' ) ) {
			// Update payment status
			VRSTORE_Order::update_payment_status( $order_id, $virastore_status );

			// Update order status if payment is completed
			if ( $virastore_status === 'completed' ) {
				VRSTORE_Order::update_order_status( $order_id, 'completed' );

				// Generate license for completed orders
				$order = VRSTORE_Order::get_order( $order_id );
				if ( $order && class_exists( 'VRSTORE_License' ) ) {
					$license = VRSTORE_License::get_instance();
					
					// Handle cart items with license types or single product
					if ( isset( $order['cart_items'] ) && is_array( $order['cart_items'] ) ) {
						// Process each cart item
						foreach ( $order['cart_items'] as $cart_item ) {
							$license_type_slug = isset( $cart_item['license_type'] ) ? $cart_item['license_type'] : '';
							$license->generate_license_on_purchase( 
								$cart_item['product_id'], 
								isset( $order['user_id'] ) ? $order['user_id'] : 0, 
								$license_type_slug 
							);
						}
					} else {
						// Single product purchase (legacy)
						$license->generate_license_on_purchase( 
							isset( $order['product_id'] ) ? $order['product_id'] : 0, 
							isset( $order['user_id'] ) ? $order['user_id'] : 0 
						);
					}
				}
			} elseif ( $virastore_status === 'pending' ) {
				VRSTORE_Order::update_order_status( $order_id, 'pending' );
			} elseif ( $virastore_status === 'failed' ) {
				VRSTORE_Order::update_order_status( $order_id, 'failed' );
			}
		} else {
			// Fallback to direct meta update if class not available
			update_post_meta( $order_id, '_payment_status', $virastore_status );

			// If payment is completed, trigger action for license generation
			if ( $virastore_status === 'completed' ) {
				do_action( 'virastore_payment_completed', $order_id );
			}
		}

		return true;
	}

	/**
	 * Map Xendit status to ViraStore status
	 *
	 * @param string $status Xendit status.
	 * @return string|bool
	 */
	private function map_status( $status ) {
		$status = strtoupper( $status );

		$status_map = array(
			'PAID'      => 'completed',
			'COMPLETED' => 'completed',
			'CAPTURED'  => 'completed',
			'SUCCESS'   => 'completed',
			'PENDING'   => 'pending',
			'FAILED'    => 'failed',
			'EXPIRED'   => 'failed',
		);

		return isset( $status_map[ $status ] ) ? $status_map[ $status ] : false;
	}

	/**
	 * Log webhook data for debugging
	 *
	 * @param array $data Webhook data.
	 */
	private function log_webhook_data( $data ) {
		if ( ! defined( 'WP_DEBUG' ) || ! WP_DEBUG ) {
			return;
		}

		$log_dir = WP_CONTENT_DIR . '/xendit-logs';
		if ( ! file_exists( $log_dir ) ) {
			mkdir( $log_dir, 0755, true );
		}

		$log_file = $log_dir . '/webhook-' . date( 'Y-m-d' ) . '.log';
		$log_data = date( 'Y-m-d H:i:s' ) . ' - ' . wp_json_encode( $data ) . "\n";

		file_put_contents( $log_file, $log_data, FILE_APPEND );
	}
}