<?php
/**
 * Xendit Hooks
 *
 * @package ViraStore_Xendit
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ViraStore_Xendit_Hooks
 *
 * Handles the integration with ViraStore plugin through hooks.
 *
 * @since 1.0.0
 */
class ViraStore_Xendit_Hooks {

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		// Register hooks for payment gateway (use vrstore_payment_gateways filter like PayPal).
		add_filter( 'vrstore_payment_gateways', array( $this, 'register_payment_gateway' ), 10 );

		// Add payment form
		add_action( 'virastore_payment_form_xendit', array( $this, 'render_payment_form' ) );

		// Process payment
		add_filter( 'virastore_process_payment_xendit', array( $this, 'process_payment' ), 10, 2 );

		// Add payment instructions
		add_action( 'virastore_payment_instructions_xendit', array( $this, 'render_payment_instructions' ) );

		// Register hooks for admin menu.
		add_action( 'admin_menu', array( $this, 'add_admin_menu' ), 20 );

		// Register hooks for settings.
		add_action( 'admin_init', array( $this, 'register_settings' ) );

		// Register hooks for AJAX handlers.
		add_action( 'wp_ajax_virastore_xendit_get_payment_methods', array( $this, 'ajax_get_payment_methods' ) );
		add_action( 'wp_ajax_nopriv_virastore_xendit_get_payment_methods', array( $this, 'ajax_get_payment_methods' ) );
		add_action( 'wp_ajax_virastore_xendit_process_payment', array( $this, 'ajax_process_payment' ) );
		add_action( 'wp_ajax_nopriv_virastore_xendit_process_payment', array( $this, 'ajax_process_payment' ) );

		// Register hooks for script enqueuing.
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ) );
	}

	/**
	 * Register Xendit as a payment gateway
	 *
	 * @param array $gateways Payment gateways.
	 * @return array
	 */
	public function register_payment_gateway( $gateways ) {
		$gateways['xendit'] = array(
			'name'        => __( 'Xendit', 'virastore-xendit' ),
			'description' => __( 'Pay with credit card, bank transfer, e-wallet, or retail outlet via Xendit.', 'virastore-xendit' ),
			'icon'        => VIRASTORE_XENDIT_PLUGIN_URL . 'assets/images/xendit-logo.svg',
		);

		return $gateways;
	}

	/**
	 * Render payment form
	 *
	 * @param string $payment_method Current payment method.
	 */
	public function render_payment_form( $payment_method ) {
		// Include payment form template
		include VIRASTORE_XENDIT_PLUGIN_DIR . 'views/payment-form.php';
	}

	/**
	 * Process payment
	 *
	 * @param array $result Result data.
	 * @param array $data Payment data.
	 * @return array
	 */
	public function process_payment( $result, $data ) {
		// Check if Xendit payment is selected
		if ( ! isset( $data['xendit_payment'] ) || $data['xendit_payment'] !== '1' ) {
			return $result;
		}

		// Initialize payment processor
		$processor = new ViraStore_Xendit_Payment_Processor();

		// Process payment
		$payment_result = $processor->process_payment( $data['order_data'], $data );

		if ( is_wp_error( $payment_result ) ) {
			$result['success'] = false;
			$result['message'] = $payment_result->get_error_message();
		} else {
			$result = $payment_result;
		}

		return $result;
	}

	/**
	 * Render payment instructions
	 *
	 * @param array $data Payment data.
	 */
	public function render_payment_instructions( $data ) {
		// Get order ID
		$order_id = isset( $_GET['order_id'] ) ? intval( $_GET['order_id'] ) : 0;

		if ( ! $order_id ) {
			return;
		}

		// Get payment type
		$payment_type = isset( $_GET['payment_type'] ) ? sanitize_text_field( $_GET['payment_type'] ) : '';

		if ( ! in_array( $payment_type, array( 'bank_transfer', 'retail' ), true ) ) {
			return;
		}

		// Get payment details
		$payment_method = get_post_meta( $order_id, '_xendit_payment_method', true );

		if ( $payment_method !== $payment_type ) {
			return;
		}

		// Include payment instructions template based on payment type
		if ( $payment_type === 'bank_transfer' ) {
			include VIRASTORE_XENDIT_PLUGIN_DIR . 'views/bank-transfer-instructions.php';
		} elseif ( $payment_type === 'retail' ) {
			include VIRASTORE_XENDIT_PLUGIN_DIR . 'views/retail-instructions.php';
		}
	}

	/**
	 * Add admin menu
	 */
	public function add_admin_menu() {
		add_submenu_page(
			'vrstore-dashboard',
			__( 'Xendit Settings', 'virastore-xendit' ),
			__( 'Xendit Settings', 'virastore-xendit' ),
			'manage_options',
			'virastore-xendit-settings',
			array( $this, 'render_settings_page' )
		);
	}

	/**
	 * Render settings page
	 */
	public function render_settings_page() {
		// Include settings page template
		include VIRASTORE_XENDIT_PLUGIN_DIR . 'views/settings-page.php';
	}

	/**
	 * Register settings
	 */
	public function register_settings() {
		// Register settings group
		register_setting( 'virastore_xendit_settings', 'virastore_xendit_test_mode' );
		register_setting( 'virastore_xendit_settings', 'virastore_xendit_test_api_key' );
		register_setting( 'virastore_xendit_settings', 'virastore_xendit_test_secret_key' );
		register_setting( 'virastore_xendit_settings', 'virastore_xendit_live_api_key' );
		register_setting( 'virastore_xendit_settings', 'virastore_xendit_live_secret_key' );
		register_setting( 'virastore_xendit_settings', 'virastore_xendit_payment_methods' );
		register_setting( 'virastore_xendit_settings', 'virastore_xendit_test_webhook_token' );
		register_setting( 'virastore_xendit_settings', 'virastore_xendit_live_webhook_token' );
	}

	/**
	 * AJAX handler for getting payment methods
	 */
	public function ajax_get_payment_methods() {
		// Verify nonce
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( $_POST['nonce'], 'virastore_xendit_nonce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid nonce.', 'virastore-xendit' ) ) );
		}

		// Get available payment methods
		$payment_methods = get_option( 'virastore_xendit_payment_methods', array() );

		// Start output buffer
		ob_start();

		// Include payment methods template
		include VIRASTORE_XENDIT_PLUGIN_DIR . 'views/payment-methods.php';

		// Get the output
		$html = ob_get_clean();

		// Send response
		wp_send_json_success( array( 'html' => $html ) );
	}

	/**
	 * AJAX handler for processing payment
	 */
	public function ajax_process_payment() {
		// Verify nonce
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( $_POST['nonce'], 'virastore_xendit_nonce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid nonce.', 'virastore-xendit' ) ) );
		}

		// Get order data
		$order_id = isset( $_POST['order_id'] ) ? intval( $_POST['order_id'] ) : 0;

		if ( ! $order_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid order ID.', 'virastore-xendit' ) ) );
		}

		// Get order data
		$order_data = array(
			'order_id' => $order_id,
			'name'     => get_post_meta( $order_id, '_billing_name', true ),
			'email'    => get_post_meta( $order_id, '_billing_email', true ),
			'subtotal' => get_post_meta( $order_id, '_subtotal', true ),
			'discount' => get_post_meta( $order_id, '_discount', true ),
			'total'    => get_post_meta( $order_id, '_total', true ),
		);

		// Initialize payment processor
		$processor = new ViraStore_Xendit_Payment_Processor();

		// Process payment
		$payment_result = $processor->process_payment( $order_data, $_POST );

		if ( is_wp_error( $payment_result ) ) {
			wp_send_json_error( array( 'message' => $payment_result->get_error_message() ) );
		} else {
			wp_send_json_success( $payment_result );
		}
	}

	/**
	 * Enqueue scripts
	 */
	public function enqueue_scripts() {
		// Only enqueue on checkout page or pages with checkout shortcode
		$checkout_page_id = get_option( 'vrstore_checkout_page', 0 );
		$is_checkout_page = $checkout_page_id && is_page( $checkout_page_id );
		$has_checkout_form = $is_checkout_page || ( function_exists( 'has_shortcode' ) && has_shortcode( get_post()->post_content ?? '', 'vrstore_checkout' ) );
		
		// Also check if checkout form exists on page
		if ( ! $has_checkout_form && ! $is_checkout_page ) {
			global $post;
			if ( $post && ( strpos( $post->post_content, 'vrstore_checkout' ) !== false || strpos( $post->post_content, '[vrstore_checkout' ) !== false ) ) {
				$has_checkout_form = true;
			}
		}
		
		// Enqueue on checkout page or if checkout form detected
		if ( $is_checkout_page || $has_checkout_form ) {
			// Enqueue styles
			wp_enqueue_style(
				'virastore-xendit',
				VIRASTORE_XENDIT_PLUGIN_URL . 'assets/css/xendit-payment.css',
				array(),
				VIRASTORE_XENDIT_VERSION
			);

			// Enqueue scripts
			wp_enqueue_script(
				'virastore-xendit',
				VIRASTORE_XENDIT_PLUGIN_URL . 'assets/js/xendit-payment.js',
				array( 'jquery' ),
				VIRASTORE_XENDIT_VERSION,
				true
			);

			// Localize script
			wp_localize_script(
				'virastore-xendit',
				'virastore_xendit',
				array(
					'ajax_url'        => admin_url( 'admin-ajax.php' ),
					'nonce'          => wp_create_nonce( 'virastore_xendit_nonce' ),
					'loading_text'    => __( 'Loading payment methods...', 'virastore-xendit' ),
					'processing_text' => __( 'Processing payment...', 'virastore-xendit' ),
					'submit_text'     => __( 'Pay Now', 'virastore-xendit' ),
					'error_text'      => __( 'An error occurred. Please try again.', 'virastore-xendit' ),
				)
			);
		}
	}

	/**
	 * Enqueue admin scripts
	 *
	 * @param string $hook Current admin page.
	 */
	public function admin_enqueue_scripts( $hook ) {
		// Only enqueue on Xendit settings page
		if ( $hook !== 'vrstore-dashboard_page_virastore-xendit-settings' ) {
			return;
		}

		// Enqueue admin styles
		wp_enqueue_style(
			'virastore-xendit-admin',
			VIRASTORE_XENDIT_PLUGIN_URL . 'assets/css/admin.css',
			array(),
			VIRASTORE_XENDIT_VERSION
		);

		// Enqueue admin scripts
		wp_enqueue_script(
			'virastore-xendit-admin',
			VIRASTORE_XENDIT_PLUGIN_URL . 'assets/js/admin.js',
			array( 'jquery' ),
			VIRASTORE_XENDIT_VERSION,
			true
		);
	}
}