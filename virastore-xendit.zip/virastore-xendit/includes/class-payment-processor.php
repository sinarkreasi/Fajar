<?php
/**
 * Xendit Payment Processor
 *
 * @package ViraStore_Xendit
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ViraStore_Xendit_Payment_Processor Class
 *
 * Handles the payment processing for Xendit gateway.
 *
 * @since 1.0.0
 */
class ViraStore_Xendit_Payment_Processor {

	/**
	 * API Base URL
	 *
	 * @var string
	 */
	private $api_url = 'https://api.xendit.co';

	/**
	 * Test mode flag
	 *
	 * @var bool
	 */
	private $test_mode;

	/**
	 * API Key
	 *
	 * @var string
	 */
	private $api_key;

	/**
	 * Secret Key
	 *
	 * @var string
	 */
	private $secret_key;

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->test_mode = get_option( 'virastore_xendit_test_mode', 'yes' ) === 'yes';
		
		if ( $this->test_mode ) {
			$this->api_key = get_option( 'virastore_xendit_test_api_key', '' );
			$this->secret_key = get_option( 'virastore_xendit_test_secret_key', '' );
		} else {
			$this->api_key = get_option( 'virastore_xendit_live_api_key', '' );
			$this->secret_key = get_option( 'virastore_xendit_live_secret_key', '' );
		}
	}

	/**
	 * Process payment
	 *
	 * @param array $order_data Order data.
	 * @param array $payment_data Payment data.
	 * @return array|WP_Error
	 */
	public function process_payment( $order_data, $payment_data ) {
		if ( empty( $this->api_key ) || empty( $this->secret_key ) ) {
			return new WP_Error( 'xendit_error', __( 'Xendit API credentials are not configured properly.', 'virastore-xendit' ) );
		}

		$payment_channel = isset( $payment_data['xendit_payment_channel'] ) ? sanitize_text_field( $payment_data['xendit_payment_channel'] ) : 'credit_card';

		switch ( $payment_channel ) {
			case 'credit_card':
				return $this->process_credit_card_payment( $order_data, $payment_data );

			case 'bank_transfer':
				return $this->process_bank_transfer_payment( $order_data, $payment_data );

			case 'e_wallet':
				return $this->process_ewallet_payment( $order_data, $payment_data );

			case 'retail':
				return $this->process_retail_payment( $order_data, $payment_data );

			default:
				return new WP_Error( 'xendit_error', __( 'Invalid payment channel.', 'virastore-xendit' ) );
		}
	}

	/**
	 * Process credit card payment
	 *
	 * @param array $order_data Order data.
	 * @param array $payment_data Payment data.
	 * @return array|WP_Error
	 */
	private function process_credit_card_payment( $order_data, $payment_data ) {
		// Validate card data
		if ( ! isset( $payment_data['xendit_card_number'] ) || ! isset( $payment_data['xendit_card_expiry'] ) || ! isset( $payment_data['xendit_card_cvc'] ) ) {
			return new WP_Error( 'xendit_error', __( 'Credit card information is incomplete.', 'virastore-xendit' ) );
		}

		// Format card data
		$card_number = preg_replace( '/\D/', '', $payment_data['xendit_card_number'] );
		$expiry = explode( '/', $payment_data['xendit_card_expiry'] );
		$exp_month = isset( $expiry[0] ) ? trim( $expiry[0] ) : '';
		$exp_year = isset( $expiry[1] ) ? trim( $expiry[1] ) : '';
		
		if ( strlen( $exp_year ) === 2 ) {
			$exp_year = '20' . $exp_year;
		}

		// Create token
		$token_response = $this->create_card_token( $card_number, $exp_month, $exp_year, $payment_data['xendit_card_cvc'] );

		if ( is_wp_error( $token_response ) ) {
			return $token_response;
		}

		// Create charge
		$order_id = isset( $order_data['order_id'] ) ? intval( $order_data['order_id'] ) : 0;
		$charge_data = array(
			'token_id'          => $token_response['id'],
			'external_id'       => 'virastore_order_' . $order_id,
			'amount'            => $order_data['total'] * 100, // Convert to cents
			'card_cvn'          => $payment_data['xendit_card_cvc'],
			'capture'           => true,
			'descriptor'        => get_bloginfo( 'name' ),
			'currency'          => 'IDR',
			'metadata'          => array(
				'order_id'        => $order_data['order_id'],
				'customer_email' => $order_data['email'],
			),
		);

		$charge_response = $this->create_charge( $charge_data );

		if ( is_wp_error( $charge_response ) ) {
			return $charge_response;
		}

		// Return success response
		return array(
			'success'      => true,
			'redirect_url' => '',
			'transaction_id' => $charge_response['id'],
			'message'      => __( 'Payment processed successfully.', 'virastore-xendit' ),
		);
	}

	/**
	 * Process bank transfer payment
	 *
	 * @param array $order_data Order data.
	 * @param array $payment_data Payment data.
	 * @return array|WP_Error
	 */
	private function process_bank_transfer_payment( $order_data, $payment_data ) {
		if ( ! isset( $payment_data['xendit_bank'] ) ) {
			return new WP_Error( 'xendit_error', __( 'Please select a bank.', 'virastore-xendit' ) );
		}

		$bank_code = sanitize_text_field( $payment_data['xendit_bank'] );
		$order_id = isset( $order_data['order_id'] ) ? intval( $order_data['order_id'] ) : 0;
		
		// Create virtual account
		$va_data = array(
			'external_id'      => 'virastore_order_' . $order_id,
			'bank_code'        => strtoupper( $bank_code ),
			'name'             => $order_data['name'],
			'expected_amount'  => $order_data['total'],
			'is_closed'        => true,
			'expiration_date'  => date( 'Y-m-d\TH:i:s\Z', strtotime( '+1 day' ) ),
			'is_single_use'    => true,
		);

		$va_response = $this->create_virtual_account( $va_data );

		if ( is_wp_error( $va_response ) ) {
			return $va_response;
		}

		// Save VA details to order meta
		$order_id = isset( $order_data['order_id'] ) ? intval( $order_data['order_id'] ) : 0;
		if ( $order_id ) {
			update_post_meta( $order_id, '_xendit_payment_method', 'bank_transfer' );
			update_post_meta( $order_id, '_xendit_bank_code', $bank_code );
			update_post_meta( $order_id, '_xendit_va_number', $va_response['account_number'] );
			update_post_meta( $order_id, '_xendit_va_id', $va_response['id'] );
			update_post_meta( $order_id, '_xendit_va_expiry', $va_response['expiration_date'] );
		}

		// Return success response with payment instructions
		return array(
			'success'      => true,
			'redirect_url' => add_query_arg( array(
				'payment_method' => 'xendit',
				'payment_type'   => 'bank_transfer',
				'order_id'       => $order_data['order_id'],
			), home_url( '/payment-instructions/' ) ),
			'transaction_id' => $va_response['id'],
			'message'      => __( 'Virtual account created successfully. Please complete the payment.', 'virastore-xendit' ),
		);
	}

	/**
	 * Process e-wallet payment
	 *
	 * @param array $order_data Order data.
	 * @param array $payment_data Payment data.
	 * @return array|WP_Error
	 */
	private function process_ewallet_payment( $order_data, $payment_data ) {
		if ( ! isset( $payment_data['xendit_ewallet'] ) ) {
			return new WP_Error( 'xendit_error', __( 'Please select an e-wallet.', 'virastore-xendit' ) );
		}

		if ( ! isset( $payment_data['xendit_phone_number'] ) || empty( $payment_data['xendit_phone_number'] ) ) {
			return new WP_Error( 'xendit_error', __( 'Phone number is required for e-wallet payment.', 'virastore-xendit' ) );
		}

		$ewallet_type = sanitize_text_field( $payment_data['xendit_ewallet'] );
		$phone_number = sanitize_text_field( $payment_data['xendit_phone_number'] );

		// Create e-wallet charge
		$order_id = isset( $order_data['order_id'] ) ? intval( $order_data['order_id'] ) : 0;
		$ewallet_data = array(
			'reference_id'    => 'virastore_order_' . $order_id,
			'currency'        => 'IDR',
			'amount'          => $order_data['total'],
			'checkout_method' => 'ONE_TIME_PAYMENT',
			'channel_code'    => strtoupper( $ewallet_type ),
			'channel_properties' => array(
				'mobile_number' => $phone_number,
			),
			'metadata'        => array(
				'order_id'      => $order_data['order_id'],
			),
		);

		$ewallet_response = $this->create_ewallet_charge( $ewallet_data );

		if ( is_wp_error( $ewallet_response ) ) {
			return $ewallet_response;
		}

		// Save e-wallet details to order meta
		$order_id = isset( $order_data['order_id'] ) ? intval( $order_data['order_id'] ) : 0;
		if ( $order_id ) {
			update_post_meta( $order_id, '_xendit_payment_method', 'e_wallet' );
			update_post_meta( $order_id, '_xendit_ewallet_type', $ewallet_type );
			update_post_meta( $order_id, '_xendit_ewallet_id', $ewallet_response['id'] );
			update_post_meta( $order_id, '_xendit_ewallet_status', $ewallet_response['status'] );
		}

		// Return success response with redirect URL if available
		return array(
			'success'      => true,
			'redirect_url' => isset( $ewallet_response['actions']['mobile_web_checkout_url'] ) 
				? $ewallet_response['actions']['mobile_web_checkout_url'] 
				: '',
			'transaction_id' => $ewallet_response['id'],
			'message'      => __( 'E-wallet payment initiated. Please complete the payment.', 'virastore-xendit' ),
		);
	}

	/**
	 * Process retail payment
	 *
	 * @param array $order_data Order data.
	 * @param array $payment_data Payment data.
	 * @return array|WP_Error
	 */
	private function process_retail_payment( $order_data, $payment_data ) {
		if ( ! isset( $payment_data['xendit_retail'] ) ) {
			return new WP_Error( 'xendit_error', __( 'Please select a retail outlet.', 'virastore-xendit' ) );
		}

		$retail_outlet = sanitize_text_field( $payment_data['xendit_retail'] );
		$order_id = isset( $order_data['order_id'] ) ? intval( $order_data['order_id'] ) : 0;

		// Create retail payment code
		$retail_data = array(
			'reference_id'    => 'virastore_order_' . $order_id,
			'channel_code'    => strtoupper( $retail_outlet ),
			'customer_name'   => $order_data['name'],
			'amount'          => $order_data['total'],
			'currency'        => 'IDR',
			'market'          => 'ID',
			'payment_code'    => array(
				'expires_at'    => date( 'Y-m-d\TH:i:s\Z', strtotime( '+1 day' ) ),
			),
			'metadata'        => array(
				'order_id'      => $order_data['order_id'],
			),
		);

		$retail_response = $this->create_retail_payment( $retail_data );

		if ( is_wp_error( $retail_response ) ) {
			return $retail_response;
		}

		// Save retail details to order meta
		$order_id = isset( $order_data['order_id'] ) ? intval( $order_data['order_id'] ) : 0;
		if ( $order_id ) {
			update_post_meta( $order_id, '_xendit_payment_method', 'retail' );
			update_post_meta( $order_id, '_xendit_retail_outlet', $retail_outlet );
			update_post_meta( $order_id, '_xendit_payment_code', $retail_response['payment_code'] );
			update_post_meta( $order_id, '_xendit_retail_id', $retail_response['id'] );
			update_post_meta( $order_id, '_xendit_retail_expiry', $retail_response['expires_at'] );
		}

		// Return success response with payment instructions
		return array(
			'success'      => true,
			'redirect_url' => add_query_arg( array(
				'payment_method' => 'xendit',
				'payment_type'   => 'retail',
				'order_id'       => $order_data['order_id'],
			), home_url( '/payment-instructions/' ) ),
			'transaction_id' => $retail_response['id'],
			'message'      => __( 'Retail payment code created successfully. Please complete the payment.', 'virastore-xendit' ),
		);
	}

	/**
	 * Create card token
	 *
	 * @param string $card_number Card number.
	 * @param string $exp_month Expiry month.
	 * @param string $exp_year Expiry year.
	 * @param string $cvc CVC.
	 * @return array|WP_Error
	 */
	private function create_card_token( $card_number, $exp_month, $exp_year, $cvc ) {
		$endpoint = '/v2/card_tokens';
		
		$data = array(
			'card_number' => $card_number,
			'card_exp_month' => $exp_month,
			'card_exp_year' => $exp_year,
			'card_cvn' => $cvc,
		);

		return $this->make_request( 'POST', $endpoint, $data );
	}

	/**
	 * Create charge
	 *
	 * @param array $data Charge data.
	 * @return array|WP_Error
	 */
	private function create_charge( $data ) {
		$endpoint = '/v2/credit_card_charges';
		
		return $this->make_request( 'POST', $endpoint, $data );
	}

	/**
	 * Create virtual account
	 *
	 * @param array $data Virtual account data.
	 * @return array|WP_Error
	 */
	private function create_virtual_account( $data ) {
		$endpoint = '/callback_virtual_accounts';
		
		return $this->make_request( 'POST', $endpoint, $data );
	}

	/**
	 * Create e-wallet charge
	 *
	 * @param array $data E-wallet data.
	 * @return array|WP_Error
	 */
	private function create_ewallet_charge( $data ) {
		$endpoint = '/ewallets/charges';
		
		return $this->make_request( 'POST', $endpoint, $data );
	}

	/**
	 * Create retail payment
	 *
	 * @param array $data Retail payment data.
	 * @return array|WP_Error
	 */
	private function create_retail_payment( $data ) {
		$endpoint = '/payment_codes';
		
		return $this->make_request( 'POST', $endpoint, $data );
	}

	/**
	 * Make API request
	 *
	 * @param string $method Request method.
	 * @param string $endpoint API endpoint.
	 * @param array  $data Request data.
	 * @return array|WP_Error
	 */
	private function make_request( $method, $endpoint, $data = array() ) {
		$url = $this->api_url . $endpoint;
		
		$headers = array(
			'Content-Type'  => 'application/json',
			'Authorization' => 'Basic ' . base64_encode( $this->secret_key . ':' ),
		);

		$args = array(
			'method'    => $method,
			'headers'   => $headers,
			'timeout'   => 30,
			'sslverify' => true,
		);

		if ( ! empty( $data ) ) {
			$args['body'] = wp_json_encode( $data );
		}

		$response = wp_remote_request( $url, $args );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$response_code = wp_remote_retrieve_response_code( $response );
		$response_body = wp_remote_retrieve_body( $response );
		$response_data = json_decode( $response_body, true );

		if ( $response_code < 200 || $response_code >= 300 ) {
			$error_message = isset( $response_data['message'] ) ? $response_data['message'] : __( 'Unknown error occurred.', 'virastore-xendit' );
			return new WP_Error( 'xendit_api_error', $error_message, $response_data );
		}

		return $response_data;
	}

	/**
	 * Process webhook
	 *
	 * @param array $data Webhook data.
	 * @return bool
	 */
	public function process_webhook( $data ) {
		// Verify webhook data
		if ( ! isset( $data['external_id'] ) || ! isset( $data['status'] ) ) {
			return false;
		}

		// Extract order ID from external_id
		$external_id = sanitize_text_field( $data['external_id'] );
		$order_id = 0;

		if ( strpos( $external_id, 'virastore_order_' ) === 0 ) {
			$order_id = intval( str_replace( 'virastore_order_', '', $external_id ) );
		}

		if ( ! $order_id ) {
			return false;
		}

		// Get payment status
		$status = sanitize_text_field( $data['status'] );

		// Update order status based on payment status
		switch ( $status ) {
			case 'PAID':
			case 'COMPLETED':
			case 'CAPTURED':
			case 'SUCCESS':
				// Update order status to completed using VRSTORE_Order if available
				if ( class_exists( 'VRSTORE_Order' ) ) {
					VRSTORE_Order::update_payment_status( $order_id, 'completed' );
					VRSTORE_Order::update_order_status( $order_id, 'completed' );
					
					// Generate license for completed orders
					$order = VRSTORE_Order::get_order( $order_id );
					if ( $order && class_exists( 'VRSTORE_License' ) ) {
						$license = VRSTORE_License::get_instance();
						
						// Handle cart items with license types or single product
						if ( isset( $order['cart_items'] ) && is_array( $order['cart_items'] ) ) {
							foreach ( $order['cart_items'] as $cart_item ) {
								$license_type_slug = isset( $cart_item['license_type'] ) ? $cart_item['license_type'] : '';
								$license->generate_license_on_purchase( 
									$cart_item['product_id'], 
									isset( $order['user_id'] ) ? $order['user_id'] : 0, 
									$license_type_slug 
								);
							}
						} else {
							$license->generate_license_on_purchase( 
								isset( $order['product_id'] ) ? $order['product_id'] : 0, 
								isset( $order['user_id'] ) ? $order['user_id'] : 0 
							);
						}
					}
				} else {
					// Fallback to direct meta update
					update_post_meta( $order_id, '_payment_status', 'completed' );
					do_action( 'virastore_payment_completed', $order_id );
				}
				return true;

			case 'FAILED':
			case 'EXPIRED':
				// Update order status to failed using VRSTORE_Order if available
				if ( class_exists( 'VRSTORE_Order' ) ) {
					VRSTORE_Order::update_payment_status( $order_id, 'failed' );
					VRSTORE_Order::update_order_status( $order_id, 'failed' );
				} else {
					update_post_meta( $order_id, '_payment_status', 'failed' );
				}
				return true;

			case 'PENDING':
				// Update order status to pending using VRSTORE_Order if available
				if ( class_exists( 'VRSTORE_Order' ) ) {
					VRSTORE_Order::update_payment_status( $order_id, 'pending' );
					VRSTORE_Order::update_order_status( $order_id, 'pending' );
				} else {
					update_post_meta( $order_id, '_payment_status', 'pending' );
				}
				return true;

			default:
				return false;
		}
	}
}