<?php
/**
 * Xendit Payment Gateway Integration Class
 *
 * @package ViraStore_Xendit
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ViraStore_Xendit Class
 *
 * Handles Xendit payment gateway integration for ViraStore.
 *
 * @since 1.0.0
 */
class ViraStore_Xendit {

	/**
	 * Instance of this class.
	 *
	 * @since 1.0.0
	 * @var object
	 */
	protected static $instance = null;

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		// Gateway registration is handled by ViraStore_Xendit_Hooks class.
		// Process Xendit payment (legacy filter - kept for compatibility).
		add_filter( 'vrstore_process_payment_xendit', array( $this, 'process_xendit_payment' ), 10, 2 );

		// Handle Xendit webhook (webhook handler class also handles this via init action).
		add_action( 'init', array( $this, 'handle_xendit_webhook' ) );

		// Enqueue scripts and styles (also handled by hooks class, but kept here for compatibility).
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );

		// Load text domain
		add_action( 'init', array( $this, 'load_textdomain' ) );
	}

	/**
	 * Return an instance of this class.
	 *
	 * @since 1.0.0
	 * @return object A single instance of this class.
	 */
	public static function get_instance() {
		// If the single instance hasn't been set, set it now.
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Register Xendit as a payment gateway.
	 *
	 * @since 1.0.0
	 * @param array $gateways Available payment gateways.
	 * @return array Modified payment gateways.
	 */
	public function register_xendit_gateway( $gateways ) {
		// Add Xendit to the list of available gateways.
		$gateways['xendit'] = array(
			'name'        => $this->get_translated_text( 'Xendit' ),
			'description' => $this->get_translated_text( 'Pay using various payment methods via Xendit.' ),
			'icon'        => 'credit-card',
			'enabled'     => true,
		);

		return $gateways;
	}

	/**
	 * Get translated text with conditional loading check.
	 *
	 * @since 1.0.0
	 * @param string $text The text to translate.
	 * @return string
	 */
	private function get_translated_text( $text ) {
		if ( function_exists( 'vrstore_is_textdomain_ready' ) && vrstore_is_textdomain_ready() ) {
			return esc_html__( $text, 'virastore-xendit' );
		}
		return esc_html( $text );
	}

	/**
	 * Add settings page.
	 *
	 * @since 1.0.0
	 */
	public function add_settings_page() {
		add_submenu_page(
			'vrstore-settings',
			__( 'Xendit Settings', 'virastore-xendit' ),
			__( 'Xendit', 'virastore-xendit' ),
			'manage_options',
			'virastore-xendit-settings',
			array( $this, 'render_settings_page' )
		);
	}

	/**
	 * Register settings.
	 *
	 * @since 1.0.0
	 */
	public function register_settings() {
		// Register settings.
		register_setting( 'virastore_xendit_settings', 'virastore_xendit_test_mode' );
		register_setting( 'virastore_xendit_settings', 'virastore_xendit_test_api_key' );
		register_setting( 'virastore_xendit_settings', 'virastore_xendit_test_secret_key' );
		register_setting( 'virastore_xendit_settings', 'virastore_xendit_live_api_key' );
		register_setting( 'virastore_xendit_settings', 'virastore_xendit_live_secret_key' );
		register_setting( 'virastore_xendit_settings', 'virastore_xendit_payment_methods' );
	}

	/**
	 * Render settings page.
	 *
	 * @since 1.0.0
	 */
	public function render_settings_page() {
		// Include settings page template.
		require_once VIRASTORE_XENDIT_PLUGIN_DIR . 'views/settings-page.php';
	}
	
	/**
	 * Load plugin text domain.
	 *
	 * @since 1.0.0
	 */
	public function load_textdomain() {
		load_plugin_textdomain( 'virastore-xendit', false, dirname( plugin_basename( VIRASTORE_XENDIT_PLUGIN_FILE ) ) . '/languages' );
	}

	/**
	 * Process Xendit payment.
	 *
	 * @since 1.0.0
	 * @param array $payment_data Payment data from checkout.
	 * @return array|WP_Error Payment result or error.
	 */
	public function process_payment( $payment_data ) {
		// Validate payment data
		if ( empty( $payment_data ) || ! is_array( $payment_data ) ) {
			return new WP_Error( 'xendit_invalid_data', $this->get_translated_text( 'Invalid payment data provided.' ) );
		}

		// Get order ID
		$order_id = isset( $payment_data['order_id'] ) ? intval( $payment_data['order_id'] ) : 0;
		if ( ! $order_id ) {
			return new WP_Error( 'xendit_no_order', $this->get_translated_text( 'Order ID is required.' ) );
		}

		// Get amount - use 'amount' first, then 'total', then 'order_total'
		$amount = isset( $payment_data['amount'] ) ? floatval( $payment_data['amount'] ) : 0;
		if ( $amount <= 0 && isset( $payment_data['total'] ) ) {
			$amount = floatval( $payment_data['total'] );
		}
		if ( $amount <= 0 && isset( $payment_data['order_total'] ) ) {
			$amount = floatval( $payment_data['order_total'] );
		}

		// Get order snapshot if amount is still 0
		if ( $amount <= 0 && class_exists( 'VRSTORE_Order' ) ) {
			$order_snapshot = VRSTORE_Order::get_order( $order_id );
			if ( $order_snapshot && isset( $order_snapshot['total'] ) ) {
				$amount = floatval( $order_snapshot['total'] );
			}
		}

		if ( $amount <= 0 ) {
			return new WP_Error( 'xendit_invalid_amount', $this->get_translated_text( 'Invalid payment amount.' ) );
		}

		// Get currency
		$currency = isset( $payment_data['currency'] ) ? sanitize_text_field( $payment_data['currency'] ) : 'IDR';
		if ( empty( $currency ) && class_exists( 'VRSTORE_Order' ) ) {
			$order_snapshot = VRSTORE_Order::get_order( $order_id );
			if ( $order_snapshot && ! empty( $order_snapshot['currency'] ) ) {
				$currency = $order_snapshot['currency'];
			}
		}

		// Get customer data
		$customer_name = isset( $payment_data['customer_name'] ) ? sanitize_text_field( $payment_data['customer_name'] ) : '';
		$customer_email = isset( $payment_data['customer_email'] ) ? sanitize_email( $payment_data['customer_email'] ) : '';

		// Get payment method/channel from form data
		$form_data = isset( $payment_data['form_data'] ) ? $payment_data['form_data'] : array();
		$xendit_payment_channel = isset( $form_data['xendit_payment_channel'] ) ? sanitize_text_field( $form_data['xendit_payment_channel'] ) : '';
		if ( empty( $xendit_payment_channel ) && isset( $form_data['xendit_method'] ) ) {
			$xendit_payment_channel = sanitize_text_field( $form_data['xendit_method'] );
		}
		if ( empty( $xendit_payment_channel ) ) {
			// Default to credit_card if not specified
			$xendit_payment_channel = 'credit_card';
		}

		// Check if Xendit API keys are configured
		$test_mode = get_option( 'virastore_xendit_test_mode', 'yes' ) === 'yes';
		$api_key = $test_mode ? get_option( 'virastore_xendit_test_api_key', '' ) : get_option( 'virastore_xendit_live_api_key', '' );
		$secret_key = $test_mode ? get_option( 'virastore_xendit_test_secret_key', '' ) : get_option( 'virastore_xendit_live_secret_key', '' );

		if ( empty( $api_key ) || empty( $secret_key ) ) {
			return new WP_Error( 'xendit_not_configured', $this->get_translated_text( 'Xendit is not properly configured. Please check your API keys in settings.' ) );
		}

		// Prepare order data for payment processor
		$order_data = array(
			'order_id' => $order_id,
			'total' => $amount,
			'amount' => $amount,
			'currency' => $currency,
			'name' => $customer_name,
			'email' => $customer_email,
		);

		// Prepare payment data for processor
		$processor_payment_data = array(
			'xendit_payment_channel' => $xendit_payment_channel,
		);

		// Add channel-specific data
		if ( $xendit_payment_channel === 'credit_card' ) {
			if ( isset( $form_data['xendit_card_number'] ) ) {
				$processor_payment_data['xendit_card_number'] = sanitize_text_field( $form_data['xendit_card_number'] );
			}
			if ( isset( $form_data['xendit_card_expiry'] ) ) {
				$processor_payment_data['xendit_card_expiry'] = sanitize_text_field( $form_data['xendit_card_expiry'] );
			}
			if ( isset( $form_data['xendit_card_cvc'] ) ) {
				$processor_payment_data['xendit_card_cvc'] = sanitize_text_field( $form_data['xendit_card_cvc'] );
			}
		} elseif ( $xendit_payment_channel === 'bank_transfer' ) {
			if ( isset( $form_data['xendit_bank'] ) ) {
				$processor_payment_data['xendit_bank'] = sanitize_text_field( $form_data['xendit_bank'] );
			}
		} elseif ( $xendit_payment_channel === 'e_wallet' ) {
			if ( isset( $form_data['xendit_ewallet'] ) ) {
				$processor_payment_data['xendit_ewallet'] = sanitize_text_field( $form_data['xendit_ewallet'] );
			}
			if ( isset( $form_data['xendit_phone_number'] ) ) {
				$processor_payment_data['xendit_phone_number'] = sanitize_text_field( $form_data['xendit_phone_number'] );
			}
		} elseif ( $xendit_payment_channel === 'retail' ) {
			if ( isset( $form_data['xendit_retail'] ) ) {
				$processor_payment_data['xendit_retail'] = sanitize_text_field( $form_data['xendit_retail'] );
			}
		}

		// Initialize payment processor
		if ( ! class_exists( 'ViraStore_Xendit_Payment_Processor' ) ) {
			return new WP_Error( 'xendit_processor_missing', $this->get_translated_text( 'Payment processor class not found.' ) );
		}

		try {
			$processor = new ViraStore_Xendit_Payment_Processor();
			$result = $processor->process_payment( $order_data, $processor_payment_data );

			if ( is_wp_error( $result ) ) {
				return $result;
			}

			// Ensure result has success flag
			if ( ! isset( $result['success'] ) ) {
				$result['success'] = true;
			}

			// Ensure redirect_url exists
			if ( ! isset( $result['redirect_url'] ) && isset( $result['payment_url'] ) ) {
				$result['redirect_url'] = $result['payment_url'];
			}

			return $result;

		} catch ( Exception $e ) {
			error_log( 'ViraStore Xendit Error: ' . $e->getMessage() );
			return new WP_Error( 'xendit_error', $this->get_translated_text( 'Payment processing failed: ' ) . $e->getMessage() );
		}
	}

	/**
	 * Process Xendit payment (legacy filter method - kept for compatibility).
	 *
	 * @since 1.0.0
	 * @param bool  $result    Default result.
	 * @param array $order_data Order data.
	 * @return array|WP_Error Payment result or error.
	 */
	public function process_xendit_payment( $result, $order_data ) {
		// Convert to new format
		$payment_data = array_merge( $order_data, array( 'order_id' => isset( $order_data['order_id'] ) ? $order_data['order_id'] : 0 ) );
		return $this->process_payment( $payment_data );
	}

	/**
	 * Handle Xendit webhook.
	 *
	 * @since 1.0.0
	 */
	public function handle_xendit_webhook() {
		// Check if this is a Xendit webhook.
		if ( ! isset( $_GET['virastore_xendit_webhook'] ) ) {
			return;
		}

		// Get the JSON payload.
		$payload = file_get_contents( 'php://input' );
		$data    = json_decode( $payload, true );

		// Verify the webhook signature.
		$signature = isset( $_SERVER['HTTP_X_CALLBACK_TOKEN'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_CALLBACK_TOKEN'] ) ) : '';
		$test_mode = get_option( 'virastore_xendit_test_mode', 'yes' ) === 'yes';
		$secret_key = $test_mode ? get_option( 'virastore_xendit_test_secret_key', '' ) : get_option( 'virastore_xendit_live_secret_key', '' );

		// In a real implementation, you would verify the signature here.
		// For this example, we'll assume the signature is valid.

		// Delegate webhook handling to webhook handler class if available
		if ( class_exists( 'ViraStore_Xendit_Webhook_Handler' ) ) {
			// Use the webhook handler class to process the webhook
			$webhook_handler = new ViraStore_Xendit_Webhook_Handler();
			// The webhook handler will process the webhook automatically via its constructor
			return;
		}

		// Fallback webhook processing (legacy)
		if ( isset( $data['status'] ) && 'PAID' === $data['status'] && isset( $data['external_id'] ) ) {
			// Get the order ID from the external ID.
			$external_id = sanitize_text_field( $data['external_id'] );

			// Extract order ID from external_id (format: virastore_order_123)
			$order_id = 0;
			if ( strpos( $external_id, 'virastore_order_' ) === 0 ) {
				$order_id = intval( str_replace( 'virastore_order_', '', $external_id ) );
			}

			if ( $order_id && class_exists( 'VRSTORE_Order' ) ) {
				// Update payment status and order status to completed
				VRSTORE_Order::update_payment_status( $order_id, 'completed' );
				VRSTORE_Order::update_order_status( $order_id, 'completed' );

				// Generate license key for the order.
				$order = VRSTORE_Order::get_order( $order_id );
				if ( $order && class_exists( 'VRSTORE_License' ) ) {
					$license = VRSTORE_License::get_instance();
					
					// Handle cart items with license types or single product
					if ( isset( $order['cart_items'] ) && is_array( $order['cart_items'] ) ) {
						// Process each cart item
						foreach ( $order['cart_items'] as $cart_item ) {
							$license_type_slug = isset( $cart_item['license_type'] ) ? $cart_item['license_type'] : '';
							$license->generate_license_on_purchase( 
								$cart_item['product_id'], 
								isset( $order['user_id'] ) ? $order['user_id'] : 0, 
								$license_type_slug 
							);
						}
					} else {
						// Single product purchase (legacy)
						$license->generate_license_on_purchase( 
							isset( $order['product_id'] ) ? $order['product_id'] : 0, 
							isset( $order['user_id'] ) ? $order['user_id'] : 0 
						);
					}
				}
			}
		}

		// Return a 200 response to acknowledge receipt of the webhook.
		status_header( 200 );
		exit;
	}

	/**
	 * Enqueue scripts and styles.
	 *
	 * @since 1.0.0
	 */
	public function enqueue_scripts() {
		// Only enqueue on checkout page.
		if ( ! is_page( get_option( 'vrstore_checkout_page', 0 ) ) ) {
			return;
		}

		// Enqueue Xendit JS.
		wp_enqueue_script(
			'virastore-xendit',
			VIRASTORE_XENDIT_PLUGIN_URL . 'assets/js/xendit-payment.js',
			array( 'jquery' ),
			VIRASTORE_XENDIT_VERSION,
			true
		);

		// Enqueue Xendit CSS.
		wp_enqueue_style(
			'virastore-xendit',
			VIRASTORE_XENDIT_PLUGIN_URL . 'assets/css/xendit-payment.css',
			array(),
			VIRASTORE_XENDIT_VERSION
		);

		// Localize script.
		wp_localize_script(
			'virastore-xendit',
			'virastore_xendit',
			array(
				'ajax_url'       => admin_url( 'admin-ajax.php' ),
				'payment_methods' => $this->get_available_payment_methods(),
			)
		);
	}

	/**
	 * Get available payment methods.
	 *
	 * @since 1.0.0
	 * @return array Available payment methods.
	 */
	private function get_available_payment_methods() {
		// Get enabled payment methods from settings.
		$enabled_methods = get_option( 'virastore_xendit_payment_methods', array() );

		// Define available payment methods.
		$available_methods = array(
			'credit_card' => array(
				'name'  => $this->get_translated_text( 'Credit Card' ),
				'icon'  => 'credit-card',
				'value' => 'credit_card',
			),
			'bank_transfer' => array(
				'name'  => $this->get_translated_text( 'Bank Transfer' ),
				'icon'  => 'bank',
				'value' => 'bank_transfer',
			),
			'e_wallet' => array(
				'name'  => $this->get_translated_text( 'E-Wallet' ),
				'icon'  => 'smartphone',
				'value' => 'e_wallet',
			),
			'retail' => array(
				'name'  => $this->get_translated_text( 'Retail Outlet' ),
				'icon'  => 'store',
				'value' => 'retail',
			),
		);

		// Filter available methods based on enabled methods.
		if ( ! empty( $enabled_methods ) ) {
			foreach ( $available_methods as $key => $method ) {
				if ( ! isset( $enabled_methods[ $key ] ) || 'on' !== $enabled_methods[ $key ] ) {
					unset( $available_methods[ $key ] );
				}
			}
		}

		return $available_methods;
	}
}