<?php
/**
 * Plugin Name: ViraStore Xendit Payment Gateway
 * Plugin URI: https://virastore.com/addons/xendit
 * Description: Adds Xendit payment gateway integration to ViraStore.
 * Version: 1.0.0
 * Author: ViraStore
 * Author URI: https://virastore.com
 * Text Domain: virastore-xendit
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 8.2
 *
 * @package ViraStore_Xendit
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Define plugin constants.
define( 'VIRASTORE_XENDIT_VERSION', '1.0.0' );
define( 'VIRASTORE_XENDIT_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'VIRASTORE_XENDIT_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'VIRASTORE_XENDIT_PLUGIN_FILE', __FILE__ );

/**
 * Check if ViraStore plugin is active.
 *
 * @since 1.0.0
 */
function virastore_xendit_check_virastore() {
	if ( ! class_exists( 'VRSTORE_Payment' ) ) {
		add_action( 'admin_notices', 'virastore_xendit_missing_virastore_notice' );
		return false;
	}
	return true;
}

/**
 * Display admin notice if ViraStore plugin is not active.
 *
 * @since 1.0.0
 */
function virastore_xendit_missing_virastore_notice() {
	$message = sprintf(
		/* translators: %s: ViraStore plugin link */
		__( 'ViraStore Xendit Payment Gateway requires ViraStore plugin to be installed and activated. Please %s.', 'virastore-xendit' ),
		'<a href="' . esc_url( admin_url( 'plugins.php' ) ) . '">' . __( 'install and activate ViraStore', 'virastore-xendit' ) . '</a>'
	);
	
	echo '<div class="notice notice-error"><p>' . wp_kses_post( $message ) . '</p></div>';
}

/**
 * Initialize the plugin.
 *
 * @since 1.0.0
 */
function virastore_xendit_init() {
	// Check if ViraStore plugin is active.
	if ( ! virastore_xendit_check_virastore() ) {
		return;
	}

	// Include required files.
	require_once VIRASTORE_XENDIT_PLUGIN_DIR . 'includes/class-virastore-xendit.php';
	require_once VIRASTORE_XENDIT_PLUGIN_DIR . 'includes/class-payment-processor.php';
	require_once VIRASTORE_XENDIT_PLUGIN_DIR . 'includes/class-webhook-handler.php';
	require_once VIRASTORE_XENDIT_PLUGIN_DIR . 'includes/class-hooks.php';

	// Initialize the plugin.
	ViraStore_Xendit::get_instance();
	
	// Initialize the hooks.
	new ViraStore_Xendit_Hooks();
}
add_action( 'plugins_loaded', 'virastore_xendit_init' );