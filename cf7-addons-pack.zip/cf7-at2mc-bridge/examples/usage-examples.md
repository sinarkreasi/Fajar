# CF7 Bridge Usage Examples

This document provides examples of how to use the CF7 Access Token to Mini Ecommerce Bridge.

## Basic Setup

### 1. Contact Form 7 Form Example

Create a CF7 form that works with both CF7 Mini Ecommerce and CF7 Access Token:

```
[text* customer-email placeholder "Your Email"]
[text* customer-name placeholder "Your Name"]
[select product-id "Product 1|product_1" "Product 2|product_2" "Service A|service_a"]
[number quantity min:1 max:10 placeholder "Quantity"]
[textarea notes placeholder "Additional Notes (Optional)"]
[submit "Place Order"]
```

### 2. Plugin Configuration

Configure the bridge in **CF7 Bridge > Settings**:

- ✅ Enable Order Access
- ✅ Auto Generate Tokens  
- ✅ Send Access Emails
- Token Expiry: 72 hours
- Access Page Slug: `order-access`
- ✅ Allow Payment Retry
- Retry Limit: 3

## Integration Examples

### 1. Custom Order Access Page

Create a custom page template for order access:

```php
<?php
// Template: page-order-access.php

get_header();

// Check if this is an order access request
if (cf7at2mc_is_order_access_request()) {
    // Let the bridge handle the request
    do_action('cf7at2mc_handle_order_access');
} else {
    // Show access form
    ?>
    <div class="order-access-form">
        <h2>Access Your Order</h2>
        <form method="get" class="cf7at2mc-access-form">
            <input type="text" name="token" placeholder="Enter your access token" required>
            <button type="submit">Access Order</button>
        </form>
    </div>
    <?php
}

get_footer();
?>
```

### 2. Custom Email Template

Customize the magic link email using CF7 Access Token hooks:

```php
// In your theme's functions.php
add_filter('cf7at_email_template_order', 'custom_order_access_email', 10, 2);

function custom_order_access_email($template, $token_data) {
    if ($token_data['related_type'] !== 'order') {
        return $template;
    }
    
    $order_id = $token_data['related_id'];
    $order_manager = new CF7MC\Core\OrderManager();
    $order = $order_manager->get_order($order_id);
    
    return [
        'subject' => 'Your Order #' . $order['order_code'] . ' - Access Link',
        'message' => "
            <h2>Order Access Link</h2>
            <p>Hello,</p>
            <p>Your order #{$order['order_code']} has been created. Click the link below to view your order details and complete payment:</p>
            <p><a href='{magic_link}' style='background: #007cba; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px;'>View My Order</a></p>
            <p>Order Total: " . cf7at2mc_format_amount($order['total_amount']) . "</p>
            <p>This link will expire in " . cf7at2mc_get_token_expiry_hours() . " hours.</p>
        "
    ];
}
```

### 3. Custom Order Content

Add custom content to order access pages:

```php
// Add download links for digital products
add_action('cf7at2mc_render_paid_order_content', 'add_digital_downloads', 10, 2);

function add_digital_downloads($order, $token_data) {
    if ($order['status'] !== 'paid') {
        return;
    }
    
    // Check if order contains digital products
    foreach ($order['items'] as $item) {
        if (isset($item['type']) && $item['type'] === 'digital') {
            ?>
            <div class="digital-downloads">
                <h3>Your Downloads</h3>
                <p>Thank you for your purchase! Your digital products are ready for download:</p>
                <ul>
                    <li>
                        <a href="<?php echo wp_nonce_url(home_url('/download/?product=' . $item['id'] . '&order=' . $order['id']), 'download_' . $item['id']); ?>" class="download-link">
                            📁 Download <?php echo esc_html($item['name']); ?>
                        </a>
                    </li>
                </ul>
            </div>
            <?php
        }
    }
}
```

### 4. Order Status Webhooks

Handle order status changes:

```php
// Send notifications when order status changes
add_action('cf7mc_order_status_updated', 'handle_order_status_change', 10, 2);

function handle_order_status_change($order_id, $new_status) {
    $order_manager = new CF7MC\Core\OrderManager();
    $order = $order_manager->get_order($order_id);
    
    if (!$order) {
        return;
    }
    
    // Send status update email
    if ($new_status === 'paid') {
        // Send order confirmation
        wp_mail(
            $order['email'],
            'Order Confirmed - #' . $order['order_code'],
            "Your order has been confirmed and is being processed."
        );
    } elseif ($new_status === 'failed') {
        // Send payment failure notice with retry link
        $bridge = CF7AT2MC\Core\Bridge::instance();
        $token_id = $bridge->generate_order_token($order_id, $order['email']);
        
        if ($token_id) {
            wp_mail(
                $order['email'],
                'Payment Failed - #' . $order['order_code'],
                "Your payment failed. Please try again using your order access link."
            );
        }
    }
}
```

## Advanced Usage

### 1. Custom Access Validation

Add additional validation for order access:

```php
add_filter('cf7at2mc_validate_order_access', 'custom_access_validation', 10, 3);

function custom_access_validation($is_valid, $order, $token_data) {
    if (!$is_valid) {
        return false;
    }
    
    // Additional validation rules
    
    // Check if order is too old (beyond normal expiry)
    $order_date = strtotime($order['created_at']);
    $max_age = 30 * DAY_IN_SECONDS; // 30 days
    
    if (time() - $order_date > $max_age) {
        return false;
    }
    
    // Check if customer is blocked
    $blocked_emails = get_option('blocked_customer_emails', []);
    if (in_array($order['email'], $blocked_emails)) {
        return false;
    }
    
    return true;
}
```

### 2. Custom Payment Retry Logic

Customize payment retry behavior:

```php
add_filter('cf7at2mc_can_retry_payment', 'custom_retry_logic', 10, 2);

function custom_retry_logic($can_retry, $order) {
    // Don't allow retry for orders older than 7 days
    $order_date = strtotime($order['created_at']);
    $max_retry_age = 7 * DAY_IN_SECONDS;
    
    if (time() - $order_date > $max_retry_age) {
        return false;
    }
    
    // Check retry count (if you're tracking it)
    $retry_count = get_post_meta($order['id'], '_retry_count', true) ?: 0;
    $max_retries = cf7at2mc_get_retry_limit();
    
    if ($retry_count >= $max_retries) {
        return false;
    }
    
    return $can_retry;
}
```

### 3. Integration with Other Plugins

#### WooCommerce Integration

```php
// Sync orders with WooCommerce
add_action('cf7mc_order_created', 'sync_with_woocommerce', 10, 2);

function sync_with_woocommerce($order_id, $order_data) {
    if (!class_exists('WooCommerce')) {
        return;
    }
    
    // Create WooCommerce order
    $wc_order = wc_create_order();
    
    foreach ($order_data['items'] as $item) {
        $product_id = $item['product_id'];
        $wc_order->add_product(wc_get_product($product_id), $item['quantity']);
    }
    
    $wc_order->set_address([
        'email' => $order_data['email']
    ], 'billing');
    
    $wc_order->calculate_totals();
    $wc_order->save();
    
    // Store reference
    update_post_meta($order_id, '_wc_order_id', $wc_order->get_id());
}
```

#### Membership Plugin Integration

```php
// Grant membership access for paid orders
add_action('cf7mc_order_status_updated', 'grant_membership_access', 10, 2);

function grant_membership_access($order_id, $status) {
    if ($status !== 'paid') {
        return;
    }
    
    $order_manager = new CF7MC\Core\OrderManager();
    $order = $order_manager->get_order($order_id);
    
    // Check if order contains membership products
    foreach ($order['items'] as $item) {
        if (isset($item['membership_level'])) {
            // Grant membership (example for MemberPress)
            if (function_exists('mepr_create_transaction')) {
                $user = get_user_by('email', $order['email']);
                if ($user) {
                    // Create membership transaction
                    // Implementation depends on your membership plugin
                }
            }
        }
    }
}
```

## Styling Examples

### Custom CSS for Order Access Page

```css
/* Custom styles for order access page */
.cf7at2mc-order-access-page {
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
}

.cf7at2mc-order-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 30px;
    border-radius: 8px 8px 0 0;
    margin-bottom: 0;
}

.cf7at2mc-order-details {
    border: none;
    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
}

.cf7at2mc-status-paid {
    background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
    color: white;
}

.cf7at2mc-retry-payment-btn {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border: none;
    padding: 15px 30px;
    font-size: 16px;
    font-weight: 600;
    border-radius: 25px;
    transition: all 0.3s ease;
}

.cf7at2mc-retry-payment-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
}
```

## Testing

### Test Order Access Flow

1. Create a test order via CF7 form
2. Check email for magic link
3. Click magic link to access order
4. Test payment retry functionality
5. Verify order status updates

### Debug Mode Testing

Enable debug mode and check logs for:
- Token generation events
- Order access attempts
- Payment retry attempts
- Error messages

```php
// Enable debug logging
cf7at2mc_update_option('debug_mode', true);

// Check logs
tail -f /path/to/wordpress/wp-content/debug.log | grep CF7AT2MC
```

This completes the bridge plugin implementation with comprehensive examples and documentation.