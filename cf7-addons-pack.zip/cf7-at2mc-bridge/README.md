# CF7 Access Token to Mini Ecommerce Bridge

A WordPress plugin that bridges CF7 Access Token (Magic Link) with CF7 Mini Ecommerce for secure, passwordless order access.

## Overview

This bridge plugin connects two powerful Contact Form 7 addons:
- **CF7 Access Token**: Provides secure, passwordless access via magic links
- **CF7 Mini Ecommerce**: Handles order creation and payment processing

The bridge enables customers to access their orders securely without passwords, using magic links sent to their email addresses.

## Features

- **Automatic Token Generation**: Creates access tokens when orders are placed
- **Secure Order Access**: Customers access orders via magic links
- **Payment Retry**: Allow customers to retry failed payments
- **Order Status Tracking**: Real-time order status updates
- **Admin Dashboard**: Comprehensive admin interface for managing bridge settings
- **Debug Logging**: Built-in logging for troubleshooting

## Requirements

- WordPress 6.0+
- PHP 7.4+
- Contact Form 7 plugin
- CF7 Access Token plugin
- CF7 Mini Ecommerce plugin

## Installation

1. Upload the plugin files to `/wp-content/plugins/cf7-at2mc-bridge/`
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Ensure all required plugins are installed and activated
4. Configure settings via **CF7 Bridge > Settings**

## Configuration

### Basic Settings

1. Go to **CF7 Bridge > Settings**
2. Configure the following options:
   - **Enable Order Access**: Allow customers to access orders via magic links
   - **Auto Generate Tokens**: Automatically create tokens when orders are placed
   - **Send Access Emails**: Send magic link emails to customers
   - **Token Expiry**: How long tokens remain valid (default: 72 hours)
   - **Access Page Slug**: URL slug for order access pages

### Payment Settings

- **Allow Payment Retry**: Enable customers to retry failed payments
- **Retry Limit**: Maximum number of retry attempts (default: 3)

### Advanced Settings

- **Debug Mode**: Enable detailed logging for troubleshooting

## How It Works

### Order Creation Flow

1. Customer submits CF7 form with order details
2. CF7 Mini Ecommerce creates order with "pending" status
3. Bridge automatically generates access token for the order
4. Magic link email is sent to customer's email address
5. Customer clicks magic link to access order details

### Order Access Flow

1. Customer clicks magic link from email
2. Bridge validates token and loads order data
3. Order details are displayed with current status
4. If payment is pending/failed, retry button is shown
5. Customer can complete payment or view order information

### Payment Retry Flow

1. Customer clicks "Complete Payment" button on order access page
2. Bridge validates access permissions
3. New payment intent is created via CF7 Mini Ecommerce
4. Customer is redirected to payment gateway
5. Order status is updated based on payment result

## URL Structure

Order access URLs follow this pattern:
```
https://yoursite.com/order-access/?token=abc123...
```

The slug (`order-access`) can be customized in settings.

## Hooks and Filters

### Actions

- `cf7at2mc_init` - Fired when bridge is initialized
- `cf7at2mc_order_token_generated` - Fired when order access token is created
- `cf7at2mc_order_accessed` - Fired when customer accesses order via token
- `cf7at2mc_payment_retry_attempted` - Fired when payment retry is attempted

### Filters

- `cf7at2mc_token_expiry_hours` - Modify token expiry time
- `cf7at2mc_access_page_slug` - Modify access page URL slug
- `cf7at2mc_order_access_content` - Modify order access page content

## Security Features

- **Token Hashing**: Access tokens are securely hashed in database
- **Nonce Verification**: All AJAX requests use WordPress nonces
- **Email Validation**: Tokens are tied to specific email addresses
- **Expiration**: Tokens automatically expire after configured time
- **Usage Tracking**: Token usage is logged and monitored

## Troubleshooting

### Common Issues

1. **Missing Dependencies Error**
   - Ensure all required plugins are installed and activated
   - Check plugin versions meet minimum requirements

2. **Access Links Not Working**
   - Verify rewrite rules are flushed (deactivate/reactivate plugin)
   - Check access page slug setting
   - Ensure tokens haven't expired

3. **Payment Retry Not Working**
   - Verify payment retry is enabled in settings
   - Check order status allows retry (pending/failed)
   - Ensure CF7 Mini Ecommerce gateways are configured

### Debug Mode

Enable debug mode in settings to log detailed information:
- Token generation and validation
- Order access attempts
- Payment retry attempts
- Error messages and stack traces

Logs are written to WordPress error log and can be viewed via debug plugins or server logs.

## Support

For support and bug reports, please check:
1. Plugin settings and configuration
2. WordPress error logs
3. Required plugin versions and compatibility

## Changelog

### 1.0.0
- Initial release
- Basic bridge functionality
- Order access via magic links
- Payment retry capability
- Admin dashboard and settings
- Debug logging system

## License

This plugin is licensed under the GPL v2 or later.