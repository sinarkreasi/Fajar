/**
 * CF7 Access Token to Mini Ecommerce Bridge - Admin JavaScript
 */

(function($) {
	'use strict';
	
	// Initialize when document is ready
	$(document).ready(function() {
		CF7AT2MC_Admin.init();
	});
	
	/**
	 * Admin functionality
	 */
	var CF7AT2MC_Admin = {
		
		/**
		 * Initialize admin
		 */
		init: function() {
			this.bindEvents();
			this.initDashboard();
			this.initSettings();
		},
		
		/**
		 * Bind event handlers
		 */
		bindEvents: function() {
			// Settings reset button
			$(document).on('click', '#cf7at2mc-reset-settings', this.handleSettingsReset);
			
			// Settings form submission
			$(document).on('submit', '#cf7at2mc-settings-form', this.handleSettingsSubmit);
			
			// Test connection button
			$(document).on('click', '.cf7at2mc-test-connection', this.handleTestConnection);
			
			// Refresh logs button
			$(document).on('click', '.cf7at2mc-refresh-logs', this.handleRefreshLogs);
		},
		
		/**
		 * Initialize dashboard
		 */
		initDashboard: function() {
			// Auto-refresh dashboard widgets every 60 seconds
			if ($('.cf7at2mc-admin-dashboard').length) {
				setInterval(this.refreshDashboard, 60000);
			}
			
			// Initialize status indicators
			this.updateStatusIndicators();
		},
		
		/**
		 * Initialize settings page
		 */
		initSettings: function() {
			// Show/hide conditional fields
			this.toggleConditionalFields();
			
			// Bind conditional field toggles
			$(document).on('change', 'input[name="cf7at2mc_options[enable_order_access]"]', this.toggleConditionalFields);
			$(document).on('change', 'input[name="cf7at2mc_options[allow_payment_retry]"]', this.toggleConditionalFields);
		},
		
		/**
		 * Handle settings reset
		 */
		handleSettingsReset: function(e) {
			e.preventDefault();
			
			if (!confirm(cf7at2mc_admin.strings.confirm_reset)) {
				return;
			}
			
			var $button = $(this);
			$button.prop('disabled', true).text(cf7at2mc_admin.strings.saving);
			
			$.ajax({
				url: cf7at2mc_admin.ajax_url,
				type: 'POST',
				data: {
					action: 'cf7at2mc_reset_settings',
					nonce: cf7at2mc_admin.nonce
				},
				success: function(response) {
					if (response.success) {
						CF7AT2MC_Admin.showNotice(cf7at2mc_admin.strings.saved, 'success');
						
						// Reload page after short delay
						setTimeout(function() {
							window.location.reload();
						}, 1000);
					} else {
						CF7AT2MC_Admin.showNotice(response.data.message || 'Reset failed.', 'error');
					}
				},
				error: function() {
					CF7AT2MC_Admin.showNotice('An error occurred while resetting settings.', 'error');
				},
				complete: function() {
					$button.prop('disabled', false).text('Reset to Defaults');
				}
			});
		},
		
		/**
		 * Handle settings form submission
		 */
		handleSettingsSubmit: function(e) {
			var $form = $(this);
			var $submitBtn = $form.find('input[type="submit"]');
			
			// Add loading state
			$submitBtn.addClass('cf7at2mc-saving');
			
			// Form will submit normally, but we can add validation here
			return true;
		},
		
		/**
		 * Handle test connection
		 */
		handleTestConnection: function(e) {
			e.preventDefault();
			
			var $button = $(this);
			var testType = $button.data('test-type');
			
			$button.prop('disabled', true).text('Testing...');
			
			$.ajax({
				url: cf7at2mc_admin.ajax_url,
				type: 'POST',
				data: {
					action: 'cf7at2mc_test_connection',
					test_type: testType,
					nonce: cf7at2mc_admin.nonce
				},
				success: function(response) {
					if (response.success) {
						CF7AT2MC_Admin.showNotice('Connection test successful!', 'success');
					} else {
						CF7AT2MC_Admin.showNotice(response.data.message || 'Connection test failed.', 'error');
					}
				},
				error: function() {
					CF7AT2MC_Admin.showNotice('Connection test failed.', 'error');
				},
				complete: function() {
					$button.prop('disabled', false).text('Test Connection');
				}
			});
		},
		
		/**
		 * Handle refresh logs
		 */
		handleRefreshLogs: function(e) {
			e.preventDefault();
			
			var $button = $(this);
			var $logsContainer = $('.cf7at2mc-logs-container');
			
			$button.prop('disabled', true).text('Refreshing...');
			CF7AT2MC_Admin.showLoading($logsContainer);
			
			$.ajax({
				url: cf7at2mc_admin.ajax_url,
				type: 'POST',
				data: {
					action: 'cf7at2mc_refresh_logs',
					nonce: cf7at2mc_admin.nonce
				},
				success: function(response) {
					if (response.success && response.data.html) {
						$logsContainer.html(response.data.html);
					} else {
						CF7AT2MC_Admin.showNotice('Failed to refresh logs.', 'error');
					}
				},
				error: function() {
					CF7AT2MC_Admin.showNotice('Failed to refresh logs.', 'error');
				},
				complete: function() {
					$button.prop('disabled', false).text('Refresh Logs');
					CF7AT2MC_Admin.hideLoading($logsContainer);
				}
			});
		},
		
		/**
		 * Toggle conditional fields based on settings
		 */
		toggleConditionalFields: function() {
			// Show/hide token settings based on order access enabled
			var orderAccessEnabled = $('input[name="cf7at2mc_options[enable_order_access]"]').is(':checked');
			var $tokenFields = $('.cf7at2mc-token-fields');
			
			if (orderAccessEnabled) {
				$tokenFields.show();
			} else {
				$tokenFields.hide();
			}
			
			// Show/hide retry limit based on payment retry enabled
			var retryEnabled = $('input[name="cf7at2mc_options[allow_payment_retry]"]').is(':checked');
			var $retryFields = $('.cf7at2mc-retry-fields');
			
			if (retryEnabled) {
				$retryFields.show();
			} else {
				$retryFields.hide();
			}
		},
		
		/**
		 * Update status indicators
		 */
		updateStatusIndicators: function() {
			$('.cf7at2mc-status-indicator').each(function() {
				var $indicator = $(this);
				var status = $indicator.data('status');
				
				// Add appropriate classes based on status
				$indicator.removeClass('cf7at2mc-status-active cf7at2mc-status-inactive');
				
				if (status === 'active' || status === true) {
					$indicator.addClass('cf7at2mc-status-active');
				} else {
					$indicator.addClass('cf7at2mc-status-inactive');
				}
			});
		},
		
		/**
		 * Refresh dashboard widgets
		 */
		refreshDashboard: function() {
			$.ajax({
				url: cf7at2mc_admin.ajax_url,
				type: 'POST',
				data: {
					action: 'cf7at2mc_refresh_dashboard',
					nonce: cf7at2mc_admin.nonce
				},
				success: function(response) {
					if (response.success && response.data.widgets) {
						// Update each widget
						$.each(response.data.widgets, function(widgetId, html) {
							$('#' + widgetId).html(html);
						});
						
						// Update status indicators
						CF7AT2MC_Admin.updateStatusIndicators();
					}
				}
			});
		},
		
		/**
		 * Show admin notice
		 */
		showNotice: function(message, type) {
			type = type || 'info';
			
			// Remove existing notices
			$('.cf7at2mc-notice').remove();
			
			// Create notice element
			var $notice = $('<div class="notice cf7at2mc-notice notice-' + type + ' is-dismissible"><p>' + message + '</p></div>');
			
			// Add to page
			if ($('.wrap h1').length) {
				$('.wrap h1').after($notice);
			} else {
				$('.wrap').prepend($notice);
			}
			
			// Make dismissible
			$notice.on('click', '.notice-dismiss', function() {
				$notice.fadeOut(function() {
					$(this).remove();
				});
			});
			
			// Auto-hide success notices after 5 seconds
			if (type === 'success') {
				setTimeout(function() {
					$notice.fadeOut(function() {
						$(this).remove();
					});
				}, 5000);
			}
		},
		
		/**
		 * Show loading overlay
		 */
		showLoading: function($container) {
			$container.addClass('cf7at2mc-loading');
		},
		
		/**
		 * Hide loading overlay
		 */
		hideLoading: function($container) {
			$container.removeClass('cf7at2mc-loading');
		},
		
		/**
		 * Validate settings form
		 */
		validateSettings: function() {
			var isValid = true;
			var errors = [];
			
			// Validate token expiry hours
			var expiryHours = parseInt($('input[name="cf7at2mc_options[token_expiry_hours]"]').val());
			if (isNaN(expiryHours) || expiryHours < 1) {
				errors.push('Token expiry hours must be at least 1.');
				isValid = false;
			}
			
			// Validate access page slug
			var pageSlug = $('input[name="cf7at2mc_options[access_page_slug]"]').val().trim();
			if (!pageSlug || !/^[a-z0-9-]+$/.test(pageSlug)) {
				errors.push('Access page slug must contain only lowercase letters, numbers, and hyphens.');
				isValid = false;
			}
			
			// Validate retry limit
			var retryLimit = parseInt($('input[name="cf7at2mc_options[retry_limit]"]').val());
			if (isNaN(retryLimit) || retryLimit < 1 || retryLimit > 10) {
				errors.push('Retry limit must be between 1 and 10.');
				isValid = false;
			}
			
			// Show errors if any
			if (!isValid) {
				CF7AT2MC_Admin.showNotice('Please fix the following errors:<br>• ' + errors.join('<br>• '), 'error');
			}
			
			return isValid;
		}
	};
	
	// Form validation on submit
	$(document).on('submit', 'form[action="options.php"]', function(e) {
		if (!CF7AT2MC_Admin.validateSettings()) {
			e.preventDefault();
			return false;
		}
	});
	
	// Settings saved notice
	$(document).ready(function() {
		if (window.location.search.indexOf('settings-updated=true') !== -1) {
			CF7AT2MC_Admin.showNotice(cf7at2mc_admin.strings.saved, 'success');
		}
	});
	
	// Expose to global scope for external access
	window.CF7AT2MC_Admin = CF7AT2MC_Admin;
	
})(jQuery);