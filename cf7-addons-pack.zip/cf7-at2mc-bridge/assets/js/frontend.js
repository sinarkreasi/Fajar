/**
 * CF7 Access Token to Mini Ecommerce Bridge - Frontend JavaScript
 */

(function($) {
	'use strict';
	
	// Initialize when document is ready
	$(document).ready(function() {
		CF7AT2MC_Frontend.init();
	});
	
	/**
	 * Frontend functionality
	 */
	var CF7AT2MC_Frontend = {
		
		/**
		 * Initialize frontend
		 */
		init: function() {
			this.bindEvents();
			this.initOrderAccess();
		},
		
		/**
		 * Bind event handlers
		 */
		bindEvents: function() {
			// Payment retry button
			$(document).on('click', '.cf7at2mc-retry-payment-btn', this.handlePaymentRetry);
			
			// Order access form submission
			$(document).on('submit', '.cf7at2mc-access-form', this.handleAccessForm);
		},
		
		/**
		 * Initialize order access functionality
		 */
		initOrderAccess: function() {
			// Auto-focus on token input if present
			$('.cf7at2mc-token-input').focus();
			
			// Format amounts on page load
			this.formatAmounts();
			
			// Initialize any interactive elements
			this.initInteractiveElements();
		},
		
		/**
		 * Handle payment retry
		 */
		handlePaymentRetry: function(e) {
			e.preventDefault();
			
			var $button = $(this);
			var orderId = $button.data('order-id');
			var token = $button.data('token');
			
			// Confirm action
			if (!confirm(cf7at2mc_ajax.strings.confirm_retry)) {
				return;
			}
			
			// Disable button and show loading
			$button.prop('disabled', true).text(cf7at2mc_ajax.strings.processing);
			
			// Make AJAX request
			$.ajax({
				url: cf7at2mc_ajax.ajax_url,
				type: 'POST',
				data: {
					action: 'cf7at2mc_retry_payment',
					order_id: orderId,
					token: token,
					nonce: cf7at2mc_ajax.nonce
				},
				success: function(response) {
					if (response.success) {
						// Redirect to payment URL
						if (response.data.payment_url) {
							window.location.href = response.data.payment_url;
						} else {
							CF7AT2MC_Frontend.showMessage(response.data.message, 'success');
						}
					} else {
						CF7AT2MC_Frontend.showMessage(response.data.message, 'error');
						$button.prop('disabled', false).text(cf7at2mc_ajax.strings.confirm_retry);
					}
				},
				error: function() {
					CF7AT2MC_Frontend.showMessage('An error occurred. Please try again.', 'error');
					$button.prop('disabled', false).text(cf7at2mc_ajax.strings.confirm_retry);
				}
			});
		},
		
		/**
		 * Handle access form submission
		 */
		handleAccessForm: function(e) {
			e.preventDefault();
			
			var $form = $(this);
			var $submitBtn = $form.find('.cf7at2mc-access-submit');
			var token = $form.find('.cf7at2mc-token-input').val();
			
			if (!token.trim()) {
				CF7AT2MC_Frontend.showMessage('Please enter your access token.', 'error');
				return;
			}
			
			// Show loading state
			$submitBtn.prop('disabled', true).addClass('cf7at2mc-loading');
			
			// Redirect to access URL with token
			var accessUrl = $form.data('access-url') || window.location.href;
			var separator = accessUrl.indexOf('?') !== -1 ? '&' : '?';
			
			window.location.href = accessUrl + separator + 'token=' + encodeURIComponent(token);
		},
		
		/**
		 * Format currency amounts
		 */
		formatAmounts: function() {
			$('.cf7at2mc-amount').each(function() {
				var $el = $(this);
				var amount = parseFloat($el.text());
				
				if (!isNaN(amount)) {
					$el.text(CF7AT2MC_Frontend.formatCurrency(amount));
				}
			});
		},
		
		/**
		 * Format currency value
		 */
		formatCurrency: function(amount) {
			// Basic currency formatting - can be enhanced based on locale
			return '$' + amount.toFixed(2);
		},
		
		/**
		 * Initialize interactive elements
		 */
		initInteractiveElements: function() {
			// Copy order code functionality
			$(document).on('click', '.cf7at2mc-copy-order-code', function(e) {
				e.preventDefault();
				
				var orderCode = $(this).data('order-code');
				
				if (navigator.clipboard) {
					navigator.clipboard.writeText(orderCode).then(function() {
						CF7AT2MC_Frontend.showMessage('Order code copied to clipboard!', 'success');
					});
				} else {
					// Fallback for older browsers
					var $temp = $('<input>');
					$('body').append($temp);
					$temp.val(orderCode).select();
					document.execCommand('copy');
					$temp.remove();
					
					CF7AT2MC_Frontend.showMessage('Order code copied to clipboard!', 'success');
				}
			});
			
			// Expandable order items
			$(document).on('click', '.cf7at2mc-toggle-items', function(e) {
				e.preventDefault();
				
				var $toggle = $(this);
				var $items = $('.cf7at2mc-order-items');
				
				$items.slideToggle();
				$toggle.text($items.is(':visible') ? 'Hide Items' : 'Show Items');
			});
		},
		
		/**
		 * Show message to user
		 */
		showMessage: function(message, type) {
			type = type || 'info';
			
			// Remove existing messages
			$('.cf7at2mc-message').remove();
			
			// Create message element
			var $message = $('<div class="cf7at2mc-message cf7at2mc-message-' + type + '">' + message + '</div>');
			
			// Add to page
			if ($('.cf7at2mc-order-details').length) {
				$('.cf7at2mc-order-details').prepend($message);
			} else {
				$('.cf7at2mc-container').prepend($message);
			}
			
			// Auto-hide after 5 seconds
			setTimeout(function() {
				$message.fadeOut(function() {
					$(this).remove();
				});
			}, 5000);
		},
		
		/**
		 * Show loading overlay
		 */
		showLoading: function($container) {
			$container = $container || $('.cf7at2mc-order-details');
			$container.addClass('cf7at2mc-loading');
		},
		
		/**
		 * Hide loading overlay
		 */
		hideLoading: function($container) {
			$container = $container || $('.cf7at2mc-order-details');
			$container.removeClass('cf7at2mc-loading');
		},
		
		/**
		 * Refresh order status
		 */
		refreshOrderStatus: function() {
			var $statusElement = $('.cf7at2mc-order-status');
			
			if (!$statusElement.length) {
				return;
			}
			
			var orderId = $statusElement.data('order-id');
			
			if (!orderId) {
				return;
			}
			
			$.ajax({
				url: cf7at2mc_ajax.ajax_url,
				type: 'POST',
				data: {
					action: 'cf7at2mc_get_order_status',
					order_id: orderId,
					nonce: cf7at2mc_ajax.nonce
				},
				success: function(response) {
					if (response.success && response.data.status) {
						var newStatus = response.data.status;
						var currentStatus = $statusElement.text().toLowerCase();
						
						if (newStatus !== currentStatus) {
							// Update status display
							$statusElement
								.removeClass(function(index, className) {
									return (className.match(/(^|\s)cf7at2mc-status-\S+/g) || []).join(' ');
								})
								.addClass('cf7at2mc-status-' + newStatus)
								.text(response.data.status_label);
							
							// Show notification
							CF7AT2MC_Frontend.showMessage('Order status updated to: ' + response.data.status_label, 'success');
							
							// Reload page if status changed to paid
							if (newStatus === 'paid') {
								setTimeout(function() {
									window.location.reload();
								}, 2000);
							}
						}
					}
				}
			});
		}
	};
	
	// Auto-refresh order status every 30 seconds for pending orders
	$(document).ready(function() {
		var $status = $('.cf7at2mc-order-status');
		
		if ($status.hasClass('cf7at2mc-status-pending')) {
			setInterval(function() {
				CF7AT2MC_Frontend.refreshOrderStatus();
			}, 30000); // 30 seconds
		}
	});
	
	// Expose to global scope for external access
	window.CF7AT2MC_Frontend = CF7AT2MC_Frontend;
	
})(jQuery);