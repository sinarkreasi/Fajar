<?php

namespace CF7AT2MC\Interfaces;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Magic Order Bridge Interface
 */
interface MagicOrderBridgeInterface {
	
	/**
	 * Generate access token for order
	 *
	 * @param int $order_id Order ID
	 * @param string $email Customer email
	 * @return int|false Token ID or false on failure
	 */
	public function generate_order_token( $order_id, $email );
	
	/**
	 * Resolve order from token
	 *
	 * @param string $token Raw token
	 * @return array|false Order data or false if invalid
	 */
	public function resolve_order_from_token( $token );
	
	/**
	 * Validate token and get order access
	 *
	 * @param string $token Raw token
	 * @return array Validation result with order data
	 */
	public function validate_order_access( $token );
	
	/**
	 * Check if order can be accessed with token
	 *
	 * @param array $token_data Token data
	 * @param int $order_id Order ID
	 * @return bool
	 */
	public function can_access_order( $token_data, $order_id );
}