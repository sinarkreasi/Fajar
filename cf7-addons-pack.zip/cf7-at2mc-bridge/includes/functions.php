<?php

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Check if order access is enabled
 *
 * @return bool
 */
function cf7at2mc_is_order_access_enabled() {
	return CF7AT2MC\Core\OptionsManager::get( 'enable_order_access', true );
}

/**
 * Get token expiry hours
 *
 * @return int
 */
function cf7at2mc_get_token_expiry_hours() {
	return CF7AT2MC\Core\OptionsManager::get( 'token_expiry_hours', 72 );
}

/**
 * Get access page slug
 *
 * @return string
 */
function cf7at2mc_get_access_page_slug() {
	return CF7AT2MC\Core\OptionsManager::get( 'access_page_slug', 'order-access' );
}

/**
 * Log message
 *
 * @param string $message Log message
 * @param string $level Log level (info, warning, error)
 */
function cf7at2mc_log( $message, $level = 'info' ) {
	if ( ! CF7AT2MC\Core\OptionsManager::get( 'debug_mode', false ) ) {
		return;
	}
	
	$log_entry = sprintf(
		'[%s] CF7AT2MC %s: %s',
		current_time( 'Y-m-d H:i:s' ),
		strtoupper( $level ),
		$message
	);
	
	error_log( $log_entry );
}

/**
 * Format amount for display
 *
 * @param float $amount Amount to format
 * @return string Formatted amount
 */
function cf7at2mc_format_amount( $amount ) {
	// Use CF7MC function if available
	if ( function_exists( 'cf7mc_format_amount' ) ) {
		return cf7mc_format_amount( $amount );
	}
	
	// Basic formatting - can be enhanced with currency settings
	return '$' . number_format( (float) $amount, 2 );
}

/**
 * Format date for display
 *
 * @param string $date MySQL datetime
 * @return string Formatted date
 */
function cf7at2mc_format_date( $date ) {
	return date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $date ) );
}

/**
 * Get status label
 *
 * @param string $status Status key
 * @return string Status label
 */
function cf7at2mc_get_status_label( $status ) {
	$labels = array(
		'pending' => __( 'Pending Payment', CF7AT2MC_TEXT_DOMAIN ),
		'paid'    => __( 'Paid', CF7AT2MC_TEXT_DOMAIN ),
		'failed'  => __( 'Payment Failed', CF7AT2MC_TEXT_DOMAIN ),
		'expired' => __( 'Expired', CF7AT2MC_TEXT_DOMAIN ),
	);
	
	return isset( $labels[ $status ] ) ? $labels[ $status ] : ucfirst( $status );
}

/**
 * Get gateway label
 *
 * @param string $gateway Gateway key
 * @return string Gateway label
 */
function cf7at2mc_get_gateway_label( $gateway ) {
	$labels = array(
		'whatsapp' => __( 'WhatsApp Checkout', CF7AT2MC_TEXT_DOMAIN ),
		'tripay'   => __( 'TriPay', CF7AT2MC_TEXT_DOMAIN ),
		'paypal'   => __( 'PayPal', CF7AT2MC_TEXT_DOMAIN ),
	);
	
	return isset( $labels[ $gateway ] ) ? $labels[ $gateway ] : ucfirst( $gateway );
}

/**
 * Get gateway class name
 *
 * @param string $gateway Gateway key
 * @return string|false Gateway class name or false if not found
 */
function cf7mc_get_gateway_class( $gateway ) {
	$gateways = array(
		'whatsapp' => 'CF7MC\Gateways\WhatsAppGateway',
		'tripay'   => 'CF7MC\Gateways\TriPayGateway',
		'paypal'   => 'CF7MC\Gateways\PayPalGateway',
	);
	
	if ( isset( $gateways[ $gateway ] ) && class_exists( $gateways[ $gateway ] ) ) {
		return $gateways[ $gateway ];
	}
	
	return false;
}

/**
 * Get recent access logs
 *
 * @param int $limit Number of logs to retrieve
 * @return array Access logs
 */
function cf7at2mc_get_recent_access_logs( $limit = 10 ) {
	// This would typically query a custom log table
	// For now, return empty array as logs aren't implemented yet
	return array();
}

/**
 * Get access logs
 *
 * @param array $args Query arguments
 * @return array Access logs
 */
function cf7at2mc_get_access_logs( $args = array() ) {
	// This would typically query a custom log table
	// For now, return empty array as logs aren't implemented yet
	return array();
}

/**
 * Generate secure access URL
 *
 * @param string $token Access token
 * @return string Access URL
 */
function cf7at2mc_generate_access_url( $token ) {
	$slug = cf7at2mc_get_access_page_slug();
	return home_url( $slug . '/?token=' . urlencode( $token ) );
}

/**
 * Check if current request is for order access
 *
 * @return bool
 */
function cf7at2mc_is_order_access_request() {
	return get_query_var( 'cf7at2mc_order_access' ) || get_query_var( 'cf7at_access' );
}

/**
 * Get bridge version
 *
 * @return string
 */
function cf7at2mc_get_version() {
	return CF7AT2MC_VERSION;
}

/**
 * Get missing dependencies
 *
 * @return array Missing plugin names
 */
function cf7at2mc_get_missing_dependencies() {
	return CF7AT2MC\Core\StatusChecker::get_missing_dependencies();
}

/**
 * Get plugin status
 *
 * @return array Plugin status information
 */
function cf7at2mc_get_plugin_status() {
	$status = cf7at2mc_get_status();
	return $status;
}

/**
 * Check if payment retry is allowed
 *
 * @return bool
 */
function cf7at2mc_is_payment_retry_allowed() {
	return CF7AT2MC\Core\OptionsManager::get( 'allow_payment_retry', true );
}

/**
 * Get retry limit
 *
 * @return int
 */
function cf7at2mc_get_retry_limit() {
	return CF7AT2MC\Core\OptionsManager::get( 'retry_limit', 3 );
}

/**
 * Check if order status allows payment retry
 *
 * @param string $status Order status
 * @return bool
 */
function cf7at2mc_can_retry_payment( $status ) {
	$retryable_statuses = array( 'pending', 'failed' );
	return in_array( $status, $retryable_statuses ) && cf7at2mc_is_payment_retry_allowed();
}

/**
 * Get order status CSS class
 *
 * @param string $status Order status
 * @return string CSS class
 */
function cf7at2mc_get_status_class( $status ) {
	$classes = array(
		'pending' => 'cf7at2mc-status-pending',
		'paid'    => 'cf7at2mc-status-paid',
		'failed'  => 'cf7at2mc-status-failed',
		'expired' => 'cf7at2mc-status-expired',
	);
	
	return isset( $classes[ $status ] ) ? $classes[ $status ] : 'cf7at2mc-status-unknown';
}

/**
 * Verify nonce for security
 *
 * @param string $nonce Nonce value
 * @param string $action Nonce action
 * @return bool
 */
function cf7at2mc_verify_nonce( $nonce, $action ) {
	return wp_verify_nonce( $nonce, $action );
}

/**
 * Sanitize order status
 *
 * @param string $status Raw status
 * @return string Sanitized status
 */
function cf7at2mc_sanitize_status( $status ) {
	$allowed_statuses = array( 'pending', 'paid', 'failed', 'expired' );
	return in_array( $status, $allowed_statuses ) ? $status : 'pending';
}

/**
 * Get plugin option with fallback
 *
 * @param string $name Option name
 * @param mixed $default Default value
 * @return mixed Option value
 */
function cf7at2mc_get_option( $name, $default = false ) {
	return CF7AT2MC\Core\OptionsManager::get( $name, $default );
}

/**
 * Update plugin option
 *
 * @param string $name Option name
 * @param mixed $value Option value
 * @return bool Success status
 */
function cf7at2mc_update_option( $name, $value ) {
	return CF7AT2MC\Core\OptionsManager::set( $name, $value );
}

/**
 * Get bridge status
 *
 * @return array Status information
 */
function cf7at2mc_get_status() {
	return CF7AT2MC\Core\StatusChecker::get_status();
}

/**
 * Check if bridge is ready to use
 *
 * @return bool
 */
function cf7at2mc_is_ready() {
	$status = cf7at2mc_get_status();
	return $status['functional'];
}