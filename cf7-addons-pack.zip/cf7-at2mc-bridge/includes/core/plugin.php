<?php

namespace CF7AT2MC\Core;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Main plugin class
 */
class Plugin {
	
	/**
	 * Plugin instance
	 *
	 * @var Plugin
	 */
	private static $instance = null;
	
	/**
	 * Get plugin instance
	 *
	 * @return Plugin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		$this->init_hooks();
	}
	
	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
		add_action( 'init', array( $this, 'init_rewrite_rules' ) );
	}
	
	/**
	 * Enqueue frontend scripts
	 */
	public function enqueue_scripts() {
		// Only enqueue on order access pages
		if ( ! $this->is_order_access_page() ) {
			return;
		}
		
		wp_enqueue_style( 
			'cf7at2mc-frontend', 
			CF7AT2MC_PLUGIN_URL . '/assets/css/frontend.css', 
			array(), 
			CF7AT2MC_VERSION 
		);
		
		wp_enqueue_script( 
			'cf7at2mc-frontend', 
			CF7AT2MC_PLUGIN_URL . '/assets/js/frontend.js', 
			array( 'jquery' ), 
			CF7AT2MC_VERSION, 
			true 
		);
		
		wp_localize_script( 'cf7at2mc-frontend', 'cf7at2mc_ajax', array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'cf7at2mc_frontend' ),
			'strings'  => array(
				'confirm_retry' => __( 'Retry payment for this order?', CF7AT2MC_TEXT_DOMAIN ),
				'processing'    => __( 'Processing...', CF7AT2MC_TEXT_DOMAIN ),
			),
		));
	}
	
	/**
	 * Initialize rewrite rules
	 */
	public function init_rewrite_rules() {
		$access_slug = cf7at2mc_get_access_page_slug();
		
		// Add rewrite rule for order access pages
		add_rewrite_rule( 
			"^{$access_slug}/?$", 
			'index.php?cf7at2mc_order_access=1', 
			'top' 
		);
		
		// Add query vars
		add_filter( 'query_vars', function( $vars ) {
			$vars[] = 'cf7at2mc_order_access';
			return $vars;
		});
	}
	
	/**
	 * Check if current page is order access page
	 *
	 * @return bool
	 */
	private function is_order_access_page() {
		return get_query_var( 'cf7at2mc_order_access' ) || get_query_var( 'cf7at_access' );
	}
}