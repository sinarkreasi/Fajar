<?php

namespace CF7AT2MC\Core;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Status checker for bridge plugin
 */
class StatusChecker {
	
	/**
	 * Check if all dependencies are available
	 *
	 * @return array Status information
	 */
	public static function check_dependencies() {
		$status = array(
			'cf7'    => class_exists( 'WPCF7' ),
			'cf7at'  => defined( 'CF7AT_VERSION' ),
			'cf7mc'  => defined( 'CF7MC_VERSION' ),
		);
		
		$status['all_ready'] = $status['cf7'] && $status['cf7at'] && $status['cf7mc'];
		
		return $status;
	}
	
	/**
	 * Get missing dependencies
	 *
	 * @return array Missing plugin names
	 */
	public static function get_missing_dependencies() {
		$missing = array();
		
		if ( ! class_exists( 'WPCF7' ) ) {
			$missing[] = 'Contact Form 7';
		}
		
		if ( ! defined( 'CF7AT_VERSION' ) ) {
			$missing[] = 'CF7 Access Token';
		}
		
		if ( ! defined( 'CF7MC_VERSION' ) ) {
			$missing[] = 'CF7 Mini Ecommerce';
		}
		
		return $missing;
	}
	
	/**
	 * Check if bridge is properly configured
	 *
	 * @return bool
	 */
	public static function is_configured() {
		// Check if basic options are set
		$required_options = array(
			'enable_order_access',
			'token_expiry_hours',
			'access_page_slug',
		);
		
		foreach ( $required_options as $option ) {
			$value = OptionsManager::get( $option );
			if ( empty( $value ) && $value !== false ) {
				return false;
			}
		}
		
		return true;
	}
	
	/**
	 * Get plugin status summary
	 *
	 * @return array Complete status information
	 */
	public static function get_status() {
		$dependencies = self::check_dependencies();
		$missing = self::get_missing_dependencies();
		
		return array(
			'version'        => CF7AT2MC_VERSION,
			'dependencies'   => $dependencies,
			'missing'        => $missing,
			'ready'          => $dependencies['all_ready'],
			'configured'     => self::is_configured(),
			'functional'     => $dependencies['all_ready'] && self::is_configured(),
		);
	}
}