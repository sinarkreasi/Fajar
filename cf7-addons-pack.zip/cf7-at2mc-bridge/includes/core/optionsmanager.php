<?php

namespace CF7AT2MC\Core;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Options management class
 */
class OptionsManager {
	
	/**
	 * Option prefix
	 */
	const OPTION_PREFIX = 'cf7at2mc_';
	
	/**
	 * Default options
	 */
	private static $defaults = array(
		'enable_order_access'    => true,
		'token_expiry_hours'     => 72,
		'access_page_slug'       => 'order-access',
		'auto_generate_tokens'   => true,
		'send_access_emails'     => true,
		'allow_payment_retry'    => true,
		'retry_limit'            => 3,
		'email_template'         => 'default',
		'debug_mode'             => false,
	);
	
	/**
	 * Get option value
	 *
	 * @param string $key Option key
	 * @param mixed $default Default value
	 * @return mixed
	 */
	public static function get( $key, $default = null ) {
		$option_name = self::OPTION_PREFIX . $key;
		
		if ( $default === null && isset( self::$defaults[ $key ] ) ) {
			$default = self::$defaults[ $key ];
		}
		
		return get_option( $option_name, $default );
	}
	
	/**
	 * Set option value
	 *
	 * @param string $key Option key
	 * @param mixed $value Option value
	 * @return bool
	 */
	public static function set( $key, $value ) {
		$option_name = self::OPTION_PREFIX . $key;
		return update_option( $option_name, $value );
	}
	
	/**
	 * Delete option
	 *
	 * @param string $key Option key
	 * @return bool
	 */
	public static function delete( $key ) {
		$option_name = self::OPTION_PREFIX . $key;
		return delete_option( $option_name );
	}
	
	/**
	 * Get all options
	 *
	 * @return array
	 */
	public static function get_all() {
		$options = array();
		
		foreach ( self::$defaults as $key => $default ) {
			$options[ $key ] = self::get( $key, $default );
		}
		
		return $options;
	}
	
	/**
	 * Set default options
	 */
	public static function set_defaults() {
		foreach ( self::$defaults as $key => $value ) {
			$option_name = self::OPTION_PREFIX . $key;
			
			// Only set if option doesn't exist
			if ( get_option( $option_name ) === false ) {
				update_option( $option_name, $value );
			}
		}
	}
	
	/**
	 * Reset all options to defaults
	 */
	public static function reset_to_defaults() {
		foreach ( self::$defaults as $key => $value ) {
			self::set( $key, $value );
		}
	}
	
	/**
	 * Get default options
	 *
	 * @return array
	 */
	public static function get_defaults() {
		return self::$defaults;
	}
	
	/**
	 * Validate option value
	 *
	 * @param string $key Option key
	 * @param mixed $value Option value
	 * @return mixed Validated value
	 */
	public static function validate( $key, $value ) {
		switch ( $key ) {
			case 'enable_order_access':
			case 'auto_generate_tokens':
			case 'send_access_emails':
			case 'allow_payment_retry':
			case 'debug_mode':
				return (bool) $value;
				
			case 'token_expiry_hours':
			case 'retry_limit':
				return max( 1, absint( $value ) );
				
			case 'access_page_slug':
				return sanitize_title( $value );
				
			case 'email_template':
				return sanitize_text_field( $value );
				
			default:
				return $value;
		}
	}
	
	/**
	 * Update multiple options at once
	 *
	 * @param array $options Key-value pairs
	 * @return bool
	 */
	public static function update_multiple( $options ) {
		$success = true;
		
		foreach ( $options as $key => $value ) {
			$validated_value = self::validate( $key, $value );
			
			if ( ! self::set( $key, $validated_value ) ) {
				$success = false;
			}
		}
		
		return $success;
	}
}