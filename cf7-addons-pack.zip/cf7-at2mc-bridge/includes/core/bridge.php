<?php

namespace CF7AT2MC\Core;

use CF7AT2MC\Interfaces\MagicOrderBridgeInterface;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Main bridge class connecting CF7 Access Token with CF7 Mini Ecommerce
 */
class Bridge implements MagicOrderBridgeInterface {
	
	/**
	 * Bridge instance
	 *
	 * @var Bridge
	 */
	private static $instance = null;
	
	/**
	 * Get bridge instance
	 *
	 * @return Bridge
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		$this->init_hooks();
	}
	
	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		// Hook into CF7MC order creation
		add_action( 'cf7mc_order_created', array( $this, 'on_order_created' ), 10, 2 );
		
		// Hook into CF7MC payment status updates
		add_action( 'cf7mc_order_status_updated', array( $this, 'on_order_status_updated' ), 10, 2 );
		
		// Hook into CF7AT token validation for order access
		add_filter( 'cf7at_can_access_resource', array( $this, 'validate_order_resource_access' ), 10, 4 );
		
		// Add order-specific content rendering
		add_action( 'cf7at_render_protected_content', array( $this, 'render_order_content' ), 10, 1 );
	}
	
	/**
	 * Generate access token for order
	 *
	 * @param int $order_id Order ID
	 * @param string $email Customer email
	 * @return int|false Token ID or false on failure
	 */
	public function generate_order_token( $order_id, $email ) {
		if ( ! cf7at2mc_is_order_access_enabled() ) {
			return false;
		}
		
		// Validate order exists
		if ( ! class_exists( 'CF7MC\Core\OrderManager' ) ) {
			cf7at2mc_log( 'CF7MC OrderManager class not found', 'error' );
			return false;
		}
		
		$order_manager = new \CF7MC\Core\OrderManager();
		$order = $order_manager->get_order( $order_id );
		
		if ( ! $order ) {
			cf7at2mc_log( "Order not found: {$order_id}", 'error' );
			return false;
		}
		
		// Validate email matches order
		if ( $order['email'] !== $email ) {
			cf7at2mc_log( "Email mismatch for order {$order_id}", 'error' );
			return false;
		}
		
		// Generate token using CF7AT
		if ( ! class_exists( 'CF7AT\Core\TokenManager' ) ) {
			cf7at2mc_log( 'CF7AT TokenManager class not found', 'error' );
			return false;
		}
		
		$token_manager = new \CF7AT\Core\TokenManager();
		
		$token_data = array(
			'related_type' => 'order',
			'related_id'   => $order_id,
			'email'        => $email,
			'expires_at'   => $this->calculate_token_expiry(),
			'usage_limit'  => null, // Allow unlimited access for orders
			'metadata'     => array(
				'order_code'   => $order['order_code'],
				'total_amount' => $order['total_amount'],
				'gateway'      => $order['gateway'],
				'bridge_version' => CF7AT2MC_VERSION,
			),
		);
		
		$token_id = $token_manager->create_token( $token_data );
		
		if ( $token_id ) {
			cf7at2mc_log( "Order token created: token_id={$token_id}, order_id={$order_id}" );
			
			// Send magic link email
			$this->send_order_access_email( $token_id, $order );
		}
		
		return $token_id;
	}
	
	/**
	 * Resolve order from token
	 *
	 * @param string $token Raw token
	 * @return array|false Order data or false if invalid
	 */
	public function resolve_order_from_token( $token ) {
		$validation_result = $this->validate_order_access( $token );
		
		if ( ! $validation_result['valid'] ) {
			return false;
		}
		
		return $validation_result['order'];
	}
	
	/**
	 * Validate token and get order access
	 *
	 * @param string $token Raw token
	 * @return array Validation result with order data
	 */
	public function validate_order_access( $token ) {
		// Validate token using CF7AT
		if ( ! class_exists( 'CF7AT\Core\AccessValidator' ) ) {
			return array(
				'valid'   => false,
				'error'   => 'cf7at_not_available',
				'message' => __( 'Access Token system not available.', CF7AT2MC_TEXT_DOMAIN ),
			);
		}
		
		$validator = new \CF7AT\Core\AccessValidator();
		$validation_result = $validator->validate_access( $token );
		
		if ( ! $validation_result['valid'] ) {
			return $validation_result;
		}
		
		$token_data = $validation_result['token_data'];
		
		// Ensure token is for an order
		if ( $token_data['related_type'] !== 'order' ) {
			return array(
				'valid'   => false,
				'error'   => 'invalid_resource_type',
				'message' => __( 'This token is not for order access.', CF7AT2MC_TEXT_DOMAIN ),
			);
		}
		
		// Load order data
		if ( ! class_exists( 'CF7MC\Core\OrderManager' ) ) {
			return array(
				'valid'   => false,
				'error'   => 'cf7mc_not_available',
				'message' => __( 'Mini Ecommerce system not available.', CF7AT2MC_TEXT_DOMAIN ),
			);
		}
		
		$order_manager = new \CF7MC\Core\OrderManager();
		$order = $order_manager->get_order( $token_data['related_id'] );
		
		if ( ! $order ) {
			return array(
				'valid'   => false,
				'error'   => 'order_not_found',
				'message' => __( 'Order not found.', CF7AT2MC_TEXT_DOMAIN ),
			);
		}
		
		// Validate email matches
		if ( $order['email'] !== $token_data['email'] ) {
			return array(
				'valid'   => false,
				'error'   => 'email_mismatch',
				'message' => __( 'Access denied.', CF7AT2MC_TEXT_DOMAIN ),
			);
		}
		
		return array(
			'valid'      => true,
			'token_data' => $token_data,
			'order'      => $order,
			'message'    => __( 'Order access granted.', CF7AT2MC_TEXT_DOMAIN ),
		);
	}
	
	/**
	 * Check if order can be accessed with token
	 *
	 * @param array $token_data Token data
	 * @param int $order_id Order ID
	 * @return bool
	 */
	public function can_access_order( $token_data, $order_id ) {
		return $token_data['related_type'] === 'order' && $token_data['related_id'] == $order_id;
	}
	
	/**
	 * Handle order creation
	 *
	 * @param int $order_id Order ID
	 * @param array $order_data Order data
	 */
	public function on_order_created( $order_id, $order_data ) {
		if ( ! cf7at2mc_is_order_access_enabled() ) {
			return;
		}
		
		// Generate access token for the order
		$token_id = $this->generate_order_token( $order_id, $order_data['email'] );
		
		if ( $token_id ) {
			cf7at2mc_log( "Order access token generated for order {$order_id}" );
		} else {
			cf7at2mc_log( "Failed to generate access token for order {$order_id}", 'error' );
		}
	}
	
	/**
	 * Handle order status updates
	 *
	 * @param int $order_id Order ID
	 * @param string $status New status
	 */
	public function on_order_status_updated( $order_id, $status ) {
		cf7at2mc_log( "Order {$order_id} status updated to {$status}" );
		
		// Could implement additional logic here, such as:
		// - Extending token expiry for failed payments
		// - Revoking tokens for completed orders (optional)
		// - Sending status update emails
	}
	
	/**
	 * Validate order resource access for CF7AT
	 *
	 * @param bool $can_access Current access permission
	 * @param array $token_data Token data
	 * @param string $resource_type Resource type
	 * @param int $resource_id Resource ID
	 * @return bool
	 */
	public function validate_order_resource_access( $can_access, $token_data, $resource_type, $resource_id ) {
		if ( $resource_type === 'order' ) {
			return $this->can_access_order( $token_data, $resource_id );
		}
		
		return $can_access;
	}
	
	/**
	 * Render order content for CF7AT protected content
	 *
	 * @param array $token_data Token data
	 */
	public function render_order_content( $token_data ) {
		if ( $token_data['related_type'] !== 'order' ) {
			return;
		}
		
		// Redirect to order access controller
		$order_access_controller = \CF7AT2MC\Frontend\OrderAccessController::instance();
		$order_access_controller->render_order_access_content( $token_data );
	}
	
	/**
	 * Calculate token expiry time
	 *
	 * @return string MySQL datetime
	 */
	private function calculate_token_expiry() {
		$hours = cf7at2mc_get_token_expiry_hours();
		return date( 'Y-m-d H:i:s', time() + ( $hours * HOUR_IN_SECONDS ) );
	}
	
	/**
	 * Send order access email
	 *
	 * @param int $token_id Token ID
	 * @param array $order Order data
	 */
	private function send_order_access_email( $token_id, $order ) {
		// Use CF7AT email system if available
		if ( class_exists( 'CF7AT\Emails\EmailBuilder' ) ) {
			$email_builder = new \CF7AT\Emails\EmailBuilder();
			$email_builder->send_magic_link_email( $token_id, $order['email'] );
		}
	}
}