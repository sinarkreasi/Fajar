<?php

namespace CF7AT2MC\Admin;

use CF7AT2MC\Core\OptionsManager;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin initialization class
 */
class AdminInit {
	
	/**
	 * Admin instance
	 *
	 * @var AdminInit
	 */
	private static $instance = null;
	
	/**
	 * Get admin instance
	 *
	 * @return AdminInit
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		$this->init_hooks();
	}
	
	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_notices', array( $this, 'show_admin_notices' ) );
	}
	
	/**
	 * Add admin menu
	 */
	public function add_admin_menu() {
		// Add main menu page
		add_menu_page(
			__( 'CF7 Bridge', CF7AT2MC_TEXT_DOMAIN ),
			__( 'CF7 Bridge', CF7AT2MC_TEXT_DOMAIN ),
			'manage_options',
			'cf7at2mc-bridge',
			array( $this, 'render_main_page' ),
			'dashicons-admin-links',
			30
		);
		
		// Add settings submenu
		add_submenu_page(
			'cf7at2mc-bridge',
			__( 'Bridge Settings', CF7AT2MC_TEXT_DOMAIN ),
			__( 'Settings', CF7AT2MC_TEXT_DOMAIN ),
			'manage_options',
			'cf7at2mc-settings',
			array( $this, 'render_settings_page' )
		);
		
		// Add order access submenu
		add_submenu_page(
			'cf7at2mc-bridge',
			__( 'Order Access Logs', CF7AT2MC_TEXT_DOMAIN ),
			__( 'Access Logs', CF7AT2MC_TEXT_DOMAIN ),
			'manage_options',
			'cf7at2mc-logs',
			array( $this, 'render_logs_page' )
		);
	}
	
	/**
	 * Enqueue admin scripts
	 *
	 * @param string $hook Current admin page hook
	 */
	public function enqueue_admin_scripts( $hook ) {
		// Only load on our admin pages
		if ( strpos( $hook, 'cf7at2mc' ) === false ) {
			return;
		}
		
		wp_enqueue_style(
			'cf7at2mc-admin',
			CF7AT2MC_PLUGIN_URL . '/assets/css/admin.css',
			array(),
			CF7AT2MC_VERSION
		);
		
		wp_enqueue_script(
			'cf7at2mc-admin',
			CF7AT2MC_PLUGIN_URL . '/assets/js/admin.js',
			array( 'jquery' ),
			CF7AT2MC_VERSION,
			true
		);
		
		wp_localize_script( 'cf7at2mc-admin', 'cf7at2mc_admin', array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'cf7at2mc_admin' ),
			'strings'  => array(
				'confirm_reset' => __( 'Are you sure you want to reset all settings to defaults?', CF7AT2MC_TEXT_DOMAIN ),
				'saving'        => __( 'Saving...', CF7AT2MC_TEXT_DOMAIN ),
				'saved'         => __( 'Settings saved!', CF7AT2MC_TEXT_DOMAIN ),
			),
		));
	}
	
	/**
	 * Register settings
	 */
	public function register_settings() {
		register_setting( 'cf7at2mc_settings', 'cf7at2mc_options', array(
			'sanitize_callback' => array( $this, 'sanitize_settings' ),
		));
		
		// General settings section
		add_settings_section(
			'cf7at2mc_general',
			__( 'General Settings', CF7AT2MC_TEXT_DOMAIN ),
			array( $this, 'render_general_section' ),
			'cf7at2mc_settings'
		);
		
		// Order access settings
		add_settings_field(
			'enable_order_access',
			__( 'Enable Order Access', CF7AT2MC_TEXT_DOMAIN ),
			array( $this, 'render_checkbox_field' ),
			'cf7at2mc_settings',
			'cf7at2mc_general',
			array(
				'key'         => 'enable_order_access',
				'description' => __( 'Allow customers to access their orders via magic links.', CF7AT2MC_TEXT_DOMAIN ),
			)
		);
		
		add_settings_field(
			'auto_generate_tokens',
			__( 'Auto Generate Tokens', CF7AT2MC_TEXT_DOMAIN ),
			array( $this, 'render_checkbox_field' ),
			'cf7at2mc_settings',
			'cf7at2mc_general',
			array(
				'key'         => 'auto_generate_tokens',
				'description' => __( 'Automatically generate access tokens when orders are created.', CF7AT2MC_TEXT_DOMAIN ),
			)
		);
		
		add_settings_field(
			'send_access_emails',
			__( 'Send Access Emails', CF7AT2MC_TEXT_DOMAIN ),
			array( $this, 'render_checkbox_field' ),
			'cf7at2mc_settings',
			'cf7at2mc_general',
			array(
				'key'         => 'send_access_emails',
				'description' => __( 'Send magic link emails to customers for order access.', CF7AT2MC_TEXT_DOMAIN ),
			)
		);
		
		// Token settings section
		add_settings_section(
			'cf7at2mc_tokens',
			__( 'Token Settings', CF7AT2MC_TEXT_DOMAIN ),
			array( $this, 'render_tokens_section' ),
			'cf7at2mc_settings'
		);
		
		add_settings_field(
			'token_expiry_hours',
			__( 'Token Expiry (Hours)', CF7AT2MC_TEXT_DOMAIN ),
			array( $this, 'render_number_field' ),
			'cf7at2mc_settings',
			'cf7at2mc_tokens',
			array(
				'key'         => 'token_expiry_hours',
				'min'         => 1,
				'max'         => 8760, // 1 year
				'description' => __( 'How long order access tokens remain valid (in hours).', CF7AT2MC_TEXT_DOMAIN ),
			)
		);
		
		add_settings_field(
			'access_page_slug',
			__( 'Access Page Slug', CF7AT2MC_TEXT_DOMAIN ),
			array( $this, 'render_text_field' ),
			'cf7at2mc_settings',
			'cf7at2mc_tokens',
			array(
				'key'         => 'access_page_slug',
				'description' => __( 'URL slug for order access pages (e.g., "order-access").', CF7AT2MC_TEXT_DOMAIN ),
			)
		);
		
		// Payment settings section
		add_settings_section(
			'cf7at2mc_payment',
			__( 'Payment Settings', CF7AT2MC_TEXT_DOMAIN ),
			array( $this, 'render_payment_section' ),
			'cf7at2mc_settings'
		);
		
		add_settings_field(
			'allow_payment_retry',
			__( 'Allow Payment Retry', CF7AT2MC_TEXT_DOMAIN ),
			array( $this, 'render_checkbox_field' ),
			'cf7at2mc_settings',
			'cf7at2mc_payment',
			array(
				'key'         => 'allow_payment_retry',
				'description' => __( 'Allow customers to retry failed payments from order access page.', CF7AT2MC_TEXT_DOMAIN ),
			)
		);
		
		add_settings_field(
			'retry_limit',
			__( 'Retry Limit', CF7AT2MC_TEXT_DOMAIN ),
			array( $this, 'render_number_field' ),
			'cf7at2mc_settings',
			'cf7at2mc_payment',
			array(
				'key'         => 'retry_limit',
				'min'         => 1,
				'max'         => 10,
				'description' => __( 'Maximum number of payment retry attempts allowed.', CF7AT2MC_TEXT_DOMAIN ),
			)
		);
		
		// Advanced settings section
		add_settings_section(
			'cf7at2mc_advanced',
			__( 'Advanced Settings', CF7AT2MC_TEXT_DOMAIN ),
			array( $this, 'render_advanced_section' ),
			'cf7at2mc_settings'
		);
		
		add_settings_field(
			'debug_mode',
			__( 'Debug Mode', CF7AT2MC_TEXT_DOMAIN ),
			array( $this, 'render_checkbox_field' ),
			'cf7at2mc_settings',
			'cf7at2mc_advanced',
			array(
				'key'         => 'debug_mode',
				'description' => __( 'Enable debug logging for troubleshooting.', CF7AT2MC_TEXT_DOMAIN ),
			)
		);
	}
	
	/**
	 * Sanitize settings
	 *
	 * @param array $input Raw input
	 * @return array Sanitized input
	 */
	public function sanitize_settings( $input ) {
		$sanitized = array();
		
		foreach ( $input as $key => $value ) {
			$sanitized[ $key ] = OptionsManager::validate( $key, $value );
		}
		
		return $sanitized;
	}
	
	/**
	 * Render main admin page
	 */
	public function render_main_page() {
		?>
		<div class="wrap">
			<h1><?php _e( 'CF7 Access Token to Mini Ecommerce Bridge', CF7AT2MC_TEXT_DOMAIN ); ?></h1>
			
			<div class="cf7at2mc-admin-dashboard">
				<div class="cf7at2mc-dashboard-widgets">
					<div class="cf7at2mc-widget">
						<h2><?php _e( 'Bridge Status', CF7AT2MC_TEXT_DOMAIN ); ?></h2>
						<?php $this->render_bridge_status(); ?>
					</div>
					
					<div class="cf7at2mc-widget">
						<h2><?php _e( 'Recent Activity', CF7AT2MC_TEXT_DOMAIN ); ?></h2>
						<?php $this->render_recent_activity(); ?>
					</div>
					
					<div class="cf7at2mc-widget">
						<h2><?php _e( 'Quick Actions', CF7AT2MC_TEXT_DOMAIN ); ?></h2>
						<?php $this->render_quick_actions(); ?>
					</div>
				</div>
			</div>
		</div>
		<?php
	}
	
	/**
	 * Render settings page
	 */
	public function render_settings_page() {
		?>
		<div class="wrap">
			<h1><?php _e( 'Bridge Settings', CF7AT2MC_TEXT_DOMAIN ); ?></h1>
			
			<form method="post" action="options.php">
				<?php
				settings_fields( 'cf7at2mc_settings' );
				do_settings_sections( 'cf7at2mc_settings' );
				submit_button();
				?>
			</form>
			
			<div class="cf7at2mc-settings-actions">
				<button type="button" class="button" id="cf7at2mc-reset-settings">
					<?php _e( 'Reset to Defaults', CF7AT2MC_TEXT_DOMAIN ); ?>
				</button>
			</div>
		</div>
		<?php
	}
	
	/**
	 * Render logs page
	 */
	public function render_logs_page() {
		?>
		<div class="wrap">
			<h1><?php _e( 'Order Access Logs', CF7AT2MC_TEXT_DOMAIN ); ?></h1>
			
			<div class="cf7at2mc-logs-container">
				<?php $this->render_access_logs(); ?>
			</div>
		</div>
		<?php
	}
	
	/**
	 * Render bridge status widget
	 */
	private function render_bridge_status() {
		$dependencies = array(
			'Contact Form 7'      => class_exists( 'WPCF7' ),
			'CF7 Access Token'    => defined( 'CF7AT_VERSION' ),
			'CF7 Mini Ecommerce'  => defined( 'CF7MC_VERSION' ),
		);
		
		?>
		<table class="cf7at2mc-status-table">
			<?php foreach ( $dependencies as $name => $active ) : ?>
			<tr>
				<td><?php echo esc_html( $name ); ?></td>
				<td>
					<span class="cf7at2mc-status-indicator cf7at2mc-status-<?php echo $active ? 'active' : 'inactive'; ?>">
						<?php echo $active ? __( 'Active', CF7AT2MC_TEXT_DOMAIN ) : __( 'Inactive', CF7AT2MC_TEXT_DOMAIN ); ?>
					</span>
				</td>
			</tr>
			<?php endforeach; ?>
		</table>
		
		<div class="cf7at2mc-status-summary">
			<?php if ( array_filter( $dependencies ) === $dependencies ) : ?>
				<p class="cf7at2mc-status-success">
					<?php _e( 'All dependencies are active. Bridge is ready to use.', CF7AT2MC_TEXT_DOMAIN ); ?>
				</p>
			<?php else : ?>
				<p class="cf7at2mc-status-error">
					<?php _e( 'Some dependencies are missing. Please ensure all required plugins are installed and activated.', CF7AT2MC_TEXT_DOMAIN ); ?>
				</p>
			<?php endif; ?>
		</div>
		<?php
	}
	
	/**
	 * Render recent activity widget
	 */
	private function render_recent_activity() {
		// Get recent order access logs
		$logs = cf7at2mc_get_recent_access_logs( 5 );
		
		if ( empty( $logs ) ) {
			echo '<p>' . __( 'No recent activity.', CF7AT2MC_TEXT_DOMAIN ) . '</p>';
			return;
		}
		
		?>
		<ul class="cf7at2mc-activity-list">
			<?php foreach ( $logs as $log ) : ?>
			<li>
				<strong><?php echo esc_html( $log['action'] ); ?></strong>
				<br>
				<small><?php echo cf7at2mc_format_date( $log['created_at'] ); ?></small>
			</li>
			<?php endforeach; ?>
		</ul>
		<?php
	}
	
	/**
	 * Render quick actions widget
	 */
	private function render_quick_actions() {
		?>
		<div class="cf7at2mc-quick-actions">
			<a href="<?php echo admin_url( 'admin.php?page=cf7at2mc-settings' ); ?>" class="button button-primary">
				<?php _e( 'Configure Settings', CF7AT2MC_TEXT_DOMAIN ); ?>
			</a>
			
			<a href="<?php echo admin_url( 'admin.php?page=cf7at2mc-logs' ); ?>" class="button">
				<?php _e( 'View Access Logs', CF7AT2MC_TEXT_DOMAIN ); ?>
			</a>
			
			<?php if ( defined( 'CF7MC_VERSION' ) ) : ?>
			<a href="<?php echo admin_url( 'admin.php?page=cf7mc-orders' ); ?>" class="button">
				<?php _e( 'View Orders', CF7AT2MC_TEXT_DOMAIN ); ?>
			</a>
			<?php endif; ?>
			
			<?php if ( defined( 'CF7AT_VERSION' ) ) : ?>
			<a href="<?php echo admin_url( 'admin.php?page=cf7at-tokens' ); ?>" class="button">
				<?php _e( 'View Tokens', CF7AT2MC_TEXT_DOMAIN ); ?>
			</a>
			<?php endif; ?>
		</div>
		<?php
	}
	
	/**
	 * Render access logs
	 */
	private function render_access_logs() {
		$logs = cf7at2mc_get_access_logs();
		
		if ( empty( $logs ) ) {
			echo '<p>' . __( 'No access logs found.', CF7AT2MC_TEXT_DOMAIN ) . '</p>';
			return;
		}
		
		?>
		<table class="wp-list-table widefat fixed striped">
			<thead>
				<tr>
					<th><?php _e( 'Date', CF7AT2MC_TEXT_DOMAIN ); ?></th>
					<th><?php _e( 'Action', CF7AT2MC_TEXT_DOMAIN ); ?></th>
					<th><?php _e( 'Order', CF7AT2MC_TEXT_DOMAIN ); ?></th>
					<th><?php _e( 'Email', CF7AT2MC_TEXT_DOMAIN ); ?></th>
					<th><?php _e( 'Status', CF7AT2MC_TEXT_DOMAIN ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $logs as $log ) : ?>
				<tr>
					<td><?php echo cf7at2mc_format_date( $log['created_at'] ); ?></td>
					<td><?php echo esc_html( $log['action'] ); ?></td>
					<td><?php echo esc_html( $log['order_code'] ); ?></td>
					<td><?php echo esc_html( $log['email'] ); ?></td>
					<td>
						<span class="cf7at2mc-status-<?php echo esc_attr( $log['status'] ); ?>">
							<?php echo esc_html( $log['status'] ); ?>
						</span>
					</td>
				</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}
	
	/**
	 * Show admin notices
	 */
	public function show_admin_notices() {
		// Check for missing dependencies
		$missing = array();
		
		if ( ! class_exists( 'WPCF7' ) ) {
			$missing[] = 'Contact Form 7';
		}
		
		if ( ! defined( 'CF7AT_VERSION' ) ) {
			$missing[] = 'CF7 Access Token';
		}
		
		if ( ! defined( 'CF7MC_VERSION' ) ) {
			$missing[] = 'CF7 Mini Ecommerce';
		}
		
		if ( ! empty( $missing ) ) {
			?>
			<div class="notice notice-warning">
				<p>
					<?php printf(
						__( 'CF7 Bridge requires the following plugins: %s', CF7AT2MC_TEXT_DOMAIN ),
						implode( ', ', $missing )
					); ?>
				</p>
			</div>
			<?php
		}
	}
	
	/**
	 * Render section descriptions
	 */
	public function render_general_section() {
		echo '<p>' . __( 'Configure general bridge settings for connecting CF7 Access Token with CF7 Mini Ecommerce.', CF7AT2MC_TEXT_DOMAIN ) . '</p>';
	}
	
	public function render_tokens_section() {
		echo '<p>' . __( 'Configure how access tokens are generated and managed for order access.', CF7AT2MC_TEXT_DOMAIN ) . '</p>';
	}
	
	public function render_payment_section() {
		echo '<p>' . __( 'Configure payment retry and order access behavior.', CF7AT2MC_TEXT_DOMAIN ) . '</p>';
	}
	
	public function render_advanced_section() {
		echo '<p>' . __( 'Advanced settings for debugging and troubleshooting.', CF7AT2MC_TEXT_DOMAIN ) . '</p>';
	}
	
	/**
	 * Render form fields
	 */
	public function render_checkbox_field( $args ) {
		$key = $args['key'];
		$value = OptionsManager::get( $key );
		$description = isset( $args['description'] ) ? $args['description'] : '';
		
		?>
		<label>
			<input type="checkbox" name="cf7at2mc_options[<?php echo esc_attr( $key ); ?>]" value="1" <?php checked( $value ); ?> />
			<?php echo esc_html( $description ); ?>
		</label>
		<?php
	}
	
	public function render_text_field( $args ) {
		$key = $args['key'];
		$value = OptionsManager::get( $key );
		$description = isset( $args['description'] ) ? $args['description'] : '';
		
		?>
		<input type="text" name="cf7at2mc_options[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $value ); ?>" class="regular-text" />
		<?php if ( $description ) : ?>
			<p class="description"><?php echo esc_html( $description ); ?></p>
		<?php endif; ?>
		<?php
	}
	
	public function render_number_field( $args ) {
		$key = $args['key'];
		$value = OptionsManager::get( $key );
		$description = isset( $args['description'] ) ? $args['description'] : '';
		$min = isset( $args['min'] ) ? $args['min'] : 1;
		$max = isset( $args['max'] ) ? $args['max'] : 999999;
		
		?>
		<input type="number" name="cf7at2mc_options[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $value ); ?>" min="<?php echo esc_attr( $min ); ?>" max="<?php echo esc_attr( $max ); ?>" class="small-text" />
		<?php if ( $description ) : ?>
			<p class="description"><?php echo esc_html( $description ); ?></p>
		<?php endif; ?>
		<?php
	}
}