<?php

namespace CF7AT2MC\Frontend;

use CF7AT2MC\Core\Bridge;
use CF7AT2MC\Core\OptionsManager;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Order access controller for frontend
 */
class OrderAccessController {
	
	/**
	 * Controller instance
	 *
	 * @var OrderAccessController
	 */
	private static $instance = null;
	
	/**
	 * Get controller instance
	 *
	 * @return OrderAccessController
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		$this->init_hooks();
	}
	
	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		add_action( 'template_redirect', array( $this, 'handle_order_access_request' ) );
		add_action( 'wp_ajax_cf7at2mc_retry_payment', array( $this, 'handle_payment_retry' ) );
		add_action( 'wp_ajax_nopriv_cf7at2mc_retry_payment', array( $this, 'handle_payment_retry' ) );
	}
	
	/**
	 * Handle order access request
	 */
	public function handle_order_access_request() {
		// Check if this is an order access page
		if ( ! get_query_var( 'cf7at2mc_order_access' ) && ! get_query_var( 'cf7at_access' ) ) {
			return;
		}
		
		// Get token from URL
		$token = $this->get_token_from_request();
		
		if ( empty( $token ) ) {
			$this->render_error_page( __( 'Invalid access link.', CF7AT2MC_TEXT_DOMAIN ) );
			return;
		}
		
		// Validate token and get order
		$bridge = Bridge::instance();
		$validation_result = $bridge->validate_order_access( $token );
		
		if ( ! $validation_result['valid'] ) {
			$this->render_error_page( $validation_result['message'] );
			return;
		}
		
		// Render order access page
		$this->render_order_access_page( $validation_result['order'], $validation_result['token_data'] );
	}
	
	/**
	 * Get token from request
	 *
	 * @return string|false
	 */
	private function get_token_from_request() {
		// Check URL parameter
		if ( ! empty( $_GET['token'] ) ) {
			return sanitize_text_field( $_GET['token'] );
		}
		
		// Check CF7AT access parameter
		if ( ! empty( $_GET['cf7at_token'] ) ) {
			return sanitize_text_field( $_GET['cf7at_token'] );
		}
		
		return false;
	}
	
	/**
	 * Render order access page
	 *
	 * @param array $order Order data
	 * @param array $token_data Token data
	 */
	public function render_order_access_page( $order, $token_data ) {
		// Set page title
		add_filter( 'wp_title', function( $title ) use ( $order ) {
			return sprintf( __( 'Order %s - %s', CF7AT2MC_TEXT_DOMAIN ), $order['order_code'], get_bloginfo( 'name' ) );
		});
		
		// Start output buffering
		ob_start();
		
		// Include header
		get_header();
		
		?>
		<div class="cf7at2mc-order-access-page">
			<div class="cf7at2mc-container">
				<?php $this->render_order_details( $order, $token_data ); ?>
			</div>
		</div>
		<?php
		
		// Include footer
		get_footer();
		
		// End output buffering and exit
		ob_end_flush();
		exit;
	}
	
	/**
	 * Render order details
	 *
	 * @param array $order Order data
	 * @param array $token_data Token data
	 */
	public function render_order_details( $order, $token_data ) {
		?>
		<div class="cf7at2mc-order-details">
			<header class="cf7at2mc-order-header">
				<h1><?php printf( __( 'Order %s', CF7AT2MC_TEXT_DOMAIN ), esc_html( $order['order_code'] ) ); ?></h1>
				<div class="cf7at2mc-order-status cf7at2mc-status-<?php echo esc_attr( $order['status'] ); ?>">
					<?php echo esc_html( cf7at2mc_get_status_label( $order['status'] ) ); ?>
				</div>
			</header>
			
			<div class="cf7at2mc-order-content">
				<div class="cf7at2mc-order-info">
					<h2><?php _e( 'Order Information', CF7AT2MC_TEXT_DOMAIN ); ?></h2>
					
					<table class="cf7at2mc-info-table">
						<tr>
							<th><?php _e( 'Order Code:', CF7AT2MC_TEXT_DOMAIN ); ?></th>
							<td><?php echo esc_html( $order['order_code'] ); ?></td>
						</tr>
						<tr>
							<th><?php _e( 'Email:', CF7AT2MC_TEXT_DOMAIN ); ?></th>
							<td><?php echo esc_html( $order['email'] ); ?></td>
						</tr>
						<tr>
							<th><?php _e( 'Total Amount:', CF7AT2MC_TEXT_DOMAIN ); ?></th>
							<td><?php echo cf7at2mc_format_amount( $order['total_amount'] ); ?></td>
						</tr>
						<tr>
							<th><?php _e( 'Payment Gateway:', CF7AT2MC_TEXT_DOMAIN ); ?></th>
							<td><?php echo esc_html( cf7at2mc_get_gateway_label( $order['gateway'] ) ); ?></td>
						</tr>
						<tr>
							<th><?php _e( 'Order Date:', CF7AT2MC_TEXT_DOMAIN ); ?></th>
							<td><?php echo cf7at2mc_format_date( $order['created_at'] ); ?></td>
						</tr>
						<?php if ( $order['paid_at'] ) : ?>
						<tr>
							<th><?php _e( 'Payment Date:', CF7AT2MC_TEXT_DOMAIN ); ?></th>
							<td><?php echo cf7at2mc_format_date( $order['paid_at'] ); ?></td>
						</tr>
						<?php endif; ?>
					</table>
				</div>
				
				<div class="cf7at2mc-order-items">
					<h2><?php _e( 'Order Items', CF7AT2MC_TEXT_DOMAIN ); ?></h2>
					<?php $this->render_order_items( $order['items'] ); ?>
				</div>
				
				<?php $this->render_order_actions( $order, $token_data ); ?>
			</div>
		</div>
		<?php
	}
	
	/**
	 * Render order items
	 *
	 * @param array $items Order items
	 */
	private function render_order_items( $items ) {
		if ( empty( $items ) ) {
			echo '<p>' . __( 'No items found.', CF7AT2MC_TEXT_DOMAIN ) . '</p>';
			return;
		}
		
		?>
		<table class="cf7at2mc-items-table">
			<thead>
				<tr>
					<th><?php _e( 'Item', CF7AT2MC_TEXT_DOMAIN ); ?></th>
					<th><?php _e( 'Quantity', CF7AT2MC_TEXT_DOMAIN ); ?></th>
					<th><?php _e( 'Price', CF7AT2MC_TEXT_DOMAIN ); ?></th>
					<th><?php _e( 'Total', CF7AT2MC_TEXT_DOMAIN ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $items as $item ) : ?>
				<tr>
					<td>
						<strong><?php echo esc_html( $item['name'] ); ?></strong>
						<?php if ( ! empty( $item['description'] ) ) : ?>
							<br><small><?php echo esc_html( $item['description'] ); ?></small>
						<?php endif; ?>
					</td>
					<td><?php echo esc_html( $item['quantity'] ); ?></td>
					<td><?php echo cf7at2mc_format_amount( $item['price'] ); ?></td>
					<td><?php echo cf7at2mc_format_amount( $item['price'] * $item['quantity'] ); ?></td>
				</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}
	
	/**
	 * Render order actions
	 *
	 * @param array $order Order data
	 * @param array $token_data Token data
	 */
	private function render_order_actions( $order, $token_data ) {
		?>
		<div class="cf7at2mc-order-actions">
			<?php
			// Show payment retry button for failed/pending orders
			if ( in_array( $order['status'], array( 'pending', 'failed' ) ) && OptionsManager::get( 'allow_payment_retry' ) ) {
				$this->render_payment_retry_button( $order, $token_data );
			}
			
			// Show download/access links for paid orders
			if ( $order['status'] === 'paid' ) {
				$this->render_paid_order_actions( $order, $token_data );
			}
			
			// Show status-specific messages
			$this->render_status_message( $order );
			?>
		</div>
		<?php
	}
	
	/**
	 * Render payment retry button
	 *
	 * @param array $order Order data
	 * @param array $token_data Token data
	 */
	private function render_payment_retry_button( $order, $token_data ) {
		?>
		<div class="cf7at2mc-payment-retry">
			<h3><?php _e( 'Payment Required', CF7AT2MC_TEXT_DOMAIN ); ?></h3>
			<p><?php _e( 'Your order is waiting for payment. Click the button below to complete your payment.', CF7AT2MC_TEXT_DOMAIN ); ?></p>
			
			<button type="button" class="cf7at2mc-retry-payment-btn" data-order-id="<?php echo esc_attr( $order['id'] ); ?>" data-token="<?php echo esc_attr( $token_data['token_hash'] ); ?>">
				<?php _e( 'Complete Payment', CF7AT2MC_TEXT_DOMAIN ); ?>
			</button>
		</div>
		<?php
	}
	
	/**
	 * Render paid order actions
	 *
	 * @param array $order Order data
	 * @param array $token_data Token data
	 */
	private function render_paid_order_actions( $order, $token_data ) {
		?>
		<div class="cf7at2mc-paid-order-actions">
			<h3><?php _e( 'Payment Completed', CF7AT2MC_TEXT_DOMAIN ); ?></h3>
			<p><?php _e( 'Thank you! Your payment has been received and your order is complete.', CF7AT2MC_TEXT_DOMAIN ); ?></p>
			
			<?php
			// Allow other plugins to add download links or access content
			do_action( 'cf7at2mc_render_paid_order_content', $order, $token_data );
			?>
		</div>
		<?php
	}
	
	/**
	 * Render status message
	 *
	 * @param array $order Order data
	 */
	private function render_status_message( $order ) {
		$messages = array(
			'pending' => __( 'Your order is pending payment. Please complete the payment to process your order.', CF7AT2MC_TEXT_DOMAIN ),
			'paid'    => __( 'Your order has been paid and is being processed.', CF7AT2MC_TEXT_DOMAIN ),
			'failed'  => __( 'Payment for this order failed. You can retry the payment using the button above.', CF7AT2MC_TEXT_DOMAIN ),
			'expired' => __( 'This order has expired. Please create a new order if you still wish to make this purchase.', CF7AT2MC_TEXT_DOMAIN ),
		);
		
		if ( isset( $messages[ $order['status'] ] ) ) {
			?>
			<div class="cf7at2mc-status-message cf7at2mc-status-<?php echo esc_attr( $order['status'] ); ?>">
				<p><?php echo esc_html( $messages[ $order['status'] ] ); ?></p>
			</div>
			<?php
		}
	}
	
	/**
	 * Handle payment retry AJAX request
	 */
	public function handle_payment_retry() {
		// Verify nonce
		if ( ! wp_verify_nonce( $_POST['nonce'], 'cf7at2mc_frontend' ) ) {
			wp_die( __( 'Security check failed.', CF7AT2MC_TEXT_DOMAIN ) );
		}
		
		$order_id = absint( $_POST['order_id'] );
		$token = sanitize_text_field( $_POST['token'] );
		
		if ( ! $order_id || ! $token ) {
			wp_send_json_error( array(
				'message' => __( 'Invalid request.', CF7AT2MC_TEXT_DOMAIN ),
			));
		}
		
		// Validate token access to order
		$bridge = Bridge::instance();
		$validation_result = $bridge->validate_order_access( $token );
		
		if ( ! $validation_result['valid'] || $validation_result['order']['id'] != $order_id ) {
			wp_send_json_error( array(
				'message' => __( 'Access denied.', CF7AT2MC_TEXT_DOMAIN ),
			));
		}
		
		$order = $validation_result['order'];
		
		// Check if retry is allowed
		if ( ! in_array( $order['status'], array( 'pending', 'failed' ) ) ) {
			wp_send_json_error( array(
				'message' => __( 'Payment retry not allowed for this order status.', CF7AT2MC_TEXT_DOMAIN ),
			));
		}
		
		// Generate new payment URL using CF7MC
		if ( ! class_exists( 'CF7MC\Core\OrderManager' ) ) {
			wp_send_json_error( array(
				'message' => __( 'Payment system not available.', CF7AT2MC_TEXT_DOMAIN ),
			));
		}
		
		// Get gateway and generate payment URL
		$gateway_class = cf7mc_get_gateway_class( $order['gateway'] );
		
		if ( ! $gateway_class ) {
			wp_send_json_error( array(
				'message' => __( 'Payment gateway not available.', CF7AT2MC_TEXT_DOMAIN ),
			));
		}
		
		$gateway = new $gateway_class();
		$payment_result = $gateway->create_payment_intent( $order );
		
		if ( ! $payment_result['success'] ) {
			wp_send_json_error( array(
				'message' => $payment_result['message'],
			));
		}
		
		wp_send_json_success( array(
			'payment_url' => $payment_result['payment_url'],
			'message'     => __( 'Redirecting to payment...', CF7AT2MC_TEXT_DOMAIN ),
		));
	}
	
	/**
	 * Render error page
	 *
	 * @param string $message Error message
	 */
	private function render_error_page( $message ) {
		// Start output buffering
		ob_start();
		
		// Include header
		get_header();
		
		?>
		<div class="cf7at2mc-error-page">
			<div class="cf7at2mc-container">
				<div class="cf7at2mc-error-message">
					<h1><?php _e( 'Access Error', CF7AT2MC_TEXT_DOMAIN ); ?></h1>
					<p><?php echo esc_html( $message ); ?></p>
					<a href="<?php echo esc_url( home_url() ); ?>" class="cf7at2mc-home-link">
						<?php _e( 'Return to Homepage', CF7AT2MC_TEXT_DOMAIN ); ?>
					</a>
				</div>
			</div>
		</div>
		<?php
		
		// Include footer
		get_footer();
		
		// End output buffering and exit
		ob_end_flush();
		exit;
	}
	
	/**
	 * Render order content for CF7AT integration
	 *
	 * @param array $token_data Token data
	 */
	public function render_order_access_content( $token_data ) {
		if ( $token_data['related_type'] !== 'order' ) {
			return;
		}
		
		// Load order data
		if ( ! class_exists( 'CF7MC\Core\OrderManager' ) ) {
			echo '<p>' . __( 'Order system not available.', CF7AT2MC_TEXT_DOMAIN ) . '</p>';
			return;
		}
		
		$order_manager = new \CF7MC\Core\OrderManager();
		$order = $order_manager->get_order( $token_data['related_id'] );
		
		if ( ! $order ) {
			echo '<p>' . __( 'Order not found.', CF7AT2MC_TEXT_DOMAIN ) . '</p>';
			return;
		}
		
		// Render order details inline
		$this->render_order_details( $order, $token_data );
	}
}