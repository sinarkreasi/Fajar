# Coding AI Prompt: CF7 Magic Link ↔ Mini Ecommerce Bridge

## Role
You are a senior WordPress plugin developer experienced in:
- Contact Form 7
- Token-based access systems
- Mini ecommerce / instant checkout
- Secure data access without user accounts

You will build a **bridge module** that connects:
- CF7 Magic Link (Access Token Addon)
with
- CF7 Mini Ecommerce Addon

This bridge enables **secure, passwordless order access** for customers.

---

## Bridge Goal

Allow customers who place an order via Contact Form 7
to securely access their **order details and payment actions**
using a **magic link**, without creating a WordPress account.

---

## Core Concept

CF7 Form Submission
→ Mini Ecommerce creates Order
→ Magic Link token is generated
→ User receives secure access link
→ User can:
- view order status
- complete payment
- download invoice
- view transaction history

---

## Architectural Rule (VERY IMPORTANT)

- Magic Link addon handles **authentication**
- Mini Ecommerce addon handles **business logic**
- Bridge ONLY maps:
  token ↔ order_id

No duplicated logic.
No tight coupling.

---

## Data Relationship

Token table:
- related_type = `order`
- related_id = `{order_id}`

Order table:
- referenced by token only via ID
- never exposed directly via URL

---

## Order Access Scope

Magic Link grants access ONLY to:
- ONE order
- actions related to that order

Allowed actions:
- View order summary
- View payment status
- Trigger payment retry
- Download invoice (if available)

Disallowed:
- View other orders
- Edit order data
- Access admin pages

---

## Order Access Flow

1. User submits CF7 checkout form
2. Mini Ecommerce addon:
   - creates order (status: pending)
3. Bridge:
   - requests Magic Link addon to generate token
   - token scoped to order_id
4. Magic Link is sent via email

---

## Magic Link URL Example

https://example.com/access/?token=XXXX


---

## Access Validation Flow

1. User opens magic link
2. Magic Link addon validates token
3. Bridge resolves:
   - related_type = order
   - related_id = order_id
4. Mini Ecommerce addon loads order data
5. Order access page is rendered

---

## Order Access Page (Frontend)

Display:
- Order code
- Order status (pending / paid / expired / failed)
- Item list
- Total amount
- Payment status

Conditional CTA:
- If `pending` → "Complete Payment"
- If `failed` → "Retry Payment"
- If `paid` → "Download Invoice"

---

## Payment Retry Logic

When user clicks "Retry Payment":

1. Validate token again
2. Validate order status = pending OR failed
3. Generate new payment intent
4. Redirect to payment gateway
5. Gateway callback updates order
6. User redirected back to order access page

---

## Security Requirements

- Token must be validated on EVERY request
- No order_id allowed via GET/POST
- Order loaded ONLY via token mapping
- Prevent replay attacks (optional usage limit)
- Expire token after configurable time

---

## Bridge Interface Contract

Implement a simple interface:

```php
interface MagicOrderBridgeInterface {
  public function generate_order_token( $order_id, $email );
  public function resolve_order_from_token( $token );
}
```
Bridge must NOT:

generate tokens itself

validate tokens itself

Plugin Integration Points

From Mini Ecommerce:

order_created
payment_failed
payment_expired

From Magic Link:

token_validated
token_expired
token_revoked

Admin Configuration

Provide settings:

Enable / disable order magic links

Token expiration time

Allow payment retry (on/off)

Access page slug

Explicit Non-Goals

DO NOT implement:

User login

Order dashboard

Order search

Multi-order access

Cart recovery

UX Principles

One link = one order

No confusion

No login

Clear status

Clear CTA

Output Expectations

Generate:

Bridge module structure
Integration hooks
Order access controller
Secure order renderer
Retry payment handler

Code must be:

Secure
Decoupled
Extendable
WordPress coding standard compliant

## Final Instruction

Start by:

Designing the bridge module structure
Defining integration hooks
Implementing order-token mapping
Building secure order access page
Adding payment retry logic

Proceed step-by-step.
Do NOT expand scope beyond this bridge.