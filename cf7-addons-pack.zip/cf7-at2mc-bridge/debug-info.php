<?php
/**
 * Debug information for CF7 Bridge plugin
 * 
 * This file can be accessed directly to check plugin status
 * URL: /wp-content/plugins/cf7-at2mc-bridge/debug-info.php
 */

// Prevent direct access unless debugging
if ( ! defined( 'ABSPATH' ) ) {
	// Load WordPress if accessed directly
	require_once '../../../wp-load.php';
}

// Check if user has admin capabilities
if ( ! current_user_can( 'manage_options' ) ) {
	wp_die( 'Access denied. Admin privileges required.' );
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>CF7 Bridge Debug Info</title>
	<style>
		body { font-family: Arial, sans-serif; margin: 20px; }
		.status-ok { color: green; }
		.status-error { color: red; }
		.status-warning { color: orange; }
		table { border-collapse: collapse; width: 100%; }
		th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
		th { background-color: #f2f2f2; }
		.code { background: #f5f5f5; padding: 10px; border-radius: 4px; font-family: monospace; }
	</style>
</head>
<body>
	<h1>CF7 Bridge Debug Information</h1>
	
	<h2>Plugin Status</h2>
	<?php
	$status = function_exists( 'cf7at2mc_get_status' ) ? cf7at2mc_get_status() : null;
	
	if ( $status ) {
		?>
		<table>
			<tr>
				<th>Item</th>
				<th>Status</th>
				<th>Details</th>
			</tr>
			<tr>
				<td>Plugin Version</td>
				<td class="status-ok">✓</td>
				<td><?php echo esc_html( $status['version'] ); ?></td>
			</tr>
			<tr>
				<td>Contact Form 7</td>
				<td class="<?php echo $status['dependencies']['cf7'] ? 'status-ok' : 'status-error'; ?>">
					<?php echo $status['dependencies']['cf7'] ? '✓' : '✗'; ?>
				</td>
				<td><?php echo $status['dependencies']['cf7'] ? 'Active' : 'Not Found'; ?></td>
			</tr>
			<tr>
				<td>CF7 Access Token</td>
				<td class="<?php echo $status['dependencies']['cf7at'] ? 'status-ok' : 'status-error'; ?>">
					<?php echo $status['dependencies']['cf7at'] ? '✓' : '✗'; ?>
				</td>
				<td><?php echo $status['dependencies']['cf7at'] ? 'Active' : 'Not Found'; ?></td>
			</tr>
			<tr>
				<td>CF7 Mini Ecommerce</td>
				<td class="<?php echo $status['dependencies']['cf7mc'] ? 'status-ok' : 'status-error'; ?>">
					<?php echo $status['dependencies']['cf7mc'] ? '✓' : '✗'; ?>
				</td>
				<td><?php echo $status['dependencies']['cf7mc'] ? 'Active' : 'Not Found'; ?></td>
			</tr>
			<tr>
				<td>Bridge Ready</td>
				<td class="<?php echo $status['ready'] ? 'status-ok' : 'status-error'; ?>">
					<?php echo $status['ready'] ? '✓' : '✗'; ?>
				</td>
				<td><?php echo $status['ready'] ? 'All dependencies met' : 'Missing dependencies'; ?></td>
			</tr>
			<tr>
				<td>Configuration</td>
				<td class="<?php echo $status['configured'] ? 'status-ok' : 'status-warning'; ?>">
					<?php echo $status['configured'] ? '✓' : '!'; ?>
				</td>
				<td><?php echo $status['configured'] ? 'Configured' : 'Needs configuration'; ?></td>
			</tr>
			<tr>
				<td>Functional</td>
				<td class="<?php echo $status['functional'] ? 'status-ok' : 'status-error'; ?>">
					<?php echo $status['functional'] ? '✓' : '✗'; ?>
				</td>
				<td><?php echo $status['functional'] ? 'Ready to use' : 'Not functional'; ?></td>
			</tr>
		</table>
		
		<?php if ( ! empty( $status['missing'] ) ) : ?>
		<h3>Missing Dependencies</h3>
		<ul>
			<?php foreach ( $status['missing'] as $missing ) : ?>
				<li class="status-error"><?php echo esc_html( $missing ); ?></li>
			<?php endforeach; ?>
		</ul>
		<?php endif; ?>
		
	<?php } else { ?>
		<p class="status-error">❌ Bridge plugin not loaded or functions not available</p>
	<?php } ?>
	
	<h2>WordPress Environment</h2>
	<table>
		<tr>
			<td>WordPress Version</td>
			<td><?php echo get_bloginfo( 'version' ); ?></td>
		</tr>
		<tr>
			<td>PHP Version</td>
			<td><?php echo PHP_VERSION; ?></td>
		</tr>
		<tr>
			<td>Active Theme</td>
			<td><?php echo wp_get_theme()->get( 'Name' ); ?></td>
		</tr>
		<tr>
			<td>Debug Mode</td>
			<td><?php echo defined( 'WP_DEBUG' ) && WP_DEBUG ? 'Enabled' : 'Disabled'; ?></td>
		</tr>
	</table>
	
	<h2>Plugin Constants</h2>
	<div class="code">
		<?php
		$constants = array(
			'CF7AT2MC_VERSION',
			'CF7AT2MC_PLUGIN_DIR',
			'CF7AT2MC_PLUGIN_URL',
			'CF7AT2MC_TEXT_DOMAIN',
			'CF7AT_VERSION',
			'CF7MC_VERSION'
		);
		
		foreach ( $constants as $constant ) {
			$value = defined( $constant ) ? constant( $constant ) : 'Not defined';
			echo esc_html( $constant ) . ': ' . esc_html( $value ) . "<br>";
		}
		?>
	</div>
	
	<h2>Active Plugins</h2>
	<ul>
		<?php
		$active_plugins = get_option( 'active_plugins' );
		foreach ( $active_plugins as $plugin ) {
			$plugin_data = get_plugin_data( WP_PLUGIN_DIR . '/' . $plugin );
			echo '<li>' . esc_html( $plugin_data['Name'] ) . ' (' . esc_html( $plugin_data['Version'] ) . ')</li>';
		}
		?>
	</ul>
	
	<h2>Recent Errors</h2>
	<?php
	$error_log = ini_get( 'error_log' );
	if ( $error_log && file_exists( $error_log ) ) {
		$errors = file_get_contents( $error_log );
		$cf7_errors = array();
		
		// Extract CF7 related errors from last 100 lines
		$lines = explode( "\n", $errors );
		$recent_lines = array_slice( $lines, -100 );
		
		foreach ( $recent_lines as $line ) {
			if ( strpos( $line, 'CF7' ) !== false || strpos( $line, 'cf7' ) !== false ) {
				$cf7_errors[] = $line;
			}
		}
		
		if ( ! empty( $cf7_errors ) ) {
			echo '<div class="code">';
			foreach ( array_slice( $cf7_errors, -10 ) as $error ) {
				echo esc_html( $error ) . "<br>";
			}
			echo '</div>';
		} else {
			echo '<p>No recent CF7-related errors found.</p>';
		}
	} else {
		echo '<p>Error log not accessible.</p>';
	}
	?>
	
	<hr>
	<p><small>Generated at: <?php echo current_time( 'Y-m-d H:i:s' ); ?></small></p>
</body>
</html>