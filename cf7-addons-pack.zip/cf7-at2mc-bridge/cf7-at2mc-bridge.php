<?php
/*
 * Plugin Name: CF7 Access Token to Mini Ecommerce Bridge
 * Plugin URI: https://github.com/cf7-bridge/cf7-at2mc-bridge
 * Description: Bridge plugin connecting CF7 Access Token (Magic Link) with CF7 Mini Ecommerce for secure, passwordless order access.
 * Author: CF7 Bridge Team
 * Version: 1.0.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Text Domain: cf7-at2mc-bridge
 * Domain Path: /languages
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Plugin version
define( 'CF7AT2MC_VERSION', '1.0.0' );

// Plugin constants
define( 'CF7AT2MC_PLUGIN_FILE', __FILE__ );
define( 'CF7AT2MC_PLUGIN_BASENAME', plugin_basename( CF7AT2MC_PLUGIN_FILE ) );
define( 'CF7AT2MC_PLUGIN_DIR', untrailingslashit( dirname( CF7AT2MC_PLUGIN_FILE ) ) );
define( 'CF7AT2MC_PLUGIN_URL', untrailingslashit( plugins_url( '', CF7AT2MC_PLUGIN_FILE ) ) );
define( 'CF7AT2MC_TEXT_DOMAIN', 'cf7-at2mc-bridge' );

// Check dependencies
add_action( 'plugins_loaded', 'cf7at2mc_check_dependencies' );

function cf7at2mc_check_dependencies() {
	$missing_plugins = array();
	
	// Check for Contact Form 7
	if ( ! class_exists( 'WPCF7' ) ) {
		$missing_plugins[] = 'Contact Form 7';
	}
	
	// Check for CF7 Access Token
	if ( ! defined( 'CF7AT_VERSION' ) ) {
		$missing_plugins[] = 'CF7 Access Token';
	}
	
	// Check for CF7 Mini Ecommerce
	if ( ! defined( 'CF7MC_VERSION' ) ) {
		$missing_plugins[] = 'CF7 Mini Ecommerce';
	}
	
	if ( ! empty( $missing_plugins ) ) {
		add_action( 'admin_notices', function() use ( $missing_plugins ) {
			?>
			<div class="notice notice-error">
				<p><?php printf( 
					__( 'CF7 Access Token to Mini Ecommerce Bridge requires the following plugins: %s', CF7AT2MC_TEXT_DOMAIN ),
					implode( ', ', $missing_plugins )
				); ?></p>
			</div>
			<?php
		});
		return;
	}
	
	// Initialize bridge
	cf7at2mc_init();
}

// Load plugin files
require_once CF7AT2MC_PLUGIN_DIR . '/load.php';

// Plugin activation hook
register_activation_hook( CF7AT2MC_PLUGIN_FILE, 'cf7at2mc_activate' );

// Plugin deactivation hook
register_deactivation_hook( CF7AT2MC_PLUGIN_FILE, 'cf7at2mc_deactivate' );

/**
 * Plugin activation callback
 */
function cf7at2mc_activate() {
	// Set default options
	CF7AT2MC\Core\OptionsManager::set_defaults();
	
	// Flush rewrite rules
	flush_rewrite_rules();
}

/**
 * Plugin deactivation callback
 */
function cf7at2mc_deactivate() {
	// Flush rewrite rules
	flush_rewrite_rules();
}