<?php

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Autoloader
spl_autoload_register( 'cf7at2mc_autoloader' );

function cf7at2mc_autoloader( $class ) {
	// Only handle our namespace
	if ( strpos( $class, 'CF7AT2MC\\' ) !== 0 ) {
		return;
	}
	
	// Remove namespace prefix
	$class = substr( $class, 9 );
	
	// Convert namespace separators to directory separators
	$class = str_replace( '\\', DIRECTORY_SEPARATOR, $class );
	
	// Convert to lowercase and add .php extension
	$file = CF7AT2MC_PLUGIN_DIR . '/includes/' . strtolower( $class ) . '.php';
	
	if ( file_exists( $file ) ) {
		require_once $file;
	}
}

// Load core files
require_once CF7AT2MC_PLUGIN_DIR . '/includes/functions.php';

// Load interfaces
require_once CF7AT2MC_PLUGIN_DIR . '/includes/interfaces/magicorderbridgeinterface.php';

// Load core classes
require_once CF7AT2MC_PLUGIN_DIR . '/includes/core/optionsmanager.php';
require_once CF7AT2MC_PLUGIN_DIR . '/includes/core/statuschecker.php';
require_once CF7AT2MC_PLUGIN_DIR . '/includes/core/plugin.php';
require_once CF7AT2MC_PLUGIN_DIR . '/includes/core/bridge.php';

// Load frontend classes
require_once CF7AT2MC_PLUGIN_DIR . '/includes/frontend/orderaccesscontroller.php';

// Load admin classes if in admin area
if ( is_admin() ) {
	require_once CF7AT2MC_PLUGIN_DIR . '/includes/admin/admininit.php';
}

// Initialize plugin
function cf7at2mc_init() {
	// Load text domain
	load_plugin_textdomain( CF7AT2MC_TEXT_DOMAIN, false, dirname( CF7AT2MC_PLUGIN_BASENAME ) . '/languages' );
	
	// Initialize core components
	CF7AT2MC\Core\Plugin::instance();
	
	// Initialize bridge
	CF7AT2MC\Core\Bridge::instance();
	
	// Initialize order access controller
	CF7AT2MC\Frontend\OrderAccessController::instance();
	
	// Initialize admin if in admin area
	if ( is_admin() ) {
		CF7AT2MC\Admin\AdminInit::instance();
	}
	
	do_action( 'cf7at2mc_init' );
}