# Coding AI Prompt: CF7 Access Token / Magic Link Addon

## Role
You are a senior WordPress plugin developer with deep experience in:
- Contact Form 7 internals
- Secure token-based authentication
- Custom database tables
- Frontend access control
- Security best practices

You will build a WordPress addon plugin called **CF7 Access Token / Magic Link**.

This plugin provides **secure, passwordless access** to specific resources
(order, submission, booking, subscription) generated from Contact Form 7 forms.

This is NOT a user account system.
Do NOT implement user registration, login, or WordPress roles.

---

## Product Goal
Allow users who submit a Contact Form 7 form to securely access
their related data via a **magic link** sent by email.

Access is granted using:
- a secure token
- limited scope
- expiration time

No username, no password, no WordPress login required.

---

## Core Principles (VERY IMPORTANT)

- Contact Form 7 is only a trigger and data source
- Tokens grant access to ONE specific resource only
- Tokens are temporary and revocable
- Security > convenience
- No persistent authentication session

---

## Core Features (V1 – MUST IMPLEMENT)

1. Generate secure access token after CF7 form submission
2. Store token metadata in a custom database table
3. Send magic link via email
4. Validate token on access
5. Enforce expiration and usage limits
6. Restrict access to specific resource only
7. Display protected content when token is valid
8. Show expired / invalid message when token fails
9. Admin UI to manage tokens
10. Token revocation support

---

## Token Model

Each token must have:
- token_hash (never store raw token)
- related_type (submission | order | booking | subscription)
- related_id
- email
- expires_at
- usage_limit (optional)
- usage_count
- status (active | expired | revoked)
- created_at

---

## Database Requirements

Create a custom table on plugin activation.

Example table:
- `wp_cf7_access_tokens`

Do NOT store tokens in:
- wp_options
- post_meta
- user_meta

---

## Token Generation Flow

1. Contact Form 7 form is submitted
2. Plugin extracts user email and related entity ID
3. Plugin generates a cryptographically secure random token
4. Token is hashed before storage
5. Token metadata is saved to database
6. A magic link is generated:

https://example.com/access/?token=RAW_TOKEN


7. The link is sent to the user via email

---

## Access Validation Flow

1. User opens magic link
2. Plugin intercepts request
3. Plugin validates:
   - token hash
   - expiration time
   - usage limit
   - token status
4. If valid:
   - increment usage count
   - grant access to related resource
5. If invalid:
   - show error or expired message

---

## Access Scope Rules

- Token grants access to ONE resource only
- Token cannot access WordPress admin
- Token cannot access other user data
- Token does not create a login session

Access must be handled at application level,
not via WordPress authentication.

---

## Security Requirements (MANDATORY)

- Use cryptographically secure random token generation
- Hash tokens using `hash_hmac` or `password_hash`
- Enforce HTTPS-only usage
- Rate-limit token validation attempts
- Prevent token reuse if one-time use is enabled
- Sanitize all inputs
- Escape all outputs
- Protect against brute-force token guessing

---

## Admin Interface

Provide an admin page with:
- Token list table
- Filter by status
- View token details
- Revoke token
- Extend expiration
- View usage count

UI should be minimal, functional, and lightweight.

---

## Frontend Integration

Provide:
- A dedicated access endpoint (e.g. `/access/`)
- Shortcodes or template hooks to render protected content
- Conditional rendering:
  - valid token → show content
  - invalid token → show error / CTA

---

## Email Requirements

- Customizable email template
- Clear CTA button
- Expiration notice
- Security disclaimer

Example subject:
"Secure Access to Your Request"

---

## Explicit Non-Goals (DO NOT IMPLEMENT)

- WordPress user login
- Membership system
- Role management
- Persistent sessions
- Multi-resource tokens
- OAuth or SSO

---

## Architecture Requirements

Use modular architecture:

- `/core`
  - TokenManager
  - AccessValidator
- `/integrations`
  - CF7Listener
- `/database`
  - SchemaManager
- `/admin`
  - TokenAdminPage
- `/frontend`
  - AccessController
- `/emails`
  - EmailBuilder

Use namespaces and clean separation of concerns.

---

## Output Expectations

Generate:
- Plugin folder structure
- Main plugin bootstrap file
- Database schema creation
- Token generation logic
- Token validation logic
- CF7 integration hook
- Admin token management UI
- Secure access endpoint

Code must be:
- Secure
- Well-documented
- Extendable
- WordPress coding standards compliant

---

## Final Instruction

Start by:
1. Designing the plugin folder structure
2. Creating the main plugin file
3. Implementing database schema creation
4. Implementing CF7 submission hook
5. Implementing token generation logic

Proceed step-by-step.
Explain decisions briefly when necessary.
Do NOT expand scope beyond this specification.
