/* CF7 Access Token Frontend JavaScript */

(function($) {
    'use strict';
    
    // Initialize when document is ready
    $(document).ready(function() {
        initCF7AccessToken();
    });
    
    function initCF7AccessToken() {
        // Add security notice for access pages
        addSecurityNotice();
        
        // Handle copy to clipboard functionality
        initCopyToClipboard();
        
        // Auto-refresh token info if needed
        initTokenRefresh();
    }
    
    function addSecurityNotice() {
        // Add a subtle security reminder
        if ($('.cf7at-access-page').length > 0) {
            console.log('CF7AT: Secure access page loaded');
            
            // Disable right-click context menu for security
            $(document).on('contextmenu', function(e) {
                if ($(e.target).closest('.cf7at-protected-content').length > 0) {
                    e.preventDefault();
                    return false;
                }
            });
        }
    }
    
    function initCopyToClipboard() {
        // Add copy buttons to data values if needed
        $('.cf7at-data-value').each(function() {
            var $value = $(this);
            var text = $value.text().trim();
            
            // Add copy button for longer text values
            if (text.length > 20) {
                var $copyBtn = $('<button class="cf7at-copy-btn" title="Copy to clipboard">📋</button>');
                $value.append($copyBtn);
                
                $copyBtn.on('click', function(e) {
                    e.preventDefault();
                    copyToClipboard(text);
                    showCopyFeedback($copyBtn);
                });
            }
        });
    }
    
    function copyToClipboard(text) {
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(text);
        } else {
            // Fallback for older browsers
            var textArea = document.createElement('textarea');
            textArea.value = text;
            textArea.style.position = 'fixed';
            textArea.style.left = '-999999px';
            textArea.style.top = '-999999px';
            document.body.appendChild(textArea);
            textArea.focus();
            textArea.select();
            
            try {
                document.execCommand('copy');
            } catch (err) {
                console.error('Failed to copy text: ', err);
            }
            
            document.body.removeChild(textArea);
        }
    }
    
    function showCopyFeedback($button) {
        var originalText = $button.text();
        $button.text('✓').addClass('copied');
        
        setTimeout(function() {
            $button.text(originalText).removeClass('copied');
        }, 2000);
    }
    
    function initTokenRefresh() {
        // Check if token is close to expiring and show warning
        var $tokenInfo = $('.cf7at-token-info');
        if ($tokenInfo.length > 0) {
            // This could be enhanced to show real-time expiration countdown
            checkTokenExpiration();
        }
    }
    
    function checkTokenExpiration() {
        // Parse expiration time from the page if available
        var expiryText = $('.cf7at-info-item:contains("Expires:")').text();
        if (expiryText) {
            // Could implement countdown timer here
            console.log('CF7AT: Token expiration monitoring active');
        }
    }
    
    // Utility function to show messages
    function showMessage(message, type) {
        var $message = $('<div class="cf7at-alert cf7at-alert-' + type + '">' + message + '</div>');
        $('.cf7at-main').prepend($message);
        
        setTimeout(function() {
            $message.fadeOut(function() {
                $message.remove();
            });
        }, 5000);
    }
    
    // Add some basic styling for copy buttons
    $('<style>')
        .prop('type', 'text/css')
        .html(`
            .cf7at-copy-btn {
                background: none;
                border: none;
                cursor: pointer;
                font-size: 12px;
                margin-left: 10px;
                opacity: 0.6;
                transition: opacity 0.2s;
            }
            .cf7at-copy-btn:hover {
                opacity: 1;
            }
            .cf7at-copy-btn.copied {
                color: #28a745;
            }
        `)
        .appendTo('head');
    
})(jQuery);