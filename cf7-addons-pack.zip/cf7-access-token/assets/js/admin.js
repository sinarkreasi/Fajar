/* CF7 Access Token Admin JavaScript */

(function($) {
    'use strict';
    
    $(document).ready(function() {
        initAdminInterface();
    });
    
    function initAdminInterface() {
        // Handle token actions
        initTokenActions();
        
        // Handle settings form
        initSettingsForm();
        
        // Handle bulk actions
        initBulkActions();
        
        // Initialize tooltips and help text
        initHelpSystem();
    }
    
    function initTokenActions() {
        // Revoke token
        $(document).on('click', '.cf7at-revoke-token', function(e) {
            e.preventDefault();
            
            var $button = $(this);
            var tokenId = $button.data('token-id');
            
            if (!confirm(cf7at_admin.strings.confirm_revoke)) {
                return;
            }
            
            revokeToken(tokenId, $button);
        });
        
        // Extend token
        $(document).on('click', '.cf7at-extend-token', function(e) {
            e.preventDefault();
            
            var $button = $(this);
            var tokenId = $button.data('token-id');
            
            if (!confirm(cf7at_admin.strings.confirm_extend)) {
                return;
            }
            
            extendToken(tokenId, $button);
        });
    }
    
    function revokeToken(tokenId, $button) {
        var $row = $button.closest('tr');
        
        showLoading($row);
        
        $.post(cf7at_admin.ajax_url, {
            action: 'cf7at_revoke_token',
            token_id: tokenId,
            nonce: cf7at_admin.nonce
        }, function(response) {
            hideLoading($row);
            
            if (response.success) {
                // Update status in the table
                $row.find('.cf7at-status').removeClass('cf7at-status-active')
                    .addClass('cf7at-status-revoked')
                    .text('REVOKED');
                
                // Disable action buttons
                $row.find('.cf7at-token-actions .button').prop('disabled', true);
                
                showNotice(response.data.message, 'success');
            } else {
                showNotice(response.data || 'Failed to revoke token', 'error');
            }
        }).fail(function() {
            hideLoading($row);
            showNotice('Network error occurred', 'error');
        });
    }
    
    function extendToken(tokenId, $button) {
        var $row = $button.closest('tr');
        
        showLoading($row);
        
        $.post(cf7at_admin.ajax_url, {
            action: 'cf7at_extend_token',
            token_id: tokenId,
            hours: 24,
            nonce: cf7at_admin.nonce
        }, function(response) {
            hideLoading($row);
            
            if (response.success) {
                showNotice(response.data.message, 'success');
                
                // Refresh the page to show updated expiration
                setTimeout(function() {
                    location.reload();
                }, 1000);
            } else {
                showNotice(response.data || 'Failed to extend token', 'error');
            }
        }).fail(function() {
            hideLoading($row);
            showNotice('Network error occurred', 'error');
        });
    }
    
    function initSettingsForm() {
        // Handle email template preview
        $('.cf7at-preview-email').on('click', function(e) {
            e.preventDefault();
            previewEmailTemplate();
        });
        
        // Handle template variable insertion
        $('.cf7at-insert-variable').on('click', function(e) {
            e.preventDefault();
            
            var variable = $(this).data('variable');
            var $textarea = $(this).closest('.cf7at-template-help').prev('textarea');
            
            insertAtCursor($textarea[0], variable);
        });
        
        // Validate settings form
        $('#cf7at-settings-form').on('submit', function(e) {
            var isValid = validateSettingsForm();
            
            if (!isValid) {
                e.preventDefault();
                showNotice('Please correct the highlighted fields.', 'error');
            }
        });
    }
    
    function previewEmailTemplate() {
        var subject = $('#email_subject').val();
        var message = $('#email_message').val();
        
        // Simple preview - could be enhanced with actual template parsing
        var previewWindow = window.open('', 'preview', 'width=600,height=400');
        previewWindow.document.write(`
            <html>
            <head><title>Email Preview</title></head>
            <body style="font-family: Arial, sans-serif; padding: 20px;">
                <h3>Subject: ${escapeHtml(subject)}</h3>
                <div style="border: 1px solid #ddd; padding: 15px; background: #f9f9f9;">
                    ${escapeHtml(message).replace(/\n/g, '<br>')}
                </div>
            </body>
            </html>
        `);
    }
    
    function insertAtCursor(textarea, text) {
        var startPos = textarea.selectionStart;
        var endPos = textarea.selectionEnd;
        var value = textarea.value;
        
        textarea.value = value.substring(0, startPos) + text + value.substring(endPos, value.length);
        textarea.selectionStart = textarea.selectionEnd = startPos + text.length;
        textarea.focus();
    }
    
    function validateSettingsForm() {
        var isValid = true;
        
        // Validate required fields
        $('[required]').each(function() {
            var $field = $(this);
            
            if (!$field.val().trim()) {
                $field.addClass('error');
                isValid = false;
            } else {
                $field.removeClass('error');
            }
        });
        
        // Validate email fields
        $('input[type="email"]').each(function() {
            var $field = $(this);
            var email = $field.val().trim();
            
            if (email && !isValidEmail(email)) {
                $field.addClass('error');
                isValid = false;
            } else {
                $field.removeClass('error');
            }
        });
        
        return isValid;
    }
    
    function initBulkActions() {
        // Handle bulk action form submission
        $('#doaction, #doaction2').on('click', function(e) {
            var action = $(this).siblings('select').val();
            
            if (action === 'revoke') {
                if (!confirm('Are you sure you want to revoke the selected tokens?')) {
                    e.preventDefault();
                    return false;
                }
            }
        });
    }
    
    function initHelpSystem() {
        // Toggle help sections
        $('.cf7at-help-toggle').on('click', function(e) {
            e.preventDefault();
            $(this).next('.cf7at-help-content').slideToggle();
        });
        
        // Add tooltips to help icons
        $('.cf7at-help-icon').each(function() {
            var $icon = $(this);
            var helpText = $icon.attr('title');
            
            if (helpText) {
                $icon.tooltip({
                    content: helpText,
                    position: { my: "left+15 center", at: "right center" }
                });
            }
        });
    }
    
    function showLoading($element) {
        $element.addClass('cf7at-loading');
    }
    
    function hideLoading($element) {
        $element.removeClass('cf7at-loading');
    }
    
    function showNotice(message, type) {
        var $notice = $('<div class="cf7at-notice ' + type + '">' + message + '</div>');
        $('.wrap h1').after($notice);
        
        // Auto-dismiss after 5 seconds
        setTimeout(function() {
            $notice.fadeOut(function() {
                $notice.remove();
            });
        }, 5000);
    }
    
    function isValidEmail(email) {
        var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
    
    function escapeHtml(text) {
        var map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        
        return text.replace(/[&<>"']/g, function(m) { return map[m]; });
    }
    
})(jQuery);