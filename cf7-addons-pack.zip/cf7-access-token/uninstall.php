<?php

// Prevent direct access
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Define plugin constants for uninstall
define( 'CF7AT_PLUGIN_DIR', dirname( __FILE__ ) );
define( 'CF7AT_TOKENS_TABLE', 'cf7_access_tokens' );

// Load the schema manager
require_once CF7AT_PLUGIN_DIR . '/includes/database/schemamanager.php';

// Remove database tables
CF7AT\Database\SchemaManager::drop_tables();

// Remove plugin options
delete_option( 'cf7at_options' );
delete_option( 'cf7at_db_version' );

// Remove scheduled events
wp_clear_scheduled_hook( 'cf7at_cleanup_expired_tokens' );

// Remove any transients
global $wpdb;
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_cf7at_%'" );
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_cf7at_%'" );

// Clear any cached data
wp_cache_flush();