# CF7 Access Token / Magic Link

A WordPress plugin that provides secure, passwordless access to Contact Form 7 submission data via magic links. No user accounts required.

## Features

- **Secure Token Generation**: Cryptographically secure random tokens with HMAC SHA256 hashing
- **Magic Link Email**: Automated email delivery with customizable templates
- **Access Control**: Token-based access to specific resources with expiration and usage limits
- **Rate Limiting**: Protection against brute-force token guessing attempts
- **Admin Management**: Complete token management interface with revocation and extension capabilities
- **HTTPS Enforcement**: Optional HTTPS requirement for secure access
- **Automatic Cleanup**: Scheduled cleanup of expired tokens

## Requirements

- WordPress 6.0+
- PHP 7.4+
- Contact Form 7 plugin
- HTTPS recommended for production

## Installation

1. Upload the plugin files to `/wp-content/plugins/cf7-access-token/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Configure settings in **Access Tokens > Settings**

## Quick Start

### 1. Enable Access Tokens for a CF7 Form

Add this hidden field to your Contact Form 7 form:

```
[hidden cf7at-enable "1"]
```

Or add these fields for more control:

```
[hidden cf7at-type "submission"]
[hidden cf7at-id "12345"]
```

### 2. Required Form Fields

Your form must include an email field (one of these names):
- `your-email`
- `email` 
- `customer-email`
- `user-email`

### 3. Example Form

```
<label> Your Email (required)
    [email* your-email] </label>

<label> Your Name
    [text* your-name] </label>

<label> Message
    [textarea your-message] </label>

[hidden cf7at-enable "1"]
[hidden cf7at-type "booking"]

[submit "Send"]
```

### 4. Test the Flow

1. Submit the form with a valid email
2. Check your email for the magic link
3. Click the link to access your submission data
4. View the secure access page with your information

## Configuration

### General Settings

- **Default Expiry Hours**: How long tokens remain valid (default: 72 hours)
- **Max Validation Attempts**: Rate limiting for failed token attempts (default: 5)
- **Require HTTPS**: Enforce HTTPS for access pages (recommended: enabled)
- **Cleanup Expired Tokens**: Automatically clean up expired tokens (recommended: enabled)

### Email Settings

- **From Name**: Sender name for magic link emails
- **From Email**: Sender email address
- **Subject Template**: Email subject with placeholder support
- **Message Template**: Email body with placeholder support

### Access Page Settings

- **Page Title**: Title shown on access pages
- **Success Message**: Message shown when access is granted
- **Error Message**: Message shown for invalid tokens
- **Expired Message**: Message shown for expired tokens

## Email Template Placeholders

Use these placeholders in your email templates:

- `{access_link}` - The magic link URL
- `{access_url}` - Same as access_link
- `{email}` - Recipient email address
- `{expiry_hours}` - Hours until expiration
- `{expiry_time}` - Formatted expiration date/time
- `{site_name}` - Your site name
- `{site_url}` - Your site URL
- `{related_type}` - Resource type (submission, order, etc.)
- `{related_id}` - Resource ID
- `{form_title}` - Contact Form 7 form title
- `{form_id}` - Contact Form 7 form ID

## Form Field Mapping

### Required Fields
- **Email**: `your-email`, `email`, `customer-email`, `user-email`

### Optional Control Fields
- **Enable Tokens**: `cf7at-enable` (set to "1")
- **Resource Type**: `cf7at-type` (submission, order, booking, subscription)
- **Resource ID**: `cf7at-id` (custom ID for the resource)
- **Usage Limit**: `cf7at-usage-limit` (number of times token can be used)

## Token Types

### Supported Resource Types

- **submission**: Form submission data (default)
- **order**: Order information
- **booking**: Booking details  
- **subscription**: Subscription data

You can add custom types using the `cf7at_related_types` filter.

## Security Features

### Token Security
- **Cryptographically Secure**: Uses `random_bytes()` or `openssl_random_pseudo_bytes()`
- **Secure Hashing**: HMAC SHA256 with WordPress salt
- **No Raw Storage**: Only hashed tokens stored in database
- **Time-Limited**: Configurable expiration times
- **Usage Limits**: Optional usage count restrictions

### Access Security
- **Rate Limiting**: Prevents brute-force attacks
- **HTTPS Enforcement**: Optional HTTPS requirement
- **IP Tracking**: Failed attempts tracked by IP
- **No Sessions**: Stateless access without persistent login
- **Scope Limitation**: Tokens grant access to one resource only

### Data Protection
- **Input Sanitization**: All inputs sanitized and validated
- **Output Escaping**: All outputs properly escaped
- **SQL Injection Protection**: Prepared statements throughout
- **XSS Prevention**: Content Security Policy headers
- **Cache Prevention**: No-cache headers on access pages

## Admin Interface

### Token Management

Access **Access Tokens > Tokens** to:

- View all generated tokens
- Filter by status (active, expired, revoked)
- Search by email or resource
- View token details and usage
- Revoke active tokens
- Extend token expiration
- Bulk actions for multiple tokens

### Token Information

Each token displays:
- Token status and creation date
- Associated email and resource
- Expiration time and usage count
- Last used timestamp
- Form submission data

## Hooks and Filters

### Actions

- `cf7at_init`: Plugin initialized
- `cf7at_token_created`: New token created
- `cf7at_token_status_updated`: Token status changed
- `cf7at_token_extended`: Token expiration extended
- `cf7at_render_protected_content`: Render custom protected content

### Filters

- `cf7at_related_types`: Add custom resource types
- `cf7at_email_placeholders`: Modify email template placeholders
- `cf7at_can_access_resource`: Custom access permission checks

## Shortcodes

### Protected Content

```
[cf7at_content type="submission" id="123"]
This content is only visible with a valid token for submission #123.
[/cf7at_content]
```

### Token Information

```
[cf7at_token_info field="email"]
[cf7at_token_info field="expires"]
[cf7at_token_info field="usage"]
[cf7at_token_info] <!-- Shows all info in a table -->
```

## Database Schema

### Access Tokens Table (`wp_cf7_access_tokens`)

- `id`: Primary key
- `token_hash`: Hashed token (never store raw token)
- `related_type`: Resource type (submission, order, etc.)
- `related_id`: Resource identifier
- `email`: Associated email address
- `expires_at`: Expiration timestamp
- `usage_limit`: Maximum usage count (optional)
- `usage_count`: Current usage count
- `status`: Token status (active, expired, revoked)
- `metadata`: JSON metadata (form data, etc.)
- `created_at`: Creation timestamp
- `last_used_at`: Last access timestamp

## API Integration

### Custom Resource Types

```php
// Add custom resource type
add_filter( 'cf7at_related_types', function( $types ) {
    $types['appointment'] = __( 'Appointment', 'textdomain' );
    return $types;
});
```

### Custom Content Rendering

```php
// Render custom protected content
add_action( 'cf7at_render_protected_content', function( $token_data ) {
    if ( $token_data['related_type'] === 'appointment' ) {
        // Display appointment details
        echo '<h3>Appointment Details</h3>';
        // ... custom content
    }
});
```

### Email Customization

```php
// Add custom email placeholders
add_filter( 'cf7at_email_placeholders', function( $placeholders, $token_data ) {
    $placeholders['{custom_field}'] = 'Custom Value';
    return $placeholders;
}, 10, 2 );
```

## Troubleshooting

### Common Issues

**Tokens not being generated:**
- Check that CF7 form has required email field
- Verify `cf7at-enable` field is present
- Check error logs for validation failures

**Magic link emails not sending:**
- Verify WordPress mail configuration
- Check spam/junk folders
- Test with different email providers
- Enable debug logging

**Access denied errors:**
- Check token expiration time
- Verify HTTPS requirements
- Check rate limiting settings
- Review error logs for details

### Debug Mode

Enable WordPress debug mode in `wp-config.php`:

```php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
```

Check `/wp-content/debug.log` for `[CF7AT]` prefixed messages.

### Testing Checklist

- [ ] CF7 form has email field
- [ ] Access token fields configured
- [ ] Email settings configured
- [ ] SMTP/mail working
- [ ] HTTPS enabled (production)
- [ ] Debug logging enabled
- [ ] Test with valid email address

## Performance

### Optimization Tips

- **Regular Cleanup**: Enable automatic expired token cleanup
- **Reasonable Expiry**: Don't set extremely long expiration times
- **Usage Limits**: Set appropriate usage limits for tokens
- **Database Indexing**: Plugin creates proper database indexes
- **Caching**: Access pages have no-cache headers for security

### Monitoring

- Monitor token creation rates
- Check cleanup job performance
- Review failed access attempts
- Monitor email delivery rates

## Security Best Practices

### Production Deployment

1. **Enable HTTPS**: Always use HTTPS in production
2. **Strong Passwords**: Use strong WordPress admin passwords
3. **Regular Updates**: Keep WordPress and plugins updated
4. **Backup Database**: Regular backups including token table
5. **Monitor Logs**: Review access logs regularly
6. **Rate Limiting**: Configure appropriate rate limits
7. **Email Security**: Use authenticated SMTP for emails

### Token Management

- Set reasonable expiration times (24-72 hours)
- Use usage limits for sensitive data
- Regularly review and revoke unused tokens
- Monitor for suspicious access patterns
- Clean up expired tokens regularly

## Support

For support and feature requests:

1. Check the troubleshooting section
2. Enable debug logging
3. Review error logs
4. Test with minimal configuration
5. Contact plugin support with logs

## License

GPL v2 or later - https://www.gnu.org/licenses/gpl-2.0.html