<?php
/**
 * Token detail template
 * 
 * @var array $token
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$is_expired = strtotime( $token['expires_at'] ) < time();
$is_revoked = $token['status'] === 'revoked';
$is_active = $token['status'] === 'active' && ! $is_expired;
?>

<div class="wrap">
	<h1 class="wp-heading-inline"><?php _e( 'Token Details', CF7AT_TEXT_DOMAIN ); ?></h1>
	<a href="<?php echo admin_url( 'admin.php?page=cf7at-tokens' ); ?>" class="page-title-action"><?php _e( 'Back to List', CF7AT_TEXT_DOMAIN ); ?></a>
	<hr class="wp-header-end">
	
	<div id="poststuff">
		<div id="post-body" class="metabox-holder columns-2">
			<div id="post-body-content">
				<!-- Token Information -->
				<div class="postbox">
					<h2 class="hndle"><span><?php _e( 'Token Information', CF7AT_TEXT_DOMAIN ); ?></span></h2>
					<div class="inside">
						<table class="form-table">
							<tr>
								<th><?php _e( 'Token ID:', CF7AT_TEXT_DOMAIN ); ?></th>
								<td><strong>#<?php echo esc_html( $token['id'] ); ?></strong></td>
							</tr>
							<tr>
								<th><?php _e( 'Status:', CF7AT_TEXT_DOMAIN ); ?></th>
								<td>
									<?php if ( $is_active ) : ?>
										<span class="cf7at-status cf7at-status-active"><?php _e( 'Active', CF7AT_TEXT_DOMAIN ); ?></span>
									<?php elseif ( $is_expired ) : ?>
										<span class="cf7at-status cf7at-status-expired"><?php _e( 'Expired', CF7AT_TEXT_DOMAIN ); ?></span>
									<?php elseif ( $is_revoked ) : ?>
										<span class="cf7at-status cf7at-status-revoked"><?php _e( 'Revoked', CF7AT_TEXT_DOMAIN ); ?></span>
									<?php endif; ?>
								</td>
							</tr>
							<tr>
								<th><?php _e( 'Email:', CF7AT_TEXT_DOMAIN ); ?></th>
								<td><?php echo esc_html( $token['email'] ); ?></td>
							</tr>
							<tr>
								<th><?php _e( 'Related Type:', CF7AT_TEXT_DOMAIN ); ?></th>
								<td><?php echo esc_html( ucfirst( $token['related_type'] ) ); ?></td>
							</tr>
							<tr>
								<th><?php _e( 'Related ID:', CF7AT_TEXT_DOMAIN ); ?></th>
								<td>#<?php echo esc_html( $token['related_id'] ); ?></td>
							</tr>
							<tr>
								<th><?php _e( 'Created:', CF7AT_TEXT_DOMAIN ); ?></th>
								<td><?php echo esc_html( $token['created_at'] ); ?></td>
							</tr>
							<tr>
								<th><?php _e( 'Expires:', CF7AT_TEXT_DOMAIN ); ?></th>
								<td>
									<?php echo esc_html( $token['expires_at'] ); ?>
									<?php if ( $is_expired ) : ?>
										<span style="color: #d63638;">(<?php _e( 'Expired', CF7AT_TEXT_DOMAIN ); ?>)</span>
									<?php endif; ?>
								</td>
							</tr>
							<tr>
								<th><?php _e( 'Last Used:', CF7AT_TEXT_DOMAIN ); ?></th>
								<td>
									<?php if ( $token['last_used_at'] ) : ?>
										<?php echo esc_html( $token['last_used_at'] ); ?>
									<?php else : ?>
										<em><?php _e( 'Never', CF7AT_TEXT_DOMAIN ); ?></em>
									<?php endif; ?>
								</td>
							</tr>
							<tr>
								<th><?php _e( 'Usage Count:', CF7AT_TEXT_DOMAIN ); ?></th>
								<td>
									<?php echo esc_html( $token['usage_count'] ); ?>
									<?php if ( $token['usage_limit'] ) : ?>
										/ <?php echo esc_html( $token['usage_limit'] ); ?>
									<?php else : ?>
										/ <?php _e( 'Unlimited', CF7AT_TEXT_DOMAIN ); ?>
									<?php endif; ?>
								</td>
							</tr>
						</table>
					</div>
				</div>
				
				<!-- Metadata -->
				<?php if ( ! empty( $token['metadata'] ) && is_array( $token['metadata'] ) ) : ?>
					<div class="postbox">
						<h2 class="hndle"><span><?php _e( 'Metadata', CF7AT_TEXT_DOMAIN ); ?></span></h2>
						<div class="inside">
							<table class="widefat striped">
								<thead>
									<tr>
										<th><?php _e( 'Key', CF7AT_TEXT_DOMAIN ); ?></th>
										<th><?php _e( 'Value', CF7AT_TEXT_DOMAIN ); ?></th>
									</tr>
								</thead>
								<tbody>
									<?php foreach ( $token['metadata'] as $key => $value ) : ?>
										<tr>
											<td><strong><?php echo esc_html( $key ); ?></strong></td>
											<td>
												<?php 
												if ( is_array( $value ) || is_object( $value ) ) {
													echo '<pre>' . esc_html( print_r( $value, true ) ) . '</pre>';
												} else {
													echo esc_html( $value );
												}
												?>
											</td>
										</tr>
									<?php endforeach; ?>
								</tbody>
							</table>
						</div>
					</div>
				<?php endif; ?>
				
				<!-- Access Log -->
				<div class="postbox">
					<h2 class="hndle"><span><?php _e( 'Access Log', CF7AT_TEXT_DOMAIN ); ?></span></h2>
					<div class="inside">
						<?php
						global $wpdb;
						$table_name = $wpdb->prefix . 'cf7_access_logs';
						
						// Check if access logs table exists
						if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) === $table_name ) {
							$logs = $wpdb->get_results(
								$wpdb->prepare(
									"SELECT * FROM $table_name WHERE token_id = %d ORDER BY accessed_at DESC LIMIT 20",
									$token['id']
								),
								ARRAY_A
							);
							
							if ( $logs ) : ?>
								<table class="widefat striped">
									<thead>
										<tr>
											<th><?php _e( 'Date/Time', CF7AT_TEXT_DOMAIN ); ?></th>
											<th><?php _e( 'IP Address', CF7AT_TEXT_DOMAIN ); ?></th>
											<th><?php _e( 'User Agent', CF7AT_TEXT_DOMAIN ); ?></th>
										</tr>
									</thead>
									<tbody>
										<?php foreach ( $logs as $log ) : ?>
											<tr>
												<td><?php echo esc_html( $log['accessed_at'] ); ?></td>
												<td><?php echo esc_html( $log['ip_address'] ); ?></td>
												<td><?php echo esc_html( substr( $log['user_agent'], 0, 100 ) ); ?></td>
											</tr>
										<?php endforeach; ?>
									</tbody>
								</table>
							<?php else : ?>
								<p><em><?php _e( 'No access logs found.', CF7AT_TEXT_DOMAIN ); ?></em></p>
							<?php endif;
						} else {
							echo '<p><em>' . __( 'Access logging is not enabled.', CF7AT_TEXT_DOMAIN ) . '</em></p>';
						}
						?>
					</div>
				</div>
			</div>
			
			<!-- Sidebar -->
			<div id="postbox-container-1" class="postbox-container">
				<!-- Actions -->
				<div class="postbox">
					<h2 class="hndle"><span><?php _e( 'Actions', CF7AT_TEXT_DOMAIN ); ?></span></h2>
					<div class="inside">
						<?php if ( $is_active ) : ?>
							<p>
								<button type="button" class="button button-primary" onclick="cf7atExtendToken(<?php echo $token['id']; ?>)">
									<?php _e( 'Extend Expiration', CF7AT_TEXT_DOMAIN ); ?>
								</button>
							</p>
							<p>
								<button type="button" class="button" onclick="cf7atRevokeToken(<?php echo $token['id']; ?>)">
									<?php _e( 'Revoke Token', CF7AT_TEXT_DOMAIN ); ?>
								</button>
							</p>
						<?php elseif ( $is_expired ) : ?>
							<p>
								<button type="button" class="button button-primary" onclick="cf7atExtendToken(<?php echo $token['id']; ?>, 72)">
									<?php _e( 'Reactivate (72h)', CF7AT_TEXT_DOMAIN ); ?>
								</button>
							</p>
						<?php endif; ?>
					</div>
				</div>
				
				<!-- Access Link -->
				<?php if ( $is_active ) : ?>
					<div class="postbox">
						<h2 class="hndle"><span><?php _e( 'Access Link', CF7AT_TEXT_DOMAIN ); ?></span></h2>
						<div class="inside">
							<p><?php _e( 'This is a preview only. The actual token is hashed and cannot be displayed.', CF7AT_TEXT_DOMAIN ); ?></p>
							<p>
								<code style="word-break: break-all; display: block; padding: 10px; background: #f0f0f0;">
									<?php echo esc_url( home_url( '/access/' . str_repeat( '*', 32 ) ) ); ?>
								</code>
							</p>
							<p class="description"><?php _e( 'The actual link was sent to the user via email.', CF7AT_TEXT_DOMAIN ); ?></p>
						</div>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>

<script>
function cf7atRevokeToken(tokenId) {
	if (!confirm(cf7at_admin.strings.confirm_revoke)) {
		return;
	}
	
	jQuery.post(cf7at_admin.ajax_url, {
		action: 'cf7at_revoke_token',
		nonce: cf7at_admin.nonce,
		token_id: tokenId
	}, function(response) {
		if (response.success) {
			alert(response.data.message);
			location.reload();
		} else {
			alert(response.data || 'Failed to revoke token');
		}
	});
}

function cf7atExtendToken(tokenId, hours) {
	hours = hours || 24;
	
	if (!confirm(cf7at_admin.strings.confirm_extend)) {
		return;
	}
	
	jQuery.post(cf7at_admin.ajax_url, {
		action: 'cf7at_extend_token',
		nonce: cf7at_admin.nonce,
		token_id: tokenId,
		hours: hours
	}, function(response) {
		if (response.success) {
			alert(response.data.message);
			location.reload();
		} else {
			alert(response.data || 'Failed to extend token');
		}
	});
}
</script>
