<?php

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Autoloader
spl_autoload_register( 'cf7at_autoloader' );

function cf7at_autoloader( $class ) {
	// Only handle our namespace
	if ( strpos( $class, 'CF7AT\\' ) !== 0 ) {
		return;
	}
	
	// Remove namespace prefix
	$class = substr( $class, 6 );
	
	// Convert namespace separators to directory separators
	$class = str_replace( '\\', DIRECTORY_SEPARATOR, $class );
	
	// Convert to lowercase and add .php extension
	$file = CF7AT_PLUGIN_DIR . '/includes/' . strtolower( $class ) . '.php';
	
	if ( file_exists( $file ) ) {
		require_once $file;
	}
}

// Load core files
require_once CF7AT_PLUGIN_DIR . '/includes/functions.php';

// Initialize plugin
function cf7at_init() {
	// Load text domain
	load_plugin_textdomain( CF7AT_TEXT_DOMAIN, false, dirname( CF7AT_PLUGIN_BASENAME ) . '/languages' );
	
	// Initialize core components
	CF7AT\Core\Plugin::instance();
	
	// Hook into CF7
	CF7AT\Integrations\CF7Listener::instance();
	
	// Initialize frontend access controller
	CF7AT\Frontend\AccessController::instance();
	
	// Initialize admin if in admin area
	if ( is_admin() ) {
		CF7AT\Admin\AdminInit::instance();
	}
	
	do_action( 'cf7at_init' );
}

// Hook plugin initialization
add_action( 'init', 'cf7at_plugin_init', 20 );

function cf7at_plugin_init() {
	// Register rewrite rules for access endpoint
	add_rewrite_rule( 
		'^access/?$', 
		'index.php?cf7at_access=1', 
		'top' 
	);
	
	// Add query vars
	add_filter( 'query_vars', function( $vars ) {
		$vars[] = 'cf7at_access';
		$vars[] = 'token';
		return $vars;
	});
}