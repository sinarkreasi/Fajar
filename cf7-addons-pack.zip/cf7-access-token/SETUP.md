# CF7 Access Token Setup Guide

Quick setup guide for the CF7 Access Token / Magic Link plugin.

## Installation Steps

### 1. Install the Plugin
1. Upload the `cf7-access-token` folder to `/wp-content/plugins/`
2. Activate the plugin in WordPress admin
3. Ensure Contact Form 7 is installed and activated

### 2. Configure Basic Settings
1. Go to **Access Tokens > Settings**
2. Configure these essential settings:
   - **Default Expiry Hours**: 72 (recommended)
   - **Require HTTPS**: Enable for production
   - **From Email**: Your site's email address
   - **From Name**: Your site name

### 3. Set Up Email Template
1. In **Access Tokens > Settings** > **Email Notifications**
2. Customize the email subject and message
3. Use placeholders like `{access_link}` and `{site_name}`
4. Test email delivery

### 4. Create Your First Form
1. Go to **Contact > Contact Forms**
2. Create a new form or edit existing
3. Add this basic structure:

```
<label> Your Email (required)
    [email* your-email] </label>

<label> Your Name
    [text* your-name] </label>

<label> Message
    [textarea your-message] </label>

[hidden cf7at-enable "1"]

[submit "Send"]
```

### 5. Test the Flow
1. Submit the form with your email
2. Check your email for the magic link
3. Click the link to access the secure page
4. Verify your submission data is displayed

## Quick Configuration Checklist

- [ ] Plugin activated
- [ ] Contact Form 7 installed
- [ ] Email settings configured
- [ ] HTTPS enabled (production)
- [ ] Test form created with `cf7at-enable` field
- [ ] Email delivery tested
- [ ] Magic link access tested
- [ ] Admin token management tested

## Common Form Configurations

### Basic Contact Form
```
[email* your-email]
[text* your-name]
[textarea your-message]
[hidden cf7at-enable "1"]
```

### Booking Form
```
[email* customer-email]
[text* full-name]
[date preferred-date]
[hidden cf7at-enable "1"]
[hidden cf7at-type "booking"]
```

### Support Request
```
[email* your-email]
[text* subject]
[textarea* description]
[hidden cf7at-enable "1"]
[hidden cf7at-type "support"]
[hidden cf7at-usage-limit "5"]
```

## Security Recommendations

### Production Setup
1. **Enable HTTPS**: Always use SSL certificates
2. **Strong Passwords**: Use strong WordPress admin passwords
3. **Regular Updates**: Keep WordPress and plugins updated
4. **Email Security**: Use authenticated SMTP
5. **Monitor Access**: Review token usage regularly

### Token Settings
- Set reasonable expiry times (24-72 hours)
- Use usage limits for sensitive data
- Enable automatic cleanup of expired tokens
- Monitor failed access attempts

## Troubleshooting

### Emails Not Sending
1. Check WordPress mail configuration
2. Test with different email providers
3. Verify SMTP settings
4. Check spam/junk folders

### Access Denied Errors
1. Verify token hasn't expired
2. Check HTTPS requirements
3. Review rate limiting settings
4. Check error logs

### Form Not Generating Tokens
1. Ensure `cf7at-enable` field is present
2. Verify email field exists and is valid
3. Check CF7 form submission success
4. Review plugin error logs

## Advanced Configuration

### Custom Resource Types
```php
add_filter( 'cf7at_related_types', function( $types ) {
    $types['appointment'] = 'Appointment';
    return $types;
});
```

### Custom Email Placeholders
```php
add_filter( 'cf7at_email_placeholders', function( $placeholders, $token_data ) {
    $placeholders['{custom_field}'] = 'Custom Value';
    return $placeholders;
}, 10, 2 );
```

### Custom Protected Content
```php
add_action( 'cf7at_render_protected_content', function( $token_data ) {
    if ( $token_data['related_type'] === 'appointment' ) {
        echo '<h3>Appointment Details</h3>';
        // Display custom content
    }
});
```

## Support

For additional help:
1. Check the full README.md documentation
2. Review example forms in `/examples/`
3. Enable debug logging for troubleshooting
4. Check WordPress error logs for CF7AT messages

## Next Steps

After basic setup:
1. Customize email templates
2. Set up custom resource types if needed
3. Configure usage limits and expiry times
4. Monitor token usage and cleanup
5. Implement custom protected content rendering