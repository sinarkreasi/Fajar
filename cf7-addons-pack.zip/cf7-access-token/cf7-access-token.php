<?php
/*
 * Plugin Name: CF7 Access Token / Magic Link
 * Plugin URI: https://github.com/cf7-access-token/cf7-access-token
 * Description: Secure, passwordless access to Contact Form 7 submission data via magic links. No user accounts required.
 * Author: CF7 Access Token Team
 * Version: 1.0.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Text Domain: cf7-access-token
 * Domain Path: /languages
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Plugin version
define( 'CF7AT_VERSION', '1.0.0' );

// Plugin constants
define( 'CF7AT_PLUGIN_FILE', __FILE__ );
define( 'CF7AT_PLUGIN_BASENAME', plugin_basename( CF7AT_PLUGIN_FILE ) );
define( 'CF7AT_PLUGIN_DIR', untrailingslashit( dirname( CF7AT_PLUGIN_FILE ) ) );
define( 'CF7AT_PLUGIN_URL', untrailingslashit( plugins_url( '', CF7AT_PLUGIN_FILE ) ) );
define( 'CF7AT_TEXT_DOMAIN', 'cf7-access-token' );

// Database table name
define( 'CF7AT_TOKENS_TABLE', 'cf7_access_tokens' );

// Security constants
define( 'CF7AT_TOKEN_LENGTH', 32 );
define( 'CF7AT_DEFAULT_EXPIRY_HOURS', 72 );
define( 'CF7AT_MAX_VALIDATION_ATTEMPTS', 5 );

// Check if Contact Form 7 is active
add_action( 'plugins_loaded', 'cf7at_check_dependencies' );

function cf7at_check_dependencies() {
	if ( ! class_exists( 'WPCF7' ) ) {
		add_action( 'admin_notices', 'cf7at_cf7_missing_notice' );
		return;
	}
	
	// Initialize plugin
	cf7at_init();
}

function cf7at_cf7_missing_notice() {
	?>
	<div class="notice notice-error">
		<p><?php _e( 'CF7 Access Token requires Contact Form 7 to be installed and activated.', CF7AT_TEXT_DOMAIN ); ?></p>
	</div>
	<?php
}

// Load plugin files
require_once CF7AT_PLUGIN_DIR . '/load.php';

// Plugin activation hook
register_activation_hook( CF7AT_PLUGIN_FILE, 'cf7at_activate' );

// Plugin deactivation hook
register_deactivation_hook( CF7AT_PLUGIN_FILE, 'cf7at_deactivate' );

/**
 * Plugin activation callback
 */
function cf7at_activate() {
	// Create database tables
	CF7AT\Database\SchemaManager::create_tables();
	
	// Set default options
	CF7AT\Core\OptionsManager::set_defaults();
	
	// Add rewrite rules
	CF7AT\Frontend\AccessController::add_rewrite_rules();
	
	// Flush rewrite rules
	flush_rewrite_rules();
}

/**
 * Plugin deactivation callback
 */
function cf7at_deactivate() {
	// Flush rewrite rules
	flush_rewrite_rules();
}