<?php

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Get plugin option
 *
 * @param string $name Option name
 * @param mixed $default Default value
 * @return mixed
 */
function cf7at_get_option( $name, $default = false ) {
	$options = get_option( 'cf7at_options', array() );
	return isset( $options[ $name ] ) ? $options[ $name ] : $default;
}

/**
 * Update plugin option
 *
 * @param string $name Option name
 * @param mixed $value Option value
 */
function cf7at_update_option( $name, $value ) {
	$options = get_option( 'cf7at_options', array() );
	$options[ $name ] = $value;
	update_option( 'cf7at_options', $options );
}

/**
 * Generate cryptographically secure token
 *
 * @param int $length Token length
 * @return string
 */
function cf7at_generate_secure_token( $length = CF7AT_TOKEN_LENGTH ) {
	if ( function_exists( 'random_bytes' ) ) {
		return bin2hex( random_bytes( $length / 2 ) );
	} elseif ( function_exists( 'openssl_random_pseudo_bytes' ) ) {
		return bin2hex( openssl_random_pseudo_bytes( $length / 2 ) );
	} else {
		// Fallback for older PHP versions
		return wp_generate_password( $length, false );
	}
}

/**
 * Hash token for secure storage
 *
 * @param string $token Raw token
 * @return string Hashed token
 */
function cf7at_hash_token( $token ) {
	return hash_hmac( 'sha256', $token, wp_salt( 'auth' ) );
}

/**
 * Verify token hash
 *
 * @param string $token Raw token
 * @param string $hash Stored hash
 * @return bool
 */
function cf7at_verify_token( $token, $hash ) {
	return hash_equals( $hash, cf7at_hash_token( $token ) );
}

/**
 * Get token statuses
 *
 * @return array
 */
function cf7at_get_token_statuses() {
	return array(
		'active'  => __( 'Active', CF7AT_TEXT_DOMAIN ),
		'expired' => __( 'Expired', CF7AT_TEXT_DOMAIN ),
		'revoked' => __( 'Revoked', CF7AT_TEXT_DOMAIN ),
	);
}

/**
 * Get related types
 *
 * @return array
 */
function cf7at_get_related_types() {
	$types = array(
		'submission'   => __( 'Form Submission', CF7AT_TEXT_DOMAIN ),
		'order'        => __( 'Order', CF7AT_TEXT_DOMAIN ),
		'booking'      => __( 'Booking', CF7AT_TEXT_DOMAIN ),
		'subscription' => __( 'Subscription', CF7AT_TEXT_DOMAIN ),
	);
	
	return apply_filters( 'cf7at_related_types', $types );
}

/**
 * Log debug message
 *
 * @param string $message
 * @param string $level
 */
function cf7at_log( $message, $level = 'info' ) {
	if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
		error_log( sprintf( '[CF7AT %s] %s', strtoupper( $level ), $message ) );
	}
}

/**
 * Check if HTTPS is required and enforced
 *
 * @return bool
 */
function cf7at_is_https_required() {
	return cf7at_get_option( 'require_https', true ) && ! is_ssl() && ! wp_get_environment_type() === 'local';
}

/**
 * Get access URL for token
 *
 * @param string $token Raw token
 * @return string
 */
function cf7at_get_access_url( $token ) {
	$base_url = home_url( '/access/' );
	return add_query_arg( 'token', $token, $base_url );
}

/**
 * Sanitize related type
 *
 * @param string $type
 * @return string
 */
function cf7at_sanitize_related_type( $type ) {
	$allowed_types = array_keys( cf7at_get_related_types() );
	return in_array( $type, $allowed_types ) ? $type : 'submission';
}

/**
 * Format date for display
 *
 * @param string $date
 * @return string
 */
function cf7at_format_date( $date ) {
	if ( empty( $date ) || $date === '0000-00-00 00:00:00' ) {
		return '—';
	}
	
	return date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $date ) );
}

/**
 * Check if token is expired
 *
 * @param string $expires_at
 * @return bool
 */
function cf7at_is_token_expired( $expires_at ) {
	if ( empty( $expires_at ) || $expires_at === '0000-00-00 00:00:00' ) {
		return false; // No expiration set
	}
	
	return strtotime( $expires_at ) < time();
}

/**
 * Get time until expiration
 *
 * @param string $expires_at
 * @return string
 */
function cf7at_get_time_until_expiration( $expires_at ) {
	if ( empty( $expires_at ) || $expires_at === '0000-00-00 00:00:00' ) {
		return __( 'Never', CF7AT_TEXT_DOMAIN );
	}
	
	$time_diff = strtotime( $expires_at ) - time();
	
	if ( $time_diff <= 0 ) {
		return __( 'Expired', CF7AT_TEXT_DOMAIN );
	}
	
	return human_time_diff( time(), strtotime( $expires_at ) );
}