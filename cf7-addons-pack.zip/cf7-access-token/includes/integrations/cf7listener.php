<?php

namespace CF7AT\Integrations;

use CF7AT\Core\TokenManager;
use CF7AT\Emails\EmailBuilder;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Contact Form 7 integration class
 */
class CF7Listener {
	
	/**
	 * Instance
	 *
	 * @var CF7Listener
	 */
	private static $instance = null;
	
	/**
	 * Get instance
	 *
	 * @return CF7Listener
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		$this->init_hooks();
	}
	
	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		add_action( 'wpcf7_mail_sent', array( $this, 'process_form_submission' ), 10, 1 );
		add_filter( 'wpcf7_form_tag', array( $this, 'add_access_token_fields' ), 10, 2 );
	}
	
	/**
	 * Process form submission and generate access token
	 *
	 * @param WPCF7_ContactForm $contact_form
	 */
	public function process_form_submission( $contact_form ) {
		// Check if this form should generate access tokens
		if ( ! $this->should_generate_token( $contact_form ) ) {
			return;
		}
		
		$submission = \WPCF7_Submission::get_instance();
		
		if ( ! $submission ) {
			return;
		}
		
		$form_data = $submission->get_posted_data();
		
		// Extract required data
		$email = $this->extract_email( $form_data );
		$related_data = $this->extract_related_data( $form_data, $contact_form );
		
		if ( empty( $email ) || empty( $related_data ) ) {
			cf7at_log( 'Missing required data for token generation: email or related data', 'warning' );
			return;
		}
		
		// Create access token
		$token_manager = new TokenManager();
		
		$token_data = array(
			'related_type' => $related_data['type'],
			'related_id'   => $related_data['id'],
			'email'        => $email,
			'usage_limit'  => $this->get_usage_limit( $contact_form ),
			'metadata'     => array(
				'form_id'    => $contact_form->id(),
				'form_title' => $contact_form->title(),
				'form_data'  => $this->sanitize_form_data( $form_data ),
				'ip_address' => $this->get_client_ip(),
				'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
			),
		);
		
		$token_id = $token_manager->create_token( $token_data );
		
		if ( ! $token_id ) {
			cf7at_log( 'Failed to create access token for form submission', 'error' );
			return;
		}
		
		// Send magic link email
		$this->send_magic_link_email( $token_id, $email, $contact_form );
		
		cf7at_log( "Access token created for form {$contact_form->id()}: token ID {$token_id}" );
	}
	
	/**
	 * Check if form should generate access tokens
	 *
	 * @param WPCF7_ContactForm $contact_form
	 * @return bool
	 */
	private function should_generate_token( $contact_form ) {
		$form_content = $contact_form->prop( 'form' );
		
		// Check for access token specific fields or tags
		$token_indicators = array(
			'cf7at-enable',
			'access-token',
			'magic-link',
			'secure-access',
		);
		
		foreach ( $token_indicators as $indicator ) {
			if ( strpos( $form_content, $indicator ) !== false ) {
				return true;
			}
		}
		
		// Check form properties for access token flag
		$properties = $contact_form->get_properties();
		return ! empty( $properties['cf7at_enabled'] );
	}
	
	/**
	 * Extract email from form data
	 *
	 * @param array $form_data
	 * @return string
	 */
	private function extract_email( $form_data ) {
		$email_fields = array( 'your-email', 'email', 'customer-email', 'user-email' );
		
		foreach ( $email_fields as $field ) {
			if ( ! empty( $form_data[ $field ] ) && is_email( $form_data[ $field ] ) ) {
				return sanitize_email( $form_data[ $field ] );
			}
		}
		
		return '';
	}
	
	/**
	 * Extract related data (resource type and ID)
	 *
	 * @param array $form_data
	 * @param WPCF7_ContactForm $contact_form
	 * @return array
	 */
	private function extract_related_data( $form_data, $contact_form ) {
		// Check for explicit related type and ID
		$related_type = $form_data['cf7at-type'] ?? $form_data['related-type'] ?? 'submission';
		$related_id = $form_data['cf7at-id'] ?? $form_data['related-id'] ?? null;
		
		// If no explicit ID provided, use form submission ID or form ID
		if ( empty( $related_id ) ) {
			$submission = \WPCF7_Submission::get_instance();
			$related_id = $submission ? $submission->get_meta( 'timestamp' ) : $contact_form->id();
		}
		
		return array(
			'type' => cf7at_sanitize_related_type( $related_type ),
			'id'   => absint( $related_id ),
		);
	}
	
	/**
	 * Get usage limit for form
	 *
	 * @param WPCF7_ContactForm $contact_form
	 * @return int|null
	 */
	private function get_usage_limit( $contact_form ) {
		$properties = $contact_form->get_properties();
		
		if ( isset( $properties['cf7at_usage_limit'] ) ) {
			return absint( $properties['cf7at_usage_limit'] );
		}
		
		return cf7at_get_option( 'default_usage_limit', null );
	}
	
	/**
	 * Send magic link email
	 *
	 * @param int $token_id
	 * @param string $email
	 * @param WPCF7_ContactForm $contact_form
	 */
	private function send_magic_link_email( $token_id, $email, $contact_form ) {
		$email_options = \CF7AT\Core\OptionsManager::get_email_options();
		
		if ( empty( $email_options['send_magic_link'] ) ) {
			return;
		}
		
		$email_builder = new EmailBuilder();
		$email_builder->send_magic_link_email( $token_id, $email, $contact_form );
	}
	
	/**
	 * Sanitize form data for storage
	 *
	 * @param array $form_data
	 * @return array
	 */
	private function sanitize_form_data( $form_data ) {
		$sanitized = array();
		
		foreach ( $form_data as $key => $value ) {
			// Skip sensitive fields
			if ( in_array( $key, array( 'password', 'pass', 'pwd' ) ) ) {
				continue;
			}
			
			$key = sanitize_key( $key );
			
			if ( is_array( $value ) ) {
				$sanitized[ $key ] = array_map( 'sanitize_text_field', $value );
			} else {
				$sanitized[ $key ] = sanitize_text_field( $value );
			}
		}
		
		return $sanitized;
	}
	
	/**
	 * Get client IP address
	 *
	 * @return string
	 */
	private function get_client_ip() {
		$ip_keys = array(
			'HTTP_CF_CONNECTING_IP',
			'HTTP_CLIENT_IP',
			'HTTP_X_FORWARDED_FOR',
			'HTTP_X_FORWARDED',
			'HTTP_X_CLUSTER_CLIENT_IP',
			'HTTP_FORWARDED_FOR',
			'HTTP_FORWARDED',
			'REMOTE_ADDR'
		);
		
		foreach ( $ip_keys as $key ) {
			if ( array_key_exists( $key, $_SERVER ) === true ) {
				$ip = $_SERVER[ $key ];
				
				if ( strpos( $ip, ',' ) !== false ) {
					$ip = explode( ',', $ip )[0];
				}
				
				$ip = trim( $ip );
				
				if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
					return $ip;
				}
			}
		}
		
		return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
	}
	
	/**
	 * Add access token fields to CF7 form tags
	 *
	 * @param array $tag
	 * @param bool $unused
	 * @return array
	 */
	public function add_access_token_fields( $tag, $unused ) {
		// Add custom form tags for access token configuration
		if ( $tag['type'] === 'cf7at-enable' ) {
			$tag['name'] = 'cf7at-enable';
			$tag['type'] = 'hidden';
			$tag['values'] = array( '1' );
		}
		
		return $tag;
	}
}