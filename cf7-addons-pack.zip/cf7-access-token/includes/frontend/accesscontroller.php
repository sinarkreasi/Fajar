<?php

namespace CF7AT\Frontend;

use CF7AT\Core\AccessValidator;
use CF7AT\Core\OptionsManager;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Frontend access controller class
 */
class AccessController {
	
	/**
	 * Instance
	 *
	 * @var AccessController
	 */
	private static $instance = null;
	
	/**
	 * Current token data
	 *
	 * @var array|null
	 */
	private $current_token_data = null;
	
	/**
	 * Get instance
	 *
	 * @return AccessController
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		$this->init_hooks();
	}
	
	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		add_action( 'template_redirect', array( $this, 'handle_access_request' ) );
		add_shortcode( 'cf7at_content', array( $this, 'render_protected_content' ) );
		add_shortcode( 'cf7at_token_info', array( $this, 'render_token_info' ) );
	}
	
	/**
	 * Add rewrite rules
	 */
	public static function add_rewrite_rules() {
		add_rewrite_rule( 
			'^access/?$', 
			'index.php?cf7at_access=1', 
			'top' 
		);
	}
	
	/**
	 * Handle access request
	 */
	public function handle_access_request() {
		if ( ! get_query_var( 'cf7at_access' ) ) {
			return;
		}
		
		$token = sanitize_text_field( $_GET['token'] ?? '' );
		
		if ( empty( $token ) ) {
			$this->display_access_page( null, 'missing_token' );
			return;
		}
		
		// Validate access
		$validator = new AccessValidator();
		$validation_result = $validator->validate_access( $token );
		
		if ( ! $validation_result['valid'] ) {
			$this->display_access_page( null, $validation_result['error'], $validation_result['message'] );
			return;
		}
		
		// Store token data for use in content rendering
		$this->current_token_data = $validation_result['token_data'];
		
		// Display access page with content
		$this->display_access_page( $this->current_token_data );
	}
	
	/**
	 * Display access page
	 *
	 * @param array|null $token_data
	 * @param string $error_type
	 * @param string $error_message
	 */
	private function display_access_page( $token_data = null, $error_type = '', $error_message = '' ) {
		$page_options = OptionsManager::get_access_page_options();
		
		// Set page title
		$page_title = $page_options['page_title'] ?? __( 'Secure Access', CF7AT_TEXT_DOMAIN );
		
		// Determine content to display
		if ( $token_data ) {
			$content = $this->render_success_content( $token_data );
		} else {
			$content = $this->render_error_content( $error_type, $error_message );
		}
		
		// Display the page
		$this->render_access_page( $page_title, $content, $token_data );
		exit;
	}
	
	/**
	 * Render success content
	 *
	 * @param array $token_data
	 * @return string
	 */
	private function render_success_content( $token_data ) {
		$page_options = OptionsManager::get_access_page_options();
		$success_message = $page_options['success_message'] ?? __( 'Access granted.', CF7AT_TEXT_DOMAIN );
		
		ob_start();
		?>
		<div class="cf7at-success-message">
			<div class="cf7at-alert cf7at-alert-success">
				<?php echo esc_html( $success_message ); ?>
			</div>
		</div>
		
		<div class="cf7at-token-info">
			<h3><?php _e( 'Access Information', CF7AT_TEXT_DOMAIN ); ?></h3>
			<div class="cf7at-info-grid">
				<div class="cf7at-info-item">
					<strong><?php _e( 'Type:', CF7AT_TEXT_DOMAIN ); ?></strong>
					<?php echo esc_html( ucfirst( $token_data['related_type'] ) ); ?>
				</div>
				<div class="cf7at-info-item">
					<strong><?php _e( 'Reference ID:', CF7AT_TEXT_DOMAIN ); ?></strong>
					<?php echo esc_html( $token_data['related_id'] ); ?>
				</div>
				<div class="cf7at-info-item">
					<strong><?php _e( 'Email:', CF7AT_TEXT_DOMAIN ); ?></strong>
					<?php echo esc_html( $token_data['email'] ); ?>
				</div>
				<div class="cf7at-info-item">
					<strong><?php _e( 'Expires:', CF7AT_TEXT_DOMAIN ); ?></strong>
					<?php echo cf7at_format_date( $token_data['expires_at'] ); ?>
				</div>
				<?php if ( ! empty( $token_data['usage_limit'] ) ) : ?>
				<div class="cf7at-info-item">
					<strong><?php _e( 'Usage:', CF7AT_TEXT_DOMAIN ); ?></strong>
					<?php printf( __( '%d of %d', CF7AT_TEXT_DOMAIN ), $token_data['usage_count'], $token_data['usage_limit'] ); ?>
				</div>
				<?php endif; ?>
			</div>
		</div>
		
		<div class="cf7at-protected-content">
			<?php echo $this->render_protected_data( $token_data ); ?>
		</div>
		<?php
		
		return ob_get_clean();
	}
	
	/**
	 * Render error content
	 *
	 * @param string $error_type
	 * @param string $error_message
	 * @return string
	 */
	private function render_error_content( $error_type, $error_message ) {
		$page_options = OptionsManager::get_access_page_options();
		
		// Get appropriate error message
		switch ( $error_type ) {
			case 'missing_token':
				$message = __( 'No access token provided.', CF7AT_TEXT_DOMAIN );
				break;
			case 'invalid_token':
				$message = $page_options['error_message'] ?? __( 'Invalid or expired access link.', CF7AT_TEXT_DOMAIN );
				break;
			case 'rate_limited':
				$message = __( 'Too many attempts. Please try again later.', CF7AT_TEXT_DOMAIN );
				break;
			case 'https_required':
				$message = __( 'HTTPS is required for secure access.', CF7AT_TEXT_DOMAIN );
				break;
			default:
				$message = $error_message ?: $page_options['error_message'] ?? __( 'Access denied.', CF7AT_TEXT_DOMAIN );
				break;
		}
		
		ob_start();
		?>
		<div class="cf7at-error-message">
			<div class="cf7at-alert cf7at-alert-error">
				<?php echo esc_html( $message ); ?>
			</div>
			
			<div class="cf7at-help-text">
				<p><?php _e( 'If you believe this is an error, please check:', CF7AT_TEXT_DOMAIN ); ?></p>
				<ul>
					<li><?php _e( 'The link was copied correctly from your email', CF7AT_TEXT_DOMAIN ); ?></li>
					<li><?php _e( 'The link has not expired', CF7AT_TEXT_DOMAIN ); ?></li>
					<li><?php _e( 'You are using the most recent link sent to you', CF7AT_TEXT_DOMAIN ); ?></li>
				</ul>
				<p>
					<a href="<?php echo home_url(); ?>" class="cf7at-button">
						<?php _e( 'Return to Home', CF7AT_TEXT_DOMAIN ); ?>
					</a>
				</p>
			</div>
		</div>
		<?php
		
		return ob_get_clean();
	}
	
	/**
	 * Render protected data based on token
	 *
	 * @param array $token_data
	 * @return string
	 */
	private function render_protected_data( $token_data ) {
		ob_start();
		
		// Display form submission data if available
		if ( ! empty( $token_data['metadata']['form_data'] ) ) {
			?>
			<div class="cf7at-form-data">
				<h3><?php _e( 'Your Submission', CF7AT_TEXT_DOMAIN ); ?></h3>
				<div class="cf7at-data-table">
					<?php foreach ( $token_data['metadata']['form_data'] as $field => $value ) : ?>
						<?php if ( ! empty( $value ) && ! in_array( $field, array( 'cf7at-enable', '_wpcf7', '_wpcf7_version' ) ) ) : ?>
						<div class="cf7at-data-row">
							<div class="cf7at-data-label">
								<?php echo esc_html( ucwords( str_replace( array( '-', '_' ), ' ', $field ) ) ); ?>:
							</div>
							<div class="cf7at-data-value">
								<?php 
								if ( is_array( $value ) ) {
									echo esc_html( implode( ', ', $value ) );
								} else {
									echo esc_html( $value );
								}
								?>
							</div>
						</div>
						<?php endif; ?>
					<?php endforeach; ?>
				</div>
			</div>
			<?php
		}
		
		// Allow custom content rendering
		do_action( 'cf7at_render_protected_content', $token_data );
		
		return ob_get_clean();
	}
	
	/**
	 * Render complete access page
	 *
	 * @param string $title
	 * @param string $content
	 * @param array|null $token_data
	 */
	private function render_access_page( $title, $content, $token_data = null ) {
		?>
		<!DOCTYPE html>
		<html <?php language_attributes(); ?>>
		<head>
			<meta charset="<?php bloginfo( 'charset' ); ?>">
			<meta name="viewport" content="width=device-width, initial-scale=1">
			<meta name="robots" content="noindex, nofollow">
			<title><?php echo esc_html( $title ); ?> - <?php bloginfo( 'name' ); ?></title>
			<?php wp_head(); ?>
		</head>
		<body class="cf7at-access-page">
			<div class="cf7at-container">
				<header class="cf7at-header">
					<h1><?php echo esc_html( $title ); ?></h1>
					<div class="cf7at-site-info">
						<a href="<?php echo home_url(); ?>"><?php bloginfo( 'name' ); ?></a>
					</div>
				</header>
				
				<main class="cf7at-main">
					<?php echo $content; ?>
				</main>
				
				<footer class="cf7at-footer">
					<p><?php printf( __( 'Powered by %s', CF7AT_TEXT_DOMAIN ), '<a href="' . home_url() . '">' . get_bloginfo( 'name' ) . '</a>' ); ?></p>
				</footer>
			</div>
			<?php wp_footer(); ?>
		</body>
		</html>
		<?php
	}
	
	/**
	 * Shortcode to render protected content
	 *
	 * @param array $atts
	 * @param string $content
	 * @return string
	 */
	public function render_protected_content( $atts, $content = '' ) {
		if ( ! $this->current_token_data ) {
			return '<p>' . __( 'This content is only available with a valid access token.', CF7AT_TEXT_DOMAIN ) . '</p>';
		}
		
		$atts = shortcode_atts( array(
			'type' => '',
			'id'   => '',
		), $atts );
		
		// Check if token grants access to this specific content
		if ( ! empty( $atts['type'] ) && $atts['type'] !== $this->current_token_data['related_type'] ) {
			return '<p>' . __( 'Access denied for this content type.', CF7AT_TEXT_DOMAIN ) . '</p>';
		}
		
		if ( ! empty( $atts['id'] ) && $atts['id'] != $this->current_token_data['related_id'] ) {
			return '<p>' . __( 'Access denied for this content ID.', CF7AT_TEXT_DOMAIN ) . '</p>';
		}
		
		return do_shortcode( $content );
	}
	
	/**
	 * Shortcode to render token information
	 *
	 * @param array $atts
	 * @return string
	 */
	public function render_token_info( $atts ) {
		if ( ! $this->current_token_data ) {
			return '';
		}
		
		$atts = shortcode_atts( array(
			'field' => 'all',
		), $atts );
		
		switch ( $atts['field'] ) {
			case 'email':
				return esc_html( $this->current_token_data['email'] );
			case 'type':
				return esc_html( $this->current_token_data['related_type'] );
			case 'id':
				return esc_html( $this->current_token_data['related_id'] );
			case 'expires':
				return cf7at_format_date( $this->current_token_data['expires_at'] );
			case 'usage':
				if ( ! empty( $this->current_token_data['usage_limit'] ) ) {
					return sprintf( '%d/%d', $this->current_token_data['usage_count'], $this->current_token_data['usage_limit'] );
				}
				return $this->current_token_data['usage_count'];
			default:
				return $this->render_token_info_table();
		}
	}
	
	/**
	 * Render token info table
	 *
	 * @return string
	 */
	private function render_token_info_table() {
		ob_start();
		?>
		<div class="cf7at-token-info-table">
			<table>
				<tr>
					<td><?php _e( 'Email:', CF7AT_TEXT_DOMAIN ); ?></td>
					<td><?php echo esc_html( $this->current_token_data['email'] ); ?></td>
				</tr>
				<tr>
					<td><?php _e( 'Type:', CF7AT_TEXT_DOMAIN ); ?></td>
					<td><?php echo esc_html( ucfirst( $this->current_token_data['related_type'] ) ); ?></td>
				</tr>
				<tr>
					<td><?php _e( 'Reference ID:', CF7AT_TEXT_DOMAIN ); ?></td>
					<td><?php echo esc_html( $this->current_token_data['related_id'] ); ?></td>
				</tr>
				<tr>
					<td><?php _e( 'Expires:', CF7AT_TEXT_DOMAIN ); ?></td>
					<td><?php echo cf7at_format_date( $this->current_token_data['expires_at'] ); ?></td>
				</tr>
			</table>
		</div>
		<?php
		return ob_get_clean();
	}
}