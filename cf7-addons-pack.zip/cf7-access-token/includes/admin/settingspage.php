<?php

namespace CF7AT\Admin;

use CF7AT\Core\OptionsManager;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Settings page class
 */
class SettingsPage {
	
	/**
	 * Display settings page
	 */
	public function display() {
		if ( isset( $_POST['submit'] ) ) {
			$this->save_settings();
		}
		
		$options = OptionsManager::get_all_options();
		
		?>
		<div class="wrap">
			<h1><?php _e( 'CF7 Access Token Settings', CF7AT_TEXT_DOMAIN ); ?></h1>
			
			<form method="post" action="" id="cf7at-settings-form">
				<?php wp_nonce_field( 'cf7at_settings', 'cf7at_settings_nonce' ); ?>
				
				<!-- General Settings -->
				<div class="cf7at-settings-section">
					<h3><?php _e( 'General Settings', CF7AT_TEXT_DOMAIN ); ?></h3>
					<table class="form-table">
						<tr>
							<th scope="row"><?php _e( 'Default Expiry Hours', CF7AT_TEXT_DOMAIN ); ?></th>
							<td>
								<input type="number" name="default_expiry_hours" value="<?php echo esc_attr( $options['default_expiry_hours'] ?? CF7AT_DEFAULT_EXPIRY_HOURS ); ?>" min="1" max="8760" />
								<p class="description"><?php _e( 'How many hours tokens remain valid (1-8760 hours).', CF7AT_TEXT_DOMAIN ); ?></p>
							</td>
						</tr>
						
						<tr>
							<th scope="row"><?php _e( 'Max Validation Attempts', CF7AT_TEXT_DOMAIN ); ?></th>
							<td>
								<input type="number" name="max_validation_attempts" value="<?php echo esc_attr( $options['max_validation_attempts'] ?? CF7AT_MAX_VALIDATION_ATTEMPTS ); ?>" min="1" max="100" />
								<p class="description"><?php _e( 'Maximum failed validation attempts per IP per hour.', CF7AT_TEXT_DOMAIN ); ?></p>
							</td>
						</tr>
						
						<tr>
							<th scope="row"><?php _e( 'Security Options', CF7AT_TEXT_DOMAIN ); ?></th>
							<td>
								<label>
									<input type="checkbox" name="require_https" value="1" <?php checked( $options['require_https'] ?? true ); ?> />
									<?php _e( 'Require HTTPS for access pages', CF7AT_TEXT_DOMAIN ); ?>
								</label><br />
								
								<label>
									<input type="checkbox" name="cleanup_expired_tokens" value="1" <?php checked( $options['cleanup_expired_tokens'] ?? true ); ?> />
									<?php _e( 'Automatically cleanup expired tokens daily', CF7AT_TEXT_DOMAIN ); ?>
								</label>
							</td>
						</tr>
						
						<tr>
							<th scope="row"><?php _e( 'Default Usage Limit', CF7AT_TEXT_DOMAIN ); ?></th>
							<td>
								<input type="number" name="default_usage_limit" value="<?php echo esc_attr( $options['default_usage_limit'] ?? '' ); ?>" min="1" max="100" placeholder="<?php _e( 'Unlimited', CF7AT_TEXT_DOMAIN ); ?>" />
								<p class="description"><?php _e( 'Default maximum number of times a token can be used. Leave empty for unlimited.', CF7AT_TEXT_DOMAIN ); ?></p>
							</td>
						</tr>
					</table>
				</div>
				
				<!-- Email Settings -->
				<div class="cf7at-settings-section">
					<h3><?php _e( 'Email Notifications', CF7AT_TEXT_DOMAIN ); ?></h3>
					<table class="form-table">
						<tr>
							<th scope="row"><?php _e( 'Send Magic Links', CF7AT_TEXT_DOMAIN ); ?></th>
							<td>
								<label>
									<input type="checkbox" name="send_magic_link" value="1" <?php checked( $options['email_notifications']['send_magic_link'] ?? true ); ?> />
									<?php _e( 'Send magic link emails automatically', CF7AT_TEXT_DOMAIN ); ?>
								</label>
							</td>
						</tr>
						
						<tr>
							<th scope="row"><?php _e( 'From Name', CF7AT_TEXT_DOMAIN ); ?></th>
							<td>
								<input type="text" name="from_name" value="<?php echo esc_attr( $options['email_notifications']['from_name'] ?? get_bloginfo( 'name' ) ); ?>" class="regular-text" />
							</td>
						</tr>
						
						<tr>
							<th scope="row"><?php _e( 'From Email', CF7AT_TEXT_DOMAIN ); ?></th>
							<td>
								<input type="email" name="from_email" value="<?php echo esc_attr( $options['email_notifications']['from_email'] ?? get_option( 'admin_email' ) ); ?>" class="regular-text" />
							</td>
						</tr>
						
						<tr>
							<th scope="row"><?php _e( 'Email Subject', CF7AT_TEXT_DOMAIN ); ?></th>
							<td>
								<input type="text" name="subject_template" value="<?php echo esc_attr( $options['email_notifications']['subject_template'] ?? __( 'Secure Access to Your Request', CF7AT_TEXT_DOMAIN ) ); ?>" class="large-text" />
							</td>
						</tr>
						
						<tr>
							<th scope="row"><?php _e( 'Email Message', CF7AT_TEXT_DOMAIN ); ?></th>
							<td>
								<textarea name="message_template" class="cf7at-email-template"><?php echo esc_textarea( $options['email_notifications']['message_template'] ?? $this->get_default_email_template() ); ?></textarea>
								
								<div class="cf7at-template-help">
									<h4><?php _e( 'Available Placeholders:', CF7AT_TEXT_DOMAIN ); ?></h4>
									<p>
										<code>{access_link}</code> - <?php _e( 'Magic link URL', CF7AT_TEXT_DOMAIN ); ?><br>
										<code>{email}</code> - <?php _e( 'Recipient email', CF7AT_TEXT_DOMAIN ); ?><br>
										<code>{expiry_hours}</code> - <?php _e( 'Hours until expiration', CF7AT_TEXT_DOMAIN ); ?><br>
										<code>{expiry_time}</code> - <?php _e( 'Expiration date/time', CF7AT_TEXT_DOMAIN ); ?><br>
										<code>{site_name}</code> - <?php _e( 'Site name', CF7AT_TEXT_DOMAIN ); ?><br>
										<code>{site_url}</code> - <?php _e( 'Site URL', CF7AT_TEXT_DOMAIN ); ?><br>
										<code>{related_type}</code> - <?php _e( 'Resource type', CF7AT_TEXT_DOMAIN ); ?><br>
										<code>{related_id}</code> - <?php _e( 'Resource ID', CF7AT_TEXT_DOMAIN ); ?>
									</p>
								</div>
							</td>
						</tr>
					</table>
				</div>
				
				<!-- Access Page Settings -->
				<div class="cf7at-settings-section">
					<h3><?php _e( 'Access Page Settings', CF7AT_TEXT_DOMAIN ); ?></h3>
					<table class="form-table">
						<tr>
							<th scope="row"><?php _e( 'Page Title', CF7AT_TEXT_DOMAIN ); ?></th>
							<td>
								<input type="text" name="page_title" value="<?php echo esc_attr( $options['access_page']['page_title'] ?? __( 'Secure Access', CF7AT_TEXT_DOMAIN ) ); ?>" class="regular-text" />
							</td>
						</tr>
						
						<tr>
							<th scope="row"><?php _e( 'Success Message', CF7AT_TEXT_DOMAIN ); ?></th>
							<td>
								<textarea name="success_message" rows="3" class="large-text"><?php echo esc_textarea( $options['access_page']['success_message'] ?? __( 'Access granted. You can now view your information below.', CF7AT_TEXT_DOMAIN ) ); ?></textarea>
							</td>
						</tr>
						
						<tr>
							<th scope="row"><?php _e( 'Error Message', CF7AT_TEXT_DOMAIN ); ?></th>
							<td>
								<textarea name="error_message" rows="3" class="large-text"><?php echo esc_textarea( $options['access_page']['error_message'] ?? __( 'Invalid or expired access link.', CF7AT_TEXT_DOMAIN ) ); ?></textarea>
							</td>
						</tr>
						
						<tr>
							<th scope="row"><?php _e( 'Expired Message', CF7AT_TEXT_DOMAIN ); ?></th>
							<td>
								<textarea name="expired_message" rows="3" class="large-text"><?php echo esc_textarea( $options['access_page']['expired_message'] ?? __( 'This access link has expired.', CF7AT_TEXT_DOMAIN ) ); ?></textarea>
							</td>
						</tr>
					</table>
				</div>
				
				<?php submit_button(); ?>
			</form>
			
			<!-- Statistics -->
			<div class="cf7at-settings-section">
				<h3><?php _e( 'Statistics', CF7AT_TEXT_DOMAIN ); ?></h3>
				<?php $this->display_statistics(); ?>
			</div>
		</div>
		<?php
	}
	
	/**
	 * Save settings
	 */
	private function save_settings() {
		if ( ! wp_verify_nonce( $_POST['cf7at_settings_nonce'] ?? '', 'cf7at_settings' ) ) {
			wp_die( __( 'Security check failed.', CF7AT_TEXT_DOMAIN ) );
		}
		
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( __( 'You do not have permission to access this page.', CF7AT_TEXT_DOMAIN ) );
		}
		
		$options = OptionsManager::get_all_options();
		
		// Update general settings
		$options['default_expiry_hours'] = max( 1, intval( $_POST['default_expiry_hours'] ?? CF7AT_DEFAULT_EXPIRY_HOURS ) );
		$options['max_validation_attempts'] = max( 1, intval( $_POST['max_validation_attempts'] ?? CF7AT_MAX_VALIDATION_ATTEMPTS ) );
		$options['require_https'] = ! empty( $_POST['require_https'] );
		$options['cleanup_expired_tokens'] = ! empty( $_POST['cleanup_expired_tokens'] );
		$options['default_usage_limit'] = ! empty( $_POST['default_usage_limit'] ) ? max( 1, intval( $_POST['default_usage_limit'] ) ) : null;
		
		// Update email settings
		$options['email_notifications']['send_magic_link'] = ! empty( $_POST['send_magic_link'] );
		$options['email_notifications']['from_name'] = sanitize_text_field( $_POST['from_name'] ?? get_bloginfo( 'name' ) );
		$options['email_notifications']['from_email'] = sanitize_email( $_POST['from_email'] ?? get_option( 'admin_email' ) );
		$options['email_notifications']['subject_template'] = sanitize_text_field( $_POST['subject_template'] ?? '' );
		$options['email_notifications']['message_template'] = sanitize_textarea_field( $_POST['message_template'] ?? '' );
		
		// Update access page settings
		$options['access_page']['page_title'] = sanitize_text_field( $_POST['page_title'] ?? '' );
		$options['access_page']['success_message'] = sanitize_textarea_field( $_POST['success_message'] ?? '' );
		$options['access_page']['error_message'] = sanitize_textarea_field( $_POST['error_message'] ?? '' );
		$options['access_page']['expired_message'] = sanitize_textarea_field( $_POST['expired_message'] ?? '' );
		
		update_option( 'cf7at_options', $options );
		
		echo '<div class="notice notice-success"><p>' . __( 'Settings saved successfully.', CF7AT_TEXT_DOMAIN ) . '</p></div>';
	}
	
	/**
	 * Display statistics
	 */
	private function display_statistics() {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7AT_TOKENS_TABLE;
		
		// Get token counts by status
		$stats = $wpdb->get_results(
			"SELECT status, COUNT(*) as count FROM {$table_name} GROUP BY status",
			ARRAY_A
		);
		
		$total_tokens = $wpdb->get_var( "SELECT COUNT(*) FROM {$table_name}" );
		$tokens_today = $wpdb->get_var( 
			$wpdb->prepare( 
				"SELECT COUNT(*) FROM {$table_name} WHERE DATE(created_at) = %s",
				current_time( 'Y-m-d' )
			)
		);
		
		?>
		<div class="cf7at-stats-grid">
			<div class="cf7at-stat-box">
				<span class="cf7at-stat-number"><?php echo number_format( $total_tokens ); ?></span>
				<div class="cf7at-stat-label"><?php _e( 'Total Tokens', CF7AT_TEXT_DOMAIN ); ?></div>
			</div>
			
			<div class="cf7at-stat-box">
				<span class="cf7at-stat-number"><?php echo number_format( $tokens_today ); ?></span>
				<div class="cf7at-stat-label"><?php _e( 'Tokens Today', CF7AT_TEXT_DOMAIN ); ?></div>
			</div>
			
			<?php foreach ( $stats as $stat ) : ?>
			<div class="cf7at-stat-box">
				<span class="cf7at-stat-number"><?php echo number_format( $stat['count'] ); ?></span>
				<div class="cf7at-stat-label"><?php echo esc_html( ucfirst( $stat['status'] ) ); ?></div>
			</div>
			<?php endforeach; ?>
		</div>
		<?php
	}
	
	/**
	 * Get default email template
	 *
	 * @return string
	 */
	private function get_default_email_template() {
		return sprintf(
			__( 'Hello,

You have requested secure access to your information. Please click the link below to access your data:

{access_link}

This link will expire in {expiry_hours} hours for security reasons.

Important Security Information:
- Do not share this link with anyone
- This link is for your use only
- If you did not request this access, please ignore this email

Best regards,
%s', CF7AT_TEXT_DOMAIN ),
			get_bloginfo( 'name' )
		);
	}
}