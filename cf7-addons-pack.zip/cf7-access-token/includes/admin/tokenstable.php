<?php

namespace CF7AT\Admin;

use CF7AT\Core\TokenManager;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Load WP_List_Table if not loaded
if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

/**
 * Tokens table class
 */
class TokensTable extends \WP_List_Table {
	
	/**
	 * Constructor
	 */
	public function __construct() {
		parent::__construct( array(
			'singular' => 'token',
			'plural'   => 'tokens',
			'ajax'     => false,
		) );
	}
	
	/**
	 * Get columns
	 *
	 * @return array
	 */
	public function get_columns() {
		return array(
			'cb'           => '<input type="checkbox" />',
			'email'        => __( 'Email', CF7AT_TEXT_DOMAIN ),
			'related_type' => __( 'Type', CF7AT_TEXT_DOMAIN ),
			'related_id'   => __( 'Resource ID', CF7AT_TEXT_DOMAIN ),
			'status'       => __( 'Status', CF7AT_TEXT_DOMAIN ),
			'usage'        => __( 'Usage', CF7AT_TEXT_DOMAIN ),
			'expires_at'   => __( 'Expires', CF7AT_TEXT_DOMAIN ),
			'created_at'   => __( 'Created', CF7AT_TEXT_DOMAIN ),
			'actions'      => __( 'Actions', CF7AT_TEXT_DOMAIN ),
		);
	}
	
	/**
	 * Get sortable columns
	 *
	 * @return array
	 */
	public function get_sortable_columns() {
		return array(
			'email'        => array( 'email', false ),
			'related_type' => array( 'related_type', false ),
			'status'       => array( 'status', false ),
			'expires_at'   => array( 'expires_at', false ),
			'created_at'   => array( 'created_at', true ),
		);
	}
	
	/**
	 * Get bulk actions
	 *
	 * @return array
	 */
	public function get_bulk_actions() {
		return array(
			'revoke' => __( 'Revoke', CF7AT_TEXT_DOMAIN ),
			'extend' => __( 'Extend (24h)', CF7AT_TEXT_DOMAIN ),
		);
	}
	
	/**
	 * Column checkbox
	 *
	 * @param array $item
	 * @return string
	 */
	public function column_cb( $item ) {
		return sprintf( '<input type="checkbox" name="token[]" value="%s" />', $item['id'] );
	}
	
	/**
	 * Column email
	 *
	 * @param array $item
	 * @return string
	 */
	public function column_email( $item ) {
		$actions = array();
		
		// Add view details link
		$view_url = add_query_arg(
			array(
				'page'     => 'cf7at-tokens',
				'action'   => 'view',
				'token_id' => $item['id'],
			),
			admin_url( 'admin.php' )
		);
		
		$actions['view'] = sprintf(
			'<a href="%s">%s</a>',
			esc_url( $view_url ),
			__( 'View Details', CF7AT_TEXT_DOMAIN )
		);
		
		if ( $item['status'] === 'active' ) {
			$actions['revoke'] = sprintf(
				'<a href="#" class="cf7at-revoke-token" data-token-id="%s">%s</a>',
				$item['id'],
				__( 'Revoke', CF7AT_TEXT_DOMAIN )
			);
		}
		
		return sprintf( '%1$s %2$s', 
			'<strong>' . esc_html( $item['email'] ) . '</strong>',
			$this->row_actions( $actions ) 
		);
	}
	
	/**
	 * Column related type
	 *
	 * @param array $item
	 * @return string
	 */
	public function column_related_type( $item ) {
		$types = cf7at_get_related_types();
		$type_label = isset( $types[ $item['related_type'] ] ) ? $types[ $item['related_type'] ] : $item['related_type'];
		
		return esc_html( $type_label );
	}
	
	/**
	 * Column related ID
	 *
	 * @param array $item
	 * @return string
	 */
	public function column_related_id( $item ) {
		return esc_html( $item['related_id'] );
	}
	
	/**
	 * Column status
	 *
	 * @param array $item
	 * @return string
	 */
	public function column_status( $item ) {
		$statuses = cf7at_get_token_statuses();
		$status_label = isset( $statuses[ $item['status'] ] ) ? $statuses[ $item['status'] ] : $item['status'];
		
		$class = 'cf7at-status-' . $item['status'];
		
		return sprintf( '<span class="%s">%s</span>', $class, esc_html( strtoupper( $status_label ) ) );
	}
	
	/**
	 * Column usage
	 *
	 * @param array $item
	 * @return string
	 */
	public function column_usage( $item ) {
		if ( ! empty( $item['usage_limit'] ) ) {
			return sprintf( '%d / %d', $item['usage_count'], $item['usage_limit'] );
		}
		
		return $item['usage_count'];
	}
	
	/**
	 * Column expires at
	 *
	 * @param array $item
	 * @return string
	 */
	public function column_expires_at( $item ) {
		if ( empty( $item['expires_at'] ) || $item['expires_at'] === '0000-00-00 00:00:00' ) {
			return __( 'Never', CF7AT_TEXT_DOMAIN );
		}
		
		$expires_at = strtotime( $item['expires_at'] );
		$now = time();
		
		if ( $expires_at < $now ) {
			return '<span style="color: #d63638;">' . cf7at_format_date( $item['expires_at'] ) . '</span>';
		}
		
		$time_left = cf7at_get_time_until_expiration( $item['expires_at'] );
		
		return sprintf( 
			'<span title="%s">%s</span>',
			cf7at_format_date( $item['expires_at'] ),
			esc_html( $time_left )
		);
	}
	
	/**
	 * Column created at
	 *
	 * @param array $item
	 * @return string
	 */
	public function column_created_at( $item ) {
		return cf7at_format_date( $item['created_at'] );
	}
	
	/**
	 * Column actions
	 *
	 * @param array $item
	 * @return string
	 */
	public function column_actions( $item ) {
		$actions = array();
		
		if ( $item['status'] === 'active' ) {
			$actions[] = sprintf(
				'<button type="button" class="button button-small cf7at-extend-token" data-token-id="%s">%s</button>',
				$item['id'],
				__( 'Extend', CF7AT_TEXT_DOMAIN )
			);
			
			$actions[] = sprintf(
				'<button type="button" class="button button-small cf7at-revoke-token" data-token-id="%s">%s</button>',
				$item['id'],
				__( 'Revoke', CF7AT_TEXT_DOMAIN )
			);
		}
		
		return '<div class="cf7at-token-actions">' . implode( ' ', $actions ) . '</div>';
	}
	
	/**
	 * Default column
	 *
	 * @param array $item
	 * @param string $column_name
	 * @return string
	 */
	public function column_default( $item, $column_name ) {
		return isset( $item[ $column_name ] ) ? esc_html( $item[ $column_name ] ) : '';
	}
	
	/**
	 * Prepare items
	 */
	public function prepare_items() {
		$per_page = 20;
		$current_page = $this->get_pagenum();
		
		$orderby = isset( $_GET['orderby'] ) ? sanitize_text_field( $_GET['orderby'] ) : 'created_at';
		$order = isset( $_GET['order'] ) ? sanitize_text_field( $_GET['order'] ) : 'DESC';
		
		$search = isset( $_GET['s'] ) ? sanitize_text_field( $_GET['s'] ) : '';
		$status_filter = isset( $_GET['status'] ) ? sanitize_text_field( $_GET['status'] ) : '';
		
		$token_manager = new TokenManager();
		
		$args = array(
			'per_page' => $per_page,
			'page'     => $current_page,
			'orderby'  => $orderby,
			'order'    => $order,
		);
		
		if ( ! empty( $search ) ) {
			$args['email'] = $search;
		}
		
		if ( ! empty( $status_filter ) ) {
			$args['status'] = $status_filter;
		}
		
		$result = $token_manager->get_tokens( $args );
		
		$this->items = $result['tokens'];
		
		$this->set_pagination_args( array(
			'total_items' => $result['total'],
			'per_page'    => $per_page,
		) );
		
		$columns = $this->get_columns();
		$hidden = array();
		$sortable = $this->get_sortable_columns();
		
		$this->_column_headers = array( $columns, $hidden, $sortable );
	}
	
	/**
	 * Extra table navigation
	 *
	 * @param string $which
	 */
	protected function extra_tablenav( $which ) {
		if ( $which === 'top' ) {
			?>
			<div class="alignleft actions">
				<select name="status">
					<option value=""><?php _e( 'All Statuses', CF7AT_TEXT_DOMAIN ); ?></option>
					<?php
					$statuses = cf7at_get_token_statuses();
					$current_status = isset( $_GET['status'] ) ? $_GET['status'] : '';
					
					foreach ( $statuses as $status => $label ) {
						printf(
							'<option value="%s" %s>%s</option>',
							esc_attr( $status ),
							selected( $current_status, $status, false ),
							esc_html( $label )
						);
					}
					?>
				</select>
				<?php submit_button( __( 'Filter', CF7AT_TEXT_DOMAIN ), '', 'filter_action', false, array( 'id' => 'post-query-submit' ) ); ?>
			</div>
			<?php
		}
	}
}