<?php

namespace CF7AT\Admin;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin initialization class
 */
class AdminInit {
	
	/**
	 * Instance
	 *
	 * @var AdminInit
	 */
	private static $instance = null;
	
	/**
	 * Get instance
	 *
	 * @return AdminInit
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		$this->init_hooks();
	}
	
	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
		add_action( 'admin_init', array( $this, 'maybe_upgrade_database' ) );
		add_action( 'wp_ajax_cf7at_revoke_token', array( $this, 'handle_ajax_revoke_token' ) );
		add_action( 'wp_ajax_cf7at_extend_token', array( $this, 'handle_ajax_extend_token' ) );
	}
	
	/**
	 * Add admin menu
	 */
	public function add_admin_menu() {
		add_menu_page(
			__( 'CF7 Access Tokens', CF7AT_TEXT_DOMAIN ),
			__( 'Access Tokens', CF7AT_TEXT_DOMAIN ),
			'manage_options',
			'cf7at-tokens',
			array( $this, 'tokens_page' ),
			'dashicons-admin-network',
			30
		);
		
		add_submenu_page(
			'cf7at-tokens',
			__( 'Access Tokens', CF7AT_TEXT_DOMAIN ),
			__( 'Tokens', CF7AT_TEXT_DOMAIN ),
			'manage_options',
			'cf7at-tokens',
			array( $this, 'tokens_page' )
		);
		
		add_submenu_page(
			'cf7at-tokens',
			__( 'Settings', CF7AT_TEXT_DOMAIN ),
			__( 'Settings', CF7AT_TEXT_DOMAIN ),
			'manage_options',
			'cf7at-settings',
			array( $this, 'settings_page' )
		);
	}
	
	/**
	 * Enqueue admin scripts
	 *
	 * @param string $hook
	 */
	public function enqueue_admin_scripts( $hook ) {
		if ( strpos( $hook, 'cf7at' ) === false ) {
			return;
		}
		
		wp_enqueue_script(
			'cf7at-admin',
			CF7AT_PLUGIN_URL . '/assets/js/admin.js',
			array( 'jquery' ),
			CF7AT_VERSION,
			true
		);
		
		wp_localize_script( 'cf7at-admin', 'cf7at_admin', array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'cf7at_admin' ),
			'strings'  => array(
				'confirm_revoke' => __( 'Are you sure you want to revoke this token?', CF7AT_TEXT_DOMAIN ),
				'confirm_extend' => __( 'Extend token expiration by 24 hours?', CF7AT_TEXT_DOMAIN ),
			),
		));
		
		wp_enqueue_style(
			'cf7at-admin',
			CF7AT_PLUGIN_URL . '/assets/css/admin.css',
			array(),
			CF7AT_VERSION
		);
	}
	
	/**
	 * Maybe upgrade database
	 */
	public function maybe_upgrade_database() {
		\CF7AT\Database\SchemaManager::maybe_upgrade();
	}
	
	/**
	 * Tokens page
	 */
	public function tokens_page() {
		// Handle detail view
		if ( isset( $_GET['action'] ) && $_GET['action'] === 'view' && isset( $_GET['token_id'] ) ) {
			$this->token_detail_page( intval( $_GET['token_id'] ) );
			return;
		}
		
		$tokens_table = new TokensTable();
		$tokens_table->prepare_items();
		
		?>
		<div class="wrap">
			<h1><?php _e( 'CF7 Access Tokens', CF7AT_TEXT_DOMAIN ); ?></h1>
			
			<form method="get">
				<input type="hidden" name="page" value="cf7at-tokens" />
				<?php $tokens_table->search_box( __( 'Search Tokens', CF7AT_TEXT_DOMAIN ), 'token' ); ?>
			</form>
			
			<?php $tokens_table->display(); ?>
		</div>
		<?php
	}
	
	/**
	 * Token detail page
	 *
	 * @param int $token_id
	 */
	private function token_detail_page( $token_id ) {
		$token_manager = new \CF7AT\Core\TokenManager();
		$token = $token_manager->get_token( $token_id );
		
		if ( ! $token ) {
			echo '<div class="wrap"><h1>' . __( 'Token Not Found', CF7AT_TEXT_DOMAIN ) . '</h1></div>';
			return;
		}
		
		// Decode metadata
		if ( ! empty( $token['metadata'] ) && is_string( $token['metadata'] ) ) {
			$token['metadata'] = json_decode( $token['metadata'], true );
		}
		
		include CF7AT_PLUGIN_DIR . '/templates/admin/token-detail.php';
	}
	
	/**
	 * Settings page
	 */
	public function settings_page() {
		$settings = new SettingsPage();
		$settings->display();
	}
	
	/**
	 * Handle AJAX token revocation
	 */
	public function handle_ajax_revoke_token() {
		if ( ! wp_verify_nonce( $_POST['nonce'] ?? '', 'cf7at_admin' ) ) {
			wp_send_json_error( __( 'Invalid nonce.', CF7AT_TEXT_DOMAIN ) );
		}
		
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( __( 'Insufficient permissions.', CF7AT_TEXT_DOMAIN ) );
		}
		
		$token_id = intval( $_POST['token_id'] ?? 0 );
		
		if ( ! $token_id ) {
			wp_send_json_error( __( 'Invalid token ID.', CF7AT_TEXT_DOMAIN ) );
		}
		
		$token_manager = new \CF7AT\Core\TokenManager();
		$result = $token_manager->revoke_token( $token_id );
		
		if ( $result ) {
			wp_send_json_success( array( 'message' => __( 'Token revoked successfully.', CF7AT_TEXT_DOMAIN ) ) );
		} else {
			wp_send_json_error( __( 'Failed to revoke token.', CF7AT_TEXT_DOMAIN ) );
		}
	}
	
	/**
	 * Handle AJAX token extension
	 */
	public function handle_ajax_extend_token() {
		if ( ! wp_verify_nonce( $_POST['nonce'] ?? '', 'cf7at_admin' ) ) {
			wp_send_json_error( __( 'Invalid nonce.', CF7AT_TEXT_DOMAIN ) );
		}
		
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( __( 'Insufficient permissions.', CF7AT_TEXT_DOMAIN ) );
		}
		
		$token_id = intval( $_POST['token_id'] ?? 0 );
		$hours = intval( $_POST['hours'] ?? 24 );
		
		if ( ! $token_id ) {
			wp_send_json_error( __( 'Invalid token ID.', CF7AT_TEXT_DOMAIN ) );
		}
		
		$token_manager = new \CF7AT\Core\TokenManager();
		$result = $token_manager->extend_token_expiration( $token_id, $hours );
		
		if ( $result ) {
			wp_send_json_success( array( 'message' => __( 'Token extended successfully.', CF7AT_TEXT_DOMAIN ) ) );
		} else {
			wp_send_json_error( __( 'Failed to extend token.', CF7AT_TEXT_DOMAIN ) );
		}
	}
}