<?php

namespace CF7AT\Database;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Database schema management class
 */
class SchemaManager {
	
	/**
	 * Create database tables
	 */
	public static function create_tables() {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7AT_TOKENS_TABLE;
		
		$charset_collate = $wpdb->get_charset_collate();
		
		$sql = "CREATE TABLE $table_name (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			token_hash varchar(64) NOT NULL,
			related_type varchar(50) NOT NULL DEFAULT 'submission',
			related_id bigint(20) unsigned NOT NULL,
			email varchar(100) NOT NULL,
			expires_at datetime DEFAULT NULL,
			usage_limit int(10) unsigned DEFAULT NULL,
			usage_count int(10) unsigned NOT NULL DEFAULT 0,
			status varchar(20) NOT NULL DEFAULT 'active',
			metadata longtext DEFAULT NULL,
			created_at datetime NOT NULL,
			last_used_at datetime DEFAULT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY token_hash (token_hash),
			KEY related_lookup (related_type, related_id),
			KEY email (email),
			KEY status (status),
			KEY expires_at (expires_at),
			KEY created_at (created_at)
		) $charset_collate;";
		
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );
		
		// Check if table was created successfully
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) !== $table_name ) {
			cf7at_log( 'Failed to create access tokens table', 'error' );
		} else {
			cf7at_log( 'Access tokens table created successfully' );
		}
		
		// Update database version
		update_option( 'cf7at_db_version', CF7AT_VERSION );
	}
	
	/**
	 * Drop database tables (for uninstall)
	 */
	public static function drop_tables() {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7AT_TOKENS_TABLE;
		
		$wpdb->query( "DROP TABLE IF EXISTS $table_name" );
		
		// Remove database version option
		delete_option( 'cf7at_db_version' );
	}
	
	/**
	 * Check if database needs upgrade
	 *
	 * @return bool
	 */
	public static function needs_upgrade() {
		$current_version = get_option( 'cf7at_db_version', '0' );
		return version_compare( $current_version, CF7AT_VERSION, '<' );
	}
	
	/**
	 * Upgrade database if needed
	 */
	public static function maybe_upgrade() {
		if ( self::needs_upgrade() ) {
			self::create_tables();
		}
	}
	
	/**
	 * Get table name with prefix
	 *
	 * @return string
	 */
	public static function get_tokens_table_name() {
		global $wpdb;
		return $wpdb->prefix . CF7AT_TOKENS_TABLE;
	}
	
	/**
	 * Clean up expired tokens
	 *
	 * @return int Number of tokens cleaned up
	 */
	public static function cleanup_expired_tokens() {
		global $wpdb;
		
		$table_name = self::get_tokens_table_name();
		
		$result = $wpdb->query(
			"UPDATE $table_name 
			 SET status = 'expired' 
			 WHERE status = 'active' 
			 AND expires_at IS NOT NULL 
			 AND expires_at < NOW()"
		);
		
		if ( $result !== false && $result > 0 ) {
			cf7at_log( "Cleaned up {$result} expired tokens" );
		}
		
		return $result !== false ? $result : 0;
	}
}