<?php

namespace CF7AT\Core;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Main plugin class
 */
class Plugin {
	
	/**
	 * Plugin instance
	 *
	 * @var Plugin
	 */
	private static $instance = null;
	
	/**
	 * Get plugin instance
	 *
	 * @return Plugin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		$this->init_hooks();
	}
	
	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
		add_action( 'wp_head', array( $this, 'add_security_headers' ) );
		
		// Schedule cleanup of expired tokens
		add_action( 'cf7at_cleanup_expired_tokens', array( $this, 'cleanup_expired_tokens' ) );
		
		// Schedule the cleanup event if not already scheduled
		if ( ! wp_next_scheduled( 'cf7at_cleanup_expired_tokens' ) ) {
			wp_schedule_event( time(), 'daily', 'cf7at_cleanup_expired_tokens' );
		}
	}
	
	/**
	 * Enqueue frontend scripts
	 */
	public function enqueue_scripts() {
		// Only enqueue on access pages
		if ( ! get_query_var( 'cf7at_access' ) ) {
			return;
		}
		
		wp_enqueue_style( 
			'cf7at-frontend', 
			CF7AT_PLUGIN_URL . '/assets/css/frontend.css', 
			array(), 
			CF7AT_VERSION 
		);
		
		wp_enqueue_script( 
			'cf7at-frontend', 
			CF7AT_PLUGIN_URL . '/assets/js/frontend.js', 
			array( 'jquery' ), 
			CF7AT_VERSION, 
			true 
		);
		
		wp_localize_script( 'cf7at-frontend', 'cf7at_ajax', array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'cf7at_frontend' ),
		));
	}
	
	/**
	 * Add security headers for access pages
	 */
	public function add_security_headers() {
		if ( ! get_query_var( 'cf7at_access' ) ) {
			return;
		}
		
		// Prevent caching of access pages
		header( 'Cache-Control: no-cache, no-store, must-revalidate' );
		header( 'Pragma: no-cache' );
		header( 'Expires: 0' );
		
		// Add security headers
		header( 'X-Content-Type-Options: nosniff' );
		header( 'X-Frame-Options: DENY' );
		header( 'X-XSS-Protection: 1; mode=block' );
	}
	
	/**
	 * Cleanup expired tokens
	 */
	public function cleanup_expired_tokens() {
		\CF7AT\Database\SchemaManager::cleanup_expired_tokens();
	}
}