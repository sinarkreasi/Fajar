<?php

namespace CF7AT\Core;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Access validation class
 */
class AccessValidator {
	
	/**
	 * Rate limiting cache
	 *
	 * @var array
	 */
	private static $rate_limit_cache = array();
	
	/**
	 * Validate access request
	 *
	 * @param string $token Raw token
	 * @param string $ip_address Client IP
	 * @return array Validation result
	 */
	public function validate_access( $token, $ip_address = null ) {
		if ( $ip_address === null ) {
			$ip_address = $this->get_client_ip();
		}
		
		// Check HTTPS requirement
		if ( cf7at_is_https_required() ) {
			return array(
				'valid'   => false,
				'error'   => 'https_required',
				'message' => __( 'HTTPS is required for secure access.', CF7AT_TEXT_DOMAIN ),
			);
		}
		
		// Check rate limiting
		if ( ! $this->check_rate_limit( $ip_address ) ) {
			return array(
				'valid'   => false,
				'error'   => 'rate_limited',
				'message' => __( 'Too many validation attempts. Please try again later.', CF7AT_TEXT_DOMAIN ),
			);
		}
		
		// Validate token format
		if ( ! $this->is_valid_token_format( $token ) ) {
			$this->record_failed_attempt( $ip_address );
			return array(
				'valid'   => false,
				'error'   => 'invalid_format',
				'message' => __( 'Invalid token format.', CF7AT_TEXT_DOMAIN ),
			);
		}
		
		// Validate token
		$token_manager = new TokenManager();
		$token_data = $token_manager->validate_token( $token );
		
		if ( ! $token_data ) {
			$this->record_failed_attempt( $ip_address );
			return array(
				'valid'   => false,
				'error'   => 'invalid_token',
				'message' => __( 'Invalid or expired token.', CF7AT_TEXT_DOMAIN ),
			);
		}
		
		// Reset rate limiting on successful validation
		$this->reset_rate_limit( $ip_address );
		
		return array(
			'valid'      => true,
			'token_data' => $token_data,
			'message'    => __( 'Access granted.', CF7AT_TEXT_DOMAIN ),
		);
	}
	
	/**
	 * Check if user has permission to access resource
	 *
	 * @param array $token_data
	 * @param string $resource_type
	 * @param int $resource_id
	 * @return bool
	 */
	public function can_access_resource( $token_data, $resource_type, $resource_id ) {
		// Token must match the exact resource
		if ( $token_data['related_type'] !== $resource_type ) {
			return false;
		}
		
		if ( $token_data['related_id'] != $resource_id ) {
			return false;
		}
		
		// Additional permission checks can be added here
		return apply_filters( 'cf7at_can_access_resource', true, $token_data, $resource_type, $resource_id );
	}
	
	/**
	 * Check rate limiting for IP address
	 *
	 * @param string $ip_address
	 * @return bool
	 */
	private function check_rate_limit( $ip_address ) {
		$cache_key = 'cf7at_rate_limit_' . md5( $ip_address );
		$attempts = get_transient( $cache_key );
		
		if ( $attempts === false ) {
			return true; // No attempts recorded
		}
		
		$max_attempts = cf7at_get_option( 'max_validation_attempts', CF7AT_MAX_VALIDATION_ATTEMPTS );
		
		return $attempts < $max_attempts;
	}
	
	/**
	 * Record failed validation attempt
	 *
	 * @param string $ip_address
	 */
	private function record_failed_attempt( $ip_address ) {
		$cache_key = 'cf7at_rate_limit_' . md5( $ip_address );
		$attempts = get_transient( $cache_key );
		
		if ( $attempts === false ) {
			$attempts = 0;
		}
		
		$attempts++;
		
		// Store for 1 hour
		set_transient( $cache_key, $attempts, HOUR_IN_SECONDS );
		
		cf7at_log( "Failed validation attempt from IP: {$ip_address} (attempt #{$attempts})", 'warning' );
	}
	
	/**
	 * Reset rate limiting for IP address
	 *
	 * @param string $ip_address
	 */
	private function reset_rate_limit( $ip_address ) {
		$cache_key = 'cf7at_rate_limit_' . md5( $ip_address );
		delete_transient( $cache_key );
	}
	
	/**
	 * Validate token format
	 *
	 * @param string $token
	 * @return bool
	 */
	private function is_valid_token_format( $token ) {
		// Check length
		if ( strlen( $token ) !== CF7AT_TOKEN_LENGTH ) {
			return false;
		}
		
		// Check if it's hexadecimal
		if ( ! ctype_xdigit( $token ) ) {
			return false;
		}
		
		return true;
	}
	
	/**
	 * Get client IP address
	 *
	 * @return string
	 */
	private function get_client_ip() {
		$ip_keys = array(
			'HTTP_CF_CONNECTING_IP',     // Cloudflare
			'HTTP_CLIENT_IP',            // Proxy
			'HTTP_X_FORWARDED_FOR',      // Load balancer/proxy
			'HTTP_X_FORWARDED',          // Proxy
			'HTTP_X_CLUSTER_CLIENT_IP',  // Cluster
			'HTTP_FORWARDED_FOR',        // Proxy
			'HTTP_FORWARDED',            // Proxy
			'REMOTE_ADDR'                // Standard
		);
		
		foreach ( $ip_keys as $key ) {
			if ( array_key_exists( $key, $_SERVER ) === true ) {
				$ip = $_SERVER[ $key ];
				
				if ( strpos( $ip, ',' ) !== false ) {
					$ip = explode( ',', $ip )[0];
				}
				
				$ip = trim( $ip );
				
				if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) ) {
					return $ip;
				}
			}
		}
		
		return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
	}
}