<?php

namespace CF7AT\Core;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Options management class
 */
class OptionsManager {
	
	/**
	 * Set default options on plugin activation
	 */
	public static function set_defaults() {
		$defaults = array(
			'default_expiry_hours'      => CF7AT_DEFAULT_EXPIRY_HOURS,
			'max_validation_attempts'   => CF7AT_MAX_VALIDATION_ATTEMPTS,
			'require_https'             => true,
			'cleanup_expired_tokens'    => true,
			'default_usage_limit'       => null,
			'email_notifications'       => array(
				'send_magic_link'       => true,
				'from_name'             => get_bloginfo( 'name' ),
				'from_email'            => get_option( 'admin_email' ),
				'subject_template'      => __( 'Secure Access to Your Request', CF7AT_TEXT_DOMAIN ),
				'message_template'      => self::get_default_email_template(),
			),
			'access_page'               => array(
				'page_title'            => __( 'Secure Access', CF7AT_TEXT_DOMAIN ),
				'success_message'       => __( 'Access granted. You can now view your information below.', CF7AT_TEXT_DOMAIN ),
				'error_message'         => __( 'Invalid or expired access link.', CF7AT_TEXT_DOMAIN ),
				'expired_message'       => __( 'This access link has expired.', CF7AT_TEXT_DOMAIN ),
			),
		);
		
		$existing_options = get_option( 'cf7at_options', array() );
		$options = wp_parse_args( $existing_options, $defaults );
		
		update_option( 'cf7at_options', $options );
	}
	
	/**
	 * Get all options
	 *
	 * @return array
	 */
	public static function get_all_options() {
		return get_option( 'cf7at_options', array() );
	}
	
	/**
	 * Get email notification options
	 *
	 * @return array
	 */
	public static function get_email_options() {
		$options = self::get_all_options();
		return isset( $options['email_notifications'] ) ? $options['email_notifications'] : array();
	}
	
	/**
	 * Update email notification options
	 *
	 * @param array $email_options
	 */
	public static function update_email_options( $email_options ) {
		$options = self::get_all_options();
		$options['email_notifications'] = $email_options;
		update_option( 'cf7at_options', $options );
	}
	
	/**
	 * Get access page options
	 *
	 * @return array
	 */
	public static function get_access_page_options() {
		$options = self::get_all_options();
		return isset( $options['access_page'] ) ? $options['access_page'] : array();
	}
	
	/**
	 * Update access page options
	 *
	 * @param array $page_options
	 */
	public static function update_access_page_options( $page_options ) {
		$options = self::get_all_options();
		$options['access_page'] = $page_options;
		update_option( 'cf7at_options', $options );
	}
	
	/**
	 * Get default email template
	 *
	 * @return string
	 */
	private static function get_default_email_template() {
		return sprintf(
			__( 'Hello,

You have requested secure access to your information. Please click the link below to access your data:

{access_link}

This link will expire in {expiry_hours} hours for security reasons.

Important Security Information:
- Do not share this link with anyone
- This link is for your use only
- If you did not request this access, please ignore this email

Best regards,
%s', CF7AT_TEXT_DOMAIN ),
			get_bloginfo( 'name' )
		);
	}
}