<?php

namespace CF7AT\Core;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Token management class
 */
class TokenManager {
	
	/**
	 * Create new access token
	 *
	 * @param array $token_data
	 * @return int|false Token ID or false on failure
	 */
	public function create_token( $token_data ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7AT_TOKENS_TABLE;
		
		// Generate secure token
		$raw_token = cf7at_generate_secure_token();
		$token_hash = cf7at_hash_token( $raw_token );
		
		// Set defaults
		$defaults = array(
			'token_hash'   => $token_hash,
			'related_type' => 'submission',
			'related_id'   => 0,
			'email'        => '',
			'expires_at'   => $this->calculate_expiry(),
			'usage_limit'  => null,
			'usage_count'  => 0,
			'status'       => 'active',
			'metadata'     => null,
			'created_at'   => current_time( 'mysql' ),
		);
		
		$token_data = wp_parse_args( $token_data, $defaults );
		
		// Sanitize data
		$token_data['related_type'] = cf7at_sanitize_related_type( $token_data['related_type'] );
		$token_data['related_id'] = absint( $token_data['related_id'] );
		$token_data['email'] = sanitize_email( $token_data['email'] );
		$token_data['usage_limit'] = ! empty( $token_data['usage_limit'] ) ? absint( $token_data['usage_limit'] ) : null;
		$token_data['status'] = sanitize_text_field( $token_data['status'] );
		
		// Ensure metadata is JSON
		if ( is_array( $token_data['metadata'] ) ) {
			$token_data['metadata'] = wp_json_encode( $token_data['metadata'] );
		}
		
		$result = $wpdb->insert(
			$table_name,
			$token_data,
			array(
				'%s', // token_hash
				'%s', // related_type
				'%d', // related_id
				'%s', // email
				'%s', // expires_at
				'%d', // usage_limit
				'%d', // usage_count
				'%s', // status
				'%s', // metadata
				'%s', // created_at
			)
		);
		
		if ( $result === false ) {
			cf7at_log( 'Failed to create token: ' . $wpdb->last_error, 'error' );
			return false;
		}
		
		$token_id = $wpdb->insert_id;
		
		// Store raw token temporarily for email sending
		$this->store_raw_token_temporarily( $token_id, $raw_token );
		
		do_action( 'cf7at_token_created', $token_id, $token_data, $raw_token );
		
		return $token_id;
	}
	
	/**
	 * Get token by ID
	 *
	 * @param int $token_id
	 * @return array|null
	 */
	public function get_token( $token_id ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7AT_TOKENS_TABLE;
		
		$token = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table_name} WHERE id = %d", $token_id ),
			ARRAY_A
		);
		
		if ( $token && ! empty( $token['metadata'] ) ) {
			$token['metadata'] = json_decode( $token['metadata'], true );
		}
		
		return $token;
	}
	
	/**
	 * Get token by hash
	 *
	 * @param string $token_hash
	 * @return array|null
	 */
	public function get_token_by_hash( $token_hash ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7AT_TOKENS_TABLE;
		
		$token = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table_name} WHERE token_hash = %s", $token_hash ),
			ARRAY_A
		);
		
		if ( $token && ! empty( $token['metadata'] ) ) {
			$token['metadata'] = json_decode( $token['metadata'], true );
		}
		
		return $token;
	}
	
	/**
	 * Validate token and return token data if valid
	 *
	 * @param string $raw_token
	 * @return array|false Token data or false if invalid
	 */
	public function validate_token( $raw_token ) {
		if ( empty( $raw_token ) ) {
			return false;
		}
		
		$token_hash = cf7at_hash_token( $raw_token );
		$token = $this->get_token_by_hash( $token_hash );
		
		if ( ! $token ) {
			cf7at_log( 'Token not found: ' . substr( $raw_token, 0, 8 ) . '...', 'warning' );
			return false;
		}
		
		// Check if token is active
		if ( $token['status'] !== 'active' ) {
			cf7at_log( "Token {$token['id']} is not active: {$token['status']}", 'warning' );
			return false;
		}
		
		// Check expiration
		if ( cf7at_is_token_expired( $token['expires_at'] ) ) {
			cf7at_log( "Token {$token['id']} is expired", 'warning' );
			$this->update_token_status( $token['id'], 'expired' );
			return false;
		}
		
		// Check usage limit
		if ( ! empty( $token['usage_limit'] ) && $token['usage_count'] >= $token['usage_limit'] ) {
			cf7at_log( "Token {$token['id']} usage limit exceeded", 'warning' );
			return false;
		}
		
		// Token is valid, increment usage count
		$this->increment_usage_count( $token['id'] );
		
		cf7at_log( "Token {$token['id']} validated successfully" );
		
		return $token;
	}
	
	/**
	 * Update token status
	 *
	 * @param int $token_id
	 * @param string $status
	 * @return bool
	 */
	public function update_token_status( $token_id, $status ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7AT_TOKENS_TABLE;
		
		$result = $wpdb->update(
			$table_name,
			array( 'status' => sanitize_text_field( $status ) ),
			array( 'id' => $token_id ),
			array( '%s' ),
			array( '%d' )
		);
		
		if ( $result !== false ) {
			do_action( 'cf7at_token_status_updated', $token_id, $status );
			return true;
		}
		
		return false;
	}
	
	/**
	 * Increment usage count
	 *
	 * @param int $token_id
	 * @return bool
	 */
	public function increment_usage_count( $token_id ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7AT_TOKENS_TABLE;
		
		$result = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table_name} SET usage_count = usage_count + 1, last_used_at = %s WHERE id = %d",
				current_time( 'mysql' ),
				$token_id
			)
		);
		
		return $result !== false;
	}
	
	/**
	 * Revoke token
	 *
	 * @param int $token_id
	 * @return bool
	 */
	public function revoke_token( $token_id ) {
		return $this->update_token_status( $token_id, 'revoked' );
	}
	
	/**
	 * Extend token expiration
	 *
	 * @param int $token_id
	 * @param int $hours Hours to extend
	 * @return bool
	 */
	public function extend_token_expiration( $token_id, $hours = 24 ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7AT_TOKENS_TABLE;
		
		$new_expiry = date( 'Y-m-d H:i:s', time() + ( $hours * HOUR_IN_SECONDS ) );
		
		$result = $wpdb->update(
			$table_name,
			array( 'expires_at' => $new_expiry ),
			array( 'id' => $token_id ),
			array( '%s' ),
			array( '%d' )
		);
		
		if ( $result !== false ) {
			do_action( 'cf7at_token_extended', $token_id, $new_expiry );
			return true;
		}
		
		return false;
	}
	
	/**
	 * Get tokens with pagination
	 *
	 * @param array $args
	 * @return array
	 */
	public function get_tokens( $args = array() ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7AT_TOKENS_TABLE;
		
		$defaults = array(
			'status'       => '',
			'related_type' => '',
			'email'        => '',
			'per_page'     => 20,
			'page'         => 1,
			'orderby'      => 'created_at',
			'order'        => 'DESC',
		);
		
		$args = wp_parse_args( $args, $defaults );
		
		$where = '1=1';
		$where_values = array();
		
		if ( ! empty( $args['status'] ) ) {
			$where .= ' AND status = %s';
			$where_values[] = $args['status'];
		}
		
		if ( ! empty( $args['related_type'] ) ) {
			$where .= ' AND related_type = %s';
			$where_values[] = $args['related_type'];
		}
		
		if ( ! empty( $args['email'] ) ) {
			$where .= ' AND email LIKE %s';
			$where_values[] = '%' . $wpdb->esc_like( $args['email'] ) . '%';
		}
		
		$offset = ( $args['page'] - 1 ) * $args['per_page'];
		
		$query = "SELECT * FROM {$table_name} WHERE {$where} ORDER BY {$args['orderby']} {$args['order']} LIMIT %d OFFSET %d";
		$where_values[] = $args['per_page'];
		$where_values[] = $offset;
		
		$tokens = $wpdb->get_results(
			$wpdb->prepare( $query, $where_values ),
			ARRAY_A
		);
		
		// Decode metadata JSON for each token
		foreach ( $tokens as &$token ) {
			if ( ! empty( $token['metadata'] ) ) {
				$token['metadata'] = json_decode( $token['metadata'], true );
			}
		}
		
		// Get total count
		$count_query = "SELECT COUNT(*) FROM {$table_name} WHERE {$where}";
		$count_values = array_slice( $where_values, 0, -2 ); // Remove LIMIT and OFFSET values
		
		if ( ! empty( $count_values ) ) {
			$total = $wpdb->get_var(
				$wpdb->prepare( $count_query, $count_values )
			);
		} else {
			$total = $wpdb->get_var( $count_query );
		}
		
		return array(
			'tokens' => $tokens,
			'total'  => $total,
		);
	}
	
	/**
	 * Calculate token expiry time
	 *
	 * @param int $hours Hours from now
	 * @return string MySQL datetime
	 */
	private function calculate_expiry( $hours = null ) {
		if ( $hours === null ) {
			$hours = cf7at_get_option( 'default_expiry_hours', CF7AT_DEFAULT_EXPIRY_HOURS );
		}
		
		return date( 'Y-m-d H:i:s', time() + ( $hours * HOUR_IN_SECONDS ) );
	}
	
	/**
	 * Store raw token temporarily for email sending
	 *
	 * @param int $token_id
	 * @param string $raw_token
	 */
	private function store_raw_token_temporarily( $token_id, $raw_token ) {
		// Store in transient for 1 hour - enough time to send email
		set_transient( "cf7at_raw_token_{$token_id}", $raw_token, HOUR_IN_SECONDS );
	}
	
	/**
	 * Get raw token temporarily stored
	 *
	 * @param int $token_id
	 * @return string|false
	 */
	public function get_raw_token_temporarily( $token_id ) {
		return get_transient( "cf7at_raw_token_{$token_id}" );
	}
}