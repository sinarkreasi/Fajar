<?php

namespace CF7AT\Emails;

use CF7AT\Core\TokenManager;
use CF7AT\Core\OptionsManager;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Email builder class
 */
class EmailBuilder {
	
	/**
	 * Send magic link email
	 *
	 * @param int $token_id
	 * @param string $email
	 * @param WPCF7_ContactForm $contact_form
	 * @return bool
	 */
	public function send_magic_link_email( $token_id, $email, $contact_form = null ) {
		$token_manager = new TokenManager();
		$raw_token = $token_manager->get_raw_token_temporarily( $token_id );
		
		if ( ! $raw_token ) {
			cf7at_log( "Failed to get raw token for email sending: token ID {$token_id}", 'error' );
			return false;
		}
		
		$token_data = $token_manager->get_token( $token_id );
		
		if ( ! $token_data ) {
			cf7at_log( "Failed to get token data for email sending: token ID {$token_id}", 'error' );
			return false;
		}
		
		$email_options = OptionsManager::get_email_options();
		
		// Generate magic link
		$access_url = cf7at_get_access_url( $raw_token );
		
		// Prepare email content
		$subject = $this->parse_template( $email_options['subject_template'] ?? '', $token_data, $access_url, $contact_form );
		$message = $this->parse_template( $email_options['message_template'] ?? '', $token_data, $access_url, $contact_form );
		
		// Set email headers
		$headers = array();
		
		if ( ! empty( $email_options['from_email'] ) && ! empty( $email_options['from_name'] ) ) {
			$headers[] = sprintf( 'From: %s <%s>', $email_options['from_name'], $email_options['from_email'] );
		}
		
		$headers[] = 'Content-Type: text/html; charset=UTF-8';
		
		// Convert message to HTML
		$html_message = $this->convert_to_html( $message, $access_url );
		
		// Send email
		$sent = wp_mail( $email, $subject, $html_message, $headers );
		
		if ( $sent ) {
			cf7at_log( "Magic link email sent to {$email} for token ID {$token_id}" );
			
			// Clean up raw token after sending
			delete_transient( "cf7at_raw_token_{$token_id}" );
		} else {
			cf7at_log( "Failed to send magic link email to {$email} for token ID {$token_id}", 'error' );
		}
		
		return $sent;
	}
	
	/**
	 * Parse email template with placeholders
	 *
	 * @param string $template
	 * @param array $token_data
	 * @param string $access_url
	 * @param WPCF7_ContactForm $contact_form
	 * @return string
	 */
	private function parse_template( $template, $token_data, $access_url, $contact_form = null ) {
		$expiry_hours = cf7at_get_option( 'default_expiry_hours', CF7AT_DEFAULT_EXPIRY_HOURS );
		$expiry_time = cf7at_format_date( $token_data['expires_at'] );
		
		$placeholders = array(
			'{access_link}'    => $access_url,
			'{access_url}'     => $access_url,
			'{token}'          => '***', // Never expose raw token in email
			'{email}'          => $token_data['email'],
			'{expiry_hours}'   => $expiry_hours,
			'{expiry_time}'    => $expiry_time,
			'{site_name}'      => get_bloginfo( 'name' ),
			'{site_url}'       => home_url(),
			'{related_type}'   => $token_data['related_type'],
			'{related_id}'     => $token_data['related_id'],
		);
		
		// Add form-specific placeholders
		if ( $contact_form ) {
			$placeholders['{form_title}'] = $contact_form->title();
			$placeholders['{form_id}'] = $contact_form->id();
		}
		
		// Add metadata placeholders
		if ( ! empty( $token_data['metadata'] ) && is_array( $token_data['metadata'] ) ) {
			foreach ( $token_data['metadata'] as $key => $value ) {
				if ( is_string( $value ) || is_numeric( $value ) ) {
					$placeholders[ '{' . $key . '}' ] = $value;
				}
			}
		}
		
		// Allow filtering of placeholders
		$placeholders = apply_filters( 'cf7at_email_placeholders', $placeholders, $token_data, $contact_form );
		
		return str_replace( array_keys( $placeholders ), array_values( $placeholders ), $template );
	}
	
	/**
	 * Convert plain text message to HTML
	 *
	 * @param string $message
	 * @param string $access_url
	 * @return string
	 */
	private function convert_to_html( $message, $access_url ) {
		// Convert line breaks to HTML
		$html_message = nl2br( $message );
		
		// Make the access URL a clickable button
		$button_html = sprintf(
			'<a href="%s" style="display: inline-block; padding: 12px 24px; background-color: #0073aa; color: white; text-decoration: none; border-radius: 4px; font-weight: bold;">%s</a>',
			esc_url( $access_url ),
			__( 'Access Your Information', CF7AT_TEXT_DOMAIN )
		);
		
		// Replace plain URL with button
		$html_message = str_replace( $access_url, $button_html, $html_message );
		
		// Wrap in basic HTML template
		$html_template = '
		<!DOCTYPE html>
		<html>
		<head>
			<meta charset="UTF-8">
			<meta name="viewport" content="width=device-width, initial-scale=1.0">
			<title>%s</title>
			<style>
				body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px; }
				.header { border-bottom: 2px solid #0073aa; padding-bottom: 20px; margin-bottom: 30px; }
				.content { margin-bottom: 30px; }
				.footer { border-top: 1px solid #ddd; padding-top: 20px; font-size: 12px; color: #666; }
				.security-notice { background: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 4px; margin: 20px 0; }
			</style>
		</head>
		<body>
			<div class="header">
				<h2>%s</h2>
			</div>
			<div class="content">
				%s
			</div>
			<div class="security-notice">
				<strong>%s</strong><br>
				%s
			</div>
			<div class="footer">
				<p>%s<br>
				%s</p>
			</div>
		</body>
		</html>';
		
		return sprintf(
			$html_template,
			__( 'Secure Access Link', CF7AT_TEXT_DOMAIN ),
			get_bloginfo( 'name' ),
			$html_message,
			__( 'Security Notice:', CF7AT_TEXT_DOMAIN ),
			__( 'This is a secure access link. Do not share it with anyone. If you did not request this access, please ignore this email.', CF7AT_TEXT_DOMAIN ),
			sprintf( __( 'This email was sent by %s', CF7AT_TEXT_DOMAIN ), get_bloginfo( 'name' ) ),
			sprintf( __( 'Visit: %s', CF7AT_TEXT_DOMAIN ), home_url() )
		);
	}
}