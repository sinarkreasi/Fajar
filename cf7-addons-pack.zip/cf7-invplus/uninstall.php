<?php
/**
 * Uninstall script
 * 
 * Fired when the plugin is uninstalled.
 */

// If uninstall not called from WordPress, exit
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Option to preserve data on uninstall
$preserve_data = get_option( 'cf7invplus_preserve_data_on_uninstall', false );

if ( ! $preserve_data ) {
	global $wpdb;
	
	// Drop tables
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}cf7_invoices" );
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}cf7_invoice_items" );
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}cf7_estimator_snapshots" );
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}cf7_calculators" );
	
	// Delete options
	delete_option( 'cf7invplus_version' );
	delete_option( 'cf7invplus_settings' );
	delete_option( 'cf7invplus_preserve_data_on_uninstall' );
	
	// Clear any cached data
	wp_cache_flush();
}
