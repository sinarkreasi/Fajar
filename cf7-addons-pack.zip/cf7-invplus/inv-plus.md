# ROLE
You are a senior WordPress plugin engineer with strong experience in:
- Contact Form 7 internals
- Secure token-based access systems
- Payment & billing architecture
- Modular, extensible plugin design

You will build a production-ready WordPress addon plugin.

---

# PROJECT
CF7 Invoicing Addon  
(Invoice Builder + Cost Estimator + Calculator Builder + Magic Link Access)

---

# GOAL
Transform Contact Form 7 into a billing & calculation system that supports:
- Cost estimation
- Financial calculators
- Invoice generation
- Payment-ready invoices
- Secure access WITHOUT user accounts

---

# CORE PRINCIPLES
- No frontend user accounts
- Token-based (Magic Link) access
- Editable invoices
- Snapshot-based calculations
- Modular & extensible architecture
- Clean separation of concerns

---

# PLUGIN ARCHITECTURE

/ cf7-invplus
│
├─ plugin.php
├─ /includes
│  ├─ invoice-manager.php
│  ├─ invoice-item.php
│  ├─ estimator-engine.php
│  ├─ calculator-builder.php
│  ├─ magic-link.php
│  ├─ payment-bridge.php
│  ├─ email-service.php
│  └─ hooks.php
│
├─ /database
│  ├─ schema-invoice.php
│  ├─ schema-estimator.php
│  ├─ schema-calculator.php
│  └─ schema-magic-link.php
│
├─ /admin
│  ├─ invoice-editor.php
│  ├─ calculator-builder-ui.php
│  └─ settings.php
│
├─ /public
│  ├─ invoice-view.php
│  ├─ calculator-render.php
│  └─ checkout-inline.php
│
└─ /assets

---

# DATA MODELS

## Invoice
- id
- invoice_number
- status (draft, sent, unpaid, paid, overdue, cancelled)
- issue_date
- due_date
- currency
- subtotal
- tax_total
- discount_total
- grand_total
- client_snapshot (name, email, company, address)
- source (cf7, manual, calculator)
- created_at
- updated_at

## Invoice Items
- invoice_id
- name
- description
- qty
- unit_price
- subtotal
- tax
- discount

## Estimator Snapshot
- invoice_id
- formula_version
- inputs (JSON)
- calculation_steps (JSON)
- result_total

## Magic Link Token
- resource_type (invoice)
- resource_id
- token_hash
- expires_at
- max_usage
- usage_count

## Calculator
- id
- name
- type (loan, kpr, roi, roas, custom)
- formula
- output_format

---

# ESTIMATOR FORMULA ENGINE

## Requirements
- Declarative formula definitions
- Versioned formulas
- JSON-based inputs
- Expression parser (no eval)

## Supported logic
- Fixed pricing
- Quantity-based pricing
- Conditional pricing
- Formula expressions

## Example Formula
{
  "version": "1.0",
  "rules": [
    "base = pages * price_per_page",
    "seo_fee = seo == 'advanced' ? 2000000 : 0",
    "total = base + seo_fee"
  ]
}

---

# CALCULATOR BUILDER

## Calculator Types
- Loan / Installment
- Mortgage (KPR)
- ROI
- ROAS
- Profit / Margin
- Custom formula calculator

## Features
- Visual field builder (number, select, slider)
- Formula-based calculation
- Conditional outputs
- Frontend rendering
- Email result option
- Convert result → Invoice draft

---

# MAGIC LINK SECURITY FLOW

## Token Rules
- Token stored as hash
- Expirable
- Limited usage
- Revocable & regeneratable

## Access Permissions
Allowed:
- View invoice
- Download PDF
- Pay invoice

Denied:
- Edit invoice
- View other invoices

---

# PAYMENT BRIDGE

## Capabilities
- Inline checkout (no redirect)
- Gateway-agnostic architecture
- Payment callback updates invoice status

## Status Flow
Payment Success → Invoice Paid → Trigger Hooks

---

# CONTACT FORM 7 INTEGRATION

## Mapping
- CF7 field → estimator variable (slider)
- CF7 field → invoice field
- CF7 submission → invoice trigger

## Triggers
- On submit
- Conditional invoice creation
- Draft or auto-send

---

# ADMIN UI

## Invoice Editor
- Editable items
- Inline recalculation
- Manual status control

## Calculator Builder
- Create & manage calculators
- Preview calculations
- Assign to CF7 forms

---

# EMAIL SYSTEM

## Email Types
- Invoice created
- Invoice reminder
- Payment confirmation
- Calculator result

## Email Content
- Dynamic variables
- Magic link CTA

---

# EXTENSIBILITY

## Hooks
- before_invoice_create
- after_invoice_paid
- before_magic_link_send
- after_calculation_complete

## REST-ready
Prepare for future SaaS backend integration.

---

# OUTPUT EXPECTATION
Produce:
1. Clean, production-ready PHP code
2. Secure token handling
3. Well-structured database schema
4. Modular, extensible classes
5. Inline documentation for developers

---

# IMPORTANT
Do NOT:
- Use user login systems
- Depend on WooCommerce
- Hardcode gateways
- Mix frontend and admin logic

Build this as a scalable foundation for a billing ecosystem.
