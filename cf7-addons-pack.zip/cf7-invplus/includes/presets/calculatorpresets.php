<?php

namespace CF7InvPlus\Presets;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Calculator presets class
 */
class CalculatorPresets {
	
	/**
	 * Install all calculator presets
	 */
	public static function install_presets() {
		$calculator_builder = \CF7InvPlus\Core\CalculatorBuilder::instance();
		
		$presets = self::get_presets();
		
		foreach ( $presets as $preset ) {
			// Check if preset already exists
			$existing = $calculator_builder->get_calculator_by_slug( $preset['slug'] );
			
			if ( ! $existing ) {
				$calculator_builder->create_calculator( $preset );
			}
		}
	}
	
	/**
	 * Get all preset definitions
	 *
	 * @return array
	 */
	public static function get_presets() {
		return array(
			self::get_loan_calculator(),
			self::get_kpr_calculator(),
			self::get_roi_calculator(),
			self::get_roas_calculator(),
			self::get_profit_margin_calculator(),
		);
	}
	
	/**
	 * Loan Calculator preset
	 *
	 * @return array
	 */
	private static function get_loan_calculator() {
		return array(
			'name'        => __( 'Loan Calculator', CF7INVPLUS_TEXT_DOMAIN ),
			'slug'        => 'loan-calculator',
			'type'        => 'loan',
			'description' => __( 'Calculate monthly loan payments with interest', CF7INVPLUS_TEXT_DOMAIN ),
			'is_preset'   => 1,
			'fields'      => array(
				array(
					'name'        => 'principal',
					'label'       => __( 'Loan Amount', CF7INVPLUS_TEXT_DOMAIN ),
					'type'        => 'number',
					'placeholder' => '10000000',
					'required'    => true,
				),
				array(
					'name'        => 'rate',
					'label'       => __( 'Interest Rate (% per year)', CF7INVPLUS_TEXT_DOMAIN ),
					'type'        => 'number',
					'placeholder' => '12',
					'step'        => '0.1',
					'required'    => true,
				),
				array(
					'name'        => 'term',
					'label'       => __( 'Loan Term (months)', CF7INVPLUS_TEXT_DOMAIN ),
					'type'        => 'number',
					'placeholder' => '12',
					'required'    => true,
				),
			),
			'formula'     => array(
				'version' => '1.0',
				'rules'   => array(
					'monthly_rate = rate / 12 / 100',
					'monthly_payment = monthly_rate != 0 ? (principal * monthly_rate) / (1 - (1 + monthly_rate)^(-term)) : principal / term',
					'total_payment = monthly_payment * term',
					'total_interest = total_payment - principal',
					'total = monthly_payment',
				),
			),
			'output_format' => array(
				'fields' => array(
					array(
						'variable' => 'monthly_payment',
						'label'    => __( 'Monthly Payment', CF7INVPLUS_TEXT_DOMAIN ),
						'format'   => 'currency',
						'currency' => 'IDR',
					),
					array(
						'variable' => 'total_payment',
						'label'    => __( 'Total Payment', CF7INVPLUS_TEXT_DOMAIN ),
						'format'   => 'currency',
						'currency' => 'IDR',
					),
					array(
						'variable' => 'total_interest',
						'label'    => __( 'Total Interest', CF7INVPLUS_TEXT_DOMAIN ),
						'format'   => 'currency',
						'currency' => 'IDR',
					),
				),
			),
		);
	}
	
	/**
	 * KPR/Mortgage Calculator preset
	 *
	 * @return array
	 */
	private static function get_kpr_calculator() {
		return array(
			'name'        => __( 'KPR/Mortgage Calculator', CF7INVPLUS_TEXT_DOMAIN ),
			'slug'        => 'kpr-calculator',
			'type'        => 'kpr',
			'description' => __( 'Indonesian mortgage calculator with down payment', CF7INVPLUS_TEXT_DOMAIN ),
			'is_preset'   => 1,
			'fields'      => array(
				array(
					'name'        => 'price',
					'label'       => __( 'Property Price', CF7INVPLUS_TEXT_DOMAIN ),
					'type'        => 'number',
					'placeholder' => '500000000',
					'required'    => true,
				),
				array(
					'name'        => 'dp_percent',
					'label'       => __( 'Down Payment (%)', CF7INVPLUS_TEXT_DOMAIN ),
					'type'        => 'number',
					'placeholder' => '20',
					'step'        => '1',
					'required'    => true,
				),
				array(
					'name'        => 'rate',
					'label'       => __( 'Interest Rate (% per year)', CF7INVPLUS_TEXT_DOMAIN ),
					'type'        => 'number',
					'placeholder' => '8.5',
					'step'        => '0.1',
					'required'    => true,
				),
				array(
					'name'        => 'term_years',
					'label'       => __( 'Loan Term (years)', CF7INVPLUS_TEXT_DOMAIN ),
					'type'        => 'number',
					'placeholder' => '15',
					'required'    => true,
				),
			),
			'formula'     => array(
				'version' => '1.0',
				'rules'   => array(
					'down_payment = price * (dp_percent / 100)',
					'loan_amount = price - down_payment',
					'monthly_rate = rate / 12 / 100',
					'months = term_years * 12',
					'monthly_payment = monthly_rate != 0 ? (loan_amount * monthly_rate) / (1 - (1 + monthly_rate)^(-months)) : loan_amount / months',
					'total_payment = monthly_payment * months',
					'total_interest = total_payment - loan_amount',
					'total = monthly_payment',
				),
			),
			'output_format' => array(
				'fields' => array(
					array(
						'variable' => 'down_payment',
						'label'    => __( 'Down Payment', CF7INVPLUS_TEXT_DOMAIN ),
						'format'   => 'currency',
						'currency' => 'IDR',
					),
					array(
						'variable' => 'loan_amount',
						'label'    => __( 'Loan Amount', CF7INVPLUS_TEXT_DOMAIN ),
						'format'   => 'currency',
						'currency' => 'IDR',
					),
					array(
						'variable' => 'monthly_payment',
						'label'    => __( 'Monthly Installment', CF7INVPLUS_TEXT_DOMAIN ),
						'format'   => 'currency',
						'currency' => 'IDR',
					),
					array(
						'variable' => 'total_payment',
						'label'    => __( 'Total Payment', CF7INVPLUS_TEXT_DOMAIN ),
						'format'   => 'currency',
						'currency' => 'IDR',
					),
					array(
						'variable' => 'total_interest',
						'label'    => __( 'Total Interest', CF7INVPLUS_TEXT_DOMAIN ),
						'format'   => 'currency',
						'currency' => 'IDR',
					),
				),
			),
		);
	}
	
	/**
	 * ROI Calculator preset
	 *
	 * @return array
	 */
	private static function get_roi_calculator() {
		return array(
			'name'        => __( 'ROI Calculator', CF7INVPLUS_TEXT_DOMAIN ),
			'slug'        => 'roi-calculator',
			'type'        => 'roi',
			'description' => __( 'Calculate return on investment', CF7INVPLUS_TEXT_DOMAIN ),
			'is_preset'   => 1,
			'fields'      => array(
				array(
					'name'        => 'initial_investment',
					'label'       => __( 'Initial Investment', CF7INVPLUS_TEXT_DOMAIN ),
					'type'        => 'number',
					'placeholder' => '10000000',
					'required'    => true,
				),
				array(
					'name'        => 'final_value',
					'label'       => __( 'Final Value', CF7INVPLUS_TEXT_DOMAIN ),
					'type'        => 'number',
					'placeholder' => '15000000',
					'required'    => true,
				),
				array(
					'name'        => 'time_period',
					'label'       => __( 'Time Period (years)', CF7INVPLUS_TEXT_DOMAIN ),
					'type'        => 'number',
					'placeholder' => '2',
					'step'        => '0.1',
					'required'    => true,
				),
			),
			'formula'     => array(
				'version' => '1.0',
				'rules'   => array(
					'gain = final_value - initial_investment',
					'roi = initial_investment != 0 ? (gain / initial_investment) * 100 : 0',
					'annualized_roi = time_period != 0 ? roi / time_period : 0',
					'total = roi',
				),
			),
			'output_format' => array(
				'fields' => array(
					array(
						'variable' => 'gain',
						'label'    => __( 'Total Gain/Loss', CF7INVPLUS_TEXT_DOMAIN ),
						'format'   => 'currency',
						'currency' => 'IDR',
					),
					array(
						'variable' => 'roi',
						'label'    => __( 'ROI', CF7INVPLUS_TEXT_DOMAIN ),
						'format'   => 'percentage',
					),
					array(
						'variable' => 'annualized_roi',
						'label'    => __( 'Annualized ROI', CF7INVPLUS_TEXT_DOMAIN ),
						'format'   => 'percentage',
					),
				),
			),
		);
	}
	
	/**
	 * ROAS Calculator preset
	 *
	 * @return array
	 */
	private static function get_roas_calculator() {
		return array(
			'name'        => __( 'ROAS Calculator', CF7INVPLUS_TEXT_DOMAIN ),
			'slug'        => 'roas-calculator',
			'type'        => 'roas',
			'description' => __( 'Calculate return on ad spend', CF7INVPLUS_TEXT_DOMAIN ),
			'is_preset'   => 1,
			'fields'      => array(
				array(
					'name'        => 'ad_spend',
					'label'       => __( 'Ad Spend', CF7INVPLUS_TEXT_DOMAIN ),
					'type'        => 'number',
					'placeholder' => '5000000',
					'required'    => true,
				),
				array(
					'name'        => 'revenue',
					'label'       => __( 'Revenue Generated', CF7INVPLUS_TEXT_DOMAIN ),
					'type'        => 'number',
					'placeholder' => '20000000',
					'required'    => true,
				),
			),
			'formula'     => array(
				'version' => '1.0',
				'rules'   => array(
					'profit = revenue - ad_spend',
					'roas = ad_spend != 0 ? (revenue / ad_spend) * 100 : 0',
					'breakeven = ad_spend',
					'total = roas',
				),
			),
			'output_format' => array(
				'fields' => array(
					array(
						'variable' => 'roas',
						'label'    => __( 'ROAS', CF7INVPLUS_TEXT_DOMAIN ),
						'format'   => 'percentage',
					),
					array(
						'variable' => 'profit',
						'label'    => __( 'Profit/Loss', CF7INVPLUS_TEXT_DOMAIN ),
						'format'   => 'currency',
						'currency' => 'IDR',
					),
					array(
						'variable' => 'breakeven',
						'label'    => __( 'Break-even Point', CF7INVPLUS_TEXT_DOMAIN ),
						'format'   => 'currency',
						'currency' => 'IDR',
					),
				),
			),
		);
	}
	
	/**
	 * Profit/Margin Calculator preset
	 *
	 * @return array
	 */
	private static function get_profit_margin_calculator() {
		return array(
			'name'        => __( 'Profit/Margin Calculator', CF7INVPLUS_TEXT_DOMAIN ),
			'slug'        => 'profit-margin-calculator',
			'type'        => 'profit_margin',
			'description' => __( 'Calculate profit and margin', CF7INVPLUS_TEXT_DOMAIN ),
			'is_preset'   => 1,
			'fields'      => array(
				array(
					'name'        => 'cost_price',
					'label'       => __( 'Cost Price', CF7INVPLUS_TEXT_DOMAIN ),
					'type'        => 'number',
					'placeholder' => '100000',
					'required'    => true,
				),
				array(
					'name'        => 'selling_price',
					'label'       => __( 'Selling Price', CF7INVPLUS_TEXT_DOMAIN ),
					'type'        => 'number',
					'placeholder' => '150000',
					'required'    => true,
				),
				array(
					'name'        => 'quantity',
					'label'       => __( 'Quantity', CF7INVPLUS_TEXT_DOMAIN ),
					'type'        => 'number',
					'placeholder' => '10',
					'required'    => true,
				),
			),
			'formula'     => array(
				'version' => '1.0',
				'rules'   => array(
					'profit_per_unit = selling_price - cost_price',
					'total_profit = profit_per_unit * quantity',
					'margin = selling_price != 0 ? (profit_per_unit / selling_price) * 100 : 0',
					'markup = cost_price != 0 ? (profit_per_unit / cost_price) * 100 : 0',
					'total = total_profit',
				),
			),
			'output_format' => array(
				'fields' => array(
					array(
						'variable' => 'profit_per_unit',
						'label'    => __( 'Profit per Unit', CF7INVPLUS_TEXT_DOMAIN ),
						'format'   => 'currency',
						'currency' => 'IDR',
					),
					array(
						'variable' => 'total_profit',
						'label'    => __( 'Total Profit', CF7INVPLUS_TEXT_DOMAIN ),
						'format'   => 'currency',
						'currency' => 'IDR',
					),
					array(
						'variable' => 'margin',
						'label'    => __( 'Profit Margin', CF7INVPLUS_TEXT_DOMAIN ),
						'format'   => 'percentage',
					),
					array(
						'variable' => 'markup',
						'label'    => __( 'Markup', CF7INVPLUS_TEXT_DOMAIN ),
						'format'   => 'percentage',
					),
				),
			),
		);
	}
}
