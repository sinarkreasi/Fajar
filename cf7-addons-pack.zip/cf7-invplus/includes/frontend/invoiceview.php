<?php

namespace CF7InvPlus\Frontend;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Invoice view frontend class
 */
class InvoiceView {
	
	/**
	 * Instance
	 */
	private static $instance = null;
	
	/**
	 * Get instance
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		// Constructor intentionally left empty
	}
	
	/**
	 * Render invoice
	 *
	 * @param array $invoice
	 */
	public function render_invoice( $invoice ) {
		// Get invoice items
		$invoice_manager = \CF7InvPlus\Core\InvoiceManager::instance();
		$items = $invoice_manager->get_invoice_items( $invoice['id'] );
		
		// Get payment URL if unpaid
		$payment_url = '';
		if ( in_array( $invoice['status'], array( 'sent', 'unpaid', 'overdue' ) ) ) {
			$payment_integration = \CF7InvPlus\Integrations\PaymentIntegration::instance();
			$payment_url = $payment_integration->get_payment_url( $invoice['id'] );
		}
		
		// Render template
		include CF7INVPLUS_PLUGIN_DIR . '/templates/invoice-view.php';
	}
}
