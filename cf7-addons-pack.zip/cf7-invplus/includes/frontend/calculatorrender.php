<?php

namespace CF7InvPlus\Frontend;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Calculator render frontend class
 */
class CalculatorRender {
	
	/**
	 * Instance
	 */
	private static $instance = null;
	
	/**
	 * Get instance
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		// Constructor intentionally left empty
	}
	
	/**
	 * Render calculator shortcode
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function render_shortcode( $atts ) {
		$atts = shortcode_atts( array(
			'id'   => 0,
			'slug' => '',
		), $atts );
		
		$calculator_builder = \CF7InvPlus\Core\CalculatorBuilder::instance();
		
		if ( ! empty( $atts['id'] ) ) {
			$calculator = $calculator_builder->get_calculator( intval( $atts['id'] ) );
		} elseif ( ! empty( $atts['slug'] ) ) {
			$calculator = $calculator_builder->get_calculator_by_slug( $atts['slug'] );
		} else {
			return '<p>' . __( 'Please specify calculator ID or slug', CF7INVPLUS_TEXT_DOMAIN ) . '</p>';
		}
		
		if ( ! $calculator ) {
			return '<p>' . __( 'Calculator not found', CF7INVPLUS_TEXT_DOMAIN ) . '</p>';
		}
		
		ob_start();
		include CF7INVPLUS_PLUGIN_DIR . '/templates/calculator-form.php';
		return ob_get_clean();
	}
}
