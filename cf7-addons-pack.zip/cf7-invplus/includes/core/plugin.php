<?php

namespace CF7InvPlus\Core;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Main plugin class
 */
class Plugin {
	
	/**
	 * Instance
	 */
	private static $instance = null;
	
	/**
	 * Get instance
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		$this->init_hooks();
	}
	
	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		// Enqueue assets
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_frontend_assets' ) );
		
		// AJAX handlers
		add_action( 'wp_ajax_cf7invplus_calculate', array( $this, 'ajax_calculate' ) );
		add_action( 'wp_ajax_nopriv_cf7invplus_calculate', array( $this, 'ajax_calculate' ) );
	}
	
	/**
	 * Enqueue admin assets
	 */
	public function enqueue_admin_assets( $hook ) {
		// Only load on our admin pages
		if ( strpos( $hook, 'cf7invplus' ) === false ) {
			return;
		}
		
		wp_enqueue_style(
			'cf7invplus-admin',
			CF7INVPLUS_PLUGIN_URL . '/assets/css/admin.css',
			array(),
			CF7INVPLUS_VERSION
		);
		
		wp_enqueue_script(
			'cf7invplus-admin',
			CF7INVPLUS_PLUGIN_URL . '/assets/js/admin.js',
			array( 'jquery' ),
			CF7INVPLUS_VERSION,
			true
		);
		
		wp_localize_script( 'cf7invplus-admin', 'cf7invplus', array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'cf7invplus_nonce' ),
		) );
	}
	
	/**
	 * Enqueue frontend assets
	 */
	public function enqueue_frontend_assets() {
		wp_enqueue_style(
			'cf7invplus-frontend',
			CF7INVPLUS_PLUGIN_URL . '/assets/css/frontend.css',
			array(),
			CF7INVPLUS_VERSION
		);
		
		wp_enqueue_script(
			'cf7invplus-calculator',
			CF7INVPLUS_PLUGIN_URL . '/assets/js/calculator.js',
			array( 'jquery' ),
			CF7INVPLUS_VERSION,
			true
		);
		
		wp_localize_script( 'cf7invplus-calculator', 'cf7invplus', array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'cf7invplus_nonce' ),
		) );
	}
	
	/**
	 * AJAX calculate handler
	 */
	public function ajax_calculate() {
		check_ajax_referer( 'cf7invplus_nonce', 'nonce' );
		
		$calculator_id = isset( $_POST['calculator_id'] ) ? intval( $_POST['calculator_id'] ) : 0;
		$inputs = isset( $_POST['inputs'] ) ? $_POST['inputs'] : array();
		
		if ( ! $calculator_id ) {
			wp_send_json_error( array( 'message' => 'Invalid calculator ID' ) );
		}
		
		$calculator_builder = CalculatorBuilder::instance();
		$result = $calculator_builder->calculate( $calculator_id, $inputs );
		
		if ( $result ) {
			wp_send_json_success( $result );
		} else {
			wp_send_json_error( array( 'message' => 'Calculation failed' ) );
		}
	}
}
