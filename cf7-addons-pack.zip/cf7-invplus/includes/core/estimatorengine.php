<?php

namespace CF7InvPlus\Core;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Estimator engine class
 * Handles formula-based calculations without using eval()
 */
class EstimatorEngine {
	
	/**
	 * Execute calculation
	 *
	 * @param array $formula Formula definition
	 * @param array $inputs Input values
	 * @return array|false Result or false on failure
	 */
	public function calculate( $formula, $inputs ) {
		if ( empty( $formula['rules'] ) ) {
			return false;
		}
		
		$variables = $inputs;
		$steps = array();
		
		try {
			foreach ( $formula['rules'] as $rule ) {
				$result = $this->execute_rule( $rule, $variables );
				
				if ( $result === false ) {
					cf7invplus_log( "Failed to execute rule: $rule", 'error' );
					return false;
				}
				
				$variables[ $result['variable'] ] = $result['value'];
				$steps[] = $result;
			}
			
			return array(
				'variables' => $variables,
				'steps'     => $steps,
				'result'    => isset( $variables['total'] ) ? $variables['total'] : 0,
			);
			
		} catch ( \Exception $e ) {
			cf7invplus_log( 'Calculation error: ' . $e->getMessage(), 'error' );
			return false;
		}
	}
	
	/**
	 * Execute a single rule
	 *
	 * @param string $rule
	 * @param array $variables
	 * @return array|false
	 */
	private function execute_rule( $rule, $variables ) {
		// Parse rule: variable = expression
		if ( ! preg_match( '/^\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*=\s*(.+)$/', $rule, $matches ) ) {
			return false;
		}
		
		$variable_name = $matches[1];
		$expression = $matches[2];
		
		// Evaluate expression
		$value = $this->evaluate_expression( $expression, $variables );
		
		if ( $value === false ) {
			return false;
		}
		
		return array(
			'variable' => $variable_name,
			'value'    => $value,
			'rule'     => $rule,
		);
	}
	
	/**
	 * Evaluate expression
	 *
	 * @param string $expression
	 * @param array $variables
	 * @return float|false
	 */
	private function evaluate_expression( $expression, $variables ) {
		$expression = trim( $expression );
		
		// Handle ternary operator: condition ? true_value : false_value
		if ( preg_match( '/^(.+?)\s*\?\s*(.+?)\s*:\s*(.+)$/', $expression, $matches ) ) {
			$condition = $this->evaluate_condition( $matches[1], $variables );
			
			if ( $condition === null ) {
				return false;
			}
			
			$true_expr = $matches[2];
			$false_expr = $matches[3];
			
			return $condition ? 
				$this->evaluate_expression( $true_expr, $variables ) : 
				$this->evaluate_expression( $false_expr, $variables );
		}
		
		// Replace variables with their values
		$expression = $this->replace_variables( $expression, $variables );
		
		// Evaluate mathematical expression
		return $this->evaluate_math( $expression );
	}
	
	/**
	 * Evaluate condition
	 *
	 * @param string $condition
	 * @param array $variables
	 * @return bool|null
	 */
	private function evaluate_condition( $condition, $variables ) {
		$condition = trim( $condition );
		
		// Replace variables
		$condition = $this->replace_variables( $condition, $variables );
		
		// Handle comparison operators
		if ( preg_match( '/^(.+?)\s*(==|!=|>|<|>=|<=)\s*(.+)$/', $condition, $matches ) ) {
			$left = $this->evaluate_math( trim( $matches[1] ) );
			$operator = $matches[2];
			$right = $this->evaluate_math( trim( $matches[3] ) );
			
			// Handle string comparisons (for select values)
			if ( is_string( $left ) || is_string( $right ) ) {
				$left = trim( $left, '\'"' );
				$right = trim( $right, '\'"' );
				
				switch ( $operator ) {
					case '==':
						return $left == $right;
					case '!=':
						return $left != $right;
					default:
						return null;
				}
			}
			
			// Numeric comparisons
			switch ( $operator ) {
				case '==':
					return $left == $right;
				case '!=':
					return $left != $right;
				case '>':
					return $left > $right;
				case '<':
					return $left < $right;
				case '>=':
					return $left >= $right;
				case '<=':
					return $left <= $right;
				default:
					return null;
			}
		}
		
		return null;
	}
	
	/**
	 * Replace variables in expression
	 *
	 * @param string $expression
	 * @param array $variables
	 * @return string
	 */
	private function replace_variables( $expression, $variables ) {
		// Sort by length (longest first) to avoid partial replacements
		$var_names = array_keys( $variables );
		usort( $var_names, function( $a, $b ) {
			return strlen( $b ) - strlen( $a );
		});
		
		foreach ( $var_names as $var_name ) {
			$value = $variables[ $var_name ];
			
			// Handle string values (keep quotes)
			if ( is_string( $value ) && ! is_numeric( $value ) ) {
				$value = "'" . addslashes( $value ) . "'";
			}
			
			// Replace variable with value (word boundary)
			$expression = preg_replace( '/\b' . preg_quote( $var_name, '/' ) . '\b/', $value, $expression );
		}
		
		return $expression;
	}
	
	/**
	 * Evaluate mathematical expression safely
	 *
	 * @param string $expression
	 * @return float|string
	 */
	private function evaluate_math( $expression ) {
		$expression = trim( $expression );
		
		// If it's a quoted string, return as is
		if ( preg_match( '/^[\'"](.+)[\'"]$/', $expression, $matches ) ) {
			return $matches[1];
		}
		
		// If it's already a number, return it
		if ( is_numeric( $expression ) ) {
			return floatval( $expression );
		}
		
		// Sanitize expression - only allow numbers, operators, parentheses, and dots
		if ( ! preg_match( '/^[\d\s\+\-\*\/\(\)\.\^]+$/', $expression ) ) {
			return $expression; // Return as string if not a valid math expression
		}
		
		// Replace ^ with ** for power operator
		$expression = str_replace( '^', '**', $expression );
		
		// Use BC Math for safe calculation
		try {
			// Simple recursive descent parser for basic arithmetic
			$result = $this->parse_expression( $expression );
			return $result;
		} catch ( \Exception $e ) {
			cf7invplus_log( 'Math evaluation error: ' . $e->getMessage(), 'error' );
			return 0;
		}
	}
	
	/**
	 * Parse and evaluate mathematical expression
	 *
	 * @param string $expr
	 * @return float
	 */
	private function parse_expression( $expr ) {
		$expr = str_replace( ' ', '', $expr );
		
		// Handle parentheses
		while ( preg_match( '/\(([^\(\)]+)\)/', $expr, $matches ) ) {
			$inner = $this->parse_simple_expression( $matches[1] );
			$expr = str_replace( $matches[0], $inner, $expr );
		}
		
		return $this->parse_simple_expression( $expr );
	}
	
	/**
	 * Parse simple expression without parentheses
	 *
	 * @param string $expr
	 * @return float
	 */
	private function parse_simple_expression( $expr ) {
		// Handle power operator first (highest precedence)
		if ( preg_match( '/^(.+)\*\*(.+)$/', $expr, $matches ) ) {
			$left = $this->parse_simple_expression( $matches[1] );
			$right = $this->parse_simple_expression( $matches[2] );
			return pow( $left, $right );
		}
		
		// Handle multiplication and division
		if ( preg_match( '/^(.+)([\*\/])(.+)$/', $expr, $matches ) ) {
			$left = $this->parse_simple_expression( $matches[1] );
			$operator = $matches[2];
			$right = $this->parse_simple_expression( $matches[3] );
			
			if ( $operator === '*' ) {
				return $left * $right;
			} else {
				return $right != 0 ? $left / $right : 0;
			}
		}
		
		// Handle addition and subtraction
		if ( preg_match( '/^(.+)([\+\-])(.+)$/', $expr, $matches ) ) {
			$left = $this->parse_simple_expression( $matches[1] );
			$operator = $matches[2];
			$right = $this->parse_simple_expression( $matches[3] );
			
			if ( $operator === '+' ) {
				return $left + $right;
			} else {
				return $left - $right;
			}
		}
		
		// Base case: just a number
		return floatval( $expr );
	}
	
	/**
	 * Save calculation snapshot
	 *
	 * @param int $invoice_id
	 * @param array $formula
	 * @param array $inputs
	 * @param array $result
	 * @return int|false Snapshot ID or false
	 */
	public function save_snapshot( $invoice_id, $formula, $inputs, $result ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7INVPLUS_ESTIMATOR_SNAPSHOTS_TABLE;
		
		$data = array(
			'invoice_id'        => $invoice_id,
			'formula_version'   => isset( $formula['version'] ) ? $formula['version'] : '1.0',
			'inputs'            => wp_json_encode( $inputs ),
			'calculation_steps' => wp_json_encode( $result['steps'] ),
			'result_total'      => $result['result'],
			'created_at'        => current_time( 'mysql' ),
		);
		
		$wpdb->insert( $table_name, $data );
		
		return $wpdb->insert_id;
	}
}
