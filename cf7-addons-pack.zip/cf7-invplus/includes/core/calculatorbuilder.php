<?php

namespace CF7InvPlus\Core;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Calculator builder class
 */
class CalculatorBuilder {
	
	/**
	 * Instance
	 */
	private static $instance = null;
	
	/**
	 * Get instance
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		// Constructor intentionally left empty
	}
	
	/**
	 * Create calculator
	 *
	 * @param array $calculator_data
	 * @return int|false Calculator ID or false on failure
	 */
	public function create_calculator( $calculator_data ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7INVPLUS_CALCULATORS_TABLE;
		
		// Generate slug if not provided
		if ( empty( $calculator_data['slug'] ) ) {
			$calculator_data['slug'] = sanitize_title( $calculator_data['name'] );
		}
		
		$defaults = array(
			'name'          => '',
			'slug'          => '',
			'type'          => 'custom',
			'description'   => '',
			'fields'        => '[]',
			'formula'       => '{}',
			'output_format' => '{}',
			'is_preset'     => 0,
			'status'        => 'active',
			'created_at'    => current_time( 'mysql' ),
		);
		
		$calculator_data = wp_parse_args( $calculator_data, $defaults );
		
		// Ensure JSON fields
		if ( is_array( $calculator_data['fields'] ) ) {
			$calculator_data['fields'] = wp_json_encode( $calculator_data['fields'] );
		}
		if ( is_array( $calculator_data['formula'] ) ) {
			$calculator_data['formula'] = wp_json_encode( $calculator_data['formula'] );
		}
		if ( is_array( $calculator_data['output_format'] ) ) {
			$calculator_data['output_format'] = wp_json_encode( $calculator_data['output_format'] );
		}
		
		$result = $wpdb->insert( $table_name, $calculator_data );
		
		if ( $result === false ) {
			cf7invplus_log( 'Failed to create calculator: ' . $wpdb->last_error, 'error' );
			return false;
		}
		
		$calculator_id = $wpdb->insert_id;
		
		do_action( 'cf7invplus_calculator_created', $calculator_id, $calculator_data );
		
		return $calculator_id;
	}
	
	/**
	 * Get calculator by ID
	 *
	 * @param int $calculator_id
	 * @return array|null
	 */
	public function get_calculator( $calculator_id ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7INVPLUS_CALCULATORS_TABLE;
		
		$calculator = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table_name} WHERE id = %d", $calculator_id ),
			ARRAY_A
		);
		
		if ( $calculator ) {
			$calculator['fields'] = json_decode( $calculator['fields'], true );
			$calculator['formula'] = json_decode( $calculator['formula'], true );
			$calculator['output_format'] = json_decode( $calculator['output_format'], true );
		}
		
		return $calculator;
	}
	
	/**
	 * Get calculator by slug
	 *
	 * @param string $slug
	 * @return array|null
	 */
	public function get_calculator_by_slug( $slug ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7INVPLUS_CALCULATORS_TABLE;
		
		$calculator = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table_name} WHERE slug = %s", $slug ),
			ARRAY_A
		);
		
		if ( $calculator ) {
			$calculator['fields'] = json_decode( $calculator['fields'], true );
			$calculator['formula'] = json_decode( $calculator['formula'], true );
			$calculator['output_format'] = json_decode( $calculator['output_format'], true );
		}
		
		return $calculator;
	}
	
	/**
	 * Update calculator
	 *
	 * @param int $calculator_id
	 * @param array $data
	 * @return bool
	 */
	public function update_calculator( $calculator_id, $data ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7INVPLUS_CALCULATORS_TABLE;
		
		$data['updated_at'] = current_time( 'mysql' );
		
		// Ensure JSON fields
		if ( isset( $data['fields'] ) && is_array( $data['fields'] ) ) {
			$data['fields'] = wp_json_encode( $data['fields'] );
		}
		if ( isset( $data['formula'] ) && is_array( $data['formula'] ) ) {
			$data['formula'] = wp_json_encode( $data['formula'] );
		}
		if ( isset( $data['output_format'] ) && is_array( $data['output_format'] ) ) {
			$data['output_format'] = wp_json_encode( $data['output_format'] );
		}
		
		$result = $wpdb->update(
			$table_name,
			$data,
			array( 'id' => $calculator_id )
		);
		
		if ( $result !== false ) {
			do_action( 'cf7invplus_calculator_updated', $calculator_id, $data );
			return true;
		}
		
		return false;
	}
	
	/**
	 * Delete calculator
	 *
	 * @param int $calculator_id
	 * @return bool
	 */
	public function delete_calculator( $calculator_id ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7INVPLUS_CALCULATORS_TABLE;
		
		$result = $wpdb->delete(
			$table_name,
			array( 'id' => $calculator_id ),
			array( '%d' )
		);
		
		if ( $result !== false ) {
			do_action( 'cf7invplus_calculator_deleted', $calculator_id );
			return true;
		}
		
		return false;
	}
	
	/**
	 * Calculate using calculator
	 *
	 * @param int $calculator_id
	 * @param array $inputs
	 * @return array|false
	 */
	public function calculate( $calculator_id, $inputs ) {
		$calculator = $this->get_calculator( $calculator_id );
		
		if ( ! $calculator ) {
			return false;
		}
		
		$estimator = new EstimatorEngine();
		$result = $estimator->calculate( $calculator['formula'], $inputs );
		
		if ( $result ) {
			// Format output
			$result['formatted'] = $this->format_output( $result, $calculator['output_format'] );
		}
		
		return $result;
	}
	
	/**
	 * Format calculation output
	 *
	 * @param array $result
	 * @param array $output_format
	 * @return array
	 */
	private function format_output( $result, $output_format ) {
		$formatted = array();
		
		if ( empty( $output_format ) || empty( $output_format['fields'] ) ) {
			// Default formatting
			$formatted['result'] = cf7invplus_format_currency( $result['result'] );
			return $formatted;
		}
		
		foreach ( $output_format['fields'] as $field ) {
			$var_name = $field['variable'];
			$label = $field['label'];
			$format_type = isset( $field['format'] ) ? $field['format'] : 'number';
			
			if ( ! isset( $result['variables'][ $var_name ] ) ) {
				continue;
			}
			
			$value = $result['variables'][ $var_name ];
			
			switch ( $format_type ) {
				case 'currency':
					$currency = isset( $field['currency'] ) ? $field['currency'] : 'IDR';
					$formatted[ $var_name ] = array(
						'label' => $label,
						'value' => cf7invplus_format_currency( $value, $currency ),
						'raw'   => $value,
					);
					break;
					
				case 'percentage':
					$formatted[ $var_name ] = array(
						'label' => $label,
						'value' => number_format( $value, 2 ) . '%',
						'raw'   => $value,
					);
					break;
					
				case 'number':
				default:
					$decimals = isset( $field['decimals'] ) ? $field['decimals'] : 2;
					$formatted[ $var_name ] = array(
						'label' => $label,
						'value' => number_format( $value, $decimals ),
						'raw'   => $value,
					);
					break;
			}
		}
		
		return $formatted;
	}
	
	/**
	 * Get all calculators
	 *
	 * @param array $args
	 * @return array
	 */
	public function get_calculators( $args = array() ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7INVPLUS_CALCULATORS_TABLE;
		
		$defaults = array(
			'type'   => '',
			'status' => 'active',
		);
		
		$args = wp_parse_args( $args, $defaults );
		
		$where = '1=1';
		$where_values = array();
		
		if ( ! empty( $args['type'] ) ) {
			$where .= ' AND type = %s';
			$where_values[] = $args['type'];
		}
		
		if ( ! empty( $args['status'] ) ) {
			$where .= ' AND status = %s';
			$where_values[] = $args['status'];
		}
		
		$query = "SELECT * FROM {$table_name} WHERE {$where} ORDER BY name ASC";
		
		if ( ! empty( $where_values ) ) {
			$calculators = $wpdb->get_results(
				$wpdb->prepare( $query, $where_values ),
				ARRAY_A
			);
		} else {
			$calculators = $wpdb->get_results( $query, ARRAY_A );
		}
		
		// Decode JSON fields
		foreach ( $calculators as &$calculator ) {
			$calculator['fields'] = json_decode( $calculator['fields'], true );
			$calculator['formula'] = json_decode( $calculator['formula'], true );
			$calculator['output_format'] = json_decode( $calculator['output_format'], true );
		}
		
		return $calculators;
	}
}
