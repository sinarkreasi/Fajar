<?php

namespace CF7InvPlus\Core;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Email service class
 */
class EmailService {
	
	/**
	 * Send invoice email
	 *
	 * @param int $invoice_id
	 * @param string $type
	 * @return bool
	 */
	public function send_invoice_email( $invoice_id, $type = 'sent' ) {
		$invoice_manager = InvoiceManager::instance();
		$invoice = $invoice_manager->get_invoice( $invoice_id );
		
		if ( ! $invoice ) {
			return false;
		}
		
		$to = $invoice['client_email'];
		
		switch ( $type ) {
			case 'sent':
				$subject = sprintf( __( 'Invoice %s from %s', CF7INVPLUS_TEXT_DOMAIN ), $invoice['invoice_number'], get_bloginfo( 'name' ) );
				$message = $this->get_invoice_sent_template( $invoice );
				break;
				
			case 'reminder':
				$subject = sprintf( __( 'Payment Reminder: Invoice %s', CF7INVPLUS_TEXT_DOMAIN ), $invoice['invoice_number'] );
				$message = $this->get_invoice_reminder_template( $invoice );
				break;
				
			case 'paid':
				$subject = sprintf( __( 'Payment Confirmation: Invoice %s', CF7INVPLUS_TEXT_DOMAIN ), $invoice['invoice_number'] );
				$message = $this->get_payment_confirmation_template( $invoice );
				break;
				
			default:
				return false;
		}
		
		$headers = array(
			'Content-Type: text/html; charset=UTF-8',
			'From: ' . OptionsManager::get( 'email_from_name', get_bloginfo( 'name' ) ) . ' <' . OptionsManager::get( 'email_from_email', get_bloginfo( 'admin_email' ) ) . '>',
		);
		
		$sent = wp_mail( $to, $subject, $message, $headers );
		
		if ( $sent ) {
			cf7invplus_log( "Email sent to {$to} for invoice {$invoice_id} (type: {$type})" );
		} else {
			cf7invplus_log( "Failed to send email to {$to} for invoice {$invoice_id} (type: {$type})", 'error' );
		}
		
		return $sent;
	}
	
	/**
	 * Get invoice sent email template
	 *
	 * @param array $invoice
	 * @return string
	 */
	private function get_invoice_sent_template( $invoice ) {
		$magic_link = isset( $invoice['metadata']['magic_link'] ) ? $invoice['metadata']['magic_link'] : '';
		
		ob_start();
		?>
		<!DOCTYPE html>
		<html>
		<head>
			<meta charset="UTF-8">
			<style>
				body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
				.container { max-width: 600px; margin: 0 auto; padding: 20px; }
				.header { background: #0073aa; color: white; padding: 20px; text-align: center; }
				.content { padding: 20px; background: #f9f9f9; }
				.button { display: inline-block; padding: 12px 24px; background: #0073aa; color: white; text-decoration: none; border-radius: 4px; margin: 20px 0; }
				.footer { padding: 20px; text-align: center; font-size: 12px; color: #666; }
			</style>
		</head>
		<body>
			<div class="container">
				<div class="header">
					<h1><?php echo esc_html( get_bloginfo( 'name' ) ); ?></h1>
				</div>
				<div class="content">
					<p><?php printf( __( 'Dear %s,', CF7INVPLUS_TEXT_DOMAIN ), esc_html( $invoice['client_name'] ) ); ?></p>
					
					<p><?php _e( 'Thank you for your business. Please find your invoice details below:', CF7INVPLUS_TEXT_DOMAIN ); ?></p>
					
					<table style="width: 100%; margin: 20px 0;">
						<tr>
							<td><strong><?php _e( 'Invoice Number:', CF7INVPLUS_TEXT_DOMAIN ); ?></strong></td>
							<td><?php echo esc_html( $invoice['invoice_number'] ); ?></td>
						</tr>
						<tr>
							<td><strong><?php _e( 'Issue Date:', CF7INVPLUS_TEXT_DOMAIN ); ?></strong></td>
							<td><?php echo esc_html( $invoice['issue_date'] ); ?></td>
						</tr>
						<tr>
							<td><strong><?php _e( 'Due Date:', CF7INVPLUS_TEXT_DOMAIN ); ?></strong></td>
							<td><?php echo esc_html( $invoice['due_date'] ); ?></td>
						</tr>
						<tr>
							<td><strong><?php _e( 'Total Amount:', CF7INVPLUS_TEXT_DOMAIN ); ?></strong></td>
							<td><strong><?php echo cf7invplus_format_currency( $invoice['grand_total'], $invoice['currency'] ); ?></strong></td>
						</tr>
					</table>
					
					<?php if ( $magic_link ) : ?>
						<p style="text-align: center;">
							<a href="<?php echo esc_url( $magic_link ); ?>" class="button">
								<?php _e( 'View Invoice & Pay', CF7INVPLUS_TEXT_DOMAIN ); ?>
							</a>
						</p>
					<?php endif; ?>
					
					<p><?php _e( 'If you have any questions, please don\'t hesitate to contact us.', CF7INVPLUS_TEXT_DOMAIN ); ?></p>
				</div>
				<div class="footer">
					<p>&copy; <?php echo date( 'Y' ); ?> <?php echo esc_html( get_bloginfo( 'name' ) ); ?></p>
				</div>
			</div>
		</body>
		</html>
		<?php
		return ob_get_clean();
	}
	
	/**
	 * Get invoice reminder email template
	 *
	 * @param array $invoice
	 * @return string
	 */
	private function get_invoice_reminder_template( $invoice ) {
		$magic_link = isset( $invoice['metadata']['magic_link'] ) ? $invoice['metadata']['magic_link'] : '';
		
		ob_start();
		?>
		<!DOCTYPE html>
		<html>
		<head>
			<meta charset="UTF-8">
			<style>
				body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
				.container { max-width: 600px; margin: 0 auto; padding: 20px; }
				.header { background: #d63638; color: white; padding: 20px; text-align: center; }
				.content { padding: 20px; background: #f9f9f9; }
				.button { display: inline-block; padding: 12px 24px; background: #d63638; color: white; text-decoration: none; border-radius: 4px; margin: 20px 0; }
				.footer { padding: 20px; text-align: center; font-size: 12px; color: #666; }
			</style>
		</head>
		<body>
			<div class="container">
				<div class="header">
					<h1><?php _e( 'Payment Reminder', CF7INVPLUS_TEXT_DOMAIN ); ?></h1>
				</div>
				<div class="content">
					<p><?php printf( __( 'Dear %s,', CF7INVPLUS_TEXT_DOMAIN ), esc_html( $invoice['client_name'] ) ); ?></p>
					
					<p><?php _e( 'This is a friendly reminder that the following invoice is awaiting payment:', CF7INVPLUS_TEXT_DOMAIN ); ?></p>
					
					<table style="width: 100%; margin: 20px 0;">
						<tr>
							<td><strong><?php _e( 'Invoice Number:', CF7INVPLUS_TEXT_DOMAIN ); ?></strong></td>
							<td><?php echo esc_html( $invoice['invoice_number'] ); ?></td>
						</tr>
						<tr>
							<td><strong><?php _e( 'Due Date:', CF7INVPLUS_TEXT_DOMAIN ); ?></strong></td>
							<td><?php echo esc_html( $invoice['due_date'] ); ?></td>
						</tr>
						<tr>
							<td><strong><?php _e( 'Amount Due:', CF7INVPLUS_TEXT_DOMAIN ); ?></strong></td>
							<td><strong><?php echo cf7invplus_format_currency( $invoice['grand_total'], $invoice['currency'] ); ?></strong></td>
						</tr>
					</table>
					
					<?php if ( $magic_link ) : ?>
						<p style="text-align: center;">
							<a href="<?php echo esc_url( $magic_link ); ?>" class="button">
								<?php _e( 'Pay Now', CF7INVPLUS_TEXT_DOMAIN ); ?>
							</a>
						</p>
					<?php endif; ?>
				</div>
				<div class="footer">
					<p>&copy; <?php echo date( 'Y' ); ?> <?php echo esc_html( get_bloginfo( 'name' ) ); ?></p>
				</div>
			</div>
		</body>
		</html>
		<?php
		return ob_get_clean();
	}
	
	/**
	 * Get payment confirmation email template
	 *
	 * @param array $invoice
	 * @return string
	 */
	private function get_payment_confirmation_template( $invoice ) {
		// Get licenses if any
		$license_integration = \CF7InvPlus\Integrations\LicenseIntegration::instance();
		$licenses = $license_integration->get_invoice_licenses( $invoice['id'] );
		
		ob_start();
		?>
		<!DOCTYPE html>
		<html>
		<head>
			<meta charset="UTF-8">
			<style>
				body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
				.container { max-width: 600px; margin: 0 auto; padding: 20px; }
				.header { background: #46b450; color: white; padding: 20px; text-align: center; }
				.content { padding: 20px; background: #f9f9f9; }
				.license-box { background: white; border: 2px solid #46b450; padding: 15px; margin: 10px 0; border-radius: 4px; }
				.footer { padding: 20px; text-align: center; font-size: 12px; color: #666; }
			</style>
		</head>
		<body>
			<div class="container">
				<div class="header">
					<h1><?php _e( 'Payment Received!', CF7INVPLUS_TEXT_DOMAIN ); ?></h1>
				</div>
				<div class="content">
					<p><?php printf( __( 'Dear %s,', CF7INVPLUS_TEXT_DOMAIN ), esc_html( $invoice['client_name'] ) ); ?></p>
					
					<p><?php _e( 'Thank you! We have received your payment for the following invoice:', CF7INVPLUS_TEXT_DOMAIN ); ?></p>
					
					<table style="width: 100%; margin: 20px 0;">
						<tr>
							<td><strong><?php _e( 'Invoice Number:', CF7INVPLUS_TEXT_DOMAIN ); ?></strong></td>
							<td><?php echo esc_html( $invoice['invoice_number'] ); ?></td>
						</tr>
						<tr>
							<td><strong><?php _e( 'Amount Paid:', CF7INVPLUS_TEXT_DOMAIN ); ?></strong></td>
							<td><strong><?php echo cf7invplus_format_currency( $invoice['grand_total'], $invoice['currency'] ); ?></strong></td>
						</tr>
					</table>
					
					<?php if ( ! empty( $licenses ) ) : ?>
						<h3><?php _e( 'Your License Keys:', CF7INVPLUS_TEXT_DOMAIN ); ?></h3>
						<?php foreach ( $licenses as $license ) : ?>
							<div class="license-box">
								<p><strong><?php echo esc_html( $license['item_name'] ); ?></strong></p>
								<p style="font-family: monospace; font-size: 14px; background: #f0f0f0; padding: 10px; border-radius: 3px;">
									<?php echo esc_html( $license['license_key'] ); ?>
								</p>
							</div>
						<?php endforeach; ?>
					<?php endif; ?>
					
					<p><?php _e( 'Thank you for your business!', CF7INVPLUS_TEXT_DOMAIN ); ?></p>
				</div>
				<div class="footer">
					<p>&copy; <?php echo date( 'Y' ); ?> <?php echo esc_html( get_bloginfo( 'name' ) ); ?></p>
				</div>
			</div>
		</body>
		</html>
		<?php
		return ob_get_clean();
	}
}
