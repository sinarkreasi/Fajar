<?php

namespace CF7InvPlus\Core;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Invoice manager class
 */
class InvoiceManager {
	
	/**
	 * Instance
	 */
	private static $instance = null;
	
	/**
	 * Get instance
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		// Constructor intentionally left empty
	}
	
	/**
	 * Create new invoice
	 *
	 * @param array $invoice_data
	 * @return int|false Invoice ID or false on failure
	 */
	public function create_invoice( $invoice_data ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7INVPLUS_INVOICES_TABLE;
		
		// Generate invoice number if not provided
		if ( empty( $invoice_data['invoice_number'] ) ) {
			$invoice_data['invoice_number'] = cf7invplus_generate_invoice_number();
		}
		
		// Set defaults
		$defaults = array(
			'invoice_number'     => '',
			'status'             => 'draft',
			'issue_date'         => current_time( 'Y-m-d' ),
			'due_date'           => date( 'Y-m-d', strtotime( '+' . OptionsManager::get( 'default_due_days', 30 ) . ' days' ) ),
			'currency'           => OptionsManager::get( 'default_currency', 'IDR' ),
			'subtotal'           => 0,
			'tax_total'          => 0,
			'discount_total'     => 0,
			'grand_total'        => 0,
			'client_name'        => '',
			'client_email'       => '',
			'client_company'     => '',
			'client_address'     => '',
			'source'             => 'manual',
			'source_id'          => null,
			'cf7_submission_id'  => null,
			'mc_order_id'        => null,
			'metadata'           => null,
			'created_at'         => current_time( 'mysql' ),
		);
		
		$invoice_data = wp_parse_args( $invoice_data, $defaults );
		
		// Sanitize data
		$invoice_data['invoice_number'] = sanitize_text_field( $invoice_data['invoice_number'] );
		$invoice_data['status'] = cf7invplus_sanitize_invoice_status( $invoice_data['status'] );
		$invoice_data['currency'] = sanitize_text_field( $invoice_data['currency'] );
		$invoice_data['client_name'] = sanitize_text_field( $invoice_data['client_name'] );
		$invoice_data['client_email'] = sanitize_email( $invoice_data['client_email'] );
		$invoice_data['client_company'] = sanitize_text_field( $invoice_data['client_company'] );
		$invoice_data['client_address'] = sanitize_textarea_field( $invoice_data['client_address'] );
		$invoice_data['source'] = sanitize_text_field( $invoice_data['source'] );
		
		// Ensure metadata is JSON
		if ( is_array( $invoice_data['metadata'] ) ) {
			$invoice_data['metadata'] = wp_json_encode( $invoice_data['metadata'] );
		}
		
		$result = $wpdb->insert(
			$table_name,
			$invoice_data,
			array(
				'%s', // invoice_number
				'%s', // status
				'%s', // issue_date
				'%s', // due_date
				'%s', // currency
				'%f', // subtotal
				'%f', // tax_total
				'%f', // discount_total
				'%f', // grand_total
				'%s', // client_name
				'%s', // client_email
				'%s', // client_company
				'%s', // client_address
				'%s', // source
				'%d', // source_id
				'%d', // cf7_submission_id
				'%d', // mc_order_id
				'%s', // metadata
				'%s', // created_at
			)
		);
		
		if ( $result === false ) {
			cf7invplus_log( 'Failed to create invoice: ' . $wpdb->last_error, 'error' );
			return false;
		}
		
		$invoice_id = $wpdb->insert_id;
		
		cf7invplus_log( "Invoice created: ID {$invoice_id}, Number {$invoice_data['invoice_number']}" );
		
		do_action( 'cf7invplus_invoice_created', $invoice_id, $invoice_data );
		
		return $invoice_id;
	}
	
	/**
	 * Get invoice by ID
	 *
	 * @param int $invoice_id
	 * @return array|null
	 */
	public function get_invoice( $invoice_id ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7INVPLUS_INVOICES_TABLE;
		
		$invoice = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table_name} WHERE id = %d", $invoice_id ),
			ARRAY_A
		);
		
		if ( $invoice && ! empty( $invoice['metadata'] ) ) {
			$invoice['metadata'] = json_decode( $invoice['metadata'], true );
		}
		
		return $invoice;
	}
	
	/**
	 * Get invoice by invoice number
	 *
	 * @param string $invoice_number
	 * @return array|null
	 */
	public function get_invoice_by_number( $invoice_number ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7INVPLUS_INVOICES_TABLE;
		
		$invoice = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table_name} WHERE invoice_number = %s", $invoice_number ),
			ARRAY_A
		);
		
		if ( $invoice && ! empty( $invoice['metadata'] ) ) {
			$invoice['metadata'] = json_decode( $invoice['metadata'], true );
		}
		
		return $invoice;
	}
	
	/**
	 * Update invoice
	 *
	 * @param int $invoice_id
	 * @param array $data
	 * @return bool
	 */
	public function update_invoice( $invoice_id, $data ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7INVPLUS_INVOICES_TABLE;
		
		// Add updated timestamp
		$data['updated_at'] = current_time( 'mysql' );
		
		// Sanitize metadata
		if ( isset( $data['metadata'] ) && is_array( $data['metadata'] ) ) {
			$data['metadata'] = wp_json_encode( $data['metadata'] );
		}
		
		// Build format array dynamically
		$format = array();
		foreach ( $data as $key => $value ) {
			if ( in_array( $key, array( 'subtotal', 'tax_total', 'discount_total', 'grand_total' ) ) ) {
				$format[] = '%f';
			} elseif ( in_array( $key, array( 'source_id', 'cf7_submission_id', 'mc_order_id' ) ) ) {
				$format[] = '%d';
			} else {
				$format[] = '%s';
			}
		}
		
		$result = $wpdb->update(
			$table_name,
			$data,
			array( 'id' => $invoice_id ),
			$format,
			array( '%d' )
		);
		
		if ( $result !== false ) {
			do_action( 'cf7invplus_invoice_updated', $invoice_id, $data );
			return true;
		}
		
		return false;
	}
	
	/**
	 * Update invoice status
	 *
	 * @param int $invoice_id
	 * @param string $new_status
	 * @return bool
	 */
	public function update_invoice_status( $invoice_id, $new_status ) {
		$invoice = $this->get_invoice( $invoice_id );
		
		if ( ! $invoice ) {
			cf7invplus_log( "Invoice not found: $invoice_id", 'error' );
			return false;
		}
		
		$old_status = $invoice['status'];
		
		// Validate status transition
		if ( ! cf7invplus_is_valid_status_transition( $old_status, $new_status ) ) {
			cf7invplus_log( "Invalid status transition from $old_status to $new_status for invoice $invoice_id", 'error' );
			return false;
		}
		
		$result = $this->update_invoice( $invoice_id, array( 'status' => $new_status ) );
		
		if ( $result ) {
			cf7invplus_log( "Invoice {$invoice_id} status updated: {$old_status} → {$new_status}" );
			do_action( 'cf7invplus_invoice_status_changed', $invoice_id, $new_status, $old_status );
			
			// Fire specific status hooks
			switch ( $new_status ) {
				case 'sent':
					do_action( 'cf7invplus_invoice_sent', $invoice_id, $invoice );
					break;
				case 'paid':
					do_action( 'cf7invplus_invoice_paid', $invoice_id, $invoice );
					break;
				case 'overdue':
					do_action( 'cf7invplus_invoice_overdue', $invoice_id, $invoice );
					break;
			}
		}
		
		return $result;
	}
	
	/**
	 * Calculate invoice totals
	 *
	 * @param int $invoice_id
	 * @return bool
	 */
	public function calculate_totals( $invoice_id ) {
		$items = $this->get_invoice_items( $invoice_id );
		
		$subtotal = 0;
		$tax_total = 0;
		$discount_total = 0;
		
		foreach ( $items as $item ) {
			$subtotal += floatval( $item['subtotal'] );
			$tax_total += floatval( $item['tax'] );
			$discount_total += floatval( $item['discount'] );
		}
		
		$grand_total = $subtotal + $tax_total - $discount_total;
		
		return $this->update_invoice( $invoice_id, array(
			'subtotal'       => $subtotal,
			'tax_total'      => $tax_total,
			'discount_total' => $discount_total,
			'grand_total'    => $grand_total,
		) );
	}
	
	/**
	 * Get invoice items
	 *
	 * @param int $invoice_id
	 * @return array
	 */
	public function get_invoice_items( $invoice_id ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7INVPLUS_INVOICE_ITEMS_TABLE;
		
		$items = $wpdb->get_results(
			$wpdb->prepare( 
				"SELECT * FROM {$table_name} WHERE invoice_id = %d ORDER BY sort_order ASC, id ASC", 
				$invoice_id 
			),
			ARRAY_A
		);
		
		return $items ?: array();
	}
	
	/**
	 * Add invoice item
	 *
	 * @param int $invoice_id
	 * @param array $item_data
	 * @return int|false Item ID or false on failure
	 */
	public function add_invoice_item( $invoice_id, $item_data ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7INVPLUS_INVOICE_ITEMS_TABLE;
		
		$defaults = array(
			'invoice_id'          => $invoice_id,
			'name'                => '',
			'description'         => '',
			'qty'                 => 1,
			'unit_price'          => 0,
			'subtotal'            => 0,
			'tax'                 => 0,
			'discount'            => 0,
			'is_licensed_product' => 0,
			'license_id'          => null,
			'product_id'          => null,
			'sort_order'          => 0,
			'created_at'          => current_time( 'mysql' ),
		);
		
		$item_data = wp_parse_args( $item_data, $defaults );
		
		// Calculate subtotal if not provided
		if ( $item_data['subtotal'] == 0 ) {
			$item_data['subtotal'] = $item_data['qty'] * $item_data['unit_price'];
		}
		
		$result = $wpdb->insert(
			$table_name,
			$item_data,
			array(
				'%d', // invoice_id
				'%s', // name
				'%s', // description
				'%f', // qty
				'%f', // unit_price
				'%f', // subtotal
				'%f', // tax
				'%f', // discount
				'%d', // is_licensed_product
				'%d', // license_id
				'%s', // product_id
				'%d', // sort_order
				'%s', // created_at
			)
		);
		
		if ( $result === false ) {
			cf7invplus_log( 'Failed to add invoice item: ' . $wpdb->last_error, 'error' );
			return false;
		}
		
		$item_id = $wpdb->insert_id;
		
		// Recalculate invoice totals
		$this->calculate_totals( $invoice_id );
		
		do_action( 'cf7invplus_invoice_item_added', $item_id, $invoice_id, $item_data );
		
		return $item_id;
	}
	
	/**
	 * Update invoice item
	 *
	 * @param int $item_id
	 * @param array $data
	 * @return bool
	 */
	public function update_invoice_item( $item_id, $data ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7INVPLUS_INVOICE_ITEMS_TABLE;
		
		// Get current item to get invoice_id
		$item = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table_name} WHERE id = %d", $item_id ),
			ARRAY_A
		);
		
		if ( ! $item ) {
			return false;
		}
		
		// Recalculate subtotal if qty or unit_price changed
		if ( isset( $data['qty'] ) || isset( $data['unit_price'] ) ) {
			$qty = isset( $data['qty'] ) ? $data['qty'] : $item['qty'];
			$unit_price = isset( $data['unit_price'] ) ? $data['unit_price'] : $item['unit_price'];
			$data['subtotal'] = $qty * $unit_price;
		}
		
		$result = $wpdb->update(
			$table_name,
			$data,
			array( 'id' => $item_id ),
			null,
			array( '%d' )
		);
		
		if ( $result !== false ) {
			// Recalculate invoice totals
			$this->calculate_totals( $item['invoice_id'] );
			
			do_action( 'cf7invplus_invoice_item_updated', $item_id, $item['invoice_id'], $data );
			return true;
		}
		
		return false;
	}
	
	/**
	 * Delete invoice item
	 *
	 * @param int $item_id
	 * @return bool
	 */
	public function delete_invoice_item( $item_id ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7INVPLUS_INVOICE_ITEMS_TABLE;
		
		// Get item to get invoice_id
		$item = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table_name} WHERE id = %d", $item_id ),
			ARRAY_A
		);
		
		if ( ! $item ) {
			return false;
		}
		
		$result = $wpdb->delete(
			$table_name,
			array( 'id' => $item_id ),
			array( '%d' )
		);
		
		if ( $result !== false ) {
			// Recalculate invoice totals
			$this->calculate_totals( $item['invoice_id'] );
			
			do_action( 'cf7invplus_invoice_item_deleted', $item_id, $item['invoice_id'] );
			return true;
		}
		
		return false;
	}
	
	/**
	 * Get invoices with pagination
	 *
	 * @param array $args
	 * @return array
	 */
	public function get_invoices( $args = array() ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7INVPLUS_INVOICES_TABLE;
		
		$defaults = array(
			'status'   => '',
			'search'   => '',
			'per_page' => 20,
			'page'     => 1,
			'orderby'  => 'created_at',
			'order'    => 'DESC',
		);
		
		$args = wp_parse_args( $args, $defaults );
		
		// Sanitize orderby and order
		$allowed_orderby = array( 'id', 'invoice_number', 'client_name', 'client_email', 'grand_total', 'status', 'created_at', 'issue_date', 'due_date' );
		$orderby = in_array( $args['orderby'], $allowed_orderby ) ? $args['orderby'] : 'created_at';
		$order = strtoupper( $args['order'] ) === 'ASC' ? 'ASC' : 'DESC';
		
		$where = '1=1';
		$where_values = array();
		
		if ( ! empty( $args['status'] ) ) {
			$where .= ' AND status = %s';
			$where_values[] = $args['status'];
		}
		
		if ( ! empty( $args['search'] ) ) {
			$where .= ' AND (invoice_number LIKE %s OR client_name LIKE %s OR client_email LIKE %s)';
			$search_term = '%' . $wpdb->esc_like( $args['search'] ) . '%';
			$where_values[] = $search_term;
			$where_values[] = $search_term;
			$where_values[] = $search_term;
		}
		
		$offset = ( $args['page'] - 1 ) * $args['per_page'];
		
		$query = "SELECT * FROM {$table_name} WHERE {$where} ORDER BY {$orderby} {$order} LIMIT %d OFFSET %d";
		$where_values[] = $args['per_page'];
		$where_values[] = $offset;
		
		$invoices = $wpdb->get_results(
			$wpdb->prepare( $query, $where_values ),
			ARRAY_A
		);
		
		// Decode metadata for each invoice
		foreach ( $invoices as &$invoice ) {
			if ( ! empty( $invoice['metadata'] ) ) {
				$invoice['metadata'] = json_decode( $invoice['metadata'], true );
			}
		}
		
		// Get total count
		$count_query = "SELECT COUNT(*) FROM {$table_name} WHERE {$where}";
		$count_values = array_slice( $where_values, 0, -2 );
		
		if ( ! empty( $count_values ) ) {
			$total = $wpdb->get_var(
				$wpdb->prepare( $count_query, $count_values )
			);
		} else {
			$total = $wpdb->get_var( $count_query );
		}
		
		return array(
			'invoices' => $invoices,
			'total'    => $total,
		);
	}
}
