<?php

namespace CF7InvPlus\Core;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Options manager class
 */
class OptionsManager {
	
	/**
	 * Set default options
	 */
	public static function set_defaults() {
		$defaults = array(
			'invoice_number_prefix' => 'INV',
			'invoice_number_format' => 'YEAR-SEQUENCE',
			'default_currency'      => 'IDR',
			'default_tax_rate'      => 0,
			'default_due_days'      => 30,
			'enable_logging'        => false,
			'email_from_name'       => get_bloginfo( 'name' ),
			'email_from_email'      => get_bloginfo( 'admin_email' ),
		);
		
		$existing = get_option( 'cf7invplus_settings', array() );
		$settings = wp_parse_args( $existing, $defaults );
		
		update_option( 'cf7invplus_settings', $settings );
	}
	
	/**
	 * Get option
	 *
	 * @param string $key
	 * @param mixed $default
	 * @return mixed
	 */
	public static function get( $key, $default = null ) {
		return cf7invplus_get_option( $key, $default );
	}
	
	/**
	 * Update option
	 *
	 * @param string $key
	 * @param mixed $value
	 * @return bool
	 */
	public static function update( $key, $value ) {
		return cf7invplus_update_option( $key, $value );
	}
}
