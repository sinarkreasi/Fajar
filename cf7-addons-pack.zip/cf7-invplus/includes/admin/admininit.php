<?php

namespace CF7InvPlus\Admin;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin initialization class
 */
class AdminInit {
	
	/**
	 * Instance
	 */
	private static $instance = null;
	
	/**
	 * Get instance
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		$this->init_hooks();
	}
	
	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
	}
	
	/**
	 * Add admin menu
	 */
	public function add_admin_menu() {
		add_menu_page(
			__( 'CF7 InvPlus', CF7INVPLUS_TEXT_DOMAIN ),
			__( 'InvPlus', CF7INVPLUS_TEXT_DOMAIN ),
			'manage_options',
			'cf7invplus',
			array( $this, 'render_invoices_page' ),
			'dashicons-media-spreadsheet',
			30
		);
		
		add_submenu_page(
			'cf7invplus',
			__( 'Invoices', CF7INVPLUS_TEXT_DOMAIN ),
			__( 'Invoices', CF7INVPLUS_TEXT_DOMAIN ),
			'manage_options',
			'cf7invplus',
			array( $this, 'render_invoices_page' )
		);
		
		add_submenu_page(
			'cf7invplus',
			__( 'Calculators', CF7INVPLUS_TEXT_DOMAIN ),
			__( 'Calculators', CF7INVPLUS_TEXT_DOMAIN ),
			'manage_options',
			'cf7invplus-calculators',
			array( $this, 'render_calculators_page' )
		);
		
		add_submenu_page(
			'cf7invplus',
			__( 'Settings', CF7INVPLUS_TEXT_DOMAIN ),
			__( 'Settings', CF7INVPLUS_TEXT_DOMAIN ),
			'manage_options',
			'cf7invplus-settings',
			array( $this, 'render_settings_page' )
		);
	}
	
	/**
	 * Render invoices page
	 */
	public function render_invoices_page() {
		$invoice_manager = \CF7InvPlus\Core\InvoiceManager::instance();
		
		// Handle save invoice
		if ( isset( $_POST['cf7invplus_save_invoice'] ) ) {
			check_admin_referer( 'cf7invplus_save_invoice' );
			
			// Create invoice
			$invoice_data = array(
				'client_name'    => sanitize_text_field( $_POST['client_name'] ),
				'client_email'   => sanitize_email( $_POST['client_email'] ),
				'client_company' => sanitize_text_field( $_POST['client_company'] ),
				'client_address' => sanitize_textarea_field( $_POST['client_address'] ),
				'status'         => sanitize_text_field( $_POST['status'] ),
			);
			
			$invoice_id = $invoice_manager->create_invoice( $invoice_data );
			
			if ( $invoice_id ) {
				// Add items
				if ( isset( $_POST['items'] ) && is_array( $_POST['items'] ) ) {
					foreach ( $_POST['items'] as $item ) {
						$invoice_manager->add_invoice_item( $invoice_id, array(
							'name'        => sanitize_text_field( $item['name'] ),
							'description' => sanitize_text_field( $item['description'] ),
							'qty'         => floatval( $item['qty'] ),
							'unit_price'  => floatval( $item['unit_price'] ),
						) );
					}
				}
				
				echo '<div class="notice notice-success"><p>' . __( 'Invoice created successfully!', CF7INVPLUS_TEXT_DOMAIN ) . '</p></div>';
			} else {
				echo '<div class="notice notice-error"><p>' . __( 'Failed to create invoice.', CF7INVPLUS_TEXT_DOMAIN ) . '</p></div>';
			}
		}
		
		// Handle actions
		if ( isset( $_GET['action'] ) ) {
			if ( $_GET['action'] === 'new' ) {
				include CF7INVPLUS_PLUGIN_DIR . '/templates/admin/invoice-new.php';
				return;
			}
			
			if ( isset( $_GET['invoice_id'] ) ) {
				check_admin_referer( 'cf7invplus_action' );
				
				$invoice_id = intval( $_GET['invoice_id'] );
				
				switch ( $_GET['action'] ) {
					case 'view':
						include CF7INVPLUS_PLUGIN_DIR . '/templates/admin/invoice-detail.php';
						return;
						
					case 'send':
						$invoice_manager->update_invoice_status( $invoice_id, 'sent' );
						wp_redirect( admin_url( 'admin.php?page=cf7invplus&action=view&invoice_id=' . $invoice_id . '&_wpnonce=' . wp_create_nonce( 'cf7invplus_action' ) ) );
						exit;
						
					case 'mark_paid':
						$invoice_manager->update_invoice_status( $invoice_id, 'paid' );
						wp_redirect( admin_url( 'admin.php?page=cf7invplus&action=view&invoice_id=' . $invoice_id . '&_wpnonce=' . wp_create_nonce( 'cf7invplus_action' ) ) );
						exit;
						
					case 'generate_link':
					case 'regenerate_link':
						$magic_link_integration = \CF7InvPlus\Integrations\MagicLinkIntegration::instance();
						if ( $_GET['action'] === 'regenerate_link' ) {
							$magic_link_integration->regenerate_magic_link( $invoice_id );
						} else {
							$invoice = $invoice_manager->get_invoice( $invoice_id );
							$magic_link_integration->generate_magic_link( $invoice_id, $invoice );
						}
						wp_redirect( admin_url( 'admin.php?page=cf7invplus&action=view&invoice_id=' . $invoice_id . '&_wpnonce=' . wp_create_nonce( 'cf7invplus_action' ) ) );
						exit;
				}
			}
		}
		
		// List invoices
		$page = isset( $_GET['paged'] ) ? max( 1, intval( $_GET['paged'] ) ) : 1;
		$status = isset( $_GET['status'] ) ? sanitize_text_field( $_GET['status'] ) : '';
		
		$result = $invoice_manager->get_invoices( array(
			'status'   => $status,
			'page'     => $page,
			'per_page' => 20,
		) );
		
		$invoices = $result['invoices'];
		$total = $result['total'];
		
		include CF7INVPLUS_PLUGIN_DIR . '/templates/admin/invoices-list.php';
	}
	
	/**
	 * Render calculators page
	 */
	public function render_calculators_page() {
		$calculator_builder = \CF7InvPlus\Core\CalculatorBuilder::instance();
		$calculators = $calculator_builder->get_calculators();
		
		include CF7INVPLUS_PLUGIN_DIR . '/templates/admin/calculators-list.php';
	}
	
	/**
	 * Render settings page
	 */
	public function render_settings_page() {
		// Handle settings save
		if ( isset( $_POST['cf7invplus_save_settings'] ) ) {
			check_admin_referer( 'cf7invplus_settings' );
			
			$settings = array(
				'invoice_number_prefix' => sanitize_text_field( $_POST['invoice_number_prefix'] ),
				'invoice_number_format' => sanitize_text_field( $_POST['invoice_number_format'] ),
				'default_currency'      => sanitize_text_field( $_POST['default_currency'] ),
				'default_tax_rate'      => floatval( $_POST['default_tax_rate'] ),
				'default_due_days'      => intval( $_POST['default_due_days'] ),
				'enable_logging'        => isset( $_POST['enable_logging'] ),
			);
			
			update_option( 'cf7invplus_settings', $settings );
			
			echo '<div class="notice notice-success"><p>' . __( 'Settings saved successfully.', CF7INVPLUS_TEXT_DOMAIN ) . '</p></div>';
		}
		
		$settings = get_option( 'cf7invplus_settings', array() );
		
		include CF7INVPLUS_PLUGIN_DIR . '/templates/admin/settings.php';
	}
}
