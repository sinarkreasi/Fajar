<?php

namespace CF7InvPlus\Integrations;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Contact Form 7 integration
 */
class CF7Listener {
	
	/**
	 * Instance
	 */
	private static $instance = null;
	
	/**
	 * Get instance
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		$this->init_hooks();
	}
	
	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		// Hook into CF7 submission
		add_action( 'wpcf7_mail_sent', array( $this, 'handle_submission' ) );
	}
	
	/**
	 * Handle CF7 form submission
	 *
	 * @param object $contact_form
	 */
	public function handle_submission( $contact_form ) {
		$submission = \WPCF7_Submission::get_instance();
		
		if ( ! $submission ) {
			return;
		}
		
		$form_id = $contact_form->id();
		
		// Check if this form has invoice creation enabled
		$invoice_settings = get_post_meta( $form_id, '_cf7invplus_settings', true );
		
		if ( empty( $invoice_settings['enable_invoice'] ) ) {
			return;
		}
		
		$posted_data = $submission->get_posted_data();
		
		// Map CF7 fields to invoice fields
		$field_mapping = isset( $invoice_settings['field_mapping'] ) ? $invoice_settings['field_mapping'] : array();
		
		$invoice_data = array(
			'source'            => 'cf7',
			'source_id'         => $form_id,
			'cf7_submission_id' => time(), // CF7 doesn't have submission IDs by default
			'client_name'       => $this->get_mapped_value( $posted_data, $field_mapping, 'client_name' ),
			'client_email'      => $this->get_mapped_value( $posted_data, $field_mapping, 'client_email' ),
			'client_company'    => $this->get_mapped_value( $posted_data, $field_mapping, 'client_company' ),
			'client_address'    => $this->get_mapped_value( $posted_data, $field_mapping, 'client_address' ),
			'status'            => isset( $invoice_settings['initial_status'] ) ? $invoice_settings['initial_status'] : 'draft',
		);
		
		// Create invoice
		$invoice_manager = \CF7InvPlus\Core\InvoiceManager::instance();
		$invoice_id = $invoice_manager->create_invoice( $invoice_data );
		
		if ( ! $invoice_id ) {
			cf7invplus_log( "Failed to create invoice from CF7 form {$form_id}", 'error' );
			return;
		}
		
		// Add invoice items
		if ( isset( $invoice_settings['items'] ) && is_array( $invoice_settings['items'] ) ) {
			foreach ( $invoice_settings['items'] as $item_config ) {
				$item_data = array(
					'name'        => $item_config['name'],
					'description' => isset( $item_config['description'] ) ? $item_config['description'] : '',
					'qty'         => $this->get_mapped_value( $posted_data, $field_mapping, 'qty_' . $item_config['id'], 1 ),
					'unit_price'  => $this->get_mapped_value( $posted_data, $field_mapping, 'price_' . $item_config['id'], $item_config['price'] ),
				);
				
				$invoice_manager->add_invoice_item( $invoice_id, $item_data );
			}
		}
		
		// Recalculate totals
		$invoice_manager->calculate_totals( $invoice_id );
		
		// Auto-send if configured
		if ( ! empty( $invoice_settings['auto_send'] ) ) {
			$invoice_manager->update_invoice_status( $invoice_id, 'sent' );
		}
		
		cf7invplus_log( "Invoice {$invoice_id} created from CF7 form {$form_id}" );
		
		do_action( 'cf7invplus_invoice_created_from_cf7', $invoice_id, $form_id, $posted_data );
	}
	
	/**
	 * Get mapped value from posted data
	 *
	 * @param array $posted_data
	 * @param array $field_mapping
	 * @param string $target_field
	 * @param mixed $default
	 * @return mixed
	 */
	private function get_mapped_value( $posted_data, $field_mapping, $target_field, $default = '' ) {
		if ( empty( $field_mapping[ $target_field ] ) ) {
			return $default;
		}
		
		$source_field = $field_mapping[ $target_field ];
		
		return isset( $posted_data[ $source_field ] ) ? $posted_data[ $source_field ] : $default;
	}
}
