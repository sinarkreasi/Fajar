<?php

namespace CF7InvPlus\Integrations;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Payment integration with CF7 MiniCommerce
 */
class PaymentIntegration {
	
	/**
	 * Instance
	 */
	private static $instance = null;
	
	/**
	 * Get instance
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		$this->init_hooks();
	}
	
	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		// Hook into CF7MC payment events
		add_action( 'ecommerce_payment_success', array( $this, 'handle_payment_success' ), 10, 2 );
		add_action( 'ecommerce_payment_failed', array( $this, 'handle_payment_failed' ), 10, 2 );
	}
	
	/**
	 * Create CF7MC order from invoice
	 *
	 * @param int $invoice_id
	 * @return int|false Order ID or false on failure
	 */
	public function create_order_from_invoice( $invoice_id ) {
		if ( ! class_exists( 'CF7MC\Core\OrderManager' ) ) {
			cf7invplus_log( 'CF7 MiniCommerce plugin not found', 'error' );
			return false;
		}
		
		$invoice_manager = \CF7InvPlus\Core\InvoiceManager::instance();
		$invoice = $invoice_manager->get_invoice( $invoice_id );
		
		if ( ! $invoice ) {
			return false;
		}
		
		// Get invoice items
		$items = $invoice_manager->get_invoice_items( $invoice_id );
		
		// Format items for CF7MC
		$mc_items = array();
		foreach ( $items as $item ) {
			$mc_items[] = array(
				'name'        => $item['name'],
				'description' => $item['description'],
				'quantity'    => $item['qty'],
				'price'       => $item['unit_price'],
				'subtotal'    => $item['subtotal'],
			);
		}
		
		// Create CF7MC order
		$order_manager = new \CF7MC\Core\OrderManager();
		
		$order_id = $order_manager->create_order( array(
			'email'         => $invoice['client_email'],
			'customer_name' => $invoice['client_name'],
			'items'         => $mc_items,
			'total_amount'  => $invoice['grand_total'],
			'gateway'       => '', // Will be set when payment is initiated
			'status'        => 'initiated',
			'metadata'      => array(
				'source'         => 'cf7invplus',
				'invoice_id'     => $invoice_id,
				'invoice_number' => $invoice['invoice_number'],
			),
		) );
		
		if ( ! $order_id ) {
			cf7invplus_log( "Failed to create CF7MC order for invoice {$invoice_id}", 'error' );
			return false;
		}
		
		// Store order ID in invoice
		$invoice_manager->update_invoice( $invoice_id, array(
			'mc_order_id' => $order_id,
		) );
		
		cf7invplus_log( "CF7MC order {$order_id} created for invoice {$invoice_id}" );
		
		return $order_id;
	}
	
	/**
	 * Handle payment success
	 *
	 * @param int $order_id
	 * @param array $order
	 */
	public function handle_payment_success( $order_id, $order ) {
		// Check if this order is from an invoice
		if ( empty( $order['metadata'] ) ) {
			return;
		}
		
		$metadata = is_string( $order['metadata'] ) ? json_decode( $order['metadata'], true ) : $order['metadata'];
		
		if ( empty( $metadata['source'] ) || $metadata['source'] !== 'cf7invplus' ) {
			return;
		}
		
		if ( empty( $metadata['invoice_id'] ) ) {
			return;
		}
		
		$invoice_id = $metadata['invoice_id'];
		
		cf7invplus_log( "Payment success for invoice {$invoice_id} via CF7MC order {$order_id}" );
		
		// Update invoice status to paid
		$invoice_manager = \CF7InvPlus\Core\InvoiceManager::instance();
		$invoice_manager->update_invoice_status( $invoice_id, 'paid' );
	}
	
	/**
	 * Handle payment failed
	 *
	 * @param int $order_id
	 * @param array $order
	 */
	public function handle_payment_failed( $order_id, $order ) {
		// Check if this order is from an invoice
		if ( empty( $order['metadata'] ) ) {
			return;
		}
		
		$metadata = is_string( $order['metadata'] ) ? json_decode( $order['metadata'], true ) : $order['metadata'];
		
		if ( empty( $metadata['source'] ) || $metadata['source'] !== 'cf7invplus' ) {
			return;
		}
		
		if ( empty( $metadata['invoice_id'] ) ) {
			return;
		}
		
		$invoice_id = $metadata['invoice_id'];
		
		cf7invplus_log( "Payment failed for invoice {$invoice_id} via CF7MC order {$order_id}", 'warning' );
		
		// Keep invoice status as unpaid or sent
		// Don't automatically mark as failed, user might retry
	}
	
	/**
	 * Get payment URL for invoice
	 *
	 * @param int $invoice_id
	 * @param string $gateway
	 * @return string|false
	 */
	public function get_payment_url( $invoice_id, $gateway = 'tripay' ) {
		$invoice_manager = \CF7InvPlus\Core\InvoiceManager::instance();
		$invoice = $invoice_manager->get_invoice( $invoice_id );
		
		if ( ! $invoice ) {
			return false;
		}
		
		// Create or get existing order
		$order_id = $invoice['mc_order_id'];
		
		if ( ! $order_id ) {
			$order_id = $this->create_order_from_invoice( $invoice_id );
		}
		
		if ( ! $order_id ) {
			return false;
		}
		
		// Create payment session
		if ( class_exists( 'CF7MC\Core\OrderManager' ) ) {
			$order_manager = new \CF7MC\Core\OrderManager();
			$session_data = $order_manager->create_payment_session( $order_id, $gateway );
			
			if ( $session_data && isset( $session_data['payment_url'] ) ) {
				return $session_data['payment_url'];
			}
		}
		
		return false;
	}
}
