<?php

namespace CF7InvPlus\Integrations;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * License integration with CF7 License
 */
class LicenseIntegration {
	
	/**
	 * Instance
	 */
	private static $instance = null;
	
	/**
	 * Get instance
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		$this->init_hooks();
	}
	
	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		// Hook into invoice paid event
		add_action( 'cf7invplus_invoice_paid', array( $this, 'generate_licenses' ), 10, 2 );
	}
	
	/**
	 * Generate licenses for licensed products in invoice
	 *
	 * @param int $invoice_id
	 * @param array $invoice
	 */
	public function generate_licenses( $invoice_id, $invoice = null ) {
		if ( ! class_exists( 'CF7License\Core\LicenseManager' ) ) {
			cf7invplus_log( 'CF7 License plugin not found', 'error' );
			return;
		}
		
		if ( ! $invoice ) {
			$invoice_manager = \CF7InvPlus\Core\InvoiceManager::instance();
			$invoice = $invoice_manager->get_invoice( $invoice_id );
		}
		
		if ( ! $invoice ) {
			return;
		}
		
		// Get invoice items
		$invoice_manager = \CF7InvPlus\Core\InvoiceManager::instance();
		$items = $invoice_manager->get_invoice_items( $invoice_id );
		
		$license_manager = new \CF7License\Core\LicenseManager();
		$generated_licenses = array();
		
		foreach ( $items as $item ) {
			// Skip if not a licensed product
			if ( empty( $item['is_licensed_product'] ) ) {
				continue;
			}
			
			// Skip if license already generated
			if ( ! empty( $item['license_id'] ) ) {
				continue;
			}
			
			// Generate license for each quantity
			$qty = intval( $item['qty'] );
			
			for ( $i = 0; $i < $qty; $i++ ) {
				$license_id = $license_manager->create_license( array(
					'product_id' => $item['product_id'] ?: $item['name'],
					'email'      => $invoice['client_email'],
					'order_id'   => $invoice_id,
					'metadata'   => array(
						'invoice_number' => $invoice['invoice_number'],
						'invoice_id'     => $invoice_id,
						'item_id'        => $item['id'],
						'item_name'      => $item['name'],
						'client_name'    => $invoice['client_name'],
					),
				) );
				
				if ( $license_id ) {
					$generated_licenses[] = array(
						'license_id' => $license_id,
						'item_id'    => $item['id'],
						'item_name'  => $item['name'],
					);
					
					cf7invplus_log( "License {$license_id} generated for invoice {$invoice_id}, item {$item['id']}" );
				}
			}
			
			// Update item with first license ID
			if ( ! empty( $generated_licenses ) ) {
				$first_license = $generated_licenses[0];
				$invoice_manager->update_invoice_item( $item['id'], array(
					'license_id' => $first_license['license_id'],
				) );
			}
		}
		
		// Store generated licenses in invoice metadata
		if ( ! empty( $generated_licenses ) ) {
			$metadata = is_array( $invoice['metadata'] ) ? $invoice['metadata'] : array();
			$metadata['generated_licenses'] = $generated_licenses;
			
			$invoice_manager->update_invoice( $invoice_id, array(
				'metadata' => $metadata,
			) );
			
			// Trigger email with licenses
			do_action( 'cf7invplus_licenses_generated', $invoice_id, $generated_licenses, $invoice );
		}
	}
	
	/**
	 * Get licenses for invoice
	 *
	 * @param int $invoice_id
	 * @return array
	 */
	public function get_invoice_licenses( $invoice_id ) {
		if ( ! class_exists( 'CF7License\Core\LicenseManager' ) ) {
			return array();
		}
		
		$invoice_manager = \CF7InvPlus\Core\InvoiceManager::instance();
		$invoice = $invoice_manager->get_invoice( $invoice_id );
		
		if ( ! $invoice || empty( $invoice['metadata']['generated_licenses'] ) ) {
			return array();
		}
		
		$license_manager = new \CF7License\Core\LicenseManager();
		$licenses = array();
		
		foreach ( $invoice['metadata']['generated_licenses'] as $license_info ) {
			$license = $license_manager->get_license( $license_info['license_id'] );
			
			if ( $license ) {
				$license['item_name'] = $license_info['item_name'];
				$licenses[] = $license;
			}
		}
		
		return $licenses;
	}
}
