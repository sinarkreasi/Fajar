<?php

namespace CF7InvPlus\Integrations;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Magic Link integration with CF7 Access Token
 */
class MagicLinkIntegration {
	
	/**
	 * Instance
	 */
	private static $instance = null;
	
	/**
	 * Get instance
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		$this->init_hooks();
	}
	
	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		// Hook into invoice sent event
		add_action( 'cf7invplus_invoice_sent', array( $this, 'generate_magic_link' ), 10, 2 );
		
		// Register invoice as valid related type for tokens
		add_filter( 'cf7at_valid_related_types', array( $this, 'register_related_type' ) );
		
		// Handle invoice access via magic link
		add_action( 'template_redirect', array( $this, 'handle_invoice_access' ) );
	}
	
	/**
	 * Register invoice as valid related type
	 *
	 * @param array $types
	 * @return array
	 */
	public function register_related_type( $types ) {
		$types[] = 'invoice';
		return $types;
	}
	
	/**
	 * Generate magic link for invoice
	 *
	 * @param int $invoice_id
	 * @param array $invoice
	 * @return string|false Magic link URL or false on failure
	 */
	public function generate_magic_link( $invoice_id, $invoice = null ) {
		if ( ! class_exists( 'CF7AT\Core\TokenManager' ) ) {
			cf7invplus_log( 'CF7 Access Token plugin not found', 'error' );
			return false;
		}
		
		if ( ! $invoice ) {
			$invoice_manager = \CF7InvPlus\Core\InvoiceManager::instance();
			$invoice = $invoice_manager->get_invoice( $invoice_id );
		}
		
		if ( ! $invoice ) {
			return false;
		}
		
		$token_manager = new \CF7AT\Core\TokenManager();
		
		// Create token
		$token_id = $token_manager->create_token( array(
			'related_type' => 'invoice',
			'related_id'   => $invoice_id,
			'email'        => $invoice['client_email'],
			'expires_at'   => date( 'Y-m-d H:i:s', strtotime( '+90 days' ) ),
			'usage_limit'  => null, // Unlimited usage
			'metadata'     => array(
				'invoice_number' => $invoice['invoice_number'],
				'client_name'    => $invoice['client_name'],
			),
		) );
		
		if ( ! $token_id ) {
			cf7invplus_log( "Failed to create magic link token for invoice {$invoice_id}", 'error' );
			return false;
		}
		
		// Get raw token
		$raw_token = $token_manager->get_raw_token_temporarily( $token_id );
		
		if ( ! $raw_token ) {
			cf7invplus_log( "Failed to retrieve raw token for invoice {$invoice_id}", 'error' );
			return false;
		}
		
		// Build magic link URL
		$magic_link = home_url( '/invoice/' . $raw_token );
		
		// Store magic link in invoice metadata
		$invoice_manager = \CF7InvPlus\Core\InvoiceManager::instance();
		$metadata = is_array( $invoice['metadata'] ) ? $invoice['metadata'] : array();
		$metadata['magic_link_token_id'] = $token_id;
		$metadata['magic_link'] = $magic_link;
		
		$invoice_manager->update_invoice( $invoice_id, array(
			'metadata' => $metadata,
		) );
		
		cf7invplus_log( "Magic link generated for invoice {$invoice_id}" );
		
		return $magic_link;
	}
	
	/**
	 * Handle invoice access via magic link
	 */
	public function handle_invoice_access() {
		if ( ! get_query_var( 'cf7invplus_invoice' ) ) {
			return;
		}
		
		$token = get_query_var( 'token' );
		
		if ( empty( $token ) ) {
			wp_die( __( 'Invalid access link', CF7INVPLUS_TEXT_DOMAIN ), 403 );
		}
		
		// Validate token
		if ( ! class_exists( 'CF7AT\Core\TokenManager' ) ) {
			wp_die( __( 'Access system not available', CF7INVPLUS_TEXT_DOMAIN ), 500 );
		}
		
		$token_manager = new \CF7AT\Core\TokenManager();
		$token_data = $token_manager->validate_token( $token );
		
		if ( ! $token_data || $token_data['related_type'] !== 'invoice' ) {
			wp_die( __( 'Invalid or expired access link', CF7INVPLUS_TEXT_DOMAIN ), 403 );
		}
		
		// Get invoice
		$invoice_id = $token_data['related_id'];
		$invoice_manager = \CF7InvPlus\Core\InvoiceManager::instance();
		$invoice = $invoice_manager->get_invoice( $invoice_id );
		
		if ( ! $invoice ) {
			wp_die( __( 'Invoice not found', CF7INVPLUS_TEXT_DOMAIN ), 404 );
		}
		
		// Load invoice view
		$invoice_view = \CF7InvPlus\Frontend\InvoiceView::instance();
		$invoice_view->render_invoice( $invoice );
		
		exit;
	}
	
	/**
	 * Regenerate magic link for invoice
	 *
	 * @param int $invoice_id
	 * @return string|false
	 */
	public function regenerate_magic_link( $invoice_id ) {
		$invoice_manager = \CF7InvPlus\Core\InvoiceManager::instance();
		$invoice = $invoice_manager->get_invoice( $invoice_id );
		
		if ( ! $invoice ) {
			return false;
		}
		
		// Revoke old token if exists
		if ( isset( $invoice['metadata']['magic_link_token_id'] ) ) {
			$token_manager = new \CF7AT\Core\TokenManager();
			$token_manager->revoke_token( $invoice['metadata']['magic_link_token_id'] );
		}
		
		// Generate new magic link
		return $this->generate_magic_link( $invoice_id, $invoice );
	}
}
