<?php

namespace CF7InvPlus\Database;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Database schema manager
 */
class SchemaManager {
	
	/**
	 * Create all database tables
	 */
	public static function create_tables() {
		global $wpdb;
		
		$charset_collate = $wpdb->get_charset_collate();
		
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		
		// Create invoices table
		$table_name = $wpdb->prefix . CF7INVPLUS_INVOICES_TABLE;
		$sql = "CREATE TABLE $table_name (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			invoice_number varchar(50) NOT NULL,
			status varchar(20) NOT NULL DEFAULT 'draft',
			issue_date date DEFAULT NULL,
			due_date date DEFAULT NULL,
			currency varchar(10) NOT NULL DEFAULT 'IDR',
			subtotal decimal(15,2) NOT NULL DEFAULT 0,
			tax_total decimal(15,2) NOT NULL DEFAULT 0,
			discount_total decimal(15,2) NOT NULL DEFAULT 0,
			grand_total decimal(15,2) NOT NULL DEFAULT 0,
			client_name varchar(255) DEFAULT NULL,
			client_email varchar(255) DEFAULT NULL,
			client_company varchar(255) DEFAULT NULL,
			client_address text DEFAULT NULL,
			source varchar(50) DEFAULT 'manual',
			source_id bigint(20) DEFAULT NULL,
			cf7_submission_id bigint(20) DEFAULT NULL,
			mc_order_id bigint(20) DEFAULT NULL,
			metadata longtext DEFAULT NULL,
			created_at datetime NOT NULL,
			updated_at datetime DEFAULT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY invoice_number (invoice_number),
			KEY status (status),
			KEY client_email (client_email),
			KEY mc_order_id (mc_order_id)
		) $charset_collate;";
		
		dbDelta( $sql );
		
		// Create invoice items table
		$table_name = $wpdb->prefix . CF7INVPLUS_INVOICE_ITEMS_TABLE;
		$sql = "CREATE TABLE $table_name (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			invoice_id bigint(20) unsigned NOT NULL,
			name varchar(255) NOT NULL,
			description text DEFAULT NULL,
			qty decimal(10,2) NOT NULL DEFAULT 1,
			unit_price decimal(15,2) NOT NULL DEFAULT 0,
			subtotal decimal(15,2) NOT NULL DEFAULT 0,
			tax decimal(15,2) NOT NULL DEFAULT 0,
			discount decimal(15,2) NOT NULL DEFAULT 0,
			is_licensed_product tinyint(1) NOT NULL DEFAULT 0,
			license_id bigint(20) DEFAULT NULL,
			product_id varchar(100) DEFAULT NULL,
			sort_order int(11) NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY invoice_id (invoice_id),
			KEY license_id (license_id)
		) $charset_collate;";
		
		dbDelta( $sql );
		
		// Create estimator snapshots table
		$table_name = $wpdb->prefix . CF7INVPLUS_ESTIMATOR_SNAPSHOTS_TABLE;
		$sql = "CREATE TABLE $table_name (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			invoice_id bigint(20) unsigned NOT NULL,
			formula_version varchar(20) NOT NULL,
			inputs longtext NOT NULL,
			calculation_steps longtext DEFAULT NULL,
			result_total decimal(15,2) NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY invoice_id (invoice_id)
		) $charset_collate;";
		
		dbDelta( $sql );
		
		// Create calculators table
		$table_name = $wpdb->prefix . CF7INVPLUS_CALCULATORS_TABLE;
		$sql = "CREATE TABLE $table_name (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			name varchar(255) NOT NULL,
			slug varchar(255) NOT NULL,
			type varchar(50) NOT NULL,
			description text DEFAULT NULL,
			fields longtext NOT NULL,
			formula longtext NOT NULL,
			output_format longtext DEFAULT NULL,
			is_preset tinyint(1) NOT NULL DEFAULT 0,
			status varchar(20) NOT NULL DEFAULT 'active',
			created_at datetime NOT NULL,
			updated_at datetime DEFAULT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY slug (slug),
			KEY type (type),
			KEY status (status)
		) $charset_collate;";
		
		dbDelta( $sql );
		
		// Update version
		update_option( 'cf7invplus_db_version', CF7INVPLUS_VERSION );
	}
	
	/**
	 * Check if tables exist
	 */
	public static function tables_exist() {
		global $wpdb;
		
		$tables = array(
			$wpdb->prefix . CF7INVPLUS_INVOICES_TABLE,
			$wpdb->prefix . CF7INVPLUS_INVOICE_ITEMS_TABLE,
			$wpdb->prefix . CF7INVPLUS_ESTIMATOR_SNAPSHOTS_TABLE,
			$wpdb->prefix . CF7INVPLUS_CALCULATORS_TABLE,
		);
		
		foreach ( $tables as $table ) {
			if ( $wpdb->get_var( "SHOW TABLES LIKE '$table'" ) !== $table ) {
				return false;
			}
		}
		
		return true;
	}
}
