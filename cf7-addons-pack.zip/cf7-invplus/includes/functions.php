<?php

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Helper functions for CF7 InvPlus
 */

/**
 * Generate unique invoice number
 *
 * @return string
 */
function cf7invplus_generate_invoice_number() {
	$prefix = cf7invplus_get_option( 'invoice_number_prefix', 'INV' );
	$format = cf7invplus_get_option( 'invoice_number_format', 'YEAR-SEQUENCE' );
	
	global $wpdb;
	$table_name = $wpdb->prefix . CF7INVPLUS_INVOICES_TABLE;
	
	switch ( $format ) {
		case 'YEAR-SEQUENCE':
			$year = date( 'Y' );
			$pattern = $prefix . '-' . $year . '-%';
			
			$last_number = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT invoice_number FROM $table_name WHERE invoice_number LIKE %s ORDER BY id DESC LIMIT 1",
					$pattern
				)
			);
			
			if ( $last_number ) {
				$parts = explode( '-', $last_number );
				$sequence = intval( end( $parts ) ) + 1;
			} else {
				$sequence = 1;
			}
			
			return sprintf( '%s-%s-%04d', $prefix, $year, $sequence );
			
		case 'SEQUENCE':
			$last_number = $wpdb->get_var(
				"SELECT invoice_number FROM $table_name ORDER BY id DESC LIMIT 1"
			);
			
			if ( $last_number ) {
				$sequence = intval( str_replace( $prefix . '-', '', $last_number ) ) + 1;
			} else {
				$sequence = 1;
			}
			
			return sprintf( '%s-%06d', $prefix, $sequence );
			
		default:
			return $prefix . '-' . time() . '-' . wp_rand( 1000, 9999 );
	}
}

/**
 * Format currency
 *
 * @param float $amount
 * @param string $currency
 * @return string
 */
function cf7invplus_format_currency( $amount, $currency = 'IDR' ) {
	$amount = floatval( $amount );
	
	switch ( $currency ) {
		case 'IDR':
			return 'Rp ' . number_format( $amount, 0, ',', '.' );
		case 'USD':
			return '$' . number_format( $amount, 2, '.', ',' );
		case 'EUR':
			return '€' . number_format( $amount, 2, ',', '.' );
		default:
			return $currency . ' ' . number_format( $amount, 2, '.', ',' );
	}
}

/**
 * Sanitize amount
 *
 * @param mixed $amount
 * @return float
 */
function cf7invplus_sanitize_amount( $amount ) {
	// Remove currency symbols and formatting
	$amount = preg_replace( '/[^0-9.,]/', '', $amount );
	
	// Handle different decimal separators
	if ( strpos( $amount, ',' ) !== false && strpos( $amount, '.' ) !== false ) {
		// Both present, assume comma is thousands separator
		$amount = str_replace( ',', '', $amount );
	} elseif ( strpos( $amount, ',' ) !== false ) {
		// Only comma, could be decimal separator
		$amount = str_replace( ',', '.', $amount );
	}
	
	return floatval( $amount );
}

/**
 * Get plugin option
 *
 * @param string $key
 * @param mixed $default
 * @return mixed
 */
function cf7invplus_get_option( $key, $default = null ) {
	$options = get_option( 'cf7invplus_settings', array() );
	return isset( $options[ $key ] ) ? $options[ $key ] : $default;
}

/**
 * Update plugin option
 *
 * @param string $key
 * @param mixed $value
 * @return bool
 */
function cf7invplus_update_option( $key, $value ) {
	$options = get_option( 'cf7invplus_settings', array() );
	$options[ $key ] = $value;
	return update_option( 'cf7invplus_settings', $options );
}

/**
 * Log message
 *
 * @param string $message
 * @param string $level
 */
function cf7invplus_log( $message, $level = 'info' ) {
	if ( ! cf7invplus_get_option( 'enable_logging', false ) ) {
		return;
	}
	
	$log_file = CF7INVPLUS_PLUGIN_DIR . '/logs/cf7invplus.log';
	$log_dir = dirname( $log_file );
	
	if ( ! file_exists( $log_dir ) ) {
		wp_mkdir_p( $log_dir );
	}
	
	$timestamp = current_time( 'Y-m-d H:i:s' );
	$log_entry = sprintf( "[%s] [%s] %s\n", $timestamp, strtoupper( $level ), $message );
	
	error_log( $log_entry, 3, $log_file );
}

/**
 * Get invoice statuses
 *
 * @return array
 */
function cf7invplus_get_invoice_statuses() {
	return array(
		'draft'     => __( 'Draft', CF7INVPLUS_TEXT_DOMAIN ),
		'sent'      => __( 'Sent', CF7INVPLUS_TEXT_DOMAIN ),
		'unpaid'    => __( 'Unpaid', CF7INVPLUS_TEXT_DOMAIN ),
		'paid'      => __( 'Paid', CF7INVPLUS_TEXT_DOMAIN ),
		'overdue'   => __( 'Overdue', CF7INVPLUS_TEXT_DOMAIN ),
		'cancelled' => __( 'Cancelled', CF7INVPLUS_TEXT_DOMAIN ),
	);
}

/**
 * Get calculator types
 *
 * @return array
 */
function cf7invplus_get_calculator_types() {
	return array(
		'loan'          => __( 'Loan Calculator', CF7INVPLUS_TEXT_DOMAIN ),
		'kpr'           => __( 'KPR/Mortgage Calculator', CF7INVPLUS_TEXT_DOMAIN ),
		'roi'           => __( 'ROI Calculator', CF7INVPLUS_TEXT_DOMAIN ),
		'roas'          => __( 'ROAS Calculator', CF7INVPLUS_TEXT_DOMAIN ),
		'profit_margin' => __( 'Profit/Margin Calculator', CF7INVPLUS_TEXT_DOMAIN ),
		'custom'        => __( 'Custom Formula', CF7INVPLUS_TEXT_DOMAIN ),
	);
}

/**
 * Sanitize invoice status
 *
 * @param string $status
 * @return string
 */
function cf7invplus_sanitize_invoice_status( $status ) {
	$valid_statuses = array_keys( cf7invplus_get_invoice_statuses() );
	return in_array( $status, $valid_statuses ) ? $status : 'draft';
}

/**
 * Check if invoice status transition is valid
 *
 * @param string $from
 * @param string $to
 * @return bool
 */
function cf7invplus_is_valid_status_transition( $from, $to ) {
	$transitions = array(
		'draft'     => array( 'sent', 'cancelled' ),
		'sent'      => array( 'unpaid', 'paid', 'cancelled' ),
		'unpaid'    => array( 'paid', 'overdue', 'cancelled' ),
		'paid'      => array(),
		'overdue'   => array( 'paid', 'cancelled' ),
		'cancelled' => array(),
	);
	
	// Allow same status (idempotent)
	if ( $from === $to ) {
		return true;
	}
	
	return isset( $transitions[ $from ] ) && in_array( $to, $transitions[ $from ] );
}
