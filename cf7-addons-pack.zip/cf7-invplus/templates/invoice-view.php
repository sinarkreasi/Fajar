<?php
/**
 * Invoice view template
 * 
 * @var array $invoice
 * @var array $items
 * @var string $payment_url
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<div class="cf7invplus-invoice-view" style="max-width: 800px; margin: 40px auto; padding: 20px; background: white; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
	<div class="invoice-header" style="border-bottom: 3px solid #0073aa; padding-bottom: 20px; margin-bottom: 30px;">
		<h1 style="margin: 0; color: #0073aa;"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></h1>
		<p style="margin: 5px 0 0 0; color: #666;"><?php _e( 'Invoice', CF7INVPLUS_TEXT_DOMAIN ); ?></p>
	</div>
	
	<div class="invoice-info" style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px; margin-bottom: 30px;">
		<div class="client-info">
			<h3 style="margin-top: 0;"><?php _e( 'Bill To:', CF7INVPLUS_TEXT_DOMAIN ); ?></h3>
			<p style="margin: 5px 0;"><strong><?php echo esc_html( $invoice['client_name'] ); ?></strong></p>
			<?php if ( $invoice['client_company'] ) : ?>
				<p style="margin: 5px 0;"><?php echo esc_html( $invoice['client_company'] ); ?></p>
			<?php endif; ?>
			<p style="margin: 5px 0;"><?php echo esc_html( $invoice['client_email'] ); ?></p>
			<?php if ( $invoice['client_address'] ) : ?>
				<p style="margin: 5px 0; white-space: pre-line;"><?php echo esc_html( $invoice['client_address'] ); ?></p>
			<?php endif; ?>
		</div>
		
		<div class="invoice-details" style="text-align: right;">
			<p style="margin: 5px 0;"><strong><?php _e( 'Invoice Number:', CF7INVPLUS_TEXT_DOMAIN ); ?></strong> <?php echo esc_html( $invoice['invoice_number'] ); ?></p>
			<p style="margin: 5px 0;"><strong><?php _e( 'Issue Date:', CF7INVPLUS_TEXT_DOMAIN ); ?></strong> <?php echo esc_html( $invoice['issue_date'] ); ?></p>
			<p style="margin: 5px 0;"><strong><?php _e( 'Due Date:', CF7INVPLUS_TEXT_DOMAIN ); ?></strong> <?php echo esc_html( $invoice['due_date'] ); ?></p>
			<p style="margin: 5px 0;"><strong><?php _e( 'Status:', CF7INVPLUS_TEXT_DOMAIN ); ?></strong> 
				<span style="padding: 3px 10px; background: <?php echo $invoice['status'] === 'paid' ? '#46b450' : '#d63638'; ?>; color: white; border-radius: 3px; font-size: 12px;">
					<?php echo esc_html( ucfirst( $invoice['status'] ) ); ?>
				</span>
			</p>
		</div>
	</div>
	
	<table style="width: 100%; border-collapse: collapse; margin-bottom: 30px;">
		<thead>
			<tr style="background: #f0f0f0;">
				<th style="padding: 12px; text-align: left; border-bottom: 2px solid #ddd;"><?php _e( 'Item', CF7INVPLUS_TEXT_DOMAIN ); ?></th>
				<th style="padding: 12px; text-align: center; border-bottom: 2px solid #ddd;"><?php _e( 'Qty', CF7INVPLUS_TEXT_DOMAIN ); ?></th>
				<th style="padding: 12px; text-align: right; border-bottom: 2px solid #ddd;"><?php _e( 'Unit Price', CF7INVPLUS_TEXT_DOMAIN ); ?></th>
				<th style="padding: 12px; text-align: right; border-bottom: 2px solid #ddd;"><?php _e( 'Total', CF7INVPLUS_TEXT_DOMAIN ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ( $items as $item ) : ?>
				<tr>
					<td style="padding: 12px; border-bottom: 1px solid #eee;">
						<strong><?php echo esc_html( $item['name'] ); ?></strong>
						<?php if ( $item['description'] ) : ?>
							<br><small style="color: #666;"><?php echo esc_html( $item['description'] ); ?></small>
						<?php endif; ?>
					</td>
					<td style="padding: 12px; text-align: center; border-bottom: 1px solid #eee;"><?php echo esc_html( $item['qty'] ); ?></td>
					<td style="padding: 12px; text-align: right; border-bottom: 1px solid #eee;"><?php echo cf7invplus_format_currency( $item['unit_price'], $invoice['currency'] ); ?></td>
					<td style="padding: 12px; text-align: right; border-bottom: 1px solid #eee;"><?php echo cf7invplus_format_currency( $item['subtotal'], $invoice['currency'] ); ?></td>
				</tr>
			<?php endforeach; ?>
		</tbody>
		<tfoot>
			<tr>
				<td colspan="3" style="padding: 12px; text-align: right;"><strong><?php _e( 'Subtotal:', CF7INVPLUS_TEXT_DOMAIN ); ?></strong></td>
				<td style="padding: 12px; text-align: right;"><?php echo cf7invplus_format_currency( $invoice['subtotal'], $invoice['currency'] ); ?></td>
			</tr>
			<?php if ( $invoice['tax_total'] > 0 ) : ?>
				<tr>
					<td colspan="3" style="padding: 12px; text-align: right;"><strong><?php _e( 'Tax:', CF7INVPLUS_TEXT_DOMAIN ); ?></strong></td>
					<td style="padding: 12px; text-align: right;"><?php echo cf7invplus_format_currency( $invoice['tax_total'], $invoice['currency'] ); ?></td>
				</tr>
			<?php endif; ?>
			<?php if ( $invoice['discount_total'] > 0 ) : ?>
				<tr>
					<td colspan="3" style="padding: 12px; text-align: right;"><strong><?php _e( 'Discount:', CF7INVPLUS_TEXT_DOMAIN ); ?></strong></td>
					<td style="padding: 12px; text-align: right;">-<?php echo cf7invplus_format_currency( $invoice['discount_total'], $invoice['currency'] ); ?></td>
				</tr>
			<?php endif; ?>
			<tr style="background: #f0f0f0;">
				<td colspan="3" style="padding: 15px; text-align: right; font-size: 18px;"><strong><?php _e( 'Total:', CF7INVPLUS_TEXT_DOMAIN ); ?></strong></td>
				<td style="padding: 15px; text-align: right; font-size: 18px;"><strong><?php echo cf7invplus_format_currency( $invoice['grand_total'], $invoice['currency'] ); ?></strong></td>
			</tr>
		</tfoot>
	</table>
	
	<?php if ( $payment_url && in_array( $invoice['status'], array( 'sent', 'unpaid', 'overdue' ) ) ) : ?>
		<div style="text-align: center; margin: 30px 0;">
			<a href="<?php echo esc_url( $payment_url ); ?>" class="button" style="display: inline-block; padding: 15px 40px; background: #0073aa; color: white; text-decoration: none; border-radius: 5px; font-size: 16px;">
				<?php _e( 'Pay Now', CF7INVPLUS_TEXT_DOMAIN ); ?>
			</a>
		</div>
	<?php endif; ?>
	
	<?php if ( $invoice['status'] === 'paid' ) : ?>
		<div style="text-align: center; padding: 20px; background: #e7f7e9; border-radius: 5px; color: #46b450;">
			<strong><?php _e( '✓ This invoice has been paid. Thank you!', CF7INVPLUS_TEXT_DOMAIN ); ?></strong>
		</div>
	<?php endif; ?>
</div>

<?php
get_footer();
