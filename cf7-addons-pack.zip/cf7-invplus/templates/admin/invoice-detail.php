<?php
/**
 * Admin invoice detail template
 * 
 * @var int $invoice_id
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$invoice_manager = \CF7InvPlus\Core\InvoiceManager::instance();
$invoice = $invoice_manager->get_invoice( $invoice_id );

if ( ! $invoice ) {
	echo '<div class="wrap"><h1>' . __( 'Invoice Not Found', CF7INVPLUS_TEXT_DOMAIN ) . '</h1></div>';
	return;
}

$items = $invoice_manager->get_invoice_items( $invoice_id );
$magic_link_integration = \CF7InvPlus\Integrations\MagicLinkIntegration::instance();
?>

<div class="wrap">
	<h1 class="wp-heading-inline"><?php printf( __( 'Invoice: %s', CF7INVPLUS_TEXT_DOMAIN ), esc_html( $invoice['invoice_number'] ) ); ?></h1>
	<a href="<?php echo admin_url( 'admin.php?page=cf7invplus' ); ?>" class="page-title-action"><?php _e( 'Back to List', CF7INVPLUS_TEXT_DOMAIN ); ?></a>
	<hr class="wp-header-end">
	
	<div id="poststuff">
		<div id="post-body" class="metabox-holder columns-2">
			<div id="post-body-content">
				<!-- Client Information -->
				<div class="postbox">
					<h2 class="hndle"><span><?php _e( 'Client Information', CF7INVPLUS_TEXT_DOMAIN ); ?></span></h2>
					<div class="inside">
						<table class="form-table">
							<tr>
								<th><?php _e( 'Name:', CF7INVPLUS_TEXT_DOMAIN ); ?></th>
								<td><strong><?php echo esc_html( $invoice['client_name'] ); ?></strong></td>
							</tr>
							<tr>
								<th><?php _e( 'Email:', CF7INVPLUS_TEXT_DOMAIN ); ?></th>
								<td><?php echo esc_html( $invoice['client_email'] ); ?></td>
							</tr>
							<?php if ( $invoice['client_company'] ) : ?>
								<tr>
									<th><?php _e( 'Company:', CF7INVPLUS_TEXT_DOMAIN ); ?></th>
									<td><?php echo esc_html( $invoice['client_company'] ); ?></td>
								</tr>
							<?php endif; ?>
							<?php if ( $invoice['client_address'] ) : ?>
								<tr>
									<th><?php _e( 'Address:', CF7INVPLUS_TEXT_DOMAIN ); ?></th>
									<td><?php echo nl2br( esc_html( $invoice['client_address'] ) ); ?></td>
								</tr>
							<?php endif; ?>
						</table>
					</div>
				</div>
				
				<!-- Invoice Items -->
				<div class="postbox">
					<h2 class="hndle"><span><?php _e( 'Invoice Items', CF7INVPLUS_TEXT_DOMAIN ); ?></span></h2>
					<div class="inside">
						<table class="wp-list-table widefat fixed striped">
							<thead>
								<tr>
									<th><?php _e( 'Item', CF7INVPLUS_TEXT_DOMAIN ); ?></th>
									<th style="text-align: center;"><?php _e( 'Qty', CF7INVPLUS_TEXT_DOMAIN ); ?></th>
									<th style="text-align: right;"><?php _e( 'Unit Price', CF7INVPLUS_TEXT_DOMAIN ); ?></th>
									<th style="text-align: right;"><?php _e( 'Subtotal', CF7INVPLUS_TEXT_DOMAIN ); ?></th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ( $items as $item ) : ?>
									<tr>
										<td>
											<strong><?php echo esc_html( $item['name'] ); ?></strong>
											<?php if ( $item['description'] ) : ?>
												<br><small><?php echo esc_html( $item['description'] ); ?></small>
											<?php endif; ?>
											<?php if ( $item['is_licensed_product'] ) : ?>
												<br><span class="dashicons dashicons-admin-network" style="color: #0073aa;"></span> <em><?php _e( 'Licensed Product', CF7INVPLUS_TEXT_DOMAIN ); ?></em>
											<?php endif; ?>
										</td>
										<td style="text-align: center;"><?php echo esc_html( $item['qty'] ); ?></td>
										<td style="text-align: right;"><?php echo cf7invplus_format_currency( $item['unit_price'], $invoice['currency'] ); ?></td>
										<td style="text-align: right;"><?php echo cf7invplus_format_currency( $item['subtotal'], $invoice['currency'] ); ?></td>
									</tr>
								<?php endforeach; ?>
							</tbody>
							<tfoot>
								<tr>
									<td colspan="3" style="text-align: right;"><strong><?php _e( 'Subtotal:', CF7INVPLUS_TEXT_DOMAIN ); ?></strong></td>
									<td style="text-align: right;"><?php echo cf7invplus_format_currency( $invoice['subtotal'], $invoice['currency'] ); ?></td>
								</tr>
								<?php if ( $invoice['tax_total'] > 0 ) : ?>
									<tr>
										<td colspan="3" style="text-align: right;"><strong><?php _e( 'Tax:', CF7INVPLUS_TEXT_DOMAIN ); ?></strong></td>
										<td style="text-align: right;"><?php echo cf7invplus_format_currency( $invoice['tax_total'], $invoice['currency'] ); ?></td>
									</tr>
								<?php endif; ?>
								<?php if ( $invoice['discount_total'] > 0 ) : ?>
									<tr>
										<td colspan="3" style="text-align: right;"><strong><?php _e( 'Discount:', CF7INVPLUS_TEXT_DOMAIN ); ?></strong></td>
										<td style="text-align: right;">-<?php echo cf7invplus_format_currency( $invoice['discount_total'], $invoice['currency'] ); ?></td>
									</tr>
								<?php endif; ?>
								<tr style="background: #f0f0f0;">
									<td colspan="3" style="text-align: right; font-size: 16px;"><strong><?php _e( 'Grand Total:', CF7INVPLUS_TEXT_DOMAIN ); ?></strong></td>
									<td style="text-align: right; font-size: 16px;"><strong><?php echo cf7invplus_format_currency( $invoice['grand_total'], $invoice['currency'] ); ?></strong></td>
								</tr>
							</tfoot>
						</table>
					</div>
				</div>
			</div>
			
			<!-- Sidebar -->
			<div id="postbox-container-1" class="postbox-container">
				<!-- Invoice Details -->
				<div class="postbox">
					<h2 class="hndle"><span><?php _e( 'Invoice Details', CF7INVPLUS_TEXT_DOMAIN ); ?></span></h2>
					<div class="inside">
						<p><strong><?php _e( 'Invoice Number:', CF7INVPLUS_TEXT_DOMAIN ); ?></strong><br><?php echo esc_html( $invoice['invoice_number'] ); ?></p>
						<p><strong><?php _e( 'Status:', CF7INVPLUS_TEXT_DOMAIN ); ?></strong><br>
							<span class="invoice-status status-<?php echo esc_attr( $invoice['status'] ); ?>">
								<?php echo esc_html( ucfirst( $invoice['status'] ) ); ?>
							</span>
						</p>
						<p><strong><?php _e( 'Issue Date:', CF7INVPLUS_TEXT_DOMAIN ); ?></strong><br><?php echo esc_html( $invoice['issue_date'] ); ?></p>
						<p><strong><?php _e( 'Due Date:', CF7INVPLUS_TEXT_DOMAIN ); ?></strong><br><?php echo esc_html( $invoice['due_date'] ); ?></p>
						<p><strong><?php _e( 'Created:', CF7INVPLUS_TEXT_DOMAIN ); ?></strong><br><?php echo esc_html( $invoice['created_at'] ); ?></p>
					</div>
				</div>
				
				<!-- Magic Link -->
				<?php if ( isset( $invoice['metadata']['magic_link'] ) ) : ?>
					<div class="postbox">
						<h2 class="hndle"><span><?php _e( 'Magic Link', CF7INVPLUS_TEXT_DOMAIN ); ?></span></h2>
						<div class="inside">
							<p><?php _e( 'Share this link with your client:', CF7INVPLUS_TEXT_DOMAIN ); ?></p>
							<input type="text" value="<?php echo esc_url( $invoice['metadata']['magic_link'] ); ?>" class="regular-text" readonly onclick="this.select();">
							<p>
								<a href="<?php echo esc_url( $invoice['metadata']['magic_link'] ); ?>" class="button" target="_blank"><?php _e( 'Preview', CF7INVPLUS_TEXT_DOMAIN ); ?></a>
							</p>
						</div>
					</div>
				<?php endif; ?>
				
				<!-- Actions -->
				<div class="postbox">
					<h2 class="hndle"><span><?php _e( 'Actions', CF7INVPLUS_TEXT_DOMAIN ); ?></span></h2>
					<div class="inside">
						<?php if ( $invoice['status'] === 'draft' ) : ?>
							<p>
								<a href="#" class="button button-primary" onclick="if(confirm('<?php _e( 'Send this invoice to the client?', CF7INVPLUS_TEXT_DOMAIN ); ?>')) { window.location.href='<?php echo wp_nonce_url( admin_url( 'admin.php?page=cf7invplus&action=send&invoice_id=' . $invoice_id ), 'cf7invplus_action' ); ?>'; } return false;">
									<?php _e( 'Send Invoice', CF7INVPLUS_TEXT_DOMAIN ); ?>
								</a>
							</p>
						<?php endif; ?>
						
						<?php if ( in_array( $invoice['status'], array( 'sent', 'unpaid', 'overdue' ) ) ) : ?>
							<p>
								<a href="#" class="button button-primary" onclick="if(confirm('<?php _e( 'Mark this invoice as paid?', CF7INVPLUS_TEXT_DOMAIN ); ?>')) { window.location.href='<?php echo wp_nonce_url( admin_url( 'admin.php?page=cf7invplus&action=mark_paid&invoice_id=' . $invoice_id ), 'cf7invplus_action' ); ?>'; } return false;">
									<?php _e( 'Mark as Paid', CF7INVPLUS_TEXT_DOMAIN ); ?>
								</a>
							</p>
						<?php endif; ?>
						
						<?php if ( ! isset( $invoice['metadata']['magic_link'] ) ) : ?>
							<p>
								<a href="<?php echo wp_nonce_url( admin_url( 'admin.php?page=cf7invplus&action=generate_link&invoice_id=' . $invoice_id ), 'cf7invplus_action' ); ?>" class="button">
									<?php _e( 'Generate Magic Link', CF7INVPLUS_TEXT_DOMAIN ); ?>
								</a>
							</p>
						<?php else : ?>
							<p>
								<a href="<?php echo wp_nonce_url( admin_url( 'admin.php?page=cf7invplus&action=regenerate_link&invoice_id=' . $invoice_id ), 'cf7invplus_action' ); ?>" class="button">
									<?php _e( 'Regenerate Magic Link', CF7INVPLUS_TEXT_DOMAIN ); ?>
								</a>
							</p>
						<?php endif; ?>
					</div>
				</div>
				
				<!-- Payment Info -->
				<?php if ( $invoice['mc_order_id'] ) : ?>
					<div class="postbox">
						<h2 class="hndle"><span><?php _e( 'Payment Info', CF7INVPLUS_TEXT_DOMAIN ); ?></span></h2>
						<div class="inside">
							<p><strong><?php _e( 'CF7MC Order ID:', CF7INVPLUS_TEXT_DOMAIN ); ?></strong><br>#<?php echo esc_html( $invoice['mc_order_id'] ); ?></p>
						</div>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>
