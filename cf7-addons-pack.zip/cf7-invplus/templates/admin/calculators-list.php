<?php
/**
 * Admin calculators list template
 * 
 * @var array $calculators
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="wrap">
	<h1 class="wp-heading-inline"><?php _e( 'Calculators', CF7INVPLUS_TEXT_DOMAIN ); ?></h1>
	<hr class="wp-header-end">
	
	<p><?php _e( 'Use these calculators in your pages with the shortcode:', CF7INVPLUS_TEXT_DOMAIN ); ?> <code>[cf7invplus_calculator slug="calculator-slug"]</code></p>
	
	<table class="wp-list-table widefat fixed striped">
		<thead>
			<tr>
				<th><?php _e( 'Name', CF7INVPLUS_TEXT_DOMAIN ); ?></th>
				<th><?php _e( 'Type', CF7INVPLUS_TEXT_DOMAIN ); ?></th>
				<th><?php _e( 'Shortcode', CF7INVPLUS_TEXT_DOMAIN ); ?></th>
				<th><?php _e( 'Preset', CF7INVPLUS_TEXT_DOMAIN ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php if ( empty( $calculators ) ) : ?>
				<tr>
					<td colspan="4"><?php _e( 'No calculators found.', CF7INVPLUS_TEXT_DOMAIN ); ?></td>
				</tr>
			<?php else : ?>
				<?php foreach ( $calculators as $calculator ) : ?>
					<tr>
						<td><strong><?php echo esc_html( $calculator['name'] ); ?></strong></td>
						<td><?php echo esc_html( ucfirst( str_replace( '_', ' ', $calculator['type'] ) ) ); ?></td>
						<td><code>[cf7invplus_calculator slug="<?php echo esc_attr( $calculator['slug'] ); ?>"]</code></td>
						<td><?php echo $calculator['is_preset'] ? '✓' : ''; ?></td>
					</tr>
				<?php endforeach; ?>
			<?php endif; ?>
		</tbody>
	</table>
</div>
