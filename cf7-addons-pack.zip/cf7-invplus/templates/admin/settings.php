<?php
/**
 * Admin settings template
 * 
 * @var array $settings
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="wrap">
	<h1><?php _e( 'CF7 InvPlus Settings', CF7INVPLUS_TEXT_DOMAIN ); ?></h1>
	
	<form method="post" action="">
		<?php wp_nonce_field( 'cf7invplus_settings' ); ?>
		
		<table class="form-table">
			<tr>
				<th scope="row"><label for="invoice_number_prefix"><?php _e( 'Invoice Number Prefix', CF7INVPLUS_TEXT_DOMAIN ); ?></label></th>
				<td>
					<input type="text" id="invoice_number_prefix" name="invoice_number_prefix" value="<?php echo esc_attr( isset( $settings['invoice_number_prefix'] ) ? $settings['invoice_number_prefix'] : 'INV' ); ?>" class="regular-text">
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="invoice_number_format"><?php _e( 'Invoice Number Format', CF7INVPLUS_TEXT_DOMAIN ); ?></label></th>
				<td>
					<select id="invoice_number_format" name="invoice_number_format">
						<option value="YEAR-SEQUENCE" <?php selected( isset( $settings['invoice_number_format'] ) ? $settings['invoice_number_format'] : '', 'YEAR-SEQUENCE' ); ?>><?php _e( 'PREFIX-YEAR-SEQUENCE (e.g., INV-2025-0001)', CF7INVPLUS_TEXT_DOMAIN ); ?></option>
						<option value="SEQUENCE" <?php selected( isset( $settings['invoice_number_format'] ) ? $settings['invoice_number_format'] : '', 'SEQUENCE' ); ?>><?php _e( 'PREFIX-SEQUENCE (e.g., INV-000001)', CF7INVPLUS_TEXT_DOMAIN ); ?></option>
					</select>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="default_currency"><?php _e( 'Default Currency', CF7INVPLUS_TEXT_DOMAIN ); ?></label></th>
				<td>
					<select id="default_currency" name="default_currency">
						<option value="IDR" <?php selected( isset( $settings['default_currency'] ) ? $settings['default_currency'] : '', 'IDR' ); ?>>IDR (Indonesian Rupiah)</option>
						<option value="USD" <?php selected( isset( $settings['default_currency'] ) ? $settings['default_currency'] : '', 'USD' ); ?>>USD (US Dollar)</option>
						<option value="EUR" <?php selected( isset( $settings['default_currency'] ) ? $settings['default_currency'] : '', 'EUR' ); ?>>EUR (Euro)</option>
					</select>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="default_tax_rate"><?php _e( 'Default Tax Rate (%)', CF7INVPLUS_TEXT_DOMAIN ); ?></label></th>
				<td>
					<input type="number" id="default_tax_rate" name="default_tax_rate" value="<?php echo esc_attr( isset( $settings['default_tax_rate'] ) ? $settings['default_tax_rate'] : 0 ); ?>" step="0.01" class="small-text">
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="default_due_days"><?php _e( 'Default Due Days', CF7INVPLUS_TEXT_DOMAIN ); ?></label></th>
				<td>
					<input type="number" id="default_due_days" name="default_due_days" value="<?php echo esc_attr( isset( $settings['default_due_days'] ) ? $settings['default_due_days'] : 30 ); ?>" class="small-text">
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="enable_logging"><?php _e( 'Enable Logging', CF7INVPLUS_TEXT_DOMAIN ); ?></label></th>
				<td>
					<input type="checkbox" id="enable_logging" name="enable_logging" value="1" <?php checked( ! empty( $settings['enable_logging'] ) ); ?>>
					<p class="description"><?php _e( 'Enable logging for debugging purposes', CF7INVPLUS_TEXT_DOMAIN ); ?></p>
				</td>
			</tr>
		</table>
		
		<p class="submit">
			<input type="submit" name="cf7invplus_save_settings" class="button button-primary" value="<?php _e( 'Save Settings', CF7INVPLUS_TEXT_DOMAIN ); ?>">
		</p>
	</form>
</div>
