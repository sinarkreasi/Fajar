<?php
/**
 * Admin new invoice template
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="wrap">
	<h1 class="wp-heading-inline"><?php _e( 'Create New Invoice', CF7INVPLUS_TEXT_DOMAIN ); ?></h1>
	<a href="<?php echo admin_url( 'admin.php?page=cf7invplus' ); ?>" class="page-title-action"><?php _e( 'Back to List', CF7INVPLUS_TEXT_DOMAIN ); ?></a>
	<hr class="wp-header-end">
	
	<form method="post" action="<?php echo admin_url( 'admin.php?page=cf7invplus' ); ?>">
		<?php wp_nonce_field( 'cf7invplus_save_invoice' ); ?>
		
		<table class="form-table">
			<tr>
				<th scope="row"><label for="client_name"><?php _e( 'Client Name', CF7INVPLUS_TEXT_DOMAIN ); ?> *</label></th>
				<td>
					<input type="text" id="client_name" name="client_name" class="regular-text" required>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="client_email"><?php _e( 'Client Email', CF7INVPLUS_TEXT_DOMAIN ); ?> *</label></th>
				<td>
					<input type="email" id="client_email" name="client_email" class="regular-text" required>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="client_company"><?php _e( 'Company', CF7INVPLUS_TEXT_DOMAIN ); ?></label></th>
				<td>
					<input type="text" id="client_company" name="client_company" class="regular-text">
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="client_address"><?php _e( 'Address', CF7INVPLUS_TEXT_DOMAIN ); ?></label></th>
				<td>
					<textarea id="client_address" name="client_address" rows="3" class="large-text"></textarea>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="status"><?php _e( 'Status', CF7INVPLUS_TEXT_DOMAIN ); ?></label></th>
				<td>
					<select id="status" name="status">
						<?php foreach ( cf7invplus_get_invoice_statuses() as $key => $label ) : ?>
							<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $key, 'draft' ); ?>><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select>
				</td>
			</tr>
		</table>
		
		<h2><?php _e( 'Invoice Items', CF7INVPLUS_TEXT_DOMAIN ); ?></h2>
		<p class="description"><?php _e( 'Add at least one item to the invoice.', CF7INVPLUS_TEXT_DOMAIN ); ?></p>
		
		<table class="wp-list-table widefat fixed striped" id="invoice-items-table">
			<thead>
				<tr>
					<th style="width: 30%;"><?php _e( 'Item Name', CF7INVPLUS_TEXT_DOMAIN ); ?></th>
					<th style="width: 30%;"><?php _e( 'Description', CF7INVPLUS_TEXT_DOMAIN ); ?></th>
					<th style="width: 15%;"><?php _e( 'Quantity', CF7INVPLUS_TEXT_DOMAIN ); ?></th>
					<th style="width: 20%;"><?php _e( 'Unit Price', CF7INVPLUS_TEXT_DOMAIN ); ?></th>
					<th style="width: 5%;"></th>
				</tr>
			</thead>
			<tbody id="invoice-items">
				<tr class="invoice-item-row">
					<td><input type="text" name="items[0][name]" class="regular-text" required></td>
					<td><input type="text" name="items[0][description]" class="regular-text"></td>
					<td><input type="number" name="items[0][qty]" value="1" step="0.01" class="small-text" required></td>
					<td><input type="number" name="items[0][unit_price]" value="0" step="0.01" class="regular-text" required></td>
					<td><button type="button" class="button remove-item" disabled>×</button></td>
				</tr>
			</tbody>
		</table>
		
		<p>
			<button type="button" id="add-item" class="button"><?php _e( 'Add Item', CF7INVPLUS_TEXT_DOMAIN ); ?></button>
		</p>
		
		<p class="submit">
			<input type="submit" name="cf7invplus_save_invoice" class="button button-primary" value="<?php _e( 'Create Invoice', CF7INVPLUS_TEXT_DOMAIN ); ?>">
			<a href="<?php echo admin_url( 'admin.php?page=cf7invplus' ); ?>" class="button"><?php _e( 'Cancel', CF7INVPLUS_TEXT_DOMAIN ); ?></a>
		</p>
	</form>
</div>

<script>
jQuery(document).ready(function($) {
	var itemIndex = 1;
	
	$('#add-item').on('click', function() {
		var newRow = '<tr class="invoice-item-row">' +
			'<td><input type="text" name="items[' + itemIndex + '][name]" class="regular-text" required></td>' +
			'<td><input type="text" name="items[' + itemIndex + '][description]" class="regular-text"></td>' +
			'<td><input type="number" name="items[' + itemIndex + '][qty]" value="1" step="0.01" class="small-text" required></td>' +
			'<td><input type="number" name="items[' + itemIndex + '][unit_price]" value="0" step="0.01" class="regular-text" required></td>' +
			'<td><button type="button" class="button remove-item">×</button></td>' +
			'</tr>';
		
		$('#invoice-items').append(newRow);
		itemIndex++;
		updateRemoveButtons();
	});
	
	$(document).on('click', '.remove-item', function() {
		$(this).closest('tr').remove();
		updateRemoveButtons();
	});
	
	function updateRemoveButtons() {
		var rowCount = $('#invoice-items tr').length;
		if (rowCount === 1) {
			$('.remove-item').prop('disabled', true);
		} else {
			$('.remove-item').prop('disabled', false);
		}
	}
});
</script>

<style>
.invoice-item-row input[type="text"],
.invoice-item-row input[type="number"] {
	width: 100%;
}
.remove-item {
	font-size: 20px;
	line-height: 1;
	padding: 0 8px;
	color: #d63638;
}
</style>
