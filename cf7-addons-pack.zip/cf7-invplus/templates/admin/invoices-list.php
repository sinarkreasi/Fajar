<?php
/**
 * Admin invoices list template
 * 
 * @var array $invoices
 * @var int $total
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="wrap">
	<h1 class="wp-heading-inline"><?php _e( 'Invoices', CF7INVPLUS_TEXT_DOMAIN ); ?></h1>
	<a href="<?php echo admin_url( 'admin.php?page=cf7invplus&action=new' ); ?>" class="page-title-action"><?php _e( 'Add New', CF7INVPLUS_TEXT_DOMAIN ); ?></a>
	<hr class="wp-header-end">
	
	<ul class="subsubsub">
		<li><a href="<?php echo admin_url( 'admin.php?page=cf7invplus' ); ?>" <?php echo empty( $status ) ? 'class="current"' : ''; ?>><?php _e( 'All', CF7INVPLUS_TEXT_DOMAIN ); ?></a> |</li>
		<?php foreach ( cf7invplus_get_invoice_statuses() as $key => $label ) : ?>
			<li><a href="<?php echo admin_url( 'admin.php?page=cf7invplus&status=' . $key ); ?>" <?php echo $status === $key ? 'class="current"' : ''; ?>><?php echo esc_html( $label ); ?></a> |</li>
		<?php endforeach; ?>
	</ul>
	
	<table class="wp-list-table widefat fixed striped">
		<thead>
			<tr>
				<th><?php _e( 'Invoice #', CF7INVPLUS_TEXT_DOMAIN ); ?></th>
				<th><?php _e( 'Client', CF7INVPLUS_TEXT_DOMAIN ); ?></th>
				<th><?php _e( 'Amount', CF7INVPLUS_TEXT_DOMAIN ); ?></th>
				<th><?php _e( 'Status', CF7INVPLUS_TEXT_DOMAIN ); ?></th>
				<th><?php _e( 'Date', CF7INVPLUS_TEXT_DOMAIN ); ?></th>
				<th><?php _e( 'Actions', CF7INVPLUS_TEXT_DOMAIN ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php if ( empty( $invoices ) ) : ?>
				<tr>
					<td colspan="6"><?php _e( 'No invoices found.', CF7INVPLUS_TEXT_DOMAIN ); ?></td>
				</tr>
			<?php else : ?>
				<?php foreach ( $invoices as $invoice ) : ?>
					<tr>
						<td><strong><?php echo esc_html( $invoice['invoice_number'] ); ?></strong></td>
						<td>
							<?php echo esc_html( $invoice['client_name'] ); ?><br>
							<small><?php echo esc_html( $invoice['client_email'] ); ?></small>
						</td>
						<td><?php echo cf7invplus_format_currency( $invoice['grand_total'], $invoice['currency'] ); ?></td>
						<td><span class="invoice-status status-<?php echo esc_attr( $invoice['status'] ); ?>"><?php echo esc_html( ucfirst( $invoice['status'] ) ); ?></span></td>
						<td><?php echo esc_html( $invoice['created_at'] ); ?></td>
						<td>
							<a href="<?php echo wp_nonce_url( admin_url( 'admin.php?page=cf7invplus&action=view&invoice_id=' . $invoice['id'] ), 'cf7invplus_action' ); ?>"><?php _e( 'View', CF7INVPLUS_TEXT_DOMAIN ); ?></a>
						</td>
					</tr>
				<?php endforeach; ?>
			<?php endif; ?>
		</tbody>
	</table>
</div>
