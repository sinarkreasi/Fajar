<?php
/**
 * Calculator form template
 * 
 * @var array $calculator
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="cf7invplus-calculator" data-calculator-id="<?php echo esc_attr( $calculator['id'] ); ?>" style="max-width: 600px; margin: 20px auto; padding: 30px; background: #f9f9f9; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
	<h3 style="margin-top: 0; color: #0073aa;"><?php echo esc_html( $calculator['name'] ); ?></h3>
	
	<?php if ( $calculator['description'] ) : ?>
		<p style="color: #666; margin-bottom: 25px;"><?php echo esc_html( $calculator['description'] ); ?></p>
	<?php endif; ?>
	
	<form class="calculator-form">
		<?php foreach ( $calculator['fields'] as $field ) : ?>
			<div class="calculator-field" style="margin-bottom: 20px;">
				<label style="display: block; margin-bottom: 5px; font-weight: bold; color: #333;">
					<?php echo esc_html( $field['label'] ); ?>
					<?php if ( ! empty( $field['required'] ) ) : ?>
						<span style="color: #d63638;">*</span>
					<?php endif; ?>
				</label>
				
				<?php if ( $field['type'] === 'select' ) : ?>
					<select 
						name="<?php echo esc_attr( $field['name'] ); ?>" 
						<?php echo ! empty( $field['required'] ) ? 'required' : ''; ?>
						style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 14px;">
						<?php foreach ( $field['options'] as $option ) : ?>
							<option value="<?php echo esc_attr( $option['value'] ); ?>">
								<?php echo esc_html( $option['label'] ); ?>
							</option>
						<?php endforeach; ?>
					</select>
				<?php else : ?>
					<input 
						type="<?php echo esc_attr( $field['type'] ); ?>" 
						name="<?php echo esc_attr( $field['name'] ); ?>" 
						placeholder="<?php echo esc_attr( isset( $field['placeholder'] ) ? $field['placeholder'] : '' ); ?>"
						step="<?php echo esc_attr( isset( $field['step'] ) ? $field['step'] : 'any' ); ?>"
						<?php echo ! empty( $field['required'] ) ? 'required' : ''; ?>
						style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 14px;">
				<?php endif; ?>
			</div>
		<?php endforeach; ?>
		
		<button type="submit" style="width: 100%; padding: 12px; background: #0073aa; color: white; border: none; border-radius: 4px; font-size: 16px; cursor: pointer; margin-top: 10px;">
			<?php _e( 'Calculate', CF7INVPLUS_TEXT_DOMAIN ); ?>
		</button>
	</form>
	
	<div class="calculator-result" style="margin-top: 30px; padding: 20px; background: white; border-radius: 4px; display: none;">
		<h4 style="margin-top: 0; color: #0073aa;"><?php _e( 'Results:', CF7INVPLUS_TEXT_DOMAIN ); ?></h4>
		<div class="result-content"></div>
	</div>
	
	<div class="calculator-loading" style="display: none; text-align: center; margin-top: 20px;">
		<p><?php _e( 'Calculating...', CF7INVPLUS_TEXT_DOMAIN ); ?></p>
	</div>
</div>

<script>
jQuery(document).ready(function($) {
	$('.calculator-form').on('submit', function(e) {
		e.preventDefault();
		
		var $form = $(this);
		var $calculator = $form.closest('.cf7invplus-calculator');
		var calculatorId = $calculator.data('calculator-id');
		var $result = $calculator.find('.calculator-result');
		var $loading = $calculator.find('.calculator-loading');
		
		// Gather inputs
		var inputs = {};
		$form.find('input, select').each(function() {
			var $field = $(this);
			inputs[$field.attr('name')] = $field.val();
		});
		
		// Show loading
		$result.hide();
		$loading.show();
		
		// Calculate
		$.ajax({
			url: cf7invplus.ajax_url,
			type: 'POST',
			data: {
				action: 'cf7invplus_calculate',
				nonce: cf7invplus.nonce,
				calculator_id: calculatorId,
				inputs: inputs
			},
			success: function(response) {
				$loading.hide();
				
				if (response.success && response.data.formatted) {
					var html = '';
					$.each(response.data.formatted, function(key, field) {
						html += '<div style="margin-bottom: 15px; padding: 15px; background: #f0f0f0; border-radius: 4px;">';
						html += '<div style="color: #666; font-size: 12px; margin-bottom: 5px;">' + field.label + '</div>';
						html += '<div style="font-size: 24px; font-weight: bold; color: #0073aa;">' + field.value + '</div>';
						html += '</div>';
					});
					
					$result.find('.result-content').html(html);
					$result.slideDown();
				} else {
					alert('<?php _e( 'Calculation failed. Please check your inputs.', CF7INVPLUS_TEXT_DOMAIN ); ?>');
				}
			},
			error: function() {
				$loading.hide();
				alert('<?php _e( 'An error occurred. Please try again.', CF7INVPLUS_TEXT_DOMAIN ); ?>');
			}
		});
	});
});
</script>
