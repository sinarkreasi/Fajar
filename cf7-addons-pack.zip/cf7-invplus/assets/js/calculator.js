/* CF7 InvPlus Calculator JavaScript */

(function ($) {
    'use strict';

    // Calculator functionality is handled inline in the template
    // This file can be used for additional calculator features

    $(document).ready(function () {
        console.log('CF7 InvPlus Calculator loaded');
    });

})(jQuery);
