/* CF7 InvPlus Admin JavaScript */

(function($) {
	'use strict';
	
	$(document).ready(function() {
		// Admin functionality can be added here
		console.log('CF7 InvPlus Admin loaded');
	});
	
})(jQuery);
