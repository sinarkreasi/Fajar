# CF7 Invoice Plus

Transform Contact Form 7 into a complete invoicing and calculation system with magic link access, payment processing, and license generation.

## Features

### Invoice Management
- Create and manage invoices with line items
- Automatic invoice number generation
- Multiple invoice statuses (draft, sent, unpaid, paid, overdue, cancelled)
- Client information snapshots
- Tax and discount calculations

### Calculator System
- **5 Ready-to-Use Calculator Presets:**
  - Loan Calculator
  - KPR/Mortgage Calculator (Indonesian)
  - ROI Calculator
  - ROAS Calculator
  - Profit/Margin Calculator
- Custom formula calculator builder
- Safe expression parser (no eval())
- Frontend calculator rendering via shortcode

### Magic Link Access
- Secure, passwordless invoice access via CF7 Access Token
- No user accounts required
- Token-based authentication with expiration
- View invoice, download PDF, and pay online

### Payment Integration
- Integrated with CF7 MiniCommerce
- Support for multiple payment gateways (TriPay, PayPal, etc.)
- Automatic invoice status updates on payment
- Inline checkout support

### License Generation
- Automatic license key generation via CF7 License
- Generate licenses for licensed products on payment
- Email delivery of license keys
- Support for multiple licenses per invoice

### Email System
- Invoice sent notifications
- Payment reminders
- Payment confirmation with license keys
- HTML email templates

### Contact Form 7 Integration
- Create invoices from CF7 form submissions
- Field mapping configuration
- Conditional invoice creation
- Auto-send option

## Requirements

- WordPress 6.0 or higher
- PHP 7.4 or higher
- Contact Form 7
- CF7 Access Token
- CF7 License
- CF7 Mini Ecommerce

## Installation

1. Upload the `cf7-invplus` folder to `/wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Ensure all required plugins are installed and activated
4. Go to InvPlus → Settings to configure

## Usage

### Creating Invoices

1. Navigate to InvPlus → Invoices
2. Click "Add New"
3. Fill in client details and add line items
4. Save as draft or send immediately

### Using Calculators

Use the shortcode in any page or post:

```
[cf7invplus_calculator slug="loan-calculator"]
```

Available calculator slugs:
- `loan-calculator`
- `kpr-calculator`
- `roi-calculator`
- `roas-calculator`
- `profit-margin-calculator`

### Integrating with CF7 Forms

1. Edit your Contact Form 7 form
2. Configure CF7 InvPlus integration settings
3. Map CF7 fields to invoice fields
4. Enable auto-send if desired

## File Structure

```
cf7-invplus/
├── cf7-invplus.php          # Main plugin file
├── load.php                  # Autoloader and initialization
├── uninstall.php            # Cleanup on uninstall
├── includes/
│   ├── functions.php        # Helper functions
│   ├── core/                # Core classes
│   ├── database/            # Database schema
│   ├── integrations/        # Plugin integrations
│   ├── admin/               # Admin interface
│   ├── frontend/            # Frontend components
│   └── presets/             # Calculator presets
├── templates/               # View templates
└── assets/                  # CSS and JavaScript
```

## Hooks

### Actions

- `cf7invplus_invoice_created` - After invoice is created
- `cf7invplus_invoice_sent` - When invoice is sent
- `cf7invplus_invoice_paid` - When invoice is marked as paid
- `cf7invplus_licenses_generated` - After licenses are generated
- `cf7invplus_calculator_created` - After calculator is created

### Filters

- `cf7at_valid_related_types` - Register invoice as valid token type

## License

GPL v2 or later

## Support

For support, please visit the plugin documentation or contact support.
