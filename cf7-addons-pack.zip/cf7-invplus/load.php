<?php

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Autoloader
spl_autoload_register( 'cf7invplus_autoloader' );

function cf7invplus_autoloader( $class ) {
	// Only handle our namespace
	if ( strpos( $class, 'CF7InvPlus\\' ) !== 0 ) {
		return;
	}
	
	// Remove namespace prefix
	$class = substr( $class, 11 );
	
	// Convert namespace separators to directory separators
	$class = str_replace( '\\', DIRECTORY_SEPARATOR, $class );
	
	// Convert to lowercase and add .php extension
	$file = CF7INVPLUS_PLUGIN_DIR . '/includes/' . strtolower( $class ) . '.php';
	
	if ( file_exists( $file ) ) {
		require_once $file;
	}
}

// Load core files
require_once CF7INVPLUS_PLUGIN_DIR . '/includes/functions.php';

// Initialize plugin
function cf7invplus_init() {
	// Load text domain
	load_plugin_textdomain( CF7INVPLUS_TEXT_DOMAIN, false, dirname( CF7INVPLUS_PLUGIN_BASENAME ) . '/languages' );
	
	// Initialize core components
	CF7InvPlus\Core\Plugin::instance();
	
	// Initialize invoice manager
	CF7InvPlus\Core\InvoiceManager::instance();
	
	// Initialize calculator builder
	CF7InvPlus\Core\CalculatorBuilder::instance();
	
	// Initialize integrations
	CF7InvPlus\Integrations\MagicLinkIntegration::instance();
	CF7InvPlus\Integrations\LicenseIntegration::instance();
	CF7InvPlus\Integrations\PaymentIntegration::instance();
	CF7InvPlus\Integrations\CF7Listener::instance();
	
	// Initialize admin if in admin area
	if ( is_admin() ) {
		CF7InvPlus\Admin\AdminInit::instance();
	}
	
	// Initialize frontend
	CF7InvPlus\Frontend\InvoiceView::instance();
	CF7InvPlus\Frontend\CalculatorRender::instance();
	
	do_action( 'cf7invplus_init' );
}

// Hook plugin initialization
add_action( 'init', 'cf7invplus_plugin_init', 20 );

function cf7invplus_plugin_init() {
	// Register rewrite rules for invoice access
	add_rewrite_rule( 
		'^invoice/([^/]+)/?$', 
		'index.php?cf7invplus_invoice=1&token=$matches[1]', 
		'top' 
	);
	
	// Add query vars
	add_filter( 'query_vars', function( $vars ) {
		$vars[] = 'cf7invplus_invoice';
		$vars[] = 'token';
		return $vars;
	});
	
	// Register shortcodes
	add_shortcode( 'cf7invplus_calculator', array( 'CF7InvPlus\Frontend\CalculatorRender', 'render_shortcode' ) );
}
