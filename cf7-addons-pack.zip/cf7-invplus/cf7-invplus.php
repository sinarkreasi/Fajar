<?php
/*
 * Plugin Name: CF7 Invoice Plus
 * Plugin URI: https://github.com/cf7-invplus/cf7-invplus
 * Description: Transform Contact Form 7 into a complete invoicing and calculation system with magic link access, payment processing, and license generation.
 * Author: CF7 InvPlus Team
 * Version: 1.0.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Text Domain: cf7-invplus
 * Domain Path: /languages
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Plugin version
define( 'CF7INVPLUS_VERSION', '1.0.0' );

// Plugin constants
define( 'CF7INVPLUS_PLUGIN_FILE', __FILE__ );
define( 'CF7INVPLUS_PLUGIN_BASENAME', plugin_basename( CF7INVPLUS_PLUGIN_FILE ) );
define( 'CF7INVPLUS_PLUGIN_DIR', untrailingslashit( dirname( CF7INVPLUS_PLUGIN_FILE ) ) );
define( 'CF7INVPLUS_PLUGIN_URL', untrailingslashit( plugins_url( '', CF7INVPLUS_PLUGIN_FILE ) ) );
define( 'CF7INVPLUS_TEXT_DOMAIN', 'cf7-invplus' );

// Database table names
define( 'CF7INVPLUS_INVOICES_TABLE', 'cf7_invoices' );
define( 'CF7INVPLUS_INVOICE_ITEMS_TABLE', 'cf7_invoice_items' );
define( 'CF7INVPLUS_ESTIMATOR_SNAPSHOTS_TABLE', 'cf7_estimator_snapshots' );
define( 'CF7INVPLUS_CALCULATORS_TABLE', 'cf7_calculators' );

// Check dependencies
add_action( 'plugins_loaded', 'cf7invplus_check_dependencies' );

function cf7invplus_check_dependencies() {
	$missing_plugins = array();
	
	// Check for Contact Form 7
	if ( ! class_exists( 'WPCF7' ) ) {
		$missing_plugins[] = 'Contact Form 7';
	}
	
	// Check for CF7 Access Token
	if ( ! defined( 'CF7AT_VERSION' ) ) {
		$missing_plugins[] = 'CF7 Access Token';
	}
	
	// Check for CF7 License
	if ( ! defined( 'CF7LICENSE_VERSION' ) ) {
		$missing_plugins[] = 'CF7 License';
	}
	
	// Check for CF7 MiniCommerce
	if ( ! defined( 'CF7MC_VERSION' ) ) {
		$missing_plugins[] = 'CF7 Mini Ecommerce';
	}
	
	if ( ! empty( $missing_plugins ) ) {
		add_action( 'admin_notices', function() use ( $missing_plugins ) {
			?>
			<div class="notice notice-error">
				<p><?php printf( 
					__( 'CF7 Invoice Plus requires the following plugins: %s', CF7INVPLUS_TEXT_DOMAIN ),
					implode( ', ', $missing_plugins )
				); ?></p>
			</div>
			<?php
		});
		return;
	}
	
	// Initialize plugin
	cf7invplus_init();
}

// Load plugin files
require_once CF7INVPLUS_PLUGIN_DIR . '/load.php';

// Plugin activation hook
register_activation_hook( CF7INVPLUS_PLUGIN_FILE, 'cf7invplus_activate' );

// Plugin deactivation hook
register_deactivation_hook( CF7INVPLUS_PLUGIN_FILE, 'cf7invplus_deactivate' );

/**
 * Plugin activation callback
 */
function cf7invplus_activate() {
	// Create database tables
	CF7InvPlus\Database\SchemaManager::create_tables();
	
	// Set default options
	CF7InvPlus\Core\OptionsManager::set_defaults();
	
	// Install calculator presets
	CF7InvPlus\Presets\CalculatorPresets::install_presets();
	
	// Flush rewrite rules
	flush_rewrite_rules();
}

/**
 * Plugin deactivation callback
 */
function cf7invplus_deactivate() {
	// Flush rewrite rules
	flush_rewrite_rules();
}
