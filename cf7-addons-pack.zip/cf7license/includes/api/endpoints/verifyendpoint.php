<?php

namespace CF7License\API\Endpoints;

use CF7License\API\RestController;
use CF7License\Core\LicenseValidator;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * License verification endpoint
 */
class VerifyEndpoint {
	
	/**
	 * Register routes
	 */
	public function register_routes() {
		register_rest_route(
			RestController::NAMESPACE,
			'/verify',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'verify_license' ),
				'permission_callback' => array( $this, 'check_permissions' ),
				'args'                => $this->get_endpoint_args(),
			)
		);
	}
	
	/**
	 * Verify license callback
	 *
	 * @param WP_REST_Request $request Request object
	 * @return WP_REST_Response|WP_Error
	 */
	public function verify_license( $request ) {
		// Validate required parameters
		$validation = RestController::validate_required_params( $request, array( 'license_key', 'domain' ) );
		if ( is_wp_error( $validation ) ) {
			return $validation;
		}
		
		$license_key = sanitize_text_field( $request->get_param( 'license_key' ) );
		$domain = sanitize_text_field( $request->get_param( 'domain' ) );
		$product_id = sanitize_text_field( $request->get_param( 'product_id' ) );
		
		// Validate license key format
		$validator = new LicenseValidator();
		$format_validation = $validator->validate_license_key_format( $license_key );
		
		if ( ! $format_validation['valid'] ) {
			return RestController::error_response( $format_validation['message'], 'invalid_license_key_format' );
		}
		
		// Verify license
		$result = $validator->verify_license( $license_key, $domain, $product_id );
		
		if ( ! $result['valid'] ) {
			return RestController::error_response( $result['message'], 'license_verification_failed' );
		}
		
		// Log successful verification
		cf7license_log( "License verified via API: {$license_key} for {$domain}" );
		
		// Format response
		$response_data = array(
			'valid'                 => true,
			'status'                => $result['status'],
			'expires_at'            => $result['expires_at'],
			'remaining_activations' => $result['remaining_activations'],
		);
		
		// Include license details if requested
		if ( $request->get_param( 'include_details' ) ) {
			$response_data['license'] = $result['license'];
		}
		
		return rest_ensure_response( RestController::success_response( $response_data ) );
	}
	
	/**
	 * Check permissions
	 *
	 * @param WP_REST_Request $request Request object
	 * @return bool|WP_Error
	 */
	public function check_permissions( $request ) {
		return RestController::validate_authentication( $request );
	}
	
	/**
	 * Get endpoint arguments
	 *
	 * @return array
	 */
	private function get_endpoint_args() {
		return array(
			'license_key' => array(
				'required'          => true,
				'type'              => 'string',
				'description'       => __( 'License key to verify', CF7LICENSE_TEXT_DOMAIN ),
				'sanitize_callback' => 'sanitize_text_field',
				'validate_callback' => function( $param ) {
					return ! empty( $param );
				},
			),
			'domain' => array(
				'required'          => true,
				'type'              => 'string',
				'description'       => __( 'Domain to verify license for', CF7LICENSE_TEXT_DOMAIN ),
				'sanitize_callback' => 'sanitize_text_field',
				'validate_callback' => function( $param ) {
					return ! empty( $param );
				},
			),
			'product_id' => array(
				'required'          => false,
				'type'              => 'string',
				'description'       => __( 'Product ID to verify license for', CF7LICENSE_TEXT_DOMAIN ),
				'sanitize_callback' => 'sanitize_text_field',
			),
			'include_details' => array(
				'required'          => false,
				'type'              => 'boolean',
				'description'       => __( 'Include detailed license information in response', CF7LICENSE_TEXT_DOMAIN ),
				'default'           => false,
			),
		);
	}
}