<?php

namespace CF7License\API\Endpoints;

use CF7License\API\RestController;
use CF7License\Core\ActivationManager;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * License activation endpoint
 */
class ActivateEndpoint {
	
	/**
	 * Register routes
	 */
	public function register_routes() {
		register_rest_route(
			RestController::NAMESPACE,
			'/activate',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'activate_license' ),
				'permission_callback' => array( $this, 'check_permissions' ),
				'args'                => $this->get_endpoint_args(),
			)
		);
	}
	
	/**
	 * Activate license callback
	 *
	 * @param WP_REST_Request $request Request object
	 * @return WP_REST_Response|WP_Error
	 */
	public function activate_license( $request ) {
		// Validate required parameters
		$validation = RestController::validate_required_params( $request, array( 'license_key', 'domain' ) );
		if ( is_wp_error( $validation ) ) {
			return $validation;
		}
		
		$license_key = sanitize_text_field( $request->get_param( 'license_key' ) );
		$domain = sanitize_text_field( $request->get_param( 'domain' ) );
		$product_id = sanitize_text_field( $request->get_param( 'product_id' ) );
		
		// Activate license
		$activation_manager = new ActivationManager();
		$result = $activation_manager->activate_license( $license_key, $domain, $product_id );
		
		if ( ! $result['success'] ) {
			return RestController::error_response( $result['message'], 'license_activation_failed' );
		}
		
		// Log successful activation
		cf7license_log( "License activated via API: {$license_key} for {$domain}" );
		
		// Format response
		$response_data = array(
			'activated' => true,
			'message'   => $result['message'],
		);
		
		// Include license details if available
		if ( isset( $result['license'] ) ) {
			$response_data['license'] = $result['license'];
		}
		
		return rest_ensure_response( RestController::success_response( $response_data ) );
	}
	
	/**
	 * Check permissions
	 *
	 * @param WP_REST_Request $request Request object
	 * @return bool|WP_Error
	 */
	public function check_permissions( $request ) {
		return RestController::validate_authentication( $request );
	}
	
	/**
	 * Get endpoint arguments
	 *
	 * @return array
	 */
	private function get_endpoint_args() {
		return array(
			'license_key' => array(
				'required'          => true,
				'type'              => 'string',
				'description'       => __( 'License key to activate', CF7LICENSE_TEXT_DOMAIN ),
				'sanitize_callback' => 'sanitize_text_field',
				'validate_callback' => function( $param ) {
					return ! empty( $param );
				},
			),
			'domain' => array(
				'required'          => true,
				'type'              => 'string',
				'description'       => __( 'Domain to activate license for', CF7LICENSE_TEXT_DOMAIN ),
				'sanitize_callback' => 'sanitize_text_field',
				'validate_callback' => function( $param ) {
					return ! empty( $param );
				},
			),
			'product_id' => array(
				'required'          => false,
				'type'              => 'string',
				'description'       => __( 'Product ID to activate license for', CF7LICENSE_TEXT_DOMAIN ),
				'sanitize_callback' => 'sanitize_text_field',
			),
		);
	}
}