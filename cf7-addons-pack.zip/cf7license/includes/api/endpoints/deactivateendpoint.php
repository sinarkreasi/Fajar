<?php

namespace CF7License\API\Endpoints;

use CF7License\API\RestController;
use CF7License\Core\ActivationManager;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * License deactivation endpoint
 */
class DeactivateEndpoint {
	
	/**
	 * Register routes
	 */
	public function register_routes() {
		register_rest_route(
			RestController::NAMESPACE,
			'/deactivate',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'deactivate_license' ),
				'permission_callback' => array( $this, 'check_permissions' ),
				'args'                => $this->get_endpoint_args(),
			)
		);
	}
	
	/**
	 * Deactivate license callback
	 *
	 * @param WP_REST_Request $request Request object
	 * @return WP_REST_Response|WP_Error
	 */
	public function deactivate_license( $request ) {
		// Validate required parameters
		$validation = RestController::validate_required_params( $request, array( 'license_key', 'domain' ) );
		if ( is_wp_error( $validation ) ) {
			return $validation;
		}
		
		$license_key = sanitize_text_field( $request->get_param( 'license_key' ) );
		$domain = sanitize_text_field( $request->get_param( 'domain' ) );
		
		// Deactivate license
		$activation_manager = new ActivationManager();
		$result = $activation_manager->deactivate_license( $license_key, $domain );
		
		if ( ! $result['success'] ) {
			return RestController::error_response( $result['message'], 'license_deactivation_failed' );
		}
		
		// Log successful deactivation
		cf7license_log( "License deactivated via API: {$license_key} for {$domain}" );
		
		// Format response
		$response_data = array(
			'deactivated' => true,
			'message'     => $result['message'],
		);
		
		return rest_ensure_response( RestController::success_response( $response_data ) );
	}
	
	/**
	 * Check permissions
	 *
	 * @param WP_REST_Request $request Request object
	 * @return bool|WP_Error
	 */
	public function check_permissions( $request ) {
		return RestController::validate_authentication( $request );
	}
	
	/**
	 * Get endpoint arguments
	 *
	 * @return array
	 */
	private function get_endpoint_args() {
		return array(
			'license_key' => array(
				'required'          => true,
				'type'              => 'string',
				'description'       => __( 'License key to deactivate', CF7LICENSE_TEXT_DOMAIN ),
				'sanitize_callback' => 'sanitize_text_field',
				'validate_callback' => function( $param ) {
					return ! empty( $param );
				},
			),
			'domain' => array(
				'required'          => true,
				'type'              => 'string',
				'description'       => __( 'Domain to deactivate license for', CF7LICENSE_TEXT_DOMAIN ),
				'sanitize_callback' => 'sanitize_text_field',
				'validate_callback' => function( $param ) {
					return ! empty( $param );
				},
			),
		);
	}
}