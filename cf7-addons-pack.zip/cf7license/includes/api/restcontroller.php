<?php

namespace CF7License\API;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * REST API controller class
 */
class RestController {
	
	/**
	 * Controller instance
	 *
	 * @var RestController
	 */
	private static $instance = null;
	
	/**
	 * API namespace
	 */
	const NAMESPACE = 'cf7-license/v1';
	
	/**
	 * Get controller instance
	 *
	 * @return RestController
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		$this->init_hooks();
	}
	
	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
		add_filter( 'rest_pre_dispatch', array( $this, 'check_rate_limit' ), 10, 3 );
	}
	
	/**
	 * Register REST API routes
	 */
	public function register_routes() {
		// Verify endpoint
		$verify_endpoint = new Endpoints\VerifyEndpoint();
		$verify_endpoint->register_routes();
		
		// Activate endpoint
		$activate_endpoint = new Endpoints\ActivateEndpoint();
		$activate_endpoint->register_routes();
		
		// Deactivate endpoint
		$deactivate_endpoint = new Endpoints\DeactivateEndpoint();
		$deactivate_endpoint->register_routes();
		
		cf7license_log( 'REST API routes registered' );
	}
	
	/**
	 * Check rate limit for API requests
	 *
	 * @param mixed $result Response to replace the requested version with
	 * @param WP_REST_Server $server Server instance
	 * @param WP_REST_Request $request Request used to generate the response
	 * @return mixed
	 */
	public function check_rate_limit( $result, $server, $request ) {
		// Only apply to our API endpoints
		if ( strpos( $request->get_route(), '/cf7-license/' ) === false ) {
			return $result;
		}
		
		// Check if rate limiting is enabled
		if ( ! cf7license_get_option( 'rate_limit_enabled', true ) ) {
			return $result;
		}
		
		$client_ip = cf7license_get_client_ip();
		$limit = cf7license_get_option( 'rate_limit_requests', 60 );
		$window = cf7license_get_option( 'rate_limit_window', 3600 );
		
		$rate_limit_key = 'cf7license_api_' . $client_ip;
		
		if ( ! cf7license_rate_limit_check( $rate_limit_key, $limit, $window ) ) {
			cf7license_log( "Rate limit exceeded for IP: {$client_ip}", 'warning' );
			
			return new \WP_Error(
				'cf7license_rate_limit_exceeded',
				__( 'Rate limit exceeded. Please try again later.', CF7LICENSE_TEXT_DOMAIN ),
				array( 'status' => 429 )
			);
		}
		
		return $result;
	}
	
	/**
	 * Validate API authentication
	 *
	 * @param WP_REST_Request $request Request object
	 * @return bool|WP_Error
	 */
	public static function validate_authentication( $request ) {
		// Check if API authentication is enabled
		if ( ! cf7license_get_option( 'api_authentication', false ) ) {
			return true; // No authentication required
		}
		
		$auth_header = $request->get_header( 'Authorization' );
		$api_key = $request->get_header( 'X-API-Key' );
		
		// Check for API key in header
		if ( ! empty( $api_key ) ) {
			$secret_key = cf7license_get_option( 'api_secret_key' );
			
			if ( hash_equals( $secret_key, $api_key ) ) {
				return true;
			}
		}
		
		// Check for Bearer token
		if ( ! empty( $auth_header ) && strpos( $auth_header, 'Bearer ' ) === 0 ) {
			$token = substr( $auth_header, 7 );
			$secret_key = cf7license_get_option( 'api_secret_key' );
			
			if ( hash_equals( $secret_key, $token ) ) {
				return true;
			}
		}
		
		cf7license_log( 'API authentication failed', 'warning' );
		
		return new \WP_Error(
			'cf7license_authentication_failed',
			__( 'Authentication failed.', CF7LICENSE_TEXT_DOMAIN ),
			array( 'status' => 401 )
		);
	}
	
	/**
	 * Validate required parameters
	 *
	 * @param WP_REST_Request $request Request object
	 * @param array $required_params Required parameters
	 * @return bool|WP_Error
	 */
	public static function validate_required_params( $request, $required_params ) {
		$missing_params = array();
		
		foreach ( $required_params as $param ) {
			if ( empty( $request->get_param( $param ) ) ) {
				$missing_params[] = $param;
			}
		}
		
		if ( ! empty( $missing_params ) ) {
			return new \WP_Error(
				'cf7license_missing_parameters',
				sprintf(
					__( 'Missing required parameters: %s', CF7LICENSE_TEXT_DOMAIN ),
					implode( ', ', $missing_params )
				),
				array( 'status' => 400 )
			);
		}
		
		return true;
	}
	
	/**
	 * Format success response
	 *
	 * @param mixed $data Response data
	 * @param string $message Success message
	 * @return array
	 */
	public static function success_response( $data = null, $message = '' ) {
		$response = array(
			'success' => true,
		);
		
		if ( ! empty( $message ) ) {
			$response['message'] = $message;
		}
		
		if ( $data !== null ) {
			$response['data'] = $data;
		}
		
		return $response;
	}
	
	/**
	 * Format error response
	 *
	 * @param string $message Error message
	 * @param string $code Error code
	 * @param int $status HTTP status code
	 * @return WP_Error
	 */
	public static function error_response( $message, $code = 'cf7license_error', $status = 400 ) {
		return new \WP_Error( $code, $message, array( 'status' => $status ) );
	}
}