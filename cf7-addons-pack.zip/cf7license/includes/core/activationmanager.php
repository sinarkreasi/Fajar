<?php

namespace CF7License\Core;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * License activation management class
 */
class ActivationManager {
	
	/**
	 * Activate license for domain
	 *
	 * @param string $license_key License key
	 * @param string $domain Domain
	 * @param string $product_id Product ID (optional)
	 * @return array Result array
	 */
	public function activate_license( $license_key, $domain, $product_id = '' ) {
		// Validate inputs
		if ( empty( $license_key ) || empty( $domain ) ) {
			return array(
				'success' => false,
				'message' => __( 'License key and domain are required.', CF7LICENSE_TEXT_DOMAIN ),
			);
		}
		
		// Sanitize domain
		$domain = cf7license_sanitize_domain( $domain );
		
		if ( ! cf7license_is_valid_domain( $domain ) ) {
			return array(
				'success' => false,
				'message' => __( 'Invalid domain format.', CF7LICENSE_TEXT_DOMAIN ),
			);
		}
		
		// Get license
		$license_manager = new LicenseManager();
		$license = $license_manager->get_license_by_key( $license_key );
		
		if ( ! $license ) {
			cf7license_log( "Activation failed: License not found - {$license_key}" );
			return array(
				'success' => false,
				'message' => __( 'License not found.', CF7LICENSE_TEXT_DOMAIN ),
			);
		}
		
		// Validate license
		$validator = new LicenseValidator();
		$validation = $validator->validate_license_for_activation( $license, $product_id );
		
		if ( ! $validation['valid'] ) {
			return array(
				'success' => false,
				'message' => $validation['message'],
			);
		}
		
		// Check if already activated for this domain
		if ( $this->is_domain_activated( $license['id'], $domain ) ) {
			return array(
				'success' => true,
				'message' => __( 'License already activated for this domain.', CF7LICENSE_TEXT_DOMAIN ),
				'license'  => $this->format_license_response( $license ),
			);
		}
		
		// Check activation limit
		if ( $license['activation_count'] >= $license['max_activations'] ) {
			cf7license_log( "Activation failed: Limit exceeded - {$license_key}" );
			return array(
				'success' => false,
				'message' => __( 'Maximum number of activations reached.', CF7LICENSE_TEXT_DOMAIN ),
			);
		}
		
		// Create activation record
		$activation_id = $this->create_activation_record( $license['id'], $domain );
		
		if ( ! $activation_id ) {
			return array(
				'success' => false,
				'message' => __( 'Failed to create activation record.', CF7LICENSE_TEXT_DOMAIN ),
			);
		}
		
		// Increment activation count
		$license_manager->increment_activation_count( $license['id'] );
		
		// Get updated license data
		$updated_license = $license_manager->get_license( $license['id'] );
		
		cf7license_log( "License activated: {$license_key} for domain {$domain}" );
		
		do_action( 'cf7_license_activated', $license['id'], $domain, $activation_id );
		
		return array(
			'success' => true,
			'message' => __( 'License activated successfully.', CF7LICENSE_TEXT_DOMAIN ),
			'license' => $this->format_license_response( $updated_license ),
		);
	}
	
	/**
	 * Deactivate license for domain
	 *
	 * @param string $license_key License key
	 * @param string $domain Domain
	 * @return array Result array
	 */
	public function deactivate_license( $license_key, $domain ) {
		// Validate inputs
		if ( empty( $license_key ) || empty( $domain ) ) {
			return array(
				'success' => false,
				'message' => __( 'License key and domain are required.', CF7LICENSE_TEXT_DOMAIN ),
			);
		}
		
		// Sanitize domain
		$domain = cf7license_sanitize_domain( $domain );
		
		// Get license
		$license_manager = new LicenseManager();
		$license = $license_manager->get_license_by_key( $license_key );
		
		if ( ! $license ) {
			return array(
				'success' => false,
				'message' => __( 'License not found.', CF7LICENSE_TEXT_DOMAIN ),
			);
		}
		
		// Check if activated for this domain
		$activation = $this->get_domain_activation( $license['id'], $domain );
		
		if ( ! $activation ) {
			return array(
				'success' => false,
				'message' => __( 'License not activated for this domain.', CF7LICENSE_TEXT_DOMAIN ),
			);
		}
		
		// Deactivate
		$success = $this->deactivate_domain( $license['id'], $domain );
		
		if ( ! $success ) {
			return array(
				'success' => false,
				'message' => __( 'Failed to deactivate license.', CF7LICENSE_TEXT_DOMAIN ),
			);
		}
		
		// Optionally decrement activation count
		$decrement_on_deactivation = apply_filters( 'cf7_license_decrement_on_deactivation', true );
		if ( $decrement_on_deactivation ) {
			$license_manager->decrement_activation_count( $license['id'] );
		}
		
		cf7license_log( "License deactivated: {$license_key} for domain {$domain}" );
		
		do_action( 'cf7_license_deactivated', $license['id'], $domain );
		
		return array(
			'success' => true,
			'message' => __( 'License deactivated successfully.', CF7LICENSE_TEXT_DOMAIN ),
		);
	}
	
	/**
	 * Get license activations
	 *
	 * @param int $license_id License ID
	 * @return array Activations
	 */
	public function get_license_activations( $license_id ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7LICENSE_ACTIVATIONS_TABLE;
		
		$activations = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table_name} WHERE license_id = %d AND deactivated_at IS NULL ORDER BY activated_at DESC",
				$license_id
			),
			ARRAY_A
		);
		
		// Decode metadata for each activation
		foreach ( $activations as &$activation ) {
			if ( ! empty( $activation['metadata'] ) ) {
				$activation['metadata'] = json_decode( $activation['metadata'], true );
			}
		}
		
		return $activations;
	}
	
	/**
	 * Check if domain is activated for license
	 *
	 * @param int $license_id License ID
	 * @param string $domain Domain
	 * @return bool
	 */
	private function is_domain_activated( $license_id, $domain ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7LICENSE_ACTIVATIONS_TABLE;
		
		$count = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$table_name} WHERE license_id = %d AND domain = %s AND deactivated_at IS NULL",
				$license_id,
				$domain
			)
		);
		
		return $count > 0;
	}
	
	/**
	 * Get domain activation record
	 *
	 * @param int $license_id License ID
	 * @param string $domain Domain
	 * @return array|null Activation record
	 */
	private function get_domain_activation( $license_id, $domain ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7LICENSE_ACTIVATIONS_TABLE;
		
		$activation = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$table_name} WHERE license_id = %d AND domain = %s AND deactivated_at IS NULL",
				$license_id,
				$domain
			),
			ARRAY_A
		);
		
		if ( $activation && ! empty( $activation['metadata'] ) ) {
			$activation['metadata'] = json_decode( $activation['metadata'], true );
		}
		
		return $activation;
	}
	
	/**
	 * Create activation record
	 *
	 * @param int $license_id License ID
	 * @param string $domain Domain
	 * @return int|false Activation ID or false on failure
	 */
	private function create_activation_record( $license_id, $domain ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7LICENSE_ACTIVATIONS_TABLE;
		
		$activation_data = array(
			'license_id'  => $license_id,
			'domain'      => $domain,
			'ip_address'  => cf7license_get_client_ip(),
			'user_agent'  => isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( $_SERVER['HTTP_USER_AGENT'] ) : '',
			'metadata'    => wp_json_encode( array(
				'activated_via' => 'api',
				'timestamp'     => time(),
			)),
		);
		
		$result = $wpdb->insert(
			$table_name,
			$activation_data,
			array(
				'%d', // license_id
				'%s', // domain
				'%s', // ip_address
				'%s', // user_agent
				'%s', // metadata
			)
		);
		
		if ( $result === false ) {
			cf7license_log( 'Failed to create activation record: ' . $wpdb->last_error, 'error' );
			return false;
		}
		
		return $wpdb->insert_id;
	}
	
	/**
	 * Deactivate domain
	 *
	 * @param int $license_id License ID
	 * @param string $domain Domain
	 * @return bool Success status
	 */
	private function deactivate_domain( $license_id, $domain ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7LICENSE_ACTIVATIONS_TABLE;
		
		$result = $wpdb->update(
			$table_name,
			array( 'deactivated_at' => current_time( 'mysql' ) ),
			array(
				'license_id' => $license_id,
				'domain'     => $domain,
			),
			array( '%s' ),
			array( '%d', '%s' )
		);
		
		return $result !== false;
	}
	
	/**
	 * Format license response for API
	 *
	 * @param array $license License data
	 * @return array Formatted response
	 */
	private function format_license_response( $license ) {
		return array(
			'license_key'           => $license['license_key'],
			'product_id'            => $license['product_id'],
			'status'                => $license['status'],
			'max_activations'       => $license['max_activations'],
			'activation_count'      => $license['activation_count'],
			'remaining_activations' => max( 0, $license['max_activations'] - $license['activation_count'] ),
			'expires_at'            => $license['expires_at'],
			'created_at'            => $license['created_at'],
		);
	}
}