<?php

namespace CF7License\Core;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * License validation class
 */
class LicenseValidator {
	
	/**
	 * Verify license
	 *
	 * @param string $license_key License key
	 * @param string $domain Domain
	 * @param string $product_id Product ID (optional)
	 * @return array Verification result
	 */
	public function verify_license( $license_key, $domain, $product_id = '' ) {
		// Validate inputs
		if ( empty( $license_key ) || empty( $domain ) ) {
			return array(
				'valid'   => false,
				'message' => __( 'License key and domain are required.', CF7LICENSE_TEXT_DOMAIN ),
			);
		}
		
		// Sanitize domain
		$domain = cf7license_sanitize_domain( $domain );
		
		if ( ! cf7license_is_valid_domain( $domain ) ) {
			return array(
				'valid'   => false,
				'message' => __( 'Invalid domain format.', CF7LICENSE_TEXT_DOMAIN ),
			);
		}
		
		// Get license
		$license_manager = new LicenseManager();
		$license = $license_manager->get_license_by_key( $license_key );
		
		if ( ! $license ) {
			cf7license_log( "Verification failed: License not found - {$license_key}" );
			return array(
				'valid'   => false,
				'message' => __( 'License not found.', CF7LICENSE_TEXT_DOMAIN ),
			);
		}
		
		// Validate license status and expiry
		$validation = $this->validate_license_status( $license );
		if ( ! $validation['valid'] ) {
			return $validation;
		}
		
		// Validate product ID if provided
		if ( ! empty( $product_id ) && $license['product_id'] !== $product_id ) {
			cf7license_log( "Verification failed: Product ID mismatch - {$license_key}" );
			return array(
				'valid'   => false,
				'message' => __( 'License not valid for this product.', CF7LICENSE_TEXT_DOMAIN ),
			);
		}
		
		// Check if domain is activated
		$activation_manager = new ActivationManager();
		$activations = $activation_manager->get_license_activations( $license['id'] );
		
		$domain_activated = false;
		foreach ( $activations as $activation ) {
			if ( $activation['domain'] === $domain ) {
				$domain_activated = true;
				break;
			}
		}
		
		if ( ! $domain_activated ) {
			cf7license_log( "Verification failed: Domain not activated - {$license_key} for {$domain}" );
			return array(
				'valid'   => false,
				'message' => __( 'License not activated for this domain.', CF7LICENSE_TEXT_DOMAIN ),
			);
		}
		
		cf7license_log( "License verified successfully: {$license_key} for {$domain}" );
		
		return array(
			'valid'                 => true,
			'status'                => $license['status'],
			'expires_at'            => $license['expires_at'],
			'remaining_activations' => max( 0, $license['max_activations'] - $license['activation_count'] ),
			'license'               => $this->format_license_response( $license ),
		);
	}
	
	/**
	 * Validate license for activation
	 *
	 * @param array $license License data
	 * @param string $product_id Product ID (optional)
	 * @return array Validation result
	 */
	public function validate_license_for_activation( $license, $product_id = '' ) {
		// Validate license status and expiry
		$validation = $this->validate_license_status( $license );
		if ( ! $validation['valid'] ) {
			return $validation;
		}
		
		// Validate product ID if provided
		if ( ! empty( $product_id ) && $license['product_id'] !== $product_id ) {
			return array(
				'valid'   => false,
				'message' => __( 'License not valid for this product.', CF7LICENSE_TEXT_DOMAIN ),
			);
		}
		
		return array(
			'valid'   => true,
			'message' => __( 'License is valid for activation.', CF7LICENSE_TEXT_DOMAIN ),
		);
	}
	
	/**
	 * Validate license status and expiry
	 *
	 * @param array $license License data
	 * @return array Validation result
	 */
	public function validate_license_status( $license ) {
		// Check if license is active
		if ( $license['status'] !== 'active' ) {
			$status_messages = array(
				'expired'   => __( 'License has expired.', CF7LICENSE_TEXT_DOMAIN ),
				'suspended' => __( 'License is suspended.', CF7LICENSE_TEXT_DOMAIN ),
				'revoked'   => __( 'License has been revoked.', CF7LICENSE_TEXT_DOMAIN ),
			);
			
			$message = isset( $status_messages[ $license['status'] ] ) 
				? $status_messages[ $license['status'] ] 
				: __( 'License is not active.', CF7LICENSE_TEXT_DOMAIN );
			
			return array(
				'valid'   => false,
				'message' => $message,
			);
		}
		
		// Check expiry date
		if ( ! empty( $license['expires_at'] ) && cf7license_is_expired( $license['expires_at'] ) ) {
			// Auto-update status to expired
			$license_manager = new LicenseManager();
			$license_manager->update_license_status( $license['id'], 'expired' );
			
			return array(
				'valid'   => false,
				'message' => __( 'License has expired.', CF7LICENSE_TEXT_DOMAIN ),
			);
		}
		
		return array(
			'valid'   => true,
			'message' => __( 'License is valid.', CF7LICENSE_TEXT_DOMAIN ),
		);
	}
	
	/**
	 * Validate license key format
	 *
	 * @param string $license_key License key
	 * @return array Validation result
	 */
	public function validate_license_key_format( $license_key ) {
		if ( empty( $license_key ) ) {
			return array(
				'valid'   => false,
				'message' => __( 'License key is required.', CF7LICENSE_TEXT_DOMAIN ),
			);
		}
		
		if ( ! cf7license_is_valid_key_format( $license_key ) ) {
			return array(
				'valid'   => false,
				'message' => __( 'Invalid license key format.', CF7LICENSE_TEXT_DOMAIN ),
			);
		}
		
		return array(
			'valid'   => true,
			'message' => __( 'License key format is valid.', CF7LICENSE_TEXT_DOMAIN ),
		);
	}
	
	/**
	 * Check if license can be activated
	 *
	 * @param array $license License data
	 * @param string $domain Domain
	 * @return array Check result
	 */
	public function can_activate_license( $license, $domain ) {
		// Validate license status
		$validation = $this->validate_license_status( $license );
		if ( ! $validation['valid'] ) {
			return $validation;
		}
		
		// Check if domain is already activated
		$activation_manager = new ActivationManager();
		$activations = $activation_manager->get_license_activations( $license['id'] );
		
		foreach ( $activations as $activation ) {
			if ( $activation['domain'] === $domain ) {
				return array(
					'valid'   => true,
					'message' => __( 'License already activated for this domain.', CF7LICENSE_TEXT_DOMAIN ),
					'already_activated' => true,
				);
			}
		}
		
		// Check activation limit
		if ( $license['activation_count'] >= $license['max_activations'] ) {
			return array(
				'valid'   => false,
				'message' => __( 'Maximum number of activations reached.', CF7LICENSE_TEXT_DOMAIN ),
			);
		}
		
		return array(
			'valid'   => true,
			'message' => __( 'License can be activated.', CF7LICENSE_TEXT_DOMAIN ),
			'already_activated' => false,
		);
	}
	
	/**
	 * Format license response for API
	 *
	 * @param array $license License data
	 * @return array Formatted response
	 */
	private function format_license_response( $license ) {
		return array(
			'license_key'           => $license['license_key'],
			'product_id'            => $license['product_id'],
			'status'                => $license['status'],
			'max_activations'       => $license['max_activations'],
			'activation_count'      => $license['activation_count'],
			'remaining_activations' => max( 0, $license['max_activations'] - $license['activation_count'] ),
			'expires_at'            => $license['expires_at'],
			'created_at'            => $license['created_at'],
		);
	}
}