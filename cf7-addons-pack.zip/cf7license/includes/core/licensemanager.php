<?php

namespace CF7License\Core;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * License management class
 */
class LicenseManager {
	
	/**
	 * Create new license
	 *
	 * @param array $license_data License data
	 * @return int|false License ID or false on failure
	 */
	public function create_license( $license_data ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7LICENSE_LICENSES_TABLE;
		
		// Generate unique license key
		$license_key = $this->generate_unique_license_key();
		
		// Set defaults
		$defaults = array(
			'license_key'      => $license_key,
			'product_id'       => '',
			'email'            => '',
			'status'           => 'active',
			'max_activations'  => cf7license_get_max_activations(),
			'activation_count' => 0,
			'expires_at'       => null,
			'order_id'         => null,
			'metadata'         => null,
		);
		
		$license_data = wp_parse_args( $license_data, $defaults );
		
		// Validate required fields
		if ( empty( $license_data['product_id'] ) || empty( $license_data['email'] ) ) {
			cf7license_log( 'Failed to create license: missing required fields', 'error' );
			return false;
		}
		
		// Sanitize data
		$license_data['email'] = cf7license_sanitize_email( $license_data['email'] );
		$license_data['product_id'] = sanitize_text_field( $license_data['product_id'] );
		$license_data['status'] = sanitize_text_field( $license_data['status'] );
		$license_data['max_activations'] = absint( $license_data['max_activations'] );
		$license_data['order_id'] = ! empty( $license_data['order_id'] ) ? absint( $license_data['order_id'] ) : null;
		
		// Calculate expiry if not set
		if ( $license_data['expires_at'] === null ) {
			$license_data['expires_at'] = cf7license_calculate_expiry( $license_data['product_id'], $license_data );
		}
		
		// Ensure metadata is JSON
		if ( is_array( $license_data['metadata'] ) ) {
			$license_data['metadata'] = wp_json_encode( $license_data['metadata'] );
		}
		
		$result = $wpdb->insert(
			$table_name,
			$license_data,
			array(
				'%s', // license_key
				'%s', // product_id
				'%s', // email
				'%s', // status
				'%d', // max_activations
				'%d', // activation_count
				'%s', // expires_at
				'%d', // order_id
				'%s', // metadata
			)
		);
		
		if ( $result === false ) {
			cf7license_log( 'Failed to create license: ' . $wpdb->last_error, 'error' );
			return false;
		}
		
		$license_id = $wpdb->insert_id;
		
		cf7license_log( "License created: ID {$license_id}, Key {$license_key}" );
		
		do_action( 'cf7_license_created', $license_id, $license_data );
		
		return $license_id;
	}
	
	/**
	 * Get license by ID
	 *
	 * @param int $license_id License ID
	 * @return array|null License data
	 */
	public function get_license( $license_id ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7LICENSE_LICENSES_TABLE;
		
		$license = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table_name} WHERE id = %d", $license_id ),
			ARRAY_A
		);
		
		if ( $license && ! empty( $license['metadata'] ) ) {
			$license['metadata'] = json_decode( $license['metadata'], true );
		}
		
		return $license;
	}
	
	/**
	 * Get license by key
	 *
	 * @param string $license_key License key
	 * @return array|null License data
	 */
	public function get_license_by_key( $license_key ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7LICENSE_LICENSES_TABLE;
		
		$license = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table_name} WHERE license_key = %s", $license_key ),
			ARRAY_A
		);
		
		if ( $license && ! empty( $license['metadata'] ) ) {
			$license['metadata'] = json_decode( $license['metadata'], true );
		}
		
		return $license;
	}
	
	/**
	 * Get licenses by email
	 *
	 * @param string $email Email address
	 * @return array Licenses
	 */
	public function get_licenses_by_email( $email ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7LICENSE_LICENSES_TABLE;
		$email = cf7license_sanitize_email( $email );
		
		$licenses = $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM {$table_name} WHERE email = %s ORDER BY created_at DESC", $email ),
			ARRAY_A
		);
		
		// Decode metadata for each license
		foreach ( $licenses as &$license ) {
			if ( ! empty( $license['metadata'] ) ) {
				$license['metadata'] = json_decode( $license['metadata'], true );
			}
		}
		
		return $licenses;
	}
	
	/**
	 * Update license status
	 *
	 * @param int $license_id License ID
	 * @param string $status New status
	 * @return bool Success status
	 */
	public function update_license_status( $license_id, $status ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7LICENSE_LICENSES_TABLE;
		
		$valid_statuses = array( 'active', 'expired', 'suspended', 'revoked' );
		if ( ! in_array( $status, $valid_statuses ) ) {
			return false;
		}
		
		$result = $wpdb->update(
			$table_name,
			array( 'status' => $status ),
			array( 'id' => $license_id ),
			array( '%s' ),
			array( '%d' )
		);
		
		if ( $result !== false ) {
			cf7license_log( "License {$license_id} status updated to {$status}" );
			
			do_action( 'cf7_license_status_updated', $license_id, $status );
			
			// Fire specific status hooks
			switch ( $status ) {
				case 'expired':
					do_action( 'cf7_license_expired', $license_id );
					break;
				case 'suspended':
					do_action( 'cf7_license_suspended', $license_id );
					break;
				case 'revoked':
					do_action( 'cf7_license_revoked', $license_id );
					break;
			}
			
			return true;
		}
		
		return false;
	}
	
	/**
	 * Extend license expiration
	 *
	 * @param int $license_id License ID
	 * @param string $new_expiry New expiry date
	 * @return bool Success status
	 */
	public function extend_license( $license_id, $new_expiry ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7LICENSE_LICENSES_TABLE;
		
		$result = $wpdb->update(
			$table_name,
			array( 'expires_at' => $new_expiry ),
			array( 'id' => $license_id ),
			array( '%s' ),
			array( '%d' )
		);
		
		if ( $result !== false ) {
			cf7license_log( "License {$license_id} extended to {$new_expiry}" );
			do_action( 'cf7_license_extended', $license_id, $new_expiry );
			return true;
		}
		
		return false;
	}
	
	/**
	 * Increment activation count
	 *
	 * @param int $license_id License ID
	 * @return bool Success status
	 */
	public function increment_activation_count( $license_id ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7LICENSE_LICENSES_TABLE;
		
		$result = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table_name} SET activation_count = activation_count + 1 WHERE id = %d",
				$license_id
			)
		);
		
		return $result !== false;
	}
	
	/**
	 * Decrement activation count
	 *
	 * @param int $license_id License ID
	 * @return bool Success status
	 */
	public function decrement_activation_count( $license_id ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7LICENSE_LICENSES_TABLE;
		
		$result = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table_name} SET activation_count = GREATEST(0, activation_count - 1) WHERE id = %d",
				$license_id
			)
		);
		
		return $result !== false;
	}
	
	/**
	 * Get licenses with pagination
	 *
	 * @param array $args Query arguments
	 * @return array Licenses and pagination data
	 */
	public function get_licenses( $args = array() ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7LICENSE_LICENSES_TABLE;
		
		$defaults = array(
			'status'     => '',
			'product_id' => '',
			'email'      => '',
			'per_page'   => 20,
			'page'       => 1,
			'orderby'    => 'created_at',
			'order'      => 'DESC',
		);
		
		$args = wp_parse_args( $args, $defaults );
		
		$where = '1=1';
		$where_values = array();
		
		if ( ! empty( $args['status'] ) ) {
			$where .= ' AND status = %s';
			$where_values[] = $args['status'];
		}
		
		if ( ! empty( $args['product_id'] ) ) {
			$where .= ' AND product_id = %s';
			$where_values[] = $args['product_id'];
		}
		
		if ( ! empty( $args['email'] ) ) {
			$where .= ' AND email LIKE %s';
			$where_values[] = '%' . $wpdb->esc_like( $args['email'] ) . '%';
		}
		
		$offset = ( $args['page'] - 1 ) * $args['per_page'];
		
		$query = "SELECT * FROM {$table_name} WHERE {$where} ORDER BY {$args['orderby']} {$args['order']} LIMIT %d OFFSET %d";
		$where_values[] = $args['per_page'];
		$where_values[] = $offset;
		
		$licenses = $wpdb->get_results(
			$wpdb->prepare( $query, $where_values ),
			ARRAY_A
		);
		
		// Decode metadata JSON for each license
		foreach ( $licenses as &$license ) {
			if ( ! empty( $license['metadata'] ) ) {
				$license['metadata'] = json_decode( $license['metadata'], true );
			}
		}
		
		// Get total count
		$count_query = "SELECT COUNT(*) FROM {$table_name} WHERE {$where}";
		$count_values = array_slice( $where_values, 0, -2 ); // Remove LIMIT and OFFSET values
		
		if ( ! empty( $count_values ) ) {
			$total = $wpdb->get_var(
				$wpdb->prepare( $count_query, $count_values )
			);
		} else {
			$total = $wpdb->get_var( $count_query );
		}
		
		return array(
			'licenses' => $licenses,
			'total'    => $total,
		);
	}
	
	/**
	 * Generate unique license key
	 *
	 * @return string Unique license key
	 */
	private function generate_unique_license_key() {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7LICENSE_LICENSES_TABLE;
		$max_attempts = 10;
		
		for ( $i = 0; $i < $max_attempts; $i++ ) {
			$license_key = cf7license_generate_license_key();
			
			// Check if key already exists
			$exists = $wpdb->get_var(
				$wpdb->prepare( "SELECT COUNT(*) FROM {$table_name} WHERE license_key = %s", $license_key )
			);
			
			if ( ! $exists ) {
				return $license_key;
			}
		}
		
		// Fallback: add timestamp to ensure uniqueness
		$license_key = cf7license_generate_license_key();
		$timestamp = time();
		
		return $license_key . '-' . $timestamp;
	}
}