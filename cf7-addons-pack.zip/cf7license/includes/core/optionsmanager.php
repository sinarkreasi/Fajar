<?php

namespace CF7License\Core;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Options management class
 */
class OptionsManager {
	
	/**
	 * Option prefix
	 */
	const OPTION_PREFIX = 'cf7license_';
	
	/**
	 * Default options
	 */
	private static $defaults = array(
		'debug_mode'              => false,
		'rate_limit_enabled'      => true,
		'rate_limit_requests'     => 60,
		'rate_limit_window'       => 3600,
		'auto_cleanup_expired'    => true,
		'cleanup_schedule'        => 'daily',
		'default_max_activations' => CF7LICENSE_DEFAULT_MAX_ACTIVATIONS,
		'api_authentication'      => false,
		'api_secret_key'          => '',
		'license_key_format'      => 'XXXX-XXXX-XXXX-XXXX',
	);
	
	/**
	 * Get option value
	 *
	 * @param string $key Option key
	 * @param mixed $default Default value
	 * @return mixed
	 */
	public static function get( $key, $default = null ) {
		$option_name = self::OPTION_PREFIX . $key;
		
		if ( $default === null && isset( self::$defaults[ $key ] ) ) {
			$default = self::$defaults[ $key ];
		}
		
		return get_option( $option_name, $default );
	}
	
	/**
	 * Set option value
	 *
	 * @param string $key Option key
	 * @param mixed $value Option value
	 * @return bool
	 */
	public static function set( $key, $value ) {
		$option_name = self::OPTION_PREFIX . $key;
		return update_option( $option_name, $value );
	}
	
	/**
	 * Delete option
	 *
	 * @param string $key Option key
	 * @return bool
	 */
	public static function delete( $key ) {
		$option_name = self::OPTION_PREFIX . $key;
		return delete_option( $option_name );
	}
	
	/**
	 * Get all options
	 *
	 * @return array
	 */
	public static function get_all() {
		$options = array();
		
		foreach ( self::$defaults as $key => $default ) {
			$options[ $key ] = self::get( $key, $default );
		}
		
		return $options;
	}
	
	/**
	 * Get options (alias for get_all for backward compatibility)
	 *
	 * @return array
	 */
	public static function get_options() {
		return self::get_all();
	}
	
	/**
	 * Set default options
	 */
	public static function set_defaults() {
		foreach ( self::$defaults as $key => $value ) {
			$option_name = self::OPTION_PREFIX . $key;
			
			// Only set if option doesn't exist
			if ( get_option( $option_name ) === false ) {
				// Generate API secret key if needed
				if ( $key === 'api_secret_key' && empty( $value ) ) {
					$value = wp_generate_password( 32, false );
				}
				
				update_option( $option_name, $value );
			}
		}
	}
	
	/**
	 * Reset all options to defaults
	 */
	public static function reset_to_defaults() {
		foreach ( self::$defaults as $key => $value ) {
			// Generate new API secret key
			if ( $key === 'api_secret_key' && empty( $value ) ) {
				$value = wp_generate_password( 32, false );
			}
			
			self::set( $key, $value );
		}
	}
	
	/**
	 * Get default options
	 *
	 * @return array
	 */
	public static function get_defaults() {
		return self::$defaults;
	}
	
	/**
	 * Validate option value
	 *
	 * @param string $key Option key
	 * @param mixed $value Option value
	 * @return mixed Validated value
	 */
	public static function validate( $key, $value ) {
		switch ( $key ) {
			case 'debug_mode':
			case 'rate_limit_enabled':
			case 'auto_cleanup_expired':
			case 'api_authentication':
				return (bool) $value;
				
			case 'rate_limit_requests':
			case 'rate_limit_window':
			case 'default_max_activations':
				return max( 1, absint( $value ) );
				
			case 'cleanup_schedule':
				$valid_schedules = array( 'hourly', 'daily', 'weekly' );
				return in_array( $value, $valid_schedules ) ? $value : 'daily';
				
			case 'license_key_format':
				// Validate format pattern
				if ( ! preg_match( '/^[X\-]+$/', $value ) ) {
					return 'XXXX-XXXX-XXXX-XXXX';
				}
				return $value;
				
			case 'api_secret_key':
				return sanitize_text_field( $value );
				
			default:
				return $value;
		}
	}
	
	/**
	 * Update multiple options at once
	 *
	 * @param array $options Key-value pairs
	 * @return bool
	 */
	public static function update_multiple( $options ) {
		$success = true;
		
		foreach ( $options as $key => $value ) {
			$validated_value = self::validate( $key, $value );
			
			if ( ! self::set( $key, $validated_value ) ) {
				$success = false;
			}
		}
		
		return $success;
	}
}