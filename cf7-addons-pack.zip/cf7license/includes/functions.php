<?php

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Generate cryptographically secure license key
 *
 * @return string License key
 */
function cf7license_generate_license_key() {
	$format = apply_filters( 'cf7_license_key_format', 'XXXX-XXXX-XXXX-XXXX' );
	
	// Generate random bytes
	$bytes = random_bytes( CF7LICENSE_KEY_LENGTH / 2 );
	$hex = strtoupper( bin2hex( $bytes ) );
	
	// Format the key according to the pattern
	$key = '';
	$hex_pos = 0;
	
	for ( $i = 0; $i < strlen( $format ); $i++ ) {
		if ( $format[ $i ] === 'X' ) {
			$key .= $hex[ $hex_pos ];
			$hex_pos++;
		} else {
			$key .= $format[ $i ];
		}
	}
	
	return $key;
}

/**
 * Validate license key format
 *
 * @param string $license_key License key to validate
 * @return bool
 */
function cf7license_is_valid_key_format( $license_key ) {
	$format = apply_filters( 'cf7_license_key_format', 'XXXX-XXXX-XXXX-XXXX' );
	$pattern = str_replace( 'X', '[A-F0-9]', $format );
	$pattern = '/^' . str_replace( '-', '\\-', $pattern ) . '$/';
	
	return preg_match( $pattern, $license_key );
}

/**
 * Get license option
 *
 * @param string $key Option key
 * @param mixed $default Default value
 * @return mixed
 */
function cf7license_get_option( $key, $default = false ) {
	return CF7License\Core\OptionsManager::get( $key, $default );
}

/**
 * Update license option
 *
 * @param string $key Option key
 * @param mixed $value Option value
 * @return bool
 */
function cf7license_update_option( $key, $value ) {
	return CF7License\Core\OptionsManager::set( $key, $value );
}

/**
 * Log license message
 *
 * @param string $message Log message
 * @param string $level Log level (info, warning, error)
 */
function cf7license_log( $message, $level = 'info' ) {
	if ( ! cf7license_get_option( 'debug_mode', false ) ) {
		return;
	}
	
	$log_entry = sprintf(
		'[%s] CF7License %s: %s',
		current_time( 'Y-m-d H:i:s' ),
		strtoupper( $level ),
		$message
	);
	
	error_log( $log_entry );
}

/**
 * Sanitize email for license system
 *
 * @param string $email Raw email
 * @return string Sanitized email
 */
function cf7license_sanitize_email( $email ) {
	return sanitize_email( strtolower( trim( $email ) ) );
}

/**
 * Validate email format
 *
 * @param string $email Email to validate
 * @return bool
 */
function cf7license_is_valid_email( $email ) {
	return is_email( $email );
}

/**
 * Sanitize domain name
 *
 * @param string $domain Raw domain
 * @return string Sanitized domain
 */
function cf7license_sanitize_domain( $domain ) {
	// Remove protocol
	$domain = preg_replace( '/^https?:\/\//', '', $domain );
	
	// Remove www prefix
	$domain = preg_replace( '/^www\./', '', $domain );
	
	// Remove trailing slash and path
	$domain = strtok( $domain, '/' );
	
	// Convert to lowercase
	$domain = strtolower( trim( $domain ) );
	
	return $domain;
}

/**
 * Validate domain format
 *
 * @param string $domain Domain to validate
 * @return bool
 */
function cf7license_is_valid_domain( $domain ) {
	return filter_var( $domain, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME );
}

/**
 * Get license statuses
 *
 * @return array
 */
function cf7license_get_license_statuses() {
	return array(
		'active'    => __( 'Active', CF7LICENSE_TEXT_DOMAIN ),
		'expired'   => __( 'Expired', CF7LICENSE_TEXT_DOMAIN ),
		'suspended' => __( 'Suspended', CF7LICENSE_TEXT_DOMAIN ),
		'revoked'   => __( 'Revoked', CF7LICENSE_TEXT_DOMAIN ),
	);
}

/**
 * Format date for display
 *
 * @param string $date MySQL datetime
 * @return string Formatted date
 */
function cf7license_format_date( $date ) {
	if ( empty( $date ) || $date === '0000-00-00 00:00:00' ) {
		return __( 'Never', CF7LICENSE_TEXT_DOMAIN );
	}
	
	return date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $date ) );
}

/**
 * Check if license is expired
 *
 * @param string $expires_at MySQL datetime
 * @return bool
 */
function cf7license_is_expired( $expires_at ) {
	if ( empty( $expires_at ) || $expires_at === '0000-00-00 00:00:00' ) {
		return false; // No expiration date
	}
	
	return strtotime( $expires_at ) < time();
}

/**
 * Get default max activations
 *
 * @param string $product_id Product ID
 * @return int
 */
function cf7license_get_max_activations( $product_id = '' ) {
	$default = CF7LICENSE_DEFAULT_MAX_ACTIVATIONS;
	
	if ( ! empty( $product_id ) ) {
		$default = apply_filters( 'cf7_license_max_activations', $default, $product_id );
	}
	
	return $default;
}

/**
 * Calculate license expiry date
 *
 * @param string $product_id Product ID
 * @param array $order_data Order data
 * @return string|null MySQL datetime or null for no expiry
 */
function cf7license_calculate_expiry( $product_id, $order_data = array() ) {
	$expiry_rules = apply_filters( 'cf7_license_expiry_rules', array(), $product_id, $order_data );
	
	if ( empty( $expiry_rules ) || ! isset( $expiry_rules['type'] ) ) {
		return null; // No expiry
	}
	
	$now = time();
	
	switch ( $expiry_rules['type'] ) {
		case 'days':
			$days = isset( $expiry_rules['value'] ) ? absint( $expiry_rules['value'] ) : 365;
			return date( 'Y-m-d H:i:s', $now + ( $days * DAY_IN_SECONDS ) );
			
		case 'months':
			$months = isset( $expiry_rules['value'] ) ? absint( $expiry_rules['value'] ) : 12;
			return date( 'Y-m-d H:i:s', strtotime( "+{$months} months", $now ) );
			
		case 'years':
			$years = isset( $expiry_rules['value'] ) ? absint( $expiry_rules['value'] ) : 1;
			return date( 'Y-m-d H:i:s', strtotime( "+{$years} years", $now ) );
			
		case 'date':
			if ( isset( $expiry_rules['value'] ) && strtotime( $expiry_rules['value'] ) ) {
				return date( 'Y-m-d H:i:s', strtotime( $expiry_rules['value'] ) );
			}
			break;
	}
	
	return null;
}

/**
 * Create license from order data
 *
 * @param array $order_data Order data
 * @return int|false License ID or false on failure
 */
function cf7license_create_license( $order_data ) {
	$license_manager = new CF7License\Core\LicenseManager();
	return $license_manager->create_license( $order_data );
}

/**
 * Get license by key
 *
 * @param string $license_key License key
 * @return array|null License data
 */
function cf7license_get_license( $license_key ) {
	$license_manager = new CF7License\Core\LicenseManager();
	return $license_manager->get_license_by_key( $license_key );
}

/**
 * Activate license for domain
 *
 * @param string $license_key License key
 * @param string $domain Domain
 * @param string $product_id Product ID
 * @return array Result array
 */
function cf7license_activate_license( $license_key, $domain, $product_id = '' ) {
	$activation_manager = new CF7License\Core\ActivationManager();
	return $activation_manager->activate_license( $license_key, $domain, $product_id );
}

/**
 * Deactivate license for domain
 *
 * @param string $license_key License key
 * @param string $domain Domain
 * @return array Result array
 */
function cf7license_deactivate_license( $license_key, $domain ) {
	$activation_manager = new CF7License\Core\ActivationManager();
	return $activation_manager->deactivate_license( $license_key, $domain );
}

/**
 * Verify license
 *
 * @param string $license_key License key
 * @param string $domain Domain
 * @param string $product_id Product ID
 * @return array Verification result
 */
function cf7license_verify_license( $license_key, $domain, $product_id = '' ) {
	$validator = new CF7License\Core\LicenseValidator();
	return $validator->verify_license( $license_key, $domain, $product_id );
}

/**
 * Get licenses by email
 *
 * @param string $email Email address
 * @return array Licenses
 */
function cf7license_get_licenses_by_email( $email ) {
	$license_manager = new CF7License\Core\LicenseManager();
	return $license_manager->get_licenses_by_email( $email );
}

/**
 * Rate limit check for API endpoints
 *
 * @param string $key Rate limit key
 * @param int $limit Request limit
 * @param int $window Time window in seconds
 * @return bool True if within limit
 */
function cf7license_rate_limit_check( $key, $limit = 60, $window = 3600 ) {
	$transient_key = 'cf7license_rate_limit_' . md5( $key );
	$requests = get_transient( $transient_key );
	
	if ( $requests === false ) {
		set_transient( $transient_key, 1, $window );
		return true;
	}
	
	if ( $requests >= $limit ) {
		return false;
	}
	
	set_transient( $transient_key, $requests + 1, $window );
	return true;
}

/**
 * Get client IP address
 *
 * @return string Client IP
 */
function cf7license_get_client_ip() {
	$ip_keys = array( 'HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR' );
	
	foreach ( $ip_keys as $key ) {
		if ( array_key_exists( $key, $_SERVER ) === true ) {
			foreach ( explode( ',', $_SERVER[ $key ] ) as $ip ) {
				$ip = trim( $ip );
				
				if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) !== false ) {
					return $ip;
				}
			}
		}
	}
	
	return isset( $_SERVER['REMOTE_ADDR'] ) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
}