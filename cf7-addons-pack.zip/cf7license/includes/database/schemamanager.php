<?php

namespace CF7License\Database;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Database schema management class
 */
class SchemaManager {
	
	/**
	 * Create database tables
	 */
	public static function create_tables() {
		global $wpdb;
		
		$charset_collate = $wpdb->get_charset_collate();
		
		// Licenses table
		$licenses_table = $wpdb->prefix . CF7LICENSE_LICENSES_TABLE;
		$licenses_sql = "CREATE TABLE $licenses_table (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			license_key varchar(64) NOT NULL,
			product_id varchar(100) NOT NULL,
			email varchar(100) NOT NULL,
			status enum('active','expired','suspended','revoked') NOT NULL DEFAULT 'active',
			max_activations int(10) unsigned NOT NULL DEFAULT 3,
			activation_count int(10) unsigned NOT NULL DEFAULT 0,
			expires_at datetime NULL,
			order_id bigint(20) unsigned NULL,
			metadata longtext NULL,
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY (id),
			UNIQUE KEY license_key (license_key),
			KEY product_id (product_id),
			KEY email (email),
			KEY status (status),
			KEY expires_at (expires_at),
			KEY order_id (order_id),
			KEY created_at (created_at)
		) $charset_collate;";
		
		// License activations table
		$activations_table = $wpdb->prefix . CF7LICENSE_ACTIVATIONS_TABLE;
		$activations_sql = "CREATE TABLE $activations_table (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			license_id bigint(20) unsigned NOT NULL,
			domain varchar(255) NOT NULL,
			activated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			deactivated_at datetime NULL,
			ip_address varchar(45) NULL,
			user_agent text NULL,
			metadata longtext NULL,
			PRIMARY KEY (id),
			KEY license_id (license_id),
			KEY domain (domain),
			KEY activated_at (activated_at),
			KEY deactivated_at (deactivated_at),
			UNIQUE KEY license_domain (license_id, domain),
			FOREIGN KEY (license_id) REFERENCES $licenses_table(id) ON DELETE CASCADE
		) $charset_collate;";
		
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		
		dbDelta( $licenses_sql );
		dbDelta( $activations_sql );
		
		// Update database version
		update_option( 'cf7license_db_version', CF7LICENSE_VERSION );
		
		cf7license_log( 'Database tables created successfully' );
	}
	
	/**
	 * Drop database tables
	 */
	public static function drop_tables() {
		global $wpdb;
		
		$licenses_table = $wpdb->prefix . CF7LICENSE_LICENSES_TABLE;
		$activations_table = $wpdb->prefix . CF7LICENSE_ACTIVATIONS_TABLE;
		
		$wpdb->query( "DROP TABLE IF EXISTS $activations_table" );
		$wpdb->query( "DROP TABLE IF EXISTS $licenses_table" );
		
		delete_option( 'cf7license_db_version' );
		
		cf7license_log( 'Database tables dropped' );
	}
	
	/**
	 * Check if tables exist
	 *
	 * @return bool
	 */
	public static function tables_exist() {
		global $wpdb;
		
		$licenses_table = $wpdb->prefix . CF7LICENSE_LICENSES_TABLE;
		$activations_table = $wpdb->prefix . CF7LICENSE_ACTIVATIONS_TABLE;
		
		$licenses_exists = $wpdb->get_var( "SHOW TABLES LIKE '$licenses_table'" ) === $licenses_table;
		$activations_exists = $wpdb->get_var( "SHOW TABLES LIKE '$activations_table'" ) === $activations_table;
		
		return $licenses_exists && $activations_exists;
	}
	
	/**
	 * Get database version
	 *
	 * @return string
	 */
	public static function get_db_version() {
		return get_option( 'cf7license_db_version', '0.0.0' );
	}
	
	/**
	 * Check if database needs update
	 *
	 * @return bool
	 */
	public static function needs_update() {
		return version_compare( self::get_db_version(), CF7LICENSE_VERSION, '<' );
	}
	
	/**
	 * Update database schema
	 */
	public static function update_schema() {
		if ( self::needs_update() ) {
			self::create_tables();
		}
	}
	
	/**
	 * Clean up expired licenses
	 *
	 * @return int Number of licenses updated
	 */
	public static function cleanup_expired_licenses() {
		global $wpdb;
		
		$licenses_table = $wpdb->prefix . CF7LICENSE_LICENSES_TABLE;
		
		// Update expired licenses
		$updated = $wpdb->query(
			"UPDATE $licenses_table 
			SET status = 'expired' 
			WHERE status = 'active' 
			AND expires_at IS NOT NULL 
			AND expires_at < NOW()"
		);
		
		cf7license_log( "Cleaned up {$updated} expired licenses" );
		
		return $updated;
	}
	
	/**
	 * Get table statistics
	 *
	 * @return array
	 */
	public static function get_table_stats() {
		global $wpdb;
		
		$licenses_table = $wpdb->prefix . CF7LICENSE_LICENSES_TABLE;
		$activations_table = $wpdb->prefix . CF7LICENSE_ACTIVATIONS_TABLE;
		
		$stats = array();
		
		// License statistics
		$stats['licenses'] = array(
			'total'     => $wpdb->get_var( "SELECT COUNT(*) FROM $licenses_table" ),
			'active'    => $wpdb->get_var( "SELECT COUNT(*) FROM $licenses_table WHERE status = 'active'" ),
			'expired'   => $wpdb->get_var( "SELECT COUNT(*) FROM $licenses_table WHERE status = 'expired'" ),
			'suspended' => $wpdb->get_var( "SELECT COUNT(*) FROM $licenses_table WHERE status = 'suspended'" ),
			'revoked'   => $wpdb->get_var( "SELECT COUNT(*) FROM $licenses_table WHERE status = 'revoked'" ),
		);
		
		// Activation statistics
		$stats['activations'] = array(
			'total'  => $wpdb->get_var( "SELECT COUNT(*) FROM $activations_table" ),
			'active' => $wpdb->get_var( "SELECT COUNT(*) FROM $activations_table WHERE deactivated_at IS NULL" ),
			'today'  => $wpdb->get_var( "SELECT COUNT(*) FROM $activations_table WHERE DATE(activated_at) = CURDATE()" ),
		);
		
		return $stats;
	}
	
	/**
	 * Get license usage by product
	 *
	 * @return array
	 */
	public static function get_product_usage() {
		global $wpdb;
		
		$licenses_table = $wpdb->prefix . CF7LICENSE_LICENSES_TABLE;
		
		$results = $wpdb->get_results(
			"SELECT product_id, status, COUNT(*) as count 
			FROM $licenses_table 
			GROUP BY product_id, status 
			ORDER BY product_id, status",
			ARRAY_A
		);
		
		$usage = array();
		
		foreach ( $results as $row ) {
			$product_id = $row['product_id'];
			$status = $row['status'];
			$count = $row['count'];
			
			if ( ! isset( $usage[ $product_id ] ) ) {
				$usage[ $product_id ] = array(
					'active'    => 0,
					'expired'   => 0,
					'suspended' => 0,
					'revoked'   => 0,
					'total'     => 0,
				);
			}
			
			$usage[ $product_id ][ $status ] = $count;
			$usage[ $product_id ]['total'] += $count;
		}
		
		return $usage;
	}
}