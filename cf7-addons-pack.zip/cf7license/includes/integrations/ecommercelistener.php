<?php

namespace CF7License\Integrations;

use CF7License\Core\LicenseManager;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Ecommerce integration listener class
 */
class EcommerceListener {
	
	/**
	 * Listener instance
	 *
	 * @var EcommerceListener
	 */
	private static $instance = null;
	
	/**
	 * Get listener instance
	 *
	 * @return EcommerceListener
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		$this->init_hooks();
	}
	
	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		// Listen for CF7 Mini Ecommerce order paid events
		add_action( 'cf7mc_order_paid', array( $this, 'handle_order_paid' ), 10, 2 );
		
		// Listen for order status changes
		add_action( 'cf7mc_order_status_changed', array( $this, 'handle_order_status_change' ), 10, 3 );
		
		// Listen for subscription events (if available)
		add_action( 'cf7mc_subscription_cancelled', array( $this, 'handle_subscription_cancelled' ), 10, 2 );
		add_action( 'cf7mc_subscription_expired', array( $this, 'handle_subscription_expired' ), 10, 2 );
		
		// Generic order hooks for other ecommerce plugins
		add_action( 'cf7license_create_license_from_order', array( $this, 'create_license_from_order' ), 10, 1 );
	}
	
	/**
	 * Handle order paid event
	 *
	 * @param int $order_id Order ID
	 * @param array $order_data Order data
	 */
	public function handle_order_paid( $order_id, $order_data ) {
		cf7license_log( "Processing paid order for license creation: Order ID {$order_id}" );
		
		// Check if this order should generate a license
		if ( ! $this->should_create_license( $order_data ) ) {
			cf7license_log( "Order {$order_id} does not require license creation" );
			return;
		}
		
		// Extract license data from order
		$license_data = $this->extract_license_data( $order_data );
		
		if ( empty( $license_data ) ) {
			cf7license_log( "Failed to extract license data from order {$order_id}", 'error' );
			return;
		}
		
		// Add order ID to license data
		$license_data['order_id'] = $order_id;
		
		// Create license
		$license_manager = new LicenseManager();
		$license_id = $license_manager->create_license( $license_data );
		
		if ( $license_id ) {
			cf7license_log( "License created for order {$order_id}: License ID {$license_id}" );
			
			// Store license ID in order metadata (if supported)
			$this->link_license_to_order( $order_id, $license_id );
			
			do_action( 'cf7license_license_created_from_order', $license_id, $order_id, $order_data );
		} else {
			cf7license_log( "Failed to create license for order {$order_id}", 'error' );
		}
	}
	
	/**
	 * Handle order status change
	 *
	 * @param int $order_id Order ID
	 * @param string $old_status Old status
	 * @param string $new_status New status
	 */
	public function handle_order_status_change( $order_id, $old_status, $new_status ) {
		cf7license_log( "Order {$order_id} status changed from {$old_status} to {$new_status}" );
		
		// Get licenses associated with this order
		$licenses = $this->get_licenses_by_order( $order_id );
		
		if ( empty( $licenses ) ) {
			return;
		}
		
		$license_manager = new LicenseManager();
		
		foreach ( $licenses as $license ) {
			switch ( $new_status ) {
				case 'refunded':
				case 'cancelled':
					// Revoke license
					$license_manager->update_license_status( $license['id'], 'revoked' );
					cf7license_log( "License {$license['id']} revoked due to order status: {$new_status}" );
					break;
					
				case 'failed':
				case 'pending':
					// Suspend license
					$license_manager->update_license_status( $license['id'], 'suspended' );
					cf7license_log( "License {$license['id']} suspended due to order status: {$new_status}" );
					break;
					
				case 'paid':
				case 'completed':
					// Reactivate license if it was suspended
					if ( $license['status'] === 'suspended' ) {
						$license_manager->update_license_status( $license['id'], 'active' );
						cf7license_log( "License {$license['id']} reactivated due to order status: {$new_status}" );
					}
					break;
			}
		}
	}
	
	/**
	 * Handle subscription cancelled
	 *
	 * @param int $subscription_id Subscription ID
	 * @param array $subscription_data Subscription data
	 */
	public function handle_subscription_cancelled( $subscription_id, $subscription_data ) {
		cf7license_log( "Processing subscription cancellation: Subscription ID {$subscription_id}" );
		
		// Get licenses associated with this subscription
		$licenses = $this->get_licenses_by_subscription( $subscription_id );
		
		if ( empty( $licenses ) ) {
			return;
		}
		
		$license_manager = new LicenseManager();
		
		foreach ( $licenses as $license ) {
			// Set expiry date based on subscription terms
			$expiry_date = $this->calculate_subscription_expiry( $subscription_data );
			
			if ( $expiry_date ) {
				$license_manager->extend_license( $license['id'], $expiry_date );
				cf7license_log( "License {$license['id']} expiry updated due to subscription cancellation" );
			} else {
				// Immediate expiration
				$license_manager->update_license_status( $license['id'], 'expired' );
				cf7license_log( "License {$license['id']} expired due to subscription cancellation" );
			}
		}
	}
	
	/**
	 * Handle subscription expired
	 *
	 * @param int $subscription_id Subscription ID
	 * @param array $subscription_data Subscription data
	 */
	public function handle_subscription_expired( $subscription_id, $subscription_data ) {
		cf7license_log( "Processing subscription expiration: Subscription ID {$subscription_id}" );
		
		// Get licenses associated with this subscription
		$licenses = $this->get_licenses_by_subscription( $subscription_id );
		
		if ( empty( $licenses ) ) {
			return;
		}
		
		$license_manager = new LicenseManager();
		
		foreach ( $licenses as $license ) {
			$license_manager->update_license_status( $license['id'], 'expired' );
			cf7license_log( "License {$license['id']} expired due to subscription expiration" );
		}
	}
	
	/**
	 * Create license from order (generic hook)
	 *
	 * @param array $order_data Order data
	 */
	public function create_license_from_order( $order_data ) {
		$license_data = $this->extract_license_data( $order_data );
		
		if ( empty( $license_data ) ) {
			cf7license_log( 'Failed to extract license data from generic order', 'error' );
			return;
		}
		
		$license_manager = new LicenseManager();
		$license_id = $license_manager->create_license( $license_data );
		
		if ( $license_id ) {
			cf7license_log( "License created from generic order: License ID {$license_id}" );
			do_action( 'cf7license_license_created_from_generic_order', $license_id, $order_data );
		}
	}
	
	/**
	 * Check if order should create a license
	 *
	 * @param array $order_data Order data
	 * @return bool
	 */
	private function should_create_license( $order_data ) {
		// Check if order contains licensable products
		if ( empty( $order_data['product_id'] ) ) {
			return false;
		}
		
		// Allow filtering
		return apply_filters( 'cf7license_should_create_license', true, $order_data );
	}
	
	/**
	 * Extract license data from order
	 *
	 * @param array $order_data Order data
	 * @return array License data
	 */
	private function extract_license_data( $order_data ) {
		$license_data = array();
		
		// Required fields
		if ( empty( $order_data['email'] ) || empty( $order_data['product_id'] ) ) {
			return array();
		}
		
		$license_data['email'] = $order_data['email'];
		$license_data['product_id'] = $order_data['product_id'];
		
		// Optional fields
		if ( isset( $order_data['max_activations'] ) ) {
			$license_data['max_activations'] = absint( $order_data['max_activations'] );
		}
		
		if ( isset( $order_data['expires_at'] ) ) {
			$license_data['expires_at'] = $order_data['expires_at'];
		}
		
		// Metadata
		$metadata = array(
			'created_from' => 'ecommerce_order',
			'order_total'  => isset( $order_data['total'] ) ? $order_data['total'] : null,
			'currency'     => isset( $order_data['currency'] ) ? $order_data['currency'] : null,
		);
		
		$license_data['metadata'] = $metadata;
		
		// Allow filtering
		return apply_filters( 'cf7license_extract_license_data', $license_data, $order_data );
	}
	
	/**
	 * Link license to order
	 *
	 * @param int $order_id Order ID
	 * @param int $license_id License ID
	 */
	private function link_license_to_order( $order_id, $license_id ) {
		// This would depend on the ecommerce plugin's metadata system
		// For CF7 Mini Ecommerce, we might store it in order metadata
		
		do_action( 'cf7license_link_license_to_order', $license_id, $order_id );
	}
	
	/**
	 * Get licenses by order ID
	 *
	 * @param int $order_id Order ID
	 * @return array Licenses
	 */
	private function get_licenses_by_order( $order_id ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7LICENSE_LICENSES_TABLE;
		
		$licenses = $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM {$table_name} WHERE order_id = %d", $order_id ),
			ARRAY_A
		);
		
		return $licenses;
	}
	
	/**
	 * Get licenses by subscription ID
	 *
	 * @param int $subscription_id Subscription ID
	 * @return array Licenses
	 */
	private function get_licenses_by_subscription( $subscription_id ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7LICENSE_LICENSES_TABLE;
		
		// This would need to be adapted based on how subscription IDs are stored
		// For now, we'll check in metadata
		$licenses = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table_name} WHERE metadata LIKE %s",
				'%subscription_id\":' . $subscription_id . '%'
			),
			ARRAY_A
		);
		
		return $licenses;
	}
	
	/**
	 * Calculate subscription expiry date
	 *
	 * @param array $subscription_data Subscription data
	 * @return string|null Expiry date or null
	 */
	private function calculate_subscription_expiry( $subscription_data ) {
		// Default: 30 days grace period
		$grace_period_days = apply_filters( 'cf7license_subscription_grace_period', 30 );
		
		if ( $grace_period_days > 0 ) {
			return date( 'Y-m-d H:i:s', time() + ( $grace_period_days * DAY_IN_SECONDS ) );
		}
		
		return null; // Immediate expiration
	}
}