<?php

namespace CF7License\Admin;

use CF7License\Database\SchemaManager;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin initialization class
 */
class AdminInit {
	
	/**
	 * Admin instance
	 *
	 * @var AdminInit
	 */
	private static $instance = null;
	
	/**
	 * Get admin instance
	 *
	 * @return AdminInit
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		$this->init_hooks();
	}
	
	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
		add_action( 'admin_notices', array( $this, 'show_admin_notices' ) );
		
		// AJAX handlers
		add_action( 'wp_ajax_cf7license_revoke_license', array( $this, 'handle_revoke_license' ) );
		add_action( 'wp_ajax_cf7license_extend_license', array( $this, 'handle_extend_license' ) );
		add_action( 'wp_ajax_cf7license_cleanup_expired', array( $this, 'handle_cleanup_expired' ) );
		
		// Scheduled cleanup
		add_action( 'cf7license_cleanup_expired', array( $this, 'scheduled_cleanup' ) );
		
		// Schedule cleanup if not already scheduled
		if ( ! wp_next_scheduled( 'cf7license_cleanup_expired' ) ) {
			$schedule = cf7license_get_option( 'cleanup_schedule', 'daily' );
			wp_schedule_event( time(), $schedule, 'cf7license_cleanup_expired' );
		}
	}
	
	/**
	 * Add admin menu
	 */
	public function add_admin_menu() {
		// Add main menu page
		add_menu_page(
			__( 'CF7 License', CF7LICENSE_TEXT_DOMAIN ),
			__( 'CF7 License', CF7LICENSE_TEXT_DOMAIN ),
			'manage_options',
			'cf7license',
			array( $this, 'render_main_page' ),
			'dashicons-admin-network',
			30
		);
		
		// Add licenses submenu
		add_submenu_page(
			'cf7license',
			__( 'Licenses', CF7LICENSE_TEXT_DOMAIN ),
			__( 'Licenses', CF7LICENSE_TEXT_DOMAIN ),
			'manage_options',
			'cf7license-licenses',
			array( $this, 'render_licenses_page' )
		);
		
		// Add settings submenu
		add_submenu_page(
			'cf7license',
			__( 'Settings', CF7LICENSE_TEXT_DOMAIN ),
			__( 'Settings', CF7LICENSE_TEXT_DOMAIN ),
			'manage_options',
			'cf7license-settings',
			array( $this, 'render_settings_page' )
		);
	}
	
	/**
	 * Enqueue admin scripts
	 *
	 * @param string $hook Current admin page hook
	 */
	public function enqueue_admin_scripts( $hook ) {
		// Only load on our admin pages
		if ( strpos( $hook, 'cf7license' ) === false ) {
			return;
		}
		
		wp_enqueue_style(
			'cf7license-admin',
			CF7LICENSE_PLUGIN_URL . '/assets/css/admin.css',
			array(),
			CF7LICENSE_VERSION
		);
		
		wp_enqueue_script(
			'cf7license-admin',
			CF7LICENSE_PLUGIN_URL . '/assets/js/admin.js',
			array( 'jquery' ),
			CF7LICENSE_VERSION,
			true
		);
		
		wp_localize_script( 'cf7license-admin', 'cf7license_admin', array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'cf7license_admin' ),
			'strings'  => array(
				'confirm_revoke'  => __( 'Are you sure you want to revoke this license?', CF7LICENSE_TEXT_DOMAIN ),
				'confirm_cleanup' => __( 'Are you sure you want to cleanup expired licenses?', CF7LICENSE_TEXT_DOMAIN ),
				'processing'      => __( 'Processing...', CF7LICENSE_TEXT_DOMAIN ),
				'success'         => __( 'Operation completed successfully!', CF7LICENSE_TEXT_DOMAIN ),
				'error'           => __( 'An error occurred. Please try again.', CF7LICENSE_TEXT_DOMAIN ),
			),
		));
	}
	
	/**
	 * Render main admin page
	 */
	public function render_main_page() {
		?>
		<div class="wrap">
			<h1><?php _e( 'CF7 License Core', CF7LICENSE_TEXT_DOMAIN ); ?></h1>
			
			<div class="cf7license-admin-dashboard">
				<?php $this->render_dashboard_widgets(); ?>
			</div>
		</div>
		<?php
	}
	
	/**
	 * Render licenses page
	 */
	public function render_licenses_page() {
		$licenses_table = new LicensesTable();
		$licenses_table->prepare_items();
		
		?>
		<div class="wrap">
			<h1><?php _e( 'Licenses', CF7LICENSE_TEXT_DOMAIN ); ?></h1>
			
			<div class="cf7license-licenses-actions">
				<button type="button" class="button" id="cf7license-cleanup-expired">
					<?php _e( 'Cleanup Expired Licenses', CF7LICENSE_TEXT_DOMAIN ); ?>
				</button>
			</div>
			
			<form method="get">
				<input type="hidden" name="page" value="cf7license-licenses" />
				<?php $licenses_table->search_box( __( 'Search Licenses', CF7LICENSE_TEXT_DOMAIN ), 'license' ); ?>
			</form>
			
			<form method="post">
				<?php $licenses_table->display(); ?>
			</form>
		</div>
		<?php
	}
	
	/**
	 * Render settings page
	 */
	public function render_settings_page() {
		$settings_page = new SettingsPage();
		$settings_page->render();
	}
	
	/**
	 * Render dashboard widgets
	 */
	private function render_dashboard_widgets() {
		$stats = SchemaManager::get_table_stats();
		
		?>
		<div class="cf7license-dashboard-widgets">
			<div class="cf7license-widget">
				<h2><?php _e( 'License Statistics', CF7LICENSE_TEXT_DOMAIN ); ?></h2>
				<?php $this->render_license_statistics( $stats ); ?>
			</div>
			
			<div class="cf7license-widget">
				<h2><?php _e( 'Recent Activity', CF7LICENSE_TEXT_DOMAIN ); ?></h2>
				<?php $this->render_recent_activity(); ?>
			</div>
			
			<div class="cf7license-widget">
				<h2><?php _e( 'System Status', CF7LICENSE_TEXT_DOMAIN ); ?></h2>
				<?php $this->render_system_status(); ?>
			</div>
		</div>
		<?php
	}
	
	/**
	 * Render license statistics
	 *
	 * @param array $stats Statistics data
	 */
	private function render_license_statistics( $stats ) {
		?>
		<div class="cf7license-stats-grid">
			<div class="cf7license-stat-item">
				<div class="cf7license-stat-number"><?php echo esc_html( $stats['licenses']['total'] ); ?></div>
				<div class="cf7license-stat-label"><?php _e( 'Total Licenses', CF7LICENSE_TEXT_DOMAIN ); ?></div>
			</div>
			<div class="cf7license-stat-item">
				<div class="cf7license-stat-number"><?php echo esc_html( $stats['licenses']['active'] ); ?></div>
				<div class="cf7license-stat-label"><?php _e( 'Active Licenses', CF7LICENSE_TEXT_DOMAIN ); ?></div>
			</div>
			<div class="cf7license-stat-item">
				<div class="cf7license-stat-number"><?php echo esc_html( $stats['activations']['active'] ); ?></div>
				<div class="cf7license-stat-label"><?php _e( 'Active Activations', CF7LICENSE_TEXT_DOMAIN ); ?></div>
			</div>
			<div class="cf7license-stat-item">
				<div class="cf7license-stat-number"><?php echo esc_html( $stats['activations']['today'] ); ?></div>
				<div class="cf7license-stat-label"><?php _e( 'Activations Today', CF7LICENSE_TEXT_DOMAIN ); ?></div>
			</div>
		</div>
		<?php
	}
	
	/**
	 * Render recent activity
	 */
	private function render_recent_activity() {
		// This would show recent license creations, activations, etc.
		?>
		<div class="cf7license-recent-activity">
			<p><?php _e( 'Recent activity will be displayed here.', CF7LICENSE_TEXT_DOMAIN ); ?></p>
		</div>
		<?php
	}
	
	/**
	 * Render system status
	 */
	private function render_system_status() {
		$status_items = array(
			'database_tables' => SchemaManager::tables_exist(),
			'rate_limiting'   => cf7license_get_option( 'rate_limit_enabled', true ),
			'auto_cleanup'    => cf7license_get_option( 'auto_cleanup_expired', true ),
			'api_auth'        => cf7license_get_option( 'api_authentication', false ),
		);
		
		?>
		<table class="cf7license-status-table">
			<tr>
				<td><?php _e( 'Database Tables', CF7LICENSE_TEXT_DOMAIN ); ?></td>
				<td><?php echo $this->render_status_indicator( $status_items['database_tables'] ); ?></td>
			</tr>
			<tr>
				<td><?php _e( 'Rate Limiting', CF7LICENSE_TEXT_DOMAIN ); ?></td>
				<td><?php echo $this->render_status_indicator( $status_items['rate_limiting'] ); ?></td>
			</tr>
			<tr>
				<td><?php _e( 'Auto Cleanup', CF7LICENSE_TEXT_DOMAIN ); ?></td>
				<td><?php echo $this->render_status_indicator( $status_items['auto_cleanup'] ); ?></td>
			</tr>
			<tr>
				<td><?php _e( 'API Authentication', CF7LICENSE_TEXT_DOMAIN ); ?></td>
				<td><?php echo $this->render_status_indicator( $status_items['api_auth'] ); ?></td>
			</tr>
		</table>
		<?php
	}
	
	/**
	 * Render status indicator
	 *
	 * @param bool $status Status
	 * @return string HTML
	 */
	private function render_status_indicator( $status ) {
		$class = $status ? 'cf7license-status-active' : 'cf7license-status-inactive';
		$text = $status ? __( 'Active', CF7LICENSE_TEXT_DOMAIN ) : __( 'Inactive', CF7LICENSE_TEXT_DOMAIN );
		
		return '<span class="cf7license-status-indicator ' . $class . '">' . $text . '</span>';
	}
	
	/**
	 * Show admin notices
	 */
	public function show_admin_notices() {
		// Check database tables
		if ( ! SchemaManager::tables_exist() ) {
			?>
			<div class="notice notice-error">
				<p><?php _e( 'CF7 License Core database tables are missing. Please deactivate and reactivate the plugin.', CF7LICENSE_TEXT_DOMAIN ); ?></p>
			</div>
			<?php
		}
	}
	
	/**
	 * Handle revoke license AJAX
	 */
	public function handle_revoke_license() {
		if ( ! wp_verify_nonce( $_POST['nonce'], 'cf7license_admin' ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', CF7LICENSE_TEXT_DOMAIN ) ) );
		}
		
		$license_id = absint( $_POST['license_id'] );
		
		$license_manager = new \CF7License\Core\LicenseManager();
		$success = $license_manager->update_license_status( $license_id, 'revoked' );
		
		if ( $success ) {
			wp_send_json_success( array( 'message' => __( 'License revoked successfully.', CF7LICENSE_TEXT_DOMAIN ) ) );
		} else {
			wp_send_json_error( array( 'message' => __( 'Failed to revoke license.', CF7LICENSE_TEXT_DOMAIN ) ) );
		}
	}
	
	/**
	 * Handle extend license AJAX
	 */
	public function handle_extend_license() {
		if ( ! wp_verify_nonce( $_POST['nonce'], 'cf7license_admin' ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', CF7LICENSE_TEXT_DOMAIN ) ) );
		}
		
		$license_id = absint( $_POST['license_id'] );
		$days = absint( $_POST['days'] );
		
		$new_expiry = date( 'Y-m-d H:i:s', time() + ( $days * DAY_IN_SECONDS ) );
		
		$license_manager = new \CF7License\Core\LicenseManager();
		$success = $license_manager->extend_license( $license_id, $new_expiry );
		
		if ( $success ) {
			wp_send_json_success( array( 'message' => __( 'License extended successfully.', CF7LICENSE_TEXT_DOMAIN ) ) );
		} else {
			wp_send_json_error( array( 'message' => __( 'Failed to extend license.', CF7LICENSE_TEXT_DOMAIN ) ) );
		}
	}
	
	/**
	 * Handle cleanup expired AJAX
	 */
	public function handle_cleanup_expired() {
		if ( ! wp_verify_nonce( $_POST['nonce'], 'cf7license_admin' ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', CF7LICENSE_TEXT_DOMAIN ) ) );
		}
		
		$updated = SchemaManager::cleanup_expired_licenses();
		
		wp_send_json_success( array( 
			'message' => sprintf( __( '%d expired licenses cleaned up.', CF7LICENSE_TEXT_DOMAIN ), $updated ),
			'updated' => $updated,
		));
	}
	
	/**
	 * Scheduled cleanup
	 */
	public function scheduled_cleanup() {
		if ( cf7license_get_option( 'auto_cleanup_expired', true ) ) {
			SchemaManager::cleanup_expired_licenses();
		}
	}
}