<?php

namespace CF7License\Admin;

use CF7License\Core\OptionsManager;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Settings page class
 */
class SettingsPage {
	
	/**
	 * Render settings page
	 */
	public function render() {
		// Handle form submission
		if ( isset( $_POST['submit'] ) && wp_verify_nonce( $_POST['cf7license_settings_nonce'], 'cf7license_settings' ) ) {
			$this->save_settings();
		}
		
		$options = OptionsManager::get_all();
		
		?>
		<div class="wrap">
			<h1><?php _e( 'CF7 License Settings', CF7LICENSE_TEXT_DOMAIN ); ?></h1>
			
			<?php settings_errors(); ?>
			
			<form method="post" action="">
				<?php wp_nonce_field( 'cf7license_settings', 'cf7license_settings_nonce' ); ?>
				
				<table class="form-table">
					<tbody>
						<!-- General Settings -->
						<tr>
							<th colspan="2">
								<h2><?php _e( 'General Settings', CF7LICENSE_TEXT_DOMAIN ); ?></h2>
							</th>
						</tr>
						
						<tr>
							<th scope="row">
								<label for="debug_mode"><?php _e( 'Debug Mode', CF7LICENSE_TEXT_DOMAIN ); ?></label>
							</th>
							<td>
								<input type="checkbox" id="debug_mode" name="debug_mode" value="1" <?php checked( $options['debug_mode'] ); ?> />
								<p class="description"><?php _e( 'Enable debug logging for troubleshooting.', CF7LICENSE_TEXT_DOMAIN ); ?></p>
							</td>
						</tr>
						
						<tr>
							<th scope="row">
								<label for="default_max_activations"><?php _e( 'Default Max Activations', CF7LICENSE_TEXT_DOMAIN ); ?></label>
							</th>
							<td>
								<input type="number" id="default_max_activations" name="default_max_activations" value="<?php echo esc_attr( $options['default_max_activations'] ); ?>" min="1" max="100" class="small-text" />
								<p class="description"><?php _e( 'Default maximum number of activations per license.', CF7LICENSE_TEXT_DOMAIN ); ?></p>
							</td>
						</tr>
						
						<tr>
							<th scope="row">
								<label for="license_key_format"><?php _e( 'License Key Format', CF7LICENSE_TEXT_DOMAIN ); ?></label>
							</th>
							<td>
								<input type="text" id="license_key_format" name="license_key_format" value="<?php echo esc_attr( $options['license_key_format'] ); ?>" class="regular-text" />
								<p class="description"><?php _e( 'Format for generated license keys. Use X for random characters and - for separators.', CF7LICENSE_TEXT_DOMAIN ); ?></p>
							</td>
						</tr>
						
						<!-- API Settings -->
						<tr>
							<th colspan="2">
								<h2><?php _e( 'API Settings', CF7LICENSE_TEXT_DOMAIN ); ?></h2>
							</th>
						</tr>
						
						<tr>
							<th scope="row">
								<label for="rate_limit_enabled"><?php _e( 'Enable Rate Limiting', CF7LICENSE_TEXT_DOMAIN ); ?></label>
							</th>
							<td>
								<input type="checkbox" id="rate_limit_enabled" name="rate_limit_enabled" value="1" <?php checked( $options['rate_limit_enabled'] ); ?> />
								<p class="description"><?php _e( 'Limit the number of API requests per time window.', CF7LICENSE_TEXT_DOMAIN ); ?></p>
							</td>
						</tr>
						
						<tr>
							<th scope="row">
								<label for="rate_limit_requests"><?php _e( 'Rate Limit Requests', CF7LICENSE_TEXT_DOMAIN ); ?></label>
							</th>
							<td>
								<input type="number" id="rate_limit_requests" name="rate_limit_requests" value="<?php echo esc_attr( $options['rate_limit_requests'] ); ?>" min="1" max="1000" class="small-text" />
								<p class="description"><?php _e( 'Maximum number of requests per time window.', CF7LICENSE_TEXT_DOMAIN ); ?></p>
							</td>
						</tr>
						
						<tr>
							<th scope="row">
								<label for="rate_limit_window"><?php _e( 'Rate Limit Window (seconds)', CF7LICENSE_TEXT_DOMAIN ); ?></label>
							</th>
							<td>
								<input type="number" id="rate_limit_window" name="rate_limit_window" value="<?php echo esc_attr( $options['rate_limit_window'] ); ?>" min="60" max="86400" class="small-text" />
								<p class="description"><?php _e( 'Time window for rate limiting in seconds.', CF7LICENSE_TEXT_DOMAIN ); ?></p>
							</td>
						</tr>
						
						<tr>
							<th scope="row">
								<label for="api_authentication"><?php _e( 'API Authentication', CF7LICENSE_TEXT_DOMAIN ); ?></label>
							</th>
							<td>
								<input type="checkbox" id="api_authentication" name="api_authentication" value="1" <?php checked( $options['api_authentication'] ); ?> />
								<p class="description"><?php _e( 'Require authentication for API endpoints.', CF7LICENSE_TEXT_DOMAIN ); ?></p>
							</td>
						</tr>
						
						<tr>
							<th scope="row">
								<label for="api_secret_key"><?php _e( 'API Secret Key', CF7LICENSE_TEXT_DOMAIN ); ?></label>
							</th>
							<td>
								<input type="text" id="api_secret_key" name="api_secret_key" value="<?php echo esc_attr( $options['api_secret_key'] ); ?>" class="regular-text" readonly />
								<button type="button" id="regenerate_api_key" class="button"><?php _e( 'Regenerate', CF7LICENSE_TEXT_DOMAIN ); ?></button>
								<p class="description"><?php _e( 'Secret key for API authentication. Keep this secure.', CF7LICENSE_TEXT_DOMAIN ); ?></p>
							</td>
						</tr>
						
						<!-- Cleanup Settings -->
						<tr>
							<th colspan="2">
								<h2><?php _e( 'Cleanup Settings', CF7LICENSE_TEXT_DOMAIN ); ?></h2>
							</th>
						</tr>
						
						<tr>
							<th scope="row">
								<label for="auto_cleanup_expired"><?php _e( 'Auto Cleanup Expired', CF7LICENSE_TEXT_DOMAIN ); ?></label>
							</th>
							<td>
								<input type="checkbox" id="auto_cleanup_expired" name="auto_cleanup_expired" value="1" <?php checked( $options['auto_cleanup_expired'] ); ?> />
								<p class="description"><?php _e( 'Automatically update expired licenses status.', CF7LICENSE_TEXT_DOMAIN ); ?></p>
							</td>
						</tr>
						
						<tr>
							<th scope="row">
								<label for="cleanup_schedule"><?php _e( 'Cleanup Schedule', CF7LICENSE_TEXT_DOMAIN ); ?></label>
							</th>
							<td>
								<select id="cleanup_schedule" name="cleanup_schedule">
									<option value="hourly" <?php selected( $options['cleanup_schedule'], 'hourly' ); ?>><?php _e( 'Hourly', CF7LICENSE_TEXT_DOMAIN ); ?></option>
									<option value="daily" <?php selected( $options['cleanup_schedule'], 'daily' ); ?>><?php _e( 'Daily', CF7LICENSE_TEXT_DOMAIN ); ?></option>
									<option value="weekly" <?php selected( $options['cleanup_schedule'], 'weekly' ); ?>><?php _e( 'Weekly', CF7LICENSE_TEXT_DOMAIN ); ?></option>
								</select>
								<p class="description"><?php _e( 'How often to run the cleanup process.', CF7LICENSE_TEXT_DOMAIN ); ?></p>
							</td>
						</tr>
					</tbody>
				</table>
				
				<?php submit_button(); ?>
			</form>
			
			<div class="cf7license-api-info">
				<h2><?php _e( 'API Information', CF7LICENSE_TEXT_DOMAIN ); ?></h2>
				<?php $this->render_api_info(); ?>
			</div>
		</div>
		
		<script>
		jQuery(document).ready(function($) {
			$('#regenerate_api_key').on('click', function() {
				if (confirm('<?php _e( 'Are you sure you want to regenerate the API key? This will invalidate the current key.', CF7LICENSE_TEXT_DOMAIN ); ?>')) {
					var newKey = generateRandomString(32);
					$('#api_secret_key').val(newKey);
				}
			});
			
			function generateRandomString(length) {
				var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
				var result = '';
				for (var i = 0; i < length; i++) {
					result += chars.charAt(Math.floor(Math.random() * chars.length));
				}
				return result;
			}
		});
		</script>
		<?php
	}
	
	/**
	 * Save settings
	 */
	private function save_settings() {
		$options = array();
		
		// Boolean options
		$boolean_options = array( 'debug_mode', 'rate_limit_enabled', 'api_authentication', 'auto_cleanup_expired' );
		foreach ( $boolean_options as $option ) {
			$options[ $option ] = isset( $_POST[ $option ] );
		}
		
		// Integer options
		$integer_options = array( 'default_max_activations', 'rate_limit_requests', 'rate_limit_window' );
		foreach ( $integer_options as $option ) {
			if ( isset( $_POST[ $option ] ) ) {
				$options[ $option ] = absint( $_POST[ $option ] );
			}
		}
		
		// String options
		$string_options = array( 'license_key_format', 'api_secret_key', 'cleanup_schedule' );
		foreach ( $string_options as $option ) {
			if ( isset( $_POST[ $option ] ) ) {
				$options[ $option ] = sanitize_text_field( $_POST[ $option ] );
			}
		}
		
		// Update options
		$success = OptionsManager::update_multiple( $options );
		
		if ( $success ) {
			add_settings_error( 'cf7license_settings', 'settings_updated', __( 'Settings saved successfully.', CF7LICENSE_TEXT_DOMAIN ), 'updated' );
		} else {
			add_settings_error( 'cf7license_settings', 'settings_error', __( 'Failed to save settings.', CF7LICENSE_TEXT_DOMAIN ), 'error' );
		}
	}
	
	/**
	 * Render API information
	 */
	private function render_api_info() {
		$base_url = rest_url( 'cf7-license/v1' );
		
		?>
		<div class="cf7license-api-endpoints">
			<h3><?php _e( 'API Endpoints', CF7LICENSE_TEXT_DOMAIN ); ?></h3>
			
			<table class="wp-list-table widefat fixed striped">
				<thead>
					<tr>
						<th><?php _e( 'Endpoint', CF7LICENSE_TEXT_DOMAIN ); ?></th>
						<th><?php _e( 'Method', CF7LICENSE_TEXT_DOMAIN ); ?></th>
						<th><?php _e( 'Description', CF7LICENSE_TEXT_DOMAIN ); ?></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><code><?php echo esc_html( $base_url . '/verify' ); ?></code></td>
						<td><span class="cf7license-method-post">POST</span></td>
						<td><?php _e( 'Verify license for domain', CF7LICENSE_TEXT_DOMAIN ); ?></td>
					</tr>
					<tr>
						<td><code><?php echo esc_html( $base_url . '/activate' ); ?></code></td>
						<td><span class="cf7license-method-post">POST</span></td>
						<td><?php _e( 'Activate license for domain', CF7LICENSE_TEXT_DOMAIN ); ?></td>
					</tr>
					<tr>
						<td><code><?php echo esc_html( $base_url . '/deactivate' ); ?></code></td>
						<td><span class="cf7license-method-post">POST</span></td>
						<td><?php _e( 'Deactivate license for domain', CF7LICENSE_TEXT_DOMAIN ); ?></td>
					</tr>
				</tbody>
			</table>
			
			<h4><?php _e( 'Example Request', CF7LICENSE_TEXT_DOMAIN ); ?></h4>
			<pre><code>POST <?php echo esc_html( $base_url . '/verify' ); ?>
Content-Type: application/json
<?php if ( cf7license_get_option( 'api_authentication' ) ) : ?>
X-API-Key: <?php echo esc_html( cf7license_get_option( 'api_secret_key' ) ); ?>
<?php endif; ?>

{
  "license_key": "XXXX-XXXX-XXXX-XXXX",
  "domain": "example.com",
  "product_id": "my-plugin"
}</code></pre>
		</div>
		<?php
	}
}