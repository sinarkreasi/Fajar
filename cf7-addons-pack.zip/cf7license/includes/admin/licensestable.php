<?php

namespace CF7License\Admin;

use CF7License\Core\LicenseManager;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Load WP_List_Table if not loaded
if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

/**
 * Licenses list table class
 */
class LicensesTable extends \WP_List_Table {
	
	/**
	 * Constructor
	 */
	public function __construct() {
		parent::__construct( array(
			'singular' => 'license',
			'plural'   => 'licenses',
			'ajax'     => false,
		));
	}
	
	/**
	 * Get columns
	 *
	 * @return array
	 */
	public function get_columns() {
		return array(
			'cb'               => '<input type="checkbox" />',
			'license_key'      => __( 'License Key', CF7LICENSE_TEXT_DOMAIN ),
			'product_id'       => __( 'Product', CF7LICENSE_TEXT_DOMAIN ),
			'email'            => __( 'Email', CF7LICENSE_TEXT_DOMAIN ),
			'status'           => __( 'Status', CF7LICENSE_TEXT_DOMAIN ),
			'activations'      => __( 'Activations', CF7LICENSE_TEXT_DOMAIN ),
			'expires_at'       => __( 'Expires', CF7LICENSE_TEXT_DOMAIN ),
			'created_at'       => __( 'Created', CF7LICENSE_TEXT_DOMAIN ),
			'actions'          => __( 'Actions', CF7LICENSE_TEXT_DOMAIN ),
		);
	}
	
	/**
	 * Get sortable columns
	 *
	 * @return array
	 */
	public function get_sortable_columns() {
		return array(
			'license_key' => array( 'license_key', false ),
			'product_id'  => array( 'product_id', false ),
			'email'       => array( 'email', false ),
			'status'      => array( 'status', false ),
			'expires_at'  => array( 'expires_at', false ),
			'created_at'  => array( 'created_at', true ),
		);
	}
	
	/**
	 * Get bulk actions
	 *
	 * @return array
	 */
	public function get_bulk_actions() {
		return array(
			'revoke'  => __( 'Revoke', CF7LICENSE_TEXT_DOMAIN ),
			'suspend' => __( 'Suspend', CF7LICENSE_TEXT_DOMAIN ),
			'activate' => __( 'Activate', CF7LICENSE_TEXT_DOMAIN ),
		);
	}
	
	/**
	 * Prepare items
	 */
	public function prepare_items() {
		$per_page = 20;
		$current_page = $this->get_pagenum();
		
		// Get search term
		$search = isset( $_REQUEST['s'] ) ? sanitize_text_field( $_REQUEST['s'] ) : '';
		
		// Get filter values
		$status_filter = isset( $_REQUEST['status'] ) ? sanitize_text_field( $_REQUEST['status'] ) : '';
		$product_filter = isset( $_REQUEST['product_id'] ) ? sanitize_text_field( $_REQUEST['product_id'] ) : '';
		
		// Prepare query args
		$args = array(
			'per_page' => $per_page,
			'page'     => $current_page,
			'orderby'  => isset( $_REQUEST['orderby'] ) ? sanitize_text_field( $_REQUEST['orderby'] ) : 'created_at',
			'order'    => isset( $_REQUEST['order'] ) ? sanitize_text_field( $_REQUEST['order'] ) : 'DESC',
		);
		
		if ( ! empty( $search ) ) {
			$args['email'] = $search;
		}
		
		if ( ! empty( $status_filter ) ) {
			$args['status'] = $status_filter;
		}
		
		if ( ! empty( $product_filter ) ) {
			$args['product_id'] = $product_filter;
		}
		
		// Get licenses
		$license_manager = new LicenseManager();
		$result = $license_manager->get_licenses( $args );
		
		$this->items = $result['licenses'];
		
		// Set pagination
		$this->set_pagination_args( array(
			'total_items' => $result['total'],
			'per_page'    => $per_page,
		));
		
		// Set column headers
		$this->_column_headers = array(
			$this->get_columns(),
			array(),
			$this->get_sortable_columns(),
		);
	}
	
	/**
	 * Column default
	 *
	 * @param array $item Item data
	 * @param string $column_name Column name
	 * @return string
	 */
	public function column_default( $item, $column_name ) {
		switch ( $column_name ) {
			case 'license_key':
				return '<code>' . esc_html( $item['license_key'] ) . '</code>';
				
			case 'product_id':
				return esc_html( $item['product_id'] );
				
			case 'email':
				return esc_html( $item['email'] );
				
			case 'status':
				return $this->render_status_badge( $item['status'] );
				
			case 'activations':
				return $this->render_activation_info( $item );
				
			case 'expires_at':
				return cf7license_format_date( $item['expires_at'] );
				
			case 'created_at':
				return cf7license_format_date( $item['created_at'] );
				
			case 'actions':
				return $this->render_row_actions( $item );
				
			default:
				return '';
		}
	}
	
	/**
	 * Column checkbox
	 *
	 * @param array $item Item data
	 * @return string
	 */
	public function column_cb( $item ) {
		return sprintf(
			'<input type="checkbox" name="license[]" value="%s" />',
			$item['id']
		);
	}
	
	/**
	 * Render status badge
	 *
	 * @param string $status Status
	 * @return string
	 */
	private function render_status_badge( $status ) {
		$class = 'cf7license-status-badge cf7license-status-' . esc_attr( $status );
		$label = ucfirst( $status );
		
		return '<span class="' . $class . '">' . esc_html( $label ) . '</span>';
	}
	
	/**
	 * Render activation info
	 *
	 * @param array $item License data
	 * @return string
	 */
	private function render_activation_info( $item ) {
		$activation_count = $item['activation_count'];
		$max_activations = $item['max_activations'];
		
		$class = '';
		if ( $activation_count >= $max_activations ) {
			$class = 'cf7license-activations-full';
		} elseif ( $activation_count > ( $max_activations * 0.8 ) ) {
			$class = 'cf7license-activations-warning';
		}
		
		return sprintf(
			'<span class="%s">%d / %d</span>',
			$class,
			$activation_count,
			$max_activations
		);
	}
	
	/**
	 * Render row actions
	 *
	 * @param array $item License data
	 * @return string
	 */
	private function render_row_actions( $item ) {
		$actions = array();
		
		if ( $item['status'] === 'active' ) {
			$actions['revoke'] = sprintf(
				'<a href="#" class="cf7license-revoke-license" data-license-id="%d">%s</a>',
				$item['id'],
				__( 'Revoke', CF7LICENSE_TEXT_DOMAIN )
			);
			
			$actions['suspend'] = sprintf(
				'<a href="#" class="cf7license-suspend-license" data-license-id="%d">%s</a>',
				$item['id'],
				__( 'Suspend', CF7LICENSE_TEXT_DOMAIN )
			);
		} elseif ( $item['status'] === 'suspended' ) {
			$actions['activate'] = sprintf(
				'<a href="#" class="cf7license-activate-license" data-license-id="%d">%s</a>',
				$item['id'],
				__( 'Activate', CF7LICENSE_TEXT_DOMAIN )
			);
		}
		
		if ( ! empty( $item['expires_at'] ) ) {
			$actions['extend'] = sprintf(
				'<a href="#" class="cf7license-extend-license" data-license-id="%d">%s</a>',
				$item['id'],
				__( 'Extend', CF7LICENSE_TEXT_DOMAIN )
			);
		}
		
		return implode( ' | ', $actions );
	}
	
	/**
	 * Extra table navigation
	 *
	 * @param string $which Position (top or bottom)
	 */
	public function extra_tablenav( $which ) {
		if ( $which === 'top' ) {
			?>
			<div class="alignleft actions">
				<?php $this->render_status_filter(); ?>
				<?php $this->render_product_filter(); ?>
				<?php submit_button( __( 'Filter', CF7LICENSE_TEXT_DOMAIN ), '', 'filter_action', false, array( 'id' => 'post-query-submit' ) ); ?>
			</div>
			<?php
		}
	}
	
	/**
	 * Render status filter
	 */
	private function render_status_filter() {
		$current_status = isset( $_REQUEST['status'] ) ? $_REQUEST['status'] : '';
		$statuses = cf7license_get_license_statuses();
		
		?>
		<select name="status">
			<option value=""><?php _e( 'All Statuses', CF7LICENSE_TEXT_DOMAIN ); ?></option>
			<?php foreach ( $statuses as $value => $label ) : ?>
				<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $current_status, $value ); ?>>
					<?php echo esc_html( $label ); ?>
				</option>
			<?php endforeach; ?>
		</select>
		<?php
	}
	
	/**
	 * Render product filter
	 */
	private function render_product_filter() {
		$current_product = isset( $_REQUEST['product_id'] ) ? $_REQUEST['product_id'] : '';
		
		// Get unique product IDs
		global $wpdb;
		$table_name = $wpdb->prefix . CF7LICENSE_LICENSES_TABLE;
		$products = $wpdb->get_col( "SELECT DISTINCT product_id FROM {$table_name} ORDER BY product_id" );
		
		if ( empty( $products ) ) {
			return;
		}
		
		?>
		<select name="product_id">
			<option value=""><?php _e( 'All Products', CF7LICENSE_TEXT_DOMAIN ); ?></option>
			<?php foreach ( $products as $product_id ) : ?>
				<option value="<?php echo esc_attr( $product_id ); ?>" <?php selected( $current_product, $product_id ); ?>>
					<?php echo esc_html( $product_id ); ?>
				</option>
			<?php endforeach; ?>
		</select>
		<?php
	}
}