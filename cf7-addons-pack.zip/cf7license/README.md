# CF7 License Core

Professional license management system for Contact Form 7 ecosystem. Generates and manages software licenses without user accounts.

## Features

- **Token-based License System**: Cryptographically secure license key generation
- **REST API**: Complete API for license verification, activation, and deactivation
- **Ecommerce Integration**: Automatic license creation from CF7 Mini Ecommerce orders
- **No User Accounts**: Email-based identity system
- **Scalable Architecture**: Custom database tables, indexed queries
- **Rate Limiting**: Built-in API rate limiting and security
- **Admin Interface**: Minimal but functional license management
- **Extensible**: Hook and filter system for customization

## Installation

1. Upload the plugin files to `/wp-content/plugins/cf7license/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Configure settings under 'CF7 License' in the admin menu

## Requirements

- WordPress 6.0+
- PHP 7.4+
- Contact Form 7 plugin

## API Endpoints

### Verify License
```
POST /wp-json/cf7-license/v1/verify
```

**Request:**
```json
{
  "license_key": "XXXX-XXXX-XXXX-XXXX",
  "domain": "example.com",
  "product_id": "my-plugin"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "valid": true,
    "status": "active",
    "expires_at": "2026-01-01 00:00:00",
    "remaining_activations": 2
  }
}
```

### Activate License
```
POST /wp-json/cf7-license/v1/activate
```

**Request:**
```json
{
  "license_key": "XXXX-XXXX-XXXX-XXXX",
  "domain": "example.com",
  "product_id": "my-plugin"
}
```

### Deactivate License
```
POST /wp-json/cf7-license/v1/deactivate
```

**Request:**
```json
{
  "license_key": "XXXX-XXXX-XXXX-XXXX",
  "domain": "example.com"
}
```

## Integration

### Ecommerce Integration

The plugin automatically listens for CF7 Mini Ecommerce order events:

```php
// Triggered when order is paid
do_action('cf7mc_order_paid', $order_id, $order_data);

// Order data should include:
$order_data = array(
    'email' => 'customer@example.com',
    'product_id' => 'my-plugin',
    'max_activations' => 3, // optional
    'expires_at' => '2026-01-01 00:00:00' // optional
);
```

### Custom Integration

Create licenses programmatically:

```php
$license_data = array(
    'email' => 'customer@example.com',
    'product_id' => 'my-plugin',
    'max_activations' => 3,
    'expires_at' => '2026-01-01 00:00:00'
);

$license_id = cf7license_create_license($license_data);
```

## Hooks & Filters

### Actions

- `cf7_license_created` - Fired when license is created
- `cf7_license_activated` - Fired when license is activated
- `cf7_license_deactivated` - Fired when license is deactivated
- `cf7_license_expired` - Fired when license expires
- `cf7_license_revoked` - Fired when license is revoked

### Filters

- `cf7_license_key_format` - Customize license key format
- `cf7_license_max_activations` - Set max activations per product
- `cf7_license_expiry_rules` - Define expiration rules
- `cf7license_should_create_license` - Control license creation

## Database Schema

### Licenses Table (`wp_cf7_licenses`)

- `id` - Primary key
- `license_key` - Unique license key
- `product_id` - Product identifier
- `email` - Customer email
- `status` - License status (active, expired, suspended, revoked)
- `max_activations` - Maximum allowed activations
- `activation_count` - Current activation count
- `expires_at` - Expiration date (nullable)
- `order_id` - Associated order ID (nullable)
- `metadata` - JSON metadata
- `created_at` - Creation timestamp
- `updated_at` - Last update timestamp

### Activations Table (`wp_cf7_license_activations`)

- `id` - Primary key
- `license_id` - Foreign key to licenses table
- `domain` - Activated domain
- `activated_at` - Activation timestamp
- `deactivated_at` - Deactivation timestamp (nullable)
- `ip_address` - Client IP address
- `user_agent` - Client user agent
- `metadata` - JSON metadata

## Security Features

- Cryptographically secure license key generation
- Token hashing for secure storage
- Rate limiting on API endpoints
- Optional API authentication
- Domain validation
- IP address logging

## Configuration

### License Key Format

Customize the license key format using the filter:

```php
add_filter('cf7_license_key_format', function($format) {
    return 'XXXX-XXXX-XXXX-XXXX'; // Default format
});
```

### Expiration Rules

Define custom expiration rules:

```php
add_filter('cf7_license_expiry_rules', function($rules, $product_id, $order_data) {
    if ($product_id === 'premium-plugin') {
        return array(
            'type' => 'years',
            'value' => 1
        );
    }
    return $rules;
}, 10, 3);
```

### Max Activations

Set product-specific activation limits:

```php
add_filter('cf7_license_max_activations', function($max, $product_id) {
    if ($product_id === 'enterprise-plugin') {
        return 10;
    }
    return $max;
}, 10, 2);
```

## Performance

- All database queries are indexed
- No wp_options abuse
- Efficient pagination
- Scalable to 100k+ licenses
- Minimal memory footprint

## Support

For support and documentation, visit the plugin repository or contact the development team.

## License

GPL v2 or later