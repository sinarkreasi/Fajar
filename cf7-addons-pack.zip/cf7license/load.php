<?php

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Autoloader
spl_autoload_register( 'cf7license_autoloader' );

function cf7license_autoloader( $class ) {
	// Only handle our namespace
	if ( strpos( $class, 'CF7License\\' ) !== 0 ) {
		return;
	}
	
	// Remove namespace prefix
	$class = substr( $class, 11 );
	
	// Convert namespace separators to directory separators
	$class = str_replace( '\\', DIRECTORY_SEPARATOR, $class );
	
	// Convert to lowercase and add .php extension
	$file = CF7LICENSE_PLUGIN_DIR . '/includes/' . strtolower( $class ) . '.php';
	
	if ( file_exists( $file ) ) {
		require_once $file;
	}
}

// Load helper functions
require_once CF7LICENSE_PLUGIN_DIR . '/includes/functions.php';

// Load core classes
require_once CF7LICENSE_PLUGIN_DIR . '/includes/core/optionsmanager.php';
require_once CF7LICENSE_PLUGIN_DIR . '/includes/core/licensemanager.php';
require_once CF7LICENSE_PLUGIN_DIR . '/includes/core/activationmanager.php';
require_once CF7LICENSE_PLUGIN_DIR . '/includes/core/licensevalidator.php';

// Load database classes
require_once CF7LICENSE_PLUGIN_DIR . '/includes/database/schemamanager.php';

// Load API classes
require_once CF7LICENSE_PLUGIN_DIR . '/includes/api/restcontroller.php';
require_once CF7LICENSE_PLUGIN_DIR . '/includes/api/endpoints/verifyendpoint.php';
require_once CF7LICENSE_PLUGIN_DIR . '/includes/api/endpoints/activateendpoint.php';
require_once CF7LICENSE_PLUGIN_DIR . '/includes/api/endpoints/deactivateendpoint.php';

// Load integration classes
require_once CF7LICENSE_PLUGIN_DIR . '/includes/integrations/ecommercelistener.php';

// Load admin classes if in admin area
if ( is_admin() ) {
	require_once CF7LICENSE_PLUGIN_DIR . '/includes/admin/admininit.php';
	require_once CF7LICENSE_PLUGIN_DIR . '/includes/admin/licensestable.php';
	require_once CF7LICENSE_PLUGIN_DIR . '/includes/admin/settingspage.php';
}

// Initialize plugin
function cf7license_init() {
	// Load text domain
	load_plugin_textdomain( CF7LICENSE_TEXT_DOMAIN, false, dirname( CF7LICENSE_PLUGIN_BASENAME ) . '/languages' );
	
	// Initialize REST API
	CF7License\API\RestController::instance();
	
	// Initialize integrations
	CF7License\Integrations\EcommerceListener::instance();
	
	// Initialize admin if in admin area
	if ( is_admin() ) {
		CF7License\Admin\AdminInit::instance();
	}
	
	do_action( 'cf7license_init' );
}