<?php
/*
 * Plugin Name: CF7 License Core
 * Plugin URI: https://github.com/cf7-license/cf7license
 * Description: Professional license management system for Contact Form 7 ecosystem. Generates and manages software licenses without user accounts.
 * Author: CF7 License Team
 * Version: 1.0.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Text Domain: cf7license
 * Domain Path: /languages
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Plugin version
define( 'CF7LICENSE_VERSION', '1.0.0' );

// Plugin constants
define( 'CF7LICENSE_PLUGIN_FILE', __FILE__ );
define( 'CF7LICENSE_PLUGIN_BASENAME', plugin_basename( CF7LICENSE_PLUGIN_FILE ) );
define( 'CF7LICENSE_PLUGIN_DIR', untrailingslashit( dirname( CF7LICENSE_PLUGIN_FILE ) ) );
define( 'CF7LICENSE_PLUGIN_URL', untrailingslashit( plugins_url( '', CF7LICENSE_PLUGIN_FILE ) ) );
define( 'CF7LICENSE_TEXT_DOMAIN', 'cf7license' );

// Database table names
define( 'CF7LICENSE_LICENSES_TABLE', 'cf7_licenses' );
define( 'CF7LICENSE_ACTIVATIONS_TABLE', 'cf7_license_activations' );

// License constants
define( 'CF7LICENSE_KEY_LENGTH', 32 );
define( 'CF7LICENSE_DEFAULT_MAX_ACTIVATIONS', 3 );
define( 'CF7LICENSE_API_VERSION', 'v1' );

// Check dependencies
add_action( 'plugins_loaded', 'cf7license_check_dependencies' );

function cf7license_check_dependencies() {
	$missing_plugins = array();
	
	// Check for Contact Form 7
	if ( ! class_exists( 'WPCF7' ) ) {
		$missing_plugins[] = 'Contact Form 7';
	}
	
	if ( ! empty( $missing_plugins ) ) {
		add_action( 'admin_notices', function() use ( $missing_plugins ) {
			?>
			<div class="notice notice-error">
				<p><?php printf( 
					__( 'CF7 License Core requires the following plugins: %s', CF7LICENSE_TEXT_DOMAIN ),
					implode( ', ', $missing_plugins )
				); ?></p>
			</div>
			<?php
		});
		return;
	}
	
	// Initialize License Core
	cf7license_init();
}

// Load plugin files
require_once CF7LICENSE_PLUGIN_DIR . '/load.php';

// Plugin activation hook
register_activation_hook( CF7LICENSE_PLUGIN_FILE, 'cf7license_activate' );

// Plugin deactivation hook
register_deactivation_hook( CF7LICENSE_PLUGIN_FILE, 'cf7license_deactivate' );

/**
 * Plugin activation callback
 */
function cf7license_activate() {
	// Create database tables
	CF7License\Database\SchemaManager::create_tables();
	
	// Set default options
	CF7License\Core\OptionsManager::set_defaults();
	
	// Flush rewrite rules for REST API
	flush_rewrite_rules();
}

/**
 * Plugin deactivation callback
 */
function cf7license_deactivate() {
	// Flush rewrite rules
	flush_rewrite_rules();
}