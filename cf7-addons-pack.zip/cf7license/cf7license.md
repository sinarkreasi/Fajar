# Prompt: Build License Core Addon for Contact Form 7 Ecosystem

## Role
You are a senior WordPress plugin engineer.
You understand CF7 internals, custom database tables, REST APIs, and scalable plugin architecture.
You are building a **License Core Addon** designed to work with a **Mini Ecommerce + Magic Link (UCA)** system.
No WooCommerce. No WordPress user accounts required.

---

## Objective
Build a **License Core Addon** that:
- Generates and manages software licenses
- Is triggered by successful payments
- Works without user accounts (email + magic link only)
- Can be consumed by external plugins, themes, or SaaS apps
- Is modular, secure, and extensible

This addon is NOT a UI-heavy plugin.
It is a **business logic + API layer**.

---

## Hard Requirements
- No dependency on WooCommerce
- No dependency on WP Users
- Uses custom database tables
- Email is the primary identity
- License lifecycle is driven by payment status
- Magic Link (UCA) is the access layer
- Clean separation between:
  - License logic
  - Ecommerce logic
  - Auth / access logic

---

## Core Concepts

### License
A license represents the right to use a product.

Each license is associated with:
- Product
- Buyer email
- Activation limits
- Expiration rules

---

## Database Schema (Required)

### Table: wp_cf7_licenses
Fields:
- id (BIGINT, PK)
- license_key (VARCHAR, unique)
- product_id (VARCHAR)
- email (VARCHAR)
- status (active | expired | suspended | revoked)
- max_activations (INT)
- activation_count (INT)
- expires_at (DATETIME, nullable)
- created_at (DATETIME)
- updated_at (DATETIME)

---

### Table: wp_cf7_license_activations
Fields:
- id (BIGINT, PK)
- license_id (BIGINT, FK)
- domain (VARCHAR)
- activated_at (DATETIME)
- deactivated_at (DATETIME, nullable)

---

## License Lifecycle

### Creation
Triggered ONLY when:
- Mini Ecommerce order status = `paid`

Actions:
- Generate cryptographically secure license key
- Store license record
- Assign email + product
- Set expiration if applicable

---

### Activation
Triggered by:
- External plugin/theme calling REST API

Rules:
- Activation count must not exceed limit
- Domain must be unique per activation
- License must be active

---

### Expiration
Triggered by:
- Subscription cancellation
- Expiry date reached
- Manual admin action

Expired licenses:
- Cannot activate
- Existing activations may be invalidated

---

## REST API (Mandatory)

### Endpoint: Verify License
`POST /wp-json/cf7-license/v1/verify`

Request:
```json
{
  "license_key": "XXXX-XXXX",
  "domain": "example.com",
  "product_id": "plugin-slug"
}
```
Response:

{
  "valid": true,
  "status": "active",
  "expires_at": "2026-01-01",
  "remaining_activations": 2
}

Endpoint: Activate License

POST /wp-json/cf7-license/v1/activate

Rules:

Verify license

Register domain

Increment activation count

Endpoint: Deactivate License

POST /wp-json/cf7-license/v1/deactivate

Rules:

Remove domain

Decrement activation count (optional, configurable)

Hooks & Events (Extensibility)
Required Actions

cf7_license_created

cf7_license_activated

cf7_license_expired

cf7_license_revoked

Required Filters

cf7_license_key_format

cf7_license_max_activations

cf7_license_expiry_rules

Integration Contracts
Mini Ecommerce Addon

Calls license creation on order_paid

Provides:

product_id

buyer email

order_id

Subscription Addon

Calls:

renew license

suspend on failed payment

expire on cancellation

Magic Link / UCA

License Core must expose:

fetch licenses by email

fetch license details

NO auth logic inside License Core

Admin UI (Minimal)

Only for:

Viewing licenses

Revoking licenses

Manually extending expiry

No checkout UI.
No frontend dashboard.

Security Requirements

License keys must be non-guessable

REST endpoints protected with:

rate limiting

optional signature / token

No sensitive data exposed publicly

Performance Requirements

All queries indexed

No wp_options abuse

No postmeta storage

Scalable to 100k+ licenses

Non-Goals

No DRM

No heavy analytics

No account system

No frontend builder

Output Expectation

Generate:

Plugin folder structure

Core classes

Database installer

REST controllers

Hooks & filters

Clean, production-ready code

Code must be:

Namespaced

PSR-4 compliant

Extensible

Documented inline

Mindset

Think like a SaaS backend engineer, not a WordPress hobbyist.
This is a license infrastructure, not a toy plugin.