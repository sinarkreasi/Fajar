/**
 * CF7 License Admin JavaScript
 */
(function($) {
	'use strict';
	
	var CF7LicenseAdmin = {
		
		/**
		 * Initialize
		 */
		init: function() {
			this.bindEvents();
		},
		
		/**
		 * Bind events
		 */
		bindEvents: function() {
			// License actions
			$(document).on('click', '.cf7license-revoke-license', this.handleRevokeLicense);
			$(document).on('click', '.cf7license-suspend-license', this.handleSuspendLicense);
			$(document).on('click', '.cf7license-activate-license', this.handleActivateLicense);
			$(document).on('click', '.cf7license-extend-license', this.handleExtendLicense);
			
			// Bulk actions
			$(document).on('click', '#cf7license-cleanup-expired', this.handleCleanupExpired);
			
			// API key regeneration
			$(document).on('click', '#regenerate_api_key', this.handleRegenerateApiKey);
		},
		
		/**
		 * Handle revoke license
		 */
		handleRevokeLicense: function(e) {
			e.preventDefault();
			
			if (!confirm(cf7license_admin.strings.confirm_revoke)) {
				return;
			}
			
			var $button = $(this);
			var licenseId = $button.data('license-id');
			
			CF7LicenseAdmin.updateLicenseStatus(licenseId, 'revoked', $button);
		},
		
		/**
		 * Handle suspend license
		 */
		handleSuspendLicense: function(e) {
			e.preventDefault();
			
			var $button = $(this);
			var licenseId = $button.data('license-id');
			
			CF7LicenseAdmin.updateLicenseStatus(licenseId, 'suspended', $button);
		},
		
		/**
		 * Handle activate license
		 */
		handleActivateLicense: function(e) {
			e.preventDefault();
			
			var $button = $(this);
			var licenseId = $button.data('license-id');
			
			CF7LicenseAdmin.updateLicenseStatus(licenseId, 'active', $button);
		},
		
		/**
		 * Update license status
		 */
		updateLicenseStatus: function(licenseId, status, $button) {
			var $row = $button.closest('tr');
			
			$row.addClass('cf7license-loading');
			
			$.ajax({
				url: cf7license_admin.ajax_url,
				type: 'POST',
				data: {
					action: 'cf7license_update_status',
					license_id: licenseId,
					status: status,
					nonce: cf7license_admin.nonce
				},
				success: function(response) {
					if (response.success) {
						// Reload page to show updated status
						window.location.reload();
					} else {
						alert(response.data.message || cf7license_admin.strings.error);
					}
				},
				error: function() {
					alert(cf7license_admin.strings.error);
				},
				complete: function() {
					$row.removeClass('cf7license-loading');
				}
			});
		},
		
		/**
		 * Handle extend license
		 */
		handleExtendLicense: function(e) {
			e.preventDefault();
			
			var days = prompt('Enter number of days to extend:', '30');
			
			if (!days || isNaN(days) || days <= 0) {
				return;
			}
			
			var $button = $(this);
			var licenseId = $button.data('license-id');
			var $row = $button.closest('tr');
			
			$row.addClass('cf7license-loading');
			
			$.ajax({
				url: cf7license_admin.ajax_url,
				type: 'POST',
				data: {
					action: 'cf7license_extend_license',
					license_id: licenseId,
					days: days,
					nonce: cf7license_admin.nonce
				},
				success: function(response) {
					if (response.success) {
						alert(cf7license_admin.strings.success);
						window.location.reload();
					} else {
						alert(response.data.message || cf7license_admin.strings.error);
					}
				},
				error: function() {
					alert(cf7license_admin.strings.error);
				},
				complete: function() {
					$row.removeClass('cf7license-loading');
				}
			});
		},
		
		/**
		 * Handle cleanup expired
		 */
		handleCleanupExpired: function(e) {
			e.preventDefault();
			
			if (!confirm(cf7license_admin.strings.confirm_cleanup)) {
				return;
			}
			
			var $button = $(this);
			var originalText = $button.text();
			
			$button.text(cf7license_admin.strings.processing).prop('disabled', true);
			
			$.ajax({
				url: cf7license_admin.ajax_url,
				type: 'POST',
				data: {
					action: 'cf7license_cleanup_expired',
					nonce: cf7license_admin.nonce
				},
				success: function(response) {
					if (response.success) {
						alert(response.data.message);
						window.location.reload();
					} else {
						alert(response.data.message || cf7license_admin.strings.error);
					}
				},
				error: function() {
					alert(cf7license_admin.strings.error);
				},
				complete: function() {
					$button.text(originalText).prop('disabled', false);
				}
			});
		},
		
		/**
		 * Handle API key regeneration
		 */
		handleRegenerateApiKey: function(e) {
			e.preventDefault();
			
			if (!confirm('Are you sure you want to regenerate the API key? This will invalidate the current key.')) {
				return;
			}
			
			var newKey = CF7LicenseAdmin.generateRandomString(32);
			$('#api_secret_key').val(newKey);
		},
		
		/**
		 * Generate random string
		 */
		generateRandomString: function(length) {
			var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
			var result = '';
			
			for (var i = 0; i < length; i++) {
				result += chars.charAt(Math.floor(Math.random() * chars.length));
			}
			
			return result;
		}
	};
	
	// Initialize when document is ready
	$(document).ready(function() {
		CF7LicenseAdmin.init();
	});
	
})(jQuery);