/**
 * CF7 Conversation Runtime Engine
 */
(function($) {
    'use strict';
    
    // Runtime state
    let conversationState = {
        conversationId: null,
        sessionId: null,
        currentStep: null,
        answers: {},
        config: {},
        stepHistory: [],
        isLoading: false
    };
    
    // Initialize when document is ready
    $(document).ready(function() {
        initConversationRuntime();
    });
    
    /**
     * Initialize the conversation runtime
     */
    function initConversationRuntime() {
        // Load initial data
        loadInitialData();
        
        // Bind events
        bindEvents();
        
        // Render current step
        renderCurrentStep();
        
        // Setup auto-save
        if (cf7conv_runtime.settings.auto_save_interval > 0) {
            setInterval(autoSave, cf7conv_runtime.settings.auto_save_interval);
        }
        
        // Setup keyboard navigation
        if (cf7conv_runtime.settings.enable_keyboard_nav) {
            setupKeyboardNavigation();
        }
        
        console.log('CF7 Conversation Runtime initialized');
    }
    
    /**
     * Load initial data from DOM
     */
    function loadInitialData() {
        const $app = $('#cf7conv-app');
        
        conversationState.conversationId = $app.data('conversation-id');
        conversationState.sessionId = $app.data('session-id') || null;
        conversationState.currentStep = $app.data('current-step');
        
        // Load configuration
        const configScript = document.getElementById('cf7conv-config');
        if (configScript) {
            try {
                conversationState.config = JSON.parse(configScript.textContent);
                console.log('Loaded conversation config:', conversationState.config);
            } catch (e) {
                console.error('Failed to parse conversation config:', e);
                conversationState.config = { steps: [] };
            }
        } else {
            console.error('No config script found');
            conversationState.config = { steps: [] };
        }
        
        // Load existing answers
        const answersScript = document.getElementById('cf7conv-answers');
        if (answersScript) {
            try {
                conversationState.answers = JSON.parse(answersScript.textContent);
                console.log('Loaded existing answers:', conversationState.answers);
            } catch (e) {
                console.error('Failed to parse existing answers:', e);
                conversationState.answers = {};
            }
        } else {
            conversationState.answers = {};
        }
        
        console.log('Initial conversation state:', conversationState);
    }
    
    /**
     * Bind event handlers
     */
    function bindEvents() {
        // Next button
        $(document).on('click', '.cf7conv-btn-next', handleNextClick);
        
        // Back button
        $(document).on('click', '.cf7conv-btn-back', handleBackClick);
        
        // Form input changes
        $(document).on('change input', '.cf7conv-step-form input, .cf7conv-step-form select, .cf7conv-step-form textarea', handleInputChange);
        
        // Choice selection
        $(document).on('change', '.cf7conv-choice-input', handleChoiceChange);
        
        // Pricing updates
        $(document).on('change', '.cf7conv-pricing-trigger', handlePricingUpdate);
        
        // Payment button
        $(document).on('click', '.cf7conv-payment-btn', handlePaymentClick);
    }
    
    /**
     * Setup keyboard navigation
     */
    function setupKeyboardNavigation() {
        $(document).on('keydown', function(e) {
            if (conversationState.isLoading) return;
            
            switch (e.key) {
                case 'Enter':
                    if (!$(e.target).is('textarea')) {
                        e.preventDefault();
                        $('.cf7conv-btn-next:visible').click();
                    }
                    break;
                case 'Escape':
                    $('.cf7conv-btn-back:visible').click();
                    break;
                case 'ArrowLeft':
                    if (e.ctrlKey || e.metaKey) {
                        e.preventDefault();
                        $('.cf7conv-btn-back:visible').click();
                    }
                    break;
                case 'ArrowRight':
                    if (e.ctrlKey || e.metaKey) {
                        e.preventDefault();
                        $('.cf7conv-btn-next:visible').click();
                    }
                    break;
            }
        });
    }
    
    /**
     * Render the current step
     */
    function renderCurrentStep() {
        const step = getCurrentStep();
        if (!step) {
            console.error('Current step not found:', conversationState.currentStep);
            return;
        }
        
        const $container = $('.cf7conv-steps-container');
        const stepHtml = renderStep(step);
        
        // Animate step transition
        if (cf7conv_runtime.settings.animation_duration > 0) {
            $container.fadeOut(cf7conv_runtime.settings.animation_duration / 2, function() {
                $container.html(stepHtml).fadeIn(cf7conv_runtime.settings.animation_duration / 2);
                afterStepRender(step);
            });
        } else {
            $container.html(stepHtml);
            afterStepRender(step);
        }
        
        // Update navigation
        updateNavigation();
        
        // Update progress
        updateProgress();
    }
    
    /**
     * Render a step based on its type
     */
    function renderStep(step) {
        let html = `<div class="cf7conv-step cf7conv-step-${step.type}" data-step-id="${step.id}">`;
        
        if (step.title) {
            html += `<h2 class="cf7conv-step-title">${escapeHtml(step.title)}</h2>`;
        }
        
        if (step.content) {
            html += `<div class="cf7conv-step-content">${step.content}</div>`;
        }
        
        switch (step.type) {
            case 'question':
                html += renderQuestionStep(step);
                break;
            case 'choice':
                html += renderChoiceStep(step);
                break;
            case 'info':
                html += renderInfoStep(step);
                break;
            case 'logic':
                // Logic steps are processed automatically - show loading
                html += '<div class="cf7conv-logic-processing">';
                html += '<div class="cf7conv-spinner"></div>';
                html += '<p>Processing logic...</p>';
                html += '</div>';
                break;
            case 'conditional':
                // Conditional steps are processed automatically - show loading
                html += '<div class="cf7conv-conditional-processing">';
                html += '<div class="cf7conv-spinner"></div>';
                html += '<p>Evaluating conditions...</p>';
                html += '</div>';
                break;
            case 'pricing':
                html += renderPricingStep(step);
                break;
            case 'payment':
                html += renderPaymentStep(step);
                break;
            case 'result':
                html += renderResultStep(step);
                break;
            default:
                console.error('Unknown step type:', step.type);
                html += `<div class="cf7conv-error">
                    <p><strong>Error:</strong> Unknown step type "${escapeHtml(step.type)}"</p>
                    <p>Valid step types are: question, choice, info, logic, conditional, pricing, payment, result</p>
                </div>`;
        }
        
        html += '</div>';
        return html;
    }
    
    /**
     * Render question step
     */
    function renderQuestionStep(step) {
        const fieldName = step.field_name || step.id;
        const currentValue = conversationState.answers[fieldName] || '';
        const inputType = step.input_type || 'text';
        const required = step.required ? 'required' : '';
        const placeholder = step.placeholder || '';
        
        let html = '<form class="cf7conv-step-form">';
        
        switch (inputType) {
            case 'textarea':
                html += `<textarea name="${fieldName}" class="cf7conv-input" placeholder="${placeholder}" ${required}>${escapeHtml(currentValue)}</textarea>`;
                break;
            case 'email':
                html += `<input type="email" name="${fieldName}" class="cf7conv-input" value="${escapeHtml(currentValue)}" placeholder="${placeholder}" ${required}>`;
                break;
            case 'number':
                const min = step.min || '';
                const max = step.max || '';
                const stepAttr = step.step || '';
                html += `<input type="number" name="${fieldName}" class="cf7conv-input" value="${escapeHtml(currentValue)}" placeholder="${placeholder}" min="${min}" max="${max}" step="${stepAttr}" ${required}>`;
                break;
            default:
                html += `<input type="text" name="${fieldName}" class="cf7conv-input" value="${escapeHtml(currentValue)}" placeholder="${placeholder}" ${required}>`;
        }
        
        html += '</form>';
        return html;
    }
    
    /**
     * Render choice step
     */
    function renderChoiceStep(step) {
        const fieldName = step.field_name || step.id;
        const currentValue = conversationState.answers[fieldName] || (step.multiple ? [] : '');
        const choices = step.choices || [];
        
        let html = '<form class="cf7conv-step-form"><div class="cf7conv-choices">';
        
        choices.forEach(function(choice, index) {
            const choiceId = `${fieldName}_${index}`;
            const inputType = step.multiple ? 'checkbox' : 'radio';
            const isChecked = step.multiple 
                ? (Array.isArray(currentValue) && currentValue.includes(choice.value))
                : (currentValue === choice.value);
            
            html += `
                <div class="cf7conv-choice">
                    <input type="${inputType}" 
                           id="${choiceId}" 
                           name="${fieldName}" 
                           value="${escapeHtml(choice.value)}" 
                           class="cf7conv-choice-input"
                           ${isChecked ? 'checked' : ''}>
                    <label for="${choiceId}" class="cf7conv-choice-label">
                        ${escapeHtml(choice.label)}
                        ${choice.description ? `<span class="cf7conv-choice-description">${escapeHtml(choice.description)}</span>` : ''}
                    </label>
                </div>
            `;
        });
        
        html += '</div></form>';
        return html;
    }
    
    /**
     * Render info step
     */
    function renderInfoStep(step) {
        return ''; // Content already rendered in main step container
    }
    
    /**
     * Render pricing step
     */
    function renderPricingStep(step) {
        const total = calculatePricing(step.pricing_rules || []);
        
        let html = '<div class="cf7conv-pricing-display">';
        html += `<div class="cf7conv-price-total">Total: <span class="cf7conv-price-amount" data-amount="${total}">$${total.toFixed(2)}</span></div>`;
        
        if (step.pricing_breakdown) {
            html += '<div class="cf7conv-price-breakdown">';
            // Add breakdown logic here
            html += '</div>';
        }
        
        html += '</div>';
        return html;
    }
    
    /**
     * Render payment step
     */
    function renderPaymentStep(step) {
        const total = calculatePricing(step.pricing_rules || []);
        
        let html = '<div class="cf7conv-payment-section">';
        html += `<div class="cf7conv-payment-total">Amount to pay: <strong>$${total.toFixed(2)}</strong></div>`;
        
        if (total > 0) {
            html += '<button type="button" class="cf7conv-payment-btn cf7conv-btn cf7conv-btn-primary">Proceed to Payment</button>';
        } else {
            html += '<p class="cf7conv-free-message">This is free! Click Next to continue.</p>';
        }
        
        html += '</div>';
        return html;
    }
    
    /**
     * Render result step
     */
    function renderResultStep(step) {
        let html = '<div class="cf7conv-result-section">';
        
        if (step.show_summary) {
            html += '<div class="cf7conv-summary">';
            html += '<h3>Summary</h3>';
            html += renderAnswersSummary();
            html += '</div>';
        }
        
        if (step.actions) {
            html += '<div class="cf7conv-result-actions">';
            step.actions.forEach(function(action) {
                html += `<a href="${action.url}" class="cf7conv-btn cf7conv-btn-secondary">${escapeHtml(action.label)}</a>`;
            });
            html += '</div>';
        }
        
        html += '</div>';
        return html;
    }
    
    /**
     * Render answers summary
     */
    function renderAnswersSummary() {
        let html = '<div class="cf7conv-answers-summary">';
        
        Object.keys(conversationState.answers).forEach(function(key) {
            const value = conversationState.answers[key];
            if (value && value !== '') {
                html += `<div class="cf7conv-answer-item">`;
                html += `<span class="cf7conv-answer-label">${escapeHtml(key)}:</span> `;
                html += `<span class="cf7conv-answer-value">${escapeHtml(String(value))}</span>`;
                html += `</div>`;
            }
        });
        
        html += '</div>';
        return html;
    }
    
    /**
     * After step render callback
     */
    function afterStepRender(step) {
        // Auto-process logic and conditional steps
        if (step.type === 'logic' || step.type === 'conditional') {
            // Process the step automatically after a short delay
            setTimeout(function() {
                processLogicStep(step);
            }, 500);
            return;
        }
        
        // Focus first input
        $('.cf7conv-input:first').focus();
        
        // Trigger pricing update if needed
        if (step.type === 'pricing') {
            updatePricingDisplay();
        }
        
        // Emit analytics event
        emitAnalyticsEvent('step_viewed', {
            step_id: step.id,
            step_type: step.type
        });
    }
    
    /**
     * Handle next button click
     */
    function handleNextClick(e) {
        e.preventDefault();
        
        if (conversationState.isLoading) return;
        
        const currentStep = getCurrentStep();
        if (!currentStep) return;
        
        // Validate current step
        if (!validateCurrentStep()) {
            return;
        }
        
        // Save current step data
        saveCurrentStepData();
        
        // Determine next step
        const nextStepId = determineNextStep(currentStep);
        if (nextStepId) {
            navigateToStep(nextStepId);
        } else {
            completeConversation();
        }
    }
    
    /**
     * Handle back button click
     */
    function handleBackClick(e) {
        e.preventDefault();
        
        if (conversationState.isLoading || conversationState.stepHistory.length === 0) return;
        
        const previousStepId = conversationState.stepHistory.pop();
        navigateToStep(previousStepId, false);
    }
    
    /**
     * Handle input changes
     */
    function handleInputChange(e) {
        const $input = $(e.target);
        const fieldName = $input.attr('name');
        const value = $input.val();
        
        if (fieldName) {
            conversationState.answers[fieldName] = value;
        }
        
        // Trigger pricing update if this is a pricing trigger
        if ($input.hasClass('cf7conv-pricing-trigger')) {
            updatePricingDisplay();
        }
    }
    
    /**
     * Handle choice changes
     */
    function handleChoiceChange(e) {
        const $input = $(e.target);
        const fieldName = $input.attr('name');
        const value = $input.val();
        const isMultiple = $input.attr('type') === 'checkbox';
        
        if (isMultiple) {
            if (!Array.isArray(conversationState.answers[fieldName])) {
                conversationState.answers[fieldName] = [];
            }
            
            if ($input.is(':checked')) {
                if (!conversationState.answers[fieldName].includes(value)) {
                    conversationState.answers[fieldName].push(value);
                }
            } else {
                const index = conversationState.answers[fieldName].indexOf(value);
                if (index > -1) {
                    conversationState.answers[fieldName].splice(index, 1);
                }
            }
        } else {
            conversationState.answers[fieldName] = value;
        }
        
        // Trigger pricing update if this is a pricing trigger
        if ($input.hasClass('cf7conv-pricing-trigger')) {
            updatePricingDisplay();
        }
    }
    
    /**
     * Handle pricing updates
     */
    function handlePricingUpdate() {
        updatePricingDisplay();
    }
    
    /**
     * Handle payment button click
     */
    function handlePaymentClick(e) {
        e.preventDefault();
        
        const currentStep = getCurrentStep();
        if (!currentStep || currentStep.type !== 'payment') return;
        
        // Save current state
        saveCurrentStepData();
        
        // Create order and redirect to payment
        createOrderAndRedirect();
    }
    
    /**
     * Validate current step
     */
    function validateCurrentStep() {
        const currentStep = getCurrentStep();
        if (!currentStep) return true;
        
        const $form = $('.cf7conv-step-form');
        if ($form.length === 0) return true;
        
        // Check required fields
        let isValid = true;
        $form.find('[required]').each(function() {
            const $field = $(this);
            const value = $field.val();
            
            if (!value || value.trim() === '') {
                $field.addClass('cf7conv-error');
                isValid = false;
            } else {
                $field.removeClass('cf7conv-error');
            }
        });
        
        if (!isValid) {
            showMessage('Please fill in all required fields.', 'error');
        }
        
        return isValid;
    }
    
    /**
     * Save current step data
     */
    function saveCurrentStepData() {
        const currentStep = getCurrentStep();
        if (!currentStep) return;
        
        // Collect form data
        const $form = $('.cf7conv-step-form');
        if ($form.length > 0) {
            const formData = {};
            $form.find('input, select, textarea').each(function() {
                const $field = $(this);
                const name = $field.attr('name');
                const type = $field.attr('type');
                
                if (name) {
                    if (type === 'checkbox') {
                        if (!Array.isArray(formData[name])) {
                            formData[name] = [];
                        }
                        if ($field.is(':checked')) {
                            formData[name].push($field.val());
                        }
                    } else if (type === 'radio') {
                        if ($field.is(':checked')) {
                            formData[name] = $field.val();
                        }
                    } else {
                        formData[name] = $field.val();
                    }
                }
            });
            
            // Merge with existing answers
            Object.assign(conversationState.answers, formData);
        }
        
        // Save to server
        saveToServer();
    }
    
    /**
     * Save data to server
     */
    function saveToServer() {
        if (conversationState.isLoading) return;
        
        conversationState.isLoading = true;
        showLoading();
        
        $.ajax({
            url: cf7conv_runtime.ajax_url,
            type: 'POST',
            data: {
                action: 'cf7conv_save_step',
                nonce: cf7conv_runtime.nonce,
                conversation_id: conversationState.conversationId,
                session_id: conversationState.sessionId,
                step_id: conversationState.currentStep,
                step_data: conversationState.answers
            },
            success: function(response) {
                if (response.success) {
                    if (!conversationState.sessionId) {
                        conversationState.sessionId = response.data.session_id;
                    }
                } else {
                    console.error('Failed to save step data:', response.data);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error saving step data:', error);
            },
            complete: function() {
                conversationState.isLoading = false;
                hideLoading();
            }
        });
    }
    
    /**
     * Auto-save function
     */
    function autoSave() {
        if (!conversationState.isLoading && conversationState.sessionId) {
            saveToServer();
        }
    }
    
    /**
     * Navigate to a step
     */
    function navigateToStep(stepId, addToHistory = true) {
        if (addToHistory && conversationState.currentStep) {
            conversationState.stepHistory.push(conversationState.currentStep);
        }
        
        conversationState.currentStep = stepId;
        renderCurrentStep();
        
        // Emit analytics event
        emitAnalyticsEvent('step_navigation', {
            from_step: conversationState.stepHistory[conversationState.stepHistory.length - 1] || null,
            to_step: stepId
        });
    }
    
    /**
     * Determine next step based on logic
     */
    function determineNextStep(currentStep) {
        // Simple next step
        if (currentStep.next_step) {
            return currentStep.next_step;
        }
        
        // Conditional logic
        if (currentStep.logic && Array.isArray(currentStep.logic)) {
            for (let rule of currentStep.logic) {
                if (evaluateCondition(rule.condition)) {
                    return rule.next_step;
                }
            }
        }
        
        // Default: find next step in sequence
        const steps = conversationState.config.steps || [];
        const currentIndex = steps.findIndex(step => step.id === currentStep.id);
        if (currentIndex >= 0 && currentIndex < steps.length - 1) {
            return steps[currentIndex + 1].id;
        }
        
        return null;
    }
    
    /**
     * Process logic/conditional step automatically
     */
    function processLogicStep(step) {
        console.log('Processing logic/conditional step:', step.id);
        
        // Determine next step based on the logic
        const nextStepId = determineNextStep(step);
        
        if (nextStepId) {
            // Navigate to the next step
            navigateToStep(nextStepId);
        } else {
            // No next step found, complete the conversation
            completeConversation();
        }
    }
    
    /**
     * Evaluate a condition against current answers
     */
    function evaluateCondition(condition) {
        if (!condition || !condition.field) {
            return false;
        }
        
        const fieldValue = conversationState.answers[condition.field];
        const compareValue = condition.value;
        const operator = condition.operator || 'equals';
        
        switch (operator) {
            case 'equals':
                return fieldValue === compareValue;
            case 'not_equals':
                return fieldValue !== compareValue;
            case 'contains':
                return String(fieldValue || '').indexOf(String(compareValue || '')) !== -1;
            case 'not_contains':
                return String(fieldValue || '').indexOf(String(compareValue || '')) === -1;
            case 'greater_than':
                return parseFloat(fieldValue || 0) > parseFloat(compareValue || 0);
            case 'less_than':
                return parseFloat(fieldValue || 0) < parseFloat(compareValue || 0);
            case 'is_empty':
                return !fieldValue || fieldValue === '';
            case 'is_not_empty':
                return fieldValue && fieldValue !== '';
            default:
                console.warn('Unknown condition operator:', operator);
                return false;
        }
    }
    
    /**
     * Complete the conversation
     */
    function completeConversation() {
        console.log('Completing conversation');
        
        // Update session status
        conversationState.isLoading = true;
        
        // Send completion to server
        $.ajax({
            url: cf7conv_runtime.ajax_url,
            type: 'POST',
            data: {
                action: 'cf7conv_complete_session',
                nonce: cf7conv_runtime.nonce,
                session_id: conversationState.sessionId,
                answers: JSON.stringify(conversationState.answers)
            },
            success: function(response) {
                if (response.success) {
                    // Show completion message
                    $('.cf7conv-steps-container').html(`
                        <div class="cf7conv-step cf7conv-step-completed">
                            <h2>Conversation Completed</h2>
                            <p>Thank you for completing the conversation!</p>
                        </div>
                    `);
                    
                    // Hide navigation
                    $('.cf7conv-navigation').hide();
                    
                    // Emit completion event
                    emitAnalyticsEvent('conversation_completed', {
                        total_steps: conversationState.stepHistory.length + 1,
                        answers: conversationState.answers
                    });
                } else {
                    showMessage('Failed to complete conversation: ' + (response.data || 'Unknown error'), 'error');
                }
            },
            error: function() {
                showMessage('Failed to complete conversation. Please try again.', 'error');
            },
            complete: function() {
                conversationState.isLoading = false;
            }
        });
    }
    
    /**
     * Evaluate a condition
     */
    function evaluateCondition(condition) {
        if (!condition || !condition.field) return false;
        
        const fieldValue = conversationState.answers[condition.field] || '';
        const compareValue = condition.value || '';
        
        switch (condition.operator) {
            case 'equals':
                return fieldValue === compareValue;
            case 'not_equals':
                return fieldValue !== compareValue;
            case 'contains':
                return String(fieldValue).indexOf(compareValue) !== -1;
            case 'not_contains':
                return String(fieldValue).indexOf(compareValue) === -1;
            case 'greater_than':
                return parseFloat(fieldValue) > parseFloat(compareValue);
            case 'less_than':
                return parseFloat(fieldValue) < parseFloat(compareValue);
            case 'is_empty':
                return !fieldValue || fieldValue === '';
            case 'is_not_empty':
                return fieldValue && fieldValue !== '';
            default:
                return false;
        }
    }
    
    /**
     * Calculate pricing
     */
    function calculatePricing(pricingRules) {
        let total = 0;
        
        pricingRules.forEach(function(rule) {
            switch (rule.type) {
                case 'base':
                    total += parseFloat(rule.amount || 0);
                    break;
                case 'conditional':
                    if (evaluateCondition(rule.condition)) {
                        total += parseFloat(rule.amount || 0);
                    }
                    break;
                case 'multiplier':
                    if (rule.field && conversationState.answers[rule.field]) {
                        const multiplier = parseFloat(conversationState.answers[rule.field]);
                        total += multiplier * parseFloat(rule.amount || 0);
                    }
                    break;
            }
        });
        
        return Math.max(0, total);
    }
    
    /**
     * Update pricing display
     */
    function updatePricingDisplay() {
        const currentStep = getCurrentStep();
        if (!currentStep || currentStep.type !== 'pricing') return;
        
        const total = calculatePricing(currentStep.pricing_rules || []);
        $('.cf7conv-price-amount').text('$' + total.toFixed(2)).attr('data-amount', total);
        
        // Emit analytics event
        emitAnalyticsEvent('pricing_calculated', {
            step_id: currentStep.id,
            total: total
        });
    }
    
    /**
     * Create order and redirect to payment
     */
    function createOrderAndRedirect() {
        // This would integrate with CF7 Mini Ecommerce
        // For now, just simulate payment completion
        setTimeout(function() {
            conversationState.answers._payment_status = 'completed';
            const nextStepId = determineNextStep(getCurrentStep());
            if (nextStepId) {
                navigateToStep(nextStepId);
            } else {
                completeConversation();
            }
        }, 1000);
    }
    
    /**
     * Complete the conversation
     */
    function completeConversation() {
        // Mark session as completed
        if (conversationState.sessionId) {
            $.ajax({
                url: cf7conv_runtime.ajax_url,
                type: 'POST',
                data: {
                    action: 'cf7conv_complete_session',
                    nonce: cf7conv_runtime.nonce,
                    session_id: conversationState.sessionId
                }
            });
        }
        
        // Show completion message
        $('.cf7conv-steps-container').html(`
            <div class="cf7conv-completion">
                <h2>Thank You!</h2>
                <p>Your conversation has been completed successfully.</p>
            </div>
        `);
        
        $('.cf7conv-navigation').hide();
        
        // Emit analytics event
        emitAnalyticsEvent('conversation_completed', {
            conversation_id: conversationState.conversationId,
            session_id: conversationState.sessionId,
            total_steps: conversationState.stepHistory.length + 1
        });
    }
    
    /**
     * Update navigation buttons
     */
    function updateNavigation() {
        const $backBtn = $('.cf7conv-btn-back');
        const $nextBtn = $('.cf7conv-btn-next');
        
        // Show/hide back button
        if (conversationState.stepHistory.length > 0) {
            $backBtn.show();
        } else {
            $backBtn.hide();
        }
        
        // Update next button text
        const currentStep = getCurrentStep();
        if (currentStep) {
            const isLastStep = !currentStep.next_step && !currentStep.logic;
            $nextBtn.text(isLastStep ? 'Complete' : 'Next');
        }
    }
    
    /**
     * Update progress bar
     */
    function updateProgress() {
        const steps = conversationState.config.steps || [];
        const currentIndex = steps.findIndex(step => step.id === conversationState.currentStep);
        const progress = steps.length > 0 ? ((currentIndex + 1) / steps.length) * 100 : 0;
        
        $('.cf7conv-progress-fill').css('width', progress + '%');
    }
    
    /**
     * Get current step object
     */
    function getCurrentStep() {
        const steps = conversationState.config.steps || [];
        return steps.find(step => step.id === conversationState.currentStep);
    }
    
    /**
     * Show loading state
     */
    function showLoading() {
        $('.cf7conv-loading').show();
    }
    
    /**
     * Hide loading state
     */
    function hideLoading() {
        $('.cf7conv-loading').hide();
    }
    
    /**
     * Show message to user
     */
    function showMessage(message, type = 'info') {
        const $message = $(`<div class="cf7conv-message cf7conv-message-${type}">${escapeHtml(message)}</div>`);
        $('.cf7conv-container').prepend($message);
        
        setTimeout(function() {
            $message.fadeOut(function() {
                $message.remove();
            });
        }, 5000);
    }
    
    /**
     * Emit analytics event
     */
    function emitAnalyticsEvent(eventType, data) {
        // Emit custom event for analytics tracking
        $(document).trigger('cf7conv_analytics', {
            event_type: eventType,
            conversation_id: conversationState.conversationId,
            session_id: conversationState.sessionId,
            timestamp: new Date().toISOString(),
            data: data
        });
    }
    
    /**
     * Escape HTML
     */
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    /**
     * Render payment step
     */
    function renderPaymentStep(step) {
        const total = calculatePricing(step.pricing_rules || []);
        
        let html = '<div class="cf7conv-payment-section">';
        html += `<div class="cf7conv-payment-total">Amount to pay: <strong>${cf7conv_runtime.format_price ? cf7conv_runtime.format_price(total) : '$' + total.toFixed(2)}</strong></div>`;
        
        if (total > 0) {
            // Check if CF7 Mini Ecommerce is available
            if (cf7conv_runtime.ecommerce_available) {
                html += '<div class="cf7conv-payment-gateways">';
                html += '<h4>Select Payment Method:</h4>';
                
                // Add payment gateway options
                const gateways = cf7conv_runtime.payment_gateways || [];
                if (gateways.length > 0) {
                    gateways.forEach(function(gateway) {
                        html += `
                            <div class="cf7conv-gateway-option">
                                <input type="radio" id="gateway_${gateway.id}" name="payment_gateway" value="${gateway.id}" class="cf7conv-gateway-input">
                                <label for="gateway_${gateway.id}" class="cf7conv-gateway-label">
                                    <span class="cf7conv-gateway-name">${escapeHtml(gateway.name)}</span>
                                    ${gateway.description ? `<span class="cf7conv-gateway-description">${escapeHtml(gateway.description)}</span>` : ''}
                                </label>
                            </div>
                        `;
                    });
                    
                    html += '</div>';
                    html += '<button type="button" class="cf7conv-payment-btn cf7conv-btn cf7conv-btn-primary">Proceed to Payment</button>';
                } else {
                    html += '<p class="cf7conv-error">No payment methods available.</p>';
                }
            } else {
                html += '<p class="cf7conv-error">Payment processing is not available. Please ensure CF7 Mini Ecommerce is installed and activated.</p>';
            }
        } else {
            html += '<p class="cf7conv-free-message">This is free! Click Next to continue.</p>';
        }
        
        html += '</div>';
        return html;
    }
    
    /**
     * Render pricing step
     */
    function renderPricingStep(step) {
        const total = calculatePricing(step.pricing_rules || []);
        
        let html = '<div class="cf7conv-pricing-section">';
        html += '<div class="cf7conv-pricing-breakdown">';
        
        // Show pricing breakdown
        const breakdown = getPricingBreakdown(step.pricing_rules || []);
        breakdown.forEach(function(item) {
            html += `<div class="cf7conv-pricing-item">
                <span class="cf7conv-pricing-label">${escapeHtml(item.label)}</span>
                <span class="cf7conv-pricing-value">${cf7conv_runtime.format_price ? cf7conv_runtime.format_price(item.value) : '$' + item.value.toFixed(2)}</span>
            </div>`;
        });
        
        html += `<div class="cf7conv-pricing-total">
            <span class="cf7conv-pricing-label"><strong>Total:</strong></span>
            <span class="cf7conv-pricing-value"><strong>${cf7conv_runtime.format_price ? cf7conv_runtime.format_price(total) : '$' + total.toFixed(2)}</strong></span>
        </div>`;
        
        html += '</div></div>';
        return html;
    }
    
    /**
     * Handle payment button click
     */
    function handlePaymentClick(e) {
        e.preventDefault();
        
        const $button = $(e.currentTarget);
        const selectedGateway = $('input[name="payment_gateway"]:checked').val();
        
        if (!selectedGateway) {
            showMessage('Please select a payment method.', 'error');
            return;
        }
        
        // Disable button and show loading
        $button.prop('disabled', true).text('Processing...');
        
        // Prepare payment data
        const paymentData = {
            conversation_id: conversationState.conversationId,
            session_id: conversationState.sessionId,
            step_id: conversationState.currentStep,
            gateway: selectedGateway,
            amount: calculatePricing(getCurrentStep().pricing_rules || []),
            email: conversationState.answers.email || '',
            customer_name: conversationState.answers.name || conversationState.answers.customer_name || '',
            items: getOrderItems(),
        };
        
        // Trigger payment initialization event
        $(document).trigger('cf7conv:step:payment:init', paymentData);
        
        // Initialize inline checkout
        initializeInlineCheckout(paymentData);
    }
    
    /**
     * Initialize inline checkout
     */
    function initializeInlineCheckout(paymentData) {
        // Check if CF7MC inline checkout is available
        if (window.CF7MC_InlineCheckout) {
            // Create order first
            $.ajax({
                url: cf7conv_runtime.ajax_url,
                type: 'POST',
                data: {
                    action: 'cf7mc_create_order',
                    nonce: cf7conv_runtime.nonce,
                    step_data: paymentData
                },
                success: function(response) {
                    if (response.success) {
                        // Initialize payment session
                        window.CF7MC_InlineCheckout.initializeCheckout(response.data.order_id, paymentData.gateway);
                    } else {
                        showMessage(response.data.message || 'Failed to create order.', 'error');
                        resetPaymentButton();
                    }
                },
                error: function() {
                    showMessage('Payment initialization failed. Please try again.', 'error');
                    resetPaymentButton();
                }
            });
        } else {
            showMessage('Payment system not available. Please refresh the page and try again.', 'error');
            resetPaymentButton();
        }
    }
    
    /**
     * Reset payment button
     */
    function resetPaymentButton() {
        $('.cf7conv-payment-btn').prop('disabled', false).text('Proceed to Payment');
    }
    
    /**
     * Get order items from conversation answers
     */
    function getOrderItems() {
        const items = [];
        const currentStep = getCurrentStep();
        
        // Add items based on pricing rules
        if (currentStep && currentStep.pricing_rules) {
            currentStep.pricing_rules.forEach(function(rule) {
                if (rule.type === 'fixed' || rule.type === 'multiplier') {
                    items.push({
                        name: rule.label || 'Service',
                        price: rule.value || 0,
                        quantity: 1
                    });
                }
            });
        }
        
        // Add items from conversation answers
        Object.keys(conversationState.answers).forEach(function(key) {
            const value = conversationState.answers[key];
            if (Array.isArray(value)) {
                value.forEach(function(item) {
                    items.push({
                        name: key + ': ' + item,
                        price: 0,
                        quantity: 1
                    });
                });
            }
        });
        
        return items;
    }
    
    /**
     * Calculate pricing based on rules
     */
    function calculatePricing(pricingRules) {
        let total = 0;
        
        pricingRules.forEach(function(rule) {
            switch (rule.type) {
                case 'fixed':
                    total += parseFloat(rule.value || 0);
                    break;
                case 'multiplier':
                    const fieldValue = conversationState.answers[rule.field] || 0;
                    total += parseFloat(fieldValue) * parseFloat(rule.multiplier || 1);
                    break;
                case 'conditional':
                    const conditionValue = conversationState.answers[rule.field];
                    if (conditionValue === rule.condition_value) {
                        total += parseFloat(rule.value || 0);
                    }
                    break;
            }
        });
        
        return Math.max(0, total);
    }
    
    /**
     * Get pricing breakdown
     */
    function getPricingBreakdown(pricingRules) {
        const breakdown = [];
        
        pricingRules.forEach(function(rule) {
            let value = 0;
            let label = rule.label || 'Item';
            
            switch (rule.type) {
                case 'fixed':
                    value = parseFloat(rule.value || 0);
                    break;
                case 'multiplier':
                    const fieldValue = conversationState.answers[rule.field] || 0;
                    value = parseFloat(fieldValue) * parseFloat(rule.multiplier || 1);
                    label += ` (${fieldValue} × ${rule.multiplier})`;
                    break;
                case 'conditional':
                    const conditionValue = conversationState.answers[rule.field];
                    if (conditionValue === rule.condition_value) {
                        value = parseFloat(rule.value || 0);
                        label += ` (${conditionValue})`;
                    }
                    break;
            }
            
            if (value > 0) {
                breakdown.push({ label, value });
            }
        });
        
        return breakdown;
    }
    
    // Expose global functions for external access
    window.CF7CONV = {
        nextStep: function() {
            $('.cf7conv-btn-next:visible').click();
        },
        previousStep: function() {
            $('.cf7conv-btn-back:visible').click();
        },
        getCurrentStep: getCurrentStep,
        getAnswers: function() {
            return conversationState.answers;
        },
        setAnswer: function(field, value) {
            conversationState.answers[field] = value;
        }
    };

})(jQuery);