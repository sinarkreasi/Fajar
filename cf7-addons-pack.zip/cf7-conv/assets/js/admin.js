/**
 * CF7 Conversation Admin JavaScript
 */
(function($) {
    'use strict';
    
    // Initialize when document is ready
    $(document).ready(function() {
        initConversationAdmin();
    });
    
    /**
     * Initialize admin functionality
     */
    function initConversationAdmin() {
        // Initialize color picker
        $('.cf7conv-color-picker').wpColorPicker();
        
        // Bind events
        bindEvents();
        
        // Initialize conversation builder if present
        if ($('#cf7conv-builder').length > 0) {
            initConversationBuilder();
        }
        
        console.log('CF7 Conversation Admin initialized');
    }
    
    /**
     * Bind event handlers
     */
    function bindEvents() {
        // Delete conversation
        $(document).on('click', '.cf7conv-delete-conversation', handleDeleteConversation);
        
        // Duplicate conversation
        $(document).on('click', '.cf7conv-duplicate-conversation', handleDuplicateConversation);
        
        // Save conversation
        $(document).on('click', '.cf7conv-save-conversation', handleSaveConversation);
        
        // Add step
        $(document).on('click', '.cf7conv-add-step', handleAddStep);
        
        // Delete step
        $(document).on('click', '.cf7conv-delete-step', handleDeleteStep);
        
        // Step type change
        $(document).on('change', '.cf7conv-step-type', handleStepTypeChange);
        
        // Toggle step settings
        $(document).on('click', '.cf7conv-step-header', handleToggleStepSettings);
        
        // Add/remove choice
        $(document).on('click', '.cf7conv-add-choice', handleAddChoice);
        $(document).on('click', '.cf7conv-remove-choice', handleRemoveChoice);
        
        // Add/remove pricing rule
        $(document).on('click', '.cf7conv-add-pricing-rule', handleAddPricingRule);
        $(document).on('click', '.cf7conv-remove-rule', handleRemovePricingRule);
        
        // Add/remove logic rule
        $(document).on('click', '.cf7conv-add-logic-rule', handleAddLogicRule);
        $(document).on('click', '.cf7conv-remove-logic-rule', handleRemoveLogicRule);
    }
    
    /**
     * Initialize conversation builder
     */
    function initConversationBuilder() {
        // Make steps sortable
        $('#cf7conv-steps-list').sortable({
            handle: '.cf7conv-step-handle',
            placeholder: 'cf7conv-step-placeholder',
            update: function() {
                updateStepOrder();
            }
        });
        
        // Load existing configuration
        loadConversationConfig();
    }
    
    /**
     * Handle delete conversation
     */
    function handleDeleteConversation(e) {
        e.preventDefault();
        
        if (!confirm(cf7conv_admin.strings.confirm_delete)) {
            return;
        }
        
        const conversationId = $(this).data('id');
        
        $.ajax({
            url: cf7conv_admin.ajax_url,
            type: 'POST',
            data: {
                action: 'cf7conv_delete_conversation',
                nonce: cf7conv_admin.nonce,
                conversation_id: conversationId
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert('Error: ' + response.data);
                }
            },
            error: function() {
                alert('An error occurred while deleting the conversation.');
            }
        });
    }
    
    /**
     * Handle duplicate conversation
     */
    function handleDuplicateConversation(e) {
        e.preventDefault();
        
        const conversationId = $(this).data('id');
        
        $.ajax({
            url: cf7conv_admin.ajax_url,
            type: 'POST',
            data: {
                action: 'cf7conv_duplicate_conversation',
                nonce: cf7conv_admin.nonce,
                conversation_id: conversationId
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert('Error: ' + response.data);
                }
            },
            error: function() {
                alert('An error occurred while duplicating the conversation.');
            }
        });
    }
    
    /**
     * Handle save conversation
     */
    function handleSaveConversation(e) {
        e.preventDefault();
        
        const conversationData = collectConversationData();
        
        if (!validateConversationData(conversationData)) {
            return;
        }
        
        showLoading();
        
        $.ajax({
            url: cf7conv_admin.ajax_url,
            type: 'POST',
            data: {
                action: 'cf7conv_save_conversation',
                nonce: cf7conv_admin.nonce,
                ...conversationData
            },
            success: function(response) {
                if (response.success) {
                    showNotice('Conversation saved successfully!', 'success');
                    
                    // Update URL if this was a new conversation
                    if (response.data.conversation_id && !getConversationId()) {
                        const newUrl = window.location.href + '&id=' + response.data.conversation_id;
                        window.history.replaceState({}, '', newUrl);
                    }
                } else {
                    showNotice('Error: ' + response.data, 'error');
                }
            },
            error: function() {
                showNotice('An error occurred while saving the conversation.', 'error');
            },
            complete: function() {
                hideLoading();
            }
        });
    }
    
    /**
     * Handle add step
     */
    function handleAddStep(e) {
        e.preventDefault();
        
        const stepType = $(this).data('type') || 'question';
        const stepId = 'step_' + Date.now();
        
        const stepHtml = createStepHtml(stepId, stepType);
        $('#cf7conv-steps-list').append(stepHtml);
        
        // Scroll to new step
        const $newStep = $('#cf7conv-step-' + stepId);
        $newStep[0].scrollIntoView({ behavior: 'smooth' });
        
        // Focus on title field
        $newStep.find('.cf7conv-step-title-input').focus();
    }
    
    /**
     * Handle delete step
     */
    function handleDeleteStep(e) {
        e.preventDefault();
        
        if (!confirm('Are you sure you want to delete this step?')) {
            return;
        }
        
        $(this).closest('.cf7conv-step-item').remove();
    }
    
    /**
     * Handle step type change
     */
    function handleStepTypeChange(e) {
        const $step = $(this).closest('.cf7conv-step-item');
        const stepType = $(this).val();
        
        // Update step settings based on type
        updateStepSettings($step, stepType);
    }
    
    /**
     * Handle toggle step settings
     */
    function handleToggleStepSettings(e) {
        const $step = $(this).closest('.cf7conv-step-item');
        const $settings = $step.find('.cf7conv-step-settings');
        
        $settings.slideToggle();
        $step.toggleClass('cf7conv-step-collapsed');
    }
    
    /**
     * Handle add choice
     */
    function handleAddChoice(e) {
        e.preventDefault();
        
        const $choicesEditor = $(this).closest('.cf7conv-choices-editor');
        const $step = $(this).closest('.cf7conv-step-item');
        const stepId = $step.data('step-id');
        const choiceIndex = $choicesEditor.find('.cf7conv-choice-item').length;
        
        const choiceHtml = `
            <div class="cf7conv-choice-item">
                <input type="text" name="steps[${stepId}][choices][${choiceIndex}][label]" placeholder="Choice label">
                <input type="text" name="steps[${stepId}][choices][${choiceIndex}][value]" placeholder="Choice value">
                <button type="button" class="cf7conv-remove-choice button-link-delete">Remove</button>
            </div>
        `;
        
        $(this).before(choiceHtml);
    }
    
    /**
     * Handle remove choice
     */
    function handleRemoveChoice(e) {
        e.preventDefault();
        $(this).closest('.cf7conv-choice-item').remove();
    }
    
    /**
     * Handle add pricing rule
     */
    function handleAddPricingRule(e) {
        e.preventDefault();
        
        const $rulesContainer = $(this).closest('.cf7conv-pricing-rules');
        const $step = $(this).closest('.cf7conv-step-item');
        const stepId = $step.data('step-id');
        const ruleIndex = $rulesContainer.find('.cf7conv-pricing-rule').length;
        
        const ruleHtml = `
            <div class="cf7conv-pricing-rule">
                <select name="steps[${stepId}][pricing_rules][${ruleIndex}][type]">
                    <option value="base">Base Price</option>
                    <option value="conditional">Conditional</option>
                    <option value="multiplier">Multiplier</option>
                </select>
                <input type="number" name="steps[${stepId}][pricing_rules][${ruleIndex}][amount]" placeholder="Amount" step="0.01">
                <button type="button" class="cf7conv-remove-rule button-link-delete">Remove</button>
            </div>
        `;
        
        $(this).before(ruleHtml);
    }
    
    /**
     * Handle remove pricing rule
     */
    function handleRemovePricingRule(e) {
        e.preventDefault();
        $(this).closest('.cf7conv-pricing-rule').remove();
    }
    
    /**
     * Handle add logic rule
     */
    function handleAddLogicRule(e) {
        e.preventDefault();
        
        const $rulesContainer = $(this).closest('.cf7conv-logic-rules');
        const $step = $(this).closest('.cf7conv-step-item');
        const stepId = $step.data('step-id');
        const ruleIndex = $rulesContainer.find('.cf7conv-logic-rule').length;
        
        const ruleHtml = `
            <div class="cf7conv-logic-rule">
                <select name="steps[${stepId}][logic][${ruleIndex}][condition][field]">
                    <option value="">Select field...</option>
                </select>
                <select name="steps[${stepId}][logic][${ruleIndex}][condition][operator]">
                    <option value="equals">Equals</option>
                    <option value="not_equals">Not Equals</option>
                    <option value="contains">Contains</option>
                    <option value="not_contains">Not Contains</option>
                    <option value="greater_than">Greater Than</option>
                    <option value="less_than">Less Than</option>
                    <option value="is_empty">Is Empty</option>
                    <option value="is_not_empty">Is Not Empty</option>
                </select>
                <input type="text" name="steps[${stepId}][logic][${ruleIndex}][condition][value]" placeholder="Value">
                <select name="steps[${stepId}][logic][${ruleIndex}][next_step]">
                    <option value="">Select next step...</option>
                </select>
                <button type="button" class="cf7conv-remove-logic-rule button-link-delete">Remove</button>
            </div>
        `;
        
        $(this).before(ruleHtml);
    }
    
    /**
     * Handle remove logic rule
     */
    function handleRemoveLogicRule(e) {
        e.preventDefault();
        $(this).closest('.cf7conv-logic-rule').remove();
    }
    
    /**
     * Create step HTML
     */
    function createStepHtml(stepId, stepType) {
        const stepTypes = cf7conv_admin.strings.step_types;
        const stepTypeInfo = stepTypes[stepType] || stepTypes.question;
        
        return `
            <div class="cf7conv-step-item" id="cf7conv-step-${stepId}" data-step-id="${stepId}">
                <div class="cf7conv-step-header">
                    <div class="cf7conv-step-handle">
                        <span class="dashicons dashicons-menu"></span>
                    </div>
                    <div class="cf7conv-step-info">
                        <span class="cf7conv-step-icon dashicons ${stepTypeInfo.icon}"></span>
                        <input type="text" class="cf7conv-step-title-input" placeholder="Step Title" value="New ${stepTypeInfo.label}">
                        <span class="cf7conv-step-type-label">${stepTypeInfo.label}</span>
                    </div>
                    <div class="cf7conv-step-actions">
                        <button type="button" class="cf7conv-delete-step button-link-delete">Delete</button>
                    </div>
                </div>
                <div class="cf7conv-step-settings" style="display: none;">
                    ${createStepSettingsHtml(stepId, stepType)}
                </div>
            </div>
        `;
    }
    
    /**
     * Create step settings HTML
     */
    function createStepSettingsHtml(stepId, stepType) {
        let html = `
            <div class="cf7conv-step-setting">
                <label>Step Type:</label>
                <select class="cf7conv-step-type" name="steps[${stepId}][type]">
        `;
        
        const stepTypes = cf7conv_admin.strings.step_types;
        Object.keys(stepTypes).forEach(function(type) {
            const selected = type === stepType ? 'selected' : '';
            html += `<option value="${type}" ${selected}>${stepTypes[type].label}</option>`;
        });
        
        html += `
                </select>
            </div>
            <div class="cf7conv-step-setting">
                <label>Content:</label>
                <textarea name="steps[${stepId}][content]" rows="3" placeholder="Step content or question..."></textarea>
            </div>
        `;
        
        // Add type-specific settings
        switch (stepType) {
            case 'question':
                html += createQuestionSettings(stepId);
                break;
            case 'choice':
                html += createChoiceSettings(stepId);
                break;
            case 'pricing':
                html += createPricingSettings(stepId);
                break;
            case 'logic':
                html += createLogicSettings(stepId);
                break;
        }
        
        html += `
            <div class="cf7conv-step-setting">
                <label>Next Step:</label>
                <select name="steps[${stepId}][next_step]">
                    <option value="">Auto (next in sequence)</option>
                    <option value="end">End conversation</option>
                </select>
            </div>
        `;
        
        return html;
    }
    
    /**
     * Create question step settings
     */
    function createQuestionSettings(stepId) {
        return `
            <div class="cf7conv-step-setting">
                <label>Input Type:</label>
                <select name="steps[${stepId}][input_type]">
                    <option value="text">Text</option>
                    <option value="email">Email</option>
                    <option value="number">Number</option>
                    <option value="textarea">Textarea</option>
                </select>
            </div>
            <div class="cf7conv-step-setting">
                <label>Field Name:</label>
                <input type="text" name="steps[${stepId}][field_name]" placeholder="field_name">
            </div>
            <div class="cf7conv-step-setting">
                <label>Placeholder:</label>
                <input type="text" name="steps[${stepId}][placeholder]" placeholder="Enter placeholder text...">
            </div>
            <div class="cf7conv-step-setting">
                <label>
                    <input type="checkbox" name="steps[${stepId}][required]" value="1">
                    Required field
                </label>
            </div>
        `;
    }
    
    /**
     * Create choice step settings
     */
    function createChoiceSettings(stepId) {
        return `
            <div class="cf7conv-step-setting">
                <label>Field Name:</label>
                <input type="text" name="steps[${stepId}][field_name]" placeholder="field_name">
            </div>
            <div class="cf7conv-step-setting">
                <label>
                    <input type="checkbox" name="steps[${stepId}][multiple]" value="1">
                    Allow multiple selections
                </label>
            </div>
            <div class="cf7conv-step-setting">
                <label>Choices:</label>
                <div class="cf7conv-choices-editor">
                    <div class="cf7conv-choice-item">
                        <input type="text" name="steps[${stepId}][choices][0][label]" placeholder="Choice label">
                        <input type="text" name="steps[${stepId}][choices][0][value]" placeholder="Choice value">
                        <button type="button" class="cf7conv-remove-choice button-link-delete">Remove</button>
                    </div>
                    <button type="button" class="cf7conv-add-choice button-secondary">Add Choice</button>
                </div>
            </div>
        `;
    }
    
    /**
     * Create pricing step settings
     */
    function createPricingSettings(stepId) {
        return `
            <div class="cf7conv-step-setting">
                <label>Pricing Rules:</label>
                <div class="cf7conv-pricing-rules">
                    <div class="cf7conv-pricing-rule">
                        <select name="steps[${stepId}][pricing_rules][0][type]">
                            <option value="base">Base Price</option>
                            <option value="conditional">Conditional</option>
                            <option value="multiplier">Multiplier</option>
                        </select>
                        <input type="number" name="steps[${stepId}][pricing_rules][0][amount]" placeholder="Amount" step="0.01">
                        <button type="button" class="cf7conv-remove-rule button-link-delete">Remove</button>
                    </div>
                    <button type="button" class="cf7conv-add-pricing-rule button-secondary">Add Rule</button>
                </div>
            </div>
        `;
    }
    
    /**
     * Create logic step settings
     */
    function createLogicSettings(stepId) {
        return `
            <div class="cf7conv-step-setting">
                <label>Logic Rules:</label>
                <div class="cf7conv-logic-rules">
                    <div class="cf7conv-logic-rule">
                        <select name="steps[${stepId}][logic][0][condition][field]">
                            <option value="">Select field...</option>
                        </select>
                        <select name="steps[${stepId}][logic][0][condition][operator]">
                            <option value="equals">Equals</option>
                            <option value="not_equals">Not Equals</option>
                            <option value="contains">Contains</option>
                            <option value="not_contains">Not Contains</option>
                            <option value="greater_than">Greater Than</option>
                            <option value="less_than">Less Than</option>
                            <option value="is_empty">Is Empty</option>
                            <option value="is_not_empty">Is Not Empty</option>
                        </select>
                        <input type="text" name="steps[${stepId}][logic][0][condition][value]" placeholder="Value">
                        <select name="steps[${stepId}][logic][0][next_step]">
                            <option value="">Select next step...</option>
                        </select>
                        <button type="button" class="cf7conv-remove-logic-rule button-link-delete">Remove</button>
                    </div>
                    <button type="button" class="cf7conv-add-logic-rule button-secondary">Add Rule</button>
                </div>
            </div>
        `;
    }
    
    /**
     * Update step settings based on type
     */
    function updateStepSettings($step, stepType) {
        const stepId = $step.data('step-id');
        const $settings = $step.find('.cf7conv-step-settings');
        
        // Update step icon
        const stepTypes = cf7conv_admin.strings.step_types;
        const stepTypeInfo = stepTypes[stepType] || stepTypes.question;
        $step.find('.cf7conv-step-icon').attr('class', `cf7conv-step-icon dashicons ${stepTypeInfo.icon}`);
        $step.find('.cf7conv-step-type-label').text(stepTypeInfo.label);
        
        // Regenerate settings HTML
        const newSettingsHtml = createStepSettingsHtml(stepId, stepType);
        $settings.html(newSettingsHtml);
    }
    
    /**
     * Update step order after sorting
     */
    function updateStepOrder() {
        $('#cf7conv-steps-list .cf7conv-step-item').each(function(index) {
            $(this).find('[name*="[order]"]').val(index);
        });
    }
    
    /**
     * Load conversation configuration
     */
    function loadConversationConfig() {
        const configData = $('#cf7conv-config-data').text();
        
        if (configData) {
            try {
                const config = JSON.parse(configData);
                populateBuilder(config);
            } catch (e) {
                console.error('Failed to parse conversation config:', e);
            }
        }
    }
    
    /**
     * Populate builder with configuration
     */
    function populateBuilder(config) {
        if (!config.steps || !Array.isArray(config.steps)) {
            return;
        }
        
        const $stepsList = $('#cf7conv-steps-list');
        $stepsList.empty();
        
        config.steps.forEach(function(step) {
            const stepHtml = createStepHtml(step.id, step.type);
            $stepsList.append(stepHtml);
            
            // Populate step data
            populateStepData(step.id, step);
        });
    }
    
    /**
     * Populate step data
     */
    function populateStepData(stepId, stepData) {
        const $step = $('#cf7conv-step-' + stepId);
        
        // Basic fields
        $step.find('.cf7conv-step-title-input').val(stepData.title || '');
        $step.find('[name*="[content]"]').val(stepData.content || '');
        $step.find('[name*="[next_step]"]').val(stepData.next_step || '');
        
        // Type-specific fields
        Object.keys(stepData).forEach(function(key) {
            const $field = $step.find(`[name*="[${key}]"]`);
            if ($field.length > 0) {
                if ($field.is(':checkbox')) {
                    $field.prop('checked', !!stepData[key]);
                } else {
                    $field.val(stepData[key]);
                }
            }
        });
    }
    
    /**
     * Collect conversation data
     */
    function collectConversationData() {
        const data = {
            conversation_id: getConversationId(),
            title: $('#conversation_title').val(),
            description: $('#conversation_description').val(),
            status: $('#conversation_status').val() || 'draft',
            config: collectStepsConfig()
        };
        
        return data;
    }
    
    /**
     * Collect steps configuration
     */
    function collectStepsConfig() {
        const steps = [];
        const settings = {
            enable_progress: $('#enable_progress').is(':checked'),
            enable_back_button: $('#enable_back_button').is(':checked'),
            auto_save: $('#auto_save').is(':checked')
        };
        
        $('#cf7conv-steps-list .cf7conv-step-item').each(function() {
            const $step = $(this);
            const stepId = $step.data('step-id');
            
            const stepData = {
                id: stepId,
                title: $step.find('.cf7conv-step-title-input').val(),
                type: $step.find('.cf7conv-step-type').val(),
                content: $step.find('[name*="[content]"]').val(),
                next_step: $step.find('[name*="[next_step]"]').val()
            };
            
            // Collect type-specific data
            $step.find('[name*="[' + stepId + ']"]').each(function() {
                const name = $(this).attr('name');
                const matches = name.match(/\[([^\]]+)\]$/);
                
                if (matches) {
                    const fieldName = matches[1];
                    let value = $(this).val();
                    
                    if ($(this).is(':checkbox')) {
                        value = $(this).is(':checked');
                    }
                    
                    stepData[fieldName] = value;
                }
            });
            
            steps.push(stepData);
        });
        
        return {
            version: '1.0',
            settings: settings,
            steps: steps
        };
    }
    
    /**
     * Validate conversation data
     */
    function validateConversationData(data) {
        if (!data.title || data.title.trim() === '') {
            showNotice('Please enter a conversation title.', 'error');
            $('#conversation_title').focus();
            return false;
        }
        
        if (!data.config.steps || data.config.steps.length === 0) {
            showNotice('Please add at least one step to the conversation.', 'error');
            return false;
        }
        
        // Validate each step
        for (let i = 0; i < data.config.steps.length; i++) {
            const step = data.config.steps[i];
            
            if (!step.title || step.title.trim() === '') {
                showNotice(`Step ${i + 1} is missing a title.`, 'error');
                return false;
            }
            
            if (!step.type) {
                showNotice(`Step ${i + 1} is missing a type.`, 'error');
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * Get conversation ID from URL
     */
    function getConversationId() {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get('id') || 0;
    }
    
    /**
     * Show loading state
     */
    function showLoading() {
        $('.cf7conv-save-conversation').prop('disabled', true).text('Saving...');
    }
    
    /**
     * Hide loading state
     */
    function hideLoading() {
        $('.cf7conv-save-conversation').prop('disabled', false).text('Save Conversation');
    }
    
    /**
     * Show admin notice
     */
    function showNotice(message, type = 'info') {
        const $notice = $(`<div class="notice notice-${type} is-dismissible"><p>${message}</p></div>`);
        $('.wrap h1').after($notice);
        
        // Auto-dismiss after 5 seconds
        setTimeout(function() {
            $notice.fadeOut(function() {
                $notice.remove();
            });
        }, 5000);
        
        // Scroll to notice
        $('html, body').animate({
            scrollTop: $notice.offset().top - 50
        }, 300);
    }
    
})(jQuery);