<?php

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Autoloader
spl_autoload_register( 'cf7conv_autoloader' );

function cf7conv_autoloader( $class ) {
	// Only handle our namespace
	if ( strpos( $class, 'CF7CONV\\' ) !== 0 ) {
		return;
	}
	
	// Remove namespace prefix
	$class = substr( $class, 8 );
	
	// Convert namespace separators to directory separators
	$class = str_replace( '\\', DIRECTORY_SEPARATOR, $class );
	
	// Convert to lowercase and add .php extension
	$file = CF7CONV_PLUGIN_DIR . '/includes/' . strtolower( $class ) . '.php';
	
	if ( file_exists( $file ) ) {
		require_once $file;
	}
}

// Load core files
require_once CF7CONV_PLUGIN_DIR . '/includes/functions.php';

// Initialize plugin
function cf7conv_init() {
	// Load text domain
	load_plugin_textdomain( CF7CONV_TEXT_DOMAIN, false, dirname( CF7CONV_PLUGIN_BASENAME ) . '/languages' );
	
	// Initialize core components
	CF7CONV\Core\Plugin::instance();
	
	// Hook into CF7
	CF7CONV\Integrations\CF7Listener::instance();
	
	// Initialize admin if in admin area
	if ( is_admin() ) {
		CF7CONV\Admin\AdminInit::instance();
	}
	
	// Initialize REST API
	CF7CONV\API\RestController::instance();
	
	do_action( 'cf7conv_init' );
}

// Hook plugin initialization
add_action( 'init', 'cf7conv_plugin_init', 20 );

function cf7conv_plugin_init() {
	// Register rewrite rules for conversation endpoints
	add_rewrite_rule( 
		'^cf7conv/([0-9]+)/?$', 
		'index.php?cf7conv_conversation=1&conversation_id=$matches[1]', 
		'top' 
	);
	
	add_rewrite_rule( 
		'^cf7conv/([0-9]+)/resume/([a-zA-Z0-9_-]+)/?$', 
		'index.php?cf7conv_conversation=1&conversation_id=$matches[1]&resume_token=$matches[2]', 
		'top' 
	);
	
	// Add query vars
	add_filter( 'query_vars', function( $vars ) {
		$vars[] = 'cf7conv_conversation';
		$vars[] = 'conversation_id';
		$vars[] = 'resume_token';
		return $vars;
	});
}

// Force flush rewrite rules on plugin activation
add_action( 'wp_loaded', 'cf7conv_maybe_flush_rewrite_rules' );

function cf7conv_maybe_flush_rewrite_rules() {
	if ( get_option( 'cf7conv_flush_rewrite_rules' ) ) {
		flush_rewrite_rules();
		delete_option( 'cf7conv_flush_rewrite_rules' );
	}
}