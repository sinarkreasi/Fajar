# CF7 Conversation Engine

Transform Contact Form 7 forms into guided, step-based conversation funnels with pricing and checkout support.

## Features

- **Conversation Builder**: Visual drag-and-drop builder for creating multi-step conversations
- **Step Types**: Question, Choice, Info, Logic, Pricing, Payment, and Result steps
- **Conditional Logic**: Dynamic routing based on user answers
- **Pricing Integration**: Real-time price calculation with Mini Ecommerce integration
- **Resume Functionality**: Magic link support for resuming conversations
- **Analytics Ready**: Built-in event tracking for analytics plugins
- **Mobile Optimized**: Responsive design with touch-friendly interface
- **Keyboard Navigation**: Full keyboard accessibility support

## Requirements

- WordPress 6.0+
- PHP 7.4+
- Contact Form 7 plugin
- CF7 Mini Ecommerce (optional, for pricing/checkout)
- CF7 UCA (optional, for magic link resume)

## Installation

1. Upload the plugin files to `/wp-content/plugins/cf7-conv/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to **Conversations > Add New** to create your first conversation

## Quick Start

### 1. Create a Conversation

1. Go to **Conversations > Add New**
2. Enter a title and description
3. Optionally link to a Contact Form 7 form
4. Click **Create Conversation**

### 2. Build Your Conversation Flow

Use the visual builder to add steps:

- **Question Steps**: Collect user input (text, email, number, textarea)
- **Choice Steps**: Multiple choice or checkbox selections
- **Info Steps**: Display information without input
- **Logic Steps**: Conditional routing based on answers
- **Pricing Steps**: Dynamic price calculation
- **Payment Steps**: Checkout integration
- **Result Steps**: Summary and completion

### 3. Configure Step Logic

Each step can have:
- **Next Step**: Simple linear progression
- **Conditional Logic**: Route based on user answers
- **Pricing Rules**: Base price, conditional pricing, multipliers

### 4. Publish and Test

1. Set conversation status to "Published"
2. Save the conversation
3. Visit the conversation URL to test
4. Share the link or integrate with CF7 forms

## Step Types

### Question Step
Collect user input with various field types:
```
- Text input
- Email validation
- Number input
- Textarea for longer responses
- Required field validation
- Custom placeholders
```

### Choice Step
Multiple choice or checkbox selections:
```
- Radio buttons (single choice)
- Checkboxes (multiple choice)
- Custom choice labels and values
- Choice descriptions
```

### Info Step
Display content without requiring input:
```
- Rich text content
- Images and media
- Instructions or explanations
- Progress indicators
```

### Logic Step
Conditional routing based on previous answers:
```
Conditions:
- Equals / Not Equals
- Contains / Not Contains
- Greater Than / Less Than
- Is Empty / Is Not Empty

Actions:
- Route to specific step
- Skip steps based on conditions
- End conversation early
```

### Pricing Step
Dynamic price calculation:
```
Rule Types:
- Base Price: Fixed amount
- Conditional: Price based on conditions
- Multiplier: Price × quantity/factor

Integration:
- Real-time calculation
- Currency formatting
- Breakdown display
```

### Payment Step
Checkout integration with Mini Ecommerce:
```
Features:
- Multiple payment gateways
- Order creation
- Payment confirmation
- Receipt generation
```

### Result Step
Conversation completion and summary:
```
Features:
- Answer summary
- Custom completion message
- Action buttons
- Download links
```

## Integration with Contact Form 7

### Automatic Integration
1. Create a conversation
2. Link it to a CF7 form in the conversation settings
3. When users submit the form, they're redirected to the conversation

### Manual Integration
Add this to your CF7 form success message:
```html
Thank you! <a href="[conversation_url]">Continue to next steps</a>
```

## Conditional Logic

### Operators
- `equals`: Exact match
- `not_equals`: Not equal to
- `contains`: Contains text
- `not_contains`: Does not contain
- `greater_than`: Numeric comparison
- `less_than`: Numeric comparison
- `is_empty`: Field is empty
- `is_not_empty`: Field has value

### Example Logic Rules
```javascript
// Route to pricing if service type is "premium"
{
  condition: {
    field: "service_type",
    operator: "equals",
    value: "premium"
  },
  next_step: "pricing_step"
}

// Skip payment if total is 0
{
  condition: {
    field: "calculated_total",
    operator: "equals",
    value: "0"
  },
  next_step: "result_step"
}
```

## Pricing Rules

### Base Price
Fixed amount added to total:
```javascript
{
  type: "base",
  amount: 100
}
```

### Conditional Price
Price added when condition is met:
```javascript
{
  type: "conditional",
  condition: {
    field: "service_type",
    operator: "equals",
    value: "premium"
  },
  amount: 50
}
```

### Multiplier Price
Price multiplied by field value:
```javascript
{
  type: "multiplier",
  field: "quantity",
  amount: 25
}
```

## Session Management

### Session Data
Each conversation session stores:
- Current step position
- User answers
- Pricing calculations
- Payment status
- Resume token (if enabled)

### Resume Links
When enabled, users receive magic links to resume conversations:
```
https://yoursite.com/cf7conv/conversation-id/resume/token
```

### Session Expiry
Sessions expire after configurable time (default: 24 hours)
Expired sessions are automatically cleaned up

## REST API

### Endpoints

#### Get Conversations
```
GET /wp-json/cf7conv/v1/conversations
```

#### Get Single Conversation
```
GET /wp-json/cf7conv/v1/conversations/{id}
```

#### Get Sessions
```
GET /wp-json/cf7conv/v1/sessions?conversation_id={id}
```

#### Update Session
```
PUT /wp-json/cf7conv/v1/sessions/{session_id}
```

#### Calculate Pricing
```
POST /wp-json/cf7conv/v1/pricing/calculate
```

#### Track Analytics
```
POST /wp-json/cf7conv/v1/analytics/events
```

## Hooks and Filters

### Actions
```php
// Conversation events
do_action( 'cf7conv_conversation_created', $conversation_id, $data );
do_action( 'cf7conv_conversation_updated', $conversation_id, $data );
do_action( 'cf7conv_conversation_deleted', $conversation_id );

// Session events
do_action( 'cf7conv_session_created', $session_id, $data );
do_action( 'cf7conv_session_updated', $session_id, $data );
do_action( 'cf7conv_session_completed', $session_id );

// Analytics events
do_action( 'cf7conv_analytics_event', $event_data );

// Integration events
do_action( 'cf7conv_form_to_conversation', $form_id, $conversation_id, $session_id );
```

### Filters
```php
// Modify step rendering
apply_filters( 'cf7conv_render_step', $html, $step, $session );

// Modify pricing calculation
apply_filters( 'cf7conv_calculate_pricing', $total, $rules, $answers );

// Modify session data
apply_filters( 'cf7conv_session_data', $data, $session_id );

// Modify conversation config
apply_filters( 'cf7conv_conversation_config', $config, $conversation_id );
```

## Settings

### General Settings
- **Session Expiry**: How long sessions remain active (hours)
- **Resume Links**: Enable/disable magic link resume functionality
- **Progress Bar**: Show conversation progress
- **Back Button**: Allow users to go back
- **Keyboard Navigation**: Enable keyboard shortcuts
- **Animation Duration**: Step transition speed (milliseconds)
- **Auto-save Interval**: How often to save progress (seconds)

### Appearance Settings
- **Primary Color**: Main theme color
- **Font Family**: Typography settings
- **Border Radius**: Corner rounding

### Integration Settings
- **Ecommerce**: Enable Mini Ecommerce integration
- **UCA**: Enable magic link integration
- **Analytics**: Enable event tracking

## Performance

### Optimization Features
- Minimal JavaScript footprint
- CSS-only animations (when possible)
- Efficient database queries
- Automatic session cleanup
- Lazy loading of step content

### Scalability
- Indexed database queries
- Efficient session storage
- Configurable cleanup intervals
- REST API for external integrations

## Security

### Data Protection
- Input sanitization and validation
- Nonce verification for all forms
- SQL injection prevention
- XSS protection

### Session Security
- Secure token generation
- Session expiry enforcement
- Access control for sensitive data
- Rate limiting on API endpoints

## Browser Support

### Supported Browsers
- Chrome 70+
- Firefox 65+
- Safari 12+
- Edge 79+

### Mobile Support
- iOS Safari 12+
- Chrome Mobile 70+
- Samsung Internet 10+

## Troubleshooting

### Common Issues

**Conversations not loading:**
- Check that CF7 is installed and active
- Verify conversation is published
- Check for JavaScript errors in console

**Sessions not saving:**
- Verify database tables were created
- Check PHP error logs
- Ensure proper permissions

**Pricing not calculating:**
- Verify pricing rules syntax
- Check field names match answers
- Test with simple base price first

**Resume links not working:**
- Ensure resume links are enabled in settings
- Check token generation and storage
- Verify URL rewrite rules

### Debug Mode
Enable WordPress debug mode to see detailed logs:
```php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
```

Logs are written to `/wp-content/debug.log` with `[CF7CONV]` prefix.

## Extending the Plugin

### Custom Step Types
Register custom step types:
```php
add_filter( 'cf7conv_step_types', function( $types ) {
    $types['custom'] = array(
        'label' => 'Custom Step',
        'description' => 'My custom step type',
        'icon' => 'dashicons-star-filled',
    );
    return $types;
});
```

### Custom Pricing Rules
Add custom pricing logic:
```php
add_filter( 'cf7conv_calculate_pricing', function( $total, $rules, $answers ) {
    foreach ( $rules as $rule ) {
        if ( $rule['type'] === 'custom' ) {
            // Custom pricing logic
            $total += custom_calculate_price( $rule, $answers );
        }
    }
    return $total;
}, 10, 3 );
```

### Analytics Integration
Track custom events:
```php
add_action( 'cf7conv_analytics_event', function( $event ) {
    // Send to your analytics service
    send_to_analytics( $event );
});
```

## License

GPL v2 or later - https://www.gnu.org/licenses/gpl-2.0.html

## Support

For support and feature requests, please check the plugin documentation or contact the development team.