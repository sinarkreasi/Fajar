# Prompt: Build Conversation Engine & Builder for Contact Form 7

## Role
You are a senior WordPress frontend & backend engineer.
You specialize in form engines, JavaScript state machines, and scalable WordPress plugin architecture.

You are building a **Conversation Engine addon** for the Contact Form 7 ecosystem.
This addon transforms CF7 forms into **guided, step-based conversation funnels** with pricing and checkout support.

---

## Objective
Build a **Conversation Builder + Runtime Engine** that:
- Renders CF7 forms as multi-step conversations
- Supports conditional logic and branching
- Integrates with Mini Ecommerce for pricing & payment
- Works without user accounts
- Is extensible via addons (License, UCA, Analytics)

---

## Hard Constraints
- Must work on top of Contact Form 7
- No WooCommerce
- No WordPress user dependency
- Email is the only identity
- Checkout must happen inside the conversation flow

---

## Architecture Overview

### Layers
1. Conversation Runtime (Frontend)
2. State Manager
3. Builder Config (Admin)
4. Integration Layer (Ecommerce, UCA, License)

---

## Conversation Runtime Requirements

### Behavior
- One step per screen
- Smooth transitions (CSS / minimal JS)
- Keyboard navigation support
- Back / Next controls
- Resume progress support

---

### Step Types (Required)
- Question (text, email, number)
- Choice (radio, checkbox)
- Info (content only)
- Logic (conditional routing)
- Pricing (dynamic calculation)
- Payment (checkout trigger)
- Result (summary / recommendation)

---

## State Management
State must include:
- current_step
- answers
- calculated pricing
- payment status

Persistence:
- in-memory
- cookie or localStorage
- resumable via Magic Link

---

## Pricing Integration
- Pricing step must call Mini Ecommerce API
- Price can be affected by previous answers
- Pricing preview must update in real-time

---

## Checkout Integration
- Payment step must:
  - block completion until paid
  - listen to payment success event
  - continue flow after payment confirmation

---

## Admin Builder Requirements

### Builder UI
- Step list view (reorderable)
- Step configuration panel
- Conditional logic editor
- Pricing rule editor (simple, rule-based)

Builder output:
- JSON schema representing the conversation flow

---

## Integration Contracts

### Mini Ecommerce (cf7-minicommerce)
- create order
- update order status
- confirm payment

### UCA / Magic Link (cf7uca)
- resume conversation
- access result
- access purchase

### Analytics
- emit events per step
- no analytics storage in this addon

---

## Security & Performance
- No sensitive data exposed in frontend
- Minimal JS footprint
- No inline secrets
- Scalable to long conversations (20+ steps)

---

## Output Expectations
Generate:
- Plugin folder structure
- Core PHP classes
- JS runtime engine
- Builder UI components
- Integration hooks

Code must be:
- Modular
- Extensible
- Well-documented
- Production-ready

---

## Mindset
You are not building a form.
You are building a **conversion-focused conversation engine**.
Think funnel, not fields.
