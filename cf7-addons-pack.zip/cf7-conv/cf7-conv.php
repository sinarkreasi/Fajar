<?php
/*
 * Plugin Name: CF7 Conversation Engine
 * Plugin URI: https://github.com/cf7-conv/cf7-conv
 * Description: Transform Contact Form 7 forms into guided, step-based conversation funnels with pricing and checkout support.
 * Author: CF7 Conversation Team
 * Version: 1.0.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Text Domain: cf7-conv
 * Domain Path: /languages
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Plugin version
define( 'CF7CONV_VERSION', '1.0.0' );

// Plugin constants
define( 'CF7CONV_PLUGIN_FILE', __FILE__ );
define( 'CF7CONV_PLUGIN_BASENAME', plugin_basename( CF7CONV_PLUGIN_FILE ) );
define( 'CF7CONV_PLUGIN_DIR', untrailingslashit( dirname( CF7CONV_PLUGIN_FILE ) ) );
define( 'CF7CONV_PLUGIN_URL', untrailingslashit( plugins_url( '', CF7CONV_PLUGIN_FILE ) ) );
define( 'CF7CONV_TEXT_DOMAIN', 'cf7-conv' );

// Database table names
define( 'CF7CONV_CONVERSATIONS_TABLE', 'cf7_conversations' );
define( 'CF7CONV_SESSIONS_TABLE', 'cf7_conversation_sessions' );

// Check dependencies
add_action( 'plugins_loaded', 'cf7conv_check_dependencies' );

function cf7conv_check_dependencies() {
	// Check PHP version
	if ( version_compare( PHP_VERSION, '7.4', '<' ) ) {
		add_action( 'admin_notices', 'cf7conv_php_version_notice' );
		return;
	}
	
	if ( ! class_exists( 'WPCF7' ) ) {
		add_action( 'admin_notices', 'cf7conv_cf7_missing_notice' );
		return;
	}
	
	// Initialize plugin
	cf7conv_init();
}

function cf7conv_php_version_notice() {
	?>
	<div class="notice notice-error">
		<p><?php printf( __( 'CF7 Conversation Engine requires PHP 7.4 or higher. You are running PHP %s.', CF7CONV_TEXT_DOMAIN ), PHP_VERSION ); ?></p>
	</div>
	<?php
}

function cf7conv_cf7_missing_notice() {
	?>
	<div class="notice notice-error">
		<p><?php _e( 'CF7 Conversation Engine requires Contact Form 7 to be installed and activated.', CF7CONV_TEXT_DOMAIN ); ?></p>
	</div>
	<?php
}

// Load plugin files
require_once CF7CONV_PLUGIN_DIR . '/load.php';



// Add comprehensive null value prevention for WordPress functions
add_action( 'init', function() {
	// Override common WordPress functions that might receive null values
	if ( ! function_exists( 'cf7conv_safe_wp_functions' ) ) {
		function cf7conv_safe_wp_functions() {
			// Add filters to sanitize data before it reaches WordPress core functions
			add_filter( 'query_vars', function( $vars ) {
				return is_array( $vars ) ? $vars : array();
			}, 1 );
			
			// Ensure query vars are properly set
			add_action( 'parse_request', function( $wp ) {
				if ( isset( $wp->query_vars ) && is_array( $wp->query_vars ) ) {
					foreach ( $wp->query_vars as $key => $value ) {
						if ( $value === null ) {
							$wp->query_vars[ $key ] = '';
						}
					}
				}
			}, 1 );
			
			// Additional safety for admin area
			if ( is_admin() ) {
				add_action( 'admin_init', function() {
					// Ensure all $_POST, $_GET values are not null when processed
					if ( ! empty( $_POST ) ) {
						foreach ( $_POST as $key => $value ) {
							if ( $value === null ) {
								$_POST[ $key ] = '';
							}
						}
					}
					if ( ! empty( $_GET ) ) {
						foreach ( $_GET as $key => $value ) {
							if ( $value === null ) {
								$_GET[ $key ] = '';
							}
						}
					}
				}, 1 );
			}
		}
		cf7conv_safe_wp_functions();
	}
}, 1 );

// Additional error suppression specifically for our plugin context
if ( version_compare( PHP_VERSION, '8.0', '>=' ) ) {
	// Temporarily disable deprecation warnings during our plugin operations
	add_action( 'plugins_loaded', function() {
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			// Keep debug on but suppress specific deprecation warnings
			$current_reporting = error_reporting();
			$new_reporting = $current_reporting & ~E_DEPRECATED;
			error_reporting( $new_reporting );
			
			// Restore error reporting after init
			add_action( 'wp_loaded', function() use ( $current_reporting ) {
				error_reporting( $current_reporting );
			}, 999 );
		}
	}, 1 );
}

// Set up error handling for PHP 8+ compatibility
if ( version_compare( PHP_VERSION, '8.0', '>=' ) ) {
	// Set custom error handler to prevent deprecation warnings from WordPress core
	set_error_handler( function( $errno, $errstr, $errfile, $errline ) {
		// Only handle deprecation warnings
		if ( $errno !== E_DEPRECATED ) {
			return false; // Let PHP handle other errors normally
		}
		
		// Check if the error is related to common WordPress functions with null values
		$wp_null_warnings = array(
			'strpos(): Passing null to parameter',
			'str_replace(): Passing null to parameter',
			'strip_tags(): Passing null to parameter',
			'sanitize_text_field(): Passing null to parameter',
			'esc_attr(): Passing null to parameter',
			'esc_html(): Passing null to parameter',
			'wp_parse_str(): Passing null to parameter',
			'wp_parse_url(): Passing null to parameter',
		);
		
		// Check if this is a WordPress core file
		$is_wp_core = strpos( $errfile, 'wp-includes' ) !== false || strpos( $errfile, 'wp-admin' ) !== false;
		
		foreach ( $wp_null_warnings as $warning_pattern ) {
			if ( strpos( $errstr, $warning_pattern ) !== false ) {
				// Always suppress these warnings, regardless of source
				if ( defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG && $is_wp_core ) {
					// Only log if it's from WordPress core to reduce noise
					$backtrace = debug_backtrace( DEBUG_BACKTRACE_IGNORE_ARGS, 10 );
					$caller_info = '';
					
					// Find the first non-WordPress file in the call stack
					foreach ( $backtrace as $trace ) {
						if ( isset( $trace['file'] ) && 
							 strpos( $trace['file'], 'wp-includes' ) === false && 
							 strpos( $trace['file'], 'wp-admin' ) === false ) {
							$caller_info = ' (originated from ' . basename( $trace['file'] ) . ':' . ( $trace['line'] ?? 'unknown' ) . ')';
							break;
						}
					}
					
					// Only log once per minute to prevent spam
					$log_key = 'cf7conv_null_warning_' . md5( $errstr . $errfile . $errline );
					if ( ! get_transient( $log_key ) ) {
						error_log( "[CF7CONV SUPPRESSED] $errstr in $errfile on line $errline$caller_info" );
						set_transient( $log_key, true, 60 ); // Cache for 1 minute
					}
				}
				return true; // Suppress the warning
			}
		}
		
		return false; // Let PHP handle other deprecation warnings normally
	}, E_DEPRECATED );
}

// Plugin activation hook
register_activation_hook( CF7CONV_PLUGIN_FILE, 'cf7conv_activate' );

// Plugin deactivation hook
register_deactivation_hook( CF7CONV_PLUGIN_FILE, 'cf7conv_deactivate' );

/**
 * Plugin activation callback
 */
if ( ! function_exists( 'cf7conv_activate' ) ) {
	function cf7conv_activate() {
		// Create database tables
		CF7CONV\Database\SchemaManager::create_tables();
		
		// Set default options
		CF7CONV\Core\OptionsManager::set_defaults();
		
		// Set flag to flush rewrite rules
		update_option( 'cf7conv_flush_rewrite_rules', true );
		
		// Flush rewrite rules
		flush_rewrite_rules();
	}
}

/**
 * Plugin deactivation callback
 */
if ( ! function_exists( 'cf7conv_deactivate' ) ) {
	function cf7conv_deactivate() {
		// Restore previous error handler
		if ( version_compare( PHP_VERSION, '8.0', '>=' ) ) {
			restore_error_handler();
		}
		
		// Flush rewrite rules
		flush_rewrite_rules();
	}
}