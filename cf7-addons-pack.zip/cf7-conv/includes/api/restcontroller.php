<?php

namespace CF7CONV\API;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * REST API controller
 */
class RestController {
	
	/**
	 * Controller instance
	 *
	 * @var RestController
	 */
	private static $instance = null;
	
	/**
	 * API namespace
	 */
	const NAMESPACE = 'cf7conv/v1';
	
	/**
	 * Get controller instance
	 *
	 * @return RestController
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		$this->init_hooks();
	}
	
	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}
	
	/**
	 * Register REST API routes
	 */
	public function register_routes() {
		// Conversations
		register_rest_route( self::NAMESPACE, '/conversations', array(
			'methods' => 'GET',
			'callback' => array( $this, 'get_conversations' ),
			'permission_callback' => array( $this, 'check_admin_permissions' ),
		) );
		
		register_rest_route( self::NAMESPACE, '/conversations/(?P<id>\d+)', array(
			'methods' => 'GET',
			'callback' => array( $this, 'get_conversation' ),
			'permission_callback' => array( $this, 'check_admin_permissions' ),
			'args' => array(
				'id' => array(
					'validate_callback' => function( $param ) {
						return is_numeric( $param );
					}
				),
			),
		) );
		
		// Sessions
		register_rest_route( self::NAMESPACE, '/sessions', array(
			'methods' => 'GET',
			'callback' => array( $this, 'get_sessions' ),
			'permission_callback' => array( $this, 'check_admin_permissions' ),
		) );
		
		register_rest_route( self::NAMESPACE, '/sessions/(?P<session_id>[a-zA-Z0-9_]+)', array(
			'methods' => 'GET',
			'callback' => array( $this, 'get_session' ),
			'permission_callback' => array( $this, 'check_session_access' ),
			'args' => array(
				'session_id' => array(
					'validate_callback' => function( $param ) {
						return ! empty( $param );
					}
				),
			),
		) );
		
		register_rest_route( self::NAMESPACE, '/sessions/(?P<session_id>[a-zA-Z0-9_]+)', array(
			'methods' => 'PUT',
			'callback' => array( $this, 'update_session' ),
			'permission_callback' => array( $this, 'check_session_access' ),
			'args' => array(
				'session_id' => array(
					'validate_callback' => function( $param ) {
						return ! empty( $param );
					}
				),
			),
		) );
		
		// Analytics
		register_rest_route( self::NAMESPACE, '/analytics/events', array(
			'methods' => 'POST',
			'callback' => array( $this, 'track_event' ),
			'permission_callback' => '__return_true', // Public endpoint
		) );
		
		// Pricing calculation
		register_rest_route( self::NAMESPACE, '/pricing/calculate', array(
			'methods' => 'POST',
			'callback' => array( $this, 'calculate_pricing' ),
			'permission_callback' => '__return_true', // Public endpoint
		) );
		
		// Integration endpoints
		register_rest_route( self::NAMESPACE, '/integrations/ecommerce/create-order', array(
			'methods' => 'POST',
			'callback' => array( $this, 'create_ecommerce_order' ),
			'permission_callback' => array( $this, 'check_session_access' ),
		) );
	}
	
	/**
	 * Get conversations
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function get_conversations( $request ) {
		$conversation_manager = new \CF7CONV\Core\ConversationManager();
		
		$args = array(
			'status' => $request->get_param( 'status' ),
			'limit' => min( intval( $request->get_param( 'per_page' ) ?: 20 ), 100 ),
			'offset' => intval( $request->get_param( 'offset' ) ?: 0 ),
			'orderby' => sanitize_text_field( $request->get_param( 'orderby' ) ?: 'created_at' ),
			'order' => sanitize_text_field( $request->get_param( 'order' ) ?: 'DESC' ),
		);
		
		$conversations = $conversation_manager->get_conversations( $args );
		$total = $conversation_manager->get_conversation_count( $args['status'] );
		
		$response = rest_ensure_response( $conversations );
		$response->header( 'X-WP-Total', $total );
		$response->header( 'X-WP-TotalPages', ceil( $total / $args['limit'] ) );
		
		return $response;
	}
	
	/**
	 * Get single conversation
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_conversation( $request ) {
		$conversation_id = intval( $request->get_param( 'id' ) );
		
		$conversation_manager = new \CF7CONV\Core\ConversationManager();
		$conversation = $conversation_manager->get_conversation( $conversation_id );
		
		if ( ! $conversation ) {
			return new \WP_Error( 'conversation_not_found', __( 'Conversation not found.', CF7CONV_TEXT_DOMAIN ), array( 'status' => 404 ) );
		}
		
		// Include session statistics
		$session_manager = new \CF7CONV\Core\SessionManager();
		$conversation['stats'] = $session_manager->get_session_stats( $conversation_id );
		
		return rest_ensure_response( $conversation );
	}
	
	/**
	 * Get sessions
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function get_sessions( $request ) {
		$conversation_id = intval( $request->get_param( 'conversation_id' ) );
		
		if ( $conversation_id <= 0 ) {
			return new \WP_Error( 'invalid_conversation_id', __( 'Invalid conversation ID.', CF7CONV_TEXT_DOMAIN ), array( 'status' => 400 ) );
		}
		
		$session_manager = new \CF7CONV\Core\SessionManager();
		
		$args = array(
			'status' => $request->get_param( 'status' ),
			'limit' => min( intval( $request->get_param( 'per_page' ) ?: 50 ), 100 ),
			'offset' => intval( $request->get_param( 'offset' ) ?: 0 ),
			'orderby' => sanitize_text_field( $request->get_param( 'orderby' ) ?: 'started_at' ),
			'order' => sanitize_text_field( $request->get_param( 'order' ) ?: 'DESC' ),
		);
		
		$sessions = $session_manager->get_sessions_by_conversation( $conversation_id, $args );
		
		// Remove sensitive data from public response
		foreach ( $sessions as &$session ) {
			unset( $session['resume_token'] );
			
			// Parse answers for display
			if ( ! empty( $session['answers'] ) ) {
				$session['answers'] = json_decode( $session['answers'], true );
			}
			
			if ( ! empty( $session['pricing_data'] ) ) {
				$session['pricing_data'] = json_decode( $session['pricing_data'], true );
			}
		}
		
		return rest_ensure_response( $sessions );
	}
	
	/**
	 * Get single session
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_session( $request ) {
		$session_id = sanitize_text_field( $request->get_param( 'session_id' ) );
		
		$session_manager = new \CF7CONV\Core\SessionManager();
		$session = $session_manager->get_session( $session_id );
		
		if ( ! $session ) {
			return new \WP_Error( 'session_not_found', __( 'Session not found.', CF7CONV_TEXT_DOMAIN ), array( 'status' => 404 ) );
		}
		
		// Parse JSON fields
		$session['answers'] = json_decode( $session['answers'], true );
		$session['pricing_data'] = json_decode( $session['pricing_data'], true );
		
		// Remove sensitive data
		unset( $session['resume_token'] );
		
		return rest_ensure_response( $session );
	}
	
	/**
	 * Update session
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response|WP_Error
	 */
	public function update_session( $request ) {
		$session_id = sanitize_text_field( $request->get_param( 'session_id' ) );
		$data = $request->get_json_params();
		
		$session_manager = new \CF7CONV\Core\SessionManager();
		$session = $session_manager->get_session( $session_id );
		
		if ( ! $session ) {
			return new \WP_Error( 'session_not_found', __( 'Session not found.', CF7CONV_TEXT_DOMAIN ), array( 'status' => 404 ) );
		}
		
		// Prepare update data
		$update_data = array();
		
		if ( isset( $data['current_step'] ) ) {
			$update_data['current_step'] = sanitize_text_field( $data['current_step'] );
		}
		
		if ( isset( $data['answers'] ) ) {
			$update_data['answers'] = wp_json_encode( cf7conv_sanitize_step_data( $data['answers'] ) );
		}
		
		if ( isset( $data['pricing_data'] ) ) {
			$update_data['pricing_data'] = wp_json_encode( $data['pricing_data'] );
		}
		
		if ( isset( $data['email'] ) ) {
			$update_data['email'] = sanitize_email( $data['email'] );
		}
		
		$result = $session_manager->update_session( $session_id, $update_data );
		
		if ( ! $result ) {
			return new \WP_Error( 'update_failed', __( 'Failed to update session.', CF7CONV_TEXT_DOMAIN ), array( 'status' => 500 ) );
		}
		
		return rest_ensure_response( array( 'success' => true ) );
	}
	
	/**
	 * Track analytics event
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function track_event( $request ) {
		$data = $request->get_json_params();
		
		// Validate required fields
		if ( empty( $data['event_type'] ) || empty( $data['conversation_id'] ) ) {
			return new \WP_Error( 'invalid_event_data', __( 'Invalid event data.', CF7CONV_TEXT_DOMAIN ), array( 'status' => 400 ) );
		}
		
		// Emit analytics event for other plugins to handle
		do_action( 'cf7conv_analytics_event', array(
			'event_type' => sanitize_text_field( $data['event_type'] ),
			'conversation_id' => intval( $data['conversation_id'] ),
			'session_id' => sanitize_text_field( $data['session_id'] ?? '' ),
			'timestamp' => sanitize_text_field( $data['timestamp'] ?? current_time( 'mysql' ) ),
			'data' => $data['data'] ?? array(),
			'user_agent' => sanitize_text_field( $_SERVER['HTTP_USER_AGENT'] ?? '' ),
			'ip_address' => sanitize_text_field( $_SERVER['REMOTE_ADDR'] ?? '' ),
		) );
		
		return rest_ensure_response( array( 'success' => true ) );
	}
	
	/**
	 * Calculate pricing
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response|WP_Error
	 */
	public function calculate_pricing( $request ) {
		$data = $request->get_json_params();
		
		if ( empty( $data['pricing_rules'] ) || empty( $data['answers'] ) ) {
			return new \WP_Error( 'invalid_pricing_data', __( 'Invalid pricing data.', CF7CONV_TEXT_DOMAIN ), array( 'status' => 400 ) );
		}
		
		$pricing_rules = $data['pricing_rules'];
		$answers = cf7conv_sanitize_step_data( $data['answers'] );
		
		$total = cf7conv_calculate_pricing( $pricing_rules, $answers );
		
		$response = array(
			'total' => $total,
			'formatted' => cf7conv_is_ecommerce_available() ? cf7mc_format_price( $total ) : '$' . number_format( $total, 2 ),
			'currency' => cf7conv_is_ecommerce_available() ? cf7mc_get_option( 'currency', 'USD' ) : 'USD',
		);
		
		return rest_ensure_response( $response );
	}
	
	/**
	 * Create ecommerce order
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response|WP_Error
	 */
	public function create_ecommerce_order( $request ) {
		if ( ! cf7conv_is_ecommerce_available() ) {
			return new \WP_Error( 'ecommerce_not_available', __( 'Ecommerce integration not available.', CF7CONV_TEXT_DOMAIN ), array( 'status' => 400 ) );
		}
		
		$data = $request->get_json_params();
		$session_id = sanitize_text_field( $request->get_param( 'session_id' ) );
		
		$session_manager = new \CF7CONV\Core\SessionManager();
		$session = $session_manager->get_session( $session_id );
		
		if ( ! $session ) {
			return new \WP_Error( 'session_not_found', __( 'Session not found.', CF7CONV_TEXT_DOMAIN ), array( 'status' => 404 ) );
		}
		
		$answers = json_decode( $session['answers'], true );
		
		// Prepare order data
		$order_data = array(
			'customer_email' => $session['email'],
			'customer_name' => $answers['name'] ?? $answers['your-name'] ?? '',
			'total_amount' => floatval( $data['total'] ?? 0 ),
			'items' => wp_json_encode( $data['items'] ?? array() ),
			'gateway' => sanitize_text_field( $data['gateway'] ?? 'whatsapp' ),
			'source' => 'cf7conv',
			'source_id' => $session['conversation_id'],
		);
		
		// Create order using Mini Ecommerce
		$order_manager = new \CF7MC\Core\OrderManager();
		$order_id = $order_manager->create_order( $order_data );
		
		if ( ! $order_id ) {
			return new \WP_Error( 'order_creation_failed', __( 'Failed to create order.', CF7CONV_TEXT_DOMAIN ), array( 'status' => 500 ) );
		}
		
		// Update session with order ID
		$session_manager->update_session( $session_id, array(
			'order_id' => $order_id,
			'payment_status' => 'pending',
		) );
		
		// Get order details
		$order = $order_manager->get_order( $order_id );
		
		return rest_ensure_response( array(
			'order_id' => $order_id,
			'order_code' => $order['order_code'],
			'checkout_url' => $this->get_order_checkout_url( $order ),
		) );
	}
	
	/**
	 * Get order checkout URL
	 *
	 * @param array $order
	 * @return string
	 */
	private function get_order_checkout_url( $order ) {
		if ( ! cf7conv_is_ecommerce_available() ) {
			return '';
		}
		
		$gateway_manager = new \CF7MC\Core\GatewayManager();
		$gateway = $gateway_manager->get_gateway( $order['gateway'] );
		
		if ( $gateway ) {
			return $gateway->get_checkout_url( $order );
		}
		
		return '';
	}
	
	/**
	 * Check admin permissions
	 *
	 * @return bool
	 */
	public function check_admin_permissions() {
		return current_user_can( 'manage_options' );
	}
	
	/**
	 * Check session access permissions
	 *
	 * @param WP_REST_Request $request
	 * @return bool
	 */
	public function check_session_access( $request ) {
		// Allow admin access
		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}
		
		// For public access, we could implement token-based authentication
		// For now, allow public access to session endpoints
		return true;
	}
}