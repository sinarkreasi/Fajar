<?php

namespace CF7CONV\Admin;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin initialization class
 */
class AdminInit {
	
	/**
	 * Admin instance
	 *
	 * @var AdminInit
	 */
	private static $instance = null;
	
	/**
	 * Get admin instance
	 *
	 * @return AdminInit
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		$this->init_hooks();
	}
	
	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
		add_action( 'wp_ajax_cf7conv_save_conversation', array( $this, 'ajax_save_conversation' ) );
		add_action( 'wp_ajax_cf7conv_delete_conversation', array( $this, 'ajax_delete_conversation' ) );
		add_action( 'wp_ajax_cf7conv_duplicate_conversation', array( $this, 'ajax_duplicate_conversation' ) );
		
		// Add CF7 form integration
		add_action( 'add_meta_boxes', array( $this, 'add_cf7_meta_boxes' ) );
	}
	
	/**
	 * Add admin menu
	 */
	public function add_admin_menu() {
		add_menu_page(
			__( 'CF7 Conversations', CF7CONV_TEXT_DOMAIN ) ?: 'CF7 Conversations',
			__( 'Conversations', CF7CONV_TEXT_DOMAIN ) ?: 'Conversations',
			'manage_options',
			'cf7conv-conversations',
			array( $this, 'render_conversations_page' ),
			'dashicons-format-chat',
			30
		);
		
		add_submenu_page(
			'cf7conv-conversations',
			__( 'All Conversations', CF7CONV_TEXT_DOMAIN ) ?: 'All Conversations',
			__( 'All Conversations', CF7CONV_TEXT_DOMAIN ) ?: 'All Conversations',
			'manage_options',
			'cf7conv-conversations',
			array( $this, 'render_conversations_page' )
		);
		
		add_submenu_page(
			'cf7conv-conversations',
			__( 'Add New', CF7CONV_TEXT_DOMAIN ),
			__( 'Add New', CF7CONV_TEXT_DOMAIN ),
			'manage_options',
			'cf7conv-new-conversation',
			array( $this, 'render_new_conversation_page' )
		);
		
		// Hidden edit page (accessed via URL parameter)
		add_submenu_page(
			null, // Hidden from menu
			__( 'Edit Conversation', CF7CONV_TEXT_DOMAIN ),
			__( 'Edit Conversation', CF7CONV_TEXT_DOMAIN ),
			'manage_options',
			'cf7conv-edit-conversation',
			array( $this, 'render_edit_conversation_page' )
		);
		
		add_submenu_page(
			'cf7conv-conversations',
			__( 'Sessions', CF7CONV_TEXT_DOMAIN ),
			__( 'Sessions', CF7CONV_TEXT_DOMAIN ),
			'manage_options',
			'cf7conv-sessions',
			array( $this, 'render_sessions_page' )
		);
		
		add_submenu_page(
			'cf7conv-conversations',
			__( 'Settings', CF7CONV_TEXT_DOMAIN ),
			__( 'Settings', CF7CONV_TEXT_DOMAIN ),
			'manage_options',
			'cf7conv-settings',
			array( $this, 'render_settings_page' )
		);
		
		// Add debug submenu for troubleshooting
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			add_submenu_page(
				'cf7conv-conversations',
				__( 'Debug', CF7CONV_TEXT_DOMAIN ),
				__( 'Debug', CF7CONV_TEXT_DOMAIN ),
				'manage_options',
				'cf7conv-debug',
				array( $this, 'render_debug_page' )
			);
		}
	}
	
	/**
	 * Enqueue admin scripts
	 */
	public function enqueue_admin_scripts( $hook ) {
		// Ensure $hook is a string and handle null values
		$hook = $hook ?? '';
		if ( ! is_string( $hook ) || strpos( $hook, 'cf7conv' ) === false ) {
			return;
		}
		
		wp_enqueue_script( 'jquery-ui-sortable' );
		wp_enqueue_script( 'wp-color-picker' );
		wp_enqueue_style( 'wp-color-picker' );
		
		wp_enqueue_script(
			'cf7conv-admin',
			CF7CONV_PLUGIN_URL . '/assets/js/admin.js',
			array( 'jquery', 'jquery-ui-sortable', 'wp-color-picker' ),
			CF7CONV_VERSION,
			true
		);
		
		wp_localize_script( 'cf7conv-admin', 'cf7conv_admin', array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce' => wp_create_nonce( 'cf7conv_admin' ),
			'strings' => array(
				'confirm_delete' => __( 'Are you sure you want to delete this conversation?', CF7CONV_TEXT_DOMAIN ) ?: 'Are you sure you want to delete this conversation?',
				'confirm_delete_session' => __( 'Are you sure you want to delete this session?', CF7CONV_TEXT_DOMAIN ) ?: 'Are you sure you want to delete this session?',
				'step_types' => cf7conv_get_step_types(),
			),
		) );
		
		wp_enqueue_style(
			'cf7conv-admin',
			CF7CONV_PLUGIN_URL . '/assets/css/admin.css',
			array(),
			CF7CONV_VERSION
		);
	}
	
	/**
	 * Add CF7 form meta boxes
	 */
	public function add_cf7_meta_boxes() {
		if ( class_exists( 'WPCF7_ContactForm' ) ) {
			add_meta_box(
				'cf7conv-conversation-settings',
				__( 'Conversation Settings', CF7CONV_TEXT_DOMAIN ) ?: 'Conversation Settings',
				array( $this, 'render_cf7_meta_box' ),
				'wpcf7_contact_form',
				'side',
				'default'
			);
		}
	}
	
	/**
	 * Render CF7 meta box
	 */
	public function render_cf7_meta_box( $post ) {
		$conversation_manager = new \CF7CONV\Core\ConversationManager();
		$conversations = $conversation_manager->get_conversations( array( 'status' => 'published' ) );
		
		$linked_conversation = get_post_meta( $post->ID, '_cf7conv_conversation_id', true );
		
		?>
		<div class="cf7conv-cf7-settings">
			<p>
				<label for="cf7conv_conversation_id"><?php _e( 'Link to Conversation:', CF7CONV_TEXT_DOMAIN ) ?: 'Link to Conversation:'; ?></label>
				<select name="cf7conv_conversation_id" id="cf7conv_conversation_id" style="width: 100%;">
					<option value=""><?php _e( 'No conversation', CF7CONV_TEXT_DOMAIN ) ?: 'No conversation'; ?></option>
					<?php foreach ( $conversations as $conversation ): ?>
					<option value="<?php echo esc_attr( $conversation['id'] ); ?>" <?php selected( $linked_conversation, $conversation['id'] ); ?>>
						<?php echo esc_html( $conversation['title'] ); ?>
					</option>
					<?php endforeach; ?>
				</select>
			</p>
			
			<p class="description">
				<?php _e( 'When linked, form submissions will redirect to the conversation instead of showing the standard success message.', CF7CONV_TEXT_DOMAIN ) ?: 'When linked, form submissions will redirect to the conversation instead of showing the standard success message.'; ?>
			</p>
		</div>
		
		<?php wp_nonce_field( 'cf7conv_cf7_settings', 'cf7conv_cf7_nonce' ); ?>
		<?php
	}
	
	/**
	 * Render conversations page
	 */
	public function render_conversations_page() {
		$conversation_manager = new \CF7CONV\Core\ConversationManager();
		
		// Handle bulk actions
		if ( isset( $_POST['action'] ) && isset( $_POST['conversations'] ) ) {
			check_admin_referer( 'cf7conv_bulk_action' );
			
			$action = sanitize_text_field( $_POST['action'] );
			$conversation_ids = array_map( 'intval', $_POST['conversations'] );
			
			switch ( $action ) {
				case 'delete':
					foreach ( $conversation_ids as $conversation_id ) {
						$conversation_manager->delete_conversation( $conversation_id );
					}
					echo '<div class="notice notice-success"><p>' . __( 'Conversations deleted successfully.', CF7CONV_TEXT_DOMAIN ) . '</p></div>';
					break;
					
				case 'publish':
					foreach ( $conversation_ids as $conversation_id ) {
						$conversation_manager->update_conversation( $conversation_id, array( 'status' => 'published' ) );
					}
					echo '<div class="notice notice-success"><p>' . __( 'Conversations published successfully.', CF7CONV_TEXT_DOMAIN ) . '</p></div>';
					break;
					
				case 'draft':
					foreach ( $conversation_ids as $conversation_id ) {
						$conversation_manager->update_conversation( $conversation_id, array( 'status' => 'draft' ) );
					}
					echo '<div class="notice notice-success"><p>' . __( 'Conversations moved to draft successfully.', CF7CONV_TEXT_DOMAIN ) . '</p></div>';
					break;
			}
		}
		
		$conversations = $conversation_manager->get_conversations();
		
		?>
		<div class="wrap">
			<h1 class="wp-heading-inline"><?php _e( 'Conversations', CF7CONV_TEXT_DOMAIN ); ?></h1>
			<a href="<?php echo admin_url( 'admin.php?page=cf7conv-new-conversation' ); ?>" class="page-title-action">
				<?php _e( 'Add New', CF7CONV_TEXT_DOMAIN ); ?>
			</a>
			
			<form method="post">
				<?php wp_nonce_field( 'cf7conv_bulk_action' ); ?>
				
				<div class="tablenav top">
					<div class="alignleft actions bulkactions">
						<select name="action">
							<option value="-1"><?php _e( 'Bulk Actions', CF7CONV_TEXT_DOMAIN ); ?></option>
							<option value="publish"><?php _e( 'Publish', CF7CONV_TEXT_DOMAIN ); ?></option>
							<option value="draft"><?php _e( 'Move to Draft', CF7CONV_TEXT_DOMAIN ); ?></option>
							<option value="delete"><?php _e( 'Delete', CF7CONV_TEXT_DOMAIN ); ?></option>
						</select>
						<input type="submit" class="button action" value="<?php _e( 'Apply', CF7CONV_TEXT_DOMAIN ); ?>">
					</div>
				</div>
				
				<table class="wp-list-table widefat fixed striped">
					<thead>
						<tr>
							<td class="manage-column column-cb check-column">
								<input type="checkbox" id="cb-select-all-1">
							</td>
							<th class="manage-column column-title"><?php _e( 'Title', CF7CONV_TEXT_DOMAIN ); ?></th>
							<th class="manage-column column-status"><?php _e( 'Status', CF7CONV_TEXT_DOMAIN ); ?></th>
							<th class="manage-column column-sessions"><?php _e( 'Sessions', CF7CONV_TEXT_DOMAIN ); ?></th>
							<th class="manage-column column-date"><?php _e( 'Date', CF7CONV_TEXT_DOMAIN ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php if ( empty( $conversations ) ): ?>
						<tr>
							<td colspan="5" style="text-align: center; padding: 40px;">
								<?php _e( 'No conversations found.', CF7CONV_TEXT_DOMAIN ); ?>
								<br><br>
								<a href="<?php echo admin_url( 'admin.php?page=cf7conv-new-conversation' ); ?>" class="button button-primary">
									<?php _e( 'Create Your First Conversation', CF7CONV_TEXT_DOMAIN ); ?>
								</a>
							</td>
						</tr>
						<?php else: ?>
						<?php foreach ( $conversations as $conversation ): ?>
						<tr>
							<th class="check-column">
								<input type="checkbox" name="conversations[]" value="<?php echo esc_attr( $conversation['id'] ?? '' ); ?>">
							</th>
							<td class="column-title">
								<strong>
									<a href="<?php echo admin_url( 'admin.php?page=cf7conv-edit-conversation&id=' . ( $conversation['id'] ?? '' ) ); ?>">
										<?php echo esc_html( $conversation['title'] ?? 'Untitled' ); ?>
									</a>
								</strong>
								<div class="row-actions">
									<span class="edit">
										<a href="<?php echo admin_url( 'admin.php?page=cf7conv-edit-conversation&id=' . ( $conversation['id'] ?? '' ) ); ?>">
											<?php _e( 'Edit', CF7CONV_TEXT_DOMAIN ); ?>
										</a> |
									</span>
									<span class="view">
										<a href="<?php echo cf7conv_get_conversation_url( $conversation['id'] ?? '' ); ?>" target="_blank">
											<?php _e( 'View', CF7CONV_TEXT_DOMAIN ); ?>
										</a> |
									</span>
									<span class="duplicate">
										<a href="#" class="cf7conv-duplicate-conversation" data-id="<?php echo esc_attr( $conversation['id'] ?? '' ); ?>">
											<?php _e( 'Duplicate', CF7CONV_TEXT_DOMAIN ); ?>
										</a> |
									</span>
									<span class="trash">
										<a href="#" class="cf7conv-delete-conversation" data-id="<?php echo esc_attr( $conversation['id'] ?? '' ); ?>">
											<?php _e( 'Delete', CF7CONV_TEXT_DOMAIN ); ?>
										</a>
									</span>
								</div>
							</td>
							<td class="column-status">
								<span class="cf7conv-status cf7conv-status-<?php echo esc_attr( $conversation['status'] ?? 'draft' ); ?>">
									<?php echo esc_html( ucfirst( $conversation['status'] ?? 'draft' ) ); ?>
								</span>
							</td>
							<td class="column-sessions">
								<?php
								$session_manager = new \CF7CONV\Core\SessionManager();
								$stats = $session_manager->get_session_stats( $conversation['id'] ?? 0 );
								echo intval( $stats['total_sessions'] ?? 0 );
								?>
							</td>
							<td class="column-date">
								<?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $conversation['created_at'] ?? 'now' ) ) ); ?>
							</td>
						</tr>
						<?php endforeach; ?>
						<?php endif; ?>
					</tbody>
				</table>
			</form>
		</div>
		<?php
	}
	
	/**
	 * Render edit conversation page
	 */
	public function render_edit_conversation_page() {
		$conversation_id = isset( $_GET['id'] ) ? intval( $_GET['id'] ) : 0;
		
		if ( $conversation_id <= 0 ) {
			wp_die( __( 'Invalid conversation ID.', CF7CONV_TEXT_DOMAIN ) );
		}
		
		$conversation_manager = new \CF7CONV\Core\ConversationManager();
		$conversation = $conversation_manager->get_conversation( $conversation_id );
		
		if ( ! $conversation ) {
			wp_die( __( 'Conversation not found.', CF7CONV_TEXT_DOMAIN ) );
		}
		
		// Handle form submission
		if ( isset( $_POST['save_conversation'] ) ) {
			check_admin_referer( 'cf7conv_save_conversation' );
			
			$update_data = array(
				'title' => sanitize_text_field( $_POST['title'] ),
				'description' => sanitize_textarea_field( $_POST['description'] ),
				'status' => sanitize_text_field( $_POST['status'] ?? 'draft' ),
			);
			
			// Handle config if provided
			if ( isset( $_POST['config'] ) ) {
				$config = json_decode( stripslashes( $_POST['config'] ), true );
				if ( json_last_error() === JSON_ERROR_NONE ) {
					$update_data['config'] = wp_json_encode( $config );
				}
			}
			
			$result = $conversation_manager->update_conversation( $conversation_id, $update_data );
			
			if ( $result ) {
				echo '<div class="notice notice-success"><p>' . __( 'Conversation updated successfully.', CF7CONV_TEXT_DOMAIN ) . '</p></div>';
				// Refresh conversation data
				$conversation = $conversation_manager->get_conversation( $conversation_id );
			} else {
				echo '<div class="notice notice-error"><p>' . __( 'Failed to update conversation.', CF7CONV_TEXT_DOMAIN ) . '</p></div>';
			}
		}
		
		?>
		<div class="wrap">
			<h1 class="wp-heading-inline"><?php _e( 'Edit Conversation', CF7CONV_TEXT_DOMAIN ); ?></h1>
			<a href="<?php echo admin_url( 'admin.php?page=cf7conv-conversations' ); ?>" class="page-title-action">
				<?php _e( 'Back to Conversations', CF7CONV_TEXT_DOMAIN ); ?>
			</a>
			
			<div class="cf7conv-conversation-settings">
				<form method="post" action="" class="cf7conv-conversation-form">
					<?php wp_nonce_field( 'cf7conv_save_conversation' ); ?>
					
					<div class="cf7conv-setting-row">
						<div class="cf7conv-setting-col">
							<label for="conversation_title"><?php _e( 'Title', CF7CONV_TEXT_DOMAIN ); ?></label>
							<input type="text" id="conversation_title" name="title" class="regular-text" value="<?php echo esc_attr( $conversation['title'] ?? '' ); ?>" required>
						</div>
						<div class="cf7conv-setting-col">
							<label for="conversation_status"><?php _e( 'Status', CF7CONV_TEXT_DOMAIN ); ?></label>
							<select id="conversation_status" name="status">
								<option value="draft" <?php selected( $conversation['status'] ?? 'draft', 'draft' ); ?>><?php _e( 'Draft', CF7CONV_TEXT_DOMAIN ); ?></option>
								<option value="published" <?php selected( $conversation['status'] ?? 'draft', 'published' ); ?>><?php _e( 'Published', CF7CONV_TEXT_DOMAIN ); ?></option>
								<option value="archived" <?php selected( $conversation['status'] ?? 'draft', 'archived' ); ?>><?php _e( 'Archived', CF7CONV_TEXT_DOMAIN ); ?></option>
							</select>
						</div>
					</div>
					
					<div class="cf7conv-setting-row">
						<div class="cf7conv-setting-col">
							<label for="conversation_description"><?php _e( 'Description', CF7CONV_TEXT_DOMAIN ); ?></label>
							<textarea id="conversation_description" name="description" class="large-text" rows="3"><?php echo esc_textarea( $conversation['description'] ?? '' ); ?></textarea>
							<p class="description"><?php _e( 'Optional description shown to users at the start of the conversation.', CF7CONV_TEXT_DOMAIN ); ?></p>
						</div>
					</div>
					
					<div class="cf7conv-actions">
						<input type="submit" name="save_conversation" class="button-primary cf7conv-save-conversation" value="<?php _e( 'Save Conversation', CF7CONV_TEXT_DOMAIN ); ?>">
						<a href="<?php echo cf7conv_get_conversation_url( $conversation_id ); ?>" class="button cf7conv-preview-conversation" target="_blank">
							<?php _e( 'Preview Conversation', CF7CONV_TEXT_DOMAIN ); ?>
						</a>
					</div>
				</form>
			</div>
			
			<div class="cf7conv-builder" id="cf7conv-builder">
				<div class="cf7conv-builder-sidebar">
					<div class="cf7conv-step-types">
						<h3><?php _e( 'Add Step', CF7CONV_TEXT_DOMAIN ); ?></h3>
						<?php
						$step_types = cf7conv_get_step_types();
						foreach ( $step_types as $type => $info ):
						?>
						<button type="button" class="cf7conv-step-type-item cf7conv-add-step" data-type="<?php echo esc_attr( $type ); ?>">
							<span class="dashicons <?php echo esc_attr( $info['icon'] ); ?>"></span>
							<div>
								<div class="cf7conv-step-type-title"><?php echo esc_html( $info['label'] ); ?></div>
								<div class="cf7conv-step-type-description"><?php echo esc_html( $info['description'] ); ?></div>
							</div>
						</button>
						<?php endforeach; ?>
					</div>
					
					<div class="cf7conv-conversation-info">
						<h3><?php _e( 'Conversation Info', CF7CONV_TEXT_DOMAIN ); ?></h3>
						<p><strong><?php _e( 'ID:', CF7CONV_TEXT_DOMAIN ); ?></strong> <?php echo esc_html( $conversation['id'] ?? '' ); ?></p>
						<p><strong><?php _e( 'Created:', CF7CONV_TEXT_DOMAIN ); ?></strong> <?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $conversation['created_at'] ?? 'now' ) ) ); ?></p>
						<p><strong><?php _e( 'Updated:', CF7CONV_TEXT_DOMAIN ); ?></strong> <?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $conversation['updated_at'] ?? 'now' ) ) ); ?></p>
						
						<?php
						$session_manager = new \CF7CONV\Core\SessionManager();
						$stats = $session_manager->get_session_stats( $conversation_id );
						if ( ! empty( $stats ) ):
						?>
						<h4><?php _e( 'Statistics', CF7CONV_TEXT_DOMAIN ); ?></h4>
						<p><strong><?php _e( 'Total Sessions:', CF7CONV_TEXT_DOMAIN ); ?></strong> <?php echo intval( $stats['total_sessions'] ); ?></p>
						<p><strong><?php _e( 'Completed:', CF7CONV_TEXT_DOMAIN ); ?></strong> <?php echo intval( $stats['completed_sessions'] ); ?></p>
						<p><strong><?php _e( 'Completion Rate:', CF7CONV_TEXT_DOMAIN ); ?></strong> <?php echo floatval( $stats['completion_rate'] ); ?>%</p>
						<?php endif; ?>
					</div>
				</div>
				
				<div class="cf7conv-builder-main">
					<div class="cf7conv-steps-header">
						<h3><?php _e( 'Conversation Steps', CF7CONV_TEXT_DOMAIN ); ?></h3>
						<div class="cf7conv-steps-actions">
							<button type="button" class="button cf7conv-save-conversation"><?php _e( 'Save Changes', CF7CONV_TEXT_DOMAIN ); ?></button>
						</div>
					</div>
					
					<div class="cf7conv-steps-list" id="cf7conv-steps-list">
						<?php 
						$config_json = $conversation['config'] ?? '{}';
						$config = json_decode( $config_json, true );
						$steps = is_array( $config ) ? ( $config['steps'] ?? [] ) : [];
						if ( empty( $steps ) ): 
						?>
						<div class="cf7conv-empty-state">
							<span class="dashicons dashicons-format-chat"></span>
							<h3><?php _e( 'No steps yet', CF7CONV_TEXT_DOMAIN ); ?></h3>
							<p><?php _e( 'Add your first step using the buttons on the left.', CF7CONV_TEXT_DOMAIN ); ?></p>
						</div>
						<?php endif; ?>
					</div>
				</div>
			</div>
			
			<!-- Hidden config data for JavaScript -->
			<script type="application/json" id="cf7conv-config-data">
				<?php 
				$config_json = $conversation['config'] ?? '{}';
				$config = json_decode( $config_json, true );
				echo wp_json_encode( is_array( $config ) ? $config : array() ); 
				?>
			</script>
		</div>
		<?php
	}
	public function render_new_conversation_page() {
		?>
		<div class="wrap">
			<h1><?php _e( 'Add New Conversation', CF7CONV_TEXT_DOMAIN ); ?></h1>
			
			<form method="post" action="" class="cf7conv-conversation-form">
				<?php wp_nonce_field( 'cf7conv_save_conversation' ); ?>
				
				<table class="form-table">
					<tr>
						<th scope="row">
							<label for="conversation_title"><?php _e( 'Title', CF7CONV_TEXT_DOMAIN ); ?></label>
						</th>
						<td>
							<input type="text" id="conversation_title" name="title" class="regular-text" required>
							<p class="description"><?php _e( 'Enter a descriptive title for your conversation.', CF7CONV_TEXT_DOMAIN ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row">
							<label for="conversation_description"><?php _e( 'Description', CF7CONV_TEXT_DOMAIN ); ?></label>
						</th>
						<td>
							<textarea id="conversation_description" name="description" class="large-text" rows="3"></textarea>
							<p class="description"><?php _e( 'Optional description shown to users at the start of the conversation.', CF7CONV_TEXT_DOMAIN ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row">
							<label for="cf7_form_id"><?php _e( 'Link to CF7 Form', CF7CONV_TEXT_DOMAIN ); ?></label>
						</th>
						<td>
							<select id="cf7_form_id" name="cf7_form_id">
								<option value=""><?php _e( 'No form (standalone conversation)', CF7CONV_TEXT_DOMAIN ); ?></option>
								<?php
								$cf7_forms = get_posts( array(
									'post_type' => 'wpcf7_contact_form',
									'posts_per_page' => -1,
									'post_status' => 'publish',
								) );
								
								foreach ( $cf7_forms as $form ):
								?>
								<option value="<?php echo esc_attr( $form->ID ); ?>">
									<?php echo esc_html( $form->post_title ); ?>
								</option>
								<?php endforeach; ?>
							</select>
							<p class="description"><?php _e( 'Optionally link this conversation to a Contact Form 7 form.', CF7CONV_TEXT_DOMAIN ); ?></p>
						</td>
					</tr>
				</table>
				
				<p class="submit">
					<input type="submit" name="create_conversation" class="button-primary" value="<?php _e( 'Create Conversation', CF7CONV_TEXT_DOMAIN ); ?>">
				</p>
			</form>
		</div>
		<?php
		
		// Handle form submission
		if ( isset( $_POST['create_conversation'] ) ) {
			check_admin_referer( 'cf7conv_save_conversation' );
			
			$conversation_manager = new \CF7CONV\Core\ConversationManager();
			$conversation_id = $conversation_manager->create_conversation( array(
				'title' => sanitize_text_field( $_POST['title'] ),
				'description' => sanitize_textarea_field( $_POST['description'] ),
				'cf7_form_id' => intval( $_POST['cf7_form_id'] ),
			) );
			
			if ( $conversation_id ) {
				wp_redirect( admin_url( 'admin.php?page=cf7conv-edit-conversation&id=' . $conversation_id ) );
				exit;
			}
		}
	}
	

	
	/**
	 * Render settings page
	 */
	public function render_settings_page() {
		if ( isset( $_POST['save_settings'] ) ) {
			check_admin_referer( 'cf7conv_settings' );
			
			$ui_settings = array(
				'theme' => sanitize_text_field( $_POST['theme'] ?? 'default' ),
				'primary_color' => sanitize_hex_color( $_POST['primary_color'] ?? '#007cba' ),
				'font_family' => sanitize_text_field( $_POST['font_family'] ?? 'inherit' ),
				'border_radius' => sanitize_text_field( $_POST['border_radius'] ?? '4px' ),
			);
			
			\CF7CONV\Core\OptionsManager::update_ui_settings( $ui_settings );
			
			cf7conv_update_option( 'session_expiry_hours', intval( $_POST['session_expiry_hours'] ?? 24 ) );
			cf7conv_update_option( 'enable_resume_links', ! empty( $_POST['enable_resume_links'] ) );
			cf7conv_update_option( 'enable_progress_bar', ! empty( $_POST['enable_progress_bar'] ) );
			cf7conv_update_option( 'enable_back_button', ! empty( $_POST['enable_back_button'] ) );
			cf7conv_update_option( 'enable_keyboard_nav', ! empty( $_POST['enable_keyboard_nav'] ) );
			cf7conv_update_option( 'animation_duration', intval( $_POST['animation_duration'] ?? 300 ) );
			cf7conv_update_option( 'auto_save_interval', intval( $_POST['auto_save_interval'] ?? 30 ) );
			
			echo '<div class="notice notice-success"><p>' . __( 'Settings saved successfully.', CF7CONV_TEXT_DOMAIN ) . '</p></div>';
		}
		
		$ui_settings = \CF7CONV\Core\OptionsManager::get_ui_settings();
		
		?>
		<div class="wrap">
			<h1><?php _e( 'Conversation Settings', CF7CONV_TEXT_DOMAIN ); ?></h1>
			
			<form method="post" action="">
				<?php wp_nonce_field( 'cf7conv_settings' ); ?>
				
				<h2><?php _e( 'General Settings', CF7CONV_TEXT_DOMAIN ); ?></h2>
				<table class="form-table">
					<tr>
						<th scope="row"><?php _e( 'Session Expiry', CF7CONV_TEXT_DOMAIN ); ?></th>
						<td>
							<input type="number" name="session_expiry_hours" value="<?php echo esc_attr( cf7conv_get_option( 'session_expiry_hours', 24 ) ); ?>" min="1" max="168">
							<span><?php _e( 'hours', CF7CONV_TEXT_DOMAIN ); ?></span>
							<p class="description"><?php _e( 'How long conversation sessions remain active.', CF7CONV_TEXT_DOMAIN ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php _e( 'Features', CF7CONV_TEXT_DOMAIN ); ?></th>
						<td>
							<fieldset>
								<label>
									<input type="checkbox" name="enable_resume_links" value="1" <?php checked( cf7conv_get_option( 'enable_resume_links', true ) ); ?>>
									<?php _e( 'Enable resume links', CF7CONV_TEXT_DOMAIN ); ?>
								</label><br>
								<label>
									<input type="checkbox" name="enable_progress_bar" value="1" <?php checked( cf7conv_get_option( 'enable_progress_bar', true ) ); ?>>
									<?php _e( 'Show progress bar', CF7CONV_TEXT_DOMAIN ); ?>
								</label><br>
								<label>
									<input type="checkbox" name="enable_back_button" value="1" <?php checked( cf7conv_get_option( 'enable_back_button', true ) ); ?>>
									<?php _e( 'Enable back button', CF7CONV_TEXT_DOMAIN ); ?>
								</label><br>
								<label>
									<input type="checkbox" name="enable_keyboard_nav" value="1" <?php checked( cf7conv_get_option( 'enable_keyboard_nav', true ) ); ?>>
									<?php _e( 'Enable keyboard navigation', CF7CONV_TEXT_DOMAIN ); ?>
								</label>
							</fieldset>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php _e( 'Animation Duration', CF7CONV_TEXT_DOMAIN ); ?></th>
						<td>
							<input type="number" name="animation_duration" value="<?php echo esc_attr( cf7conv_get_option( 'animation_duration', 300 ) ); ?>" min="0" max="1000">
							<span><?php _e( 'milliseconds', CF7CONV_TEXT_DOMAIN ); ?></span>
							<p class="description"><?php _e( 'Step transition animation duration. Set to 0 to disable animations.', CF7CONV_TEXT_DOMAIN ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php _e( 'Auto-save Interval', CF7CONV_TEXT_DOMAIN ); ?></th>
						<td>
							<input type="number" name="auto_save_interval" value="<?php echo esc_attr( cf7conv_get_option( 'auto_save_interval', 30 ) ); ?>" min="0" max="300">
							<span><?php _e( 'seconds', CF7CONV_TEXT_DOMAIN ); ?></span>
							<p class="description"><?php _e( 'How often to automatically save progress. Set to 0 to disable auto-save.', CF7CONV_TEXT_DOMAIN ); ?></p>
						</td>
					</tr>
				</table>
				
				<h2><?php _e( 'Appearance', CF7CONV_TEXT_DOMAIN ); ?></h2>
				<table class="form-table">
					<tr>
						<th scope="row"><?php _e( 'Primary Color', CF7CONV_TEXT_DOMAIN ); ?></th>
						<td>
							<input type="text" name="primary_color" value="<?php echo esc_attr( $ui_settings['primary_color'] ?? '#007cba' ); ?>" class="cf7conv-color-picker">
						</td>
					</tr>
					<tr>
						<th scope="row"><?php _e( 'Font Family', CF7CONV_TEXT_DOMAIN ); ?></th>
						<td>
							<input type="text" name="font_family" value="<?php echo esc_attr( $ui_settings['font_family'] ?? 'inherit' ); ?>" class="regular-text">
							<p class="description"><?php _e( 'CSS font-family value. Use "inherit" to use theme font.', CF7CONV_TEXT_DOMAIN ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php _e( 'Border Radius', CF7CONV_TEXT_DOMAIN ); ?></th>
						<td>
							<input type="text" name="border_radius" value="<?php echo esc_attr( $ui_settings['border_radius'] ?? '4px' ); ?>" class="small-text">
							<p class="description"><?php _e( 'CSS border-radius value for rounded corners.', CF7CONV_TEXT_DOMAIN ); ?></p>
						</td>
					</tr>
				</table>
				
				<p class="submit">
					<input type="submit" name="save_settings" class="button-primary" value="<?php _e( 'Save Settings', CF7CONV_TEXT_DOMAIN ); ?>">
				</p>
			</form>
		</div>
		<?php
	}
	

	
	/**
	 * AJAX handler for saving conversation
	 */
	public function ajax_save_conversation() {
		check_ajax_referer( 'cf7conv_admin', 'nonce' );
		
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( __( 'Insufficient permissions.', CF7CONV_TEXT_DOMAIN ) );
		}
		
		$conversation_id = intval( $_POST['conversation_id'] ?? 0 );
		$data = array(
			'title' => sanitize_text_field( $_POST['title'] ?? '' ),
			'description' => sanitize_textarea_field( $_POST['description'] ?? '' ),
			'config' => wp_json_encode( $_POST['config'] ?? array() ),
			'status' => sanitize_text_field( $_POST['status'] ?? 'draft' ),
		);
		
		$conversation_manager = new \CF7CONV\Core\ConversationManager();
		
		if ( $conversation_id > 0 ) {
			$result = $conversation_manager->update_conversation( $conversation_id, $data );
		} else {
			$result = $conversation_manager->create_conversation( $data );
			$conversation_id = $result;
		}
		
		if ( $result ) {
			wp_send_json_success( array(
				'conversation_id' => $conversation_id,
				'message' => __( 'Conversation saved successfully.', CF7CONV_TEXT_DOMAIN ),
			) );
		} else {
			wp_send_json_error( __( 'Failed to save conversation.', CF7CONV_TEXT_DOMAIN ) );
		}
	}
	
	/**
	 * AJAX handler for deleting conversation
	 */
	public function ajax_delete_conversation() {
		check_ajax_referer( 'cf7conv_admin', 'nonce' );
		
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( __( 'Insufficient permissions.', CF7CONV_TEXT_DOMAIN ) );
		}
		
		$conversation_id = intval( $_POST['conversation_id'] ?? 0 );
		
		if ( $conversation_id <= 0 ) {
			wp_send_json_error( __( 'Invalid conversation ID.', CF7CONV_TEXT_DOMAIN ) );
		}
		
		$conversation_manager = new \CF7CONV\Core\ConversationManager();
		$result = $conversation_manager->delete_conversation( $conversation_id );
		
		if ( $result ) {
			wp_send_json_success( __( 'Conversation deleted successfully.', CF7CONV_TEXT_DOMAIN ) );
		} else {
			wp_send_json_error( __( 'Failed to delete conversation.', CF7CONV_TEXT_DOMAIN ) );
		}
	}
	
	/**
	 * AJAX handler for duplicating conversation
	 */
	public function ajax_duplicate_conversation() {
		check_ajax_referer( 'cf7conv_admin', 'nonce' );
		
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( __( 'Insufficient permissions.', CF7CONV_TEXT_DOMAIN ) );
		}
		
		$conversation_id = intval( $_POST['conversation_id'] ?? 0 );
		
		if ( $conversation_id <= 0 ) {
			wp_send_json_error( __( 'Invalid conversation ID.', CF7CONV_TEXT_DOMAIN ) );
		}
		
		$conversation_manager = new \CF7CONV\Core\ConversationManager();
		$original = $conversation_manager->get_conversation( $conversation_id );
		
		if ( ! $original ) {
			wp_send_json_error( __( 'Conversation not found.', CF7CONV_TEXT_DOMAIN ) );
		}
		
		$duplicate_data = array(
			'title' => $original['title'] . ' (Copy)',
			'description' => $original['description'],
			'cf7_form_id' => $original['cf7_form_id'],
			'config' => $original['config'],
			'status' => 'draft',
		);
		
		$new_id = $conversation_manager->create_conversation( $duplicate_data );
		
		if ( $new_id ) {
			wp_send_json_success( array(
				'conversation_id' => $new_id,
				'message' => __( 'Conversation duplicated successfully.', CF7CONV_TEXT_DOMAIN ),
			) );
		} else {
			wp_send_json_error( __( 'Failed to duplicate conversation.', CF7CONV_TEXT_DOMAIN ) );
		}
	}
	
	/**
	 * Render sessions page
	 */
	public function render_sessions_page() {
		$session_manager = new \CF7CONV\Core\SessionManager();
		$conversation_manager = new \CF7CONV\Core\ConversationManager();
		
		// Handle bulk actions
		if ( isset( $_POST['action'] ) && $_POST['action'] === 'delete_sessions' && isset( $_POST['session_ids'] ) ) {
			check_admin_referer( 'cf7conv_sessions' );
			
			$deleted_count = 0;
			foreach ( $_POST['session_ids'] as $session_id ) {
				if ( $session_manager->delete_session( sanitize_text_field( $session_id ) ) ) {
					$deleted_count++;
				}
			}
			
			echo '<div class="notice notice-success"><p>' . 
				sprintf( _n( '%d session deleted.', '%d sessions deleted.', $deleted_count, CF7CONV_TEXT_DOMAIN ), $deleted_count ) . 
				'</p></div>';
		}
		
		// Get filter parameters
		$current_status = sanitize_text_field( $_GET['status'] ?? 'all' );
		$current_conversation = intval( $_GET['conversation_id'] ?? 0 );
		$search = sanitize_text_field( $_GET['s'] ?? '' );
		$paged = max( 1, intval( $_GET['paged'] ?? 1 ) );
		$per_page = 20;
		
		// Get sessions
		$args = array(
			'limit' => $per_page,
			'offset' => ( $paged - 1 ) * $per_page,
			'search' => $search,
		);
		
		if ( $current_status !== 'all' ) {
			$args['status'] = $current_status;
		}
		
		if ( $current_conversation > 0 ) {
			$args['conversation_id'] = $current_conversation;
		}
		
		$sessions_data = $session_manager->get_sessions( $args );
		$sessions = $sessions_data['sessions'];
		$total_sessions = $sessions_data['total'];
		
		// Get session counts for status filter
		$session_counts = $session_manager->get_session_counts();
		
		// Get conversations for filter
		$conversations = $conversation_manager->get_conversations( array( 'status' => 'published' ) );
		
		?>
		<div class="wrap">
			<h1 class="wp-heading-inline"><?php _e( 'Conversation Sessions', CF7CONV_TEXT_DOMAIN ); ?></h1>
			
			<div class="cf7conv-sessions-filters">
				<ul class="subsubsub">
					<li class="all">
						<a href="<?php echo admin_url( 'admin.php?page=cf7conv-sessions' ); ?>" <?php echo $current_status === 'all' ? 'class="current"' : ''; ?>>
							<?php _e( 'All', CF7CONV_TEXT_DOMAIN ); ?> <span class="count">(<?php echo $session_counts['all']; ?>)</span>
						</a> |
					</li>
					<li class="active">
						<a href="<?php echo admin_url( 'admin.php?page=cf7conv-sessions&status=active' ); ?>" <?php echo $current_status === 'active' ? 'class="current"' : ''; ?>>
							<?php _e( 'Active', CF7CONV_TEXT_DOMAIN ); ?> <span class="count">(<?php echo $session_counts['active']; ?>)</span>
						</a> |
					</li>
					<li class="completed">
						<a href="<?php echo admin_url( 'admin.php?page=cf7conv-sessions&status=completed' ); ?>" <?php echo $current_status === 'completed' ? 'class="current"' : ''; ?>>
							<?php _e( 'Completed', CF7CONV_TEXT_DOMAIN ); ?> <span class="count">(<?php echo $session_counts['completed']; ?>)</span>
						</a> |
					</li>
					<li class="abandoned">
						<a href="<?php echo admin_url( 'admin.php?page=cf7conv-sessions&status=abandoned' ); ?>" <?php echo $current_status === 'abandoned' ? 'class="current"' : ''; ?>>
							<?php _e( 'Abandoned', CF7CONV_TEXT_DOMAIN ); ?> <span class="count">(<?php echo $session_counts['abandoned']; ?>)</span>
						</a>
					</li>
				</ul>
			</div>
			
			<form method="get" class="cf7conv-sessions-search">
				<input type="hidden" name="page" value="cf7conv-sessions">
				<?php if ( $current_status !== 'all' ): ?>
				<input type="hidden" name="status" value="<?php echo esc_attr( $current_status ); ?>">
				<?php endif; ?>
				
				<div class="cf7conv-search-filters">
					<select name="conversation_id">
						<option value=""><?php _e( 'All Conversations', CF7CONV_TEXT_DOMAIN ); ?></option>
						<?php foreach ( $conversations as $conversation ): ?>
						<option value="<?php echo esc_attr( $conversation['id'] ); ?>" <?php selected( $current_conversation, $conversation['id'] ); ?>>
							<?php echo esc_html( $conversation['title'] ); ?>
						</option>
						<?php endforeach; ?>
					</select>
					
					<input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php _e( 'Search sessions...', CF7CONV_TEXT_DOMAIN ); ?>">
					<input type="submit" class="button" value="<?php _e( 'Filter', CF7CONV_TEXT_DOMAIN ); ?>">
				</div>
			</form>
			
			<?php if ( empty( $sessions ) ): ?>
			<div class="cf7conv-no-sessions">
				<h2><?php _e( 'No sessions found', CF7CONV_TEXT_DOMAIN ); ?></h2>
				<p><?php _e( 'Sessions will appear here when users start conversations.', CF7CONV_TEXT_DOMAIN ); ?></p>
				<?php if ( empty( $conversations ) ): ?>
				<p>
					<a href="<?php echo admin_url( 'admin.php?page=cf7conv-new-conversation' ); ?>" class="button button-primary">
						<?php _e( 'Create Your First Conversation', CF7CONV_TEXT_DOMAIN ); ?>
					</a>
				</p>
				<?php endif; ?>
			</div>
			<?php else: ?>
			<form method="post" id="cf7conv-sessions-form">
				<?php wp_nonce_field( 'cf7conv_sessions' ); ?>
				
				<div class="tablenav top">
					<div class="alignleft actions bulkactions">
						<select name="action">
							<option value="-1"><?php _e( 'Bulk Actions', CF7CONV_TEXT_DOMAIN ); ?></option>
							<option value="delete_sessions"><?php _e( 'Delete', CF7CONV_TEXT_DOMAIN ); ?></option>
						</select>
						<input type="submit" class="button action" value="<?php _e( 'Apply', CF7CONV_TEXT_DOMAIN ); ?>">
					</div>
					
					<?php
					$total_pages = ceil( $total_sessions / $per_page );
					if ( $total_pages > 1 ):
					?>
					<div class="tablenav-pages">
						<span class="displaying-num"><?php printf( _n( '%s item', '%s items', $total_sessions, CF7CONV_TEXT_DOMAIN ), number_format_i18n( $total_sessions ) ); ?></span>
						<?php
						$page_links = paginate_links( array(
							'base' => add_query_arg( 'paged', '%#%' ),
							'format' => '',
							'prev_text' => __( '&laquo;' ),
							'next_text' => __( '&raquo;' ),
							'total' => $total_pages,
							'current' => $paged,
						) );
						echo $page_links;
						?>
					</div>
					<?php endif; ?>
				</div>
				
				<table class="wp-list-table widefat fixed striped cf7conv-sessions-table">
					<thead>
						<tr>
							<td class="manage-column column-cb check-column">
								<input type="checkbox" id="cb-select-all-1">
							</td>
							<th class="manage-column column-session"><?php _e( 'Session', CF7CONV_TEXT_DOMAIN ); ?></th>
							<th class="manage-column column-conversation"><?php _e( 'Conversation', CF7CONV_TEXT_DOMAIN ); ?></th>
							<th class="manage-column column-email"><?php _e( 'Email', CF7CONV_TEXT_DOMAIN ); ?></th>
							<th class="manage-column column-status"><?php _e( 'Status', CF7CONV_TEXT_DOMAIN ); ?></th>
							<th class="manage-column column-progress"><?php _e( 'Progress', CF7CONV_TEXT_DOMAIN ); ?></th>
							<th class="manage-column column-date"><?php _e( 'Started', CF7CONV_TEXT_DOMAIN ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $sessions as $session ): ?>
						<?php
						$conversation = null;
						if ( $session['conversation_id'] ) {
							foreach ( $conversations as $conv ) {
								if ( $conv['id'] == $session['conversation_id'] ) {
									$conversation = $conv;
									break;
								}
							}
						}
						?>
						<tr>
							<th scope="row" class="check-column">
								<input type="checkbox" name="session_ids[]" value="<?php echo esc_attr( $session['session_id'] ); ?>">
							</th>
							<td class="column-session">
								<strong><?php echo esc_html( substr( $session['session_id'], 0, 12 ) . '...' ); ?></strong>
								<div class="row-actions">
									<span class="view">
										<a href="<?php echo cf7conv_get_conversation_url( $session['conversation_id'], $session['resume_token'] ); ?>" target="_blank">
											<?php _e( 'View', CF7CONV_TEXT_DOMAIN ); ?>
										</a>
									</span>
								</div>
							</td>
							<td class="column-conversation">
								<?php if ( $conversation ): ?>
								<a href="<?php echo admin_url( 'admin.php?page=cf7conv-edit-conversation&id=' . $conversation['id'] ); ?>">
									<?php echo esc_html( $conversation['title'] ); ?>
								</a>
								<?php else: ?>
								<em><?php _e( 'Unknown', CF7CONV_TEXT_DOMAIN ); ?></em>
								<?php endif; ?>
							</td>
							<td class="column-email">
								<?php echo esc_html( $session['email'] ?: __( 'Not provided', CF7CONV_TEXT_DOMAIN ) ); ?>
							</td>
							<td class="column-status">
								<span class="cf7conv-status cf7conv-status-<?php echo esc_attr( $session['status'] ); ?>">
									<?php echo esc_html( ucfirst( $session['status'] ) ); ?>
								</span>
							</td>
							<td class="column-progress">
								<?php echo esc_html( $session['current_step'] ?: __( 'Not started', CF7CONV_TEXT_DOMAIN ) ); ?>
							</td>
							<td class="column-date">
								<?php echo esc_html( date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $session['started_at'] ) ) ); ?>
							</td>
						</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
				
				<div class="tablenav bottom">
					<?php if ( $total_pages > 1 ): ?>
					<div class="tablenav-pages">
						<?php echo $page_links; ?>
					</div>
					<?php endif; ?>
				</div>
			</form>
			<?php endif; ?>
		</div>
		
		<style>
		.cf7conv-sessions-filters {
			margin: 10px 0;
		}
		
		.cf7conv-sessions-search {
			margin: 20px 0;
		}
		
		.cf7conv-search-filters {
			display: flex;
			gap: 10px;
			align-items: center;
		}
		
		.cf7conv-search-filters select,
		.cf7conv-search-filters input[type="search"] {
			min-width: 200px;
		}
		
		.cf7conv-no-sessions {
			text-align: center;
			padding: 40px 20px;
			background: #fff;
			border: 1px solid #c3c4c7;
			border-radius: 4px;
			margin-top: 20px;
		}
		
		.cf7conv-status {
			padding: 2px 8px;
			border-radius: 3px;
			font-size: 11px;
			font-weight: 600;
			text-transform: uppercase;
		}
		
		.cf7conv-status-active {
			background: #d1ecf1;
			color: #0c5460;
		}
		
		.cf7conv-status-completed {
			background: #d4edda;
			color: #155724;
		}
		
		.cf7conv-status-abandoned {
			background: #f8d7da;
			color: #721c24;
		}
		
		.cf7conv-status-expired {
			background: #fff3cd;
			color: #856404;
		}
		</style>
		<?php
	}
	
	/**
	 * Render debug page
	 */
	public function render_debug_page() {
		// Handle manual table creation
		if ( isset( $_POST['create_tables'] ) ) {
			check_admin_referer( 'cf7conv_debug' );
			CF7CONV\Database\SchemaManager::create_tables();
			echo '<div class="notice notice-success"><p>' . __( 'Database tables created successfully.', CF7CONV_TEXT_DOMAIN ) . '</p></div>';
		}
		
		// Handle flush rewrite rules
		if ( isset( $_POST['flush_rewrite_rules'] ) ) {
			check_admin_referer( 'cf7conv_debug' );
			flush_rewrite_rules();
			echo '<div class="notice notice-success"><p>' . __( 'Rewrite rules flushed successfully.', CF7CONV_TEXT_DOMAIN ) . '</p></div>';
		}
		
		global $wpdb;
		$conversations_table = $wpdb->prefix . CF7CONV_CONVERSATIONS_TABLE;
		$sessions_table = $wpdb->prefix . CF7CONV_SESSIONS_TABLE;
		
		$conversations_exists = $wpdb->get_var( "SHOW TABLES LIKE '$conversations_table'" ) === $conversations_table;
		$sessions_exists = $wpdb->get_var( "SHOW TABLES LIKE '$sessions_table'" ) === $sessions_table;
		
		?>
		<div class="wrap">
			<h1><?php _e( 'CF7 Conversation Debug', CF7CONV_TEXT_DOMAIN ); ?></h1>
			
			<div class="cf7conv-debug-section">
				<h2><?php _e( 'System Status', CF7CONV_TEXT_DOMAIN ); ?></h2>
				<table class="widefat">
					<tbody>
						<tr>
							<th><?php _e( 'Plugin Version', CF7CONV_TEXT_DOMAIN ); ?></th>
							<td><?php echo esc_html( CF7CONV_VERSION ); ?></td>
						</tr>
						<tr>
							<th><?php _e( 'WordPress Version', CF7CONV_TEXT_DOMAIN ); ?></th>
							<td><?php echo esc_html( get_bloginfo( 'version' ) ); ?></td>
						</tr>
						<tr>
							<th><?php _e( 'PHP Version', CF7CONV_TEXT_DOMAIN ); ?></th>
							<td><?php echo esc_html( PHP_VERSION ); ?></td>
						</tr>
						<tr>
							<th><?php _e( 'CF7 Active', CF7CONV_TEXT_DOMAIN ); ?></th>
							<td>
								<?php if ( class_exists( 'WPCF7' ) ): ?>
								<span style="color: #00a32a;">✓ <?php _e( 'Active', CF7CONV_TEXT_DOMAIN ); ?></span>
								<?php else: ?>
								<span style="color: #d63638;">✗ <?php _e( 'Not Active', CF7CONV_TEXT_DOMAIN ); ?></span>
								<?php endif; ?>
							</td>
						</tr>
						<tr>
							<th><?php _e( 'Conversations Table', CF7CONV_TEXT_DOMAIN ); ?></th>
							<td>
								<?php if ( $conversations_exists ): ?>
								<span style="color: #00a32a;">✓ <?php _e( 'Exists', CF7CONV_TEXT_DOMAIN ); ?></span>
								<?php else: ?>
								<span style="color: #d63638;">✗ <?php _e( 'Missing', CF7CONV_TEXT_DOMAIN ); ?></span>
								<?php endif; ?>
							</td>
						</tr>
						<tr>
							<th><?php _e( 'Sessions Table', CF7CONV_TEXT_DOMAIN ); ?></th>
							<td>
								<?php if ( $sessions_exists ): ?>
								<span style="color: #00a32a;">✓ <?php _e( 'Exists', CF7CONV_TEXT_DOMAIN ); ?></span>
								<?php else: ?>
								<span style="color: #d63638;">✗ <?php _e( 'Missing', CF7CONV_TEXT_DOMAIN ); ?></span>
								<?php endif; ?>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
			
			<div class="cf7conv-debug-section">
				<h2><?php _e( 'Database Actions', CF7CONV_TEXT_DOMAIN ); ?></h2>
				<form method="post" style="display: inline-block; margin-right: 10px;">
					<?php wp_nonce_field( 'cf7conv_debug' ); ?>
					<input type="submit" name="create_tables" class="button button-primary" value="<?php _e( 'Create/Update Tables', CF7CONV_TEXT_DOMAIN ); ?>">
				</form>
				
				<form method="post" style="display: inline-block;">
					<?php wp_nonce_field( 'cf7conv_debug' ); ?>
					<input type="submit" name="flush_rewrite_rules" class="button" value="<?php _e( 'Flush Rewrite Rules', CF7CONV_TEXT_DOMAIN ); ?>">
				</form>
			</div>
			
			<?php if ( $conversations_exists && $sessions_exists ): ?>
			<div class="cf7conv-debug-section">
				<h2><?php _e( 'Database Statistics', CF7CONV_TEXT_DOMAIN ); ?></h2>
				<?php
				$conversation_count = $wpdb->get_var( "SELECT COUNT(*) FROM $conversations_table" );
				$session_count = $wpdb->get_var( "SELECT COUNT(*) FROM $sessions_table" );
				$active_sessions = $wpdb->get_var( "SELECT COUNT(*) FROM $sessions_table WHERE status = 'active'" );
				$completed_sessions = $wpdb->get_var( "SELECT COUNT(*) FROM $sessions_table WHERE status = 'completed'" );
				?>
				<table class="widefat">
					<tbody>
						<tr>
							<th><?php _e( 'Total Conversations', CF7CONV_TEXT_DOMAIN ); ?></th>
							<td><?php echo intval( $conversation_count ); ?></td>
						</tr>
						<tr>
							<th><?php _e( 'Total Sessions', CF7CONV_TEXT_DOMAIN ); ?></th>
							<td><?php echo intval( $session_count ); ?></td>
						</tr>
						<tr>
							<th><?php _e( 'Active Sessions', CF7CONV_TEXT_DOMAIN ); ?></th>
							<td><?php echo intval( $active_sessions ); ?></td>
						</tr>
						<tr>
							<th><?php _e( 'Completed Sessions', CF7CONV_TEXT_DOMAIN ); ?></th>
							<td><?php echo intval( $completed_sessions ); ?></td>
						</tr>
					</tbody>
				</table>
			</div>
			<?php endif; ?>
		</div>
		<?php
	}
}
