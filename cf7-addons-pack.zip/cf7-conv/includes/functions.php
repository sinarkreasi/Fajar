<?php

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Get plugin option
 *
 * @param string $name Option name
 * @param mixed $default Default value
 * @return mixed
 */
function cf7conv_get_option( $name, $default = false ) {
	$options = get_option( 'cf7conv_options', array() );
	return isset( $options[ $name ] ) ? $options[ $name ] : $default;
}

/**
 * Update plugin option
 *
 * @param string $name Option name
 * @param mixed $value Option value
 */
function cf7conv_update_option( $name, $value ) {
	$options = get_option( 'cf7conv_options', array() );
	$options[ $name ] = $value;
	update_option( 'cf7conv_options', $options );
}

/**
 * Generate unique conversation session ID
 *
 * @return string
 */
function cf7conv_generate_session_id() {
	return 'cf7conv_' . wp_generate_password( 32, false );
}

/**
 * Generate resume token
 *
 * @param string $session_id
 * @return string
 */
function cf7conv_generate_resume_token( $session_id ) {
	return wp_hash( $session_id . 'resume_token' . time() );
}

/**
 * Sanitize step data
 *
 * @param array $step_data
 * @return array
 */
function cf7conv_sanitize_step_data( $step_data ) {
	$sanitized = array();
	
	if ( ! is_array( $step_data ) ) {
		return $sanitized;
	}
	
	foreach ( $step_data as $key => $value ) {
		if ( $key === null || $key === '' ) {
			continue;
		}
		
		if ( is_array( $value ) ) {
			$sanitized[ $key ] = cf7conv_sanitize_step_data( $value );
		} else {
			$sanitized[ sanitize_key( $key ) ] = sanitize_text_field( $value ?? '' );
		}
	}
	
	return $sanitized;
}

/**
 * Log debug message
 *
 * @param string $message
 * @param string $level
 */
function cf7conv_log( $message, $level = 'info' ) {
	if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
		// Ensure message is a string
		if ( ! is_string( $message ) ) {
			$message = print_r( $message, true );
		}
		
		error_log( sprintf( '[CF7CONV %s] %s', strtoupper( $level ), $message ) );
	}
}

/**
 * Safe error handler for CF7CONV operations
 *
 * @param callable $callback
 * @param mixed $default_return
 * @return mixed
 */
function cf7conv_safe_execute( $callback, $default_return = null ) {
	try {
		return call_user_func( $callback );
	} catch ( Exception $e ) {
		cf7conv_log( 'Exception caught: ' . $e->getMessage(), 'error' );
		return $default_return;
	} catch ( Error $e ) {
		cf7conv_log( 'Error caught: ' . $e->getMessage(), 'error' );
		return $default_return;
	}
}

/**
 * Get conversation step types
 *
 * @return array
 */
function cf7conv_get_step_types() {
	return array(
		'question' => array(
			'label' => __( 'Question', CF7CONV_TEXT_DOMAIN ),
			'description' => __( 'Ask for user input (text, email, number)', CF7CONV_TEXT_DOMAIN ),
			'icon' => 'dashicons-editor-help',
		),
		'choice' => array(
			'label' => __( 'Choice', CF7CONV_TEXT_DOMAIN ),
			'description' => __( 'Multiple choice selection (radio, checkbox)', CF7CONV_TEXT_DOMAIN ),
			'icon' => 'dashicons-list-view',
		),
		'info' => array(
			'label' => __( 'Information', CF7CONV_TEXT_DOMAIN ),
			'description' => __( 'Display content without input', CF7CONV_TEXT_DOMAIN ),
			'icon' => 'dashicons-info',
		),
		'logic' => array(
			'label' => __( 'Logic', CF7CONV_TEXT_DOMAIN ),
			'description' => __( 'Conditional routing based on answers', CF7CONV_TEXT_DOMAIN ),
			'icon' => 'dashicons-randomize',
		),
		'conditional' => array(
			'label' => __( 'Conditional', CF7CONV_TEXT_DOMAIN ),
			'description' => __( 'Conditional logic and branching', CF7CONV_TEXT_DOMAIN ),
			'icon' => 'dashicons-randomize',
		),
		'pricing' => array(
			'label' => __( 'Pricing', CF7CONV_TEXT_DOMAIN ),
			'description' => __( 'Dynamic price calculation', CF7CONV_TEXT_DOMAIN ),
			'icon' => 'dashicons-money-alt',
		),
		'payment' => array(
			'label' => __( 'Payment', CF7CONV_TEXT_DOMAIN ),
			'description' => __( 'Checkout and payment processing', CF7CONV_TEXT_DOMAIN ),
			'icon' => 'dashicons-cart',
		),
		'result' => array(
			'label' => __( 'Result', CF7CONV_TEXT_DOMAIN ),
			'description' => __( 'Summary and recommendations', CF7CONV_TEXT_DOMAIN ),
			'icon' => 'dashicons-yes-alt',
		),
	);
}

/**
 * Get conversation session statuses
 *
 * @return array
 */
function cf7conv_get_session_statuses() {
	return array(
		'active' => __( 'Active', CF7CONV_TEXT_DOMAIN ),
		'completed' => __( 'Completed', CF7CONV_TEXT_DOMAIN ),
		'abandoned' => __( 'Abandoned', CF7CONV_TEXT_DOMAIN ),
		'expired' => __( 'Expired', CF7CONV_TEXT_DOMAIN ),
	);
}

/**
 * Check if Mini Ecommerce is available
 *
 * @return bool
 */
function cf7conv_is_ecommerce_available() {
	return function_exists( 'cf7mc_get_available_gateways' ) && class_exists( 'CF7MC\Core\OrderManager' );
}

/**
 * Check if UCA is available
 *
 * @return bool
 */
function cf7conv_is_uca_available() {
	return function_exists( 'cf7uca_generate_access_token' );
}

/**
 * Create order through CF7 Mini Ecommerce
 *
 * @param array $order_data
 * @return int|false Order ID or false on failure
 */
function cf7conv_create_order( $order_data ) {
	if ( ! cf7conv_is_ecommerce_available() ) {
		return false;
	}
	
	try {
		$order_manager = new CF7MC\Core\OrderManager();
		return $order_manager->create_order( $order_data );
	} catch ( Exception $e ) {
		cf7conv_log( 'Failed to create order: ' . $e->getMessage(), 'error' );
		return false;
	}
}

/**
 * Get available payment gateways
 *
 * @return array
 */
function cf7conv_get_payment_gateways() {
	if ( ! cf7conv_is_ecommerce_available() ) {
		return array();
	}
	
	if ( function_exists( 'cf7mc_get_available_gateways' ) ) {
		return cf7mc_get_available_gateways();
	}
	
	return array();
}

/**
 * Format price using CF7 Mini Ecommerce formatting
 *
 * @param float $amount
 * @return string
 */
function cf7conv_format_price( $amount ) {
	if ( cf7conv_is_ecommerce_available() && function_exists( 'cf7mc_format_price' ) ) {
		return cf7mc_format_price( $amount );
	}
	
	return '$' . number_format( $amount, 2 );
}

/**
 * Get payment URL for an order
 *
 * @param int $order_id
 * @param string $gateway
 * @return string
 */
function cf7conv_get_payment_url( $order_id, $gateway = '' ) {
	if ( ! cf7conv_is_ecommerce_available() ) {
		return '';
	}
	
	if ( function_exists( 'cf7mc_get_payment_url' ) ) {
		return cf7mc_get_payment_url( $order_id, $gateway );
	}
	
	// Fallback URL
	return home_url( "payment/$order_id" );
}

/**
 * Format conversation URL
 *
 * @param string $conversation_id
 * @param string $resume_token
 * @return string
 */
function cf7conv_get_conversation_url( $conversation_id, $resume_token = '' ) {
	$base_url = home_url( 'cf7conv/' . $conversation_id );
	
	if ( ! empty( $resume_token ) ) {
		$base_url .= '/resume/' . $resume_token;
	}
	
	return $base_url;
}

/**
 * Debug conversation URL rewriting
 *
 * @param string $conversation_id
 * @return array
 */
function cf7conv_debug_conversation_url( $conversation_id ) {
	$url = cf7conv_get_conversation_url( $conversation_id );
	$parsed = parse_url( $url );
	
	// Test if rewrite rules are working
	$request = wp_parse_request( $parsed['path'] ?? '' );
	
	return array(
		'url' => $url,
		'parsed_path' => $parsed['path'] ?? '',
		'query_vars' => $request,
		'rewrite_rules' => get_option( 'rewrite_rules' ),
	);
}

/**
 * Evaluate conditional logic
 *
 * @param array $condition
 * @param array $answers
 * @return bool
 */
function cf7conv_evaluate_condition( $condition, $answers ) {
	if ( ! is_array( $condition ) || empty( $condition['field'] ) || empty( $condition['operator'] ) ) {
		return false;
	}
	
	if ( ! is_array( $answers ) ) {
		$answers = array();
	}
	
	$field_value = isset( $answers[ $condition['field'] ] ) ? $answers[ $condition['field'] ] : '';
	$compare_value = $condition['value'] ?? '';
	
	// Convert null values to empty strings
	$field_value = $field_value ?? '';
	$compare_value = $compare_value ?? '';
	
	switch ( $condition['operator'] ) {
		case 'equals':
			return $field_value === $compare_value;
		case 'not_equals':
			return $field_value !== $compare_value;
		case 'contains':
			return strpos( (string) $field_value, (string) $compare_value ) !== false;
		case 'not_contains':
			return strpos( (string) $field_value, (string) $compare_value ) === false;
		case 'greater_than':
			return floatval( $field_value ) > floatval( $compare_value );
		case 'less_than':
			return floatval( $field_value ) < floatval( $compare_value );
		case 'is_empty':
			return empty( $field_value );
		case 'is_not_empty':
			return ! empty( $field_value );
		default:
			return false;
	}
}

/**
 * Calculate dynamic pricing
 *
 * @param array $pricing_rules
 * @param array $answers
 * @return float
 */
function cf7conv_calculate_pricing( $pricing_rules, $answers ) {
	$total = 0;
	
	if ( ! is_array( $pricing_rules ) ) {
		return $total;
	}
	
	if ( ! is_array( $answers ) ) {
		$answers = array();
	}
	
	foreach ( $pricing_rules as $rule ) {
		if ( ! is_array( $rule ) || empty( $rule['type'] ) ) {
			continue;
		}
		
		switch ( $rule['type'] ) {
			case 'base':
				$total += floatval( $rule['amount'] ?? 0 );
				break;
				
			case 'conditional':
				if ( ! empty( $rule['condition'] ) && cf7conv_evaluate_condition( $rule['condition'], $answers ) ) {
					$total += floatval( $rule['amount'] ?? 0 );
				}
				break;
				
			case 'multiplier':
				if ( ! empty( $rule['field'] ) && isset( $answers[ $rule['field'] ] ) ) {
					$multiplier = floatval( $answers[ $rule['field'] ] ?? 0 );
					$total += $multiplier * floatval( $rule['amount'] ?? 0 );
				}
				break;
		}
	}
	
	return max( 0, $total );
}

/**
 * Get ecommerce integration data for frontend
 *
 * @return array
 */
function cf7conv_get_ecommerce_data() {
	$data = array(
		'available' => cf7conv_is_ecommerce_available(),
		'gateways' => array(),
		'currency' => 'USD',
		'format_price_callback' => 'cf7conv_format_price',
	);
	
	if ( $data['available'] ) {
		// Get available gateways
		if ( function_exists( 'cf7mc_get_available_gateways' ) ) {
			$gateways = cf7mc_get_available_gateways();
			foreach ( $gateways as $gateway_id => $gateway ) {
				$data['gateways'][] = array(
					'id' => $gateway_id,
					'name' => $gateway->get_name(),
					'description' => $gateway->get_description(),
					'supports_inline' => method_exists( $gateway, 'supports_inline_checkout' ) ? $gateway->supports_inline_checkout() : false,
				);
			}
		}
		
		// Get currency
		if ( function_exists( 'cf7mc_get_option' ) ) {
			$data['currency'] = cf7mc_get_option( 'currency', 'USD' );
		}
	}
	
	return $data;
}

/**
 * Get available payment gateways for frontend
 *
 * @return array
 */
function cf7conv_get_available_gateways() {
	if ( ! cf7conv_is_ecommerce_available() ) {
		return array();
	}
	
	$gateways = array();
	
	try {
		$gateway_manager = new CF7MC\Core\GatewayManager();
		$enabled_gateways = $gateway_manager->get_enabled_gateways();
		
		foreach ( $enabled_gateways as $gateway_id => $gateway ) {
			$gateways[] = array(
				'id' => $gateway_id,
				'name' => $gateway->get_name(),
				'description' => $gateway->get_description(),
				'supports_inline' => method_exists( $gateway, 'supports_inline_checkout' ) ? $gateway->supports_inline_checkout() : false,
			);
		}
	} catch ( Exception $e ) {
		cf7conv_log( 'Failed to get payment gateways: ' . $e->getMessage(), 'error' );
	}
	
	return $gateways;
}

/**
 * Create order from conversation step data
 *
 * @param array $step_data
 * @return int|false Order ID or false on failure
 */
function cf7conv_create_order_from_step( $step_data ) {
	if ( ! cf7conv_is_ecommerce_available() ) {
		return false;
	}
	
	// Prepare order data
	$order_data = array(
		'email' => sanitize_email( $step_data['email'] ?? '' ),
		'total_amount' => floatval( $step_data['amount'] ?? 0 ),
		'gateway' => sanitize_text_field( $step_data['gateway'] ?? 'whatsapp' ),
		'items' => $step_data['items'] ?? array(),
		'metadata' => array(
			'conversation_id' => intval( $step_data['conversation_id'] ?? 0 ),
			'step_id' => intval( $step_data['step_id'] ?? 0 ),
			'session_id' => sanitize_text_field( $step_data['session_id'] ?? '' ),
			'customer_name' => sanitize_text_field( $step_data['customer_name'] ?? '' ),
			'source' => 'conversation_engine',
		),
	);
	
	// Validate required fields
	if ( empty( $order_data['email'] ) || $order_data['total_amount'] <= 0 ) {
		cf7conv_log( 'Invalid order data: missing email or amount', 'error' );
		return false;
	}
	
	try {
		$order_manager = new CF7MC\Core\OrderManager();
		$order_id = $order_manager->create_order( $order_data );
		
		if ( $order_id ) {
			cf7conv_log( "Order created from conversation: ID={$order_id}, Amount={$order_data['total_amount']}" );
		}
		
		return $order_id;
	} catch ( Exception $e ) {
		cf7conv_log( 'Failed to create order from conversation: ' . $e->getMessage(), 'error' );
		return false;
	}
}

/**
 * Handle payment success from conversation
 *
 * @param int $order_id
 * @param array $order_data
 */
function cf7conv_handle_payment_success( $order_id, $order_data ) {
	// Log payment success
	cf7conv_log( "Payment successful for conversation order: {$order_id}" );
	
	// Trigger conversation-specific actions
	do_action( 'cf7conv_payment_success', $order_id, $order_data );
	
	// If UCA is available, generate access token
	if ( cf7conv_is_uca_available() && function_exists( 'cf7uca_generate_access_token' ) ) {
		$metadata = json_decode( $order_data['metadata'] ?? '{}', true );
		$conversation_id = $metadata['conversation_id'] ?? 0;
		
		if ( $conversation_id ) {
			$access_token = cf7uca_generate_access_token( array(
				'email' => $order_data['email'],
				'conversation_id' => $conversation_id,
				'order_id' => $order_id,
				'expires_in' => 30 * DAY_IN_SECONDS, // 30 days
			) );
			
			if ( $access_token ) {
				cf7conv_log( "Access token generated for conversation order: {$order_id}" );
			}
		}
	}
}

// Hook into payment success events
add_action( 'ecommerce_payment_success', 'cf7conv_handle_payment_success', 10, 2 );