<?php

namespace CF7CONV\Integrations;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Contact Form 7 integration listener
 */
class CF7Listener {
	
	/**
	 * Listener instance
	 *
	 * @var CF7Listener
	 */
	private static $instance = null;
	
	/**
	 * Get listener instance
	 *
	 * @return CF7Listener
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		$this->init_hooks();
	}
	
	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		// Hook into CF7 form submission
		add_action( 'wpcf7_mail_sent', array( $this, 'handle_form_submission' ) );
		
		// Hook into CF7 form display
		add_filter( 'wpcf7_form_response_output', array( $this, 'modify_form_response' ), 10, 4 );
		
		// Add conversation redirect script
		add_action( 'wp_footer', array( $this, 'add_conversation_redirect_script' ) );
		
		// Save CF7 form conversation settings
		add_action( 'save_post', array( $this, 'save_cf7_conversation_settings' ) );
	}
	
	/**
	 * Handle CF7 form submission
	 *
	 * @param WPCF7_ContactForm $contact_form
	 */
	public function handle_form_submission( $contact_form ) {
		$form_id = $contact_form->id();
		$conversation_id = get_post_meta( $form_id, '_cf7conv_conversation_id', true );
		
		if ( empty( $conversation_id ) ) {
			return;
		}
		
		// Get submitted data
		$submission = \WPCF7_Submission::get_instance();
		if ( ! $submission ) {
			return;
		}
		
		$posted_data = $submission->get_posted_data();
		$email = $this->extract_email_from_data( $posted_data );
		
		if ( empty( $email ) ) {
			cf7conv_log( "No email found in CF7 form submission for form ID: $form_id", 'warning' );
			return;
		}
		
		// Create conversation session
		$session_manager = new \CF7CONV\Core\SessionManager();
		$session_id = $session_manager->create_session( array(
			'conversation_id' => $conversation_id,
			'email' => $email,
			'current_step' => $this->get_conversation_start_step( $conversation_id ),
			'answers' => wp_json_encode( $this->prepare_initial_answers( $posted_data ) ),
		) );
		
		if ( $session_id ) {
			// Store session ID for redirect
			$this->store_redirect_session( $session_id, $conversation_id );
			
			cf7conv_log( "Created conversation session $session_id for form $form_id" );
			
			// Emit analytics event
			do_action( 'cf7conv_form_to_conversation', $form_id, $conversation_id, $session_id );
		}
	}
	
	/**
	 * Modify CF7 form response to include conversation redirect
	 *
	 * @param string $output
	 * @param string $class
	 * @param string $content
	 * @param WPCF7_ContactForm $contact_form
	 * @return string
	 */
	public function modify_form_response( $output, $class, $content, $contact_form ) {
		// Handle null values
		$output = $output ?? '';
		$class = $class ?? '';
		$content = $content ?? '';
		
		// Only modify successful submissions
		if ( strpos( $class, 'wpcf7-mail-sent-ok' ) === false ) {
			return $output;
		}
		
		$form_id = $contact_form->id();
		$conversation_id = get_post_meta( $form_id, '_cf7conv_conversation_id', true );
		
		if ( empty( $conversation_id ) ) {
			return $output;
		}
		
		// Check if we have a redirect session
		$redirect_data = $this->get_redirect_session();
		if ( ! $redirect_data || $redirect_data['conversation_id'] != $conversation_id ) {
			return $output;
		}
		
		// Generate conversation URL
		$conversation_url = cf7conv_get_conversation_url( $conversation_id );
		if ( ! empty( $redirect_data['session_id'] ) ) {
			$session_manager = new \CF7CONV\Core\SessionManager();
			$resume_link = $session_manager->generate_resume_link( $redirect_data['session_id'] );
			if ( $resume_link ) {
				$conversation_url = $resume_link;
			}
		}
		
		// Modify the response to include redirect information
		$redirect_message = sprintf(
			__( 'Thank you! Please continue to complete your conversation: <a href="%s" class="cf7conv-continue-link">Continue Conversation</a>', CF7CONV_TEXT_DOMAIN ),
			esc_url( $conversation_url )
		);
		
		// Add redirect data attribute for JavaScript
		$output = str_replace(
			'<div class="' . esc_attr( $class ) . '">',
			'<div class="' . esc_attr( $class ) . '" data-cf7conv-redirect="' . esc_attr( $conversation_url ) . '">',
			$output
		);
		
		// Replace or append the redirect message
		if ( ! empty( $content ) ) {
			$output = str_replace( $content, $redirect_message, $output );
		} else {
			$output = str_replace(
				'</div>',
				$redirect_message . '</div>',
				$output
			);
		}
		
		// Clear the redirect session
		$this->clear_redirect_session();
		
		return $output;
	}
	
	/**
	 * Add conversation redirect script to footer
	 */
	public function add_conversation_redirect_script() {
		?>
		<script type="text/javascript">
		(function() {
			// Auto-redirect to conversation after form submission
			document.addEventListener('wpcf7mailsent', function(event) {
				var form = event.target;
				var responseOutput = form.querySelector('.wpcf7-response-output');
				
				if (responseOutput) {
					var redirectUrl = responseOutput.getAttribute('data-cf7conv-redirect');
					
					if (redirectUrl) {
						// Show message for 2 seconds, then redirect
						setTimeout(function() {
							window.location.href = redirectUrl;
						}, 2000);
					}
				}
			});
			
			// Handle continue link clicks
			document.addEventListener('click', function(event) {
				if (event.target.classList.contains('cf7conv-continue-link')) {
					event.preventDefault();
					window.location.href = event.target.href;
				}
			});
		})();
		</script>
		<style type="text/css">
		.cf7conv-continue-link {
			display: inline-block;
			background: #007cba;
			color: white !important;
			padding: 10px 20px;
			text-decoration: none;
			border-radius: 4px;
			margin-top: 10px;
			font-weight: 500;
			transition: background 0.2s ease;
		}
		.cf7conv-continue-link:hover {
			background: #005a87;
			color: white !important;
			text-decoration: none;
		}
		</style>
		<?php
	}
	
	/**
	 * Save CF7 form conversation settings
	 *
	 * @param int $post_id
	 */
	public function save_cf7_conversation_settings( $post_id ) {
		// Check if this is a CF7 form
		if ( get_post_type( $post_id ) !== 'wpcf7_contact_form' ) {
			return;
		}
		
		// Check nonce
		if ( ! isset( $_POST['cf7conv_cf7_nonce'] ) || ! wp_verify_nonce( $_POST['cf7conv_cf7_nonce'], 'cf7conv_cf7_settings' ) ) {
			return;
		}
		
		// Check permissions
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		
		// Save conversation ID
		$conversation_id = isset( $_POST['cf7conv_conversation_id'] ) ? intval( $_POST['cf7conv_conversation_id'] ) : 0;
		
		if ( $conversation_id > 0 ) {
			update_post_meta( $post_id, '_cf7conv_conversation_id', $conversation_id );
		} else {
			delete_post_meta( $post_id, '_cf7conv_conversation_id' );
		}
		
		cf7conv_log( "Updated CF7 form $post_id conversation settings: $conversation_id" );
	}
	
	/**
	 * Extract email from CF7 submitted data
	 *
	 * @param array $posted_data
	 * @return string
	 */
	private function extract_email_from_data( $posted_data ) {
		if ( ! is_array( $posted_data ) ) {
			return '';
		}
		
		// Common email field names
		$email_fields = array( 'your-email', 'email', 'customer-email', 'user-email', 'contact-email' );
		
		foreach ( $email_fields as $field ) {
			if ( ! empty( $posted_data[ $field ] ) && is_email( $posted_data[ $field ] ) ) {
				return sanitize_email( $posted_data[ $field ] );
			}
		}
		
		// Look for any field containing 'email' in the name
		foreach ( $posted_data as $key => $value ) {
			if ( is_string( $key ) && strpos( $key, 'email' ) !== false && is_email( $value ) ) {
				return sanitize_email( $value );
			}
		}
		
		return '';
	}
	
	/**
	 * Get conversation start step
	 *
	 * @param int $conversation_id
	 * @return string
	 */
	private function get_conversation_start_step( $conversation_id ) {
		$conversation_manager = new \CF7CONV\Core\ConversationManager();
		$conversation = $conversation_manager->get_conversation( $conversation_id );
		
		if ( ! $conversation ) {
			return 'start';
		}
		
		$config_json = $conversation['config'] ?? '{}';
		if ( empty( $config_json ) || ! is_string( $config_json ) ) {
			return 'start';
		}
		
		$config = json_decode( $config_json, true );
		if ( ! is_array( $config ) || empty( $config['steps'] ) || ! is_array( $config['steps'] ) ) {
			return 'start';
		}
		
		return $config['steps'][0]['id'] ?? 'start';
	}
	
	/**
	 * Prepare initial answers from CF7 data
	 *
	 * @param array $posted_data
	 * @return array
	 */
	private function prepare_initial_answers( $posted_data ) {
		$answers = array();
		
		if ( ! is_array( $posted_data ) ) {
			return $answers;
		}
		
		// Filter out CF7 internal fields
		$internal_fields = array( '_wpcf7', '_wpcf7_version', '_wpcf7_locale', '_wpcf7_unit_tag', '_wpcf7_container_post' );
		
		foreach ( $posted_data as $key => $value ) {
			if ( ! in_array( $key, $internal_fields ) && ! empty( $value ) ) {
				$answers[ $key ] = is_array( $value ) ? $value : sanitize_text_field( $value );
			}
		}
		
		return $answers;
	}
	
	/**
	 * Store redirect session data
	 *
	 * @param string $session_id
	 * @param int $conversation_id
	 */
	private function store_redirect_session( $session_id, $conversation_id ) {
		// Ensure we have a valid session
		if ( ! session_id() ) {
			if ( ! headers_sent() ) {
				session_start();
			}
		}
		
		$current_session_id = session_id();
		if ( empty( $current_session_id ) ) {
			// Fallback to a temporary identifier
			$current_session_id = 'temp_' . wp_generate_password( 12, false );
		}
		
		$data = array(
			'session_id' => sanitize_text_field( $session_id ),
			'conversation_id' => intval( $conversation_id ),
			'timestamp' => time(),
		);
		
		set_transient( 'cf7conv_redirect_' . $current_session_id, $data, 300 ); // 5 minutes
	}
	
	/**
	 * Get redirect session data
	 *
	 * @return array|false
	 */
	private function get_redirect_session() {
		$current_session_id = session_id();
		if ( empty( $current_session_id ) ) {
			return false;
		}
		
		return get_transient( 'cf7conv_redirect_' . $current_session_id );
	}
	
	/**
	 * Clear redirect session data
	 */
	private function clear_redirect_session() {
		$current_session_id = session_id();
		if ( empty( $current_session_id ) ) {
			return;
		}
		
		delete_transient( 'cf7conv_redirect_' . $current_session_id );
	}
}