<?php

namespace CF7CONV\Database;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Database schema management
 */
class SchemaManager {
	
	/**
	 * Create database tables
	 */
	public static function create_tables() {
		global $wpdb;
		
		$charset_collate = $wpdb->get_charset_collate();
		
		// Conversations table
		$conversations_table = $wpdb->prefix . CF7CONV_CONVERSATIONS_TABLE;
		$conversations_sql = "CREATE TABLE $conversations_table (
			id bigint(20) NOT NULL AUTO_INCREMENT,
			title varchar(255) NOT NULL,
			description text,
			cf7_form_id bigint(20),
			config longtext,
			status varchar(20) DEFAULT 'draft',
			created_at datetime DEFAULT CURRENT_TIMESTAMP,
			updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY (id),
			KEY cf7_form_id (cf7_form_id),
			KEY status (status)
		) $charset_collate;";
		
		// Sessions table
		$sessions_table = $wpdb->prefix . CF7CONV_SESSIONS_TABLE;
		$sessions_sql = "CREATE TABLE $sessions_table (
			id bigint(20) NOT NULL AUTO_INCREMENT,
			session_id varchar(64) NOT NULL,
			conversation_id bigint(20) NOT NULL,
			email varchar(255),
			current_step varchar(50),
			answers longtext,
			pricing_data longtext,
			payment_status varchar(20) DEFAULT 'pending',
			order_id bigint(20),
			resume_token varchar(64),
			status varchar(20) DEFAULT 'active',
			started_at datetime DEFAULT CURRENT_TIMESTAMP,
			updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			completed_at datetime,
			expires_at datetime,
			PRIMARY KEY (id),
			UNIQUE KEY session_id (session_id),
			KEY conversation_id (conversation_id),
			KEY email (email),
			KEY status (status),
			KEY expires_at (expires_at)
		) $charset_collate;";
		
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		dbDelta( $conversations_sql );
		dbDelta( $sessions_sql );
		
		cf7conv_log( 'Database tables created successfully' );
	}
	
	/**
	 * Drop database tables
	 */
	public static function drop_tables() {
		global $wpdb;
		
		$conversations_table = $wpdb->prefix . CF7CONV_CONVERSATIONS_TABLE;
		$sessions_table = $wpdb->prefix . CF7CONV_SESSIONS_TABLE;
		
		$wpdb->query( "DROP TABLE IF EXISTS $sessions_table" );
		$wpdb->query( "DROP TABLE IF EXISTS $conversations_table" );
		
		cf7conv_log( 'Database tables dropped' );
	}
	
	/**
	 * Clean up expired sessions
	 */
	public static function cleanup_expired_sessions() {
		global $wpdb;
		
		$sessions_table = $wpdb->prefix . CF7CONV_SESSIONS_TABLE;
		
		$expired_count = $wpdb->query( $wpdb->prepare(
			"UPDATE $sessions_table SET status = 'expired' WHERE expires_at < %s AND status = 'active'",
			current_time( 'mysql' )
		) );
		
		if ( $expired_count > 0 ) {
			cf7conv_log( "Marked $expired_count sessions as expired" );
		}
		
		return $expired_count;
	}
}