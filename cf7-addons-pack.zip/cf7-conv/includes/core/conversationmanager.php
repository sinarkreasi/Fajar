<?php

namespace CF7CONV\Core;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Conversation management class
 */
class ConversationManager {
	
	/**
	 * Create a new conversation
	 *
	 * @param array $data
	 * @return int|false
	 */
	public function create_conversation( $data ) {
		global $wpdb;
		
		$table = $wpdb->prefix . CF7CONV_CONVERSATIONS_TABLE;
		
		$defaults = array(
			'title' => '',
			'description' => '',
			'cf7_form_id' => 0,
			'config' => wp_json_encode( $this->get_default_config() ),
			'status' => 'published', // Changed from 'draft' to 'published'
		);
		
		$data = wp_parse_args( $data, $defaults );
		
		$result = $wpdb->insert(
			$table,
			array(
				'title' => sanitize_text_field( $data['title'] ),
				'description' => sanitize_textarea_field( $data['description'] ),
				'cf7_form_id' => intval( $data['cf7_form_id'] ),
				'config' => $data['config'],
				'status' => sanitize_text_field( $data['status'] ),
			),
			array( '%s', '%s', '%d', '%s', '%s' )
		);
		
		if ( $result === false ) {
			cf7conv_log( 'Failed to create conversation: ' . $wpdb->last_error, 'error' );
			return false;
		}
		
		$conversation_id = $wpdb->insert_id;
		cf7conv_log( "Conversation created with ID: $conversation_id" );
		
		do_action( 'cf7conv_conversation_created', $conversation_id, $data );
		
		return $conversation_id;
	}
	
	/**
	 * Get conversation by ID
	 *
	 * @param int $conversation_id
	 * @return array|null
	 */
	public function get_conversation( $conversation_id ) {
		global $wpdb;
		
		$table = $wpdb->prefix . CF7CONV_CONVERSATIONS_TABLE;
		
		$conversation = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM $table WHERE id = %d",
			$conversation_id
		), ARRAY_A );
		
		return $conversation ?: null;
	}
	
	/**
	 * Update conversation
	 *
	 * @param int $conversation_id
	 * @param array $data
	 * @return bool
	 */
	public function update_conversation( $conversation_id, $data ) {
		global $wpdb;
		
		$table = $wpdb->prefix . CF7CONV_CONVERSATIONS_TABLE;
		
		$allowed_fields = array( 'title', 'description', 'cf7_form_id', 'config', 'status' );
		$update_data = array();
		$format = array();
		
		foreach ( $data as $key => $value ) {
			if ( in_array( $key, $allowed_fields ) ) {
				switch ( $key ) {
					case 'title':
						$update_data[ $key ] = sanitize_text_field( $value );
						$format[] = '%s';
						break;
					case 'description':
						$update_data[ $key ] = sanitize_textarea_field( $value );
						$format[] = '%s';
						break;
					case 'cf7_form_id':
						$update_data[ $key ] = intval( $value );
						$format[] = '%d';
						break;
					case 'config':
					case 'status':
						$update_data[ $key ] = sanitize_text_field( $value );
						$format[] = '%s';
						break;
				}
			}
		}
		
		if ( empty( $update_data ) ) {
			return false;
		}
		
		$result = $wpdb->update(
			$table,
			$update_data,
			array( 'id' => $conversation_id ),
			$format,
			array( '%d' )
		);
		
		if ( $result === false ) {
			cf7conv_log( "Failed to update conversation $conversation_id: " . $wpdb->last_error, 'error' );
			return false;
		}
		
		do_action( 'cf7conv_conversation_updated', $conversation_id, $data );
		
		return true;
	}
	
	/**
	 * Delete conversation
	 *
	 * @param int $conversation_id
	 * @return bool
	 */
	public function delete_conversation( $conversation_id ) {
		global $wpdb;
		
		$conversations_table = $wpdb->prefix . CF7CONV_CONVERSATIONS_TABLE;
		$sessions_table = $wpdb->prefix . CF7CONV_SESSIONS_TABLE;
		
		// Delete related sessions first
		$wpdb->delete( $sessions_table, array( 'conversation_id' => $conversation_id ), array( '%d' ) );
		
		// Delete conversation
		$result = $wpdb->delete( $conversations_table, array( 'id' => $conversation_id ), array( '%d' ) );
		
		if ( $result === false ) {
			cf7conv_log( "Failed to delete conversation $conversation_id: " . $wpdb->last_error, 'error' );
			return false;
		}
		
		do_action( 'cf7conv_conversation_deleted', $conversation_id );
		
		return true;
	}
	
	/**
	 * Get all conversations
	 *
	 * @param array $args
	 * @return array
	 */
	public function get_conversations( $args = array() ) {
		global $wpdb;
		
		$table = $wpdb->prefix . CF7CONV_CONVERSATIONS_TABLE;
		
		$defaults = array(
			'status' => '',
			'limit' => 20,
			'offset' => 0,
			'orderby' => 'created_at',
			'order' => 'DESC',
		);
		
		$args = wp_parse_args( $args, $defaults );
		
		$where = '1=1';
		$where_values = array();
		
		if ( ! empty( $args['status'] ) ) {
			$where .= ' AND status = %s';
			$where_values[] = $args['status'];
		}
		
		$orderby = sanitize_sql_orderby( $args['orderby'] . ' ' . $args['order'] );
		$limit = intval( $args['limit'] );
		$offset = intval( $args['offset'] );
		
		$query = "SELECT * FROM $table WHERE $where ORDER BY $orderby LIMIT $limit OFFSET $offset";
		
		if ( ! empty( $where_values ) ) {
			$query = $wpdb->prepare( $query, $where_values );
		}
		
		return $wpdb->get_results( $query, ARRAY_A );
	}
	
	/**
	 * Get conversation count
	 *
	 * @param string $status
	 * @return int
	 */
	public function get_conversation_count( $status = '' ) {
		global $wpdb;
		
		$table = $wpdb->prefix . CF7CONV_CONVERSATIONS_TABLE;
		
		if ( empty( $status ) ) {
			return $wpdb->get_var( "SELECT COUNT(*) FROM $table" );
		}
		
		return $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM $table WHERE status = %s",
			$status
		) );
	}
	
	/**
	 * Get default conversation configuration
	 *
	 * @return array
	 */
	public function get_default_config() {
		return array(
			'version' => '1.0',
			'settings' => array(
				'enable_progress' => true,
				'enable_back_button' => true,
				'auto_save' => true,
			),
			'steps' => array(
				array(
					'id' => 'step_1_welcome',
					'type' => 'info',
					'title' => __( 'Welcome', CF7CONV_TEXT_DOMAIN ),
					'content' => __( 'Welcome to our conversation. Let\'s get started!', CF7CONV_TEXT_DOMAIN ),
					'next_step' => 'step_2_name',
				),
				array(
					'id' => 'step_2_name',
					'type' => 'question',
					'title' => __( 'What\'s your name?', CF7CONV_TEXT_DOMAIN ),
					'content' => __( 'Please tell us your name so we can personalize your experience.', CF7CONV_TEXT_DOMAIN ),
					'field_name' => 'name',
					'input_type' => 'text',
					'required' => true,
					'placeholder' => __( 'Enter your name', CF7CONV_TEXT_DOMAIN ),
					'next_step' => 'step_3_email',
				),
				array(
					'id' => 'step_3_email',
					'type' => 'question',
					'title' => __( 'What\'s your email?', CF7CONV_TEXT_DOMAIN ),
					'content' => __( 'We\'ll use this to send you updates and information.', CF7CONV_TEXT_DOMAIN ),
					'field_name' => 'email',
					'input_type' => 'email',
					'required' => true,
					'placeholder' => __( 'Enter your email address', CF7CONV_TEXT_DOMAIN ),
					'next_step' => 'step_4_interests',
				),
				array(
					'id' => 'step_4_interests',
					'type' => 'choice',
					'title' => __( 'What are you interested in?', CF7CONV_TEXT_DOMAIN ),
					'content' => __( 'Select all that apply to help us understand your needs.', CF7CONV_TEXT_DOMAIN ),
					'field_name' => 'interests',
					'multiple' => true,
					'choices' => array(
						array(
							'value' => 'products',
							'label' => __( 'Products & Services', CF7CONV_TEXT_DOMAIN ),
							'description' => __( 'Learn about what we offer', CF7CONV_TEXT_DOMAIN ),
						),
						array(
							'value' => 'support',
							'label' => __( 'Customer Support', CF7CONV_TEXT_DOMAIN ),
							'description' => __( 'Get help with existing services', CF7CONV_TEXT_DOMAIN ),
						),
						array(
							'value' => 'partnership',
							'label' => __( 'Partnership Opportunities', CF7CONV_TEXT_DOMAIN ),
							'description' => __( 'Explore working together', CF7CONV_TEXT_DOMAIN ),
						),
					),
					'next_step' => 'step_5_result',
				),
				array(
					'id' => 'step_5_result',
					'type' => 'result',
					'title' => __( 'Thank You!', CF7CONV_TEXT_DOMAIN ),
					'content' => __( 'Thank you for completing our conversation. We\'ll be in touch soon!', CF7CONV_TEXT_DOMAIN ),
					'show_summary' => true,
					'actions' => array(
						array(
							'label' => __( 'Visit Our Website', CF7CONV_TEXT_DOMAIN ),
							'url' => home_url(),
						),
					),
				),
			),
		);
	}
	
	/**
	 * Validate conversation configuration
	 *
	 * @param array $config
	 * @return array|true
	 */
	public function validate_config( $config ) {
		$errors = array();
		
		if ( empty( $config['steps'] ) || ! is_array( $config['steps'] ) ) {
			$errors[] = __( 'Configuration must contain at least one step.', CF7CONV_TEXT_DOMAIN );
			return $errors;
		}
		
		$step_ids = array();
		foreach ( $config['steps'] as $index => $step ) {
			if ( empty( $step['id'] ) ) {
				$errors[] = sprintf( __( 'Step %d is missing an ID.', CF7CONV_TEXT_DOMAIN ), $index + 1 );
				continue;
			}
			
			if ( in_array( $step['id'], $step_ids ) ) {
				$errors[] = sprintf( __( 'Duplicate step ID: %s', CF7CONV_TEXT_DOMAIN ), $step['id'] );
			}
			
			$step_ids[] = $step['id'];
			
			if ( empty( $step['type'] ) ) {
				$errors[] = sprintf( __( 'Step %s is missing a type.', CF7CONV_TEXT_DOMAIN ), $step['id'] );
			}
			
			$step_types = array_keys( cf7conv_get_step_types() );
			if ( ! empty( $step['type'] ) && ! in_array( $step['type'], $step_types ) ) {
				$errors[] = sprintf( __( 'Invalid step type: %s', CF7CONV_TEXT_DOMAIN ), $step['type'] );
			}
		}
		
		return empty( $errors ) ? true : $errors;
	}
}