<?php

namespace CF7CONV\Core;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Main plugin class
 */
class Plugin {
	
	/**
	 * Plugin instance
	 *
	 * @var Plugin
	 */
	private static $instance = null;
	
	/**
	 * Get plugin instance
	 *
	 * @return Plugin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		$this->init_hooks();
	}
	
	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
		add_action( 'parse_request', array( $this, 'handle_conversation_request' ), 1 );
		add_action( 'wp_ajax_cf7conv_save_step', array( $this, 'ajax_save_step' ) );
		add_action( 'wp_ajax_nopriv_cf7conv_save_step', array( $this, 'ajax_save_step' ) );
		add_action( 'wp_ajax_cf7conv_calculate_pricing', array( $this, 'ajax_calculate_pricing' ) );
		add_action( 'wp_ajax_nopriv_cf7conv_calculate_pricing', array( $this, 'ajax_calculate_pricing' ) );
		add_action( 'wp_ajax_cf7conv_process_payment', array( $this, 'ajax_process_payment' ) );
		add_action( 'wp_ajax_nopriv_cf7conv_process_payment', array( $this, 'ajax_process_payment' ) );
		add_action( 'wp_ajax_cf7conv_complete_session', array( $this, 'ajax_complete_session' ) );
		add_action( 'wp_ajax_nopriv_cf7conv_complete_session', array( $this, 'ajax_complete_session' ) );
		
		// Ecommerce integration AJAX handlers
		add_action( 'wp_ajax_cf7conv_create_order', array( $this, 'ajax_create_order' ) );
		add_action( 'wp_ajax_nopriv_cf7conv_create_order', array( $this, 'ajax_create_order' ) );
		
		// Schedule cleanup
		if ( ! wp_next_scheduled( 'cf7conv_cleanup_sessions' ) ) {
			wp_schedule_event( time(), 'daily', 'cf7conv_cleanup_sessions' );
		}
		
		add_action( 'cf7conv_cleanup_sessions', array( $this, 'cleanup_expired_sessions' ) );
	}
	
	/**
	 * Enqueue frontend scripts
	 */
	public function enqueue_scripts() {
		// Check if this is a conversation page by URL pattern
		$request_uri = $_SERVER['REQUEST_URI'] ?? '';
		if ( strpos( $request_uri, '/cf7conv/' ) === false ) {
			return;
		}
		
		wp_enqueue_script( 
			'cf7conv-runtime', 
			CF7CONV_PLUGIN_URL . '/assets/js/runtime.js', 
			array( 'jquery' ), 
			CF7CONV_VERSION, 
			true 
		);
		
		wp_localize_script( 'cf7conv-runtime', 'cf7conv_runtime', array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce' => wp_create_nonce( 'cf7conv_runtime' ),
			'settings' => array(
				'animation_duration' => cf7conv_get_option( 'animation_duration', 300 ),
				'auto_save_interval' => cf7conv_get_option( 'auto_save_interval', 30 ) * 1000,
				'enable_keyboard_nav' => cf7conv_get_option( 'enable_keyboard_nav', true ),
			),
			'ecommerce_available' => cf7conv_is_ecommerce_available(),
			'payment_gateways' => cf7conv_get_available_gateways(),
			'currency' => cf7conv_is_ecommerce_available() && function_exists( 'cf7mc_get_option' ) ? cf7mc_get_option( 'currency', 'USD' ) : 'USD',
			'format_price' => null, // Will be handled by JavaScript
		));
		
		wp_enqueue_style( 
			'cf7conv-runtime', 
			CF7CONV_PLUGIN_URL . '/assets/css/runtime.css', 
			array(), 
			CF7CONV_VERSION 
		);
		
		// Add custom CSS variables
		$ui_settings = OptionsManager::get_ui_settings();
		$custom_css = $this->generate_custom_css( $ui_settings );
		wp_add_inline_style( 'cf7conv-runtime', $custom_css );
	}
	
	/**
	 * Generate custom CSS from UI settings
	 *
	 * @param array $ui_settings
	 * @return string
	 */
	private function generate_custom_css( $ui_settings ) {
		$css = ':root {';
		
		if ( ! empty( $ui_settings['primary_color'] ) ) {
			$css .= '--cf7conv-primary-color: ' . sanitize_hex_color( $ui_settings['primary_color'] ) . ';';
		}
		
		if ( ! empty( $ui_settings['font_family'] ) ) {
			$css .= '--cf7conv-font-family: ' . sanitize_text_field( $ui_settings['font_family'] ) . ';';
		}
		
		if ( ! empty( $ui_settings['border_radius'] ) ) {
			$css .= '--cf7conv-border-radius: ' . sanitize_text_field( $ui_settings['border_radius'] ) . ';';
		}
		
		$css .= '}';
		
		return $css;
	}
	
	/**
	 * Handle conversation page requests
	 */
	public function handle_conversation_request( $wp ) {
		// Check if this is a conversation request
		if ( empty( $wp->query_vars['cf7conv_conversation'] ) ) {
			return;
		}
		
		// Use safe query var retrieval with proper defaults
		$conversation_id = $wp->query_vars['conversation_id'] ?? '';
		$resume_token = $wp->query_vars['resume_token'] ?? '';
		
		// Ensure we have proper string values, not null
		$conversation_id = is_numeric( $conversation_id ) ? intval( $conversation_id ) : 0;
		$resume_token = is_string( $resume_token ) && ! empty( $resume_token ) ? sanitize_text_field( $resume_token ) : '';
		
		// Debug logging
		cf7conv_log( "Conversation request: ID=$conversation_id, Token=$resume_token" );
		
		if ( $conversation_id <= 0 ) {
			cf7conv_log( 'Invalid conversation ID in request', 'error' );
			wp_die( __( 'Invalid conversation URL.', CF7CONV_TEXT_DOMAIN ) );
		}
		
		// Load conversation
		$conversation_manager = new ConversationManager();
		$conversation = $conversation_manager->get_conversation( $conversation_id );
		
		if ( ! $conversation ) {
			cf7conv_log( "Conversation not found: ID=$conversation_id", 'error' );
			wp_die( __( 'Conversation not found.', CF7CONV_TEXT_DOMAIN ) );
		}
		
		// Check if conversation is published (allow draft for admins)
		if ( $conversation['status'] !== 'published' && ! current_user_can( 'manage_options' ) ) {
			cf7conv_log( "Conversation not published: ID=$conversation_id, Status={$conversation['status']}", 'warning' );
			wp_die( __( 'This conversation is not available.', CF7CONV_TEXT_DOMAIN ) );
		}
		
		// Handle resume token or create new session
		$session = null;
		$session_manager = new SessionManager();
		
		if ( ! empty( $resume_token ) ) {
			$session = $session_manager->get_session_by_resume_token( $resume_token );
			
			if ( ! $session || $session['conversation_id'] != $conversation_id ) {
				cf7conv_log( "Invalid resume token: $resume_token for conversation $conversation_id", 'warning' );
				wp_die( __( 'Invalid resume link.', CF7CONV_TEXT_DOMAIN ) );
			}
			
			cf7conv_log( "Resume session found: {$session['session_id']}" );
		} else {
			// Create new session for first-time visitors
			$config = json_decode( $conversation['config'] ?? '{}', true );
			$steps = is_array( $config ) ? ( $config['steps'] ?? [] ) : [];
			$first_step = ! empty( $steps ) ? $steps[0]['id'] ?? 'start' : 'start';
			
			$session_data = array(
				'conversation_id' => $conversation_id,
				'current_step' => $first_step,
				'status' => 'active',
			);
			
			$session_id = $session_manager->create_session( $session_data );
			
			if ( $session_id ) {
				$session = $session_manager->get_session( $session_id );
				cf7conv_log( "New session created: $session_id for conversation $conversation_id" );
			} else {
				cf7conv_log( "Failed to create session for conversation $conversation_id", 'error' );
				// Continue without session - conversation will still work but won't be tracked
			}
		}
		
		cf7conv_log( "Rendering conversation: ID=$conversation_id, Title={$conversation['title']}" );
		
		// Render conversation early to prevent theme interference
		$this->render_conversation( $conversation, $session );
		exit;
	}
	
	/**
	 * Render conversation page
	 *
	 * @param array $conversation
	 * @param array|null $session
	 */
	private function render_conversation( $conversation, $session = null ) {
		$config = json_decode( $conversation['config'] ?? '{}', true );
		if ( ! is_array( $config ) ) {
			$config = array( 'steps' => array() );
		}
		
		$current_step = $session ? ( $session['current_step'] ?? '' ) : ( $config['steps'][0]['id'] ?? 'start' );
		$answers = $session ? json_decode( $session['answers'] ?? '{}', true ) : array();
		if ( ! is_array( $answers ) ) {
			$answers = array();
		}
		
		// Check if headers have already been sent
		if ( headers_sent() ) {
			cf7conv_log( 'Headers already sent, using JavaScript injection method', 'warning' );
			
			// Use JavaScript to replace page content
			$conversation_html = $this->get_conversation_html_body( $conversation, $session, $config, $current_step, $answers );
			?>
			<script type="text/javascript">
				document.addEventListener('DOMContentLoaded', function() {
					// Replace entire page content
					document.documentElement.innerHTML = <?php echo wp_json_encode( $conversation_html ); ?>;
					
					// Update page title
					document.title = <?php echo wp_json_encode( esc_html( $conversation['title'] ?? 'Conversation' ) . ' - ' . get_bloginfo( 'name' ) ); ?>;
					
					// Re-initialize scripts
					if (typeof jQuery !== 'undefined') {
						jQuery(document).ready(function() {
							// Trigger conversation initialization
							if (window.CF7CONV && window.CF7CONV.init) {
								window.CF7CONV.init();
							}
						});
					}
				});
			</script>
			<?php
			return;
		}
		
		// Headers not sent yet, we can render normally
		// Start output buffering to capture any early output
		ob_start();
		
		// Clean any existing output buffers to prevent header issues
		while ( ob_get_level() > 1 ) {
			ob_end_clean();
		}
		
		// Send proper headers
		status_header( 200 );
		header( 'Content-Type: text/html; charset=' . get_option( 'blog_charset' ) );
		
		// Output the conversation HTML
		echo $this->get_conversation_html( $conversation, $session, $config, $current_step, $answers );
		
		// End output buffering and send content
		ob_end_flush();
		exit;
	}
	
	/**
	 * Get conversation HTML content
	 *
	 * @param array $conversation
	 * @param array|null $session
	 * @param array $config
	 * @param string $current_step
	 * @param array $answers
	 * @return string
	 */
	private function get_conversation_html( $conversation, $session, $config, $current_step, $answers ) {
		ob_start();
		?>
		<!DOCTYPE html>
		<html <?php language_attributes(); ?>>
		<head>
			<meta charset="<?php bloginfo( 'charset' ); ?>">
			<meta name="viewport" content="width=device-width, initial-scale=1">
			<title><?php echo esc_html( $conversation['title'] ?? 'Conversation' ); ?> - <?php bloginfo( 'name' ); ?></title>
			
			<!-- jQuery -->
			<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
			
			<!-- CF7 Conversation Styles -->
			<link rel="stylesheet" href="<?php echo CF7CONV_PLUGIN_URL; ?>/assets/css/runtime.css?v=<?php echo CF7CONV_VERSION; ?>">
			
			<!-- Custom CSS Variables -->
			<style>
				<?php echo $this->generate_custom_css( OptionsManager::get_ui_settings() ); ?>
			</style>
			
			<?php wp_head(); ?>
		</head>
		<body class="cf7conv-conversation-page">
			<?php echo $this->get_conversation_html_body( $conversation, $session, $config, $current_step, $answers ); ?>
			<?php wp_footer(); ?>
		</body>
		</html>
		<?php
		return ob_get_clean();
	}
	
	/**
	 * Get conversation body HTML content
	 *
	 * @param array $conversation
	 * @param array|null $session
	 * @param array $config
	 * @param string $current_step
	 * @param array $answers
	 * @return string
	 */
	private function get_conversation_html_body( $conversation, $session, $config, $current_step, $answers ) {
		ob_start();
		?>
		<div id="cf7conv-app" 
			 data-conversation-id="<?php echo esc_attr( $conversation['id'] ?? '' ); ?>"
			 data-session-id="<?php echo esc_attr( $session['session_id'] ?? '' ); ?>"
			 data-current-step="<?php echo esc_attr( $current_step ); ?>">
			
			<?php if ( cf7conv_get_option( 'enable_progress_bar', true ) ): ?>
			<div class="cf7conv-progress-bar">
				<div class="cf7conv-progress-fill" style="width: 0%"></div>
			</div>
			<?php endif; ?>
			
			<div class="cf7conv-container">
				<div class="cf7conv-header">
					<h1><?php echo esc_html( $conversation['title'] ?? 'Conversation' ); ?></h1>
					<?php if ( ! empty( $conversation['description'] ) ): ?>
					<p class="cf7conv-description"><?php echo esc_html( $conversation['description'] ); ?></p>
					<?php endif; ?>
				</div>
				
				<div class="cf7conv-steps-container">
					<!-- Steps will be rendered by JavaScript -->
					<div class="cf7conv-step cf7conv-step-loading">
						<h2>Loading conversation...</h2>
						<p>Please wait while we prepare your conversation.</p>
					</div>
				</div>
				
				<div class="cf7conv-navigation">
					<?php if ( cf7conv_get_option( 'enable_back_button', true ) ): ?>
					<button type="button" class="cf7conv-btn cf7conv-btn-back" style="display: none;">
						<?php _e( 'Back', CF7CONV_TEXT_DOMAIN ); ?>
					</button>
					<?php endif; ?>
					
					<button type="button" class="cf7conv-btn cf7conv-btn-next">
						<?php _e( 'Next', CF7CONV_TEXT_DOMAIN ); ?>
					</button>
				</div>
			</div>
			
			<div class="cf7conv-loading" style="display: none;">
				<div class="cf7conv-spinner"></div>
				<p><?php _e( 'Processing...', CF7CONV_TEXT_DOMAIN ); ?></p>
			</div>
		</div>
		
		<script type="application/json" id="cf7conv-config">
			<?php echo wp_json_encode( $config ); ?>
		</script>
		
		<script type="application/json" id="cf7conv-answers">
			<?php echo wp_json_encode( $answers ); ?>
		</script>
		
		<!-- CF7 Conversation Runtime -->
		<script>
			var cf7conv_runtime = {
				ajax_url: '<?php echo admin_url( 'admin-ajax.php' ); ?>',
				nonce: '<?php echo wp_create_nonce( 'cf7conv_runtime' ); ?>',
				ecommerce_available: <?php echo cf7conv_is_ecommerce_available() ? 'true' : 'false'; ?>,
				payment_gateways: <?php echo wp_json_encode( cf7conv_get_available_gateways() ); ?>,
				settings: {
					animation_duration: <?php echo cf7conv_get_option( 'animation_duration', 300 ); ?>,
					auto_save_interval: <?php echo cf7conv_get_option( 'auto_save_interval', 30 ) * 1000; ?>,
					enable_keyboard_nav: <?php echo cf7conv_get_option( 'enable_keyboard_nav', true ) ? 'true' : 'false'; ?>
				}
			};
		</script>
		<script src="<?php echo CF7CONV_PLUGIN_URL; ?>/assets/js/runtime.js?v=<?php echo CF7CONV_VERSION; ?>"></script>
		<?php
		return ob_get_clean();
	}
	
	/**
	 * AJAX handler for saving step data
	 */
	public function ajax_save_step() {
		check_ajax_referer( 'cf7conv_runtime', 'nonce' );
		
		$conversation_id = intval( $_POST['conversation_id'] ?? 0 );
		$session_id = sanitize_text_field( $_POST['session_id'] ?? '' );
		$step_id = sanitize_text_field( $_POST['step_id'] ?? '' );
		$step_data = cf7conv_sanitize_step_data( $_POST['step_data'] ?? array() );
		
		if ( empty( $conversation_id ) || empty( $step_id ) ) {
			wp_send_json_error( __( 'Invalid request.', CF7CONV_TEXT_DOMAIN ) );
		}
		
		$session_manager = new SessionManager();
		
		// Create or update session
		if ( empty( $session_id ) ) {
			$session_id = cf7conv_generate_session_id();
			$session_data = array(
				'session_id' => $session_id,
				'conversation_id' => $conversation_id,
				'current_step' => $step_id,
				'answers' => wp_json_encode( $step_data ),
				'status' => 'active',
				'expires_at' => date( 'Y-m-d H:i:s', time() + ( cf7conv_get_option( 'session_expiry_hours', 24 ) * HOUR_IN_SECONDS ) ),
			);
			
			$session_manager->create_session( $session_data );
		} else {
			$session = $session_manager->get_session( $session_id );
			if ( $session ) {
				$existing_answers = json_decode( $session['answers'], true ) ?: array();
				$updated_answers = array_merge( $existing_answers, $step_data );
				
				$session_manager->update_session( $session_id, array(
					'current_step' => $step_id,
					'answers' => wp_json_encode( $updated_answers ),
				) );
			}
		}
		
		wp_send_json_success( array(
			'session_id' => $session_id,
			'step_id' => $step_id,
		) );
	}
	
	/**
	 * AJAX handler for calculating pricing
	 */
	public function ajax_calculate_pricing() {
		check_ajax_referer( 'cf7conv_runtime', 'nonce' );
		
		$pricing_rules = $_POST['pricing_rules'] ?? array();
		$answers = cf7conv_sanitize_step_data( $_POST['answers'] ?? array() );
		
		$total = cf7conv_calculate_pricing( $pricing_rules, $answers );
		
		wp_send_json_success( array(
			'total' => $total,
			'formatted' => cf7conv_format_price( $total ),
		) );
	}
	
	/**
	 * AJAX handler for processing payment
	 */
	public function ajax_process_payment() {
		check_ajax_referer( 'cf7conv_runtime', 'nonce' );
		
		$session_id = sanitize_text_field( $_POST['session_id'] ?? '' );
		$gateway = sanitize_text_field( $_POST['gateway'] ?? '' );
		$amount = floatval( $_POST['amount'] ?? 0 );
		
		if ( empty( $session_id ) || $amount <= 0 ) {
			wp_send_json_error( __( 'Invalid payment request.', CF7CONV_TEXT_DOMAIN ) );
		}
		
		// Get session data
		$session_manager = new SessionManager();
		$session = $session_manager->get_session( $session_id );
		
		if ( ! $session ) {
			wp_send_json_error( __( 'Session not found.', CF7CONV_TEXT_DOMAIN ) );
		}
		
		// Create order through CF7 Mini Ecommerce
		if ( cf7conv_is_ecommerce_available() ) {
			$order_data = array(
				'customer_email' => $session['email'] ?? '',
				'amount' => $amount,
				'currency' => 'USD', // Default currency
				'description' => 'Conversation Payment',
				'gateway' => $gateway,
				'metadata' => array(
					'conversation_id' => $session['conversation_id'],
					'session_id' => $session_id,
					'answers' => $session['answers'],
				),
			);
			
			$order_id = cf7conv_create_order( $order_data );
			
			if ( $order_id ) {
				// Update session with order ID
				$session_manager->update_session( $session_id, array(
					'order_id' => $order_id,
					'payment_status' => 'pending',
				) );
				
				wp_send_json_success( array(
					'order_id' => $order_id,
					'redirect_url' => cf7conv_get_payment_url( $order_id, $gateway ),
				) );
			} else {
				wp_send_json_error( __( 'Failed to create order.', CF7CONV_TEXT_DOMAIN ) );
			}
		} else {
			wp_send_json_error( __( 'Payment processing not available.', CF7CONV_TEXT_DOMAIN ) );
		}
	}
	
	/**
	 * AJAX handler for completing session
	 */
	public function ajax_complete_session() {
		check_ajax_referer( 'cf7conv_runtime', 'nonce' );
		
		$session_id = sanitize_text_field( $_POST['session_id'] ?? '' );
		
		if ( empty( $session_id ) ) {
			wp_send_json_error( __( 'Invalid session ID.', CF7CONV_TEXT_DOMAIN ) );
		}
		
		$session_manager = new SessionManager();
		$result = $session_manager->complete_session( $session_id );
		
		if ( $result ) {
			wp_send_json_success( __( 'Session completed successfully.', CF7CONV_TEXT_DOMAIN ) );
		} else {
			wp_send_json_error( __( 'Failed to complete session.', CF7CONV_TEXT_DOMAIN ) );
		}
	}
	
	/**
	 * AJAX handler for creating order from conversation
	 */
	public function ajax_create_order() {
		check_ajax_referer( 'cf7conv_runtime', 'nonce' );
		
		$step_data = $_POST['step_data'] ?? array();
		
		if ( empty( $step_data ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid step data.', CF7CONV_TEXT_DOMAIN ) ) );
		}
		
		// Sanitize step data
		$step_data = cf7conv_sanitize_step_data( $step_data );
		
		// Create order through ecommerce integration
		$order_id = cf7conv_create_order_from_step( $step_data );
		
		if ( $order_id ) {
			wp_send_json_success( array( 
				'order_id' => $order_id,
				'message' => __( 'Order created successfully.', CF7CONV_TEXT_DOMAIN )
			) );
		} else {
			wp_send_json_error( array( 'message' => __( 'Failed to create order.', CF7CONV_TEXT_DOMAIN ) ) );
		}
	}
	
	/**
	 * Cleanup expired sessions
	 */
	public function cleanup_expired_sessions() {
		\CF7CONV\Database\SchemaManager::cleanup_expired_sessions();
	}
}