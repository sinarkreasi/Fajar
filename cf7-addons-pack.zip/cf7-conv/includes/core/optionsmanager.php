<?php

namespace CF7CONV\Core;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Options management class
 */
class OptionsManager {
	
	/**
	 * Set default options on plugin activation
	 */
	public static function set_defaults() {
		$defaults = array(
			'session_expiry_hours' => 24,
			'enable_resume_links' => true,
			'enable_progress_bar' => true,
			'enable_back_button' => true,
			'enable_keyboard_nav' => true,
			'animation_duration' => 300,
			'auto_save_interval' => 30,
			'cleanup_interval' => 'daily',
			'integrations' => array(
				'ecommerce_enabled' => true,
				'uca_enabled' => true,
				'analytics_enabled' => false,
			),
			'ui_settings' => array(
				'theme' => 'default',
				'primary_color' => '#007cba',
				'font_family' => 'inherit',
				'border_radius' => '4px',
			),
		);
		
		$existing_options = get_option( 'cf7conv_options', array() );
		$options = wp_parse_args( $existing_options, $defaults );
		
		update_option( 'cf7conv_options', $options );
	}
	
	/**
	 * Get all options
	 *
	 * @return array
	 */
	public static function get_all_options() {
		return get_option( 'cf7conv_options', array() );
	}
	
	/**
	 * Get UI settings
	 *
	 * @return array
	 */
	public static function get_ui_settings() {
		$options = self::get_all_options();
		return isset( $options['ui_settings'] ) ? $options['ui_settings'] : array();
	}
	
	/**
	 * Get integration settings
	 *
	 * @return array
	 */
	public static function get_integration_settings() {
		$options = self::get_all_options();
		return isset( $options['integrations'] ) ? $options['integrations'] : array();
	}
	
	/**
	 * Update UI settings
	 *
	 * @param array $ui_settings
	 */
	public static function update_ui_settings( $ui_settings ) {
		$options = self::get_all_options();
		$options['ui_settings'] = $ui_settings;
		update_option( 'cf7conv_options', $options );
	}
	
	/**
	 * Update integration settings
	 *
	 * @param array $integration_settings
	 */
	public static function update_integration_settings( $integration_settings ) {
		$options = self::get_all_options();
		$options['integrations'] = $integration_settings;
		update_option( 'cf7conv_options', $options );
	}
}