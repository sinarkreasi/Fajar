<?php

namespace CF7CONV\Core;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Session management class
 */
class SessionManager {
	
	/**
	 * Create a new session
	 *
	 * @param array $data
	 * @return string|false
	 */
	public function create_session( $data ) {
		global $wpdb;
		
		$table = $wpdb->prefix . CF7CONV_SESSIONS_TABLE;
		
		$defaults = array(
			'session_id' => cf7conv_generate_session_id(),
			'conversation_id' => 0,
			'email' => '',
			'current_step' => '',
			'answers' => wp_json_encode( array() ),
			'pricing_data' => wp_json_encode( array() ),
			'payment_status' => 'pending',
			'order_id' => 0,
			'resume_token' => '',
			'status' => 'active',
			'expires_at' => date( 'Y-m-d H:i:s', time() + ( cf7conv_get_option( 'session_expiry_hours', 24 ) * HOUR_IN_SECONDS ) ),
		);
		
		$data = wp_parse_args( $data, $defaults );
		
		// Generate resume token if enabled
		if ( cf7conv_get_option( 'enable_resume_links', true ) && empty( $data['resume_token'] ) ) {
			$data['resume_token'] = cf7conv_generate_resume_token( $data['session_id'] );
		}
		
		$result = $wpdb->insert(
			$table,
			array(
				'session_id' => $data['session_id'],
				'conversation_id' => intval( $data['conversation_id'] ),
				'email' => sanitize_email( $data['email'] ),
				'current_step' => sanitize_text_field( $data['current_step'] ),
				'answers' => $data['answers'],
				'pricing_data' => $data['pricing_data'],
				'payment_status' => sanitize_text_field( $data['payment_status'] ),
				'order_id' => intval( $data['order_id'] ),
				'resume_token' => $data['resume_token'],
				'status' => sanitize_text_field( $data['status'] ),
				'expires_at' => $data['expires_at'],
			),
			array( '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s' )
		);
		
		if ( $result === false ) {
			cf7conv_log( 'Failed to create session: ' . $wpdb->last_error, 'error' );
			return false;
		}
		
		cf7conv_log( "Session created: {$data['session_id']}" );
		
		do_action( 'cf7conv_session_created', $data['session_id'], $data );
		
		return $data['session_id'];
	}
	
	/**
	 * Get session by ID
	 *
	 * @param string $session_id
	 * @return array|null
	 */
	public function get_session( $session_id ) {
		global $wpdb;
		
		$table = $wpdb->prefix . CF7CONV_SESSIONS_TABLE;
		
		$session = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM $table WHERE session_id = %s",
			$session_id
		), ARRAY_A );
		
		return $session ?: null;
	}
	
	/**
	 * Get session by resume token
	 *
	 * @param string $resume_token
	 * @return array|null
	 */
	public function get_session_by_resume_token( $resume_token ) {
		global $wpdb;
		
		$table = $wpdb->prefix . CF7CONV_SESSIONS_TABLE;
		
		$session = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM $table WHERE resume_token = %s AND status = 'active'",
			$resume_token
		), ARRAY_A );
		
		return $session ?: null;
	}
	
	/**
	 * Update session
	 *
	 * @param string $session_id
	 * @param array $data
	 * @return bool
	 */
	public function update_session( $session_id, $data ) {
		global $wpdb;
		
		$table = $wpdb->prefix . CF7CONV_SESSIONS_TABLE;
		
		$allowed_fields = array( 
			'email', 'current_step', 'answers', 'pricing_data', 
			'payment_status', 'order_id', 'status' 
		);
		
		$update_data = array();
		$format = array();
		
		foreach ( $data as $key => $value ) {
			if ( in_array( $key, $allowed_fields ) ) {
				switch ( $key ) {
					case 'email':
						$update_data[ $key ] = sanitize_email( $value );
						$format[] = '%s';
						break;
					case 'current_step':
					case 'payment_status':
					case 'status':
						$update_data[ $key ] = sanitize_text_field( $value );
						$format[] = '%s';
						break;
					case 'order_id':
						$update_data[ $key ] = intval( $value );
						$format[] = '%d';
						break;
					case 'answers':
					case 'pricing_data':
						$update_data[ $key ] = is_string( $value ) ? $value : wp_json_encode( $value );
						$format[] = '%s';
						break;
				}
			}
		}
		
		if ( empty( $update_data ) ) {
			return false;
		}
		
		$result = $wpdb->update(
			$table,
			$update_data,
			array( 'session_id' => $session_id ),
			$format,
			array( '%s' )
		);
		
		if ( $result === false ) {
			cf7conv_log( "Failed to update session $session_id: " . $wpdb->last_error, 'error' );
			return false;
		}
		
		do_action( 'cf7conv_session_updated', $session_id, $data );
		
		return true;
	}
	
	/**
	 * Complete session
	 *
	 * @param string $session_id
	 * @return bool
	 */
	public function complete_session( $session_id ) {
		$result = $this->update_session( $session_id, array(
			'status' => 'completed',
		) );
		
		if ( $result ) {
			global $wpdb;
			$table = $wpdb->prefix . CF7CONV_SESSIONS_TABLE;
			
			$wpdb->update(
				$table,
				array( 'completed_at' => current_time( 'mysql' ) ),
				array( 'session_id' => $session_id ),
				array( '%s' ),
				array( '%s' )
			);
			
			do_action( 'cf7conv_session_completed', $session_id );
		}
		
		return $result;
	}
	
	/**
	 * Get sessions by conversation ID
	 *
	 * @param int $conversation_id
	 * @param array $args
	 * @return array
	 */
	public function get_sessions_by_conversation( $conversation_id, $args = array() ) {
		global $wpdb;
		
		$table = $wpdb->prefix . CF7CONV_SESSIONS_TABLE;
		
		$defaults = array(
			'status' => '',
			'limit' => 50,
			'offset' => 0,
			'orderby' => 'started_at',
			'order' => 'DESC',
		);
		
		$args = wp_parse_args( $args, $defaults );
		
		$where = 'conversation_id = %d';
		$where_values = array( $conversation_id );
		
		if ( ! empty( $args['status'] ) ) {
			$where .= ' AND status = %s';
			$where_values[] = $args['status'];
		}
		
		$orderby = sanitize_sql_orderby( $args['orderby'] . ' ' . $args['order'] );
		$limit = intval( $args['limit'] );
		$offset = intval( $args['offset'] );
		
		$query = "SELECT * FROM $table WHERE $where ORDER BY $orderby LIMIT $limit OFFSET $offset";
		$query = $wpdb->prepare( $query, $where_values );
		
		return $wpdb->get_results( $query, ARRAY_A );
	}
	
	/**
	 * Get session statistics
	 *
	 * @param int $conversation_id
	 * @return array
	 */
	public function get_session_stats( $conversation_id ) {
		global $wpdb;
		
		$table = $wpdb->prefix . CF7CONV_SESSIONS_TABLE;
		
		$stats = $wpdb->get_row( $wpdb->prepare(
			"SELECT 
				COUNT(*) as total_sessions,
				SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_sessions,
				SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_sessions,
				SUM(CASE WHEN status = 'abandoned' THEN 1 ELSE 0 END) as abandoned_sessions,
				SUM(CASE WHEN payment_status = 'paid' THEN 1 ELSE 0 END) as paid_sessions
			FROM $table 
			WHERE conversation_id = %d",
			$conversation_id
		), ARRAY_A );
		
		if ( $stats ) {
			$stats['completion_rate'] = $stats['total_sessions'] > 0 
				? round( ( $stats['completed_sessions'] / $stats['total_sessions'] ) * 100, 2 )
				: 0;
			
			$stats['conversion_rate'] = $stats['completed_sessions'] > 0 
				? round( ( $stats['paid_sessions'] / $stats['completed_sessions'] ) * 100, 2 )
				: 0;
		}
		
		return $stats ?: array();
	}
	
	/**
	 * Delete session
	 *
	 * @param string $session_id
	 * @return bool
	 */
	public function delete_session( $session_id ) {
		global $wpdb;
		
		$table = $wpdb->prefix . CF7CONV_SESSIONS_TABLE;
		
		$result = $wpdb->delete( $table, array( 'session_id' => $session_id ), array( '%s' ) );
		
		if ( $result === false ) {
			cf7conv_log( "Failed to delete session $session_id: " . $wpdb->last_error, 'error' );
			return false;
		}
		
		do_action( 'cf7conv_session_deleted', $session_id );
		
		return true;
	}
	
	/**
	 * Generate resume link for session
	 *
	 * @param string $session_id
	 * @return string|false
	 */
	public function generate_resume_link( $session_id ) {
		$session = $this->get_session( $session_id );
		
		if ( ! $session || empty( $session['resume_token'] ) ) {
			return false;
		}
		
		return cf7conv_get_conversation_url( $session['conversation_id'], $session['resume_token'] );
	}
	
	/**
	 * Get all sessions with pagination and filtering
	 *
	 * @param array $args
	 * @return array
	 */
	public function get_sessions( $args = array() ) {
		global $wpdb;
		
		$table = $wpdb->prefix . CF7CONV_SESSIONS_TABLE;
		
		$defaults = array(
			'status' => '',
			'conversation_id' => 0,
			'search' => '',
			'limit' => 20,
			'offset' => 0,
			'orderby' => 'started_at',
			'order' => 'DESC',
		);
		
		$args = wp_parse_args( $args, $defaults );
		
		$where = '1=1';
		$where_values = array();
		
		if ( ! empty( $args['status'] ) ) {
			$where .= ' AND status = %s';
			$where_values[] = $args['status'];
		}
		
		if ( ! empty( $args['conversation_id'] ) ) {
			$where .= ' AND conversation_id = %d';
			$where_values[] = intval( $args['conversation_id'] );
		}
		
		if ( ! empty( $args['search'] ) ) {
			$where .= ' AND (email LIKE %s OR session_id LIKE %s)';
			$search_term = '%' . $wpdb->esc_like( $args['search'] ) . '%';
			$where_values[] = $search_term;
			$where_values[] = $search_term;
		}
		
		$orderby = sanitize_sql_orderby( $args['orderby'] . ' ' . $args['order'] );
		if ( ! $orderby ) {
			$orderby = 'started_at DESC';
		}
		
		$limit = intval( $args['limit'] );
		$offset = intval( $args['offset'] );
		
		// Get sessions
		$query = "SELECT * FROM $table WHERE $where ORDER BY $orderby LIMIT $limit OFFSET $offset";
		if ( ! empty( $where_values ) ) {
			$query = $wpdb->prepare( $query, $where_values );
		}
		
		$sessions = $wpdb->get_results( $query, ARRAY_A );
		
		// Get total count
		$count_query = "SELECT COUNT(*) FROM $table WHERE $where";
		if ( ! empty( $where_values ) ) {
			// Remove LIMIT and OFFSET values for count query
			$count_values = array_slice( $where_values, 0, -2 );
			if ( ! empty( $count_values ) ) {
				$count_query = $wpdb->prepare( $count_query, $count_values );
			}
		}
		
		$total = $wpdb->get_var( $count_query );
		
		return array(
			'sessions' => $sessions ?: array(),
			'total' => intval( $total ),
		);
	}
	
	/**
	 * Get session count by status
	 *
	 * @return array
	 */
	public function get_session_counts() {
		global $wpdb;
		
		$table = $wpdb->prefix . CF7CONV_SESSIONS_TABLE;
		
		$counts = $wpdb->get_results(
			"SELECT status, COUNT(*) as count FROM $table GROUP BY status",
			ARRAY_A
		);
		
		$result = array(
			'all' => 0,
			'active' => 0,
			'completed' => 0,
			'abandoned' => 0,
			'expired' => 0,
		);
		
		foreach ( $counts as $count ) {
			$result[ $count['status'] ] = intval( $count['count'] );
			$result['all'] += intval( $count['count'] );
		}
		
		return $result;
	}
}