<?php

namespace CF7CONV\Compatibility;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PHP 8+ Compatibility helper functions
 */
class CompatibilityHelper {
	
	/**
	 * Safe strpos that handles null values
	 *
	 * @param string|null $haystack
	 * @param string $needle
	 * @param int $offset
	 * @return int|false
	 */
	public static function safe_strpos( $haystack, $needle, $offset = 0 ) {
		return strpos( $haystack ?? '', $needle, $offset );
	}
	
	/**
	 * Safe str_replace that handles null values
	 *
	 * @param array|string $search
	 * @param array|string $replace
	 * @param array|string|null $subject
	 * @param int $count
	 * @return array|string
	 */
	public static function safe_str_replace( $search, $replace, $subject, &$count = null ) {
		return str_replace( $search, $replace, $subject ?? '', $count );
	}
	
	/**
	 * Safe json_decode that handles null values
	 *
	 * @param string|null $json
	 * @param bool $associative
	 * @param int $depth
	 * @param int $flags
	 * @return mixed
	 */
	public static function safe_json_decode( $json, $associative = false, $depth = 512, $flags = 0 ) {
		if ( $json === null || $json === '' ) {
			return $associative ? array() : null;
		}
		
		return json_decode( $json, $associative, $depth, $flags );
	}
	
	/**
	 * Safe esc_attr that handles null values
	 *
	 * @param string|null $text
	 * @return string
	 */
	public static function safe_esc_attr( $text ) {
		return esc_attr( $text ?? '' );
	}
	
	/**
	 * Safe esc_html that handles null values
	 *
	 * @param string|null $text
	 * @return string
	 */
	public static function safe_esc_html( $text ) {
		return esc_html( $text ?? '' );
	}
	
	/**
	 * Safe esc_textarea that handles null values
	 *
	 * @param string|null $text
	 * @return string
	 */
	public static function safe_esc_textarea( $text ) {
		return esc_textarea( $text ?? '' );
	}
	
	/**
	 * Safe sanitize_text_field that handles null values
	 *
	 * @param string|null $str
	 * @return string
	 */
	public static function safe_sanitize_text_field( $str ) {
		return sanitize_text_field( $str ?? '' );
	}
	
	/**
	 * Safe sanitize_textarea_field that handles null values
	 *
	 * @param string|null $str
	 * @return string
	 */
	public static function safe_sanitize_textarea_field( $str ) {
		return sanitize_textarea_field( $str ?? '' );
	}
	
	/**
	 * Safe get_query_var that handles null values
	 *
	 * @param string $var
	 * @param mixed $default
	 * @return mixed
	 */
	public static function safe_get_query_var( $var, $default = '' ) {
		$value = get_query_var( $var );
		return $value !== false ? $value : $default;
	}
	
	/**
	 * Check if current PHP version has known compatibility issues
	 *
	 * @return array
	 */
	public static function check_php_compatibility() {
		$issues = array();
		
		if ( version_compare( PHP_VERSION, '8.0', '>=' ) ) {
			$issues[] = array(
				'level' => 'info',
				'message' => 'PHP 8.0+ detected. Null value handling has been implemented.',
			);
		}
		
		if ( version_compare( PHP_VERSION, '8.1', '>=' ) ) {
			$issues[] = array(
				'level' => 'info',
				'message' => 'PHP 8.1+ detected. Additional deprecation warnings may appear from WordPress core.',
			);
		}
		
		if ( version_compare( PHP_VERSION, '7.4', '<' ) ) {
			$issues[] = array(
				'level' => 'error',
				'message' => 'PHP version ' . PHP_VERSION . ' is not supported. Please upgrade to PHP 7.4 or higher.',
			);
		}
		
		return $issues;
	}
	
	/**
	 * Test common WordPress functions with null values
	 *
	 * @return array
	 */
	public static function test_wordpress_functions() {
		$results = array();
		
		// Test esc_attr with null
		try {
			$test = esc_attr( null );
			$results['esc_attr_null'] = 'OK';
		} catch ( Exception $e ) {
			$results['esc_attr_null'] = 'ERROR: ' . $e->getMessage();
		}
		
		// Test esc_html with null
		try {
			$test = esc_html( null );
			$results['esc_html_null'] = 'OK';
		} catch ( Exception $e ) {
			$results['esc_html_null'] = 'ERROR: ' . $e->getMessage();
		}
		
		// Test strpos with null
		try {
			$test = strpos( null, 'test' );
			$results['strpos_null'] = 'OK';
		} catch ( Exception $e ) {
			$results['strpos_null'] = 'ERROR: ' . $e->getMessage();
		}
		
		// Test str_replace with null
		try {
			$test = str_replace( 'a', 'b', null );
			$results['str_replace_null'] = 'OK';
		} catch ( Exception $e ) {
			$results['str_replace_null'] = 'ERROR: ' . $e->getMessage();
		}
		
		// Test sanitize_text_field with null
		try {
			$test = sanitize_text_field( null );
			$results['sanitize_text_field_null'] = 'OK';
		} catch ( Exception $e ) {
			$results['sanitize_text_field_null'] = 'ERROR: ' . $e->getMessage();
		}
		
		// Test get_query_var with non-existent var
		try {
			$test = get_query_var( 'non_existent_var_test_12345' );
			$results['get_query_var_nonexistent'] = 'OK';
		} catch ( Exception $e ) {
			$results['get_query_var_nonexistent'] = 'ERROR: ' . $e->getMessage();
		}
		
		return $results;
	}
}