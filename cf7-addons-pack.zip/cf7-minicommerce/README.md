# CF7 Mini Ecommerce

A lightweight WordPress plugin that transforms Contact Form 7 forms into instant checkout forms for services, digital products, donations, or bookings.

## Features

- **Instant Checkout**: Transform CF7 forms into payment forms
- **Multiple Payment Gateways**: Extensible gateway system (WhatsApp checkout included by default)
- **Order Management**: Complete order tracking and management
- **Secure Webhooks**: Secure payment confirmation handling
- **Email Notifications**: Automated notifications for customers and admins
- **Clean Architecture**: Modular, extensible codebase

## Requirements

- WordPress 6.0+
- PHP 7.4+
- Contact Form 7 plugin

## Installation

1. Upload the plugin files to `/wp-content/plugins/cf7-minicommerce/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Configure settings in **CF7 Ecommerce > Settings**

## Quick Start

### 1. Create a Contact Form 7 Form

Create a new CF7 form with these required fields:

```
[email* your-email placeholder "Your Email"]
[text* product_id placeholder "Product ID"]
[text product_name placeholder "Product Name"]
[number quantity min:1 max:10 placeholder "Quantity"]
[number price step:0.01 placeholder "Price"]

[submit "Order Now"]
```

### 2. Configure Products (Optional)

Go to **CF7 Ecommerce > Settings** to pre-configure products with fixed prices.

### 3. Set Up Payment Gateway

1. Go to **CF7 Ecommerce > Settings**
2. Configure your preferred payment gateway
3. For instant messaging checkout, configure the WhatsApp Gateway with your business number

### 4. Test the Form

1. Submit the form with valid product information
2. You'll receive a checkout link
3. Complete payment through the gateway
4. Check **CF7 Ecommerce > Orders** for order status

## Form Field Mapping

The plugin automatically detects these field names:

### Required Fields
- **Email**: `your-email`, `email`, `customer-email`
- **Product ID**: `product_id`, `product-id`, `product`

### Optional Fields
- **Product Name**: `product_name`, `product-name`, `service`, `item`
- **Quantity**: `quantity`, `qty`
- **Price**: `price`, `amount`, `cost`
- **Description**: `description`, `notes`, `details`

## Payment Gateways

### WhatsApp Gateway (Default)
Direct customer communication through WhatsApp for personalized checkout experience.

**Features:**
- Direct WhatsApp messaging with order details
- Customizable message templates
- Auto-completion after specified hours
- Personal customer service approach

**Configuration:**
- WhatsApp Business Number: Your business WhatsApp number with country code
- Message Template: Customizable template with order placeholders
- Auto Complete Hours: Automatically mark orders as completed after X hours
- Button Text: Customize the checkout button text
- Success Message: Message shown after WhatsApp redirect

**How it works:**
1. Customer submits CF7 form
2. Order is created with "pending_payment" status
3. Customer clicks WhatsApp button
4. Pre-filled message opens in WhatsApp
5. Customer contacts your business directly
6. You handle payment and mark order as completed

### TriPay Gateway (Indonesian Payments)
Indonesian payment gateway supporting various local payment methods.

**Supported Payment Methods:**
- Virtual Accounts: BRI, BNI, BCA, Mandiri
- E-wallets: OVO, DANA, GoPay, LinkAja, ShopeePay
- Retail Outlets: Alfamart, Indomaret

**Configuration:**
- API Key: From TriPay merchant dashboard
- Private Key: From TriPay merchant dashboard  
- Merchant Code: Your TriPay merchant code
- Sandbox Mode: Enable for testing
- Default Payment Method: Choose preferred method

**Webhook URL:** `https://yoursite.com/cf7mc-webhook/tripay/`

### PayPal Gateway (International Payments)
Accept payments via PayPal worldwide with support for multiple currencies.

**Features:**
- PayPal account payments
- Credit/debit card payments (guest checkout)
- Multiple currency support
- Immediate or authorized capture

**Configuration:**
- Client ID: From PayPal Developer Dashboard
- Client Secret: From PayPal Developer Dashboard
- Sandbox Mode: Enable for testing
- Payment Intent: Capture (immediate) or Authorize (manual)
- Brand Name: Displayed on PayPal checkout

**Webhook URL:** `https://yoursite.com/cf7mc-webhook/paypal/`

### Adding Custom Gateways

Create a new gateway class implementing `CF7MC\Gateways\GatewayInterface`:

```php
class MyCustomGateway implements CF7MC\Gateways\GatewayInterface {
    // Implement required methods
}

// Register the gateway
add_action('cf7mc_register_gateways', function($gateway_manager) {
    $gateway_manager->register_gateway('my_gateway', new MyCustomGateway());
});
```

## Webhooks

Webhook endpoints are automatically created at:
```
https://yoursite.com/cf7mc-webhook/{gateway_id}/
```

Each gateway handles its own webhook verification and processing.

## Order Statuses

- **pending**: Order created, payment not yet received
- **paid**: Payment confirmed
- **failed**: Payment failed
- **expired**: Order expired (configurable timeout)

## Hooks and Filters

### Actions
- `cf7mc_init`: Plugin initialized
- `cf7mc_order_created`: New order created
- `cf7mc_order_status_updated`: Order status changed
- `cf7mc_register_gateways`: Register custom gateways

### Filters
- `cf7mc_product_price`: Filter product price
- `cf7mc_item_total`: Filter item total calculation
- `cf7mc_apply_discounts`: Filter discount application
- `cf7mc_apply_fees`: Filter fee application
- `cf7mc_available_gateways`: Filter available gateways

## Configuration Options

### General Settings
- **Currency**: Default currency (USD, EUR, GBP, JPY, IDR)
  - USD: US Dollar (PayPal, Mock)
  - EUR: Euro (PayPal)
  - GBP: British Pound (PayPal)
  - JPY: Japanese Yen (PayPal)
  - IDR: Indonesian Rupiah (TriPay, PayPal)
- **Minimum Amount**: Minimum order amount
- **Order Expiry**: Hours until unpaid orders expire
- **Default Gateway**: Default payment gateway

### Email Notifications
- **Admin Email**: Email for admin notifications
- **Admin New Order**: Notify admin of new orders
- **Customer Paid**: Notify customer when payment confirmed

## Database Schema

### Orders Table (`wp_cf7_mini_orders`)
- `id`: Primary key
- `order_code`: Unique order identifier
- `email`: Customer email
- `items`: JSON-encoded order items
- `total_amount`: Order total
- `gateway`: Payment gateway used
- `gateway_payment_id`: Gateway's payment ID
- `status`: Order status
- `created_at`: Creation timestamp
- `paid_at`: Payment timestamp

## Security Features

- **Nonce Verification**: All forms protected with nonces
- **Input Sanitization**: All inputs sanitized and validated
- **Webhook Signatures**: Secure webhook verification
- **Checkout Tokens**: Tokenized checkout URLs
- **SQL Injection Protection**: Prepared statements used throughout

## Development

### File Structure
```
cf7-minicommerce/
├── cf7-minicommerce.php          # Main plugin file
├── load.php                      # Plugin loader
├── uninstall.php                 # Uninstall cleanup
├── includes/
│   ├── functions.php             # Utility functions
│   ├── core/                     # Core classes
│   ├── gateways/                 # Payment gateways
│   ├── integrations/             # CF7 integration
│   ├── webhooks/                 # Webhook handling
│   ├── admin/                    # Admin interface
│   └── database/                 # Database management
└── assets/                       # CSS/JS files
```

### Coding Standards
- WordPress Coding Standards
- PSR-4 Autoloading
- Namespaced classes
- Comprehensive input validation
- Extensive logging for debugging

## Troubleshooting

### Common Issues

**Orders not being created:**
- Check that CF7 form has required fields
- Verify email field is valid
- Check error logs for validation failures

**Payments not updating:**
- Verify webhook URL is accessible
- Check gateway configuration
- Review webhook logs in error log

**Gateway not appearing:**
- Ensure gateway is enabled in settings
- Check gateway availability conditions
- Verify gateway registration hook

### Debug Mode
Enable WordPress debug mode to see detailed logs:
```php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
```

Logs are written to `/wp-content/debug.log` with `[CF7MC]` prefix.

## Support

For support and feature requests, please check the plugin documentation or contact the development team.

## License

GPL v2 or later - https://www.gnu.org/licenses/gpl-2.0.html