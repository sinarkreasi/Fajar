<?php

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Autoloader
spl_autoload_register( 'cf7mc_autoloader' );

function cf7mc_autoloader( $class ) {
	// Only handle our namespace
	if ( strpos( $class, 'CF7MC\\' ) !== 0 ) {
		return;
	}
	
	// Remove namespace prefix
	$class = substr( $class, 6 );
	
	// Convert namespace separators to directory separators
	$class = str_replace( '\\', DIRECTORY_SEPARATOR, $class );
	
	// Convert to lowercase and add .php extension
	$file = CF7MC_PLUGIN_DIR . '/includes/' . strtolower( $class ) . '.php';
	
	if ( file_exists( $file ) ) {
		require_once $file;
	}
}

// Load core files
require_once CF7MC_PLUGIN_DIR . '/includes/functions.php';

// Load interfaces
require_once CF7MC_PLUGIN_DIR . '/includes/interfaces/paymentgatewayinterface.php';

// Load gateway interface (legacy)
require_once CF7MC_PLUGIN_DIR . '/includes/gateways/gatewayinterface.php';

// Load gateways
require_once CF7MC_PLUGIN_DIR . '/includes/gateways/whatsappgateway.php';
require_once CF7MC_PLUGIN_DIR . '/includes/gateways/tripaygateway.php';
require_once CF7MC_PLUGIN_DIR . '/includes/gateways/paypalgateway.php';

// Initialize plugin
function cf7mc_init() {
	// Load text domain
	load_plugin_textdomain( CF7MC_TEXT_DOMAIN, false, dirname( CF7MC_PLUGIN_BASENAME ) . '/languages' );
	
	// Check and upgrade database if needed
	CF7MC\Database\SchemaManager::maybe_upgrade();
	
	// Initialize event dispatcher
	CF7MC\Core\EventDispatcher::init();
	
	// Initialize core components
	CF7MC\Core\Plugin::instance();
	
	// Initialize inline checkout manager
	new CF7MC\Core\InlineCheckoutManager();
	
	// Hook into CF7
	CF7MC\Integrations\CF7Listener::instance();
	
	// Initialize admin if in admin area
	if ( is_admin() ) {
		CF7MC\Admin\AdminInit::instance();
	}
	
	// Initialize webhooks endpoint
	CF7MC\Webhooks\WebhookHandler::instance();
	
	do_action( 'cf7mc_init' );
}

// Hook plugin initialization
add_action( 'init', 'cf7mc_plugin_init', 20 );

function cf7mc_plugin_init() {
	// Register rewrite rules for webhooks
	add_rewrite_rule( 
		'^cf7mc-webhook/([^/]+)/?$', 
		'index.php?cf7mc_webhook=1&gateway=$matches[1]', 
		'top' 
	);
	
	// Add query vars
	add_filter( 'query_vars', function( $vars ) {
		$vars[] = 'cf7mc_webhook';
		$vars[] = 'gateway';
		return $vars;
	});
}