/* CF7 Mini Ecommerce Admin JavaScript */

(function($) {
    'use strict';
    
    $(document).ready(function() {
        initAdminInterface();
    });
    
    function initAdminInterface() {
        // Handle gateway enable/disable
        $(document).on('change', '.gateway-enabled-checkbox', function() {
            var $checkbox = $(this);
            var $gatewaySettings = $checkbox.closest('.cf7mc-gateway-settings');
            
            if ($checkbox.is(':checked')) {
                $gatewaySettings.find('.gateway-config-fields').show();
            } else {
                $gatewaySettings.find('.gateway-config-fields').hide();
            }
        });
        
        // Handle order status updates
        $(document).on('change', '.order-status-select', function() {
            var $select = $(this);
            var orderId = $select.data('order-id');
            var newStatus = $select.val();
            
            updateOrderStatus(orderId, newStatus);
        });
        
        // Handle bulk actions
        $('#doaction, #doaction2').on('click', function(e) {
            var action = $(this).siblings('select').val();
            
            if (action === 'delete') {
                if (!confirm(cf7mc_admin.delete_confirmation || 'Are you sure you want to delete the selected orders?')) {
                    e.preventDefault();
                    return false;
                }
            }
        });
        
        // Initialize gateway settings visibility
        $('.gateway-enabled-checkbox').trigger('change');
    }
    
    function updateOrderStatus(orderId, status) {
        var data = {
            action: 'cf7mc_update_order_status',
            order_id: orderId,
            status: status,
            nonce: cf7mc_admin.nonce
        };
        
        $.post(cf7mc_admin.ajax_url, data, function(response) {
            if (response.success) {
                showNotice('Order status updated successfully.', 'success');
                
                // Update status display
                var $statusCell = $('.order-' + orderId + ' .column-status');
                $statusCell.html('<span class="cf7mc-status-' + status + '">' + status.toUpperCase() + '</span>');
            } else {
                showNotice('Failed to update order status: ' + response.data, 'error');
            }
        }).fail(function() {
            showNotice('Failed to update order status. Please try again.', 'error');
        });
    }
    
    function showNotice(message, type) {
        var $notice = $('<div class="notice notice-' + type + ' is-dismissible"><p>' + message + '</p></div>');
        $('.wrap h1').after($notice);
        
        // Auto-dismiss after 5 seconds
        setTimeout(function() {
            $notice.fadeOut(function() {
                $notice.remove();
            });
        }, 5000);
    }
    
    // Handle settings form validation
    $('#cf7mc-settings-form').on('submit', function(e) {
        var $form = $(this);
        var isValid = true;
        
        // Validate required fields
        $form.find('[required]').each(function() {
            var $field = $(this);
            
            if (!$field.val().trim()) {
                $field.addClass('error');
                isValid = false;
            } else {
                $field.removeClass('error');
            }
        });
        
        // Validate email fields
        $form.find('input[type="email"]').each(function() {
            var $field = $(this);
            var email = $field.val().trim();
            
            if (email && !isValidEmail(email)) {
                $field.addClass('error');
                isValid = false;
            } else {
                $field.removeClass('error');
            }
        });
        
        if (!isValid) {
            e.preventDefault();
            showNotice('Please correct the highlighted fields.', 'error');
        }
    });
    
    function isValidEmail(email) {
        var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
    
})(jQuery);

// AJAX handler for order status updates
jQuery(document).ready(function($) {
    // Add AJAX handler
    wp.hooks = wp.hooks || {};
    
    $(document).ajaxComplete(function(event, xhr, settings) {
        if (settings.data && settings.data.indexOf('cf7mc_update_order_status') !== -1) {
            // Refresh the page after successful status update
            setTimeout(function() {
                location.reload();
            }, 1000);
        }
    });
});