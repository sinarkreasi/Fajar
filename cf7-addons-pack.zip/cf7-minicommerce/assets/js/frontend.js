/* CF7 Mini Ecommerce Frontend JavaScript */

(function($) {
    'use strict';
    
    // Initialize when document is ready
    $(document).ready(function() {
        initCF7MiniCommerce();
    });
    
    function initCF7MiniCommerce() {
        // Handle quantity changes
        $(document).on('change', '.cf7mc-quantity', function() {
            updatePriceDisplay();
        });
        
        // Handle product selection changes
        $(document).on('change', '.cf7mc-product-select', function() {
            updatePriceDisplay();
        });
        
        // Handle form submission success
        $(document).on('wpcf7mailsent', function(event) {
            var $form = $(event.target);
            
            // Check if this is an ecommerce form
            if ($form.find('.cf7mc-checkout-info').length > 0) {
                // Form submitted successfully, checkout info should be displayed
                console.log('CF7MC: Order created successfully');
            }
        });
        
        // Handle form submission failure
        $(document).on('wpcf7mailfailed', function(event) {
            var $form = $(event.target);
            
            if ($form.find('.cf7mc-checkout-info').length > 0) {
                console.log('CF7MC: Order creation failed');
            }
        });
        
        // Initial price calculation
        updatePriceDisplay();
    }
    
    function updatePriceDisplay() {
        $('.cf7mc-price-display').each(function() {
            var $display = $(this);
            var $form = $display.closest('form');
            
            var price = parseFloat($form.find('[name*="price"]').val() || 0);
            var quantity = parseInt($form.find('[name*="quantity"]').val() || 1);
            
            if (price > 0) {
                var total = price * quantity;
                var currency = $display.data('currency') || 'USD';
                var formattedPrice = formatPrice(total, currency);
                
                $display.text(formattedPrice);
                $display.show();
            } else {
                $display.hide();
            }
        });
    }
    
    function formatPrice(amount, currency) {
        var symbols = {
            'USD': '$',
            'EUR': '€',
            'GBP': '£',
            'JPY': '¥',
            'IDR': 'Rp'
        };
        
        var symbol = symbols[currency] || currency + ' ';
        return symbol + amount.toFixed(2);
    }
    
    // Utility function to show loading state
    function showLoading($element) {
        $element.addClass('cf7mc-loading');
    }
    
    function hideLoading($element) {
        $element.removeClass('cf7mc-loading');
    }
    
    // Utility function to show messages
    function showMessage(message, type) {
        var $message = $('<div class="cf7mc-' + type + '">' + message + '</div>');
        $('.wpcf7-form').prepend($message);
        
        setTimeout(function() {
            $message.fadeOut(function() {
                $message.remove();
            });
        }, 5000);
    }
    
})(jQuery);