/**
 * CF7 Mini Ecommerce - Inline Checkout
 * 
 * Handles inline checkout without page redirects
 */
(function($) {
    'use strict';

    // Checkout manager
    window.CF7MC_InlineCheckout = {
        
        // Configuration
        config: window.cf7mc_checkout || {},
        
        // Current checkout session
        currentSession: null,
        
        // Payment status polling
        statusPolling: null,
        
        /**
         * Initialize inline checkout
         */
        init: function() {
            this.bindEvents();
            this.initExistingCheckouts();
        },
        
        /**
         * Bind events
         */
        bindEvents: function() {
            // Payment step initialization
            $(document).on('cf7conv:step:payment:init', this.handlePaymentStepInit.bind(this));
            
            // Payment button clicks
            $(document).on('click', '.cf7mc-payment-button', this.handlePaymentButtonClick.bind(this));
            
            // Gateway selection
            $(document).on('change', '.cf7mc-gateway-select', this.handleGatewayChange.bind(this));
            
            // Retry payment
            $(document).on('click', '.cf7mc-retry-payment', this.handleRetryPayment.bind(this));
        },
        
        /**
         * Initialize existing checkouts on page load
         */
        initExistingCheckouts: function() {
            $('.cf7mc-inline-checkout').each(function() {
                var $checkout = $(this);
                var orderId = $checkout.data('order-id');
                
                if (orderId) {
                    CF7MC_InlineCheckout.checkPaymentStatus(orderId);
                }
            });
        },
        
        /**
         * Handle payment step initialization
         */
        handlePaymentStepInit: function(event, stepData) {
            console.log('Payment step initialized:', stepData);
            
            // Create order if not exists
            if (!stepData.orderId) {
                this.createOrder(stepData);
            } else {
                this.initializeCheckout(stepData.orderId, stepData.gateway);
            }
        },
        
        /**
         * Create order for payment
         */
        createOrder: function(stepData) {
            var self = this;
            
            $.ajax({
                url: this.config.ajax_url,
                type: 'POST',
                data: {
                    action: 'cf7mc_create_order',
                    nonce: this.config.nonce,
                    step_data: stepData
                },
                success: function(response) {
                    if (response.success) {
                        self.initializeCheckout(response.data.order_id, stepData.gateway);
                    } else {
                        self.showError(response.data.message || self.config.strings.error);
                    }
                },
                error: function() {
                    self.showError(self.config.strings.error);
                }
            });
        },
        
        /**
         * Initialize checkout for order
         */
        initializeCheckout: function(orderId, gateway) {
            var self = this;
            
            $.ajax({
                url: this.config.ajax_url,
                type: 'POST',
                data: {
                    action: 'cf7mc_create_payment_session',
                    nonce: this.config.nonce,
                    order_id: orderId,
                    gateway: gateway
                },
                success: function(response) {
                    if (response.success) {
                        self.currentSession = response.data;
                        self.renderCheckoutUI(orderId, response.data);
                    } else {
                        self.showError(response.data.message || self.config.strings.error);
                    }
                },
                error: function() {
                    self.showError(self.config.strings.error);
                }
            });
        },
        
        /**
         * Render checkout UI
         */
        renderCheckoutUI: function(orderId, sessionData) {
            var $container = $('.cf7conv-step-payment .cf7conv-step-content');
            
            if (!$container.length) {
                console.error('Payment step container not found');
                return;
            }
            
            var html = this.buildCheckoutHTML(orderId, sessionData);
            $container.html(html);
            
            // Load required scripts for gateway
            this.loadGatewayScripts(sessionData.required_scripts || []);
        },
        
        /**
         * Build checkout HTML
         */
        buildCheckoutHTML: function(orderId, sessionData) {
            var config = sessionData.client_config;
            var gateway = config.gateway;
            
            var html = '<div class="cf7mc-inline-checkout" data-order-id="' + orderId + '" data-gateway="' + gateway + '">';
            
            // Payment summary
            html += '<div class="cf7mc-payment-summary">';
            html += '<h4>' + (this.config.strings.payment_summary || 'Payment Summary') + '</h4>';
            html += '<div class="cf7mc-amount">' + this.formatAmount(sessionData.session_data.amount, sessionData.session_data.currency) + '</div>';
            html += '</div>';
            
            // Gateway-specific UI
            if (gateway === 'whatsapp') {
                html += this.buildWhatsAppUI(config);
            } else {
                html += this.buildGenericUI(config);
            }
            
            // Status area
            html += '<div class="cf7mc-payment-status" style="display: none;"></div>';
            
            html += '</div>';
            
            return html;
        },
        
        /**
         * Build WhatsApp UI
         */
        buildWhatsAppUI: function(config) {
            var html = '<div class="cf7mc-whatsapp-checkout">';
            html += '<div class="cf7mc-whatsapp-info">';
            html += '<p>' + (this.config.strings.whatsapp_info || 'Complete your payment via WhatsApp with our sales team.') + '</p>';
            html += '</div>';
            html += '<button type="button" class="cf7mc-payment-button cf7mc-whatsapp-button" data-url="' + config.whatsapp_url + '">';
            html += '<span class="cf7mc-whatsapp-icon">💬</span>';
            html += config.button_text;
            html += '</button>';
            html += '</div>';
            
            return html;
        },
        
        /**
         * Build generic payment UI
         */
        buildGenericUI: function(config) {
            var html = '<div class="cf7mc-generic-checkout">';
            html += '<button type="button" class="cf7mc-payment-button">';
            html += config.button_text || 'Complete Payment';
            html += '</button>';
            html += '</div>';
            
            return html;
        },
        
        /**
         * Handle payment button click
         */
        handlePaymentButtonClick: function(event) {
            event.preventDefault();
            
            var $button = $(event.currentTarget);
            var $checkout = $button.closest('.cf7mc-inline-checkout');
            var orderId = $checkout.data('order-id');
            var gateway = $checkout.data('gateway');
            
            if (!orderId) {
                this.showError('Order ID not found');
                return;
            }
            
            // Disable button and show processing
            $button.prop('disabled', true).addClass('processing');
            this.showProcessing();
            
            if (gateway === 'whatsapp') {
                this.processWhatsAppPayment($button, orderId);
            } else {
                this.processGenericPayment($button, orderId);
            }
        },
        
        /**
         * Process WhatsApp payment
         */
        processWhatsAppPayment: function($button, orderId) {
            var self = this;
            var whatsappUrl = $button.data('url');
            
            // Confirm payment initiation
            $.ajax({
                url: this.config.ajax_url,
                type: 'POST',
                data: {
                    action: 'cf7mc_confirm_payment',
                    nonce: this.config.nonce,
                    order_id: orderId,
                    payment_data: {
                        gateway: 'whatsapp',
                        whatsapp_url: whatsappUrl
                    }
                },
                success: function(response) {
                    if (response.success) {
                        // Open WhatsApp
                        window.open(whatsappUrl, '_blank');
                        
                        // Show success message
                        self.showSuccess(response.data.message || self.config.strings.success);
                        
                        // Start polling for payment status
                        self.startStatusPolling(orderId);
                        
                        // Trigger conversation continuation after delay
                        setTimeout(function() {
                            self.continueConversation();
                        }, 3000);
                        
                    } else {
                        self.showError(response.data.error || self.config.strings.error);
                        $button.prop('disabled', false).removeClass('processing');
                    }
                },
                error: function() {
                    self.showError(self.config.strings.error);
                    $button.prop('disabled', false).removeClass('processing');
                }
            });
        },
        
        /**
         * Process generic payment
         */
        processGenericPayment: function($button, orderId) {
            // Implement for other gateways
            console.log('Generic payment processing not implemented');
            $button.prop('disabled', false).removeClass('processing');
        },
        
        /**
         * Start payment status polling
         */
        startStatusPolling: function(orderId) {
            var self = this;
            
            // Clear existing polling
            if (this.statusPolling) {
                clearInterval(this.statusPolling);
            }
            
            // Poll every 10 seconds
            this.statusPolling = setInterval(function() {
                self.checkPaymentStatus(orderId);
            }, 10000);
            
            // Stop polling after 10 minutes
            setTimeout(function() {
                if (self.statusPolling) {
                    clearInterval(self.statusPolling);
                    self.statusPolling = null;
                }
            }, 600000);
        },
        
        /**
         * Check payment status
         */
        checkPaymentStatus: function(orderId) {
            var self = this;
            
            $.ajax({
                url: this.config.ajax_url,
                type: 'POST',
                data: {
                    action: 'cf7mc_get_payment_status',
                    nonce: this.config.nonce,
                    order_id: orderId
                },
                success: function(response) {
                    if (response.success) {
                        var status = response.data.status;
                        
                        if (status === 'paid') {
                            self.handlePaymentSuccess(orderId);
                        } else if (status === 'failed') {
                            self.handlePaymentFailure(orderId);
                        }
                        // Continue polling for other statuses
                    }
                }
            });
        },
        
        /**
         * Handle payment success
         */
        handlePaymentSuccess: function(orderId) {
            // Stop polling
            if (this.statusPolling) {
                clearInterval(this.statusPolling);
                this.statusPolling = null;
            }
            
            this.showSuccess(this.config.strings.success);
            
            // Trigger payment success event
            $(document).trigger('cf7mc:payment:success', { orderId: orderId });
            
            // Continue conversation
            this.continueConversation();
        },
        
        /**
         * Handle payment failure
         */
        handlePaymentFailure: function(orderId) {
            // Stop polling
            if (this.statusPolling) {
                clearInterval(this.statusPolling);
                this.statusPolling = null;
            }
            
            this.showError(this.config.strings.error);
            
            // Show retry option
            this.showRetryOption(orderId);
            
            // Trigger payment failure event
            $(document).trigger('cf7mc:payment:failed', { orderId: orderId });
        },
        
        /**
         * Continue conversation after payment
         */
        continueConversation: function() {
            // Trigger conversation engine to continue
            if (window.CF7CONV && window.CF7CONV.nextStep) {
                setTimeout(function() {
                    window.CF7CONV.nextStep();
                }, 2000);
            }
        },
        
        /**
         * Show processing state
         */
        showProcessing: function() {
            var $status = $('.cf7mc-payment-status');
            $status.removeClass('success error').addClass('processing')
                   .html('<div class="cf7mc-spinner"></div>' + this.config.strings.processing)
                   .show();
        },
        
        /**
         * Show success message
         */
        showSuccess: function(message) {
            var $status = $('.cf7mc-payment-status');
            $status.removeClass('processing error').addClass('success')
                   .html('<div class="cf7mc-success-icon">✓</div>' + message)
                   .show();
        },
        
        /**
         * Show error message
         */
        showError: function(message) {
            var $status = $('.cf7mc-payment-status');
            $status.removeClass('processing success').addClass('error')
                   .html('<div class="cf7mc-error-icon">✗</div>' + message)
                   .show();
        },
        
        /**
         * Show retry option
         */
        showRetryOption: function(orderId) {
            var $status = $('.cf7mc-payment-status');
            var retryHtml = '<button type="button" class="cf7mc-retry-payment" data-order-id="' + orderId + '">';
            retryHtml += (this.config.strings.retry || 'Try Again') + '</button>';
            $status.append(retryHtml);
        },
        
        /**
         * Handle retry payment
         */
        handleRetryPayment: function(event) {
            var $button = $(event.currentTarget);
            var orderId = $button.data('order-id');
            
            // Reset UI and retry
            $('.cf7mc-payment-status').hide();
            $('.cf7mc-payment-button').prop('disabled', false).removeClass('processing');
            
            // Re-initialize checkout
            var gateway = $('.cf7mc-inline-checkout').data('gateway');
            this.initializeCheckout(orderId, gateway);
        },
        
        /**
         * Load gateway-specific scripts
         */
        loadGatewayScripts: function(scripts) {
            if (!scripts || scripts.length === 0) {
                return;
            }
            
            var loadedScripts = 0;
            var totalScripts = scripts.length;
            
            scripts.forEach(function(scriptUrl) {
                var script = document.createElement('script');
                script.src = scriptUrl;
                script.onload = function() {
                    loadedScripts++;
                    if (loadedScripts === totalScripts) {
                        $(document).trigger('cf7mc:scripts:loaded');
                    }
                };
                document.head.appendChild(script);
            });
        },
        
        /**
         * Format amount for display
         */
        formatAmount: function(amount, currency) {
            var formatter = new Intl.NumberFormat('en-US', {
                style: 'currency',
                currency: currency || 'USD'
            });
            
            return formatter.format(amount);
        },
        
        /**
         * Handle gateway change
         */
        handleGatewayChange: function(event) {
            var $select = $(event.currentTarget);
            var gateway = $select.val();
            var orderId = $select.closest('.cf7mc-inline-checkout').data('order-id');
            
            if (orderId && gateway) {
                this.initializeCheckout(orderId, gateway);
            }
        }
    };

    // Initialize when document is ready
    $(document).ready(function() {
        CF7MC_InlineCheckout.init();
    });

})(jQuery);