<?php

// Prevent direct access
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Define plugin constants for uninstall
define( 'CF7MC_PLUGIN_DIR', dirname( __FILE__ ) );
define( 'CF7MC_ORDERS_TABLE', 'cf7_mini_orders' );

// Load the schema manager
require_once CF7MC_PLUGIN_DIR . '/includes/database/schemamanager.php';

// Remove database tables
CF7MC\Database\SchemaManager::drop_tables();

// Remove plugin options
delete_option( 'cf7mc_options' );
delete_option( 'cf7mc_db_version' );

// Remove any transients
global $wpdb;
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_cf7mc_%'" );
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_cf7mc_%'" );

// Clear any cached data
wp_cache_flush();