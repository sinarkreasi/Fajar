# CF7 Mini Ecommerce - WhatsApp Setup Instructions

## Quick Setup

1. **Run the setup script** (via browser or command line):
   ```
   http://yoursite.com/wp-content/plugins/cf7-minicommerce/setup-whatsapp.php
   ```

2. **Configure WhatsApp Number**:
   - Go to WordPress Admin → CF7 Mini Ecommerce → Settings
   - Find "WhatsApp Checkout" section
   - Update "WhatsApp Business Number" from `+1234567890` to your actual number
   - Example: `+6281234567890` (include country code)

3. **Test the setup**:
   ```
   http://yoursite.com/wp-content/plugins/cf7-minicommerce/test-whatsapp.php
   ```

## Current Issues Fixed

✅ **Database columns added**: `customer_name`, `payment_session_id`, `payment_intent_id`, `metadata`
✅ **Customer name extraction**: Now properly extracts names from CF7 form fields
✅ **WhatsApp gateway configuration**: Default settings applied
✅ **Product parsing**: Handles "Product Name - $Price" format correctly
✅ **Order creation**: Works with new database schema

## How It Works

1. **Form Submission**: User submits CF7 form with product information
2. **Order Creation**: System creates order with customer details
3. **WhatsApp URL**: Generates WhatsApp message with order details
4. **Customer Contact**: Customer clicks WhatsApp button to contact you
5. **Manual Confirmation**: You manually confirm payment and update order status

## Form Field Names Supported

The system automatically detects these field names:

**Customer Name**:
- `your-name`, `name`, `customer-name`, `customer_name`
- `first-name`, `first_name`, `full-name`, `full_name`

**Customer Email**:
- `your-email`, `email`, `customer-email`, `customer_email`

**Product Information**:
- `product_id` (supports "Product Name - $Price" format)
- `product`, `product_name`, `item`, `service`
- `price`, `amount`, `cost`, `total`

## WhatsApp Message Template

The default message template includes:
- Order ID and amount
- Product details
- Customer information
- Professional formatting with emojis

You can customize this in the admin settings.

## Troubleshooting

**"Unknown column" errors**: Run `setup-whatsapp.php` to upgrade database

**"Gateway not available"**: Set WhatsApp phone number in admin settings

**"Customer" instead of real name**: Check your form field names match supported names above

**No WhatsApp URL generated**: Verify phone number is set and starts with `+`

## Next Steps

1. Set your real WhatsApp Business number
2. Test with a real Contact Form 7 form
3. Customize the message template if needed
4. Train your team on manual order confirmation process