# Prompt: Build Inline Checkout (No Redirect) for CF7 Mini Ecommerce

## Role
You are a senior WordPress plugin engineer with deep experience in:
- Payment gateway integrations (PayPal, Stripe)
- Frontend checkout UX
- Secure transaction flows
- Event-driven architectures

You are building an **Inline Checkout Engine** for a **Mini Ecommerce addon** inside the Contact Form 7 ecosystem.

This is NOT a redirect-based checkout.
Payment must happen **inside the current page / conversation flow**.

---

## Objective
Build an **Inline Checkout system** that:
- Allows users to complete payments without page reloads or redirects
- Integrates seamlessly with a Conversation Engine
- Works without WooCommerce or WordPress user accounts
- Emits clear payment lifecycle events for other addons (License, UCA, Analytics)

---

## Hard Constraints
- No WooCommerce
- No external checkout pages
- No WordPress user login
- Email is the only user identity
- Payment confirmation must be verifiable server-side
- Must support async payment flows (webhooks)

---

## Checkout Philosophy
- Conversation must NOT break during payment
- Payment is a step, not an exit
- UI must remain responsive and trustable
- Business logic lives server-side, not JS-only

---

## Supported Payment Models (Phase 1)
- One-time payment
- Fixed amount
- Dynamic amount (based on conversation answers)

(Subscription handled by separate addon)

---

## Architecture Overview

### Components
1. Inline Checkout UI (Frontend)
2. Payment Session Manager
3. Order State Machine
4. Payment Gateway Adapter
5. Event Dispatcher

---

## Order State Machine (MANDATORY)

### States
- initiated
- awaiting_payment
- processing
- paid
- failed
- cancelled
- refunded

State transitions must be explicit and logged.

---

## Inline Checkout UI Requirements

### UX Requirements
- Rendered as a step inside Conversation Engine
- Modal or embedded card-based UI
- Clear amount, currency, product summary
- Loading & processing indicators
- Error handling without page reload

### UI Behavior
- Disable navigation while payment is processing
- Show real-time payment status
- Resume conversation after successful payment

---

## Payment Session Flow

### Step 1: Initialize Checkout
Triggered when entering Payment step.

Server:
- Create order (initiated)
- Generate payment intent/session
- Return client-safe payment data

Frontend:
- Render payment UI
- Bind to payment session

---

### Step 2: Process Payment
Frontend:
- Collect payment details securely
- Submit to gateway SDK (e.g. Stripe Elements)

Backend:
- Never trust frontend success alone
- Await webhook confirmation

---

### Step 3: Confirm Payment
Payment confirmation must be based on:
- Gateway webhook
- Signed event
- Order ID matching

Only then:
- Mark order as `paid`
- Emit payment success event

---

## Payment Gateway Integration

### Adapter Pattern (Required)
Each gateway must implement:
- create_payment_session()
- confirm_payment()
- handle_webhook()
- refund_payment()

Gateways must be:
- Swappable
- Isolated from checkout UI

---

## Event System (Critical)

### Required Events
- ecommerce_order_created
- ecommerce_payment_started
- ecommerce_payment_success
- ecommerce_payment_failed
- ecommerce_payment_refunded

Other addons (License, UCA, Analytics) listen to these events.

---

## Security Requirements
- No secret keys in frontend
- CSRF protection
- Signed webhook verification
- Rate limiting on payment endpoints
- Idempotent webhook handling

---

## Failure & Recovery Handling
- Payment timeout handling
- Retry logic
- User-friendly failure messages
- Ability to re-enter payment step

---

## Integration Contracts

### Conversation Engine
- Inline checkout is a step
- Conversation pauses during payment
- Conversation resumes after success

---

### License Addon
- License generation only after `paid` state
- Never before webhook confirmation

---

### UCA / Magic Link
- Send access link after payment success
- Allow user to resume flow if browser closed

---

## Admin Configuration
- Enable / disable inline checkout per form
- Select payment gateway
- Currency & amount rules
- Test / live mode toggle

---

## Performance Requirements
- Minimal JS payload
- Lazy-load gateway SDKs
- Non-blocking webhook processing

---

## Output Expectations
Generate:
- Plugin folder structure
- PHP order & payment classes
- JS inline checkout UI
- Gateway adapter interface
- Webhook controller
- Event dispatcher

Code must be:
- Modular
- Secure
- Extensible
- Production-ready

---

## Mindset
You are NOT building a payment button.
You are building a **checkout engine inside a conversation funnel**.
The conversation must survive the payment.
