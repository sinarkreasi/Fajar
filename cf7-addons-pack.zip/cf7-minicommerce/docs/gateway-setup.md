# Payment Gateway Setup Guide

This guide will help you configure TriPay and PayPal gateways for CF7 Mini Ecommerce.

## TriPay Setup (Indonesian Payments)

### 1. Create TriPay Account
1. Visit [tripay.co.id](https://tripay.co.id)
2. Register for a merchant account
3. Complete the verification process
4. Access your merchant dashboard

### 2. Get API Credentials
1. Login to TriPay merchant dashboard
2. Go to **Settings** > **API**
3. Copy the following credentials:
   - **API Key**: Your public API key
   - **Private Key**: Your secret private key  
   - **Merchant Code**: Your unique merchant identifier

### 3. Configure in WordPress
1. Go to **CF7 Ecommerce** > **Settings**
2. Find the **TriPay** section
3. Fill in the credentials:
   ```
   Enable TriPay: ✓ Checked
   API Key: [Your API Key]
   Private Key: [Your Private Key]
   Merchant Code: [Your Merchant Code]
   Sandbox Mode: ✓ Checked (for testing)
   Default Payment Method: BRIVA (or your preference)
   ```

### 4. Configure Webhook
1. In TriPay dashboard, go to **Settings** > **Webhook**
2. Set webhook URL to: `https://yoursite.com/cf7mc-webhook/tripay/`
3. Enable all payment event notifications
4. Save the configuration

### 5. Testing
1. Keep **Sandbox Mode** enabled
2. Use TriPay test credentials
3. Test with small amounts (minimum 10,000 IDR)
4. Check order status in **CF7 Ecommerce** > **Orders**

### 6. Go Live
1. Get production credentials from TriPay
2. Update credentials in WordPress settings
3. Disable **Sandbox Mode**
4. Update webhook URL if needed

---

## PayPal Setup (International Payments)

### 1. Create PayPal Developer Account
1. Visit [developer.paypal.com](https://developer.paypal.com)
2. Login with your PayPal account
3. Go to **My Apps & Credentials**

### 2. Create Application
1. Click **Create App**
2. Choose **Default Application**
3. Select **Sandbox** for testing
4. Choose **Merchant** as account type
5. Click **Create App**

### 3. Get API Credentials
From your created app, copy:
- **Client ID**: Your application's client ID
- **Client Secret**: Your application's secret key

### 4. Configure in WordPress
1. Go to **CF7 Ecommerce** > **Settings**
2. Find the **PayPal** section
3. Fill in the credentials:
   ```
   Enable PayPal: ✓ Checked
   Client ID: [Your Client ID]
   Client Secret: [Your Client Secret]
   Sandbox Mode: ✓ Checked (for testing)
   Payment Intent: Capture (recommended)
   Brand Name: [Your Business Name]
   ```

### 5. Configure Webhook (Optional but Recommended)
1. In PayPal Developer Dashboard, go to your app
2. Click **Add Webhook**
3. Set webhook URL to: `https://yoursite.com/cf7mc-webhook/paypal/`
4. Select these events:
   - `CHECKOUT.ORDER.APPROVED`
   - `CHECKOUT.ORDER.CANCELLED`
   - `PAYMENT.CAPTURE.COMPLETED`
   - `PAYMENT.CAPTURE.DENIED`
5. Save the webhook

### 6. Testing
1. Keep **Sandbox Mode** enabled
2. Use PayPal sandbox test accounts
3. Test with various amounts and currencies
4. Check order status in **CF7 Ecommerce** > **Orders**

### 7. Go Live
1. Create a **Live** application in PayPal Developer Dashboard
2. Get production credentials
3. Update credentials in WordPress settings
4. Disable **Sandbox Mode**
5. Update webhook URL to production

---

## Currency Configuration

### Supported Currencies by Gateway

| Currency | Code | TriPay | PayPal | Mock |
|----------|------|--------|--------|------|
| US Dollar | USD | ❌ | ✅ | ✅ |
| Euro | EUR | ❌ | ✅ | ✅ |
| British Pound | GBP | ❌ | ✅ | ✅ |
| Japanese Yen | JPY | ❌ | ✅ | ✅ |
| Indonesian Rupiah | IDR | ✅ | ✅ | ✅ |

### Setting Currency
1. Go to **CF7 Ecommerce** > **Settings**
2. Set **Currency** to match your gateway:
   - **IDR** for TriPay
   - **USD/EUR/GBP/JPY** for PayPal
   - Any currency for Mock Gateway

---

## Troubleshooting

### Common Issues

**TriPay Issues:**
- **"Invalid signature"**: Check Private Key and Merchant Code
- **"Merchant not found"**: Verify Merchant Code
- **"Invalid amount"**: Ensure minimum 10,000 IDR
- **"Webhook not received"**: Check webhook URL and SSL certificate

**PayPal Issues:**
- **"Authentication failed"**: Check Client ID and Secret
- **"Invalid currency"**: Ensure currency is supported by PayPal
- **"Order not found"**: Check webhook configuration
- **"Sandbox errors"**: Ensure using sandbox credentials in sandbox mode

### Debug Mode
1. Enable WordPress debug mode in `wp-config.php`:
   ```php
   define('WP_DEBUG', true);
   define('WP_DEBUG_LOG', true);
   ```
2. Check `/wp-content/debug.log` for CF7MC error messages
3. Look for `[CF7MC]` prefixed log entries

### Testing Checklist
- [ ] Gateway credentials configured correctly
- [ ] Webhook URL accessible (returns 200 status)
- [ ] SSL certificate valid
- [ ] Currency matches gateway requirements
- [ ] Minimum amount requirements met
- [ ] Test mode enabled during testing
- [ ] Debug logging enabled

### Support
- Check plugin documentation
- Review error logs
- Test with Mock Gateway first
- Verify gateway-specific requirements
- Contact gateway support for API issues