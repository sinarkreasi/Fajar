<?php
/*
 * Plugin Name: CF7 Mini Ecommerce
 * Plugin URI: https://github.com/cf7-minicommerce/cf7-minicommerce
 * Description: Lightweight ecommerce addon for Contact Form 7. Transform CF7 forms into instant checkout forms for services, digital products, donations, or bookings.
 * Author: CF7 Mini Ecommerce Team
 * Version: 1.0.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Text Domain: cf7-minicommerce
 * Domain Path: /languages
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Plugin version
define( 'CF7MC_VERSION', '1.0.0' );

// Plugin constants
define( 'CF7MC_PLUGIN_FILE', __FILE__ );
define( 'CF7MC_PLUGIN_BASENAME', plugin_basename( CF7MC_PLUGIN_FILE ) );
define( 'CF7MC_PLUGIN_DIR', untrailingslashit( dirname( CF7MC_PLUGIN_FILE ) ) );
define( 'CF7MC_PLUGIN_URL', untrailingslashit( plugins_url( '', CF7MC_PLUGIN_FILE ) ) );
define( 'CF7MC_TEXT_DOMAIN', 'cf7-minicommerce' );

// Database table name
define( 'CF7MC_ORDERS_TABLE', 'cf7_mini_orders' );

// Check if Contact Form 7 is active
add_action( 'plugins_loaded', 'cf7mc_check_dependencies' );

function cf7mc_check_dependencies() {
	if ( ! class_exists( 'WPCF7' ) ) {
		add_action( 'admin_notices', 'cf7mc_cf7_missing_notice' );
		return;
	}
	
	// Initialize plugin
	cf7mc_init();
}

function cf7mc_cf7_missing_notice() {
	?>
	<div class="notice notice-error">
		<p><?php _e( 'CF7 Mini Ecommerce requires Contact Form 7 to be installed and activated.', CF7MC_TEXT_DOMAIN ); ?></p>
	</div>
	<?php
}

// Load plugin files
require_once CF7MC_PLUGIN_DIR . '/load.php';

// Plugin activation hook
register_activation_hook( CF7MC_PLUGIN_FILE, 'cf7mc_activate' );

// Plugin deactivation hook
register_deactivation_hook( CF7MC_PLUGIN_FILE, 'cf7mc_deactivate' );

/**
 * Plugin activation callback
 */
function cf7mc_activate() {
	// Create database tables
	CF7MC\Database\SchemaManager::create_tables();
	
	// Set default options
	CF7MC\Core\OptionsManager::set_defaults();
	
	// Flush rewrite rules
	flush_rewrite_rules();
}

/**
 * Plugin deactivation callback
 */
function cf7mc_deactivate() {
	// Flush rewrite rules
	flush_rewrite_rules();
}