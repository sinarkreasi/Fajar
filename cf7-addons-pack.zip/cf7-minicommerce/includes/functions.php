<?php

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Get plugin option
 *
 * @param string $name Option name
 * @param mixed $default Default value
 * @return mixed
 */
function cf7mc_get_option( $name, $default = false ) {
	$options = get_option( 'cf7mc_options', array() );
	return isset( $options[ $name ] ) ? $options[ $name ] : $default;
}

/**
 * Update plugin option
 *
 * @param string $name Option name
 * @param mixed $value Option value
 */
function cf7mc_update_option( $name, $value ) {
	$options = get_option( 'cf7mc_options', array() );
	$options[ $name ] = $value;
	update_option( 'cf7mc_options', $options );
}

/**
 * Generate unique order code
 *
 * @return string
 */
function cf7mc_generate_order_code() {
	return 'CF7MC-' . strtoupper( wp_generate_password( 8, false ) );
}

/**
 * Sanitize price amount
 *
 * @param mixed $amount
 * @return float
 */
function cf7mc_sanitize_amount( $amount ) {
	return floatval( str_replace( ',', '', $amount ) );
}

/**
 * Format price for display
 *
 * @param float $amount
 * @param string $currency
 * @return string
 */
function cf7mc_format_price( $amount, $currency = 'USD' ) {
	$currency_symbols = array(
		'USD' => '$',
		'EUR' => '€',
		'GBP' => '£',
		'JPY' => '¥',
		'IDR' => 'Rp',
	);
	
	$symbol = isset( $currency_symbols[ $currency ] ) ? $currency_symbols[ $currency ] : $currency . ' ';
	
	return $symbol . number_format( $amount, 2 );
}

/**
 * Get order statuses
 *
 * @return array
 */
function cf7mc_get_order_statuses() {
	return array(
		'initiated' => __( 'Initiated', CF7MC_TEXT_DOMAIN ),
		'awaiting_payment' => __( 'Awaiting Payment', CF7MC_TEXT_DOMAIN ),
		'processing' => __( 'Processing', CF7MC_TEXT_DOMAIN ),
		'paid' => __( 'Paid', CF7MC_TEXT_DOMAIN ),
		'failed' => __( 'Failed', CF7MC_TEXT_DOMAIN ),
		'cancelled' => __( 'Cancelled', CF7MC_TEXT_DOMAIN ),
		'refunded' => __( 'Refunded', CF7MC_TEXT_DOMAIN ),
	);
}

/**
 * Log debug message
 *
 * @param string $message
 * @param string $level
 */
function cf7mc_log( $message, $level = 'info' ) {
	if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
		// Ensure message is a string
		if ( ! is_string( $message ) ) {
			$message = print_r( $message, true );
		}
		
		error_log( sprintf( '[CF7MC %s] %s', strtoupper( $level ), $message ) );
	}
}

/**
 * Verify nonce for security
 *
 * @param string $nonce
 * @param string $action
 * @return bool
 */
function cf7mc_verify_nonce( $nonce, $action ) {
	return wp_verify_nonce( $nonce, $action );
}

/**
 * Get available payment gateways
 *
 * @return array
 */
function cf7mc_get_available_gateways() {
	try {
		$gateway_manager = new CF7MC\Core\GatewayManager();
		return $gateway_manager->get_enabled_gateways();
	} catch ( Exception $e ) {
		cf7mc_log( 'Failed to get available gateways: ' . $e->getMessage(), 'error' );
		return array();
	}
}

/**
 * Get gateway by ID
 *
 * @param string $gateway_id
 * @return \CF7MC\Interfaces\PaymentGatewayInterface|null
 */
function cf7mc_get_gateway( $gateway_id ) {
	try {
		$gateway_manager = new CF7MC\Core\GatewayManager();
		return $gateway_manager->get_gateway( $gateway_id );
	} catch ( Exception $e ) {
		cf7mc_log( 'Failed to get gateway: ' . $e->getMessage(), 'error' );
		return null;
	}
}

/**
 * Get gateway option
 *
 * @param string $gateway_id
 * @param string $option_name
 * @param mixed $default
 * @return mixed
 */
function cf7mc_get_gateway_option( $gateway_id, $option_name, $default = '' ) {
	$options = get_option( 'cf7mc_options', array() );
	$gateway_options = isset( $options['gateways'][ $gateway_id ] ) ? $options['gateways'][ $gateway_id ] : array();
	return isset( $gateway_options[ $option_name ] ) ? $gateway_options[ $option_name ] : $default;
}

/**
 * Update gateway option
 *
 * @param string $gateway_id
 * @param string $option_name
 * @param mixed $value
 */
function cf7mc_update_gateway_option( $gateway_id, $option_name, $value ) {
	$options = get_option( 'cf7mc_options', array() );
	if ( ! isset( $options['gateways'] ) ) {
		$options['gateways'] = array();
	}
	if ( ! isset( $options['gateways'][ $gateway_id ] ) ) {
		$options['gateways'][ $gateway_id ] = array();
	}
	$options['gateways'][ $gateway_id ][ $option_name ] = $value;
	update_option( 'cf7mc_options', $options );
}
/**
 * Enable ecommerce for all CF7 forms (for testing)
 */
function cf7mc_enable_for_all_forms() {
	cf7mc_update_option( 'enable_for_all_forms', true );
	cf7mc_log( 'Ecommerce enabled for all CF7 forms' );
}

/**
 * Disable ecommerce for all CF7 forms
 */
function cf7mc_disable_for_all_forms() {
	cf7mc_update_option( 'enable_for_all_forms', false );
	cf7mc_log( 'Ecommerce disabled for all CF7 forms' );
}