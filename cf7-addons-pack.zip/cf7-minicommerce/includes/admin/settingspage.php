<?php

namespace CF7MC\Admin;

use CF7MC\Core\OptionsManager;
use CF7MC\Core\GatewayManager;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Settings page class
 */
class SettingsPage {
	
	/**
	 * Display settings page
	 */
	public function display() {
		if ( isset( $_POST['submit'] ) ) {
			$this->save_settings();
		}
		
		$options = OptionsManager::get_all_options();
		$gateway_manager = new GatewayManager();
		$gateways = $gateway_manager->get_all_gateways();
		
		?>
		<div class="wrap">
			<h1><?php _e( 'CF7 Mini Ecommerce Settings', CF7MC_TEXT_DOMAIN ); ?></h1>
			
			<form method="post" action="">
				<?php wp_nonce_field( 'cf7mc_settings', 'cf7mc_settings_nonce' ); ?>
				
				<table class="form-table">
					<tr>
						<th scope="row"><?php _e( 'Currency', CF7MC_TEXT_DOMAIN ); ?></th>
						<td>
							<select name="currency">
								<option value="USD" <?php selected( $options['currency'] ?? 'USD', 'USD' ); ?>>USD ($)</option>
								<option value="EUR" <?php selected( $options['currency'] ?? 'USD', 'EUR' ); ?>>EUR (€)</option>
								<option value="GBP" <?php selected( $options['currency'] ?? 'USD', 'GBP' ); ?>>GBP (£)</option>
								<option value="JPY" <?php selected( $options['currency'] ?? 'USD', 'JPY' ); ?>>JPY (¥)</option>
								<option value="IDR" <?php selected( $options['currency'] ?? 'USD', 'IDR' ); ?>>IDR (Rp)</option>
							</select>
						</td>
					</tr>
					
					<tr>
						<th scope="row"><?php _e( 'Minimum Amount', CF7MC_TEXT_DOMAIN ); ?></th>
						<td>
							<input type="number" name="minimum_amount" value="<?php echo esc_attr( $options['minimum_amount'] ?? 1 ); ?>" step="0.01" min="0" />
							<p class="description"><?php _e( 'Minimum order amount allowed.', CF7MC_TEXT_DOMAIN ); ?></p>
						</td>
					</tr>
					
					<tr>
						<th scope="row"><?php _e( 'Order Expiry (Hours)', CF7MC_TEXT_DOMAIN ); ?></th>
						<td>
							<input type="number" name="order_expiry_hours" value="<?php echo esc_attr( $options['order_expiry_hours'] ?? 24 ); ?>" min="1" />
							<p class="description"><?php _e( 'Hours after which unpaid orders expire.', CF7MC_TEXT_DOMAIN ); ?></p>
						</td>
					</tr>
					
					<tr>
						<th scope="row"><?php _e( 'Default Gateway', CF7MC_TEXT_DOMAIN ); ?></th>
						<td>
							<select name="default_gateway">
								<?php foreach ( $gateways as $gateway_id => $gateway ) : ?>
									<option value="<?php echo esc_attr( $gateway_id ); ?>" <?php selected( $options['default_gateway'] ?? '', $gateway_id ); ?>>
										<?php echo esc_html( $gateway->get_title() ); ?>
									</option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
				</table>
				
				<h2><?php _e( 'Email Notifications', CF7MC_TEXT_DOMAIN ); ?></h2>
				<table class="form-table">
					<tr>
						<th scope="row"><?php _e( 'Admin Email', CF7MC_TEXT_DOMAIN ); ?></th>
						<td>
							<input type="email" name="admin_email" value="<?php echo esc_attr( $options['email_notifications']['admin_email'] ?? get_option( 'admin_email' ) ); ?>" class="regular-text" />
						</td>
					</tr>
					
					<tr>
						<th scope="row"><?php _e( 'Notifications', CF7MC_TEXT_DOMAIN ); ?></th>
						<td>
							<label>
								<input type="checkbox" name="admin_new_order" value="1" <?php checked( $options['email_notifications']['admin_new_order'] ?? false ); ?> />
								<?php _e( 'Send admin notification for new orders', CF7MC_TEXT_DOMAIN ); ?>
							</label><br />
							
							<label>
								<input type="checkbox" name="customer_paid" value="1" <?php checked( $options['email_notifications']['customer_paid'] ?? false ); ?> />
								<?php _e( 'Send customer notification when payment is confirmed', CF7MC_TEXT_DOMAIN ); ?>
							</label>
						</td>
					</tr>
				</table>
				
				<h2><?php _e( 'Payment Gateways', CF7MC_TEXT_DOMAIN ); ?></h2>
				<?php foreach ( $gateways as $gateway_id => $gateway ) : ?>
					<?php $this->display_gateway_settings( $gateway_id, $gateway, $options ); ?>
				<?php endforeach; ?>
				
				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}
	
	/**
	 * Display gateway settings
	 *
	 * @param string $gateway_id
	 * @param object $gateway
	 * @param array $options
	 */
	private function display_gateway_settings( $gateway_id, $gateway, $options ) {
		$gateway_options = $options['gateways'][ $gateway_id ] ?? array();
		$config_fields = $gateway->get_config_fields();
		
		?>
		<h3><?php echo esc_html( $gateway->get_title() ); ?></h3>
		<p><?php echo esc_html( $gateway->get_description() ); ?></p>
		
		<table class="form-table">
			<?php foreach ( $config_fields as $field_id => $field ) : ?>
				<tr>
					<th scope="row"><?php echo esc_html( $field['title'] ); ?></th>
					<td>
						<?php $this->display_field( $gateway_id, $field_id, $field, $gateway_options ); ?>
						<?php if ( ! empty( $field['description'] ) ) : ?>
							<p class="description"><?php echo esc_html( $field['description'] ); ?></p>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
		</table>
		<?php
	}
	
	/**
	 * Display form field
	 *
	 * @param string $gateway_id
	 * @param string $field_id
	 * @param array $field
	 * @param array $gateway_options
	 */
	private function display_field( $gateway_id, $field_id, $field, $gateway_options ) {
		$name = "gateways[{$gateway_id}][{$field_id}]";
		$value = $gateway_options[ $field_id ] ?? $field['default'] ?? '';
		
		switch ( $field['type'] ) {
			case 'select':
				$options_html = '';
				if ( isset( $field['options'] ) && is_array( $field['options'] ) ) {
					foreach ( $field['options'] as $option_value => $option_label ) {
						$selected = selected( $value, $option_value, false );
						$options_html .= sprintf( '<option value="%s" %s>%s</option>', esc_attr( $option_value ), $selected, esc_html( $option_label ) );
					}
				}
				printf(
					'<select name="%s">%s</select>',
					esc_attr( $name ),
					$options_html
				);
				break;
				
			case 'checkbox':
				printf(
					'<input type="checkbox" name="%s" value="1" %s />',
					esc_attr( $name ),
					checked( $value, 1, false )
				);
				break;
				
			case 'password':
				printf(
					'<input type="password" name="%s" value="%s" class="regular-text" />',
					esc_attr( $name ),
					esc_attr( $value )
				);
				break;
				
			case 'textarea':
				printf(
					'<textarea name="%s" rows="5" cols="50">%s</textarea>',
					esc_attr( $name ),
					esc_textarea( $value )
				);
				break;
				
			default:
				printf(
					'<input type="text" name="%s" value="%s" class="regular-text" />',
					esc_attr( $name ),
					esc_attr( $value )
				);
				break;
		}
	}
	
	/**
	 * Save settings
	 */
	private function save_settings() {
		if ( ! wp_verify_nonce( $_POST['cf7mc_settings_nonce'] ?? '', 'cf7mc_settings' ) ) {
			wp_die( __( 'Security check failed.', CF7MC_TEXT_DOMAIN ) );
		}
		
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( __( 'You do not have permission to access this page.', CF7MC_TEXT_DOMAIN ) );
		}
		
		$options = OptionsManager::get_all_options();
		
		// Update general settings
		$options['currency'] = sanitize_text_field( $_POST['currency'] ?? 'USD' );
		$options['minimum_amount'] = floatval( $_POST['minimum_amount'] ?? 1 );
		$options['order_expiry_hours'] = intval( $_POST['order_expiry_hours'] ?? 24 );
		$options['default_gateway'] = sanitize_text_field( $_POST['default_gateway'] ?? '' );
		
		// Update email settings
		$options['email_notifications']['admin_email'] = sanitize_email( $_POST['admin_email'] ?? get_option( 'admin_email' ) );
		$options['email_notifications']['admin_new_order'] = ! empty( $_POST['admin_new_order'] );
		$options['email_notifications']['customer_paid'] = ! empty( $_POST['customer_paid'] );
		
		// Update gateway settings
		if ( isset( $_POST['gateways'] ) && is_array( $_POST['gateways'] ) ) {
			foreach ( $_POST['gateways'] as $gateway_id => $gateway_settings ) {
				$gateway_id = sanitize_text_field( $gateway_id );
				$options['gateways'][ $gateway_id ] = array_map( 'sanitize_text_field', $gateway_settings );
			}
		}
		
		update_option( 'cf7mc_options', $options );
		
		echo '<div class="notice notice-success"><p>' . __( 'Settings saved successfully.', CF7MC_TEXT_DOMAIN ) . '</p></div>';
	}
}