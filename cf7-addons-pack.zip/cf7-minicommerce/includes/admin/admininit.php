<?php

namespace CF7MC\Admin;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin initialization class
 */
class AdminInit {
	
	/**
	 * Instance
	 *
	 * @var AdminInit
	 */
	private static $instance = null;
	
	/**
	 * Get instance
	 *
	 * @return AdminInit
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		$this->init_hooks();
	}
	
	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
		add_action( 'admin_init', array( $this, 'maybe_upgrade_database' ) );
		add_action( 'wp_ajax_cf7mc_update_order_status', array( $this, 'handle_ajax_update_order_status' ) );
	}
	
	/**
	 * Add admin menu
	 */
	public function add_admin_menu() {
		add_menu_page(
			__( 'CF7 Mini Ecommerce', CF7MC_TEXT_DOMAIN ),
			__( 'CF7 Ecommerce', CF7MC_TEXT_DOMAIN ),
			'manage_options',
			'cf7mc-orders',
			array( $this, 'orders_page' ),
			'dashicons-cart',
			30
		);
		
		add_submenu_page(
			'cf7mc-orders',
			__( 'Orders', CF7MC_TEXT_DOMAIN ),
			__( 'Orders', CF7MC_TEXT_DOMAIN ),
			'manage_options',
			'cf7mc-orders',
			array( $this, 'orders_page' )
		);
		
		add_submenu_page(
			'cf7mc-orders',
			__( 'Settings', CF7MC_TEXT_DOMAIN ),
			__( 'Settings', CF7MC_TEXT_DOMAIN ),
			'manage_options',
			'cf7mc-settings',
			array( $this, 'settings_page' )
		);
	}
	
	/**
	 * Enqueue admin scripts
	 *
	 * @param string $hook
	 */
	public function enqueue_admin_scripts( $hook ) {
		if ( strpos( $hook, 'cf7mc' ) === false ) {
			return;
		}
		
		wp_enqueue_script(
			'cf7mc-admin',
			CF7MC_PLUGIN_URL . '/assets/js/admin.js',
			array( 'jquery' ),
			CF7MC_VERSION,
			true
		);
		
		wp_localize_script( 'cf7mc-admin', 'cf7mc_admin', array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'cf7mc_admin' ),
		));
		
		wp_enqueue_style(
			'cf7mc-admin',
			CF7MC_PLUGIN_URL . '/assets/css/admin.css',
			array(),
			CF7MC_VERSION
		);
	}
	
	/**
	 * Maybe upgrade database
	 */
	public function maybe_upgrade_database() {
		\CF7MC\Database\SchemaManager::maybe_upgrade();
	}
	
	/**
	 * Orders page
	 */
	public function orders_page() {
		$orders_table = new OrdersTable();
		$orders_table->prepare_items();
		
		?>
		<div class="wrap">
			<h1><?php _e( 'CF7 Mini Ecommerce Orders', CF7MC_TEXT_DOMAIN ); ?></h1>
			
			<form method="get">
				<input type="hidden" name="page" value="cf7mc-orders" />
				<?php $orders_table->search_box( __( 'Search Orders', CF7MC_TEXT_DOMAIN ), 'order' ); ?>
			</form>
			
			<?php $orders_table->display(); ?>
		</div>
		<?php
	}
	
	/**
	 * Settings page
	 */
	public function settings_page() {
		$settings = new SettingsPage();
		$settings->display();
	}
	
	/**
	 * Handle AJAX order status update
	 */
	public function handle_ajax_update_order_status() {
		if ( ! wp_verify_nonce( $_POST['nonce'] ?? '', 'cf7mc_admin' ) ) {
			wp_send_json_error( __( 'Invalid nonce.', CF7MC_TEXT_DOMAIN ) );
		}
		
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( __( 'Insufficient permissions.', CF7MC_TEXT_DOMAIN ) );
		}
		
		$order_id = intval( $_POST['order_id'] ?? 0 );
		$status = sanitize_text_field( $_POST['status'] ?? '' );
		
		if ( ! $order_id || ! $status ) {
			wp_send_json_error( __( 'Invalid parameters.', CF7MC_TEXT_DOMAIN ) );
		}
		
		$order_manager = new \CF7MC\Core\OrderManager();
		$result = $order_manager->update_order_status( $order_id, $status );
		
		if ( $result ) {
			wp_send_json_success( array( 'status' => $status ) );
		} else {
			wp_send_json_error( __( 'Failed to update order status.', CF7MC_TEXT_DOMAIN ) );
		}
	}
}