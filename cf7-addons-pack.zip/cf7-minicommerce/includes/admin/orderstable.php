<?php

namespace CF7MC\Admin;

use CF7MC\Core\OrderManager;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Load WP_List_Table if not loaded
if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

/**
 * Orders table class
 */
class OrdersTable extends \WP_List_Table {
	
	/**
	 * Constructor
	 */
	public function __construct() {
		parent::__construct( array(
			'singular' => 'order',
			'plural'   => 'orders',
			'ajax'     => false,
		) );
	}
	
	/**
	 * Get columns
	 *
	 * @return array
	 */
	public function get_columns() {
		return array(
			'cb'           => '<input type="checkbox" />',
			'order_code'   => __( 'Order Code', CF7MC_TEXT_DOMAIN ),
			'email'        => __( 'Customer Email', CF7MC_TEXT_DOMAIN ),
			'total_amount' => __( 'Total Amount', CF7MC_TEXT_DOMAIN ),
			'status'       => __( 'Status', CF7MC_TEXT_DOMAIN ),
			'gateway'      => __( 'Gateway', CF7MC_TEXT_DOMAIN ),
			'created_at'   => __( 'Created', CF7MC_TEXT_DOMAIN ),
			'paid_at'      => __( 'Paid', CF7MC_TEXT_DOMAIN ),
		);
	}
	
	/**
	 * Get sortable columns
	 *
	 * @return array
	 */
	public function get_sortable_columns() {
		return array(
			'order_code'   => array( 'order_code', false ),
			'email'        => array( 'email', false ),
			'total_amount' => array( 'total_amount', false ),
			'status'       => array( 'status', false ),
			'created_at'   => array( 'created_at', true ),
			'paid_at'      => array( 'paid_at', false ),
		);
	}
	
	/**
	 * Get bulk actions
	 *
	 * @return array
	 */
	public function get_bulk_actions() {
		return array(
			'delete' => __( 'Delete', CF7MC_TEXT_DOMAIN ),
		);
	}
	
	/**
	 * Column checkbox
	 *
	 * @param array $item
	 * @return string
	 */
	public function column_cb( $item ) {
		return sprintf( '<input type="checkbox" name="order[]" value="%s" />', $item['id'] );
	}
	
	/**
	 * Column order code
	 *
	 * @param array $item
	 * @return string
	 */
	public function column_order_code( $item ) {
		$actions = array(
			'view' => sprintf(
				'<a href="?page=%s&action=%s&order=%s">%s</a>',
				$_REQUEST['page'],
				'view',
				$item['id'],
				__( 'View', CF7MC_TEXT_DOMAIN )
			),
			'delete' => sprintf(
				'<a href="?page=%s&action=%s&order=%s" onclick="return confirm(\'%s\')">%s</a>',
				$_REQUEST['page'],
				'delete',
				$item['id'],
				__( 'Are you sure you want to delete this order?', CF7MC_TEXT_DOMAIN ),
				__( 'Delete', CF7MC_TEXT_DOMAIN )
			),
		);
		
		return sprintf( '%1$s %2$s', $item['order_code'], $this->row_actions( $actions ) );
	}
	
	/**
	 * Column email
	 *
	 * @param array $item
	 * @return string
	 */
	public function column_email( $item ) {
		return sprintf( '<a href="mailto:%s">%s</a>', $item['email'], $item['email'] );
	}
	
	/**
	 * Column total amount
	 *
	 * @param array $item
	 * @return string
	 */
	public function column_total_amount( $item ) {
		$currency = cf7mc_get_option( 'currency', 'USD' );
		return cf7mc_format_price( $item['total_amount'], $currency );
	}
	
	/**
	 * Column status
	 *
	 * @param array $item
	 * @return string
	 */
	public function column_status( $item ) {
		$statuses = cf7mc_get_order_statuses();
		$status_label = isset( $statuses[ $item['status'] ] ) ? $statuses[ $item['status'] ] : $item['status'];
		
		$class = 'cf7mc-status-' . $item['status'];
		
		return sprintf( '<span class="%s">%s</span>', $class, $status_label );
	}
	
	/**
	 * Column gateway
	 *
	 * @param array $item
	 * @return string
	 */
	public function column_gateway( $item ) {
		return ucfirst( $item['gateway'] );
	}
	
	/**
	 * Column created at
	 *
	 * @param array $item
	 * @return string
	 */
	public function column_created_at( $item ) {
		return date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $item['created_at'] ) );
	}
	
	/**
	 * Column paid at
	 *
	 * @param array $item
	 * @return string
	 */
	public function column_paid_at( $item ) {
		if ( empty( $item['paid_at'] ) ) {
			return '—';
		}
		
		return date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $item['paid_at'] ) );
	}
	
	/**
	 * Default column
	 *
	 * @param array $item
	 * @param string $column_name
	 * @return string
	 */
	public function column_default( $item, $column_name ) {
		return isset( $item[ $column_name ] ) ? $item[ $column_name ] : '';
	}
	
	/**
	 * Prepare items
	 */
	public function prepare_items() {
		$per_page = 20;
		$current_page = $this->get_pagenum();
		
		$orderby = isset( $_GET['orderby'] ) ? sanitize_text_field( $_GET['orderby'] ) : 'created_at';
		$order = isset( $_GET['order'] ) ? sanitize_text_field( $_GET['order'] ) : 'DESC';
		
		$search = isset( $_GET['s'] ) ? sanitize_text_field( $_GET['s'] ) : '';
		
		$order_manager = new OrderManager();
		
		$args = array(
			'per_page' => $per_page,
			'page'     => $current_page,
			'orderby'  => $orderby,
			'order'    => $order,
		);
		
		if ( ! empty( $search ) ) {
			$args['search'] = $search;
		}
		
		$result = $order_manager->get_orders( $args );
		
		$this->items = $result['orders'];
		
		$this->set_pagination_args( array(
			'total_items' => $result['total'],
			'per_page'    => $per_page,
		) );
		
		$columns = $this->get_columns();
		$hidden = array();
		$sortable = $this->get_sortable_columns();
		
		$this->_column_headers = array( $columns, $hidden, $sortable );
	}
}