<?php

namespace CF7MC\Database;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Database schema management class
 */
class SchemaManager {
	
	/**
	 * Create database tables
	 */
	public static function create_tables() {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7MC_ORDERS_TABLE;
		
		$charset_collate = $wpdb->get_charset_collate();
		
		$sql = "CREATE TABLE $table_name (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			order_code varchar(50) NOT NULL,
			email varchar(100) NOT NULL,
			customer_name varchar(255) DEFAULT NULL,
			items longtext NOT NULL,
			total_amount decimal(10,2) NOT NULL DEFAULT 0.00,
			gateway varchar(50) NOT NULL,
			gateway_payment_id varchar(255) DEFAULT NULL,
			payment_session_id varchar(255) DEFAULT NULL,
			payment_intent_id varchar(255) DEFAULT NULL,
			metadata longtext DEFAULT NULL,
			status varchar(20) NOT NULL DEFAULT 'initiated',
			created_at datetime NOT NULL,
			paid_at datetime DEFAULT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY order_code (order_code),
			KEY email (email),
			KEY status (status),
			KEY created_at (created_at),
			KEY payment_session_id (payment_session_id),
			KEY payment_intent_id (payment_intent_id)
		) $charset_collate;";
		
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );
		
		// Check if table was created successfully
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) !== $table_name ) {
			cf7mc_log( 'Failed to create orders table', 'error' );
		} else {
			cf7mc_log( 'Orders table created successfully' );
		}
		
		// Update database version
		update_option( 'cf7mc_db_version', CF7MC_VERSION );
	}
	
	/**
	 * Drop database tables (for uninstall)
	 */
	public static function drop_tables() {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7MC_ORDERS_TABLE;
		
		$wpdb->query( "DROP TABLE IF EXISTS $table_name" );
		
		// Remove database version option
		delete_option( 'cf7mc_db_version' );
	}
	
	/**
	 * Check if database needs upgrade
	 *
	 * @return bool
	 */
	public static function needs_upgrade() {
		$current_version = get_option( 'cf7mc_db_version', '0' );
		return version_compare( $current_version, CF7MC_VERSION, '<' );
	}
	
	/**
	 * Upgrade database if needed
	 */
	public static function maybe_upgrade() {
		if ( self::needs_upgrade() ) {
			self::upgrade_tables();
		}
	}
	
	/**
	 * Upgrade existing tables
	 */
	public static function upgrade_tables() {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7MC_ORDERS_TABLE;
		
		// Check if table exists
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) !== $table_name ) {
			// Table doesn't exist, create it
			self::create_tables();
			return;
		}
		
		// Check for missing columns and add them
		$columns = $wpdb->get_col( "DESCRIBE $table_name", 0 );
		
		$required_columns = array(
			'customer_name' => "ALTER TABLE $table_name ADD COLUMN customer_name varchar(255) DEFAULT NULL",
			'payment_session_id' => "ALTER TABLE $table_name ADD COLUMN payment_session_id varchar(255) DEFAULT NULL",
			'payment_intent_id' => "ALTER TABLE $table_name ADD COLUMN payment_intent_id varchar(255) DEFAULT NULL",
			'gateway_payment_id' => "ALTER TABLE $table_name ADD COLUMN gateway_payment_id varchar(255) DEFAULT NULL",
			'metadata' => "ALTER TABLE $table_name ADD COLUMN metadata longtext DEFAULT NULL",
		);
		
		foreach ( $required_columns as $column => $sql ) {
			if ( ! in_array( $column, $columns ) ) {
				cf7mc_log( "Adding missing column: $column" );
				$wpdb->query( $sql );
				
				// Add index for session and intent IDs
				if ( $column === 'payment_session_id' ) {
					$wpdb->query( "ALTER TABLE $table_name ADD KEY payment_session_id (payment_session_id)" );
				}
				if ( $column === 'payment_intent_id' ) {
					$wpdb->query( "ALTER TABLE $table_name ADD KEY payment_intent_id (payment_intent_id)" );
				}
			}
		}
		
		// Update status column if it's too small
		$status_column = $wpdb->get_row( "SHOW COLUMNS FROM $table_name LIKE 'status'" );
		if ( $status_column && strpos( $status_column->Type, 'varchar(10)' ) !== false ) {
			cf7mc_log( "Upgrading status column size" );
			$wpdb->query( "ALTER TABLE $table_name MODIFY COLUMN status varchar(20) NOT NULL DEFAULT 'initiated'" );
		}
		
		// Update database version
		update_option( 'cf7mc_db_version', CF7MC_VERSION );
		
		cf7mc_log( 'Database upgrade completed' );
	}
	
	/**
	 * Get table name with prefix
	 *
	 * @return string
	 */
	public static function get_orders_table_name() {
		global $wpdb;
		return $wpdb->prefix . CF7MC_ORDERS_TABLE;
	}
}