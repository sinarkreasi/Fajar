<?php

namespace CF7MC\Core;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Order management class
 */
class OrderManager {
	
	/**
	 * Valid order states
	 */
	const VALID_STATES = array(
		'initiated',
		'awaiting_payment',
		'processing',
		'paid',
		'failed',
		'cancelled',
		'refunded'
	);
	
	/**
	 * Valid state transitions
	 */
	const STATE_TRANSITIONS = array(
		'initiated' => array( 'awaiting_payment', 'cancelled' ),
		'awaiting_payment' => array( 'processing', 'failed', 'cancelled' ),
		'processing' => array( 'paid', 'failed' ),
		'paid' => array( 'refunded' ),
		'failed' => array( 'awaiting_payment', 'cancelled' ),
		'cancelled' => array(),
		'refunded' => array()
	);
	
	/**
	 * Create new order
	 *
	 * @param array $order_data
	 * @return int|false Order ID or false on failure
	 */
	public function create_order( $order_data ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7MC_ORDERS_TABLE;
		
		// Check which columns exist in the table
		$existing_columns = $wpdb->get_col( "DESCRIBE $table_name", 0 );
		
		$defaults = array(
			'order_code'    => cf7mc_generate_order_code(),
			'email'         => '',
			'customer_name' => '',
			'items'         => '[]',
			'total_amount'  => 0,
			'gateway'       => '',
			'status'        => 'initiated',
			'created_at'    => current_time( 'mysql' ),
			'paid_at'       => null,
		);
		
		// Add new columns only if they exist
		if ( in_array( 'customer_name', $existing_columns ) ) {
			$defaults['customer_name'] = '';
		}
		if ( in_array( 'payment_session_id', $existing_columns ) ) {
			$defaults['payment_session_id'] = '';
		}
		if ( in_array( 'payment_intent_id', $existing_columns ) ) {
			$defaults['payment_intent_id'] = '';
		}
		if ( in_array( 'metadata', $existing_columns ) ) {
			$defaults['metadata'] = '{}';
		}
		
		$order_data = wp_parse_args( $order_data, $defaults );
		
		// Sanitize data
		$order_data['email'] = sanitize_email( $order_data['email'] );
		$order_data['total_amount'] = cf7mc_sanitize_amount( $order_data['total_amount'] );
		$order_data['gateway'] = sanitize_text_field( $order_data['gateway'] );
		$order_data['status'] = sanitize_text_field( $order_data['status'] );
		
		if ( isset( $order_data['customer_name'] ) ) {
			$order_data['customer_name'] = sanitize_text_field( $order_data['customer_name'] );
		}
		if ( isset( $order_data['payment_session_id'] ) ) {
			$order_data['payment_session_id'] = sanitize_text_field( $order_data['payment_session_id'] );
		}
		if ( isset( $order_data['payment_intent_id'] ) ) {
			$order_data['payment_intent_id'] = sanitize_text_field( $order_data['payment_intent_id'] );
		}
		
		// Ensure items is JSON
		if ( is_array( $order_data['items'] ) ) {
			$order_data['items'] = wp_json_encode( $order_data['items'] );
		}
		
		// Ensure metadata is JSON
		if ( isset( $order_data['metadata'] ) ) {
			if ( is_array( $order_data['metadata'] ) ) {
				$order_data['metadata'] = wp_json_encode( $order_data['metadata'] );
			}
		}
		
		// Build format array based on existing columns
		$format = array();
		$insert_data = array();
		
		foreach ( $order_data as $key => $value ) {
			if ( in_array( $key, $existing_columns ) ) {
				$insert_data[ $key ] = $value;
				
				// Set appropriate format
				if ( $key === 'total_amount' ) {
					$format[] = '%f';
				} else {
					$format[] = '%s';
				}
			}
		}
		
		$result = $wpdb->insert( $table_name, $insert_data, $format );
		
		if ( $result === false ) {
			cf7mc_log( 'Failed to create order: ' . $wpdb->last_error, 'error' );
			return false;
		}
		
		$order_id = $wpdb->insert_id;
		
		// Log state transition
		$this->log_state_transition( $order_id, '', $order_data['status'] );
		
		do_action( 'cf7mc_order_created', $order_id, $order_data );
		do_action( 'ecommerce_order_created', $order_id, $order_data );
		
		return $order_id;
	}
	
	/**
	 * Get order by ID
	 *
	 * @param int $order_id
	 * @return array|null
	 */
	public function get_order( $order_id ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7MC_ORDERS_TABLE;
		
		$order = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table_name} WHERE id = %d", $order_id ),
			ARRAY_A
		);
		
		if ( $order ) {
			$order['items'] = json_decode( $order['items'], true );
		}
		
		return $order;
	}
	
	/**
	 * Get order by order code
	 *
	 * @param string $order_code
	 * @return array|null
	 */
	public function get_order_by_code( $order_code ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7MC_ORDERS_TABLE;
		
		$order = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table_name} WHERE order_code = %s", $order_code ),
			ARRAY_A
		);
		
		if ( $order ) {
			$order['items'] = json_decode( $order['items'], true );
		}
		
		return $order;
	}
	
	/**
	 * Update order status with state machine validation
	 *
	 * @param int $order_id
	 * @param string $new_status
	 * @param array $metadata Additional metadata
	 * @return bool
	 */
	public function update_order_status( $order_id, $new_status, $metadata = array() ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7MC_ORDERS_TABLE;
		
		// Get current order
		$order = $this->get_order( $order_id );
		if ( ! $order ) {
			cf7mc_log( "Order not found: $order_id", 'error' );
			return false;
		}
		
		$current_status = $order['status'];
		
		// Validate state transition
		if ( ! $this->is_valid_state_transition( $current_status, $new_status ) ) {
			cf7mc_log( "Invalid state transition from $current_status to $new_status for order $order_id", 'error' );
			return false;
		}
		
		$update_data = array( 'status' => sanitize_text_field( $new_status ) );
		$format = array( '%s' );
		
		// Set paid_at timestamp if status is paid
		if ( $new_status === 'paid' ) {
			$update_data['paid_at'] = current_time( 'mysql' );
			$format[] = '%s';
		}
		
		// Update metadata if provided
		if ( ! empty( $metadata ) ) {
			$existing_metadata = json_decode( $order['metadata'], true ) ?: array();
			$updated_metadata = array_merge( $existing_metadata, $metadata );
			$update_data['metadata'] = wp_json_encode( $updated_metadata );
			$format[] = '%s';
		}
		
		$result = $wpdb->update(
			$table_name,
			$update_data,
			array( 'id' => $order_id ),
			$format,
			array( '%d' )
		);
		
		if ( $result !== false ) {
			// Log state transition
			$this->log_state_transition( $order_id, $current_status, $new_status );
			
			// Emit events
			do_action( 'cf7mc_order_status_updated', $order_id, $new_status, $current_status );
			$this->emit_payment_events( $order_id, $new_status, $current_status );
			
			return true;
		}
		
		return false;
	}
	
	/**
	 * Check if state transition is valid
	 *
	 * @param string $from_state
	 * @param string $to_state
	 * @return bool
	 */
	private function is_valid_state_transition( $from_state, $to_state ) {
		// Allow any transition to the same state (idempotent)
		if ( $from_state === $to_state ) {
			return true;
		}
		
		// Check if target state is valid
		if ( ! in_array( $to_state, self::VALID_STATES ) ) {
			return false;
		}
		
		// Check if transition is allowed
		if ( ! isset( self::STATE_TRANSITIONS[ $from_state ] ) ) {
			return false;
		}
		
		return in_array( $to_state, self::STATE_TRANSITIONS[ $from_state ] );
	}
	
	/**
	 * Log state transition
	 *
	 * @param int $order_id
	 * @param string $from_state
	 * @param string $to_state
	 */
	private function log_state_transition( $order_id, $from_state, $to_state ) {
		$message = $from_state ? 
			"Order $order_id: $from_state → $to_state" : 
			"Order $order_id: Created with status $to_state";
		
		cf7mc_log( $message, 'info' );
	}
	
	/**
	 * Emit payment lifecycle events
	 *
	 * @param int $order_id
	 * @param string $new_status
	 * @param string $old_status
	 */
	private function emit_payment_events( $order_id, $new_status, $old_status ) {
		$order = $this->get_order( $order_id );
		
		switch ( $new_status ) {
			case 'awaiting_payment':
				do_action( 'ecommerce_payment_started', $order_id, $order );
				break;
			case 'paid':
				do_action( 'ecommerce_payment_success', $order_id, $order );
				break;
			case 'failed':
				do_action( 'ecommerce_payment_failed', $order_id, $order );
				break;
			case 'refunded':
				do_action( 'ecommerce_payment_refunded', $order_id, $order );
				break;
		}
	}
	
	/**
	 * Create payment session for inline checkout
	 *
	 * @param int $order_id
	 * @param string $gateway
	 * @return array|false
	 */
	public function create_payment_session( $order_id, $gateway ) {
		$order = $this->get_order( $order_id );
		if ( ! $order ) {
			return false;
		}
		
		// Get gateway adapter
		$gateway_manager = new \CF7MC\Core\GatewayManager();
		$gateway_adapter = $gateway_manager->get_gateway( $gateway );
		
		if ( ! $gateway_adapter ) {
			cf7mc_log( "Gateway not found: $gateway", 'error' );
			return false;
		}
		
		// Create payment session through gateway
		$session_data = $gateway_adapter->create_payment_session( $order );
		
		if ( $session_data ) {
			// Update order with session data
			$this->update_order_payment_session( $order_id, $session_data );
			
			// Transition to awaiting_payment
			$this->update_order_status( $order_id, 'awaiting_payment' );
			
			return $session_data;
		}
		
		return false;
	}
	
	/**
	 * Update order with payment session data
	 *
	 * @param int $order_id
	 * @param array $session_data
	 * @return bool
	 */
	private function update_order_payment_session( $order_id, $session_data ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7MC_ORDERS_TABLE;
		
		$update_data = array();
		$format = array();
		
		if ( isset( $session_data['session_id'] ) ) {
			$update_data['payment_session_id'] = sanitize_text_field( $session_data['session_id'] );
			$format[] = '%s';
		}
		
		if ( isset( $session_data['intent_id'] ) ) {
			$update_data['payment_intent_id'] = sanitize_text_field( $session_data['intent_id'] );
			$format[] = '%s';
		}
		
		if ( empty( $update_data ) ) {
			return true;
		}
		
		$result = $wpdb->update(
			$table_name,
			$update_data,
			array( 'id' => $order_id ),
			$format,
			array( '%d' )
		);
		
		return $result !== false;
	}
	
	/**
	 * Get orders with pagination
	 *
	 * @param array $args
	 * @return array
	 */
	public function get_orders( $args = array() ) {
		global $wpdb;
		
		$table_name = $wpdb->prefix . CF7MC_ORDERS_TABLE;
		
		$defaults = array(
			'status'   => '',
			'per_page' => 20,
			'page'     => 1,
			'orderby'  => 'created_at',
			'order'    => 'DESC',
		);
		
		$args = wp_parse_args( $args, $defaults );
		
		// Sanitize orderby and order to prevent SQL injection
		$allowed_orderby = array( 'id', 'order_code', 'email', 'total_amount', 'status', 'created_at', 'paid_at' );
		$orderby = in_array( $args['orderby'], $allowed_orderby ) ? $args['orderby'] : 'created_at';
		$order = strtoupper( $args['order'] ) === 'ASC' ? 'ASC' : 'DESC';
		
		$where = '1=1';
		$where_values = array();
		
		if ( ! empty( $args['status'] ) ) {
			$where .= ' AND status = %s';
			$where_values[] = $args['status'];
		}
		
		if ( ! empty( $args['search'] ) ) {
			$where .= ' AND (order_code LIKE %s OR email LIKE %s)';
			$search_term = '%' . $wpdb->esc_like( $args['search'] ) . '%';
			$where_values[] = $search_term;
			$where_values[] = $search_term;
		}
		
		$offset = ( $args['page'] - 1 ) * $args['per_page'];
		
		// Build query with safe ORDER BY clause (not using placeholders for column names)
		$query = "SELECT * FROM {$table_name} WHERE {$where} ORDER BY {$orderby} {$order} LIMIT %d OFFSET %d";
		$where_values[] = $args['per_page'];
		$where_values[] = $offset;
		
		$orders = $wpdb->get_results(
			$wpdb->prepare( $query, $where_values ),
			ARRAY_A
		);
		
		// Decode items JSON for each order
		foreach ( $orders as &$order ) {
			$order['items'] = json_decode( $order['items'], true );
		}
		
		// Get total count
		$count_query = "SELECT COUNT(*) FROM {$table_name} WHERE {$where}";
		$count_values = array_slice( $where_values, 0, -2 ); // Remove LIMIT and OFFSET values
		
		if ( ! empty( $count_values ) ) {
			$total = $wpdb->get_var(
				$wpdb->prepare( $count_query, $count_values )
			);
		} else {
			// No placeholders needed, execute directly
			$total = $wpdb->get_var( $count_query );
		}
		
		return array(
			'orders' => $orders,
			'total'  => $total,
		);
	}
	
	/**
	 * Update order status by order code
	 *
	 * @param string $order_code
	 * @param string $status
	 * @return bool
	 */
	public function update_order_status_by_code( $order_code, $status ) {
		$order = $this->get_order_by_code( $order_code );
		
		if ( ! $order ) {
			return false;
		}
		
		return $this->update_order_status( $order['id'], $status );
	}
}