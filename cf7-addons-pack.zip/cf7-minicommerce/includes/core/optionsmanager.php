<?php

namespace CF7MC\Core;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Options management class
 */
class OptionsManager {
	
	/**
	 * Set default options on plugin activation
	 */
	public static function set_defaults() {
		$defaults = array(
			'default_gateway'    => 'whatsapp',
			'currency'           => 'USD',
			'minimum_amount'     => 1,
			'order_expiry_hours' => 24,
			'enable_logging'     => true,
			'products'           => array(),
			'discounts'          => array(),
			'fees'               => array(),
			'email_notifications' => array(
				'admin_new_order'    => true,
				'customer_paid'      => true,
				'admin_email'        => get_option( 'admin_email' ),
			),
			'gateways' => array(
				'whatsapp' => array(
					'enabled'              => true,
					'title'                => 'WhatsApp Checkout',
					'whatsapp_number'      => '',
					'message_template'     => "Hello! I'd like to complete my order:\n\n🛒 *Order Details*\nOrder ID: {order_code}\nAmount: {amount}\nItems: {items}\n\n👤 *Customer Information*\nName: {customer_name}\nEmail: {customer_email}\n\nPlease let me know how to proceed with the payment.\n\nThank you!",
					'auto_complete_hours'  => 24,
					'button_text'          => 'Complete Order via WhatsApp',
					'success_message'      => 'Thank you! Please complete your payment via WhatsApp. Our team will contact you shortly.',
				),
				'tripay' => array(
					'enabled' => false,
					'title'   => 'TriPay',
				),
				'paypal' => array(
					'enabled' => false,
					'title'   => 'PayPal',
				),
			),
		);
		
		$existing_options = get_option( 'cf7mc_options', array() );
		$options = wp_parse_args( $existing_options, $defaults );
		
		update_option( 'cf7mc_options', $options );
	}
	
	/**
	 * Get all options
	 *
	 * @return array
	 */
	public static function get_all_options() {
		return get_option( 'cf7mc_options', array() );
	}
	
	/**
	 * Get gateway options
	 *
	 * @param string $gateway_id
	 * @return array
	 */
	public static function get_gateway_options( $gateway_id ) {
		$options = self::get_all_options();
		return isset( $options['gateways'][ $gateway_id ] ) ? $options['gateways'][ $gateway_id ] : array();
	}
	
	/**
	 * Update gateway options
	 *
	 * @param string $gateway_id
	 * @param array $gateway_options
	 */
	public static function update_gateway_options( $gateway_id, $gateway_options ) {
		$options = self::get_all_options();
		$options['gateways'][ $gateway_id ] = $gateway_options;
		update_option( 'cf7mc_options', $options );
	}
	
	/**
	 * Get enabled gateways
	 *
	 * @return array
	 */
	public static function get_enabled_gateways() {
		$options = self::get_all_options();
		$gateways = isset( $options['gateways'] ) ? $options['gateways'] : array();
		
		$enabled = array();
		foreach ( $gateways as $gateway_id => $gateway_config ) {
			if ( ! empty( $gateway_config['enabled'] ) ) {
				$enabled[ $gateway_id ] = $gateway_config;
			}
		}
		
		return $enabled;
	}
}