<?php

namespace CF7MC\Core;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Main plugin class
 */
class Plugin {
	
	/**
	 * Plugin instance
	 *
	 * @var Plugin
	 */
	private static $instance = null;
	
	/**
	 * Get plugin instance
	 *
	 * @return Plugin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		$this->init_hooks();
	}
	
	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
		add_action( 'template_redirect', array( $this, 'handle_checkout_redirect' ) );
		add_action( 'template_redirect', array( $this, 'handle_payment_return' ) );
	}
	
	/**
	 * Enqueue frontend scripts
	 */
	public function enqueue_scripts() {
		wp_enqueue_script( 
			'cf7mc-frontend', 
			CF7MC_PLUGIN_URL . '/assets/js/frontend.js', 
			array( 'jquery' ), 
			CF7MC_VERSION, 
			true 
		);
		
		wp_localize_script( 'cf7mc-frontend', 'cf7mc_ajax', array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'cf7mc_frontend' ),
		));
		
		wp_enqueue_style( 
			'cf7mc-frontend', 
			CF7MC_PLUGIN_URL . '/assets/css/frontend.css', 
			array(), 
			CF7MC_VERSION 
		);
	}
	
	/**
	 * Handle checkout redirect
	 */
	public function handle_checkout_redirect() {
		if ( ! isset( $_GET['cf7mc_checkout'] ) ) {
			return;
		}
		
		$order_code = sanitize_text_field( $_GET['cf7mc_checkout'] );
		$token = sanitize_text_field( $_GET['token'] ?? '' );
		
		// Verify token and redirect to payment gateway
		$order_manager = new OrderManager();
		$order = $order_manager->get_order_by_code( $order_code );
		
		if ( ! $order || ! $this->verify_checkout_token( $order_code, $token ) ) {
			wp_die( __( 'Invalid checkout link.', CF7MC_TEXT_DOMAIN ) );
		}
		
		// Redirect to payment gateway
		$gateway_manager = new GatewayManager();
		$gateway = $gateway_manager->get_gateway( $order['gateway'] );
		
		if ( $gateway ) {
			$checkout_url = $gateway->get_checkout_url( $order );
			wp_redirect( $checkout_url );
			exit;
		}
		
		wp_die( __( 'Payment gateway not available.', CF7MC_TEXT_DOMAIN ) );
	}
	
	/**
	 * Verify checkout token
	 *
	 * @param string $order_code
	 * @param string $token
	 * @return bool
	 */
	private function verify_checkout_token( $order_code, $token ) {
		$expected_token = wp_hash( $order_code . 'cf7mc_checkout' );
		return hash_equals( $expected_token, $token );
	}
	
	/**
	 * Generate checkout token
	 *
	 * @param string $order_code
	 * @return string
	 */
	public static function generate_checkout_token( $order_code ) {
		return wp_hash( $order_code . 'cf7mc_checkout' );
	}
	
	/**
	 * Handle payment return from gateways
	 */
	public function handle_payment_return() {
		// Handle TriPay return
		if ( isset( $_GET['cf7mc_return'] ) && $_GET['cf7mc_return'] === 'tripay' ) {
			$this->handle_tripay_return();
		}
		
		// Handle PayPal return
		if ( isset( $_GET['cf7mc_return'] ) && $_GET['cf7mc_return'] === 'paypal' ) {
			$this->handle_paypal_return();
		}
		
		// Handle PayPal cancel
		if ( isset( $_GET['cf7mc_cancel'] ) && $_GET['cf7mc_cancel'] === 'paypal' ) {
			$this->handle_paypal_cancel();
		}
	}
	
	/**
	 * Handle TriPay return
	 */
	private function handle_tripay_return() {
		$order_code = sanitize_text_field( $_GET['order'] ?? '' );
		
		if ( empty( $order_code ) ) {
			wp_die( __( 'Invalid return from TriPay.', CF7MC_TEXT_DOMAIN ) );
		}
		
		$order_manager = new OrderManager();
		$order = $order_manager->get_order_by_code( $order_code );
		
		if ( ! $order ) {
			wp_die( __( 'Order not found.', CF7MC_TEXT_DOMAIN ) );
		}
		
		// Display return page
		$this->display_payment_return_page( $order, 'tripay' );
	}
	
	/**
	 * Handle PayPal return
	 */
	private function handle_paypal_return() {
		$order_code = sanitize_text_field( $_GET['order'] ?? '' );
		$paypal_order_id = sanitize_text_field( $_GET['token'] ?? '' );
		
		if ( empty( $order_code ) || empty( $paypal_order_id ) ) {
			wp_die( __( 'Invalid return from PayPal.', CF7MC_TEXT_DOMAIN ) );
		}
		
		$order_manager = new OrderManager();
		$order = $order_manager->get_order_by_code( $order_code );
		
		if ( ! $order ) {
			wp_die( __( 'Order not found.', CF7MC_TEXT_DOMAIN ) );
		}
		
		// Capture PayPal payment if using CAPTURE intent
		$this->capture_paypal_payment( $paypal_order_id, $order );
		
		// Display return page
		$this->display_payment_return_page( $order, 'paypal' );
	}
	
	/**
	 * Handle PayPal cancel
	 */
	private function handle_paypal_cancel() {
		$order_code = sanitize_text_field( $_GET['order'] ?? '' );
		
		if ( ! empty( $order_code ) ) {
			$order_manager = new OrderManager();
			$order_manager->update_order_status_by_code( $order_code, 'failed' );
		}
		
		wp_redirect( home_url( '?cf7mc_message=payment_cancelled' ) );
		exit;
	}
	
	/**
	 * Capture PayPal payment
	 *
	 * @param string $paypal_order_id
	 * @param array $order
	 */
	private function capture_paypal_payment( $paypal_order_id, $order ) {
		$gateway_manager = new GatewayManager();
		$paypal_gateway = $gateway_manager->get_gateway( 'paypal' );
		
		if ( ! $paypal_gateway ) {
			return;
		}
		
		// This would require additional PayPal API implementation
		// For now, we'll rely on webhooks for payment confirmation
		cf7mc_log( "PayPal payment return for order {$order['order_code']}, PayPal Order ID: {$paypal_order_id}" );
	}
	
	/**
	 * Display payment return page
	 *
	 * @param array $order
	 * @param string $gateway
	 */
	private function display_payment_return_page( $order, $gateway ) {
		$gateway_names = array(
			'tripay' => 'TriPay',
			'paypal' => 'PayPal',
		);
		
		$gateway_name = $gateway_names[ $gateway ] ?? ucfirst( $gateway );
		
		?>
		<!DOCTYPE html>
		<html>
		<head>
			<title><?php _e( 'Payment Processing', CF7MC_TEXT_DOMAIN ); ?></title>
			<style>
				body { font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; text-align: center; }
				.return-box { border: 1px solid #ddd; padding: 30px; border-radius: 8px; background: #f9f9f9; }
				.status-pending { color: #856404; background: #fff3cd; padding: 15px; border-radius: 4px; margin: 20px 0; }
				.order-details { text-align: left; margin: 20px 0; padding: 15px; background: white; border-radius: 4px; }
			</style>
		</head>
		<body>
			<div class="return-box">
				<h2><?php printf( __( 'Payment via %s', CF7MC_TEXT_DOMAIN ), $gateway_name ); ?></h2>
				
				<div class="status-pending">
					<strong><?php _e( 'Payment Processing', CF7MC_TEXT_DOMAIN ); ?></strong><br>
					<?php _e( 'Your payment is being processed. You will receive a confirmation email once the payment is completed.', CF7MC_TEXT_DOMAIN ); ?>
				</div>
				
				<div class="order-details">
					<h3><?php _e( 'Order Details', CF7MC_TEXT_DOMAIN ); ?></h3>
					<p><strong><?php _e( 'Order Code:', CF7MC_TEXT_DOMAIN ); ?></strong> <?php echo esc_html( $order['order_code'] ); ?></p>
					<p><strong><?php _e( 'Total Amount:', CF7MC_TEXT_DOMAIN ); ?></strong> <?php echo cf7mc_format_price( $order['total_amount'] ); ?></p>
					<p><strong><?php _e( 'Status:', CF7MC_TEXT_DOMAIN ); ?></strong> <?php echo esc_html( ucfirst( $order['status'] ) ); ?></p>
				</div>
				
				<p>
					<a href="<?php echo home_url(); ?>" style="background: #007cba; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px;">
						<?php _e( 'Return to Home', CF7MC_TEXT_DOMAIN ); ?>
					</a>
				</p>
			</div>
		</body>
		</html>
		<?php
		exit;
	}
}