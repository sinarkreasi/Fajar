<?php

namespace CF7MC\Core;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Gateway management class
 */
class GatewayManager {
	
	/**
	 * Registered gateways
	 *
	 * @var array
	 */
	private $gateways = array();
	
	/**
	 * Constructor
	 */
	public function __construct() {
		$this->load_gateways();
	}
	
	/**
	 * Load available gateways
	 */
	private function load_gateways() {
		// Load WhatsApp gateway (default)
		$this->register_gateway( 'whatsapp', new \CF7MC\Gateways\WhatsAppGateway() );
		
		// Load TriPay gateway
		$this->register_gateway( 'tripay', new \CF7MC\Gateways\TripayGateway() );
		
		// Load PayPal gateway
		$this->register_gateway( 'paypal', new \CF7MC\Gateways\PaypalGateway() );
		
		// Allow other plugins to register gateways
		do_action( 'cf7mc_register_gateways', $this );
	}
	
	/**
	 * Register a gateway
	 *
	 * @param string $gateway_id
	 * @param object $gateway_instance
	 */
	public function register_gateway( $gateway_id, $gateway_instance ) {
		$this->gateways[ $gateway_id ] = $gateway_instance;
	}
	
	/**
	 * Get gateway instance
	 *
	 * @param string $gateway_id
	 * @return object|null
	 */
	public function get_gateway( $gateway_id ) {
		return isset( $this->gateways[ $gateway_id ] ) ? $this->gateways[ $gateway_id ] : null;
	}
	
	/**
	 * Get all registered gateways
	 *
	 * @return array
	 */
	public function get_all_gateways() {
		return $this->gateways;
	}
	
	/**
	 * Get enabled gateways
	 *
	 * @return array
	 */
	public function get_enabled_gateways() {
		$enabled_configs = OptionsManager::get_enabled_gateways();
		$enabled_gateways = array();
		
		foreach ( $enabled_configs as $gateway_id => $config ) {
			if ( isset( $this->gateways[ $gateway_id ] ) ) {
				$enabled_gateways[ $gateway_id ] = $this->gateways[ $gateway_id ];
			}
		}
		
		return $enabled_gateways;
	}
	
	/**
	 * Get default gateway
	 *
	 * @return string|null
	 */
	public function get_default_gateway() {
		$default = cf7mc_get_option( 'default_gateway', 'whatsapp' );
		$enabled = $this->get_enabled_gateways();
		
		if ( isset( $enabled[ $default ] ) ) {
			return $default;
		}
		
		// Return first enabled gateway
		$gateway_ids = array_keys( $enabled );
		return ! empty( $gateway_ids ) ? $gateway_ids[0] : null;
	}
}