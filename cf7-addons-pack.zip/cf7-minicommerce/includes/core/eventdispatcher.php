<?php

namespace CF7MC\Core;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Event Dispatcher for Payment Lifecycle Events
 * 
 * Emits standardized events that other addons can listen to
 */
class EventDispatcher {
	
	/**
	 * Event listeners
	 *
	 * @var array
	 */
	private static $listeners = array();
	
	/**
	 * Initialize event dispatcher
	 */
	public static function init() {
		// Hook into WordPress actions to emit our events
		add_action( 'cf7mc_order_created', array( __CLASS__, 'emit_order_created' ), 10, 2 );
		add_action( 'cf7mc_order_status_updated', array( __CLASS__, 'emit_status_events' ), 10, 3 );
		
		// Register default event listeners
		self::register_default_listeners();
	}
	
	/**
	 * Register default event listeners
	 */
	private static function register_default_listeners() {
		// Log all payment events
		self::add_listener( 'ecommerce_order_created', array( __CLASS__, 'log_order_created' ) );
		self::add_listener( 'ecommerce_payment_started', array( __CLASS__, 'log_payment_started' ) );
		self::add_listener( 'ecommerce_payment_success', array( __CLASS__, 'log_payment_success' ) );
		self::add_listener( 'ecommerce_payment_failed', array( __CLASS__, 'log_payment_failed' ) );
		self::add_listener( 'ecommerce_payment_refunded', array( __CLASS__, 'log_payment_refunded' ) );
	}
	
	/**
	 * Add event listener
	 *
	 * @param string $event
	 * @param callable $callback
	 * @param int $priority
	 */
	public static function add_listener( $event, $callback, $priority = 10 ) {
		if ( ! isset( self::$listeners[ $event ] ) ) {
			self::$listeners[ $event ] = array();
		}
		
		self::$listeners[ $event ][] = array(
			'callback' => $callback,
			'priority' => $priority
		);
		
		// Sort by priority
		usort( self::$listeners[ $event ], function( $a, $b ) {
			return $a['priority'] - $b['priority'];
		} );
	}
	
	/**
	 * Remove event listener
	 *
	 * @param string $event
	 * @param callable $callback
	 */
	public static function remove_listener( $event, $callback ) {
		if ( ! isset( self::$listeners[ $event ] ) ) {
			return;
		}
		
		self::$listeners[ $event ] = array_filter( self::$listeners[ $event ], function( $listener ) use ( $callback ) {
			return $listener['callback'] !== $callback;
		} );
	}
	
	/**
	 * Emit event
	 *
	 * @param string $event
	 * @param mixed ...$args
	 */
	public static function emit( $event, ...$args ) {
		// Emit WordPress action
		do_action( $event, ...$args );
		
		// Call our internal listeners
		if ( isset( self::$listeners[ $event ] ) ) {
			foreach ( self::$listeners[ $event ] as $listener ) {
				if ( is_callable( $listener['callback'] ) ) {
					call_user_func_array( $listener['callback'], $args );
				}
			}
		}
		
		// Log event emission
		cf7mc_log( "Event emitted: {$event} with " . count( $args ) . " arguments", 'debug' );
	}
	
	/**
	 * Emit order created event
	 *
	 * @param int $order_id
	 * @param array $order_data
	 */
	public static function emit_order_created( $order_id, $order_data ) {
		self::emit( 'ecommerce_order_created', $order_id, $order_data );
	}
	
	/**
	 * Emit status-based events
	 *
	 * @param int $order_id
	 * @param string $new_status
	 * @param string $old_status
	 */
	public static function emit_status_events( $order_id, $new_status, $old_status ) {
		$order_manager = new OrderManager();
		$order = $order_manager->get_order( $order_id );
		
		if ( ! $order ) {
			return;
		}
		
		switch ( $new_status ) {
			case 'awaiting_payment':
				if ( $old_status !== 'awaiting_payment' ) {
					self::emit( 'ecommerce_payment_started', $order_id, $order );
				}
				break;
				
			case 'paid':
				if ( $old_status !== 'paid' ) {
					self::emit( 'ecommerce_payment_success', $order_id, $order );
				}
				break;
				
			case 'failed':
				if ( $old_status !== 'failed' ) {
					self::emit( 'ecommerce_payment_failed', $order_id, $order );
				}
				break;
				
			case 'refunded':
				if ( $old_status !== 'refunded' ) {
					self::emit( 'ecommerce_payment_refunded', $order_id, $order );
				}
				break;
		}
	}
	
	/**
	 * Get all registered listeners for an event
	 *
	 * @param string $event
	 * @return array
	 */
	public static function get_listeners( $event ) {
		return self::$listeners[ $event ] ?? array();
	}
	
	/**
	 * Check if event has listeners
	 *
	 * @param string $event
	 * @return bool
	 */
	public static function has_listeners( $event ) {
		return ! empty( self::$listeners[ $event ] );
	}
	
	/**
	 * Default event listeners for logging
	 */
	
	/**
	 * Log order created event
	 *
	 * @param int $order_id
	 * @param array $order_data
	 */
	public static function log_order_created( $order_id, $order_data ) {
		cf7mc_log( "Order created: ID={$order_id}, Code={$order_data['order_code']}, Amount={$order_data['total_amount']}", 'info' );
	}
	
	/**
	 * Log payment started event
	 *
	 * @param int $order_id
	 * @param array $order
	 */
	public static function log_payment_started( $order_id, $order ) {
		cf7mc_log( "Payment started: Order={$order['order_code']}, Gateway={$order['gateway']}, Amount={$order['total_amount']}", 'info' );
	}
	
	/**
	 * Log payment success event
	 *
	 * @param int $order_id
	 * @param array $order
	 */
	public static function log_payment_success( $order_id, $order ) {
		cf7mc_log( "Payment successful: Order={$order['order_code']}, Gateway={$order['gateway']}, Amount={$order['total_amount']}", 'info' );
		
		// Send success email if configured
		self::maybe_send_payment_success_email( $order );
	}
	
	/**
	 * Log payment failed event
	 *
	 * @param int $order_id
	 * @param array $order
	 */
	public static function log_payment_failed( $order_id, $order ) {
		cf7mc_log( "Payment failed: Order={$order['order_code']}, Gateway={$order['gateway']}, Amount={$order['total_amount']}", 'warning' );
		
		// Send failure notification if configured
		self::maybe_send_payment_failure_email( $order );
	}
	
	/**
	 * Log payment refunded event
	 *
	 * @param int $order_id
	 * @param array $order
	 */
	public static function log_payment_refunded( $order_id, $order ) {
		cf7mc_log( "Payment refunded: Order={$order['order_code']}, Gateway={$order['gateway']}, Amount={$order['total_amount']}", 'info' );
	}
	
	/**
	 * Send payment success email
	 *
	 * @param array $order
	 */
	private static function maybe_send_payment_success_email( $order ) {
		if ( ! cf7mc_get_option( 'send_success_emails', true ) ) {
			return;
		}
		
		$to = $order['email'];
		$subject = sprintf( __( 'Payment Confirmation - Order %s', CF7MC_TEXT_DOMAIN ), $order['order_code'] );
		
		$message = sprintf(
			__( "Dear Customer,\n\nYour payment has been successfully processed.\n\nOrder Details:\nOrder ID: %s\nAmount: %s\nPayment Method: %s\n\nThank you for your business!\n\nBest regards,\n%s", CF7MC_TEXT_DOMAIN ),
			$order['order_code'],
			cf7mc_format_price( $order['total_amount'] ),
			ucfirst( $order['gateway'] ),
			get_bloginfo( 'name' )
		);
		
		$headers = array( 'Content-Type: text/plain; charset=UTF-8' );
		
		wp_mail( $to, $subject, $message, $headers );
		
		cf7mc_log( "Payment success email sent to: {$to}" );
	}
	
	/**
	 * Send payment failure email
	 *
	 * @param array $order
	 */
	private static function maybe_send_payment_failure_email( $order ) {
		if ( ! cf7mc_get_option( 'send_failure_emails', false ) ) {
			return;
		}
		
		$admin_email = get_option( 'admin_email' );
		$subject = sprintf( __( 'Payment Failed - Order %s', CF7MC_TEXT_DOMAIN ), $order['order_code'] );
		
		$message = sprintf(
			__( "A payment has failed for order %s.\n\nOrder Details:\nOrder ID: %s\nCustomer: %s\nAmount: %s\nPayment Method: %s\n\nPlease review the order in the admin panel.", CF7MC_TEXT_DOMAIN ),
			$order['order_code'],
			$order['order_code'],
			$order['email'],
			cf7mc_format_price( $order['total_amount'] ),
			ucfirst( $order['gateway'] )
		);
		
		$headers = array( 'Content-Type: text/plain; charset=UTF-8' );
		
		wp_mail( $admin_email, $subject, $message, $headers );
		
		cf7mc_log( "Payment failure notification sent to admin: {$admin_email}" );
	}
	
	/**
	 * Get event statistics
	 *
	 * @return array
	 */
	public static function get_event_stats() {
		return array(
			'total_listeners' => array_sum( array_map( 'count', self::$listeners ) ),
			'events_with_listeners' => count( self::$listeners ),
			'listeners_by_event' => array_map( 'count', self::$listeners ),
		);
	}
}