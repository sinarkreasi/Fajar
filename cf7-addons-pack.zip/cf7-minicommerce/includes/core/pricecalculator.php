<?php

namespace CF7MC\Core;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Price calculation class
 */
class PriceCalculator {
	
	/**
	 * Calculate total price for order
	 *
	 * @param array $items
	 * @return float
	 */
	public function calculate_total( $items ) {
		$total = 0;
		
		foreach ( $items as $item ) {
			$item_total = $this->calculate_item_total( $item );
			$total += $item_total;
		}
		
		// Apply discounts if any
		$total = $this->apply_discounts( $total, $items );
		
		// Apply fees if any
		$total = $this->apply_fees( $total, $items );
		
		// Ensure minimum amount
		$min_amount = cf7mc_get_option( 'minimum_amount', 0 );
		if ( $min_amount > 0 && $total < $min_amount ) {
			$total = $min_amount;
		}
		
		return round( $total, 2 );
	}
	
	/**
	 * Calculate total for single item
	 *
	 * @param array $item
	 * @return float
	 */
	public function calculate_item_total( $item ) {
		$price = cf7mc_sanitize_amount( $item['price'] ?? 0 );
		$quantity = max( 1, intval( $item['quantity'] ?? 1 ) );
		
		$total = $price * $quantity;
		
		// Allow filtering for custom calculations
		return apply_filters( 'cf7mc_item_total', $total, $item );
	}
	
	/**
	 * Apply discounts to total
	 *
	 * @param float $total
	 * @param array $items
	 * @return float
	 */
	private function apply_discounts( $total, $items ) {
		// Get configured discounts
		$discounts = cf7mc_get_option( 'discounts', array() );
		
		foreach ( $discounts as $discount ) {
			if ( ! $this->is_discount_applicable( $discount, $total, $items ) ) {
				continue;
			}
			
			if ( $discount['type'] === 'percentage' ) {
				$discount_amount = $total * ( $discount['value'] / 100 );
			} else {
				$discount_amount = $discount['value'];
			}
			
			$total -= $discount_amount;
		}
		
		// Allow filtering for custom discounts
		return apply_filters( 'cf7mc_apply_discounts', $total, $items );
	}
	
	/**
	 * Apply fees to total
	 *
	 * @param float $total
	 * @param array $items
	 * @return float
	 */
	private function apply_fees( $total, $items ) {
		// Get configured fees
		$fees = cf7mc_get_option( 'fees', array() );
		
		foreach ( $fees as $fee ) {
			if ( ! $this->is_fee_applicable( $fee, $total, $items ) ) {
				continue;
			}
			
			if ( $fee['type'] === 'percentage' ) {
				$fee_amount = $total * ( $fee['value'] / 100 );
			} else {
				$fee_amount = $fee['value'];
			}
			
			$total += $fee_amount;
		}
		
		// Allow filtering for custom fees
		return apply_filters( 'cf7mc_apply_fees', $total, $items );
	}
	
	/**
	 * Check if discount is applicable
	 *
	 * @param array $discount
	 * @param float $total
	 * @param array $items
	 * @return bool
	 */
	private function is_discount_applicable( $discount, $total, $items ) {
		// Check minimum amount
		if ( isset( $discount['min_amount'] ) && $total < $discount['min_amount'] ) {
			return false;
		}
		
		// Check maximum amount
		if ( isset( $discount['max_amount'] ) && $total > $discount['max_amount'] ) {
			return false;
		}
		
		// Check applicable products
		if ( isset( $discount['products'] ) && ! empty( $discount['products'] ) ) {
			$applicable = false;
			foreach ( $items as $item ) {
				if ( in_array( $item['id'], $discount['products'] ) ) {
					$applicable = true;
					break;
				}
			}
			if ( ! $applicable ) {
				return false;
			}
		}
		
		return true;
	}
	
	/**
	 * Check if fee is applicable
	 *
	 * @param array $fee
	 * @param float $total
	 * @param array $items
	 * @return bool
	 */
	private function is_fee_applicable( $fee, $total, $items ) {
		// Check minimum amount
		if ( isset( $fee['min_amount'] ) && $total < $fee['min_amount'] ) {
			return false;
		}
		
		// Check maximum amount
		if ( isset( $fee['max_amount'] ) && $total > $fee['max_amount'] ) {
			return false;
		}
		
		return true;
	}
	
	/**
	 * Get price breakdown
	 *
	 * @param array $items
	 * @return array
	 */
	public function get_price_breakdown( $items ) {
		$breakdown = array(
			'subtotal'  => 0,
			'discounts' => 0,
			'fees'      => 0,
			'total'     => 0,
			'items'     => array(),
		);
		
		// Calculate item totals
		foreach ( $items as $item ) {
			$item_total = $this->calculate_item_total( $item );
			$breakdown['subtotal'] += $item_total;
			$breakdown['items'][] = array(
				'name'     => $item['name'],
				'price'    => $item['price'],
				'quantity' => $item['quantity'],
				'total'    => $item_total,
			);
		}
		
		$total_before_adjustments = $breakdown['subtotal'];
		
		// Calculate discounts
		$total_after_discounts = $this->apply_discounts( $total_before_adjustments, $items );
		$breakdown['discounts'] = $total_before_adjustments - $total_after_discounts;
		
		// Calculate fees
		$breakdown['total'] = $this->apply_fees( $total_after_discounts, $items );
		$breakdown['fees'] = $breakdown['total'] - $total_after_discounts;
		
		return $breakdown;
	}
}