<?php

namespace CF7MC\Core;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Product resolver class
 */
class ProductResolver {
	
	/**
	 * Resolve product from form submission
	 *
	 * @param array $form_data
	 * @return array|false
	 */
	public function resolve_product( $form_data ) {
		$product = array();
		
		// Extract product ID
		$product_id = $this->extract_field( $form_data, array( 'product_id', 'product-id', 'product' ) );
		if ( empty( $product_id ) ) {
			cf7mc_log( 'No product ID found in form submission', 'error' );
			return false;
		}
		
		$product['id'] = sanitize_text_field( $product_id );
		
		// Extract product name
		$product['name'] = $this->extract_field( $form_data, array( 'product_name', 'product-name', 'service', 'item' ) );
		if ( empty( $product['name'] ) ) {
			$product['name'] = $product['id']; // Fallback to ID
		}
		$product['name'] = sanitize_text_field( $product['name'] );
		
		// Extract quantity
		$quantity = $this->extract_field( $form_data, array( 'quantity', 'qty' ) );
		$product['quantity'] = max( 1, intval( $quantity ) );
		
		// Extract price (optional, can be calculated from product ID)
		$price = $this->extract_field( $form_data, array( 'price', 'amount', 'cost' ) );
		if ( ! empty( $price ) ) {
			$product['price'] = cf7mc_sanitize_amount( $price );
		} else {
			// Get price from product configuration
			$product['price'] = $this->get_product_price( $product['id'] );
		}
		
		// Extract additional product data
		$product['description'] = sanitize_textarea_field( 
			$this->extract_field( $form_data, array( 'description', 'notes', 'details' ) ) 
		);
		
		return $product;
	}
	
	/**
	 * Extract field value from form data
	 *
	 * @param array $form_data
	 * @param array $field_names
	 * @return string
	 */
	private function extract_field( $form_data, $field_names ) {
		foreach ( $field_names as $field_name ) {
			if ( isset( $form_data[ $field_name ] ) && ! empty( $form_data[ $field_name ] ) ) {
				return is_array( $form_data[ $field_name ] ) 
					? $form_data[ $field_name ][0] 
					: $form_data[ $field_name ];
			}
		}
		
		return '';
	}
	
	/**
	 * Get product price from configuration
	 *
	 * @param string $product_id
	 * @return float
	 */
	private function get_product_price( $product_id ) {
		$products = cf7mc_get_option( 'products', array() );
		
		if ( isset( $products[ $product_id ] ) && isset( $products[ $product_id ]['price'] ) ) {
			return cf7mc_sanitize_amount( $products[ $product_id ]['price'] );
		}
		
		// Allow filtering for dynamic pricing
		return apply_filters( 'cf7mc_product_price', 0, $product_id );
	}
	
	/**
	 * Validate product data
	 *
	 * @param array $product
	 * @return bool|WP_Error
	 */
	public function validate_product( $product ) {
		if ( empty( $product['id'] ) ) {
			return new \WP_Error( 'missing_product_id', __( 'Product ID is required.', CF7MC_TEXT_DOMAIN ) );
		}
		
		if ( empty( $product['name'] ) ) {
			return new \WP_Error( 'missing_product_name', __( 'Product name is required.', CF7MC_TEXT_DOMAIN ) );
		}
		
		if ( $product['quantity'] < 1 ) {
			return new \WP_Error( 'invalid_quantity', __( 'Quantity must be at least 1.', CF7MC_TEXT_DOMAIN ) );
		}
		
		if ( $product['price'] <= 0 ) {
			return new \WP_Error( 'invalid_price', __( 'Product price must be greater than 0.', CF7MC_TEXT_DOMAIN ) );
		}
		
		return true;
	}
	
	/**
	 * Get configured products
	 *
	 * @return array
	 */
	public function get_configured_products() {
		return cf7mc_get_option( 'products', array() );
	}
	
	/**
	 * Add or update product configuration
	 *
	 * @param string $product_id
	 * @param array $product_data
	 */
	public function update_product_config( $product_id, $product_data ) {
		$products = $this->get_configured_products();
		$products[ $product_id ] = $product_data;
		cf7mc_update_option( 'products', $products );
	}
}