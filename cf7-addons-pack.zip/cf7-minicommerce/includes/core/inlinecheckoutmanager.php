<?php

namespace CF7MC\Core;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Inline Checkout Manager
 * 
 * Handles the inline checkout process without redirects
 */
class InlineCheckoutManager {
	
	/**
	 * Order manager instance
	 *
	 * @var OrderManager
	 */
	private $order_manager;
	
	/**
	 * Gateway manager instance
	 *
	 * @var GatewayManager
	 */
	private $gateway_manager;
	
	/**
	 * Constructor
	 */
	public function __construct() {
		$this->order_manager = new OrderManager();
		$this->gateway_manager = new GatewayManager();
		
		$this->init_hooks();
	}
	
	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		// AJAX endpoints for inline checkout
		add_action( 'wp_ajax_cf7mc_create_order', array( $this, 'ajax_create_order' ) );
		add_action( 'wp_ajax_nopriv_cf7mc_create_order', array( $this, 'ajax_create_order' ) );
		
		add_action( 'wp_ajax_cf7mc_create_payment_session', array( $this, 'ajax_create_payment_session' ) );
		add_action( 'wp_ajax_nopriv_cf7mc_create_payment_session', array( $this, 'ajax_create_payment_session' ) );
		
		add_action( 'wp_ajax_cf7mc_confirm_payment', array( $this, 'ajax_confirm_payment' ) );
		add_action( 'wp_ajax_nopriv_cf7mc_confirm_payment', array( $this, 'ajax_confirm_payment' ) );
		
		add_action( 'wp_ajax_cf7mc_get_payment_status', array( $this, 'ajax_get_payment_status' ) );
		add_action( 'wp_ajax_nopriv_cf7mc_get_payment_status', array( $this, 'ajax_get_payment_status' ) );
		
		// Webhook endpoint
		add_action( 'wp_ajax_cf7mc_webhook', array( $this, 'handle_webhook' ) );
		add_action( 'wp_ajax_nopriv_cf7mc_webhook', array( $this, 'handle_webhook' ) );
		
		// Enqueue scripts for inline checkout
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_checkout_scripts' ) );
	}
	
	/**
	 * Create order from conversation step data
	 *
	 * @param array $step_data
	 * @return int|false Order ID or false on failure
	 */
	public function create_order_from_step( $step_data ) {
		// Extract order data from step
		$order_data = array(
			'email' => sanitize_email( $step_data['email'] ?? '' ),
			'total_amount' => cf7mc_sanitize_amount( $step_data['amount'] ?? 0 ),
			'gateway' => sanitize_text_field( $step_data['gateway'] ?? 'whatsapp' ),
			'items' => $step_data['items'] ?? array(),
			'metadata' => array(
				'conversation_id' => intval( $step_data['conversation_id'] ?? 0 ),
				'step_id' => intval( $step_data['step_id'] ?? 0 ),
				'session_id' => sanitize_text_field( $step_data['session_id'] ?? '' ),
				'customer_name' => sanitize_text_field( $step_data['customer_name'] ?? '' ),
				'source' => 'conversation_engine',
			),
		);
		
		// Validate required fields
		if ( empty( $order_data['email'] ) || $order_data['total_amount'] <= 0 ) {
			cf7mc_log( 'Invalid order data: missing email or amount', 'error' );
			return false;
		}
		
		// Create order
		$order_id = $this->order_manager->create_order( $order_data );
		
		if ( $order_id ) {
			cf7mc_log( "Order created from conversation: ID={$order_id}, Amount={$order_data['total_amount']}" );
		}
		
		return $order_id;
	}
	
	/**
	 * Create payment session for inline checkout
	 *
	 * @param int $order_id
	 * @param string $gateway
	 * @return array|false
	 */
	public function create_payment_session( $order_id, $gateway ) {
		$order = $this->order_manager->get_order( $order_id );
		if ( ! $order ) {
			return false;
		}
		
		// Check if order is in correct state
		if ( $order['status'] !== 'initiated' ) {
			cf7mc_log( "Cannot create payment session for order {$order_id} in status {$order['status']}", 'error' );
			return false;
		}
		
		// Get gateway adapter
		$gateway_adapter = $this->gateway_manager->get_gateway( $gateway );
		if ( ! $gateway_adapter || ! $gateway_adapter->supports_inline_checkout() ) {
			cf7mc_log( "Gateway {$gateway} does not support inline checkout", 'error' );
			return false;
		}
		
		// Create payment session
		$session_data = $this->order_manager->create_payment_session( $order_id, $gateway );
		
		if ( $session_data ) {
			// Get client configuration
			$client_config = $gateway_adapter->get_client_config( $session_data );
			
			return array(
				'success' => true,
				'session_data' => $session_data,
				'client_config' => $client_config,
				'required_scripts' => $gateway_adapter->get_required_scripts(),
			);
		}
		
		return false;
	}
	
	/**
	 * Confirm payment from client-side
	 *
	 * @param int $order_id
	 * @param array $payment_data
	 * @return array
	 */
	public function confirm_payment( $order_id, $payment_data ) {
		$order = $this->order_manager->get_order( $order_id );
		if ( ! $order ) {
			return array(
				'success' => false,
				'error' => __( 'Order not found.', CF7MC_TEXT_DOMAIN )
			);
		}
		
		// Check if order is in correct state
		if ( ! in_array( $order['status'], array( 'awaiting_payment', 'processing' ) ) ) {
			return array(
				'success' => false,
				'error' => __( 'Order is not in a payable state.', CF7MC_TEXT_DOMAIN )
			);
		}
		
		// Get gateway adapter
		$gateway_adapter = $this->gateway_manager->get_gateway( $order['gateway'] );
		if ( ! $gateway_adapter ) {
			return array(
				'success' => false,
				'error' => __( 'Payment gateway not available.', CF7MC_TEXT_DOMAIN )
			);
		}
		
		// Update order to processing
		$this->order_manager->update_order_status( $order_id, 'processing' );
		
		// Confirm payment with gateway
		$result = $gateway_adapter->confirm_payment( $payment_data );
		
		if ( $result['success'] ) {
			// Note: We don't mark as paid here - that happens via webhook
			return array(
				'success' => true,
				'message' => __( 'Payment is being processed.', CF7MC_TEXT_DOMAIN ),
				'requires_webhook' => true
			);
		} else {
			// Mark as failed
			$this->order_manager->update_order_status( $order_id, 'failed', array(
				'error' => $result['error'] ?? 'Payment confirmation failed'
			) );
			
			return array(
				'success' => false,
				'error' => $result['error'] ?? __( 'Payment failed.', CF7MC_TEXT_DOMAIN )
			);
		}
	}
	
	/**
	 * Get payment status
	 *
	 * @param int $order_id
	 * @return array
	 */
	public function get_payment_status( $order_id ) {
		$order = $this->order_manager->get_order( $order_id );
		if ( ! $order ) {
			return array(
				'success' => false,
				'error' => __( 'Order not found.', CF7MC_TEXT_DOMAIN )
			);
		}
		
		return array(
			'success' => true,
			'status' => $order['status'],
			'order' => $order
		);
	}
	
	/**
	 * Handle webhook from payment provider
	 *
	 * @param string $gateway
	 * @param array $webhook_data
	 * @return bool
	 */
	public function handle_payment_webhook( $gateway, $webhook_data ) {
		// Get gateway adapter
		$gateway_adapter = $this->gateway_manager->get_gateway( $gateway );
		if ( ! $gateway_adapter ) {
			cf7mc_log( "Gateway not found for webhook: {$gateway}", 'error' );
			return false;
		}
		
		// Let gateway handle the webhook
		return $gateway_adapter->handle_webhook( $webhook_data );
	}
	
	/**
	 * AJAX: Create order from conversation step
	 */
	public function ajax_create_order() {
		// Verify nonce
		if ( ! wp_verify_nonce( $_POST['nonce'] ?? '', 'cf7mc_checkout' ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', CF7MC_TEXT_DOMAIN ) ) );
		}
		
		$step_data = $_POST['step_data'] ?? array();
		
		if ( empty( $step_data ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid step data.', CF7MC_TEXT_DOMAIN ) ) );
		}
		
		$order_id = $this->create_order_from_step( $step_data );
		
		if ( $order_id ) {
			wp_send_json_success( array( 
				'order_id' => $order_id,
				'message' => __( 'Order created successfully.', CF7MC_TEXT_DOMAIN )
			) );
		} else {
			wp_send_json_error( array( 'message' => __( 'Failed to create order.', CF7MC_TEXT_DOMAIN ) ) );
		}
	}
	
	/**
	 * AJAX: Create payment session
	 */
	public function ajax_create_payment_session() {
		// Verify nonce
		if ( ! wp_verify_nonce( $_POST['nonce'] ?? '', 'cf7mc_checkout' ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', CF7MC_TEXT_DOMAIN ) ) );
		}
		
		$order_id = intval( $_POST['order_id'] ?? 0 );
		$gateway = sanitize_text_field( $_POST['gateway'] ?? '' );
		
		if ( ! $order_id || ! $gateway ) {
			wp_send_json_error( array( 'message' => __( 'Invalid request.', CF7MC_TEXT_DOMAIN ) ) );
		}
		
		$result = $this->create_payment_session( $order_id, $gateway );
		
		if ( $result ) {
			wp_send_json_success( $result );
		} else {
			wp_send_json_error( array( 'message' => __( 'Failed to create payment session.', CF7MC_TEXT_DOMAIN ) ) );
		}
	}
	
	/**
	 * AJAX: Confirm payment
	 */
	public function ajax_confirm_payment() {
		// Verify nonce
		if ( ! wp_verify_nonce( $_POST['nonce'] ?? '', 'cf7mc_checkout' ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', CF7MC_TEXT_DOMAIN ) ) );
		}
		
		$order_id = intval( $_POST['order_id'] ?? 0 );
		$payment_data = $_POST['payment_data'] ?? array();
		
		if ( ! $order_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid request.', CF7MC_TEXT_DOMAIN ) ) );
		}
		
		$result = $this->confirm_payment( $order_id, $payment_data );
		
		if ( $result['success'] ) {
			wp_send_json_success( $result );
		} else {
			wp_send_json_error( $result );
		}
	}
	
	/**
	 * AJAX: Get payment status
	 */
	public function ajax_get_payment_status() {
		// Verify nonce
		if ( ! wp_verify_nonce( $_POST['nonce'] ?? '', 'cf7mc_checkout' ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', CF7MC_TEXT_DOMAIN ) ) );
		}
		
		$order_id = intval( $_POST['order_id'] ?? 0 );
		
		if ( ! $order_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid request.', CF7MC_TEXT_DOMAIN ) ) );
		}
		
		$result = $this->get_payment_status( $order_id );
		
		if ( $result['success'] ) {
			wp_send_json_success( $result );
		} else {
			wp_send_json_error( $result );
		}
	}
	
	/**
	 * Handle webhook endpoint
	 */
	public function handle_webhook() {
		$gateway = sanitize_text_field( $_GET['gateway'] ?? '' );
		
		if ( ! $gateway ) {
			status_header( 400 );
			exit( 'Missing gateway parameter' );
		}
		
		// Get raw POST data
		$payload = file_get_contents( 'php://input' );
		$webhook_data = json_decode( $payload, true );
		
		if ( ! $webhook_data ) {
			status_header( 400 );
			exit( 'Invalid JSON payload' );
		}
		
		// Handle webhook
		$result = $this->handle_payment_webhook( $gateway, array(
			'payload' => $payload,
			'data' => $webhook_data,
			'headers' => getallheaders()
		) );
		
		if ( $result ) {
			status_header( 200 );
			exit( 'OK' );
		} else {
			status_header( 400 );
			exit( 'Webhook processing failed' );
		}
	}
	
	/**
	 * Enqueue checkout scripts
	 */
	public function enqueue_checkout_scripts() {
		// Only enqueue on pages that might have inline checkout
		if ( ! $this->should_enqueue_checkout_scripts() ) {
			return;
		}
		
		wp_enqueue_script(
			'cf7mc-inline-checkout',
			CF7MC_PLUGIN_URL . '/assets/js/inline-checkout.js',
			array( 'jquery' ),
			CF7MC_VERSION,
			true
		);
		
		wp_localize_script( 'cf7mc-inline-checkout', 'cf7mc_checkout', array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce' => wp_create_nonce( 'cf7mc_checkout' ),
			'webhook_url' => admin_url( 'admin-ajax.php?action=cf7mc_webhook' ),
			'strings' => array(
				'processing' => __( 'Processing payment...', CF7MC_TEXT_DOMAIN ),
				'success' => __( 'Payment successful!', CF7MC_TEXT_DOMAIN ),
				'error' => __( 'Payment failed. Please try again.', CF7MC_TEXT_DOMAIN ),
				'timeout' => __( 'Payment is taking longer than expected. Please wait...', CF7MC_TEXT_DOMAIN ),
			)
		) );
		
		wp_enqueue_style(
			'cf7mc-inline-checkout',
			CF7MC_PLUGIN_URL . '/assets/css/inline-checkout.css',
			array(),
			CF7MC_VERSION
		);
	}
	
	/**
	 * Check if checkout scripts should be enqueued
	 *
	 * @return bool
	 */
	private function should_enqueue_checkout_scripts() {
		// Enqueue on conversation pages or forms with ecommerce enabled
		return is_singular() || 
			   ( isset( $_SERVER['REQUEST_URI'] ) && strpos( $_SERVER['REQUEST_URI'], 'cf7conv' ) !== false );
	}
}