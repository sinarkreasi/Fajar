<?php

namespace CF7MC\Gateways;

use CF7MC\Core\OptionsManager;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * TriPay Gateway for Indonesian payments
 */
class TripayGateway implements GatewayInterface {
	
	/**
	 * Gateway ID
	 */
	const ID = 'tripay';
	
	/**
	 * API URLs
	 */
	const SANDBOX_URL = 'https://tripay.co.id/api-sandbox';
	const PRODUCTION_URL = 'https://tripay.co.id/api';
	
	/**
	 * Get gateway ID
	 *
	 * @return string
	 */
	public function get_id() {
		return self::ID;
	}
	
	/**
	 * Get gateway title
	 *
	 * @return string
	 */
	public function get_title() {
		return __( 'TriPay', CF7MC_TEXT_DOMAIN );
	}
	
	/**
	 * Get gateway description
	 *
	 * @return string
	 */
	public function get_description() {
		return __( 'Indonesian payment gateway supporting various local payment methods including bank transfers, e-wallets, and retail outlets.', CF7MC_TEXT_DOMAIN );
	}
	
	/**
	 * Check if gateway is available
	 *
	 * @return bool
	 */
	public function is_available() {
		$options = OptionsManager::get_gateway_options( self::ID );
		return ! empty( $options['api_key'] ) && ! empty( $options['private_key'] ) && ! empty( $options['merchant_code'] );
	}
	
	/**
	 * Get gateway configuration fields
	 *
	 * @return array
	 */
	public function get_config_fields() {
		return array(
			'enabled' => array(
				'title'   => __( 'Enable TriPay', CF7MC_TEXT_DOMAIN ),
				'type'    => 'checkbox',
				'default' => false,
			),
			'title' => array(
				'title'       => __( 'Title', CF7MC_TEXT_DOMAIN ),
				'type'        => 'text',
				'description' => __( 'Payment method title that customers will see.', CF7MC_TEXT_DOMAIN ),
				'default'     => $this->get_title(),
			),
			'sandbox_mode' => array(
				'title'       => __( 'Sandbox Mode', CF7MC_TEXT_DOMAIN ),
				'type'        => 'checkbox',
				'description' => __( 'Enable sandbox mode for testing.', CF7MC_TEXT_DOMAIN ),
				'default'     => true,
			),
			'api_key' => array(
				'title'       => __( 'API Key', CF7MC_TEXT_DOMAIN ),
				'type'        => 'text',
				'description' => __( 'Your TriPay API Key from merchant dashboard.', CF7MC_TEXT_DOMAIN ),
				'default'     => '',
			),
			'private_key' => array(
				'title'       => __( 'Private Key', CF7MC_TEXT_DOMAIN ),
				'type'        => 'password',
				'description' => __( 'Your TriPay Private Key from merchant dashboard.', CF7MC_TEXT_DOMAIN ),
				'default'     => '',
			),
			'merchant_code' => array(
				'title'       => __( 'Merchant Code', CF7MC_TEXT_DOMAIN ),
				'type'        => 'text',
				'description' => __( 'Your TriPay Merchant Code.', CF7MC_TEXT_DOMAIN ),
				'default'     => '',
			),
			'payment_method' => array(
				'title'       => __( 'Default Payment Method', CF7MC_TEXT_DOMAIN ),
				'type'        => 'select',
				'description' => __( 'Default payment method for customers.', CF7MC_TEXT_DOMAIN ),
				'options'     => array(
					'BRIVA'    => 'BRI Virtual Account',
					'BNIVA'    => 'BNI Virtual Account',
					'BCAVA'    => 'BCA Virtual Account',
					'MANDIRIVA' => 'Mandiri Virtual Account',
					'ALFAMART' => 'Alfamart',
					'INDOMARET' => 'Indomaret',
					'OVO'      => 'OVO',
					'DANA'     => 'DANA',
					'GOPAY'    => 'GoPay',
					'LINKAJA'  => 'LinkAja',
					'SHOPEEPAY' => 'ShopeePay',
				),
				'default'     => 'BRIVA',
			),
		);
	}
	
	/**
	 * Create payment intent
	 *
	 * @param array $order
	 * @return array|WP_Error
	 */
	public function create_payment_intent( $order ) {
		$options = OptionsManager::get_gateway_options( self::ID );
		
		if ( ! $this->is_available() ) {
			return new \WP_Error( 'tripay_not_configured', __( 'TriPay gateway is not properly configured.', CF7MC_TEXT_DOMAIN ) );
		}
		
		$api_url = ! empty( $options['sandbox_mode'] ) ? self::SANDBOX_URL : self::PRODUCTION_URL;
		$endpoint = $api_url . '/transaction/create';
		
		// Prepare order items
		$order_items = array();
		foreach ( $order['items'] as $item ) {
			$order_items[] = array(
				'sku'         => $item['id'],
				'name'        => $item['name'],
				'price'       => (int) $item['price'],
				'quantity'    => (int) $item['quantity'],
				'product_url' => home_url(),
				'image_url'   => '',
			);
		}
		
		// Prepare payload
		$payload = array(
			'method'         => $options['payment_method'] ?? 'BRIVA',
			'merchant_ref'   => $order['order_code'],
			'amount'         => (int) $order['total_amount'],
			'customer_name'  => $this->extract_customer_name( $order['email'] ),
			'customer_email' => $order['email'],
			'customer_phone' => '',
			'order_items'    => $order_items,
			'return_url'     => home_url( '?cf7mc_return=tripay&order=' . $order['order_code'] ),
			'expired_time'   => ( time() + ( 24 * 60 * 60 ) ), // 24 hours
			'signature'      => $this->generate_signature( $order['order_code'], $order['total_amount'], $options ),
		);
		
		// Make API request
		$response = $this->make_api_request( $endpoint, $payload, $options );
		
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		
		if ( ! isset( $response['success'] ) || ! $response['success'] ) {
			$error_message = isset( $response['message'] ) ? $response['message'] : __( 'Unknown error from TriPay API.', CF7MC_TEXT_DOMAIN );
			return new \WP_Error( 'tripay_api_error', $error_message );
		}
		
		$transaction_data = $response['data'];
		
		return array(
			'id'            => $transaction_data['reference'],
			'amount'        => $order['total_amount'],
			'currency'      => 'IDR',
			'status'        => 'requires_payment_method',
			'checkout_url'  => $transaction_data['checkout_url'],
			'payment_data'  => $transaction_data,
		);
	}
	
	/**
	 * Get checkout URL
	 *
	 * @param array $order
	 * @return string
	 */
	public function get_checkout_url( $order ) {
		// Create payment intent first
		$payment_intent = $this->create_payment_intent( $order );
		
		if ( is_wp_error( $payment_intent ) ) {
			cf7mc_log( 'TriPay checkout URL error: ' . $payment_intent->get_error_message(), 'error' );
			return home_url( '?cf7mc_error=payment_failed' );
		}
		
		return $payment_intent['checkout_url'];
	}
	
	/**
	 * Process webhook
	 *
	 * @param array $payload
	 * @return bool|WP_Error
	 */
	public function process_webhook( $payload ) {
		cf7mc_log( 'TriPay webhook received: ' . wp_json_encode( $payload ) );
		
		if ( ! isset( $payload['merchant_ref'] ) || ! isset( $payload['status'] ) ) {
			return new \WP_Error( 'invalid_webhook', __( 'Invalid webhook payload from TriPay.', CF7MC_TEXT_DOMAIN ) );
		}
		
		// Map TriPay status to our status
		$status_map = array(
			'PAID'      => 'paid',
			'EXPIRED'   => 'expired',
			'FAILED'    => 'failed',
			'CANCELLED' => 'failed',
			'UNPAID'    => 'pending',
		);
		
		$tripay_status = strtoupper( $payload['status'] );
		$order_status = isset( $status_map[ $tripay_status ] ) ? $status_map[ $tripay_status ] : 'pending';
		
		return array(
			'order_code' => sanitize_text_field( $payload['merchant_ref'] ),
			'status'     => $order_status,
			'gateway_id' => sanitize_text_field( $payload['reference'] ?? '' ),
		);
	}
	
	/**
	 * Verify webhook signature
	 *
	 * @param string $payload
	 * @param string $signature
	 * @return bool
	 */
	public function verify_webhook_signature( $payload, $signature ) {
		$options = OptionsManager::get_gateway_options( self::ID );
		
		if ( empty( $options['private_key'] ) ) {
			return false;
		}
		
		// TriPay uses HMAC SHA256 for webhook signature
		$expected_signature = hash_hmac( 'sha256', $payload, $options['private_key'] );
		
		return hash_equals( $expected_signature, $signature );
	}
	
	/**
	 * Generate signature for API request
	 *
	 * @param string $merchant_ref
	 * @param float $amount
	 * @param array $options
	 * @return string
	 */
	private function generate_signature( $merchant_ref, $amount, $options ) {
		$data = $options['merchant_code'] . $merchant_ref . (int) $amount;
		return hash_hmac( 'sha256', $data, $options['private_key'] );
	}
	
	/**
	 * Make API request to TriPay
	 *
	 * @param string $endpoint
	 * @param array $payload
	 * @param array $options
	 * @return array|WP_Error
	 */
	private function make_api_request( $endpoint, $payload, $options ) {
		$headers = array(
			'Authorization' => 'Bearer ' . $options['api_key'],
			'Content-Type'  => 'application/json',
		);
		
		$args = array(
			'method'  => 'POST',
			'headers' => $headers,
			'body'    => wp_json_encode( $payload ),
			'timeout' => 30,
		);
		
		$response = wp_remote_request( $endpoint, $args );
		
		if ( is_wp_error( $response ) ) {
			cf7mc_log( 'TriPay API request failed: ' . $response->get_error_message(), 'error' );
			return $response;
		}
		
		$response_code = wp_remote_retrieve_response_code( $response );
		$response_body = wp_remote_retrieve_body( $response );
		
		if ( $response_code !== 200 ) {
			cf7mc_log( "TriPay API returned status {$response_code}: {$response_body}", 'error' );
			return new \WP_Error( 'tripay_api_error', sprintf( __( 'TriPay API error: %s', CF7MC_TEXT_DOMAIN ), $response_code ) );
		}
		
		$data = json_decode( $response_body, true );
		
		if ( json_last_error() !== JSON_ERROR_NONE ) {
			cf7mc_log( 'TriPay API returned invalid JSON: ' . $response_body, 'error' );
			return new \WP_Error( 'tripay_invalid_response', __( 'Invalid response from TriPay API.', CF7MC_TEXT_DOMAIN ) );
		}
		
		return $data;
	}
	
	/**
	 * Extract customer name from email
	 *
	 * @param string $email
	 * @return string
	 */
	private function extract_customer_name( $email ) {
		$name = strstr( $email, '@', true );
		return ucfirst( str_replace( array( '.', '_', '-' ), ' ', $name ) );
	}
}