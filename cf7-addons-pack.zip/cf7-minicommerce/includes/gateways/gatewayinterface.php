<?php

namespace CF7MC\Gateways;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Gateway interface
 */
interface GatewayInterface {
	
	/**
	 * Get gateway ID
	 *
	 * @return string
	 */
	public function get_id();
	
	/**
	 * Get gateway title
	 *
	 * @return string
	 */
	public function get_title();
	
	/**
	 * Get gateway description
	 *
	 * @return string
	 */
	public function get_description();
	
	/**
	 * Check if gateway is available
	 *
	 * @return bool
	 */
	public function is_available();
	
	/**
	 * Get gateway configuration fields
	 *
	 * @return array
	 */
	public function get_config_fields();
	
	/**
	 * Create payment intent
	 *
	 * @param array $order
	 * @return array|WP_Error
	 */
	public function create_payment_intent( $order );
	
	/**
	 * Get checkout URL
	 *
	 * @param array $order
	 * @return string
	 */
	public function get_checkout_url( $order );
	
	/**
	 * Process webhook
	 *
	 * @param array $payload
	 * @return bool|WP_Error
	 */
	public function process_webhook( $payload );
	
	/**
	 * Verify webhook signature
	 *
	 * @param string $payload
	 * @param string $signature
	 * @return bool
	 */
	public function verify_webhook_signature( $payload, $signature );
}