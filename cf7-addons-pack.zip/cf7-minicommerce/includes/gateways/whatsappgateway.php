<?php

namespace CF7MC\Gateways;

use CF7MC\Core\OptionsManager;
use CF7MC\Interfaces\PaymentGatewayInterface;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WhatsApp gateway for instant checkout
 */
class WhatsAppGateway implements PaymentGatewayInterface {
	
	/**
	 * Gateway ID
	 */
	const ID = 'whatsapp';
	
	/**
	 * Get gateway ID
	 *
	 * @return string
	 */
	public function get_id() {
		return self::ID;
	}
	
	/**
	 * Get gateway title
	 *
	 * @return string
	 */
	public function get_title() {
		return __( 'WhatsApp Checkout', CF7MC_TEXT_DOMAIN );
	}
	
	/**
	 * Get gateway name
	 *
	 * @return string
	 */
	public function get_name() {
		return $this->get_title();
	}
	
	/**
	 * Check if gateway supports inline checkout
	 *
	 * @return bool
	 */
	public function supports_inline_checkout() {
		return true; // WhatsApp supports inline checkout
	}
	
	/**
	 * Get gateway description
	 *
	 * @return string
	 */
	public function get_description() {
		return __( 'Complete your purchase via WhatsApp with our sales team. Fast, personal, and secure.', CF7MC_TEXT_DOMAIN );
	}
	
	/**
	 * Check if gateway is available
	 *
	 * @return bool
	 */
	public function is_available() {
		$phone = $this->get_whatsapp_number();
		return ! empty( $phone );
	}
	
	/**
	 * Get gateway configuration fields
	 *
	 * @return array
	 */
	public function get_config_fields() {
		return array(
			'enabled' => array(
				'title'   => __( 'Enable WhatsApp Checkout', CF7MC_TEXT_DOMAIN ),
				'type'    => 'checkbox',
				'default' => true,
			),
			'title' => array(
				'title'       => __( 'Title', CF7MC_TEXT_DOMAIN ),
				'type'        => 'text',
				'description' => __( 'Payment method title that customers will see.', CF7MC_TEXT_DOMAIN ),
				'default'     => $this->get_title(),
			),
			'whatsapp_number' => array(
				'title'       => __( 'WhatsApp Business Number', CF7MC_TEXT_DOMAIN ),
				'type'        => 'text',
				'description' => __( 'Your WhatsApp Business number with country code (e.g., +1234567890)', CF7MC_TEXT_DOMAIN ),
				'placeholder' => '+1234567890',
				'required'    => true,
			),
			'message_template' => array(
				'title'       => __( 'Message Template', CF7MC_TEXT_DOMAIN ),
				'type'        => 'textarea',
				'description' => __( 'WhatsApp message template. Use {order_code}, {amount}, {currency}, {customer_name}, {customer_email}, {items} as placeholders.', CF7MC_TEXT_DOMAIN ),
				'default'     => $this->get_default_message_template(),
				'rows'        => 8,
			),
			'auto_complete_hours' => array(
				'title'       => __( 'Auto Complete After (Hours)', CF7MC_TEXT_DOMAIN ),
				'type'        => 'number',
				'description' => __( 'Automatically mark order as completed after X hours. Set to 0 to disable.', CF7MC_TEXT_DOMAIN ),
				'default'     => 24,
				'min'         => 0,
				'max'         => 168, // 1 week
			),
			'button_text' => array(
				'title'       => __( 'Checkout Button Text', CF7MC_TEXT_DOMAIN ),
				'type'        => 'text',
				'description' => __( 'Text displayed on the WhatsApp checkout button.', CF7MC_TEXT_DOMAIN ),
				'default'     => __( 'Complete Order via WhatsApp', CF7MC_TEXT_DOMAIN ),
			),
			'success_message' => array(
				'title'       => __( 'Success Message', CF7MC_TEXT_DOMAIN ),
				'type'        => 'textarea',
				'description' => __( 'Message shown after customer clicks WhatsApp button.', CF7MC_TEXT_DOMAIN ),
				'default'     => __( 'Thank you! Please complete your payment via WhatsApp. Our team will contact you shortly.', CF7MC_TEXT_DOMAIN ),
				'rows'        => 3,
			),
		);
	}
	
	/**
	 * Create payment intent
	 *
	 * @param array $order
	 * @return array|WP_Error
	 */
	public function create_payment_intent( $order ) {
		// Generate WhatsApp checkout intent
		$payment_intent = array(
			'id'            => 'wa_pi_' . $order['order_code'],
			'amount'        => $order['total_amount'],
			'currency'      => cf7mc_get_option( 'currency', 'USD' ),
			'status'        => 'requires_payment_method',
			'whatsapp_url'  => $this->generate_whatsapp_url( $order ),
		);
		
		cf7mc_log( 'WhatsApp payment intent created: ' . $payment_intent['id'] );
		
		return $payment_intent;
	}
	
	/**
	 * Create payment session for inline checkout
	 *
	 * @param array $order Order data
	 * @return array|false Session data or false on failure
	 */
	public function create_payment_session( $order ) {
		$session_data = array(
			'session_id' => 'wa_session_' . $order['order_code'],
			'intent_id' => 'wa_pi_' . $order['order_code'],
			'whatsapp_url' => $this->generate_whatsapp_url( $order ),
			'gateway' => 'whatsapp',
			'amount' => $order['total_amount'],
			'currency' => cf7mc_get_option( 'currency', 'USD' ),
		);
		
		cf7mc_log( 'WhatsApp payment session created: ' . $session_data['session_id'] );
		
		return $session_data;
	}
	
	/**
	 * Get client-side configuration for inline checkout
	 *
	 * @param array $session_data
	 * @return array
	 */
	public function get_client_config( $session_data ) {
		return array(
			'gateway' => 'whatsapp',
			'whatsapp_url' => $session_data['whatsapp_url'],
			'button_text' => cf7mc_get_gateway_option( 'whatsapp', 'button_text', __( 'Complete Order via WhatsApp', CF7MC_TEXT_DOMAIN ) ),
			'success_message' => cf7mc_get_gateway_option( 'whatsapp', 'success_message', __( 'Thank you! Please complete your payment via WhatsApp. Our team will contact you shortly.', CF7MC_TEXT_DOMAIN ) ),
		);
	}
	
	/**
	 * Confirm payment from client-side
	 *
	 * @param array $payment_data
	 * @return array Result with success/error
	 */
	public function confirm_payment( $payment_data ) {
		// For WhatsApp, we consider the payment "confirmed" when user clicks the WhatsApp button
		// Actual payment confirmation happens manually by admin
		return array(
			'success' => true,
			'message' => __( 'WhatsApp payment initiated. Please complete payment via WhatsApp.', CF7MC_TEXT_DOMAIN ),
			'requires_manual_confirmation' => true,
		);
	}
	
	/**
	 * Handle webhook from payment provider
	 *
	 * @param array $webhook_data
	 * @return bool
	 */
	public function handle_webhook( $webhook_data ) {
		// WhatsApp doesn't send webhooks, manual processing required
		cf7mc_log( 'WhatsApp gateway does not support webhooks', 'info' );
		return false;
	}
	
	/**
	 * Refund payment
	 *
	 * @param string $payment_id
	 * @param float $amount
	 * @return bool
	 */
	public function refund_payment( $payment_id, $amount = null ) {
		// WhatsApp refunds must be handled manually
		cf7mc_log( "WhatsApp refund requested for payment: $payment_id", 'info' );
		return false; // Manual process
	}
	
	/**
	 * Get payment status from provider
	 *
	 * @param string $payment_id
	 * @return string
	 */
	public function get_payment_status( $payment_id ) {
		// WhatsApp payments are always pending until manually confirmed
		return 'pending';
	}
	
	/**
	 * Get required JavaScript libraries for inline checkout
	 *
	 * @return array Array of script URLs
	 */
	public function get_required_scripts() {
		// WhatsApp doesn't require external scripts
		return array();
	}
	
	/**
	 * Validate webhook signature
	 *
	 * @param string $payload
	 * @param string $signature
	 * @return bool
	 */
	public function validate_webhook_signature( $payload, $signature ) {
		// WhatsApp doesn't use webhooks
		return false;
	}
	
	/**
	 * Generate WhatsApp URL with order details
	 *
	 * @param array $order
	 * @return string
	 */
	private function generate_whatsapp_url( $order ) {
		$phone = $this->get_whatsapp_number();
		$message = $this->generate_message( $order );
		
		// Clean phone number (remove spaces, dashes, etc.)
		$phone = preg_replace( '/[^0-9+]/', '', $phone );
		
		// Remove + from phone number for WhatsApp URL
		$phone = ltrim( $phone, '+' );
		
		// Generate WhatsApp URL
		$whatsapp_url = 'https://wa.me/' . $phone . '?text=' . urlencode( $message );
		
		cf7mc_log( "WhatsApp URL generated for order {$order['order_code']}: {$whatsapp_url}" );
		
		return $whatsapp_url;
	}
	
	/**
	 * Generate WhatsApp message from template
	 *
	 * @param array $order
	 * @return string
	 */
	private function generate_message( $order ) {
		$template = $this->get_message_template();
		$currency = cf7mc_get_option( 'currency', 'USD' );
		
		// Prepare order items text
		$items_text = '';
		if ( ! empty( $order['items'] ) ) {
			$items_list = is_string( $order['items'] ) ? json_decode( $order['items'], true ) : $order['items'];
			if ( is_array( $items_list ) ) {
				$items_text = implode( ', ', array_map( function( $item ) {
					return is_array( $item ) ? ( $item['name'] ?? $item['title'] ?? 'Item' ) : $item;
				}, $items_list ) );
			}
		}
		
		// Replace placeholders
		$replacements = array(
			'{order_code}'     => $order['order_code'],
			'{amount}'         => cf7mc_format_price( $order['total_amount'], $currency ),
			'{currency}'       => $currency,
			'{customer_name}'  => $order['customer_name'] ?? __( 'Customer', CF7MC_TEXT_DOMAIN ),
			'{customer_email}' => $order['email'] ?? '',
			'{items}'          => $items_text,
			'{site_name}'      => get_bloginfo( 'name' ),
			'{site_url}'       => home_url(),
			'{date}'           => date_i18n( get_option( 'date_format' ) ),
			'{time}'           => date_i18n( get_option( 'time_format' ) ),
		);
		
		$message = str_replace( array_keys( $replacements ), array_values( $replacements ), $template );
		
		return $message;
	}
	
	/**
	 * Get WhatsApp number from settings
	 *
	 * @return string
	 */
	private function get_whatsapp_number() {
		return cf7mc_get_gateway_option( 'whatsapp', 'whatsapp_number', '' );
	}
	
	/**
	 * Get message template from settings
	 *
	 * @return string
	 */
	private function get_message_template() {
		return cf7mc_get_gateway_option( 'whatsapp', 'message_template', $this->get_default_message_template() );
	}
	
	/**
	 * Get default message template
	 *
	 * @return string
	 */
	private function get_default_message_template() {
		return __( "Hello! I'd like to complete my order:\n\n" .
			"🛒 *Order Details*\n" .
			"Order ID: {order_code}\n" .
			"Amount: {amount}\n" .
			"Items: {items}\n\n" .
			"👤 *Customer Information*\n" .
			"Name: {customer_name}\n" .
			"Email: {customer_email}\n\n" .
			"Please let me know how to proceed with the payment.\n\n" .
			"Thank you!", CF7MC_TEXT_DOMAIN );
	}
	
	/**
	 * Handle order completion after WhatsApp redirect
	 */
	public static function handle_whatsapp_return() {
		// Check if this is a WhatsApp return
		if ( ! isset( $_GET['cf7mc_whatsapp_return'] ) ) {
			return;
		}
		
		$order_code = sanitize_text_field( $_GET['order_code'] ?? '' );
		$nonce = sanitize_text_field( $_GET['nonce'] ?? '' );
		
		if ( ! wp_verify_nonce( $nonce, 'cf7mc_whatsapp_return' ) ) {
			return;
		}
		
		// Mark order as pending (customer contacted via WhatsApp)
		if ( ! empty( $order_code ) ) {
			$order_manager = new \CF7MC\Core\OrderManager();
			$order = $order_manager->get_order_by_code( $order_code );
			
			if ( $order && $order['status'] === 'pending_payment' ) {
				$order_manager->update_order_status( $order['id'], 'processing' );
				$order_manager->add_order_note( $order['id'], __( 'Customer contacted via WhatsApp for payment.', CF7MC_TEXT_DOMAIN ) );
				
				cf7mc_log( "Order {$order_code} marked as processing after WhatsApp contact" );
			}
		}
	}
	
	/**
	 * Schedule auto-completion for WhatsApp orders
	 *
	 * @param array $order
	 */
	public function schedule_auto_completion( $order ) {
		$auto_complete_hours = cf7mc_get_gateway_option( 'whatsapp', 'auto_complete_hours', 24 );
		
		if ( $auto_complete_hours > 0 ) {
			wp_schedule_single_event(
				time() + ( $auto_complete_hours * HOUR_IN_SECONDS ),
				'cf7mc_whatsapp_auto_complete',
				array( $order['id'] )
			);
			
			cf7mc_log( "Auto-completion scheduled for order {$order['order_code']} in {$auto_complete_hours} hours" );
		}
	}
}

// Handle WhatsApp return
add_action( 'template_redirect', array( 'CF7MC\Gateways\WhatsAppGateway', 'handle_whatsapp_return' ) );

// Handle auto-completion
add_action( 'cf7mc_whatsapp_auto_complete', 'cf7mc_handle_whatsapp_auto_complete' );

function cf7mc_handle_whatsapp_auto_complete( $order_id ) {
	$order_manager = new \CF7MC\Core\OrderManager();
	$order = $order_manager->get_order( $order_id );
	
	if ( $order && $order['status'] === 'processing' ) {
		$order_manager->update_order_status( $order_id, 'completed' );
		$order_manager->add_order_note( $order_id, __( 'Order auto-completed after WhatsApp timeout.', CF7MC_TEXT_DOMAIN ) );
		
		cf7mc_log( "Order {$order['order_code']} auto-completed via WhatsApp gateway" );
		
		// Trigger order completion hooks
		do_action( 'cf7mc_order_completed', $order_id, $order );
	}
}