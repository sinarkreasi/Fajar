<?php

namespace CF7MC\Gateways;

use CF7MC\Core\OptionsManager;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PayPal Gateway using Orders API v2
 */
class PaypalGateway implements GatewayInterface {
	
	/**
	 * Gateway ID
	 */
	const ID = 'paypal';
	
	/**
	 * API URLs
	 */
	const SANDBOX_URL = 'https://api-m.sandbox.paypal.com';
	const PRODUCTION_URL = 'https://api-m.paypal.com';
	
	/**
	 * Access token cache
	 */
	private $access_token = null;
	
	/**
	 * Get gateway ID
	 *
	 * @return string
	 */
	public function get_id() {
		return self::ID;
	}
	
	/**
	 * Get gateway title
	 *
	 * @return string
	 */
	public function get_title() {
		return __( 'PayPal', CF7MC_TEXT_DOMAIN );
	}
	
	/**
	 * Get gateway description
	 *
	 * @return string
	 */
	public function get_description() {
		return __( 'Accept payments via PayPal. Customers can pay with their PayPal account or credit/debit cards.', CF7MC_TEXT_DOMAIN );
	}
	
	/**
	 * Check if gateway is available
	 *
	 * @return bool
	 */
	public function is_available() {
		$options = OptionsManager::get_gateway_options( self::ID );
		return ! empty( $options['client_id'] ) && ! empty( $options['client_secret'] );
	}
	
	/**
	 * Get gateway configuration fields
	 *
	 * @return array
	 */
	public function get_config_fields() {
		return array(
			'enabled' => array(
				'title'   => __( 'Enable PayPal', CF7MC_TEXT_DOMAIN ),
				'type'    => 'checkbox',
				'default' => false,
			),
			'title' => array(
				'title'       => __( 'Title', CF7MC_TEXT_DOMAIN ),
				'type'        => 'text',
				'description' => __( 'Payment method title that customers will see.', CF7MC_TEXT_DOMAIN ),
				'default'     => $this->get_title(),
			),
			'sandbox_mode' => array(
				'title'       => __( 'Sandbox Mode', CF7MC_TEXT_DOMAIN ),
				'type'        => 'checkbox',
				'description' => __( 'Enable sandbox mode for testing.', CF7MC_TEXT_DOMAIN ),
				'default'     => true,
			),
			'client_id' => array(
				'title'       => __( 'Client ID', CF7MC_TEXT_DOMAIN ),
				'type'        => 'text',
				'description' => __( 'Your PayPal REST API Client ID.', CF7MC_TEXT_DOMAIN ),
				'default'     => '',
			),
			'client_secret' => array(
				'title'       => __( 'Client Secret', CF7MC_TEXT_DOMAIN ),
				'type'        => 'password',
				'description' => __( 'Your PayPal REST API Client Secret.', CF7MC_TEXT_DOMAIN ),
				'default'     => '',
			),
			'intent' => array(
				'title'       => __( 'Payment Intent', CF7MC_TEXT_DOMAIN ),
				'type'        => 'select',
				'description' => __( 'Payment capture method.', CF7MC_TEXT_DOMAIN ),
				'options'     => array(
					'CAPTURE'   => __( 'Capture (Immediate)', CF7MC_TEXT_DOMAIN ),
					'AUTHORIZE' => __( 'Authorize (Manual Capture)', CF7MC_TEXT_DOMAIN ),
				),
				'default'     => 'CAPTURE',
			),
			'brand_name' => array(
				'title'       => __( 'Brand Name', CF7MC_TEXT_DOMAIN ),
				'type'        => 'text',
				'description' => __( 'Brand name displayed on PayPal checkout page.', CF7MC_TEXT_DOMAIN ),
				'default'     => get_bloginfo( 'name' ),
			),
		);
	}
	
	/**
	 * Create payment intent
	 *
	 * @param array $order
	 * @return array|WP_Error
	 */
	public function create_payment_intent( $order ) {
		$options = OptionsManager::get_gateway_options( self::ID );
		
		if ( ! $this->is_available() ) {
			return new \WP_Error( 'paypal_not_configured', __( 'PayPal gateway is not properly configured.', CF7MC_TEXT_DOMAIN ) );
		}
		
		// Get access token
		$access_token = $this->get_access_token( $options );
		if ( is_wp_error( $access_token ) ) {
			return $access_token;
		}
		
		$api_url = ! empty( $options['sandbox_mode'] ) ? self::SANDBOX_URL : self::PRODUCTION_URL;
		$endpoint = $api_url . '/v2/checkout/orders';
		
		// Prepare order items
		$items = array();
		$item_total = 0;
		
		foreach ( $order['items'] as $item ) {
			$unit_amount = number_format( $item['price'], 2, '.', '' );
			$quantity = (int) $item['quantity'];
			$item_total += $item['price'] * $quantity;
			
			$items[] = array(
				'name'        => $item['name'],
				'description' => $item['description'] ?? '',
				'sku'         => $item['id'] ?? sanitize_title( $item['name'] ),
				'unit_amount' => array(
					'currency_code' => $this->get_currency(),
					'value'         => $unit_amount,
				),
				'quantity'    => (string) $quantity,
				'category'    => 'DIGITAL_GOODS',
			);
		}
		
		// Prepare purchase units
		$purchase_units = array(
			array(
				'reference_id' => $order['order_code'],
				'description'  => sprintf( __( 'Order %s', CF7MC_TEXT_DOMAIN ), $order['order_code'] ),
				'custom_id'    => $order['order_code'],
				'amount'       => array(
					'currency_code' => $this->get_currency(),
					'value'         => number_format( $order['total_amount'], 2, '.', '' ),
					'breakdown'     => array(
						'item_total' => array(
							'currency_code' => $this->get_currency(),
							'value'         => number_format( $item_total, 2, '.', '' ),
						),
					),
				),
				'items'        => $items,
			),
		);
		
		// Prepare payload
		$payload = array(
			'intent'              => $options['intent'] ?? 'CAPTURE',
			'purchase_units'      => $purchase_units,
			'application_context' => array(
				'brand_name'          => $options['brand_name'] ?? get_bloginfo( 'name' ),
				'landing_page'        => 'BILLING',
				'shipping_preference' => 'NO_SHIPPING',
				'user_action'         => 'PAY_NOW',
				'return_url'          => home_url( '?cf7mc_return=paypal&order=' . $order['order_code'] ),
				'cancel_url'          => home_url( '?cf7mc_cancel=paypal&order=' . $order['order_code'] ),
			),
		);
		
		// Make API request
		$response = $this->make_api_request( $endpoint, $payload, $access_token );
		
		if ( is_wp_error( $response ) ) {
			cf7mc_log( 'PayPal payment intent creation failed: ' . $response->get_error_message(), 'error' );
			return $response;
		}
		
		if ( ! isset( $response['id'] ) ) {
			cf7mc_log( 'PayPal API response missing ID: ' . wp_json_encode( $response ), 'error' );
			return new \WP_Error( 'paypal_api_error', __( 'Invalid response from PayPal API.', CF7MC_TEXT_DOMAIN ) );
		}
		
		cf7mc_log( 'PayPal payment intent created successfully: ' . $response['id'], 'info' );
		
		// Find approval URL
		$approval_url = '';
		if ( isset( $response['links'] ) ) {
			foreach ( $response['links'] as $link ) {
				if ( $link['rel'] === 'approve' ) {
					$approval_url = $link['href'];
					break;
				}
			}
		}
		
		return array(
			'id'            => $response['id'],
			'amount'        => $order['total_amount'],
			'currency'      => $this->get_currency(),
			'status'        => 'requires_payment_method',
			'checkout_url'  => $approval_url,
			'payment_data'  => $response,
		);
	}
	
	/**
	 * Get checkout URL
	 *
	 * @param array $order
	 * @return string
	 */
	public function get_checkout_url( $order ) {
		// Create payment intent first
		$payment_intent = $this->create_payment_intent( $order );
		
		if ( is_wp_error( $payment_intent ) ) {
			cf7mc_log( 'PayPal checkout URL error: ' . $payment_intent->get_error_message(), 'error' );
			return home_url( '?cf7mc_error=payment_failed' );
		}
		
		return $payment_intent['checkout_url'];
	}
	
	/**
	 * Process webhook
	 *
	 * @param array $payload
	 * @return bool|WP_Error
	 */
	public function process_webhook( $payload ) {
		cf7mc_log( 'PayPal webhook received: ' . wp_json_encode( $payload ) );
		
		if ( ! isset( $payload['event_type'] ) || ! isset( $payload['resource'] ) ) {
			return new \WP_Error( 'invalid_webhook', __( 'Invalid webhook payload from PayPal.', CF7MC_TEXT_DOMAIN ) );
		}
		
		$event_type = $payload['event_type'];
		$resource = $payload['resource'];
		
		// Handle different event types
		switch ( $event_type ) {
			case 'CHECKOUT.ORDER.APPROVED':
			case 'PAYMENT.CAPTURE.COMPLETED':
				$status = 'paid';
				break;
				
			case 'CHECKOUT.ORDER.CANCELLED':
			case 'PAYMENT.CAPTURE.DENIED':
				$status = 'failed';
				break;
				
			case 'CHECKOUT.ORDER.CREATED':
			default:
				$status = 'pending';
				break;
		}
		
		// Extract order reference
		$order_code = '';
		if ( isset( $resource['purchase_units'][0]['custom_id'] ) ) {
			$order_code = $resource['purchase_units'][0]['custom_id'];
		} elseif ( isset( $resource['purchase_units'][0]['reference_id'] ) ) {
			$order_code = $resource['purchase_units'][0]['reference_id'];
		}
		
		if ( empty( $order_code ) ) {
			return new \WP_Error( 'missing_order_reference', __( 'Order reference not found in PayPal webhook.', CF7MC_TEXT_DOMAIN ) );
		}
		
		return array(
			'order_code' => sanitize_text_field( $order_code ),
			'status'     => $status,
			'gateway_id' => sanitize_text_field( $resource['id'] ?? '' ),
		);
	}
	
	/**
	 * Verify webhook signature
	 *
	 * @param string $payload
	 * @param string $signature
	 * @return bool
	 */
	public function verify_webhook_signature( $payload, $signature ) {
		// PayPal webhook verification is more complex and requires webhook ID
		// For now, we'll implement basic verification
		// In production, you should implement proper PayPal webhook verification
		
		$options = OptionsManager::get_gateway_options( self::ID );
		
		// Basic verification - check if payload contains PayPal-specific fields
		$decoded_payload = json_decode( $payload, true );
		
		if ( ! $decoded_payload ) {
			return false;
		}
		
		// Check for PayPal-specific fields
		$required_fields = array( 'id', 'event_type', 'resource' );
		foreach ( $required_fields as $field ) {
			if ( ! isset( $decoded_payload[ $field ] ) ) {
				return false;
			}
		}
		
		// Additional verification can be implemented here
		// For production, implement PayPal's webhook signature verification
		
		return true;
	}
	
	/**
	 * Get access token
	 *
	 * @param array $options
	 * @return string|WP_Error
	 */
	private function get_access_token( $options ) {
		// Check if we have a cached token
		if ( $this->access_token ) {
			return $this->access_token;
		}
		
		$api_url = ! empty( $options['sandbox_mode'] ) ? self::SANDBOX_URL : self::PRODUCTION_URL;
		$endpoint = $api_url . '/v1/oauth2/token';
		
		$credentials = base64_encode( $options['client_id'] . ':' . $options['client_secret'] );
		
		$headers = array(
			'Authorization' => 'Basic ' . $credentials,
			'Content-Type'  => 'application/x-www-form-urlencoded',
		);
		
		$args = array(
			'method'  => 'POST',
			'headers' => $headers,
			'body'    => 'grant_type=client_credentials',
			'timeout' => 30,
		);
		
		$response = wp_remote_request( $endpoint, $args );
		
		if ( is_wp_error( $response ) ) {
			cf7mc_log( 'PayPal token request failed: ' . $response->get_error_message(), 'error' );
			return $response;
		}
		
		$response_code = wp_remote_retrieve_response_code( $response );
		$response_body = wp_remote_retrieve_body( $response );
		
		if ( $response_code !== 200 ) {
			cf7mc_log( "PayPal token request returned status {$response_code}: {$response_body}", 'error' );
			return new \WP_Error( 'paypal_auth_error', sprintf( __( 'PayPal authentication failed: %s', CF7MC_TEXT_DOMAIN ), $response_code ) );
		}
		
		$data = json_decode( $response_body, true );
		
		if ( json_last_error() !== JSON_ERROR_NONE || ! isset( $data['access_token'] ) ) {
			cf7mc_log( 'PayPal token response invalid: ' . $response_body, 'error' );
			return new \WP_Error( 'paypal_invalid_token_response', __( 'Invalid token response from PayPal.', CF7MC_TEXT_DOMAIN ) );
		}
		
		$this->access_token = $data['access_token'];
		
		return $this->access_token;
	}
	
	/**
	 * Make API request to PayPal
	 *
	 * @param string $endpoint
	 * @param array $payload
	 * @param string $access_token
	 * @return array|WP_Error
	 */
	private function make_api_request( $endpoint, $payload, $access_token ) {
		$headers = array(
			'Authorization'  => 'Bearer ' . $access_token,
			'Content-Type'   => 'application/json',
			'Prefer'         => 'return=representation',
		);
		
		$args = array(
			'method'  => 'POST',
			'headers' => $headers,
			'body'    => wp_json_encode( $payload ),
			'timeout' => 30,
		);
		
		$response = wp_remote_request( $endpoint, $args );
		
		if ( is_wp_error( $response ) ) {
			cf7mc_log( 'PayPal API request failed: ' . $response->get_error_message(), 'error' );
			return $response;
		}
		
		$response_code = wp_remote_retrieve_response_code( $response );
		$response_body = wp_remote_retrieve_body( $response );
		
		if ( ! in_array( $response_code, array( 200, 201 ) ) ) {
			cf7mc_log( "PayPal API returned status {$response_code}: {$response_body}", 'error' );
			return new \WP_Error( 'paypal_api_error', sprintf( __( 'PayPal API error: %s', CF7MC_TEXT_DOMAIN ), $response_code ) );
		}
		
		$data = json_decode( $response_body, true );
		
		if ( json_last_error() !== JSON_ERROR_NONE ) {
			cf7mc_log( 'PayPal API returned invalid JSON: ' . $response_body, 'error' );
			return new \WP_Error( 'paypal_invalid_response', __( 'Invalid response from PayPal API.', CF7MC_TEXT_DOMAIN ) );
		}
		
		return $data;
	}
	
	/**
	 * Get currency code
	 *
	 * @return string
	 */
	private function get_currency() {
		return cf7mc_get_option( 'currency', 'USD' );
	}
}