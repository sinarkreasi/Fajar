<?php

namespace CF7MC\Interfaces;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Payment Gateway Interface
 * 
 * All payment gateways must implement this interface for inline checkout
 */
interface PaymentGatewayInterface {
	
	/**
	 * Get gateway ID
	 *
	 * @return string
	 */
	public function get_id();
	
	/**
	 * Get gateway name
	 *
	 * @return string
	 */
	public function get_name();
	
	/**
	 * Get gateway description
	 *
	 * @return string
	 */
	public function get_description();
	
	/**
	 * Check if gateway supports inline checkout
	 *
	 * @return bool
	 */
	public function supports_inline_checkout();
	
	/**
	 * Create payment session for inline checkout
	 *
	 * @param array $order Order data
	 * @return array|false Session data or false on failure
	 */
	public function create_payment_session( $order );
	
	/**
	 * Get client-side configuration for inline checkout
	 *
	 * @param array $session_data
	 * @return array
	 */
	public function get_client_config( $session_data );
	
	/**
	 * Confirm payment from client-side
	 *
	 * @param array $payment_data
	 * @return array Result with success/error
	 */
	public function confirm_payment( $payment_data );
	
	/**
	 * Handle webhook from payment provider
	 *
	 * @param array $webhook_data
	 * @return bool
	 */
	public function handle_webhook( $webhook_data );
	
	/**
	 * Refund payment
	 *
	 * @param string $payment_id
	 * @param float $amount
	 * @return bool
	 */
	public function refund_payment( $payment_id, $amount = null );
	
	/**
	 * Get payment status from provider
	 *
	 * @param string $payment_id
	 * @return string
	 */
	public function get_payment_status( $payment_id );
	
	/**
	 * Get required JavaScript libraries for inline checkout
	 *
	 * @return array Array of script URLs
	 */
	public function get_required_scripts();
	
	/**
	 * Validate webhook signature
	 *
	 * @param string $payload
	 * @param string $signature
	 * @return bool
	 */
	public function validate_webhook_signature( $payload, $signature );
}