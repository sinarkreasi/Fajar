<?php

namespace CF7MC\Webhooks;

use CF7MC\Core\OrderManager;
use CF7MC\Core\GatewayManager;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Webhook handler class
 */
class WebhookHandler {
	
	/**
	 * Instance
	 *
	 * @var WebhookHandler
	 */
	private static $instance = null;
	
	/**
	 * Get instance
	 *
	 * @return WebhookHandler
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		$this->init_hooks();
	}
	
	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		add_action( 'template_redirect', array( $this, 'handle_webhook' ) );
	}
	
	/**
	 * Handle webhook requests
	 */
	public function handle_webhook() {
		if ( ! get_query_var( 'cf7mc_webhook' ) ) {
			return;
		}
		
		$gateway_id = get_query_var( 'gateway' );
		
		if ( empty( $gateway_id ) ) {
			$this->send_webhook_response( 400, array( 'error' => 'Missing gateway parameter' ) );
			return;
		}
		
		// Get gateway instance
		$gateway_manager = new GatewayManager();
		$gateway = $gateway_manager->get_gateway( $gateway_id );
		
		if ( ! $gateway ) {
			cf7mc_log( "Webhook received for unknown gateway: {$gateway_id}", 'error' );
			$this->send_webhook_response( 404, array( 'error' => 'Gateway not found' ) );
			return;
		}
		
		// Get request body
		$request_body = file_get_contents( 'php://input' );
		$request_headers = $this->get_request_headers();
		
		cf7mc_log( "Webhook received for gateway {$gateway_id}: " . substr( $request_body, 0, 500 ) );
		
		// Verify webhook signature
		$signature = $request_headers['X-Signature'] ?? $request_headers['HTTP_X_SIGNATURE'] ?? '';
		
		if ( ! $gateway->verify_webhook_signature( $request_body, $signature ) ) {
			cf7mc_log( "Invalid webhook signature for gateway: {$gateway_id}", 'error' );
			$this->send_webhook_response( 401, array( 'error' => 'Invalid signature' ) );
			return;
		}
		
		// Parse webhook payload
		$payload = json_decode( $request_body, true );
		
		if ( json_last_error() !== JSON_ERROR_NONE ) {
			cf7mc_log( "Invalid JSON in webhook payload for gateway: {$gateway_id}", 'error' );
			$this->send_webhook_response( 400, array( 'error' => 'Invalid JSON' ) );
			return;
		}
		
		// Process webhook
		$result = $gateway->process_webhook( $payload );
		
		if ( is_wp_error( $result ) ) {
			cf7mc_log( "Webhook processing failed: " . $result->get_error_message(), 'error' );
			$this->send_webhook_response( 400, array( 'error' => $result->get_error_message() ) );
			return;
		}
		
		// Update order status
		$this->update_order_from_webhook( $result );
		
		// Send success response
		$this->send_webhook_response( 200, array( 'status' => 'success' ) );
	}
	
	/**
	 * Update order from webhook result
	 *
	 * @param array $webhook_result
	 */
	private function update_order_from_webhook( $webhook_result ) {
		$order_manager = new OrderManager();
		
		$order_code = $webhook_result['order_code'] ?? '';
		$status = $webhook_result['status'] ?? '';
		$gateway_payment_id = $webhook_result['gateway_id'] ?? '';
		
		if ( empty( $order_code ) || empty( $status ) ) {
			cf7mc_log( 'Invalid webhook result: missing order_code or status', 'error' );
			return;
		}
		
		// Get order
		$order = $order_manager->get_order_by_code( $order_code );
		
		if ( ! $order ) {
			cf7mc_log( "Order not found for webhook: {$order_code}", 'error' );
			return;
		}
		
		// Update order status
		$updated = $order_manager->update_order_status( $order['id'], $status );
		
		if ( ! $updated ) {
			cf7mc_log( "Failed to update order status: {$order_code}", 'error' );
			return;
		}
		
		// Update gateway payment ID if provided
		if ( ! empty( $gateway_payment_id ) ) {
			global $wpdb;
			$table_name = $wpdb->prefix . CF7MC_ORDERS_TABLE;
			
			$wpdb->update(
				$table_name,
				array( 'gateway_payment_id' => $gateway_payment_id ),
				array( 'id' => $order['id'] ),
				array( '%s' ),
				array( '%d' )
			);
		}
		
		cf7mc_log( "Order {$order_code} status updated to {$status}" );
		
		// Trigger notifications
		$this->trigger_notifications( $order, $status );
	}
	
	/**
	 * Trigger notifications based on order status
	 *
	 * @param array $order
	 * @param string $status
	 */
	private function trigger_notifications( $order, $status ) {
		if ( $status === 'paid' ) {
			// Send customer notification
			$this->send_customer_notification( $order );
			
			// Send admin notification
			$this->send_admin_notification( $order );
		}
	}
	
	/**
	 * Send customer notification
	 *
	 * @param array $order
	 */
	private function send_customer_notification( $order ) {
		$email_enabled = cf7mc_get_option( 'email_notifications', array() );
		
		if ( empty( $email_enabled['customer_paid'] ) ) {
			return;
		}
		
		$to = $order['email'];
		$subject = sprintf( __( 'Payment Confirmed - Order %s', CF7MC_TEXT_DOMAIN ), $order['order_code'] );
		
		$message = sprintf(
			__( "Hello,\n\nYour payment has been confirmed for order %s.\n\nTotal Amount: %s\n\nThank you for your purchase!", CF7MC_TEXT_DOMAIN ),
			$order['order_code'],
			cf7mc_format_price( $order['total_amount'] )
		);
		
		wp_mail( $to, $subject, $message );
		
		cf7mc_log( "Customer notification sent to {$order['email']} for order {$order['order_code']}" );
	}
	
	/**
	 * Send admin notification
	 *
	 * @param array $order
	 */
	private function send_admin_notification( $order ) {
		$email_settings = cf7mc_get_option( 'email_notifications', array() );
		
		if ( empty( $email_settings['admin_new_order'] ) ) {
			return;
		}
		
		$admin_email = $email_settings['admin_email'] ?? get_option( 'admin_email' );
		$subject = sprintf( __( 'New Order Payment - %s', CF7MC_TEXT_DOMAIN ), $order['order_code'] );
		
		$message = sprintf(
			__( "A new order payment has been received:\n\nOrder Code: %s\nCustomer Email: %s\nTotal Amount: %s\nGateway: %s\n\nView order details in the admin panel.", CF7MC_TEXT_DOMAIN ),
			$order['order_code'],
			$order['email'],
			cf7mc_format_price( $order['total_amount'] ),
			$order['gateway']
		);
		
		wp_mail( $admin_email, $subject, $message );
		
		cf7mc_log( "Admin notification sent for order {$order['order_code']}" );
	}
	
	/**
	 * Get request headers
	 *
	 * @return array
	 */
	private function get_request_headers() {
		$headers = array();
		
		foreach ( $_SERVER as $key => $value ) {
			if ( strpos( $key, 'HTTP_' ) === 0 ) {
				$header = str_replace( 'HTTP_', '', $key );
				$header = str_replace( '_', '-', $header );
				$headers[ $header ] = $value;
			}
		}
		
		return $headers;
	}
	
	/**
	 * Send webhook response
	 *
	 * @param int $status_code
	 * @param array $data
	 */
	private function send_webhook_response( $status_code, $data ) {
		status_header( $status_code );
		header( 'Content-Type: application/json' );
		echo wp_json_encode( $data );
		exit;
	}
}