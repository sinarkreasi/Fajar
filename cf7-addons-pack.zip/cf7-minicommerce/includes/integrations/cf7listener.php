<?php

namespace CF7MC\Integrations;

use CF7MC\Core\OrderManager;
use CF7MC\Core\GatewayManager;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Contact Form 7 integration class
 */
class CF7Listener {
	
	/**
	 * Instance
	 *
	 * @var CF7Listener
	 */
	private static $instance = null;
	
	/**
	 * Get instance
	 *
	 * @return CF7Listener
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		$this->init_hooks();
	}
	
	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		add_action( 'wpcf7_before_send_mail', array( $this, 'process_form_submission' ), 10, 3 );
		add_filter( 'wpcf7_skip_mail', array( $this, 'maybe_skip_mail' ), 10, 2 );
	}
	
	/**
	 * Process form submission
	 *
	 * @param WPCF7_ContactForm $contact_form
	 * @param bool $abort
	 * @param WPCF7_Submission $submission
	 */
	public function process_form_submission( $contact_form, &$abort, $submission ) {
		// Check if this form has ecommerce enabled
		if ( ! $this->is_ecommerce_form( $contact_form ) ) {
			return;
		}
		
		$form_data = $submission->get_posted_data();
		
		// Debug: Log form data
		cf7mc_log( 'CF7 Form submission data: ' . print_r( $form_data, true ), 'debug' );
		
		// Validate required fields
		if ( ! $this->validate_required_fields( $form_data ) ) {
			cf7mc_log( 'Required fields validation failed', 'error' );
			$submission->set_status( 'validation_failed' );
			$submission->set_response( __( 'Required ecommerce fields are missing.', CF7MC_TEXT_DOMAIN ) );
			$abort = true;
			return;
		}
		
		// Extract product information from form data
		$product_info = $this->extract_product_info( $form_data );
		
		// Debug: Log product info
		cf7mc_log( 'Extracted product info: ' . print_r( $product_info, true ), 'debug' );
		
		if ( ! $product_info ) {
			cf7mc_log( 'Product info extraction failed', 'error' );
			$submission->set_status( 'validation_failed' );
			$submission->set_response( __( 'Invalid product information.', CF7MC_TEXT_DOMAIN ) );
			$abort = true;
			return;
		}
		
		// Get gateway
		$gateway_manager = new GatewayManager();
		$gateway_id = $this->get_form_gateway( $contact_form );
		if ( ! $gateway_id ) {
			$gateway_id = $gateway_manager->get_default_gateway();
		}
		
		if ( ! $gateway_id ) {
			cf7mc_log( 'No payment gateway available', 'error' );
			$submission->set_status( 'validation_failed' );
			$submission->set_response( __( 'No payment gateway available.', CF7MC_TEXT_DOMAIN ) );
			$abort = true;
			return;
		}
		
		// Create order
		$order_manager = new OrderManager();
		$order_data = array(
			'email'         => $this->get_customer_email( $form_data ),
			'customer_name' => $this->get_customer_name( $form_data ),
			'items'         => array( $product_info ),
			'total_amount'  => $product_info['price'] * $product_info['quantity'],
			'gateway'       => $gateway_id,
			'metadata'      => array(
				'form_id' => $contact_form->id(),
				'form_title' => $contact_form->title(),
				'source' => 'contact_form_7',
			),
		);
		
		$order_id = $order_manager->create_order( $order_data );
		
		if ( ! $order_id ) {
			cf7mc_log( 'Failed to create order', 'error' );
			$submission->set_status( 'validation_failed' );
			$submission->set_response( __( 'Failed to create order.', CF7MC_TEXT_DOMAIN ) );
			$abort = true;
			return;
		}
		
		// Get created order
		$order = $order_manager->get_order( $order_id );
		
		// Generate checkout URL (this will create payment intent if needed)
		$checkout_url = $this->generate_checkout_url( $order );
		
		// Set success response with checkout URL
		$response_message = sprintf(
			__( 'Order created successfully! <a href="%s" target="_blank">Click here to complete payment</a>', CF7MC_TEXT_DOMAIN ),
			esc_url( $checkout_url )
		);
		
		$submission->set_response( $response_message );
		
		// Store order info in transient for potential use (expires in 1 hour)
		$transient_key = 'cf7mc_order_' . $order['order_code'];
		set_transient( $transient_key, array(
			'order_code' => $order['order_code'],
			'checkout_url' => $checkout_url,
			'total_amount' => cf7mc_format_price( $order['total_amount'] ),
			'customer_email' => $order['email'],
			'created_at' => current_time( 'mysql' ),
		), HOUR_IN_SECONDS );
		
		cf7mc_log( "Order created from CF7 form: {$order['order_code']} for {$order['email']}" );
	}
	
	/**
	 * Check if form has ecommerce enabled
	 *
	 * @param WPCF7_ContactForm $contact_form
	 * @return bool
	 */
	private function is_ecommerce_form( $contact_form ) {
		// Check if ecommerce is enabled for all forms (debug mode)
		if ( cf7mc_get_option( 'enable_for_all_forms', false ) ) {
			cf7mc_log( 'Ecommerce enabled for all forms (debug mode)', 'debug' );
			return true;
		}
		
		// First check form properties for explicit ecommerce flag
		$properties = $contact_form->get_properties();
		if ( ! empty( $properties['cf7mc_enabled'] ) ) {
			cf7mc_log( 'Form has explicit ecommerce flag enabled', 'debug' );
			return true;
		}
		
		// Check form content for ecommerce-specific fields or tags
		$form_content = $contact_form->prop( 'form' );
		if ( ! $form_content ) {
			cf7mc_log( 'No form content found', 'debug' );
			return false;
		}
		
		$ecommerce_indicators = array(
			'product_id', 'product-id', 'product', 'price', 'amount', 'cost',
			'quantity', 'qty', 'service', 'item', 'total', 'cf7mc-product',
			'payment', 'checkout', 'order'
		);
		
		foreach ( $ecommerce_indicators as $indicator ) {
			if ( strpos( $form_content, $indicator ) !== false ) {
				cf7mc_log( "Found ecommerce indicator '$indicator' in form content", 'debug' );
				return true;
			}
		}
		
		// Check if this is being called from a conversation engine (which might have ecommerce)
		if ( isset( $_POST['cf7conv_session_id'] ) || isset( $_GET['cf7conv'] ) ) {
			cf7mc_log( 'Form submission from conversation engine, treating as ecommerce', 'debug' );
			return true;
		}
		
		cf7mc_log( 'No ecommerce indicators found in form', 'debug' );
		return false;
	}
	
	/**
	 * Extract product information from form data
	 *
	 * @param array $form_data
	 * @return array|null
	 */
	private function extract_product_info( $form_data ) {
		$product_info = array(
			'name' => 'Product',
			'price' => 0,
			'quantity' => 1,
		);
		
		// Handle product_id field which might contain "SEO Package - $300"
		if ( ! empty( $form_data['product_id'] ) ) {
			$product_id = $form_data['product_id'];
			
			// If it's an array, get the first element
			if ( is_array( $product_id ) ) {
				$product_id = $product_id[0];
			}
			
			// Parse product name and price from format like "SEO Package - $300"
			if ( preg_match( '/^(.+?)\s*-\s*\$?([0-9.,]+)$/', $product_id, $matches ) ) {
				$product_info['name'] = trim( $matches[1] );
				$product_info['price'] = cf7mc_sanitize_amount( $matches[2] );
				cf7mc_log( "Parsed product from product_id: {$product_info['name']} - \${$product_info['price']}", 'debug' );
			} else {
				// Just use as product name
				$product_info['name'] = sanitize_text_field( $product_id );
				cf7mc_log( "Using product_id as name: {$product_info['name']}", 'debug' );
			}
		}
		
		// Get product name - try multiple field variations
		$name_fields = array( 'product', 'product_name', 'product-name', 'item', 'service' );
		foreach ( $name_fields as $field ) {
			if ( ! empty( $form_data[ $field ] ) && $product_info['name'] === 'Product' ) {
				$product_info['name'] = sanitize_text_field( $form_data[ $field ] );
				break;
			}
		}
		
		// Get price - try multiple field variations (only if not already set from product_id)
		if ( $product_info['price'] <= 0 ) {
			$price_fields = array( 'price', 'amount', 'cost', 'total', 'product_price', 'product-price' );
			foreach ( $price_fields as $field ) {
				if ( ! empty( $form_data[ $field ] ) ) {
					$price = cf7mc_sanitize_amount( $form_data[ $field ] );
					if ( $price > 0 ) {
						$product_info['price'] = $price;
						break;
					}
				}
			}
		}
		
		// Get quantity - try multiple field variations
		$quantity_fields = array( 'quantity', 'qty', 'amount_qty', 'product_quantity', 'product-quantity' );
		foreach ( $quantity_fields as $field ) {
			if ( ! empty( $form_data[ $field ] ) ) {
				$qty = intval( $form_data[ $field ] );
				if ( $qty > 0 ) {
					$product_info['quantity'] = $qty;
					break;
				}
			}
		}
		
		// If no price found, try to set a default or extract from other fields
		if ( $product_info['price'] <= 0 ) {
			// Check if there's a fixed price in the form configuration
			$default_price = cf7mc_get_option( 'default_product_price', 0 );
			if ( $default_price > 0 ) {
				$product_info['price'] = $default_price;
			} else {
				// Set a minimal price to allow order creation
				$product_info['price'] = 1.00;
				cf7mc_log( 'No price found in form data, using default price: 1.00', 'warning' );
			}
		}
		
		// Log the final product info
		cf7mc_log( 'Final product info: ' . print_r( $product_info, true ), 'debug' );
		
		return $product_info;
	}
	
	/**
	 * Get customer email from form data
	 *
	 * @param array $form_data
	 * @return string
	 */
	private function get_customer_email( $form_data ) {
		$email_fields = array( 'your-email', 'email', 'customer-email', 'customer_email' );
		
		foreach ( $email_fields as $field ) {
			if ( ! empty( $form_data[ $field ] ) && is_email( $form_data[ $field ] ) ) {
				cf7mc_log( "Found email in field: $field = " . $form_data[ $field ], 'debug' );
				return sanitize_email( $form_data[ $field ] );
			}
		}
		
		return '';
	}
	
	/**
	 * Get customer name from form data
	 *
	 * @param array $form_data
	 * @return string
	 */
	private function get_customer_name( $form_data ) {
		$name_fields = array( 'your-name', 'name', 'customer-name', 'customer_name', 'first-name', 'first_name', 'full-name', 'full_name' );
		
		foreach ( $name_fields as $field ) {
			if ( ! empty( $form_data[ $field ] ) ) {
				$name = sanitize_text_field( $form_data[ $field ] );
				cf7mc_log( "Found customer name in field: $field = $name", 'debug' );
				return $name;
			}
		}
		
		// Try to combine first and last name
		$first_name = '';
		$last_name = '';
		
		$first_name_fields = array( 'first-name', 'first_name', 'fname' );
		foreach ( $first_name_fields as $field ) {
			if ( ! empty( $form_data[ $field ] ) ) {
				$first_name = sanitize_text_field( $form_data[ $field ] );
				break;
			}
		}
		
		$last_name_fields = array( 'last-name', 'last_name', 'lname', 'surname' );
		foreach ( $last_name_fields as $field ) {
			if ( ! empty( $form_data[ $field ] ) ) {
				$last_name = sanitize_text_field( $form_data[ $field ] );
				break;
			}
		}
		
		if ( $first_name || $last_name ) {
			$full_name = trim( $first_name . ' ' . $last_name );
			cf7mc_log( "Combined name from first/last: $full_name", 'debug' );
			return $full_name;
		}
		
		cf7mc_log( 'No customer name found in form data', 'debug' );
		return __( 'Customer', CF7MC_TEXT_DOMAIN );
	}
	
	/**
	 * Generate checkout URL for order
	 *
	 * @param array $order
	 * @return string
	 */
	private function generate_checkout_url( $order ) {
		// Get the gateway
		$gateway_manager = new GatewayManager();
		$gateway = $gateway_manager->get_gateway( $order['gateway'] );
		
		if ( $gateway ) {
			// For WhatsApp gateway, get the WhatsApp URL from payment intent
			if ( $order['gateway'] === 'whatsapp' && method_exists( $gateway, 'create_payment_intent' ) ) {
				$payment_intent = $gateway->create_payment_intent( $order );
				if ( is_array( $payment_intent ) && ! empty( $payment_intent['whatsapp_url'] ) ) {
					return $payment_intent['whatsapp_url'];
				}
			}
			
			// For other gateways, try to get checkout URL
			if ( method_exists( $gateway, 'get_checkout_url' ) ) {
				return $gateway->get_checkout_url( $order );
			}
		}
		
		// Default checkout URL
		return add_query_arg( array(
			'cf7mc_checkout' => $order['order_code'],
			'token' => wp_create_nonce( 'cf7mc_checkout_' . $order['order_code'] ),
		), home_url() );
	}
	
	/**
	 * Validate required ecommerce fields
	 *
	 * @param array $form_data
	 * @return bool
	 */
	private function validate_required_fields( $form_data ) {
		// Check for email
		$email_fields = array( 'your-email', 'email', 'customer-email', 'customer_email', 'user-email', 'user_email' );
		$has_email = false;
		
		foreach ( $email_fields as $field ) {
			if ( ! empty( $form_data[ $field ] ) && is_email( $form_data[ $field ] ) ) {
				$has_email = true;
				cf7mc_log( "Found email in field: $field = " . $form_data[ $field ], 'debug' );
				break;
			}
		}
		
		if ( ! $has_email ) {
			cf7mc_log( 'No valid email found in form data', 'error' );
			return false;
		}
		
		// For ecommerce, we don't strictly require product fields in validation
		// since we can use defaults in extract_product_info()
		// Just check that this looks like an ecommerce form
		$ecommerce_indicators = array( 
			'product', 'product_id', 'product-id', 'price', 'amount', 'cost', 
			'quantity', 'service', 'item', 'total' 
		);
		
		$has_ecommerce_field = false;
		foreach ( $ecommerce_indicators as $field ) {
			if ( isset( $form_data[ $field ] ) ) {
				$has_ecommerce_field = true;
				cf7mc_log( "Found ecommerce indicator field: $field", 'debug' );
				break;
			}
		}
		
		// If no specific ecommerce fields, allow it anyway (might be configured differently)
		if ( ! $has_ecommerce_field ) {
			cf7mc_log( 'No ecommerce indicator fields found, but allowing anyway', 'debug' );
		}
		
		return true;
	}
	
	/**
	 * Get gateway for form
	 *
	 * @param WPCF7_ContactForm $contact_form
	 * @return string|null
	 */
	private function get_form_gateway( $contact_form ) {
		$properties = $contact_form->get_properties();
		return $properties['cf7mc_gateway'] ?? null;
	}
	
	/**
	 * Maybe skip mail sending for ecommerce forms
	 *
	 * @param bool $skip_mail
	 * @param WPCF7_ContactForm $contact_form
	 * @return bool
	 */
	public function maybe_skip_mail( $skip_mail, $contact_form ) {
		// Skip mail for ecommerce forms until payment is confirmed
		if ( $this->is_ecommerce_form( $contact_form ) ) {
			$skip_on_pending = cf7mc_get_option( 'skip_mail_on_pending', true );
			if ( $skip_on_pending ) {
				return true;
			}
		}
		
		return $skip_mail;
	}
}