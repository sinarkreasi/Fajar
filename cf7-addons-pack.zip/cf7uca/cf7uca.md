# Coding AI Prompt: Unified Client Access (UCA) for Contact Form 7

## Role
You are a senior WordPress plugin architect with expertise in:
- Contact Form 7 ecosystem
- Token-based access systems
- Secure, account-less client portals
- Modular plugin architecture
- WordPress security best practices

You will build a **Unified Client Access (UCA)** plugin for Contact Form 7.

This plugin acts as a **central client access layer**
that allows users to access multiple CF7-related resources
without creating WordPress user accounts.

---

## Product Definition

Unified Client Access (UCA) is a **passwordless, token-based access system**
that provides a single entry point for clients to view and interact with
their data generated from Contact Form 7 submissions.

UCA is NOT:
- a membership system
- a user dashboard
- a WordPress authentication replacement

---

## Core Goals

- One magic link per client
- One access entry point
- Multiple related resources
- No WordPress login
- Secure, scoped, temporary access

---

## Key Principles (MANDATORY)

- Email-based identity only
- Token-based access only
- No persistent sessions
- Read-only by default
- Action-limited interactions
- Addons plug into UCA, not vice versa

---

## Supported Resource Types

UCA must support multiple resource types via adapters:
- order
- booking
- subscription
- file
- ticket
- custom (extensible)

Each resource belongs to an email identity.

---

## Token Model

Each access token must include:
- token_hash
- email
- access_scope (single | unified)
- expires_at
- usage_limit
- usage_count
- status (active | expired | revoked)
- created_at

Tokens must be stored hashed only.

---

## Database Requirements

Create custom tables on activation.

Example:
- `wp_cf7_uca_tokens`
- `wp_cf7_uca_logs` (optional)

Do NOT use:
- wp_users
- wp_usermeta
- wp_options for token storage

---

## Access Types

### 1. Single Resource Access
- One token → one resource (e.g. order)

### 2. Unified Access (UCA)
- One token → multiple resources
- Scoped by email
- Read-first

Unified access must be explicitly enabled.

---

## Unified Access Rules

When a unified token is validated:
- Load only resources linked to the token email
- Never allow resource ID via URL
- Resources are resolved internally via adapters

---

## Resource Adapter Interface

Each addon integrates via a resource adapter:

```php
interface UCA_Resource_Interface {
  public function get_resources_by_email( $email );
  public function render_resource_summary( $resource );
  public function render_resource_detail( $resource_id );
  public function allowed_actions( $resource_id );
}
```
UCA must not know internal addon logic.

Access Flow (Unified)

User submits CF7 form(s)

Addon creates resource(s)

UCA generates unified access token

Magic link sent to user

User opens /access/?token=XXX

Token validated

UCA loads all adapters

Resources resolved by email

Unified client view rendered

Unified Client View (Frontend)

Display:

Greeting (email-based)

Resource list grouped by type

Status indicators

Example:

Order #123 – Paid

Booking – Upcoming

Subscription – Active

Clicking a resource:

Revalidates token

Loads resource detail via adapter

Allowed Client Actions

Actions must be:

explicitly allowed per adapter

non-destructive

validated on every request

Examples:

retry payment

download invoice

upload file

reschedule booking

Security Requirements (CRITICAL)

Cryptographically secure token generation

Token hashing

Expiration enforcement

Usage limit enforcement

Rate limiting

HTTPS-only

Adapter-level permission checks

No direct object reference via URL

Admin Interface

Provide admin pages for:

Global UCA settings

Token list & management

Access logs

Adapter status (active/inactive)

Admin UI must be minimal and functional.

Configuration Options

Default token expiry

Unified access enable/disable

One-time vs multi-use tokens

Access page slug

Email template

Explicit Non-Goals (DO NOT IMPLEMENT)

WordPress user accounts

Login / logout system

Persistent sessions

Role-based access control

Profile editing

Admin-level actions

Architecture Requirements

Use modular architecture:

/core

TokenManager

AccessValidator

AccessController

/adapters

ResourceRegistry

AdapterLoader

/frontend

UnifiedViewRenderer

/admin

SettingsPage

TokenTable

/database

SchemaManager

/emails

MagicLinkMailer

All addons must integrate via adapters.

Output Expectations

Generate:

Plugin folder structure

Core bootstrap file

Token management logic

Unified access controller

Adapter interface & registry

Example adapter (mock)

Frontend unified access page

Code must be:

Secure

Extensible

Well-documented

WordPress coding standards compliant

Final Instruction

Start by:

Designing the UCA plugin architecture

Defining the resource adapter interface

Implementing token generation & validation

Building the unified access endpoint

Rendering unified client view

Proceed step-by-step.
Do NOT expand scope beyond this specification.