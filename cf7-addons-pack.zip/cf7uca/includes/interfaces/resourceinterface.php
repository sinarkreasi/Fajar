<?php

namespace CF7UCA\Interfaces;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Resource adapter interface
 * 
 * All UCA resource adapters must implement this interface
 */
interface ResourceInterface {
	
	/**
	 * Get resources by email
	 *
	 * @param string $email Client email
	 * @return array Array of resources
	 */
	public function get_resources_by_email( $email );
	
	/**
	 * Render resource summary
	 *
	 * @param array $resource Resource data
	 * @return string HTML output
	 */
	public function render_resource_summary( $resource );
	
	/**
	 * Render resource detail
	 *
	 * @param int $resource_id Resource ID
	 * @return string HTML output
	 */
	public function render_resource_detail( $resource_id );
	
	/**
	 * Get allowed actions for resource
	 *
	 * @param int $resource_id Resource ID
	 * @return array Array of allowed actions
	 */
	public function get_allowed_actions( $resource_id );
	
	/**
	 * Get resource type
	 *
	 * @return string Resource type identifier
	 */
	public function get_resource_type();
	
	/**
	 * Get resource type label
	 *
	 * @return string Human-readable resource type label
	 */
	public function get_resource_type_label();
	
	/**
	 * Validate resource access
	 *
	 * @param int $resource_id Resource ID
	 * @param string $email Client email
	 * @return bool True if access is allowed
	 */
	public function validate_resource_access( $resource_id, $email );
	
	/**
	 * Handle resource action
	 *
	 * @param string $action Action name
	 * @param int $resource_id Resource ID
	 * @param array $data Action data
	 * @return array Result array with success/error
	 */
	public function handle_resource_action( $action, $resource_id, $data = array() );
	
	/**
	 * Get resource status
	 *
	 * @param array $resource Resource data
	 * @return string Status identifier
	 */
	public function get_resource_status( $resource );
	
	/**
	 * Get resource status label
	 *
	 * @param string $status Status identifier
	 * @return string Human-readable status label
	 */
	public function get_resource_status_label( $status );
}