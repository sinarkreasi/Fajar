<?php

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Generate cryptographically secure token
 *
 * @return string Raw token
 */
function cf7uca_generate_secure_token() {
	return bin2hex( random_bytes( CF7UCA_TOKEN_LENGTH / 2 ) );
}

/**
 * Hash token for storage
 *
 * @param string $raw_token Raw token
 * @return string Hashed token
 */
function cf7uca_hash_token( $raw_token ) {
	return hash( 'sha256', $raw_token );
}

/**
 * Check if token is expired
 *
 * @param string $expires_at MySQL datetime
 * @return bool
 */
function cf7uca_is_token_expired( $expires_at ) {
	return strtotime( $expires_at ) < time();
}

/**
 * Get UCA option
 *
 * @param string $key Option key
 * @param mixed $default Default value
 * @return mixed
 */
function cf7uca_get_option( $key, $default = false ) {
	return CF7UCA\Core\OptionsManager::get( $key, $default );
}

/**
 * Update UCA option
 *
 * @param string $key Option key
 * @param mixed $value Option value
 * @return bool
 */
function cf7uca_update_option( $key, $value ) {
	return CF7UCA\Core\OptionsManager::set( $key, $value );
}

/**
 * Log UCA message
 *
 * @param string $message Log message
 * @param string $level Log level (info, warning, error)
 */
function cf7uca_log( $message, $level = 'info' ) {
	if ( ! cf7uca_get_option( 'debug_mode', false ) ) {
		return;
	}
	
	$log_entry = sprintf(
		'[%s] CF7UCA %s: %s',
		current_time( 'Y-m-d H:i:s' ),
		strtoupper( $level ),
		$message
	);
	
	error_log( $log_entry );
}

/**
 * Check if unified access is enabled
 *
 * @return bool
 */
function cf7uca_is_unified_access_enabled() {
	return cf7uca_get_option( 'enable_unified_access', true );
}

/**
 * Get access page slug
 *
 * @return string
 */
function cf7uca_get_access_page_slug() {
	return cf7uca_get_option( 'access_page_slug', 'access' );
}

/**
 * Get default token expiry hours
 *
 * @return int
 */
function cf7uca_get_default_expiry_hours() {
	return cf7uca_get_option( 'default_expiry_hours', CF7UCA_DEFAULT_EXPIRY_HOURS );
}

/**
 * Check if one-time tokens are enabled
 *
 * @return bool
 */
function cf7uca_is_one_time_tokens_enabled() {
	return cf7uca_get_option( 'one_time_tokens', false );
}

/**
 * Generate access URL
 *
 * @param string $token Raw token
 * @return string Access URL
 */
function cf7uca_generate_access_url( $token ) {
	$slug = cf7uca_get_access_page_slug();
	return home_url( $slug . '/?token=' . urlencode( $token ) );
}

/**
 * Sanitize email for UCA
 *
 * @param string $email Raw email
 * @return string Sanitized email
 */
function cf7uca_sanitize_email( $email ) {
	return sanitize_email( strtolower( trim( $email ) ) );
}

/**
 * Validate email format
 *
 * @param string $email Email to validate
 * @return bool
 */
function cf7uca_is_valid_email( $email ) {
	return is_email( $email );
}

/**
 * Get access scope options
 *
 * @return array
 */
function cf7uca_get_access_scopes() {
	return array(
		'single'  => __( 'Single Resource', CF7UCA_TEXT_DOMAIN ),
		'unified' => __( 'Unified Access', CF7UCA_TEXT_DOMAIN ),
	);
}

/**
 * Get token status options
 *
 * @return array
 */
function cf7uca_get_token_statuses() {
	return array(
		'active'  => __( 'Active', CF7UCA_TEXT_DOMAIN ),
		'expired' => __( 'Expired', CF7UCA_TEXT_DOMAIN ),
		'revoked' => __( 'Revoked', CF7UCA_TEXT_DOMAIN ),
	);
}

/**
 * Format date for display
 *
 * @param string $date MySQL datetime
 * @return string Formatted date
 */
function cf7uca_format_date( $date ) {
	return date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $date ) );
}

/**
 * Get resource type labels
 *
 * @return array
 */
function cf7uca_get_resource_type_labels() {
	return apply_filters( 'cf7uca_resource_type_labels', array(
		'order'        => __( 'Orders', CF7UCA_TEXT_DOMAIN ),
		'booking'      => __( 'Bookings', CF7UCA_TEXT_DOMAIN ),
		'subscription' => __( 'Subscriptions', CF7UCA_TEXT_DOMAIN ),
		'file'         => __( 'Files', CF7UCA_TEXT_DOMAIN ),
		'ticket'       => __( 'Tickets', CF7UCA_TEXT_DOMAIN ),
		'custom'       => __( 'Custom', CF7UCA_TEXT_DOMAIN ),
	));
}

/**
 * Check if current request is for UCA access
 *
 * @return bool
 */
function cf7uca_is_access_request() {
	return get_query_var( 'cf7uca_access' ) || ( isset( $_GET['token'] ) && cf7uca_is_access_page() );
}

/**
 * Check if current page is UCA access page
 *
 * @return bool
 */
function cf7uca_is_access_page() {
	global $wp;
	$slug = cf7uca_get_access_page_slug();
	return $wp->request === $slug || strpos( $wp->request, $slug . '/' ) === 0;
}

/**
 * Verify nonce for UCA
 *
 * @param string $nonce Nonce value
 * @param string $action Nonce action
 * @return bool
 */
function cf7uca_verify_nonce( $nonce, $action ) {
	return wp_verify_nonce( $nonce, $action );
}

/**
 * Rate limit check
 *
 * @param string $key Rate limit key
 * @param int $limit Request limit
 * @param int $window Time window in seconds
 * @return bool True if within limit
 */
function cf7uca_rate_limit_check( $key, $limit = 10, $window = 300 ) {
	$transient_key = 'cf7uca_rate_limit_' . md5( $key );
	$requests = get_transient( $transient_key );
	
	if ( $requests === false ) {
		set_transient( $transient_key, 1, $window );
		return true;
	}
	
	if ( $requests >= $limit ) {
		return false;
	}
	
	set_transient( $transient_key, $requests + 1, $window );
	return true;
}

/**
 * Get UCA version
 *
 * @return string
 */
function cf7uca_get_version() {
	return CF7UCA_VERSION;
}

/**
 * Check if HTTPS is required
 *
 * @return bool
 */
function cf7uca_requires_https() {
	return cf7uca_get_option( 'require_https' );
}

/**
 * Validate HTTPS requirement
 *
 * @return bool
 */
function cf7uca_validate_https() {
	if ( ! cf7uca_requires_https() ) {
		return true;
	}
	
	return is_ssl();
}

/**
 * Get registered adapters
 *
 * @return array
 */
function cf7uca_get_registered_adapters() {
	return CF7UCA\Adapters\ResourceRegistry::instance()->get_adapters();
}

/**
 * Register resource adapter
 *
 * @param string $type Resource type
 * @param string $class_name Adapter class name
 * @return bool
 */
function cf7uca_register_adapter( $type, $class_name ) {
	return CF7UCA\Adapters\ResourceRegistry::instance()->register_adapter( $type, $class_name );
}

/**
 * Get adapter for resource type
 *
 * @param string $type Resource type
 * @return CF7UCA\Interfaces\ResourceInterface|false
 */
function cf7uca_get_adapter( $type ) {
	return CF7UCA\Adapters\ResourceRegistry::instance()->get_adapter( $type );
}

/**
 * Create unified access token
 *
 * @param string $email Client email
 * @param array $args Optional arguments
 * @return int|false Token ID or false on failure
 */
function cf7uca_create_unified_token( $email, $args = array() ) {
	$token_manager = new CF7UCA\Core\TokenManager();
	
	$defaults = array(
		'access_scope' => 'unified',
		'expires_at'   => date( 'Y-m-d H:i:s', time() + ( cf7uca_get_default_expiry_hours() * HOUR_IN_SECONDS ) ),
		'usage_limit'  => cf7uca_is_one_time_tokens_enabled() ? 1 : null,
	);
	
	$token_data = wp_parse_args( $args, $defaults );
	$token_data['email'] = cf7uca_sanitize_email( $email );
	
	return $token_manager->create_token( $token_data );
}

/**
 * Send unified access email
 *
 * @param string $email Client email
 * @param string $token Raw token
 * @return bool
 */
function cf7uca_send_access_email( $email, $token ) {
	$mailer = new CF7UCA\Emails\MagicLinkMailer();
	return $mailer->send_unified_access_email( $email, $token );
}

