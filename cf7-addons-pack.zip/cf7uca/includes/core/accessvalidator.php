<?php

namespace CF7UCA\Core;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Access validation class
 */
class AccessValidator {
	
	/**
	 * Validate access request
	 *
	 * @param string $raw_token Raw token
	 * @return array Validation result
	 */
	public function validate_access( $raw_token ) {
		// Check HTTPS requirement
		if ( ! cf7uca_validate_https() ) {
			return array(
				'valid'   => false,
				'error'   => 'https_required',
				'message' => __( 'HTTPS is required for secure access.', CF7UCA_TEXT_DOMAIN ),
			);
		}
		
		// Rate limiting check
		if ( ! $this->check_rate_limit( $raw_token ) ) {
			return array(
				'valid'   => false,
				'error'   => 'rate_limit_exceeded',
				'message' => __( 'Too many requests. Please try again later.', CF7UCA_TEXT_DOMAIN ),
			);
		}
		
		// Validate token
		$token_manager = new TokenManager();
		$token_data = $token_manager->validate_token( $raw_token );
		
		if ( ! $token_data ) {
			return array(
				'valid'   => false,
				'error'   => 'invalid_token',
				'message' => __( 'Invalid or expired access token.', CF7UCA_TEXT_DOMAIN ),
			);
		}
		
		// Additional security checks
		$security_check = $this->perform_security_checks( $token_data );
		if ( ! $security_check['valid'] ) {
			return $security_check;
		}
		
		return array(
			'valid'      => true,
			'token_data' => $token_data,
			'message'    => __( 'Access granted.', CF7UCA_TEXT_DOMAIN ),
		);
	}
	
	/**
	 * Validate resource access
	 *
	 * @param array $token_data Token data
	 * @param string $resource_type Resource type
	 * @param int $resource_id Resource ID
	 * @return array Validation result
	 */
	public function validate_resource_access( $token_data, $resource_type, $resource_id ) {
		// Check if token allows unified access
		if ( $token_data['access_scope'] !== 'unified' ) {
			return array(
				'valid'   => false,
				'error'   => 'scope_mismatch',
				'message' => __( 'Token does not allow unified access.', CF7UCA_TEXT_DOMAIN ),
			);
		}
		
		// Get adapter for resource type
		$adapter = cf7uca_get_adapter( $resource_type );
		if ( ! $adapter ) {
			return array(
				'valid'   => false,
				'error'   => 'adapter_not_found',
				'message' => __( 'Resource type not supported.', CF7UCA_TEXT_DOMAIN ),
			);
		}
		
		// Validate resource access via adapter
		if ( ! $adapter->validate_resource_access( $resource_id, $token_data['email'] ) ) {
			return array(
				'valid'   => false,
				'error'   => 'resource_access_denied',
				'message' => __( 'Access to this resource is denied.', CF7UCA_TEXT_DOMAIN ),
			);
		}
		
		return array(
			'valid'   => true,
			'message' => __( 'Resource access granted.', CF7UCA_TEXT_DOMAIN ),
		);
	}
	
	/**
	 * Validate action permission
	 *
	 * @param array $token_data Token data
	 * @param string $resource_type Resource type
	 * @param int $resource_id Resource ID
	 * @param string $action Action name
	 * @return array Validation result
	 */
	public function validate_action_permission( $token_data, $resource_type, $resource_id, $action ) {
		// First validate resource access
		$resource_validation = $this->validate_resource_access( $token_data, $resource_type, $resource_id );
		if ( ! $resource_validation['valid'] ) {
			return $resource_validation;
		}
		
		// Get adapter for resource type
		$adapter = cf7uca_get_adapter( $resource_type );
		$allowed_actions = $adapter->get_allowed_actions( $resource_id );
		
		if ( ! in_array( $action, $allowed_actions ) ) {
			return array(
				'valid'   => false,
				'error'   => 'action_not_allowed',
				'message' => __( 'This action is not allowed for this resource.', CF7UCA_TEXT_DOMAIN ),
			);
		}
		
		return array(
			'valid'   => true,
			'message' => __( 'Action permission granted.', CF7UCA_TEXT_DOMAIN ),
		);
	}
	
	/**
	 * Check rate limiting
	 *
	 * @param string $token Raw token for rate limit key
	 * @return bool True if within rate limit
	 */
	private function check_rate_limit( $token ) {
		if ( ! cf7uca_get_option( 'rate_limit_enabled', true ) ) {
			return true;
		}
		
		$limit = cf7uca_get_option( 'rate_limit_requests', 10 );
		$window = cf7uca_get_option( 'rate_limit_window', 300 );
		
		// Use IP + token hash for rate limiting
		$rate_limit_key = $this->get_client_ip() . '_' . substr( cf7uca_hash_token( $token ), 0, 16 );
		
		return cf7uca_rate_limit_check( $rate_limit_key, $limit, $window );
	}
	
	/**
	 * Perform additional security checks
	 *
	 * @param array $token_data Token data
	 * @return array Security check result
	 */
	private function perform_security_checks( $token_data ) {
		// Check for suspicious activity patterns
		if ( $this->detect_suspicious_activity( $token_data ) ) {
			return array(
				'valid'   => false,
				'error'   => 'suspicious_activity',
				'message' => __( 'Suspicious activity detected. Access denied.', CF7UCA_TEXT_DOMAIN ),
			);
		}
		
		// Check token usage patterns
		if ( $this->check_usage_patterns( $token_data ) ) {
			return array(
				'valid'   => false,
				'error'   => 'unusual_usage',
				'message' => __( 'Unusual usage pattern detected. Access denied.', CF7UCA_TEXT_DOMAIN ),
			);
		}
		
		return array(
			'valid' => true,
		);
	}
	
	/**
	 * Detect suspicious activity
	 *
	 * @param array $token_data Token data
	 * @return bool True if suspicious activity detected
	 */
	private function detect_suspicious_activity( $token_data ) {
		global $wpdb;
		
		$logs_table = $wpdb->prefix . CF7UCA_LOGS_TABLE;
		
		// Check for rapid successive requests from same IP
		$recent_requests = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$logs_table} 
				WHERE ip_address = %s 
				AND created_at > DATE_SUB(NOW(), INTERVAL 1 MINUTE)",
				$this->get_client_ip()
			)
		);
		
		if ( $recent_requests > 20 ) {
			cf7uca_log( "Suspicious activity: {$recent_requests} requests in 1 minute from IP: " . $this->get_client_ip(), 'warning' );
			return true;
		}
		
		// Check for failed attempts
		$failed_attempts = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$logs_table} 
				WHERE email = %s 
				AND status = 'failure' 
				AND created_at > DATE_SUB(NOW(), INTERVAL 5 MINUTE)",
				$token_data['email']
			)
		);
		
		if ( $failed_attempts > 5 ) {
			cf7uca_log( "Suspicious activity: {$failed_attempts} failed attempts for email: " . $token_data['email'], 'warning' );
			return true;
		}
		
		return false;
	}
	
	/**
	 * Check usage patterns
	 *
	 * @param array $token_data Token data
	 * @return bool True if unusual usage detected
	 */
	private function check_usage_patterns( $token_data ) {
		// Check if token is being used too frequently
		if ( ! empty( $token_data['usage_limit'] ) ) {
			$usage_percentage = ( $token_data['usage_count'] / $token_data['usage_limit'] ) * 100;
			
			// If token has been used more than 80% of its limit in a short time, flag it
			if ( $usage_percentage > 80 ) {
				$token_age_hours = ( time() - strtotime( $token_data['created_at'] ) ) / HOUR_IN_SECONDS;
				
				if ( $token_age_hours < 1 ) {
					cf7uca_log( "Unusual usage: Token {$token_data['id']} used {$usage_percentage}% in {$token_age_hours} hours", 'warning' );
					return true;
				}
			}
		}
		
		return false;
	}
	
	/**
	 * Get client IP address
	 *
	 * @return string Client IP
	 */
	private function get_client_ip() {
		$ip_keys = array( 'HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR' );
		
		foreach ( $ip_keys as $key ) {
			if ( array_key_exists( $key, $_SERVER ) === true ) {
				foreach ( explode( ',', $_SERVER[ $key ] ) as $ip ) {
					$ip = trim( $ip );
					
					if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) !== false ) {
						return $ip;
					}
				}
			}
		}
		
		return isset( $_SERVER['REMOTE_ADDR'] ) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
	}
}