<?php

namespace CF7UCA\Core;

use CF7UCA\Adapters\ResourceRegistry;
use CF7UCA\Frontend\UnifiedViewRenderer;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Access controller class
 */
class AccessController {
	
	/**
	 * Controller instance
	 *
	 * @var AccessController
	 */
	private static $instance = null;
	
	/**
	 * Get controller instance
	 *
	 * @return AccessController
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		$this->init_hooks();
	}
	
	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		add_action( 'init', array( $this, 'init_rewrite_rules' ) );
		add_action( 'template_redirect', array( $this, 'handle_access_request' ) );
		add_action( 'wp_ajax_cf7uca_resource_action', array( $this, 'handle_resource_action' ) );
		add_action( 'wp_ajax_nopriv_cf7uca_resource_action', array( $this, 'handle_resource_action' ) );
	}
	
	/**
	 * Initialize rewrite rules
	 */
	public function init_rewrite_rules() {
		$access_slug = cf7uca_get_access_page_slug();
		
		// Add rewrite rule for access pages
		add_rewrite_rule( 
			"^{$access_slug}/?$", 
			'index.php?cf7uca_access=1', 
			'top' 
		);
		
		// Add rewrite rule for resource detail pages
		add_rewrite_rule( 
			"^{$access_slug}/([^/]+)/([0-9]+)/?$", 
			'index.php?cf7uca_access=1&cf7uca_resource_type=$matches[1]&cf7uca_resource_id=$matches[2]', 
			'top' 
		);
		
		// Add query vars
		add_filter( 'query_vars', function( $vars ) {
			$vars[] = 'cf7uca_access';
			$vars[] = 'cf7uca_resource_type';
			$vars[] = 'cf7uca_resource_id';
			return $vars;
		});
	}
	
	/**
	 * Handle access request
	 */
	public function handle_access_request() {
		// Check if this is a UCA access request
		if ( ! get_query_var( 'cf7uca_access' ) ) {
			return;
		}
		
		// Get token from request
		$token = $this->get_token_from_request();
		
		if ( empty( $token ) ) {
			$this->render_error_page( __( 'Access token is required.', CF7UCA_TEXT_DOMAIN ) );
			return;
		}
		
		// Validate access
		$validator = new AccessValidator();
		$validation_result = $validator->validate_access( $token );
		
		if ( ! $validation_result['valid'] ) {
			$this->render_error_page( $validation_result['message'] );
			return;
		}
		
		$token_data = $validation_result['token_data'];
		
		// Check if this is a resource detail request
		$resource_type = get_query_var( 'cf7uca_resource_type' );
		$resource_id = get_query_var( 'cf7uca_resource_id' );
		
		if ( $resource_type && $resource_id ) {
			$this->render_resource_detail( $token_data, $resource_type, $resource_id );
		} else {
			$this->render_unified_view( $token_data );
		}
	}
	
	/**
	 * Render unified view
	 *
	 * @param array $token_data Token data
	 */
	private function render_unified_view( $token_data ) {
		// Check if unified access is enabled
		if ( ! cf7uca_is_unified_access_enabled() ) {
			$this->render_error_page( __( 'Unified access is not enabled.', CF7UCA_TEXT_DOMAIN ) );
			return;
		}
		
		// Check token scope
		if ( $token_data['access_scope'] !== 'unified' ) {
			$this->render_error_page( __( 'This token does not allow unified access.', CF7UCA_TEXT_DOMAIN ) );
			return;
		}
		
		// Load resources via adapters
		$resources = $this->load_resources_by_email( $token_data['email'] );
		
		// Render unified view
		$renderer = UnifiedViewRenderer::instance();
		$renderer->render_unified_view( $token_data, $resources );
	}
	
	/**
	 * Render resource detail
	 *
	 * @param array $token_data Token data
	 * @param string $resource_type Resource type
	 * @param int $resource_id Resource ID
	 */
	private function render_resource_detail( $token_data, $resource_type, $resource_id ) {
		// Validate resource access
		$validator = new AccessValidator();
		$validation_result = $validator->validate_resource_access( $token_data, $resource_type, $resource_id );
		
		if ( ! $validation_result['valid'] ) {
			$this->render_error_page( $validation_result['message'] );
			return;
		}
		
		// Get adapter
		$adapter = cf7uca_get_adapter( $resource_type );
		if ( ! $adapter ) {
			$this->render_error_page( __( 'Resource type not supported.', CF7UCA_TEXT_DOMAIN ) );
			return;
		}
		
		// Render resource detail
		$renderer = UnifiedViewRenderer::instance();
		$renderer->render_resource_detail( $token_data, $adapter, $resource_id );
	}
	
	/**
	 * Handle resource action AJAX request
	 */
	public function handle_resource_action() {
		// Verify nonce
		if ( ! cf7uca_verify_nonce( $_POST['nonce'], 'cf7uca_resource_action' ) ) {
			wp_send_json_error( array(
				'message' => __( 'Security check failed.', CF7UCA_TEXT_DOMAIN ),
			));
		}
		
		$token = sanitize_text_field( $_POST['token'] );
		$resource_type = sanitize_text_field( $_POST['resource_type'] );
		$resource_id = absint( $_POST['resource_id'] );
		$action = sanitize_text_field( $_POST['action'] );
		$action_data = isset( $_POST['action_data'] ) ? $_POST['action_data'] : array();
		
		// Validate access
		$validator = new AccessValidator();
		$validation_result = $validator->validate_access( $token );
		
		if ( ! $validation_result['valid'] ) {
			wp_send_json_error( array(
				'message' => $validation_result['message'],
			));
		}
		
		$token_data = $validation_result['token_data'];
		
		// Validate action permission
		$action_validation = $validator->validate_action_permission( $token_data, $resource_type, $resource_id, $action );
		
		if ( ! $action_validation['valid'] ) {
			wp_send_json_error( array(
				'message' => $action_validation['message'],
			));
		}
		
		// Get adapter and handle action
		$adapter = cf7uca_get_adapter( $resource_type );
		if ( ! $adapter ) {
			wp_send_json_error( array(
				'message' => __( 'Resource type not supported.', CF7UCA_TEXT_DOMAIN ),
			));
		}
		
		$result = $adapter->handle_resource_action( $action, $resource_id, $action_data );
		
		if ( $result['success'] ) {
			wp_send_json_success( $result );
		} else {
			wp_send_json_error( $result );
		}
	}
	
	/**
	 * Load resources by email
	 *
	 * @param string $email Client email
	 * @return array Resources grouped by type
	 */
	private function load_resources_by_email( $email ) {
		$resources = array();
		$registry = ResourceRegistry::instance();
		$adapters = $registry->get_adapters();
		
		foreach ( $adapters as $type => $adapter_class ) {
			$adapter = new $adapter_class();
			
			if ( $adapter instanceof \CF7UCA\Interfaces\ResourceInterface ) {
				$type_resources = $adapter->get_resources_by_email( $email );
				
				if ( ! empty( $type_resources ) ) {
					$resources[ $type ] = array(
						'adapter'   => $adapter,
						'resources' => $type_resources,
					);
				}
			}
		}
		
		return $resources;
	}
	
	/**
	 * Get token from request
	 *
	 * @return string|false Token or false if not found
	 */
	private function get_token_from_request() {
		// Check URL parameter
		if ( ! empty( $_GET['token'] ) ) {
			return sanitize_text_field( $_GET['token'] );
		}
		
		// Check POST data
		if ( ! empty( $_POST['token'] ) ) {
			return sanitize_text_field( $_POST['token'] );
		}
		
		return false;
	}
	
	/**
	 * Render error page
	 *
	 * @param string $message Error message
	 */
	private function render_error_page( $message ) {
		// Set page title
		add_filter( 'wp_title', function( $title ) {
			return __( 'Access Error', CF7UCA_TEXT_DOMAIN ) . ' - ' . get_bloginfo( 'name' );
		});
		
		// Start output buffering
		ob_start();
		
		// Include header
		get_header();
		
		?>
		<div class="cf7uca-error-page">
			<div class="cf7uca-container">
				<div class="cf7uca-error-message">
					<h1><?php _e( 'Access Error', CF7UCA_TEXT_DOMAIN ); ?></h1>
					<p><?php echo esc_html( $message ); ?></p>
					<a href="<?php echo esc_url( home_url() ); ?>" class="cf7uca-home-link">
						<?php _e( 'Return to Homepage', CF7UCA_TEXT_DOMAIN ); ?>
					</a>
				</div>
			</div>
		</div>
		<?php
		
		// Include footer
		get_footer();
		
		// End output buffering and exit
		ob_end_flush();
		exit;
	}
}