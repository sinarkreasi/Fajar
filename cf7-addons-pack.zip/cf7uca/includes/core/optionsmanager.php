<?php

namespace CF7UCA\Core;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Options management class
 */
class OptionsManager {
	
	/**
	 * Option prefix
	 */
	const OPTION_PREFIX = 'cf7uca_';
	
	/**
	 * Default options
	 */
	private static $defaults = array(
		'enable_unified_access' => true,
		'default_expiry_hours'  => CF7UCA_DEFAULT_EXPIRY_HOURS,
		'one_time_tokens'       => false,
		'access_page_slug'      => 'access',
		'require_https'         => null, // Will be set dynamically based on environment
		'rate_limit_enabled'    => true,
		'rate_limit_requests'   => 10,
		'rate_limit_window'     => 300,
		'debug_mode'            => false,
		'email_template'        => 'default',
		'auto_cleanup_tokens'   => true,
		'cleanup_days'          => 30,
	);
	
	/**
	 * Get option value
	 *
	 * @param string $key Option key
	 * @param mixed $default Default value
	 * @return mixed
	 */
	public static function get( $key, $default = null ) {
		$option_name = self::OPTION_PREFIX . $key;
		
		if ( $default === null && isset( self::$defaults[ $key ] ) ) {
			$default = self::$defaults[ $key ];
		}
		
		// Handle dynamic HTTPS requirement
		if ( $key === 'require_https' && $default === null ) {
			$default = self::get_default_https_requirement();
		}
		
		return get_option( $option_name, $default );
	}
	
	/**
	 * Set option value
	 *
	 * @param string $key Option key
	 * @param mixed $value Option value
	 * @return bool
	 */
	public static function set( $key, $value ) {
		$option_name = self::OPTION_PREFIX . $key;
		return update_option( $option_name, $value );
	}
	
	/**
	 * Delete option
	 *
	 * @param string $key Option key
	 * @return bool
	 */
	public static function delete( $key ) {
		$option_name = self::OPTION_PREFIX . $key;
		return delete_option( $option_name );
	}
	
	/**
	 * Get all options
	 *
	 * @return array
	 */
	public static function get_all() {
		$options = array();
		
		foreach ( self::$defaults as $key => $default ) {
			$options[ $key ] = self::get( $key, $default );
		}
		
		return $options;
	}
	
	/**
	 * Get options (alias for get_all for backward compatibility)
	 *
	 * @return array
	 */
	public static function get_options() {
		return self::get_all();
	}
	
	/**
	 * Set default options
	 */
	public static function set_defaults() {
		foreach ( self::$defaults as $key => $value ) {
			$option_name = self::OPTION_PREFIX . $key;
			
			// Only set if option doesn't exist
			if ( get_option( $option_name ) === false ) {
				// Handle dynamic HTTPS requirement
				if ( $key === 'require_https' && $value === null ) {
					$value = self::get_default_https_requirement();
				}
				
				update_option( $option_name, $value );
			}
		}
	}
	
	/**
	 * Reset all options to defaults
	 */
	public static function reset_to_defaults() {
		foreach ( self::$defaults as $key => $value ) {
			self::set( $key, $value );
		}
	}
	
	/**
	 * Get default options
	 *
	 * @return array
	 */
	public static function get_defaults() {
		return self::$defaults;
	}
	
	/**
	 * Validate option value
	 *
	 * @param string $key Option key
	 * @param mixed $value Option value
	 * @return mixed Validated value
	 */
	public static function validate( $key, $value ) {
		switch ( $key ) {
			case 'enable_unified_access':
			case 'one_time_tokens':
			case 'require_https':
			case 'rate_limit_enabled':
			case 'debug_mode':
			case 'auto_cleanup_tokens':
				return (bool) $value;
				
			case 'default_expiry_hours':
			case 'rate_limit_requests':
			case 'rate_limit_window':
			case 'cleanup_days':
				return max( 1, absint( $value ) );
				
			case 'access_page_slug':
				return sanitize_title( $value );
				
			case 'email_template':
				return sanitize_text_field( $value );
				
			default:
				return $value;
		}
	}
	
	/**
	 * Update multiple options at once
	 *
	 * @param array $options Key-value pairs
	 * @return bool
	 */
	public static function update_multiple( $options ) {
		$success = true;
		
		foreach ( $options as $key => $value ) {
			$validated_value = self::validate( $key, $value );
			
			if ( ! self::set( $key, $validated_value ) ) {
				$success = false;
			}
		}
		
		return $success;
	}
	
	/**
	 * Get default HTTPS requirement based on environment
	 *
	 * @return bool
	 */
	private static function get_default_https_requirement() {
		// Check if we're on localhost or development environment
		$host = isset( $_SERVER['HTTP_HOST'] ) ? $_SERVER['HTTP_HOST'] : '';
		
		$localhost_patterns = array(
			'localhost',
			'127.0.0.1',
			'::1',
			'.local',
			'.test',
			'.dev',
		);
		
		foreach ( $localhost_patterns as $pattern ) {
			if ( strpos( $host, $pattern ) !== false ) {
				return false; // Disable HTTPS requirement for localhost
			}
		}
		
		// For production environments, require HTTPS by default
		return true;
	}
}