<?php

namespace CF7UCA\Emails;

use CF7UCA\Core\TokenManager;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Magic link mailer class
 */
class MagicLinkMailer {
	
	/**
	 * Send unified access email
	 *
	 * @param string $email Client email
	 * @param string $token Raw token
	 * @return bool Success status
	 */
	public function send_unified_access_email( $email, $token ) {
		$access_url = cf7uca_generate_access_url( $token );
		
		$subject = $this->get_email_subject( 'unified_access' );
		$message = $this->get_email_message( 'unified_access', array(
			'email'      => $email,
			'access_url' => $access_url,
			'token'      => $token,
		));
		
		$headers = $this->get_email_headers();
		
		$sent = wp_mail( $email, $subject, $message, $headers );
		
		if ( $sent ) {
			cf7uca_log( "Unified access email sent to: {$email}" );
		} else {
			cf7uca_log( "Failed to send unified access email to: {$email}", 'error' );
		}
		
		return $sent;
	}
	
	/**
	 * Send token created notification
	 *
	 * @param int $token_id Token ID
	 * @param string $email Client email
	 * @return bool Success status
	 */
	public function send_token_created_notification( $token_id, $email ) {
		$token_manager = new TokenManager();
		$raw_token = $token_manager->get_raw_token_temporarily( $token_id );
		
		if ( ! $raw_token ) {
			cf7uca_log( "Raw token not found for token ID: {$token_id}", 'error' );
			return false;
		}
		
		return $this->send_unified_access_email( $email, $raw_token );
	}
	
	/**
	 * Get email subject
	 *
	 * @param string $template Template name
	 * @return string Email subject
	 */
	private function get_email_subject( $template ) {
		$subjects = array(
			'unified_access' => __( 'Your Client Access Link', CF7UCA_TEXT_DOMAIN ),
			'token_expired'  => __( 'Your Access Link Has Expired', CF7UCA_TEXT_DOMAIN ),
			'token_revoked'  => __( 'Your Access Has Been Revoked', CF7UCA_TEXT_DOMAIN ),
		);
		
		$subject = isset( $subjects[ $template ] ) ? $subjects[ $template ] : $subjects['unified_access'];
		
		// Add site name
		$subject = '[' . get_bloginfo( 'name' ) . '] ' . $subject;
		
		return apply_filters( 'cf7uca_email_subject', $subject, $template );
	}
	
	/**
	 * Get email message
	 *
	 * @param string $template Template name
	 * @param array $variables Template variables
	 * @return string Email message
	 */
	private function get_email_message( $template, $variables = array() ) {
		$template_content = $this->get_email_template( $template );
		
		// Replace variables in template
		foreach ( $variables as $key => $value ) {
			$template_content = str_replace( '{' . $key . '}', $value, $template_content );
		}
		
		// Add common variables
		$template_content = str_replace( '{site_name}', get_bloginfo( 'name' ), $template_content );
		$template_content = str_replace( '{site_url}', home_url(), $template_content );
		
		return apply_filters( 'cf7uca_email_message', $template_content, $template, $variables );
	}
	
	/**
	 * Get email template
	 *
	 * @param string $template Template name
	 * @return string Template content
	 */
	private function get_email_template( $template ) {
		$templates = array(
			'unified_access' => $this->get_unified_access_template(),
			'token_expired'  => $this->get_token_expired_template(),
			'token_revoked'  => $this->get_token_revoked_template(),
		);
		
		$template_content = isset( $templates[ $template ] ) ? $templates[ $template ] : $templates['unified_access'];
		
		return apply_filters( 'cf7uca_email_template', $template_content, $template );
	}
	
	/**
	 * Get unified access email template
	 *
	 * @return string Template content
	 */
	private function get_unified_access_template() {
		return '
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Client Access Link</title>
	<style>
		body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
		.container { max-width: 600px; margin: 0 auto; padding: 20px; }
		.header { background: #f8f9fa; padding: 20px; text-align: center; border-radius: 8px 8px 0 0; }
		.content { background: #fff; padding: 30px; border: 1px solid #dee2e6; }
		.footer { background: #f8f9fa; padding: 15px; text-align: center; border-radius: 0 0 8px 8px; font-size: 12px; color: #6c757d; }
		.btn { display: inline-block; padding: 12px 24px; background: #007cba; color: white; text-decoration: none; border-radius: 4px; margin: 20px 0; }
		.btn:hover { background: #005a87; }
		.security-note { background: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 4px; margin: 20px 0; }
	</style>
</head>
<body>
	<div class="container">
		<div class="header">
			<h1>Client Access Link</h1>
		</div>
		
		<div class="content">
			<p>Hello,</p>
			
			<p>You have been granted access to view your resources on {site_name}. Click the button below to access your client portal:</p>
			
			<div style="text-align: center;">
				<a href="{access_url}" class="btn">Access My Resources</a>
			</div>
			
			<p>If the button doesn\'t work, you can copy and paste this link into your browser:</p>
			<p style="word-break: break-all; background: #f8f9fa; padding: 10px; border-radius: 4px;">{access_url}</p>
			
			<div class="security-note">
				<strong>Security Notice:</strong>
				<ul>
					<li>This link is unique to your email address: {email}</li>
					<li>Do not share this link with others</li>
					<li>The link will expire automatically for security</li>
					<li>If you didn\'t request this access, please ignore this email</li>
				</ul>
			</div>
			
			<p>If you have any questions or need assistance, please contact our support team.</p>
			
			<p>Best regards,<br>The {site_name} Team</p>
		</div>
		
		<div class="footer">
			<p>This email was sent from {site_name} ({site_url})</p>
			<p>Please do not reply to this automated email.</p>
		</div>
	</div>
</body>
</html>';
	}
	
	/**
	 * Get token expired email template
	 *
	 * @return string Template content
	 */
	private function get_token_expired_template() {
		return '
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Access Link Expired</title>
</head>
<body>
	<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
		<h2>Access Link Expired</h2>
		
		<p>Hello,</p>
		
		<p>Your access link for {site_name} has expired for security reasons.</p>
		
		<p>If you need to access your resources again, please contact us to request a new access link.</p>
		
		<p>Best regards,<br>The {site_name} Team</p>
	</div>
</body>
</html>';
	}
	
	/**
	 * Get token revoked email template
	 *
	 * @return string Template content
	 */
	private function get_token_revoked_template() {
		return '
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Access Revoked</title>
</head>
<body>
	<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
		<h2>Access Revoked</h2>
		
		<p>Hello,</p>
		
		<p>Your access to {site_name} has been revoked.</p>
		
		<p>If you believe this is an error, please contact our support team for assistance.</p>
		
		<p>Best regards,<br>The {site_name} Team</p>
	</div>
</body>
</html>';
	}
	
	/**
	 * Get email headers
	 *
	 * @return array Email headers
	 */
	private function get_email_headers() {
		$headers = array(
			'Content-Type: text/html; charset=UTF-8',
		);
		
		// Add from header if configured
		$from_email = cf7uca_get_option( 'from_email', get_option( 'admin_email' ) );
		$from_name = cf7uca_get_option( 'from_name', get_bloginfo( 'name' ) );
		
		if ( $from_email ) {
			$headers[] = 'From: ' . $from_name . ' <' . $from_email . '>';
		}
		
		return apply_filters( 'cf7uca_email_headers', $headers );
	}
}