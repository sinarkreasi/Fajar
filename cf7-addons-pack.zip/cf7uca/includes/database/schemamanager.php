<?php

namespace CF7UCA\Database;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Database schema management class
 */
class SchemaManager {
	
	/**
	 * Create database tables
	 */
	public static function create_tables() {
		global $wpdb;
		
		$charset_collate = $wpdb->get_charset_collate();
		
		// Tokens table
		$tokens_table = $wpdb->prefix . CF7UCA_TOKENS_TABLE;
		$tokens_sql = "CREATE TABLE $tokens_table (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			token_hash varchar(64) NOT NULL,
			email varchar(100) NOT NULL,
			access_scope enum('single','unified') NOT NULL DEFAULT 'unified',
			expires_at datetime NOT NULL,
			usage_limit int(10) unsigned NULL,
			usage_count int(10) unsigned NOT NULL DEFAULT 0,
			status enum('active','expired','revoked') NOT NULL DEFAULT 'active',
			metadata longtext NULL,
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			last_used_at datetime NULL,
			PRIMARY KEY (id),
			UNIQUE KEY token_hash (token_hash),
			KEY email (email),
			KEY status (status),
			KEY expires_at (expires_at),
			KEY created_at (created_at)
		) $charset_collate;";
		
		// Logs table
		$logs_table = $wpdb->prefix . CF7UCA_LOGS_TABLE;
		$logs_sql = "CREATE TABLE $logs_table (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			token_id bigint(20) unsigned NULL,
			email varchar(100) NOT NULL,
			action varchar(50) NOT NULL,
			resource_type varchar(50) NULL,
			resource_id bigint(20) unsigned NULL,
			ip_address varchar(45) NULL,
			user_agent text NULL,
			status enum('success','failure','blocked') NOT NULL DEFAULT 'success',
			message text NULL,
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id),
			KEY token_id (token_id),
			KEY email (email),
			KEY action (action),
			KEY status (status),
			KEY created_at (created_at),
			FOREIGN KEY (token_id) REFERENCES $tokens_table(id) ON DELETE SET NULL
		) $charset_collate;";
		
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		
		dbDelta( $tokens_sql );
		dbDelta( $logs_sql );
		
		// Update database version
		update_option( 'cf7uca_db_version', CF7UCA_VERSION );
	}
	
	/**
	 * Drop database tables
	 */
	public static function drop_tables() {
		global $wpdb;
		
		$tokens_table = $wpdb->prefix . CF7UCA_TOKENS_TABLE;
		$logs_table = $wpdb->prefix . CF7UCA_LOGS_TABLE;
		
		$wpdb->query( "DROP TABLE IF EXISTS $logs_table" );
		$wpdb->query( "DROP TABLE IF EXISTS $tokens_table" );
		
		delete_option( 'cf7uca_db_version' );
	}
	
	/**
	 * Check if tables exist
	 *
	 * @return bool
	 */
	public static function tables_exist() {
		global $wpdb;
		
		$tokens_table = $wpdb->prefix . CF7UCA_TOKENS_TABLE;
		$logs_table = $wpdb->prefix . CF7UCA_LOGS_TABLE;
		
		$tokens_exists = $wpdb->get_var( "SHOW TABLES LIKE '$tokens_table'" ) === $tokens_table;
		$logs_exists = $wpdb->get_var( "SHOW TABLES LIKE '$logs_table'" ) === $logs_table;
		
		return $tokens_exists && $logs_exists;
	}
	
	/**
	 * Get database version
	 *
	 * @return string
	 */
	public static function get_db_version() {
		return get_option( 'cf7uca_db_version', '0.0.0' );
	}
	
	/**
	 * Check if database needs update
	 *
	 * @return bool
	 */
	public static function needs_update() {
		return version_compare( self::get_db_version(), CF7UCA_VERSION, '<' );
	}
	
	/**
	 * Update database schema
	 */
	public static function update_schema() {
		if ( self::needs_update() ) {
			self::create_tables();
		}
	}
	
	/**
	 * Clean up expired tokens
	 *
	 * @return int Number of tokens cleaned up
	 */
	public static function cleanup_expired_tokens() {
		global $wpdb;
		
		$tokens_table = $wpdb->prefix . CF7UCA_TOKENS_TABLE;
		
		// Update expired tokens
		$wpdb->query(
			"UPDATE $tokens_table 
			SET status = 'expired' 
			WHERE status = 'active' 
			AND expires_at < NOW()"
		);
		
		// Delete old tokens if auto cleanup is enabled
		if ( cf7uca_get_option( 'auto_cleanup_tokens', true ) ) {
			$cleanup_days = cf7uca_get_option( 'cleanup_days', 30 );
			
			$deleted = $wpdb->query(
				$wpdb->prepare(
					"DELETE FROM $tokens_table 
					WHERE status IN ('expired', 'revoked') 
					AND created_at < DATE_SUB(NOW(), INTERVAL %d DAY)",
					$cleanup_days
				)
			);
			
			return $deleted;
		}
		
		return 0;
	}
	
	/**
	 * Get table statistics
	 *
	 * @return array
	 */
	public static function get_table_stats() {
		global $wpdb;
		
		$tokens_table = $wpdb->prefix . CF7UCA_TOKENS_TABLE;
		$logs_table = $wpdb->prefix . CF7UCA_LOGS_TABLE;
		
		$stats = array();
		
		// Token statistics
		$stats['tokens'] = array(
			'total'   => $wpdb->get_var( "SELECT COUNT(*) FROM $tokens_table" ),
			'active'  => $wpdb->get_var( "SELECT COUNT(*) FROM $tokens_table WHERE status = 'active'" ),
			'expired' => $wpdb->get_var( "SELECT COUNT(*) FROM $tokens_table WHERE status = 'expired'" ),
			'revoked' => $wpdb->get_var( "SELECT COUNT(*) FROM $tokens_table WHERE status = 'revoked'" ),
		);
		
		// Log statistics
		$stats['logs'] = array(
			'total'   => $wpdb->get_var( "SELECT COUNT(*) FROM $logs_table" ),
			'today'   => $wpdb->get_var( "SELECT COUNT(*) FROM $logs_table WHERE DATE(created_at) = CURDATE()" ),
			'week'    => $wpdb->get_var( "SELECT COUNT(*) FROM $logs_table WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)" ),
		);
		
		return $stats;
	}
}