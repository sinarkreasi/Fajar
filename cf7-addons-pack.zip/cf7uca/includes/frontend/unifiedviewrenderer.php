<?php

namespace CF7UCA\Frontend;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Unified view renderer class
 */
class UnifiedViewRenderer {
	
	/**
	 * Renderer instance
	 *
	 * @var UnifiedViewRenderer
	 */
	private static $instance = null;
	
	/**
	 * Get renderer instance
	 *
	 * @return UnifiedViewRenderer
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		$this->init_hooks();
	}
	
	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
	}
	
	/**
	 * Enqueue frontend scripts
	 */
	public function enqueue_scripts() {
		// Only enqueue on UCA access pages
		if ( ! cf7uca_is_access_request() ) {
			return;
		}
		
		wp_enqueue_style( 
			'cf7uca-frontend', 
			CF7UCA_PLUGIN_URL . '/assets/css/frontend.css', 
			array(), 
			CF7UCA_VERSION 
		);
		
		wp_enqueue_script( 
			'cf7uca-frontend', 
			CF7UCA_PLUGIN_URL . '/assets/js/frontend.js', 
			array( 'jquery' ), 
			CF7UCA_VERSION, 
			true 
		);
		
		wp_localize_script( 'cf7uca-frontend', 'cf7uca_ajax', array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'cf7uca_resource_action' ),
			'strings'  => array(
				'confirm_action' => __( 'Are you sure you want to perform this action?', CF7UCA_TEXT_DOMAIN ),
				'processing'     => __( 'Processing...', CF7UCA_TEXT_DOMAIN ),
				'error'          => __( 'An error occurred. Please try again.', CF7UCA_TEXT_DOMAIN ),
			),
		));
	}
	
	/**
	 * Render unified view
	 *
	 * @param array $token_data Token data
	 * @param array $resources Resources grouped by type
	 */
	public function render_unified_view( $token_data, $resources ) {
		// Set page title
		add_filter( 'wp_title', function( $title ) use ( $token_data ) {
			return sprintf( __( 'Client Access - %s', CF7UCA_TEXT_DOMAIN ), $token_data['email'] ) . ' - ' . get_bloginfo( 'name' );
		});
		
		// Start output buffering
		ob_start();
		
		// Include header
		get_header();
		
		?>
		<div class="cf7uca-unified-view">
			<div class="cf7uca-container">
				<?php $this->render_client_header( $token_data ); ?>
				<?php $this->render_resources_list( $resources, $token_data ); ?>
			</div>
		</div>
		<?php
		
		// Include footer
		get_footer();
		
		// End output buffering and exit
		ob_end_flush();
		exit;
	}
	
	/**
	 * Render resource detail
	 *
	 * @param array $token_data Token data
	 * @param \CF7UCA\Interfaces\ResourceInterface $adapter Resource adapter
	 * @param int $resource_id Resource ID
	 */
	public function render_resource_detail( $token_data, $adapter, $resource_id ) {
		// Set page title
		add_filter( 'wp_title', function( $title ) use ( $adapter, $resource_id ) {
			return sprintf( __( '%s #%d', CF7UCA_TEXT_DOMAIN ), $adapter->get_resource_type_label(), $resource_id ) . ' - ' . get_bloginfo( 'name' );
		});
		
		// Start output buffering
		ob_start();
		
		// Include header
		get_header();
		
		?>
		<div class="cf7uca-resource-detail-view">
			<div class="cf7uca-container">
				<?php $this->render_breadcrumb( $token_data, $adapter, $resource_id ); ?>
				<?php echo $adapter->render_resource_detail( $resource_id ); ?>
			</div>
		</div>
		<?php
		
		// Include footer
		get_footer();
		
		// End output buffering and exit
		ob_end_flush();
		exit;
	}
	
	/**
	 * Render client header
	 *
	 * @param array $token_data Token data
	 */
	private function render_client_header( $token_data ) {
		?>
		<div class="cf7uca-client-header">
			<div class="cf7uca-greeting">
				<h1><?php printf( __( 'Welcome, %s', CF7UCA_TEXT_DOMAIN ), esc_html( $token_data['email'] ) ); ?></h1>
				<p class="cf7uca-access-info">
					<?php _e( 'Here are your resources and recent activity.', CF7UCA_TEXT_DOMAIN ); ?>
				</p>
			</div>
			
			<div class="cf7uca-token-info">
				<div class="cf7uca-token-meta">
					<span class="cf7uca-token-scope">
						<?php echo esc_html( ucfirst( $token_data['access_scope'] ) ); ?> <?php _e( 'Access', CF7UCA_TEXT_DOMAIN ); ?>
					</span>
					<span class="cf7uca-token-expires">
						<?php printf( __( 'Expires: %s', CF7UCA_TEXT_DOMAIN ), cf7uca_format_date( $token_data['expires_at'] ) ); ?>
					</span>
				</div>
			</div>
		</div>
		<?php
	}
	
	/**
	 * Render resources list
	 *
	 * @param array $resources Resources grouped by type
	 * @param array $token_data Token data
	 */
	private function render_resources_list( $resources, $token_data ) {
		if ( empty( $resources ) ) {
			$this->render_no_resources_message();
			return;
		}
		
		?>
		<div class="cf7uca-resources-list">
			<?php foreach ( $resources as $type => $type_data ) : ?>
				<?php $this->render_resource_type_section( $type, $type_data, $token_data ); ?>
			<?php endforeach; ?>
		</div>
		<?php
	}
	
	/**
	 * Render resource type section
	 *
	 * @param string $type Resource type
	 * @param array $type_data Type data with adapter and resources
	 * @param array $token_data Token data
	 */
	private function render_resource_type_section( $type, $type_data, $token_data ) {
		$adapter = $type_data['adapter'];
		$resources = $type_data['resources'];
		
		?>
		<div class="cf7uca-resource-type-section" data-type="<?php echo esc_attr( $type ); ?>">
			<div class="cf7uca-section-header">
				<h2 class="cf7uca-section-title">
					<?php echo esc_html( $adapter->get_resource_type_label() ); ?>
					<span class="cf7uca-resource-count">(<?php echo count( $resources ); ?>)</span>
				</h2>
			</div>
			
			<div class="cf7uca-resources-grid">
				<?php foreach ( $resources as $resource ) : ?>
					<div class="cf7uca-resource-item" data-resource-id="<?php echo esc_attr( $resource['id'] ); ?>">
						<?php echo $adapter->render_resource_summary( $resource ); ?>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}
	
	/**
	 * Render no resources message
	 */
	private function render_no_resources_message() {
		?>
		<div class="cf7uca-no-resources">
			<div class="cf7uca-no-resources-icon">
				<span class="dashicons dashicons-inbox"></span>
			</div>
			<h3><?php _e( 'No Resources Found', CF7UCA_TEXT_DOMAIN ); ?></h3>
			<p><?php _e( 'You don\'t have any resources associated with this email address yet.', CF7UCA_TEXT_DOMAIN ); ?></p>
		</div>
		<?php
	}
	
	/**
	 * Render breadcrumb navigation
	 *
	 * @param array $token_data Token data
	 * @param \CF7UCA\Interfaces\ResourceInterface $adapter Resource adapter
	 * @param int $resource_id Resource ID
	 */
	private function render_breadcrumb( $token_data, $adapter, $resource_id ) {
		$access_slug = cf7uca_get_access_page_slug();
		$access_url = home_url( $access_slug . '/?token=' . urlencode( $this->get_current_token() ) );
		
		?>
		<div class="cf7uca-breadcrumb">
			<nav class="cf7uca-breadcrumb-nav">
				<a href="<?php echo esc_url( $access_url ); ?>" class="cf7uca-breadcrumb-link">
					<?php _e( 'Client Access', CF7UCA_TEXT_DOMAIN ); ?>
				</a>
				<span class="cf7uca-breadcrumb-separator">/</span>
				<span class="cf7uca-breadcrumb-current">
					<?php echo esc_html( $adapter->get_resource_type_label() ); ?> #<?php echo esc_html( $resource_id ); ?>
				</span>
			</nav>
		</div>
		<?php
	}
	
	/**
	 * Get current token from request
	 *
	 * @return string Current token
	 */
	private function get_current_token() {
		if ( ! empty( $_GET['token'] ) ) {
			return sanitize_text_field( $_GET['token'] );
		}
		
		return '';
	}
	
	/**
	 * Render access form for token entry
	 */
	public function render_access_form() {
		?>
		<div class="cf7uca-access-form-container">
			<div class="cf7uca-access-form">
				<h2><?php _e( 'Client Access', CF7UCA_TEXT_DOMAIN ); ?></h2>
				<p><?php _e( 'Enter your access token to view your resources.', CF7UCA_TEXT_DOMAIN ); ?></p>
				
				<form method="get" class="cf7uca-token-form">
					<div class="cf7uca-form-field">
						<label for="cf7uca-token-input"><?php _e( 'Access Token:', CF7UCA_TEXT_DOMAIN ); ?></label>
						<input type="text" 
							   id="cf7uca-token-input" 
							   name="token" 
							   class="cf7uca-token-input" 
							   placeholder="<?php esc_attr_e( 'Enter your access token', CF7UCA_TEXT_DOMAIN ); ?>" 
							   required>
					</div>
					
					<div class="cf7uca-form-actions">
						<button type="submit" class="cf7uca-access-btn">
							<?php _e( 'Access Resources', CF7UCA_TEXT_DOMAIN ); ?>
						</button>
					</div>
				</form>
				
				<div class="cf7uca-help-text">
					<p><?php _e( 'Don\'t have an access token? Check your email for the magic link we sent you.', CF7UCA_TEXT_DOMAIN ); ?></p>
				</div>
			</div>
		</div>
		<?php
	}
}