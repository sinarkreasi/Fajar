<?php

namespace CF7UCA\Admin;

use CF7UCA\Core\TokenManager;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Load WP_List_Table if not loaded
if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

/**
 * Token list table class
 */
class TokenTable extends \WP_List_Table {
	
	/**
	 * Constructor
	 */
	public function __construct() {
		parent::__construct( array(
			'singular' => 'token',
			'plural'   => 'tokens',
			'ajax'     => false,
		));
	}
	
	/**
	 * Get columns
	 *
	 * @return array
	 */
	public function get_columns() {
		return array(
			'cb'           => '<input type="checkbox" />',
			'id'           => __( 'ID', CF7UCA_TEXT_DOMAIN ),
			'email'        => __( 'Email', CF7UCA_TEXT_DOMAIN ),
			'access_scope' => __( 'Scope', CF7UCA_TEXT_DOMAIN ),
			'status'       => __( 'Status', CF7UCA_TEXT_DOMAIN ),
			'usage'        => __( 'Usage', CF7UCA_TEXT_DOMAIN ),
			'expires_at'   => __( 'Expires', CF7UCA_TEXT_DOMAIN ),
			'created_at'   => __( 'Created', CF7UCA_TEXT_DOMAIN ),
			'actions'      => __( 'Actions', CF7UCA_TEXT_DOMAIN ),
		);
	}
	
	/**
	 * Get sortable columns
	 *
	 * @return array
	 */
	public function get_sortable_columns() {
		return array(
			'id'         => array( 'id', false ),
			'email'      => array( 'email', false ),
			'status'     => array( 'status', false ),
			'expires_at' => array( 'expires_at', false ),
			'created_at' => array( 'created_at', true ),
		);
	}
	
	/**
	 * Get bulk actions
	 *
	 * @return array
	 */
	public function get_bulk_actions() {
		return array(
			'revoke' => __( 'Revoke', CF7UCA_TEXT_DOMAIN ),
			'extend' => __( 'Extend (24h)', CF7UCA_TEXT_DOMAIN ),
		);
	}
	
	/**
	 * Prepare items
	 */
	public function prepare_items() {
		$per_page = 20;
		$current_page = $this->get_pagenum();
		
		// Get search term
		$search = isset( $_REQUEST['s'] ) ? sanitize_text_field( $_REQUEST['s'] ) : '';
		
		// Get filter values
		$status_filter = isset( $_REQUEST['status'] ) ? sanitize_text_field( $_REQUEST['status'] ) : '';
		$scope_filter = isset( $_REQUEST['scope'] ) ? sanitize_text_field( $_REQUEST['scope'] ) : '';
		
		// Prepare query args
		$args = array(
			'per_page' => $per_page,
			'page'     => $current_page,
			'orderby'  => isset( $_REQUEST['orderby'] ) ? sanitize_text_field( $_REQUEST['orderby'] ) : 'created_at',
			'order'    => isset( $_REQUEST['order'] ) ? sanitize_text_field( $_REQUEST['order'] ) : 'DESC',
		);
		
		if ( ! empty( $search ) ) {
			$args['email'] = $search;
		}
		
		if ( ! empty( $status_filter ) ) {
			$args['status'] = $status_filter;
		}
		
		if ( ! empty( $scope_filter ) ) {
			$args['access_scope'] = $scope_filter;
		}
		
		// Get tokens
		$token_manager = new TokenManager();
		$result = $token_manager->get_tokens( $args );
		
		$this->items = $result['tokens'];
		
		// Set pagination
		$this->set_pagination_args( array(
			'total_items' => $result['total'],
			'per_page'    => $per_page,
		));
		
		// Set column headers
		$this->_column_headers = array(
			$this->get_columns(),
			array(),
			$this->get_sortable_columns(),
		);
	}
	
	/**
	 * Column default
	 *
	 * @param array $item Item data
	 * @param string $column_name Column name
	 * @return string
	 */
	public function column_default( $item, $column_name ) {
		switch ( $column_name ) {
			case 'id':
				return $item['id'];
				
			case 'email':
				return esc_html( $item['email'] );
				
			case 'access_scope':
				return esc_html( ucfirst( $item['access_scope'] ) );
				
			case 'status':
				return $this->render_status_badge( $item['status'] );
				
			case 'usage':
				return $this->render_usage_info( $item );
				
			case 'expires_at':
				return cf7uca_format_date( $item['expires_at'] );
				
			case 'created_at':
				return cf7uca_format_date( $item['created_at'] );
				
			case 'actions':
				return $this->render_row_actions( $item );
				
			default:
				return '';
		}
	}
	
	/**
	 * Column checkbox
	 *
	 * @param array $item Item data
	 * @return string
	 */
	public function column_cb( $item ) {
		return sprintf(
			'<input type="checkbox" name="token[]" value="%s" />',
			$item['id']
		);
	}
	
	/**
	 * Render status badge
	 *
	 * @param string $status Status
	 * @return string
	 */
	private function render_status_badge( $status ) {
		$class = 'cf7uca-status-badge cf7uca-status-' . esc_attr( $status );
		$label = ucfirst( $status );
		
		return '<span class="' . $class . '">' . esc_html( $label ) . '</span>';
	}
	
	/**
	 * Render usage info
	 *
	 * @param array $item Token data
	 * @return string
	 */
	private function render_usage_info( $item ) {
		$usage_count = $item['usage_count'];
		$usage_limit = $item['usage_limit'];
		
		if ( $usage_limit ) {
			return sprintf( '%d / %d', $usage_count, $usage_limit );
		} else {
			return sprintf( '%d / ∞', $usage_count );
		}
	}
	
	/**
	 * Render row actions
	 *
	 * @param array $item Token data
	 * @return string
	 */
	private function render_row_actions( $item ) {
		$actions = array();
		
		if ( $item['status'] === 'active' ) {
			$actions['revoke'] = sprintf(
				'<a href="#" class="cf7uca-revoke-token" data-token-id="%d">%s</a>',
				$item['id'],
				__( 'Revoke', CF7UCA_TEXT_DOMAIN )
			);
			
			$actions['extend'] = sprintf(
				'<a href="#" class="cf7uca-extend-token" data-token-id="%d">%s</a>',
				$item['id'],
				__( 'Extend', CF7UCA_TEXT_DOMAIN )
			);
		}
		
		return implode( ' | ', $actions );
	}
	
	/**
	 * Extra table navigation
	 *
	 * @param string $which Position (top or bottom)
	 */
	public function extra_tablenav( $which ) {
		if ( $which === 'top' ) {
			?>
			<div class="alignleft actions">
				<?php $this->render_status_filter(); ?>
				<?php $this->render_scope_filter(); ?>
				<?php submit_button( __( 'Filter', CF7UCA_TEXT_DOMAIN ), '', 'filter_action', false, array( 'id' => 'post-query-submit' ) ); ?>
			</div>
			<?php
		}
	}
	
	/**
	 * Render status filter
	 */
	private function render_status_filter() {
		$current_status = isset( $_REQUEST['status'] ) ? $_REQUEST['status'] : '';
		$statuses = cf7uca_get_token_statuses();
		
		?>
		<select name="status">
			<option value=""><?php _e( 'All Statuses', CF7UCA_TEXT_DOMAIN ); ?></option>
			<?php foreach ( $statuses as $value => $label ) : ?>
				<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $current_status, $value ); ?>>
					<?php echo esc_html( $label ); ?>
				</option>
			<?php endforeach; ?>
		</select>
		<?php
	}
	
	/**
	 * Render scope filter
	 */
	private function render_scope_filter() {
		$current_scope = isset( $_REQUEST['scope'] ) ? $_REQUEST['scope'] : '';
		$scopes = cf7uca_get_access_scopes();
		
		?>
		<select name="scope">
			<option value=""><?php _e( 'All Scopes', CF7UCA_TEXT_DOMAIN ); ?></option>
			<?php foreach ( $scopes as $value => $label ) : ?>
				<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $current_scope, $value ); ?>>
					<?php echo esc_html( $label ); ?>
				</option>
			<?php endforeach; ?>
		</select>
		<?php
	}
}