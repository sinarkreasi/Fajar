<?php

namespace CF7UCA\Admin;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin initialization class
 */
class AdminInit {
	
	/**
	 * Admin instance
	 *
	 * @var AdminInit
	 */
	private static $instance = null;
	
	/**
	 * Get admin instance
	 *
	 * @return AdminInit
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		$this->init_hooks();
	}
	
	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_notices', array( $this, 'show_admin_notices' ) );
		
		// AJAX handlers
		add_action( 'wp_ajax_cf7uca_revoke_token', array( $this, 'handle_revoke_token' ) );
		add_action( 'wp_ajax_cf7uca_extend_token', array( $this, 'handle_extend_token' ) );
		add_action( 'wp_ajax_cf7uca_cleanup_tokens', array( $this, 'handle_cleanup_tokens' ) );
	}
	
	/**
	 * Add admin menu
	 */
	public function add_admin_menu() {
		// Add main menu page
		add_menu_page(
			__( 'CF7 UCA', CF7UCA_TEXT_DOMAIN ),
			__( 'CF7 UCA', CF7UCA_TEXT_DOMAIN ),
			'manage_options',
			'cf7uca',
			array( $this, 'render_main_page' ),
			'dashicons-admin-network',
			30
		);
		
		// Add settings submenu
		add_submenu_page(
			'cf7uca',
			__( 'UCA Settings', CF7UCA_TEXT_DOMAIN ),
			__( 'Settings', CF7UCA_TEXT_DOMAIN ),
			'manage_options',
			'cf7uca-settings',
			array( $this, 'render_settings_page' )
		);
		
		// Add tokens submenu
		add_submenu_page(
			'cf7uca',
			__( 'Access Tokens', CF7UCA_TEXT_DOMAIN ),
			__( 'Tokens', CF7UCA_TEXT_DOMAIN ),
			'manage_options',
			'cf7uca-tokens',
			array( $this, 'render_tokens_page' )
		);
		
		// Add adapters submenu
		add_submenu_page(
			'cf7uca',
			__( 'Resource Adapters', CF7UCA_TEXT_DOMAIN ),
			__( 'Adapters', CF7UCA_TEXT_DOMAIN ),
			'manage_options',
			'cf7uca-adapters',
			array( $this, 'render_adapters_page' )
		);
	}
	
	/**
	 * Enqueue admin scripts
	 *
	 * @param string $hook Current admin page hook
	 */
	public function enqueue_admin_scripts( $hook ) {
		// Only load on our admin pages
		if ( strpos( $hook, 'cf7uca' ) === false ) {
			return;
		}
		
		wp_enqueue_style(
			'cf7uca-admin',
			CF7UCA_PLUGIN_URL . '/assets/css/admin.css',
			array(),
			CF7UCA_VERSION
		);
		
		wp_enqueue_script(
			'cf7uca-admin',
			CF7UCA_PLUGIN_URL . '/assets/js/admin.js',
			array( 'jquery' ),
			CF7UCA_VERSION,
			true
		);
		
		wp_localize_script( 'cf7uca-admin', 'cf7uca_admin', array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'cf7uca_admin' ),
			'strings'  => array(
				'confirm_revoke'  => __( 'Are you sure you want to revoke this token?', CF7UCA_TEXT_DOMAIN ),
				'confirm_cleanup' => __( 'Are you sure you want to cleanup expired tokens?', CF7UCA_TEXT_DOMAIN ),
				'processing'      => __( 'Processing...', CF7UCA_TEXT_DOMAIN ),
				'success'         => __( 'Operation completed successfully!', CF7UCA_TEXT_DOMAIN ),
				'error'           => __( 'An error occurred. Please try again.', CF7UCA_TEXT_DOMAIN ),
			),
		));
	}
	
	/**
	 * Register settings
	 */
	public function register_settings() {
		register_setting( 'cf7uca_settings', 'cf7uca_options', array(
			'sanitize_callback' => array( $this, 'sanitize_settings' ),
		));
		
		// General settings section
		add_settings_section(
			'cf7uca_general',
			__( 'General Settings', CF7UCA_TEXT_DOMAIN ),
			array( $this, 'render_general_section' ),
			'cf7uca_settings'
		);
		
		// Access settings
		$this->add_settings_fields();
	}
	
	/**
	 * Add settings fields
	 */
	private function add_settings_fields() {
		// Unified access
		add_settings_field(
			'enable_unified_access',
			__( 'Enable Unified Access', CF7UCA_TEXT_DOMAIN ),
			array( $this, 'render_checkbox_field' ),
			'cf7uca_settings',
			'cf7uca_general',
			array(
				'key'         => 'enable_unified_access',
				'description' => __( 'Allow clients to access multiple resources with a single token.', CF7UCA_TEXT_DOMAIN ),
			)
		);
		
		// Default expiry hours
		add_settings_field(
			'default_expiry_hours',
			__( 'Default Token Expiry (Hours)', CF7UCA_TEXT_DOMAIN ),
			array( $this, 'render_number_field' ),
			'cf7uca_settings',
			'cf7uca_general',
			array(
				'key'         => 'default_expiry_hours',
				'min'         => 1,
				'max'         => 8760,
				'description' => __( 'How long access tokens remain valid by default.', CF7UCA_TEXT_DOMAIN ),
			)
		);
		
		// One-time tokens
		add_settings_field(
			'one_time_tokens',
			__( 'One-Time Tokens', CF7UCA_TEXT_DOMAIN ),
			array( $this, 'render_checkbox_field' ),
			'cf7uca_settings',
			'cf7uca_general',
			array(
				'key'         => 'one_time_tokens',
				'description' => __( 'Tokens can only be used once (more secure but less convenient).', CF7UCA_TEXT_DOMAIN ),
			)
		);
		
		// Access page slug
		add_settings_field(
			'access_page_slug',
			__( 'Access Page Slug', CF7UCA_TEXT_DOMAIN ),
			array( $this, 'render_text_field' ),
			'cf7uca_settings',
			'cf7uca_general',
			array(
				'key'         => 'access_page_slug',
				'description' => __( 'URL slug for client access pages (e.g., "access").', CF7UCA_TEXT_DOMAIN ),
			)
		);
		
		// HTTPS requirement
		add_settings_field(
			'require_https',
			__( 'Require HTTPS', CF7UCA_TEXT_DOMAIN ),
			array( $this, 'render_checkbox_field' ),
			'cf7uca_settings',
			'cf7uca_general',
			array(
				'key'         => 'require_https',
				'description' => __( 'Require HTTPS for secure token transmission.', CF7UCA_TEXT_DOMAIN ),
			)
		);
		
		// Rate limiting
		add_settings_field(
			'rate_limit_enabled',
			__( 'Enable Rate Limiting', CF7UCA_TEXT_DOMAIN ),
			array( $this, 'render_checkbox_field' ),
			'cf7uca_settings',
			'cf7uca_general',
			array(
				'key'         => 'rate_limit_enabled',
				'description' => __( 'Limit the number of access requests per time window.', CF7UCA_TEXT_DOMAIN ),
			)
		);
	}
	
	/**
	 * Sanitize settings
	 *
	 * @param array $input Raw input
	 * @return array Sanitized input
	 */
	public function sanitize_settings( $input ) {
		$sanitized = array();
		
		foreach ( $input as $key => $value ) {
			$sanitized[ $key ] = \CF7UCA\Core\OptionsManager::validate( $key, $value );
		}
		
		return $sanitized;
	}
	
	/**
	 * Render main admin page
	 */
	public function render_main_page() {
		?>
		<div class="wrap">
			<h1><?php _e( 'CF7 Unified Client Access', CF7UCA_TEXT_DOMAIN ); ?></h1>
			
			<div class="cf7uca-admin-dashboard">
				<?php $this->render_dashboard_widgets(); ?>
			</div>
		</div>
		<?php
	}
	
	/**
	 * Render settings page
	 */
	public function render_settings_page() {
		?>
		<div class="wrap">
			<h1><?php _e( 'UCA Settings', CF7UCA_TEXT_DOMAIN ); ?></h1>
			
			<form method="post" action="options.php">
				<?php
				settings_fields( 'cf7uca_settings' );
				do_settings_sections( 'cf7uca_settings' );
				submit_button();
				?>
			</form>
		</div>
		<?php
	}
	
	/**
	 * Render tokens page
	 */
	public function render_tokens_page() {
		$tokens_table = new TokenTable();
		$tokens_table->prepare_items();
		
		?>
		<div class="wrap">
			<h1><?php _e( 'Access Tokens', CF7UCA_TEXT_DOMAIN ); ?></h1>
			
			<div class="cf7uca-tokens-actions">
				<button type="button" class="button" id="cf7uca-cleanup-tokens">
					<?php _e( 'Cleanup Expired Tokens', CF7UCA_TEXT_DOMAIN ); ?>
				</button>
			</div>
			
			<?php $tokens_table->display(); ?>
		</div>
		<?php
	}
	
	/**
	 * Render adapters page
	 */
	public function render_adapters_page() {
		$registry = \CF7UCA\Adapters\ResourceRegistry::instance();
		$adapter_status = $registry->get_adapter_status();
		
		?>
		<div class="wrap">
			<h1><?php _e( 'Resource Adapters', CF7UCA_TEXT_DOMAIN ); ?></h1>
			
			<div class="cf7uca-adapters-list">
				<?php $this->render_adapters_table( $adapter_status ); ?>
			</div>
		</div>
		<?php
	}
	
	/**
	 * Render adapters table
	 *
	 * @param array $adapter_status Adapter status data
	 */
	private function render_adapters_table( $adapter_status ) {
		?>
		<table class="wp-list-table widefat fixed striped">
			<thead>
				<tr>
					<th><?php _e( 'Type', CF7UCA_TEXT_DOMAIN ); ?></th>
					<th><?php _e( 'Class', CF7UCA_TEXT_DOMAIN ); ?></th>
					<th><?php _e( 'Status', CF7UCA_TEXT_DOMAIN ); ?></th>
					<th><?php _e( 'Details', CF7UCA_TEXT_DOMAIN ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php if ( empty( $adapter_status ) ) : ?>
					<tr>
						<td colspan="4" class="cf7uca-no-adapters">
							<?php _e( 'No adapters registered.', CF7UCA_TEXT_DOMAIN ); ?>
						</td>
					</tr>
				<?php else : ?>
					<?php foreach ( $adapter_status as $type => $status ) : ?>
						<tr>
							<td><strong><?php echo esc_html( ucfirst( $type ) ); ?></strong></td>
							<td><code><?php echo esc_html( $status['class'] ); ?></code></td>
							<td>
								<?php if ( $status['active'] ) : ?>
									<span class="cf7uca-status-active"><?php _e( 'Active', CF7UCA_TEXT_DOMAIN ); ?></span>
								<?php else : ?>
									<span class="cf7uca-status-inactive"><?php _e( 'Inactive', CF7UCA_TEXT_DOMAIN ); ?></span>
								<?php endif; ?>
							</td>
							<td>
								<?php if ( ! $status['exists'] ) : ?>
									<span class="cf7uca-error"><?php _e( 'Class not found', CF7UCA_TEXT_DOMAIN ); ?></span>
								<?php elseif ( ! $status['implements'] ) : ?>
									<span class="cf7uca-error"><?php _e( 'Does not implement ResourceInterface', CF7UCA_TEXT_DOMAIN ); ?></span>
								<?php elseif ( isset( $status['error'] ) ) : ?>
									<span class="cf7uca-error"><?php echo esc_html( $status['error'] ); ?></span>
								<?php else : ?>
									<span class="cf7uca-success"><?php _e( 'OK', CF7UCA_TEXT_DOMAIN ); ?></span>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				<?php endif; ?>
			</tbody>
		</table>
		
		<?php if ( ! empty( $adapter_status ) ) : ?>
			<div class="cf7uca-adapter-info">
				<h3><?php _e( 'Adapter Information', CF7UCA_TEXT_DOMAIN ); ?></h3>
				<p><?php _e( 'Adapters allow CF7 UCA to integrate with other plugins and provide unified access to different resource types.', CF7UCA_TEXT_DOMAIN ); ?></p>
				<ul>
					<li><strong><?php _e( 'Active:', CF7UCA_TEXT_DOMAIN ); ?></strong> <?php _e( 'Adapter is loaded and functioning correctly', CF7UCA_TEXT_DOMAIN ); ?></li>
					<li><strong><?php _e( 'Inactive:', CF7UCA_TEXT_DOMAIN ); ?></strong> <?php _e( 'Adapter has issues and cannot be used', CF7UCA_TEXT_DOMAIN ); ?></li>
				</ul>
			</div>
		<?php endif; ?>
		<?php
	}
	
	/**
	 * Render dashboard widgets
	 */
	private function render_dashboard_widgets() {
		?>
		<div class="cf7uca-dashboard-widgets">
			<div class="cf7uca-widget">
				<h2><?php _e( 'System Status', CF7UCA_TEXT_DOMAIN ); ?></h2>
				<?php $this->render_system_status(); ?>
			</div>
			
			<div class="cf7uca-widget">
				<h2><?php _e( 'Token Statistics', CF7UCA_TEXT_DOMAIN ); ?></h2>
				<?php $this->render_token_statistics(); ?>
			</div>
			
			<div class="cf7uca-widget">
				<h2><?php _e( 'Adapter Status', CF7UCA_TEXT_DOMAIN ); ?></h2>
				<?php $this->render_adapter_summary(); ?>
			</div>
		</div>
		<?php
	}
	
	/**
	 * Render system status
	 */
	private function render_system_status() {
		$status_items = array(
			'unified_access' => cf7uca_is_unified_access_enabled(),
			'https_required' => cf7uca_requires_https(),
			'https_active'   => is_ssl(),
			'rate_limiting'  => cf7uca_get_option( 'rate_limit_enabled', true ),
		);
		
		?>
		<table class="cf7uca-status-table">
			<tr>
				<td><?php _e( 'Unified Access', CF7UCA_TEXT_DOMAIN ); ?></td>
				<td><?php echo $this->render_status_indicator( $status_items['unified_access'] ); ?></td>
			</tr>
			<tr>
				<td><?php _e( 'HTTPS Required', CF7UCA_TEXT_DOMAIN ); ?></td>
				<td><?php echo $this->render_status_indicator( $status_items['https_required'] ); ?></td>
			</tr>
			<tr>
				<td><?php _e( 'HTTPS Active', CF7UCA_TEXT_DOMAIN ); ?></td>
				<td><?php echo $this->render_status_indicator( $status_items['https_active'] ); ?></td>
			</tr>
			<tr>
				<td><?php _e( 'Rate Limiting', CF7UCA_TEXT_DOMAIN ); ?></td>
				<td><?php echo $this->render_status_indicator( $status_items['rate_limiting'] ); ?></td>
			</tr>
		</table>
		<?php
	}
	
	/**
	 * Render token statistics
	 */
	private function render_token_statistics() {
		$stats = \CF7UCA\Database\SchemaManager::get_table_stats();
		
		?>
		<div class="cf7uca-stats-grid">
			<div class="cf7uca-stat-item">
				<div class="cf7uca-stat-number"><?php echo esc_html( $stats['tokens']['total'] ); ?></div>
				<div class="cf7uca-stat-label"><?php _e( 'Total Tokens', CF7UCA_TEXT_DOMAIN ); ?></div>
			</div>
			<div class="cf7uca-stat-item">
				<div class="cf7uca-stat-number"><?php echo esc_html( $stats['tokens']['active'] ); ?></div>
				<div class="cf7uca-stat-label"><?php _e( 'Active Tokens', CF7UCA_TEXT_DOMAIN ); ?></div>
			</div>
			<div class="cf7uca-stat-item">
				<div class="cf7uca-stat-number"><?php echo esc_html( $stats['logs']['today'] ); ?></div>
				<div class="cf7uca-stat-label"><?php _e( 'Access Today', CF7UCA_TEXT_DOMAIN ); ?></div>
			</div>
		</div>
		<?php
	}
	
	/**
	 * Render adapter summary
	 */
	private function render_adapter_summary() {
		$registry = \CF7UCA\Adapters\ResourceRegistry::instance();
		$stats = $registry->get_statistics();
		
		?>
		<div class="cf7uca-adapter-summary">
			<p><?php printf( __( '%d adapters registered, %d active', CF7UCA_TEXT_DOMAIN ), $stats['total_adapters'], $stats['active_adapters'] ); ?></p>
			
			<ul class="cf7uca-adapter-list">
				<?php foreach ( $stats['types'] as $type => $active ) : ?>
				<li>
					<?php echo $this->render_status_indicator( $active ); ?>
					<?php echo esc_html( ucfirst( $type ) ); ?>
				</li>
				<?php endforeach; ?>
			</ul>
		</div>
		<?php
	}
	
	/**
	 * Render status indicator
	 *
	 * @param bool $status Status
	 * @return string HTML
	 */
	private function render_status_indicator( $status ) {
		$class = $status ? 'cf7uca-status-active' : 'cf7uca-status-inactive';
		$text = $status ? __( 'Active', CF7UCA_TEXT_DOMAIN ) : __( 'Inactive', CF7UCA_TEXT_DOMAIN );
		
		return '<span class="cf7uca-status-indicator ' . $class . '">' . $text . '</span>';
	}
	
	/**
	 * Show admin notices
	 */
	public function show_admin_notices() {
		// Check database tables
		if ( ! \CF7UCA\Database\SchemaManager::tables_exist() ) {
			?>
			<div class="notice notice-error">
				<p><?php _e( 'CF7 UCA database tables are missing. Please deactivate and reactivate the plugin.', CF7UCA_TEXT_DOMAIN ); ?></p>
			</div>
			<?php
		}
		
		// Check HTTPS if required
		if ( cf7uca_requires_https() && ! is_ssl() ) {
			?>
			<div class="notice notice-warning">
				<p>
					<?php _e( 'CF7 UCA requires HTTPS but your site is not using SSL.', CF7UCA_TEXT_DOMAIN ); ?>
					<a href="<?php echo admin_url( 'admin.php?page=cf7uca-settings' ); ?>">
						<?php _e( 'Disable HTTPS requirement in settings', CF7UCA_TEXT_DOMAIN ); ?>
					</a>
					<?php _e( 'or enable HTTPS on your server.', CF7UCA_TEXT_DOMAIN ); ?>
				</p>
			</div>
			<?php
		}
		
		// Show info notice for localhost development
		$host = isset( $_SERVER['HTTP_HOST'] ) ? $_SERVER['HTTP_HOST'] : '';
		if ( strpos( $host, 'localhost' ) !== false || strpos( $host, '127.0.0.1' ) !== false ) {
			$https_required = cf7uca_requires_https();
			if ( ! $https_required ) {
				?>
				<div class="notice notice-info is-dismissible">
					<p>
						<?php _e( 'CF7 UCA: HTTPS requirement is automatically disabled for localhost development.', CF7UCA_TEXT_DOMAIN ); ?>
						<a href="<?php echo admin_url( 'admin.php?page=cf7uca-settings' ); ?>">
							<?php _e( 'View settings', CF7UCA_TEXT_DOMAIN ); ?>
						</a>
					</p>
				</div>
				<?php
			}
		}
	}
	
	/**
	 * Handle revoke token AJAX
	 */
	public function handle_revoke_token() {
		if ( ! cf7uca_verify_nonce( $_POST['nonce'], 'cf7uca_admin' ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', CF7UCA_TEXT_DOMAIN ) ) );
		}
		
		$token_id = absint( $_POST['token_id'] );
		
		$token_manager = new \CF7UCA\Core\TokenManager();
		$success = $token_manager->revoke_token( $token_id );
		
		if ( $success ) {
			wp_send_json_success( array( 'message' => __( 'Token revoked successfully.', CF7UCA_TEXT_DOMAIN ) ) );
		} else {
			wp_send_json_error( array( 'message' => __( 'Failed to revoke token.', CF7UCA_TEXT_DOMAIN ) ) );
		}
	}
	
	/**
	 * Handle extend token AJAX
	 */
	public function handle_extend_token() {
		if ( ! cf7uca_verify_nonce( $_POST['nonce'], 'cf7uca_admin' ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', CF7UCA_TEXT_DOMAIN ) ) );
		}
		
		$token_id = absint( $_POST['token_id'] );
		$hours = absint( $_POST['hours'] );
		
		$token_manager = new \CF7UCA\Core\TokenManager();
		$success = $token_manager->extend_token_expiration( $token_id, $hours );
		
		if ( $success ) {
			wp_send_json_success( array( 'message' => __( 'Token extended successfully.', CF7UCA_TEXT_DOMAIN ) ) );
		} else {
			wp_send_json_error( array( 'message' => __( 'Failed to extend token.', CF7UCA_TEXT_DOMAIN ) ) );
		}
	}
	
	/**
	 * Handle cleanup tokens AJAX
	 */
	public function handle_cleanup_tokens() {
		if ( ! cf7uca_verify_nonce( $_POST['nonce'], 'cf7uca_admin' ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', CF7UCA_TEXT_DOMAIN ) ) );
		}
		
		$deleted = \CF7UCA\Database\SchemaManager::cleanup_expired_tokens();
		
		wp_send_json_success( array( 
			'message' => sprintf( __( '%d expired tokens cleaned up.', CF7UCA_TEXT_DOMAIN ), $deleted ),
			'deleted' => $deleted,
		));
	}
	
	// Form field rendering methods
	public function render_general_section() {
		echo '<p>' . __( 'Configure general UCA settings and security options.', CF7UCA_TEXT_DOMAIN ) . '</p>';
	}
	
	public function render_checkbox_field( $args ) {
		$key = $args['key'];
		$value = cf7uca_get_option( $key );
		$description = isset( $args['description'] ) ? $args['description'] : '';
		
		?>
		<label>
			<input type="checkbox" name="cf7uca_options[<?php echo esc_attr( $key ); ?>]" value="1" <?php checked( $value ); ?> />
			<?php echo esc_html( $description ); ?>
		</label>
		<?php
	}
	
	public function render_text_field( $args ) {
		$key = $args['key'];
		$value = cf7uca_get_option( $key );
		$description = isset( $args['description'] ) ? $args['description'] : '';
		
		?>
		<input type="text" name="cf7uca_options[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $value ); ?>" class="regular-text" />
		<?php if ( $description ) : ?>
			<p class="description"><?php echo esc_html( $description ); ?></p>
		<?php endif; ?>
		<?php
	}
	
	public function render_number_field( $args ) {
		$key = $args['key'];
		$value = cf7uca_get_option( $key );
		$description = isset( $args['description'] ) ? $args['description'] : '';
		$min = isset( $args['min'] ) ? $args['min'] : 1;
		$max = isset( $args['max'] ) ? $args['max'] : 999999;
		
		?>
		<input type="number" name="cf7uca_options[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $value ); ?>" min="<?php echo esc_attr( $min ); ?>" max="<?php echo esc_attr( $max ); ?>" class="small-text" />
		<?php if ( $description ) : ?>
			<p class="description"><?php echo esc_html( $description ); ?></p>
		<?php endif; ?>
		<?php
	}
}