<?php

namespace CF7UCA\Admin;

use CF7UCA\Core\OptionsManager;
use CF7UCA\Adapters\ResourceRegistry;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Settings page class
 */
class SettingsPage {
	
	/**
	 * Page instance
	 *
	 * @var SettingsPage
	 */
	private static $instance = null;
	
	/**
	 * Get page instance
	 *
	 * @return SettingsPage
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		$this->init_hooks();
	}
	
	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
		add_action( 'admin_init', array( $this, 'init_settings' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
	}
	
	/**
	 * Add admin menu
	 */
	public function add_admin_menu() {
		add_submenu_page(
			'wpcf7',
			__( 'UCA Settings', CF7UCA_TEXT_DOMAIN ),
			__( 'UCA Settings', CF7UCA_TEXT_DOMAIN ),
			'manage_options',
			'cf7uca-settings',
			array( $this, 'render_settings_page' )
		);
		
		add_submenu_page(
			'wpcf7',
			__( 'UCA Tokens', CF7UCA_TEXT_DOMAIN ),
			__( 'UCA Tokens', CF7UCA_TEXT_DOMAIN ),
			'manage_options',
			'cf7uca-tokens',
			array( $this, 'render_tokens_page' )
		);
		
		add_submenu_page(
			'wpcf7',
			__( 'UCA Adapters', CF7UCA_TEXT_DOMAIN ),
			__( 'UCA Adapters', CF7UCA_TEXT_DOMAIN ),
			'manage_options',
			'cf7uca-adapters',
			array( $this, 'render_adapters_page' )
		);
	}
	
	/**
	 * Initialize settings
	 */
	public function init_settings() {
		register_setting( 'cf7uca_settings', 'cf7uca_options', array( $this, 'sanitize_options' ) );
		
		// General settings section
		add_settings_section(
			'cf7uca_general',
			__( 'General Settings', CF7UCA_TEXT_DOMAIN ),
			array( $this, 'render_general_section' ),
			'cf7uca_settings'
		);
		
		// Token settings section
		add_settings_section(
			'cf7uca_tokens',
			__( 'Token Settings', CF7UCA_TEXT_DOMAIN ),
			array( $this, 'render_tokens_section' ),
			'cf7uca_settings'
		);
		
		// Access settings section
		add_settings_section(
			'cf7uca_access',
			__( 'Access Settings', CF7UCA_TEXT_DOMAIN ),
			array( $this, 'render_access_section' ),
			'cf7uca_settings'
		);
		
		// Email settings section
		add_settings_section(
			'cf7uca_email',
			__( 'Email Settings', CF7UCA_TEXT_DOMAIN ),
			array( $this, 'render_email_section' ),
			'cf7uca_settings'
		);
		
		$this->add_settings_fields();
	}
	
	/**
	 * Add settings fields
	 */
	private function add_settings_fields() {
		// General settings fields
		add_settings_field(
			'unified_access_enabled',
			__( 'Enable Unified Access', CF7UCA_TEXT_DOMAIN ),
			array( $this, 'render_checkbox_field' ),
			'cf7uca_settings',
			'cf7uca_general',
			array(
				'name'        => 'unified_access_enabled',
				'description' => __( 'Allow clients to access multiple resources with a single token', CF7UCA_TEXT_DOMAIN ),
			)
		);
		
		add_settings_field(
			'access_page_slug',
			__( 'Access Page Slug', CF7UCA_TEXT_DOMAIN ),
			array( $this, 'render_text_field' ),
			'cf7uca_settings',
			'cf7uca_general',
			array(
				'name'        => 'access_page_slug',
				'description' => __( 'URL slug for the access page (e.g., "access" for /access/)', CF7UCA_TEXT_DOMAIN ),
				'placeholder' => 'access',
			)
		);
		
		// Token settings fields
		add_settings_field(
			'default_token_expiry_hours',
			__( 'Default Token Expiry (Hours)', CF7UCA_TEXT_DOMAIN ),
			array( $this, 'render_number_field' ),
			'cf7uca_settings',
			'cf7uca_tokens',
			array(
				'name'        => 'default_token_expiry_hours',
				'description' => __( 'Default expiration time for new tokens in hours', CF7UCA_TEXT_DOMAIN ),
				'min'         => 1,
				'max'         => 8760, // 1 year
			)
		);
		
		add_settings_field(
			'max_usage_count',
			__( 'Maximum Usage Count', CF7UCA_TEXT_DOMAIN ),
			array( $this, 'render_number_field' ),
			'cf7uca_settings',
			'cf7uca_tokens',
			array(
				'name'        => 'max_usage_count',
				'description' => __( 'Maximum number of times a token can be used (0 for unlimited)', CF7UCA_TEXT_DOMAIN ),
				'min'         => 0,
				'max'         => 1000,
			)
		);
		
		add_settings_field(
			'one_time_tokens',
			__( 'One-time Tokens', CF7UCA_TEXT_DOMAIN ),
			array( $this, 'render_checkbox_field' ),
			'cf7uca_settings',
			'cf7uca_tokens',
			array(
				'name'        => 'one_time_tokens',
				'description' => __( 'Tokens can only be used once by default', CF7UCA_TEXT_DOMAIN ),
			)
		);
		
		// Access settings fields
		add_settings_field(
			'require_https',
			__( 'Require HTTPS', CF7UCA_TEXT_DOMAIN ),
			array( $this, 'render_checkbox_field' ),
			'cf7uca_settings',
			'cf7uca_access',
			array(
				'name'        => 'require_https',
				'description' => __( 'Only allow access over HTTPS connections. Automatically disabled for localhost development.', CF7UCA_TEXT_DOMAIN ),
			)
		);
		
		add_settings_field(
			'rate_limit_enabled',
			__( 'Enable Rate Limiting', CF7UCA_TEXT_DOMAIN ),
			array( $this, 'render_checkbox_field' ),
			'cf7uca_settings',
			'cf7uca_access',
			array(
				'name'        => 'rate_limit_enabled',
				'description' => __( 'Limit the number of access attempts per IP address', CF7UCA_TEXT_DOMAIN ),
			)
		);
		
		add_settings_field(
			'rate_limit_attempts',
			__( 'Rate Limit Attempts', CF7UCA_TEXT_DOMAIN ),
			array( $this, 'render_number_field' ),
			'cf7uca_settings',
			'cf7uca_access',
			array(
				'name'        => 'rate_limit_attempts',
				'description' => __( 'Maximum attempts per hour per IP address', CF7UCA_TEXT_DOMAIN ),
				'min'         => 1,
				'max'         => 100,
			)
		);
		
		// Email settings fields
		add_settings_field(
			'email_from_name',
			__( 'From Name', CF7UCA_TEXT_DOMAIN ),
			array( $this, 'render_text_field' ),
			'cf7uca_settings',
			'cf7uca_email',
			array(
				'name'        => 'email_from_name',
				'description' => __( 'Name to use in the "From" field of access emails', CF7UCA_TEXT_DOMAIN ),
				'placeholder' => get_bloginfo( 'name' ),
			)
		);
		
		add_settings_field(
			'email_from_address',
			__( 'From Email Address', CF7UCA_TEXT_DOMAIN ),
			array( $this, 'render_email_field' ),
			'cf7uca_settings',
			'cf7uca_email',
			array(
				'name'        => 'email_from_address',
				'description' => __( 'Email address to use in the "From" field', CF7UCA_TEXT_DOMAIN ),
				'placeholder' => get_option( 'admin_email' ),
			)
		);
		
		add_settings_field(
			'email_subject',
			__( 'Email Subject', CF7UCA_TEXT_DOMAIN ),
			array( $this, 'render_text_field' ),
			'cf7uca_settings',
			'cf7uca_email',
			array(
				'name'        => 'email_subject',
				'description' => __( 'Subject line for access emails', CF7UCA_TEXT_DOMAIN ),
				'placeholder' => __( 'Your Access Link', CF7UCA_TEXT_DOMAIN ),
			)
		);
		
		add_settings_field(
			'email_template',
			__( 'Email Template', CF7UCA_TEXT_DOMAIN ),
			array( $this, 'render_textarea_field' ),
			'cf7uca_settings',
			'cf7uca_email',
			array(
				'name'        => 'email_template',
				'description' => __( 'Email template. Use {access_link} for the access URL and {expiry_date} for expiration date.', CF7UCA_TEXT_DOMAIN ),
				'rows'        => 8,
			)
		);
	}
	
	/**
	 * Render settings page
	 */
	public function render_settings_page() {
		?>
		<div class="wrap">
			<h1><?php _e( 'CF7 UCA Settings', CF7UCA_TEXT_DOMAIN ); ?></h1>
			
			<?php settings_errors(); ?>
			
			<form method="post" action="options.php">
				<?php
				settings_fields( 'cf7uca_settings' );
				do_settings_sections( 'cf7uca_settings' );
				submit_button();
				?>
			</form>
			
			<div class="cf7uca-admin-info">
				<h2><?php _e( 'System Information', CF7UCA_TEXT_DOMAIN ); ?></h2>
				<?php $this->render_system_info(); ?>
			</div>
		</div>
		<?php
	}
	
	/**
	 * Render tokens page
	 */
	public function render_tokens_page() {
		$tokens_table = new TokenTable();
		$tokens_table->prepare_items();
		
		?>
		<div class="wrap">
			<h1><?php _e( 'CF7 UCA Tokens', CF7UCA_TEXT_DOMAIN ); ?></h1>
			
			<form method="get">
				<input type="hidden" name="page" value="cf7uca-tokens" />
				<?php $tokens_table->search_box( __( 'Search Tokens', CF7UCA_TEXT_DOMAIN ), 'token' ); ?>
			</form>
			
			<form method="post">
				<?php $tokens_table->display(); ?>
			</form>
		</div>
		<?php
	}
	
	/**
	 * Render adapters page
	 */
	public function render_adapters_page() {
		$registry = ResourceRegistry::instance();
		$adapter_status = $registry->get_adapter_status();
		$statistics = $registry->get_statistics();
		
		?>
		<div class="wrap">
			<h1><?php _e( 'CF7 UCA Adapters', CF7UCA_TEXT_DOMAIN ); ?></h1>
			
			<div class="cf7uca-adapter-stats">
				<h2><?php _e( 'Adapter Statistics', CF7UCA_TEXT_DOMAIN ); ?></h2>
				<p>
					<?php printf( 
						__( 'Total Adapters: %d | Active Adapters: %d', CF7UCA_TEXT_DOMAIN ),
						$statistics['total_adapters'],
						$statistics['active_adapters']
					); ?>
				</p>
			</div>
			
			<div class="cf7uca-adapter-list">
				<h2><?php _e( 'Registered Adapters', CF7UCA_TEXT_DOMAIN ); ?></h2>
				<table class="wp-list-table widefat fixed striped">
					<thead>
						<tr>
							<th><?php _e( 'Type', CF7UCA_TEXT_DOMAIN ); ?></th>
							<th><?php _e( 'Class', CF7UCA_TEXT_DOMAIN ); ?></th>
							<th><?php _e( 'Status', CF7UCA_TEXT_DOMAIN ); ?></th>
							<th><?php _e( 'Details', CF7UCA_TEXT_DOMAIN ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $adapter_status as $type => $status ) : ?>
							<tr>
								<td><strong><?php echo esc_html( $type ); ?></strong></td>
								<td><code><?php echo esc_html( $status['class'] ); ?></code></td>
								<td>
									<?php if ( $status['active'] ) : ?>
										<span class="cf7uca-status-active"><?php _e( 'Active', CF7UCA_TEXT_DOMAIN ); ?></span>
									<?php else : ?>
										<span class="cf7uca-status-inactive"><?php _e( 'Inactive', CF7UCA_TEXT_DOMAIN ); ?></span>
									<?php endif; ?>
								</td>
								<td>
									<?php if ( ! $status['exists'] ) : ?>
										<span class="cf7uca-error"><?php _e( 'Class not found', CF7UCA_TEXT_DOMAIN ); ?></span>
									<?php elseif ( ! $status['implements'] ) : ?>
										<span class="cf7uca-error"><?php _e( 'Does not implement ResourceInterface', CF7UCA_TEXT_DOMAIN ); ?></span>
									<?php elseif ( isset( $status['error'] ) ) : ?>
										<span class="cf7uca-error"><?php echo esc_html( $status['error'] ); ?></span>
									<?php else : ?>
										<span class="cf7uca-success"><?php _e( 'OK', CF7UCA_TEXT_DOMAIN ); ?></span>
									<?php endif; ?>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
		<?php
	}
	
	/**
	 * Render section descriptions
	 */
	public function render_general_section() {
		echo '<p>' . __( 'Configure general UCA settings.', CF7UCA_TEXT_DOMAIN ) . '</p>';
	}
	
	public function render_tokens_section() {
		echo '<p>' . __( 'Configure token behavior and security settings.', CF7UCA_TEXT_DOMAIN ) . '</p>';
	}
	
	public function render_access_section() {
		echo '<p>' . __( 'Configure access control and security settings.', CF7UCA_TEXT_DOMAIN ) . '</p>';
	}
	
	public function render_email_section() {
		echo '<p>' . __( 'Configure email settings for magic link delivery.', CF7UCA_TEXT_DOMAIN ) . '</p>';
	}
	
	/**
	 * Render form fields
	 */
	public function render_checkbox_field( $args ) {
		$options = OptionsManager::get_options();
		$value = isset( $options[ $args['name'] ] ) ? $options[ $args['name'] ] : false;
		
		?>
		<label>
			<input type="checkbox" name="cf7uca_options[<?php echo esc_attr( $args['name'] ); ?>]" value="1" <?php checked( $value ); ?> />
			<?php if ( ! empty( $args['description'] ) ) : ?>
				<span class="description"><?php echo esc_html( $args['description'] ); ?></span>
			<?php endif; ?>
		</label>
		<?php
	}
	
	public function render_text_field( $args ) {
		$options = OptionsManager::get_options();
		$value = isset( $options[ $args['name'] ] ) ? $options[ $args['name'] ] : '';
		$placeholder = isset( $args['placeholder'] ) ? $args['placeholder'] : '';
		
		?>
		<input type="text" 
			   name="cf7uca_options[<?php echo esc_attr( $args['name'] ); ?>]" 
			   value="<?php echo esc_attr( $value ); ?>" 
			   placeholder="<?php echo esc_attr( $placeholder ); ?>"
			   class="regular-text" />
		<?php if ( ! empty( $args['description'] ) ) : ?>
			<p class="description"><?php echo esc_html( $args['description'] ); ?></p>
		<?php endif; ?>
		<?php
	}
	
	public function render_email_field( $args ) {
		$options = OptionsManager::get_options();
		$value = isset( $options[ $args['name'] ] ) ? $options[ $args['name'] ] : '';
		$placeholder = isset( $args['placeholder'] ) ? $args['placeholder'] : '';
		
		?>
		<input type="email" 
			   name="cf7uca_options[<?php echo esc_attr( $args['name'] ); ?>]" 
			   value="<?php echo esc_attr( $value ); ?>" 
			   placeholder="<?php echo esc_attr( $placeholder ); ?>"
			   class="regular-text" />
		<?php if ( ! empty( $args['description'] ) ) : ?>
			<p class="description"><?php echo esc_html( $args['description'] ); ?></p>
		<?php endif; ?>
		<?php
	}
	
	public function render_number_field( $args ) {
		$options = OptionsManager::get_options();
		$value = isset( $options[ $args['name'] ] ) ? $options[ $args['name'] ] : '';
		$min = isset( $args['min'] ) ? $args['min'] : '';
		$max = isset( $args['max'] ) ? $args['max'] : '';
		
		?>
		<input type="number" 
			   name="cf7uca_options[<?php echo esc_attr( $args['name'] ); ?>]" 
			   value="<?php echo esc_attr( $value ); ?>" 
			   min="<?php echo esc_attr( $min ); ?>"
			   max="<?php echo esc_attr( $max ); ?>"
			   class="small-text" />
		<?php if ( ! empty( $args['description'] ) ) : ?>
			<p class="description"><?php echo esc_html( $args['description'] ); ?></p>
		<?php endif; ?>
		<?php
	}
	
	public function render_textarea_field( $args ) {
		$options = OptionsManager::get_options();
		$value = isset( $options[ $args['name'] ] ) ? $options[ $args['name'] ] : '';
		$rows = isset( $args['rows'] ) ? $args['rows'] : 5;
		
		?>
		<textarea name="cf7uca_options[<?php echo esc_attr( $args['name'] ); ?>]" 
				  rows="<?php echo esc_attr( $rows ); ?>" 
				  class="large-text"><?php echo esc_textarea( $value ); ?></textarea>
		<?php if ( ! empty( $args['description'] ) ) : ?>
			<p class="description"><?php echo esc_html( $args['description'] ); ?></p>
		<?php endif; ?>
		<?php
	}
	
	/**
	 * Sanitize options
	 *
	 * @param array $input Input options
	 * @return array Sanitized options
	 */
	public function sanitize_options( $input ) {
		$sanitized = array();
		
		// Boolean fields
		$boolean_fields = array(
			'unified_access_enabled',
			'one_time_tokens',
			'require_https',
			'rate_limit_enabled',
		);
		
		foreach ( $boolean_fields as $field ) {
			$sanitized[ $field ] = ! empty( $input[ $field ] );
		}
		
		// Text fields
		$text_fields = array(
			'access_page_slug',
			'email_from_name',
			'email_subject',
		);
		
		foreach ( $text_fields as $field ) {
			if ( isset( $input[ $field ] ) ) {
				$sanitized[ $field ] = sanitize_text_field( $input[ $field ] );
			}
		}
		
		// Email fields
		if ( isset( $input['email_from_address'] ) ) {
			$sanitized['email_from_address'] = sanitize_email( $input['email_from_address'] );
		}
		
		// Number fields
		$number_fields = array(
			'default_token_expiry_hours' => array( 'min' => 1, 'max' => 8760 ),
			'max_usage_count'            => array( 'min' => 0, 'max' => 1000 ),
			'rate_limit_attempts'        => array( 'min' => 1, 'max' => 100 ),
		);
		
		foreach ( $number_fields as $field => $limits ) {
			if ( isset( $input[ $field ] ) ) {
				$value = absint( $input[ $field ] );
				$value = max( $limits['min'], min( $limits['max'], $value ) );
				$sanitized[ $field ] = $value;
			}
		}
		
		// Textarea fields
		if ( isset( $input['email_template'] ) ) {
			$sanitized['email_template'] = wp_kses_post( $input['email_template'] );
		}
		
		// Validate access page slug
		if ( ! empty( $sanitized['access_page_slug'] ) ) {
			$sanitized['access_page_slug'] = sanitize_title( $sanitized['access_page_slug'] );
			
			if ( empty( $sanitized['access_page_slug'] ) ) {
				$sanitized['access_page_slug'] = 'access';
			}
		}
		
		return $sanitized;
	}
	
	/**
	 * Render system information
	 */
	private function render_system_info() {
		$registry = ResourceRegistry::instance();
		$statistics = $registry->get_statistics();
		
		?>
		<table class="form-table">
			<tr>
				<th scope="row"><?php _e( 'Plugin Version', CF7UCA_TEXT_DOMAIN ); ?></th>
				<td><?php echo esc_html( CF7UCA_VERSION ); ?></td>
			</tr>
			<tr>
				<th scope="row"><?php _e( 'WordPress Version', CF7UCA_TEXT_DOMAIN ); ?></th>
				<td><?php echo esc_html( get_bloginfo( 'version' ) ); ?></td>
			</tr>
			<tr>
				<th scope="row"><?php _e( 'PHP Version', CF7UCA_TEXT_DOMAIN ); ?></th>
				<td><?php echo esc_html( PHP_VERSION ); ?></td>
			</tr>
			<tr>
				<th scope="row"><?php _e( 'Contact Form 7', CF7UCA_TEXT_DOMAIN ); ?></th>
				<td>
					<?php if ( class_exists( 'WPCF7' ) ) : ?>
						<span class="cf7uca-status-active"><?php printf( __( 'Active (v%s)', CF7UCA_TEXT_DOMAIN ), WPCF7_VERSION ); ?></span>
					<?php else : ?>
						<span class="cf7uca-status-inactive"><?php _e( 'Not Active', CF7UCA_TEXT_DOMAIN ); ?></span>
					<?php endif; ?>
				</td>
			</tr>
			<tr>
				<th scope="row"><?php _e( 'Active Adapters', CF7UCA_TEXT_DOMAIN ); ?></th>
				<td><?php echo esc_html( $statistics['active_adapters'] ); ?> / <?php echo esc_html( $statistics['total_adapters'] ); ?></td>
			</tr>
			<tr>
				<th scope="row"><?php _e( 'Database Tables', CF7UCA_TEXT_DOMAIN ); ?></th>
				<td>
					<?php
					global $wpdb;
					$tokens_table = $wpdb->prefix . CF7UCA_TOKENS_TABLE;
					$logs_table = $wpdb->prefix . CF7UCA_LOGS_TABLE;
					
					$tokens_exists = $wpdb->get_var( "SHOW TABLES LIKE '{$tokens_table}'" ) === $tokens_table;
					$logs_exists = $wpdb->get_var( "SHOW TABLES LIKE '{$logs_table}'" ) === $logs_table;
					
					if ( $tokens_exists && $logs_exists ) {
						echo '<span class="cf7uca-status-active">' . __( 'OK', CF7UCA_TEXT_DOMAIN ) . '</span>';
					} else {
						echo '<span class="cf7uca-status-inactive">' . __( 'Missing Tables', CF7UCA_TEXT_DOMAIN ) . '</span>';
					}
					?>
				</td>
			</tr>
		</table>
		<?php
	}
	
	/**
	 * Enqueue admin scripts
	 *
	 * @param string $hook Current admin page hook
	 */
	public function enqueue_admin_scripts( $hook ) {
		// Only load on UCA admin pages
		if ( strpos( $hook, 'cf7uca' ) === false ) {
			return;
		}
		
		wp_enqueue_style(
			'cf7uca-admin',
			CF7UCA_PLUGIN_URL . '/assets/css/admin.css',
			array(),
			CF7UCA_VERSION
		);
		
		wp_enqueue_script(
			'cf7uca-admin',
			CF7UCA_PLUGIN_URL . '/assets/js/admin.js',
			array( 'jquery' ),
			CF7UCA_VERSION,
			true
		);
		
		wp_localize_script( 'cf7uca-admin', 'cf7uca_admin', array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'cf7uca_admin' ),
			'strings'  => array(
				'confirm_delete' => __( 'Are you sure you want to delete this token?', CF7UCA_TEXT_DOMAIN ),
				'confirm_revoke' => __( 'Are you sure you want to revoke this token?', CF7UCA_TEXT_DOMAIN ),
			),
		));
	}
}