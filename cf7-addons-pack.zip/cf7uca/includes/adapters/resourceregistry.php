<?php

namespace CF7UCA\Adapters;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Resource adapter registry
 */
class ResourceRegistry {
	
	/**
	 * Registry instance
	 *
	 * @var ResourceRegistry
	 */
	private static $instance = null;
	
	/**
	 * Registered adapters
	 *
	 * @var array
	 */
	private $adapters = array();
	
	/**
	 * Get registry instance
	 *
	 * @return ResourceRegistry
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	/**
	 * Constructor
	 */
	private function __construct() {
		$this->init_default_adapters();
		$this->init_hooks();
	}
	
	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		add_action( 'cf7uca_init', array( $this, 'load_external_adapters' ) );
	}
	
	/**
	 * Initialize default adapters
	 */
	private function init_default_adapters() {
		// Register mock adapter for testing
		$this->register_adapter( 'mock', 'CF7UCA\Adapters\MockAdapter' );
	}
	
	/**
	 * Register resource adapter
	 *
	 * @param string $type Resource type
	 * @param string $class_name Adapter class name
	 * @return bool Success status
	 */
	public function register_adapter( $type, $class_name ) {
		// Validate type
		if ( empty( $type ) || ! is_string( $type ) ) {
			cf7uca_log( 'Invalid adapter type provided', 'error' );
			return false;
		}
		
		// Validate class name
		if ( empty( $class_name ) || ! is_string( $class_name ) ) {
			cf7uca_log( "Invalid adapter class name for type: {$type}", 'error' );
			return false;
		}
		
		// Check if class exists
		if ( ! class_exists( $class_name ) ) {
			cf7uca_log( "Adapter class not found: {$class_name}", 'error' );
			return false;
		}
		
		// Check if class implements interface
		if ( ! in_array( 'CF7UCA\Interfaces\ResourceInterface', class_implements( $class_name ) ) ) {
			cf7uca_log( "Adapter class does not implement ResourceInterface: {$class_name}", 'error' );
			return false;
		}
		
		$this->adapters[ $type ] = $class_name;
		
		cf7uca_log( "Adapter registered: {$type} -> {$class_name}" );
		
		do_action( 'cf7uca_adapter_registered', $type, $class_name );
		
		return true;
	}
	
	/**
	 * Unregister resource adapter
	 *
	 * @param string $type Resource type
	 * @return bool Success status
	 */
	public function unregister_adapter( $type ) {
		if ( isset( $this->adapters[ $type ] ) ) {
			unset( $this->adapters[ $type ] );
			
			cf7uca_log( "Adapter unregistered: {$type}" );
			
			do_action( 'cf7uca_adapter_unregistered', $type );
			
			return true;
		}
		
		return false;
	}
	
	/**
	 * Get adapter for resource type
	 *
	 * @param string $type Resource type
	 * @return \CF7UCA\Interfaces\ResourceInterface|false Adapter instance or false
	 */
	public function get_adapter( $type ) {
		if ( ! isset( $this->adapters[ $type ] ) ) {
			return false;
		}
		
		$class_name = $this->adapters[ $type ];
		
		try {
			$adapter = new $class_name();
			
			if ( $adapter instanceof \CF7UCA\Interfaces\ResourceInterface ) {
				return $adapter;
			}
		} catch ( Exception $e ) {
			cf7uca_log( "Failed to instantiate adapter {$class_name}: " . $e->getMessage(), 'error' );
		}
		
		return false;
	}
	
	/**
	 * Get all registered adapters
	 *
	 * @return array Registered adapters
	 */
	public function get_adapters() {
		return $this->adapters;
	}
	
	/**
	 * Get adapter types
	 *
	 * @return array Adapter types
	 */
	public function get_adapter_types() {
		return array_keys( $this->adapters );
	}
	
	/**
	 * Check if adapter is registered
	 *
	 * @param string $type Resource type
	 * @return bool True if registered
	 */
	public function is_adapter_registered( $type ) {
		return isset( $this->adapters[ $type ] );
	}
	
	/**
	 * Get adapter status
	 *
	 * @return array Adapter status information
	 */
	public function get_adapter_status() {
		$status = array();
		
		foreach ( $this->adapters as $type => $class_name ) {
			$adapter_status = array(
				'type'       => $type,
				'class'      => $class_name,
				'exists'     => class_exists( $class_name ),
				'implements' => false,
				'active'     => false,
			);
			
			if ( $adapter_status['exists'] ) {
				$adapter_status['implements'] = in_array( 'CF7UCA\Interfaces\ResourceInterface', class_implements( $class_name ) );
				
				if ( $adapter_status['implements'] ) {
					try {
						$adapter = new $class_name();
						$adapter_status['active'] = true;
					} catch ( Exception $e ) {
						$adapter_status['error'] = $e->getMessage();
					}
				}
			}
			
			$status[ $type ] = $adapter_status;
		}
		
		return $status;
	}
	
	/**
	 * Load external adapters from other plugins
	 */
	public function load_external_adapters() {
		// Allow other plugins to register adapters
		do_action( 'cf7uca_register_adapters', $this );
		
		// Load adapters from CF7 Mini Ecommerce if available
		if ( defined( 'CF7MC_VERSION' ) ) {
			$this->register_cf7mc_adapter();
		}
		
		// Load adapters from CF7 Access Token if available
		if ( defined( 'CF7AT_VERSION' ) ) {
			$this->register_cf7at_adapter();
		}
	}
	
	/**
	 * Register CF7 Mini Ecommerce adapter
	 */
	private function register_cf7mc_adapter() {
		// Check if CF7MC order adapter exists
		if ( class_exists( 'CF7UCA\Adapters\CF7MCOrderAdapter' ) ) {
			$this->register_adapter( 'order', 'CF7UCA\Adapters\CF7MCOrderAdapter' );
		}
	}
	
	/**
	 * Register CF7 Access Token adapter
	 */
	private function register_cf7at_adapter() {
		// Check if CF7AT submission adapter exists
		if ( class_exists( 'CF7UCA\Adapters\CF7ATSubmissionAdapter' ) ) {
			$this->register_adapter( 'submission', 'CF7UCA\Adapters\CF7ATSubmissionAdapter' );
		}
	}
	
	/**
	 * Get adapter statistics
	 *
	 * @return array Statistics
	 */
	public function get_statistics() {
		$stats = array(
			'total_adapters'  => count( $this->adapters ),
			'active_adapters' => 0,
			'types'           => array(),
		);
		
		$status = $this->get_adapter_status();
		
		foreach ( $status as $type => $adapter_status ) {
			if ( $adapter_status['active'] ) {
				$stats['active_adapters']++;
			}
			
			$stats['types'][ $type ] = $adapter_status['active'];
		}
		
		return $stats;
	}
}