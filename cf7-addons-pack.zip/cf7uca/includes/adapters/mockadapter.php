<?php

namespace CF7UCA\Adapters;

use CF7UCA\Interfaces\ResourceInterface;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Mock adapter for testing and demonstration
 */
class MockAdapter implements ResourceInterface {
	
	/**
	 * Get resources by email
	 *
	 * @param string $email Client email
	 * @return array Array of resources
	 */
	public function get_resources_by_email( $email ) {
		// Mock data for demonstration
		return array(
			array(
				'id'          => 1,
				'title'       => 'Sample Order #1001',
				'description' => 'Mock order for testing purposes',
				'status'      => 'completed',
				'created_at'  => '2024-12-25 10:00:00',
				'amount'      => 99.99,
				'email'       => $email,
			),
			array(
				'id'          => 2,
				'title'       => 'Sample Order #1002',
				'description' => 'Another mock order',
				'status'      => 'pending',
				'created_at'  => '2024-12-26 14:30:00',
				'amount'      => 149.50,
				'email'       => $email,
			),
		);
	}
	
	/**
	 * Render resource summary
	 *
	 * @param array $resource Resource data
	 * @return string HTML output
	 */
	public function render_resource_summary( $resource ) {
		$status_class = 'cf7uca-status-' . esc_attr( $resource['status'] );
		$status_label = $this->get_resource_status_label( $resource['status'] );
		
		ob_start();
		?>
		<div class="cf7uca-resource-summary cf7uca-mock-resource">
			<div class="cf7uca-resource-header">
				<h3 class="cf7uca-resource-title">
					<a href="<?php echo esc_url( $this->get_resource_url( $resource['id'] ) ); ?>">
						<?php echo esc_html( $resource['title'] ); ?>
					</a>
				</h3>
				<span class="cf7uca-resource-status <?php echo $status_class; ?>">
					<?php echo esc_html( $status_label ); ?>
				</span>
			</div>
			
			<div class="cf7uca-resource-meta">
				<span class="cf7uca-resource-date">
					<?php echo cf7uca_format_date( $resource['created_at'] ); ?>
				</span>
				<span class="cf7uca-resource-amount">
					$<?php echo number_format( $resource['amount'], 2 ); ?>
				</span>
			</div>
			
			<div class="cf7uca-resource-description">
				<?php echo esc_html( $resource['description'] ); ?>
			</div>
			
			<div class="cf7uca-resource-actions">
				<?php $this->render_resource_actions( $resource['id'] ); ?>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}
	
	/**
	 * Render resource detail
	 *
	 * @param int $resource_id Resource ID
	 * @return string HTML output
	 */
	public function render_resource_detail( $resource_id ) {
		// Mock detailed data
		$resource = array(
			'id'          => $resource_id,
			'title'       => 'Sample Order #100' . $resource_id,
			'description' => 'Detailed view of mock order for testing purposes',
			'status'      => $resource_id % 2 === 0 ? 'completed' : 'pending',
			'created_at'  => '2024-12-25 10:00:00',
			'amount'      => 99.99 + ( $resource_id * 10 ),
			'items'       => array(
				array(
					'name'     => 'Mock Product A',
					'quantity' => 2,
					'price'    => 29.99,
				),
				array(
					'name'     => 'Mock Product B',
					'quantity' => 1,
					'price'    => 39.99,
				),
			),
		);
		
		$status_class = 'cf7uca-status-' . esc_attr( $resource['status'] );
		$status_label = $this->get_resource_status_label( $resource['status'] );
		
		ob_start();
		?>
		<div class="cf7uca-resource-detail cf7uca-mock-resource-detail">
			<div class="cf7uca-resource-header">
				<h2 class="cf7uca-resource-title"><?php echo esc_html( $resource['title'] ); ?></h2>
				<span class="cf7uca-resource-status <?php echo $status_class; ?>">
					<?php echo esc_html( $status_label ); ?>
				</span>
			</div>
			
			<div class="cf7uca-resource-info">
				<div class="cf7uca-info-section">
					<h3><?php _e( 'Order Information', CF7UCA_TEXT_DOMAIN ); ?></h3>
					<table class="cf7uca-info-table">
						<tr>
							<th><?php _e( 'Order ID:', CF7UCA_TEXT_DOMAIN ); ?></th>
							<td><?php echo esc_html( $resource['id'] ); ?></td>
						</tr>
						<tr>
							<th><?php _e( 'Date:', CF7UCA_TEXT_DOMAIN ); ?></th>
							<td><?php echo cf7uca_format_date( $resource['created_at'] ); ?></td>
						</tr>
						<tr>
							<th><?php _e( 'Status:', CF7UCA_TEXT_DOMAIN ); ?></th>
							<td><?php echo esc_html( $status_label ); ?></td>
						</tr>
						<tr>
							<th><?php _e( 'Total:', CF7UCA_TEXT_DOMAIN ); ?></th>
							<td>$<?php echo number_format( $resource['amount'], 2 ); ?></td>
						</tr>
					</table>
				</div>
				
				<div class="cf7uca-info-section">
					<h3><?php _e( 'Items', CF7UCA_TEXT_DOMAIN ); ?></h3>
					<table class="cf7uca-items-table">
						<thead>
							<tr>
								<th><?php _e( 'Item', CF7UCA_TEXT_DOMAIN ); ?></th>
								<th><?php _e( 'Quantity', CF7UCA_TEXT_DOMAIN ); ?></th>
								<th><?php _e( 'Price', CF7UCA_TEXT_DOMAIN ); ?></th>
								<th><?php _e( 'Total', CF7UCA_TEXT_DOMAIN ); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ( $resource['items'] as $item ) : ?>
							<tr>
								<td><?php echo esc_html( $item['name'] ); ?></td>
								<td><?php echo esc_html( $item['quantity'] ); ?></td>
								<td>$<?php echo number_format( $item['price'], 2 ); ?></td>
								<td>$<?php echo number_format( $item['price'] * $item['quantity'], 2 ); ?></td>
							</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			</div>
			
			<div class="cf7uca-resource-actions">
				<?php $this->render_resource_actions( $resource_id ); ?>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}
	
	/**
	 * Get allowed actions for resource
	 *
	 * @param int $resource_id Resource ID
	 * @return array Array of allowed actions
	 */
	public function get_allowed_actions( $resource_id ) {
		// Mock actions based on resource status
		$status = $resource_id % 2 === 0 ? 'completed' : 'pending';
		
		$actions = array();
		
		if ( $status === 'pending' ) {
			$actions[] = 'retry_payment';
			$actions[] = 'cancel_order';
		} elseif ( $status === 'completed' ) {
			$actions[] = 'download_invoice';
			$actions[] = 'request_refund';
		}
		
		return $actions;
	}
	
	/**
	 * Get resource type
	 *
	 * @return string Resource type identifier
	 */
	public function get_resource_type() {
		return 'mock';
	}
	
	/**
	 * Get resource type label
	 *
	 * @return string Human-readable resource type label
	 */
	public function get_resource_type_label() {
		return __( 'Mock Orders', CF7UCA_TEXT_DOMAIN );
	}
	
	/**
	 * Validate resource access
	 *
	 * @param int $resource_id Resource ID
	 * @param string $email Client email
	 * @return bool True if access is allowed
	 */
	public function validate_resource_access( $resource_id, $email ) {
		// Mock validation - always allow access for demonstration
		return true;
	}
	
	/**
	 * Handle resource action
	 *
	 * @param string $action Action name
	 * @param int $resource_id Resource ID
	 * @param array $data Action data
	 * @return array Result array with success/error
	 */
	public function handle_resource_action( $action, $resource_id, $data = array() ) {
		switch ( $action ) {
			case 'retry_payment':
				return array(
					'success' => true,
					'message' => __( 'Payment retry initiated successfully.', CF7UCA_TEXT_DOMAIN ),
					'data'    => array(
						'payment_url' => 'https://example.com/payment/' . $resource_id,
					),
				);
				
			case 'cancel_order':
				return array(
					'success' => true,
					'message' => __( 'Order cancelled successfully.', CF7UCA_TEXT_DOMAIN ),
				);
				
			case 'download_invoice':
				return array(
					'success' => true,
					'message' => __( 'Invoice download started.', CF7UCA_TEXT_DOMAIN ),
					'data'    => array(
						'download_url' => 'https://example.com/invoice/' . $resource_id . '.pdf',
					),
				);
				
			case 'request_refund':
				return array(
					'success' => true,
					'message' => __( 'Refund request submitted successfully.', CF7UCA_TEXT_DOMAIN ),
				);
				
			default:
				return array(
					'success' => false,
					'message' => __( 'Unknown action.', CF7UCA_TEXT_DOMAIN ),
				);
		}
	}
	
	/**
	 * Get resource status
	 *
	 * @param array $resource Resource data
	 * @return string Status identifier
	 */
	public function get_resource_status( $resource ) {
		return isset( $resource['status'] ) ? $resource['status'] : 'unknown';
	}
	
	/**
	 * Get resource status label
	 *
	 * @param string $status Status identifier
	 * @return string Human-readable status label
	 */
	public function get_resource_status_label( $status ) {
		$labels = array(
			'pending'   => __( 'Pending', CF7UCA_TEXT_DOMAIN ),
			'completed' => __( 'Completed', CF7UCA_TEXT_DOMAIN ),
			'cancelled' => __( 'Cancelled', CF7UCA_TEXT_DOMAIN ),
			'refunded'  => __( 'Refunded', CF7UCA_TEXT_DOMAIN ),
		);
		
		return isset( $labels[ $status ] ) ? $labels[ $status ] : ucfirst( $status );
	}
	
	/**
	 * Get resource URL
	 *
	 * @param int $resource_id Resource ID
	 * @return string Resource URL
	 */
	private function get_resource_url( $resource_id ) {
		$access_slug = cf7uca_get_access_page_slug();
		return home_url( $access_slug . '/mock/' . $resource_id );
	}
	
	/**
	 * Render resource actions
	 *
	 * @param int $resource_id Resource ID
	 */
	private function render_resource_actions( $resource_id ) {
		$actions = $this->get_allowed_actions( $resource_id );
		
		if ( empty( $actions ) ) {
			return;
		}
		
		foreach ( $actions as $action ) {
			$label = $this->get_action_label( $action );
			$class = 'cf7uca-action-btn cf7uca-action-' . esc_attr( $action );
			
			?>
			<button type="button" 
					class="<?php echo $class; ?>" 
					data-action="<?php echo esc_attr( $action ); ?>"
					data-resource-id="<?php echo esc_attr( $resource_id ); ?>"
					data-resource-type="mock">
				<?php echo esc_html( $label ); ?>
			</button>
			<?php
		}
	}
	
	/**
	 * Get action label
	 *
	 * @param string $action Action name
	 * @return string Action label
	 */
	private function get_action_label( $action ) {
		$labels = array(
			'retry_payment'    => __( 'Retry Payment', CF7UCA_TEXT_DOMAIN ),
			'cancel_order'     => __( 'Cancel Order', CF7UCA_TEXT_DOMAIN ),
			'download_invoice' => __( 'Download Invoice', CF7UCA_TEXT_DOMAIN ),
			'request_refund'   => __( 'Request Refund', CF7UCA_TEXT_DOMAIN ),
		);
		
		return isset( $labels[ $action ] ) ? $labels[ $action ] : ucfirst( str_replace( '_', ' ', $action ) );
	}
}