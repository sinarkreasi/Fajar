<?php

namespace CF7UCA\Adapters;

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Adapter loader class
 */
class AdapterLoader {
	
	/**
	 * Load adapters from directory
	 *
	 * @param string $directory Directory path
	 * @param string $namespace Namespace prefix
	 * @return array Loaded adapters
	 */
	public static function load_from_directory( $directory, $namespace = 'CF7UCA\Adapters' ) {
		$loaded_adapters = array();
		
		if ( ! is_dir( $directory ) ) {
			return $loaded_adapters;
		}
		
		$files = glob( $directory . '/*adapter.php' );
		
		foreach ( $files as $file ) {
			$adapter_info = self::load_adapter_file( $file, $namespace );
			
			if ( $adapter_info ) {
				$loaded_adapters[] = $adapter_info;
			}
		}
		
		return $loaded_adapters;
	}
	
	/**
	 * Load adapter from file
	 *
	 * @param string $file File path
	 * @param string $namespace Namespace prefix
	 * @return array|false Adapter info or false on failure
	 */
	public static function load_adapter_file( $file, $namespace = 'CF7UCA\Adapters' ) {
		if ( ! file_exists( $file ) ) {
			return false;
		}
		
		// Include the file
		require_once $file;
		
		// Extract class name from filename
		$filename = basename( $file, '.php' );
		$class_name = $namespace . '\\' . ucfirst( $filename );
		
		// Check if class exists and implements interface
		if ( class_exists( $class_name ) && 
			 in_array( 'CF7UCA\Interfaces\ResourceInterface', class_implements( $class_name ) ) ) {
			
			try {
				$adapter = new $class_name();
				$resource_type = $adapter->get_resource_type();
				
				return array(
					'type'       => $resource_type,
					'class'      => $class_name,
					'file'       => $file,
					'adapter'    => $adapter,
				);
			} catch ( Exception $e ) {
				cf7uca_log( "Failed to load adapter from {$file}: " . $e->getMessage(), 'error' );
			}
		}
		
		return false;
	}
	
	/**
	 * Auto-register adapters from directory
	 *
	 * @param string $directory Directory path
	 * @param string $namespace Namespace prefix
	 * @return int Number of adapters registered
	 */
	public static function auto_register_from_directory( $directory, $namespace = 'CF7UCA\Adapters' ) {
		$adapters = self::load_from_directory( $directory, $namespace );
		$registered_count = 0;
		
		$registry = ResourceRegistry::instance();
		
		foreach ( $adapters as $adapter_info ) {
			if ( $registry->register_adapter( $adapter_info['type'], $adapter_info['class'] ) ) {
				$registered_count++;
			}
		}
		
		return $registered_count;
	}
	
	/**
	 * Validate adapter class
	 *
	 * @param string $class_name Class name
	 * @return array Validation result
	 */
	public static function validate_adapter_class( $class_name ) {
		$result = array(
			'valid'      => false,
			'exists'     => false,
			'implements' => false,
			'instantiable' => false,
			'errors'     => array(),
		);
		
		// Check if class exists
		if ( ! class_exists( $class_name ) ) {
			$result['errors'][] = "Class {$class_name} does not exist";
			return $result;
		}
		
		$result['exists'] = true;
		
		// Check if implements interface
		if ( ! in_array( 'CF7UCA\Interfaces\ResourceInterface', class_implements( $class_name ) ) ) {
			$result['errors'][] = "Class {$class_name} does not implement ResourceInterface";
			return $result;
		}
		
		$result['implements'] = true;
		
		// Check if instantiable
		try {
			$adapter = new $class_name();
			$result['instantiable'] = true;
			$result['valid'] = true;
		} catch ( Exception $e ) {
			$result['errors'][] = "Cannot instantiate {$class_name}: " . $e->getMessage();
		}
		
		return $result;
	}
	
	/**
	 * Get adapter requirements
	 *
	 * @param string $class_name Adapter class name
	 * @return array Requirements
	 */
	public static function get_adapter_requirements( $class_name ) {
		$requirements = array(
			'php_version'    => '7.4',
			'wp_version'     => '6.0',
			'dependencies'   => array(),
			'constants'      => array(),
			'functions'      => array(),
			'classes'        => array(),
		);
		
		// Check if adapter has requirements method
		if ( class_exists( $class_name ) && method_exists( $class_name, 'get_requirements' ) ) {
			$adapter_requirements = call_user_func( array( $class_name, 'get_requirements' ) );
			$requirements = wp_parse_args( $adapter_requirements, $requirements );
		}
		
		return $requirements;
	}
	
	/**
	 * Check adapter requirements
	 *
	 * @param string $class_name Adapter class name
	 * @return array Check result
	 */
	public static function check_adapter_requirements( $class_name ) {
		$requirements = self::get_adapter_requirements( $class_name );
		$result = array(
			'met'    => true,
			'checks' => array(),
		);
		
		// Check PHP version
		$php_check = version_compare( PHP_VERSION, $requirements['php_version'], '>=' );
		$result['checks']['php_version'] = array(
			'required' => $requirements['php_version'],
			'current'  => PHP_VERSION,
			'met'      => $php_check,
		);
		
		if ( ! $php_check ) {
			$result['met'] = false;
		}
		
		// Check WordPress version
		$wp_check = version_compare( get_bloginfo( 'version' ), $requirements['wp_version'], '>=' );
		$result['checks']['wp_version'] = array(
			'required' => $requirements['wp_version'],
			'current'  => get_bloginfo( 'version' ),
			'met'      => $wp_check,
		);
		
		if ( ! $wp_check ) {
			$result['met'] = false;
		}
		
		// Check dependencies
		foreach ( $requirements['dependencies'] as $dependency ) {
			$dep_check = is_plugin_active( $dependency );
			$result['checks']['dependencies'][ $dependency ] = array(
				'required' => $dependency,
				'met'      => $dep_check,
			);
			
			if ( ! $dep_check ) {
				$result['met'] = false;
			}
		}
		
		// Check constants
		foreach ( $requirements['constants'] as $constant ) {
			$const_check = defined( $constant );
			$result['checks']['constants'][ $constant ] = array(
				'required' => $constant,
				'met'      => $const_check,
			);
			
			if ( ! $const_check ) {
				$result['met'] = false;
			}
		}
		
		// Check functions
		foreach ( $requirements['functions'] as $function ) {
			$func_check = function_exists( $function );
			$result['checks']['functions'][ $function ] = array(
				'required' => $function,
				'met'      => $func_check,
			);
			
			if ( ! $func_check ) {
				$result['met'] = false;
			}
		}
		
		// Check classes
		foreach ( $requirements['classes'] as $class ) {
			$class_check = class_exists( $class );
			$result['checks']['classes'][ $class ] = array(
				'required' => $class,
				'met'      => $class_check,
			);
			
			if ( ! $class_check ) {
				$result['met'] = false;
			}
		}
		
		return $result;
	}
}