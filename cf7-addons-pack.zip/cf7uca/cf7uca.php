<?php
/*
 * Plugin Name: CF7 Unified Client Access (UCA)
 * Plugin URI: https://github.com/cf7-uca/cf7uca
 * Description: Unified Client Access system for Contact Form 7 - provides passwordless, token-based access to multiple CF7 resources through a single entry point.
 * Author: CF7 UCA Team
 * Version: 1.0.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Text Domain: cf7uca
 * Domain Path: /languages
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Plugin version
define( 'CF7UCA_VERSION', '1.0.0' );

// Plugin constants
define( 'CF7UCA_PLUGIN_FILE', __FILE__ );
define( 'CF7UCA_PLUGIN_BASENAME', plugin_basename( CF7UCA_PLUGIN_FILE ) );
define( 'CF7UCA_PLUGIN_DIR', untrailingslashit( dirname( CF7UCA_PLUGIN_FILE ) ) );
define( 'CF7UCA_PLUGIN_URL', untrailingslashit( plugins_url( '', CF7UCA_PLUGIN_FILE ) ) );
define( 'CF7UCA_TEXT_DOMAIN', 'cf7uca' );

// Database table names
define( 'CF7UCA_TOKENS_TABLE', 'cf7_uca_tokens' );
define( 'CF7UCA_LOGS_TABLE', 'cf7_uca_logs' );

// Security constants
define( 'CF7UCA_TOKEN_LENGTH', 64 );
define( 'CF7UCA_DEFAULT_EXPIRY_HOURS', 72 );
define( 'CF7UCA_MAX_USAGE_COUNT', 10 );

// Check dependencies
add_action( 'plugins_loaded', 'cf7uca_check_dependencies' );

function cf7uca_check_dependencies() {
	$missing_plugins = array();
	
	// Check for Contact Form 7
	if ( ! class_exists( 'WPCF7' ) ) {
		$missing_plugins[] = 'Contact Form 7';
	}
	
	if ( ! empty( $missing_plugins ) ) {
		add_action( 'admin_notices', function() use ( $missing_plugins ) {
			?>
			<div class="notice notice-error">
				<p><?php printf( 
					__( 'CF7 Unified Client Access requires the following plugins: %s', CF7UCA_TEXT_DOMAIN ),
					implode( ', ', $missing_plugins )
				); ?></p>
			</div>
			<?php
		});
		return;
	}
	
	// Initialize UCA
	cf7uca_init();
}

// Load plugin files
require_once CF7UCA_PLUGIN_DIR . '/load.php';

// Plugin activation hook
register_activation_hook( CF7UCA_PLUGIN_FILE, 'cf7uca_activate' );

// Plugin deactivation hook
register_deactivation_hook( CF7UCA_PLUGIN_FILE, 'cf7uca_deactivate' );

/**
 * Plugin activation callback
 */
function cf7uca_activate() {
	// Create database tables
	CF7UCA\Database\SchemaManager::create_tables();
	
	// Set default options
	CF7UCA\Core\OptionsManager::set_defaults();
	
	// Flush rewrite rules
	flush_rewrite_rules();
}

/**
 * Plugin deactivation callback
 */
function cf7uca_deactivate() {
	// Flush rewrite rules
	flush_rewrite_rules();
}