<?php

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Autoloader
spl_autoload_register( 'cf7uca_autoloader' );

function cf7uca_autoloader( $class ) {
	// Only handle our namespace
	if ( strpos( $class, 'CF7UCA\\' ) !== 0 ) {
		return;
	}
	
	// Remove namespace prefix
	$class = substr( $class, 7 );
	
	// Convert namespace separators to directory separators
	$class = str_replace( '\\', DIRECTORY_SEPARATOR, $class );
	
	// Convert to lowercase and add .php extension
	$file = CF7UCA_PLUGIN_DIR . '/includes/' . strtolower( $class ) . '.php';
	
	if ( file_exists( $file ) ) {
		require_once $file;
	}
}

// Load helper functions
require_once CF7UCA_PLUGIN_DIR . '/includes/functions.php';

// Load interfaces
require_once CF7UCA_PLUGIN_DIR . '/includes/interfaces/resourceinterface.php';

// Load core classes
require_once CF7UCA_PLUGIN_DIR . '/includes/core/optionsmanager.php';
require_once CF7UCA_PLUGIN_DIR . '/includes/core/tokenmanager.php';
require_once CF7UCA_PLUGIN_DIR . '/includes/core/accessvalidator.php';
require_once CF7UCA_PLUGIN_DIR . '/includes/core/accesscontroller.php';

// Load database classes
require_once CF7UCA_PLUGIN_DIR . '/includes/database/schemamanager.php';

// Load adapter classes
require_once CF7UCA_PLUGIN_DIR . '/includes/adapters/resourceregistry.php';
require_once CF7UCA_PLUGIN_DIR . '/includes/adapters/adapterloader.php';
require_once CF7UCA_PLUGIN_DIR . '/includes/adapters/mockadapter.php';

// Load frontend classes
require_once CF7UCA_PLUGIN_DIR . '/includes/frontend/unifiedviewrenderer.php';

// Load email classes
require_once CF7UCA_PLUGIN_DIR . '/includes/emails/magiclinkmailer.php';

// Load admin classes if in admin area
if ( is_admin() ) {
	require_once CF7UCA_PLUGIN_DIR . '/includes/admin/settingspage.php';
	require_once CF7UCA_PLUGIN_DIR . '/includes/admin/tokentable.php';
	require_once CF7UCA_PLUGIN_DIR . '/includes/admin/admininit.php';
}

// Initialize plugin
function cf7uca_init() {
	// Load text domain
	load_plugin_textdomain( CF7UCA_TEXT_DOMAIN, false, dirname( CF7UCA_PLUGIN_BASENAME ) . '/languages' );
	
	// Initialize core components
	CF7UCA\Core\AccessController::instance();
	
	// Initialize adapter registry
	CF7UCA\Adapters\ResourceRegistry::instance();
	
	// Initialize frontend
	CF7UCA\Frontend\UnifiedViewRenderer::instance();
	
	// Initialize admin if in admin area
	if ( is_admin() ) {
		CF7UCA\Admin\AdminInit::instance();
	}
	
	do_action( 'cf7uca_init' );
}