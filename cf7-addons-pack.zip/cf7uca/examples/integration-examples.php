<?php
/**
 * CF7 UCA Integration Examples
 * 
 * This file shows how to integrate CF7 UCA with existing plugins
 * and create custom adapters for different resource types.
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Example 1: CF7 Mini Ecommerce Integration
 * 
 * This adapter connects CF7 UCA with CF7 Mini Ecommerce orders
 */
class CF7UCA_CF7MC_OrderAdapter implements CF7UCA\Interfaces\ResourceInterface {
	
	public function get_resources_by_email( $email ) {
		if ( ! class_exists( 'CF7MC\Core\OrderManager' ) ) {
			return array();
		}
		
		$order_manager = new CF7MC\Core\OrderManager();
		$result = $order_manager->get_orders( array(
			'search' => $email,
			'per_page' => 50,
		));
		
		return $result['orders'];
	}
	
	public function render_resource_summary( $resource ) {
		$status_class = 'cf7uca-status-' . esc_attr( $resource['status'] );
		
		ob_start();
		?>
		<div class="cf7uca-resource-summary cf7uca-order-summary">
			<div class="cf7uca-resource-header">
				<h3 class="cf7uca-resource-title">
					<a href="<?php echo esc_url( $this->get_resource_url( $resource['id'] ) ); ?>">
						<?php printf( __( 'Order #%s', 'cf7uca' ), $resource['order_code'] ); ?>
					</a>
				</h3>
				<span class="cf7uca-resource-status <?php echo $status_class; ?>">
					<?php echo esc_html( $this->get_resource_status_label( $resource['status'] ) ); ?>
				</span>
			</div>
			
			<div class="cf7uca-resource-meta">
				<span class="cf7uca-resource-date">
					<?php echo cf7uca_format_date( $resource['created_at'] ); ?>
				</span>
				<span class="cf7uca-resource-amount">
					<?php echo cf7mc_format_amount( $resource['total_amount'] ); ?>
				</span>
			</div>
			
			<div class="cf7uca-resource-actions">
				<?php $this->render_order_actions( $resource ); ?>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}
	
	public function render_resource_detail( $resource_id ) {
		$order_manager = new CF7MC\Core\OrderManager();
		$order = $order_manager->get_order( $resource_id );
		
		if ( ! $order ) {
			return '<p>' . __( 'Order not found.', 'cf7uca' ) . '</p>';
		}
		
		ob_start();
		?>
		<div class="cf7uca-order-detail">
			<h2><?php printf( __( 'Order #%s', 'cf7uca' ), $order['order_code'] ); ?></h2>
			
			<div class="cf7uca-order-info">
				<table class="cf7uca-info-table">
					<tr>
						<th><?php _e( 'Order Code:', 'cf7uca' ); ?></th>
						<td><?php echo esc_html( $order['order_code'] ); ?></td>
					</tr>
					<tr>
						<th><?php _e( 'Status:', 'cf7uca' ); ?></th>
						<td><?php echo esc_html( $this->get_resource_status_label( $order['status'] ) ); ?></td>
					</tr>
					<tr>
						<th><?php _e( 'Total:', 'cf7uca' ); ?></th>
						<td><?php echo cf7mc_format_amount( $order['total_amount'] ); ?></td>
					</tr>
					<tr>
						<th><?php _e( 'Date:', 'cf7uca' ); ?></th>
						<td><?php echo cf7uca_format_date( $order['created_at'] ); ?></td>
					</tr>
				</table>
			</div>
			
			<div class="cf7uca-order-items">
				<h3><?php _e( 'Items', 'cf7uca' ); ?></h3>
				<?php $this->render_order_items( $order['items'] ); ?>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}
	
	public function get_allowed_actions( $resource_id ) {
		$order_manager = new CF7MC\Core\OrderManager();
		$order = $order_manager->get_order( $resource_id );
		
		if ( ! $order ) {
			return array();
		}
		
		$actions = array();
		
		switch ( $order['status'] ) {
			case 'pending':
			case 'failed':
				$actions[] = 'retry_payment';
				$actions[] = 'cancel_order';
				break;
				
			case 'paid':
				$actions[] = 'download_invoice';
				break;
		}
		
		return $actions;
	}
	
	public function get_resource_type() {
		return 'order';
	}
	
	public function get_resource_type_label() {
		return __( 'Orders', 'cf7uca' );
	}
	
	public function validate_resource_access( $resource_id, $email ) {
		$order_manager = new CF7MC\Core\OrderManager();
		$order = $order_manager->get_order( $resource_id );
		
		return $order && $order['email'] === $email;
	}
	
	public function handle_resource_action( $action, $resource_id, $data = array() ) {
		switch ( $action ) {
			case 'retry_payment':
				return $this->handle_payment_retry( $resource_id );
				
			case 'cancel_order':
				return $this->handle_order_cancellation( $resource_id );
				
			case 'download_invoice':
				return $this->handle_invoice_download( $resource_id );
				
			default:
				return array(
					'success' => false,
					'message' => __( 'Unknown action.', 'cf7uca' ),
				);
		}
	}
	
	public function get_resource_status( $resource ) {
		return $resource['status'];
	}
	
	public function get_resource_status_label( $status ) {
		$labels = array(
			'pending' => __( 'Pending Payment', 'cf7uca' ),
			'paid'    => __( 'Paid', 'cf7uca' ),
			'failed'  => __( 'Payment Failed', 'cf7uca' ),
			'expired' => __( 'Expired', 'cf7uca' ),
		);
		
		return isset( $labels[ $status ] ) ? $labels[ $status ] : ucfirst( $status );
	}
	
	// Helper methods
	private function get_resource_url( $resource_id ) {
		$access_slug = cf7uca_get_access_page_slug();
		return home_url( $access_slug . '/order/' . $resource_id );
	}
	
	private function render_order_actions( $order ) {
		$actions = $this->get_allowed_actions( $order['id'] );
		
		foreach ( $actions as $action ) {
			$label = $this->get_action_label( $action );
			?>
			<button type="button" 
					class="cf7uca-action-btn cf7uca-action-<?php echo esc_attr( $action ); ?>" 
					data-action="<?php echo esc_attr( $action ); ?>"
					data-resource-id="<?php echo esc_attr( $order['id'] ); ?>"
					data-resource-type="order">
				<?php echo esc_html( $label ); ?>
			</button>
			<?php
		}
	}
	
	private function render_order_items( $items ) {
		if ( empty( $items ) ) {
			echo '<p>' . __( 'No items found.', 'cf7uca' ) . '</p>';
			return;
		}
		
		?>
		<table class="cf7uca-items-table">
			<thead>
				<tr>
					<th><?php _e( 'Item', 'cf7uca' ); ?></th>
					<th><?php _e( 'Quantity', 'cf7uca' ); ?></th>
					<th><?php _e( 'Price', 'cf7uca' ); ?></th>
					<th><?php _e( 'Total', 'cf7uca' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $items as $item ) : ?>
				<tr>
					<td><?php echo esc_html( $item['name'] ); ?></td>
					<td><?php echo esc_html( $item['quantity'] ); ?></td>
					<td><?php echo cf7mc_format_amount( $item['price'] ); ?></td>
					<td><?php echo cf7mc_format_amount( $item['price'] * $item['quantity'] ); ?></td>
				</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}
	
	private function handle_payment_retry( $resource_id ) {
		// Integrate with CF7MC payment retry logic
		$order_manager = new CF7MC\Core\OrderManager();
		$order = $order_manager->get_order( $resource_id );
		
		if ( ! $order ) {
			return array(
				'success' => false,
				'message' => __( 'Order not found.', 'cf7uca' ),
			);
		}
		
		// Generate new payment URL
		$gateway_class = cf7mc_get_gateway_class( $order['gateway'] );
		if ( ! $gateway_class ) {
			return array(
				'success' => false,
				'message' => __( 'Payment gateway not available.', 'cf7uca' ),
			);
		}
		
		$gateway = new $gateway_class();
		$payment_result = $gateway->create_payment_intent( $order );
		
		return $payment_result;
	}
	
	private function handle_order_cancellation( $resource_id ) {
		$order_manager = new CF7MC\Core\OrderManager();
		$success = $order_manager->update_order_status( $resource_id, 'cancelled' );
		
		if ( $success ) {
			return array(
				'success' => true,
				'message' => __( 'Order cancelled successfully.', 'cf7uca' ),
			);
		} else {
			return array(
				'success' => false,
				'message' => __( 'Failed to cancel order.', 'cf7uca' ),
			);
		}
	}
	
	private function handle_invoice_download( $resource_id ) {
		// Generate invoice download URL
		$download_url = wp_nonce_url(
			home_url( '/download-invoice/?order_id=' . $resource_id ),
			'download_invoice_' . $resource_id
		);
		
		return array(
			'success' => true,
			'message' => __( 'Invoice download ready.', 'cf7uca' ),
			'data'    => array(
				'download_url' => $download_url,
			),
		);
	}
	
	private function get_action_label( $action ) {
		$labels = array(
			'retry_payment'    => __( 'Retry Payment', 'cf7uca' ),
			'cancel_order'     => __( 'Cancel Order', 'cf7uca' ),
			'download_invoice' => __( 'Download Invoice', 'cf7uca' ),
		);
		
		return isset( $labels[ $action ] ) ? $labels[ $action ] : ucfirst( str_replace( '_', ' ', $action ) );
	}
}

/**
 * Example 2: Register the CF7MC adapter
 */
add_action( 'cf7uca_register_adapters', function( $registry ) {
	if ( defined( 'CF7MC_VERSION' ) ) {
		$registry->register_adapter( 'order', 'CF7UCA_CF7MC_OrderAdapter' );
	}
});

/**
 * Example 3: Custom booking adapter
 */
class CF7UCA_BookingAdapter implements CF7UCA\Interfaces\ResourceInterface {
	
	public function get_resources_by_email( $email ) {
		// Get bookings from custom table or post meta
		global $wpdb;
		
		$bookings = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}bookings WHERE email = %s ORDER BY created_at DESC",
				$email
			),
			ARRAY_A
		);
		
		return $bookings;
	}
	
	public function render_resource_summary( $resource ) {
		ob_start();
		?>
		<div class="cf7uca-booking-summary">
			<h3><?php echo esc_html( $resource['service_name'] ); ?></h3>
			<p><strong><?php _e( 'Date:', 'cf7uca' ); ?></strong> <?php echo cf7uca_format_date( $resource['booking_date'] ); ?></p>
			<p><strong><?php _e( 'Status:', 'cf7uca' ); ?></strong> <?php echo esc_html( $this->get_resource_status_label( $resource['status'] ) ); ?></p>
		</div>
		<?php
		return ob_get_clean();
	}
	
	public function render_resource_detail( $resource_id ) {
		global $wpdb;
		
		$booking = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}bookings WHERE id = %d",
				$resource_id
			),
			ARRAY_A
		);
		
		if ( ! $booking ) {
			return '<p>' . __( 'Booking not found.', 'cf7uca' ) . '</p>';
		}
		
		ob_start();
		?>
		<div class="cf7uca-booking-detail">
			<h2><?php echo esc_html( $booking['service_name'] ); ?></h2>
			<p><strong><?php _e( 'Booking Date:', 'cf7uca' ); ?></strong> <?php echo cf7uca_format_date( $booking['booking_date'] ); ?></p>
			<p><strong><?php _e( 'Duration:', 'cf7uca' ); ?></strong> <?php echo esc_html( $booking['duration'] ); ?> minutes</p>
			<p><strong><?php _e( 'Status:', 'cf7uca' ); ?></strong> <?php echo esc_html( $this->get_resource_status_label( $booking['status'] ) ); ?></p>
			
			<?php if ( $booking['notes'] ) : ?>
			<p><strong><?php _e( 'Notes:', 'cf7uca' ); ?></strong> <?php echo esc_html( $booking['notes'] ); ?></p>
			<?php endif; ?>
		</div>
		<?php
		return ob_get_clean();
	}
	
	public function get_allowed_actions( $resource_id ) {
		global $wpdb;
		
		$booking = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}bookings WHERE id = %d",
				$resource_id
			),
			ARRAY_A
		);
		
		if ( ! $booking ) {
			return array();
		}
		
		$actions = array();
		
		// Allow rescheduling if booking is confirmed and in the future
		if ( $booking['status'] === 'confirmed' && strtotime( $booking['booking_date'] ) > time() ) {
			$actions[] = 'reschedule';
			$actions[] = 'cancel';
		}
		
		return $actions;
	}
	
	public function get_resource_type() {
		return 'booking';
	}
	
	public function get_resource_type_label() {
		return __( 'Bookings', 'cf7uca' );
	}
	
	public function validate_resource_access( $resource_id, $email ) {
		global $wpdb;
		
		$booking = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}bookings WHERE id = %d AND email = %s",
				$resource_id,
				$email
			),
			ARRAY_A
		);
		
		return ! empty( $booking );
	}
	
	public function handle_resource_action( $action, $resource_id, $data = array() ) {
		switch ( $action ) {
			case 'reschedule':
				return $this->handle_reschedule( $resource_id, $data );
				
			case 'cancel':
				return $this->handle_cancellation( $resource_id );
				
			default:
				return array(
					'success' => false,
					'message' => __( 'Unknown action.', 'cf7uca' ),
				);
		}
	}
	
	public function get_resource_status( $resource ) {
		return $resource['status'];
	}
	
	public function get_resource_status_label( $status ) {
		$labels = array(
			'pending'   => __( 'Pending', 'cf7uca' ),
			'confirmed' => __( 'Confirmed', 'cf7uca' ),
			'cancelled' => __( 'Cancelled', 'cf7uca' ),
			'completed' => __( 'Completed', 'cf7uca' ),
		);
		
		return isset( $labels[ $status ] ) ? $labels[ $status ] : ucfirst( $status );
	}
	
	private function handle_reschedule( $resource_id, $data ) {
		// Implementation would depend on your booking system
		return array(
			'success' => true,
			'message' => __( 'Reschedule request submitted.', 'cf7uca' ),
		);
	}
	
	private function handle_cancellation( $resource_id ) {
		global $wpdb;
		
		$result = $wpdb->update(
			$wpdb->prefix . 'bookings',
			array( 'status' => 'cancelled' ),
			array( 'id' => $resource_id ),
			array( '%s' ),
			array( '%d' )
		);
		
		if ( $result !== false ) {
			return array(
				'success' => true,
				'message' => __( 'Booking cancelled successfully.', 'cf7uca' ),
			);
		} else {
			return array(
				'success' => false,
				'message' => __( 'Failed to cancel booking.', 'cf7uca' ),
			);
		}
	}
}

/**
 * Example 4: Automatic token generation on form submission
 */
add_action( 'wpcf7_mail_sent', function( $contact_form ) {
	$submission = WPCF7_Submission::get_instance();
	
	if ( ! $submission ) {
		return;
	}
	
	$posted_data = $submission->get_posted_data();
	
	// Check if this form should generate UCA tokens
	$form_id = $contact_form->id();
	$generate_tokens = get_post_meta( $form_id, '_cf7uca_generate_tokens', true );
	
	if ( ! $generate_tokens ) {
		return;
	}
	
	// Extract email from form data
	$email = '';
	foreach ( array( 'your-email', 'email', 'customer-email' ) as $field ) {
		if ( ! empty( $posted_data[ $field ] ) ) {
			$email = sanitize_email( $posted_data[ $field ] );
			break;
		}
	}
	
	if ( ! $email ) {
		return;
	}
	
	// Generate unified access token
	$token_id = cf7uca_create_unified_token( $email, array(
		'metadata' => array(
			'form_id'     => $form_id,
			'form_title'  => $contact_form->title(),
			'submission'  => $posted_data,
		),
	));
	
	if ( $token_id ) {
		// Token will be automatically emailed by UCA
		cf7uca_log( "UCA token generated for form submission: form_id={$form_id}, email={$email}" );
	}
});

/**
 * Example 5: Custom email template
 */
add_filter( 'cf7uca_email_template', function( $template, $template_name ) {
	if ( $template_name === 'unified_access' ) {
		return '
		<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
			<h2>Your Client Portal Access</h2>
			<p>Hello,</p>
			<p>You now have access to your client portal where you can view and manage your resources.</p>
			<p><a href="{access_url}" style="background: #0073aa; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px;">Access My Portal</a></p>
			<p>This link is secure and personalized for {email}. Do not share it with others.</p>
			<p>Best regards,<br>{site_name}</p>
		</div>';
	}
	
	return $template;
}, 10, 2 );

/**
 * Example 6: Custom resource type labels
 */
add_filter( 'cf7uca_resource_type_labels', function( $labels ) {
	$labels['booking'] = __( 'Appointments', 'cf7uca' );
	$labels['subscription'] = __( 'Memberships', 'cf7uca' );
	return $labels;
});

/**
 * Example 7: Integration with WooCommerce
 */
add_action( 'woocommerce_order_status_completed', function( $order_id ) {
	$order = wc_get_order( $order_id );
	
	if ( ! $order ) {
		return;
	}
	
	$email = $order->get_billing_email();
	
	// Generate UCA token for order access
	$token_id = cf7uca_create_unified_token( $email, array(
		'metadata' => array(
			'wc_order_id' => $order_id,
			'order_total' => $order->get_total(),
		),
	));
	
	if ( $token_id ) {
		// Add note to order
		$order->add_order_note( 'UCA access token generated for customer portal.' );
	}
});