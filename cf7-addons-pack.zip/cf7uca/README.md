# CF7 Unified Client Access (UCA)

A WordPress plugin that provides passwordless, token-based access to multiple CF7-related resources through a single entry point.

## Overview

CF7 Unified Client Access (UCA) is a central client access layer that allows users to access multiple Contact Form 7-related resources without creating WordPress user accounts. It uses secure, time-limited tokens to provide scoped access to client data.

## Key Features

- **Passwordless Access**: No WordPress accounts needed
- **Token-Based Security**: Cryptographically secure access tokens
- **Unified Access**: Single entry point for multiple resource types
- **Modular Architecture**: Extensible adapter system
- **Rate Limiting**: Built-in protection against abuse
- **HTTPS Enforcement**: Secure token transmission
- **Admin Dashboard**: Comprehensive management interface

## Core Principles

- Email-based identity only
- Token-based access only
- No persistent sessions
- Read-only by default
- Action-limited interactions
- Addons plug into UCA, not vice versa

## Supported Resource Types

UCA supports multiple resource types via adapters:

- **order** - E-commerce orders
- **booking** - Appointment bookings
- **subscription** - Recurring subscriptions
- **file** - File downloads
- **ticket** - Support tickets
- **custom** - Extensible for any resource type

## Installation

1. Upload the plugin files to `/wp-content/plugins/cf7uca/`
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Configure settings via **CF7 UCA > Settings**

## Requirements

- WordPress 6.0+
- PHP 7.4+
- Contact Form 7 plugin
- HTTPS (recommended for security)

## Configuration

### Basic Settings

1. Go to **CF7 UCA > Settings**
2. Configure the following options:
   - **Enable Unified Access**: Allow clients to access multiple resources with a single token
   - **Default Token Expiry**: How long tokens remain valid (default: 72 hours)
   - **One-Time Tokens**: Tokens can only be used once (more secure but less convenient)
   - **Access Page Slug**: URL slug for client access pages (default: "access")
   - **Require HTTPS**: Enforce HTTPS for secure token transmission
   - **Rate Limiting**: Limit access requests per time window

## How It Works

### Token Generation Flow

1. Resource is created (e.g., order, booking)
2. UCA generates secure access token
3. Token is linked to client email
4. Magic link email is sent to client
5. Client clicks link to access unified view

### Access Flow

1. Client opens magic link
2. Token is validated (expiry, usage limits, security checks)
3. Resources are loaded via registered adapters
4. Unified client view is rendered
5. Client can view details and perform allowed actions

### Security Features

- **Cryptographically Secure Tokens**: 64-character random tokens
- **Token Hashing**: Tokens stored as SHA-256 hashes
- **Expiration Enforcement**: Automatic token expiry
- **Usage Limits**: Optional one-time or limited-use tokens
- **Rate Limiting**: Protection against brute force attacks
- **HTTPS Enforcement**: Secure transmission
- **Email Validation**: Tokens tied to specific email addresses
- **Suspicious Activity Detection**: Automatic blocking of unusual patterns

## URL Structure

Access URLs follow this pattern:
```
https://yoursite.com/access/?token=abc123...
```

Resource detail URLs:
```
https://yoursite.com/access/order/123/?token=abc123...
```

## Developer Guide

### Creating Resource Adapters

Implement the `ResourceInterface` to create custom adapters:

```php
<?php
namespace MyPlugin\Adapters;

use CF7UCA\Interfaces\ResourceInterface;

class MyResourceAdapter implements ResourceInterface {
    
    public function get_resources_by_email($email) {
        // Return array of resources for this email
    }
    
    public function render_resource_summary($resource) {
        // Return HTML for resource summary
    }
    
    public function render_resource_detail($resource_id) {
        // Return HTML for detailed resource view
    }
    
    public function get_allowed_actions($resource_id) {
        // Return array of allowed actions
    }
    
    public function validate_resource_access($resource_id, $email) {
        // Return true if access is allowed
    }
    
    public function handle_resource_action($action, $resource_id, $data) {
        // Handle resource actions (retry payment, download, etc.)
    }
    
    // ... other required methods
}
```

### Registering Adapters

Register your adapter during plugin initialization:

```php
add_action('cf7uca_register_adapters', function($registry) {
    $registry->register_adapter('my_resource', 'MyPlugin\Adapters\MyResourceAdapter');
});
```

### Creating Unified Tokens

Generate tokens programmatically:

```php
$token_id = cf7uca_create_unified_token('client@example.com', array(
    'expires_at' => date('Y-m-d H:i:s', time() + (24 * HOUR_IN_SECONDS)),
    'usage_limit' => 5,
));

if ($token_id) {
    // Token created successfully
    $token_manager = new CF7UCA\Core\TokenManager();
    $raw_token = $token_manager->get_raw_token_temporarily($token_id);
    
    // Send email with magic link
    cf7uca_send_access_email('client@example.com', $raw_token);
}
```

## Hooks and Filters

### Actions

- `cf7uca_init` - Fired when UCA is initialized
- `cf7uca_token_created` - Fired when a token is created
- `cf7uca_token_status_updated` - Fired when token status changes
- `cf7uca_register_adapters` - Register custom adapters

### Filters

- `cf7uca_email_subject` - Modify email subjects
- `cf7uca_email_message` - Modify email content
- `cf7uca_email_template` - Modify email templates
- `cf7uca_resource_type_labels` - Modify resource type labels

## Database Tables

UCA creates two custom tables:

### `wp_cf7_uca_tokens`
Stores access tokens with metadata:
- `id` - Token ID
- `token_hash` - SHA-256 hash of token
- `email` - Client email address
- `access_scope` - single|unified
- `expires_at` - Expiration timestamp
- `usage_limit` - Maximum uses (NULL = unlimited)
- `usage_count` - Current usage count
- `status` - active|expired|revoked
- `metadata` - JSON metadata
- `created_at` - Creation timestamp
- `last_used_at` - Last usage timestamp

### `wp_cf7_uca_logs`
Logs access attempts and actions:
- `id` - Log ID
- `token_id` - Associated token ID
- `email` - Client email
- `action` - Action performed
- `resource_type` - Resource type accessed
- `resource_id` - Resource ID
- `ip_address` - Client IP
- `user_agent` - Client user agent
- `status` - success|failure|blocked
- `message` - Log message
- `created_at` - Log timestamp

## Admin Interface

### Dashboard
- System status overview
- Token statistics
- Adapter status
- Recent activity

### Token Management
- View all tokens
- Filter by status, scope, email
- Revoke tokens
- Extend token expiration
- Bulk operations
- Cleanup expired tokens

### Settings
- Configure security options
- Set default expiry times
- Enable/disable features
- Rate limiting settings

### Adapters
- View registered adapters
- Check adapter status
- Troubleshoot adapter issues

## Security Considerations

1. **Always use HTTPS** in production
2. **Set appropriate token expiry times** (balance security vs. convenience)
3. **Enable rate limiting** to prevent abuse
4. **Monitor access logs** for suspicious activity
5. **Regularly cleanup expired tokens**
6. **Validate all adapter implementations**
7. **Use one-time tokens** for highly sensitive resources

## Troubleshooting

### Common Issues

1. **Tokens not working**
   - Check token expiry
   - Verify HTTPS requirement
   - Check rate limiting
   - Validate email address

2. **Adapters not loading**
   - Verify adapter registration
   - Check class implementation
   - Review adapter requirements
   - Check for PHP errors

3. **Email delivery issues**
   - Configure SMTP properly
   - Check spam folders
   - Verify email templates
   - Test with different email providers

### Debug Mode

Enable debug mode in settings to log detailed information:
- Token generation and validation
- Adapter loading and execution
- Access attempts and failures
- Security events

## Performance

- Tokens are cached for quick validation
- Database queries are optimized with proper indexes
- Rate limiting prevents resource exhaustion
- Automatic cleanup removes old data

## Changelog

### 1.0.0
- Initial release
- Core UCA functionality
- Token-based access system
- Adapter architecture
- Admin interface
- Security features
- Mock adapter for testing

## License

This plugin is licensed under the GPL v2 or later.

## Support

For support and bug reports:
1. Check plugin settings and configuration
2. Review WordPress error logs
3. Enable debug mode for detailed logging
4. Check adapter implementations
5. Verify security requirements (HTTPS, etc.)

## Contributing

Contributions are welcome! Please:
1. Follow WordPress coding standards
2. Include proper documentation
3. Add security considerations
4. Test thoroughly
5. Submit pull requests with clear descriptions