/**
 * CF7 Unified Client Access - Admin JavaScript
 */

(function($) {
	'use strict';
	
	// Initialize when document is ready
	$(document).ready(function() {
		CF7UCA_Admin.init();
	});
	
	/**
	 * Admin functionality
	 */
	var CF7UCA_Admin = {
		
		/**
		 * Initialize admin
		 */
		init: function() {
			this.bindEvents();
			this.initDashboard();
			this.initTokenTable();
		},
		
		/**
		 * Bind event handlers
		 */
		bindEvents: function() {
			// Token management
			$(document).on('click', '.cf7uca-revoke-token', this.handleRevokeToken);
			$(document).on('click', '.cf7uca-extend-token', this.handleExtendToken);
			$(document).on('click', '#cf7uca-cleanup-tokens', this.handleCleanupTokens);
			
			// Settings form
			$(document).on('submit', 'form[action="options.php"]', this.handleSettingsSubmit);
			
			// Dashboard refresh
			$(document).on('click', '.cf7uca-refresh-dashboard', this.refreshDashboard);
		},
		
		/**
		 * Initialize dashboard
		 */
		initDashboard: function() {
			// Auto-refresh dashboard every 5 minutes
			if ($('.cf7uca-admin-dashboard').length) {
				setInterval(this.refreshDashboard, 300000);
			}
			
			// Initialize tooltips
			this.initTooltips();
		},
		
		/**
		 * Initialize token table
		 */
		initTokenTable: function() {
			// Add row hover effects
			$('.wp-list-table tbody tr').hover(
				function() {
					$(this).addClass('cf7uca-row-hover');
				},
				function() {
					$(this).removeClass('cf7uca-row-hover');
				}
			);
		},
		
		/**
		 * Handle revoke token
		 */
		handleRevokeToken: function(e) {
			e.preventDefault();
			
			if (!confirm(cf7uca_admin.strings.confirm_revoke)) {
				return;
			}
			
			var $link = $(this);
			var tokenId = $link.data('token-id');
			
			$link.text(cf7uca_admin.strings.processing);
			
			$.ajax({
				url: cf7uca_admin.ajax_url,
				type: 'POST',
				data: {
					action: 'cf7uca_revoke_token',
					token_id: tokenId,
					nonce: cf7uca_admin.nonce
				},
				success: function(response) {
					if (response.success) {
						CF7UCA_Admin.showNotice(response.data.message, 'success');
						
						// Update row status
						var $row = $link.closest('tr');
						$row.find('.cf7uca-status-badge')
							.removeClass('cf7uca-status-active')
							.addClass('cf7uca-status-revoked')
							.text('Revoked');
						
						// Remove action links
						$row.find('.cf7uca-revoke-token, .cf7uca-extend-token').remove();
					} else {
						CF7UCA_Admin.showNotice(response.data.message, 'error');
					}
				},
				error: function() {
					CF7UCA_Admin.showNotice(cf7uca_admin.strings.error, 'error');
				},
				complete: function() {
					$link.text('Revoke');
				}
			});
		},
		
		/**
		 * Handle extend token
		 */
		handleExtendToken: function(e) {
			e.preventDefault();
			
			var $link = $(this);
			var tokenId = $link.data('token-id');
			var hours = prompt('Extend token by how many hours?', '24');
			
			if (!hours || isNaN(hours) || hours <= 0) {
				return;
			}
			
			$link.text(cf7uca_admin.strings.processing);
			
			$.ajax({
				url: cf7uca_admin.ajax_url,
				type: 'POST',
				data: {
					action: 'cf7uca_extend_token',
					token_id: tokenId,
					hours: parseInt(hours),
					nonce: cf7uca_admin.nonce
				},
				success: function(response) {
					if (response.success) {
						CF7UCA_Admin.showNotice(response.data.message, 'success');
						
						// Refresh the page to show updated expiry
						setTimeout(function() {
							window.location.reload();
						}, 1000);
					} else {
						CF7UCA_Admin.showNotice(response.data.message, 'error');
					}
				},
				error: function() {
					CF7UCA_Admin.showNotice(cf7uca_admin.strings.error, 'error');
				},
				complete: function() {
					$link.text('Extend');
				}
			});
		},
		
		/**
		 * Handle cleanup tokens
		 */
		handleCleanupTokens: function(e) {
			e.preventDefault();
			
			if (!confirm(cf7uca_admin.strings.confirm_cleanup)) {
				return;
			}
			
			var $button = $(this);
			$button.prop('disabled', true).text(cf7uca_admin.strings.processing);
			
			$.ajax({
				url: cf7uca_admin.ajax_url,
				type: 'POST',
				data: {
					action: 'cf7uca_cleanup_tokens',
					nonce: cf7uca_admin.nonce
				},
				success: function(response) {
					if (response.success) {
						CF7UCA_Admin.showNotice(response.data.message, 'success');
						
						// Refresh the page to show updated list
						setTimeout(function() {
							window.location.reload();
						}, 1000);
					} else {
						CF7UCA_Admin.showNotice(response.data.message, 'error');
					}
				},
				error: function() {
					CF7UCA_Admin.showNotice(cf7uca_admin.strings.error, 'error');
				},
				complete: function() {
					$button.prop('disabled', false).text('Cleanup Expired Tokens');
				}
			});
		},
		
		/**
		 * Handle settings form submission
		 */
		handleSettingsSubmit: function(e) {
			var $form = $(this);
			var $submitBtn = $form.find('input[type="submit"]');
			
			// Add loading state
			$submitBtn.addClass('cf7uca-saving');
			
			// Validate settings
			if (!CF7UCA_Admin.validateSettings($form)) {
				e.preventDefault();
				$submitBtn.removeClass('cf7uca-saving');
				return false;
			}
			
			return true;
		},
		
		/**
		 * Validate settings form
		 */
		validateSettings: function($form) {
			var isValid = true;
			var errors = [];
			
			// Validate expiry hours
			var expiryHours = $form.find('input[name="cf7uca_options[default_expiry_hours]"]').val();
			if (!expiryHours || isNaN(expiryHours) || expiryHours < 1) {
				errors.push('Default expiry hours must be at least 1.');
				isValid = false;
			}
			
			// Validate access page slug
			var pageSlug = $form.find('input[name="cf7uca_options[access_page_slug]"]').val().trim();
			if (!pageSlug || !/^[a-z0-9-]+$/.test(pageSlug)) {
				errors.push('Access page slug must contain only lowercase letters, numbers, and hyphens.');
				isValid = false;
			}
			
			// Show errors if any
			if (!isValid) {
				CF7UCA_Admin.showNotice('Please fix the following errors:<br>• ' + errors.join('<br>• '), 'error');
			}
			
			return isValid;
		},
		
		/**
		 * Refresh dashboard
		 */
		refreshDashboard: function() {
			var $dashboard = $('.cf7uca-admin-dashboard');
			
			if (!$dashboard.length) {
				return;
			}
			
			$.ajax({
				url: cf7uca_admin.ajax_url,
				type: 'POST',
				data: {
					action: 'cf7uca_refresh_dashboard',
					nonce: cf7uca_admin.nonce
				},
				success: function(response) {
					if (response.success && response.data.widgets) {
						// Update each widget
						$.each(response.data.widgets, function(widgetId, html) {
							$('#' + widgetId).html(html);
						});
					}
				}
			});
		},
		
		/**
		 * Initialize tooltips
		 */
		initTooltips: function() {
			// Add tooltips to status indicators
			$('.cf7uca-status-indicator').each(function() {
				var $indicator = $(this);
				var status = $indicator.hasClass('cf7uca-status-active') ? 'Active' : 'Inactive';
				$indicator.attr('title', status);
			});
		},
		
		/**
		 * Show admin notice
		 */
		showNotice: function(message, type) {
			type = type || 'info';
			
			// Remove existing notices
			$('.cf7uca-notice').remove();
			
			// Create notice element
			var $notice = $('<div class="notice cf7uca-notice notice-' + type + ' is-dismissible"><p>' + message + '</p></div>');
			
			// Add to page
			if ($('.wrap h1').length) {
				$('.wrap h1').after($notice);
			} else {
				$('.wrap').prepend($notice);
			}
			
			// Make dismissible
			$notice.on('click', '.notice-dismiss', function() {
				$notice.fadeOut(function() {
					$(this).remove();
				});
			});
			
			// Auto-hide success notices after 5 seconds
			if (type === 'success') {
				setTimeout(function() {
					$notice.fadeOut(function() {
						$(this).remove();
					});
				}, 5000);
			}
		},
		
		/**
		 * Show loading overlay
		 */
		showLoading: function($container) {
			$container.addClass('cf7uca-loading');
		},
		
		/**
		 * Hide loading overlay
		 */
		hideLoading: function($container) {
			$container.removeClass('cf7uca-loading');
		},
		
		/**
		 * Format number with commas
		 */
		formatNumber: function(num) {
			return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
		},
		
		/**
		 * Update statistics display
		 */
		updateStatistics: function(stats) {
			$('.cf7uca-stat-number').each(function() {
				var $stat = $(this);
				var statType = $stat.data('stat-type');
				
				if (stats[statType] !== undefined) {
					$stat.text(CF7UCA_Admin.formatNumber(stats[statType]));
				}
			});
		},
		
		/**
		 * Handle bulk actions
		 */
		handleBulkAction: function(action, selectedItems) {
			switch (action) {
				case 'revoke':
					if (confirm('Are you sure you want to revoke the selected tokens?')) {
						CF7UCA_Admin.bulkRevokeTokens(selectedItems);
					}
					break;
					
				case 'extend':
					var hours = prompt('Extend selected tokens by how many hours?', '24');
					if (hours && !isNaN(hours) && hours > 0) {
						CF7UCA_Admin.bulkExtendTokens(selectedItems, parseInt(hours));
					}
					break;
			}
		},
		
		/**
		 * Bulk revoke tokens
		 */
		bulkRevokeTokens: function(tokenIds) {
			$.ajax({
				url: cf7uca_admin.ajax_url,
				type: 'POST',
				data: {
					action: 'cf7uca_bulk_revoke_tokens',
					token_ids: tokenIds,
					nonce: cf7uca_admin.nonce
				},
				success: function(response) {
					if (response.success) {
						CF7UCA_Admin.showNotice(response.data.message, 'success');
						window.location.reload();
					} else {
						CF7UCA_Admin.showNotice(response.data.message, 'error');
					}
				},
				error: function() {
					CF7UCA_Admin.showNotice(cf7uca_admin.strings.error, 'error');
				}
			});
		},
		
		/**
		 * Bulk extend tokens
		 */
		bulkExtendTokens: function(tokenIds, hours) {
			$.ajax({
				url: cf7uca_admin.ajax_url,
				type: 'POST',
				data: {
					action: 'cf7uca_bulk_extend_tokens',
					token_ids: tokenIds,
					hours: hours,
					nonce: cf7uca_admin.nonce
				},
				success: function(response) {
					if (response.success) {
						CF7UCA_Admin.showNotice(response.data.message, 'success');
						window.location.reload();
					} else {
						CF7UCA_Admin.showNotice(response.data.message, 'error');
					}
				},
				error: function() {
					CF7UCA_Admin.showNotice(cf7uca_admin.strings.error, 'error');
				}
			});
		}
	};
	
	// Settings saved notice
	$(document).ready(function() {
		if (window.location.search.indexOf('settings-updated=true') !== -1) {
			CF7UCA_Admin.showNotice(cf7uca_admin.strings.success, 'success');
		}
	});
	
	// Expose to global scope for external access
	window.CF7UCA_Admin = CF7UCA_Admin;
	
})(jQuery);