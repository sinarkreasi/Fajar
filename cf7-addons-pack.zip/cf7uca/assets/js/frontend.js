/**
 * CF7 Unified Client Access - Frontend JavaScript
 */

(function($) {
	'use strict';
	
	// Initialize when document is ready
	$(document).ready(function() {
		CF7UCA_Frontend.init();
	});
	
	/**
	 * Frontend functionality
	 */
	var CF7UCA_Frontend = {
		
		/**
		 * Initialize frontend
		 */
		init: function() {
			this.bindEvents();
			this.initAccessForm();
			this.initResourceActions();
		},
		
		/**
		 * Bind event handlers
		 */
		bindEvents: function() {
			// Resource action buttons
			$(document).on('click', '.cf7uca-action-btn', this.handleResourceAction);
			
			// Access form submission
			$(document).on('submit', '.cf7uca-token-form', this.handleAccessForm);
			
			// Auto-refresh for pending resources
			this.initAutoRefresh();
		},
		
		/**
		 * Initialize access form
		 */
		initAccessForm: function() {
			// Auto-focus on token input
			$('.cf7uca-token-input').focus();
			
			// Format token input (remove spaces, convert to lowercase)
			$('.cf7uca-token-input').on('input', function() {
				var value = $(this).val().replace(/\s+/g, '').toLowerCase();
				$(this).val(value);
			});
		},
		
		/**
		 * Initialize resource actions
		 */
		initResourceActions: function() {
			// Add loading states to action buttons
			$('.cf7uca-action-btn').each(function() {
				var $btn = $(this);
				var action = $btn.data('action');
				
				// Add icons based on action type
				CF7UCA_Frontend.addActionIcon($btn, action);
			});
		},
		
		/**
		 * Handle resource action
		 */
		handleResourceAction: function(e) {
			e.preventDefault();
			
			var $button = $(this);
			var action = $button.data('action');
			var resourceId = $button.data('resource-id');
			var resourceType = $button.data('resource-type');
			var token = CF7UCA_Frontend.getCurrentToken();
			
			// Confirm destructive actions
			if (CF7UCA_Frontend.isDestructiveAction(action)) {
				if (!confirm(cf7uca_ajax.strings.confirm_action)) {
					return;
				}
			}
			
			// Show loading state
			CF7UCA_Frontend.setButtonLoading($button, true);
			
			// Make AJAX request
			$.ajax({
				url: cf7uca_ajax.ajax_url,
				type: 'POST',
				data: {
					action: 'cf7uca_resource_action',
					resource_type: resourceType,
					resource_id: resourceId,
					action: action,
					token: token,
					nonce: cf7uca_ajax.nonce
				},
				success: function(response) {
					if (response.success) {
						CF7UCA_Frontend.handleActionSuccess(action, response.data, $button);
					} else {
						CF7UCA_Frontend.showMessage(response.data.message, 'error');
					}
				},
				error: function() {
					CF7UCA_Frontend.showMessage(cf7uca_ajax.strings.error, 'error');
				},
				complete: function() {
					CF7UCA_Frontend.setButtonLoading($button, false);
				}
			});
		},
		
		/**
		 * Handle access form submission
		 */
		handleAccessForm: function(e) {
			var $form = $(this);
			var $submitBtn = $form.find('.cf7uca-access-btn');
			var token = $form.find('.cf7uca-token-input').val().trim();
			
			if (!token) {
				e.preventDefault();
				CF7UCA_Frontend.showMessage('Please enter your access token.', 'error');
				return;
			}
			
			// Show loading state
			$submitBtn.prop('disabled', true).addClass('cf7uca-loading');
		},
		
		/**
		 * Handle action success
		 */
		handleActionSuccess: function(action, data, $button) {
			switch (action) {
				case 'retry_payment':
					if (data.payment_url) {
						CF7UCA_Frontend.showMessage('Redirecting to payment...', 'success');
						setTimeout(function() {
							window.location.href = data.payment_url;
						}, 1000);
					}
					break;
					
				case 'download_invoice':
					if (data.download_url) {
						// Open download in new window
						window.open(data.download_url, '_blank');
						CF7UCA_Frontend.showMessage('Download started.', 'success');
					}
					break;
					
				case 'cancel_order':
					// Update UI to reflect cancelled status
					CF7UCA_Frontend.updateResourceStatus($button, 'cancelled');
					CF7UCA_Frontend.showMessage(data.message, 'success');
					break;
					
				case 'request_refund':
					// Disable refund button after request
					$button.prop('disabled', true).text('Refund Requested');
					CF7UCA_Frontend.showMessage(data.message, 'success');
					break;
					
				default:
					CF7UCA_Frontend.showMessage(data.message || 'Action completed successfully.', 'success');
			}
		},
		
		/**
		 * Initialize auto-refresh for pending resources
		 */
		initAutoRefresh: function() {
			var $pendingResources = $('.cf7uca-status-pending').closest('.cf7uca-resource-item');
			
			if ($pendingResources.length > 0) {
				// Refresh every 30 seconds
				setInterval(function() {
					CF7UCA_Frontend.refreshResourceStatuses();
				}, 30000);
			}
		},
		
		/**
		 * Refresh resource statuses
		 */
		refreshResourceStatuses: function() {
			var token = CF7UCA_Frontend.getCurrentToken();
			
			if (!token) {
				return;
			}
			
			// This would typically make an AJAX call to check for status updates
			// For now, we'll just log that we're checking
			console.log('Checking for resource status updates...');
		},
		
		/**
		 * Update resource status in UI
		 */
		updateResourceStatus: function($button, newStatus) {
			var $resourceItem = $button.closest('.cf7uca-resource-item');
			var $statusElement = $resourceItem.find('.cf7uca-resource-status');
			
			// Update status class and text
			$statusElement
				.removeClass(function(index, className) {
					return (className.match(/(^|\s)cf7uca-status-\S+/g) || []).join(' ');
				})
				.addClass('cf7uca-status-' + newStatus)
				.text(CF7UCA_Frontend.getStatusLabel(newStatus));
			
			// Update available actions
			CF7UCA_Frontend.updateResourceActions($resourceItem, newStatus);
		},
		
		/**
		 * Update resource actions based on status
		 */
		updateResourceActions: function($resourceItem, status) {
			var $actionsContainer = $resourceItem.find('.cf7uca-resource-actions');
			
			// Hide all action buttons first
			$actionsContainer.find('.cf7uca-action-btn').hide();
			
			// Show relevant actions based on status
			switch (status) {
				case 'pending':
					$actionsContainer.find('.cf7uca-action-retry_payment, .cf7uca-action-cancel_order').show();
					break;
				case 'completed':
					$actionsContainer.find('.cf7uca-action-download_invoice, .cf7uca-action-request_refund').show();
					break;
				case 'cancelled':
					// No actions available for cancelled orders
					break;
			}
		},
		
		/**
		 * Get current token from URL
		 */
		getCurrentToken: function() {
			var urlParams = new URLSearchParams(window.location.search);
			return urlParams.get('token') || '';
		},
		
		/**
		 * Check if action is destructive
		 */
		isDestructiveAction: function(action) {
			var destructiveActions = ['cancel_order', 'request_refund'];
			return destructiveActions.indexOf(action) !== -1;
		},
		
		/**
		 * Set button loading state
		 */
		setButtonLoading: function($button, loading) {
			if (loading) {
				$button.prop('disabled', true)
					   .addClass('cf7uca-loading')
					   .data('original-text', $button.text())
					   .text(cf7uca_ajax.strings.processing);
			} else {
				$button.prop('disabled', false)
					   .removeClass('cf7uca-loading')
					   .text($button.data('original-text') || $button.text());
			}
		},
		
		/**
		 * Add action icon to button
		 */
		addActionIcon: function($button, action) {
			var icons = {
				'retry_payment': '🔄',
				'cancel_order': '❌',
				'download_invoice': '📄',
				'request_refund': '💰'
			};
			
			if (icons[action]) {
				var currentText = $button.text();
				$button.html(icons[action] + ' ' + currentText);
			}
		},
		
		/**
		 * Get status label
		 */
		getStatusLabel: function(status) {
			var labels = {
				'pending': 'Pending',
				'completed': 'Completed',
				'cancelled': 'Cancelled',
				'refunded': 'Refunded'
			};
			
			return labels[status] || status.charAt(0).toUpperCase() + status.slice(1);
		},
		
		/**
		 * Show message to user
		 */
		showMessage: function(message, type) {
			type = type || 'info';
			
			// Remove existing messages
			$('.cf7uca-message').remove();
			
			// Create message element
			var $message = $('<div class="cf7uca-message cf7uca-message-' + type + '">' + message + '</div>');
			
			// Add styles
			$message.css({
				'position': 'fixed',
				'top': '20px',
				'right': '20px',
				'padding': '15px 20px',
				'border-radius': '6px',
				'color': '#fff',
				'font-weight': '500',
				'z-index': '9999',
				'max-width': '400px',
				'box-shadow': '0 4px 6px rgba(0,0,0,0.1)'
			});
			
			// Set background color based on type
			switch (type) {
				case 'success':
					$message.css('background', '#28a745');
					break;
				case 'error':
					$message.css('background', '#dc3545');
					break;
				case 'warning':
					$message.css('background', '#ffc107');
					$message.css('color', '#212529');
					break;
				default:
					$message.css('background', '#17a2b8');
			}
			
			// Add to page
			$('body').append($message);
			
			// Auto-hide after 5 seconds
			setTimeout(function() {
				$message.fadeOut(function() {
					$(this).remove();
				});
			}, 5000);
		},
		
		/**
		 * Format currency amount
		 */
		formatCurrency: function(amount) {
			return '$' + parseFloat(amount).toFixed(2);
		},
		
		/**
		 * Copy text to clipboard
		 */
		copyToClipboard: function(text) {
			if (navigator.clipboard) {
				navigator.clipboard.writeText(text).then(function() {
					CF7UCA_Frontend.showMessage('Copied to clipboard!', 'success');
				});
			} else {
				// Fallback for older browsers
				var $temp = $('<input>');
				$('body').append($temp);
				$temp.val(text).select();
				document.execCommand('copy');
				$temp.remove();
				
				CF7UCA_Frontend.showMessage('Copied to clipboard!', 'success');
			}
		}
	};
	
	// Expose to global scope for external access
	window.CF7UCA_Frontend = CF7UCA_Frontend;
	
})(jQuery);