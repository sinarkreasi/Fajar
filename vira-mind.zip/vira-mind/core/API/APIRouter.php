<?php

declare(strict_types=1);

namespace ViraMind\Core\API;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * API Router - REST API endpoint management
 */
class APIRouter
{
    private string $namespace = 'vrmind/v1';
    private array $routes = [];

    /**
     * Register routes
     */
    public function register(): void
    {
        add_action('rest_api_init', [$this, 'registerRoutes']);
    }

    /**
     * Register all routes
     */
    public function registerRoutes(): void
    {
        // AI endpoints
        $this->registerRoute('/ai/query', 'POST', 'AIController@query', ['vrmind_use_ai']);
        $this->registerRoute('/ai/models', 'GET', 'AIController@models', ['vrmind_use_ai']);
        
        // Queue endpoints
        $this->registerRoute('/queue/jobs', 'GET', 'QueueController@list', ['vrmind_manage_queue']);
        $this->registerRoute('/queue/process', 'POST', 'QueueController@process', ['vrmind_manage_queue']);
        
        // Integration endpoints
        $this->registerRoute('/integrations', 'GET', 'IntegrationController@list', ['vrmind_manage_integrations']);
        
        // Addon endpoints
        $this->registerRoute('/addons', 'GET', 'AddonController@list', ['vrmind_manage_addons']);
        $this->registerRoute('/addons/upload', 'POST', 'AddonController@upload', ['vrmind_manage_addons']);
    }

    /**
     * Register single route
     */
    private function registerRoute(string $route, string $method, string $handler, array $capabilities = []): void
    {
        list($controller, $action) = explode('@', $handler);
        $controllerClass = "ViraMind\\Core\\API\\Controllers\\{$controller}";

        register_rest_route($this->namespace, $route, [
            'methods' => $method,
            'callback' => function(\WP_REST_Request $request) use ($controllerClass, $action) {
                if (!class_exists($controllerClass)) {
                    return $this->errorResponse('VRMIND_ERR_1003', 'Controller not found', 500);
                }

                $controller = new $controllerClass();
                return $controller->$action($request);
            },
            'permission_callback' => function() use ($capabilities) {
                return $this->checkPermissions($capabilities);
            }
        ]);

        $this->routes[] = [
            'route' => $route,
            'method' => $method,
            'handler' => $handler,
            'capabilities' => $capabilities
        ];
    }

    /**
     * Check permissions
     */
    private function checkPermissions(array $capabilities): bool
    {
        if (empty($capabilities)) {
            return true;
        }

        foreach ($capabilities as $cap) {
            if (current_user_can($cap)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Success response
     */
    public static function successResponse(mixed $data, int $status = 200): \WP_REST_Response
    {
        return new \WP_REST_Response([
            'success' => true,
            'data' => $data
        ], $status);
    }

    /**
     * Error response
     */
    public static function errorResponse(string $code, string $message, int $status = 400): \WP_REST_Response
    {
        return new \WP_REST_Response([
            'success' => false,
            'error' => [
                'code' => $code,
                'message' => $message
            ]
        ], $status);
    }

    /**
     * Get registered routes
     */
    public function getRoutes(): array
    {
        return $this->routes;
    }
}
