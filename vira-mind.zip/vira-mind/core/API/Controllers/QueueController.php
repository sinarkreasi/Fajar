<?php

declare(strict_types=1);

namespace ViraMind\Core\API\Controllers;

use ViraMind\Core\API\APIRouter;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Queue Controller - API endpoints for queue management
 */
class QueueController
{
    /**
     * List queue jobs
     */
    public function list(\WP_REST_Request $request): \WP_REST_Response
    {
        $queueDir = VRMIND_PATH . 'storage/queue/';
        $files = glob($queueDir . '*.json');
        $jobs = [];

        foreach ($files as $file) {
            $data = json_decode(file_get_contents($file), true);
            $jobs[] = [
                'id' => $data['id'] ?? 'unknown',
                'attempts' => $data['attempts'] ?? 0,
                'created_at' => $data['created_at'] ?? 0
            ];
        }

        return APIRouter::successResponse($jobs);
    }

    /**
     * Process queue
     */
    public function process(\WP_REST_Request $request): \WP_REST_Response
    {
        $limit = (int) $request->get_param('limit') ?? 10;

        try {
            \ViraMind\vrmind()->make('queue')->process($limit);
            
            return APIRouter::successResponse([
                'message' => 'Queue processed',
                'processed' => $limit
            ]);
        } catch (\Exception $e) {
            return APIRouter::errorResponse('VRMIND_ERR_1004', $e->getMessage(), 500);
        }
    }
}
