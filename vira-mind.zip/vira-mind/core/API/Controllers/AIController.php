<?php

declare(strict_types=1);

namespace ViraMind\Core\API\Controllers;

use ViraMind\Core\API\APIRouter;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * AI Controller - API endpoints for AI operations
 */
class AIController
{
    /**
     * Query AI
     */
    public function query(\WP_REST_Request $request): \WP_REST_Response
    {
        $prompt = sanitize_text_field($request->get_param('prompt'));
        $options = $request->get_param('options') ?? [];

        if (empty($prompt)) {
            return APIRouter::errorResponse('VRMIND_ERR_1002', 'Prompt is required', 400);
        }

        try {
            $response = \ViraMind\vrmind_ai($prompt, $options);
            
            return APIRouter::successResponse([
                'content' => $response,
                'cached' => false
            ]);
        } catch (\Exception $e) {
            return APIRouter::errorResponse('VRMIND_ERR_1004', $e->getMessage(), 500);
        }
    }

    /**
     * Get available models
     */
    public function models(\WP_REST_Request $request): \WP_REST_Response
    {
        $registry = new \ViraMind\Core\AI\ModelRegistry();
        $models = $registry->all();

        return APIRouter::successResponse($models);
    }
}
