<?php

declare(strict_types=1);

namespace ViraMind\Core\API;

use ViraMind\Core\Container\ServiceProvider;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * API Service Provider
 */
class APIServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->singleton('api.router', fn() => new APIRouter());
    }

    public function boot(): void
    {
        $this->app->make('api.router')->register();
    }
}
