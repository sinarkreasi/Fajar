<?php

declare(strict_types=1);

namespace ViraMind\Core\Permissions;

use ViraMind\Core\Container\ServiceProvider;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Permissions Service Provider
 */
class PermissionsServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->singleton('permissions', fn() => new Capabilities());
    }

    public function boot(): void
    {
        $this->app->make('permissions')->register();
    }
}
