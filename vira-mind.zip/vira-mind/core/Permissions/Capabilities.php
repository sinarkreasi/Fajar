<?php

declare(strict_types=1);

namespace ViraMind\Core\Permissions;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Capabilities - Permission system for Vira Mind
 */
class Capabilities
{
    private array $capabilities = [
        'vrmind_manage_core' => 'Manage Vira Mind Core',
        'vrmind_manage_ai' => 'Manage AI Engine',
        'vrmind_manage_queue' => 'Manage Queue',
        'vrmind_manage_integrations' => 'Manage Integrations',
        'vrmind_manage_addons' => 'Manage Addons',
        'vrmind_use_ai' => 'Use AI Features',
        'vrmind_view_logs' => 'View Logs',
    ];

    /**
     * Register capabilities
     */
    public function register(): void
    {
        add_action('admin_init', [$this, 'addCapabilities']);
    }

    /**
     * Add capabilities to roles
     */
    public function addCapabilities(): void
    {
        $admin = get_role('administrator');
        $editor = get_role('editor');
        $author = get_role('author');

        if ($admin) {
            foreach ($this->capabilities as $cap => $label) {
                $admin->add_cap($cap);
            }
        }

        if ($editor) {
            $editor->add_cap('vrmind_use_ai');
            $editor->add_cap('vrmind_manage_ai');
        }

        if ($author) {
            $author->add_cap('vrmind_use_ai');
        }
    }

    /**
     * Remove capabilities
     */
    public function removeCapabilities(): void
    {
        $roles = ['administrator', 'editor', 'author', 'contributor'];

        foreach ($roles as $roleName) {
            $role = get_role($roleName);
            if ($role) {
                foreach ($this->capabilities as $cap => $label) {
                    $role->remove_cap($cap);
                }
            }
        }
    }

    /**
     * Check if user has capability
     */
    public static function userCan(string $capability): bool
    {
        return current_user_can($capability);
    }

    /**
     * Get all capabilities
     */
    public function getCapabilities(): array
    {
        return $this->capabilities;
    }
}
