<?php

declare(strict_types=1);

namespace ViraMind\Core\Events;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Event Dispatcher
 */
class EventDispatcher
{
    private array $listeners = [];

    public function listen(string $event, callable $listener): void
    {
        $this->listeners[$event][] = $listener;
    }

    public function dispatch(Event|string $event, array $payload = []): void
    {
        $eventName = is_string($event) ? $event : get_class($event);
        
        if (!isset($this->listeners[$eventName])) {
            return;
        }

        foreach ($this->listeners[$eventName] as $listener) {
            call_user_func($listener, $event, $payload);
        }
    }

    public function forget(string $event): void
    {
        unset($this->listeners[$event]);
    }
}
