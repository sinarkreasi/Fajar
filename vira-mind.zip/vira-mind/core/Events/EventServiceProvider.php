<?php

declare(strict_types=1);

namespace ViraMind\Core\Events;

use ViraMind\Core\Container\ServiceProvider;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Event Service Provider
 */
class EventServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->singleton('events', fn() => new EventDispatcher());
    }
}
