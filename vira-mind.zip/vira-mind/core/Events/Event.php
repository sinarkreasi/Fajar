<?php

declare(strict_types=1);

namespace ViraMind\Core\Events;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Base Event class
 */
abstract class Event
{
    public function __construct(
        public readonly array $data = []
    ) {}
}
