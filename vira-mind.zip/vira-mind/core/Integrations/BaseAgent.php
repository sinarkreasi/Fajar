<?php

declare(strict_types=1);

namespace ViraMind\Core\Integrations;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Base Agent - AI logic for integrations
 */
abstract class BaseAgent
{
    protected string $systemPrompt;
    protected array $context = [];

    /**
     * Build AI prompt
     */
    protected function buildPrompt(string $userContent, array $additionalContext = []): string
    {
        $context = array_merge($this->context, $additionalContext);
        
        $prompt = $this->systemPrompt . "\n\n";
        
        if (!empty($context)) {
            $prompt .= "Context:\n";
            foreach ($context as $key => $value) {
                $prompt .= "- {$key}: {$value}\n";
            }
            $prompt .= "\n";
        }
        
        $prompt .= "User Request:\n{$userContent}\n\n";
        $prompt .= "Return:\n1. main_output\n2. recommended_actions\n3. metadata";
        
        return $prompt;
    }

    /**
     * Execute AI request
     */
    protected function execute(string $prompt, array $options = []): array
    {
        try {
            $response = \ViraMind\vrmind_ai($prompt, $options);
            return $this->parseResponse($response);
        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage(),
                'main_output' => '',
                'recommended_actions' => [],
                'metadata' => []
            ];
        }
    }

    /**
     * Parse AI response
     */
    protected function parseResponse(string $response): array
    {
        // Basic parsing - can be enhanced
        return [
            'success' => true,
            'main_output' => $response,
            'recommended_actions' => [],
            'metadata' => [
                'timestamp' => current_time('mysql'),
                'model' => 'default'
            ]
        ];
    }

    /**
     * Set context
     */
    public function setContext(array $context): void
    {
        $this->context = $context;
    }

    /**
     * Add context item
     */
    public function addContext(string $key, mixed $value): void
    {
        $this->context[$key] = $value;
    }
}
