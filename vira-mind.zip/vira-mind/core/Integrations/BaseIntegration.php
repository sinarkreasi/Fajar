<?php

declare(strict_types=1);

namespace ViraMind\Core\Integrations;

use ViraMind\Core\Container\Container;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Base Integration - All integrations must extend this
 */
abstract class BaseIntegration
{
    protected Container $container;
    protected string $slug;
    protected string $name;
    protected string $pluginFile;
    protected string $basePath;

    public function __construct(Container $container)
    {
        $this->container = $container;
        $this->basePath = $this->getBasePath();
    }

    /**
     * Check if plugin is active
     */
    public function isPluginActive(): bool
    {
        if (empty($this->pluginFile)) {
            return false;
        }

        include_once ABSPATH . 'wp-admin/includes/plugin.php';
        return is_plugin_active($this->pluginFile);
    }

    /**
     * Register integration
     */
    abstract public function register(): void;

    /**
     * Get integration slug
     */
    public function getSlug(): string
    {
        return $this->slug;
    }

    /**
     * Get integration name
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * Get base path
     */
    protected function getBasePath(): string
    {
        $reflection = new \ReflectionClass($this);
        return dirname($reflection->getFileName());
    }

    /**
     * Load hooks
     */
    protected function loadHooks(): void
    {
        $hooksFile = $this->basePath . '/Hooks/' . str_replace('-', '', ucwords($this->slug, '-')) . 'Hooks.php';
        
        if (file_exists($hooksFile)) {
            require_once $hooksFile;
            
            $hooksClass = get_class($this) . '\\Hooks\\' . str_replace('-', '', ucwords($this->slug, '-')) . 'Hooks';
            if (class_exists($hooksClass)) {
                new $hooksClass($this->container);
            }
        }
    }

    /**
     * Register admin menu
     */
    protected function registerAdminMenu(string $title, callable $callback): void
    {
        add_submenu_page(
            'vira-mind',
            $title,
            $title,
            'manage_options',
            'vira-mind-' . $this->slug,
            $callback
        );
    }

    /**
     * Enqueue assets
     */
    protected function enqueueAssets(): void
    {
        $scriptsPath = $this->basePath . '/Assets/scripts/';
        $stylesPath = $this->basePath . '/Assets/styles/';
        
        if (is_dir($scriptsPath)) {
            $scripts = glob($scriptsPath . '*.js');
            foreach ($scripts as $script) {
                $handle = 'vrmind-' . $this->slug . '-' . basename($script, '.js');
                wp_enqueue_script(
                    $handle,
                    plugins_url('integrations/' . $this->slug . '/Assets/scripts/' . basename($script), VRMIND_FILE),
                    ['jquery'],
                    filemtime($script),
                    true
                );
            }
        }

        if (is_dir($stylesPath)) {
            $styles = glob($stylesPath . '*.css');
            foreach ($styles as $style) {
                $handle = 'vrmind-' . $this->slug . '-' . basename($style, '.css');
                wp_enqueue_style(
                    $handle,
                    plugins_url('integrations/' . $this->slug . '/Assets/styles/' . basename($style), VRMIND_FILE),
                    [],
                    filemtime($style)
                );
            }
        }
    }

    /**
     * Log integration activity
     */
    protected function log(string $message, string $level = 'info', array $context = []): void
    {
        $logFile = VRMIND_PATH . 'storage/logs/integrations/' . $this->slug . '-' . current_time('Y-m-d') . '.log';
        
        $logDir = dirname($logFile);
        if (!is_dir($logDir)) {
            wp_mkdir_p($logDir);
        }

        $timestamp = current_time('Y-m-d H:i:s');
        $contextStr = !empty($context) ? json_encode($context) : '';
        $logMessage = sprintf("[%s] %s: %s %s\n", $timestamp, strtoupper($level), $message, $contextStr);
        
        file_put_contents($logFile, $logMessage, FILE_APPEND);
    }
}
