<?php

declare(strict_types=1);

namespace ViraMind\Core\Integrations;

use ViraMind\Core\Container\Container;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Integration Manager - Manages third-party plugin integrations
 */
class IntegrationManager
{
    private Container $container;
    private array $integrations = [];
    private string $integrationsPath;

    public function __construct(Container $container)
    {
        $this->container = $container;
        $this->integrationsPath = VRMIND_PATH . 'integrations/';
    }

    /**
     * Discover integrations
     */
    public function discover(): void
    {
        if (!is_dir($this->integrationsPath)) {
            wp_mkdir_p($this->integrationsPath);
            return;
        }

        $directories = glob($this->integrationsPath . '*', GLOB_ONLYDIR);
        
        foreach ($directories as $dir) {
            $slug = basename($dir);
            $integrationFile = $dir . '/' . $this->getIntegrationClassName($slug) . '.php';
            
            if (file_exists($integrationFile)) {
                $this->registerIntegration($slug, $dir);
            }
        }

        do_action('vrmind_integrations_discovered', $this->integrations);
    }

    /**
     * Register integration
     */
    private function registerIntegration(string $slug, string $path): void
    {
        $className = $this->getIntegrationClassName($slug);
        $fullClass = "ViraMind\\Integrations\\" . str_replace('-', '', ucwords($slug, '-')) . "\\{$className}";
        
        if (!class_exists($fullClass)) {
            require_once $path . '/' . $className . '.php';
        }

        if (class_exists($fullClass)) {
            $integration = new $fullClass($this->container);
            
            // Check if dependency plugin is active
            if ($integration->isPluginActive()) {
                $integration->register();
                $this->integrations[$slug] = $integration;
                
                do_action('vrmind_integration_loaded', $slug, $integration);
            }
        }
    }

    /**
     * Get integration class name
     */
    private function getIntegrationClassName(string $slug): string
    {
        return str_replace('-', '', ucwords($slug, '-')) . 'Integration';
    }

    /**
     * Get all integrations
     */
    public function getIntegrations(): array
    {
        return $this->integrations;
    }

    /**
     * Get integration by slug
     */
    public function getIntegration(string $slug): ?object
    {
        return $this->integrations[$slug] ?? null;
    }

    /**
     * Check if integration is loaded
     */
    public function hasIntegration(string $slug): bool
    {
        return isset($this->integrations[$slug]);
    }
}
