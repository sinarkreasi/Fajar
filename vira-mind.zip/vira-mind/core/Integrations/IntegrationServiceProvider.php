<?php

declare(strict_types=1);

namespace ViraMind\Core\Integrations;

use ViraMind\Core\Container\ServiceProvider;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Integration Service Provider
 */
class IntegrationServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->singleton('integration.manager', fn() => new IntegrationManager($this->app));
    }

    public function boot(): void
    {
        $manager = $this->app->make('integration.manager');
        $manager->discover();
    }
}
