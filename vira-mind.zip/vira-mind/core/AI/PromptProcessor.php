<?php

declare(strict_types=1);

namespace ViraMind\Core\AI;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Prompt Processor - Handles prompt templates and validation
 */
class PromptProcessor
{
    private array $templates = [];
    private array $blockedPatterns = [
        '/ignore\s+previous\s+instructions/i',
        '/system\s+prompt/i',
        '/you\s+are\s+now/i',
        '/<script/i',
        '/<iframe/i',
    ];

    /**
     * Register template
     */
    public function registerTemplate(string $name, string $template): void
    {
        $this->templates[$name] = $template;
    }

    /**
     * Process prompt with template
     */
    public function process(string $prompt, array $variables = [], string $template = null): string
    {
        // Validate prompt
        if (!$this->validate($prompt)) {
            throw new \Exception('Invalid prompt detected');
        }

        // Apply template if provided
        if ($template && isset($this->templates[$template])) {
            $prompt = $this->applyTemplate($this->templates[$template], $prompt, $variables);
        }

        // Replace variables
        $prompt = $this->replaceVariables($prompt, $variables);

        return $this->sanitize($prompt);
    }

    /**
     * Apply template
     */
    private function applyTemplate(string $template, string $prompt, array $variables): string
    {
        $variables['prompt'] = $prompt;
        return $this->replaceVariables($template, $variables);
    }

    /**
     * Replace variables in prompt
     */
    private function replaceVariables(string $text, array $variables): string
    {
        foreach ($variables as $key => $value) {
            $text = str_replace('{{' . $key . '}}', $value, $text);
        }
        return $text;
    }

    /**
     * Validate prompt for injection attempts
     */
    public function validate(string $prompt): bool
    {
        foreach ($this->blockedPatterns as $pattern) {
            if (preg_match($pattern, $prompt)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Sanitize prompt
     */
    private function sanitize(string $prompt): string
    {
        return wp_kses_post(trim($prompt));
    }

    /**
     * Build structured payload
     */
    public function buildPayload(string $prompt, array $options = []): array
    {
        return [
            'prompt' => $prompt,
            'model' => $options['model'] ?? 'gpt-4',
            'temperature' => $options['temperature'] ?? 0.7,
            'max_tokens' => $options['max_tokens'] ?? 2000,
            'top_p' => $options['top_p'] ?? 1.0,
            'frequency_penalty' => $options['frequency_penalty'] ?? 0,
            'presence_penalty' => $options['presence_penalty'] ?? 0,
        ];
    }
}
