<?php

declare(strict_types=1);

namespace ViraMind\Core\AI;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Model Registry - Manages available AI models and their capabilities
 */
class ModelRegistry
{
    private array $models = [];

    public function __construct()
    {
        $this->registerDefaultModels();
    }

    /**
     * Register default models
     */
    private function registerDefaultModels(): void
    {
        $this->register('gpt-4', [
            'provider' => 'openai',
            'context_size' => 8192,
            'cost_per_1k_tokens' => 0.03,
            'speed' => 'medium',
            'best_for' => ['complex reasoning', 'long content', 'analysis'],
            'capabilities' => ['text', 'code', 'reasoning']
        ]);

        $this->register('gpt-4-turbo', [
            'provider' => 'openai',
            'context_size' => 128000,
            'cost_per_1k_tokens' => 0.01,
            'speed' => 'fast',
            'best_for' => ['large documents', 'fast responses'],
            'capabilities' => ['text', 'code', 'vision', 'reasoning']
        ]);

        $this->register('gpt-3.5-turbo', [
            'provider' => 'openai',
            'context_size' => 16385,
            'cost_per_1k_tokens' => 0.001,
            'speed' => 'very fast',
            'best_for' => ['quick tasks', 'simple content'],
            'capabilities' => ['text', 'code']
        ]);
    }

    /**
     * Register a model
     */
    public function register(string $modelId, array $metadata): void
    {
        $this->models[$modelId] = array_merge([
            'id' => $modelId,
            'provider' => 'unknown',
            'context_size' => 4096,
            'cost_per_1k_tokens' => 0,
            'speed' => 'medium',
            'best_for' => [],
            'capabilities' => []
        ], $metadata);
    }

    /**
     * Get model metadata
     */
    public function get(string $modelId): ?array
    {
        return $this->models[$modelId] ?? null;
    }

    /**
     * Get all models
     */
    public function all(): array
    {
        return $this->models;
    }

    /**
     * Get models by provider
     */
    public function getByProvider(string $provider): array
    {
        return array_filter($this->models, fn($model) => $model['provider'] === $provider);
    }

    /**
     * Get models by capability
     */
    public function getByCapability(string $capability): array
    {
        return array_filter($this->models, fn($model) => in_array($capability, $model['capabilities']));
    }

    /**
     * Find best model for task
     */
    public function findBestFor(string $task, array $constraints = []): ?string
    {
        $candidates = [];

        foreach ($this->models as $modelId => $model) {
            if (in_array($task, $model['best_for'])) {
                $score = 0;

                // Check constraints
                if (isset($constraints['max_cost']) && $model['cost_per_1k_tokens'] <= $constraints['max_cost']) {
                    $score += 10;
                }

                if (isset($constraints['min_context']) && $model['context_size'] >= $constraints['min_context']) {
                    $score += 10;
                }

                if (isset($constraints['speed']) && $model['speed'] === $constraints['speed']) {
                    $score += 5;
                }

                $candidates[$modelId] = $score;
            }
        }

        if (empty($candidates)) {
            return null;
        }

        arsort($candidates);
        return array_key_first($candidates);
    }
}
