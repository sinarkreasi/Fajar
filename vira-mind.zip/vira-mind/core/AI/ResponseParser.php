<?php

declare(strict_types=1);

namespace ViraMind\Core\AI;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Response Parser - Parses and validates AI responses
 */
class ResponseParser
{
    /**
     * Parse response to structured array
     */
    public function parse(string $response, string $format = 'text'): array
    {
        $parsed = [
            'success' => true,
            'content' => '',
            'metadata' => [],
            'errors' => []
        ];

        try {
            switch ($format) {
                case 'json':
                    $parsed = $this->parseJSON($response);
                    break;
                    
                case 'structured':
                    $parsed = $this->parseStructured($response);
                    break;
                    
                default:
                    $parsed['content'] = $this->sanitizeContent($response);
            }
        } catch (\Exception $e) {
            $parsed['success'] = false;
            $parsed['errors'][] = $e->getMessage();
        }

        return $parsed;
    }

    /**
     * Parse JSON response
     */
    private function parseJSON(string $response): array
    {
        $data = json_decode($response, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new \Exception('Invalid JSON response');
        }

        return [
            'success' => true,
            'content' => $this->sanitizeContent($data['content'] ?? $response),
            'metadata' => $data['metadata'] ?? [],
            'errors' => []
        ];
    }

    /**
     * Parse structured response
     */
    private function parseStructured(string $response): array
    {
        $lines = explode("\n", $response);
        $structured = [
            'main_output' => '',
            'recommended_actions' => [],
            'metadata' => []
        ];

        $currentSection = 'main_output';
        
        foreach ($lines as $line) {
            $line = trim($line);
            
            if (empty($line)) {
                continue;
            }

            if (stripos($line, 'recommended actions:') !== false) {
                $currentSection = 'recommended_actions';
                continue;
            }

            if (stripos($line, 'metadata:') !== false) {
                $currentSection = 'metadata';
                continue;
            }

            if ($currentSection === 'main_output') {
                $structured['main_output'] .= $line . "\n";
            } elseif ($currentSection === 'recommended_actions') {
                $structured['recommended_actions'][] = $line;
            } elseif ($currentSection === 'metadata') {
                $structured['metadata'][] = $line;
            }
        }

        return [
            'success' => true,
            'content' => $this->sanitizeContent($structured['main_output']),
            'metadata' => $structured,
            'errors' => []
        ];
    }

    /**
     * Sanitize content - remove HTML/scripts
     */
    private function sanitizeContent(string $content): string
    {
        // Remove any HTML tags
        $content = strip_tags($content);
        
        // Remove potential script content
        $content = preg_replace('/<script\b[^>]*>(.*?)<\/script>/is', '', $content);
        
        // Trim and clean
        return trim($content);
    }

    /**
     * Validate response
     */
    public function validate(array $parsed): bool
    {
        if (!isset($parsed['success']) || !$parsed['success']) {
            return false;
        }

        if (empty($parsed['content'])) {
            return false;
        }

        // Check for suspicious content
        if ($this->containsSuspiciousContent($parsed['content'])) {
            return false;
        }

        return true;
    }

    /**
     * Check for suspicious content
     */
    private function containsSuspiciousContent(string $content): bool
    {
        $patterns = [
            '/<script/i',
            '/<iframe/i',
            '/javascript:/i',
            '/on\w+\s*=/i', // onclick, onload, etc.
        ];

        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $content)) {
                return true;
            }
        }

        return false;
    }
}
