<?php

declare(strict_types=1);

namespace ViraMind\Core\Middleware;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Base Middleware
 */
abstract class Middleware
{
    abstract public function handle(Request $request, callable $next): mixed;
}
