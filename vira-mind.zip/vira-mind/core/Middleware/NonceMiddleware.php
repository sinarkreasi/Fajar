<?php

declare(strict_types=1);

namespace ViraMind\Core\Middleware;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Nonce validation middleware
 */
class NonceMiddleware extends Middleware
{
    public function handle(Request $request, callable $next): mixed
    {
        $nonce = $request->get('_wpnonce', '');
        $action = $request->get('_action', 'vrmind_action');

        if (!wp_verify_nonce($nonce, $action)) {
            wp_die(esc_html__('Security check failed', 'vira-mind'), 403);
        }

        return $next($request);
    }
}
