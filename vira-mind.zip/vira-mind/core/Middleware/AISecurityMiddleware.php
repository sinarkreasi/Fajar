<?php

declare(strict_types=1);

namespace ViraMind\Core\Middleware;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * AI Security Middleware
 * Prevents prompt injection and validates AI input
 */
class AISecurityMiddleware extends Middleware
{
    private array $blockedPatterns = [
        '/ignore\s+previous\s+instructions/i',
        '/system\s+prompt/i',
        '/you\s+are\s+now/i',
    ];

    public function handle(Request $request, callable $next): mixed
    {
        $prompt = $request->get('prompt', '');
        
        foreach ($this->blockedPatterns as $pattern) {
            if (preg_match($pattern, $prompt)) {
                wp_die(esc_html__('Invalid prompt detected', 'vira-mind'), 400);
            }
        }

        return $next($request);
    }
}
