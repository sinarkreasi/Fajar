<?php

declare(strict_types=1);

namespace ViraMind\Core\Middleware;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Authentication Middleware
 */
class AuthMiddleware extends Middleware
{
    public function handle(Request $request, callable $next): mixed
    {
        if (!is_user_logged_in()) {
            wp_die(esc_html__('Authentication required', 'vira-mind'), 401);
        }

        if (!current_user_can('edit_posts')) {
            wp_die(esc_html__('Insufficient permissions', 'vira-mind'), 403);
        }

        return $next($request);
    }
}
