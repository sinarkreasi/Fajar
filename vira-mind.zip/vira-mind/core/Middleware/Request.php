<?php

declare(strict_types=1);

namespace ViraMind\Core\Middleware;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Request object
 */
class Request
{
    public function __construct(
        public array $data = [],
        public array $headers = [],
        public string $method = 'GET'
    ) {}

    public function get(string $key, mixed $default = null): mixed
    {
        return $this->data[$key] ?? $default;
    }

    public function has(string $key): bool
    {
        return isset($this->data[$key]);
    }

    public function all(): array
    {
        return $this->data;
    }
}
