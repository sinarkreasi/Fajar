<?php

declare(strict_types=1);

namespace ViraMind\Core\Middleware;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Rate limiting middleware
 */
class RateLimitMiddleware extends Middleware
{
    private int $maxAttempts = 60;
    private int $decayMinutes = 1;

    public function handle(Request $request, callable $next): mixed
    {
        $key = $this->resolveRequestSignature($request);
        $attempts = (int) get_transient($key);

        if ($attempts >= $this->maxAttempts) {
            wp_die(esc_html__('Too many requests', 'vira-mind'), 429);
        }

        set_transient($key, $attempts + 1, $this->decayMinutes * 60);

        return $next($request);
    }

    private function resolveRequestSignature(Request $request): string
    {
        $user = get_current_user_id();
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        return 'vrmind_rate_limit_' . md5($user . $ip);
    }
}
