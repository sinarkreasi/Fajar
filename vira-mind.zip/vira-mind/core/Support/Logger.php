<?php

declare(strict_types=1);

namespace ViraMind\Core\Support;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Logger
 */
class Logger
{
    private string $logPath;

    public function __construct()
    {
        $this->logPath = VRMIND_PATH . 'storage/logs/';
    }

    public function log(string $level, string $message, array $context = []): void
    {
        $timestamp = current_time('Y-m-d H:i:s');
        $contextStr = !empty($context) ? json_encode($context) : '';
        $logMessage = sprintf("[%s] %s: %s %s\n", $timestamp, strtoupper($level), $message, $contextStr);
        
        $file = $this->logPath . 'vira-mind-' . current_time('Y-m-d') . '.log';
        
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
        file_put_contents($file, $logMessage, FILE_APPEND);
    }

    public function info(string $message, array $context = []): void
    {
        $this->log('info', $message, $context);
    }

    public function error(string $message, array $context = []): void
    {
        $this->log('error', $message, $context);
    }

    public function warning(string $message, array $context = []): void
    {
        $this->log('warning', $message, $context);
    }
}
