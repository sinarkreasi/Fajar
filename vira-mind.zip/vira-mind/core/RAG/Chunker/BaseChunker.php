<?php

declare(strict_types=1);

namespace ViraMind\Core\RAG\Chunker;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Base Chunker - Abstract base for all chunkers
 */
abstract class BaseChunker
{
    protected int $chunkSize = 500;
    protected int $overlap = 50;

    /**
     * Chunk content
     */
    abstract public function chunk(string $content): array;

    /**
     * Set chunk size
     */
    public function setChunkSize(int $size): void
    {
        $this->chunkSize = $size;
    }

    /**
     * Set overlap
     */
    public function setOverlap(int $overlap): void
    {
        $this->overlap = $overlap;
    }

    /**
     * Clean content
     */
    protected function clean(string $content): string
    {
        // Remove shortcodes
        $content = strip_shortcodes($content);
        
        // Remove HTML tags
        $content = wp_strip_all_tags($content);
        
        // Remove extra whitespace
        $content = preg_replace('/\s+/', ' ', $content);
        
        return trim($content);
    }

    /**
     * Split into sentences
     */
    protected function splitSentences(string $text): array
    {
        // Simple sentence splitting
        $sentences = preg_split('/(?<=[.!?])\s+/', $text, -1, PREG_SPLIT_NO_EMPTY);
        return array_map('trim', $sentences);
    }
}
