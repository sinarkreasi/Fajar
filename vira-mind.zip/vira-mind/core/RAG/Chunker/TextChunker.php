<?php

declare(strict_types=1);

namespace ViraMind\Core\RAG\Chunker;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Text Chunker - Chunks plain text content
 */
class TextChunker extends BaseChunker
{
    public function chunk(string $content): array
    {
        $content = $this->clean($content);
        $sentences = $this->splitSentences($content);
        
        $chunks = [];
        $currentChunk = '';
        $currentSize = 0;

        foreach ($sentences as $sentence) {
            $sentenceSize = str_word_count($sentence);
            
            if ($currentSize + $sentenceSize > $this->chunkSize && !empty($currentChunk)) {
                $chunks[] = trim($currentChunk);
                
                // Add overlap
                $words = explode(' ', $currentChunk);
                $overlapWords = array_slice($words, -$this->overlap);
                $currentChunk = implode(' ', $overlapWords) . ' ';
                $currentSize = count($overlapWords);
            }

            $currentChunk .= $sentence . ' ';
            $currentSize += $sentenceSize;
        }

        if (!empty($currentChunk)) {
            $chunks[] = trim($currentChunk);
        }

        return $chunks;
    }
}
