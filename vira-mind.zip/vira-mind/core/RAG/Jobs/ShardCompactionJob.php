<?php

declare(strict_types=1);

namespace ViraMind\Core\RAG\Jobs;

use ViraMind\Services\Queue\Job;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Shard Compaction Job - Optimizes vector storage
 * Merges small shards, removes deleted chunks, rebalances
 */
class ShardCompactionJob extends Job
{
    private string $storagePath;
    private int $targetSize = 1000;

    public function __construct()
    {
        $this->storagePath = VRMIND_PATH . 'storage/vectors/';
        $this->targetSize = \ViraMind\vrmind_config('rag.shards.target_size', 1000);
    }

    public function handle(): void
    {
        $dirs = glob($this->storagePath . '*', GLOB_ONLYDIR);
        $metrics = new \ViraMind\Core\RAG\Support\RAGMetrics();

        foreach ($dirs as $dir) {
            $this->compactDirectory($dir);
        }

        $metrics->recordCompaction([
            'runs' => 1,
            'shards_before' => count($dirs),
            'shards_after' => count(glob($this->storagePath . '*', GLOB_ONLYDIR))
        ]);

        \ViraMind\vrmind_log('Shard compaction completed', 'info');
    }

    /**
     * Compact shards in directory
     */
    private function compactDirectory(string $dir): void
    {
        $shards = glob($dir . '/shard-*.json');
        
        if (count($shards) <= 1) {
            return;
        }

        // Load all chunks
        $allChunks = [];
        foreach ($shards as $shard) {
            $data = json_decode(file_get_contents($shard), true) ?? [];
            $allChunks = array_merge($allChunks, $data);
        }

        // Remove duplicates and deleted chunks
        $allChunks = $this->deduplicate($allChunks);

        // Rebalance into new shards
        $newShards = array_chunk($allChunks, $this->targetSize);

        // Delete old shards
        foreach ($shards as $shard) {
            unlink($shard);
        }

        // Write new shards
        foreach ($newShards as $index => $chunks) {
            $file = $dir . '/shard-' . ($index + 1) . '.json';
            file_put_contents($file, json_encode($chunks));
        }
    }

    /**
     * Remove duplicate chunks
     */
    private function deduplicate(array $chunks): array
    {
        $seen = [];
        $unique = [];

        foreach ($chunks as $chunk) {
            $hash = md5($chunk['text']);
            
            if (!isset($seen[$hash])) {
                $seen[$hash] = true;
                $unique[] = $chunk;
            }
        }

        return $unique;
    }
}
