<?php

declare(strict_types=1);

namespace ViraMind\Core\RAG\Pipelines;

use ViraMind\Core\RAG\Stores\VectorStore;
use ViraMind\Core\RAG\Embeddings\EmbeddingManager;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * RAG Query Engine - Main processor for RAG queries
 */
class RAGQueryEngine
{
    private VectorStore $vectorStore;
    private EmbeddingManager $embeddingManager;
    private RAGContextBuilder $contextBuilder;
    private int $topK = 5;

    public function __construct()
    {
        $this->vectorStore = new VectorStore();
        $this->embeddingManager = new EmbeddingManager();
        $this->contextBuilder = new RAGContextBuilder();
    }

    /**
     * Query with RAG
     */
    public function query(string $query, array $options = []): array
    {
        try {
            // Generate query embedding
            $queryVector = $this->embeddingManager->embed($query);

            // Retrieve similar chunks
            $topK = $options['top_k'] ?? $this->topK;
            $results = $this->vectorStore->search($queryVector, $topK);

            // Build context
            $context = $this->contextBuilder->build($results);

            // Validate context window
            if (!$this->contextBuilder->validate($context, $query)) {
                $context = $this->contextBuilder->truncate($context);
            }

            // Build augmented prompt
            $augmentedPrompt = $this->buildPrompt($query, $context);

            // Query AI
            $response = \ViraMind\vrmind_ai($augmentedPrompt, $options);

            // Clean output
            $cleanResponse = $this->cleanOutput($response);

            return [
                'success' => true,
                'response' => $cleanResponse,
                'context' => $results,
                'sources' => $this->extractSources($results)
            ];

        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Build augmented prompt
     */
    private function buildPrompt(string $query, string $context): string
    {
        return "Context:\n{$context}\n\nQuestion: {$query}\n\nAnswer based on the context above:";
    }

    /**
     * Clean AI output
     */
    private function cleanOutput(string $output): string
    {
        // Remove HTML/scripts
        $output = strip_tags($output);
        
        // Remove potential injection attempts
        $output = preg_replace('/<script\b[^>]*>(.*?)<\/script>/is', '', $output);
        
        return trim($output);
    }

    /**
     * Extract sources from results
     */
    private function extractSources(array $results): array
    {
        $sources = [];
        
        foreach ($results as $result) {
            $sources[] = [
                'document_id' => $result['document_id'],
                'similarity' => $result['similarity']
            ];
        }

        return $sources;
    }
}
