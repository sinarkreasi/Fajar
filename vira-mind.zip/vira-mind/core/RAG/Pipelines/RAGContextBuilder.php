<?php

declare(strict_types=1);

namespace ViraMind\Core\RAG\Pipelines;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * RAG Context Builder - Builds context from retrieved chunks
 */
class RAGContextBuilder
{
    private int $maxTokens = 4000;

    /**
     * Build context from results
     */
    public function build(array $results): string
    {
        $context = '';

        foreach ($results as $result) {
            $context .= $result['text'] . "\n\n";
        }

        return trim($context);
    }

    /**
     * Validate context fits within token budget
     */
    public function validate(string $context, string $query): bool
    {
        $contextTokens = $this->estimateTokens($context);
        $queryTokens = $this->estimateTokens($query);
        $totalTokens = $contextTokens + $queryTokens + 100; // Buffer for prompt template

        return $totalTokens <= $this->maxTokens;
    }

    /**
     * Truncate context to fit budget
     */
    public function truncate(string $context): string
    {
        $sentences = preg_split('/(?<=[.!?])\s+/', $context);
        $truncated = '';
        $tokens = 0;

        foreach ($sentences as $sentence) {
            $sentenceTokens = $this->estimateTokens($sentence);
            
            if ($tokens + $sentenceTokens > $this->maxTokens) {
                break;
            }

            $truncated .= $sentence . ' ';
            $tokens += $sentenceTokens;
        }

        return trim($truncated);
    }

    /**
     * Estimate token count
     */
    private function estimateTokens(string $text): int
    {
        $words = str_word_count($text);
        return (int) ceil($words * 1.33);
    }

    /**
     * Set max tokens
     */
    public function setMaxTokens(int $tokens): void
    {
        $this->maxTokens = $tokens;
    }
}
