<?php

declare(strict_types=1);

namespace ViraMind\Core\RAG\Stores;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Shard Writer - Writes vectors to sharded files
 */
class ShardWriter
{
    private string $storagePath;
    private int $shardSize = 1000;

    public function __construct(string $storagePath)
    {
        $this->storagePath = $storagePath;
    }

    /**
     * Write vector to shard
     */
    public function write(int $documentId, array $data): void
    {
        $dir = $this->storagePath . $documentId;
        
        if (!is_dir($dir)) {
            wp_mkdir_p($dir);
        }

        // Find current shard
        $shardIndex = $this->getCurrentShardIndex($dir);
        $shardFile = $dir . '/shard-' . $shardIndex . '.json';

        // Load existing shard
        $shard = [];
        if (file_exists($shardFile)) {
            $shard = json_decode(file_get_contents($shardFile), true) ?? [];
        }

        // Add data
        $shard[] = array_merge($data, ['document_id' => $documentId]);

        // Check if shard is full
        if (count($shard) >= $this->shardSize) {
            $shardIndex++;
            $shardFile = $dir . '/shard-' . $shardIndex . '.json';
            $shard = [array_merge($data, ['document_id' => $documentId])];
        }

        // Write shard
        file_put_contents($shardFile, json_encode($shard));
    }

    /**
     * Get current shard index
     */
    private function getCurrentShardIndex(string $dir): int
    {
        $shards = glob($dir . '/shard-*.json');
        
        if (empty($shards)) {
            return 1;
        }

        $lastShard = end($shards);
        $lastShardData = json_decode(file_get_contents($lastShard), true) ?? [];

        if (count($lastShardData) >= $this->shardSize) {
            return count($shards) + 1;
        }

        return count($shards);
    }
}
