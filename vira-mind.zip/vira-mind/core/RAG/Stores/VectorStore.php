<?php

declare(strict_types=1);

namespace ViraMind\Core\RAG\Stores;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Vector Store - Manages vector storage and retrieval
 */
class VectorStore
{
    private string $storagePath;
    private ShardWriter $writer;
    private ShardReader $reader;
    private int $shardSize = 1000;

    public function __construct()
    {
        $this->storagePath = VRMIND_PATH . 'storage/vectors/';
        $this->writer = new ShardWriter($this->storagePath);
        $this->reader = new ShardReader($this->storagePath);
    }

    /**
     * Store vector
     */
    public function store(int $documentId, int $chunkIndex, array $vector, string $text): void
    {
        $this->writer->write($documentId, [
            'chunk_index' => $chunkIndex,
            'vector' => $vector,
            'text' => $text,
            'created_at' => current_time('mysql')
        ]);
    }

    /**
     * Get vectors for document
     */
    public function getVectors(int $documentId): array
    {
        return $this->reader->read($documentId);
    }

    /**
     * Search similar vectors
     */
    public function search(array $queryVector, int $limit = 10): array
    {
        $allVectors = $this->reader->readAll();
        $similarities = [];

        foreach ($allVectors as $item) {
            $similarity = $this->cosineSimilarity($queryVector, $item['vector']);
            $similarities[] = [
                'document_id' => $item['document_id'],
                'chunk_index' => $item['chunk_index'],
                'text' => $item['text'],
                'similarity' => $similarity
            ];
        }

        // Sort by similarity descending
        usort($similarities, fn($a, $b) => $b['similarity'] <=> $a['similarity']);

        return array_slice($similarities, 0, $limit);
    }

    /**
     * Calculate cosine similarity
     */
    private function cosineSimilarity(array $a, array $b): float
    {
        if (count($a) !== count($b)) {
            return 0.0;
        }

        $dotProduct = 0.0;
        $magnitudeA = 0.0;
        $magnitudeB = 0.0;

        for ($i = 0; $i < count($a); $i++) {
            $dotProduct += $a[$i] * $b[$i];
            $magnitudeA += $a[$i] * $a[$i];
            $magnitudeB += $b[$i] * $b[$i];
        }

        $magnitudeA = sqrt($magnitudeA);
        $magnitudeB = sqrt($magnitudeB);

        if ($magnitudeA == 0 || $magnitudeB == 0) {
            return 0.0;
        }

        return $dotProduct / ($magnitudeA * $magnitudeB);
    }

    /**
     * Delete vectors for document
     */
    public function delete(int $documentId): void
    {
        $dir = $this->storagePath . $documentId;
        
        if (is_dir($dir)) {
            $files = glob($dir . '/*');
            foreach ($files as $file) {
                unlink($file);
            }
            rmdir($dir);
        }
    }
}
