<?php

declare(strict_types=1);

namespace ViraMind\Core\RAG\Stores;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Shard Reader - Reads vectors from sharded files
 */
class ShardReader
{
    private string $storagePath;

    public function __construct(string $storagePath)
    {
        $this->storagePath = $storagePath;
    }

    /**
     * Read vectors for document
     */
    public function read(int $documentId): array
    {
        $dir = $this->storagePath . $documentId;
        
        if (!is_dir($dir)) {
            return [];
        }

        $shards = glob($dir . '/shard-*.json');
        $vectors = [];

        foreach ($shards as $shard) {
            $data = json_decode(file_get_contents($shard), true) ?? [];
            $vectors = array_merge($vectors, $data);
        }

        return $vectors;
    }

    /**
     * Read all vectors
     */
    public function readAll(): array
    {
        $dirs = glob($this->storagePath . '*', GLOB_ONLYDIR);
        $allVectors = [];

        foreach ($dirs as $dir) {
            $documentId = (int) basename($dir);
            $vectors = $this->read($documentId);
            $allVectors = array_merge($allVectors, $vectors);
        }

        return $allVectors;
    }
}
