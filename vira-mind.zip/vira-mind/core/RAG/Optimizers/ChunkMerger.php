<?php

declare(strict_types=1);

namespace ViraMind\Core\RAG\Optimizers;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Chunk Merger - Intelligently merges adjacent chunks
 * Merge threshold: default semantic > 0.88 (configurable)
 */
class ChunkMerger
{
    private float $mergeThreshold = 0.88;
    private int $maxWindowTokens = 2000;

    /**
     * Merge chunks intelligently
     */
    public function merge(array $chunks): array
    {
        if (empty($chunks)) {
            return [];
        }

        $merged = [];
        $current = $chunks[0];
        $currentTokens = $this->estimateTokens($current['text']);

        for ($i = 1; $i < count($chunks); $i++) {
            $nextChunk = $chunks[$i];
            $nextTokens = $this->estimateTokens($nextChunk['text']);
            $combinedTokens = $currentTokens + $nextTokens;

            // Check if chunks are adjacent (same document, sequential index)
            $areAdjacent = $this->areAdjacent($current, $nextChunk);

            // Calculate semantic similarity if adjacent
            $similarity = 0.0;
            if ($areAdjacent && isset($current['vector']) && isset($nextChunk['vector'])) {
                $similarity = $this->cosineSimilarity($current['vector'], $nextChunk['vector']);
            }

            // Merge if conditions met
            if ($areAdjacent && 
                $similarity > $this->mergeThreshold && 
                $combinedTokens <= $this->maxWindowTokens) {
                
                // Merge chunks
                $current['text'] .= ' ' . $nextChunk['text'];
                $currentTokens = $combinedTokens;
                
                // Update metadata
                $current['chunk_end'] = $nextChunk['chunk_index'];
                $current['merged'] = true;
            } else {
                // Save current and start new
                $merged[] = $current;
                $current = $nextChunk;
                $currentTokens = $nextTokens;
            }
        }

        // Add last chunk
        $merged[] = $current;

        return $merged;
    }

    /**
     * Check if chunks are adjacent
     */
    private function areAdjacent(array $chunk1, array $chunk2): bool
    {
        return $chunk1['document_id'] === $chunk2['document_id'] &&
               ($chunk1['chunk_index'] + 1) === $chunk2['chunk_index'];
    }

    /**
     * Estimate token count
     * Simple approximation: words * 1.33
     */
    private function estimateTokens(string $text): int
    {
        $words = str_word_count($text);
        return (int) ceil($words * 1.33);
    }

    /**
     * Calculate cosine similarity
     */
    private function cosineSimilarity(array $a, array $b): float
    {
        if (count($a) !== count($b)) {
            return 0.0;
        }

        $dotProduct = 0.0;
        $magnitudeA = 0.0;
        $magnitudeB = 0.0;

        for ($i = 0; $i < count($a); $i++) {
            $dotProduct += $a[$i] * $b[$i];
            $magnitudeA += $a[$i] * $a[$i];
            $magnitudeB += $b[$i] * $b[$i];
        }

        $magnitudeA = sqrt($magnitudeA);
        $magnitudeB = sqrt($magnitudeB);

        if ($magnitudeA == 0 || $magnitudeB == 0) {
            return 0.0;
        }

        return $dotProduct / ($magnitudeA * $magnitudeB);
    }

    /**
     * Set merge threshold
     */
    public function setMergeThreshold(float $threshold): void
    {
        $this->mergeThreshold = $threshold;
    }

    /**
     * Set max window tokens
     */
    public function setMaxWindowTokens(int $tokens): void
    {
        $this->maxWindowTokens = $tokens;
    }
}
