<?php

declare(strict_types=1);

namespace ViraMind\Core\RAG\Support;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Query Cache - Multi-level caching for RAG queries
 * L1: In-memory (request lifetime)
 * L2: File-based
 * L3: Redis (optional)
 */
class QueryCache
{
    private string $cacheDir;
    private int $ttl = 3600;
    private array $memoryCache = []; // L1 cache
    private bool $redisEnabled = false;

    public function __construct()
    {
        $this->cacheDir = VRMIND_PATH . 'storage/rag/cache/';
        
        if (!is_dir($this->cacheDir)) {
            wp_mkdir_p($this->cacheDir);
        }

        $this->redisEnabled = class_exists('Redis') && extension_loaded('redis');
    }

    /**
     * Get cached result
     */
    public function get(string $query, array $config = []): ?array
    {
        $key = $this->generateKey($query, $config);

        // L1: Check memory cache
        if (isset($this->memoryCache[$key])) {
            return $this->memoryCache[$key];
        }

        // L3: Check Redis if available
        if ($this->redisEnabled) {
            $result = $this->getFromRedis($key);
            if ($result !== null) {
                $this->memoryCache[$key] = $result; // Populate L1
                return $result;
            }
        }

        // L2: Check file cache
        $result = $this->getFromFile($key);
        if ($result !== null) {
            $this->memoryCache[$key] = $result; // Populate L1
            
            if ($this->redisEnabled) {
                $this->setToRedis($key, $result); // Populate L3
            }
        }

        return $result;
    }

    /**
     * Set cache
     */
    public function set(string $query, array $result, array $config = []): void
    {
        $key = $this->generateKey($query, $config);

        // L1: Set memory cache
        $this->memoryCache[$key] = $result;

        // L2: Set file cache
        $this->setToFile($key, $result);

        // L3: Set Redis cache
        if ($this->redisEnabled) {
            $this->setToRedis($key, $result);
        }
    }

    /**
     * Generate cache key
     */
    private function generateKey(string $query, array $config): string
    {
        $data = $query . serialize($config);
        return md5($data);
    }

    /**
     * Get from file cache
     */
    private function getFromFile(string $key): ?array
    {
        $file = $this->cacheDir . $key . '.json';

        if (!file_exists($file)) {
            return null;
        }

        $data = json_decode(file_get_contents($file), true);

        if (!$data || $data['expires'] < time()) {
            unlink($file);
            return null;
        }

        return $data['result'];
    }

    /**
     * Set to file cache
     */
    private function setToFile(string $key, array $result): void
    {
        $file = $this->cacheDir . $key . '.json';

        file_put_contents($file, json_encode([
            'result' => $result,
            'expires' => time() + $this->ttl,
            'created' => time()
        ]));
    }

    /**
     * Get from Redis
     */
    private function getFromRedis(string $key): ?array
    {
        try {
            $redis = new \Redis();
            $redis->connect('127.0.0.1', 6379);
            
            $data = $redis->get('vrmind_rag_' . $key);
            
            if ($data) {
                return json_decode($data, true);
            }
        } catch (\Exception $e) {
            // Redis not available, continue
        }

        return null;
    }

    /**
     * Set to Redis
     */
    private function setToRedis(string $key, array $result): void
    {
        try {
            $redis = new \Redis();
            $redis->connect('127.0.0.1', 6379);
            $redis->setex('vrmind_rag_' . $key, $this->ttl, json_encode($result));
        } catch (\Exception $e) {
            // Redis not available, continue
        }
    }

    /**
     * Clear cache
     */
    public function clear(): void
    {
        // Clear L1
        $this->memoryCache = [];

        // Clear L2
        $files = glob($this->cacheDir . '*.json');
        foreach ($files as $file) {
            unlink($file);
        }

        // Clear L3
        if ($this->redisEnabled) {
            try {
                $redis = new \Redis();
                $redis->connect('127.0.0.1', 6379);
                $keys = $redis->keys('vrmind_rag_*');
                foreach ($keys as $key) {
                    $redis->del($key);
                }
            } catch (\Exception $e) {
                // Redis not available
            }
        }
    }

    /**
     * Get cache statistics
     */
    public function getStats(): array
    {
        $files = glob($this->cacheDir . '*.json');
        $totalSize = 0;
        $validEntries = 0;

        foreach ($files as $file) {
            $totalSize += filesize($file);
            $data = json_decode(file_get_contents($file), true);
            if ($data && $data['expires'] >= time()) {
                $validEntries++;
            }
        }

        return [
            'l1_entries' => count($this->memoryCache),
            'l2_entries' => $validEntries,
            'l2_size' => $totalSize,
            'redis_enabled' => $this->redisEnabled
        ];
    }
}
