<?php

declare(strict_types=1);

namespace ViraMind\Core\RAG\Support;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * RAG Metrics - Track and log RAG performance metrics
 */
class RAGMetrics
{
    private string $logPath;
    private array $metrics = [];

    public function __construct()
    {
        $this->logPath = VRMIND_PATH . 'storage/logs/rag-metrics.log';
    }

    /**
     * Record retrieval metrics
     */
    public function recordRetrieval(array $data): void
    {
        $this->metrics['retrieval_latency_ms'] = $data['latency'] ?? 0;
        $this->metrics['candidates_requested'] = $data['requested'] ?? 0;
        $this->metrics['candidates_returned'] = $data['returned'] ?? 0;
        $this->metrics['method'] = $data['method'] ?? 'unknown';

        $this->log('retrieval', $this->metrics);
        
        do_action('vrmind_rag_retrieval', $this->metrics);
    }

    /**
     * Record rerank metrics
     */
    public function recordRerank(array $data): void
    {
        $this->metrics['rerank_latency_ms'] = $data['latency'] ?? 0;
        $this->metrics['rerank_method'] = $data['method'] ?? 'unknown';

        $this->log('rerank', $this->metrics);
    }

    /**
     * Record merge metrics
     */
    public function recordMerge(int $chunksBefor, int $chunksAfter): void
    {
        $this->metrics['chunks_before_merge'] = $chunksBefor;
        $this->metrics['chunks_after_merge'] = $chunksAfter;
        $this->metrics['num_chunks_merged'] = $chunksBefor - $chunksAfter;

        $this->log('merge', $this->metrics);
    }

    /**
     * Record cache hit/miss
     */
    public function recordCache(bool $hit): void
    {
        $this->metrics['cache_hit'] = $hit;
        $this->log('cache', $this->metrics);
    }

    /**
     * Record compaction
     */
    public function recordCompaction(array $data): void
    {
        $this->metrics['compaction_runs'] = $data['runs'] ?? 0;
        $this->metrics['shards_before'] = $data['shards_before'] ?? 0;
        $this->metrics['shards_after'] = $data['shards_after'] ?? 0;

        $this->log('compaction', $this->metrics);
    }

    /**
     * Log metrics
     */
    private function log(string $type, array $data): void
    {
        $timestamp = current_time('Y-m-d H:i:s');
        $logEntry = sprintf(
            "[%s] %s: %s\n",
            $timestamp,
            strtoupper($type),
            json_encode($data)
        );

        file_put_contents($this->logPath, $logEntry, FILE_APPEND);
    }

    /**
     * Get metrics summary
     */
    public function getSummary(): array
    {
        return $this->metrics;
    }

    /**
     * Calculate cache hit rate
     */
    public function getCacheHitRate(): float
    {
        if (!file_exists($this->logPath)) {
            return 0.0;
        }

        $lines = file($this->logPath);
        $hits = 0;
        $total = 0;

        foreach ($lines as $line) {
            if (strpos($line, 'CACHE:') !== false) {
                $total++;
                if (strpos($line, '"cache_hit":true') !== false) {
                    $hits++;
                }
            }
        }

        return $total > 0 ? ($hits / $total) * 100 : 0.0;
    }
}
