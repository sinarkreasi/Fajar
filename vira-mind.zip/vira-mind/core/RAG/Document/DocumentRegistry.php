<?php

declare(strict_types=1);

namespace ViraMind\Core\RAG\Document;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Document Registry - Manages documents for RAG
 */
class DocumentRegistry
{
    private string $storagePath;
    private array $documentTypes = [];

    public function __construct()
    {
        $this->storagePath = VRMIND_PATH . 'storage/rag/';
        $this->registerDefaultTypes();
    }

    /**
     * Register default document types
     */
    private function registerDefaultTypes(): void
    {
        $this->registerType('post', [
            'label' => 'Post',
            'callback' => [$this, 'getPostContent']
        ]);

        $this->registerType('page', [
            'label' => 'Page',
            'callback' => [$this, 'getPostContent']
        ]);

        $this->registerType('product', [
            'label' => 'Product',
            'callback' => [$this, 'getProductContent']
        ]);
    }

    /**
     * Register document type
     */
    public function registerType(string $type, array $config): void
    {
        $this->documentTypes[$type] = $config;
        do_action('vrmind_rag_document_type_registered', $type, $config);
    }

    /**
     * Register document
     */
    public function register(int $documentId, string $type, array $metadata = []): DocumentModel
    {
        $document = new DocumentModel([
            'id' => $documentId,
            'type' => $type,
            'metadata' => $metadata,
            'version' => $this->getDocumentVersion($documentId),
            'registered_at' => current_time('mysql'),
            'status' => 'pending'
        ]);

        $this->save($document);
        
        do_action('vrmind_rag_document_registered', $document);
        
        return $document;
    }

    /**
     * Get document
     */
    public function get(int $documentId): ?DocumentModel
    {
        $file = $this->storagePath . 'documents/' . $documentId . '.json';
        
        if (!file_exists($file)) {
            return null;
        }

        $data = json_decode(file_get_contents($file), true);
        return new DocumentModel($data);
    }

    /**
     * Save document
     */
    private function save(DocumentModel $document): void
    {
        $dir = $this->storagePath . 'documents/';
        
        if (!is_dir($dir)) {
            wp_mkdir_p($dir);
        }

        $file = $dir . $document->id . '.json';
        file_put_contents($file, json_encode($document->toArray()));
    }

    /**
     * Get document version (for change detection)
     */
    private function getDocumentVersion(int $documentId): string
    {
        $post = get_post($documentId);
        return $post ? md5($post->post_modified . $post->post_content) : '';
    }

    /**
     * Check if document needs reindexing
     */
    public function needsReindex(int $documentId): bool
    {
        $document = $this->get($documentId);
        
        if (!$document) {
            return true;
        }

        $currentVersion = $this->getDocumentVersion($documentId);
        return $document->version !== $currentVersion;
    }

    /**
     * Get post content
     */
    private function getPostContent(int $postId): string
    {
        $post = get_post($postId);
        return $post ? $post->post_content : '';
    }

    /**
     * Get product content
     */
    private function getProductContent(int $productId): string
    {
        if (!function_exists('wc_get_product')) {
            return '';
        }

        $product = wc_get_product($productId);
        return $product ? $product->get_description() : '';
    }

    /**
     * Get all documents
     */
    public function all(): array
    {
        $dir = $this->storagePath . 'documents/';
        
        if (!is_dir($dir)) {
            return [];
        }

        $files = glob($dir . '*.json');
        $documents = [];

        foreach ($files as $file) {
            $data = json_decode(file_get_contents($file), true);
            $documents[] = new DocumentModel($data);
        }

        return $documents;
    }
}
