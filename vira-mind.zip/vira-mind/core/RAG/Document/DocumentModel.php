<?php

declare(strict_types=1);

namespace ViraMind\Core\RAG\Document;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Document Model - Represents a document in RAG system
 */
class DocumentModel
{
    public int $id;
    public string $type;
    public array $metadata;
    public string $version;
    public string $registered_at;
    public string $status;
    public int $chunks_count = 0;
    public int $embeddings_count = 0;

    public function __construct(array $data)
    {
        $this->id = $data['id'] ?? 0;
        $this->type = $data['type'] ?? 'post';
        $this->metadata = $data['metadata'] ?? [];
        $this->version = $data['version'] ?? '';
        $this->registered_at = $data['registered_at'] ?? current_time('mysql');
        $this->status = $data['status'] ?? 'pending';
        $this->chunks_count = $data['chunks_count'] ?? 0;
        $this->embeddings_count = $data['embeddings_count'] ?? 0;
    }

    public function toArray(): array
    {
        return [
            'id' => $this->id,
            'type' => $this->type,
            'metadata' => $this->metadata,
            'version' => $this->version,
            'registered_at' => $this->registered_at,
            'status' => $this->status,
            'chunks_count' => $this->chunks_count,
            'embeddings_count' => $this->embeddings_count
        ];
    }
}
