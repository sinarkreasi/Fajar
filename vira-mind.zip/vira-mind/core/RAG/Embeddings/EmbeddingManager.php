<?php

declare(strict_types=1);

namespace ViraMind\Core\RAG\Embeddings;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Embedding Manager - Manages text embeddings
 */
class EmbeddingManager
{
    private array $drivers = [];
    private string $defaultDriver = 'openai';
    private int $batchSize = 10;
    private int $retryAttempts = 3;

    public function __construct()
    {
        $this->loadDrivers();
    }

    /**
     * Load embedding drivers
     */
    private function loadDrivers(): void
    {
        $this->drivers['openai'] = new Drivers\OpenAIEmbeddings();
    }

    /**
     * Generate embedding for text
     */
    public function embed(string $text, string $driver = null): array
    {
        $driver = $driver ?? $this->defaultDriver;
        
        if (!isset($this->drivers[$driver])) {
            throw new \Exception("Embedding driver '{$driver}' not found");
        }

        $attempt = 0;
        $lastError = null;

        while ($attempt < $this->retryAttempts) {
            try {
                return $this->drivers[$driver]->embed($text);
            } catch (\Exception $e) {
                $lastError = $e;
                $attempt++;
                
                if ($attempt < $this->retryAttempts) {
                    sleep(pow(2, $attempt)); // Exponential backoff
                }
            }
        }

        throw new \Exception("Failed to generate embedding after {$this->retryAttempts} attempts: " . $lastError->getMessage());
    }

    /**
     * Generate embeddings in batch
     */
    public function embedBatch(array $texts, string $driver = null): array
    {
        $embeddings = [];
        $batches = array_chunk($texts, $this->batchSize);

        foreach ($batches as $batch) {
            foreach ($batch as $text) {
                try {
                    $embeddings[] = $this->embed($text, $driver);
                } catch (\Exception $e) {
                    \ViraMind\vrmind_log('Embedding failed: ' . $e->getMessage(), 'error');
                    $embeddings[] = null;
                }
            }

            // Rate limiting
            usleep(100000); // 100ms delay between batches
        }

        return $embeddings;
    }

    /**
     * Get embedding dimension
     */
    public function getDimension(string $driver = null): int
    {
        $driver = $driver ?? $this->defaultDriver;
        return $this->drivers[$driver]->getDimension();
    }
}
