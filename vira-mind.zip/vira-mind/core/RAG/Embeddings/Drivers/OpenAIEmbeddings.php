<?php

declare(strict_types=1);

namespace ViraMind\Core\RAG\Embeddings\Drivers;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * OpenAI Embeddings Driver
 */
class OpenAIEmbeddings
{
    private string $model = 'text-embedding-ada-002';
    private int $dimension = 1536;

    /**
     * Generate embedding
     */
    public function embed(string $text): array
    {
        $apiKey = get_option('vrmind_openai_key', '');
        
        if (empty($apiKey)) {
            throw new \Exception('OpenAI API key not configured');
        }

        $response = wp_remote_post('https://api.openai.com/v1/embeddings', [
            'headers' => [
                'Authorization' => 'Bearer ' . $apiKey,
                'Content-Type' => 'application/json',
            ],
            'body' => wp_json_encode([
                'model' => $this->model,
                'input' => $text
            ]),
            'timeout' => 30,
        ]);

        if (is_wp_error($response)) {
            throw new \Exception('OpenAI API request failed: ' . $response->get_error_message());
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['error'])) {
            throw new \Exception('OpenAI API error: ' . $body['error']['message']);
        }

        return $body['data'][0]['embedding'] ?? [];
    }

    /**
     * Get embedding dimension
     */
    public function getDimension(): int
    {
        return $this->dimension;
    }
}
