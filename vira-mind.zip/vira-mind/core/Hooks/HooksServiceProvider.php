<?php

declare(strict_types=1);

namespace ViraMind\Core\Hooks;

use ViraMind\Core\Container\ServiceProvider;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Hooks Service Provider
 */
class HooksServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->singleton('hooks', fn() => new Hooks());
    }

    public function boot(): void
    {
        // Register core hooks
        Hooks::add('init', [$this, 'initHooks']);
    }

    public function initHooks(): void
    {
        // Core initialization hooks
        do_action('vrmind_init');
    }
}
