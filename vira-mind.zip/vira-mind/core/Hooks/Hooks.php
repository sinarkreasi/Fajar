<?php

declare(strict_types=1);

namespace ViraMind\Core\Hooks;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Hooks wrapper for WordPress
 */
class Hooks
{
    /**
     * Add an action hook
     */
    public static function add(string $hook, callable|array $callback, int $priority = 10, int $acceptedArgs = 1): void
    {
        add_action($hook, $callback, $priority, $acceptedArgs);
    }

    /**
     * Add a filter hook
     */
    public static function filter(string $hook, callable|array $callback, int $priority = 10, int $acceptedArgs = 1): void
    {
        add_filter($hook, $callback, $priority, $acceptedArgs);
    }

    /**
     * Remove an action hook
     */
    public static function remove(string $hook, callable|array $callback, int $priority = 10): bool
    {
        return remove_action($hook, $callback, $priority);
    }

    /**
     * Remove a filter hook
     */
    public static function removeFilter(string $hook, callable|array $callback, int $priority = 10): bool
    {
        return remove_filter($hook, $callback, $priority);
    }

    /**
     * Do an action
     */
    public static function do(string $hook, mixed ...$args): void
    {
        do_action($hook, ...$args);
    }

    /**
     * Apply filters
     */
    public static function apply(string $hook, mixed $value, mixed ...$args): mixed
    {
        return apply_filters($hook, $value, ...$args);
    }
}
