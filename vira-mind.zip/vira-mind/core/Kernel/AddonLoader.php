<?php

declare(strict_types=1);

namespace ViraMind\Core\Kernel;

use ViraMind\Core\Container\Container;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Addon Loader - Discovers and loads addons
 */
class AddonLoader
{
    private Container $container;
    private array $addons = [];
    private string $addonsPath;

    public function __construct(Container $container)
    {
        $this->container = $container;
        $this->addonsPath = VRMIND_PATH . 'addons/';
    }

    /**
     * Discover addons
     */
    public function discover(): void
    {
        if (!is_dir($this->addonsPath)) {
            return;
        }

        $directories = glob($this->addonsPath . '*', GLOB_ONLYDIR);
        
        foreach ($directories as $dir) {
            $manifestFile = $dir . '/addon.json';
            
            if (file_exists($manifestFile)) {
                $manifest = json_decode(file_get_contents($manifestFile), true);
                
                if ($this->validateManifest($manifest)) {
                    $manifest['path'] = $dir;
                    $this->addons[$manifest['slug']] = $manifest;
                    
                    // Auto-activate newly discovered addons
                    $this->autoActivateAddon($manifest['slug']);
                }
            }
        }

        do_action('vrmind_addons_discovered', $this->addons);
    }

    /**
     * Auto-activate addon if not in the list yet
     */
    private function autoActivateAddon(string $slug): void
    {
        $active = get_option('vrmind_active_addons', []);
        $discovered = get_option('vrmind_discovered_addons', []);
        
        // If this is a newly discovered addon, activate it
        if (!in_array($slug, $discovered)) {
            $discovered[] = $slug;
            update_option('vrmind_discovered_addons', $discovered);
            
            // Auto-activate
            if (!in_array($slug, $active)) {
                $active[] = $slug;
                update_option('vrmind_active_addons', $active);
            }
        }
    }

    /**
     * Load addons
     */
    public function load(): void
    {
        $activeAddons = get_option('vrmind_active_addons', []);
        
        foreach ($this->addons as $slug => $addon) {
            // Only load active addons
            if (!in_array($slug, $activeAddons)) {
                continue;
            }
            
            try {
                $this->loadAddon($addon);
            } catch (\Exception $e) {
                \ViraMind\vrmind_log("Failed to load addon {$slug}: " . $e->getMessage(), 'error');
            }
        }

        do_action('vrmind_addons_loaded', $this->addons);
    }

    /**
     * Load single addon
     */
    private function loadAddon(array $addon): void
    {
        // Load index.php if exists
        $indexFile = $addon['path'] . '/index.php';
        if (file_exists($indexFile)) {
            require_once $indexFile;
        }

        // Register service provider
        if (isset($addon['provider']) && class_exists($addon['provider'])) {
            $provider = new $addon['provider']($this->container);
            $provider->register();
            
            if (method_exists($provider, 'boot')) {
                $provider->boot();
            }
        }

        // Load routes if exists
        $routesFile = $addon['path'] . '/routes.php';
        if (file_exists($routesFile)) {
            require_once $routesFile;
        }

        do_action('vrmind_addon_loaded', $addon);
    }

    /**
     * Validate addon manifest
     */
    private function validateManifest(array $manifest): bool
    {
        $required = ['name', 'slug', 'version'];
        
        foreach ($required as $field) {
            if (!isset($manifest[$field]) || empty($manifest[$field])) {
                return false;
            }
        }

        return true;
    }

    /**
     * Get all addons
     */
    public function getAddons(): array
    {
        return $this->addons;
    }

    /**
     * Get addon by slug
     */
    public function getAddon(string $slug): ?array
    {
        return $this->addons[$slug] ?? null;
    }

    /**
     * Check if addon exists
     */
    public function hasAddon(string $slug): bool
    {
        return isset($this->addons[$slug]);
    }

    /**
     * Reload addons
     */
    public function reload(): void
    {
        $this->addons = [];
        $this->discover();
        $this->load();
    }
}
