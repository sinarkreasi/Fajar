<?php

declare(strict_types=1);

namespace ViraMind\Core\Kernel;

use ViraMind\Core\Container\Container;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Addon Installer - Handles addon upload and installation
 */
class AddonInstaller
{
    private Container $container;
    private string $tempPath;
    private string $addonsPath;
    private array $errors = [];

    public function __construct(Container $container)
    {
        $this->container = $container;
        $this->tempPath = VRMIND_PATH . 'storage/temp/';
        $this->addonsPath = VRMIND_PATH . 'addons/';
    }

    /**
     * Install addon from uploaded zip
     */
    public function install(array $file): array
    {
        $this->errors = [];

        // Validate file
        if (!$this->validateUpload($file)) {
            return ['success' => false, 'errors' => $this->errors];
        }

        // Extract zip
        $extractPath = $this->extractZip($file['tmp_name']);
        if (!$extractPath) {
            return ['success' => false, 'errors' => $this->errors];
        }

        // Validate manifest
        $manifest = $this->validateManifest($extractPath);
        if (!$manifest) {
            $this->cleanup($extractPath);
            return ['success' => false, 'errors' => $this->errors];
        }

        // Check for conflicts
        if ($this->hasConflict($manifest['slug'])) {
            $this->errors[] = 'Addon with slug "' . $manifest['slug'] . '" already exists';
            $this->cleanup($extractPath);
            return ['success' => false, 'errors' => $this->errors];
        }

        // Move to addons directory
        $finalPath = $this->addonsPath . $manifest['slug'];
        if (!rename($extractPath, $finalPath)) {
            $this->errors[] = 'Failed to move addon to addons directory';
            $this->cleanup($extractPath);
            return ['success' => false, 'errors' => $this->errors];
        }

        // Reload addons
        $this->container->make('addon.loader')->reload();

        return [
            'success' => true,
            'addon' => $manifest,
            'message' => 'Addon installed successfully'
        ];
    }

    /**
     * Validate uploaded file
     */
    private function validateUpload(array $file): bool
    {
        if ($file['error'] !== UPLOAD_ERR_OK) {
            $this->errors[] = 'Upload error: ' . $file['error'];
            return false;
        }

        if ($file['size'] > 10 * 1024 * 1024) { // 10MB limit
            $this->errors[] = 'File too large. Maximum size is 10MB';
            return false;
        }

        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if ($ext !== 'zip') {
            $this->errors[] = 'Invalid file type. Only ZIP files are allowed';
            return false;
        }

        return true;
    }

    /**
     * Extract zip file
     */
    private function extractZip(string $zipFile): ?string
    {
        if (!class_exists('ZipArchive')) {
            $this->errors[] = 'ZipArchive extension not available';
            return null;
        }

        // Ensure temp directory exists
        if (!is_dir($this->tempPath)) {
            wp_mkdir_p($this->tempPath);
        }

        $zip = new \ZipArchive();
        if ($zip->open($zipFile) !== true) {
            $this->errors[] = 'Failed to open ZIP file';
            return null;
        }

        $extractPath = $this->tempPath . 'addon_' . uniqid();
        
        if (!wp_mkdir_p($extractPath)) {
            $this->errors[] = 'Failed to create extraction directory';
            $zip->close();
            return null;
        }
        
        if (!$zip->extractTo($extractPath)) {
            $this->errors[] = 'Failed to extract ZIP file';
            $zip->close();
            return null;
        }

        $zip->close();

        // Check if extracted to subdirectory
        $contents = scandir($extractPath);
        $contents = array_diff($contents, ['.', '..']);
        $contents = array_values($contents);
        
        if (count($contents) === 1 && is_dir($extractPath . '/' . $contents[0])) {
            $subdir = $extractPath . '/' . $contents[0];
            $newPath = $extractPath . '_final';
            
            if (!rename($subdir, $newPath)) {
                $this->errors[] = 'Failed to move extracted files';
                $this->cleanup($extractPath);
                return null;
            }
            
            $this->cleanup($extractPath);
            return $newPath;
        }

        return $extractPath;
    }

    /**
     * Validate addon manifest
     */
    private function validateManifest(string $path): ?array
    {
        $manifestFile = $path . '/addon.json';
        
        if (!file_exists($manifestFile)) {
            $this->errors[] = 'addon.json not found';
            return null;
        }

        $manifest = json_decode(file_get_contents($manifestFile), true);
        
        if (!$manifest) {
            $this->errors[] = 'Invalid addon.json format';
            return null;
        }

        $required = ['name', 'slug', 'version'];
        foreach ($required as $field) {
            if (!isset($manifest[$field]) || empty($manifest[$field])) {
                $this->errors[] = "Missing required field: {$field}";
                return null;
            }
        }

        // Validate slug format
        if (!preg_match('/^[a-z0-9-]+$/', $manifest['slug'])) {
            $this->errors[] = 'Invalid slug format. Use lowercase letters, numbers, and hyphens only';
            return null;
        }

        return $manifest;
    }

    /**
     * Check for addon conflicts
     */
    private function hasConflict(string $slug): bool
    {
        return is_dir($this->addonsPath . $slug);
    }

    /**
     * Cleanup temporary files
     */
    private function cleanup(string $path): void
    {
        if (!is_dir($path)) {
            return;
        }

        try {
            $files = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator($path, \RecursiveDirectoryIterator::SKIP_DOTS),
                \RecursiveIteratorIterator::CHILD_FIRST
            );

            foreach ($files as $file) {
                if ($file->isDir()) {
                    @rmdir($file->getRealPath());
                } else {
                    @unlink($file->getRealPath());
                }
            }

            @rmdir($path);
        } catch (\Exception $e) {
            // Silently fail cleanup
            error_log('Addon cleanup failed: ' . $e->getMessage());
        }
    }

    /**
     * Uninstall addon
     */
    public function uninstall(string $slug): bool
    {
        $addonPath = $this->addonsPath . $slug;
        
        if (!is_dir($addonPath)) {
            $this->errors[] = 'Addon directory not found';
            return false;
        }

        // Deactivate addon first
        $active = get_option('vrmind_active_addons', []);
        $key = array_search($slug, $active);
        if ($key !== false) {
            unset($active[$key]);
            update_option('vrmind_active_addons', array_values($active));
        }

        // Remove from discovered list
        $discovered = get_option('vrmind_discovered_addons', []);
        $key = array_search($slug, $discovered);
        if ($key !== false) {
            unset($discovered[$key]);
            update_option('vrmind_discovered_addons', array_values($discovered));
        }

        // Delete files
        $this->cleanup($addonPath);
        
        // Reload addons
        $this->container->make('addon.loader')->reload();

        return true;
    }

    /**
     * Get errors
     */
    public function getErrors(): array
    {
        return $this->errors;
    }
}
