<?php

declare(strict_types=1);

namespace ViraMind\Core\Kernel;

use ViraMind\Core\Container\Container;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Main Kernel - Manages application lifecycle
 * Bootstrap → Provider Registration → Hooks → Routes → Middleware → Ready
 */
class Kernel
{
    private Container $container;
    private bool $booted = false;
    private array $providers = [];
    private array $middleware = [];

    public function __construct(Container $container)
    {
        $this->container = $container;
        $this->registerErrorHandler();
    }

    /**
     * Boot the kernel
     */
    public function boot(): void
    {
        if ($this->booted) {
            return;
        }

        try {
            $this->loadConfiguration();
            $this->registerCoreBindings();
            $this->registerProviders();
            $this->bootProviders();
            $this->registerMiddleware();
            $this->loadRoutes();
            $this->loadAddons();
            
            do_action('vrmind_kernel_booted');
            
            $this->booted = true;
        } catch (\Exception $e) {
            $this->handleBootError($e);
        }
    }

    /**
     * Register unified error handler
     */
    private function registerErrorHandler(): void
    {
        set_error_handler(function($errno, $errstr, $errfile, $errline) {
            if (!(error_reporting() & $errno)) {
                return false;
            }
            
            \ViraMind\vrmind_log(
                sprintf('Error [%d]: %s in %s:%d', $errno, $errstr, $errfile, $errline),
                'error'
            );
            
            return true;
        });

        set_exception_handler(function($exception) {
            \ViraMind\vrmind_log(
                sprintf('Exception: %s in %s:%d', $exception->getMessage(), $exception->getFile(), $exception->getLine()),
                'error',
                ['trace' => $exception->getTraceAsString()]
            );
        });
    }

    /**
     * Load configuration files
     */
    private function loadConfiguration(): void
    {
        $configPath = VRMIND_PATH . 'config/';
        $configs = glob($configPath . '*.php');
        
        foreach ($configs as $config) {
            $key = basename($config, '.php');
            $this->container->make('config')->set($key, require $config);
        }
    }

    /**
     * Register core bindings
     */
    private function registerCoreBindings(): void
    {
        $this->container->singleton('kernel', fn() => $this);
        $this->container->singleton('route.registrar', fn() => new RouteRegistrar($this->container));
        $this->container->singleton('middleware.kernel', fn() => new MiddlewareKernel($this->container));
        $this->container->singleton('addon.loader', fn() => new AddonLoader($this->container));
        $this->container->singleton('addon.installer', fn() => new AddonInstaller($this->container));
    }

    /**
     * Register service providers
     */
    private function registerProviders(): void
    {
        $providers = require VRMIND_PATH . 'bootstrap/providers.php';
        
        foreach ($providers as $provider) {
            if (class_exists($provider)) {
                try {
                    $instance = new $provider($this->container);
                    $instance->register();
                    $this->providers[] = $instance;
                } catch (\Exception $e) {
                    \ViraMind\vrmind_log("Failed to register provider {$provider}: " . $e->getMessage(), 'error');
                }
            }
        }
    }

    /**
     * Boot service providers
     */
    private function bootProviders(): void
    {
        foreach ($this->providers as $provider) {
            if (method_exists($provider, 'boot')) {
                try {
                    $provider->boot();
                } catch (\Exception $e) {
                    \ViraMind\vrmind_log("Failed to boot provider: " . $e->getMessage(), 'error');
                }
            }
        }
    }

    /**
     * Register middleware
     */
    private function registerMiddleware(): void
    {
        $middlewareKernel = $this->container->make('middleware.kernel');
        
        $middlewareKernel->register('nonce', \ViraMind\Core\Middleware\NonceMiddleware::class);
        $middlewareKernel->register('rate_limit', \ViraMind\Core\Middleware\RateLimitMiddleware::class);
        $middlewareKernel->register('ai_security', \ViraMind\Core\Middleware\AISecurityMiddleware::class);
        $middlewareKernel->register('auth', \ViraMind\Core\Middleware\AuthMiddleware::class);
    }

    /**
     * Load routes
     */
    private function loadRoutes(): void
    {
        $registrar = $this->container->make('route.registrar');
        
        $routes = [
            'admin' => VRMIND_PATH . 'routes/admin.php',
            'api' => VRMIND_PATH . 'routes/api.php',
            'ajax' => VRMIND_PATH . 'routes/ajax.php',
            'web' => VRMIND_PATH . 'routes/web.php',
        ];
        
        foreach ($routes as $type => $file) {
            if (file_exists($file)) {
                $registrar->loadRoutes($file, $type);
            }
        }
    }

    /**
     * Load addons
     */
    private function loadAddons(): void
    {
        $loader = $this->container->make('addon.loader');
        $loader->discover();
        $loader->load();
    }

    /**
     * Handle boot errors
     */
    private function handleBootError(\Exception $e): void
    {
        \ViraMind\vrmind_log('Kernel boot failed: ' . $e->getMessage(), 'error', [
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString()
        ]);

        if (defined('WP_DEBUG') && WP_DEBUG) {
            wp_die(
                '<h1>Vira Mind Boot Error</h1>' .
                '<p>' . esc_html($e->getMessage()) . '</p>' .
                '<pre>' . esc_html($e->getTraceAsString()) . '</pre>'
            );
        }
    }

    /**
     * Check if kernel is booted
     */
    public function isBooted(): bool
    {
        return $this->booted;
    }

    /**
     * Get registered providers
     */
    public function getProviders(): array
    {
        return $this->providers;
    }
}
