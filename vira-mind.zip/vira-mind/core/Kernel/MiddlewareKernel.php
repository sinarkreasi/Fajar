<?php

declare(strict_types=1);

namespace ViraMind\Core\Kernel;

use ViraMind\Core\Container\Container;
use ViraMind\Core\Middleware\Request;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Middleware Kernel - Manages middleware pipeline
 */
class MiddlewareKernel
{
    private Container $container;
    private array $middleware = [];
    private array $routeMiddleware = [];

    public function __construct(Container $container)
    {
        $this->container = $container;
    }

    /**
     * Register middleware
     */
    public function register(string $name, string $class): void
    {
        $this->middleware[$name] = $class;
    }

    /**
     * Run middleware pipeline
     */
    public function handle(Request $request, array $middlewareList): mixed
    {
        $pipeline = array_reduce(
            array_reverse($middlewareList),
            $this->carry(),
            $this->prepareDestination()
        );

        return $pipeline($request);
    }

    /**
     * Prepare destination
     */
    private function prepareDestination(): callable
    {
        return function($request) {
            return $request;
        };
    }

    /**
     * Carry middleware
     */
    private function carry(): callable
    {
        return function($stack, $middleware) {
            return function($request) use ($stack, $middleware) {
                $middlewareClass = $this->middleware[$middleware] ?? null;
                
                if (!$middlewareClass || !class_exists($middlewareClass)) {
                    return $stack($request);
                }

                $instance = new $middlewareClass();
                return $instance->handle($request, $stack);
            };
        };
    }

    /**
     * Get registered middleware
     */
    public function getMiddleware(): array
    {
        return $this->middleware;
    }
}
