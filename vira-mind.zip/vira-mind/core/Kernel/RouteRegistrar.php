<?php

declare(strict_types=1);

namespace ViraMind\Core\Kernel;

use ViraMind\Core\Container\Container;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Route Registrar - Manages route registration and caching
 */
class RouteRegistrar
{
    private Container $container;
    private array $routes = [];
    private string $cacheFile;

    public function __construct(Container $container)
    {
        $this->container = $container;
        $this->cacheFile = VRMIND_PATH . 'storage/cache/routes.cache';
    }

    /**
     * Load routes from file
     */
    public function loadRoutes(string $file, string $type): void
    {
        if (!file_exists($file)) {
            return;
        }

        $routes = require $file;
        
        if (is_array($routes)) {
            foreach ($routes as $route) {
                $this->register($route, $type);
            }
        }
    }

    /**
     * Register a route
     */
    public function register(array $route, string $type): void
    {
        $route['type'] = $type;
        $route['enabled'] = $route['enabled'] ?? true;
        
        $this->routes[] = $route;
    }

    /**
     * Get all routes
     */
    public function getRoutes(): array
    {
        return $this->routes;
    }

    /**
     * Get routes by type
     */
    public function getRoutesByType(string $type): array
    {
        return array_filter($this->routes, fn($route) => $route['type'] === $type);
    }

    /**
     * Cache routes
     */
    public function cacheRoutes(): void
    {
        $data = json_encode($this->routes);
        file_put_contents($this->cacheFile, $data);
    }

    /**
     * Load cached routes
     */
    public function loadCachedRoutes(): bool
    {
        if (!file_exists($this->cacheFile)) {
            return false;
        }

        $data = file_get_contents($this->cacheFile);
        $this->routes = json_decode($data, true) ?? [];
        
        return true;
    }

    /**
     * Clear route cache
     */
    public function clearCache(): void
    {
        if (file_exists($this->cacheFile)) {
            unlink($this->cacheFile);
        }
    }
}
