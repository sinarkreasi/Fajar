<?php

declare(strict_types=1);

namespace ViraMind\Core\Kernel;

use ViraMind\Core\Container\ServiceProvider as BaseServiceProvider;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Kernel Service Provider
 */
class ServiceProvider extends BaseServiceProvider
{
    public function register(): void
    {
        $this->app->singleton('router', fn() => new \ViraMind\Core\Support\Router());
        $this->app->singleton('logger', fn() => new \ViraMind\Core\Support\Logger());
    }
}
