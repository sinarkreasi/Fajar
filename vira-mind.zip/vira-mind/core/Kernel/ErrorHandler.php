<?php

declare(strict_types=1);

namespace ViraMind\Core\Kernel;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Error Handler - Centralized error handling and logging
 */
class ErrorHandler
{
    private string $logPath;
    private bool $debugMode;

    public function __construct()
    {
        $this->logPath = VRMIND_PATH . 'storage/logs/';
        $this->debugMode = defined('WP_DEBUG') && WP_DEBUG;
        $this->register();
    }

    /**
     * Register error handlers
     */
    public function register(): void
    {
        set_error_handler([$this, 'handleError']);
        set_exception_handler([$this, 'handleException']);
        register_shutdown_function([$this, 'handleShutdown']);
    }

    /**
     * Handle PHP errors
     */
    public function handleError(int $errno, string $errstr, string $errfile, int $errline): bool
    {
        if (!(error_reporting() & $errno)) {
            return false;
        }

        $this->log('error', sprintf(
            'PHP Error [%d]: %s in %s:%d',
            $errno,
            $errstr,
            $errfile,
            $errline
        ));

        if ($this->debugMode) {
            $this->showAdminNotice('error', $errstr);
        }

        return true;
    }

    /**
     * Handle uncaught exceptions
     */
    public function handleException(\Throwable $exception): void
    {
        $this->log('critical', sprintf(
            'Uncaught Exception: %s in %s:%d',
            $exception->getMessage(),
            $exception->getFile(),
            $exception->getLine()
        ), [
            'trace' => $exception->getTraceAsString()
        ]);

        if ($this->debugMode) {
            $this->showAdminNotice('error', 'Critical error occurred. Check logs for details.');
        }

        if (!headers_sent()) {
            http_response_code(500);
        }
    }

    /**
     * Handle fatal errors on shutdown
     */
    public function handleShutdown(): void
    {
        $error = error_get_last();
        
        if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
            $this->log('critical', sprintf(
                'Fatal Error: %s in %s:%d',
                $error['message'],
                $error['file'],
                $error['line']
            ));
        }
    }

    /**
     * Log message
     */
    private function log(string $level, string $message, array $context = []): void
    {
        $logFile = $this->logPath . 'core-' . current_time('Y-m-d') . '.log';
        
        if (!is_dir($this->logPath)) {
            wp_mkdir_p($this->logPath);
        }

        $timestamp = current_time('Y-m-d H:i:s');
        $contextStr = !empty($context) ? json_encode($context) : '';
        $logMessage = sprintf("[%s] %s: %s %s\n", $timestamp, strtoupper($level), $message, $contextStr);
        
        file_put_contents($logFile, $logMessage, FILE_APPEND);
    }

    /**
     * Show admin notice
     */
    private function showAdminNotice(string $type, string $message): void
    {
        add_action('admin_notices', function() use ($type, $message) {
            printf(
                '<div class="notice notice-%s is-dismissible"><p><strong>Vira Mind:</strong> %s</p></div>',
                esc_attr($type),
                esc_html($message)
            );
        });
    }

    /**
     * Log custom error
     */
    public static function logError(string $message, string $level = 'error', array $context = []): void
    {
        $handler = new self();
        $handler->log($level, $message, $context);
    }
}
