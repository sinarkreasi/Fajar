<?php

declare(strict_types=1);

namespace ViraMind\Core\Kernel;

use ViraMind\Core\Container\Container;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Application Kernel
 */
class Application extends Container
{
    private static ?Application $instance = null;
    private bool $booted = false;
    private array $providers = [];

    private function __construct()
    {
        $this->registerBaseBindings();
    }

    public static function getInstance(): Application
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function registerBaseBindings(): void
    {
        $this->singleton('app', fn() => $this);
        $this->singleton('config', fn() => new \ViraMind\Core\Support\Config());
    }

    public function boot(): void
    {
        if ($this->booted) {
            return;
        }

        // Use new Kernel for boot process
        $kernel = new Kernel($this);
        $kernel->boot();
        
        do_action('vrmind_booted');
        
        $this->booted = true;
    }

    private function loadConfig(): void
    {
        $configPath = VRMIND_PATH . 'config/';
        $configs = glob($configPath . '*.php');
        
        foreach ($configs as $config) {
            $key = basename($config, '.php');
            $this->make('config')->set($key, require $config);
        }
    }

    private function registerProviders(): void
    {
        $providers = require VRMIND_PATH . 'bootstrap/providers.php';
        
        foreach ($providers as $provider) {
            if (class_exists($provider)) {
                $instance = new $provider($this);
                $instance->register();
                $this->providers[] = $instance;
            }
        }
    }

    private function bootProviders(): void
    {
        foreach ($this->providers as $provider) {
            if (method_exists($provider, 'boot')) {
                $provider->boot();
            }
        }
    }

    private function loadRoutes(): void
    {
        $router = $this->make('router');
        
        $routes = [
            'admin' => VRMIND_PATH . 'routes/admin.php',
            'api' => VRMIND_PATH . 'routes/api.php',
            'ajax' => VRMIND_PATH . 'routes/ajax.php',
            'web' => VRMIND_PATH . 'routes/web.php',
        ];
        
        foreach ($routes as $type => $file) {
            if (file_exists($file)) {
                require $file;
            }
        }
    }

    public function isBooted(): bool
    {
        return $this->booted;
    }
}
