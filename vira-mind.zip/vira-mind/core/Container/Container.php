<?php

declare(strict_types=1);

namespace ViraMind\Core\Container;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Service Container
 */
class Container
{
    protected array $bindings = [];
    protected array $instances = [];
    protected array $aliases = [];

    /**
     * Bind a service
     */
    public function bind(string $abstract, callable|string|null $concrete = null, bool $shared = false): void
    {
        if ($concrete === null) {
            $concrete = $abstract;
        }

        $this->bindings[$abstract] = [
            'concrete' => $concrete,
            'shared' => $shared,
        ];
    }

    /**
     * Bind a singleton
     */
    public function singleton(string $abstract, callable|string|null $concrete = null): void
    {
        $this->bind($abstract, $concrete, true);
    }

    /**
     * Resolve a service
     */
    public function make(string $abstract): mixed
    {
        // Check for alias
        if (isset($this->aliases[$abstract])) {
            $abstract = $this->aliases[$abstract];
        }

        // Return existing instance if singleton
        if (isset($this->instances[$abstract])) {
            return $this->instances[$abstract];
        }

        // Resolve the concrete
        $concrete = $this->bindings[$abstract]['concrete'] ?? $abstract;
        
        $object = $this->build($concrete);

        // Store if singleton
        if (isset($this->bindings[$abstract]['shared']) && $this->bindings[$abstract]['shared']) {
            $this->instances[$abstract] = $object;
        }

        return $object;
    }

    /**
     * Build the concrete instance
     */
    protected function build(callable|string $concrete): mixed
    {
        if ($concrete instanceof \Closure) {
            return $concrete($this);
        }

        if (is_string($concrete) && class_exists($concrete)) {
            return new $concrete();
        }

        return $concrete;
    }

    /**
     * Register an alias
     */
    public function alias(string $abstract, string $alias): void
    {
        $this->aliases[$alias] = $abstract;
    }

    /**
     * Check if bound
     */
    public function bound(string $abstract): bool
    {
        return isset($this->bindings[$abstract]) || isset($this->instances[$abstract]);
    }
}
