<?php

declare(strict_types=1);

namespace ViraMind\Core\Container;

use ViraMind\Core\Kernel\Application;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Base Service Provider
 */
abstract class ServiceProvider
{
    protected Application $app;

    public function __construct(Application $app)
    {
        $this->app = $app;
    }

    /**
     * Register services
     */
    abstract public function register(): void;

    /**
     * Boot services (optional)
     */
    public function boot(): void
    {
        // Override in child classes if needed
    }
}
