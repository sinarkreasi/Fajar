<?php

declare(strict_types=1);

namespace ViraMind\Services\Cache;

use ViraMind\Core\Container\ServiceProvider;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Cache Service Provider
 */
class CacheServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->singleton('cache', fn() => new CacheManager($this->app));
    }
}
