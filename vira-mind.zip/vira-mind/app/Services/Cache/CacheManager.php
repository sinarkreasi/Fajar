<?php

declare(strict_types=1);

namespace ViraMind\Services\Cache;

use ViraMind\Core\Kernel\Application;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Cache Manager
 */
class CacheManager
{
    private Application $app;
    private string $driver;

    public function __construct(Application $app)
    {
        $this->app = $app;
        $this->driver = vrmind_config('cache.driver', 'file');
    }

    public function get(string $key): mixed
    {
        if ($this->driver === 'transient') {
            return get_transient($key);
        }

        $file = $this->getCacheFile($key);
        if (!file_exists($file)) {
            return null;
        }

        $data = json_decode(file_get_contents($file), true);
        
        if ($data['expires_at'] < time()) {
            $this->forget($key);
            return null;
        }

        return $data['value'];
    }

    public function set(string $key, mixed $value, int $ttl = 3600): void
    {
        if ($this->driver === 'transient') {
            set_transient($key, $value, $ttl);
            return;
        }

        $file = $this->getCacheFile($key);
        $data = [
            'value' => $value,
            'expires_at' => time() + $ttl,
        ];

        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
        file_put_contents($file, json_encode($data));
    }

    public function forget(string $key): void
    {
        if ($this->driver === 'transient') {
            delete_transient($key);
            return;
        }

        $file = $this->getCacheFile($key);
        if (file_exists($file)) {
            unlink($file);
        }
    }

    public function flush(): void
    {
        $cacheDir = VRMIND_PATH . 'storage/cache/';
        $files = glob($cacheDir . '*.cache');
        
        foreach ($files as $file) {
            unlink($file);
        }
    }

    private function getCacheFile(string $key): string
    {
        return VRMIND_PATH . 'storage/cache/' . md5($key) . '.cache';
    }
}
