<?php

declare(strict_types=1);

namespace ViraMind\Services\Queue;

use ViraMind\Core\Kernel\Application;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Queue Manager
 */
class QueueManager
{
    private Application $app;
    private string $queuePath;

    public function __construct(Application $app)
    {
        $this->app = $app;
        $this->queuePath = VRMIND_PATH . 'storage/queue/';
    }

    public function push(Job $job): void
    {
        $id = uniqid('job_', true);
        $file = $this->queuePath . $id . '.json';
        
        $data = [
            'id' => $id,
            'job' => serialize($job),
            'attempts' => 0,
            'created_at' => time(),
        ];

        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
        file_put_contents($file, json_encode($data));
    }

    public function process(int $limit = 10): void
    {
        $files = glob($this->queuePath . '*.json');
        $processed = 0;

        foreach ($files as $file) {
            if ($processed >= $limit) {
                break;
            }

            $data = json_decode(file_get_contents($file), true);
            $job = unserialize($data['job']);

            try {
                $job->handle();
                unlink($file);
                $processed++;
            } catch (\Exception $e) {
                $data['attempts']++;
                
                if ($data['attempts'] >= 3) {
                    // Move to dead letter
                    $deadFile = VRMIND_PATH . 'storage/queue/dead/' . basename($file);
                    rename($file, $deadFile);
                } else {
                    // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
                    file_put_contents($file, json_encode($data));
                }
                
                vrmind_log('Queue job failed: ' . $e->getMessage(), 'error');
            }
        }
    }
}
