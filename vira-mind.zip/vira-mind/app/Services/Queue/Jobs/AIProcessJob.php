<?php

declare(strict_types=1);

namespace ViraMind\Services\Queue\Jobs;

use ViraMind\Services\Queue\Job;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * AI Process Job
 */
class AIProcessJob extends Job
{
    public function __construct(
        private string $prompt,
        private array $options = []
    ) {}

    public function handle(): void
    {
        $router = \ViraMind\vrmind()->make('ai.router');
        $response = $router->route($this->prompt, $this->options);
        
        // Process the response
        vrmind_log('AI job processed: ' . $this->prompt);
    }
}
