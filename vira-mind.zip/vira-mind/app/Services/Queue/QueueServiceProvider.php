<?php

declare(strict_types=1);

namespace ViraMind\Services\Queue;

use ViraMind\Core\Container\ServiceProvider;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Queue Service Provider
 */
class QueueServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->singleton('queue', fn() => new QueueManager($this->app));
    }

    public function boot(): void
    {
        // Register cron job for queue worker
        if (!wp_next_scheduled('vrmind_process_queue')) {
            wp_schedule_event(time(), 'hourly', 'vrmind_process_queue');
        }

        add_action('vrmind_process_queue', [$this, 'processQueue']);
    }

    public function processQueue(): void
    {
        $this->app->make('queue')->process();
    }
}
