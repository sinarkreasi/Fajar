<?php

declare(strict_types=1);

namespace ViraMind\Services\Queue;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Base Job class
 */
abstract class Job
{
    abstract public function handle(): void;
}
