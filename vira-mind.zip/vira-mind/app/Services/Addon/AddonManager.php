<?php

declare(strict_types=1);

namespace ViraMind\Services\Addon;

use ViraMind\Core\Kernel\Application;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Addon Manager
 */
class AddonManager
{
    private Application $app;
    private array $addons = [];

    public function __construct(Application $app)
    {
        $this->app = $app;
    }

    public function register(array $config): void
    {
        $name = $config['name'] ?? '';
        
        if (empty($name)) {
            return;
        }

        $this->addons[$name] = $config;

        // Register providers
        if (isset($config['providers'])) {
            foreach ($config['providers'] as $provider) {
                if (class_exists($provider)) {
                    $instance = new $provider($this->app);
                    $instance->register();
                    
                    if (method_exists($instance, 'boot')) {
                        $instance->boot();
                    }
                }
            }
        }

        do_action('vrmind_addon_loaded', $name, $config);
    }

    public function get(string $name): ?array
    {
        return $this->addons[$name] ?? null;
    }

    public function all(): array
    {
        return $this->addons;
    }

    public function isLoaded(string $name): bool
    {
        return isset($this->addons[$name]);
    }
}
