<?php

declare(strict_types=1);

namespace ViraMind\Services\Addon;

use ViraMind\Core\Container\ServiceProvider;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Addon Service Provider
 */
class AddonServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->singleton('addon.manager', fn() => new AddonManager($this->app));
    }

    public function boot(): void
    {
        add_action('init', function() {
            \ViraMind\vrmind_register_addons();
        });
    }
}
