<?php

declare(strict_types=1);

namespace ViraMind\Services\AI;

use ViraMind\Core\Container\ServiceProvider;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * AI Manager Service Provider
 */
class AIManagerServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->singleton('ai.manager', fn() => new AIManager($this->app));
    }

    public function boot(): void
    {
        // Register AI event listeners
        $this->app->make('events')->listen('ai.response', function($event, $payload) {
            \ViraMind\vrmind_log('AI Response generated', 'info', [
                'driver' => $payload['driver'] ?? 'unknown',
                'execution_time' => $payload['execution_time'] ?? 0
            ]);
        });
    }
}
