<?php

declare(strict_types=1);

namespace ViraMind\Services\AI\Events;

use ViraMind\Core\Events\Event;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * AI Response Event
 */
class AIResponseEvent extends Event
{
    public function __construct(
        public readonly string $prompt,
        public readonly string $response,
        public readonly bool $cached = false
    ) {
        parent::__construct([
            'prompt' => $prompt,
            'response' => $response,
            'cached' => $cached,
        ]);
    }
}
