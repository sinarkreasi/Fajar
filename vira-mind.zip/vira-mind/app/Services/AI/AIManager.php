<?php

declare(strict_types=1);

namespace ViraMind\Services\AI;

use ViraMind\Core\Kernel\Application;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * AI Manager - Enhanced AI engine with multi-driver support
 */
class AIManager
{
    private Application $app;
    private array $drivers = [];
    private array $tokenUsage = [];
    private int $retryAttempts = 3;

    public function __construct(Application $app)
    {
        $this->app = $app;
        $this->loadDrivers();
    }

    /**
     * Execute AI request
     */
    public function execute(string $prompt, array $options = []): AIResponse
    {
        $driver = $options['driver'] ?? \ViraMind\vrmind_config('ai.default_provider', 'openai');
        $attempt = 0;
        $lastError = null;

        while ($attempt < $this->retryAttempts) {
            try {
                $response = $this->executeWithDriver($driver, $prompt, $options);
                $this->trackTokenUsage($driver, $response);
                return $response;
            } catch (\Exception $e) {
                $lastError = $e;
                $attempt++;
                
                if ($attempt < $this->retryAttempts) {
                    sleep(pow(2, $attempt)); // Exponential backoff
                }
            }
        }

        throw new \Exception("AI request failed after {$this->retryAttempts} attempts: " . $lastError->getMessage());
    }

    /**
     * Execute with specific driver
     */
    private function executeWithDriver(string $driver, string $prompt, array $options): AIResponse
    {
        if (!isset($this->drivers[$driver])) {
            throw new \Exception("AI driver '{$driver}' not found");
        }

        $driverInstance = $this->drivers[$driver];
        
        if (!$driverInstance->isAvailable()) {
            throw new \Exception("AI driver '{$driver}' is not available");
        }

        $sanitizedPrompt = $this->sanitizePrompt($prompt);
        $fingerprint = $this->generateFingerprint($sanitizedPrompt, $options);
        
        // Check cache
        $cached = $this->app->make('cache')->get($fingerprint);
        if ($cached !== null) {
            return new AIResponse($cached, true);
        }

        // Execute
        $startTime = microtime(true);
        $result = $driverInstance->execute($sanitizedPrompt, $options);
        $executionTime = microtime(true) - $startTime;

        // Cache result
        $ttl = $options['cache_ttl'] ?? \ViraMind\vrmind_config('ai.cache_ttl', 3600);
        $this->app->make('cache')->set($fingerprint, $result, $ttl);

        // Dispatch event
        $this->app->make('events')->dispatch('ai.response', [
            'prompt' => $sanitizedPrompt,
            'response' => $result,
            'driver' => $driver,
            'execution_time' => $executionTime
        ]);

        return new AIResponse($result, false, [
            'driver' => $driver,
            'execution_time' => $executionTime
        ]);
    }

    /**
     * Queue AI request
     */
    public function queue(string $prompt, array $options = []): void
    {
        $job = new \ViraMind\Services\Queue\Jobs\AIProcessJob($prompt, $options);
        $this->app->make('queue')->push($job);
    }

    /**
     * Sanitize prompt
     */
    private function sanitizePrompt(string $prompt): string
    {
        return wp_kses_post(trim($prompt));
    }

    /**
     * Generate fingerprint
     */
    private function generateFingerprint(string $prompt, array $options): string
    {
        $data = $prompt . serialize($options);
        return 'vrmind_ai_' . md5($data);
    }

    /**
     * Track token usage
     */
    private function trackTokenUsage(string $driver, AIResponse $response): void
    {
        if (!isset($this->tokenUsage[$driver])) {
            $this->tokenUsage[$driver] = 0;
        }

        $tokens = $response->getMetadata('tokens') ?? 0;
        $this->tokenUsage[$driver] += $tokens;

        update_option('vrmind_token_usage_' . $driver, $this->tokenUsage[$driver]);
    }

    /**
     * Get token usage
     */
    public function getTokenUsage(string $driver = null): int|array
    {
        if ($driver) {
            return get_option('vrmind_token_usage_' . $driver, 0);
        }

        $usage = [];
        foreach (array_keys($this->drivers) as $driverName) {
            $usage[$driverName] = get_option('vrmind_token_usage_' . $driverName, 0);
        }

        return $usage;
    }

    /**
     * Load drivers
     */
    private function loadDrivers(): void
    {
        $providers = \ViraMind\vrmind_config('ai.providers', []);
        
        foreach ($providers as $name => $config) {
            if (isset($config['class']) && class_exists($config['class'])) {
                $this->drivers[$name] = new $config['class']($config);
            }
        }
    }

    /**
     * Register custom driver
     */
    public function registerDriver(string $name, AIProvider $driver): void
    {
        $this->drivers[$name] = $driver;
    }

    /**
     * Get available drivers
     */
    public function getDrivers(): array
    {
        return array_keys($this->drivers);
    }
}
