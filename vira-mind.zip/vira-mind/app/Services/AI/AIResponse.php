<?php

declare(strict_types=1);

namespace ViraMind\Services\AI;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * AI Response
 */
class AIResponse
{
    public function __construct(
        public readonly string $content,
        public readonly bool $cached = false,
        public readonly array $metadata = []
    ) {}

    public function toArray(): array
    {
        return [
            'content' => $this->content,
            'cached' => $this->cached,
            'metadata' => $this->metadata,
        ];
    }

    public function getMetadata(string $key = null): mixed
    {
        if ($key === null) {
            return $this->metadata;
        }

        return $this->metadata[$key] ?? null;
    }
}
