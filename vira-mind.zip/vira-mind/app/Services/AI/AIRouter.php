<?php

declare(strict_types=1);

namespace ViraMind\Services\AI;

use ViraMind\Core\Kernel\Application;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * AI Router Engine
 */
class AIRouter
{
    private Application $app;
    private array $providers = [];

    public function __construct(Application $app)
    {
        $this->app = $app;
    }

    public function route(string $prompt, array $options = []): AIResponse
    {
        $sanitizedPrompt = $this->sanitizeInput($prompt);
        $fingerprint = $this->generateFingerprint($sanitizedPrompt, $options);
        
        // Check cache
        $cached = $this->app->make('cache')->get($fingerprint);
        if ($cached !== null) {
            return new AIResponse($cached, true);
        }

        // Select provider
        $provider = $this->selectProvider($options);
        
        // Execute
        $response = $provider->execute($sanitizedPrompt, $options);
        
        // Cache result
        $this->app->make('cache')->set($fingerprint, $response);
        
        // Dispatch event
        $this->app->make('events')->dispatch('ai.response', ['prompt' => $sanitizedPrompt, 'response' => $response]);
        
        return new AIResponse($response, false);
    }

    private function sanitizeInput(string $input): string
    {
        return wp_kses_post(trim($input));
    }

    private function generateFingerprint(string $prompt, array $options): string
    {
        return 'vrmind_ai_' . md5($prompt . serialize($options));
    }

    private function selectProvider(array $options): AIProvider
    {
        $providerName = $options['provider'] ?? vrmind_config('ai.default_provider', 'openai');
        return $this->app->make('ai.provider')->get($providerName);
    }

    public function registerProvider(string $name, AIProvider $provider): void
    {
        $this->providers[$name] = $provider;
    }
}
