<?php

declare(strict_types=1);

namespace ViraMind\Services\AI;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Base AI Provider
 */
abstract class AIProvider
{
    abstract public function execute(string $prompt, array $options = []): string;
    
    abstract public function getName(): string;
    
    abstract public function isAvailable(): bool;
}
