<?php

declare(strict_types=1);

namespace ViraMind\Services\AI;

use ViraMind\Core\Kernel\Application;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * AI Provider Manager
 */
class AIProviderManager
{
    private Application $app;
    private array $providers = [];

    public function __construct(Application $app)
    {
        $this->app = $app;
        $this->loadProviders();
    }

    private function loadProviders(): void
    {
        $providers = vrmind_config('ai.providers', []);
        
        foreach ($providers as $name => $config) {
            if (isset($config['class']) && class_exists($config['class'])) {
                $this->providers[$name] = new $config['class']($config);
            }
        }
    }

    public function get(string $name): AIProvider
    {
        if (!isset($this->providers[$name])) {
            throw new \Exception("AI Provider '{$name}' not found");
        }

        return $this->providers[$name];
    }

    public function all(): array
    {
        return $this->providers;
    }
}
