<?php

declare(strict_types=1);

namespace ViraMind\Services\AI;

use ViraMind\Core\Container\ServiceProvider;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * AI Service Provider
 */
class AIServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->singleton('ai.router', fn() => new AIRouter($this->app));
        $this->app->singleton('ai.provider', fn() => new AIProviderManager($this->app));
    }
}
