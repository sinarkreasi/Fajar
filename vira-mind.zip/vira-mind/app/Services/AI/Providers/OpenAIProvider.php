<?php

declare(strict_types=1);

namespace ViraMind\Services\AI\Providers;

use ViraMind\Services\AI\AIProvider;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * OpenAI Provider
 */
class OpenAIProvider extends AIProvider
{
    private array $config;

    public function __construct(array $config)
    {
        $this->config = $config;
    }

    public function execute(string $prompt, array $options = []): string
    {
        $apiKey = $this->config['api_key'] ?? '';
        
        if (empty($apiKey)) {
            throw new \Exception('OpenAI API key not configured');
        }

        $model = $options['model'] ?? $this->config['model'] ?? 'gpt-4';
        $temperature = $options['temperature'] ?? 0.7;
        $maxTokens = $options['max_tokens'] ?? 2000;

        $response = wp_remote_post('https://api.openai.com/v1/chat/completions', [
            'headers' => [
                'Authorization' => 'Bearer ' . $apiKey,
                'Content-Type' => 'application/json',
            ],
            'body' => wp_json_encode([
                'model' => $model,
                'messages' => [
                    ['role' => 'user', 'content' => $prompt]
                ],
                'temperature' => $temperature,
                'max_tokens' => $maxTokens,
            ]),
            'timeout' => 30,
        ]);

        if (is_wp_error($response)) {
            throw new \Exception('OpenAI API request failed: ' . $response->get_error_message());
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['error'])) {
            throw new \Exception('OpenAI API error: ' . $body['error']['message']);
        }

        return $body['choices'][0]['message']['content'] ?? 'No response';
    }

    public function getName(): string
    {
        return 'OpenAI';
    }

    public function isAvailable(): bool
    {
        return !empty($this->config['api_key']);
    }
}
