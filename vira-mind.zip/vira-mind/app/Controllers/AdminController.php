<?php

declare(strict_types=1);

namespace ViraMind\Controllers;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Admin Controller
 */
class AdminController
{
    public function dashboard(): void
    {
        require_once VRMIND_PATH . 'resources/views/admin/dashboard.php';
    }

    public function settings(): void
    {
        // Settings page logic
    }
}
