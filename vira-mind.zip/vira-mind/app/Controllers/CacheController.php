<?php

declare(strict_types=1);

namespace ViraMind\Controllers;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Cache Controller
 */
class CacheController
{
    public function index(): void
    {
        if (isset($_POST['vrmind_clear_cache'])) {
            $this->clearCache();
        }
        
        $data = [
            'cache_items' => $this->getCacheItems(),
            'total_size' => $this->getTotalSize(),
            'driver' => \ViraMind\vrmind_config('cache.driver', 'file'),
        ];
        
        require_once VRMIND_PATH . 'resources/views/admin/cache.php';
    }

    private function clearCache(): void
    {
        check_admin_referer('vrmind_cache', 'vrmind_cache_nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Unauthorized', 'vira-mind'));
        }

        \ViraMind\vrmind()->make('cache')->flush();
        
        add_settings_error('vrmind_cache', 'cache_cleared', __('Cache cleared successfully', 'vira-mind'), 'success');
    }

    private function getCacheItems(): array
    {
        $cacheDir = VRMIND_PATH . 'storage/cache/';
        $files = glob($cacheDir . '*.cache');
        $items = [];
        
        foreach ($files as $file) {
            $items[] = [
                'key' => basename($file, '.cache'),
                'size' => filesize($file),
                'modified' => filemtime($file),
            ];
        }
        
        return $items;
    }

    private function getTotalSize(): int
    {
        $cacheDir = VRMIND_PATH . 'storage/cache/';
        $files = glob($cacheDir . '*.cache');
        $total = 0;
        
        foreach ($files as $file) {
            $total += filesize($file);
        }
        
        return $total;
    }
}
