<?php

declare(strict_types=1);

namespace ViraMind\Controllers;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Queue Controller
 */
class QueueController
{
    public function index(): void
    {
        if (isset($_POST['vrmind_process_queue'])) {
            $this->processQueue();
        }
        
        if (isset($_POST['vrmind_clear_failed'])) {
            $this->clearFailed();
        }
        
        $data = [
            'pending_jobs' => $this->getPendingJobs(),
            'failed_jobs' => $this->getFailedJobs(),
        ];
        
        require_once VRMIND_PATH . 'resources/views/admin/queue.php';
    }

    private function processQueue(): void
    {
        check_admin_referer('vrmind_queue', 'vrmind_queue_nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Unauthorized', 'vira-mind'));
        }

        \ViraMind\vrmind()->make('queue')->process(10);
        
        add_settings_error('vrmind_queue', 'queue_processed', __('Queue processed', 'vira-mind'), 'success');
    }

    private function clearFailed(): void
    {
        check_admin_referer('vrmind_queue', 'vrmind_queue_nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Unauthorized', 'vira-mind'));
        }

        $files = glob(VRMIND_PATH . 'storage/queue/dead/*.json');
        foreach ($files as $file) {
            unlink($file);
        }
        
        add_settings_error('vrmind_queue', 'failed_cleared', __('Failed jobs cleared', 'vira-mind'), 'success');
    }

    private function getPendingJobs(): array
    {
        $files = glob(VRMIND_PATH . 'storage/queue/*.json');
        $jobs = [];
        
        foreach ($files as $file) {
            $data = json_decode(file_get_contents($file), true);
            $jobs[] = [
                'id' => $data['id'] ?? 'unknown',
                'attempts' => $data['attempts'] ?? 0,
                'created' => date('Y-m-d H:i:s', $data['created_at'] ?? time()),
            ];
        }
        
        return $jobs;
    }

    private function getFailedJobs(): array
    {
        $files = glob(VRMIND_PATH . 'storage/queue/dead/*.json');
        $jobs = [];
        
        foreach ($files as $file) {
            $data = json_decode(file_get_contents($file), true);
            $jobs[] = [
                'id' => $data['id'] ?? 'unknown',
                'attempts' => $data['attempts'] ?? 0,
                'created' => date('Y-m-d H:i:s', $data['created_at'] ?? time()),
            ];
        }
        
        return $jobs;
    }
}
