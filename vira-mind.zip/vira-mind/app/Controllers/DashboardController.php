<?php

declare(strict_types=1);

namespace ViraMind\Controllers;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Dashboard Controller
 */
class DashboardController
{
    public function index(): void
    {
        $data = [
            'system_health' => $this->getSystemHealth(),
            'ai_status' => $this->getAIStatus(),
            'cache_status' => $this->getCacheStatus(),
            'queue_status' => $this->getQueueStatus(),
            'recent_logs' => $this->getRecentLogs(),
        ];
        
        require_once VRMIND_PATH . 'resources/views/admin/dashboard.php';
    }

    private function getSystemHealth(): array
    {
        return [
            'php_version' => PHP_VERSION,
            'php_ok' => version_compare(PHP_VERSION, '8.2.0', '>='),
            'wp_version' => get_bloginfo('version'),
            'wp_ok' => version_compare(get_bloginfo('version'), '6.8', '>='),
            'memory_limit' => ini_get('memory_limit'),
            'memory_ok' => $this->parseMemory(ini_get('memory_limit')) >= 128,
            'curl_enabled' => function_exists('curl_version'),
            'json_enabled' => function_exists('json_encode'),
            'mbstring_enabled' => function_exists('mb_strlen'),
            'storage_writable' => is_writable(VRMIND_PATH . 'storage'),
        ];
    }

    private function getAIStatus(): array
    {
        $apiKey = get_option('vrmind_openai_key', '');
        
        return [
            'provider' => \ViraMind\vrmind_config('ai.default_provider', 'openai'),
            'configured' => !empty($apiKey),
            'model' => \ViraMind\vrmind_config('ai.providers.openai.model', 'gpt-4'),
        ];
    }

    private function getCacheStatus(): array
    {
        $cacheDir = VRMIND_PATH . 'storage/cache/';
        $files = glob($cacheDir . '*.cache');
        $totalSize = 0;
        
        foreach ($files as $file) {
            $totalSize += filesize($file);
        }
        
        return [
            'driver' => \ViraMind\vrmind_config('cache.driver', 'file'),
            'items' => count($files),
            'size' => $this->formatBytes($totalSize),
        ];
    }

    private function getQueueStatus(): array
    {
        $queueDir = VRMIND_PATH . 'storage/queue/';
        $pending = glob($queueDir . '*.json');
        $failed = glob($queueDir . 'dead/*.json');
        
        return [
            'pending' => count($pending),
            'failed' => count($failed),
            'driver' => \ViraMind\vrmind_config('queue.driver', 'file'),
        ];
    }

    private function getRecentLogs(): array
    {
        $logFile = VRMIND_PATH . 'storage/logs/vira-mind-' . current_time('Y-m-d') . '.log';
        
        if (!file_exists($logFile)) {
            return [];
        }
        
        $lines = file($logFile);
        $recent = array_slice($lines, -5);
        
        return array_map(function($line) {
            if (preg_match('/\[(.*?)\] (.*?): (.*)/', $line, $matches)) {
                return [
                    'time' => $matches[1],
                    'level' => strtolower($matches[2]),
                    'message' => $matches[3],
                ];
            }
            return null;
        }, $recent);
    }

    private function parseMemory(string $memory): int
    {
        $unit = strtoupper(substr($memory, -1));
        $value = (int) $memory;
        
        switch ($unit) {
            case 'G':
                return $value * 1024;
            case 'M':
                return $value;
            default:
                return $value / 1024 / 1024;
        }
    }

    private function formatBytes(int $bytes): string
    {
        if ($bytes >= 1073741824) {
            return number_format($bytes / 1073741824, 2) . ' GB';
        } elseif ($bytes >= 1048576) {
            return number_format($bytes / 1048576, 2) . ' MB';
        } elseif ($bytes >= 1024) {
            return number_format($bytes / 1024, 2) . ' KB';
        }
        return $bytes . ' B';
    }
}
