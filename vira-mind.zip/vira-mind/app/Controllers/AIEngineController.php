<?php

declare(strict_types=1);

namespace ViraMind\Controllers;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * AI Engine Controller
 */
class AIEngineController
{
    public function index(): void
    {
        if (isset($_POST['vrmind_save_ai_settings'])) {
            $this->save();
        }
        
        $data = [
            'providers' => $this->getProviders(),
            'current_provider' => \ViraMind\vrmind_config('ai.default_provider', 'openai'),
            'api_key' => get_option('vrmind_openai_key', ''),
            'model' => \ViraMind\vrmind_config('ai.providers.openai.model', 'gpt-4'),
            'timeout' => \ViraMind\vrmind_config('ai.timeout', 30),
            'max_tokens' => \ViraMind\vrmind_config('ai.max_tokens', 2000),
            'temperature' => \ViraMind\vrmind_config('ai.temperature', 0.7),
        ];
        
        require_once VRMIND_PATH . 'resources/views/admin/ai-engine.php';
    }

    private function save(): void
    {
        check_admin_referer('vrmind_ai_settings', 'vrmind_ai_nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Unauthorized', 'vira-mind'));
        }

        update_option('vrmind_openai_key', sanitize_text_field($_POST['api_key'] ?? ''));
        update_option('vrmind_ai_provider', sanitize_text_field($_POST['provider'] ?? 'openai'));
        update_option('vrmind_ai_model', sanitize_text_field($_POST['model'] ?? 'gpt-4'));
        update_option('vrmind_ai_timeout', (int) ($_POST['timeout'] ?? 30));
        update_option('vrmind_ai_max_tokens', (int) ($_POST['max_tokens'] ?? 2000));
        update_option('vrmind_ai_temperature', (float) ($_POST['temperature'] ?? 0.7));
        
        add_settings_error('vrmind_ai', 'settings_updated', __('AI settings saved', 'vira-mind'), 'success');
    }

    private function getProviders(): array
    {
        return [
            'openai' => ['name' => 'OpenAI', 'icon' => '🤖'],
            'local' => ['name' => 'Local Model', 'icon' => '💻'],
        ];
    }
}
