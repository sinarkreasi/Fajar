<?php

declare(strict_types=1);

namespace ViraMind\Controllers;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Logs Controller
 */
class LogsController
{
    public function index(): void
    {
        $level = sanitize_text_field($_GET['level'] ?? 'all');
        $search = sanitize_text_field($_GET['search'] ?? '');
        
        $data = [
            'logs' => $this->getLogs($level, $search),
            'current_level' => $level,
            'search' => $search,
        ];
        
        require_once VRMIND_PATH . 'resources/views/admin/logs.php';
    }

    private function getLogs(string $level, string $search): array
    {
        $logFile = VRMIND_PATH . 'storage/logs/vira-mind-' . current_time('Y-m-d') . '.log';
        
        if (!file_exists($logFile)) {
            return [];
        }
        
        $lines = file($logFile);
        $logs = [];
        
        foreach ($lines as $line) {
            if (preg_match('/\[(.*?)\] (.*?): (.*)/', $line, $matches)) {
                $logLevel = strtolower($matches[2]);
                $message = $matches[3];
                
                if ($level !== 'all' && $logLevel !== $level) {
                    continue;
                }
                
                if (!empty($search) && stripos($message, $search) === false) {
                    continue;
                }
                
                $logs[] = [
                    'time' => $matches[1],
                    'level' => $logLevel,
                    'message' => $message,
                ];
            }
        }
        
        return array_reverse($logs);
    }
}
