<?php

declare(strict_types=1);

namespace ViraMind\Controllers;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Addons Controller
 */
class AddonsController
{
    public function index(): void
    {
        // Handle addon upload
        if (isset($_POST['vrmind_upload_addon']) && isset($_FILES['addon_file'])) {
            $this->uploadAddon();
        }

        // Handle addon uninstall
        if (isset($_POST['vrmind_uninstall_addon'])) {
            $this->uninstallAddon();
        }

        // Handle addon activate
        if (isset($_POST['vrmind_activate_addon'])) {
            $this->activateAddon();
        }

        // Handle addon deactivate
        if (isset($_POST['vrmind_deactivate_addon'])) {
            $this->deactivateAddon();
        }

        $data = [
            'addons' => $this->getAddons(),
        ];
        
        require_once VRMIND_PATH . 'resources/views/admin/addons.php';
    }

    private function uploadAddon(): void
    {
        check_admin_referer('vrmind_upload_addon', 'vrmind_addon_nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Unauthorized', 'vira-mind'));
        }

        try {
            $installer = \ViraMind\vrmind()->make('addon.installer');
            $result = $installer->install($_FILES['addon_file']);

            if ($result['success']) {
                add_settings_error(
                    'vrmind_addons',
                    'addon_installed',
                    sprintf(__('✓ Addon "%s" installed successfully!', 'vira-mind'), $result['addon']['name']),
                    'success'
                );
                
                // Auto-activate
                $slug = $result['addon']['slug'];
                $active = get_option('vrmind_active_addons', []);
                if (!in_array($slug, $active)) {
                    $active[] = $slug;
                    update_option('vrmind_active_addons', $active);
                }
            } else {
                $errorMsg = !empty($result['errors']) 
                    ? implode(', ', $result['errors']) 
                    : 'Unknown error occurred';
                    
                add_settings_error(
                    'vrmind_addons',
                    'addon_failed',
                    __('❌ Failed to install addon: ', 'vira-mind') . $errorMsg,
                    'error'
                );
                
                // Log for debugging
                error_log('Addon upload failed: ' . $errorMsg);
            }
        } catch (\Exception $e) {
            add_settings_error(
                'vrmind_addons',
                'addon_exception',
                __('❌ Error: ', 'vira-mind') . $e->getMessage(),
                'error'
            );
            
            error_log('Addon upload exception: ' . $e->getMessage());
            error_log($e->getTraceAsString());
        }
    }

    private function uninstallAddon(): void
    {
        check_admin_referer('vrmind_uninstall_addon', 'vrmind_addon_nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Unauthorized', 'vira-mind'));
        }

        $slug = sanitize_text_field($_POST['addon_slug'] ?? '');
        
        if (empty($slug)) {
            return;
        }

        $installer = \ViraMind\vrmind()->make('addon.installer');
        
        if ($installer->uninstall($slug)) {
            add_settings_error(
                'vrmind_addons',
                'addon_uninstalled',
                __('Addon uninstalled successfully', 'vira-mind'),
                'success'
            );
        } else {
            add_settings_error(
                'vrmind_addons',
                'addon_uninstall_failed',
                __('Failed to uninstall addon', 'vira-mind'),
                'error'
            );
        }
    }

    private function activateAddon(): void
    {
        check_admin_referer('vrmind_activate_addon', 'vrmind_addon_nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Unauthorized', 'vira-mind'));
        }

        $slug = sanitize_text_field($_POST['addon_slug'] ?? '');
        
        if (empty($slug)) {
            return;
        }

        $active = get_option('vrmind_active_addons', []);
        if (!in_array($slug, $active)) {
            $active[] = $slug;
            update_option('vrmind_active_addons', $active);
            
            add_settings_error(
                'vrmind_addons',
                'addon_activated',
                __('Addon activated successfully', 'vira-mind'),
                'success'
            );
        }
    }

    private function deactivateAddon(): void
    {
        check_admin_referer('vrmind_deactivate_addon', 'vrmind_addon_nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Unauthorized', 'vira-mind'));
        }

        $slug = sanitize_text_field($_POST['addon_slug'] ?? '');
        
        if (empty($slug)) {
            return;
        }

        $active = get_option('vrmind_active_addons', []);
        $key = array_search($slug, $active);
        
        if ($key !== false) {
            unset($active[$key]);
            update_option('vrmind_active_addons', array_values($active));
            
            add_settings_error(
                'vrmind_addons',
                'addon_deactivated',
                __('Addon deactivated successfully', 'vira-mind'),
                'success'
            );
        }
    }

    private function getAddons(): array
    {
        $loader = \ViraMind\vrmind()->make('addon.loader');
        $addons = $loader->getAddons();
        $active = get_option('vrmind_active_addons', []);
        $result = [];
        
        foreach ($addons as $slug => $addon) {
            $result[] = [
                'slug' => $slug,
                'name' => $addon['name'] ?? 'Unknown',
                'version' => $addon['version'] ?? '1.0.0',
                'description' => $addon['description'] ?? '',
                'author' => $addon['author'] ?? '',
                'active' => in_array($slug, $active),
            ];
        }
        
        return $result;
    }
}
