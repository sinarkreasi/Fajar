<?php

declare(strict_types=1);

namespace ViraMind\Controllers;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Settings Controller
 */
class SettingsController
{
    public function index(): void
    {
        if (isset($_POST['vrmind_save_settings'])) {
            $this->save();
        }
        
        require_once VRMIND_PATH . 'resources/views/admin/settings.php';
    }

    private function save(): void
    {
        check_admin_referer('vrmind_settings', 'vrmind_settings_nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Unauthorized', 'vira-mind'));
        }

        $apiKey = sanitize_text_field($_POST['vrmind_openai_key'] ?? '');
        update_option('vrmind_openai_key', $apiKey);
        
        add_settings_error(
            'vrmind_settings',
            'settings_updated',
            __('Settings saved successfully', 'vira-mind'),
            'success'
        );
    }
}
