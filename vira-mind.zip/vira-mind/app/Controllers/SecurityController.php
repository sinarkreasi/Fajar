<?php

declare(strict_types=1);

namespace ViraMind\Controllers;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Security Controller
 */
class SecurityController
{
    public function index(): void
    {
        if (isset($_POST['vrmind_save_security'])) {
            $this->save();
        }
        
        $data = [
            'rate_limit_enabled' => get_option('vrmind_rate_limit_enabled', true),
            'max_attempts' => get_option('vrmind_max_attempts', 60),
            'nonce_enabled' => get_option('vrmind_nonce_enabled', true),
        ];
        
        require_once VRMIND_PATH . 'resources/views/admin/security.php';
    }

    private function save(): void
    {
        check_admin_referer('vrmind_security', 'vrmind_security_nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Unauthorized', 'vira-mind'));
        }

        update_option('vrmind_rate_limit_enabled', isset($_POST['rate_limit_enabled']));
        update_option('vrmind_max_attempts', (int) ($_POST['max_attempts'] ?? 60));
        update_option('vrmind_nonce_enabled', isset($_POST['nonce_enabled']));
        
        add_settings_error('vrmind_security', 'settings_updated', __('Security settings saved', 'vira-mind'), 'success');
    }
}
