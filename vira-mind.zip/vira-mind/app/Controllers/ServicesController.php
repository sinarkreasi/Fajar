<?php

declare(strict_types=1);

namespace ViraMind\Controllers;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Services Controller
 */
class ServicesController
{
    public function index(): void
    {
        $data = [
            'providers' => $this->getProviders(),
        ];
        
        require_once VRMIND_PATH . 'resources/views/admin/services.php';
    }

    private function getProviders(): array
    {
        $providers = require VRMIND_PATH . 'bootstrap/providers.php';
        $status = [];
        
        foreach ($providers as $provider) {
            $parts = explode('\\', $provider);
            $name = end($parts);
            
            $status[] = [
                'name' => $name,
                'class' => $provider,
                'loaded' => class_exists($provider),
            ];
        }
        
        return $status;
    }
}
