<?php

declare(strict_types=1);

namespace ViraMind\Controllers;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Integrations Controller - Manages third-party integrations
 */
class IntegrationsController
{
    public function index(): void
    {
        $data = [
            'integrations' => $this->getIntegrations(),
            'available' => $this->getAvailableIntegrations(),
        ];
        
        require_once VRMIND_PATH . 'resources/views/admin/integrations.php';
    }

    private function getIntegrations(): array
    {
        $manager = \ViraMind\vrmind()->make('integration.manager');
        $integrations = $manager->getIntegrations();
        $result = [];

        foreach ($integrations as $slug => $integration) {
            $result[] = [
                'slug' => $slug,
                'name' => $integration->getName(),
                'status' => 'active',
                'plugin_active' => $integration->isPluginActive(),
            ];
        }

        return $result;
    }

    private function getAvailableIntegrations(): array
    {
        return [
            'woocommerce' => [
                'name' => 'WooCommerce',
                'description' => 'AI-powered product descriptions and SEO',
                'plugin' => 'woocommerce/woocommerce.php',
                'installed' => is_plugin_active('woocommerce/woocommerce.php'),
            ],
            'learndash' => [
                'name' => 'LearnDash',
                'description' => 'AI course content generation',
                'plugin' => 'sfwd-lms/sfwd_lms.php',
                'installed' => is_plugin_active('sfwd-lms/sfwd_lms.php'),
            ],
            'elementor' => [
                'name' => 'Elementor',
                'description' => 'AI content blocks',
                'plugin' => 'elementor/elementor.php',
                'installed' => is_plugin_active('elementor/elementor.php'),
            ],
        ];
    }
}
