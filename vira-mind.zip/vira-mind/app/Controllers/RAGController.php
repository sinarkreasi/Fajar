<?php

declare(strict_types=1);

namespace ViraMind\Controllers;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * RAG Controller - Manages RAG Engine
 */
class RAGController
{
    public function index(): void
    {
        if (isset($_POST['vrmind_clear_rag_cache'])) {
            $this->clearCache();
        }

        if (isset($_POST['vrmind_compact_shards'])) {
            $this->compactShards();
        }

        $data = [
            'documents' => $this->getDocuments(),
            'stats' => $this->getStats(),
            'cache_stats' => $this->getCacheStats(),
        ];
        
        require_once VRMIND_PATH . 'resources/views/admin/rag.php';
    }

    private function getDocuments(): array
    {
        $registry = new \ViraMind\Core\RAG\Document\DocumentRegistry();
        return $registry->all();
    }

    private function getStats(): array
    {
        $vectorsPath = VRMIND_PATH . 'storage/vectors/';
        $dirs = glob($vectorsPath . '*', GLOB_ONLYDIR);
        
        $totalChunks = 0;
        $totalShards = 0;
        
        foreach ($dirs as $dir) {
            $shards = glob($dir . '/shard-*.json');
            $totalShards += count($shards);
            
            foreach ($shards as $shard) {
                $data = json_decode(file_get_contents($shard), true) ?? [];
                $totalChunks += count($data);
            }
        }

        return [
            'documents' => count($dirs),
            'chunks' => $totalChunks,
            'shards' => $totalShards,
        ];
    }

    private function getCacheStats(): array
    {
        $cache = new \ViraMind\Core\RAG\Support\QueryCache();
        return $cache->getStats();
    }

    private function clearCache(): void
    {
        check_admin_referer('vrmind_rag', 'vrmind_rag_nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Unauthorized', 'vira-mind'));
        }

        $cache = new \ViraMind\Core\RAG\Support\QueryCache();
        $cache->clear();
        
        add_settings_error('vrmind_rag', 'cache_cleared', __('RAG cache cleared', 'vira-mind'), 'success');
    }

    private function compactShards(): void
    {
        check_admin_referer('vrmind_rag', 'vrmind_rag_nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Unauthorized', 'vira-mind'));
        }

        \ViraMind\vrmind_queue(new \ViraMind\Core\RAG\Jobs\ShardCompactionJob());
        
        add_settings_error('vrmind_rag', 'compaction_queued', __('Shard compaction queued', 'vira-mind'), 'success');
    }
}
