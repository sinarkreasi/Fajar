<?php

declare(strict_types=1);

namespace ViraMind\Controllers;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * API Controller
 */
class APIController
{
    public function query(\WP_REST_Request $request): \WP_REST_Response
    {
        $prompt = sanitize_text_field($request->get_param('prompt'));
        
        if (empty($prompt)) {
            return new \WP_REST_Response([
                'error' => 'Prompt is required'
            ], 400);
        }
        
        try {
            $router = \ViraMind\vrmind()->make('ai.router');
            $response = $router->route($prompt);
            
            return new \WP_REST_Response($response->toArray(), 200);
        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'error' => $e->getMessage()
            ], 500);
        }
    }
}
