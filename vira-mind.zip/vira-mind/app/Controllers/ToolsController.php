<?php

declare(strict_types=1);

namespace ViraMind\Controllers;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Tools Controller
 */
class ToolsController
{
    public function index(): void
    {
        if (isset($_POST['vrmind_regenerate_config'])) {
            $this->regenerateConfig();
        }
        
        if (isset($_POST['vrmind_clean_temp'])) {
            $this->cleanTemp();
        }
        
        require_once VRMIND_PATH . 'resources/views/admin/tools.php';
    }

    private function regenerateConfig(): void
    {
        check_admin_referer('vrmind_tools', 'vrmind_tools_nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Unauthorized', 'vira-mind'));
        }

        // Clear cache
        \ViraMind\vrmind()->make('cache')->flush();
        
        add_settings_error('vrmind_tools', 'config_regenerated', __('Config cache regenerated', 'vira-mind'), 'success');
    }

    private function cleanTemp(): void
    {
        check_admin_referer('vrmind_tools', 'vrmind_tools_nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Unauthorized', 'vira-mind'));
        }

        $files = glob(VRMIND_PATH . 'storage/temp/*');
        foreach ($files as $file) {
            if (is_file($file)) {
                unlink($file);
            }
        }
        
        add_settings_error('vrmind_tools', 'temp_cleaned', __('Temp files cleaned', 'vira-mind'), 'success');
    }
}
