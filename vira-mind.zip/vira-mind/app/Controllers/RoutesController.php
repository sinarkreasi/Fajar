<?php

declare(strict_types=1);

namespace ViraMind\Controllers;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Routes Controller
 */
class RoutesController
{
    public function index(): void
    {
        $data = [
            'routes' => $this->getRoutes(),
        ];
        
        require_once VRMIND_PATH . 'resources/views/admin/routes.php';
    }

    private function getRoutes(): array
    {
        return [
            ['method' => 'POST', 'uri' => '/wp-json/vrmind/v1/ai/query', 'controller' => 'APIController@query', 'middleware' => 'auth'],
            ['method' => 'POST', 'uri' => '/wp-admin/admin-ajax.php?action=vrmind_process', 'controller' => 'AjaxController@process', 'middleware' => 'nonce'],
            ['method' => 'GET', 'uri' => '/wp-admin/admin.php?page=vira-mind', 'controller' => 'DashboardController@index', 'middleware' => 'admin'],
        ];
    }
}
