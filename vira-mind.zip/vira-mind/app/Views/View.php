<?php

declare(strict_types=1);

namespace ViraMind\Views;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * View renderer
 */
class View
{
    public static function render(string $view, array $data = []): void
    {
        extract($data);
        
        $viewPath = VRMIND_PATH . 'resources/views/' . str_replace('.', '/', $view) . '.php';
        
        if (file_exists($viewPath)) {
            require $viewPath;
        }
    }

    public static function make(string $view, array $data = []): string
    {
        ob_start();
        self::render($view, $data);
        return ob_get_clean();
    }
}
