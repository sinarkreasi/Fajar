<?php
/**
 * Plugin Name: Vira Mind
 * Plugin URI: https://viramind.dev
 * Description: AI Infrastructure Layer for WordPress
 * Version: 1.0.0
 * Requires at least: 6.8
 * Requires PHP: 8.2
 * Author: Vira Mind Team
 * License: GPL v2 or later
 * Text Domain: vira-mind
 */

declare(strict_types=1);

namespace ViraMind;

if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('VRMIND_VERSION', '1.0.0');
define('VRMIND_PATH', plugin_dir_path(__FILE__));
define('VRMIND_URL', plugin_dir_url(__FILE__));
define('VRMIND_FILE', __FILE__);

// Require Composer autoloader
if (file_exists(VRMIND_PATH . 'vendor/autoload.php')) {
    require_once VRMIND_PATH . 'vendor/autoload.php';
}

// Bootstrap the application
require_once VRMIND_PATH . 'bootstrap/app.php';

// Initialize the plugin
add_action('plugins_loaded', '\ViraMind\vrmind_boot_kernel', 10);

register_activation_hook(__FILE__, '\ViraMind\vrmind_activate');
register_deactivation_hook(__FILE__, '\ViraMind\vrmind_deactivate');
