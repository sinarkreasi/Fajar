<?php

declare(strict_types=1);

namespace ViraMind;

use ViraMind\Core\Kernel\Application;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Load core functionality
 */
function vrmind_load_core(): void
{
    require_once VRMIND_PATH . 'bootstrap/helpers.php';
    require_once VRMIND_PATH . 'bootstrap/providers.php';
}

/**
 * Boot the kernel
 */
function vrmind_boot_kernel(): void
{
    vrmind_load_core();
    
    $app = Application::getInstance();
    $app->boot();
}

/**
 * Register addons
 */
function vrmind_register_addons(): void
{
    $addonsPath = VRMIND_PATH . 'addons';
    
    if (!is_dir($addonsPath)) {
        return;
    }
    
    $addons = glob($addonsPath . '/*/manifest.php');
    
    foreach ($addons as $manifest) {
        if (file_exists($manifest)) {
            $config = require $manifest;
            vrmind()->make('addon.manager')->register($config);
        }
    }
}

/**
 * Plugin activation
 */
function vrmind_activate(): void
{
    // Create storage directories
    $dirs = ['cache', 'logs', 'queue', 'temp'];
    foreach ($dirs as $dir) {
        $path = VRMIND_PATH . 'storage/' . $dir;
        if (!is_dir($path)) {
            wp_mkdir_p($path);
        }
    }
    
    flush_rewrite_rules();
}

/**
 * Plugin deactivation
 */
function vrmind_deactivate(): void
{
    flush_rewrite_rules();
}
