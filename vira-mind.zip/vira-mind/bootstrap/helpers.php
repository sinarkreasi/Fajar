<?php

declare(strict_types=1);

namespace ViraMind;

use ViraMind\Core\Kernel\Application;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Get the application instance
 */
function vrmind(): Application
{
    return Application::getInstance();
}

/**
 * Get a service from the container
 */
function vrmind_make(string $abstract): mixed
{
    return vrmind()->make($abstract);
}

/**
 * Get config value
 */
function vrmind_config(string $key, mixed $default = null): mixed
{
    return vrmind()->make('config')->get($key, $default);
}

/**
 * Log a message
 */
function vrmind_log(string $message, string $level = 'info', array $context = []): void
{
    vrmind()->make('logger')->log($level, $message, $context);
}

/**
 * Get storage path
 */
function vrmind_storage_path(string $path = ''): string
{
    return VRMIND_PATH . 'storage/' . ltrim($path, '/');
}

/**
 * Get config path
 */
function vrmind_config_path(string $path = ''): string
{
    return VRMIND_PATH . 'config/' . ltrim($path, '/');
}

/**
 * Execute AI request
 */
function vrmind_ai(string $prompt, array $options = []): string
{
    $response = vrmind()->make('ai.manager')->execute($prompt, $options);
    return $response->content;
}

/**
 * Queue AI request
 */
function vrmind_ai_queue(string $prompt, array $options = []): void
{
    vrmind()->make('ai.manager')->queue($prompt, $options);
}

/**
 * Register route
 */
function vrmind_route(string $method, string $uri, callable|array $controller, array $middleware = []): void
{
    vrmind()->make('route.registrar')->register([
        'method' => $method,
        'uri' => $uri,
        'controller' => $controller,
        'middleware' => $middleware
    ], 'custom');
}

/**
 * Dispatch event
 */
function vrmind_event(string $event, array $payload = []): void
{
    vrmind()->make('events')->dispatch($event, $payload);
}

/**
 * Queue a job
 */
function vrmind_queue(object $job): void
{
    vrmind()->make('queue')->push($job);
}

/**
 * Cache value
 */
function vrmind_cache(string $key, mixed $value = null, int $ttl = 3600): mixed
{
    $cache = vrmind()->make('cache');
    
    if ($value === null) {
        return $cache->get($key);
    }
    
    $cache->set($key, $value, $ttl);
    return $value;
}

/**
 * Render view
 */
function vrmind_view(string $template, array $data = []): string
{
    return \ViraMind\Views\View::make($template, $data);
}
