<?php

declare(strict_types=1);

namespace ViraMind;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Core service providers
 */
return [
    \ViraMind\Core\Kernel\ServiceProvider::class,
    \ViraMind\Core\Hooks\HooksServiceProvider::class,
    \ViraMind\Core\Events\EventServiceProvider::class,
    \ViraMind\Services\AI\AIServiceProvider::class,
    \ViraMind\Services\AI\AIManagerServiceProvider::class,
    \ViraMind\Services\Cache\CacheServiceProvider::class,
    \ViraMind\Services\Queue\QueueServiceProvider::class,
    \ViraMind\Core\Integrations\IntegrationServiceProvider::class,
    \ViraMind\Core\API\APIServiceProvider::class,
    \ViraMind\Core\Permissions\PermissionsServiceProvider::class,
];
