# Vira Mind Usage Guide

## Quick Start

### Using the AI Router

```php
// Get AI response
$response = vrmind()->make('ai.router')->route('Your prompt here');
echo $response->content;

// Check if cached
if ($response->cached) {
    echo 'Response from cache';
}
```

### Using Helper Functions

```php
// Get application instance
$app = vrmind();

// Resolve service
$cache = vrmind_make('cache');

// Get config value
$apiKey = vrmind_config('ai.providers.openai.api_key');

// Log message
vrmind_log('Something happened', 'info', ['context' => 'data']);
```

## Service Container

### Binding Services

```php
// Bind a service
vrmind()->bind('my.service', function($app) {
    return new MyService();
});

// Bind singleton
vrmind()->singleton('my.singleton', function($app) {
    return new MySingleton();
});

// Resolve service
$service = vrmind()->make('my.service');
```

## Hooks System

### Adding Hooks

```php
use ViraMind\Core\Hooks\Hooks;

// Add action
Hooks::add('init', function() {
    // Your code
});

// Add filter
Hooks::filter('the_content', function($content) {
    return $content . ' - Powered by Vira Mind';
});

// Trigger custom action
Hooks::do('vrmind_custom_action', $data);
```

## Events

### Dispatching Events

```php
use ViraMind\Services\AI\Events\AIResponseEvent;

// Create and dispatch event
$event = new AIResponseEvent($prompt, $response);
vrmind()->make('events')->dispatch($event);

// Listen to events
vrmind()->make('events')->listen(AIResponseEvent::class, function($event) {
    vrmind_log('AI Response: ' . $event->response);
});
```

## Queue System

### Creating Jobs

```php
use ViraMind\Services\Queue\Job;

class MyJob extends Job
{
    public function __construct(
        private string $data
    ) {}
    
    public function handle(): void
    {
        // Process job
        vrmind_log('Processing: ' . $this->data);
    }
}
```

### Dispatching Jobs

```php
$job = new MyJob('some data');
vrmind()->make('queue')->push($job);
```

## Cache System

### Using Cache

```php
$cache = vrmind()->make('cache');

// Store value
$cache->set('my_key', 'my_value', 3600);

// Retrieve value
$value = $cache->get('my_key');

// Delete value
$cache->forget('my_key');

// Clear all cache
$cache->flush();
```

## Middleware

### Creating Middleware

```php
use ViraMind\Core\Middleware\Middleware;
use ViraMind\Core\Middleware\Request;

class MyMiddleware extends Middleware
{
    public function handle(Request $request, callable $next): mixed
    {
        // Before logic
        
        $response = $next($request);
        
        // After logic
        
        return $response;
    }
}
```

## REST API

### Making API Calls

```javascript
// Query AI
fetch('/wp-json/vrmind/v1/ai/query', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
    },
    body: JSON.stringify({
        prompt: 'Your question here'
    })
})
.then(response => response.json())
.then(data => console.log(data));
```

### PHP API Usage

```php
$request = new WP_REST_Request('POST', '/vrmind/v1/ai/query');
$request->set_param('prompt', 'Your question');
$response = rest_do_request($request);
```

## Creating Addons

### Addon Structure

```
/addons/my-addon/
├── manifest.php
├── Providers/
│   └── ServiceProvider.php
├── Controllers/
├── routes.php
└── views/
```

### Manifest File

```php
// manifest.php
return [
    'name' => 'MyAddon',
    'version' => '1.0.0',
    'description' => 'My custom addon',
    'author' => 'Your Name',
    'providers' => [
        \ViraMind\Addons\MyAddon\Providers\ServiceProvider::class,
    ],
    'dependencies' => [],
];
```

### Service Provider

```php
namespace ViraMind\Addons\MyAddon\Providers;

use ViraMind\Core\Container\ServiceProvider;

class ServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->bind('myaddon.service', function() {
            return new MyService();
        });
    }
    
    public function boot(): void
    {
        // Load routes
        require __DIR__ . '/../routes.php';
    }
}
```

## Views

### Rendering Views

```php
use ViraMind\Views\View;

// Render view
View::render('admin.dashboard', [
    'title' => 'Dashboard',
    'data' => $data
]);

// Get view as string
$html = View::make('admin.settings', ['settings' => $settings]);
```

## Configuration

### Accessing Config

```php
// Get config value
$value = vrmind_config('ai.default_provider');

// Get with default
$value = vrmind_config('ai.custom_key', 'default_value');

// Get nested value
$value = vrmind_config('ai.providers.openai.api_key');
```

### Setting Config at Runtime

```php
vrmind()->make('config')->set('custom.key', 'value');
```

## Logging

### Log Levels

```php
$logger = vrmind()->make('logger');

$logger->info('Information message');
$logger->warning('Warning message');
$logger->error('Error message');

// With context
$logger->log('error', 'Failed to process', [
    'user_id' => 123,
    'action' => 'ai_query'
]);
```

## AI Providers

### Registering Custom Provider

```php
use ViraMind\Services\AI\AIProvider;

class MyAIProvider extends AIProvider
{
    public function execute(string $prompt, array $options = []): string
    {
        // Your AI logic
        return 'AI response';
    }
    
    public function getName(): string
    {
        return 'MyAI';
    }
    
    public function isAvailable(): bool
    {
        return true;
    }
}

// Register in config/ai.php
'providers' => [
    'myai' => [
        'class' => MyAIProvider::class,
        'api_key' => 'your-key',
    ],
],
```

## Security Best Practices

### Input Sanitization

```php
// Sanitize text
$clean = sanitize_text_field($_POST['input']);

// Sanitize HTML
$clean = wp_kses_post($_POST['content']);

// Sanitize email
$clean = sanitize_email($_POST['email']);
```

### Output Escaping

```php
// Escape HTML
echo esc_html($user_input);

// Escape attributes
echo '<div class="' . esc_attr($class) . '">';

// Escape URL
echo '<a href="' . esc_url($url) . '">';
```

### Nonce Verification

```php
// Create nonce
wp_nonce_field('vrmind_action', '_wpnonce');

// Verify nonce
if (!wp_verify_nonce($_POST['_wpnonce'], 'vrmind_action')) {
    wp_die('Security check failed');
}
```

## Troubleshooting

### Enable Debug Mode

```php
// In wp-config.php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
```

### Check Logs

```bash
tail -f storage/logs/vira-mind-*.log
```

### Clear Cache

```php
vrmind()->make('cache')->flush();
```

### Process Queue Manually

```php
vrmind()->make('queue')->process(50);
```
