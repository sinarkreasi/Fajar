# Vira Mind Developer API Reference

## 🚀 Quick Start

### Basic AI Request
```php
$response = vrmind_ai('Your prompt here');
echo $response; // AI response text
```

### With Options
```php
$response = vrmind_ai('Your prompt', [
    'driver' => 'openai',
    'model' => 'gpt-4',
    'temperature' => 0.7,
    'max_tokens' => 2000,
    'cache_ttl' => 3600
]);
```

### Queue AI Request
```php
vrmind_ai_queue('Long running task', ['driver' => 'openai']);
```

## 📦 Core Functions

### Container & Services
```php
// Get application instance
$app = vrmind();

// Resolve service
$cache = vrmind_make('cache');
$queue = vrmind_make('queue');
$aiManager = vrmind_make('ai.manager');
```

### Configuration
```php
// Get config value
$value = vrmind_config('ai.default_provider');
$value = vrmind_config('cache.ttl', 3600); // with default
```

### Logging
```php
vrmind_log('Message', 'info');
vrmind_log('Error occurred', 'error', ['context' => 'data']);
vrmind_log('Warning', 'warning');
```

### Caching
```php
// Set cache
vrmind_cache('key', 'value', 3600);

// Get cache
$value = vrmind_cache('key');

// Manual cache operations
$cache = vrmind_make('cache');
$cache->set('key', 'value', 3600);
$value = $cache->get('key');
$cache->forget('key');
$cache->flush();
```

### Queue
```php
// Queue a job
vrmind_queue(new MyJob($data));

// Manual queue operations
$queue = vrmind_make('queue');
$queue->push(new MyJob());
$queue->process(10); // Process 10 jobs
```

### Events
```php
// Dispatch event
vrmind_event('custom.event', ['data' => 'value']);

// Listen to event
vrmind()->make('events')->listen('custom.event', function($event, $payload) {
    // Handle event
});
```

### Routes
```php
// Register custom route
vrmind_route('POST', '/my-endpoint', [MyController::class, 'handle'], ['auth', 'nonce']);

// Get route registrar
$registrar = vrmind_make('route.registrar');
$routes = $registrar->getRoutes();
```

### Views
```php
// Render view
$html = vrmind_view('admin.my-template', ['data' => $data]);

// Direct rendering
\ViraMind\Views\View::render('admin.dashboard', $data);
```

## 🤖 AI Manager API

### Execute Request
```php
$manager = vrmind_make('ai.manager');

// Simple execution
$response = $manager->execute('Your prompt');
echo $response->content;
echo $response->cached; // true/false
echo $response->getMetadata('driver');
echo $response->getMetadata('execution_time');

// With options
$response = $manager->execute('Prompt', [
    'driver' => 'openai',
    'model' => 'gpt-4-turbo',
    'temperature' => 0.5,
    'max_tokens' => 1000
]);
```

### Queue Request
```php
$manager->queue('Long task', ['driver' => 'openai']);
```

### Token Usage
```php
// Get usage for specific driver
$tokens = $manager->getTokenUsage('openai');

// Get all usage
$allUsage = $manager->getTokenUsage();
// Returns: ['openai' => 1234, 'local' => 567]
```

### Register Custom Driver
```php
class MyAIDriver extends \ViraMind\Services\AI\AIProvider {
    public function execute(string $prompt, array $options = []): string {
        // Your implementation
        return 'Response';
    }
    
    public function getName(): string {
        return 'MyAI';
    }
    
    public function isAvailable(): bool {
        return true;
    }
}

$manager->registerDriver('myai', new MyAIDriver([]));
```

## 🧩 Addon Development

### Addon Structure
```
/my-addon/
├── addon.json
├── index.php
├── Providers/
│   └── ServiceProvider.php
├── Controllers/
├── routes.php
└── Resources/
    ├── scripts/
    └── styles/
```

### addon.json
```json
{
  "name": "My Addon",
  "slug": "my-addon",
  "version": "1.0.0",
  "description": "My awesome addon",
  "author": "Your Name",
  "provider": "ViraMind\\Addons\\MyAddon\\Providers\\ServiceProvider"
}
```

### Service Provider
```php
namespace ViraMind\Addons\MyAddon\Providers;

use ViraMind\Core\Container\ServiceProvider as BaseServiceProvider;

class ServiceProvider extends BaseServiceProvider
{
    public function register(): void
    {
        // Register services
        $this->app->singleton('myaddon.service', fn() => new MyService());
    }

    public function boot(): void
    {
        // Boot addon
        add_action('vrmind_loaded', function() {
            // Addon ready
        });
    }
}
```

### routes.php
```php
use ViraMind\Core\Hooks\Hooks;

Hooks::add('rest_api_init', function() {
    register_rest_route('myaddon/v1', '/endpoint', [
        'methods' => 'POST',
        'callback' => [MyController::class, 'handle'],
        'permission_callback' => fn() => current_user_can('edit_posts')
    ]);
});
```

## 🔧 Middleware

### Using Middleware
```php
// In routes
vrmind_route('POST', '/secure', [Controller::class, 'method'], ['auth', 'nonce', 'rate_limit']);
```

### Custom Middleware
```php
namespace ViraMind\Core\Middleware;

class MyMiddleware extends Middleware
{
    public function handle(Request $request, callable $next): mixed
    {
        // Before logic
        
        if (!$this->checkSomething()) {
            wp_die('Access denied', 403);
        }
        
        $response = $next($request);
        
        // After logic
        
        return $response;
    }
}

// Register
vrmind()->make('middleware.kernel')->register('my_middleware', MyMiddleware::class);
```

## 📊 Available Services

### Core Services
- `app` - Application instance
- `config` - Configuration manager
- `logger` - Logger service
- `router` - Router service
- `events` - Event dispatcher
- `cache` - Cache manager
- `queue` - Queue manager

### AI Services
- `ai.router` - AI Router (legacy)
- `ai.manager` - AI Manager (new)
- `ai.provider` - AI Provider Manager

### Kernel Services
- `kernel` - Main kernel
- `route.registrar` - Route registrar
- `middleware.kernel` - Middleware kernel
- `addon.loader` - Addon loader
- `addon.installer` - Addon installer

## 🎣 Available Hooks

### Actions
```php
do_action('vrmind_loaded');
do_action('vrmind_kernel_booted');
do_action('vrmind_addon_loaded', $addon);
do_action('vrmind_addons_discovered', $addons);
do_action('vrmind_addons_loaded', $addons);
```

### Filters
```php
apply_filters('vrmind_ai_prompt', $prompt);
apply_filters('vrmind_ai_options', $options);
apply_filters('vrmind_cache_key', $key);
```

## 🔐 Security Best Practices

### Input Sanitization
```php
$text = sanitize_text_field($_POST['input']);
$html = wp_kses_post($_POST['content']);
$email = sanitize_email($_POST['email']);
```

### Output Escaping
```php
echo esc_html($user_input);
echo esc_attr($attribute);
echo esc_url($url);
```

### Nonce Verification
```php
wp_nonce_field('my_action', 'my_nonce');

if (!wp_verify_nonce($_POST['my_nonce'], 'my_action')) {
    wp_die('Security check failed');
}
```

### Capability Checks
```php
if (!current_user_can('manage_options')) {
    wp_die('Unauthorized');
}
```

## 📝 Examples

### Complete AI Integration
```php
// In your plugin/theme
add_action('init', function() {
    if (isset($_POST['ai_request'])) {
        $prompt = sanitize_text_field($_POST['prompt']);
        
        try {
            $response = vrmind_ai($prompt, [
                'driver' => 'openai',
                'model' => 'gpt-4'
            ]);
            
            echo esc_html($response);
        } catch (\Exception $e) {
            vrmind_log('AI request failed: ' . $e->getMessage(), 'error');
        }
    }
});
```

### Custom Event Handler
```php
vrmind()->make('events')->listen('ai.response', function($event, $payload) {
    // Log AI usage
    $driver = $payload['driver'] ?? 'unknown';
    $time = $payload['execution_time'] ?? 0;
    
    vrmind_log("AI response from {$driver} in {$time}s", 'info');
    
    // Track in database
    global $wpdb;
    $wpdb->insert($wpdb->prefix . 'ai_usage', [
        'driver' => $driver,
        'execution_time' => $time,
        'created_at' => current_time('mysql')
    ]);
});
```

### Background Job
```php
use ViraMind\Services\Queue\Job;

class ProcessDataJob extends Job
{
    public function __construct(
        private array $data
    ) {}
    
    public function handle(): void
    {
        // Process data
        foreach ($this->data as $item) {
            // Do something
        }
        
        vrmind_log('Data processed', 'info');
    }
}

// Queue the job
vrmind_queue(new ProcessDataJob($myData));
```

## 🎯 Tips & Tricks

1. **Always use helper functions** - They provide consistent API
2. **Cache expensive operations** - Use `vrmind_cache()`
3. **Queue long tasks** - Use `vrmind_queue()` or `vrmind_ai_queue()`
4. **Log important events** - Use `vrmind_log()`
5. **Dispatch events** - Allow others to hook into your code
6. **Use middleware** - Protect your routes
7. **Follow WordPress standards** - Sanitize, escape, verify

## 📚 Further Reading

- `ARCHITECTURE.md` - System architecture
- `USAGE.md` - General usage guide
- `DEV3-IMPLEMENTATION.md` - Latest features
- `ADMIN-UI-GUIDE.md` - Admin interface guide
