<?php

declare(strict_types=1);

namespace ViraMind\Components;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Card Component
 */
class Card
{
    public static function render(string $title, string $content, array $options = []): string
    {
        $class = $options['class'] ?? '';
        $footer = $options['footer'] ?? '';
        
        ob_start();
        ?>
        <div class="vrmind-card <?php echo esc_attr($class); ?>">
            <?php if (!empty($title)): ?>
                <h2><?php echo esc_html($title); ?></h2>
            <?php endif; ?>
            
            <div class="vrmind-card-content">
                <?php echo wp_kses_post($content); ?>
            </div>
            
            <?php if (!empty($footer)): ?>
                <div class="vrmind-card-footer">
                    <?php echo wp_kses_post($footer); ?>
                </div>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }
}
