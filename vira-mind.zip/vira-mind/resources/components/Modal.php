<?php

declare(strict_types=1);

namespace ViraMind\Components;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Modal Component
 */
class Modal
{
    public static function render(string $id, string $title, string $content, array $options = []): string
    {
        $size = $options['size'] ?? 'medium';
        $footer = $options['footer'] ?? '';
        
        ob_start();
        ?>
        <div id="<?php echo esc_attr($id); ?>" class="vrmind-modal" style="display: none;">
            <div class="vrmind-modal-overlay"></div>
            <div class="vrmind-modal-container vrmind-modal-<?php echo esc_attr($size); ?>">
                <div class="vrmind-modal-header">
                    <h3><?php echo esc_html($title); ?></h3>
                    <button type="button" class="vrmind-modal-close">&times;</button>
                </div>
                
                <div class="vrmind-modal-body">
                    <?php echo wp_kses_post($content); ?>
                </div>
                
                <?php if (!empty($footer)): ?>
                    <div class="vrmind-modal-footer">
                        <?php echo wp_kses_post($footer); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}
