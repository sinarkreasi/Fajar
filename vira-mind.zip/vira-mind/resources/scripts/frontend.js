/**
 * Vira Mind Frontend Scripts
 */

(function() {
    'use strict';

    const ViraMind = {
        init: function() {
            console.log('Vira Mind initialized');
        }
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            ViraMind.init();
        });
    } else {
        ViraMind.init();
    }

})();
