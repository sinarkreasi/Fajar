/**
 * Vira Mind Admin Scripts
 */

(function($) {
    'use strict';

    const ViraMind = {
        init: function() {
            this.bindEvents();
        },

        bindEvents: function() {
            $(document).on('click', '#vrmind-test-btn', this.testAI);
            $(document).on('click', '#vrmind-ping-model', this.pingModel);
        },

        testAI: function(e) {
            e.preventDefault();
            
            const $btn = $(this);
            const $result = $('#vrmind-test-result');
            const prompt = $('#vrmind-test-prompt').val();
            
            if (!prompt) {
                $result.html('<div class="notice notice-error"><p>Please enter a prompt</p></div>');
                return;
            }
            
            $btn.prop('disabled', true).text('Testing...');
            $result.html('<div class="notice notice-info"><p>Processing...</p></div>');
            
            $.ajax({
                url: '/wp-json/vrmind/v1/ai/query',
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({ prompt: prompt }),
                beforeSend: function(xhr) {
                    xhr.setRequestHeader('X-WP-Nonce', window.wpApiSettings?.nonce || '');
                },
                success: function(response) {
                    $result.html(
                        '<div class="notice notice-success"><p><strong>Success!</strong></p>' +
                        '<p>' + response.content + '</p>' +
                        '<p><em>Cached: ' + (response.cached ? 'Yes' : 'No') + '</em></p></div>'
                    );
                },
                error: function(xhr) {
                    const error = xhr.responseJSON?.error || 'Unknown error';
                    $result.html('<div class="notice notice-error"><p><strong>Error:</strong> ' + error + '</p></div>');
                },
                complete: function() {
                    $btn.prop('disabled', false).text('Test AI');
                }
            });
        },

        pingModel: function(e) {
            e.preventDefault();
            
            const $btn = $(this);
            const $result = $('#vrmind-ping-result');
            
            $btn.prop('disabled', true).html('<span class="vrmind-spinner"></span> Pinging...');
            $result.html('<div class="vrmind-alert info">Testing AI connection...</div>');
            
            $.ajax({
                url: '/wp-json/vrmind/v1/ai/query',
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({ prompt: 'Say "pong" if you can hear me.' }),
                beforeSend: function(xhr) {
                    xhr.setRequestHeader('X-WP-Nonce', window.wpApiSettings?.nonce || '');
                },
                success: function(response) {
                    $result.html(
                        '<div class="vrmind-alert success">' +
                        '<strong>✓ Connection Successful!</strong><br>' +
                        'Response: ' + response.content +
                        '</div>'
                    );
                },
                error: function(xhr) {
                    const error = xhr.responseJSON?.error || 'Connection failed';
                    $result.html(
                        '<div class="vrmind-alert error">' +
                        '<strong>✗ Connection Failed</strong><br>' +
                        error +
                        '</div>'
                    );
                },
                complete: function() {
                    $btn.prop('disabled', false).text('Ping Model');
                }
            });
        }
    };

    $(document).ready(function() {
        ViraMind.init();
    });

})(jQuery);
