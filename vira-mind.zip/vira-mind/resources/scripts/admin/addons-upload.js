/**
 * Addon Upload Handler
 */

(function($) {
    'use strict';

    const AddonUpload = {
        init: function() {
            this.bindEvents();
        },

        bindEvents: function() {
            $('#vrmind-addon-upload-form').on('submit', this.handleUpload.bind(this));
            $('#addon_file').on('change', this.validateFile.bind(this));
        },

        validateFile: function(e) {
            const file = e.target.files[0];
            const $result = $('#vrmind-upload-result');
            
            if (!file) {
                return;
            }

            // Check file type
            if (!file.name.endsWith('.zip')) {
                $result.html('<div class="vrmind-alert error">❌ Please select a ZIP file</div>');
                e.target.value = '';
                return;
            }

            // Check file size (10MB)
            if (file.size > 10 * 1024 * 1024) {
                $result.html('<div class="vrmind-alert error">❌ File too large. Maximum size is 10MB</div>');
                e.target.value = '';
                return;
            }

            const sizeMB = (file.size / 1024 / 1024).toFixed(2);
            $result.html('<div class="vrmind-alert success">✓ File ready to upload: ' + file.name + ' (' + sizeMB + ' MB)</div>');
        },

        handleUpload: function(e) {
            const $form = $(e.target);
            const $btn = $('#vrmind-upload-btn');
            const $progress = $('#vrmind-upload-progress');
            const $result = $('#vrmind-upload-result');
            const file = $('#addon_file')[0].files[0];

            if (!file) {
                e.preventDefault();
                $result.html('<div class="vrmind-alert error">❌ Please select a file</div>');
                return;
            }

            // Validate again before submit
            if (!file.name.endsWith('.zip')) {
                e.preventDefault();
                $result.html('<div class="vrmind-alert error">❌ Invalid file type</div>');
                return;
            }

            if (file.size > 10 * 1024 * 1024) {
                e.preventDefault();
                $result.html('<div class="vrmind-alert error">❌ File too large</div>');
                return;
            }

            // Show progress
            $btn.prop('disabled', true).text('Installing...');
            $progress.show();
            $result.html('<div class="vrmind-alert info">⏳ Uploading and installing addon...</div>');

            // Simulate progress (actual upload happens via form submit)
            let progress = 0;
            const interval = setInterval(function() {
                progress += 5;
                if (progress <= 95) {
                    $('.vrmind-progress-fill').css('width', progress + '%');
                } else {
                    clearInterval(interval);
                }
            }, 150);

            // Allow form to submit normally
            // The page will reload with success/error message
        }
    };

    $(document).ready(function() {
        AddonUpload.init();
        
        // Auto-hide success messages after 5 seconds
        setTimeout(function() {
            $('.notice.notice-success').fadeOut();
        }, 5000);
    });

})(jQuery);
