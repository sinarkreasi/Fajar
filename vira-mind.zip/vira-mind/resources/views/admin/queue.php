<?php
declare(strict_types=1);
if (!defined('ABSPATH')) exit;
$pending_jobs = $data['pending_jobs'] ?? [];
$failed_jobs = $data['failed_jobs'] ?? [];
?>
<div class="wrap vrmind-admin-wrapper">
    <h1>📋 <?php echo esc_html__('Queue Management', 'vira-mind'); ?></h1>
    
    <?php settings_errors('vrmind_queue'); ?>
    
    <div class="vrmind-grid">
        <div class="vrmind-card">
            <h2><?php echo esc_html__('Pending Jobs', 'vira-mind'); ?></h2>
            <p><?php echo esc_html(sprintf(__('%d jobs in queue', 'vira-mind'), count($pending_jobs))); ?></p>
            
            <form method="post" action="">
                <?php wp_nonce_field('vrmind_queue', 'vrmind_queue_nonce'); ?>
                <button type="submit" name="vrmind_process_queue" class="vrmind-button">
                    <?php echo esc_html__('Process Queue Now', 'vira-mind'); ?>
                </button>
            </form>
        </div>
        
        <div class="vrmind-card">
            <h2><?php echo esc_html__('Failed Jobs', 'vira-mind'); ?></h2>
            <p><?php echo esc_html(sprintf(__('%d failed jobs', 'vira-mind'), count($failed_jobs))); ?></p>
            
            <form method="post" action="">
                <?php wp_nonce_field('vrmind_queue', 'vrmind_queue_nonce'); ?>
                <button type="submit" name="vrmind_clear_failed" class="vrmind-button danger">
                    <?php echo esc_html__('Clear Failed Jobs', 'vira-mind'); ?>
                </button>
            </form>
        </div>
    </div>
    
    <?php if (!empty($pending_jobs)): ?>
    <div class="vrmind-card">
        <h2><?php echo esc_html__('Job List', 'vira-mind'); ?></h2>
        <table class="vrmind-table">
            <thead>
                <tr>
                    <th><?php echo esc_html__('Job ID', 'vira-mind'); ?></th>
                    <th><?php echo esc_html__('Attempts', 'vira-mind'); ?></th>
                    <th><?php echo esc_html__('Created', 'vira-mind'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pending_jobs as $job): ?>
                    <tr>
                        <td><code><?php echo esc_html($job['id']); ?></code></td>
                        <td><?php echo esc_html($job['attempts']); ?></td>
                        <td><?php echo esc_html($job['created']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>
