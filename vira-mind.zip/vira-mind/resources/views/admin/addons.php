<?php
declare(strict_types=1);
if (!defined('ABSPATH')) exit;
$addons = $data['addons'] ?? [];
?>
<div class="wrap vrmind-admin-wrapper">
    <h1>🧩 <?php echo esc_html__('Addons Manager', 'vira-mind'); ?></h1>
    
    <?php settings_errors('vrmind_addons'); ?>
    
    <!-- Upload Addon -->
    <div class="vrmind-card">
        <h2>📦 <?php echo esc_html__('Upload New Addon', 'vira-mind'); ?></h2>
        <p><?php echo esc_html__('Upload a ZIP file containing your addon. The addon must include an addon.json manifest file.', 'vira-mind'); ?></p>
        
        <form method="post" action="" enctype="multipart/form-data" id="vrmind-addon-upload-form">
            <?php wp_nonce_field('vrmind_upload_addon', 'vrmind_addon_nonce'); ?>
            
            <div style="margin: 20px 0;">
                <input type="file" name="addon_file" id="addon_file" accept=".zip" required />
            </div>
            
            <button type="submit" name="vrmind_upload_addon" class="vrmind-button" id="vrmind-upload-btn">
                <?php echo esc_html__('Upload & Install', 'vira-mind'); ?>
            </button>
            
            <div id="vrmind-upload-progress" style="display: none; margin-top: 15px;">
                <div class="vrmind-progress-bar">
                    <div class="vrmind-progress-fill" style="width: 0%"></div>
                </div>
                <p style="margin-top: 10px; color: #646970;"><?php echo esc_html__('Uploading...', 'vira-mind'); ?></p>
            </div>
            
            <div id="vrmind-upload-result" style="margin-top: 15px;"></div>
        </form>
        
        <div class="vrmind-alert info" style="margin-top: 20px;">
            <strong><?php echo esc_html__('Addon Requirements:', 'vira-mind'); ?></strong>
            <ul style="margin: 10px 0 0 20px;">
                <li><?php echo esc_html__('Must be a ZIP file', 'vira-mind'); ?></li>
                <li><?php echo esc_html__('Must contain addon.json manifest', 'vira-mind'); ?></li>
                <li><?php echo esc_html__('Maximum file size: 10MB', 'vira-mind'); ?></li>
                <li><?php echo esc_html__('Slug must be unique (lowercase, numbers, hyphens only)', 'vira-mind'); ?></li>
            </ul>
        </div>
    </div>
    
    <!-- Installed Addons -->
    <div class="vrmind-card">
        <h2><?php echo esc_html__('Installed Addons', 'vira-mind'); ?></h2>
        
        <?php if (empty($addons)): ?>
            <div class="vrmind-alert info">
                <?php echo esc_html__('No addons installed yet. Upload your first addon above!', 'vira-mind'); ?>
            </div>
        <?php else: ?>
            <table class="vrmind-table">
                <thead>
                    <tr>
                        <th><?php echo esc_html__('Name', 'vira-mind'); ?></th>
                        <th><?php echo esc_html__('Version', 'vira-mind'); ?></th>
                        <th><?php echo esc_html__('Author', 'vira-mind'); ?></th>
                        <th><?php echo esc_html__('Status', 'vira-mind'); ?></th>
                        <th><?php echo esc_html__('Actions', 'vira-mind'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($addons as $addon): ?>
                        <tr>
                            <td>
                                <strong><?php echo esc_html($addon['name']); ?></strong>
                                <?php if (!empty($addon['description'])): ?>
                                    <br><small><?php echo esc_html($addon['description']); ?></small>
                                <?php endif; ?>
                            </td>
                            <td><?php echo esc_html($addon['version']); ?></td>
                            <td><?php echo esc_html($addon['author']); ?></td>
                            <td>
                                <span class="vrmind-badge <?php echo $addon['active'] ? 'success' : 'error'; ?>">
                                    <?php echo $addon['active'] ? 'Active' : 'Inactive'; ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($addon['active']): ?>
                                    <form method="post" action="" style="display: inline;">
                                        <?php wp_nonce_field('vrmind_deactivate_addon', 'vrmind_addon_nonce'); ?>
                                        <input type="hidden" name="addon_slug" value="<?php echo esc_attr($addon['slug']); ?>" />
                                        <button 
                                            type="submit" 
                                            name="vrmind_deactivate_addon" 
                                            class="vrmind-button"
                                        >
                                            <?php echo esc_html__('Deactivate', 'vira-mind'); ?>
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <form method="post" action="" style="display: inline;">
                                        <?php wp_nonce_field('vrmind_activate_addon', 'vrmind_addon_nonce'); ?>
                                        <input type="hidden" name="addon_slug" value="<?php echo esc_attr($addon['slug']); ?>" />
                                        <button 
                                            type="submit" 
                                            name="vrmind_activate_addon" 
                                            class="vrmind-button"
                                        >
                                            <?php echo esc_html__('Activate', 'vira-mind'); ?>
                                        </button>
                                    </form>
                                <?php endif; ?>
                                
                                <form method="post" action="" style="display: inline; margin-left: 8px;">
                                    <?php wp_nonce_field('vrmind_uninstall_addon', 'vrmind_addon_nonce'); ?>
                                    <input type="hidden" name="addon_slug" value="<?php echo esc_attr($addon['slug']); ?>" />
                                    <button 
                                        type="submit" 
                                        name="vrmind_uninstall_addon" 
                                        class="vrmind-button danger" 
                                        onclick="return confirm('<?php echo esc_js(__('Are you sure you want to uninstall this addon?', 'vira-mind')); ?>');"
                                    >
                                        <?php echo esc_html__('Uninstall', 'vira-mind'); ?>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    
    <!-- Addon Structure Guide -->
    <div class="vrmind-card">
        <h2>📚 <?php echo esc_html__('Addon Structure Guide', 'vira-mind'); ?></h2>
        
        <div class="vrmind-code">
/my-addon/
├── addon.json          (Required manifest)
├── index.php           (Optional entry point)
├── Providers/          (Service providers)
│   └── ServiceProvider.php
├── Controllers/        (Controllers)
├── routes.php          (Routes)
└── Resources/          (Assets)
    ├── scripts/
    └── styles/
        </div>
        
        <h3><?php echo esc_html__('Example addon.json:', 'vira-mind'); ?></h3>
        <div class="vrmind-code">
{
  "name": "My Addon",
  "slug": "my-addon",
  "version": "1.0.0",
  "description": "My awesome addon",
  "author": "Your Name",
  "provider": "ViraMind\\Addons\\MyAddon\\Providers\\ServiceProvider"
}
        </div>
    </div>
</div>
