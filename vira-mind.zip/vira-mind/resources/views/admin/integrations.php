<?php
declare(strict_types=1);
if (!defined('ABSPATH')) exit;
$integrations = $data['integrations'] ?? [];
$available = $data['available'] ?? [];
?>

<div class="wrap vrmind-admin-wrapper">
    <h1>🔌 <?php echo esc_html__('Integrations', 'vira-mind'); ?></h1>
    <p><?php echo esc_html__('Manage third-party plugin integrations with AI capabilities', 'vira-mind'); ?></p>
    
    <!-- Active Integrations -->
    <div class="vrmind-card">
        <h2><?php echo esc_html__('Active Integrations', 'vira-mind'); ?></h2>
        
        <?php if (empty($integrations)): ?>
            <div class="vrmind-alert info">
                <?php echo esc_html__('No active integrations. Install supported plugins to enable AI features.', 'vira-mind'); ?>
            </div>
        <?php else: ?>
            <table class="vrmind-table">
                <thead>
                    <tr>
                        <th><?php echo esc_html__('Integration', 'vira-mind'); ?></th>
                        <th><?php echo esc_html__('Plugin Status', 'vira-mind'); ?></th>
                        <th><?php echo esc_html__('Status', 'vira-mind'); ?></th>
                        <th><?php echo esc_html__('Actions', 'vira-mind'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($integrations as $integration): ?>
                        <tr>
                            <td><strong><?php echo esc_html($integration['name']); ?></strong></td>
                            <td>
                                <span class="vrmind-badge <?php echo $integration['plugin_active'] ? 'success' : 'error'; ?>">
                                    <?php echo $integration['plugin_active'] ? 'Active' : 'Inactive'; ?>
                                </span>
                            </td>
                            <td>
                                <span class="vrmind-badge success">
                                    <?php echo esc_html(ucfirst($integration['status'])); ?>
                                </span>
                            </td>
                            <td>
                                <a href="<?php echo esc_url(admin_url('admin.php?page=vira-mind-' . $integration['slug'])); ?>" class="vrmind-button secondary">
                                    <?php echo esc_html__('Configure', 'vira-mind'); ?>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    
    <!-- Available Integrations -->
    <div class="vrmind-card">
        <h2><?php echo esc_html__('Available Integrations', 'vira-mind'); ?></h2>
        
        <div class="vrmind-grid">
            <?php foreach ($available as $slug => $integration): ?>
                <div class="vrmind-card">
                    <h3><?php echo esc_html($integration['name']); ?></h3>
                    <p><?php echo esc_html($integration['description']); ?></p>
                    
                    <div class="vrmind-info-row">
                        <span class="vrmind-info-label"><?php echo esc_html__('Plugin', 'vira-mind'); ?></span>
                        <span class="vrmind-badge <?php echo $integration['installed'] ? 'success' : 'warning'; ?>">
                            <?php echo $integration['installed'] ? 'Installed' : 'Not Installed'; ?>
                        </span>
                    </div>
                    
                    <?php if (!$integration['installed']): ?>
                        <p class="description">
                            <?php echo esc_html__('Install and activate the plugin to enable this integration.', 'vira-mind'); ?>
                        </p>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <!-- Integration Guide -->
    <div class="vrmind-card">
        <h2>📚 <?php echo esc_html__('Integration Guide', 'vira-mind'); ?></h2>
        
        <h3><?php echo esc_html__('How Integrations Work', 'vira-mind'); ?></h3>
        <ol style="margin-left: 20px;">
            <li><?php echo esc_html__('Install and activate a supported plugin', 'vira-mind'); ?></li>
            <li><?php echo esc_html__('Vira Mind automatically detects and loads the integration', 'vira-mind'); ?></li>
            <li><?php echo esc_html__('Configure AI features in the integration settings', 'vira-mind'); ?></li>
            <li><?php echo esc_html__('Use AI-powered features within the plugin', 'vira-mind'); ?></li>
        </ol>
        
        <h3><?php echo esc_html__('Creating Custom Integrations', 'vira-mind'); ?></h3>
        <p><?php echo esc_html__('Developers can create custom integrations using the Integration Framework. See documentation for details.', 'vira-mind'); ?></p>
    </div>
</div>
