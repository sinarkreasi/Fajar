<?php
declare(strict_types=1);
if (!defined('ABSPATH')) exit;
?>
<div class="wrap vrmind-admin-wrapper">
    <h1>🛠️ <?php echo esc_html__('System Tools', 'vira-mind'); ?></h1>
    
    <?php settings_errors('vrmind_tools'); ?>
    
    <div class="vrmind-grid">
        <div class="vrmind-card">
            <h2><?php echo esc_html__('Regenerate Config Cache', 'vira-mind'); ?></h2>
            <p><?php echo esc_html__('Clear and regenerate configuration cache', 'vira-mind'); ?></p>
            
            <form method="post" action="">
                <?php wp_nonce_field('vrmind_tools', 'vrmind_tools_nonce'); ?>
                <button type="submit" name="vrmind_regenerate_config" class="vrmind-button">
                    <?php echo esc_html__('Regenerate Config', 'vira-mind'); ?>
                </button>
            </form>
        </div>
        
        <div class="vrmind-card">
            <h2><?php echo esc_html__('Clean Temp Files', 'vira-mind'); ?></h2>
            <p><?php echo esc_html__('Remove all temporary files', 'vira-mind'); ?></p>
            
            <form method="post" action="">
                <?php wp_nonce_field('vrmind_tools', 'vrmind_tools_nonce'); ?>
                <button type="submit" name="vrmind_clean_temp" class="vrmind-button danger">
                    <?php echo esc_html__('Clean Temp', 'vira-mind'); ?>
                </button>
            </form>
        </div>
    </div>
    
    <div class="vrmind-card">
        <h2><?php echo esc_html__('System Information', 'vira-mind'); ?></h2>
        
        <div class="vrmind-code">
            PHP Version: <?php echo esc_html(PHP_VERSION); ?><br>
            WordPress Version: <?php echo esc_html(get_bloginfo('version')); ?><br>
            Vira Mind Version: <?php echo esc_html(VRMIND_VERSION); ?><br>
            Plugin Path: <?php echo esc_html(VRMIND_PATH); ?><br>
            Storage Writable: <?php echo is_writable(VRMIND_PATH . 'storage') ? 'Yes' : 'No'; ?>
        </div>
    </div>
</div>
