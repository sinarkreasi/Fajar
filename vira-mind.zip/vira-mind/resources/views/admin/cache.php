<?php
declare(strict_types=1);
if (!defined('ABSPATH')) exit;
$cache_items = $data['cache_items'] ?? [];
$total_size = $data['total_size'] ?? 0;
$driver = $data['driver'] ?? 'file';
?>
<div class="wrap vrmind-admin-wrapper">
    <h1>💾 <?php echo esc_html__('Cache Management', 'vira-mind'); ?></h1>
    
    <?php settings_errors('vrmind_cache'); ?>
    
    <div class="vrmind-card">
        <h2><?php echo esc_html__('Cache Overview', 'vira-mind'); ?></h2>
        
        <div class="vrmind-info-row">
            <span class="vrmind-info-label"><?php echo esc_html__('Driver', 'vira-mind'); ?></span>
            <span class="vrmind-badge info"><?php echo esc_html(ucfirst($driver)); ?></span>
        </div>
        
        <div class="vrmind-info-row">
            <span class="vrmind-info-label"><?php echo esc_html__('Total Items', 'vira-mind'); ?></span>
            <span class="vrmind-info-value"><?php echo esc_html(count($cache_items)); ?></span>
        </div>
        
        <div class="vrmind-info-row">
            <span class="vrmind-info-label"><?php echo esc_html__('Total Size', 'vira-mind'); ?></span>
            <span class="vrmind-info-value"><?php echo esc_html(size_format($total_size)); ?></span>
        </div>
        
        <form method="post" action="">
            <?php wp_nonce_field('vrmind_cache', 'vrmind_cache_nonce'); ?>
            <div class="vrmind-actions">
                <button type="submit" name="vrmind_clear_cache" class="vrmind-button danger">
                    <?php echo esc_html__('Clear All Cache', 'vira-mind'); ?>
                </button>
            </div>
        </form>
    </div>
    
    <div class="vrmind-card">
        <h2><?php echo esc_html__('Cached Items', 'vira-mind'); ?></h2>
        
        <?php if (empty($cache_items)): ?>
            <p><?php echo esc_html__('No cached items', 'vira-mind'); ?></p>
        <?php else: ?>
            <table class="vrmind-table">
                <thead>
                    <tr>
                        <th><?php echo esc_html__('Key', 'vira-mind'); ?></th>
                        <th><?php echo esc_html__('Size', 'vira-mind'); ?></th>
                        <th><?php echo esc_html__('Modified', 'vira-mind'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($cache_items as $item): ?>
                        <tr>
                            <td><code><?php echo esc_html($item['key']); ?></code></td>
                            <td><?php echo esc_html(size_format($item['size'])); ?></td>
                            <td><?php echo esc_html(date('Y-m-d H:i:s', $item['modified'])); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>
