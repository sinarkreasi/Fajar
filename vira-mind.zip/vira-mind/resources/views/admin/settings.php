<?php
/**
 * Settings View
 */

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

$apiKey = get_option('vrmind_openai_key', '');
?>

<div class="wrap vrmind-admin-wrapper">
    <h1><?php echo esc_html__('Vira Mind Settings', 'vira-mind'); ?></h1>
    
    <?php settings_errors('vrmind_settings'); ?>
    
    <form method="post" action="">
        <?php wp_nonce_field('vrmind_settings', 'vrmind_settings_nonce'); ?>
        
        <div class="vrmind-card">
            <h2><?php echo esc_html__('OpenAI Configuration', 'vira-mind'); ?></h2>
            
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="vrmind_openai_key">
                            <?php echo esc_html__('OpenAI API Key', 'vira-mind'); ?>
                        </label>
                    </th>
                    <td>
                        <input 
                            type="password" 
                            id="vrmind_openai_key" 
                            name="vrmind_openai_key" 
                            value="<?php echo esc_attr($apiKey); ?>" 
                            class="regular-text"
                        />
                        <p class="description">
                            <?php echo esc_html__('Enter your OpenAI API key. Get one at https://platform.openai.com/api-keys', 'vira-mind'); ?>
                        </p>
                    </td>
                </tr>
            </table>
        </div>
        
        <p class="submit">
            <button type="submit" name="vrmind_save_settings" class="button button-primary">
                <?php echo esc_html__('Save Settings', 'vira-mind'); ?>
            </button>
        </p>
    </form>
    
    <div class="vrmind-card">
        <h2><?php echo esc_html__('Test AI Connection', 'vira-mind'); ?></h2>
        <p><?php echo esc_html__('Test your AI configuration:', 'vira-mind'); ?></p>
        
        <div id="vrmind-test-area">
            <textarea id="vrmind-test-prompt" rows="4" class="large-text" placeholder="<?php echo esc_attr__('Enter a test prompt...', 'vira-mind'); ?>"></textarea>
            <br><br>
            <button type="button" id="vrmind-test-btn" class="button">
                <?php echo esc_html__('Test AI', 'vira-mind'); ?>
            </button>
            <div id="vrmind-test-result" style="margin-top: 15px;"></div>
        </div>
    </div>
</div>
