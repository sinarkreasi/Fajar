<?php
declare(strict_types=1);
if (!defined('ABSPATH')) exit;
$providers = $data['providers'] ?? [];
$current_provider = $data['current_provider'] ?? 'openai';
$api_key = $data['api_key'] ?? '';
$model = $data['model'] ?? 'gpt-4';
$timeout = $data['timeout'] ?? 30;
$max_tokens = $data['max_tokens'] ?? 2000;
$temperature = $data['temperature'] ?? 0.7;
?>
<div class="wrap vrmind-admin-wrapper">
    <h1>🤖 <?php echo esc_html__('AI Engine Settings', 'vira-mind'); ?></h1>
    
    <?php settings_errors('vrmind_ai'); ?>
    
    <form method="post" action="">
        <?php wp_nonce_field('vrmind_ai_settings', 'vrmind_ai_nonce'); ?>
        
        <div class="vrmind-card">
            <h2><?php echo esc_html__('General AI Configuration', 'vira-mind'); ?></h2>
            
            <table class="form-table">
                <tr>
                    <th><label for="provider"><?php echo esc_html__('AI Provider', 'vira-mind'); ?></label></th>
                    <td>
                        <select name="provider" id="provider" class="regular-text">
                            <?php foreach ($providers as $key => $provider): ?>
                                <option value="<?php echo esc_attr($key); ?>" <?php selected($current_provider, $key); ?>>
                                    <?php echo esc_html($provider['icon'] . ' ' . $provider['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th><label for="timeout"><?php echo esc_html__('Timeout (seconds)', 'vira-mind'); ?></label></th>
                    <td><input type="number" name="timeout" id="timeout" value="<?php echo esc_attr($timeout); ?>" class="small-text" /></td>
                </tr>
                <tr>
                    <th><label for="max_tokens"><?php echo esc_html__('Max Tokens', 'vira-mind'); ?></label></th>
                    <td><input type="number" name="max_tokens" id="max_tokens" value="<?php echo esc_attr($max_tokens); ?>" class="small-text" /></td>
                </tr>
                <tr>
                    <th><label for="temperature"><?php echo esc_html__('Temperature', 'vira-mind'); ?></label></th>
                    <td><input type="number" name="temperature" id="temperature" value="<?php echo esc_attr($temperature); ?>" step="0.1" min="0" max="2" class="small-text" /></td>
                </tr>
            </table>
        </div>
        
        <div class="vrmind-card">
            <h2><?php echo esc_html__('Provider Authentication', 'vira-mind'); ?></h2>
            
            <table class="form-table">
                <tr>
                    <th><label for="api_key"><?php echo esc_html__('OpenAI API Key', 'vira-mind'); ?></label></th>
                    <td>
                        <input type="password" name="api_key" id="api_key" value="<?php echo esc_attr($api_key); ?>" class="regular-text" />
                        <p class="description"><?php echo esc_html__('Get your API key from https://platform.openai.com/api-keys', 'vira-mind'); ?></p>
                    </td>
                </tr>
            </table>
        </div>
        
        <div class="vrmind-card">
            <h2><?php echo esc_html__('Model Preference', 'vira-mind'); ?></h2>
            
            <table class="form-table">
                <tr>
                    <th><label for="model"><?php echo esc_html__('Model', 'vira-mind'); ?></label></th>
                    <td>
                        <select name="model" id="model" class="regular-text">
                            <option value="gpt-4" <?php selected($model, 'gpt-4'); ?>>GPT-4</option>
                            <option value="gpt-4-turbo" <?php selected($model, 'gpt-4-turbo'); ?>>GPT-4 Turbo</option>
                            <option value="gpt-3.5-turbo" <?php selected($model, 'gpt-3.5-turbo'); ?>>GPT-3.5 Turbo</option>
                        </select>
                    </td>
                </tr>
            </table>
        </div>
        
        <p class="submit">
            <button type="submit" name="vrmind_save_ai_settings" class="button button-primary">
                <?php echo esc_html__('Save Settings', 'vira-mind'); ?>
            </button>
        </p>
    </form>
</div>
