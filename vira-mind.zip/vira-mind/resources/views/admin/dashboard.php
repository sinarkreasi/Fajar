<?php
/**
 * Admin Dashboard View
 */

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

$system_health = $data['system_health'] ?? [];
$ai_status = $data['ai_status'] ?? [];
$cache_status = $data['cache_status'] ?? [];
$queue_status = $data['queue_status'] ?? [];
$recent_logs = $data['recent_logs'] ?? [];
?>

<div class="wrap vrmind-admin-wrapper">
    <h1><?php echo esc_html__('Vira Mind Dashboard', 'vira-mind'); ?></h1>
    <p><?php echo esc_html__('AI Infrastructure Layer for WordPress', 'vira-mind'); ?></p>
    
    <!-- System Health -->
    <div class="vrmind-grid">
        <div class="vrmind-card">
            <h2>⚙️ <?php echo esc_html__('System Health', 'vira-mind'); ?></h2>
            
            <div class="vrmind-status-widget">
                <div class="vrmind-status-icon <?php echo $system_health['php_ok'] ? 'success' : 'error'; ?>">
                    <?php echo $system_health['php_ok'] ? '✓' : '✗'; ?>
                </div>
                <div class="vrmind-status-content">
                    <div class="vrmind-status-label"><?php echo esc_html__('PHP Version', 'vira-mind'); ?></div>
                    <div class="vrmind-status-value"><?php echo esc_html($system_health['php_version']); ?></div>
                </div>
            </div>
            
            <div class="vrmind-status-widget">
                <div class="vrmind-status-icon <?php echo $system_health['wp_ok'] ? 'success' : 'warning'; ?>">
                    <?php echo $system_health['wp_ok'] ? '✓' : '⚠'; ?>
                </div>
                <div class="vrmind-status-content">
                    <div class="vrmind-status-label"><?php echo esc_html__('WordPress Version', 'vira-mind'); ?></div>
                    <div class="vrmind-status-value"><?php echo esc_html($system_health['wp_version']); ?></div>
                </div>
            </div>
            
            <div class="vrmind-status-widget">
                <div class="vrmind-status-icon <?php echo $system_health['memory_ok'] ? 'success' : 'warning'; ?>">
                    <?php echo $system_health['memory_ok'] ? '✓' : '⚠'; ?>
                </div>
                <div class="vrmind-status-content">
                    <div class="vrmind-status-label"><?php echo esc_html__('Memory Limit', 'vira-mind'); ?></div>
                    <div class="vrmind-status-value"><?php echo esc_html($system_health['memory_limit']); ?></div>
                </div>
            </div>
            
            <div class="vrmind-info-row">
                <span class="vrmind-info-label"><?php echo esc_html__('cURL', 'vira-mind'); ?></span>
                <span class="vrmind-badge <?php echo $system_health['curl_enabled'] ? 'success' : 'error'; ?>">
                    <?php echo $system_health['curl_enabled'] ? 'Enabled' : 'Disabled'; ?>
                </span>
            </div>
            
            <div class="vrmind-info-row">
                <span class="vrmind-info-label"><?php echo esc_html__('JSON', 'vira-mind'); ?></span>
                <span class="vrmind-badge <?php echo $system_health['json_enabled'] ? 'success' : 'error'; ?>">
                    <?php echo $system_health['json_enabled'] ? 'Enabled' : 'Disabled'; ?>
                </span>
            </div>
            
            <div class="vrmind-info-row">
                <span class="vrmind-info-label"><?php echo esc_html__('mbstring', 'vira-mind'); ?></span>
                <span class="vrmind-badge <?php echo $system_health['mbstring_enabled'] ? 'success' : 'error'; ?>">
                    <?php echo $system_health['mbstring_enabled'] ? 'Enabled' : 'Disabled'; ?>
                </span>
            </div>
            
            <div class="vrmind-info-row">
                <span class="vrmind-info-label"><?php echo esc_html__('Storage Writable', 'vira-mind'); ?></span>
                <span class="vrmind-badge <?php echo $system_health['storage_writable'] ? 'success' : 'error'; ?>">
                    <?php echo $system_health['storage_writable'] ? 'Yes' : 'No'; ?>
                </span>
            </div>
        </div>
        
        <div class="vrmind-card">
            <h2>🤖 <?php echo esc_html__('AI Engine Status', 'vira-mind'); ?></h2>
            
            <div class="vrmind-status-widget">
                <div class="vrmind-status-icon <?php echo $ai_status['configured'] ? 'success' : 'warning'; ?>">
                    <?php echo $ai_status['configured'] ? '✓' : '⚠'; ?>
                </div>
                <div class="vrmind-status-content">
                    <div class="vrmind-status-label"><?php echo esc_html__('Configuration', 'vira-mind'); ?></div>
                    <div class="vrmind-status-value">
                        <?php echo $ai_status['configured'] ? esc_html__('Configured', 'vira-mind') : esc_html__('Not Configured', 'vira-mind'); ?>
                    </div>
                </div>
            </div>
            
            <div class="vrmind-info-row">
                <span class="vrmind-info-label"><?php echo esc_html__('Provider', 'vira-mind'); ?></span>
                <span class="vrmind-info-value"><?php echo esc_html(ucfirst($ai_status['provider'])); ?></span>
            </div>
            
            <div class="vrmind-info-row">
                <span class="vrmind-info-label"><?php echo esc_html__('Model', 'vira-mind'); ?></span>
                <span class="vrmind-info-value"><?php echo esc_html($ai_status['model']); ?></span>
            </div>
            
            <?php if (!$ai_status['configured']): ?>
            <div class="vrmind-alert warning">
                <?php echo esc_html__('AI provider not configured. Please configure in AI Engine settings.', 'vira-mind'); ?>
            </div>
            <?php endif; ?>
            
            <div class="vrmind-actions">
                <a href="<?php echo esc_url(admin_url('admin.php?page=vira-mind-ai-engine')); ?>" class="vrmind-button">
                    <?php echo esc_html__('Configure AI', 'vira-mind'); ?>
                </a>
                <button type="button" class="vrmind-button secondary" id="vrmind-ping-model">
                    <?php echo esc_html__('Ping Model', 'vira-mind'); ?>
                </button>
            </div>
            
            <div id="vrmind-ping-result" style="margin-top: 15px;"></div>
        </div>
    </div>
    
    <!-- Cache & Queue Status -->
    <div class="vrmind-grid">
        <div class="vrmind-card">
            <h2>💾 <?php echo esc_html__('Cache Status', 'vira-mind'); ?></h2>
            
            <div class="vrmind-info-row">
                <span class="vrmind-info-label"><?php echo esc_html__('Driver', 'vira-mind'); ?></span>
                <span class="vrmind-badge info"><?php echo esc_html(ucfirst($cache_status['driver'])); ?></span>
            </div>
            
            <div class="vrmind-info-row">
                <span class="vrmind-info-label"><?php echo esc_html__('Cached Items', 'vira-mind'); ?></span>
                <span class="vrmind-info-value"><?php echo esc_html($cache_status['items']); ?></span>
            </div>
            
            <div class="vrmind-info-row">
                <span class="vrmind-info-label"><?php echo esc_html__('Total Size', 'vira-mind'); ?></span>
                <span class="vrmind-info-value"><?php echo esc_html($cache_status['size']); ?></span>
            </div>
            
            <div class="vrmind-actions">
                <a href="<?php echo esc_url(admin_url('admin.php?page=vira-mind-cache')); ?>" class="vrmind-button secondary">
                    <?php echo esc_html__('Manage Cache', 'vira-mind'); ?>
                </a>
            </div>
        </div>
        
        <div class="vrmind-card">
            <h2>📋 <?php echo esc_html__('Queue Status', 'vira-mind'); ?></h2>
            
            <div class="vrmind-info-row">
                <span class="vrmind-info-label"><?php echo esc_html__('Driver', 'vira-mind'); ?></span>
                <span class="vrmind-badge info"><?php echo esc_html(ucfirst($queue_status['driver'])); ?></span>
            </div>
            
            <div class="vrmind-info-row">
                <span class="vrmind-info-label"><?php echo esc_html__('Pending Jobs', 'vira-mind'); ?></span>
                <span class="vrmind-info-value"><?php echo esc_html($queue_status['pending']); ?></span>
            </div>
            
            <div class="vrmind-info-row">
                <span class="vrmind-info-label"><?php echo esc_html__('Failed Jobs', 'vira-mind'); ?></span>
                <span class="vrmind-badge <?php echo $queue_status['failed'] > 0 ? 'error' : 'success'; ?>">
                    <?php echo esc_html($queue_status['failed']); ?>
                </span>
            </div>
            
            <div class="vrmind-actions">
                <a href="<?php echo esc_url(admin_url('admin.php?page=vira-mind-queue')); ?>" class="vrmind-button secondary">
                    <?php echo esc_html__('Manage Queue', 'vira-mind'); ?>
                </a>
            </div>
        </div>
    </div>
    
    <!-- Recent Logs -->
    <div class="vrmind-card">
        <h2>📝 <?php echo esc_html__('Recent Event Logs', 'vira-mind'); ?></h2>
        
        <?php if (empty($recent_logs)): ?>
            <p><?php echo esc_html__('No recent logs', 'vira-mind'); ?></p>
        <?php else: ?>
            <table class="vrmind-table">
                <thead>
                    <tr>
                        <th><?php echo esc_html__('Time', 'vira-mind'); ?></th>
                        <th><?php echo esc_html__('Level', 'vira-mind'); ?></th>
                        <th><?php echo esc_html__('Message', 'vira-mind'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recent_logs as $log): ?>
                        <?php if ($log): ?>
                        <tr>
                            <td><?php echo esc_html($log['time']); ?></td>
                            <td>
                                <span class="vrmind-badge <?php echo esc_attr($log['level']); ?>">
                                    <?php echo esc_html(strtoupper($log['level'])); ?>
                                </span>
                            </td>
                            <td><?php echo esc_html($log['message']); ?></td>
                        </tr>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
        
        <div class="vrmind-actions">
            <a href="<?php echo esc_url(admin_url('admin.php?page=vira-mind-logs')); ?>" class="vrmind-button secondary">
                <?php echo esc_html__('View All Logs', 'vira-mind'); ?>
            </a>
        </div>
    </div>
</div>
