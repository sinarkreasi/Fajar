<?php
declare(strict_types=1);
if (!defined('ABSPATH')) exit;
$logs = $data['logs'] ?? [];
$current_level = $data['current_level'] ?? 'all';
$search = $data['search'] ?? '';
?>
<div class="wrap vrmind-admin-wrapper">
    <h1>📝 <?php echo esc_html__('Logs Viewer', 'vira-mind'); ?></h1>
    
    <div class="vrmind-card">
        <form method="get" action="">
            <input type="hidden" name="page" value="vira-mind-logs" />
            <div style="display: flex; gap: 10px; margin-bottom: 15px;">
                <select name="level">
                    <option value="all" <?php selected($current_level, 'all'); ?>><?php echo esc_html__('All Levels', 'vira-mind'); ?></option>
                    <option value="info" <?php selected($current_level, 'info'); ?>><?php echo esc_html__('Info', 'vira-mind'); ?></option>
                    <option value="warning" <?php selected($current_level, 'warning'); ?>><?php echo esc_html__('Warning', 'vira-mind'); ?></option>
                    <option value="error" <?php selected($current_level, 'error'); ?>><?php echo esc_html__('Error', 'vira-mind'); ?></option>
                </select>
                <input type="text" name="search" value="<?php echo esc_attr($search); ?>" placeholder="<?php echo esc_attr__('Search...', 'vira-mind'); ?>" class="regular-text" />
                <button type="submit" class="vrmind-button"><?php echo esc_html__('Filter', 'vira-mind'); ?></button>
            </div>
        </form>
        
        <?php if (empty($logs)): ?>
            <p><?php echo esc_html__('No logs found', 'vira-mind'); ?></p>
        <?php else: ?>
            <table class="vrmind-table">
                <thead>
                    <tr>
                        <th><?php echo esc_html__('Time', 'vira-mind'); ?></th>
                        <th><?php echo esc_html__('Level', 'vira-mind'); ?></th>
                        <th><?php echo esc_html__('Message', 'vira-mind'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $log): ?>
                        <tr>
                            <td><?php echo esc_html($log['time']); ?></td>
                            <td><span class="vrmind-badge <?php echo esc_attr($log['level']); ?>"><?php echo esc_html(strtoupper($log['level'])); ?></span></td>
                            <td><?php echo esc_html($log['message']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>
