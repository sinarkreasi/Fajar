<?php
declare(strict_types=1);
if (!defined('ABSPATH')) exit;
$routes = $data['routes'] ?? [];
?>
<div class="wrap vrmind-admin-wrapper">
    <h1>🛣️ <?php echo esc_html__('Route Manager', 'vira-mind'); ?></h1>
    
    <div class="vrmind-card">
        <h2><?php echo esc_html__('Registered Routes', 'vira-mind'); ?></h2>
        
        <table class="vrmind-table">
            <thead>
                <tr>
                    <th><?php echo esc_html__('Method', 'vira-mind'); ?></th>
                    <th><?php echo esc_html__('URI', 'vira-mind'); ?></th>
                    <th><?php echo esc_html__('Controller', 'vira-mind'); ?></th>
                    <th><?php echo esc_html__('Middleware', 'vira-mind'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($routes as $route): ?>
                    <tr>
                        <td><span class="vrmind-badge info"><?php echo esc_html($route['method']); ?></span></td>
                        <td><code><?php echo esc_html($route['uri']); ?></code></td>
                        <td><?php echo esc_html($route['controller']); ?></td>
                        <td><span class="vrmind-badge success"><?php echo esc_html($route['middleware']); ?></span></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
