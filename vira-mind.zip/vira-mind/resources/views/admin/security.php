<?php
declare(strict_types=1);
if (!defined('ABSPATH')) exit;
$rate_limit_enabled = $data['rate_limit_enabled'] ?? true;
$max_attempts = $data['max_attempts'] ?? 60;
$nonce_enabled = $data['nonce_enabled'] ?? true;
?>
<div class="wrap vrmind-admin-wrapper">
    <h1>🔒 <?php echo esc_html__('Security Configuration', 'vira-mind'); ?></h1>
    
    <?php settings_errors('vrmind_security'); ?>
    
    <form method="post" action="">
        <?php wp_nonce_field('vrmind_security', 'vrmind_security_nonce'); ?>
        
        <div class="vrmind-card">
            <h2><?php echo esc_html__('Rate Limiting', 'vira-mind'); ?></h2>
            
            <table class="form-table">
                <tr>
                    <th><?php echo esc_html__('Enable Rate Limiting', 'vira-mind'); ?></th>
                    <td>
                        <label>
                            <input type="checkbox" name="rate_limit_enabled" value="1" <?php checked($rate_limit_enabled); ?> />
                            <?php echo esc_html__('Protect API endpoints from abuse', 'vira-mind'); ?>
                        </label>
                    </td>
                </tr>
                <tr>
                    <th><label for="max_attempts"><?php echo esc_html__('Max Attempts', 'vira-mind'); ?></label></th>
                    <td>
                        <input type="number" name="max_attempts" id="max_attempts" value="<?php echo esc_attr($max_attempts); ?>" class="small-text" />
                        <p class="description"><?php echo esc_html__('Maximum requests per minute', 'vira-mind'); ?></p>
                    </td>
                </tr>
            </table>
        </div>
        
        <div class="vrmind-card">
            <h2><?php echo esc_html__('Nonce Verification', 'vira-mind'); ?></h2>
            
            <table class="form-table">
                <tr>
                    <th><?php echo esc_html__('Enable Nonce Verification', 'vira-mind'); ?></th>
                    <td>
                        <label>
                            <input type="checkbox" name="nonce_enabled" value="1" <?php checked($nonce_enabled); ?> />
                            <?php echo esc_html__('Verify nonces on all forms', 'vira-mind'); ?>
                        </label>
                    </td>
                </tr>
            </table>
        </div>
        
        <p class="submit">
            <button type="submit" name="vrmind_save_security" class="button button-primary">
                <?php echo esc_html__('Save Settings', 'vira-mind'); ?>
            </button>
        </p>
    </form>
</div>
