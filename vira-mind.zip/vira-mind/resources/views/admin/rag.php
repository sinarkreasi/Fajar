<?php
declare(strict_types=1);
if (!defined('ABSPATH')) exit;
$documents = $data['documents'] ?? [];
$stats = $data['stats'] ?? [];
$cache_stats = $data['cache_stats'] ?? [];
?>

<div class="wrap vrmind-admin-wrapper">
    <h1>🔍 <?php echo esc_html__('RAG Engine', 'vira-mind'); ?></h1>
    <p><?php echo esc_html__('Retrieval-Augmented Generation for context-aware AI responses', 'vira-mind'); ?></p>
    
    <?php settings_errors('vrmind_rag'); ?>
    
    <!-- Statistics -->
    <div class="vrmind-grid">
        <div class="vrmind-card">
            <h2><?php echo esc_html__('Documents', 'vira-mind'); ?></h2>
            <div class="vrmind-status-value" style="font-size: 48px; text-align: center; color: #2271b1;">
                <?php echo esc_html($stats['documents'] ?? 0); ?>
            </div>
            <p style="text-align: center; color: #646970;">
                <?php echo esc_html__('Indexed Documents', 'vira-mind'); ?>
            </p>
        </div>
        
        <div class="vrmind-card">
            <h2><?php echo esc_html__('Chunks', 'vira-mind'); ?></h2>
            <div class="vrmind-status-value" style="font-size: 48px; text-align: center; color: #00a32a;">
                <?php echo esc_html($stats['chunks'] ?? 0); ?>
            </div>
            <p style="text-align: center; color: #646970;">
                <?php echo esc_html__('Text Chunks', 'vira-mind'); ?>
            </p>
        </div>
        
        <div class="vrmind-card">
            <h2><?php echo esc_html__('Shards', 'vira-mind'); ?></h2>
            <div class="vrmind-status-value" style="font-size: 48px; text-align: center; color: #dba617;">
                <?php echo esc_html($stats['shards'] ?? 0); ?>
            </div>
            <p style="text-align: center; color: #646970;">
                <?php echo esc_html__('Vector Shards', 'vira-mind'); ?>
            </p>
        </div>
    </div>
    
    <!-- Cache Statistics -->
    <div class="vrmind-card">
        <h2>💾 <?php echo esc_html__('Cache Statistics', 'vira-mind'); ?></h2>
        
        <div class="vrmind-info-row">
            <span class="vrmind-info-label"><?php echo esc_html__('L1 (Memory) Entries', 'vira-mind'); ?></span>
            <span class="vrmind-info-value"><?php echo esc_html($cache_stats['l1_entries'] ?? 0); ?></span>
        </div>
        
        <div class="vrmind-info-row">
            <span class="vrmind-info-label"><?php echo esc_html__('L2 (File) Entries', 'vira-mind'); ?></span>
            <span class="vrmind-info-value"><?php echo esc_html($cache_stats['l2_entries'] ?? 0); ?></span>
        </div>
        
        <div class="vrmind-info-row">
            <span class="vrmind-info-label"><?php echo esc_html__('L2 Cache Size', 'vira-mind'); ?></span>
            <span class="vrmind-info-value"><?php echo esc_html(size_format($cache_stats['l2_size'] ?? 0)); ?></span>
        </div>
        
        <div class="vrmind-info-row">
            <span class="vrmind-info-label"><?php echo esc_html__('Redis Enabled', 'vira-mind'); ?></span>
            <span class="vrmind-badge <?php echo ($cache_stats['redis_enabled'] ?? false) ? 'success' : 'warning'; ?>">
                <?php echo ($cache_stats['redis_enabled'] ?? false) ? 'Yes' : 'No'; ?>
            </span>
        </div>
        
        <form method="post" action="">
            <?php wp_nonce_field('vrmind_rag', 'vrmind_rag_nonce'); ?>
            <div class="vrmind-actions">
                <button type="submit" name="vrmind_clear_rag_cache" class="vrmind-button danger">
                    <?php echo esc_html__('Clear Cache', 'vira-mind'); ?>
                </button>
            </div>
        </form>
    </div>
    
    <!-- Documents List -->
    <div class="vrmind-card">
        <h2>📄 <?php echo esc_html__('Indexed Documents', 'vira-mind'); ?></h2>
        
        <?php if (empty($documents)): ?>
            <div class="vrmind-alert info">
                <?php echo esc_html__('No documents indexed yet. Documents will appear here after indexing.', 'vira-mind'); ?>
            </div>
        <?php else: ?>
            <table class="vrmind-table">
                <thead>
                    <tr>
                        <th><?php echo esc_html__('ID', 'vira-mind'); ?></th>
                        <th><?php echo esc_html__('Type', 'vira-mind'); ?></th>
                        <th><?php echo esc_html__('Chunks', 'vira-mind'); ?></th>
                        <th><?php echo esc_html__('Status', 'vira-mind'); ?></th>
                        <th><?php echo esc_html__('Registered', 'vira-mind'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($documents as $doc): ?>
                        <tr>
                            <td><?php echo esc_html($doc->id); ?></td>
                            <td><?php echo esc_html(ucfirst($doc->type)); ?></td>
                            <td><?php echo esc_html($doc->chunks_count); ?></td>
                            <td>
                                <span class="vrmind-badge <?php echo $doc->status === 'indexed' ? 'success' : 'warning'; ?>">
                                    <?php echo esc_html(ucfirst($doc->status)); ?>
                                </span>
                            </td>
                            <td><?php echo esc_html($doc->registered_at); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    
    <!-- Maintenance -->
    <div class="vrmind-card">
        <h2>🔧 <?php echo esc_html__('Maintenance', 'vira-mind'); ?></h2>
        
        <p><?php echo esc_html__('Optimize vector storage by compacting shards and removing duplicates.', 'vira-mind'); ?></p>
        
        <form method="post" action="">
            <?php wp_nonce_field('vrmind_rag', 'vrmind_rag_nonce'); ?>
            <button type="submit" name="vrmind_compact_shards" class="vrmind-button">
                <?php echo esc_html__('Compact Shards', 'vira-mind'); ?>
            </button>
        </form>
    </div>
    
    <!-- Configuration -->
    <div class="vrmind-card">
        <h2>⚙️ <?php echo esc_html__('Configuration', 'vira-mind'); ?></h2>
        
        <div class="vrmind-info-row">
            <span class="vrmind-info-label"><?php echo esc_html__('Chunk Size', 'vira-mind'); ?></span>
            <span class="vrmind-info-value"><?php echo esc_html(\ViraMind\vrmind_config('rag.chunking.chunk_size', 500)); ?></span>
        </div>
        
        <div class="vrmind-info-row">
            <span class="vrmind-info-label"><?php echo esc_html__('Overlap', 'vira-mind'); ?></span>
            <span class="vrmind-info-value"><?php echo esc_html(\ViraMind\vrmind_config('rag.chunking.overlap', 50)); ?></span>
        </div>
        
        <div class="vrmind-info-row">
            <span class="vrmind-info-label"><?php echo esc_html__('Top K Results', 'vira-mind'); ?></span>
            <span class="vrmind-info-value"><?php echo esc_html(\ViraMind\vrmind_config('rag.retrieval.top_k', 10)); ?></span>
        </div>
        
        <div class="vrmind-info-row">
            <span class="vrmind-info-label"><?php echo esc_html__('Cache TTL', 'vira-mind'); ?></span>
            <span class="vrmind-info-value"><?php echo esc_html(\ViraMind\vrmind_config('rag.cache.ttl', 3600)); ?> seconds</span>
        </div>
        
        <p class="description">
            <?php echo esc_html__('Configuration can be modified in config/rag.php', 'vira-mind'); ?>
        </p>
    </div>
</div>
