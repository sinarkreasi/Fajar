<?php
declare(strict_types=1);
if (!defined('ABSPATH')) exit;
$providers = $data['providers'] ?? [];
?>
<div class="wrap vrmind-admin-wrapper">
    <h1>⚙️ <?php echo esc_html__('Service Manager', 'vira-mind'); ?></h1>
    
    <div class="vrmind-card">
        <h2><?php echo esc_html__('Service Providers', 'vira-mind'); ?></h2>
        
        <table class="vrmind-table">
            <thead>
                <tr>
                    <th><?php echo esc_html__('Provider', 'vira-mind'); ?></th>
                    <th><?php echo esc_html__('Class', 'vira-mind'); ?></th>
                    <th><?php echo esc_html__('Status', 'vira-mind'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($providers as $provider): ?>
                    <tr>
                        <td><?php echo esc_html($provider['name']); ?></td>
                        <td><code><?php echo esc_html($provider['class']); ?></code></td>
                        <td>
                            <span class="vrmind-badge <?php echo $provider['loaded'] ? 'success' : 'error'; ?>">
                                <?php echo $provider['loaded'] ? 'Loaded' : 'Not Loaded'; ?>
                            </span>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
