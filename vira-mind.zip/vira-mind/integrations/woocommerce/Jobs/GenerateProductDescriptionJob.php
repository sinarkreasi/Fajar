<?php

declare(strict_types=1);

namespace ViraMind\Integrations\Woocommerce\Jobs;

use ViraMind\Services\Queue\Job;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Generate Product Description Job
 */
class GenerateProductDescriptionJob extends Job
{
    public function __construct(
        private int $productId
    ) {}

    public function handle(): void
    {
        $product = wc_get_product($this->productId);
        
        if (!$product) {
            return;
        }

        $service = new \ViraMind\Integrations\Woocommerce\Services\ProductAIService();
        $description = $service->generateDescription($product->get_name(), $this->productId);

        if (!empty($description)) {
            $product->set_description($description);
            $product->save();
        }
    }
}
