<?php

declare(strict_types=1);

namespace ViraMind\Integrations\Woocommerce\Services;

use ViraMind\Integrations\Woocommerce\Agents\ProductAgent;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Product AI Service - AI operations for WooCommerce products
 */
class ProductAIService
{
    private ProductAgent $agent;

    public function __construct()
    {
        $this->agent = new ProductAgent();
    }

    /**
     * Generate product description
     */
    public function generateDescription(string $productName, int $productId = 0): string
    {
        $context = ['product_name' => $productName];

        if ($productId > 0) {
            $product = wc_get_product($productId);
            if ($product) {
                $context['category'] = $this->getProductCategories($product);
                $context['price'] = $product->get_price();
            }
        }

        $this->agent->setContext($context);
        $result = $this->agent->generateProductDescription($productName);

        return $result['main_output'] ?? '';
    }

    /**
     * Generate SEO meta
     */
    public function generateSEOMeta(int $productId): array
    {
        $product = wc_get_product($productId);
        
        if (!$product) {
            throw new \Exception('Product not found');
        }

        $context = [
            'product_name' => $product->get_name(),
            'description' => $product->get_short_description(),
            'category' => $this->getProductCategories($product)
        ];

        $this->agent->setContext($context);
        $result = $this->agent->generateSEOMeta($product->get_name());

        return [
            'meta_title' => $result['meta_title'] ?? '',
            'meta_description' => $result['meta_description'] ?? '',
            'focus_keyword' => $result['focus_keyword'] ?? ''
        ];
    }

    /**
     * Get product categories
     */
    private function getProductCategories($product): string
    {
        $categories = wp_get_post_terms($product->get_id(), 'product_cat', ['fields' => 'names']);
        return implode(', ', $categories);
    }
}
