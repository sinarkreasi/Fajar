<?php

declare(strict_types=1);

namespace ViraMind\Integrations\Woocommerce\Agents;

use ViraMind\Core\Integrations\BaseAgent;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Product Agent - AI logic for WooCommerce products
 */
class ProductAgent extends BaseAgent
{
    protected string $systemPrompt = 'You are the Vira Mind AI Engine for WooCommerce products. You must return clean, structured, safe output. No markdown formatting. No HTML. No scripts.';

    /**
     * Generate product description
     */
    public function generateProductDescription(string $productName): array
    {
        $userContent = "Generate a compelling product description for: {$productName}";
        $prompt = $this->buildPrompt($userContent);

        return $this->execute($prompt, [
            'temperature' => 0.7,
            'max_tokens' => 500
        ]);
    }

    /**
     * Generate SEO meta
     */
    public function generateSEOMeta(string $productName): array
    {
        $userContent = "Generate SEO meta title, meta description, and focus keyword for product: {$productName}";
        $prompt = $this->buildPrompt($userContent);

        $result = $this->execute($prompt, [
            'temperature' => 0.5,
            'max_tokens' => 200
        ]);

        // Parse structured output
        $output = $result['main_output'] ?? '';
        $lines = explode("\n", $output);
        
        return [
            'meta_title' => $lines[0] ?? '',
            'meta_description' => $lines[1] ?? '',
            'focus_keyword' => $lines[2] ?? ''
        ];
    }

    /**
     * Generate product tags
     */
    public function generateProductTags(string $productName, string $description): array
    {
        $userContent = "Generate relevant product tags for: {$productName}\nDescription: {$description}";
        $prompt = $this->buildPrompt($userContent);

        $result = $this->execute($prompt, [
            'temperature' => 0.6,
            'max_tokens' => 100
        ]);

        $output = $result['main_output'] ?? '';
        return array_filter(array_map('trim', explode(',', $output)));
    }
}
