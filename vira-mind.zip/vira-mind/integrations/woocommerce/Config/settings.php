<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

return [
    'auto_generate' => [
        'type' => 'checkbox',
        'label' => __('Auto-generate Descriptions', 'vira-mind'),
        'description' => __('Automatically generate descriptions for new products', 'vira-mind'),
        'default' => false
    ],
    
    'auto_seo' => [
        'type' => 'checkbox',
        'label' => __('Auto-generate SEO Meta', 'vira-mind'),
        'description' => __('Automatically generate SEO meta for products', 'vira-mind'),
        'default' => false
    ],
    
    'description_length' => [
        'type' => 'number',
        'label' => __('Description Length', 'vira-mind'),
        'description' => __('Maximum words for generated descriptions', 'vira-mind'),
        'default' => 150
    ]
];
