<?php

declare(strict_types=1);

namespace ViraMind\Integrations\Woocommerce\Hooks;

use ViraMind\Core\Container\Container;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * WooCommerce Hooks - Event-based AI operations
 */
class WoocommerceHooks
{
    private Container $container;

    public function __construct(Container $container)
    {
        $this->container = $container;
        $this->registerHooks();
    }

    /**
     * Register hooks
     */
    private function registerHooks(): void
    {
        // Product saved hook
        add_action('woocommerce_update_product', [$this, 'onProductSaved'], 10, 1);
        
        // Product published hook
        add_action('woocommerce_new_product', [$this, 'onProductPublished'], 10, 1);

        // AJAX handlers
        add_action('wp_ajax_vrmind_woo_generate_description', [new \ViraMind\Integrations\Woocommerce\Controllers\ProductController(), 'generateDescription']);
        add_action('wp_ajax_vrmind_woo_generate_seo', [new \ViraMind\Integrations\Woocommerce\Controllers\ProductController(), 'generateSEOMeta']);
    }

    /**
     * On product saved
     */
    public function onProductSaved(int $productId): void
    {
        // Optional: Auto-generate missing data
        $autoGenerate = get_option('vrmind_woo_auto_generate', false);
        
        if ($autoGenerate) {
            $product = wc_get_product($productId);
            
            if ($product && empty($product->get_description())) {
                // Queue AI generation
                \ViraMind\vrmind_queue(new \ViraMind\Integrations\Woocommerce\Jobs\GenerateProductDescriptionJob($productId));
            }
        }
    }

    /**
     * On product published
     */
    public function onProductPublished(int $productId): void
    {
        do_action('vrmind_woo_product_published', $productId);
    }
}
