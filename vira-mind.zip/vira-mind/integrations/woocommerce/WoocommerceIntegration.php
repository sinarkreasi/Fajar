<?php

declare(strict_types=1);

namespace ViraMind\Integrations\Woocommerce;

use ViraMind\Core\Integrations\BaseIntegration;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * WooCommerce Integration
 */
class WoocommerceIntegration extends BaseIntegration
{
    protected string $slug = 'woocommerce';
    protected string $name = 'WooCommerce';
    protected string $pluginFile = 'woocommerce/woocommerce.php';

    public function register(): void
    {
        // Load hooks
        $this->loadHooks();

        // Register admin menu
        add_action('admin_menu', function() {
            $this->registerAdminMenu(
                __('WooCommerce AI', 'vira-mind'),
                [$this, 'renderAdminPage']
            );
        });

        // Enqueue assets
        add_action('admin_enqueue_scripts', function($hook) {
            if (strpos($hook, 'vira-mind-woocommerce') !== false) {
                $this->enqueueAssets();
            }
        });

        $this->log('WooCommerce integration registered');
    }

    public function renderAdminPage(): void
    {
        $viewFile = $this->basePath . '/Views/admin-page.php';
        
        if (file_exists($viewFile)) {
            require_once $viewFile;
        } else {
            echo '<div class="wrap">';
            echo '<h1>' . esc_html__('WooCommerce AI Integration', 'vira-mind') . '</h1>';
            echo '<p>' . esc_html__('AI-powered features for WooCommerce', 'vira-mind') . '</p>';
            echo '</div>';
        }
    }
}
