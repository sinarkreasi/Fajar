<?php
/**
 * WooCommerce Integration Admin Page
 */

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap vrmind-admin-wrapper">
    <h1>🛒 <?php echo esc_html__('WooCommerce AI Integration', 'vira-mind'); ?></h1>
    
    <div class="vrmind-card">
        <h2><?php echo esc_html__('AI Features for WooCommerce', 'vira-mind'); ?></h2>
        
        <div class="vrmind-info-row">
            <span class="vrmind-info-label"><?php echo esc_html__('Status', 'vira-mind'); ?></span>
            <span class="vrmind-badge success"><?php echo esc_html__('Active', 'vira-mind'); ?></span>
        </div>
        
        <div class="vrmind-info-row">
            <span class="vrmind-info-label"><?php echo esc_html__('WooCommerce Version', 'vira-mind'); ?></span>
            <span class="vrmind-info-value"><?php echo esc_html(WC()->version); ?></span>
        </div>
    </div>
    
    <div class="vrmind-card">
        <h2><?php echo esc_html__('Available Features', 'vira-mind'); ?></h2>
        
        <ul style="list-style: disc; margin-left: 20px;">
            <li><?php echo esc_html__('AI-powered product descriptions', 'vira-mind'); ?></li>
            <li><?php echo esc_html__('SEO meta generation', 'vira-mind'); ?></li>
            <li><?php echo esc_html__('Product tag suggestions', 'vira-mind'); ?></li>
            <li><?php echo esc_html__('Automated content generation on product save', 'vira-mind'); ?></li>
        </ul>
    </div>
    
    <div class="vrmind-card">
        <h2><?php echo esc_html__('Settings', 'vira-mind'); ?></h2>
        
        <form method="post" action="options.php">
            <?php settings_fields('vrmind_woo_settings'); ?>
            
            <table class="form-table">
                <tr>
                    <th><?php echo esc_html__('Auto-generate Descriptions', 'vira-mind'); ?></th>
                    <td>
                        <label>
                            <input type="checkbox" name="vrmind_woo_auto_generate" value="1" <?php checked(get_option('vrmind_woo_auto_generate'), 1); ?> />
                            <?php echo esc_html__('Automatically generate descriptions for new products', 'vira-mind'); ?>
                        </label>
                    </td>
                </tr>
            </table>
            
            <?php submit_button(); ?>
        </form>
    </div>
    
    <div class="vrmind-card">
        <h2><?php echo esc_html__('Usage', 'vira-mind'); ?></h2>
        
        <p><?php echo esc_html__('To use AI features:', 'vira-mind'); ?></p>
        <ol style="margin-left: 20px;">
            <li><?php echo esc_html__('Edit any product in WooCommerce', 'vira-mind'); ?></li>
            <li><?php echo esc_html__('Look for "AI Generate" buttons in the product editor', 'vira-mind'); ?></li>
            <li><?php echo esc_html__('Click to generate AI-powered content', 'vira-mind'); ?></li>
        </ol>
    </div>
</div>
