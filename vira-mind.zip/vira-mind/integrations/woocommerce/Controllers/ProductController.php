<?php

declare(strict_types=1);

namespace ViraMind\Integrations\Woocommerce\Controllers;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Product Controller - Handles WooCommerce product AI operations
 */
class ProductController
{
    private object $aiService;

    public function __construct()
    {
        $this->aiService = new \ViraMind\Integrations\Woocommerce\Services\ProductAIService();
    }

    /**
     * Generate product description
     */
    public function generateDescription(): void
    {
        check_ajax_referer('vrmind_woo_nonce', 'nonce');

        if (!current_user_can('edit_products')) {
            wp_send_json_error(['message' => 'Unauthorized'], 403);
        }

        $productId = (int) ($_POST['product_id'] ?? 0);
        $productName = sanitize_text_field($_POST['product_name'] ?? '');

        if (empty($productName)) {
            wp_send_json_error(['message' => 'Product name required']);
        }

        try {
            $description = $this->aiService->generateDescription($productName, $productId);
            wp_send_json_success(['description' => $description]);
        } catch (\Exception $e) {
            wp_send_json_error(['message' => $e->getMessage()]);
        }
    }

    /**
     * Generate SEO meta
     */
    public function generateSEOMeta(): void
    {
        check_ajax_referer('vrmind_woo_nonce', 'nonce');

        if (!current_user_can('edit_products')) {
            wp_send_json_error(['message' => 'Unauthorized'], 403);
        }

        $productId = (int) ($_POST['product_id'] ?? 0);

        try {
            $meta = $this->aiService->generateSEOMeta($productId);
            wp_send_json_success($meta);
        } catch (\Exception $e) {
            wp_send_json_error(['message' => $e->getMessage()]);
        }
    }
}
