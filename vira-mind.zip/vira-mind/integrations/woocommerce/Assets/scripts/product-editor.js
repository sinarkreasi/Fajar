/**
 * WooCommerce Product Editor AI Integration
 */

(function($) {
    'use strict';

    const WooAI = {
        init: function() {
            this.addAIButtons();
            this.bindEvents();
        },

        addAIButtons: function() {
            // Add AI button to description field
            if ($('#content').length) {
                const $btn = $('<button type="button" class="button vrmind-ai-btn" style="margin-left: 10px;">🤖 AI Generate Description</button>');
                $('#content').closest('.wp-editor-wrap').find('.wp-editor-tabs').append($btn);
            }

            // Add AI button to short description
            if ($('#excerpt').length) {
                const $btn = $('<button type="button" class="button vrmind-ai-btn" style="margin-left: 10px;">🤖 AI Generate Short Description</button>');
                $('#excerpt').closest('.wp-editor-wrap').find('.wp-editor-tabs').append($btn);
            }
        },

        bindEvents: function() {
            $(document).on('click', '.vrmind-ai-btn', this.generateContent.bind(this));
        },

        generateContent: function(e) {
            e.preventDefault();
            
            const $btn = $(e.target);
            const productName = $('#title').val();
            
            if (!productName) {
                alert('Please enter a product name first');
                return;
            }

            $btn.prop('disabled', true).text('Generating...');

            $.ajax({
                url: ajaxurl,
                method: 'POST',
                data: {
                    action: 'vrmind_woo_generate_description',
                    nonce: vrmindWoo.nonce,
                    product_name: productName,
                    product_id: $('#post_ID').val()
                },
                success: function(response) {
                    if (response.success) {
                        // Insert into editor
                        if (typeof tinymce !== 'undefined') {
                            tinymce.get('content').setContent(response.data.description);
                        } else {
                            $('#content').val(response.data.description);
                        }
                        
                        alert('Description generated successfully!');
                    } else {
                        alert('Error: ' + (response.data.message || 'Unknown error'));
                    }
                },
                error: function() {
                    alert('Failed to generate description');
                },
                complete: function() {
                    $btn.prop('disabled', false).text('🤖 AI Generate Description');
                }
            });
        }
    };

    $(document).ready(function() {
        // Only init on product edit page
        if ($('body').hasClass('post-type-product')) {
            WooAI.init();
        }
    });

})(jQuery);
