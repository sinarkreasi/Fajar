# Vira Mind Architecture

## Overview

Vira Mind is an AI Infrastructure Layer for WordPress built with a clean, modular architecture following MVC-like patterns with dependency injection.

## Core Components

### 1. Kernel (`core/Kernel/`)

The application bootstrap and lifecycle manager.

- **Application.php**: Main application container and kernel
- **ServiceProvider.php**: Core service provider registration

### 2. Service Container (`core/Container/`)

Dependency injection container supporting:
- `bind()`: Register services
- `singleton()`: Register shared instances
- `make()`: Resolve services

### 3. Hooks Layer (`core/Hooks/`)

WordPress hooks wrapper providing clean API:
- `Hooks::add()`: Register actions
- `Hooks::filter()`: Register filters
- `Hooks::do()`: Trigger actions

### 4. Middleware (`core/Middleware/`)

Request filtering and security:
- **NonceMiddleware**: CSRF protection
- **RateLimitMiddleware**: Rate limiting
- **AISecurityMiddleware**: Prompt injection prevention

### 5. Events (`core/Events/`)

Internal event system:
- **EventDispatcher**: Publish/subscribe pattern
- **Event**: Base event class

### 6. AI Router (`app/Services/AI/`)

Core AI functionality:
- **AIRouter**: Routes prompts to providers
- **AIProvider**: Base provider interface
- **AIProviderManager**: Manages multiple providers
- **AIResponse**: Normalized response object

Features:
- Multi-provider support
- Automatic caching
- Fingerprint-based deduplication
- Input sanitization
- Response normalization

### 7. Cache Layer (`app/Services/Cache/`)

Optimized caching system:
- File-based or transient storage
- TTL support
- Fingerprint hashing

### 8. Queue System (`app/Services/Queue/`)

Asynchronous job processing:
- **QueueManager**: Job queue management
- **Job**: Base job class
- Retry logic with dead letter queue
- Cron-based worker

### 9. Addon System (`app/Services/Addon/`)

Modular extension system:
- **AddonManager**: Discovers and loads addons
- Manifest-based configuration
- Service provider integration
- No core modification required

## Directory Structure

```
/vira-mind
├── vira-mind.php          # Plugin entry point
├── composer.json          # PHP dependencies
├── package.json           # JS dependencies
│
├── /app                   # Application layer
│   ├── Controllers        # Request handlers
│   ├── Models            # Data models
│   ├── Views             # View renderer
│   └── Services          # Business logic
│
├── /bootstrap            # Bootstrap files
│   ├── app.php           # Application bootstrap
│   ├── helpers.php       # Helper functions
│   └── providers.php     # Service providers list
│
├── /core                 # Core framework
│   ├── Container         # DI container
│   ├── Hooks             # WordPress hooks wrapper
│   ├── Kernel            # Application kernel
│   ├── Middleware        # Request middleware
│   ├── Events            # Event system
│   └── Support           # Support classes
│
├── /config               # Configuration files
│   ├── app.php
│   ├── ai.php
│   ├── cache.php
│   ├── queue.php
│   └── security.php
│
├── /routes               # Route definitions
│   ├── admin.php         # Admin routes
│   ├── api.php           # REST API routes
│   ├── ajax.php          # AJAX handlers
│   └── web.php           # Frontend routes
│
├── /resources            # Assets and views
│   ├── views             # PHP templates
│   ├── scripts           # JavaScript files
│   ├── styles            # CSS files
│   └── components        # Reusable components
│
├── /storage              # Runtime storage
│   ├── cache             # Cache files
│   ├── logs              # Log files
│   ├── queue             # Queue jobs
│   └── temp              # Temporary files
│
├── /addons               # Plugin addons
└── /vendor               # Composer dependencies
```

## Request Lifecycle

1. WordPress loads `vira-mind.php`
2. Composer autoloader initializes
3. Bootstrap files loaded
4. Application kernel boots
5. Service providers registered
6. Configuration loaded
7. Routes registered
8. Addons discovered and loaded
9. Request processed through middleware
10. Response returned

## Service Providers

Service providers are the central place for registering services:

```php
class CustomServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->singleton('service', fn() => new Service());
    }
    
    public function boot(): void
    {
        // Boot logic
    }
}
```

## Creating Addons

Addons extend functionality without modifying core:

1. Create addon directory in `/addons/`
2. Create `manifest.php`:

```php
return [
    'name' => 'MyAddon',
    'version' => '1.0.0',
    'providers' => [
        MyAddon\ServiceProvider::class,
    ],
];
```

3. Create service provider
4. Add routes, controllers, views as needed

## Security

- All input sanitized via `wp_kses_post()`, `sanitize_text_field()`
- Output escaped via `esc_html()`, `esc_attr()`
- Nonce verification on all forms
- Rate limiting on API endpoints
- Prompt injection prevention
- Role-based access control

## Performance

- Minimal database queries
- Aggressive caching with fingerprinting
- Lazy loading of services
- Conditional asset loading
- Queue system for heavy operations

## Coding Standards

- PHP 8.2 strict typing
- PSR-4 autoloading
- WordPress coding standards
- No inline JS/CSS
- Prefix: `vrmind_`
