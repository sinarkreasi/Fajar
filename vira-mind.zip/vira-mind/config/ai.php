<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

return [
    'default_provider' => 'openai',
    
    'providers' => [
        'openai' => [
            'class' => \ViraMind\Services\AI\Providers\OpenAIProvider::class,
            'api_key' => get_option('vrmind_openai_key', ''),
            'model' => 'gpt-4',
        ],
    ],
    
    'cache_ttl' => 3600,
    'max_tokens' => 2000,
    'temperature' => 0.7,
];
