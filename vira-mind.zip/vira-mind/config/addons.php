<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

return [
    'enabled' => true,
    'auto_discover' => true,
    'path' => VRMIND_PATH . 'addons/',
];
