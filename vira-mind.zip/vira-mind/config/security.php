<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

return [
    'rate_limit' => [
        'enabled' => true,
        'max_attempts' => 60,
        'decay_minutes' => 1,
    ],
    
    'nonce_verification' => true,
    
    'allowed_roles' => ['administrator', 'editor'],
];
