<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

return [
    // Chunking configuration
    'chunking' => [
        'chunk_size' => 500,
        'overlap' => 50,
        'preserve_boundaries' => true,
    ],

    // Merging configuration
    'merging' => [
        'enabled' => true,
        'merge_threshold' => 0.88,
        'max_window_tokens' => 2000,
    ],

    // Retrieval configuration
    'retrieval' => [
        'top_k' => 10,
        'top_m' => 200, // Stage 1 candidates
        'top_n' => 50,  // Stage 2 candidates
    ],

    // Reranking configuration
    'reranking' => [
        'enabled' => true,
        'lightweight_k' => 50,
        'final_k' => 8,
        'alpha' => 0.7, // Semantic weight
        'beta' => 0.2,  // BM25 weight
        'gamma' => 0.1, // Freshness weight
    ],

    // Caching configuration
    'cache' => [
        'enabled' => true,
        'ttl' => 3600,
        'levels' => ['memory', 'file', 'redis'],
    ],

    // Shard configuration
    'shards' => [
        'target_size' => 1000,
        'compaction_threshold' => 0.3,
        'auto_compact' => true,
    ],

    // Deduplication
    'deduplication' => [
        'enabled' => true,
        'similarity_threshold' => 0.95,
    ],

    // Diversity
    'diversity' => [
        'enabled' => true,
        'ngram_overlap_threshold' => 0.7,
    ],

    // Performance
    'performance' => [
        'batch_size' => 10,
        'max_memory_mb' => 512,
        'timeout' => 30,
    ],

    // Local engine configuration
    'local_index' => [
        'enabled' => false,
        'driver' => 'brute', // brute | sidecar | sqlite
        'sidecar' => [
            'url' => 'http://127.0.0.1:9001',
            'api_key' => '',
            'timeout' => 5,
        ],
        'sqlite' => [
            'path' => VRMIND_PATH . 'storage/vectors/index.sqlite',
        ],
        'brute' => [
            'chunk_scan_limit' => 10000,
        ],
        'sync_interval' => 3600,
    ],

    // Local inference
    'local_inference' => [
        'enabled' => false,
        'driver' => 'sidecar', // sidecar | llama_cpp | onnx
        'max_memory_mb' => 2048,
        'batch_size' => 8,
    ],

    // Metrics
    'metrics' => [
        'enabled' => true,
        'log_path' => VRMIND_PATH . 'storage/logs/rag-metrics.log',
    ],
];
