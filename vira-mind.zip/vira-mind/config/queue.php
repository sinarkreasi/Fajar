<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

return [
    'driver' => 'file',
    'max_attempts' => 3,
    'retry_delay' => 60,
];
