<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

return [
    'name' => 'Vira Mind',
    'version' => VRMIND_VERSION,
    'debug' => defined('WP_DEBUG') && WP_DEBUG,
    'timezone' => 'UTC',
];
