<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

return [
    'driver' => 'file', // 'file' or 'transient'
    'ttl' => 3600,
    'prefix' => 'vrmind_',
];
