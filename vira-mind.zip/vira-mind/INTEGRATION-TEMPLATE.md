# Integration Template Generator

## Quick Start: Create New Integration

### Step 1: Create Directory Structure

```bash
/integrations/{plugin-slug}/
├── {PluginName}Integration.php
├── Controllers/
│   └── {Feature}Controller.php
├── Services/
│   └── {Feature}AIService.php
├── Agents/
│   └── {Feature}Agent.php
├── Hooks/
│   └── {PluginName}Hooks.php
├── Jobs/
│   └── {Feature}Job.php
├── Views/
│   └── admin-page.php
├── Assets/
│   ├── scripts/
│   │   └── admin.js
│   └── styles/
│       └── admin.css
└── Config/
    └── settings.php
```

### Step 2: Main Integration Class Template

```php
<?php
declare(strict_types=1);

namespace ViraMind\Integrations\{PluginName};

use ViraMind\Core\Integrations\BaseIntegration;

if (!defined('ABSPATH')) {
    exit;
}

class {PluginName}Integration extends BaseIntegration
{
    protected string $slug = '{plugin-slug}';
    protected string $name = '{Plugin Name}';
    protected string $pluginFile = '{plugin-folder}/{plugin-file}.php';

    public function register(): void
    {
        // Load hooks
        $this->loadHooks();

        // Register admin menu
        add_action('admin_menu', function() {
            $this->registerAdminMenu(
                __'{Plugin Name} AI', 'vira-mind'),
                [$this, 'renderAdminPage']
            );
        });

        // Enqueue assets
        add_action('admin_enqueue_scripts', function($hook) {
            if (strpos($hook, 'vira-mind-{plugin-slug}') !== false) {
                $this->enqueueAssets();
            }
        });

        $this->log('{Plugin Name} integration registered');
    }

    public function renderAdminPage(): void
    {
        require_once $this->basePath . '/Views/admin-page.php';
    }
}
```

### Step 3: Agent Template

```php
<?php
declare(strict_types=1);

namespace ViraMind\Integrations\{PluginName}\Agents;

use ViraMind\Core\Integrations\BaseAgent;

if (!defined('ABSPATH')) {
    exit;
}

class {Feature}Agent extends BaseAgent
{
    protected string $systemPrompt = 'You are the Vira Mind AI Engine for {Plugin Name}. You must return clean, structured, safe output. No markdown formatting. No HTML. No scripts.';

    public function generate{Feature}(string $input): array
    {
        $userContent = "Generate {feature} for: {$input}";
        $prompt = $this->buildPrompt($userContent);

        return $this->execute($prompt, [
            'temperature' => 0.7,
            'max_tokens' => 500
        ]);
    }
}
```

### Step 4: Service Template

```php
<?php
declare(strict_types=1);

namespace ViraMind\Integrations\{PluginName}\Services;

use ViraMind\Integrations\{PluginName}\Agents\{Feature}Agent;

if (!defined('ABSPATH')) {
    exit;
}

class {Feature}AIService
{
    private {Feature}Agent $agent;

    public function __construct()
    {
        $this->agent = new {Feature}Agent();
    }

    public function process(string $data, array $context = []): string
    {
        $this->agent->setContext($context);
        $result = $this->agent->generate{Feature}($data);
        return $result['main_output'] ?? '';
    }
}
```

### Step 5: Controller Template

```php
<?php
declare(strict_types=1);

namespace ViraMind\Integrations\{PluginName}\Controllers;

if (!defined('ABSPATH')) {
    exit;
}

class {Feature}Controller
{
    private object $aiService;

    public function __construct()
    {
        $this->aiService = new \ViraMind\Integrations\{PluginName}\Services\{Feature}AIService();
    }

    public function handleAjax(): void
    {
        check_ajax_referer('vrmind_{plugin_slug}_nonce', 'nonce');

        if (!current_user_can('edit_posts')) {
            wp_send_json_error(['message' => 'Unauthorized'], 403);
        }

        $input = sanitize_text_field($_POST['input'] ?? '');

        if (empty($input)) {
            wp_send_json_error(['message' => 'Input required']);
        }

        try {
            $result = $this->aiService->process($input);
            wp_send_json_success(['result' => $result]);
        } catch (\Exception $e) {
            wp_send_json_error(['message' => $e->getMessage()]);
        }
    }
}
```

### Step 6: Hooks Template

```php
<?php
declare(strict_types=1);

namespace ViraMind\Integrations\{PluginName}\Hooks;

use ViraMind\Core\Container\Container;

if (!defined('ABSPATH')) {
    exit;
}

class {PluginName}Hooks
{
    private Container $container;

    public function __construct(Container $container)
    {
        $this->container = $container;
        $this->registerHooks();
    }

    private function registerHooks(): void
    {
        // Add your plugin-specific hooks
        add_action('{plugin_action}', [$this, 'onAction'], 10, 1);

        // AJAX handlers
        add_action('wp_ajax_vrmind_{plugin_slug}_action', [
            new \ViraMind\Integrations\{PluginName}\Controllers\{Feature}Controller(),
            'handleAjax'
        ]);
    }

    public function onAction($data): void
    {
        // Handle plugin action
        do_action('vrmind_{plugin_slug}_action', $data);
    }
}
```

### Step 7: Admin View Template

```php
<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap vrmind-admin-wrapper">
    <h1><?php echo esc_html__('{Plugin Name} AI Integration', 'vira-mind'); ?></h1>
    
    <div class="vrmind-card">
        <h2><?php echo esc_html__('Integration Status', 'vira-mind'); ?></h2>
        
        <div class="vrmind-info-row">
            <span class="vrmind-info-label"><?php echo esc_html__('Status', 'vira-mind'); ?></span>
            <span class="vrmind-badge success"><?php echo esc_html__('Active', 'vira-mind'); ?></span>
        </div>
    </div>
    
    <div class="vrmind-card">
        <h2><?php echo esc_html__('Features', 'vira-mind'); ?></h2>
        <ul style="list-style: disc; margin-left: 20px;">
            <li><?php echo esc_html__('Feature 1', 'vira-mind'); ?></li>
            <li><?php echo esc_html__('Feature 2', 'vira-mind'); ?></li>
        </ul>
    </div>
</div>
```

### Step 8: JavaScript Template

```javascript
(function($) {
    'use strict';

    const {PluginName}AI = {
        init: function() {
            this.bindEvents();
        },

        bindEvents: function() {
            $(document).on('click', '.vrmind-{plugin-slug}-btn', this.handleClick.bind(this));
        },

        handleClick: function(e) {
            e.preventDefault();
            
            const $btn = $(e.target);
            const input = $('#input-field').val();
            
            if (!input) {
                alert('Please enter input');
                return;
            }

            $btn.prop('disabled', true).text('Processing...');

            $.ajax({
                url: ajaxurl,
                method: 'POST',
                data: {
                    action: 'vrmind_{plugin_slug}_action',
                    nonce: vrmind{PluginName}.nonce,
                    input: input
                },
                success: function(response) {
                    if (response.success) {
                        alert('Success: ' + response.data.result);
                    } else {
                        alert('Error: ' + response.data.message);
                    }
                },
                error: function() {
                    alert('Request failed');
                },
                complete: function() {
                    $btn.prop('disabled', false).text('Generate');
                }
            });
        }
    };

    $(document).ready(function() {
        {PluginName}AI.init();
    });

})(jQuery);
```

### Step 9: Config Template

```php
<?php
declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

return [
    'feature_enabled' => [
        'type' => 'checkbox',
        'label' => __('Enable Feature', 'vira-mind'),
        'description' => __('Enable AI-powered feature', 'vira-mind'),
        'default' => true
    ],
    
    'max_length' => [
        'type' => 'number',
        'label' => __('Max Length', 'vira-mind'),
        'description' => __('Maximum length for generated content', 'vira-mind'),
        'default' => 150
    ]
];
```

## Common Integration Patterns

### Pattern 1: Content Generation
- Agent generates content
- Service processes and validates
- Controller handles AJAX
- Hooks trigger on save

### Pattern 2: Data Enhancement
- Agent analyzes existing data
- Service enriches with AI insights
- Background job processes bulk
- Hooks update on changes

### Pattern 3: Automation
- Hooks detect events
- Queue jobs for processing
- Agent generates recommendations
- Service applies changes

## Testing Checklist

- [ ] Plugin detection works
- [ ] Admin menu appears
- [ ] Assets load correctly
- [ ] AJAX requests work
- [ ] Nonce verification passes
- [ ] Capability checks work
- [ ] AI generation succeeds
- [ ] Error handling works
- [ ] Logging functions
- [ ] No inline JS/CSS
- [ ] All inputs sanitized
- [ ] All outputs escaped

## Common Plugins to Integrate

1. **WooCommerce** ✅ - Product AI
2. **LearnDash** - Course content
3. **FluentCRM** - Contact insights
4. **Elementor** - Content blocks
5. **WPForms** - Form suggestions
6. **Yoast SEO** - Content optimization
7. **MemberPress** - Membership content
8. **Easy Digital Downloads** - Product descriptions
9. **BuddyPress** - Community content
10. **bbPress** - Forum moderation

Use this template to quickly scaffold new integrations!
