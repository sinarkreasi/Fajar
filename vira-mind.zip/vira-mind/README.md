# Vira Mind

AI Infrastructure Layer for WordPress

## Requirements

- WordPress 6.8+
- PHP 8.2+

## Installation

1. Upload to `/wp-content/plugins/vira-mind/`
2. Run `composer install`
3. Activate through WordPress admin

## Architecture

- MVC-like pattern
- Service Container (DI)
- Modular Addon System
- AI Router Engine
- Queue/Worker System
- Middleware Layer

## Prefix

All functions and hooks use `vrmind_` prefix.
