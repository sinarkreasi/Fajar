<?php
/**
 * Example Addon Entry Point
 */

declare(strict_types=1);

namespace ViraMind\Addons\ExampleAddon;

if (!defined('ABSPATH')) {
    exit;
}

// Addon initialization code here
