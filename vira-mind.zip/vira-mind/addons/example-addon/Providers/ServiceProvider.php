<?php

declare(strict_types=1);

namespace ViraMind\Addons\ExampleAddon\Providers;

use ViraMind\Core\Container\ServiceProvider as BaseServiceProvider;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Example Addon Service Provider
 */
class ServiceProvider extends BaseServiceProvider
{
    public function register(): void
    {
        // Register addon services
    }

    public function boot(): void
    {
        // Boot addon
        add_action('vrmind_loaded', function() {
            // Addon loaded
        });
    }
}
