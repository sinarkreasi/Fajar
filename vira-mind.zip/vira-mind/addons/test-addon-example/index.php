<?php
/**
 * Test Addon Example Entry Point
 *
 * @package ViraMind\Addons\TestAddonExample
 */

defined('ABSPATH') || exit;

// Addon entry point - loaded by AddonLoader
