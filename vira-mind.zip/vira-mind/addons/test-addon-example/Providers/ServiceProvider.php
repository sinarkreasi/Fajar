<?php
/**
 * Test Addon Service Provider
 *
 * @package ViraMind\Addons\TestAddonExample
 */

namespace ViraMind\Addons\TestAddonExample\Providers;

use ViraMind\Core\Container\ServiceProvider as BaseServiceProvider;

defined('ABSPATH') || exit;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * Register services
     */
    public function register(): void
    {
        // Register any services here
    }

    /**
     * Bootstrap addon
     */
    public function boot(): void
    {
        // Add admin notice to confirm addon is working
        add_action('admin_notices', function() {
            if (!current_user_can('manage_options')) {
                return;
            }
            
            echo '<div class="notice notice-success is-dismissible">';
            echo '<p><strong>✓ Test Addon Example is active!</strong> ';
            echo 'The addon system is working correctly. ';
            echo 'You can now deactivate or uninstall this test addon.</p>';
            echo '</div>';
        });

        // Add admin menu item
        add_action('admin_menu', function() {
            add_submenu_page(
                'vira-mind',
                __('Test Addon', 'vira-mind'),
                __('Test Addon', 'vira-mind'),
                'manage_options',
                'test-addon-example',
                function() {
                    echo '<div class="wrap">';
                    echo '<h1>Test Addon Example</h1>';
                    echo '<div class="card">';
                    echo '<h2>✓ Success!</h2>';
                    echo '<p>This test addon is working correctly.</p>';
                    echo '<p><strong>What this proves:</strong></p>';
                    echo '<ul>';
                    echo '<li>Addon upload system works</li>';
                    echo '<li>Addon activation works</li>';
                    echo '<li>Service provider loads correctly</li>';
                    echo '<li>Admin menu registration works</li>';
                    echo '</ul>';
                    echo '<p><a href="' . admin_url('admin.php?page=vira-mind-addons') . '" class="button button-primary">Go to Addons Manager</a></p>';
                    echo '</div>';
                    echo '</div>';
                }
            );
        });
    }
}
