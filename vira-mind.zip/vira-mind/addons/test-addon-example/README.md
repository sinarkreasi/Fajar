# Test Addon Example

A simple test addon to verify the Vira Mind addon system is working correctly.

## Purpose

This addon demonstrates:
- Addon upload and installation
- Activation/deactivation
- Service provider loading
- Admin menu registration
- Admin notices

## Installation

### Method 1: Upload ZIP
1. Create a ZIP of this folder
2. Go to Vira Mind → Addons
3. Upload the ZIP file
4. Click Activate

### Method 2: Manual Installation
1. Copy this folder to `/wp-content/plugins/vira-mind/addons/`
2. Go to Vira Mind → Addons
3. Click Activate on "Test Addon Example"

## Verification

When active, you should see:
- ✓ Success notice in WordPress admin
- ✓ "Test Addon" menu item under Vira Mind
- ✓ Test page showing success message

## Cleanup

After verifying the system works:
1. Go to Vira Mind → Addons
2. Click Deactivate
3. Click Uninstall
4. Delete this folder if manually installed

## Creating Your Own Addon

Use this as a template:
1. Copy this folder
2. Rename folder and update addon.json
3. Update namespace in all PHP files
4. Add your functionality
5. Create ZIP and upload

## Support

See `/addons/CREATE-TEST-ADDON.md` for detailed instructions.
