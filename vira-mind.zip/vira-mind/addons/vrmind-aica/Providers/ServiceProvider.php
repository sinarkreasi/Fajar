<?php
/**
 * AI Content Assistant Service Provider
 *
 * @package ViraMind\Addons\AIContentAssistant
 */

namespace ViraMind\Addons\AIContentAssistant\Providers;

use ViraMind\Core\Container\ServiceProvider as BaseServiceProvider;
use ViraMind\Addons\AIContentAssistant\Services\ContentAIService;
use ViraMind\Addons\AIContentAssistant\Services\LinkSuggestionService;
use ViraMind\Addons\AIContentAssistant\Controllers\EditorController;
use ViraMind\Addons\AIContentAssistant\Controllers\AdminController;

defined('ABSPATH') || exit;

class ServiceProvider extends BaseServiceProvider
{
    /**
     * Register addon services
     */
    public function register(): void
    {
        // Load configuration
        $config = require __DIR__ . '/../config/assistant.php';
        $this->app->instance('aica.config', $config);

        // Register services
        $this->app->singleton(ContentAIService::class, function ($app) use ($config) {
            return new ContentAIService($app, $config);
        });

        $this->app->singleton(LinkSuggestionService::class, function ($app) use ($config) {
            return new LinkSuggestionService($app, $config);
        });

        // Register controllers
        $this->app->singleton(EditorController::class, function ($app) {
            return new EditorController($app);
        });

        $this->app->singleton(AdminController::class, function ($app) {
            return new AdminController($app);
        });
    }

    /**
     * Bootstrap addon
     */
    public function boot(): void
    {
        $config = $this->app->make('aica.config');

        if (!$config['enabled']) {
            return;
        }

        // Run migration if needed
        $this->runMigrations();

        // Register capabilities
        $this->registerCapabilities();

        // Register admin menu directly
        $this->registerAdminMenu();

        // Load routes
        $this->loadRoutes();

        // Enqueue assets
        $this->enqueueAssets();

        // Register bulk actions
        $this->registerBulkActions();

        // Auto-run hooks
        if ($config['auto_suggest_on_publish']) {
            add_action('publish_post', [$this, 'autoSuggestOnPublish'], 10, 2);
        }
    }

    /**
     * Register admin menu
     */
    protected function registerAdminMenu(): void
    {
        add_action('admin_menu', function () {
            add_submenu_page(
                'vira-mind',
                __('AI Content Assistant', 'vira-mind'),
                __('Content Assistant', 'vira-mind'),
                'manage_options',
                'vrmind-aica',
                function () {
                    try {
                        $controller = $this->app->make(AdminController::class);
                        $controller->renderSettings();
                    } catch (\Exception $e) {
                        echo '<div class="wrap">';
                        echo '<h1>' . esc_html__('AI Content Assistant', 'vira-mind') . '</h1>';
                        echo '<div class="notice notice-error"><p>' . esc_html($e->getMessage()) . '</p></div>';
                        echo '<pre>' . esc_html($e->getTraceAsString()) . '</pre>';
                        echo '</div>';
                    }
                }
            );
        }, 50); // Higher priority to ensure parent menu exists
    }

    /**
     * Run database migrations
     */
    protected function runMigrations(): void
    {
        $migrated = get_option('vrmind_aica_migrated', false);
        
        if (!$migrated) {
            require_once __DIR__ . '/../migrations/create_ai_content_logs_table.php';
            vrmind_aica_create_logs_table();
            update_option('vrmind_aica_migrated', true);
        }
    }

    /**
     * Register addon capabilities
     */
    protected function registerCapabilities(): void
    {
        add_action('init', function () {
            $config = $this->app->make('aica.config');
            
            foreach ($config['roles_allowed'] as $role_name) {
                $role = get_role($role_name);
                if ($role) {
                    $role->add_cap('vrmind_use_content_assistant');
                    if (in_array($role_name, ['administrator', 'editor'])) {
                        $role->add_cap('vrmind_bulk_content_assistant');
                    }
                }
            }
        });
    }

    /**
     * Load addon routes
     */
    protected function loadRoutes(): void
    {
        $apiRoutes = __DIR__ . '/../routes/api.php';
        $adminRoutes = __DIR__ . '/../routes/admin.php';
        
        if (file_exists($apiRoutes)) {
            require_once $apiRoutes;
        }
        
        if (file_exists($adminRoutes)) {
            require_once $adminRoutes;
        }
        
        // Log that routes were loaded
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('AICA: Admin routes loaded from ' . $adminRoutes);
        }
    }

    /**
     * Enqueue editor and admin assets
     */
    protected function enqueueAssets(): void
    {
        // Editor assets
        add_action('enqueue_block_editor_assets', function () {
            $config = $this->app->make('aica.config');
            
            if (!current_user_can('vrmind_use_content_assistant')) {
                return;
            }

            $post_type = get_post_type();
            if (!in_array($post_type, $config['post_types'])) {
                return;
            }

            wp_enqueue_script(
                'vrmind-aica-editor',
                plugins_url('resources/scripts/editor-assistant.js', dirname(__FILE__)),
                ['wp-element', 'wp-components', 'wp-data', 'wp-api-fetch'],
                '1.0.0',
                true
            );

            wp_enqueue_style(
                'vrmind-aica-editor',
                plugins_url('resources/styles/editor-assistant.css', dirname(__FILE__)),
                [],
                '1.0.0'
            );

            wp_localize_script('vrmind-aica-editor', 'vrmindAICA', [
                'nonce' => wp_create_nonce('vrmind-aica'),
                'apiUrl' => rest_url('vrmind/v1/content-assistant'),
                'config' => [
                    'tones' => ['friendly', 'formal', 'casual', 'professional'],
                    'lengths' => ['short', 'medium', 'long'],
                ],
            ]);
        });

        // Admin assets
        add_action('admin_enqueue_scripts', function ($hook) {
            if (strpos($hook, 'vrmind-aica') === false) {
                return;
            }

            wp_enqueue_script(
                'vrmind-aica-admin',
                plugins_url('resources/scripts/admin-settings.js', dirname(__FILE__)),
                ['jquery'],
                '1.0.0',
                true
            );

            wp_enqueue_style(
                'vrmind-aica-admin',
                plugins_url('resources/styles/admin-settings.css', dirname(__FILE__)),
                [],
                '1.0.0'
            );
        });
    }

    /**
     * Register bulk actions for post list
     */
    protected function registerBulkActions(): void
    {
        add_filter('bulk_actions-edit-post', function ($actions) {
            if (current_user_can('vrmind_bulk_content_assistant')) {
                $actions['vrmind_bulk_rewrite'] = __('AI Rewrite Content', 'vira-mind');
                $actions['vrmind_bulk_meta'] = __('AI Generate Meta', 'vira-mind');
            }
            return $actions;
        });

        add_filter('handle_bulk_actions-edit-post', function ($redirect_to, $action, $post_ids) {
            if (!in_array($action, ['vrmind_bulk_rewrite', 'vrmind_bulk_meta'])) {
                return $redirect_to;
            }

            if (!current_user_can('vrmind_bulk_content_assistant')) {
                return $redirect_to;
            }

            $controller = $this->app->make(EditorController::class);
            $controller->handleBulkAction($action, $post_ids);

            $redirect_to = add_query_arg('vrmind_bulk_queued', count($post_ids), $redirect_to);
            return $redirect_to;
        }, 10, 3);
    }

    /**
     * Auto-suggest on publish hook
     */
    public function autoSuggestOnPublish(int $post_id, \WP_Post $post): void
    {
        if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) {
            return;
        }

        // Queue suggestion job
        $queue = vrmind_queue();
        $queue->dispatch(new \ViraMind\Addons\AIContentAssistant\Jobs\AutoSuggestJob($post_id));
    }
}
