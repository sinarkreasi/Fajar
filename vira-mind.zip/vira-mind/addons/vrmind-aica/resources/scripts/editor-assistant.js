/**
 * Editor Assistant Script
 *
 * @package ViraMind\Addons\AIContentAssistant
 */

(function() {
    'use strict';

    const { registerPlugin } = wp.plugins;
    const { PluginSidebar, PluginSidebarMoreMenuItem } = wp.editPost;
    const { createElement: el, useState } = wp.element;
    const { Button, SelectControl, TextControl, PanelBody, Spinner } = wp.components;
    const { useSelect, useDispatch } = wp.data;
    const apiFetch = wp.apiFetch;

    const AIContentAssistant = () => {
        const [activeTab, setActiveTab] = useState('generate');
        const [loading, setLoading] = useState(false);
        const [result, setResult] = useState(null);
        const [error, setError] = useState(null);

        // Form states
        const [topic, setTopic] = useState('');
        const [tone, setTone] = useState('friendly');
        const [length, setLength] = useState('medium');
        const [keywords, setKeywords] = useState('');
        const [rewriteMode, setRewriteMode] = useState('seo');

        const postId = useSelect(select => select('core/editor').getCurrentPostId());
        const { editPost } = useDispatch('core/editor');
        const { createNotice } = useDispatch('core/notices');

        const handleGenerate = async () => {
            if (!topic.trim()) {
                createNotice('error', 'Please enter a topic', { type: 'snackbar' });
                return;
            }

            setLoading(true);
            setError(null);

            try {
                const response = await apiFetch({
                    path: '/vrmind/v1/content-assistant/generate',
                    method: 'POST',
                    data: {
                        topic,
                        tone,
                        length,
                        focus_keywords: keywords.split(',').map(k => k.trim()).filter(Boolean),
                        post_type: 'post'
                    }
                });

                if (response.success) {
                    setResult(response.data);
                    createNotice('success', 'Content generated successfully!', { type: 'snackbar' });
                }
            } catch (err) {
                setError(err.message || 'Failed to generate content');
                createNotice('error', err.message || 'Failed to generate content', { type: 'snackbar' });
            } finally {
                setLoading(false);
            }
        };

        const handleRewrite = async () => {
            setLoading(true);
            setError(null);

            try {
                const response = await apiFetch({
                    path: '/vrmind/v1/content-assistant/rewrite',
                    method: 'POST',
                    data: {
                        post_id: postId,
                        mode: rewriteMode,
                        target_keywords: keywords.split(',').map(k => k.trim()).filter(Boolean)
                    }
                });

                if (response.success) {
                    setResult(response.data);
                    createNotice('success', 'Content rewritten!', { type: 'snackbar' });
                }
            } catch (err) {
                setError(err.message || 'Failed to rewrite content');
                createNotice('error', err.message || 'Failed to rewrite', { type: 'snackbar' });
            } finally {
                setLoading(false);
            }
        };

        const handleSuggestLinks = async () => {
            setLoading(true);
            setError(null);

            try {
                const response = await apiFetch({
                    path: '/vrmind/v1/content-assistant/suggest-links',
                    method: 'POST',
                    data: {
                        post_id: postId,
                        limit: 5
                    }
                });

                if (response.success) {
                    setResult({ links: response.data });
                    createNotice('success', 'Link suggestions ready!', { type: 'snackbar' });
                }
            } catch (err) {
                setError(err.message || 'Failed to suggest links');
                createNotice('error', err.message || 'Failed to suggest links', { type: 'snackbar' });
            } finally {
                setLoading(false);
            }
        };

        const handleGenerateSchema = async () => {
            setLoading(true);
            setError(null);

            try {
                const response = await apiFetch({
                    path: '/vrmind/v1/content-assistant/generate-schema',
                    method: 'POST',
                    data: { post_id: postId }
                });

                if (response.success) {
                    setResult({ schema: response.data });
                    createNotice('success', 'Schema generated!', { type: 'snackbar' });
                }
            } catch (err) {
                setError(err.message || 'Failed to generate schema');
                createNotice('error', err.message || 'Failed to generate schema', { type: 'snackbar' });
            } finally {
                setLoading(false);
            }
        };

        const handleAccept = () => {
            if (!result) return;

            if (result.title) {
                editPost({ title: result.title });
            }
            if (result.excerpt) {
                editPost({ excerpt: result.excerpt });
            }
            if (result.suggested_content) {
                editPost({ content: result.suggested_content });
            }

            createNotice('success', 'Content applied to editor!', { type: 'snackbar' });
            setResult(null);
        };

        return el('div', { className: 'vrmind-aica-sidebar' },
            el(PanelBody, { title: 'Actions', initialOpen: true },
                el(Button, {
                    variant: activeTab === 'generate' ? 'primary' : 'secondary',
                    onClick: () => setActiveTab('generate'),
                    style: { marginRight: '8px' }
                }, 'Generate'),
                el(Button, {
                    variant: activeTab === 'rewrite' ? 'primary' : 'secondary',
                    onClick: () => setActiveTab('rewrite'),
                    style: { marginRight: '8px' }
                }, 'Rewrite'),
                el(Button, {
                    variant: activeTab === 'links' ? 'primary' : 'secondary',
                    onClick: () => setActiveTab('links'),
                    style: { marginRight: '8px' }
                }, 'Links'),
                el(Button, {
                    variant: activeTab === 'schema' ? 'primary' : 'secondary',
                    onClick: () => setActiveTab('schema')
                }, 'Schema')
            ),

            activeTab === 'generate' && el(PanelBody, { title: 'Generate Content', initialOpen: true },
                el(TextControl, {
                    label: 'Topic',
                    value: topic,
                    onChange: setTopic,
                    placeholder: 'Enter topic...'
                }),
                el(SelectControl, {
                    label: 'Tone',
                    value: tone,
                    options: vrmindAICA.config.tones.map(t => ({ label: t, value: t })),
                    onChange: setTone
                }),
                el(SelectControl, {
                    label: 'Length',
                    value: length,
                    options: vrmindAICA.config.lengths.map(l => ({ label: l, value: l })),
                    onChange: setLength
                }),
                el(TextControl, {
                    label: 'Keywords',
                    value: keywords,
                    onChange: setKeywords,
                    placeholder: 'keyword1, keyword2'
                }),
                el(Button, {
                    variant: 'primary',
                    onClick: handleGenerate,
                    disabled: loading,
                    isBusy: loading
                }, loading ? 'Generating...' : 'Generate')
            ),

            activeTab === 'rewrite' && el(PanelBody, { title: 'Rewrite Content', initialOpen: true },
                el(SelectControl, {
                    label: 'Mode',
                    value: rewriteMode,
                    options: [
                        { label: 'SEO Optimization', value: 'seo' },
                        { label: 'Improve Clarity', value: 'clarity' },
                        { label: 'Shorten', value: 'shorten' }
                    ],
                    onChange: setRewriteMode
                }),
                el(TextControl, {
                    label: 'Keywords',
                    value: keywords,
                    onChange: setKeywords
                }),
                el(Button, {
                    variant: 'primary',
                    onClick: handleRewrite,
                    disabled: loading,
                    isBusy: loading
                }, loading ? 'Rewriting...' : 'Rewrite')
            ),

            activeTab === 'links' && el(PanelBody, { title: 'Link Suggestions', initialOpen: true },
                el('p', {}, 'Get AI-powered internal link suggestions.'),
                el(Button, {
                    variant: 'primary',
                    onClick: handleSuggestLinks,
                    disabled: loading,
                    isBusy: loading
                }, loading ? 'Analyzing...' : 'Suggest Links')
            ),

            activeTab === 'schema' && el(PanelBody, { title: 'Schema Generation', initialOpen: true },
                el('p', {}, 'Generate JSON-LD schema markup.'),
                el(Button, {
                    variant: 'primary',
                    onClick: handleGenerateSchema,
                    disabled: loading,
                    isBusy: loading
                }, loading ? 'Generating...' : 'Generate Schema')
            ),

            result && el(PanelBody, { title: 'Result', initialOpen: true },
                el('div', { style: { marginBottom: '12px' } },
                    result.title && el('p', {}, el('strong', {}, 'Title: '), result.title),
                    result.excerpt && el('p', {}, el('strong', {}, 'Excerpt: '), result.excerpt),
                    result.links && el('div', {},
                        el('strong', {}, 'Suggested Links:'),
                        el('ul', {},
                            result.links.map((link, i) =>
                                el('li', { key: i },
                                    el('a', { href: link.url, target: '_blank' }, link.title),
                                    ' - ', link.anchor
                                )
                            )
                        )
                    )
                ),
                el(Button, {
                    variant: 'primary',
                    onClick: handleAccept,
                    style: { marginRight: '8px' }
                }, 'Accept'),
                el(Button, {
                    variant: 'secondary',
                    onClick: () => setResult(null)
                }, 'Cancel')
            ),

            error && el('div', { className: 'notice notice-error', style: { margin: '12px 0' } },
                el('p', {}, error)
            )
        );
    };

    registerPlugin('vrmind-ai-content-assistant', {
        render: () => el(PluginSidebarMoreMenuItem, {
            target: 'vrmind-aica-sidebar',
            icon: 'edit'
        }, 'AI Assistant'),
        icon: 'edit'
    });

    registerPlugin('vrmind-aica-sidebar-content', {
        render: () => el(PluginSidebar, {
            name: 'vrmind-aica-sidebar',
            title: 'AI Content Assistant',
            icon: 'edit'
        }, el(AIContentAssistant))
    });
})();
