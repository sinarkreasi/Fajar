/**
 * Admin Settings Script
 *
 * @package ViraMind\Addons\AIContentAssistant
 */

(function($) {
    'use strict';

    $(document).ready(function() {
        // Form validation
        $('form').on('submit', function(e) {
            const linkLimit = parseInt($('input[name="link_suggestion_limit"]').val());
            
            if (linkLimit < 1 || linkLimit > 20) {
                e.preventDefault();
                alert('Link suggestion limit must be between 1 and 20');
                return false;
            }
        });

        // Auto-refresh stats every 30 seconds
        setInterval(function() {
            location.reload();
        }, 30000);
    });
})(jQuery);
