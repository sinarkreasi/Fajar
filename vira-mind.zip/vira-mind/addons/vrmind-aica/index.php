<?php
/**
 * Vira Mind AI Content Assistant Addon
 *
 * @package ViraMind\Addons\AIContentAssistant
 */

defined('ABSPATH') || exit;

// Addon entry point - loaded by AddonLoader
