# Vira Mind AI Content Assistant

AI-powered content creation and optimization directly in WordPress editor.

## Features

- **Generate Posts**: Create full posts with title, excerpt, content blocks, and CTAs
- **SEO Rewrite**: Optimize content for target keywords with meta suggestions
- **Internal Link Suggestions**: AI-powered link recommendations using RAG
- **Schema Generation**: Auto-generate JSON-LD for Article, Product, FAQ, Course
- **Tone & Clarity**: Improve readability and adjust tone
- **Bulk Processing**: Queue-based bulk operations for multiple posts
- **Usage Tracking**: Monitor API calls, tokens, and costs

## Installation

1. Upload to `/wp-content/plugins/vira-mind/addons/vrmind-aica/`
2. Activate from Vira Mind → Addons
3. Configure settings under Vira Mind → AICA

## Usage

### Editor Panel

1. Open post/page editor (Gutenberg or Classic)
2. Find "Vira Mind Assistant" in sidebar
3. Choose action: Generate, Rewrite, Suggest Links, or Generate Schema
4. Review and accept suggestions

### Bulk Operations

1. Navigate to Posts → All Posts
2. Select multiple posts
3. Choose "Bulk Actions" → "AI Rewrite" or "Generate Meta"
4. Jobs process in background queue

## Capabilities

- `vrmind_use_content_assistant` - Use assistant in editor
- `vrmind_bulk_content_assistant` - Run bulk operations

Assign to roles via Vira Mind → Settings → Permissions

## API Endpoints

- `POST /wp-json/vrmind/v1/content-assistant/generate`
- `POST /wp-json/vrmind/v1/content-assistant/rewrite`
- `POST /wp-json/vrmind/v1/content-assistant/suggest-links`
- `POST /wp-json/vrmind/v1/content-assistant/generate-schema`
- `POST /wp-json/vrmind/v1/content-assistant/bulk`

All endpoints require nonce and capability checks.

## Security

- All inputs sanitized and validated
- Prompts hashed before logging (no PII stored)
- Rate limiting via core AI router
- Capability-based access control
- No inline JS/CSS in views

## Configuration

Edit `/config/assistant.php` or use admin settings:

- Enable/disable features
- Set default tone and length
- Configure role permissions
- Set token limits
- Enable usage logging

## Development

Run tests:
```bash
composer test -- --filter=AIContentAssistant
```

## Support

See main Vira Mind documentation at `/DEVELOPER-API.md`
