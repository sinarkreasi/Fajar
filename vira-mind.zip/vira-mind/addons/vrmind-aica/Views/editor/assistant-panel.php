<?php
/**
 * Editor Assistant Panel View
 *
 * @package ViraMind\Addons\AIContentAssistant
 */

defined('ABSPATH') || exit;
?>

<div id="vrmind-aica-panel" class="vrmind-assistant-panel">
    <div class="panel-header">
        <h3><?php _e('AI Content Assistant', 'vira-mind'); ?></h3>
    </div>

    <div class="panel-body">
        <div class="action-tabs">
            <button class="tab-btn active" data-tab="generate"><?php _e('Generate', 'vira-mind'); ?></button>
            <button class="tab-btn" data-tab="rewrite"><?php _e('Rewrite', 'vira-mind'); ?></button>
            <button class="tab-btn" data-tab="links"><?php _e('Links', 'vira-mind'); ?></button>
            <button class="tab-btn" data-tab="schema"><?php _e('Schema', 'vira-mind'); ?></button>
        </div>

        <div class="tab-content active" data-content="generate">
            <div class="form-group">
                <label><?php _e('Topic', 'vira-mind'); ?></label>
                <input type="text" id="aica-topic" class="widefat" placeholder="<?php esc_attr_e('Enter topic...', 'vira-mind'); ?>">
            </div>

            <div class="form-group">
                <label><?php _e('Tone', 'vira-mind'); ?></label>
                <select id="aica-tone" class="widefat">
                    <option value="friendly"><?php _e('Friendly', 'vira-mind'); ?></option>
                    <option value="formal"><?php _e('Formal', 'vira-mind'); ?></option>
                    <option value="casual"><?php _e('Casual', 'vira-mind'); ?></option>
                    <option value="professional"><?php _e('Professional', 'vira-mind'); ?></option>
                </select>
            </div>

            <div class="form-group">
                <label><?php _e('Length', 'vira-mind'); ?></label>
                <select id="aica-length" class="widefat">
                    <option value="short"><?php _e('Short', 'vira-mind'); ?></option>
                    <option value="medium" selected><?php _e('Medium', 'vira-mind'); ?></option>
                    <option value="long"><?php _e('Long', 'vira-mind'); ?></option>
                </select>
            </div>

            <div class="form-group">
                <label><?php _e('Keywords (comma-separated)', 'vira-mind'); ?></label>
                <input type="text" id="aica-keywords" class="widefat" placeholder="<?php esc_attr_e('keyword1, keyword2', 'vira-mind'); ?>">
            </div>

            <button class="button button-primary button-large" id="aica-generate-btn">
                <?php _e('Generate Content', 'vira-mind'); ?>
            </button>
        </div>

        <div class="tab-content" data-content="rewrite">
            <div class="form-group">
                <label><?php _e('Rewrite Mode', 'vira-mind'); ?></label>
                <select id="aica-rewrite-mode" class="widefat">
                    <option value="seo"><?php _e('SEO Optimization', 'vira-mind'); ?></option>
                    <option value="clarity"><?php _e('Improve Clarity', 'vira-mind'); ?></option>
                    <option value="shorten"><?php _e('Shorten Content', 'vira-mind'); ?></option>
                </select>
            </div>

            <div class="form-group">
                <label><?php _e('Target Keywords', 'vira-mind'); ?></label>
                <input type="text" id="aica-rewrite-keywords" class="widefat">
            </div>

            <button class="button button-primary button-large" id="aica-rewrite-btn">
                <?php _e('Rewrite Content', 'vira-mind'); ?>
            </button>
        </div>

        <div class="tab-content" data-content="links">
            <p><?php _e('Get AI-powered internal link suggestions for your content.', 'vira-mind'); ?></p>
            
            <button class="button button-primary button-large" id="aica-links-btn">
                <?php _e('Suggest Links', 'vira-mind'); ?>
            </button>
        </div>

        <div class="tab-content" data-content="schema">
            <p><?php _e('Generate JSON-LD schema markup for this post.', 'vira-mind'); ?></p>
            
            <button class="button button-primary button-large" id="aica-schema-btn">
                <?php _e('Generate Schema', 'vira-mind'); ?>
            </button>
        </div>

        <div class="result-area" id="aica-result" style="display: none;">
            <div class="result-header">
                <h4><?php _e('Result', 'vira-mind'); ?></h4>
                <button class="button-link" id="aica-close-result">&times;</button>
            </div>
            <div class="result-content" id="aica-result-content"></div>
            <div class="result-actions">
                <button class="button button-primary" id="aica-accept-btn"><?php _e('Accept', 'vira-mind'); ?></button>
                <button class="button" id="aica-cancel-btn"><?php _e('Cancel', 'vira-mind'); ?></button>
            </div>
        </div>

        <div class="loading-indicator" id="aica-loading" style="display: none;">
            <span class="spinner is-active"></span>
            <p><?php _e('Generating...', 'vira-mind'); ?></p>
        </div>
    </div>
</div>
