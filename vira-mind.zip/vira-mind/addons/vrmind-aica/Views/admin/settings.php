<?php
/**
 * Admin Settings View
 *
 * @package ViraMind\Addons\AIContentAssistant
 */

defined('ABSPATH') || exit;

$settings = get_option('vrmind_aica_settings', []);
$enabled = $settings['enabled'] ?? true;
$default_tone = $settings['default_tone'] ?? 'friendly';
$default_length = $settings['default_length'] ?? 'medium';
$auto_suggest = $settings['auto_suggest_on_publish'] ?? false;
$auto_schema = $settings['auto_schema_on_publish'] ?? false;
$link_limit = $settings['link_suggestion_limit'] ?? 5;
?>

<div class="wrap vrmind-admin">
    <h1><?php _e('AI Content Assistant Settings', 'vira-mind'); ?></h1>

    <div class="vrmind-grid">
        <div class="vrmind-col-8">
            <form method="post" action="">
                <?php wp_nonce_field('vrmind_aica_settings'); ?>
                <input type="hidden" name="vrmind_aica_settings" value="1">

                <div class="vrmind-card">
                    <h2><?php _e('General Settings', 'vira-mind'); ?></h2>

                    <table class="form-table">
                        <tr>
                            <th><?php _e('Enable Content Assistant', 'vira-mind'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="enabled" value="1" <?php checked($enabled); ?>>
                                    <?php _e('Enable AI content generation features', 'vira-mind'); ?>
                                </label>
                            </td>
                        </tr>

                        <tr>
                            <th><?php _e('Default Tone', 'vira-mind'); ?></th>
                            <td>
                                <select name="default_tone">
                                    <option value="friendly" <?php selected($default_tone, 'friendly'); ?>><?php _e('Friendly', 'vira-mind'); ?></option>
                                    <option value="formal" <?php selected($default_tone, 'formal'); ?>><?php _e('Formal', 'vira-mind'); ?></option>
                                    <option value="casual" <?php selected($default_tone, 'casual'); ?>><?php _e('Casual', 'vira-mind'); ?></option>
                                    <option value="professional" <?php selected($default_tone, 'professional'); ?>><?php _e('Professional', 'vira-mind'); ?></option>
                                </select>
                            </td>
                        </tr>

                        <tr>
                            <th><?php _e('Default Length', 'vira-mind'); ?></th>
                            <td>
                                <select name="default_length">
                                    <option value="short" <?php selected($default_length, 'short'); ?>><?php _e('Short (300-500 words)', 'vira-mind'); ?></option>
                                    <option value="medium" <?php selected($default_length, 'medium'); ?>><?php _e('Medium (800-1200 words)', 'vira-mind'); ?></option>
                                    <option value="long" <?php selected($default_length, 'long'); ?>><?php _e('Long (1500-2000 words)', 'vira-mind'); ?></option>
                                </select>
                            </td>
                        </tr>

                        <tr>
                            <th><?php _e('Link Suggestions', 'vira-mind'); ?></th>
                            <td>
                                <input type="number" name="link_suggestion_limit" value="<?php echo esc_attr($link_limit); ?>" min="1" max="20">
                                <p class="description"><?php _e('Maximum number of internal link suggestions', 'vira-mind'); ?></p>
                            </td>
                        </tr>
                    </table>
                </div>

                <div class="vrmind-card">
                    <h2><?php _e('Automation', 'vira-mind'); ?></h2>

                    <table class="form-table">
                        <tr>
                            <th><?php _e('Auto-suggest on Publish', 'vira-mind'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="auto_suggest_on_publish" value="1" <?php checked($auto_suggest); ?>>
                                    <?php _e('Automatically suggest improvements when publishing posts', 'vira-mind'); ?>
                                </label>
                            </td>
                        </tr>

                        <tr>
                            <th><?php _e('Auto-generate Schema', 'vira-mind'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="auto_schema_on_publish" value="1" <?php checked($auto_schema); ?>>
                                    <?php _e('Automatically generate JSON-LD schema on publish', 'vira-mind'); ?>
                                </label>
                            </td>
                        </tr>
                    </table>
                </div>

                <p class="submit">
                    <button type="submit" class="button button-primary"><?php _e('Save Settings', 'vira-mind'); ?></button>
                </p>
            </form>
        </div>

        <div class="vrmind-col-4">
            <div class="vrmind-card">
                <h2><?php _e('Usage Statistics', 'vira-mind'); ?></h2>
                <div class="vrmind-stats">
                    <div class="stat-item">
                        <span class="stat-label"><?php _e('Calls Today', 'vira-mind'); ?></span>
                        <span class="stat-value"><?php echo esc_html($stats['calls_today']); ?></span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label"><?php _e('Tokens Today', 'vira-mind'); ?></span>
                        <span class="stat-value"><?php echo esc_html(number_format($stats['tokens_today'])); ?></span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label"><?php _e('Total Calls', 'vira-mind'); ?></span>
                        <span class="stat-value"><?php echo esc_html($stats['calls_total']); ?></span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label"><?php _e('Avg Tokens', 'vira-mind'); ?></span>
                        <span class="stat-value"><?php echo esc_html($stats['avg_tokens']); ?></span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label"><?php _e('Failed Today', 'vira-mind'); ?></span>
                        <span class="stat-value"><?php echo esc_html($stats['failed_calls']); ?></span>
                    </div>
                </div>
            </div>

            <div class="vrmind-card">
                <h2><?php _e('Quick Guide', 'vira-mind'); ?></h2>
                <ul class="vrmind-list">
                    <li><?php _e('Open post editor to see AI Assistant panel', 'vira-mind'); ?></li>
                    <li><?php _e('Click "Generate" to create new content', 'vira-mind'); ?></li>
                    <li><?php _e('Use "Rewrite" to optimize existing content', 'vira-mind'); ?></li>
                    <li><?php _e('Get internal link suggestions automatically', 'vira-mind'); ?></li>
                    <li><?php _e('Generate JSON-LD schema for SEO', 'vira-mind'); ?></li>
                </ul>
            </div>
        </div>
    </div>
</div>
