<?php
/**
 * Create AI Content Logs Table Migration
 *
 * @package ViraMind\Addons\AIContentAssistant
 */

defined('ABSPATH') || exit;

/**
 * Run migration
 */
function vrmind_aica_create_logs_table(): void
{
    global $wpdb;

    $table_name = $wpdb->prefix . 'vrmind_ai_content_logs';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id bigint(20) UNSIGNED NOT NULL,
        post_id bigint(20) UNSIGNED NULL,
        action varchar(50) NOT NULL,
        prompt_hash varchar(64) NOT NULL,
        model varchar(100) NOT NULL,
        tokens int(11) NOT NULL DEFAULT 0,
        status varchar(20) NOT NULL DEFAULT 'success',
        created_at datetime NOT NULL,
        PRIMARY KEY (id),
        KEY user_id (user_id),
        KEY post_id (post_id),
        KEY action (action),
        KEY created_at (created_at)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

/**
 * Rollback migration
 */
function vrmind_aica_drop_logs_table(): void
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'vrmind_ai_content_logs';
    $wpdb->query("DROP TABLE IF EXISTS $table_name");
}

// Run on addon activation
register_activation_hook(__FILE__, 'vrmind_aica_create_logs_table');
register_deactivation_hook(__FILE__, 'vrmind_aica_drop_logs_table');
