<?php
/**
 * Editor Controller - Handles editor panel actions
 *
 * @package ViraMind\Addons\AIContentAssistant
 */

namespace ViraMind\Addons\AIContentAssistant\Controllers;

use ViraMind\Core\Container\Container;
use ViraMind\Addons\AIContentAssistant\Services\ContentAIService;
use ViraMind\Addons\AIContentAssistant\Services\LinkSuggestionService;
use ViraMind\Addons\AIContentAssistant\Jobs\BulkRewriteJob;
use ViraMind\Addons\AIContentAssistant\Jobs\BulkMetaGenJob;
use WP_REST_Request;
use WP_REST_Response;
use WP_Error;

defined('ABSPATH') || exit;

class EditorController
{
    protected Container $app;
    protected ContentAIService $contentService;
    protected LinkSuggestionService $linkService;
    protected array $config;

    public function __construct(Container $app)
    {
        $this->app = $app;
        $this->contentService = $app->make(ContentAIService::class);
        $this->linkService = $app->make(LinkSuggestionService::class);
        $this->config = $app->make('aica.config');
    }

    /**
     * Generate post content
     */
    public function generate(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        try {
            $params = $this->sanitizeGenerateParams($request->get_json_params());
            
            // Check rate limit
            if (!$this->checkRateLimit()) {
                return new WP_Error(
                    'rate_limit_exceeded',
                    __('Daily rate limit exceeded. Please try again tomorrow.', 'vira-mind'),
                    ['status' => 429]
                );
            }

            $result = $this->contentService->generatePost($params);

            return new WP_REST_Response([
                'success' => true,
                'data' => $result,
            ], 200);

        } catch (\Exception $e) {
            return new WP_Error(
                'generation_failed',
                $e->getMessage(),
                ['status' => 500]
            );
        }
    }

    /**
     * Rewrite existing content
     */
    public function rewrite(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        try {
            $params = $request->get_json_params();
            $post_id = absint($params['post_id'] ?? 0);
            
            if (!$post_id || !get_post($post_id)) {
                return new WP_Error('invalid_post', __('Invalid post ID', 'vira-mind'), ['status' => 400]);
            }

            if (!current_user_can('edit_post', $post_id)) {
                return new WP_Error('forbidden', __('You cannot edit this post', 'vira-mind'), ['status' => 403]);
            }

            if (!$this->checkRateLimit()) {
                return new WP_Error('rate_limit_exceeded', __('Rate limit exceeded', 'vira-mind'), ['status' => 429]);
            }

            $options = [
                'mode' => sanitize_text_field($params['mode'] ?? 'seo'),
                'target_keywords' => array_map('sanitize_text_field', $params['target_keywords'] ?? []),
            ];

            $result = $this->contentService->rewriteDraft($post_id, $options);

            return new WP_REST_Response([
                'success' => true,
                'data' => $result,
            ], 200);

        } catch (\Exception $e) {
            return new WP_Error('rewrite_failed', $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Suggest internal links
     */
    public function suggestLinks(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        try {
            $params = $request->get_json_params();
            $post_id = absint($params['post_id'] ?? 0);
            $content = wp_kses_post($params['content_excerpt'] ?? '');
            $limit = absint($params['limit'] ?? $this->config['link_suggestion_limit']);

            if (!$post_id && !$content) {
                return new WP_Error('missing_params', __('Post ID or content required', 'vira-mind'), ['status' => 400]);
            }

            $suggestions = $this->linkService->suggestLinks($post_id, $content, $limit);

            return new WP_REST_Response([
                'success' => true,
                'data' => $suggestions,
            ], 200);

        } catch (\Exception $e) {
            return new WP_Error('suggestion_failed', $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Generate JSON-LD schema
     */
    public function generateSchema(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        try {
            $params = $request->get_json_params();
            $post_id = absint($params['post_id'] ?? 0);

            if (!$post_id || !get_post($post_id)) {
                return new WP_Error('invalid_post', __('Invalid post ID', 'vira-mind'), ['status' => 400]);
            }

            $schema = $this->contentService->generateSchema($post_id);

            return new WP_REST_Response([
                'success' => true,
                'data' => $schema,
            ], 200);

        } catch (\Exception $e) {
            return new WP_Error('schema_failed', $e->getMessage(), ['status' => 500]);
        }
    }

    /**
     * Handle bulk actions
     */
    public function handleBulkAction(string $action, array $post_ids): void
    {
        $queue = vrmind_queue();
        $batch_size = $this->config['bulk_job_batch_size'];

        $chunks = array_chunk($post_ids, $batch_size);

        foreach ($chunks as $chunk) {
            if ($action === 'vrmind_bulk_rewrite') {
                $queue->dispatch(new BulkRewriteJob($chunk));
            } elseif ($action === 'vrmind_bulk_meta') {
                $queue->dispatch(new BulkMetaGenJob($chunk));
            }
        }
    }

    /**
     * Sanitize generation parameters
     */
    protected function sanitizeGenerateParams(array $params): array
    {
        return [
            'topic' => sanitize_text_field($params['topic'] ?? ''),
            'length' => in_array($params['length'] ?? '', ['short', 'medium', 'long']) 
                ? $params['length'] 
                : $this->config['default_length'],
            'tone' => sanitize_text_field($params['tone'] ?? $this->config['default_tone']),
            'focus_keywords' => array_map('sanitize_text_field', $params['focus_keywords'] ?? []),
            'post_type' => sanitize_text_field($params['post_type'] ?? 'post'),
        ];
    }

    /**
     * Check user rate limit
     */
    protected function checkRateLimit(): bool
    {
        $user = wp_get_current_user();
        $role = $user->roles[0] ?? 'subscriber';
        
        $limit = $this->config['rate_limits'][$role] ?? 0;
        if ($limit === 0) {
            return false;
        }

        $cache_key = 'vrmind_aica_rate_' . $user->ID . '_' . date('Y-m-d');
        $count = (int) vrmind_cache()->get($cache_key, 0);

        if ($count >= $limit) {
            return false;
        }

        vrmind_cache()->set($cache_key, $count + 1, 86400); // 24 hours
        return true;
    }
}
