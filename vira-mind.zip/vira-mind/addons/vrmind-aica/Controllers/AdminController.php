<?php
/**
 * Admin Controller - Settings and dashboard
 *
 * @package ViraMind\Addons\AIContentAssistant
 */

namespace ViraMind\Addons\AIContentAssistant\Controllers;

use ViraMind\Core\Container\Container;

defined('ABSPATH') || exit;

class AdminController
{
    protected Container $app;
    protected array $config;

    public function __construct(Container $app)
    {
        $this->app = $app;
        $this->config = $app->make('aica.config');
    }

    /**
     * Render settings page
     */
    public function renderSettings(): void
    {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'vira-mind'));
        }

        // Handle form submission
        if (isset($_POST['vrmind_aica_settings']) && check_admin_referer('vrmind_aica_settings')) {
            $this->saveSettings($_POST);
            echo '<div class="notice notice-success"><p>' . __('Settings saved.', 'vira-mind') . '</p></div>';
        }

        $stats = $this->getUsageStats();
        
        require __DIR__ . '/../Views/admin/settings.php';
    }

    /**
     * Save settings
     */
    protected function saveSettings(array $post_data): void
    {
        $settings = [
            'enabled' => isset($post_data['enabled']),
            'default_tone' => sanitize_text_field($post_data['default_tone'] ?? 'friendly'),
            'default_length' => sanitize_text_field($post_data['default_length'] ?? 'medium'),
            'auto_suggest_on_publish' => isset($post_data['auto_suggest_on_publish']),
            'auto_schema_on_publish' => isset($post_data['auto_schema_on_publish']),
            'link_suggestion_limit' => absint($post_data['link_suggestion_limit'] ?? 5),
        ];

        update_option('vrmind_aica_settings', $settings);
    }

    /**
     * Get usage statistics
     */
    protected function getUsageStats(): array
    {
        global $wpdb;
        
        $table = $wpdb->prefix . 'vrmind_ai_content_logs';
        $today = date('Y-m-d');

        // Check if table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") !== $table) {
            return [
                'calls_today' => 0,
                'tokens_today' => 0,
                'calls_total' => 0,
                'avg_tokens' => 0,
                'failed_calls' => 0,
            ];
        }

        $calls_today = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table WHERE DATE(created_at) = %s",
            $today
        ));

        $tokens_today = $wpdb->get_var($wpdb->prepare(
            "SELECT SUM(tokens) FROM $table WHERE DATE(created_at) = %s",
            $today
        ));

        $calls_total = $wpdb->get_var("SELECT COUNT(*) FROM $table");
        
        $avg_tokens = $wpdb->get_var("SELECT AVG(tokens) FROM $table");

        $failed_calls = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table WHERE status = 'failed' AND DATE(created_at) = %s",
            $today
        ));

        return [
            'calls_today' => (int) $calls_today,
            'tokens_today' => (int) $tokens_today,
            'calls_total' => (int) $calls_total,
            'avg_tokens' => round((float) $avg_tokens),
            'failed_calls' => (int) $failed_calls,
        ];
    }
}
