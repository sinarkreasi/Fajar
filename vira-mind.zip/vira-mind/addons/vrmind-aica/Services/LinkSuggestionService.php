<?php
/**
 * Link Suggestion Service - Internal link recommendations
 *
 * @package ViraMind\Addons\AIContentAssistant
 */

namespace ViraMind\Addons\AIContentAssistant\Services;

use ViraMind\Core\Container\Container;

defined('ABSPATH') || exit;

class LinkSuggestionService
{
    protected Container $app;
    protected array $config;

    public function __construct(Container $app, array $config)
    {
        $this->app = $app;
        $this->config = $config;
    }

    /**
     * Suggest internal links for content
     */
    public function suggestLinks(?int $post_id, string $content, int $limit = 5): array
    {
        // Get content to analyze
        if ($post_id) {
            $post = get_post($post_id);
            $content = $post ? $post->post_content : $content;
        }

        if (empty($content)) {
            return [];
        }

        // Extract key phrases
        $phrases = $this->extractKeyPhrases($content);

        // Query RAG for relevant posts
        $suggestions = [];
        foreach ($phrases as $phrase) {
            $results = $this->queryRAG($phrase, $post_id);
            $suggestions = array_merge($suggestions, $results);
        }

        // Deduplicate and score
        $suggestions = $this->deduplicateAndScore($suggestions);

        // Filter by minimum score
        $suggestions = array_filter($suggestions, function ($item) {
            return $item['score'] >= $this->config['link_min_score'];
        });

        // Sort by score and limit
        usort($suggestions, fn($a, $b) => $b['score'] <=> $a['score']);

        return array_slice($suggestions, 0, $limit);
    }

    /**
     * Extract key phrases from content
     */
    protected function extractKeyPhrases(string $content): array
    {
        // Strip HTML
        $text = wp_strip_all_tags($content);

        // Simple extraction: get noun phrases (simplified)
        $words = str_word_count($text, 1);
        $phrases = [];

        // Get 2-3 word combinations
        for ($i = 0; $i < count($words) - 1; $i++) {
            if (strlen($words[$i]) > 3) {
                $phrases[] = $words[$i] . ' ' . $words[$i + 1];
            }
        }

        // Return unique, most common phrases
        $phrases = array_count_values($phrases);
        arsort($phrases);

        return array_slice(array_keys($phrases), 0, 10);
    }

    /**
     * Query RAG for relevant posts
     */
    protected function queryRAG(string $query, ?int $exclude_post_id = null): array
    {
        try {
            // Use core RAG if available
            if (function_exists('vrmind_rag_query')) {
                $results = vrmind_rag_query($query, [
                    'limit' => 5,
                    'threshold' => $this->config['link_min_score'],
                ]);

                return $this->formatRAGResults($results, $query, $exclude_post_id);
            }

            // Fallback to simple search
            return $this->fallbackSearch($query, $exclude_post_id);

        } catch (\Exception $e) {
            return [];
        }
    }

    /**
     * Format RAG results
     */
    protected function formatRAGResults(array $results, string $query, ?int $exclude_id): array
    {
        $formatted = [];

        foreach ($results as $result) {
            $post_id = $result['post_id'] ?? 0;

            if ($post_id === $exclude_id) {
                continue;
            }

            $post = get_post($post_id);
            if (!$post || $post->post_status !== 'publish') {
                continue;
            }

            $formatted[] = [
                'post_id' => $post_id,
                'url' => get_permalink($post_id),
                'title' => get_the_title($post_id),
                'anchor' => $this->generateAnchor($query, $post),
                'score' => $result['score'] ?? 0.8,
                'reason' => $result['reason'] ?? 'Related content',
            ];
        }

        return $formatted;
    }

    /**
     * Fallback search using WP_Query
     */
    protected function fallbackSearch(string $query, ?int $exclude_id): array
    {
        $args = [
            's' => $query,
            'post_type' => 'any',
            'post_status' => 'publish',
            'posts_per_page' => 5,
            'post__not_in' => $exclude_id ? [$exclude_id] : [],
        ];

        $query_obj = new \WP_Query($args);
        $results = [];

        foreach ($query_obj->posts as $post) {
            $results[] = [
                'post_id' => $post->ID,
                'url' => get_permalink($post->ID),
                'title' => $post->post_title,
                'anchor' => $query,
                'score' => 0.75,
                'reason' => 'Search match',
            ];
        }

        return $results;
    }

    /**
     * Generate anchor text
     */
    protected function generateAnchor(string $query, \WP_Post $post): string
    {
        // Use query as base, or post title if query is too generic
        $generic = ['the', 'this', 'that', 'these', 'those', 'it', 'they'];
        
        if (in_array(strtolower($query), $generic)) {
            return $post->post_title;
        }

        return ucfirst($query);
    }

    /**
     * Deduplicate and score suggestions
     */
    protected function deduplicateAndScore(array $suggestions): array
    {
        $unique = [];

        foreach ($suggestions as $item) {
            $key = $item['post_id'];
            
            if (!isset($unique[$key])) {
                $unique[$key] = $item;
            } else {
                // Keep higher score
                if ($item['score'] > $unique[$key]['score']) {
                    $unique[$key] = $item;
                }
            }
        }

        return array_values($unique);
    }
}
