<?php
/**
 * Content AI Service - Core AI operations
 *
 * @package ViraMind\Addons\AIContentAssistant
 */

namespace ViraMind\Addons\AIContentAssistant\Services;

use ViraMind\Core\Container\Container;
use ViraMind\Addons\AIContentAssistant\Agents\PostGeneratorAgent;
use ViraMind\Addons\AIContentAssistant\Agents\SEORewriterAgent;
use ViraMind\Addons\AIContentAssistant\Agents\SchemaGeneratorAgent;

defined('ABSPATH') || exit;

class ContentAIService
{
    protected Container $app;
    protected array $config;
    protected PostGeneratorAgent $postAgent;
    protected SEORewriterAgent $seoAgent;
    protected SchemaGeneratorAgent $schemaAgent;

    public function __construct(Container $app, array $config)
    {
        $this->app = $app;
        $this->config = $config;
        $this->postAgent = new PostGeneratorAgent($config);
        $this->seoAgent = new SEORewriterAgent($config);
        $this->schemaAgent = new SchemaGeneratorAgent($config);
    }

    /**
     * Generate full post content
     */
    public function generatePost(array $opts): array
    {
        $topic = sanitize_text_field($opts['topic'] ?? '');
        $tone = sanitize_text_field($opts['tone'] ?? $this->config['default_tone']);
        $length = sanitize_text_field($opts['length'] ?? $this->config['default_length']);
        $keywords = array_map('sanitize_text_field', $opts['focus_keywords'] ?? []);

        // Build prompt
        $prompt = $this->postAgent->buildPrompt($topic, $tone, $length, $keywords);

        // Call AI
        $response = vrmind_ai([
            'prompt' => $prompt,
            'model' => $opts['model'] ?? null,
            'max_tokens' => $this->config['max_tokens_per_request'],
            'metadata' => [
                'addon' => 'ai-content-assistant',
                'user' => get_current_user_id(),
                'action' => 'generate_post',
            ],
        ]);

        // Parse and validate
        $result = $this->postAgent->parseResponse($response);

        // Log usage
        $this->logUsage('generate_post', $prompt, $response);

        return $result;
    }

    /**
     * Rewrite existing post content
     */
    public function rewriteDraft(int $post_id, array $opts): array
    {
        $post = get_post($post_id);
        if (!$post) {
            throw new \Exception('Post not found');
        }

        $mode = $opts['mode'] ?? 'seo';
        $keywords = $opts['target_keywords'] ?? [];

        $prompt = $this->seoAgent->buildPrompt($post, $mode, $keywords);

        $response = vrmind_ai([
            'prompt' => $prompt,
            'max_tokens' => $this->config['max_tokens_per_request'],
            'metadata' => [
                'addon' => 'ai-content-assistant',
                'user' => get_current_user_id(),
                'action' => 'rewrite',
                'post_id' => $post_id,
            ],
        ]);

        $result = $this->seoAgent->parseResponse($response);
        $this->logUsage('rewrite', $prompt, $response, $post_id);

        return $result;
    }

    /**
     * Generate snippet/CTA
     */
    public function generateSnippet(array $opts): array
    {
        $type = $opts['type'] ?? 'cta'; // cta, hero, excerpt
        $context = sanitize_text_field($opts['context'] ?? '');

        $prompt = $this->buildSnippetPrompt($type, $context);

        $response = vrmind_ai([
            'prompt' => $prompt,
            'max_tokens' => 500,
            'metadata' => ['addon' => 'ai-content-assistant', 'action' => 'snippet'],
        ]);

        $this->logUsage('snippet', $prompt, $response);

        return $this->parseSnippetResponse($response);
    }

    /**
     * Generate JSON-LD schema
     */
    public function generateSchema(int $post_id): array
    {
        $post = get_post($post_id);
        if (!$post) {
            throw new \Exception('Post not found');
        }

        $prompt = $this->schemaAgent->buildPrompt($post);

        $response = vrmind_ai([
            'prompt' => $prompt,
            'max_tokens' => 2000,
            'metadata' => [
                'addon' => 'ai-content-assistant',
                'action' => 'schema',
                'post_id' => $post_id,
            ],
        ]);

        $result = $this->schemaAgent->parseResponse($response);
        $this->logUsage('schema', $prompt, $response, $post_id);

        return $result;
    }

    /**
     * Build snippet prompt
     */
    protected function buildSnippetPrompt(string $type, string $context): string
    {
        $templates = [
            'cta' => "Generate 3 compelling call-to-action variations for: {$context}\nOutput JSON: {\"ctas\": [{\"text\": \"...\", \"tone\": \"...\"}]}",
            'hero' => "Generate a hero section headline and subheadline for: {$context}\nOutput JSON: {\"headline\": \"...\", \"subheadline\": \"...\"}",
            'excerpt' => "Generate a compelling excerpt (max 160 chars) for: {$context}\nOutput JSON: {\"excerpt\": \"...\"}",
        ];

        return $templates[$type] ?? $templates['cta'];
    }

    /**
     * Parse snippet response
     */
    protected function parseSnippetResponse(array $response): array
    {
        $content = $response['content'] ?? '';
        $decoded = json_decode($content, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new \Exception('Invalid JSON response from AI');
        }

        return $decoded;
    }

    /**
     * Log AI usage
     */
    protected function logUsage(string $action, string $prompt, array $response, ?int $post_id = null): void
    {
        if (!$this->config['log_ai_usage']) {
            return;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'vrmind_ai_content_logs';

        $wpdb->insert($table, [
            'user_id' => get_current_user_id(),
            'post_id' => $post_id,
            'action' => $action,
            'prompt_hash' => hash('sha256', $prompt),
            'model' => $response['model'] ?? 'unknown',
            'tokens' => $response['usage']['total_tokens'] ?? 0,
            'status' => $response['error'] ?? null ? 'failed' : 'success',
            'created_at' => current_time('mysql'),
        ]);
    }
}
