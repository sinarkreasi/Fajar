<?php
/**
 * AI Content Assistant Configuration
 *
 * @package ViraMind\Addons\AIContentAssistant
 */

defined('ABSPATH') || exit;

return [
    // Enable/disable addon
    'enabled' => true,

    // Roles allowed to use content assistant
    'roles_allowed' => ['administrator', 'editor'],

    // Default generation settings
    'default_tone' => 'friendly', // friendly, formal, casual, professional
    'default_length' => 'medium', // short, medium, long
    'max_tokens_per_request' => 4000,

    // Bulk operations
    'bulk_job_batch_size' => 25,
    'bulk_max_concurrent' => 5,

    // Link suggestions
    'link_suggestion_limit' => 5,
    'link_min_score' => 0.7,

    // Schema generation
    'schema_defaults' => [
        'Article' => true,
        'Product' => true,
        'FAQ' => true,
        'Course' => false,
    ],

    // Logging and monitoring
    'log_ai_usage' => true,
    'log_retention_days' => 30,

    // Auto-run features
    'auto_suggest_on_publish' => false,
    'auto_schema_on_publish' => false,

    // Rate limiting (per user per day)
    'rate_limits' => [
        'editor' => 50,
        'author' => 20,
        'contributor' => 10,
    ],

    // Supported post types
    'post_types' => ['post', 'page'],

    // Prompt templates directory
    'templates_path' => __DIR__ . '/../resources/prompts',
];
