<?php
/**
 * Auto Suggest Job - Run on publish
 *
 * @package ViraMind\Addons\AIContentAssistant
 */

namespace ViraMind\Addons\AIContentAssistant\Jobs;

use ViraMind\Addons\AIContentAssistant\Services\LinkSuggestionService;
use ViraMind\Addons\AIContentAssistant\Services\ContentAIService;

defined('ABSPATH') || exit;

class AutoSuggestJob
{
    protected int $post_id;

    public function __construct(int $post_id)
    {
        $this->post_id = $post_id;
    }

    /**
     * Execute job
     */
    public function handle(): void
    {
        try {
            $linkService = vrmind()->make(LinkSuggestionService::class);
            $contentService = vrmind()->make(ContentAIService::class);

            // Get link suggestions
            $links = $linkService->suggestLinks($this->post_id, '', 5);
            
            // Store as post meta for review
            update_post_meta($this->post_id, '_vrmind_suggested_links', $links);

            // Generate schema if enabled
            $config = vrmind()->make('aica.config');
            if ($config['auto_schema_on_publish']) {
                $schema = $contentService->generateSchema($this->post_id);
                update_post_meta($this->post_id, '_vrmind_schema', $schema);
            }

        } catch (\Exception $e) {
            error_log("AICA Auto Suggest failed for post {$this->post_id}: " . $e->getMessage());
        }
    }
}
