<?php
/**
 * Bulk Rewrite Job
 *
 * @package ViraMind\Addons\AIContentAssistant
 */

namespace ViraMind\Addons\AIContentAssistant\Jobs;

use ViraMind\Addons\AIContentAssistant\Services\ContentAIService;

defined('ABSPATH') || exit;

class BulkRewriteJob
{
    protected array $post_ids;

    public function __construct(array $post_ids)
    {
        $this->post_ids = $post_ids;
    }

    /**
     * Execute job
     */
    public function handle(): void
    {
        $service = vrmind()->make(ContentAIService::class);

        foreach ($this->post_ids as $post_id) {
            try {
                $result = $service->rewriteDraft($post_id, [
                    'mode' => 'seo',
                    'target_keywords' => [],
                ]);

                // Update post with rewritten content
                if (isset($result['suggested_content'])) {
                    wp_update_post([
                        'ID' => $post_id,
                        'post_content' => $result['suggested_content'],
                    ]);
                }

                // Add meta if available
                if (isset($result['meta_title'])) {
                    update_post_meta($post_id, '_vrmind_meta_title', $result['meta_title']);
                }
                if (isset($result['meta_description'])) {
                    update_post_meta($post_id, '_vrmind_meta_description', $result['meta_description']);
                }

            } catch (\Exception $e) {
                error_log("AICA Bulk Rewrite failed for post {$post_id}: " . $e->getMessage());
            }
        }
    }
}
