<?php
/**
 * Bulk Meta Generation Job
 *
 * @package ViraMind\Addons\AIContentAssistant
 */

namespace ViraMind\Addons\AIContentAssistant\Jobs;

use ViraMind\Addons\AIContentAssistant\Services\ContentAIService;

defined('ABSPATH') || exit;

class BulkMetaGenJob
{
    protected array $post_ids;

    public function __construct(array $post_ids)
    {
        $this->post_ids = $post_ids;
    }

    /**
     * Execute job
     */
    public function handle(): void
    {
        $service = vrmind()->make(ContentAIService::class);

        foreach ($this->post_ids as $post_id) {
            try {
                $post = get_post($post_id);
                if (!$post) {
                    continue;
                }

                // Generate meta using snippet service
                $result = $service->generateSnippet([
                    'type' => 'excerpt',
                    'context' => $post->post_title . ' - ' . wp_trim_words($post->post_content, 50),
                ]);

                if (isset($result['excerpt'])) {
                    update_post_meta($post_id, '_vrmind_meta_description', $result['excerpt']);
                }

            } catch (\Exception $e) {
                error_log("AICA Bulk Meta Gen failed for post {$post_id}: " . $e->getMessage());
            }
        }
    }
}
