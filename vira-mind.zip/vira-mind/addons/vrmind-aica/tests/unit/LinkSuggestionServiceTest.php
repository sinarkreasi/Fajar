<?php
/**
 * Link Suggestion Service Tests
 *
 * @package ViraMind\Addons\AIContentAssistant
 */

namespace ViraMind\Addons\AIContentAssistant\Tests\Unit;

use PHPUnit\Framework\TestCase;
use ViraMind\Addons\AIContentAssistant\Services\LinkSuggestionService;

class LinkSuggestionServiceTest extends TestCase
{
    public function test_extracts_key_phrases_from_content(): void
    {
        $service = new LinkSuggestionService(
            $this->createMock(\ViraMind\Core\Container\Container::class),
            ['link_min_score' => 0.7]
        );

        $content = 'WordPress is a great platform for blogging. Many bloggers use WordPress daily.';
        
        $reflection = new \ReflectionClass($service);
        $method = $reflection->getMethod('extractKeyPhrases');
        $method->setAccessible(true);

        $phrases = $method->invoke($service, $content);

        $this->assertIsArray($phrases);
        $this->assertNotEmpty($phrases);
    }

    public function test_filters_by_minimum_score(): void
    {
        $service = new LinkSuggestionService(
            $this->createMock(\ViraMind\Core\Container\Container::class),
            ['link_min_score' => 0.8]
        );

        $suggestions = [
            ['post_id' => 1, 'score' => 0.9],
            ['post_id' => 2, 'score' => 0.7],
            ['post_id' => 3, 'score' => 0.85],
        ];

        $reflection = new \ReflectionClass($service);
        $method = $reflection->getMethod('deduplicateAndScore');
        $method->setAccessible(true);

        $result = $method->invoke($service, $suggestions);

        $this->assertCount(3, $result);
    }
}
