<?php
/**
 * Post Generator Agent Tests
 *
 * @package ViraMind\Addons\AIContentAssistant
 */

namespace ViraMind\Addons\AIContentAssistant\Tests\Unit;

use PHPUnit\Framework\TestCase;
use ViraMind\Addons\AIContentAssistant\Agents\PostGeneratorAgent;

class PostGeneratorAgentTest extends TestCase
{
    protected PostGeneratorAgent $agent;

    protected function setUp(): void
    {
        $this->agent = new PostGeneratorAgent([
            'default_tone' => 'friendly',
            'default_length' => 'medium',
        ]);
    }

    public function test_builds_prompt_with_parameters(): void
    {
        $prompt = $this->agent->buildPrompt(
            'How to start a blog',
            'friendly',
            'medium',
            ['blogging', 'wordpress']
        );

        $this->assertStringContainsString('How to start a blog', $prompt);
        $this->assertStringContainsString('friendly', $prompt);
        $this->assertStringContainsString('blogging', $prompt);
    }

    public function test_parses_valid_json_response(): void
    {
        $response = [
            'content' => json_encode([
                'title' => 'Test Title',
                'excerpt' => 'Test excerpt',
                'content_blocks' => [
                    ['type' => 'paragraph', 'content' => 'Test content']
                ],
            ])
        ];

        $result = $this->agent->parseResponse($response);

        $this->assertEquals('Test Title', $result['title']);
        $this->assertEquals('Test excerpt', $result['excerpt']);
        $this->assertIsArray($result['content_blocks']);
    }

    public function test_throws_exception_on_invalid_response(): void
    {
        $this->expectException(\Exception::class);

        $response = ['content' => 'invalid json'];
        $this->agent->parseResponse($response);
    }

    public function test_validates_required_fields(): void
    {
        $this->expectException(\Exception::class);
        $this->expectExceptionMessage('Missing required field');

        $response = [
            'content' => json_encode([
                'title' => 'Test',
                // Missing excerpt and content_blocks
            ])
        ];

        $this->agent->parseResponse($response);
    }
}
