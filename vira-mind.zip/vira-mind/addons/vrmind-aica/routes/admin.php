<?php
/**
 * Admin Routes
 *
 * @package ViraMind\Addons\AIContentAssistant
 */

defined('ABSPATH') || exit;

use ViraMind\Core\Hooks\Hooks;
use ViraMind\Addons\AIContentAssistant\Controllers\AdminController;

// Register admin menu
Hooks::add('admin_menu', function () {
    add_submenu_page(
        'vira-mind',
        __('AI Content Assistant', 'vira-mind'),
        __('Content Assistant', 'vira-mind'),
        'manage_options',
        'vrmind-aica',
        'vrmind_aica_admin_page'
    );
});

// Admin page callback
function vrmind_aica_admin_page(): void
{
    try {
        $controller = vrmind()->make(AdminController::class);
        $controller->renderSettings();
    } catch (\Exception $e) {
        echo '<div class="wrap">';
        echo '<h1>' . esc_html__('AI Content Assistant', 'vira-mind') . '</h1>';
        echo '<div class="notice notice-error"><p>' . esc_html($e->getMessage()) . '</p></div>';
        echo '</div>';
    }
}
