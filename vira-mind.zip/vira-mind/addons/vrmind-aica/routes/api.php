<?php
/**
 * REST API Routes
 *
 * @package ViraMind\Addons\AIContentAssistant
 */

defined('ABSPATH') || exit;

use ViraMind\Addons\AIContentAssistant\Controllers\EditorController;

add_action('rest_api_init', function () {
    $namespace = 'vrmind/v1';
    $base = 'content-assistant';

    // Generate post
    register_rest_route($namespace, "/{$base}/generate", [
        'methods' => 'POST',
        'callback' => function ($request) {
            $controller = vrmind()->make(EditorController::class);
            return $controller->generate($request);
        },
        'permission_callback' => function () {
            return current_user_can('vrmind_use_content_assistant') 
                && wp_verify_nonce($_SERVER['HTTP_X_WP_NONCE'] ?? '', 'wp_rest');
        },
    ]);

    // Rewrite content
    register_rest_route($namespace, "/{$base}/rewrite", [
        'methods' => 'POST',
        'callback' => function ($request) {
            $controller = vrmind()->make(EditorController::class);
            return $controller->rewrite($request);
        },
        'permission_callback' => function () {
            return current_user_can('vrmind_use_content_assistant')
                && wp_verify_nonce($_SERVER['HTTP_X_WP_NONCE'] ?? '', 'wp_rest');
        },
    ]);

    // Suggest links
    register_rest_route($namespace, "/{$base}/suggest-links", [
        'methods' => 'POST',
        'callback' => function ($request) {
            $controller = vrmind()->make(EditorController::class);
            return $controller->suggestLinks($request);
        },
        'permission_callback' => function () {
            return current_user_can('vrmind_use_content_assistant')
                && wp_verify_nonce($_SERVER['HTTP_X_WP_NONCE'] ?? '', 'wp_rest');
        },
    ]);

    // Generate schema
    register_rest_route($namespace, "/{$base}/generate-schema", [
        'methods' => 'POST',
        'callback' => function ($request) {
            $controller = vrmind()->make(EditorController::class);
            return $controller->generateSchema($request);
        },
        'permission_callback' => function () {
            return current_user_can('vrmind_use_content_assistant')
                && wp_verify_nonce($_SERVER['HTTP_X_WP_NONCE'] ?? '', 'wp_rest');
        },
    ]);
});
