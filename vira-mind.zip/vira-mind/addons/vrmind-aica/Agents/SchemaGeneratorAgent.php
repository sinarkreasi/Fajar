<?php
/**
 * Schema Generator Agent - JSON-LD schema generation
 *
 * @package ViraMind\Addons\AIContentAssistant
 */

namespace ViraMind\Addons\AIContentAssistant\Agents;

defined('ABSPATH') || exit;

class SchemaGeneratorAgent
{
    protected array $config;

    public function __construct(array $config)
    {
        $this->config = $config;
    }

    /**
     * Build schema generation prompt
     */
    public function buildPrompt(\WP_Post $post): string
    {
        $type = $this->detectSchemaType($post);
        $system = $this->getSystemPrompt($type);
        $user = $this->getUserPrompt($post);

        return $system . "\n\n" . $user;
    }

    /**
     * Detect appropriate schema type
     */
    protected function detectSchemaType(\WP_Post $post): string
    {
        // Check post type
        if ($post->post_type === 'product') {
            return 'Product';
        }

        // Check content for FAQ patterns
        if (preg_match('/\?.*\n/i', $post->post_content)) {
            return 'FAQ';
        }

        // Default to Article
        return 'Article';
    }

    /**
     * System prompt for schema generation
     */
    protected function getSystemPrompt(string $type): string
    {
        return <<<PROMPT
You are a JSON-LD schema generator. Generate valid schema.org markup.

Output JSON:
{
  "type": "{$type}",
  "jsonld": { /* valid schema.org JSON-LD */ }
}

Rules:
- Use schema.org vocabulary
- Include required properties
- Add recommended properties when data available
- Use proper @context and @type
- Validate against schema.org spec
PROMPT;
    }

    /**
     * User prompt with post data
     */
    protected function getUserPrompt(\WP_Post $post): string
    {
        $title = $post->post_title;
        $excerpt = $post->post_excerpt ?: wp_trim_words($post->post_content, 30);
        $author = get_the_author_meta('display_name', $post->post_author);
        $date = $post->post_date;
        $modified = $post->post_modified;
        $url = get_permalink($post->ID);

        return <<<PROMPT
Generate JSON-LD schema for this content:

Title: {$title}
Excerpt: {$excerpt}
Author: {$author}
Published: {$date}
Modified: {$modified}
URL: {$url}

Create appropriate schema markup.
PROMPT;
    }

    /**
     * Parse response
     */
    public function parseResponse(array $response): array
    {
        $content = $response['content'] ?? '';
        
        $decoded = json_decode($content, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            if (preg_match('/```json\s*(\{.*?\})\s*```/s', $content, $matches)) {
                $decoded = json_decode($matches[1], true);
            }
        }

        if (!$decoded || !isset($decoded['jsonld'])) {
            throw new \Exception('Invalid schema response');
        }

        return $decoded;
    }
}
