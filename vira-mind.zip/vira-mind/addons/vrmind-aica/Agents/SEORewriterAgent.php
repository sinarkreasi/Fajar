<?php
/**
 * SEO Rewriter Agent - SEO optimization prompts
 *
 * @package ViraMind\Addons\AIContentAssistant
 */

namespace ViraMind\Addons\AIContentAssistant\Agents;

defined('ABSPATH') || exit;

class SEORewriterAgent
{
    protected array $config;

    public function __construct(array $config)
    {
        $this->config = $config;
    }

    /**
     * Build rewrite prompt
     */
    public function buildPrompt(\WP_Post $post, string $mode, array $keywords): string
    {
        $system = $this->getSystemPrompt($mode);
        $user = $this->getUserPrompt($post, $keywords);

        return $system . "\n\n" . $user;
    }

    /**
     * System prompt based on mode
     */
    protected function getSystemPrompt(string $mode): string
    {
        $prompts = [
            'seo' => <<<PROMPT
You are an SEO content optimizer. Rewrite content to improve SEO while maintaining meaning.

Output JSON:
{
  "suggested_content": "string",
  "meta_title": "string (max 60 chars)",
  "meta_description": "string (max 160 chars)",
  "notes": ["improvement 1", "improvement 2"]
}

Rules:
- Preserve target keywords
- Improve readability (shorter sentences, active voice)
- Add semantic variations of keywords
- Maintain original tone
- Keep factual accuracy
PROMPT,
            'clarity' => <<<PROMPT
You are a clarity editor. Improve readability and conciseness.

Output JSON:
{
  "suggested_content": "string",
  "notes": ["change 1", "change 2"]
}

Rules:
- Shorter sentences
- Active voice
- Remove jargon
- Clear structure
PROMPT,
            'shorten' => <<<PROMPT
You are a content editor. Reduce word count by 30-40% while keeping key points.

Output JSON:
{
  "suggested_content": "string",
  "notes": ["removed section", "condensed paragraph"]
}
PROMPT,
        ];

        return $prompts[$mode] ?? $prompts['seo'];
    }

    /**
     * User prompt with post content
     */
    protected function getUserPrompt(\WP_Post $post, array $keywords): string
    {
        $title = $post->post_title;
        $content = wp_strip_all_tags($post->post_content);
        $keywordList = !empty($keywords) ? implode(', ', $keywords) : 'none';

        return <<<PROMPT
Rewrite this content:

Title: {$title}
Target Keywords: {$keywordList}

Content:
{$content}

Provide improved version as JSON.
PROMPT;
    }

    /**
     * Parse response
     */
    public function parseResponse(array $response): array
    {
        $content = $response['content'] ?? '';
        
        // Extract JSON
        $decoded = json_decode($content, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            // Try to extract from code block
            if (preg_match('/```json\s*(\{.*?\})\s*```/s', $content, $matches)) {
                $decoded = json_decode($matches[1], true);
            }
        }

        if (!$decoded || !isset($decoded['suggested_content'])) {
            throw new \Exception('Invalid response format');
        }

        return $decoded;
    }
}
