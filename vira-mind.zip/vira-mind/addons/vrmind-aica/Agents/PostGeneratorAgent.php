<?php
/**
 * Post Generator Agent - Prompt templates and parsing
 *
 * @package ViraMind\Addons\AIContentAssistant
 */

namespace ViraMind\Addons\AIContentAssistant\Agents;

defined('ABSPATH') || exit;

class PostGeneratorAgent
{
    protected array $config;

    public function __construct(array $config)
    {
        $this->config = $config;
    }

    /**
     * Build generation prompt
     */
    public function buildPrompt(string $topic, string $tone, string $length, array $keywords): string
    {
        $system = $this->getSystemPrompt();
        $user = $this->getUserPrompt($topic, $tone, $length, $keywords);

        return $system . "\n\n" . $user;
    }

    /**
     * System prompt with schema
     */
    protected function getSystemPrompt(): string
    {
        return <<<PROMPT
You are Vira Mind Post Generator. Output JSON only, following this exact schema:

{
  "title": "string (max 70 chars)",
  "excerpt": "string (max 160 chars)",
  "content_blocks": [
    {"type": "heading", "level": 2, "content": "string"},
    {"type": "paragraph", "content": "string"},
    {"type": "list", "items": ["string"]}
  ],
  "suggested_ctas": [
    {"text": "string", "position_hint": "start|middle|end"}
  ],
  "meta_title": "string (max 60 chars)",
  "meta_description": "string (max 160 chars)"
}

Rules:
- Keep title under 70 characters
- Provide 2-3 suggested CTAs
- No external links in content
- Use provided keywords naturally
- Content blocks should be structured and semantic
- Avoid making factual claims without context
PROMPT;
    }

    /**
     * User prompt with parameters
     */
    protected function getUserPrompt(string $topic, string $tone, string $length, array $keywords): string
    {
        $lengthMap = [
            'short' => '300-500 words',
            'medium' => '800-1200 words',
            'long' => '1500-2000 words',
        ];

        $keywordList = !empty($keywords) ? implode(', ', $keywords) : 'none specified';

        return <<<PROMPT
Generate a blog post with these parameters:

Topic: {$topic}
Tone: {$tone}
Target Length: {$lengthMap[$length]}
Focus Keywords: {$keywordList}

Create engaging, well-structured content that:
1. Has a compelling title and excerpt
2. Uses clear headings and paragraphs
3. Incorporates keywords naturally
4. Includes actionable CTAs
5. Is optimized for SEO

Output valid JSON only.
PROMPT;
    }

    /**
     * Parse and validate AI response
     */
    public function parseResponse(array $response): array
    {
        $content = $response['content'] ?? '';
        
        // Try to extract JSON from response
        $json = $this->extractJSON($content);
        
        if (!$json) {
            throw new \Exception('Invalid JSON response from AI');
        }

        // Validate required fields
        $this->validateResponse($json);

        return $json;
    }

    /**
     * Extract JSON from response
     */
    protected function extractJSON(string $content): ?array
    {
        // Try direct decode
        $decoded = json_decode($content, true);
        
        if (json_last_error() === JSON_ERROR_NONE) {
            return $decoded;
        }

        // Try to find JSON in markdown code blocks
        if (preg_match('/```json\s*(\{.*?\})\s*```/s', $content, $matches)) {
            $decoded = json_decode($matches[1], true);
            if (json_last_error() === JSON_ERROR_NONE) {
                return $decoded;
            }
        }

        // Try to find any JSON object
        if (preg_match('/(\{.*\})/s', $content, $matches)) {
            $decoded = json_decode($matches[1], true);
            if (json_last_error() === JSON_ERROR_NONE) {
                return $decoded;
            }
        }

        return null;
    }

    /**
     * Validate response structure
     */
    protected function validateResponse(array $data): void
    {
        $required = ['title', 'excerpt', 'content_blocks'];

        foreach ($required as $field) {
            if (!isset($data[$field])) {
                throw new \Exception("Missing required field: {$field}");
            }
        }

        if (!is_array($data['content_blocks']) || empty($data['content_blocks'])) {
            throw new \Exception('content_blocks must be a non-empty array');
        }
    }
}
