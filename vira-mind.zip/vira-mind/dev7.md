A — Vira Mind — RAG Pipeline Optimization Prompt (.md)

Component: RAG Pipeline Optimization (chunk merging, reranking, windowing, chunk dedupe, compaction, caching, rerankers)
Prefix: vrmind_
Platform: WordPress 6.8+, PHP 8.2+
Location: /core/RAG (optimize subfolders), /storage/vectors, /storage/rag, /core/RAG/Optimizers

0. Purpose

You are the Vira Mind RAG Pipeline Optimization Agent.
Goal: design and generate code for a robust, production-ready, pluggable RAG pipeline that improves quality & efficiency via:

Chunk merging & adaptive windowing

Multi-stage retrieval + reranking

Cache-aware retrieval & TTL strategies

Shard compaction & maintenance (garbage collection)

Incremental reindexing & partial updates

Retrieval latency SLOs & backoff policies

Always follow Vira Mind rules: vrmind_ prefix, no inline JS/CSS, sanitize input, fail-safe behavior.

1. High-level Architecture & Flow

Ingest → document → chunker → chunks saved to shard(s)

Embed → chunk batch → store vectors (shards)

Retrieve (1st-pass) → ANN / brute-force on shards → top-N candidates

Rerank (2nd-pass) → contextual cross-encoder / local scorer → top-K final

Merge & Window → assemble chunks into coherent context (adaptive windowing)

Validate & Trim → ensure token budget / prompt safety / de-dup rules

Return → pass to AI engine for final generation (RAG)

2. Key Concepts & Techniques (must be implemented)
2.1 Chunk Merging & Windowing

Deterministic chunk ids (hash(document_id + chunk_index + version))

Merge rules:

Merge adjacent chunks if semantic_similarity > MERGE_THRESHOLD and combined_tokens <= MAX_WINDOW_TOKENS.

Prefer preserving semantic boundaries (paragraphs, headings).

Adaptive Windowing:

For short queries → smaller window (fewer chunks)

For long/complex queries → expand window until token budget or semantic dilution limit.

Implementation targets:

/core/RAG/Optimizers/ChunkMerger.php

/core/RAG/Optimizers/WindowingEngine.php

2.2 Multi-stage Retrieval & Reranking

Stage 1: Fast retrieval (ANN or brute-force per shard) → return top M (e.g., 200)

Driver interface: VectorRetrieverInterface → implementations: BruteForceRetriever, ANNDriverRetriever

Files: /core/RAG/Retrievers/*

Stage 2: Lightweight reranker (cheap scoring — lexical + semantic hybrid) → top 50

Files: /core/RAG/Rerankers/LightweightReranker.php

Stage 3: Cross-encoder reranker (expensive contextual scorer using LLM or small cross-encoder) → final top K (e.g., 8)

Files: /core/RAG/Rerankers/CrossEncoderReranker.php

Reranker must be pluggable; default is safe local scorer (cosine + BM25 hybrid).

2.3 Deduplication & Diversity

Dedup exact text repeats (fingerprint via normalized text hash)

Diversity enforcement: penalize high overlap between top candidates (n-gram overlap threshold)

Implement at /core/RAG/Optimizers/Deduper.php

2.4 Compacting & Shard Maintenance

Periodic compaction job:

Merge small shards into larger, remove deleted chunks, re-balance shards by size.

Compaction job file: /core/RAG/Jobs/ShardCompactionJob.php

Compaction scheduler via Queue.

2.5 Caching & TTL

Query-level cache: cache retrieval results keyed by fingerprint(query + model + config) with TTL (configurable) → /core/RAG/Support/QueryCache.php

Cache levels:

L1: in-memory (request-lifetime)

L2: file-based /storage/rag/cache

L3: optional Redis (if configured)

2.6 Re-ranking Strategies

Lexico-semantic reranker — combine BM25 score with semantic cosine: score = α * semantic + β * bm25 + γ * freshness_penalty

Freshness & Recency: weight newer content if config prioritize_recency true

Source trust score: addons may provide source_trust metadata to boost/dampen sources

2.7 Metrics and SLOs

Track:

retrieval_latency_ms

rerank_latency_ms

num_chunks_merged

compaction_runs

cache_hit_rate

Log to /storage/logs/rag-optimizer-{date}.log and feed into telemetry.

3. Files to Create / Update (paths & short description)

New / Update core optimizer files

/core/RAG/Optimizers/ChunkMerger.php
/core/RAG/Optimizers/WindowingEngine.php
/core/RAG/Optimizers/Deduper.php
/core/RAG/Optimizers/HybridScorer.php
/core/RAG/Retrievers/VectorRetrieverInterface.php
/core/RAG/Retrievers/BruteForceRetriever.php
/core/RAG/Retrievers/ANNDriverRetriever.php
/core/RAG/Rerankers/LightweightReranker.php
/core/RAG/Rerankers/CrossEncoderReranker.php
/core/RAG/Jobs/ShardCompactionJob.php
/core/RAG/Support/QueryCache.php
/core/RAG/Support/ChunkFingerprint.php
/core/RAG/Support/ShardBalancer.php
/core/RAG/Support/RAGMetrics.php


API / Controller changes

/core/API/Controllers/RAGController.php   # add endpoints: /query?optimize=true, /reindex/partial


Config changes

/config/rag.php   # new config: merge_threshold, max_window_tokens, rerank_k, cache_ttl, shard_target_size


Admin UI

/resources/views/rag/optimizer-settings.php
/resources/scripts/rag-optimizer.js
/resources/styles/rag-optimizer.css

4. Implementation Notes & Algorithms (must include in generated code comments)

Chunk merging threshold: default semantic > 0.88 (configurable)

Token estimation: use model tokenizer approximation (words * 1.33) or simpler BPE estimator if available

Scoring normalization: normalize cosine into 0..1 range before linear combination

BM25: use lightweight PHP implementation with precomputed term frequencies per shard

ANN Driver: driver interface must support index->add(vector, id), index->search(vector, k), index->remove(id) and index->compact()

Brute-force fallback: multi-shard map-reduce: compute top per-shard then global top-N merge

Partial Reindex: reindex only changed documents by doc version comparison

5. Queue Integration (jobs)

EmbedDocumentJob should call embedding driver, write to shard, then trigger ShardCompactionJob conditionally.

ReRankJob allowed for expensive cross-encoder rerank on demand (useful for offline heavy re-ranking).

Files:

/core/RAG/Jobs/EmbedDocumentJob.php
/core/RAG/Jobs/ReRankJob.php
/core/RAG/Jobs/ShardCompactionJob.php

6. Telemetry & Logging

Emit vrmind_rag_retrieval event with {latency, candidates_requested, candidates_returned, method}.

Metrics persisted to /storage/logs/rag-metrics.log and optionally pushed to telemetry service if configured.

7. Testing & Benchmarks (agent must output)

Unit tests for chunk merging correctness (edge cases: headings, short paragraphs, HTML stripping)

Integration tests for pipeline full path (ingest→embed→retrieve→rerank→RAG answer)

Provide a small benchmark harness: tools/rag_benchmark.php (configurable dataset)

8. Output Format (Agent MUST use)
# Component: RAG Pipeline Optimization
## 1. Overview
## 2. File Structure (list)
## 3. Files to Create (detailed method signatures)
## 4. Algorithms & Implementation Notes
## 5. Config Values (defaults)
## 6. API Changes (endpoints)
## 7. Queue Jobs (files + description)
## 8. Metrics & Logs
## 9. Admin UI (views/scripts to add)
## 10. Tests & Benchmarks
## 11. Final Checklist

9. Final Checklist (required)

 deterministic chunk ids

 merge & window algorithms implemented

 stage-1 retriever + stage-2 reranker implemented

 dedupe & diversity enforced

 shard compaction job exists

 caching with TTL present

 metrics instrumented

 config options added in /config/rag.php

 admin UI for optimizer settings created

📘 B — Vira Mind — Local Vector Inference Engine Prompt (.md)

Component: Local Vector Inference Engine (local ANN & local LLM/cross-encoder inference driver)
Prefix: vrmind_
Platform: WordPress 6.8+, PHP 8.2+ (but with optional native/sidecar components)
Location: /core/RAG/LocalEngine and /core/AI/LocalInference (drivers), /core/RAG/Drivers

0. Purpose

You are the Vira Mind Local Vector Inference Agent.
Goal: design & generate code to enable local, high-performance vector search & local model inference options that run beside (or within) WordPress infra:

Local ANN index driver (HNSW/Annoy-like) via sidecar or native extension

Local cross-encoder inference driver (small models for reranking)

Local embedding drivers (llama.cpp / GGML / ONNX runtime wrappers)

Driver abstraction so PHP code calls uniform API regardless of backend

Implement safe fallbacks: if local driver missing → use BruteForceRetriever or remote provider.

1. Design Principles

Driver-based architecture: PHP interface LocalIndexDriverInterface with multiple implementations

Sidecar-first approach: recommend shipping optional sidecar binary (Rust/Go) for ANN if high performance required; agent must produce a PHP driver that talks via HTTP or unix-socket to sidecar.

Pure-PHP fallback: brute-force scan over shards (works but slower).

Graceful degrade: if sidecar unavailable, enqueue heavy retrievals for background processing or use cached results.

2. Drivers & Interfaces (files)

Interfaces

/core/RAG/Drivers/LocalIndexDriverInterface.php
/core/AI/LocalInference/LocalModelDriverInterface.php


Local Index Drivers (implementations)

/core/RAG/Drivers/LocalIndex/BruteForceDriver.php      # pure PHP fallback
/core/RAG/Drivers/LocalIndex/SidecarHTTPDriver.php     # communicates with local sidecar via HTTP
/core/RAG/Drivers/LocalIndex/SQLiteVectorDriver.php    # optional: SQLite + vector extension (if available)


Local Model Drivers

/core/AI/LocalInference/LlamaCppDriver.php
/core/AI/LocalInference/ONNXRuntimeDriver.php
/core/AI/LocalInference/SidecarModelDriver.php
/core/AI/LocalInference/PyTorchServeDriver.php        # optional


Manager & Registry

/core/RAG/Drivers/LocalDriverManager.php
/core/AI/LocalInference/LocalModelRegistry.php

3. Sidecar Design (recommended)

A small HTTP server (unix socket optional) exposing endpoints:

POST /index/add {vector, id}

POST /index/search {vector, k} → returns {id, score}

POST /index/remove {id}

POST /model/infer {prompt, model, params} → returns text/json

Sidecar can be implemented in Rust/Go for speed; agent should produce PHP driver that talks to this API.

Provide health & version endpoints: /health, /version

Security: sidecar should listen only on localhost or unix-socket and provide api-key authentication.

4. Local Inference Capabilities

Cross-encoder for reranking: small distilled model (e.g., SBERT-like) served locally via sidecar or ONNX runtime.

Local embeddings: use llama.cpp or GGML-backends via driver wrapper or sidecar.

Quantization support: document how to use 4-bit/8-bit quant models with sidecar.

5. Batching & Memory Controls

Drivers must accept batch_size and return results incrementally.

Implement max_memory_mb setting; sidecar should support cgroup or memory-limiting flags.

PHP driver must stream results when possible to avoid OOM.

6. Consistency & Index Sync

Provide /core/RAG/Drivers/LocalIndex/SyncManager.php

handles sync between PHP shard files and sidecar index (add/remove/update)

idempotent operations (use vector fingerprint)

Provide vrmind_localindex_sync() CLI command for full sync.

7. Fallback & Graceful Degradation

If SidecarHTTPDriver fails:

fallback to BruteForceDriver for read-only retrievals

queue reindex tasks to attempt later

return partial results with meta: { degraded: true }

8. Files to Create / Update (paths)
/core/RAG/Drivers/LocalIndexDriverInterface.php
/core/RAG/Drivers/LocalIndex/BruteForceDriver.php
/core/RAG/Drivers/LocalIndex/SidecarHTTPDriver.php
/core/RAG/Drivers/LocalIndex/SQLiteVectorDriver.php
/core/RAG/Drivers/LocalIndex/SyncManager.php

/core/AI/LocalInference/LocalModelDriverInterface.php
/core/AI/LocalInference/LlamaCppDriver.php
/core/AI/LocalInference/ONNXRuntimeDriver.php
/core/AI/LocalInference/SidecarModelDriver.php
/core/AI/LocalInference/LocalModelRegistry.php

/core/RAG/Drivers/LocalDriverManager.php
/core/API/Controllers/LocalEngineController.php   # health, search, sync endpoints
/tools/vrmind_local_sidecar_cli.md                # docs for sidecar setup

9. Config Options (defaults)

Add to /config/rag.php or /config/local_engine.php:

'local_index' => [
  'enabled' => true,
  'driver' => 'sidecar', // sidecar | sqlite | brute
  'sidecar' => [
     'url' => 'http://127.0.0.1:9001',
     'api_key' => 'xxxx',
     'timeout' => 5
  ],
  'sqlite' => [
     'path' => '/path/to/db.sqlite'
  ],
  'brute' => [
     'chunk_scan_limit' => 10000
  ],
  'sync_interval' => 3600,
  'shard_target_size' => 1000, // chunks per shard
],
'local_inference' => [
  'enabled' => false,
  'driver' => 'sidecar', // or llama_cpp, onnx
  'max_memory_mb' => 2048,
  'batch_size' => 8
]

10. Admin UI Additions

Local Engine status panel (/resources/views/rag/local-engine.php) showing:

driver >> status/uptime

index size (docs/chunks)

last sync time

health ping / version

sync start button

Scripts/CSS:

/resources/scripts/rag-local-engine.js

/resources/styles/rag-local-engine.css

11. Security & Deployment Notes

Sidecar must bind to localhost or unix-socket only. Do not expose externally.

Use HMAC / API key for sidecar auth. Store keys securely in WP options with encryption if possible.

Provide documentation for installing sidecar binary on common platforms (Linux x86_64, arm64, macOS).

Provide automated health check and restart instructions (systemd unit snippet).

12. Output Format (Agent must follow)
# Component: Local Vector Inference Engine
## 1. Overview
## 2. Drivers & Interfaces (file list)
## 3. Sidecar API Spec (endpoints & payloads)
## 4. Sync & Consistency plan
## 5. Fallback & Degrade behavior
## 6. Config Values (defaults)
## 7. Admin UI elements
## 8. Security & Deployment notes
## 9. Tests & Benchmarks required
## 10. Final Checklist

13. Tests & Benchmarks (agent must include)

Local index search latency vs brute-force (sample dataset)

Memory usage tests for local models with various quant levels

Sync correctness tests (add/remove/update document)

Stress test for search concurrent requests

14. Final Checklist (required)

 Driver interfaces created

 Sidecar HTTP driver implemented (PHP wrapper)

 Brute-force fallback implemented

 Sync manager exists & idempotent

 Admin UI shows health & allows manual sync

 Config options added

 Security docs for sidecar created

 Tests & benchmarks scripts present