<?php

declare(strict_types=1);

use ViraMind\Core\Hooks\Hooks;

if (!defined('ABSPATH')) {
    exit;
}

// Admin menu
Hooks::add('admin_menu', function() {
    add_menu_page(
        __('Vira Mind', 'vira-mind'),
        __('Vira Mind', 'vira-mind'),
        'manage_options',
        'vira-mind',
        'vrmind_admin_dashboard',
        'dashicons-superhero',
        30
    );
    
    add_submenu_page(
        'vira-mind',
        __('Dashboard', 'vira-mind'),
        __('Dashboard', 'vira-mind'),
        'manage_options',
        'vira-mind',
        'vrmind_admin_dashboard'
    );
    
    add_submenu_page(
        'vira-mind',
        __('AI Engine', 'vira-mind'),
        __('AI Engine', 'vira-mind'),
        'manage_options',
        'vira-mind-ai-engine',
        'vrmind_admin_ai_engine'
    );
    
    add_submenu_page(
        'vira-mind',
        __('Routes', 'vira-mind'),
        __('Routes', 'vira-mind'),
        'manage_options',
        'vira-mind-routes',
        'vrmind_admin_routes'
    );
    
    add_submenu_page(
        'vira-mind',
        __('Services', 'vira-mind'),
        __('Services', 'vira-mind'),
        'manage_options',
        'vira-mind-services',
        'vrmind_admin_services'
    );
    
    add_submenu_page(
        'vira-mind',
        __('Cache', 'vira-mind'),
        __('Cache', 'vira-mind'),
        'manage_options',
        'vira-mind-cache',
        'vrmind_admin_cache'
    );
    
    add_submenu_page(
        'vira-mind',
        __('Queue', 'vira-mind'),
        __('Queue', 'vira-mind'),
        'manage_options',
        'vira-mind-queue',
        'vrmind_admin_queue'
    );
    
    add_submenu_page(
        'vira-mind',
        __('Logs', 'vira-mind'),
        __('Logs', 'vira-mind'),
        'manage_options',
        'vira-mind-logs',
        'vrmind_admin_logs'
    );
    
    add_submenu_page(
        'vira-mind',
        __('Security', 'vira-mind'),
        __('Security', 'vira-mind'),
        'manage_options',
        'vira-mind-security',
        'vrmind_admin_security'
    );
    
    add_submenu_page(
        'vira-mind',
        __('Addons', 'vira-mind'),
        __('Addons', 'vira-mind'),
        'manage_options',
        'vira-mind-addons',
        'vrmind_admin_addons'
    );
    
    add_submenu_page(
        'vira-mind',
        __('Integrations', 'vira-mind'),
        __('Integrations', 'vira-mind'),
        'manage_options',
        'vira-mind-integrations',
        'vrmind_admin_integrations'
    );
    
    add_submenu_page(
        'vira-mind',
        __('RAG Engine', 'vira-mind'),
        __('RAG Engine', 'vira-mind'),
        'manage_options',
        'vira-mind-rag',
        'vrmind_admin_rag'
    );
    
    add_submenu_page(
        'vira-mind',
        __('System Tools', 'vira-mind'),
        __('System Tools', 'vira-mind'),
        'manage_options',
        'vira-mind-tools',
        'vrmind_admin_tools'
    );
});

function vrmind_admin_dashboard(): void
{
    $controller = new \ViraMind\Controllers\DashboardController();
    $controller->index();
}

function vrmind_admin_integrations(): void
{
    $controller = new \ViraMind\Controllers\IntegrationsController();
    $controller->index();
}

function vrmind_admin_rag(): void
{
    $controller = new \ViraMind\Controllers\RAGController();
    $controller->index();
}

function vrmind_admin_ai_engine(): void
{
    $controller = new \ViraMind\Controllers\AIEngineController();
    $controller->index();
}

function vrmind_admin_routes(): void
{
    $controller = new \ViraMind\Controllers\RoutesController();
    $controller->index();
}

function vrmind_admin_services(): void
{
    $controller = new \ViraMind\Controllers\ServicesController();
    $controller->index();
}

function vrmind_admin_cache(): void
{
    $controller = new \ViraMind\Controllers\CacheController();
    $controller->index();
}

function vrmind_admin_queue(): void
{
    $controller = new \ViraMind\Controllers\QueueController();
    $controller->index();
}

function vrmind_admin_logs(): void
{
    $controller = new \ViraMind\Controllers\LogsController();
    $controller->index();
}

function vrmind_admin_security(): void
{
    $controller = new \ViraMind\Controllers\SecurityController();
    $controller->index();
}

function vrmind_admin_addons(): void
{
    $controller = new \ViraMind\Controllers\AddonsController();
    $controller->index();
}

function vrmind_admin_tools(): void
{
    $controller = new \ViraMind\Controllers\ToolsController();
    $controller->index();
}

// Enqueue admin assets
Hooks::add('admin_enqueue_scripts', function($hook) {
    if (strpos($hook, 'vira-mind') === false) {
        return;
    }
    
    wp_enqueue_style(
        'vrmind-admin',
        VRMIND_URL . 'resources/styles/admin.css',
        [],
        VRMIND_VERSION
    );
    
    wp_enqueue_script(
        'vrmind-admin',
        VRMIND_URL . 'resources/scripts/admin.js',
        ['jquery'],
        VRMIND_VERSION,
        true
    );
    
    // Enqueue addon upload script on addons page
    if (strpos($hook, 'vira-mind-addons') !== false) {
        wp_enqueue_script(
            'vrmind-addons-upload',
            VRMIND_URL . 'resources/scripts/admin/addons-upload.js',
            ['jquery'],
            VRMIND_VERSION,
            true
        );
    }
    
    wp_localize_script('vrmind-admin', 'vrmindAdmin', [
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('vrmind_nonce'),
    ]);
});
