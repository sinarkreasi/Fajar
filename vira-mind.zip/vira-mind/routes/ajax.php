<?php

declare(strict_types=1);

use ViraMind\Core\Hooks\Hooks;

if (!defined('ABSPATH')) {
    exit;
}

// AJAX handlers
Hooks::add('wp_ajax_vrmind_process', 'vrmind_ajax_process');

function vrmind_ajax_process(): void
{
    check_ajax_referer('vrmind_nonce', 'nonce');
    
    if (!current_user_can('edit_posts')) {
        wp_send_json_error(['message' => 'Unauthorized'], 403);
    }
    
    $action = sanitize_text_field($_POST['action_type'] ?? '');
    
    wp_send_json_success(['message' => 'Processed']);
}
