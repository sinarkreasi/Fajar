<?php

declare(strict_types=1);

use ViraMind\Core\Hooks\Hooks;

if (!defined('ABSPATH')) {
    exit;
}

// Register REST API routes
Hooks::add('rest_api_init', function() {
    register_rest_route('vrmind/v1', '/ai/query', [
        'methods' => 'POST',
        'callback' => 'vrmind_api_ai_query',
        'permission_callback' => function() {
            return current_user_can('edit_posts');
        },
    ]);
});

function vrmind_api_ai_query(\WP_REST_Request $request): \WP_REST_Response
{
    $prompt = sanitize_text_field($request->get_param('prompt'));
    
    if (empty($prompt)) {
        return new \WP_REST_Response(['error' => 'Prompt is required'], 400);
    }
    
    try {
        $response = vrmind()->make('ai.router')->route($prompt);
        return new \WP_REST_Response($response->toArray(), 200);
    } catch (\Exception $e) {
        return new \WP_REST_Response(['error' => $e->getMessage()], 500);
    }
}
