<?php

declare(strict_types=1);

use ViraMind\Core\Hooks\Hooks;

if (!defined('ABSPATH')) {
    exit;
}

// Frontend hooks
Hooks::add('wp_enqueue_scripts', function() {
    if (!is_admin()) {
        wp_enqueue_style(
            'vrmind-frontend',
            VRMIND_URL . 'resources/styles/frontend.css',
            [],
            VRMIND_VERSION
        );
    }
});
