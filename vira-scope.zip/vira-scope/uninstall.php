<?php
/**
 * Uninstall script for Vira Scope.
 * This file is executed when the plugin is deleted via the WordPress admin.
 */

// If uninstall not called from WordPress, exit
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Define plugin constants if not already defined
if (!defined('VRSC_PATH')) {
    define('VRSC_PATH', plugin_dir_path(__FILE__));
}

// Include necessary files
require_once VRSC_PATH . 'includes/Database/Schema.php';
require_once VRSC_PATH . 'includes/Helpers/CacheHelper.php';

// Remove database tables
$schema = new ViraScope\Database\Schema();
$schema->drop_tables();

// Clear all cache
$cache_helper = new ViraScope\Helpers\CacheHelper();
$cache_helper->flush();

// Remove plugin options
$options_to_delete = [
    'vrsc_db_version',
    'vrsc_ai_provider',
    'vrsc_gemini_api_key',
    'vrsc_gemini_model',
    'vrsc_openai_api_key',
    'vrsc_openai_model',
    'vrsc_cache_duration',
    'vrsc_analysis_frequency',
    'vrsc_max_keywords_per_batch',
    'vrsc_min_keyword_words'
];

foreach ($options_to_delete as $option) {
    delete_option($option);
}

// Remove post meta added by the plugin
global $wpdb;
$wpdb->query("DELETE FROM {$wpdb->postmeta} WHERE meta_key LIKE '_vrsc_%'");

// Clear any scheduled cron jobs
wp_clear_scheduled_hook('vrsc_analyze_content');
wp_clear_scheduled_hook('vrsc_cleanup_cache');

// Remove user meta if any
$wpdb->query("DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE 'vrsc_%'");

// Log uninstall (optional, for debugging)
if (defined('WP_DEBUG') && WP_DEBUG) {
    error_log('Vira Scope plugin uninstalled successfully');
}