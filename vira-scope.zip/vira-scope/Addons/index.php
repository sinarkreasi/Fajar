<?php
/**
 * Addons directory index file
 * Prevents direct access to the addons directory
 */

// Silence is golden
if (!defined('ABSPATH')) {
    exit;
}