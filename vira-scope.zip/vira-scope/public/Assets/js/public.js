/* Vira Scope Public JavaScript */

(function($) {
    'use strict';

    const ViraScopePublic = {
        init: function() {
            this.initScopeCharts();
            this.bindEvents();
        },

        bindEvents: function() {
            // Refresh trends button
            $('.vrsc-refresh-trends').on('click', this.refreshTrends);
            
            // Load more trends
            $('.vrsc-load-more').on('click', this.loadMoreTrends);
        },

        initScopeCharts: function() {
            $('.vrsc-scope-chart').each(function() {
                const $chart = $(this);
                const keyword = $chart.data('keyword');
                const timeframe = $chart.data('timeframe') || 30;
                
                if (keyword) {
                    ViraScopePublic.loadScopeChart($chart, keyword, timeframe);
                }
            });
        },

        loadScopeChart: function($container, keyword, timeframe) {
            const $chartContainer = $container.find('.vrsc-chart-container');
            
            $chartContainer.html('<div class="vrsc-chart-loading"><div class="vrsc-spinner"></div>Loading chart data...</div>');

            $.ajax({
                url: vrsc_public.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrsc_get_chart_data',
                    keyword: keyword,
                    timeframe: timeframe,
                    nonce: vrsc_public.nonce
                },
                success: function(response) {
                    if (response.success && response.data) {
                        ViraScopePublic.renderChart($chartContainer, response.data);
                    } else {
                        $chartContainer.html('<div class="vrsc-chart-placeholder">No chart data available for this keyword.</div>');
                    }
                },
                error: function() {
                    $chartContainer.html('<div class="vrsc-chart-placeholder">Failed to load chart data.</div>');
                }
            });
        },

        renderChart: function($container, data) {
            // Simple ASCII-style chart for demonstration
            // In a real implementation, you'd use Chart.js, D3.js, or similar
            
            let html = '<div class="vrsc-simple-chart">';
            html += '<div class="vrsc-chart-title">Trend Score Over Time</div>';
            html += '<div class="vrsc-chart-bars">';
            
            if (data.points && data.points.length > 0) {
                const maxScore = Math.max(...data.points.map(p => p.score));
                
                data.points.forEach(function(point, index) {
                    const height = (point.score / maxScore) * 100;
                    const color = ViraScopePublic.getScoreColor(point.score);
                    
                    html += '<div class="vrsc-chart-bar" style="height: ' + height + '%; background-color: ' + color + ';" title="' + point.date + ': ' + point.score + '%"></div>';
                });
            } else {
                html += '<div class="vrsc-chart-placeholder">No data points available</div>';
            }
            
            html += '</div>';
            html += '<div class="vrsc-chart-legend">';
            html += '<span class="vrsc-legend-item"><span class="vrsc-legend-color" style="background: #28a745;"></span>High (80-100%)</span>';
            html += '<span class="vrsc-legend-item"><span class="vrsc-legend-color" style="background: #ffc107;"></span>Medium (40-79%)</span>';
            html += '<span class="vrsc-legend-item"><span class="vrsc-legend-color" style="background: #dc3545;"></span>Low (0-39%)</span>';
            html += '</div>';
            html += '</div>';
            
            // Add CSS for the chart
            if (!$('#vrsc-chart-styles').length) {
                $('head').append(`
                    <style id="vrsc-chart-styles">
                        .vrsc-simple-chart {
                            width: 100%;
                            height: 100%;
                            display: flex;
                            flex-direction: column;
                            padding: 20px;
                            box-sizing: border-box;
                        }
                        .vrsc-chart-title {
                            text-align: center;
                            font-weight: 600;
                            margin-bottom: 20px;
                            color: #333;
                        }
                        .vrsc-chart-bars {
                            flex: 1;
                            display: flex;
                            align-items: end;
                            justify-content: space-around;
                            gap: 2px;
                            min-height: 200px;
                            border-bottom: 2px solid #ddd;
                            padding-bottom: 10px;
                        }
                        .vrsc-chart-bar {
                            flex: 1;
                            min-height: 10px;
                            border-radius: 2px 2px 0 0;
                            transition: opacity 0.2s ease;
                            cursor: pointer;
                        }
                        .vrsc-chart-bar:hover {
                            opacity: 0.8;
                        }
                        .vrsc-chart-legend {
                            display: flex;
                            justify-content: center;
                            gap: 20px;
                            margin-top: 15px;
                            font-size: 12px;
                        }
                        .vrsc-legend-item {
                            display: flex;
                            align-items: center;
                            gap: 5px;
                        }
                        .vrsc-legend-color {
                            width: 12px;
                            height: 12px;
                            border-radius: 2px;
                        }
                    </style>
                `);
            }
            
            $container.html(html);
        },

        getScoreColor: function(score) {
            if (score >= 80) return '#28a745';
            if (score >= 40) return '#ffc107';
            return '#dc3545';
        },

        refreshTrends: function() {
            const $button = $(this);
            const $container = $button.closest('.vrsc-trends-widget');
            const originalText = $button.text();
            
            $button.prop('disabled', true).text('Refreshing...');

            $.ajax({
                url: vrsc_public.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrsc_refresh_public_trends',
                    nonce: vrsc_public.nonce
                },
                success: function(response) {
                    if (response.success) {
                        location.reload();
                    } else {
                        console.error('Failed to refresh trends');
                    }
                },
                error: function() {
                    console.error('Network error occurred');
                },
                complete: function() {
                    $button.prop('disabled', false).text(originalText);
                }
            });
        },

        loadMoreTrends: function() {
            const $button = $(this);
            const $container = $button.closest('.vrsc-trends-widget');
            const $list = $container.find('.vrsc-trends-list');
            const offset = $list.children().length;
            const originalText = $button.text();
            
            $button.prop('disabled', true).text('Loading...');

            $.ajax({
                url: vrsc_public.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrsc_load_more_trends',
                    offset: offset,
                    nonce: vrsc_public.nonce
                },
                success: function(response) {
                    if (response.success && response.data.length > 0) {
                        response.data.forEach(function(trend) {
                            const scoreClass = ViraScopePublic.getScoreClass(trend.trend_score);
                            const html = `
                                <li class="vrsc-trend-item">
                                    <span class="vrsc-trend-keyword">${trend.keyword}</span>
                                    <span class="vrsc-trend-score ${scoreClass}">${trend.trend_score}%</span>
                                    <span class="vrsc-trend-volume">${trend.search_volume.toLocaleString()} searches</span>
                                </li>
                            `;
                            $list.append(html);
                        });
                        
                        if (response.data.length < 10) {
                            $button.hide();
                        }
                    } else {
                        $button.hide();
                    }
                },
                error: function() {
                    console.error('Network error occurred');
                },
                complete: function() {
                    $button.prop('disabled', false).text(originalText);
                }
            });
        },

        getScoreClass: function(score) {
            if (score >= 80) return 'vrsc-score-high';
            if (score >= 40) return 'vrsc-score-medium';
            return 'vrsc-score-low';
        }
    };

    // Initialize when document is ready
    $(document).ready(function() {
        ViraScopePublic.init();
    });

})(jQuery);