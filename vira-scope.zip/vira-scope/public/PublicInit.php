<?php
/**
 * Public functionality for Vira Scope.
 */

namespace ViraScope\Public;

use ViraScope\Traits\Singleton;
use ViraScope\Helpers\CacheHelper;

if (!defined('ABSPATH')) {
    exit;
}

class PublicInit {

    use Singleton;

    public function init() {
        add_action('wp_enqueue_scripts', [$this, 'enqueue_public_assets']);
        add_shortcode('vrsc_trends', [$this, 'trends_shortcode']);
        add_shortcode('vrsc_scope_chart', [$this, 'scope_chart_shortcode']);
        
        // AJAX handlers for public
        add_action('wp_ajax_vrsc_get_chart_data', [$this, 'ajax_get_chart_data']);
        add_action('wp_ajax_nopriv_vrsc_get_chart_data', [$this, 'ajax_get_chart_data']);
        add_action('wp_ajax_vrsc_refresh_public_trends', [$this, 'ajax_refresh_public_trends']);
        add_action('wp_ajax_nopriv_vrsc_refresh_public_trends', [$this, 'ajax_refresh_public_trends']);
        add_action('wp_ajax_vrsc_load_more_trends', [$this, 'ajax_load_more_trends']);
        add_action('wp_ajax_nopriv_vrsc_load_more_trends', [$this, 'ajax_load_more_trends']);
    }

    public function enqueue_public_assets() {
        wp_enqueue_script(
            'vrsc-public',
            VRSC_URL . 'public/Assets/js/public.js',
            ['jquery'],
            VRSC_VERSION,
            true
        );

        wp_enqueue_style(
            'vrsc-public',
            VRSC_URL . 'public/Assets/css/public.css',
            [],
            VRSC_VERSION
        );

        wp_localize_script('vrsc-public', 'vrsc_public', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('vrsc_public_nonce'),
        ]);
    }

    public function trends_shortcode($atts) {
        $atts = shortcode_atts([
            'limit' => 10,
            'category' => '',
            'display' => 'list'
        ], $atts, 'vrsc_trends');

        ob_start();
        include VRSC_PATH . 'public/Views/trends-shortcode.php';
        return ob_get_clean();
    }

    public function scope_chart_shortcode($atts) {
        $atts = shortcode_atts([
            'keyword' => '',
            'timeframe' => '30',
            'height' => '400'
        ], $atts, 'vrsc_scope_chart');

        ob_start();
        include VRSC_PATH . 'public/Views/scope-chart-shortcode.php';
        return ob_get_clean();
    }    

    public function ajax_get_chart_data() {
        check_ajax_referer('vrsc_public_nonce', 'nonce');

        $keyword = sanitize_text_field($_POST['keyword'] ?? '');
        $timeframe = intval($_POST['timeframe'] ?? 30);

        if (empty($keyword)) {
            wp_send_json_error(__('Keyword is required', 'vira-scope'));
        }

        // Generate sample chart data (in real implementation, this would come from database)
        $points = [];
        $base_score = rand(40, 80);
        
        for ($i = $timeframe; $i >= 0; $i--) {
            $date = date('Y-m-d', strtotime("-{$i} days"));
            $score = max(0, min(100, $base_score + rand(-15, 15)));
            $points[] = [
                'date' => $date,
                'score' => $score
            ];
        }

        wp_send_json_success([
            'keyword' => $keyword,
            'timeframe' => $timeframe,
            'points' => $points
        ]);
    }

    public function ajax_refresh_public_trends() {
        check_ajax_referer('vrsc_public_nonce', 'nonce');

        // Clear trends cache to force refresh
        $cache_helper = new CacheHelper();
        $cache_helper->delete('vrsc_latest_trends_10');
        $cache_helper->delete('vrsc_latest_trends_20');

        wp_send_json_success();
    }

    public function ajax_load_more_trends() {
        check_ajax_referer('vrsc_public_nonce', 'nonce');

        $offset = intval($_POST['offset'] ?? 0);
        $limit = 10;

        global $wpdb;
        $table = $wpdb->prefix . 'vrsc_trends';

        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table ORDER BY trend_score DESC, created_at DESC LIMIT %d OFFSET %d",
            $limit,
            $offset
        ));

        $trends = [];
        foreach ($results as $result) {
            $trends[] = [
                'keyword' => $result->keyword,
                'trend_score' => floatval($result->trend_score),
                'search_volume' => intval($result->search_volume),
                'competition_level' => $result->competition_level
            ];
        }

        wp_send_json_success($trends);
    }
}