<?php
/**
 * Trends Shortcode View for Vira Scope.
 */

if (!defined('ABSPATH')) {
    exit;
}

$trends_service = new \ViraScope\Services\TrendsService();
$limit = intval($atts['limit']);
$category = sanitize_text_field($atts['category']);
$display = sanitize_text_field($atts['display']);

$trends = $trends_service->get_latest_trends($limit);

if (empty($trends)) {
    echo '<div class="vrsc-trends-widget"><p>' . __('No trends available at the moment.', 'vira-scope') . '</p></div>';
    return;
}
?>

<div class="vrsc-trends-widget">
    <h3><?php _e('Latest Trends', 'vira-scope'); ?></h3>
    
    <?php if ($display === 'grid'): ?>
        <div class="vrsc-trends-grid">
            <?php foreach ($trends as $trend): ?>
                <div class="vrsc-trend-card">
                    <div class="vrsc-trend-keyword"><?php echo esc_html($trend->keyword); ?></div>
                    <div class="vrsc-trend-score <?php echo esc_attr($this->get_score_class($trend->trend_score)); ?>">
                        <?php echo esc_html($trend->trend_score); ?>%
                    </div>
                    <div class="vrsc-trend-volume">
                        <?php echo esc_html(number_format($trend->search_volume)); ?> <?php _e('searches', 'vira-scope'); ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <ul class="vrsc-trends-list">
            <?php foreach ($trends as $trend): ?>
                <li class="vrsc-trend-item">
                    <span class="vrsc-trend-keyword"><?php echo esc_html($trend->keyword); ?></span>
                    <span class="vrsc-trend-score <?php echo esc_attr($this->get_score_class($trend->trend_score)); ?>">
                        <?php echo esc_html($trend->trend_score); ?>%
                    </span>
                    <span class="vrsc-trend-volume">
                        <?php echo esc_html(number_format($trend->search_volume)); ?> <?php _e('searches', 'vira-scope'); ?>
                    </span>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
    
    <?php if (count($trends) >= $limit): ?>
        <div class="vrsc-trends-actions">
            <button type="button" class="vrsc-load-more button">
                <?php _e('Load More', 'vira-scope'); ?>
            </button>
        </div>
    <?php endif; ?>
</div>

<?php
// Helper method for score classes
function get_score_class($score) {
    if ($score >= 80) return 'vrsc-score-high';
    if ($score >= 40) return 'vrsc-score-medium';
    return 'vrsc-score-low';
}
?>