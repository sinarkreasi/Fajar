<?php
/**
 * Scope Chart Shortcode View for Vira Scope.
 */

if (!defined('ABSPATH')) {
    exit;
}

$keyword = sanitize_text_field($atts['keyword']);
$timeframe = intval($atts['timeframe']);
$height = intval($atts['height']);

if (empty($keyword)) {
    echo '<div class="vrsc-scope-chart"><p>' . __('Please specify a keyword for the chart.', 'vira-scope') . '</p></div>';
    return;
}
?>

<div class="vrsc-scope-chart" data-keyword="<?php echo esc_attr($keyword); ?>" data-timeframe="<?php echo esc_attr($timeframe); ?>">
    <h3><?php printf(__('Trend Analysis: %s', 'vira-scope'), esc_html($keyword)); ?></h3>
    
    <div class="vrsc-chart-container" style="height: <?php echo esc_attr($height); ?>px;">
        <div class="vrsc-chart-loading">
            <div class="vrsc-spinner"></div>
            <?php _e('Loading chart data...', 'vira-scope'); ?>
        </div>
    </div>
    
    <div class="vrsc-chart-info">
        <div class="vrsc-chart-meta">
            <span class="vrsc-chart-keyword">
                <strong><?php _e('Keyword:', 'vira-scope'); ?></strong> <?php echo esc_html($keyword); ?>
            </span>
            <span class="vrsc-chart-timeframe">
                <strong><?php _e('Timeframe:', 'vira-scope'); ?></strong> <?php printf(__('Last %d days', 'vira-scope'), $timeframe); ?>
            </span>
        </div>
    </div>
</div>