<?php
/**
 * Bootstrap loader for Vira Scope.
 * Handles autoloading, initialization, and core registration.
 */

namespace ViraScope;

if (!defined('ABSPATH')) {
    exit;
}

// Load configuration constants
require_once VRSC_PATH . 'config/constants.php';

// Simple class mapping for reliability
$class_map = [
    'ViraScope\\Admin\\Admin' => VRSC_PATH . 'admin/Admin.php',
    'ViraScope\\Public\\PublicInit' => VRSC_PATH . 'public/PublicInit.php',
    'ViraScope\\Traits\\Singleton' => VRSC_PATH . 'includes/Traits/Singleton.php',
    'ViraScope\\Services\\TrendsService' => VRSC_PATH . 'includes/Services/TrendsService.php',
    'ViraScope\\Services\\AIService' => VRSC_PATH . 'includes/Services/AIService.php',
    'ViraScope\\Models\\Trend' => VRSC_PATH . 'includes/Models/Trend.php',
    'ViraScope\\Helpers\\CacheHelper' => VRSC_PATH . 'includes/Helpers/CacheHelper.php',
    'ViraScope\\Database\\Schema' => VRSC_PATH . 'includes/Database/Schema.php',
    'ViraScope\\Controllers\\CronController' => VRSC_PATH . 'includes/Controllers/CronController.php',
];

// Register autoloader with explicit class mapping
spl_autoload_register(function ($class) use ($class_map) {
    if (isset($class_map[$class]) && file_exists($class_map[$class])) {
        require_once $class_map[$class];
        return;
    }
    
    // Fallback PSR-4 autoloader for any missed classes
    if (strpos($class, 'ViraScope\\') === 0) {
        $relative_class = str_replace('ViraScope\\', '', $class);
        $file = VRSC_PATH . 'includes/' . str_replace('\\', '/', $relative_class) . '.php';
        
        if (file_exists($file)) {
            require_once $file;
        }
    }
});

// Singleton main class
class Fajar {

    use Traits\Singleton;

    public static function init() {
        self::instance()->setup_hooks();
    }

    private function setup_hooks() {
        // Initialize Admin
        if (is_admin()) {
            Admin\Admin::instance()->init();
        }

        // Initialize Public
        Public\PublicInit::instance()->init();

        // Load text domain for translations
        add_action('init', [$this, 'load_textdomain']);
        
        // Initialize cron controller
        Controllers\CronController::init();
    }

    public function load_textdomain() {
        load_plugin_textdomain('vira-scope', false, dirname(plugin_basename(VRSC_PATH)) . '/languages');
    }
}