<?php
/**
 * Singleton Trait for Vira Scope classes.
 */

namespace ViraScope\Traits;

if (!defined('ABSPATH')) {
    exit;
}

trait Singleton {

    private static ?self $instance = null;

    private function __construct() {}
    private function __clone() {}

    public static function instance(): self {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
}