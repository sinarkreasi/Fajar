<?php
/**
 * Trends Service for Vira Scope.
 */

namespace ViraScope\Services;

use ViraScope\Models\Trend;
use ViraScope\Helpers\CacheHelper;

if (!defined('ABSPATH')) {
    exit;
}

class TrendsService {

    private $cache_helper;

    public function __construct() {
        $this->cache_helper = new CacheHelper();
    }



    public function analyze_site_content($content_types = null, $force_refresh = false) {
        if ($content_types === null) {
            $content_types = ['post', 'page'];
        }

        $analysis_results = [];
        
        // Analyze posts by type
        foreach ($content_types as $post_type) {
            $analysis_results[$post_type] = $this->analyze_content_by_type($post_type, $force_refresh);
        }
        
        // Analyze taxonomies if requested
        if (in_array('taxonomies', $content_types)) {
            $analysis_results['taxonomies'] = $this->analyze_taxonomies($force_refresh);
        }
        
        return $analysis_results;
    }

    public function analyze_content_by_type($post_type, $force_refresh = false) {
        $meta_query = [];
        if (!$force_refresh) {
            $meta_query = [
                [
                    'key' => '_vrsc_analyzed',
                    'compare' => 'NOT EXISTS'
                ]
            ];
        }

        $posts = get_posts([
            'post_type' => $post_type,
            'post_status' => 'publish',
            'numberposts' => 50, // Limit per type
            'meta_query' => $meta_query
        ]);

        $keywords = [];
        $processed_count = 0;
        
        foreach ($posts as $post) {
            $content = $post->post_title . ' ' . $post->post_content . ' ' . $post->post_excerpt;
            $extracted = $this->extract_keywords($content);
            $keywords = array_merge($keywords, $extracted);
            
            // Mark as analyzed
            update_post_meta($post->ID, '_vrsc_analyzed', time());
            $processed_count++;
        }

        return [
            'keywords' => array_unique($keywords),
            'processed_count' => $processed_count,
            'total_posts' => wp_count_posts($post_type)->publish ?? 0
        ];
    }

    public function analyze_taxonomies($force_refresh = false) {
        $taxonomies = get_taxonomies(['public' => true], 'names');
        $keywords = [];
        $processed_count = 0;
        
        foreach ($taxonomies as $taxonomy) {
            $terms = get_terms([
                'taxonomy' => $taxonomy,
                'hide_empty' => true,
                'number' => 100
            ]);
            
            foreach ($terms as $term) {
                $content = $term->name . ' ' . $term->description;
                $extracted = $this->extract_keywords($content);
                $keywords = array_merge($keywords, $extracted);
                $processed_count++;
            }
        }
        
        return [
            'keywords' => array_unique($keywords),
            'processed_count' => $processed_count,
            'taxonomies' => array_keys($taxonomies)
        ];
    }

    public function get_latest_trends($limit = 20, $min_keyword_length = 0) {
        $cache_key = 'vrsc_latest_trends_' . $limit . '_' . $min_keyword_length;
        $cached = $this->cache_helper->get($cache_key);

        if ($cached !== false) {
            return $cached;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'vrsc_trends';

        $where_clause = '';
        if ($min_keyword_length > 0) {
            $where_clause = $wpdb->prepare(' AND CHAR_LENGTH(keyword) - CHAR_LENGTH(REPLACE(keyword, " ", "")) + 1 >= %d', $min_keyword_length);
        }

        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table WHERE 1=1 $where_clause ORDER BY trend_score DESC, created_at DESC LIMIT %d",
            $limit
        ));

        $trends = [];
        foreach ($results as $result) {
            $trends[] = new Trend($result);
        }

        $this->cache_helper->set($cache_key, $trends, 300); // 5 minutes cache
        return $trends;
    }

    private function extract_keywords($content) {
        // Simple keyword extraction - can be enhanced with NLP
        $content = strip_tags($content);
        $content = strtolower($content);
        
        // Remove common words
        $stop_words = ['the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by'];
        $words = str_word_count($content, 1);
        $words = array_diff($words, $stop_words);
        
        // Filter words by length
        $keywords = array_filter($words, function($word) {
            return strlen($word) >= 3 && strlen($word) <= 20;
        });

        return array_slice(array_unique($keywords), 0, 50);
    }

    public function save_trend($keyword, $trend_score, $search_volume = 0, $ai_analysis = '') {
        global $wpdb;
        $table = $wpdb->prefix . 'vrsc_trends';

        return $wpdb->insert(
            $table,
            [
                'keyword' => sanitize_text_field($keyword),
                'trend_score' => floatval($trend_score),
                'search_volume' => intval($search_volume),
                'ai_analysis' => sanitize_textarea_field($ai_analysis),
                'source' => 'internal'
            ],
            ['%s', '%f', '%d', '%s', '%s']
        );
    }

    public function get_trend_by_keyword($keyword) {
        global $wpdb;
        $table = $wpdb->prefix . 'vrsc_trends';

        $result = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE keyword = %s ORDER BY created_at DESC LIMIT 1",
            $keyword
        ));

        return $result ? new Trend($result) : null;
    }
}