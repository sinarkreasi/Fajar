<?php
/**
 * AI Service for Vira Scope.
 */

namespace ViraScope\Services;

use ViraScope\Helpers\CacheHelper;

if (!defined('ABSPATH')) {
    exit;
}

class AIService {

    private $cache_helper;
    private $gemini_api_key;
    private $openai_api_key;

    public function __construct() {
        $this->cache_helper = new CacheHelper();
        $this->gemini_api_key = get_option('vrsc_gemini_api_key', '');
        $this->openai_api_key = get_option('vrsc_openai_api_key', '');
    }

    private function get_gemini_model() {
        $model = get_option('vrsc_gemini_model', 'gemini-2.5-flash');
        return $model;
    }

    public function get_available_gemini_models() {
        return [
            'gemini-2.5-flash' => 'Gemini Flash 2.5 (Recommended)',
            'gemini-2.5-flash-lite' => 'Gemini Flash Lite 2.5 (Faster)',
            'gemini-2.5-pro' => 'Gemini Pro 2.5 (Most Capable)'
        ];
    }

    public function get_available_openai_models() {
        return [
            'gpt-4o' => 'GPT-4o (Recommended)',
            'gpt-4o-mini' => 'GPT-4o Mini (Faster & Cost-effective)',
            'o1-preview' => 'o1 Preview (Advanced Reasoning)',
            'o1-mini' => 'o1 Mini (Fast Reasoning)'
        ];
    }

    private function get_openai_model() {
        $model = get_option('vrsc_openai_model', 'gpt-4o');
        return $model;
    }

    private function get_ai_provider() {
        return get_option('vrsc_ai_provider', 'gemini');
    }

    public function analyze_keyword($keyword) {
        $cache_key = 'vrsc_ai_analysis_' . md5($keyword);
        $cached = $this->cache_helper->get($cache_key);

        if ($cached !== false) {
            return $cached;
        }

        $analysis = [];
        $errors = [];
        $preferred_provider = $this->get_ai_provider();

        // Try preferred provider first
        if ($preferred_provider === 'openai' && !empty($this->openai_api_key)) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Vira Scope: Attempting OpenAI analysis for keyword: ' . $keyword);
            }
            
            $openai_analysis = $this->analyze_with_openai($keyword);
            if ($openai_analysis) {
                $analysis['openai'] = $openai_analysis;
                
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log('Vira Scope: OpenAI analysis successful');
                }
            } else {
                $errors[] = 'OpenAI analysis failed';
                
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log('Vira Scope: OpenAI analysis failed for keyword: ' . $keyword);
                }
            }
        } elseif ($preferred_provider === 'gemini' && !empty($this->gemini_api_key)) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Vira Scope: Attempting Gemini analysis for keyword: ' . $keyword);
            }
            
            $gemini_analysis = $this->analyze_with_gemini($keyword);
            if ($gemini_analysis) {
                $analysis['gemini'] = $gemini_analysis;
                
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log('Vira Scope: Gemini analysis successful');
                }
            } else {
                $errors[] = 'Gemini analysis failed';
                
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log('Vira Scope: Gemini analysis failed for keyword: ' . $keyword);
                }
            }
        }

        // Fallback to other provider if preferred failed
        if (empty($analysis)) {
            if ($preferred_provider === 'openai' && !empty($this->gemini_api_key)) {
                // Fallback to Gemini
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log('Vira Scope: Falling back to Gemini analysis for keyword: ' . $keyword);
                }
                
                $gemini_analysis = $this->analyze_with_gemini($keyword);
                if ($gemini_analysis) {
                    $analysis['gemini'] = $gemini_analysis;
                    
                    if (defined('WP_DEBUG') && WP_DEBUG) {
                        error_log('Vira Scope: Gemini fallback analysis successful');
                    }
                } else {
                    $errors[] = 'Gemini fallback analysis failed';
                }
            } elseif ($preferred_provider === 'gemini' && !empty($this->openai_api_key)) {
                // Fallback to OpenAI
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log('Vira Scope: Falling back to OpenAI analysis for keyword: ' . $keyword);
                }
                
                $openai_analysis = $this->analyze_with_openai($keyword);
                if ($openai_analysis) {
                    $analysis['openai'] = $openai_analysis;
                    
                    if (defined('WP_DEBUG') && WP_DEBUG) {
                        error_log('Vira Scope: OpenAI fallback analysis successful');
                    }
                } else {
                    $errors[] = 'OpenAI fallback analysis failed';
                }
            }
        }

        // Add error if no providers are configured
        if (empty($analysis)) {
            if (empty($this->gemini_api_key) && empty($this->openai_api_key)) {
                $errors[] = 'No AI providers configured';
            }
        }

        // If no analysis succeeded, add error information
        if (empty($analysis)) {
            $analysis['error'] = 'All AI services failed';
            $analysis['details'] = $errors;
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Vira Scope: All AI analysis failed for keyword: ' . $keyword . '. Errors: ' . implode(', ', $errors));
            }
        }

        // Cache for 1 hour (even failures to avoid repeated API calls)
        $this->cache_helper->set($cache_key, $analysis, 3600);
        return $analysis;
    }

    private function analyze_with_gemini($keyword) {
        if (empty($this->gemini_api_key)) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Vira Scope: Gemini API key is empty');
            }
            return false;
        }

        $prompt = $this->build_analysis_prompt($keyword);
        
        $request_data = [
            'contents' => [
                [
                    'parts' => [
                        ['text' => $prompt]
                    ]
                ]
            ]
        ];
        
        $model = $this->get_gemini_model();
        $response = wp_remote_post('https://generativelanguage.googleapis.com/v1beta/models/' . $model . ':generateContent?key=' . $this->gemini_api_key, [
            'headers' => [
                'Content-Type' => 'application/json',
            ],
            'body' => json_encode($request_data),
            'timeout' => 30
        ]);

        if (is_wp_error($response)) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Vira Scope Gemini Error: ' . $response->get_error_message());
            }
            return false;
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        if ($response_code !== 200) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Vira Scope Gemini HTTP Error ' . $response_code . ': ' . $body);
            }
            return false;
        }
        
        $data = json_decode($body, true);

        if (isset($data['candidates'][0]['content']['parts'][0]['text'])) {
            return $this->parse_ai_response($data['candidates'][0]['content']['parts'][0]['text']);
        }

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Vira Scope Gemini: Unexpected response format - ' . $body);
        }
        
        return false;
    }

    private function analyze_with_openai($keyword) {
        if (empty($this->openai_api_key)) {
            return false;
        }

        $prompt = $this->build_analysis_prompt($keyword);

        $model = $this->get_openai_model();
        $response = wp_remote_post('https://api.openai.com/v1/chat/completions', [
            'headers' => [
                'Authorization' => 'Bearer ' . $this->openai_api_key,
                'Content-Type' => 'application/json',
            ],
            'body' => json_encode([
                'model' => $model,
                'messages' => [
                    [
                        'role' => 'user',
                        'content' => $prompt
                    ]
                ],
                'max_tokens' => 500,
                'temperature' => 0.7
            ]),
            'timeout' => 30
        ]);

        if (is_wp_error($response)) {
            return false;
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (isset($data['choices'][0]['message']['content'])) {
            return $this->parse_ai_response($data['choices'][0]['message']['content']);
        }

        return false;
    }

    private function build_analysis_prompt($keyword) {
        return "Analyze the keyword '{$keyword}' for trend potential. Provide a JSON response with the following structure:
        {
            \"trend_score\": (0-100),
            \"search_volume_estimate\": (number),
            \"competition_level\": \"low|medium|high\",
            \"trend_direction\": \"rising|stable|declining\",
            \"opportunities\": [\"opportunity1\", \"opportunity2\"],
            \"related_keywords\": [\"keyword1\", \"keyword2\"],
            \"content_suggestions\": [\"suggestion1\", \"suggestion2\"],
            \"summary\": \"Brief analysis summary\"
        }";
    }

    private function parse_ai_response($response) {
        // Try to extract JSON from response
        preg_match('/\{.*\}/s', $response, $matches);
        
        if (!empty($matches[0])) {
            $json = json_decode($matches[0], true);
            if (json_last_error() === JSON_ERROR_NONE) {
                return $json;
            }
        }

        // Fallback to basic parsing
        return [
            'trend_score' => 50,
            'search_volume_estimate' => 1000,
            'competition_level' => 'medium',
            'trend_direction' => 'stable',
            'opportunities' => [],
            'related_keywords' => [],
            'content_suggestions' => [],
            'summary' => 'AI analysis completed for: ' . $response
        ];
    }

    public function test_connection() {
        $gemini_key = get_option('vrsc_gemini_api_key', '');
        $openai_key = get_option('vrsc_openai_api_key', '');
        
        // Test Gemini first if key is available
        if (!empty($gemini_key)) {
            $result = $this->test_gemini_connection($gemini_key);
            if ($result['success']) {
                return [
                    'success' => true,
                    'provider' => 'Gemini',
                    'details' => $result['details']
                ];
            } else {
                // If Gemini fails, try OpenAI
                if (!empty($openai_key)) {
                    $openai_result = $this->test_openai_connection($openai_key);
                    if ($openai_result['success']) {
                        return [
                            'success' => true,
                            'provider' => 'OpenAI',
                            'details' => $openai_result['details']
                        ];
                    }
                }
                
                return [
                    'success' => false,
                    'error' => 'Both AI services failed',
                    'details' => [
                        'gemini_error' => $result['error'],
                        'openai_error' => !empty($openai_key) ? $openai_result['error'] : 'No OpenAI key provided'
                    ]
                ];
            }
        } elseif (!empty($openai_key)) {
            // Only OpenAI key available
            $result = $this->test_openai_connection($openai_key);
            return [
                'success' => $result['success'],
                'provider' => $result['success'] ? 'OpenAI' : null,
                'error' => $result['success'] ? null : $result['error'],
                'details' => $result['details']
            ];
        } else {
            return [
                'success' => false,
                'error' => 'No API keys configured',
                'details' => 'Please configure at least one AI service API key'
            ];
        }
    }

    private function test_gemini_connection($api_key) {
        $test_prompt = 'Say "Hello" in JSON format: {"message": "Hello"}';
        $model = $this->get_gemini_model();
        
        $response = wp_remote_post('https://generativelanguage.googleapis.com/v1beta/models/' . $model . ':generateContent?key=' . $api_key, [
            'headers' => [
                'Content-Type' => 'application/json',
            ],
            'body' => json_encode([
                'contents' => [
                    [
                        'parts' => [
                            ['text' => $test_prompt]
                        ]
                    ]
                ]
            ]),
            'timeout' => 15
        ]);

        if (is_wp_error($response)) {
            return [
                'success' => false,
                'error' => 'Network error: ' . $response->get_error_message(),
                'details' => null
            ];
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        if ($response_code !== 200) {
            $error_data = json_decode($body, true);
            return [
                'success' => false,
                'error' => 'API error (HTTP ' . $response_code . ')',
                'details' => $error_data['error']['message'] ?? $body
            ];
        }

        $data = json_decode($body, true);
        
        if (isset($data['candidates'][0]['content']['parts'][0]['text'])) {
            return [
                'success' => true,
                'details' => 'Connection successful, response received'
            ];
        } else {
            return [
                'success' => false,
                'error' => 'Invalid response format',
                'details' => $body
            ];
        }
    }

    private function test_openai_connection($api_key) {
        $model = $this->get_openai_model();
        $response = wp_remote_post('https://api.openai.com/v1/chat/completions', [
            'headers' => [
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json',
            ],
            'body' => json_encode([
                'model' => $model,
                'messages' => [
                    [
                        'role' => 'user',
                        'content' => 'Say "Hello" in JSON format'
                    ]
                ],
                'max_tokens' => 50,
                'temperature' => 0.1
            ]),
            'timeout' => 15
        ]);

        if (is_wp_error($response)) {
            return [
                'success' => false,
                'error' => 'Network error: ' . $response->get_error_message(),
                'details' => null
            ];
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        if ($response_code !== 200) {
            $error_data = json_decode($body, true);
            return [
                'success' => false,
                'error' => 'API error (HTTP ' . $response_code . ')',
                'details' => $error_data['error']['message'] ?? $body
            ];
        }

        $data = json_decode($body, true);
        
        if (isset($data['choices'][0]['message']['content'])) {
            return [
                'success' => true,
                'details' => 'Connection successful, response received'
            ];
        } else {
            return [
                'success' => false,
                'error' => 'Invalid response format',
                'details' => $body
            ];
        }
    }

    public function batch_analyze_keywords($keywords) {
        $results = [];
        
        foreach ($keywords as $keyword) {
            $analysis = $this->analyze_keyword($keyword);
            if (!empty($analysis)) {
                $results[$keyword] = $analysis;
            }
            
            // Rate limiting
            usleep(500000); // 0.5 second delay
        }

        return $results;
    }
}