<?php
/**
 * Trend Model for Vira Scope.
 */

namespace ViraScope\Models;

if (!defined('ABSPATH')) {
    exit;
}

class Trend {

    public $id;
    public $keyword;
    public $trend_score;
    public $search_volume;
    public $competition_level;
    public $ai_analysis;
    public $source;
    public $created_at;
    public $updated_at;

    public function __construct($data = null) {
        if ($data) {
            $this->fill($data);
        }
    }

    public function fill($data) {
        if (is_object($data)) {
            $data = (array) $data;
        }

        $this->id = $data['id'] ?? null;
        $this->keyword = $data['keyword'] ?? '';
        $this->trend_score = floatval($data['trend_score'] ?? 0);
        $this->search_volume = intval($data['search_volume'] ?? 0);
        $this->competition_level = $data['competition_level'] ?? 'low';
        $this->ai_analysis = $data['ai_analysis'] ?? '';
        $this->source = $data['source'] ?? 'google';
        $this->created_at = $data['created_at'] ?? '';
        $this->updated_at = $data['updated_at'] ?? '';
    }

    public function save() {
        global $wpdb;
        $table = $wpdb->prefix . 'vrsc_trends';

        $data = [
            'keyword' => sanitize_text_field($this->keyword),
            'trend_score' => $this->trend_score,
            'search_volume' => $this->search_volume,
            'competition_level' => sanitize_text_field($this->competition_level),
            'ai_analysis' => sanitize_textarea_field($this->ai_analysis),
            'source' => sanitize_text_field($this->source)
        ];

        $format = ['%s', '%f', '%d', '%s', '%s', '%s'];

        if ($this->id) {
            $result = $wpdb->update($table, $data, ['id' => $this->id], $format, ['%d']);
        } else {
            $result = $wpdb->insert($table, $data, $format);
            if ($result) {
                $this->id = $wpdb->insert_id;
            }
        }

        return $result !== false;
    }

    public function delete() {
        if (!$this->id) {
            return false;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'vrsc_trends';

        return $wpdb->delete($table, ['id' => $this->id], ['%d']) !== false;
    }

    public function get_ai_analysis_array() {
        if (empty($this->ai_analysis)) {
            return [];
        }

        $decoded = json_decode($this->ai_analysis, true);
        return is_array($decoded) ? $decoded : [];
    }

    public function get_trend_direction() {
        $analysis = $this->get_ai_analysis_array();
        return $analysis['trend_direction'] ?? 'stable';
    }

    public function get_opportunities() {
        $analysis = $this->get_ai_analysis_array();
        return $analysis['opportunities'] ?? [];
    }

    public function get_related_keywords() {
        $analysis = $this->get_ai_analysis_array();
        return $analysis['related_keywords'] ?? [];
    }

    public function get_competition_color() {
        switch ($this->competition_level) {
            case 'low':
                return '#28a745';
            case 'medium':
                return '#ffc107';
            case 'high':
                return '#dc3545';
            default:
                return '#6c757d';
        }
    }

    public function get_trend_score_color() {
        if ($this->trend_score >= 80) {
            return '#28a745';
        } elseif ($this->trend_score >= 60) {
            return '#ffc107';
        } elseif ($this->trend_score >= 40) {
            return '#fd7e14';
        } else {
            return '#dc3545';
        }
    }
}