<?php
/**
 * Cache Helper for Vira Scope.
 */

namespace ViraScope\Helpers;

if (!defined('ABSPATH')) {
    exit;
}

class CacheHelper {

    private $use_database = true;

    public function __construct() {
        // Use database cache if object cache is not available
        $this->use_database = !wp_using_ext_object_cache();
    }

    public function get($key) {
        $key = $this->sanitize_key($key);

        if (!$this->use_database) {
            return wp_cache_get($key, 'vrsc');
        }

        return $this->get_from_database($key);
    }

    public function set($key, $value, $expiration = 3600) {
        $key = $this->sanitize_key($key);

        if (!$this->use_database) {
            return wp_cache_set($key, $value, 'vrsc', $expiration);
        }

        return $this->set_to_database($key, $value, $expiration);
    }

    public function delete($key) {
        $key = $this->sanitize_key($key);

        if (!$this->use_database) {
            return wp_cache_delete($key, 'vrsc');
        }

        return $this->delete_from_database($key);
    }

    public function flush() {
        if (!$this->use_database) {
            return wp_cache_flush();
        }

        return $this->flush_database();
    }

    private function sanitize_key($key) {
        return 'vrsc_' . md5($key);
    }

    private function get_from_database($key) {
        global $wpdb;
        $table = $wpdb->prefix . 'vrsc_cache';

        $result = $wpdb->get_row($wpdb->prepare(
            "SELECT cache_value, expires_at FROM $table WHERE cache_key = %s",
            $key
        ));

        if (!$result) {
            return false;
        }

        // Check if expired
        if (strtotime($result->expires_at) < time()) {
            $this->delete_from_database($key);
            return false;
        }

        return maybe_unserialize($result->cache_value);
    }

    private function set_to_database($key, $value, $expiration) {
        global $wpdb;
        $table = $wpdb->prefix . 'vrsc_cache';

        $expires_at = date('Y-m-d H:i:s', time() + $expiration);
        $serialized_value = maybe_serialize($value);

        return $wpdb->replace(
            $table,
            [
                'cache_key' => $key,
                'cache_value' => $serialized_value,
                'expires_at' => $expires_at
            ],
            ['%s', '%s', '%s']
        ) !== false;
    }

    private function delete_from_database($key) {
        global $wpdb;
        $table = $wpdb->prefix . 'vrsc_cache';

        return $wpdb->delete($table, ['cache_key' => $key], ['%s']) !== false;
    }

    private function flush_database() {
        global $wpdb;
        $table = $wpdb->prefix . 'vrsc_cache';

        return $wpdb->query("TRUNCATE TABLE $table") !== false;
    }

    public function cleanup_expired() {
        if (!$this->use_database) {
            return true;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'vrsc_cache';

        return $wpdb->query($wpdb->prepare(
            "DELETE FROM $table WHERE expires_at < %s",
            date('Y-m-d H:i:s')
        )) !== false;
    }
}