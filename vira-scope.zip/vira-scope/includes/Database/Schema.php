<?php
/**
 * Database Schema for Vira Scope.
 */

namespace ViraScope\Database;

if (!defined('ABSPATH')) {
    exit;
}

class Schema {

    public function migrate() {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        // Trends table
        $trends_table = $wpdb->prefix . 'vrsc_trends';
        $trends_sql = "CREATE TABLE $trends_table (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            keyword varchar(255) NOT NULL,
            trend_score decimal(5,2) DEFAULT 0.00,
            search_volume int(11) DEFAULT 0,
            competition_level varchar(20) DEFAULT 'low',
            ai_analysis longtext,
            source varchar(50) DEFAULT 'google',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY keyword_idx (keyword),
            KEY trend_score_idx (trend_score),
            KEY created_at_idx (created_at)
        ) $charset_collate;";

        // Cache table
        $cache_table = $wpdb->prefix . 'vrsc_cache';
        $cache_sql = "CREATE TABLE $cache_table (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            cache_key varchar(255) NOT NULL,
            cache_value longtext,
            expires_at datetime NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY cache_key_idx (cache_key),
            KEY expires_at_idx (expires_at)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($trends_sql);
        dbDelta($cache_sql);

        // Set version
        update_option('vrsc_db_version', VRSC_VERSION);
    }

    public function drop_tables() {
        global $wpdb;
        
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}vrsc_trends");
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}vrsc_cache");
        
        delete_option('vrsc_db_version');
    }
}