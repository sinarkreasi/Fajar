<?php
/**
 * Cron Controller for Vira Scope.
 */

namespace ViraScope\Controllers;

use ViraScope\Services\TrendsService;
use ViraScope\Services\AIService;
use ViraScope\Helpers\CacheHelper;

if (!defined('ABSPATH')) {
    exit;
}

class CronController {

    public static function init() {
        // Schedule cron jobs
        add_action('wp', [__CLASS__, 'schedule_events']);
        
        // Register cron hooks
        add_action('vrsc_analyze_content', [__CLASS__, 'analyze_content']);
        add_action('vrsc_cleanup_cache', [__CLASS__, 'cleanup_cache']);
        
        // Add custom cron schedules
        add_filter('cron_schedules', [__CLASS__, 'add_cron_schedules']);
    }

    public static function schedule_events() {
        $frequency = get_option('vrsc_analysis_frequency', 'daily');
        
        if ($frequency !== 'manual') {
            if (!wp_next_scheduled('vrsc_analyze_content')) {
                wp_schedule_event(time(), $frequency, 'vrsc_analyze_content');
            }
        }

        if (!wp_next_scheduled('vrsc_cleanup_cache')) {
            wp_schedule_event(time(), 'daily', 'vrsc_cleanup_cache');
        }
    }

    public static function add_cron_schedules($schedules) {
        $schedules['vrsc_hourly'] = [
            'interval' => 3600,
            'display' => __('Every Hour (Vira Scope)', 'vira-scope')
        ];
        
        return $schedules;
    }

    public static function analyze_content() {
        $trends_service = new TrendsService();
        $ai_service = new AIService();
        
        $keywords = $trends_service->analyze_site_content();
        
        if (!empty($keywords)) {
            $batch_size = get_option('vrsc_max_keywords_per_batch', 10);
            $keyword_batch = array_slice($keywords, 0, $batch_size);
            
            $results = $ai_service->batch_analyze_keywords($keyword_batch);
            
            foreach ($results as $keyword => $analysis) {
                $trend_score = 50;
                if (isset($analysis['gemini']['trend_score'])) {
                    $trend_score = $analysis['gemini']['trend_score'];
                } elseif (isset($analysis['openai']['trend_score'])) {
                    $trend_score = $analysis['openai']['trend_score'];
                }
                
                $search_volume = 0;
                if (isset($analysis['gemini']['search_volume_estimate'])) {
                    $search_volume = $analysis['gemini']['search_volume_estimate'];
                } elseif (isset($analysis['openai']['search_volume_estimate'])) {
                    $search_volume = $analysis['openai']['search_volume_estimate'];
                }
                
                $trends_service->save_trend($keyword, $trend_score, $search_volume, json_encode($analysis));
            }
        }
    }

    public static function cleanup_cache() {
        $cache_helper = new CacheHelper();
        $cache_helper->cleanup_expired();
        
        // Clean up old trends (older than 90 days)
        global $wpdb;
        $table = $wpdb->prefix . 'vrsc_trends';
        $wpdb->query($wpdb->prepare(
            "DELETE FROM $table WHERE created_at < %s",
            date('Y-m-d H:i:s', strtotime('-90 days'))
        ));
    }

    public static function clear_scheduled_events() {
        wp_clear_scheduled_hook('vrsc_analyze_content');
        wp_clear_scheduled_hook('vrsc_cleanup_cache');
    }
}