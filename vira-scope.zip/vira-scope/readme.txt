=== Vira Scope ===
Contributors: viraloka
Tags: ai, trends, seo, analytics, keywords
Requires at least: 6.8.3
Tested up to: 6.8.3
Requires PHP: 8.2
Stable tag: 1.0.0
License: GPL-2.0+
License URI: http://www.gnu.org/licenses/gpl-2.0.txt

AI-Driven Real-Time Trend Intelligence Plugin for WordPress. Discover emerging trends and content opportunities with AI-powered analysis.

== Description ==

**Vira Scope** is an advanced AI-powered trend intelligence plugin that helps you discover emerging trends, analyze keyword opportunities, and identify content gaps in real-time. Using cutting-edge AI technology from Google Gemini and OpenAI, Vira Scope provides actionable insights to boost your content strategy.

= Key Features =

* 🔍 **AI Trend Detection** - Scan your site content and external sources for emerging trends
* 📈 **Visual Analytics** - Interactive "Scope Chart" for trend visualization
* 🧠 **Dual AI Analysis** - Powered by both Gemini and OpenAI for comprehensive insights
* 🗂 **Smart Caching** - Lightning-fast performance with intelligent data caching
* 🚀 **Addon Ready** - Extensible architecture for Pro features
* 🔒 **Security First** - Built with WordPress security best practices
* 📱 **Responsive Design** - Works perfectly on all devices

= How It Works =

1. **Content Analysis** - Automatically scans your WordPress content for keywords and topics
2. **AI Processing** - Sends data to AI services for trend analysis and scoring
3. **Trend Scoring** - Assigns trend scores (0-100%) based on multiple factors
4. **Visual Reports** - Displays results in easy-to-understand charts and lists
5. **Actionable Insights** - Provides specific recommendations for content creation

= Shortcodes =

* `[vrsc_trends limit="10" display="list"]` - Display trending keywords
* `[vrsc_scope_chart keyword="your-keyword" timeframe="30"]` - Show trend chart for specific keyword

= AI Providers Supported =

* **Google Gemini** - Primary AI analysis engine
* **OpenAI GPT** - Fallback option for comprehensive coverage

= Requirements =

* WordPress 6.8.3 or higher
* PHP 8.2 or higher
* AI API key (Gemini or OpenAI)

== Installation ==

1. Upload the plugin files to `/wp-content/plugins/vira-scope/` directory
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Go to 'Vira Scope' > 'Settings' to configure your AI API keys
4. Start analyzing trends from the dashboard

= Configuration =

1. **Get API Keys**:
   - Gemini: Visit [Google AI Studio](https://makersuite.google.com/app/apikey)
   - OpenAI: Visit [OpenAI Platform](https://platform.openai.com/api-keys)

2. **Enter API Keys**:
   - Navigate to Vira Scope > Settings
   - Enter your API key(s)
   - Save settings

3. **Start Analysis**:
   - Go to Vira Scope > Dashboard
   - Click "Analyze Site Content"
   - View results in the Trends section

== Frequently Asked Questions ==

= Do I need both Gemini and OpenAI API keys? =

No, you only need one. Gemini is the primary choice, and OpenAI serves as a fallback option.

= How often does the plugin analyze content? =

You can set the analysis frequency in settings: hourly, daily, weekly, or manual only.

= Is my data secure? =

Yes, all data is processed securely. API communications are encrypted, and sensitive data is never stored in plain text.

= Can I use this on multiple sites? =

Yes, but each site requires its own API key configuration.

= What happens to my data if I uninstall? =

All plugin data, including trends and cache, is completely removed during uninstall.

== Screenshots ==

1. Dashboard overview with trend statistics and quick actions
2. Trends page showing detailed keyword analysis
3. Settings page for AI configuration
4. Scope chart visualization for keyword trends
5. Trends shortcode display on frontend

== Changelog ==

= 1.0.0 =
* Initial release
* AI-powered trend analysis with Gemini and OpenAI
* Real-time trend scoring and visualization
* Comprehensive admin dashboard
* Public shortcodes for frontend display
* Smart caching system
* Security-first architecture
* Addon-ready framework

== Upgrade Notice ==

= 1.0.0 =
Initial release of Vira Scope. Install to start discovering trends with AI-powered analysis.

== Privacy Policy ==

Vira Scope processes content data through external AI services (Google Gemini and/or OpenAI) to provide trend analysis. This data is transmitted securely and is not stored by the AI providers beyond the processing period. No personal user data is transmitted to AI services.

== Support ==

For support, documentation, and updates, visit [Viraloka.com](https://viraloka.com/pro/vira-scope/)

== Credits ==

Developed by the Viraloka team with a focus on performance, security, and user experience.