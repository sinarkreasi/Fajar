# Vira Scope (prefix: vrsc)

**AI-Driven Real-Time Trend Intelligence Plugin for WordPress**
*Main logic file: `Fajar.php`*
*Minimum Requirements: PHP 8.2+, WordPress 6.8.3+*
*AI Providers: Gemini, OpenAI*
*Code Philosophy: No inline JS/CSS in template/view files, best performance and security, Addons-ready.*

---

## 📁 Folder Structure

```
/vira-scope/
│
├── Fajar.php                        # Main plugin bootstrap file (entry point)
├── uninstall.php                    # Cleanup script on uninstall
├── readme.txt                       # WordPress.org readme standard
│
├── /includes/
│   ├── /Controllers/
│   ├── /Models/
│   ├── /Helpers/
│   ├── /Services/
│   ├── /Database/
│   ├── /Traits/
│   └── bootstrap.php
│
├── /admin/
│   ├── /Views/
│   ├── /Assets/
│   ├── /Partials/
│   └── Admin.php
│
├── /public/
│   ├── /Views/
│   ├── /Assets/
│   └── Public.php
│
├── /Addons/
│   ├── /Pro/
│   │    └── ViraScopePro.php
│   └── index.php
│
├── /languages/
├── /config/
└── /vendor/
```

---

## ⚙️ Plugin Description

**Vira Scope** (prefix: `vrsc`) is an AI-powered trend intelligence plugin that scans topics across your WordPress site and external sources to reveal emerging trends, topic opportunities, and content gaps in real time.

### Core Features:

* 🔍 AI trend detection from site content + Google + SERP signals.
* 📈 Topic growth visualization with “Scope Chart”.
* 🧠 Gemini + OpenAI dual analysis mode.
* 🗂 Data caching for lightning-fast insights.
* 🚀 Addons-ready for Pro or enterprise features.

### Security & Performance:

* Strict namespace isolation (`ViraScope\\`)
* No inline JS/CSS in any template file.
* Sanitized all input/output via WP core functions.
* Optimized database queries via WP_Query + caching layer.

---

## 🧩 Example File: `Fajar.php`

```php

<?php
/**
 * Plugin Name: Vira Scope
 * Plugin URI:  https://viraloka.com/pro/vira-scope/
 * Description: AI-Driven Real-Time Trend Intelligence Plugin for WordPress.
 * Version:     1.0.0
 * Author:      Viraloka
 * Author URI:  https://viraloka.com
 * License:     GPL-2.0+
 * Text Domain: vira-scope
 * Domain Path: /languages
 * Requires PHP: 8.2
 * Requires at least: 6.8.3
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Define constants
if (!defined('VRSC_PATH')) {
    define('VRSC_PATH', plugin_dir_path(__FILE__));
    define('VRSC_URL', plugin_dir_url(__FILE__));
    define('VRSC_VERSION', '1.0.0');
}

// Autoload classes
require_once VRSC_PATH . 'includes/bootstrap.php';

// Register activation/deactivation hooks
register_activation_hook(__FILE__, function() {
    (new ViraScope\Database\Schema())->migrate();
});

register_deactivation_hook(__FILE__, function() {
    // Reserved for cache cleanup or deactivation tasks
});

// Initialize plugin
add_action('plugins_loaded', function() {
    if (class_exists('ViraScope\\Fajar')) {
        ViraScope\Fajar::init();
    }
});
```

---

## 🧠 Example File: `/includes/bootstrap.php`

```php

<?php
/**
 * Bootstrap loader for Vira Scope.
 * Handles autoloading, initialization, and core registration.
 */

namespace ViraScope;

if (!defined('ABSPATH')) {
    exit;
}

// PSR-4 Autoloader
spl_autoload_register(function ($class) {
    if (strpos($class, __NAMESPACE__) === false) {
        return;
    }

    $path = str_replace('\\\', '/', str_replace(__NAMESPACE__ . '\\', '', $class));
    $file = VRSC_PATH . 'includes/' . $path . '.php';

    if (file_exists($file)) {
        require_once $file;
    }
});

// Singleton main class
class Fajar {

    use Traits\Singleton;

    public static function init() {
        self::instance()->setup_hooks();
    }

    private function setup_hooks() {
        // Initialize Admin
        if (is_admin()) {
            (new Admin\Admin())->init();
        }

        // Initialize Public
        (new Public\PublicInit())->init();

        // Load text domain for translations
        add_action('init', [$this, 'load_textdomain']);
    }

    public function load_textdomain() {
        load_plugin_textdomain('vira-scope', false, dirname(plugin_basename(VRSC_PATH)) . '/languages');
    }
}
```

---

## 🧬 Example File: `/includes/Traits/Singleton.php`

```php
<?php
/**
 * Singleton Trait for Vira Scope classes.
 */

namespace ViraScope\Traits;

if (!defined('ABSPATH')) {
    exit;
}

trait Singleton {

    private static ?self $instance = null;

    final private function __construct() {}
    final private function __clone() {}

    public static function instance(): self {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
}
```

---

## 🔮 Example Future Addons (under `/Addons/Pro/`):

* **AI Trend Forecasting** — Predict next month’s hot topics.
* **Competitor Watcher** — Detect keyword overlaps.
* **Geo Trend Scope** — Region-based trend analysis.