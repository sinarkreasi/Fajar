<?php
/**
 * Admin Dashboard View for Vira Scope.
 */

if (!defined('ABSPATH')) {
    exit;
}

$trends_service = new \ViraScope\Services\TrendsService();
$min_keyword_words = get_option('vrsc_min_keyword_words', 2);
$latest_trends = $trends_service->get_latest_trends(10, $min_keyword_words);
?>

<div class="wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <div class="vrsc-dashboard">
        <div class="vrsc-stats-grid">
            <div class="vrsc-stat-card">
                <h3><?php _e('Total Trends', 'vira-scope'); ?></h3>
                <div class="vrsc-stat-number" id="vrsc-total-trends">-</div>
            </div>
            
            <div class="vrsc-stat-card">
                <h3><?php _e('Hot Keywords', 'vira-scope'); ?></h3>
                <div class="vrsc-stat-number" id="vrsc-hot-keywords">-</div>
            </div>
            
            <div class="vrsc-stat-card">
                <h3><?php _e('AI Analyses', 'vira-scope'); ?></h3>
                <div class="vrsc-stat-number" id="vrsc-ai-analyses">-</div>
            </div>
            
            <div class="vrsc-stat-card">
                <h3><?php _e('Cache Hit Rate', 'vira-scope'); ?></h3>
                <div class="vrsc-stat-number" id="vrsc-cache-rate">-</div>
            </div>
        </div>

        <div class="vrsc-dashboard-content">
            <div class="vrsc-dashboard-left">
                <div class="vrsc-card">
                    <h2><?php _e('Latest Trends', 'vira-scope'); ?></h2>
                    <div class="vrsc-trends-list">
                        <?php if (!empty($latest_trends)): ?>
                            <?php foreach ($latest_trends as $trend): ?>
                                <div class="vrsc-trend-item">
                                    <div class="vrsc-trend-keyword">
                                        <?php echo esc_html($trend->keyword); ?>
                                    </div>
                                    <div class="vrsc-trend-score" style="color: <?php echo esc_attr($trend->get_trend_score_color()); ?>">
                                        <?php echo esc_html($trend->trend_score); ?>%
                                    </div>
                                    <div class="vrsc-trend-volume">
                                        <?php echo esc_html(number_format($trend->search_volume)); ?> searches
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p><?php _e('No trends found. Start analyzing keywords to see data here.', 'vira-scope'); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="vrsc-dashboard-right">
                <div class="vrsc-card">
                    <h2><?php _e('Quick Actions', 'vira-scope'); ?></h2>
                    <div class="vrsc-quick-actions">
                        <button type="button" class="button button-primary" id="vrsc-analyze-site">
                            <?php _e('Analyze Site Content', 'vira-scope'); ?>
                        </button>
                        
                        <button type="button" class="button" id="vrsc-refresh-trends">
                            <?php _e('Refresh Trends', 'vira-scope'); ?>
                        </button>
                        
                        <button type="button" class="button" id="vrsc-clear-cache">
                            <?php _e('Clear Cache', 'vira-scope'); ?>
                        </button>
                    </div>
                </div>

                <div class="vrsc-card">
                    <h2><?php _e('Keyword Analyzer', 'vira-scope'); ?></h2>
                    <div class="vrsc-keyword-analyzer">
                        <input type="text" id="vrsc-keyword-input" placeholder="<?php esc_attr_e('Enter keyword to analyze...', 'vira-scope'); ?>" class="regular-text">
                        <button type="button" class="button button-secondary" id="vrsc-analyze-keyword">
                            <?php _e('Analyze', 'vira-scope'); ?>
                        </button>
                        <div id="vrsc-analysis-result" class="vrsc-analysis-result"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>