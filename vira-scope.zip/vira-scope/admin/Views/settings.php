<?php
/**
 * Admin Settings View for Vira Scope.
 */

if (!defined('ABSPATH')) {
    exit;
}

// Handle form submission
if (isset($_POST['vrsc_save_settings']) && wp_verify_nonce($_POST['vrsc_settings_nonce'], 'vrsc_save_settings')) {
    update_option('vrsc_ai_provider', sanitize_text_field($_POST['vrsc_ai_provider']));
    update_option('vrsc_gemini_api_key', sanitize_text_field($_POST['vrsc_gemini_api_key']));
    update_option('vrsc_gemini_model', sanitize_text_field($_POST['vrsc_gemini_model']));
    update_option('vrsc_openai_api_key', sanitize_text_field($_POST['vrsc_openai_api_key']));
    update_option('vrsc_openai_model', sanitize_text_field($_POST['vrsc_openai_model']));
    update_option('vrsc_cache_duration', intval($_POST['vrsc_cache_duration']));
    update_option('vrsc_analysis_frequency', sanitize_text_field($_POST['vrsc_analysis_frequency']));
    update_option('vrsc_max_keywords_per_batch', intval($_POST['vrsc_max_keywords_per_batch']));
    update_option('vrsc_min_keyword_words', intval($_POST['vrsc_min_keyword_words']));
    
    echo '<div class="notice notice-success"><p>' . __('Settings saved successfully!', 'vira-scope') . '</p></div>';
}

// Get current settings
$ai_provider = get_option('vrsc_ai_provider', 'gemini');
$gemini_api_key = get_option('vrsc_gemini_api_key', '');
$gemini_model = get_option('vrsc_gemini_model', 'gemini-2.5-flash');
$openai_api_key = get_option('vrsc_openai_api_key', '');
$openai_model = get_option('vrsc_openai_model', 'gpt-4o');
$cache_duration = get_option('vrsc_cache_duration', 3600);
$analysis_frequency = get_option('vrsc_analysis_frequency', 'daily');
$max_keywords_per_batch = get_option('vrsc_max_keywords_per_batch', 10);
$min_keyword_words = get_option('vrsc_min_keyword_words', 2);

// Get available models
$ai_service = new \ViraScope\Services\AIService();
$available_gemini_models = $ai_service->get_available_gemini_models();
$available_openai_models = $ai_service->get_available_openai_models();
?>

<div class="wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <form method="post" action="">
        <?php wp_nonce_field('vrsc_save_settings', 'vrsc_settings_nonce'); ?>
        
        <div class="vrsc-settings-page">
            <div class="vrsc-settings-section">
                <h2><?php _e('AI Configuration', 'vira-scope'); ?></h2>
                <p class="description">
                    <?php _e('Configure your AI service providers for trend analysis.', 'vira-scope'); ?>
                </p>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="vrsc_ai_provider"><?php _e('Primary AI Provider', 'vira-scope'); ?></label>
                        </th>
                        <td>
                            <select id="vrsc_ai_provider" name="vrsc_ai_provider" onchange="toggleAIProviderSettings()">
                                <option value="gemini" <?php selected($ai_provider, 'gemini'); ?>>
                                    <?php _e('Google Gemini', 'vira-scope'); ?>
                                </option>
                                <option value="openai" <?php selected($ai_provider, 'openai'); ?>>
                                    <?php _e('OpenAI ChatGPT', 'vira-scope'); ?>
                                </option>
                            </select>
                            <p class="description">
                                <?php _e('Choose your preferred AI provider. The other will be used as fallback.', 'vira-scope'); ?>
                            </p>
                        </td>
                    </tr>
                </table>

                <div id="gemini-settings" class="vrsc-provider-settings">
                    <h3><?php _e('Google Gemini Settings', 'vira-scope'); ?></h3>
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="vrsc_gemini_api_key"><?php _e('Gemini API Key', 'vira-scope'); ?></label>
                            </th>
                            <td>
                                <input type="password" id="vrsc_gemini_api_key" name="vrsc_gemini_api_key" 
                                       value="<?php echo esc_attr($gemini_api_key); ?>" class="regular-text">
                                <p class="description">
                                    <?php _e('Get your API key from Google AI Studio.', 'vira-scope'); ?>
                                    <a href="https://makersuite.google.com/app/apikey" target="_blank"><?php _e('Get API Key', 'vira-scope'); ?></a>
                                </p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row">
                                <label for="vrsc_gemini_model"><?php _e('Gemini Model', 'vira-scope'); ?></label>
                            </th>
                            <td>
                                <select id="vrsc_gemini_model" name="vrsc_gemini_model">
                                    <?php foreach ($available_gemini_models as $model_id => $model_name): ?>
                                        <option value="<?php echo esc_attr($model_id); ?>" <?php selected($gemini_model, $model_id); ?>>
                                            <?php echo esc_html($model_name); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <p class="description">
                                    <?php _e('Choose the Gemini 2.5 model. Flash Lite is fastest, Flash is balanced, Pro is most capable.', 'vira-scope'); ?>
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>

                <div id="openai-settings" class="vrsc-provider-settings">
                    <h3><?php _e('OpenAI ChatGPT Settings', 'vira-scope'); ?></h3>
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="vrsc_openai_api_key"><?php _e('OpenAI API Key', 'vira-scope'); ?></label>
                            </th>
                            <td>
                                <input type="password" id="vrsc_openai_api_key" name="vrsc_openai_api_key" 
                                       value="<?php echo esc_attr($openai_api_key); ?>" class="regular-text">
                                <p class="description">
                                    <?php _e('Get your API key from OpenAI Platform.', 'vira-scope'); ?>
                                    <a href="https://platform.openai.com/api-keys" target="_blank"><?php _e('Get API Key', 'vira-scope'); ?></a>
                                </p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row">
                                <label for="vrsc_openai_model"><?php _e('OpenAI Model', 'vira-scope'); ?></label>
                            </th>
                            <td>
                                <select id="vrsc_openai_model" name="vrsc_openai_model">
                                    <?php foreach ($available_openai_models as $model_id => $model_name): ?>
                                        <option value="<?php echo esc_attr($model_id); ?>" <?php selected($openai_model, $model_id); ?>>
                                            <?php echo esc_html($model_name); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <p class="description">
                                    <?php _e('Choose the OpenAI model. GPT-4o is recommended, o1 series for advanced reasoning, mini versions for cost efficiency.', 'vira-scope'); ?>
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>

                <script>
                function toggleAIProviderSettings() {
                    const provider = document.getElementById('vrsc_ai_provider').value;
                    const geminiSettings = document.getElementById('gemini-settings');
                    const openaiSettings = document.getElementById('openai-settings');
                    
                    if (provider === 'gemini') {
                        geminiSettings.style.display = 'block';
                        openaiSettings.style.display = 'none';
                    } else {
                        geminiSettings.style.display = 'none';
                        openaiSettings.style.display = 'block';
                    }
                }
                
                // Initialize on page load
                document.addEventListener('DOMContentLoaded', function() {
                    toggleAIProviderSettings();
                });
                </script>

                <style>
                .vrsc-provider-settings {
                    margin: 20px 0;
                    padding: 15px;
                    border: 1px solid #ddd;
                    border-radius: 4px;
                    background: #f9f9f9;
                }
                .vrsc-provider-settings h3 {
                    margin-top: 0;
                    color: #23282d;
                }
                </style>
            </div>

            <div class="vrsc-settings-section">
                <h2><?php _e('Performance Settings', 'vira-scope'); ?></h2>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="vrsc_cache_duration"><?php _e('Cache Duration (seconds)', 'vira-scope'); ?></label>
                        </th>
                        <td>
                            <input type="number" id="vrsc_cache_duration" name="vrsc_cache_duration" 
                                   value="<?php echo esc_attr($cache_duration); ?>" min="300" max="86400" class="small-text">
                            <p class="description">
                                <?php _e('How long to cache AI analysis results. Default: 3600 (1 hour).', 'vira-scope'); ?>
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="vrsc_max_keywords_per_batch"><?php _e('Max Keywords per Batch', 'vira-scope'); ?></label>
                        </th>
                        <td>
                            <input type="number" id="vrsc_max_keywords_per_batch" name="vrsc_max_keywords_per_batch" 
                                   value="<?php echo esc_attr($max_keywords_per_batch); ?>" min="1" max="50" class="small-text">
                            <p class="description">
                                <?php _e('Maximum number of keywords to analyze in one batch operation.', 'vira-scope'); ?>
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="vrsc_min_keyword_words"><?php _e('Minimum Keyword Length', 'vira-scope'); ?></label>
                        </th>
                        <td>
                            <select id="vrsc_min_keyword_words" name="vrsc_min_keyword_words">
                                <option value="1" <?php selected($min_keyword_words, 1); ?>><?php _e('1 word (single keywords)', 'vira-scope'); ?></option>
                                <option value="2" <?php selected($min_keyword_words, 2); ?>><?php _e('2 words (phrases)', 'vira-scope'); ?></option>
                                <option value="3" <?php selected($min_keyword_words, 3); ?>><?php _e('3 words (long-tail)', 'vira-scope'); ?></option>
                                <option value="4" <?php selected($min_keyword_words, 4); ?>><?php _e('4 words (very specific)', 'vira-scope'); ?></option>
                                <option value="5" <?php selected($min_keyword_words, 5); ?>><?php _e('5+ words (ultra-specific)', 'vira-scope'); ?></option>
                            </select>
                            <p class="description">
                                <?php _e('Filter trends display to show only keywords with minimum number of words. Longer phrases are often more valuable for SEO.', 'vira-scope'); ?>
                            </p>
                        </td>
                    </tr>
                </table>
            </div>

            <div class="vrsc-settings-section">
                <h2><?php _e('Analysis Settings', 'vira-scope'); ?></h2>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="vrsc_analysis_frequency"><?php _e('Auto Analysis Frequency', 'vira-scope'); ?></label>
                        </th>
                        <td>
                            <select id="vrsc_analysis_frequency" name="vrsc_analysis_frequency">
                                <option value="hourly" <?php selected($analysis_frequency, 'hourly'); ?>><?php _e('Hourly', 'vira-scope'); ?></option>
                                <option value="daily" <?php selected($analysis_frequency, 'daily'); ?>><?php _e('Daily', 'vira-scope'); ?></option>
                                <option value="weekly" <?php selected($analysis_frequency, 'weekly'); ?>><?php _e('Weekly', 'vira-scope'); ?></option>
                                <option value="manual" <?php selected($analysis_frequency, 'manual'); ?>><?php _e('Manual Only', 'vira-scope'); ?></option>
                            </select>
                            <p class="description">
                                <?php _e('How often to automatically analyze site content for new trends.', 'vira-scope'); ?>
                            </p>
                        </td>
                    </tr>
                </table>
            </div>

            <div class="vrsc-settings-section">
                <h2><?php _e('System Information', 'vira-scope'); ?></h2>
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php _e('Plugin Version', 'vira-scope'); ?></th>
                        <td><?php echo esc_html(VRSC_VERSION); ?></td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><?php _e('Database Version', 'vira-scope'); ?></th>
                        <td><?php echo esc_html(get_option('vrsc_db_version', 'Not installed')); ?></td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><?php _e('Cache Type', 'vira-scope'); ?></th>
                        <td><?php echo wp_using_ext_object_cache() ? __('Object Cache', 'vira-scope') : __('Database Cache', 'vira-scope'); ?></td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><?php _e('Total Trends', 'vira-scope'); ?></th>
                        <td id="vrsc-total-trends-count">-</td>
                    </tr>
                </table>
            </div>

            <div class="vrsc-settings-actions">
                <p class="submit">
                    <input type="submit" name="vrsc_save_settings" class="button-primary" 
                           value="<?php esc_attr_e('Save Settings', 'vira-scope'); ?>">
                    
                    <button type="button" class="button" id="vrsc-test-ai-connection">
                        <?php _e('Test AI Connection', 'vira-scope'); ?>
                    </button>
                    
                    <button type="button" class="button" id="vrsc-clear-all-cache">
                        <?php _e('Clear All Cache', 'vira-scope'); ?>
                    </button>
                </p>
            </div>
        </div>
    </form>
</div>