<?php
/**
 * Admin Trends View for Vira Scope.
 */

if (!defined('ABSPATH')) {
    exit;
}

$trends_service = new \ViraScope\Services\TrendsService();
$min_keyword_words = get_option('vrsc_min_keyword_words', 2);
$trends = $trends_service->get_latest_trends(50, $min_keyword_words);
?>

<div class="wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <div class="vrsc-trends-page">
        <div class="vrsc-trends-filters">
            <div class="vrsc-filter-group">
                <label for="vrsc-filter-keyword"><?php _e('Search Keywords:', 'vira-scope'); ?></label>
                <input type="text" id="vrsc-filter-keyword" class="regular-text" placeholder="<?php esc_attr_e('Filter by keyword...', 'vira-scope'); ?>">
            </div>
            
            <div class="vrsc-filter-group">
                <label for="vrsc-filter-score"><?php _e('Min Trend Score:', 'vira-scope'); ?></label>
                <input type="number" id="vrsc-filter-score" min="0" max="100" value="0" class="small-text">
            </div>
            
            <div class="vrsc-filter-group">
                <label for="vrsc-filter-competition"><?php _e('Competition Level:', 'vira-scope'); ?></label>
                <select id="vrsc-filter-competition">
                    <option value=""><?php _e('All Levels', 'vira-scope'); ?></option>
                    <option value="low"><?php _e('Low', 'vira-scope'); ?></option>
                    <option value="medium"><?php _e('Medium', 'vira-scope'); ?></option>
                    <option value="high"><?php _e('High', 'vira-scope'); ?></option>
                </select>
            </div>
            
            <div class="vrsc-filter-group">
                <label for="vrsc-filter-words"><?php _e('Min Words:', 'vira-scope'); ?></label>
                <select id="vrsc-filter-words">
                    <option value="0"><?php _e('Any Length', 'vira-scope'); ?></option>
                    <option value="1"><?php _e('1+ words', 'vira-scope'); ?></option>
                    <option value="2" <?php selected($min_keyword_words, 2); ?>><?php _e('2+ words', 'vira-scope'); ?></option>
                    <option value="3" <?php selected($min_keyword_words, 3); ?>><?php _e('3+ words', 'vira-scope'); ?></option>
                    <option value="4" <?php selected($min_keyword_words, 4); ?>><?php _e('4+ words', 'vira-scope'); ?></option>
                    <option value="5" <?php selected($min_keyword_words, 5); ?>><?php _e('5+ words', 'vira-scope'); ?></option>
                </select>
            </div>
            
            <div class="vrsc-filter-actions">
                <button type="button" class="button" id="vrsc-apply-filters">
                    <?php _e('Apply Filters', 'vira-scope'); ?>
                </button>
                
                <button type="button" class="button" id="vrsc-reset-filters">
                    <?php _e('Reset', 'vira-scope'); ?>
                </button>
                
                <button type="button" class="button button-primary" id="vrsc-refresh-trends-page">
                    <?php _e('Refresh Data', 'vira-scope'); ?>
                </button>
            </div>
        </div>

        <div class="vrsc-trends-table-container">
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th scope="col" class="manage-column column-keyword">
                            <?php _e('Keyword', 'vira-scope'); ?>
                        </th>
                        <th scope="col" class="manage-column column-trend-score">
                            <?php _e('Trend Score', 'vira-scope'); ?>
                        </th>
                        <th scope="col" class="manage-column column-search-volume">
                            <?php _e('Search Volume', 'vira-scope'); ?>
                        </th>
                        <th scope="col" class="manage-column column-competition">
                            <?php _e('Competition', 'vira-scope'); ?>
                        </th>
                        <th scope="col" class="manage-column column-source">
                            <?php _e('Source', 'vira-scope'); ?>
                        </th>
                        <th scope="col" class="manage-column column-date">
                            <?php _e('Date', 'vira-scope'); ?>
                        </th>
                        <th scope="col" class="manage-column column-actions">
                            <?php _e('Actions', 'vira-scope'); ?>
                        </th>
                    </tr>
                </thead>
                <tbody id="vrsc-trends-tbody">
                    <?php if (!empty($trends)): ?>
                        <?php foreach ($trends as $trend): ?>
                            <tr data-keyword="<?php echo esc_attr($trend->keyword); ?>" 
                                data-score="<?php echo esc_attr($trend->trend_score); ?>" 
                                data-competition="<?php echo esc_attr($trend->competition_level); ?>">
                                <td class="column-keyword">
                                    <strong><?php echo esc_html($trend->keyword); ?></strong>
                                </td>
                                <td class="column-trend-score">
                                    <span class="vrsc-trend-score-badge" style="background-color: <?php echo esc_attr($trend->get_trend_score_color()); ?>">
                                        <?php echo esc_html($trend->trend_score); ?>%
                                    </span>
                                </td>
                                <td class="column-search-volume">
                                    <?php echo esc_html(number_format($trend->search_volume)); ?>
                                </td>
                                <td class="column-competition">
                                    <span class="vrsc-competition-badge" style="color: <?php echo esc_attr($trend->get_competition_color()); ?>">
                                        <?php echo esc_html(ucfirst($trend->competition_level)); ?>
                                    </span>
                                </td>
                                <td class="column-source">
                                    <?php echo esc_html(ucfirst($trend->source)); ?>
                                </td>
                                <td class="column-date">
                                    <?php echo esc_html(date_i18n(get_option('date_format'), strtotime($trend->created_at))); ?>
                                </td>
                                <td class="column-actions">
                                    <button type="button" class="button button-small vrsc-view-analysis" 
                                            data-keyword="<?php echo esc_attr($trend->keyword); ?>">
                                        <?php _e('View Analysis', 'vira-scope'); ?>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" class="vrsc-no-trends">
                                <?php _e('No trends found. Start analyzing keywords to see data here.', 'vira-scope'); ?>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Analysis Modal -->
<div id="vrsc-analysis-modal" class="vrsc-modal" style="display: none;">
    <div class="vrsc-modal-content">
        <div class="vrsc-modal-header">
            <h2 id="vrsc-modal-title"><?php _e('Keyword Analysis', 'vira-scope'); ?></h2>
            <span class="vrsc-modal-close">&times;</span>
        </div>
        <div class="vrsc-modal-body" id="vrsc-modal-body">
            <!-- Analysis content will be loaded here -->
        </div>
    </div>
</div>