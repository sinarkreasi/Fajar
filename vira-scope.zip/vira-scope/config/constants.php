<?php
/**
 * Configuration constants for Vira Scope
 */

if (!defined('ABSPATH')) {
    exit;
}

// API Configuration
define('VRSC_GEMINI_API_URL', 'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent');
define('VRSC_OPENAI_API_URL', 'https://api.openai.com/v1/chat/completions');

// Cache Configuration
define('VRSC_DEFAULT_CACHE_DURATION', 3600); // 1 hour
define('VRSC_MAX_CACHE_DURATION', 86400); // 24 hours
define('VRSC_MIN_CACHE_DURATION', 300); // 5 minutes

// Analysis Configuration
define('VRSC_MAX_KEYWORDS_PER_BATCH', 50);
define('VRSC_DEFAULT_KEYWORDS_PER_BATCH', 10);
define('VRSC_API_RATE_LIMIT_DELAY', 500000); // 0.5 seconds in microseconds

// Trend Scoring
define('VRSC_MIN_TREND_SCORE', 0);
define('VRSC_MAX_TREND_SCORE', 100);
define('VRSC_HIGH_TREND_THRESHOLD', 80);
define('VRSC_MEDIUM_TREND_THRESHOLD', 40);

// Database Configuration
define('VRSC_TRENDS_TABLE', 'vrsc_trends');
define('VRSC_CACHE_TABLE', 'vrsc_cache');

// Security
define('VRSC_NONCE_ACTION', 'vrsc_nonce');
define('VRSC_CAPABILITY_REQUIRED', 'manage_options');

// File Paths
define('VRSC_ADMIN_ASSETS_URL', VRSC_URL . 'admin/Assets/');
define('VRSC_PUBLIC_ASSETS_URL', VRSC_URL . 'public/Assets/');
define('VRSC_ADDONS_PATH', VRSC_PATH . 'Addons/');

// Feature Flags
define('VRSC_ENABLE_CRON', true);
define('VRSC_ENABLE_DEBUG_LOGGING', defined('WP_DEBUG') && WP_DEBUG);
define('VRSC_ENABLE_CACHE_CLEANUP', true);

// Cron Schedules
define('VRSC_CRON_ANALYZE_CONTENT', 'vrsc_analyze_content');
define('VRSC_CRON_CLEANUP_CACHE', 'vrsc_cleanup_cache');

// Default Settings
define('VRSC_DEFAULT_ANALYSIS_FREQUENCY', 'daily');
define('VRSC_DEFAULT_DISPLAY_LIMIT', 20);
define('VRSC_DEFAULT_CHART_TIMEFRAME', 30);

// API Limits
define('VRSC_GEMINI_MAX_TOKENS', 1000);
define('VRSC_OPENAI_MAX_TOKENS', 500);
define('VRSC_API_TIMEOUT', 30);

// Content Analysis
define('VRSC_MIN_KEYWORD_LENGTH', 3);
define('VRSC_MAX_KEYWORD_LENGTH', 50);
define('VRSC_MAX_CONTENT_ANALYSIS_POSTS', 100);

// Pro Features (for addon compatibility)
define('VRSC_PRO_AVAILABLE', class_exists('ViraScope\\Addons\\Pro\\ViraScopePro'));
define('VRSC_PRO_LICENSE_OPTION', 'vrsc_pro_license_key');

// Error Codes
define('VRSC_ERROR_API_KEY_MISSING', 'api_key_missing');
define('VRSC_ERROR_API_REQUEST_FAILED', 'api_request_failed');
define('VRSC_ERROR_INVALID_RESPONSE', 'invalid_response');
define('VRSC_ERROR_RATE_LIMIT_EXCEEDED', 'rate_limit_exceeded');
define('VRSC_ERROR_INSUFFICIENT_PERMISSIONS', 'insufficient_permissions');