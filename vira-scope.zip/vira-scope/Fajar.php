<?php
/**
 * Plugin Name: Vira Scope
 * Plugin URI:  https://viraloka.com/pro/vira-scope/
 * Description: AI-Driven Real-Time Trend Intelligence Plugin for WordPress.
 * Version:     1.0.0
 * Author:      Viraloka
 * Author URI:  https://viraloka.com
 * License:     GPL-2.0+
 * Text Domain: vira-scope
 * Domain Path: /languages
 * Requires PHP: 8.2
 * Requires at least: 6.8.3
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Define constants
if (!defined('VRSC_PATH')) {
    define('VRSC_PATH', plugin_dir_path(__FILE__));
    define('VRSC_URL', plugin_dir_url(__FILE__));
    define('VRSC_VERSION', '1.0.0');
}

// Autoload classes
require_once VRSC_PATH . 'includes/bootstrap.php';

// Register activation/deactivation hooks
register_activation_hook(__FILE__, function() {
    (new ViraScope\Database\Schema())->migrate();
});

register_deactivation_hook(__FILE__, function() {
    // Reserved for cache cleanup or deactivation tasks
});

// Initialize plugin
add_action('plugins_loaded', function() {
    if (class_exists('ViraScope\\Fajar')) {
        ViraScope\Fajar::init();
    }
});