/**
 * CFR2 Admin JavaScript
 */

(function($) {
    'use strict';

    var CFR2Admin = {
        
        init: function() {
            this.bindEvents();
        },
        
        bindEvents: function() {
            // Test connection button
            $('#cfr2-test-connection').on('click', this.testConnection);
            
            // Upload form
            $('#cfr2-upload-form').on('submit', this.uploadFile);
            
            // Delete file buttons
            $(document).on('click', '.cfr2-delete-file', this.deleteFile);
            
            // Sync files button
            $('#cfr2-sync-files').on('click', this.syncFiles);
            
            // Dismiss notice
            $(document).on('click', '.cfr2-dismiss-notice', this.dismissNotice);
        },
        
        testConnection: function(e) {
            e.preventDefault();
            
            var $button = $(this);
            var $status = $('#cfr2-connection-status');
            var originalText = $button.text();
            
            $button.prop('disabled', true).text(cfr2_ajax.strings.testing);
            $status.addClass('testing');
            
            $.ajax({
                url: cfr2_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'cfr2_test_connection',
                    nonce: cfr2_ajax.nonce
                },
                success: function(response) {
                    if (response.success) {
                        CFR2Admin.showNotice('success', response.data.message);
                        $status.removeClass('not-configured').addClass('configured')
                               .find('.status-indicator').html('<span class="dashicons dashicons-yes-alt"></span> R2 Configured');
                    } else {
                        CFR2Admin.showNotice('error', response.data.message + (response.data.details ? '<br><small>' + response.data.details + '</small>' : ''));
                    }
                },
                error: function() {
                    CFR2Admin.showNotice('error', cfr2_ajax.strings.connection_failed);
                },
                complete: function() {
                    $button.prop('disabled', false).text(originalText);
                    $status.removeClass('testing');
                }
            });
        },
        
        uploadFile: function(e) {
            e.preventDefault();
            
            var $form = $(this);
            var $button = $form.find('button[type="submit"]');
            var $progress = $('.cfr2-upload-progress');
            var $progressBar = $('.cfr2-progress-bar');
            var originalText = $button.text();
            
            // Validate form
            var pluginId = $('#cfr2_plugin_id').val();
            var version = $('#cfr2_version').val();
            var file = $('#cfr2_file_input')[0].files[0];
            
            if (!pluginId || !version || !file) {
                CFR2Admin.showNotice('error', 'Please fill in all required fields.');
                return;
            }
            
            // Prepare form data
            var formData = new FormData();
            formData.append('action', 'cfr2_upload_file');
            formData.append('nonce', cfr2_ajax.nonce);
            formData.append('plugin_id', pluginId);
            formData.append('version', version);
            formData.append('plugin_file', file);
            
            $button.prop('disabled', true).text(cfr2_ajax.strings.uploading);
            $progress.removeClass('cfr2-hidden');
            $progressBar.css('width', '0%');
            
            $.ajax({
                url: cfr2_ajax.ajax_url,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                xhr: function() {
                    var xhr = new window.XMLHttpRequest();
                    xhr.upload.addEventListener('progress', function(e) {
                        if (e.lengthComputable) {
                            var percentComplete = (e.loaded / e.total) * 100;
                            $progressBar.css('width', percentComplete + '%');
                        }
                    }, false);
                    return xhr;
                },
                success: function(response) {
                    if (response.success) {
                        CFR2Admin.showNotice('success', response.data.message);
                        $form[0].reset();
                        CFR2Admin.refreshFilesList();
                    } else {
                        CFR2Admin.showNotice('error', response.data);
                    }
                },
                error: function() {
                    CFR2Admin.showNotice('error', cfr2_ajax.strings.upload_failed);
                },
                complete: function() {
                    $button.prop('disabled', false).text(originalText);
                    $progress.addClass('cfr2-hidden');
                    $progressBar.css('width', '0%');
                }
            });
        },
        
        deleteFile: function(e) {
            e.preventDefault();
            
            if (!confirm(cfr2_ajax.strings.confirm_delete)) {
                return;
            }
            
            var $button = $(this);
            var fileId = $button.data('file-id');
            var originalText = $button.text();
            
            $button.prop('disabled', true).text(cfr2_ajax.strings.deleting);
            
            $.ajax({
                url: cfr2_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'cfr2_delete_file',
                    nonce: cfr2_ajax.nonce,
                    file_id: fileId
                },
                success: function(response) {
                    if (response.success) {
                        CFR2Admin.showNotice('success', response.data);
                        $button.closest('tr').fadeOut(300, function() {
                            $(this).remove();
                        });
                    } else {
                        CFR2Admin.showNotice('error', response.data);
                        $button.prop('disabled', false).text(originalText);
                    }
                },
                error: function() {
                    CFR2Admin.showNotice('error', cfr2_ajax.strings.delete_failed);
                    $button.prop('disabled', false).text(originalText);
                }
            });
        },
        
        syncFiles: function(e) {
            e.preventDefault();
            
            var $button = $(this);
            var originalText = $button.text();
            
            $button.prop('disabled', true).text(cfr2_ajax.strings.syncing);
            
            $.ajax({
                url: cfr2_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'cfr2_sync_files',
                    nonce: cfr2_ajax.nonce
                },
                success: function(response) {
                    if (response.success) {
                        CFR2Admin.showNotice('success', response.data.message);
                        if (response.data.files_html) {
                            $('#cfr2-files-list').html(response.data.files_html);
                        }
                    } else {
                        CFR2Admin.showNotice('error', response.data);
                    }
                },
                error: function() {
                    CFR2Admin.showNotice('error', cfr2_ajax.strings.sync_failed);
                },
                complete: function() {
                    $button.prop('disabled', false).text(originalText);
                }
            });
        },
        
        dismissNotice: function(e) {
            e.preventDefault();
            
            var $button = $(this);
            var noticeType = $button.data('notice-type');
            
            $.ajax({
                url: cfr2_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'cfr2_dismiss_notice',
                    nonce: cfr2_ajax.nonce,
                    notice_type: noticeType
                },
                success: function(response) {
                    if (response.success) {
                        $button.closest('.notice').fadeOut();
                    }
                }
            });
        },
        
        refreshFilesList: function() {
            var $filesList = $('#cfr2-files-list');
            
            $filesList.addClass('cfr2-loading');
            
            $.ajax({
                url: cfr2_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'cfr2_refresh_files',
                    nonce: cfr2_ajax.nonce
                },
                success: function(response) {
                    if (response.success && response.data.html) {
                        $filesList.html(response.data.html);
                    }
                },
                complete: function() {
                    $filesList.removeClass('cfr2-loading');
                }
            });
        },
        
        showNotice: function(type, message) {
            var $notice = $('<div class="notice notice-' + type + ' is-dismissible cfr2-notice ' + type + '"><p>' + message + '</p></div>');
            
            // Remove existing notices
            $('.cfr2-notice').remove();
            
            // Add new notice
            $('.cfr2-storage-container').prepend($notice);
            
            // Auto-dismiss success notices
            if (type === 'success') {
                setTimeout(function() {
                    $notice.fadeOut();
                }, 5000);
            }
            
            // Scroll to top
            $('html, body').animate({
                scrollTop: $('.cfr2-storage-container').offset().top - 50
            }, 300);
        }
    };
    
    // Initialize when document is ready
    $(document).ready(function() {
        CFR2Admin.init();
    });
    
})(jQuery);