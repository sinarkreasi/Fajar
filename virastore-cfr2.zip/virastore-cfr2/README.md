# Vira Store - Cloudflare R2 Integration

This addon integrates Cloudflare R2 storage with the Vira Store plugin versioning system, allowing you to store and serve plugin update files via Cloudflare's global network for faster downloads.

## Features

- **Cloudflare R2 Integration**: Store plugin files on Cloudflare R2 for global distribution
- **Automatic File Management**: Upload, delete, and sync files between your WordPress site and R2
- **Private Bucket Support**: Use signed URLs for secure file access
- **Custom Domain Support**: Serve files from your own domain
- **Download Tracking**: Monitor file downloads and usage statistics
- **API Integration**: Seamlessly integrates with Vira Store's plugin update API

## Requirements

- WordPress 5.0 or higher
- PHP 7.4 or higher
- Vira Store plugin (active)
- Cloudflare R2 account

## Installation

1. Upload the plugin files to `/wp-content/plugins/virastore-cfr2/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to Vira Store > Cloudflare R2 to configure your R2 settings

## Configuration

### R2 Setup

1. Create a Cloudflare R2 bucket
2. Generate R2 API tokens with read/write permissions
3. Note your account ID and endpoint URL

### Plugin Configuration

1. Navigate to **Vira Store > Cloudflare R2**
2. Enter your R2 credentials:
   - **R2 Endpoint**: Your account-specific R2 endpoint
   - **Access Key ID**: Your R2 access key
   - **Secret Access Key**: Your R2 secret key
   - **Bucket Name**: The name of your R2 bucket
   - **Custom Domain** (optional): Your custom domain for serving files
   - **Private Bucket**: Enable for signed URL access

3. Click **Test Connection** to verify your settings
4. Click **Save Configuration**

## Usage

### Uploading Files

1. Go to the **Upload Plugin File** section
2. Select a plugin product from the dropdown
3. Enter the version number
4. Choose the ZIP file to upload
5. Click **Upload to R2**

### Managing Files

- View all uploaded files in the **Uploaded Files** section
- Delete files directly from the interface
- Use **Sync Files** to synchronize between database and R2

### API Integration

The plugin automatically integrates with Vira Store's update API:
- Plugin update checks will serve files from R2
- Download URLs are automatically replaced with R2 URLs
- Supports both public and private bucket configurations

## Troubleshooting

### Connection Issues

If you're getting connection errors:

1. Verify your R2 credentials are correct
2. Check that your bucket exists and is accessible
3. Ensure your R2 API tokens have the correct permissions
4. Try using the **Test Connection** button

### Database Issues

If you see database table errors:
1. Deactivate and reactivate the plugin to recreate tables
2. Check that Vira Store is properly installed and activated

### File Upload Issues

- Ensure your PHP upload limits are sufficient for your file sizes
- Check that your R2 bucket has enough storage space
- Verify file permissions and temporary directory access

## Support

For support and documentation, visit [Viraloka.com](https://viraloka.com)

## Changelog

### 1.0.0
- Initial release
- Cloudflare R2 integration
- File upload and management
- API integration with Vira Store
- Download tracking and statistics