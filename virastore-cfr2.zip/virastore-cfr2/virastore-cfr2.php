<?php
/**
 * Plugin Name: Vira Store - Cloudflare R2
 * Plugin URI: https://viraloka.com/vira-store/addons/cfr2
 * Description: Cloudflare R2 integration addon for Vira Store plugin versioning system. Store and serve plugin update files via Cloudflare R2.
 * Version: 1.0.0
 * Author: Viraloka
 * Author URI: https://viraloka.com
 * Text Domain: virastore-cfr2
 * Domain Path: /languages
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('VIRASTORE_CFR2_VERSION', '1.0.0');
define('VIRASTORE_CFR2_PLUGIN_FILE', __FILE__);
define('VIRASTORE_CFR2_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('VIRASTORE_CFR2_PLUGIN_URL', plugin_dir_url(__FILE__));
define('VIRASTORE_CFR2_PLUGIN_BASENAME', plugin_basename(__FILE__));
define('VIRASTORE_CFR2_PATH', plugin_dir_path(__FILE__));
define('VIRASTORE_CFR2_URL', plugin_dir_url(__FILE__));


/**
 * Main CFR2 Plugin Class
 */
class ViraStore_CFR2 {
    
    /**
     * Single instance of the class
     */
    private static $instance = null;
    
    /**
     * Get single instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        add_action('plugins_loaded', array($this, 'init'));
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
    }
    
    /**
     * Initialize the plugin
     */
    public function init() {
        // Check if Vira Store is active
        if (!$this->is_vira_store_active()) {
            add_action('admin_notices', array($this, 'vira_store_missing_notice'));
            return;
        }
        
        // Load text domain
        load_plugin_textdomain('virastore-cfr2', false, dirname(plugin_basename(__FILE__)) . '/languages');
        
        // Include required files
        $this->includes();
        
        // Initialize components
        $this->init_components();
    }
    
    /**
     * Check if Vira Store plugin is active
     */
    private function is_vira_store_active() {
        return class_exists('Vira_Store') || function_exists('vira_store_init') || defined('VRSTORE_VERSION');
    }
    
    /**
     * Show notice if Vira Store is not active
     */
    public function vira_store_missing_notice() {
        ?>
        <div class="notice notice-error">
            <p><?php esc_html_e('Vira Store CFR2 requires the Vira Store plugin to be installed and activated.', 'virastore-cfr2'); ?></p>
        </div>
        <?php
    }
    
    /**
     * Include required files
     */
    private function includes() {
        require_once VIRASTORE_CFR2_PLUGIN_DIR . 'includes/class-r2-client.php';
        require_once VIRASTORE_CFR2_PLUGIN_DIR . 'includes/class-admin.php';
        require_once VIRASTORE_CFR2_PLUGIN_DIR . 'includes/class-api-integration.php';
        require_once VIRASTORE_CFR2_PLUGIN_DIR . 'includes/class-file-manager.php';
    }
    
    /**
     * Initialize components
     */
    private function init_components() {
        // Initialize admin interface - always initialize to ensure hooks are registered
        ViraStore_CFR2_Admin::get_instance();
        
        // Initialize API integration
        ViraStore_CFR2_API_Integration::get_instance();
        
        // Initialize file manager
        ViraStore_CFR2_File_Manager::get_instance();
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        // Create database tables if needed
        $this->create_tables();
        
        // Set default options
        $this->set_default_options();
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // Clean up temporary files
        $this->cleanup_temp_files();
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Create database tables
     */
    private function create_tables() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'virastore_cfr2_files';
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            plugin_id mediumint(9) NOT NULL,
            version varchar(20) NOT NULL,
            file_name varchar(255) NOT NULL,
            r2_key varchar(500) NOT NULL,
            r2_url varchar(1000) NOT NULL,
            file_size bigint(20) DEFAULT 0,
            upload_date datetime DEFAULT CURRENT_TIMESTAMP,
            is_private tinyint(1) DEFAULT 0,
            PRIMARY KEY (id),
            KEY plugin_version (plugin_id, version)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
    
    /**
     * Set default options
     */
    private function set_default_options() {
        $defaults = array(
            'virastore_cfr2_account_id' => '',
            'virastore_cfr2_access_key_id' => '',
            'virastore_cfr2_secret_access_key' => '',
            'virastore_cfr2_bucket_name' => '',
            'virastore_cfr2_custom_domain' => '',
            'virastore_cfr2_use_private_bucket' => '0',
            'virastore_cfr2_signed_url_expiry' => '3600', // 1 hour
        );
        
        foreach ($defaults as $option => $value) {
            if (get_option($option) === false) {
                add_option($option, $value);
            }
        }
    }
    
    /**
     * Clean up temporary files
     */
    private function cleanup_temp_files() {
        $upload_dir = wp_upload_dir();
        $temp_dir = $upload_dir['basedir'] . '/virastore-cfr2-temp/';
        
        if (is_dir($temp_dir)) {
            $files = glob($temp_dir . '*');
            foreach ($files as $file) {
                if (is_file($file)) {
                    unlink($file);
                }
            }
            rmdir($temp_dir);
        }
    }
}

// Initialize the plugin
ViraStore_CFR2::get_instance();