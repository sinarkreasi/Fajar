<?php
/**
 * CFR2 Storage Page Template
 * 
 * Admin page template for Cloudflare R2 storage configuration and management
 *
 * @package ViraStore_CFR2
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Get current settings
$account_id = get_option('virastore_cfr2_account_id', '');
$r2_endpoint = $account_id ? "https://{$account_id}.r2.cloudflarestorage.com" : '';
$r2_access_key = get_option('virastore_cfr2_access_key_id', '');
$r2_secret_key = get_option('virastore_cfr2_secret_access_key', '');
$r2_bucket = get_option('virastore_cfr2_bucket_name', '');
$r2_region = get_option('virastore_cfr2_region', 'auto');
$use_private_bucket = get_option('virastore_cfr2_use_private_bucket', '0');
$custom_domain = get_option('virastore_cfr2_custom_domain', '');

// Check if R2 is configured
$r2_client = new ViraStore_CFR2_Client();
$is_configured = $r2_client->is_configured();

// Get file manager for stats
$file_manager = ViraStore_CFR2_File_Manager::get_instance();
$stats = $file_manager->get_storage_stats();
$plugin_products = get_posts(array(
    'post_type' => 'vrstore_product',
    'post_status' => array('publish', 'draft', 'pending', 'private'),
    'posts_per_page' => -1,
    'orderby' => 'title',
    'order' => 'ASC',
));
?>

<div class="cfr2-storage-container">
    <div class="cfr2-header">
        <p class="description">
            <?php esc_html_e('Configure Cloudflare R2 as external storage for plugin update files. Files uploaded to R2 will be served directly from Cloudflare\'s global network for faster downloads.', 'virastore-cfr2'); ?>
        </p>
    </div>

    <!-- Configuration Section -->
    <div class="cfr2-section cfr2-config-section">
        <h3><?php esc_html_e('R2 Configuration', 'virastore-cfr2'); ?></h3>
        
        <div class="cfr2-config-status">
            <div id="cfr2-connection-status" class="cfr2-status">
                <span class="status-indicator <?php echo $is_configured ? 'configured' : 'not-configured'; ?>">
                    <?php if ($is_configured): ?>
                        <span class="dashicons dashicons-yes-alt"></span>
                        <?php esc_html_e('R2 Configured', 'virastore-cfr2'); ?>
                    <?php else: ?>
                        <span class="dashicons dashicons-warning"></span>
                        <?php esc_html_e('R2 Not Configured', 'virastore-cfr2'); ?>
                    <?php endif; ?>
                </span>
            </div>
        </div>

        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="cfr2-config-form">
            <?php wp_nonce_field('cfr2_save_config', 'cfr2_config_nonce'); ?>
            <input type="hidden" name="action" value="cfr2_save_config">

            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="cfr2_endpoint"><?php esc_html_e('R2 Endpoint', 'virastore-cfr2'); ?></label>
                    </th>
                    <td>
                        <input type="url" id="cfr2_endpoint" name="cfr2_endpoint" 
                               value="<?php echo esc_attr($r2_endpoint); ?>" 
                               class="regular-text" placeholder="https://your-account-id.r2.cloudflarestorage.com" required>
                        <p class="description">
                            <?php esc_html_e('Your Cloudflare R2 endpoint URL (found in your R2 dashboard)', 'virastore-cfr2'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="cfr2_access_key"><?php esc_html_e('Access Key ID', 'virastore-cfr2'); ?></label>
                    </th>
                    <td>
                        <input type="text" id="cfr2_access_key" name="cfr2_access_key" 
                               value="<?php echo esc_attr($r2_access_key); ?>" 
                               class="regular-text" required>
                        <p class="description">
                            <?php esc_html_e('Your R2 Access Key ID', 'virastore-cfr2'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="cfr2_secret_key"><?php esc_html_e('Secret Access Key', 'virastore-cfr2'); ?></label>
                    </th>
                    <td>
                        <input type="password" id="cfr2_secret_key" name="cfr2_secret_key" 
                               value="<?php echo esc_attr($r2_secret_key); ?>" 
                               class="regular-text" required>
                        <p class="description">
                            <?php esc_html_e('Your R2 Secret Access Key', 'virastore-cfr2'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="cfr2_bucket"><?php esc_html_e('Bucket Name', 'virastore-cfr2'); ?></label>
                    </th>
                    <td>
                        <input type="text" id="cfr2_bucket" name="cfr2_bucket" 
                               value="<?php echo esc_attr($r2_bucket); ?>" 
                               class="regular-text" required>
                        <p class="description">
                            <?php esc_html_e('The name of your R2 bucket', 'virastore-cfr2'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="cfr2_region"><?php esc_html_e('Region', 'virastore-cfr2'); ?></label>
                    </th>
                    <td>
                        <select id="cfr2_region" name="cfr2_region">
                            <option value="auto" <?php selected($r2_region, 'auto'); ?>><?php esc_html_e('Auto', 'virastore-cfr2'); ?></option>
                            <option value="us-east-1" <?php selected($r2_region, 'us-east-1'); ?>><?php esc_html_e('US East 1', 'virastore-cfr2'); ?></option>
                            <option value="eu-west-1" <?php selected($r2_region, 'eu-west-1'); ?>><?php esc_html_e('EU West 1', 'virastore-cfr2'); ?></option>
                            <option value="ap-southeast-1" <?php selected($r2_region, 'ap-southeast-1'); ?>><?php esc_html_e('Asia Pacific Southeast 1', 'virastore-cfr2'); ?></option>
                        </select>
                        <p class="description">
                            <?php esc_html_e('R2 region (usually "auto" works best)', 'virastore-cfr2'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="cfr2_use_private_bucket"><?php esc_html_e('Private Bucket', 'virastore-cfr2'); ?></label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" id="cfr2_use_private_bucket" name="cfr2_use_private_bucket" 
                                   value="1" <?php checked($use_private_bucket, '1'); ?>>
                            <?php esc_html_e('Use private bucket with signed URLs', 'virastore-cfr2'); ?>
                        </label>
                        <p class="description">
                            <?php esc_html_e('Enable this for better security. Files will be served via signed URLs.', 'virastore-cfr2'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="cfr2_custom_domain"><?php esc_html_e('Custom Domain', 'virastore-cfr2'); ?></label>
                    </th>
                    <td>
                        <input type="url" id="cfr2_custom_domain" name="cfr2_custom_domain" 
                               value="<?php echo esc_attr($custom_domain); ?>" 
                               class="regular-text" placeholder="https://cdn.yourdomain.com">
                        <p class="description">
                            <?php esc_html_e('Optional: Custom domain for serving files (requires R2 custom domain setup)', 'virastore-cfr2'); ?>
                        </p>
                    </td>
                </tr>
            </table>

            <div class="cfr2-form-actions">
                <button type="submit" class="button button-primary">
                    <?php esc_html_e('Save Configuration', 'virastore-cfr2'); ?>
                </button>
                <button type="button" id="cfr2-test-connection" class="button button-secondary">
                    <?php esc_html_e('Test Connection', 'virastore-cfr2'); ?>
                </button>
            </div>
        </form>
    </div>

    <?php if ($is_configured): ?>
    <!-- Storage Statistics -->
    <div class="cfr2-section cfr2-stats-section">
        <h3><?php esc_html_e('Storage Statistics', 'virastore-cfr2'); ?></h3>
        <div class="cfr2-stats-grid">
            <div class="cfr2-stat-card">
                <div class="stat-number"><?php echo esc_html($stats['total_files']); ?></div>
                <div class="stat-label"><?php esc_html_e('Total Files', 'virastore-cfr2'); ?></div>
            </div>
            <div class="cfr2-stat-card">
                <div class="stat-number"><?php echo esc_html(size_format($stats['total_size'])); ?></div>
                <div class="stat-label"><?php esc_html_e('Total Size', 'virastore-cfr2'); ?></div>
            </div>
            <div class="cfr2-stat-card">
                <div class="stat-number"><?php echo esc_html($stats['total_plugins']); ?></div>
                <div class="stat-label"><?php esc_html_e('Total Plugins', 'virastore-cfr2'); ?></div>
            </div>
        </div>
    </div>

    <!-- File Upload Section -->
    <div class="cfr2-section cfr2-upload-section">
        <h3><?php esc_html_e('Upload Plugin File', 'virastore-cfr2'); ?></h3>
        
        <form id="cfr2-upload-form" enctype="multipart/form-data">
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="cfr2_plugin_id"><?php esc_html_e('Plugin Product', 'virastore-cfr2'); ?></label>
                    </th>
                    <td>
                        <select id="cfr2_plugin_id" name="plugin_id" required>
                            <option value=""><?php esc_html_e('Select a plugin product...', 'virastore-cfr2'); ?></option>
                            <?php if (empty($plugin_products)) : ?>
                                <option value="" disabled><?php esc_html_e('No plugin products found. Please add products in Vira Store.', 'virastore-cfr2'); ?></option>
                            <?php else :
                                foreach ($plugin_products as $product) : ?>
                                <option value="<?php echo esc_attr($product->ID); ?>">
                                    <?php echo esc_html($product->post_title); ?>
                                </option>
                            <?php
                                endforeach;
                            endif;
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="cfr2_version"><?php esc_html_e('Version', 'virastore-cfr2'); ?></label>
                    </th>
                    <td>
                        <input type="text" id="cfr2_version" name="version" 
                               class="regular-text" placeholder="1.0.0" required>
                        <p class="description">
                            <?php esc_html_e('Plugin version (e.g., 1.0.0)', 'virastore-cfr2'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="cfr2_file_input"><?php esc_html_e('Plugin ZIP File', 'virastore-cfr2'); ?></label>
                    </th>
                    <td>
                        <input type="file" id="cfr2_file_input" name="plugin_file" 
                               accept=".zip" required>
                        <p class="description">
                            <?php esc_html_e('Select the plugin ZIP file to upload (max 50MB)', 'virastore-cfr2'); ?>
                        </p>
                        <div class="cfr2-upload-progress cfr2-hidden">
                            <div class="cfr2-progress-bar"></div>
                        </div>
                    </td>
                </tr>
            </table>

            <div class="cfr2-form-actions">
                <button type="submit" class="button button-primary">
                    <?php esc_html_e('Upload to R2', 'virastore-cfr2'); ?>
                </button>
            </div>
        </form>
    </div>

    <!-- File Management Section -->
    <div class="cfr2-section cfr2-files-section">
        <div class="cfr2-section-header">
            <h3><?php esc_html_e('Uploaded Files', 'virastore-cfr2'); ?></h3>
            <button type="button" id="cfr2-sync-files" class="button button-secondary">
                <span class="dashicons dashicons-update"></span>
                <?php esc_html_e('Sync Files', 'virastore-cfr2'); ?>
            </button>
        </div>
        
        <div id="cfr2-files-list">
            <?php 
            // Get admin instance and render files list
            $admin = ViraStore_CFR2_Admin::get_instance();
            $admin->render_files_list(); 
            ?>
        </div>
    </div>
    <?php endif; ?>
</div>