<?php
/**
 * File Manager Class for CFR2
 *
 * Handles file uploads, deletions, and synchronization with R2
 */

if (!defined("ABSPATH")) {
    exit();
}

class ViraStore_CFR2_File_Manager
{
    private static $instance = null;
    private $r2_client;
    private static $vrstore_table_exists = null;
    private static $plugin_cache = null;

    /**
     * Get single instance
     */
    public static function get_instance()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct()
    {
        $this->r2_client = new ViraStore_CFR2_Client();
    }

    /**
     * Determine if legacy Vira Store products table exists
     */
    private function vrstore_products_table_exists()
    {
        global $wpdb;

        if (self::$vrstore_table_exists !== null) {
            return self::$vrstore_table_exists;
        }

        $table_name = $wpdb->prefix . "vrstore_products";
        $like = $wpdb->esc_like($table_name);
        $found = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $like));
        self::$vrstore_table_exists = $found === $table_name;

        return self::$vrstore_table_exists;
    }

    /**
     * Retrieve a single plugin record (compat with table or CPT)
     */
    private function get_plugin_record($plugin_id)
    {
        $plugin_id = intval($plugin_id);
        if ($plugin_id <= 0) {
            return null;
        }

        if ($this->vrstore_products_table_exists()) {
            global $wpdb;
            return $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT id, name, slug FROM {$wpdb->prefix}vrstore_products WHERE id = %d AND type = 'plugin'",
                    $plugin_id,
                ),
            );
        }

        $post = get_post($plugin_id);
        if ($post && $post->post_type === "vrstore_product") {
            return (object) [
                "id" => $post->ID,
                "name" => $post->post_title,
                "slug" => $post->post_name,
            ];
        }

        return null;
    }

    /**
     * Get cached list of plugin records for identifier resolution
     */
    private function get_plugin_cache()
    {
        if (self::$plugin_cache !== null) {
            return self::$plugin_cache;
        }

        if ($this->vrstore_products_table_exists()) {
            global $wpdb;
            self::$plugin_cache = $wpdb->get_results(
                "SELECT id, name, slug FROM {$wpdb->prefix}vrstore_products WHERE type = 'plugin'",
            );
        } else {
            $posts = get_posts([
                "post_type" => "vrstore_product",
                "post_status" => ["publish", "draft", "pending", "private"],
                "posts_per_page" => -1,
                "orderby" => "title",
                "order" => "ASC",
                "fields" => "ids",
            ]);

            $records = [];
            foreach ($posts as $post_id) {
                $post = get_post($post_id);
                if (!$post) {
                    continue;
                }
                $records[] = (object) [
                    "id" => $post->ID,
                    "name" => $post->post_title,
                    "slug" => $post->post_name,
                ];
            }
            self::$plugin_cache = $records;
        }

        return self::$plugin_cache;
    }

    /**
     * Upload plugin file to R2
     */
    public function upload_plugin_file($plugin_id, $version, $file)
    {
        global $wpdb;

        // Debug log start
        error_log(
            "CFR2 Upload Debug: Starting upload for plugin_id=$plugin_id, version=$version",
        );

        // Validate inputs
        if (empty($plugin_id) || empty($version) || empty($file)) {
            error_log("CFR2 Upload Debug: Missing required parameters");
            throw new Exception(
                __("Missing required parameters", "virastore-cfr2"),
            );
        }

        // Debug file info
        error_log(
            "CFR2 Upload Debug: File info - " .
                json_encode([
                    "name" => $file["name"],
                    "type" => $file["type"],
                    "size" => $file["size"],
                    "error" => $file["error"],
                    "tmp_name_exists" => file_exists($file["tmp_name"]),
                ]),
        );

        // Validate file
        if ($file["error"] !== UPLOAD_ERR_OK) {
            error_log(
                "CFR2 Upload Debug: File upload error - " . $file["error"],
            );
            throw new Exception(__("File upload error", "virastore-cfr2"));
        }

        if (
            $file["type"] !== "application/zip" &&
            pathinfo($file["name"], PATHINFO_EXTENSION) !== "zip"
        ) {
            error_log(
                "CFR2 Upload Debug: Invalid file type - " . $file["type"],
            );
            throw new Exception(
                __("Only ZIP files are allowed", "virastore-cfr2"),
            );
        }

        // Get plugin info
        $plugin = $this->get_plugin_record($plugin_id);

        if (!$plugin) {
            error_log("CFR2 Upload Debug: Plugin not found for ID $plugin_id");
            throw new Exception(__("Plugin not found", "virastore-cfr2"));
        }

        error_log("CFR2 Upload Debug: Plugin found - " . json_encode($plugin));

        // Check if version already exists
        $existing = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id FROM {$wpdb->prefix}virastore_cfr2_files WHERE plugin_id = %d AND version = %s",
                $plugin_id,
                $version,
            ),
        );

        if ($existing) {
            error_log("CFR2 Upload Debug: Version already exists - $existing");
            throw new Exception(__("Version already exists", "virastore-cfr2"));
        }

        // Generate R2 key
        $identifier_source = !empty($plugin->slug)
            ? $plugin->slug
            : $plugin->name;
        $sanitized_name = sanitize_file_name($identifier_source);
        $is_private =
            get_option("virastore_cfr2_use_private_bucket", "0") === "1"
                ? 1
                : 0;
        $r2_key = "plugins/{$sanitized_name}/v{$version}/{$sanitized_name}-{$version}.zip";

        error_log("CFR2 Upload Debug: Generated R2 key - $r2_key");

        // Check R2 client configuration
        if (!$this->r2_client->is_configured()) {
            error_log(
                "CFR2 Upload Debug: R2 client is not properly configured",
            );
            throw new Exception(
                __("R2 client is not properly configured", "virastore-cfr2"),
            );
        }

        try {
            error_log("CFR2 Upload Debug: Starting R2 upload...");
            // Upload to R2
            $r2_url = $this->r2_client->upload_file(
                $file["tmp_name"],
                $r2_key,
                "application/zip",
            );
            error_log("CFR2 Upload Debug: R2 upload successful - URL: $r2_url");

            // Save to database
            $result = $wpdb->insert(
                $wpdb->prefix . "virastore_cfr2_files",
                [
                    "plugin_id" => $plugin_id,
                    "version" => $version,
                    "file_name" => $file["name"],
                    "r2_key" => $r2_key,
                    "r2_url" => $r2_url,
                    "file_size" => $file["size"],
                    "upload_date" => current_time("mysql"),
                    "is_private" => $is_private,
                ],
                ["%d", "%s", "%s", "%s", "%s", "%d", "%s", "%d"],
            );

            if ($result === false) {
                error_log(
                    "CFR2 Upload Debug: Database insert failed - " .
                        $wpdb->last_error,
                );
                // If database insert fails, try to delete from R2
                $this->r2_client->delete_file($r2_key);
                throw new Exception(
                    __("Failed to save file information", "virastore-cfr2"),
                );
            }

            error_log(
                "CFR2 Upload Debug: Database insert successful - ID: " .
                    $wpdb->insert_id,
            );

            // Update plugin version in main table if needed
            $this->update_plugin_version($plugin_id, $version, $r2_url);

            error_log("CFR2 Upload Debug: Upload completed successfully");

            return [
                "id" => $wpdb->insert_id,
                "url" => $r2_url,
                "key" => $r2_key,
            ];
        } catch (Exception $e) {
            error_log(
                "CFR2 Upload Debug: Exception caught - " . $e->getMessage(),
            );
            throw new Exception(
                __("Upload failed: ", "virastore-cfr2") . $e->getMessage(),
            );
        }
    }

    /**
     * Delete file from R2 and database
     */
    public function delete_file($file_id)
    {
        global $wpdb;

        // Get file info
        $file = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}virastore_cfr2_files WHERE id = %d",
                $file_id,
            ),
        );

        if (!$file) {
            throw new Exception(__("File not found", "virastore-cfr2"));
        }

        try {
            // Delete from R2
            $this->r2_client->delete_file($file->r2_key);

            // Delete from database
            $result = $wpdb->delete(
                $wpdb->prefix . "virastore_cfr2_files",
                ["id" => $file_id],
                ["%d"],
            );

            if ($result === false) {
                throw new Exception(
                    __("Failed to delete file record", "virastore-cfr2"),
                );
            }

            return true;
        } catch (Exception $e) {
            throw new Exception(
                __("Delete failed: ", "virastore-cfr2") . $e->getMessage(),
            );
        }
    }

    /**
     * Sync files between database and R2
     */
    public function sync_files()
    {
        global $wpdb;

        $processed = 0;
        $errors = [];

        try {
            // Get all files from R2
            $r2_files = $this->r2_client->list_files("plugins/");

            // Get all files from database
            $db_files = $wpdb->get_results(
                "SELECT * FROM {$wpdb->prefix}virastore_cfr2_files",
                OBJECT_K,
            );

            // Check for files in R2 but not in database
            foreach ($r2_files as $r2_file) {
                $found = false;
                foreach ($db_files as $db_file) {
                    if ($db_file->r2_key === $r2_file["key"]) {
                        $found = true;
                        break;
                    }
                }

                if (!$found) {
                    // Try to parse plugin info from key
                    $plugin_info = $this->parse_r2_key($r2_file["key"]);
                    if ($plugin_info) {
                        // Add to database
                        $is_private =
                            get_option(
                                "virastore_cfr2_use_private_bucket",
                                "0",
                            ) === "1"
                                ? 1
                                : 0;
                        $wpdb->insert(
                            $wpdb->prefix . "virastore_cfr2_files",
                            [
                                "plugin_id" => $plugin_info["plugin_id"],
                                "version" => $plugin_info["version"],
                                "file_name" => basename($r2_file["key"]),
                                "r2_key" => $r2_file["key"],
                                "r2_url" => $this->r2_client->get_file_url(
                                    $r2_file["key"],
                                ),
                                "file_size" => $r2_file["size"],
                                "upload_date" => current_time("mysql"),
                                "is_private" => $is_private,
                            ],
                            ["%d", "%s", "%s", "%s", "%s", "%d", "%s", "%d"],
                        );

                        // Update/insert into main plugin versions table with discovered R2 URL
                        $this->update_plugin_version(
                            $plugin_info["plugin_id"],
                            $plugin_info["version"],
                            $this->r2_client->get_file_url($r2_file["key"]),
                        );
                    }
                }
                $processed++;
            }

            // Check for files in database but not in R2
            foreach ($db_files as $db_file) {
                $found = false;
                foreach ($r2_files as $r2_file) {
                    if ($r2_file["key"] === $db_file->r2_key) {
                        $found = true;
                        break;
                    }
                }

                if (!$found) {
                    // Remove from database
                    $wpdb->delete(
                        $wpdb->prefix . "virastore_cfr2_files",
                        ["id" => $db_file->id],
                        ["%d"],
                    );
                }
                $processed++;
            }

            return [
                "processed" => $processed,
                "errors" => $errors,
            ];
        } catch (Exception $e) {
            throw new Exception(
                __("Sync failed: ", "virastore-cfr2") . $e->getMessage(),
            );
        }
    }

    /**
     * Get file URL (public or signed)
     */
    public function get_file_url($plugin_id, $version)
    {
        global $wpdb;

        $file = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}virastore_cfr2_files WHERE plugin_id = %d AND version = %s",
                $plugin_id,
                $version,
            ),
        );

        if (!$file) {
            return null;
        }

        // Return signed URL for private buckets
        if ($file->is_private) {
            $expiry = get_option("virastore_cfr2_signed_url_expiry", 3600);
            return $this->r2_client->generate_signed_url(
                $file->r2_key,
                $expiry,
            );
        }

        return $file->r2_url;
    }

    /**
     * Update plugin version in main table
     */
    private function update_plugin_version($plugin_id, $version, $download_url)
    {
        global $wpdb;

        // Check if version exists in plugin versions table
        $version_exists = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id FROM {$wpdb->prefix}vrstore_plugin_versions WHERE plugin_id = %d AND version = %s",
                $plugin_id,
                $version,
            ),
        );

        if ($version_exists) {
            // Update existing version with R2 URL
            $wpdb->update(
                $wpdb->prefix . "vrstore_plugin_versions",
                ["download_url" => $download_url],
                ["id" => $version_exists],
                ["%s"],
                ["%d"],
            );
        } else {
            // Create new version entry
            $wpdb->insert(
                $wpdb->prefix . "vrstore_plugin_versions",
                [
                    "plugin_id" => $plugin_id,
                    "version" => $version,
                    "download_url" => $download_url,
                    "release_date" => current_time("mysql"),
                    "created_at" => current_time("mysql"),
                ],
                ["%d", "%s", "%s", "%s", "%s"],
            );
        }
    }

    /**
     * Parse R2 key to extract plugin info
     */
    private function parse_r2_key($key)
    {
        // Expected format: plugins/{plugin-name}/v{version}/{plugin-name}-{version}.zip
        if (!preg_match("/^plugins\/([^\/]+)\/v([^\/]+)\//", $key, $matches)) {
            return null;
        }

        $identifier = sanitize_file_name($matches[1]);
        $version = $matches[2];

        $plugin_cache = $this->get_plugin_cache();

        if (!$plugin_cache) {
            return null;
        }

        foreach ($plugin_cache as $plugin) {
            $candidates = [];
            if (!empty($plugin->slug)) {
                $candidates[] = sanitize_file_name($plugin->slug);
            }
            if (!empty($plugin->name)) {
                $candidates[] = sanitize_file_name($plugin->name);
            }

            $candidates = array_unique(array_filter($candidates));

            if (in_array($identifier, $candidates, true)) {
                return [
                    "plugin_id" => intval($plugin->id),
                    "version" => $version,
                ];
            }
        }

        return null;
    }

    /**
     * Get storage statistics
     */
    public function get_storage_stats()
    {
        global $wpdb;

        $stats = $wpdb->get_row(
            "SELECT
                COUNT(*) as total_files,
                SUM(file_size) as total_size,
                COUNT(DISTINCT plugin_id) as total_plugins
             FROM {$wpdb->prefix}virastore_cfr2_files",
        );

        return [
            "total_files" => intval($stats->total_files),
            "total_size" => intval($stats->total_size),
            "total_plugins" => intval($stats->total_plugins),
            "formatted_size" => size_format($stats->total_size),
        ];
    }

    /**
     * Clean up orphaned files
     */
    public function cleanup_orphaned_files()
    {
        global $wpdb;

        if ($this->vrstore_products_table_exists()) {
            $join = "LEFT JOIN {$wpdb->prefix}vrstore_products p ON cf.plugin_id = p.id";
            $condition = "WHERE p.id IS NULL";
        } else {
            $posts_table = $wpdb->posts;
            $join = "LEFT JOIN {$posts_table} p ON cf.plugin_id = p.ID AND p.post_type = 'vrstore_product'";
            $condition = "WHERE p.ID IS NULL";
        }

        $orphaned = $wpdb->get_results(
            "SELECT cf.* FROM {$wpdb->prefix}virastore_cfr2_files cf
             {$join}
             {$condition}",
        );

        $cleaned = 0;
        foreach ($orphaned as $file) {
            try {
                $this->delete_file($file->id);
                $cleaned++;
            } catch (Exception $e) {
                error_log("CFR2 Cleanup Error: " . $e->getMessage());
            }
        }

        return $cleaned;
    }
}
