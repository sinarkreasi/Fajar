<?php
/**
 * Admin Interface for CFR2
 *
 * Adds Storage tab to the Vira Store plugin versions admin page
 */

if (!defined("ABSPATH")) {
    exit();
}

class ViraStore_CFR2_Admin
{
    private static $instance = null;
    private $r2_client;

    /**
     * Get single instance
     */
    public static function get_instance()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct()
    {
        $this->r2_client = new ViraStore_CFR2_Client();

        // Initialize immediately since we're in admin context
        $this->init();
    }

    /**
     * Initialize admin hooks
     */
    public function init()
    {
        add_action("admin_menu", [$this, "add_admin_menu"]);

        // Enqueue scripts on the storage page
        add_action("admin_enqueue_scripts", [$this, "enqueue_scripts"]);

        // AJAX handlers
        add_action("wp_ajax_cfr2_test_connection", [
            $this,
            "ajax_test_connection",
        ]);
        add_action("wp_ajax_cfr2_upload_file", [$this, "ajax_upload_file"]);
        add_action("wp_ajax_cfr2_delete_file", [$this, "ajax_delete_file"]);
        add_action("wp_ajax_cfr2_sync_files", [$this, "ajax_sync_files"]);
        add_action("wp_ajax_cfr2_view_file", [$this, "ajax_view_file"]);
        add_action("wp_ajax_cfr2_dismiss_notice", [
            $this,
            "ajax_dismiss_notice",
        ]);
        add_action("wp_ajax_cfr2_refresh_files", [$this, "ajax_refresh_files"]);

        // Form handlers
        add_action("admin_post_cfr2_save_config", [
            $this,
            "save_configuration",
        ]);
        add_action("admin_post_nopriv_cfr2_save_config", [
            $this,
            "save_configuration",
        ]);

        // Register settings
        $this->register_settings();
    }

    /**
     * Add admin menu
     */
    public function add_admin_menu()
    {
        // Check current user capabilities
        if (!current_user_can("manage_options")) {
            return;
        }

        add_submenu_page(
            "vrstore-dashboard",
            __("Cloudflare R2 Storage", "virastore-cfr2"),
            __("Cloudflare R2", "virastore-cfr2"),
            "manage_options",
            "vrstore-cfr2-storage",
            [$this, "render_storage_page"],
        );
    }

    /**
     * Render the storage page
     */
    public function render_storage_page()
    {
        // Show success message if configuration was saved
        if (
            isset($_GET["cfr2_message"]) &&
            $_GET["cfr2_message"] === "config_saved"
        ) {
            echo '<div class="notice notice-success is-dismissible">';
            echo "<p>" .
                esc_html__(
                    "R2 configuration saved successfully!",
                    "virastore-cfr2",
                ) .
                "</p>";
            echo "</div>";
        }

        echo '<div class="wrap">';
        echo "<h1>" .
            esc_html__("Cloudflare R2 Storage", "virastore-cfr2") .
            "</h1>";

        // Check if template file exists
        $template_path =
            VIRASTORE_CFR2_PATH . "templates/admin-storage-page.php";

        if (file_exists($template_path)) {
            // Include the template
            include $template_path;
        } else {
            echo '<div class="notice notice-error">';
            echo "<p>Template file not found: " .
                esc_html($template_path) .
                "</p>";
            echo "</div>";
            echo "<p>This is a fallback message. The R2 Storage configuration page should be here.</p>";
        }

        echo "</div>";
    }

    /**
     * Render plugin options for select dropdown
     */
    private function render_plugin_options()
    {
        $products = get_posts([
            "post_type" => "vrstore_product",
            "post_status" => ["publish", "draft", "pending", "private"],
            "posts_per_page" => -1,
            "orderby" => "title",
            "order" => "ASC",
        ]);

        foreach ($products as $product) {
            echo '<option value="' .
                esc_attr($product->ID) .
                '">' .
                esc_html(get_the_title($product->ID)) .
                "</option>";
        }
    }

    /**
     * Render files list
     */
    public function render_files_list()
    {
        global $wpdb;

        // Check if required tables exist - use correct Vira Store table name
        $cfr2_table = $wpdb->prefix . "virastore_cfr2_files";
        $products_table = $wpdb->prefix . "vrstore_products";

        $cfr2_exists =
            $wpdb->get_var(
                $wpdb->prepare(
                    "SHOW TABLES LIKE %s",
                    $wpdb->esc_like($cfr2_table),
                ),
            ) === $cfr2_table;
        $products_exists =
            $wpdb->get_var(
                $wpdb->prepare(
                    "SHOW TABLES LIKE %s",
                    $wpdb->esc_like($products_table),
                ),
            ) === $products_table;

        if (!$cfr2_exists) {
            echo '<div class="notice notice-warning"><p>' .
                esc_html__(
                    "CFR2 files table not found. Please deactivate and reactivate the plugin to create required tables.",
                    "virastore-cfr2",
                ) .
                "</p></div>";
            return;
        }

        if ($products_exists) {
            $join = "LEFT JOIN {$products_table} p ON cf.plugin_id = p.id";
            $name_field = "p.name as plugin_name";
        } else {
            $posts_table = $wpdb->posts;
            $join = "LEFT JOIN {$posts_table} p ON cf.plugin_id = p.ID AND p.post_type = 'vrstore_product'";
            $name_field = "p.post_title as plugin_name";
        }

        $files = $wpdb->get_results(
            "SELECT cf.*, {$name_field}
             FROM {$cfr2_table} cf
             {$join}
             ORDER BY cf.upload_date DESC",
        );

        if (empty($files)) {
            echo '<p class="no-files">' .
                esc_html__("No files uploaded yet.", "virastore-cfr2") .
                "</p>";
            return;
        }

        echo '<div class="cfr2-files-table-wrapper">';
        echo '<table class="wp-list-table widefat fixed striped">';
        echo "<thead>";
        echo "<tr>";
        echo "<th>" . esc_html__("Plugin", "virastore-cfr2") . "</th>";
        echo "<th>" . esc_html__("Version", "virastore-cfr2") . "</th>";
        echo "<th>" . esc_html__("File Name", "virastore-cfr2") . "</th>";
        echo "<th>" . esc_html__("Size", "virastore-cfr2") . "</th>";
        echo "<th>" . esc_html__("Upload Date", "virastore-cfr2") . "</th>";
        echo "<th>" . esc_html__("Status", "virastore-cfr2") . "</th>";
        echo "<th>" . esc_html__("Actions", "virastore-cfr2") . "</th>";
        echo "</tr>";
        echo "</thead>";
        echo "<tbody>";

        foreach ($files as $file) {
            echo "<tr>";
            $plugin_name = $file->plugin_name
                ? $file->plugin_name
                : __("Unknown Product", "virastore-cfr2");
            echo "<td>" . esc_html($plugin_name) . "</td>";
            echo "<td>" . esc_html($file->version) . "</td>";
            echo "<td>" . esc_html($file->file_name) . "</td>";
            echo "<td>" . size_format($file->file_size) . "</td>";
            echo "<td>" .
                esc_html(mysql2date("Y-m-d H:i:s", $file->upload_date)) .
                "</td>";
            echo "<td>";
            if ($file->is_private) {
                echo '<span class="status-private">' .
                    esc_html__("Private", "virastore-cfr2") .
                    "</span>";
            } else {
                echo '<span class="status-public">' .
                    esc_html__("Public", "virastore-cfr2") .
                    "</span>";
            }
            echo "</td>";
            echo "<td>";
            echo '<a href="' .
                esc_url($file->r2_url) .
                '" target="_blank" class="button button-small">';
            echo '<span class="dashicons dashicons-external"></span> ' .
                esc_html__("View", "virastore-cfr2");
            echo "</a> ";
            echo '<button class="button button-small cfr2-delete-file" data-file-id="' .
                esc_attr($file->id) .
                '">';
            echo '<span class="dashicons dashicons-trash"></span> ' .
                esc_html__("Delete", "virastore-cfr2");
            echo "</button>";
            echo "</td>";
            echo "</tr>";
        }

        echo "</tbody>";
        echo "</table>";
        echo "</div>";
    }

    /**
     * Register settings
     */
    private function register_settings()
    {
        register_setting(
            "virastore_cfr2_settings",
            "virastore_cfr2_account_id",
        );
        register_setting(
            "virastore_cfr2_settings",
            "virastore_cfr2_access_key_id",
        );
        register_setting(
            "virastore_cfr2_settings",
            "virastore_cfr2_secret_access_key",
        );
        register_setting(
            "virastore_cfr2_settings",
            "virastore_cfr2_bucket_name",
        );
        register_setting("virastore_cfr2_settings", "virastore_cfr2_region");
        register_setting(
            "virastore_cfr2_settings",
            "virastore_cfr2_custom_domain",
        );
        register_setting(
            "virastore_cfr2_settings",
            "virastore_cfr2_use_private_bucket",
        );
        register_setting(
            "virastore_cfr2_settings",
            "virastore_cfr2_signed_url_expiry",
        );
    }

    /**
     * Enqueue admin scripts and styles
     */
    public function enqueue_scripts($hook)
    {
        // Only load on our storage page
        if (strpos($hook, "vrstore-cfr2-storage") === false) {
            return;
        }

        wp_enqueue_script(
            "cfr2-admin",
            VIRASTORE_CFR2_URL . "assets/js/admin.js",
            ["jquery"],
            VIRASTORE_CFR2_VERSION,
            true,
        );

        wp_enqueue_style(
            "cfr2-admin",
            VIRASTORE_CFR2_URL . "assets/css/admin.css",
            [],
            VIRASTORE_CFR2_VERSION,
        );

        // Localize script for AJAX
        wp_localize_script("cfr2-admin", "cfr2_ajax", [
            "ajax_url" => admin_url("admin-ajax.php"),
            "nonce" => wp_create_nonce("cfr2_ajax_nonce"),
            "strings" => [
                "connection_success" => __(
                    "Connection successful!",
                    "virastore-cfr2",
                ),
                "connection_failed" => __(
                    "Connection failed. Please check your credentials.",
                    "virastore-cfr2",
                ),
                "upload_success" => __(
                    "File uploaded successfully!",
                    "virastore-cfr2",
                ),
                "upload_failed" => __("File upload failed.", "virastore-cfr2"),
                "delete_confirm" => __(
                    "Are you sure you want to delete this file?",
                    "virastore-cfr2",
                ),
                "delete_success" => __(
                    "File deleted successfully!",
                    "virastore-cfr2",
                ),
                "delete_failed" => __(
                    "File deletion failed.",
                    "virastore-cfr2",
                ),
                "sync_success" => __(
                    "Files synchronized successfully!",
                    "virastore-cfr2",
                ),
                "sync_failed" => __(
                    "File synchronization failed.",
                    "virastore-cfr2",
                ),
                "testing" => __("Testing...", "virastore-cfr2"),
                "uploading" => __("Uploading...", "virastore-cfr2"),
                "deleting" => __("Deleting...", "virastore-cfr2"),
                "syncing" => __("Syncing...", "virastore-cfr2"),
                "error" => __("Error", "virastore-cfr2"),
                "confirm_delete" => __(
                    "Are you sure you want to delete this file?",
                    "virastore-cfr2",
                ),
            ],
        ]);
    }

    /**
     * AJAX: Test R2 connection
     */
    public function ajax_test_connection()
    {
        check_ajax_referer("cfr2_ajax_nonce", "nonce");

        if (!current_user_can("manage_options")) {
            wp_die(__("Insufficient permissions", "virastore-cfr2"));
        }

        $success = $this->r2_client->test_connection();

        if ($success) {
            // Test R2 permissions with bucket listing
            $permissions_success = false;
            if (method_exists($this->r2_client, "test_r2_permissions")) {
                $permissions_success = $this->r2_client->test_r2_permissions();
            }

            if ($permissions_success) {
                wp_send_json_success([
                    "message" => __(
                        "Connection and R2 permissions successful!",
                        "virastore-cfr2",
                    ),
                ]);
            } else {
                wp_send_json_success([
                    "message" => __(
                        "Basic connection works, but R2 authentication/permissions failed. Check your API token permissions.",
                        "virastore-cfr2",
                    ),
                    "warning" => true,
                ]);
            }
        } else {
            $error = method_exists($this->r2_client, "get_last_error")
                ? $this->r2_client->get_last_error()
                : "";

            wp_send_json_error([
                "message" => __(
                    "Connection failed. Please check your configuration.",
                    "virastore-cfr2",
                ),
                "details" => $error,
            ]);
        }
    }

    /**
     * AJAX: Upload file to R2
     */
    public function ajax_upload_file()
    {
        check_ajax_referer("cfr2_ajax_nonce", "nonce");

        if (!current_user_can("manage_options")) {
            wp_send_json_error(__("Insufficient permissions", "virastore-cfr2"));
        }

        // Check if file was uploaded
        if (!isset($_FILES["plugin_file"])) {
            wp_send_json_error(__("No file uploaded", "virastore-cfr2"));
        }

        // Check for upload errors
        $upload_error = $_FILES["plugin_file"]["error"];
        if ($upload_error !== UPLOAD_ERR_OK) {
            $error_messages = [
                UPLOAD_ERR_INI_SIZE => __("File exceeds upload_max_filesize directive in php.ini", "virastore-cfr2"),
                UPLOAD_ERR_FORM_SIZE => __("File exceeds MAX_FILE_SIZE directive in HTML form", "virastore-cfr2"),
                UPLOAD_ERR_PARTIAL => __("File was only partially uploaded", "virastore-cfr2"),
                UPLOAD_ERR_NO_FILE => __("No file was uploaded", "virastore-cfr2"),
                UPLOAD_ERR_NO_TMP_DIR => __("Missing temporary folder", "virastore-cfr2"),
                UPLOAD_ERR_CANT_WRITE => __("Failed to write file to disk", "virastore-cfr2"),
                UPLOAD_ERR_EXTENSION => __("File upload stopped by extension", "virastore-cfr2"),
            ];
            $error_message = isset($error_messages[$upload_error]) 
                ? $error_messages[$upload_error] 
                : __("File upload error", "virastore-cfr2") . " (code: $upload_error)";
            wp_send_json_error($error_message);
        }

        // Validate required fields
        if (!isset($_POST["plugin_id"]) || !isset($_POST["version"])) {
            wp_send_json_error(__("Plugin ID and version are required", "virastore-cfr2"));
        }

        $plugin_id = intval($_POST["plugin_id"]);
        $version = sanitize_text_field($_POST["version"]);
        $file = $_FILES["plugin_file"];

        // Validate inputs
        if ($plugin_id <= 0) {
            wp_send_json_error(__("Invalid plugin ID", "virastore-cfr2"));
        }

        if (empty($version)) {
            wp_send_json_error(__("Version cannot be empty", "virastore-cfr2"));
        }

        // Validate file type
        $file_extension = strtolower(pathinfo($file["name"], PATHINFO_EXTENSION));
        if ($file_extension !== "zip") {
            wp_send_json_error(__("Only ZIP files are allowed", "virastore-cfr2"));
        }

        try {
            $file_manager = ViraStore_CFR2_File_Manager::get_instance();
            $result = $file_manager->upload_plugin_file(
                $plugin_id,
                $version,
                $file,
            );

            wp_send_json_success([
                "message" => __(
                    "File uploaded successfully!",
                    "virastore-cfr2",
                ),
                "file_url" => $result["url"],
            ]);
        } catch (Exception $e) {
            // Log the full error for debugging
            error_log("CFR2 Upload Error: " . $e->getMessage());
            // Send user-friendly error message
            wp_send_json_error($e->getMessage());
        }
    }

    /**
     * AJAX: Delete file from R2
     */
    public function ajax_delete_file()
    {
        check_ajax_referer("cfr2_ajax_nonce", "nonce");

        if (!current_user_can("manage_options")) {
            wp_die(__("Insufficient permissions", "virastore-cfr2"));
        }

        $file_id = intval($_POST["file_id"]);

        try {
            $file_manager = ViraStore_CFR2_File_Manager::get_instance();
            $file_manager->delete_file($file_id);

            wp_send_json_success(
                __("File deleted successfully!", "virastore-cfr2"),
            );
        } catch (Exception $e) {
            wp_send_json_error($e->getMessage());
        }
    }

    /**
     * AJAX: Dismiss integration notice
     */
    public function ajax_dismiss_notice()
    {
        check_ajax_referer("cfr2_ajax_nonce", "nonce");

        if (!current_user_can("manage_options")) {
            wp_die(__("Insufficient permissions", "virastore-cfr2"));
        }

        $notice_type = sanitize_text_field($_POST["notice_type"]);

        if ($notice_type === "integration") {
            update_user_meta(
                get_current_user_id(),
                "cfr2_integration_notice_dismissed",
                true,
            );
            wp_send_json_success(__("Notice dismissed", "virastore-cfr2"));
        }

        wp_send_json_error(__("Invalid notice type", "virastore-cfr2"));
    }

    /**
     * AJAX: Sync files with R2
     */
    public function ajax_sync_files()
    {
        check_ajax_referer("cfr2_ajax_nonce", "nonce");

        if (!current_user_can("manage_options")) {
            wp_die(__("Insufficient permissions", "virastore-cfr2"));
        }

        try {
            $file_manager = ViraStore_CFR2_File_Manager::get_instance();
            $result = $file_manager->sync_files();

            wp_send_json_success([
                "message" => sprintf(
                    __("Sync completed. %d files processed.", "virastore-cfr2"),
                    $result["processed"],
                ),
                "files_html" => $this->get_files_list_html(),
            ]);
        } catch (Exception $e) {
            wp_send_json_error($e->getMessage());
        }
    }

    /**
     * AJAX: Refresh files list
     */
    public function ajax_refresh_files()
    {
        check_ajax_referer("cfr2_ajax_nonce", "nonce");

        if (!current_user_can("manage_options")) {
            wp_die(__("Insufficient permissions", "virastore-cfr2"));
        }

        try {
            $html = $this->get_files_list_html();
            wp_send_json_success(["html" => $html]);
        } catch (Exception $e) {
            wp_send_json_error($e->getMessage());
        }
    }

    /**
     * Get files list HTML for AJAX updates
     */
    private function get_files_list_html()
    {
        ob_start();
        $this->render_files_list();
        return ob_get_clean();
    }

    /**
     * Save configuration (admin_post handler)
     */
    public function save_configuration()
    {
        if (
            !isset($_POST["cfr2_config_nonce"]) ||
            !wp_verify_nonce($_POST["cfr2_config_nonce"], "cfr2_save_config")
        ) {
            wp_die(__("Security check failed", "virastore-cfr2"));
        }

        if (!current_user_can("manage_options")) {
            wp_die(__("Insufficient permissions", "virastore-cfr2"));
        }

        // Save configuration options (using correct option names)
        $endpoint_input = isset($_POST["cfr2_endpoint"])
            ? trim(wp_unslash($_POST["cfr2_endpoint"]))
            : "";
        $endpoint = esc_url_raw($endpoint_input);
        $account_id = "";
        if (
            $endpoint &&
            preg_match(
                "/https:\/\/([^.]+)\.r2\.cloudflarestorage\.com/",
                $endpoint,
                $matches,
            )
        ) {
            $account_id = $matches[1];
        }
        update_option("virastore_cfr2_account_id", $account_id);

        $access_key_raw = isset($_POST["cfr2_access_key"])
            ? wp_unslash($_POST["cfr2_access_key"])
            : "";
        $access_key = trim(wp_strip_all_tags($access_key_raw));
        $access_key = preg_replace("/\s+/", "", $access_key);
        update_option("virastore_cfr2_access_key_id", $access_key);

        $secret_key_raw = isset($_POST["cfr2_secret_key"])
            ? wp_unslash($_POST["cfr2_secret_key"])
            : "";
        $secret_key = trim(wp_strip_all_tags($secret_key_raw));
        $secret_key = preg_replace("/\s+/", "", $secret_key);
        update_option("virastore_cfr2_secret_access_key", $secret_key);

        $bucket_raw = isset($_POST["cfr2_bucket"])
            ? trim(wp_unslash($_POST["cfr2_bucket"]))
            : "";
        $bucket_name = preg_replace("/[^A-Za-z0-9\.-]/", "", $bucket_raw);
        update_option("virastore_cfr2_bucket_name", $bucket_name);

        $region_raw = isset($_POST["cfr2_region"])
            ? trim(wp_unslash($_POST["cfr2_region"]))
            : "auto";
        $allowed_regions = ["auto", "us-east-1", "eu-west-1", "ap-southeast-1"];
        $region = in_array($region_raw, $allowed_regions, true)
            ? $region_raw
            : "auto";
        update_option("virastore_cfr2_region", $region);

        update_option(
            "virastore_cfr2_use_private_bucket",
            isset($_POST["cfr2_use_private_bucket"]) ? "1" : "0",
        );
        $custom_domain_input = isset($_POST["cfr2_custom_domain"])
            ? trim(wp_unslash($_POST["cfr2_custom_domain"]))
            : "";
        update_option(
            "virastore_cfr2_custom_domain",
            esc_url_raw($custom_domain_input),
        );

        // Redirect back with success message
        wp_redirect(
            add_query_arg(
                [
                    "page" => "vrstore-cfr2-storage",
                    "cfr2_message" => "config_saved",
                ],
                admin_url("admin.php"),
            ),
        );
        exit();
    }

    /**
     * Handle configuration save (legacy method)
     */
    public function handle_config_save()
    {
        // Redirect to the new method
        $this->save_configuration();
    }
}
