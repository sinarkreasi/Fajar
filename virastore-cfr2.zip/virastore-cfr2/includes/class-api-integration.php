<?php
/**
 * API Integration Class for CFR2
 * 
 * Integrates R2 URLs into the plugin update API responses
 */

if (!defined('ABSPATH')) {
    exit;
}

class ViraStore_CFR2_API_Integration {
    
    private static $instance = null;
    private $file_manager;
    private static $products_table_exists = null;
    
    /**
     * Get single instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->file_manager = ViraStore_CFR2_File_Manager::get_instance();
        
        add_filter('vrstore_plugin_update_response', array($this, 'modify_update_response'), 10, 3);
        add_filter('vrstore_plugin_version_download_url', array($this, 'get_version_download_url'), 10, 3);
        add_action('vrstore_plugin_downloaded', array($this, 'track_download'), 10, 3);
    }
    
    /**
     * Initialize API integration hooks
     */
    public function init() {
        // Hook into the plugin update check response
        add_filter('rest_post_dispatch', array($this, 'filter_update_response'), 10, 3);
        
        // File manager is already initialized in constructor
        // $this->file_manager = new ViraStore_CFR2_File_Manager();
    }
    
    /**
     * Filter REST API responses to modify plugin update URLs
     */
    public function filter_update_response($response, $server, $request) {
        // Only process plugin update endpoints
        if (strpos($request->get_route(), '/vira-store/v1/updates/plugin') === false) {
            return $response;
        }
        
        // Only modify successful responses with updates available
        if (is_wp_error($response) || $response->get_status() !== 200) {
            return $response;
        }
        
        $data = $response->get_data();
        if (!isset($data['update_available']) || !$data['update_available']) {
            return $response;
        }
        
        return $this->modify_update_response($response, $request);
    }
    
    /**
     * Modify plugin update API response to use R2 URLs
     */
    public function modify_update_response($response, $request) {
        // Only modify successful responses
        if (is_wp_error($response) || $response->get_status() !== 200) {
            return $response;
        }
        
        $data = $response->get_data();
        
        // Only modify if update is available and we have a download URL
        if (!isset($data['update_available']) || !$data['update_available'] || !isset($data['download_url'])) {
            return $response;
        }
        
        // Extract token from the original download URL
        $download_url = $data['download_url'];
        $token = $this->extract_token_from_url($download_url);
        
        if (!$token) {
            return $response;
        }
        
        // Get R2 download URL
        $r2_url = $this->get_r2_download_url($token);
        
        if ($r2_url) {
            $data['download_url'] = $r2_url;
            $data['package'] = $r2_url;
            $response->set_data($data);
            
            // Track that we're serving from R2
            $this->track_r2_download($token);
        }
        
        return $response;
    }
    
    /**
     * Extract token from download URL
     */
    private function extract_token_from_url($url) {
        if (preg_match('/\/download\/([a-zA-Z0-9]+)$/', $url, $matches)) {
            return $matches[1];
        }
        return null;
    }
    
    /**
     * Get R2 download URL for token
     */
    private function get_r2_download_url($token) {
        global $wpdb;
        
        // Get token data
        $token_data = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}vrstore_update_tokens 
             WHERE token = %s AND expires_at > %s AND used_at IS NULL",
            $token,
            current_time('mysql')
        ));
        
        if (!$token_data) {
            return null;
        }
        
        // Get version data
        $version_data = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}vrstore_plugin_versions WHERE id = %d",
            $token_data->version_id
        ));
        
        if (!$version_data) {
            return null;
        }
        
        // Check if file exists in R2
        $r2_file = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}virastore_cfr2_files 
             WHERE plugin_id = %d AND version = %s",
            $token_data->product_id,
            $version_data->version
        ));
        
        if (!$r2_file) {
            return null;
        }
        
        // Generate R2 URL
        $r2_client = new ViraStore_CFR2_Client();
        if (!$r2_client->is_configured()) {
            return null;
        }
        
        // Use signed URL for private buckets
        $use_private_bucket = get_option('virastore_cfr2_use_private_bucket', '0') === '1';
        if ($use_private_bucket) {
            return $r2_client->generate_signed_url($r2_file->r2_key, 3600); // 1 hour expiry
        } else {
            return $r2_client->generate_public_url($r2_file->r2_key);
        }
    }
    
    /**
     * Track R2 download
     */
    private function track_r2_download($token) {
        global $wpdb;
        
        // Update download stats
        $wpdb->query($wpdb->prepare(
            "UPDATE {$wpdb->prefix}virastore_cfr2_files 
             SET download_count = download_count + 1, last_downloaded = %s 
             WHERE r2_key IN (
                 SELECT CONCAT('plugins/', p.post_name, '/', v.version, '/', v.file_name)
                 FROM {$wpdb->prefix}vrstore_update_tokens t
                 JOIN {$wpdb->prefix}vrstore_plugin_versions v ON t.version_id = v.id
                 JOIN {$wpdb->posts} p ON t.product_id = p.ID
                 WHERE t.token = %s
             )",
            current_time('mysql'),
            $token
        ));
    }
    
    /**
     * Get version download URL (with R2 priority)
     */
    public function get_version_download_url($url, $plugin_id, $version) {
        // Check if R2 is configured
        $r2_client = new ViraStore_CFR2_Client();
        if (!$r2_client->is_configured()) {
            return $url;
        }
        
        // Try to get R2 URL first
        $r2_url = $this->file_manager->get_file_url($plugin_id, $version);
        if ($r2_url) {
            return $r2_url;
        }
        
        // Fallback to original URL
        return $url;
    }
    
    /**
     * Track download statistics
     */
    public function track_download($plugin_id, $version, $user_id) {
        global $wpdb;
        
        // Check if this is an R2 download
        $r2_file = $wpdb->get_row($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}virastore_cfr2_files WHERE plugin_id = %d AND version = %s",
            $plugin_id,
            $version
        ));
        
        if (!$r2_file) {
            return;
        }
        
        // Log R2 download
        $wpdb->insert(
            $wpdb->prefix . 'virastore_cfr2_downloads',
            array(
                'file_id' => $r2_file->id,
                'plugin_id' => $plugin_id,
                'version' => $version,
                'user_id' => $user_id,
                'download_date' => current_time('mysql'),
                'ip_address' => $this->get_client_ip(),
                'user_agent' => substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255),
            ),
            array('%d', '%d', '%s', '%d', '%s', '%s', '%s')
        );
    }
    
    /**
     * Get plugin ID by slug
     */
    private function get_plugin_id_by_slug($slug) {
        global $wpdb;

        $slug = sanitize_title($slug);
        if (empty($slug)) {
            return null;
        }

        if ($this->products_table_exists()) {
            $plugin_id = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$wpdb->prefix}vrstore_products WHERE slug = %s AND type = 'plugin'",
                $slug
            ));

            if ($plugin_id) {
                return intval($plugin_id);
            }
        }

        $post = get_page_by_path($slug, OBJECT, 'vrstore_product');
        if ($post) {
            return intval($post->ID);
        }

        return null;
    }
    
    /**
     * Get client IP address
     */
    private function get_client_ip() {
        $ip_keys = array('HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'HTTP_CLIENT_IP', 'REMOTE_ADDR');
        
        foreach ($ip_keys as $key) {
            if (!empty($_SERVER[$key])) {
                $ip = $_SERVER[$key];
                if (strpos($ip, ',') !== false) {
                    $ip = trim(explode(',', $ip)[0]);
                }
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                    return $ip;
                }
            }
        }
        
        return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }
    
    /**
     * Create download tracking table
     */
    public static function create_downloads_table() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'virastore_cfr2_downloads';
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            file_id mediumint(9) NOT NULL,
            plugin_id mediumint(9) NOT NULL,
            version varchar(20) NOT NULL,
            user_id bigint(20) DEFAULT 0,
            download_date datetime DEFAULT CURRENT_TIMESTAMP,
            ip_address varchar(45) DEFAULT '',
            user_agent varchar(255) DEFAULT '',
            PRIMARY KEY (id),
            KEY file_id (file_id),
            KEY plugin_version (plugin_id, version),
            KEY download_date (download_date)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
    
    /**
     * Get download statistics
     */
    public function get_download_stats($plugin_id = null, $days = 30) {
        global $wpdb;
        
        $where_clause = "WHERE download_date >= DATE_SUB(NOW(), INTERVAL %d DAY)";
        $params = array($days);
        
        if ($plugin_id) {
            $where_clause .= " AND plugin_id = %d";
            $params[] = $plugin_id;
        }
        
        $stats = $wpdb->get_row($wpdb->prepare(
            "SELECT 
                COUNT(*) as total_downloads,
                COUNT(DISTINCT plugin_id) as unique_plugins,
                COUNT(DISTINCT user_id) as unique_users,
                COUNT(DISTINCT ip_address) as unique_ips
             FROM {$wpdb->prefix}virastore_cfr2_downloads 
             $where_clause",
            $params
        ));
        
        return array(
            'total_downloads' => intval($stats->total_downloads),
            'unique_plugins' => intval($stats->unique_plugins),
            'unique_users' => intval($stats->unique_users),
            'unique_ips' => intval($stats->unique_ips),
        );
    }
    
    /**
     * Get top downloaded plugins
     */
    public function get_top_downloads($limit = 10, $days = 30) {
        global $wpdb;

        if ($this->products_table_exists()) {
            $join = "LEFT JOIN {$wpdb->prefix}vrstore_products p ON d.plugin_id = p.id";
            $name_field = 'p.name as plugin_name';
        } else {
            $posts_table = $wpdb->posts;
            $join = "LEFT JOIN {$posts_table} p ON d.plugin_id = p.ID";
            $name_field = 'p.post_title as plugin_name';
        }

        $query = "SELECT 
                d.plugin_id,
                $name_field,
                COUNT(*) as download_count,
                COUNT(DISTINCT d.version) as version_count
             FROM {$wpdb->prefix}virastore_cfr2_downloads d
             $join
             WHERE d.download_date >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY d.plugin_id
             ORDER BY download_count DESC
             LIMIT %d";

        return $wpdb->get_results($wpdb->prepare($query, $days, $limit));
    }
    
    /**
     * Clean old download logs
     */
    public function cleanup_old_downloads($days = 90) {
        global $wpdb;
        
        $deleted = $wpdb->query($wpdb->prepare(
            "DELETE FROM {$wpdb->prefix}virastore_cfr2_downloads 
             WHERE download_date < DATE_SUB(NOW(), INTERVAL %d DAY)",
            $days
        ));
        
        return $deleted;
    }
    
    /**
     * Handle plugin update check
     */
    public function handle_update_check($plugin_file, $plugin_data) {
        // This method can be used to customize update check behavior
        // when using R2 storage
        
        $plugin_slug = dirname($plugin_file);
        $current_version = $plugin_data['Version'] ?? '1.0.0';
        
        // Check if there's a newer version in R2
        $plugin_id = $this->get_plugin_id_by_slug($plugin_slug);
        if (!$plugin_id) {
            return;
        }
        
        global $wpdb;
        $latest_version = $wpdb->get_var($wpdb->prepare(
            "SELECT version FROM {$wpdb->prefix}virastore_cfr2_files 
             WHERE plugin_id = %d 
             ORDER BY upload_date DESC 
             LIMIT 1",
            $plugin_id
        ));
        
        if ($latest_version && version_compare($latest_version, $current_version, '>')) {
            // Trigger update notification
            $this->trigger_update_notification($plugin_slug, $latest_version);
        }
    }

    /**
     * Determine if legacy products table exists
     */
    private function products_table_exists() {
        global $wpdb;

        if (self::$products_table_exists !== null) {
            return self::$products_table_exists;
        }

        $table_name = $wpdb->prefix . 'vrstore_products';
        $like = $wpdb->esc_like($table_name);
        $found = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $like));

        self::$products_table_exists = ($found === $table_name);

        return self::$products_table_exists;
    }
    
    /**
     * Trigger update notification
     */
    private function trigger_update_notification($plugin_slug, $version) {
        $transient_key = 'vrstore_cfr2_update_' . $plugin_slug;
        set_transient($transient_key, array(
            'version' => $version,
            'checked' => time(),
        ), HOUR_IN_SECONDS);
    }
}