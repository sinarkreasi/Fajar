<?php
/**
 * Cloudflare R2 Client Class
 *
 * Handles all interactions with Cloudflare R2 storage
 */

if (!defined("ABSPATH")) {
    exit();
}

class ViraStore_CFR2_Client
{
    private $account_id;
    private $access_key_id;
    private $secret_access_key;
    private $bucket_name;
    private $custom_domain;
    private $region;
    private $endpoint;
    private $last_error = "";

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->account_id = get_option("virastore_cfr2_account_id", "");
        $this->access_key_id = get_option("virastore_cfr2_access_key_id", "");
        $this->secret_access_key = get_option(
            "virastore_cfr2_secret_access_key",
            "",
        );
        $this->bucket_name = get_option("virastore_cfr2_bucket_name", "");
        $this->custom_domain = get_option("virastore_cfr2_custom_domain", "");
        $this->region = "auto"; // R2 always uses 'auto' region

        // R2 endpoint format - use the correct format for R2
        $this->endpoint = "https://{$this->account_id}.r2.cloudflarestorage.com";
    }

    /**
     * Check if R2 is properly configured
     */
    public function is_configured()
    {
        return !empty($this->account_id) &&
            !empty($this->access_key_id) &&
            !empty($this->secret_access_key) &&
            !empty($this->bucket_name);
    }

    /**
     * Test connection to R2
     */
    public function test_connection()
    {
        try {
            // Validate configuration first
            if (!$this->is_configured()) {
                $this->last_error = "Configuration incomplete";
                return false;
            }

            // Use simple unauthenticated test to verify connectivity
            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL => $this->endpoint . "/" . $this->bucket_name,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_NOBODY => true,
                CURLOPT_CONNECTTIMEOUT => 5,
                CURLOPT_TIMEOUT => 10,
                CURLOPT_SSL_VERIFYPEER => false, // Match working connection test
                CURLOPT_FOLLOWLOCATION => false,
                CURLOPT_USERAGENT => "ViraStore-CFR2-Test/1.0",
                CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4,
            ]);

            $result = curl_exec($ch);
            $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $error = curl_error($ch);
            curl_close($ch);

            if ($error) {
                $this->last_error = "Connection failed: " . $error;
                return false;
            }

            // HTTP 400 or 403 indicates we can reach R2 (expected without auth)
            // HTTP 200-299 would indicate success
            if ($http_code >= 200 && $http_code <= 499) {
                return true;
            }

            $this->last_error = "Unexpected HTTP response: " . $http_code;
            return false;
        } catch (Exception $e) {
            $this->last_error = "Exception: " . $e->getMessage();
            error_log("CFR2 Connection Test Failed: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Upload file to R2
     */
    public function upload_file(
        $file_path,
        $key,
        $content_type = "application/zip",
    ) {
        error_log("CFR2 R2Client Debug: Starting upload_file for key: $key");

        if (!file_exists($file_path)) {
            error_log("CFR2 R2Client Debug: File does not exist: $file_path");
            throw new Exception(__("File does not exist", "virastore-cfr2"));
        }

        // Validate configuration before attempting upload
        if (!$this->is_configured()) {
            error_log("CFR2 R2Client Debug: R2 client not configured");
            throw new Exception(
                __("R2 client is not properly configured. Please check your settings.", "virastore-cfr2"),
            );
        }

        $file_content = file_get_contents($file_path);
        if ($file_content === false) {
            error_log("CFR2 R2Client Debug: Could not read file: $file_path");
            throw new Exception(__("Could not read file", "virastore-cfr2"));
        }

        $file_size = strlen($file_content);
        error_log(
            "CFR2 R2Client Debug: File read successfully, size: " .
                $file_size .
                " bytes",
        );

        // Ensure key doesn't have leading slash (bucket name already includes it in path)
        $key = ltrim($key, "/");

        // Build the path for the request
        $request_path = "/" . $this->bucket_name . "/" . $key;
        
        error_log(
            "CFR2 R2Client Debug: Making PUT request to: " . $request_path . " (Content-Type: $content_type, Size: $file_size bytes)",
        );

        $headers = [
            "Content-Type" => $content_type,
            "Content-Length" => (string) $file_size,
        ];

        // Debug upload attempt
        error_log("CFR2 R2Client Debug: Attempting upload to R2 with bucket: " . $this->bucket_name);

        $response = $this->make_request(
            "PUT",
            $request_path,
            $file_content,
            $headers,
            120, // 2 minute timeout for large files
        );

        if ($response === false) {
            $error_msg = $this->get_last_error();
            error_log(
                "CFR2 R2Client Debug: make_request returned false, last error: " .
                    $error_msg,
            );
            throw new Exception(
                __("Failed to upload file to R2: ", "virastore-cfr2") . $error_msg,
            );
        }

        error_log("CFR2 R2Client Debug: Upload successful, response received");
        return $this->get_file_url($key);
    }

    /**
     * Delete file from R2
     */
    public function delete_file($key)
    {
        $response = $this->make_request(
            "DELETE",
            "/" . $this->bucket_name . "/" . $key,
        );
        return $response !== false;
    }

    /**
     * Get public URL for file
     */
    public function get_file_url($key)
    {
        if (!empty($this->custom_domain)) {
            return rtrim($this->custom_domain, "/") . "/" . ltrim($key, "/");
        }

        return $this->endpoint .
            "/" .
            $this->bucket_name .
            "/" .
            ltrim($key, "/");
    }

    /**
     * Generate public URL for file (alias for get_file_url)
     */
    public function generate_public_url($key)
    {
        return $this->get_file_url($key);
    }

    /**
     * Generate signed URL for private bucket access
     *
     * @param string $key Object key
     * @param int $expires Expiry time in seconds (default: 1 hour)
     * @return string|false Signed URL or false on failure
     */
    public function generate_signed_url($key, $expires = 3600)
    {
        if (!$this->is_configured()) {
            return false;
        }

        try {
            $endpoint = rtrim($this->endpoint, "/");
            $bucket = $this->bucket_name;
            $region = $this->region ?: "auto";

            // Use custom domain if available
            $custom_domain = get_option("virastore_cfr2_custom_domain", "");
            if (!empty($custom_domain)) {
                $host = parse_url($custom_domain, PHP_URL_HOST);
                $base_url = rtrim($custom_domain, "/");
            } else {
                $host = parse_url($endpoint, PHP_URL_HOST);
                $base_url = $endpoint;
            }

            $timestamp = time();

            // Create canonical request
            $method = "GET";
            $uri = "/" . $bucket . "/" . ltrim($key, "/");
            $query_params = [
                "X-Amz-Algorithm" => "AWS4-HMAC-SHA256",
                "X-Amz-Credential" =>
                    $this->access_key_id .
                    "/" .
                    date("Ymd", $timestamp) .
                    "/" .
                    $region .
                    "/s3/aws4_request",
                "X-Amz-Date" => gmdate("Ymd\THis\Z", $timestamp),
                "X-Amz-Expires" => $expires,
                "X-Amz-SignedHeaders" => "host",
            ];

            // Sort query parameters
            ksort($query_params);
            $canonical_query = http_build_query(
                $query_params,
                "",
                "&",
                PHP_QUERY_RFC3986,
            );

            // Create canonical headers
            $canonical_headers = "host:" . $host . "\n";
            $signed_headers = "host";

            // Create canonical request
            $canonical_request = implode("\n", [
                $method,
                $uri,
                $canonical_query,
                $canonical_headers,
                $signed_headers,
                "UNSIGNED-PAYLOAD",
            ]);

            // Create string to sign
            $algorithm = "AWS4-HMAC-SHA256";
            $credential_scope =
                date("Ymd", $timestamp) . "/" . $region . "/s3/aws4_request";
            $string_to_sign = implode("\n", [
                $algorithm,
                gmdate("Ymd\THis\Z", $timestamp),
                $credential_scope,
                hash("sha256", $canonical_request),
            ]);

            // Calculate signature
            $date_key = hash_hmac(
                "sha256",
                date("Ymd", $timestamp),
                "AWS4" . $this->secret_access_key,
                true,
            );
            $date_region_key = hash_hmac("sha256", $region, $date_key, true);
            $date_region_service_key = hash_hmac(
                "sha256",
                "s3",
                $date_region_key,
                true,
            );
            $signing_key = hash_hmac(
                "sha256",
                "aws4_request",
                $date_region_service_key,
                true,
            );
            $signature = hash_hmac("sha256", $string_to_sign, $signing_key);

            // Build final URL
            $query_params["X-Amz-Signature"] = $signature;
            $signed_url =
                $base_url .
                $uri .
                "?" .
                http_build_query($query_params, "", "&", PHP_QUERY_RFC3986);

            return $signed_url;
        } catch (Exception $e) {
            error_log("CFR2 Signed URL Error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * List files in bucket
     */
    public function list_files($prefix = "")
    {
        $path = "/" . $this->bucket_name . "/";
        if (!empty($prefix)) {
            $path .= "?prefix=" . urlencode($prefix);
        }

        $response = $this->make_request("GET", $path);

        if ($response === false) {
            return [];
        }

        // Parse XML response
        $xml = simplexml_load_string($response);
        $files = [];

        if ($xml && isset($xml->Contents)) {
            foreach ($xml->Contents as $content) {
                $files[] = [
                    "key" => (string) $content->Key,
                    "size" => (int) $content->Size,
                    "last_modified" => (string) $content->LastModified,
                ];
            }
        }

        return $files;
    }

    /**
     * Make authenticated request to R2
     */
    private function make_request(
        $method,
        $path,
        $body = "",
        $headers = [],
        $timeout = null,
    ) {
        $url = $this->endpoint . $path;
        $endpoint_host = parse_url($this->endpoint, PHP_URL_HOST);

        // Split path and query for canonical request
        $original_path = $path;
        $query_string = "";
        if (strpos($path, "?") !== false) {
            $parts = explode("?", $path, 2);
            $original_path = $parts[0];
            $query_string = $parts[1];
        }

        // For canonical request URI: URL encode each path segment (preserving slashes)
        // AWS S3/R2 requires each path segment to be individually URL-encoded
        $canonical_uri = $original_path;
        if (!empty($canonical_uri)) {
            // Split path into segments
            $uri_parts = explode("/", $canonical_uri);
            // Remove empty parts at the start/end from splitting
            $uri_parts = array_filter($uri_parts, function($part) {
                return $part !== '';
            });
            // URL encode each segment
            $encoded_parts = array_map(function($part) {
                return rawurlencode($part);
            }, $uri_parts);
            // Rebuild path with encoded segments
            $canonical_uri = "/" . implode("/", $encoded_parts);
        } else {
            $canonical_uri = "/";
        }

        // Prepare base headers
        $amz_date = gmdate("Ymd\THis\Z");
        $date_stamp = gmdate("Ymd");
        $payload = $body !== "" && $body !== null ? $body : "";

        // Calculate payload hash
        if (is_resource($payload)) {
            $payload_contents = stream_get_contents($payload);
            $payload_hash = hash("sha256", $payload_contents);
            $payload = $payload_contents;
        } else {
            $payload_hash = hash("sha256", $payload);
        }

        $base_headers = [
            "Host" => $endpoint_host,
            "x-amz-date" => $amz_date,
            "x-amz-content-sha256" => $payload_hash,
        ];

        // Merge caller headers - ensure base headers take precedence for critical headers
        $headers = array_merge($headers, $base_headers);

        if (
            $payload !== "" &&
            !isset($headers["Content-Length"]) &&
            !isset($headers["content-length"])
        ) {
            $headers["Content-Length"] = strlen($payload);
        }

        // Build canonical query
        $query_params = [];
        if (!empty($query_string)) {
            parse_str($query_string, $query_params);
        }
        ksort($query_params);
        $canonical_query = http_build_query(
            $query_params,
            "",
            "&",
            PHP_QUERY_RFC3986,
        );

        // Canonical headers (sorted) - R2 requires specific headers only
        $canonical_headers_map = [];
        foreach ($headers as $key => $value) {
            $lk = strtolower(trim($key));
            $lv = trim($value);

            // R2 requires only these headers in signature
            if ($lk === "host") {
                $canonical_headers_map[$lk] = $lv;
            } elseif ($lk === "x-amz-date") {
                $canonical_headers_map[$lk] = $lv;
            } elseif ($lk === "x-amz-content-sha256") {
                $canonical_headers_map[$lk] = $lv;
            }
            // Note: Content-Type and Content-Length are sent but not signed
        }

        ksort($canonical_headers_map);

        $signed_headers_keys = array_keys($canonical_headers_map);

        // Build canonical headers string with exact formatting
        $canonical_headers = "";
        foreach ($canonical_headers_map as $key => $value) {
            // Ensure single space after colon and no trailing spaces
            $canonical_headers .= $key . ":" . $value . "\n";
        }

        $signed_headers = implode(";", $signed_headers_keys);

        // Canonical request - use encoded URI
        $canonical_request = implode("\n", [
            strtoupper($method),
            $canonical_uri,
            $canonical_query,
            $canonical_headers,
            $signed_headers,
            $payload_hash,
        ]);

        // String to sign
        $algorithm = "AWS4-HMAC-SHA256";
        $region = "auto"; // R2 uses 'auto' region
        $service = "s3";
        $credential_scope =
            $date_stamp . "/" . $region . "/" . $service . "/aws4_request";

        $string_to_sign = implode("\n", [
            $algorithm,
            $amz_date,
            $credential_scope,
            hash("sha256", $canonical_request),
        ]);

        // Signing key derivation for R2
        $kSecret = "AWS4" . $this->secret_access_key;
        $kDate = hash_hmac("sha256", $date_stamp, $kSecret, true);
        $kRegion = hash_hmac("sha256", $region, $kDate, true);
        $kService = hash_hmac("sha256", $service, $kRegion, true);
        $kSigning = hash_hmac("sha256", "aws4_request", $kService, true);
        $signature = hash_hmac("sha256", $string_to_sign, $kSigning);

        // Authorization header with proper formatting
        $auth_header =
            $algorithm .
            " Credential=" .
            $this->access_key_id .
            "/" .
            $credential_scope .
            ", SignedHeaders=" .
            $signed_headers .
            ", Signature=" .
            $signature;

        $headers["Authorization"] = $auth_header;

        // Prepare cURL with R2-optimized settings
        $ch = curl_init();
        $connect_timeout = $timeout ? min($timeout / 2, 10) : 5;
        $total_timeout = $timeout ?: 60; // Increased timeout for file uploads

        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => $this->format_headers($headers),
            CURLOPT_CONNECTTIMEOUT => $connect_timeout,
            CURLOPT_TIMEOUT => $total_timeout,
            CURLOPT_SSL_VERIFYPEER => false, // Disable SSL verification to match working connection
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_USERAGENT => "ViraStore-CFR2/1.0",
            CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4,
            // Additional options for better connectivity
            CURLOPT_NOSIGNAL => true,
        ]);

        if ($payload !== "") {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        }

        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        $curl_info = curl_getinfo($ch);
        curl_close($ch);

        if ($error) {
            $this->last_error = "cURL Error: " . $error;
            error_log("CFR2 cURL Error: " . $error);
            return false;
        }

        if ($http_code >= 400) {
            // Parse XML error response from R2
            $error_message = "HTTP " . $http_code;
            if (!empty($response)) {
                // Try to parse XML error
                if (preg_match('/<Message>(.*?)<\/Message>/is', $response, $matches)) {
                    $error_message .= ": " . strip_tags($matches[1]);
                } elseif (preg_match('/<Error><Code>(.*?)<\/Code>/is', $response, $matches)) {
                    $error_message .= ": " . strip_tags($matches[1]);
                } else {
                    // If not XML, use first 500 chars of response
                    $error_message .= ": " . substr(strip_tags($response), 0, 500);
                }
            }
            $this->last_error = $error_message;
            error_log("CFR2 HTTP Error " . $http_code . ": " . $error_message);
            error_log("CFR2 Response: " . substr($response, 0, 1000));
            return false;
        }

        return $response;
    }

    /**
     * Get last error message from client
     */
    public function get_last_error()
    {
        return $this->last_error;
    }

    /**
     * Format headers for cURL
     */
    private function format_headers($headers)
    {
        $formatted = [];
        foreach ($headers as $key => $value) {
            $formatted[] = $key . ": " . $value;
        }
        return $formatted;
    }

    /**
     * Get configuration status
     */
    public function get_config_status()
    {
        $status = [
            "account_id" => !empty($this->account_id),
            "access_key_id" => !empty($this->access_key_id),
            "secret_access_key" => !empty($this->secret_access_key),
            "bucket_name" => !empty($this->bucket_name),
            "custom_domain" => !empty($this->custom_domain),
        ];

        $status["is_configured"] =
            $status["account_id"] &&
            $status["access_key_id"] &&
            $status["secret_access_key"] &&
            $status["bucket_name"];

        return $status;
    }

    /**
     * Test authenticated upload to R2 with a small test file
     */
    public function test_authenticated_upload()
    {
        try {
            // Create a small test content
            $test_content = "CFR2 Test File - " . date("Y-m-d H:i:s");
            $test_key = "test/cfr2-test-" . time() . ".txt";

            error_log("CFR2 Auth Test: Starting authenticated upload test");

            // Test upload using make_request directly
            $headers = [
                "Content-Type" => "text/plain",
                "Content-Length" => strlen($test_content),
            ];

            $response = $this->make_request(
                "PUT",
                "/" . $this->bucket_name . "/" . $test_key,
                $test_content,
                $headers,
                10, // Short timeout for test
            );

            if ($response === false) {
                error_log(
                    "CFR2 Auth Test: Upload failed - " .
                        $this->get_last_error(),
                );
                return false;
            }

            error_log(
                "CFR2 Auth Test: Upload successful, cleaning up test file",
            );

            // Clean up test file
            $this->make_request(
                "DELETE",
                "/" . $this->bucket_name . "/" . $test_key,
            );

            return true;
        } catch (Exception $e) {
            error_log("CFR2 Auth Test: Exception - " . $e->getMessage());
            return false;
        }
    }

    /**
     * Test R2 permissions with simple bucket listing
     */
    public function test_r2_permissions()
    {
        try {
            error_log("CFR2 Permissions Test: Starting bucket listing test");

            // Try to list bucket contents (minimal permissions test)
            $response = $this->make_request(
                "GET",
                "/" . $this->bucket_name . "/?list-type=2&max-keys=1",
                "",
                [],
                10,
            );

            if ($response !== false) {
                error_log("CFR2 Permissions Test: Bucket listing successful");
                return true;
            } else {
                error_log(
                    "CFR2 Permissions Test: Bucket listing failed - " .
                        $this->get_last_error(),
                );
                return false;
            }
        } catch (Exception $e) {
            error_log("CFR2 Permissions Test: Exception - " . $e->getMessage());
            return false;
        }
    }
}
