<?php
/**
 * Extensions Controller
 *
 * Handles extension management.
 *
 * @package ViraInsight\UI\Admin\Controllers
 */

declare(strict_types=1);

namespace ViraInsight\UI\Admin\Controllers;

use ViraInsight\Http\Controllers\BaseController;
use ViraInsight\Core\ExtensionManager;

class ExtensionsController extends BaseController
{
    /**
     * Extension manager
     */
    private ExtensionManager $manager;

    /**
     * Constructor
     */
    public function __construct()
    {
        parent::__construct();
        $this->manager = ExtensionManager::getInstance();
    }

    /**
     * Display extensions page
     */
    public function index(): void
    {
        if (!$this->checkCapability()) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'vira-insight'));
        }

        $this->render('admin.extensions.index', [
            'title' => __('Extensions', 'vira-insight'),
            'extensions' => $this->manager->getAll(),
            'active' => $this->manager->getActive(),
        ]);
    }

    /**
     * Install extension (REST endpoint)
     */
    public function install(\WP_REST_Request $request): \WP_REST_Response
    {
        if (!isset($_FILES['extension_file'])) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => __('No file uploaded.', 'vira-insight'),
            ], 400);
        }

        $file = $_FILES['extension_file'];
        $uploadedFile = $file['tmp_name'];

        $result = $this->manager->install($uploadedFile);

        return new \WP_REST_Response($result, $result['success'] ? 200 : 400);
    }

    /**
     * Activate extension (REST endpoint)
     */
    public function activate(\WP_REST_Request $request): \WP_REST_Response
    {
        $slug = sanitize_text_field($request->get_param('slug'));

        if (!$slug) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => __('Extension slug is required.', 'vira-insight'),
            ], 400);
        }

        $success = $this->manager->activate($slug);

        return new \WP_REST_Response([
            'success' => $success,
            'message' => $success
                ? __('Extension activated successfully.', 'vira-insight')
                : __('Failed to activate extension.', 'vira-insight'),
        ], $success ? 200 : 400);
    }

    /**
     * Deactivate extension (REST endpoint)
     */
    public function deactivate(\WP_REST_Request $request): \WP_REST_Response
    {
        $slug = sanitize_text_field($request->get_param('slug'));

        if (!$slug) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => __('Extension slug is required.', 'vira-insight'),
            ], 400);
        }

        $success = $this->manager->deactivate($slug);

        return new \WP_REST_Response([
            'success' => $success,
            'message' => $success
                ? __('Extension deactivated successfully.', 'vira-insight')
                : __('Failed to deactivate extension.', 'vira-insight'),
        ], $success ? 200 : 400);
    }

    /**
     * Uninstall extension (REST endpoint)
     */
    public function uninstall(\WP_REST_Request $request): \WP_REST_Response
    {
        $slug = sanitize_text_field($request->get_param('slug'));

        if (!$slug) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => __('Extension slug is required.', 'vira-insight'),
            ], 400);
        }

        $success = $this->manager->uninstall($slug);

        return new \WP_REST_Response([
            'success' => $success,
            'message' => $success
                ? __('Extension uninstalled successfully.', 'vira-insight')
                : __('Failed to uninstall extension.', 'vira-insight'),
        ], $success ? 200 : 400);
    }
}
