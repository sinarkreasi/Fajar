<?php
/**
 * Settings Controller
 *
 * Handles plugin settings.
 *
 * @package ViraInsight\UI\Admin\Controllers
 */

declare(strict_types=1);

namespace ViraInsight\UI\Admin\Controllers;

use ViraInsight\Http\Controllers\BaseController;

class SettingsController extends BaseController
{
    /**
     * Display settings page
     */
    public function index(): void
    {
        if (!$this->checkCapability()) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'vira-insight'));
        }

        $this->render('admin.settings.index', [
            'title' => __('Vira Insight Settings', 'vira-insight'),
            'settings' => get_option('vrin_settings', []),
        ]);
    }

    /**
     * Save settings (REST endpoint)
     */
    public function saveSettings(\WP_REST_Request $request): \WP_REST_Response
    {
        $settings = [
            'seo_enabled' => (bool) $request->get_param('seo_enabled'),
            'google_ads_enabled' => (bool) $request->get_param('google_ads_enabled'),
            'social_ads_enabled' => (bool) $request->get_param('social_ads_enabled'),
            'cache_enabled' => (bool) $request->get_param('cache_enabled'),
            'cache_ttl' => absint($request->get_param('cache_ttl') ?? 3600),
        ];

        update_option('vrin_settings', $settings);

        return new \WP_REST_Response([
            'success' => true,
            'message' => __('Settings saved successfully.', 'vira-insight'),
        ], 200);
    }

    /**
     * Get settings (REST endpoint)
     */
    public function getSettings(\WP_REST_Request $request): \WP_REST_Response
    {
        $settings = get_option('vrin_settings', []);

        return new \WP_REST_Response([
            'success' => true,
            'data' => $settings,
        ], 200);
    }
}
