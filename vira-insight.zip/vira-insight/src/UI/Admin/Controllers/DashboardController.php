<?php
/**
 * Dashboard Controller
 *
 * Handles main admin dashboard.
 *
 * @package ViraInsight\UI\Admin\Controllers
 */

declare(strict_types=1);

namespace ViraInsight\UI\Admin\Controllers;

use ViraInsight\Http\Controllers\BaseController;
use ViraInsight\Core\EventEmitter;

class DashboardController extends BaseController
{
    /**
     * Display main dashboard
     */
    public function index(): void
    {
        if (!$this->checkCapability()) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'vira-insight'));
        }

        // Get dashboard data
        $data = $this->getDashboardData();

        $this->render('admin.dashboard.index', [
            'title' => __('Vira Insight Dashboard', 'vira-insight'),
            'data' => $data,
        ]);
    }

    /**
     * Get dashboard data
     */
    private function getDashboardData(): array
    {
        global $wpdb;

        // Get recent SEO analyses
        $seoTable = $wpdb->prefix . 'vrin_seo_analysis';
        $recentSEO = [];

        // Check if table exists before querying
        $tableExists = $wpdb->get_var("SHOW TABLES LIKE '{$seoTable}'") === $seoTable;

        if ($tableExists) {
            $results = $wpdb->get_results(
                "SELECT * FROM {$seoTable} ORDER BY created_at DESC LIMIT 5",
                ARRAY_A
            );
            $recentSEO = $results ?? [];
        }

        // Get settings
        $settings = get_option('vrin_settings', []);

        // Get total posts
        $postCounts = wp_count_posts();
        $totalPosts = isset($postCounts->publish) ? $postCounts->publish : 0;

        return [
            'recent_seo_analyses' => $recentSEO,
            'seo_enabled' => $settings['seo_enabled'] ?? true,
            'google_ads_enabled' => $settings['google_ads_enabled'] ?? true,
            'social_ads_enabled' => $settings['social_ads_enabled'] ?? true,
            'total_posts' => $totalPosts,
            'active_extensions' => count(\ViraInsight\Core\ExtensionManager::getInstance()->getActive()),
        ];
    }

    /**
     * Register admin menu
     */
    public static function registerMenu(): void
    {
        add_menu_page(
            __('Vira Insight', 'vira-insight'),
            __('Vira Insight', 'vira-insight'),
            'manage_options',
            'vira-insight',
            [self::class, 'renderDashboard'],
            'dashicons-analytics',
            30
        );

        add_submenu_page(
            'vira-insight',
            __('Dashboard', 'vira-insight'),
            __('Dashboard', 'vira-insight'),
            'manage_options',
            'vira-insight',
            [self::class, 'renderDashboard']
        );

        add_submenu_page(
            'vira-insight',
            __('Settings', 'vira-insight'),
            __('Settings', 'vira-insight'),
            'manage_options',
            'vira-insight-settings',
            [self::class, 'renderSettings']
        );
    }

    /**
     * Render dashboard
     */
    public static function renderDashboard(): void
    {
        $controller = new self();
        $controller->index();
    }

    /**
     * Render settings
     */
    public static function renderSettings(): void
    {
        $controller = new SettingsController();
        $controller->index();
    }

    /**
     * Enqueue admin assets
     */
    public static function enqueueAssets(): void
    {
        $screen = get_current_screen();

        // Check if we're on a Vira Insight page
        $isViraInsightPage = false;

        if ($screen) {
            // Check screen ID
            $isViraInsightPage = strpos($screen->id, 'vira-insight') !== false ||
                                 strpos($screen->id, 'toplevel_page_vira-insight') !== false;
        }

        // Also check the page parameter
        if (!$isViraInsightPage && isset($_GET['page'])) {
            $isViraInsightPage = strpos($_GET['page'], 'vira-insight') !== false;
        }

        if (!$isViraInsightPage) {
            return;
        }

        // Enqueue styles
        wp_enqueue_style(
            'vrin-admin',
            VRIN_PLUGIN_URL . 'assets/build/admin.css',
            [],
            VRIN_VERSION
        );

        // Enqueue scripts
        wp_enqueue_script(
            'vrin-admin',
            VRIN_PLUGIN_URL . 'assets/build/admin.js',
            ['jquery', 'wp-api'],
            VRIN_VERSION,
            true
        );

        // Localize script
        wp_localize_script('vrin-admin', 'vrinData', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'restUrl' => rest_url('vira-insight/v1'),
            'nonce' => wp_create_nonce('wp_rest'),
        ]);
    }
}
