<?php

namespace ViraInsight\Contracts;

interface ServiceInterface
{
    public function handle(array $payload);
}
