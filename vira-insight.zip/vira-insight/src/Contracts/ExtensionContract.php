<?php

namespace ViraInsight\Contracts;

interface ExtensionContract
{
    public function boot();
    public function register();
    public function info(): array;
}
