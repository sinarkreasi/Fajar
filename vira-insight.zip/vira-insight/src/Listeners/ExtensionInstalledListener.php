<?php
/**
 * Extension Installed Listener
 *
 * @package ViraInsight\Listeners
 */

declare(strict_types=1);

namespace ViraInsight\Listeners;

class ExtensionInstalledListener
{
    /**
     * Handle the event
     */
    public function handle($payload): void
    {
        $slug = $payload['slug'] ?? 'unknown';
        error_log("Extension installed: {$slug}");
    }
}
