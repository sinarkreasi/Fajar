<?php
/**
 * SEO Analysis Completed Listener
 *
 * @package ViraInsight\Listeners
 */

declare(strict_types=1);

namespace ViraInsight\Listeners;

class SEOAnalysisCompletedListener
{
    /**
     * Handle the event
     */
    public function handle($payload): void
    {
        // Log analysis completion
        $postId = $payload['post_id'] ?? 0;
        error_log("SEO analysis completed for post: {$postId}");
    }
}
