<?php
/**
 * Analytics Synced Listener
 *
 * @package ViraInsight\Listeners
 */

declare(strict_types=1);

namespace ViraInsight\Listeners;

class AnalyticsSyncedListener
{
    /**
     * Handle the event
     */
    public function handle($payload): void
    {
        // Log sync completion
        error_log('Analytics data synced');
    }
}
