<?php
/**
 * Plugin Deactivated Listener
 *
 * @package ViraInsight\Listeners
 */

declare(strict_types=1);

namespace ViraInsight\Listeners;

class PluginDeactivatedListener
{
    /**
     * Handle the event
     */
    public function handle($payload): void
    {
        // Log deactivation
        error_log('Vira Insight plugin deactivated');
    }
}
