<?php
/**
 * Extension Activated Listener
 *
 * @package ViraInsight\Listeners
 */

declare(strict_types=1);

namespace ViraInsight\Listeners;

class ExtensionActivatedListener
{
    /**
     * Handle the event
     */
    public function handle($payload): void
    {
        $slug = $payload['slug'] ?? 'unknown';
        error_log("Extension activated: {$slug}");

        // Clear cache
        \ViraInsight\Core\Cache::getInstance()->flush();
    }
}
