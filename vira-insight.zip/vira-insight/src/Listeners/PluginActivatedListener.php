<?php
/**
 * Plugin Activated Listener
 *
 * @package ViraInsight\Listeners
 */

declare(strict_types=1);

namespace ViraInsight\Listeners;

class PluginActivatedListener
{
    /**
     * Handle the event
     */
    public function handle($payload): void
    {
        // Log activation
        error_log('Vira Insight plugin activated');

        // Clear cache
        \ViraInsight\Core\Cache::getInstance()->flush();
    }
}
