<?php
/**
 * Nonce Middleware
 *
 * Validates nonces for requests.
 *
 * @package ViraInsight\Http\Middleware
 */

declare(strict_types=1);

namespace ViraInsight\Http\Middleware;

class NonceMiddleware
{
    /**
     * Handle the request
     */
    public function handle(\WP_REST_Request $request): bool
    {
        $nonce = $request->get_header('X-WP-Nonce');

        if (!$nonce) {
            return false;
        }

        return wp_verify_nonce($nonce, 'wp_rest');
    }
}
