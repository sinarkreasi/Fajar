<?php
/**
 * Router
 *
 * Handles REST API and admin route registration.
 *
 * @package ViraInsight\Http\Routing
 */

declare(strict_types=1);

namespace ViraInsight\Http\Routing;

class Router
{
    /**
     * REST API namespace
     */
    private string $namespace = 'vira-insight/v1';

    /**
     * Routes
     */
    private array $routes = [];

    /**
     * Register a GET route
     */
    public function get(string $route, $callback, array $args = []): void
    {
        $this->addRoute('GET', $route, $callback, $args);
    }

    /**
     * Register a POST route
     */
    public function post(string $route, $callback, array $args = []): void
    {
        $this->addRoute('POST', $route, $callback, $args);
    }

    /**
     * Register a PUT route
     */
    public function put(string $route, $callback, array $args = []): void
    {
        $this->addRoute('PUT', $route, $callback, $args);
    }

    /**
     * Register a DELETE route
     */
    public function delete(string $route, $callback, array $args = []): void
    {
        $this->addRoute('DELETE', $route, $callback, $args);
    }

    /**
     * Add a route
     */
    private function addRoute(string $method, string $route, $callback, array $args): void
    {
        $this->routes[] = [
            'method' => $method,
            'route' => $route,
            'callback' => $callback,
            'args' => $args,
        ];
    }

    /**
     * Register all routes with WordPress
     */
    public function register(): void
    {
        foreach ($this->routes as $route) {
            register_rest_route($this->namespace, $route['route'], [
                'methods' => $route['method'],
                'callback' => $route['callback'],
                'args' => $route['args'],
                'permission_callback' => function () {
                    return current_user_can('manage_options');
                },
            ]);
        }
    }

    /**
     * Get all registered routes
     */
    public function getRoutes(): array
    {
        return $this->routes;
    }

    /**
     * Set namespace
     */
    public function setNamespace(string $namespace): void
    {
        $this->namespace = $namespace;
    }

    /**
     * Get namespace
     */
    public function getNamespace(): string
    {
        return $this->namespace;
    }
}
