<?php

namespace ViraInsight\Http\Responses;

class BaseResponse
{
    protected mixed $data = null;
    protected int   $status = 200;
    protected array $headers = [];

    public function __construct($data = null, int $status = 200, array $headers = [])
    {
        $this->data    = $data;
        $this->status  = $status;
        $this->headers = $headers;
    }

    /**
     * For API endpoints — return JSON
     */
    public function json(): void
    {
        $this->applyHeaders([
            'Content-Type' => 'application/json; charset=utf-8',
        ]);

        status_header($this->status);

        echo wp_json_encode($this->data);
        exit;
    }

    /**
     * For Admin rendering using View engine
     */
    public function view(string $view, array $params = []): void
    {
        $this->applyHeaders(['Content-Type' => 'text/html; charset=utf-8']);

        status_header($this->status);

        $viewClass = new \ViraInsight\Core\View();
        echo $viewClass->render($view, $params);
        exit;
    }

    /**
     * Add headers
     */
    protected function applyHeaders(array $headers = []): void
    {
        $headers = array_merge($this->headers, $headers);

        foreach ($headers as $key => $value) {
            header("{$key}: {$value}");
        }
    }
}
