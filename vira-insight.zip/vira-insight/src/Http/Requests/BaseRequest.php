<?php

namespace ViraInsight\Http\Requests;

abstract class BaseRequest
{
    protected array $data = [];
    protected array $rules = [];
    protected bool  $verifyNonce = false;
    protected bool  $verifyPermission = false;
    protected string $nonceAction = '';
    protected string $permission = '';

    public function __construct()
    {
        $this->data = $this->sanitize($_REQUEST);
        $this->boot();
        $this->validate();
        $this->checkSecurity();
    }

    /**
     * Boot method for child classes.
     */
    protected function boot(): void
    {
        // override in child request
    }

    /**
     * Sanitize incoming data recursively.
     */
    protected function sanitize(array $input): array
    {
        $clean = [];

        foreach ($input as $key => $value) {
            if (is_array($value)) {
                $clean[$key] = $this->sanitize($value);
            } else {
                $clean[$key] = sanitize_text_field($value);
            }
        }

        return $clean;
    }

    /**
     * Simple key->rule validator (extend as needed).
     */
    protected function validate(): void
    {
        foreach ($this->rules as $field => $rule) {
            if ($rule === 'required' && empty($this->data[$field])) {
                throw new \Exception("Field '{$field}' is required.");
            }
        }
    }

    /**
     * Nonce & Permission Checks (if enabled).
     */
    protected function checkSecurity(): void
    {
        if ($this->verifyNonce && $this->nonceAction) {
            if (!isset($this->data['_wpnonce']) ||
                !wp_verify_nonce($this->data['_wpnonce'], $this->nonceAction)
            ) {
                throw new \Exception("Security check failed (invalid nonce).");
            }
        }

        if ($this->verifyPermission && $this->permission) {
            if (!current_user_can($this->permission)) {
                throw new \Exception("You don't have permission to perform this action.");
            }
        }
    }

    /**
     * Accessor for a field
     */
    public function get(string $key, $default = null)
    {
        return $this->data[$key] ?? $default;
    }

    /**
     * Return sanitized payload.
     */
    public function all(): array
    {
        return $this->data;
    }
}
