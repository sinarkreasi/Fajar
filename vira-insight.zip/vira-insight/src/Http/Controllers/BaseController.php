<?php
/**
 * Base Controller
 *
 * All controllers should extend this class.
 *
 * @package ViraInsight\Http\Controllers
 */

declare(strict_types=1);

namespace ViraInsight\Http\Controllers;

use ViraInsight\Core\View;
use ViraInsight\Core\Cache;

abstract class BaseController
{
    /**
     * View instance
     */
    protected View $view;

    /**
     * Cache instance
     */
    protected Cache $cache;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->view = new View();
        $this->cache = Cache::getInstance();
    }

    /**
     * Render a view
     */
    protected function render(string $view, array $data = []): void
    {
        $this->view->render($view, $data);
    }

    /**
     * Return JSON response
     */
    protected function json($data, int $status = 200): void
    {
        wp_send_json($data, $status);
    }

    /**
     * Return success response
     */
    protected function success($data = [], string $message = 'Success'): void
    {
        $this->json([
            'success' => true,
            'message' => $message,
            'data' => $data,
        ]);
    }

    /**
     * Return error response
     */
    protected function error(string $message = 'Error', int $status = 400): void
    {
        $this->json([
            'success' => false,
            'message' => $message,
        ], $status);
    }

    /**
     * Check if user has capability
     */
    protected function checkCapability(string $capability = 'manage_options'): bool
    {
        return current_user_can($capability);
    }

    /**
     * Verify nonce
     */
    protected function verifyNonce(string $nonce, string $action): bool
    {
        return wp_verify_nonce($nonce, $action);
    }

    /**
     * Sanitize input
     */
    protected function sanitize($input, string $type = 'text')
    {
        switch ($type) {
            case 'email':
                return sanitize_email($input);
            case 'url':
                return esc_url_raw($input);
            case 'textarea':
                return sanitize_textarea_field($input);
            case 'html':
                return wp_kses_post($input);
            case 'text':
            default:
                return sanitize_text_field($input);
        }
    }
}
