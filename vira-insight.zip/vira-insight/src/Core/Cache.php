<?php
/**
 * Cache Manager
 *
 * Unified caching layer supporting transients, object cache, and file cache.
 *
 * @package ViraInsight\Core
 */

declare(strict_types=1);

namespace ViraInsight\Core;

class Cache
{
    /**
     * Singleton instance
     */
    private static ?self $instance = null;

    /**
     * Cache driver
     */
    private string $driver = 'transient';

    /**
     * Cache prefix
     */
    private string $prefix = 'vrin_cache_';

    /**
     * Default TTL
     */
    private int $defaultTtl = 3600;

    /**
     * Private constructor
     */
    private function __construct()
    {
        $kernel = Kernel::getInstance();
        $this->driver = $kernel->getConfig('cache.driver', 'transient');
        $this->prefix = $kernel->getConfig('cache.prefix', 'vrin_cache_');
        $this->defaultTtl = $kernel->getConfig('cache.ttl', 3600);
    }

    /**
     * Get instance
     */
    public static function getInstance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Get cached value
     *
     * @param string $key Cache key
     * @param mixed $default Default value if not found
     * @return mixed
     */
    public function get(string $key, $default = null)
    {
        $key = $this->prefix . $key;

        switch ($this->driver) {
            case 'object':
                $value = wp_cache_get($key, 'vira_insight');
                return $value !== false ? $value : $default;

            case 'file':
                return $this->getFromFile($key, $default);

            case 'transient':
            default:
                $value = get_transient($key);
                return $value !== false ? $value : $default;
        }
    }

    /**
     * Set cached value
     *
     * @param string $key Cache key
     * @param mixed $value Value to cache
     * @param int|null $ttl Time to live in seconds
     * @return bool
     */
    public function set(string $key, $value, ?int $ttl = null): bool
    {
        $key = $this->prefix . $key;
        $ttl = $ttl ?? $this->defaultTtl;

        switch ($this->driver) {
            case 'object':
                return wp_cache_set($key, $value, 'vira_insight', $ttl);

            case 'file':
                return $this->setToFile($key, $value, $ttl);

            case 'transient':
            default:
                return set_transient($key, $value, $ttl);
        }
    }

    /**
     * Delete cached value
     *
     * @param string $key Cache key
     * @return bool
     */
    public function delete(string $key): bool
    {
        $key = $this->prefix . $key;

        switch ($this->driver) {
            case 'object':
                return wp_cache_delete($key, 'vira_insight');

            case 'file':
                return $this->deleteFromFile($key);

            case 'transient':
            default:
                return delete_transient($key);
        }
    }

    /**
     * Check if key exists
     *
     * @param string $key Cache key
     * @return bool
     */
    public function has(string $key): bool
    {
        return $this->get($key) !== null;
    }

    /**
     * Remember a value (get or set)
     *
     * @param string $key Cache key
     * @param int|null $ttl Time to live
     * @param callable $callback Callback to get value if not cached
     * @return mixed
     */
    public function remember(string $key, ?int $ttl, callable $callback)
    {
        $value = $this->get($key);

        if ($value !== null) {
            return $value;
        }

        $value = $callback();
        $this->set($key, $value, $ttl);

        return $value;
    }

    /**
     * Flush all cache
     *
     * @return bool
     */
    public function flush(): bool
    {
        switch ($this->driver) {
            case 'object':
                return wp_cache_flush();

            case 'file':
                return $this->flushFiles();

            case 'transient':
            default:
                global $wpdb;
                $wpdb->query(
                    $wpdb->prepare(
                        "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
                        '_transient_' . $this->prefix . '%'
                    )
                );
                return true;
        }
    }

    /**
     * Get from file cache
     */
    private function getFromFile(string $key, $default)
    {
        $file = VRIN_PLUGIN_DIR . 'storage/cache/' . md5($key) . '.cache';

        if (!file_exists($file)) {
            return $default;
        }

        $data = unserialize(file_get_contents($file));

        if ($data['expires'] < time()) {
            unlink($file);
            return $default;
        }

        return $data['value'];
    }

    /**
     * Set to file cache
     */
    private function setToFile(string $key, $value, int $ttl): bool
    {
        $file = VRIN_PLUGIN_DIR . 'storage/cache/' . md5($key) . '.cache';

        $data = [
            'value' => $value,
            'expires' => time() + $ttl,
        ];

        return file_put_contents($file, serialize($data)) !== false;
    }

    /**
     * Delete from file cache
     */
    private function deleteFromFile(string $key): bool
    {
        $file = VRIN_PLUGIN_DIR . 'storage/cache/' . md5($key) . '.cache';

        if (file_exists($file)) {
            return unlink($file);
        }

        return false;
    }

    /**
     * Flush file cache
     */
    private function flushFiles(): bool
    {
        $files = glob(VRIN_PLUGIN_DIR . 'storage/cache/*.cache');

        foreach ($files as $file) {
            if (is_file($file)) {
                unlink($file);
            }
        }

        return true;
    }
}
