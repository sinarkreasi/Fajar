<?php
/**
 * Service Provider Base Class
 *
 * All service providers should extend this class.
 *
 * @package ViraInsight\Core
 */

declare(strict_types=1);

namespace ViraInsight\Core;

abstract class ServiceProvider
{
    /**
     * Service container
     */
    protected Container $container;

    /**
     * Constructor
     */
    public function __construct(Container $container)
    {
        $this->container = $container;
    }

    /**
     * Register services
     *
     * This method is called when the provider is registered.
     * Use it to bind services into the container.
     */
    abstract public function register(): void;

    /**
     * Boot services
     *
     * This method is called after all providers have been registered.
     * Use it to perform actions that depend on other services.
     */
    public function boot(): void
    {
        // Optional implementation
    }

    /**
     * Get configuration value
     */
    protected function config(string $key, $default = null)
    {
        $kernel = Kernel::getInstance();
        return $kernel->getConfig($key, $default);
    }

    /**
     * Register WordPress hooks
     */
    protected function addAction(string $hook, callable $callback, int $priority = 10, int $accepted_args = 1): void
    {
        add_action($hook, $callback, $priority, $accepted_args);
    }

    /**
     * Register WordPress filters
     */
    protected function addFilter(string $hook, callable $callback, int $priority = 10, int $accepted_args = 1): void
    {
        add_filter($hook, $callback, $priority, $accepted_args);
    }
}
