<?php
/**
 * Extension Manager
 *
 * Manages discovery, installation, activation, and validation of extensions.
 *
 * @package ViraInsight\Core
 */

declare(strict_types=1);

namespace ViraInsight\Core;

use ViraInsight\Core\EventEmitter;

class ExtensionManager
{
    /**
     * Singleton instance
     */
    private static ?self $instance = null;

    /**
     * Extensions directory
     */
    private string $extensionsPath;

    /**
     * Discovered extensions
     */
    private array $extensions = [];

    /**
     * Active extensions
     */
    private array $active = [];

    /**
     * Private constructor
     */
    private function __construct()
    {
        $this->extensionsPath = VRIN_PLUGIN_DIR . 'extensions/';

        // Load active extensions from options
        $this->active = get_option('vrin_active_extensions', []);
    }

    /**
     * Get instance
     */
    public static function getInstance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Discover all extensions
     */
    public function discover(): void
    {
        if (!is_dir($this->extensionsPath)) {
            return;
        }

        $dirs = scandir($this->extensionsPath);

        foreach ($dirs as $dir) {
            if ($dir === '.' || $dir === '..') {
                continue;
            }

            $extensionPath = $this->extensionsPath . $dir;

            if (!is_dir($extensionPath)) {
                continue;
            }

            $manifestPath = $extensionPath . '/manifest.json';

            if (!file_exists($manifestPath)) {
                continue;
            }

            $manifest = $this->loadManifest($manifestPath);

            if ($manifest) {
                $this->extensions[$dir] = [
                    'path' => $extensionPath,
                    'manifest' => $manifest,
                    'slug' => $dir,
                ];
            }
        }
    }

    /**
     * Load active extensions
     */
    public function loadActive(): void
    {
        foreach ($this->active as $slug) {
            if (isset($this->extensions[$slug])) {
                $this->loadExtension($slug);
            }
        }
    }

    /**
     * Load an extension
     */
    private function loadExtension(string $slug): void
    {
        $extension = $this->extensions[$slug] ?? null;

        if (!$extension) {
            return;
        }

        $manifest = $extension['manifest'];
        $entryPoint = $extension['path'] . '/' . $manifest['entry_point'];

        if (!file_exists($entryPoint)) {
            return;
        }

        // Load the extension
        require_once $entryPoint;

        // Initialize the extension class
        $className = $manifest['namespace'] . '\\Extension';

        if (class_exists($className)) {
            $instance = new $className();

            if (method_exists($instance, 'boot')) {
                $instance->boot();
            }
        }

        // Fire event
        EventEmitter::getInstance()->dispatch('extension.loaded', ['slug' => $slug]);
    }

    /**
     * Install extension from ZIP
     *
     * @param string $zipPath Path to ZIP file
     * @return array Result with success/error
     */
    public function install(string $zipPath): array
    {
        // Validate ZIP file
        if (!file_exists($zipPath)) {
            return ['success' => false, 'message' => 'ZIP file not found.'];
        }

        // Check MIME type
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($finfo, $zipPath);
        finfo_close($finfo);

        if ($mimeType !== 'application/zip') {
            return ['success' => false, 'message' => 'Invalid file type. Only ZIP files are allowed.'];
        }

        // Extract ZIP
        $zip = new \ZipArchive();
        if ($zip->open($zipPath) !== true) {
            return ['success' => false, 'message' => 'Failed to open ZIP file.'];
        }

        // Get the extension directory name from ZIP
        $slug = $this->getSlugFromZip($zip);

        if (!$slug) {
            $zip->close();
            return ['success' => false, 'message' => 'Invalid extension structure.'];
        }

        $extractPath = $this->extensionsPath . $slug;

        // Check if extension already exists
        if (is_dir($extractPath)) {
            $zip->close();
            return ['success' => false, 'message' => 'Extension already installed.'];
        }

        // Extract
        $zip->extractTo($this->extensionsPath);
        $zip->close();

        // Validate manifest
        $manifestPath = $extractPath . '/manifest.json';
        if (!file_exists($manifestPath)) {
            $this->removeDirectory($extractPath);
            return ['success' => false, 'message' => 'Extension manifest not found.'];
        }

        $manifest = $this->loadManifest($manifestPath);
        if (!$manifest) {
            $this->removeDirectory($extractPath);
            return ['success' => false, 'message' => 'Invalid extension manifest.'];
        }

        // Scan for dangerous files
        if (!$this->scanExtension($extractPath)) {
            $this->removeDirectory($extractPath);
            return ['success' => false, 'message' => 'Extension contains prohibited files.'];
        }

        // Validate license (if required)
        if (!$this->validateLicense($manifest)) {
            $this->removeDirectory($extractPath);
            return ['success' => false, 'message' => 'Invalid or missing license.'];
        }

        // Add to discovered extensions
        $this->extensions[$slug] = [
            'path' => $extractPath,
            'manifest' => $manifest,
            'slug' => $slug,
        ];

        // Fire event
        EventEmitter::getInstance()->dispatch('extension.installed', ['slug' => $slug]);

        return ['success' => true, 'message' => 'Extension installed successfully.', 'slug' => $slug];
    }

    /**
     * Activate an extension
     */
    public function activate(string $slug): bool
    {
        if (!isset($this->extensions[$slug])) {
            return false;
        }

        if (in_array($slug, $this->active)) {
            return true;
        }

        $this->active[] = $slug;
        update_option('vrin_active_extensions', $this->active);

        // Load the extension
        $this->loadExtension($slug);

        // Fire event
        EventEmitter::getInstance()->dispatch('extension.activated', ['slug' => $slug]);

        return true;
    }

    /**
     * Deactivate an extension
     */
    public function deactivate(string $slug): bool
    {
        $key = array_search($slug, $this->active);

        if ($key === false) {
            return false;
        }

        unset($this->active[$key]);
        $this->active = array_values($this->active);
        update_option('vrin_active_extensions', $this->active);

        // Fire event
        EventEmitter::getInstance()->dispatch('extension.deactivated', ['slug' => $slug]);

        return true;
    }

    /**
     * Uninstall an extension
     */
    public function uninstall(string $slug): bool
    {
        if (!isset($this->extensions[$slug])) {
            return false;
        }

        // Deactivate first
        $this->deactivate($slug);

        // Remove directory
        $extensionPath = $this->extensions[$slug]['path'];
        $this->removeDirectory($extensionPath);

        // Remove from extensions list
        unset($this->extensions[$slug]);

        return true;
    }

    /**
     * Get all extensions
     */
    public function getAll(): array
    {
        return $this->extensions;
    }

    /**
     * Get active extensions
     */
    public function getActive(): array
    {
        return $this->active;
    }

    /**
     * Check if extension is active
     */
    public function isActive(string $slug): bool
    {
        return in_array($slug, $this->active);
    }

    /**
     * Load manifest file
     */
    private function loadManifest(string $path): ?array
    {
        $content = file_get_contents($path);
        $manifest = json_decode($content, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            return null;
        }

        // Validate required fields
        $required = ['name', 'version', 'description', 'author', 'namespace', 'entry_point'];

        foreach ($required as $field) {
            if (!isset($manifest[$field])) {
                return null;
            }
        }

        return $manifest;
    }

    /**
     * Get slug from ZIP
     */
    private function getSlugFromZip(\ZipArchive $zip): ?string
    {
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $filename = $zip->getNameIndex($i);
            if (strpos($filename, 'manifest.json') !== false) {
                $parts = explode('/', $filename);
                return $parts[0];
            }
        }

        return null;
    }

    /**
     * Scan extension for dangerous files
     */
    private function scanExtension(string $path): bool
    {
        $blockedExtensions = ['exe', 'sh', 'bat', 'cmd'];

        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($path)
        );

        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $extension = strtolower($file->getExtension());

                if (in_array($extension, $blockedExtensions)) {
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * Validate extension license
     */
    private function validateLicense(array $manifest): bool
    {
        // For free extensions
        if (!isset($manifest['license_key'])) {
            return true;
        }

        // Call VR Store API
        $apiUrl = 'https://store.virainsight.com/api/v1/licenses/validate';

        $response = wp_remote_post($apiUrl, [
            'body' => [
                'license_key' => $manifest['license_key'],
                'product_id' => $manifest['product_id'] ?? '',
                'domain' => get_site_url(),
            ],
            'timeout' => 10,
        ]);

        if (is_wp_error($response)) {
            return false;
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        return isset($data['valid']) && $data['valid'] === true;
    }

    /**
     * Remove directory recursively
     */
    private function removeDirectory(string $dir): bool
    {
        if (!is_dir($dir)) {
            return false;
        }

        $files = array_diff(scandir($dir), ['.', '..']);

        foreach ($files as $file) {
            $path = $dir . '/' . $file;

            if (is_dir($path)) {
                $this->removeDirectory($path);
            } else {
                unlink($path);
            }
        }

        return rmdir($dir);
    }
}
