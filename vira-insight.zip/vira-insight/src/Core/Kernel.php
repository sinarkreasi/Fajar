<?php
/**
 * Application Kernel
 *
 * The kernel is responsible for bootstrapping the application,
 * loading service providers, and managing the application lifecycle.
 *
 * @package ViraInsight\Core
 */

declare(strict_types=1);

namespace ViraInsight\Core;

use ViraInsight\Core\Container;
use ViraInsight\Core\EventEmitter;
use ViraInsight\Core\ExtensionManager;

class Kernel
{
    /**
     * Singleton instance
     */
    private static ?self $instance = null;

    /**
     * Service container
     */
    private Container $container;

    /**
     * Booted status
     */
    private bool $booted = false;

    /**
     * Service providers
     */
    private array $providers = [];

    /**
     * Configuration
     */
    private array $config = [];

    /**
     * Private constructor
     */
    private function __construct()
    {
        $this->container = Container::getInstance();
        $this->loadConfiguration();
    }

    /**
     * Get kernel instance
     */
    public static function getInstance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Boot the kernel
     */
    public function boot(): void
    {
        if ($this->booted) {
            return;
        }

        // Register core services
        $this->registerCoreServices();

        // Load service providers
        $this->loadServiceProviders();

        // Bootstrap extensions
        $this->bootstrapExtensions();

        // Bootstrap events
        $this->bootstrapEvents();

        // Register WordPress hooks
        $this->registerHooks();

        $this->booted = true;

        // Fire booted event
        EventEmitter::getInstance()->dispatch('kernel.booted');
    }

    /**
     * Load configuration
     */
    private function loadConfiguration(): void
    {
        if (defined('VRIN_CONFIG')) {
            $this->config = VRIN_CONFIG;
        }
    }

    /**
     * Register core services
     */
    private function registerCoreServices(): void
    {
        $this->container->singleton('kernel', fn() => $this);
        $this->container->singleton('events', fn() => EventEmitter::getInstance());
        $this->container->singleton('cache', fn() => new Cache());
        $this->container->singleton('view', fn() => new View());
        $this->container->singleton('extensions', fn() => ExtensionManager::getInstance());
    }

    /**
     * Load service providers
     */
    private function loadServiceProviders(): void
    {
        $providers = $this->config['app']['providers'] ?? [];

        foreach ($providers as $providerClass) {
            if (class_exists($providerClass)) {
                $provider = new $providerClass($this->container);
                $provider->register();
                $this->providers[] = $provider;
            }
        }

        // Boot all providers
        foreach ($this->providers as $provider) {
            if (method_exists($provider, 'boot')) {
                $provider->boot();
            }
        }
    }

    /**
     * Bootstrap extensions
     */
    private function bootstrapExtensions(): void
    {
        require_once VRIN_PLUGIN_DIR . 'bootstrap/extensions.php';
    }

    /**
     * Bootstrap events
     */
    private function bootstrapEvents(): void
    {
        require_once VRIN_PLUGIN_DIR . 'bootstrap/events.php';
    }

    /**
     * Register WordPress hooks
     */
    private function registerHooks(): void
    {
        // Load admin routes
        if (file_exists(VRIN_PLUGIN_DIR . 'routes/admin.php')) {
            require_once VRIN_PLUGIN_DIR . 'routes/admin.php';
        }

        // Admin hooks
        if (is_admin()) {
            add_action('admin_menu', [$this, 'registerAdminMenu']);
            add_action('admin_enqueue_scripts', [$this, 'enqueueAdminAssets']);
        }

        // REST API hooks
        add_action('rest_api_init', [$this, 'registerRestRoutes']);

        // AJAX hooks
        add_action('wp_ajax_vrin_ajax_handler', [$this, 'handleAjaxRequest']);

        // Cron hooks
        $this->registerCronJobs();
    }

    /**
     * Register admin menu
     */
    public function registerAdminMenu(): void
    {
        EventEmitter::getInstance()->dispatch('admin.menu.register');
    }

    /**
     * Enqueue admin assets
     */
    public function enqueueAdminAssets(): void
    {
        EventEmitter::getInstance()->dispatch('admin.assets.enqueue');
    }

    /**
     * Register REST routes
     */
    public function registerRestRoutes(): void
    {
        // Load API routes
        if (file_exists(VRIN_PLUGIN_DIR . 'routes/api.php')) {
            require_once VRIN_PLUGIN_DIR . 'routes/api.php';
        }

        EventEmitter::getInstance()->dispatch('rest.routes.register');
    }

    /**
     * Handle AJAX requests
     */
    public function handleAjaxRequest(): void
    {
        check_ajax_referer('vrin_ajax_nonce', 'nonce');

        $action = sanitize_text_field($_POST['action_type'] ?? '');

        EventEmitter::getInstance()->dispatch('ajax.request', ['action' => $action]);
    }

    /**
     * Register cron jobs
     */
    private function registerCronJobs(): void
    {
        // Register Google Ads fetch cron
        if (!wp_next_scheduled('vrin_google_ads_fetch')) {
            wp_schedule_event(time(), 'hourly', 'vrin_google_ads_fetch');
        }

        add_action('vrin_google_ads_fetch', [\ViraInsight\Jobs\GoogleAdsFetchJob::class, 'run']);
    }

    /**
     * Plugin activation
     */
    public function activate(): void
    {
        // Create database tables
        $this->createDatabaseTables();

        // Set default options
        $this->setDefaultOptions();

        // Flush rewrite rules
        flush_rewrite_rules();

        // Fire activation event
        EventEmitter::getInstance()->dispatch('plugin.activated');
    }

    /**
     * Plugin deactivation
     */
    public function deactivate(): void
    {
        // Clear scheduled cron jobs
        wp_clear_scheduled_hook('vrin_google_ads_fetch');

        // Clear cache
        Cache::getInstance()->flush();

        // Flush rewrite rules
        flush_rewrite_rules();

        // Fire deactivation event
        EventEmitter::getInstance()->dispatch('plugin.deactivated');
    }

    /**
     * Plugin uninstall
     */
    public static function uninstall(): void
    {
        // Remove all options
        delete_option('vrin_settings');
        delete_option('vrin_version');

        // Remove database tables
        global $wpdb;
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}vrin_seo_analysis");
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}vrin_google_ads_data");
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}vrin_social_ads_stats");
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}vrin_social_ads_data");

        // Clear cache
        wp_cache_flush();
    }

    /**
     * Create database tables
     */
    private function createDatabaseTables(): void
    {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        $tables = [
            "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}vrin_seo_analysis (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                post_id bigint(20) NOT NULL,
                score int(3) NOT NULL,
                analysis_data longtext NOT NULL,
                created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY post_id (post_id)
            ) $charset_collate;",

            "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}vrin_google_ads_data (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                campaign_id varchar(255) NOT NULL,
                campaign_data longtext NOT NULL,
                synced_at datetime NOT NULL,
                PRIMARY KEY (id),
                KEY campaign_id (campaign_id)
            ) $charset_collate;",

            "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}vrin_social_ads_data (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                platform varchar(50) NOT NULL,
                ad_id varchar(255) NOT NULL,
                ad_data longtext NOT NULL,
                synced_at datetime NOT NULL,
                PRIMARY KEY (id),
                KEY platform_ad (platform, ad_id)
            ) $charset_collate;",

            "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}vrin_google_ads_stats (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                campaign_id BIGINT NOT NULL,
                name VARCHAR(255),
                clicks BIGINT DEFAULT 0,
                impressions BIGINT DEFAULT 0,
                ctr DECIMAL(10,4) DEFAULT 0,
                avg_cpc BIGINT DEFAULT 0,
                cost_micros BIGINT DEFAULT 0,
                updated_at DATETIME,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_campaign_id (campaign_id),
                INDEX idx_updated_at (updated_at)
            ) $charset_collate;",
        ];

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        foreach ($tables as $sql) {
            dbDelta($sql);
        }

        // Run additional migrations
        $this->runMigrations();
    }

    /**
     * Run database migrations
     */
    private function runMigrations(): void
    {
        $migrationsDir = VRIN_PLUGIN_DIR . 'database/migrations/';
        
        if (!is_dir($migrationsDir)) {
            return;
        }

        $migrations = glob($migrationsDir . '*.php');
        
        foreach ($migrations as $migration) {
            if (is_file($migration)) {
                $migrationFunction = require $migration;
                if (is_callable($migrationFunction)) {
                    global $wpdb;
                    $migrationFunction($wpdb);
                }
            }
        }
    }

    /**
     * Set default options
     */
    private function setDefaultOptions(): void
    {
        $defaults = [
            'seo_enabled' => true,
            'google_ads_enabled' => true,
            'social_ads_enabled' => true,
            'cache_enabled' => true,
            'cache_ttl' => 3600,
        ];

        add_option('vrin_settings', $defaults);
        add_option('vrin_version', VRIN_VERSION);
    }

    /**
     * Get container
     */
    public function getContainer(): Container
    {
        return $this->container;
    }

    /**
     * Get configuration
     */
    public function getConfig(string $key = null, $default = null)
    {
        if ($key === null) {
            return $this->config;
        }

        $keys = explode('.', $key);
        $value = $this->config;

        foreach ($keys as $k) {
            if (!isset($value[$k])) {
                return $default;
            }
            $value = $value[$k];
        }

        return $value;
    }
}
