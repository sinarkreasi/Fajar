<?php
/**
 * View Renderer
 *
 * Simple template rendering system with caching support.
 *
 * @package ViraInsight\Core
 */

declare(strict_types=1);

namespace ViraInsight\Core;

class View
{
    /**
     * Views directory
     */
    private string $viewsPath;

    /**
     * Cache directory
     */
    private string $cachePath;

    /**
     * Cache enabled
     */
    private bool $cacheEnabled = true;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->viewsPath = VRIN_PLUGIN_DIR . 'resources/views/';
        $this->cachePath = VRIN_PLUGIN_DIR . 'storage/views/';
    }

    /**
     * Render a view
     *
     * @param string $view View name (dot notation: admin.dashboard)
     * @param array $data Data to pass to view
     * @param bool $return Whether to return or echo
     * @return string|void
     */
    public function render(string $view, array $data = [], bool $return = false)
    {
        $viewPath = $this->getViewPath($view);

        if (!file_exists($viewPath)) {
            throw new \Exception("View '{$view}' not found at {$viewPath}");
        }

        $output = $this->renderView($viewPath, $data);

        if ($return) {
            return $output;
        }

        echo $output;
    }

    /**
     * Render a view and return content
     */
    public function make(string $view, array $data = []): string
    {
        return $this->render($view, $data, true);
    }

    /**
     * Render view file
     */
    private function renderView(string $viewPath, array $data): string
    {
        // Check cache
        if ($this->cacheEnabled) {
            $cached = $this->getCached($viewPath);
            if ($cached !== null) {
                return $this->processView($cached, $data);
            }
        }

        // Read view file
        $content = file_get_contents($viewPath);

        // Cache compiled view
        if ($this->cacheEnabled) {
            $this->cacheView($viewPath, $content);
        }

        return $this->processView($content, $data);
    }

    /**
     * Process view with data
     */
    private function processView(string $content, array $data): string
    {
        // Extract data to variables
        extract($data, EXTR_SKIP);

        // Start output buffering
        ob_start();

        try {
            // Evaluate PHP in content
            eval('?>' . $content);
            $output = ob_get_clean();
        } catch (\Exception $e) {
            ob_end_clean();
            throw $e;
        }

        return $output;
    }

    /**
     * Get view file path
     */
    private function getViewPath(string $view): string
    {
        // Convert dot notation to path
        $path = str_replace('.', DIRECTORY_SEPARATOR, $view);
        return $this->viewsPath . $path . '.php';
    }

    /**
     * Get cached view
     */
    private function getCached(string $viewPath): ?string
    {
        $cacheKey = md5($viewPath);
        $cachePath = $this->cachePath . $cacheKey . '.php';

        if (!file_exists($cachePath)) {
            return null;
        }

        // Check if original view is newer
        if (filemtime($viewPath) > filemtime($cachePath)) {
            return null;
        }

        return file_get_contents($cachePath);
    }

    /**
     * Cache view
     */
    private function cacheView(string $viewPath, string $content): void
    {
        $cacheKey = md5($viewPath);
        $cachePath = $this->cachePath . $cacheKey . '.php';

        file_put_contents($cachePath, $content);
    }

    /**
     * Clear view cache
     */
    public function clearCache(): void
    {
        $files = glob($this->cachePath . '*.php');
        foreach ($files as $file) {
            if (is_file($file)) {
                unlink($file);
            }
        }
    }

    /**
     * Disable caching
     */
    public function disableCache(): void
    {
        $this->cacheEnabled = false;
    }

    /**
     * Enable caching
     */
    public function enableCache(): void
    {
        $this->cacheEnabled = true;
    }
}
