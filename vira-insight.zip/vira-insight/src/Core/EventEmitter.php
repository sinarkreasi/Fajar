<?php
/**
 * Event Emitter
 *
 * Simple event system for dispatching and listening to events.
 * Supports synchronous and asynchronous (job-based) listeners.
 *
 * @package ViraInsight\Core
 */

declare(strict_types=1);

namespace ViraInsight\Core;

class EventEmitter
{
    /**
     * Singleton instance
     */
    private static ?self $instance = null;

    /**
     * Event listeners
     */
    private array $listeners = [];

    /**
     * Private constructor
     */
    private function __construct()
    {
    }

    /**
     * Get instance
     */
    public static function getInstance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Register an event listener
     *
     * @param string $event Event name
     * @param callable|array $listener Listener callback or [class, method]
     * @param int $priority Priority (lower = earlier)
     * @param bool $async Whether to run asynchronously
     */
    public function on(string $event, $listener, int $priority = 10, bool $async = false): void
    {
        if (!isset($this->listeners[$event])) {
            $this->listeners[$event] = [];
        }

        $this->listeners[$event][] = [
            'listener' => $listener,
            'priority' => $priority,
            'async' => $async,
        ];

        // Sort by priority
        usort($this->listeners[$event], function ($a, $b) {
            return $a['priority'] <=> $b['priority'];
        });
    }

    /**
     * Register a one-time event listener
     */
    public function once(string $event, $listener, int $priority = 10): void
    {
        $wrapper = function ($payload) use ($event, $listener, &$wrapper) {
            $this->off($event, $wrapper);
            return $this->callListener($listener, $payload);
        };

        $this->on($event, $wrapper, $priority);
    }

    /**
     * Remove an event listener
     */
    public function off(string $event, $listener): void
    {
        if (!isset($this->listeners[$event])) {
            return;
        }

        $this->listeners[$event] = array_filter(
            $this->listeners[$event],
            function ($item) use ($listener) {
                return $item['listener'] !== $listener;
            }
        );
    }

    /**
     * Dispatch an event
     *
     * @param string $event Event name
     * @param mixed $payload Event payload
     * @return mixed|null
     */
    public function dispatch(string $event, $payload = null)
    {
        if (!isset($this->listeners[$event])) {
            return null;
        }

        $result = null;

        foreach ($this->listeners[$event] as $item) {
            $listener = $item['listener'];
            $async = $item['async'];

            if ($async) {
                // Queue for async processing
                $this->queueListener($event, $listener, $payload);
            } else {
                // Execute synchronously
                $result = $this->callListener($listener, $payload);
            }
        }

        return $result;
    }

    /**
     * Call a listener
     */
    private function callListener($listener, $payload)
    {
        if (is_array($listener)) {
            [$class, $method] = $listener;

            if (is_string($class) && class_exists($class)) {
                $instance = new $class();
                return $instance->$method($payload);
            }

            if (is_object($class)) {
                return $class->$method($payload);
            }
        }

        if (is_callable($listener)) {
            return $listener($payload);
        }

        return null;
    }

    /**
     * Queue listener for async execution
     */
    private function queueListener(string $event, $listener, $payload): void
    {
        // Schedule as WordPress cron job
        wp_schedule_single_event(time(), 'vrin_async_event', [
            'event' => $event,
            'listener' => $listener,
            'payload' => $payload,
        ]);
    }

    /**
     * Get all listeners for an event
     */
    public function getListeners(string $event): array
    {
        return $this->listeners[$event] ?? [];
    }

    /**
     * Check if event has listeners
     */
    public function hasListeners(string $event): bool
    {
        return isset($this->listeners[$event]) && !empty($this->listeners[$event]);
    }

    /**
     * Remove all listeners
     */
    public function flush(): void
    {
        $this->listeners = [];
    }
}
