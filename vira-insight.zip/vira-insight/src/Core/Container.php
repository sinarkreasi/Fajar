<?php
/**
 * Service Container
 *
 * Simple dependency injection container for managing services.
 *
 * @package ViraInsight\Core
 */

declare(strict_types=1);

namespace ViraInsight\Core;

class Container
{
    /**
     * Singleton instance
     */
    private static ?self $instance = null;

    /**
     * Container bindings
     */
    private array $bindings = [];

    /**
     * Singleton instances
     */
    private array $instances = [];

    /**
     * Private constructor
     */
    private function __construct()
    {
    }

    /**
     * Get container instance
     */
    public static function getInstance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Bind a service
     */
    public function bind(string $abstract, callable $concrete): void
    {
        $this->bindings[$abstract] = [
            'concrete' => $concrete,
            'shared' => false,
        ];
    }

    /**
     * Bind a singleton service
     */
    public function singleton(string $abstract, callable $concrete): void
    {
        $this->bindings[$abstract] = [
            'concrete' => $concrete,
            'shared' => true,
        ];
    }

    /**
     * Register an existing instance
     */
    public function instance(string $abstract, $instance): void
    {
        $this->instances[$abstract] = $instance;
    }

    /**
     * Resolve a service
     */
    public function make(string $abstract)
    {
        // Return existing instance if singleton
        if (isset($this->instances[$abstract])) {
            return $this->instances[$abstract];
        }

        // Check if binding exists
        if (!isset($this->bindings[$abstract])) {
            throw new \Exception("Service '{$abstract}' not found in container.");
        }

        $binding = $this->bindings[$abstract];
        $concrete = $binding['concrete'];

        // Build the service
        $object = $concrete($this);

        // Store singleton instance
        if ($binding['shared']) {
            $this->instances[$abstract] = $object;
        }

        return $object;
    }

    /**
     * Check if service exists
     */
    public function has(string $abstract): bool
    {
        return isset($this->bindings[$abstract]) || isset($this->instances[$abstract]);
    }

    /**
     * Forget a service
     */
    public function forget(string $abstract): void
    {
        unset($this->bindings[$abstract], $this->instances[$abstract]);
    }

    /**
     * Get all bindings
     */
    public function getBindings(): array
    {
        return $this->bindings;
    }
}
