<?php

namespace ViraInsight\GoogleAds\Repositories;

use ViraInsight\Support\BaseRepository;

class GoogleAdsRepository extends BaseRepository
{
    protected string $table = 'vrin_google_ads_stats';

    public function storeCampaignStats(array $items): bool
    {
        if (empty($items)) {
            return true;
        }

        foreach ($items as $row) {
            // Check if campaign already exists
            $existing = $this->db()->get_var(
                $this->db()->prepare(
                    "SELECT id FROM {$this->table} WHERE campaign_id = %s",
                    $row['campaign_id']
                )
            );

            $data = [
                'campaign_id' => $row['campaign_id'],
                'name'        => $row['name'],
                'clicks'      => $row['clicks'],
                'impressions' => $row['impressions'],
                'ctr'         => $row['ctr'],
                'avg_cpc'     => $row['avg_cpc'],
                'cost_micros' => $row['cost_micros'],
                'updated_at'  => current_time('mysql'),
            ];

            if ($existing) {
                // Update existing record
                $this->db()->update(
                    $this->table,
                    $data,
                    ['campaign_id' => $row['campaign_id']]
                );
            } else {
                // Insert new record
                $data['created_at'] = current_time('mysql');
                $this->db()->insert($this->table, $data);
            }
        }

        return true;
    }

    public function getCampaignStats(int $limit = 100): array
    {
        return $this->db()->get_results(
            $this->db()->prepare(
                "SELECT * FROM {$this->table} ORDER BY updated_at DESC LIMIT %d",
                $limit
            ),
            ARRAY_A
        );
    }

    public function getCampaignById(string $campaignId): ?array
    {
        $result = $this->db()->get_row(
            $this->db()->prepare(
                "SELECT * FROM {$this->table} WHERE campaign_id = %s",
                $campaignId
            ),
            ARRAY_A
        );

        return $result ?: null;
    }

    public function getQuickStats(string $period = '7days'): array
    {
        $dateCondition = $this->getDateCondition($period);
        
        $query = "
            SELECT 
                COUNT(*) as campaigns,
                SUM(impressions) as impressions,
                SUM(clicks) as clicks,
                AVG(ctr) as ctr,
                SUM(cost_micros) as cost,
                AVG(avg_cpc) as cpc
            FROM {$this->table}
            WHERE {$dateCondition}
        ";

        $result = $this->db()->get_row($query, ARRAY_A);

        return [
            'campaigns' => (int) ($result['campaigns'] ?? 0),
            'impressions' => (int) ($result['impressions'] ?? 0),
            'clicks' => (int) ($result['clicks'] ?? 0),
            'ctr' => (float) ($result['ctr'] ?? 0),
            'cost' => (int) ($result['cost'] ?? 0),
            'cpc' => (int) ($result['cpc'] ?? 0),
        ];
    }

    private function getDateCondition(string $period): string
    {
        switch ($period) {
            case 'today':
                return "DATE(updated_at) = CURDATE()";
            case 'yesterday':
                return "DATE(updated_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)";
            case '7days':
                return "updated_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
            case '30days':
                return "updated_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
            default:
                return "updated_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
        }
    }
}