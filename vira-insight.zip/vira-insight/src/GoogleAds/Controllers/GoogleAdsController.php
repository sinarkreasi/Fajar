<?php
/**
 * Google Ads Controller
 *
 * Handles Google Ads-related requests.
 *
 * @package ViraInsight\GoogleAds\Controllers
 */

declare(strict_types=1);

namespace ViraInsight\GoogleAds\Controllers;

use ViraInsight\Http\Controllers\BaseController;
use ViraInsight\GoogleAds\Services\AnalyzerService;

class GoogleAdsController extends BaseController
{
    /**
     * Analyzer service
     */
    private AnalyzerService $analyzer;

    /**
     * Constructor
     */
    public function __construct()
    {
        parent::__construct();
        $this->analyzer = new AnalyzerService();
    }

    /**
     * Display Google Ads dashboard
     */
    public function index(): void
    {
        if (!$this->checkCapability()) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'vira-insight'));
        }

        $this->render('admin.google-ads.index', [
            'title' => __('Google Ads Intelligence', 'vira-insight'),
        ]);
    }

    /**
     * Analyze campaign (REST endpoint)
     */
    public function analyzeCampaign(\WP_REST_Request $request): \WP_REST_Response
    {
        $campaignData = [
            'ctr' => floatval($request->get_param('ctr') ?? 0),
            'cpc' => floatval($request->get_param('cpc') ?? 0),
            'quality_score' => intval($request->get_param('quality_score') ?? 0),
            'conversion_rate' => floatval($request->get_param('conversion_rate') ?? 0),
            'daily_budget' => floatval($request->get_param('daily_budget') ?? 0),
            'spent' => floatval($request->get_param('spent') ?? 0),
            'industry_avg_cpc' => floatval($request->get_param('industry_avg_cpc') ?? 2.0),
        ];

        $analysis = $this->analyzer->analyzeCampaignHealth($campaignData);

        return new \WP_REST_Response([
            'success' => true,
            'data' => $analysis,
        ], 200);
    }

    /**
     * Get projections (REST endpoint)
     */
    public function getProjections(\WP_REST_Request $request): \WP_REST_Response
    {
        $currentData = [
            'impressions' => intval($request->get_param('impressions') ?? 0),
            'clicks' => intval($request->get_param('clicks') ?? 0),
            'spent' => floatval($request->get_param('spent') ?? 0),
            'conversion_rate' => floatval($request->get_param('conversion_rate') ?? 0),
            'days_running' => intval($request->get_param('days_running') ?? 1),
        ];

        $days = intval($request->get_param('projection_days') ?? 30);

        $projections = $this->analyzer->projectMetrics($currentData, $days);

        return new \WP_REST_Response([
            'success' => true,
            'data' => $projections,
        ], 200);
    }

    /**
     * Get campaign stats (REST endpoint)
     */
    public function stats(\WP_REST_Request $request): \WP_REST_Response
    {
        if (!$this->checkCapability()) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => __('Insufficient permissions', 'vira-insight'),
            ], 403);
        }

        try {
            $repo = vrin_app(\ViraInsight\GoogleAds\Repositories\GoogleAdsRepository::class);
            $stats = $repo->getCampaignStats();

            return new \WP_REST_Response([
                'success' => true,
                'data' => $stats,
            ], 200);
        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Get quick stats (REST endpoint)
     */
    public function quickStats(\WP_REST_Request $request): \WP_REST_Response
    {
        if (!$this->checkCapability()) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => __('Insufficient permissions', 'vira-insight'),
            ], 403);
        }

        try {
            $repo = vrin_app(\ViraInsight\GoogleAds\Repositories\GoogleAdsRepository::class);
            $period = $request->get_param('period') ?: '7days';
            
            $stats = $repo->getQuickStats($period);

            return new \WP_REST_Response([
                'success' => true,
                'data' => $stats,
            ], 200);
        } catch (\Exception $e) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Save Google Ads settings (AJAX)
     */
    public function saveSettings(): void
    {
        check_ajax_referer('vrin_google_ads_settings', 'nonce');

        if (!$this->checkCapability()) {
            wp_send_json_error(__('Insufficient permissions', 'vira-insight'));
        }

        $settings = $_POST['settings'] ?? [];

        // Sanitize settings
        $sanitized = [
            'dev_token' => sanitize_text_field($settings['dev_token'] ?? ''),
            'client_id' => sanitize_text_field($settings['client_id'] ?? ''),
            'client_secret' => sanitize_text_field($settings['client_secret'] ?? ''),
            'refresh_token' => sanitize_text_field($settings['refresh_token'] ?? ''),
            'login_customer_id' => sanitize_text_field($settings['login_customer_id'] ?? ''),
            'customer_id' => sanitize_text_field($settings['customer_id'] ?? ''),
        ];

        // Save to options
        foreach ($sanitized as $key => $value) {
            update_option('vrin_google_ads_' . $key, $value);
        }

        wp_send_json_success(__('Settings saved successfully', 'vira-insight'));
    }

    /**
     * Test Google Ads connection (AJAX)
     */
    public function testConnection(): void
    {
        check_ajax_referer('wp_rest', 'nonce');

        if (!$this->checkCapability()) {
            wp_send_json_error(__('Insufficient permissions', 'vira-insight'));
        }

        try {
            $service = vrin_app(\ViraInsight\GoogleAds\Services\GoogleAdsService::class);
            
            // Try to initialize client
            if ($service->testConnection()) {
                wp_send_json_success(__('Connection successful', 'vira-insight'));
            } else {
                wp_send_json_error(__('Connection failed', 'vira-insight'));
            }
        } catch (\Exception $e) {
            wp_send_json_error($e->getMessage());
        }
    }

    /**
     * Manual sync (AJAX)
     */
    public function manualSync(): void
    {
        check_ajax_referer('wp_rest', 'nonce');

        if (!$this->checkCapability()) {
            wp_send_json_error(__('Insufficient permissions', 'vira-insight'));
        }

        try {
            $result = \ViraInsight\Jobs\GoogleAdsFetchJob::run();
            
            if ($result) {
                update_option('vrin_google_ads_sync_status', 'success');
                update_option('vrin_google_ads_last_sync', current_time('mysql'));
                wp_send_json_success(__('Sync completed successfully', 'vira-insight'));
            } else {
                update_option('vrin_google_ads_sync_status', 'error');
                wp_send_json_error(__('Sync failed', 'vira-insight'));
            }
        } catch (\Exception $e) {
            update_option('vrin_google_ads_sync_status', 'error');
            wp_send_json_error($e->getMessage());
        }
    }

    /**
     * Reset sync schedule (AJAX)
     */
    public function resetSyncSchedule(): void
    {
        check_ajax_referer('wp_rest', 'nonce');

        if (!$this->checkCapability()) {
            wp_send_json_error(__('Insufficient permissions', 'vira-insight'));
        }

        // Clear existing schedule
        wp_clear_scheduled_hook('vrin_google_ads_fetch');
        
        // Reschedule
        wp_schedule_event(time(), 'hourly', 'vrin_google_ads_fetch');

        wp_send_json_success(__('Sync schedule reset successfully', 'vira-insight'));
    }

    /**
     * Get sync logs (AJAX)
     */
    public function getSyncLogs(): void
    {
        check_ajax_referer('wp_rest', 'nonce');

        if (!$this->checkCapability()) {
            wp_send_json_error(__('Insufficient permissions', 'vira-insight'));
        }

        $logs = get_option('vrin_google_ads_sync_logs', '');
        wp_send_json_success($logs);
    }
}
