<?php
/**
 * Google Ads Analyzer Service
 *
 * Provides campaign diagnostics and analysis (Base free version).
 *
 * @package ViraInsight\GoogleAds\Services
 */

declare(strict_types=1);

namespace ViraInsight\GoogleAds\Services;

class AnalyzerService
{
    /**
     * Analyze campaign health (manual input mode)
     */
    public function analyzeCampaignHealth(array $campaignData): array
    {
        return [
            'health_score' => $this->calculateHealthScore($campaignData),
            'budget_pacing' => $this->analyzeBudgetPacing($campaignData),
            'ctr_analysis' => $this->analyzeCTR($campaignData),
            'cpc_analysis' => $this->analyzeCPC($campaignData),
            'recommendations' => $this->getRecommendations($campaignData),
        ];
    }

    /**
     * Calculate health score
     */
    private function calculateHealthScore(array $data): int
    {
        $score = 50; // Base score

        // CTR scoring
        $ctr = $data['ctr'] ?? 0;
        if ($ctr >= 5) {
            $score += 20;
        } elseif ($ctr >= 3) {
            $score += 15;
        } elseif ($ctr >= 1) {
            $score += 10;
        }

        // Quality Score
        $qualityScore = $data['quality_score'] ?? 0;
        if ($qualityScore >= 8) {
            $score += 20;
        } elseif ($qualityScore >= 6) {
            $score += 15;
        } elseif ($qualityScore >= 4) {
            $score += 10;
        }

        // Conversion Rate
        $conversionRate = $data['conversion_rate'] ?? 0;
        if ($conversionRate >= 5) {
            $score += 10;
        } elseif ($conversionRate >= 2) {
            $score += 5;
        }

        return min($score, 100);
    }

    /**
     * Analyze budget pacing
     */
    private function analyzeBudgetPacing(array $data): array
    {
        $dailyBudget = $data['daily_budget'] ?? 0;
        $spent = $data['spent'] ?? 0;
        $daysInMonth = date('t');
        $currentDay = date('j');

        $expectedSpend = ($dailyBudget / $daysInMonth) * $currentDay;
        $pacing = $spent > 0 ? ($spent / $expectedSpend) * 100 : 0;

        return [
            'pacing_percentage' => round($pacing, 2),
            'status' => $this->getBudgetPacingStatus($pacing),
            'projected_spend' => round($dailyBudget * ($pacing / 100), 2),
        ];
    }

    /**
     * Analyze CTR
     */
    private function analyzeCTR(array $data): array
    {
        $ctr = $data['ctr'] ?? 0;

        return [
            'value' => $ctr,
            'status' => $this->getCTRStatus($ctr),
            'benchmark' => 3.0,
            'above_benchmark' => $ctr >= 3.0,
        ];
    }

    /**
     * Analyze CPC
     */
    private function analyzeCPC(array $data): array
    {
        $cpc = $data['cpc'] ?? 0;
        $industry_avg = $data['industry_avg_cpc'] ?? 2.0;

        return [
            'value' => $cpc,
            'industry_average' => $industry_avg,
            'status' => $cpc <= $industry_avg ? 'good' : 'high',
            'savings_opportunity' => max(0, $cpc - $industry_avg),
        ];
    }

    /**
     * Get recommendations
     */
    private function getRecommendations(array $data): array
    {
        $recommendations = [];

        $ctr = $data['ctr'] ?? 0;
        if ($ctr < 3) {
            $recommendations[] = [
                'type' => 'warning',
                'message' => 'CTR is below industry average. Consider improving ad copy and relevance.',
                'priority' => 'high',
            ];
        }

        $qualityScore = $data['quality_score'] ?? 0;
        if ($qualityScore < 6) {
            $recommendations[] = [
                'type' => 'error',
                'message' => 'Quality Score is low. Improve landing page experience and keyword relevance.',
                'priority' => 'critical',
            ];
        }

        $conversionRate = $data['conversion_rate'] ?? 0;
        if ($conversionRate < 2) {
            $recommendations[] = [
                'type' => 'info',
                'message' => 'Conversion rate could be improved. Review landing pages and calls-to-action.',
                'priority' => 'medium',
            ];
        }

        return $recommendations;
    }

    /**
     * Get budget pacing status
     */
    private function getBudgetPacingStatus(float $pacing): string
    {
        if ($pacing > 110) return 'overspending';
        if ($pacing > 90) return 'on_track';
        return 'underspending';
    }

    /**
     * Get CTR status
     */
    private function getCTRStatus(float $ctr): string
    {
        if ($ctr >= 5) return 'excellent';
        if ($ctr >= 3) return 'good';
        if ($ctr >= 1) return 'average';
        return 'poor';
    }

    /**
     * Calculate projected metrics
     */
    public function projectMetrics(array $currentData, int $days = 30): array
    {
        $dailyImpressions = ($currentData['impressions'] ?? 0) / max(1, $currentData['days_running'] ?? 1);
        $dailyClicks = ($currentData['clicks'] ?? 0) / max(1, $currentData['days_running'] ?? 1);
        $dailySpend = ($currentData['spent'] ?? 0) / max(1, $currentData['days_running'] ?? 1);

        return [
            'projected_impressions' => round($dailyImpressions * $days),
            'projected_clicks' => round($dailyClicks * $days),
            'projected_spend' => round($dailySpend * $days, 2),
            'projected_conversions' => round($dailyClicks * ($currentData['conversion_rate'] ?? 0) / 100 * $days),
        ];
    }
}
