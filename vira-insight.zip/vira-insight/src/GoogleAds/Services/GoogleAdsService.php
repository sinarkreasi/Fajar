<?php

namespace ViraInsight\GoogleAds\Services;

use Google\Ads\GoogleAds\Lib\V16\GoogleAdsClientBuilder;
use Google\Ads\GoogleAds\Lib\OAuth2TokenBuilder;
use ViraInsight\Support\BaseService;
use ViraInsight\GoogleAds\Repositories\GoogleAdsRepository;
use ViraInsight\Core\EventEmitter;

class GoogleAdsService extends BaseService
{
    protected $client;
    protected GoogleAdsRepository $repository;

    public function __construct(EventEmitter $events, GoogleAdsRepository $repository)
    {
        parent::__construct($events);
        $this->repository = $repository;
        $this->client = $this->bootClient();
    }

    protected function bootClient()
    {
        try {
            $oauth = (new OAuth2TokenBuilder())
                ->withClientId(config('google-ads.client_id'))
                ->withClientSecret(config('google-ads.client_secret'))
                ->withRefreshToken(config('google-ads.refresh_token'))
                ->build();

            return (new GoogleAdsClientBuilder())
                ->withDeveloperToken(config('google-ads.developer_token'))
                ->withLoginCustomerId(config('google-ads.login_customer_id'))
                ->withOAuth2Credential($oauth)
                ->build();
        } catch (\Exception $e) {
            $this->log('Google Ads Client initialization failed: ' . $e->getMessage());
            return null;
        }
    }

    public function fetchCampaignStats($customerId)
    {
        if (!$this->client) {
            $this->log('Google Ads client not initialized');
            return false;
        }

        try {
            $query = "
                SELECT 
                  campaign.id,
                  campaign.name,
                  metrics.clicks,
                  metrics.impressions,
                  metrics.ctr,
                  metrics.average_cpc,
                  metrics.cost_micros
                FROM campaign
                WHERE campaign.status = 'ENABLED'
            ";

            $response = $this->client->getGoogleAdsServiceClient()
                ->search($customerId, $query);

            $data = [];

            foreach ($response->iterateAllElements() as $row) {
                $data[] = [
                    'campaign_id'   => $row->getCampaign()->getId(),
                    'name'          => $row->getCampaign()->getName(),
                    'clicks'        => $row->getMetrics()->getClicks(),
                    'impressions'   => $row->getMetrics()->getImpressions(),
                    'ctr'           => $row->getMetrics()->getCtr(),
                    'avg_cpc'       => $row->getMetrics()->getAverageCpc(),
                    'cost_micros'   => $row->getMetrics()->getCostMicros(),
                ];
            }

            $result = $this->repository->storeCampaignStats($data);
            
            // Dispatch event
            $this->dispatch('vrin_google_ads_synced', $data);
            
            return $result;
        } catch (\Exception $e) {
            $this->log('Failed to fetch campaign stats: ' . $e->getMessage());
            return false;
        }
    }

    public function testConnection(): bool
    {
        if (!$this->client) {
            return false;
        }

        try {
            // Try a simple query to test the connection
            $customerId = config('google-ads.login_customer_id');
            if (!$customerId) {
                return false;
            }

            $query = "SELECT customer.id FROM customer LIMIT 1";
            $response = $this->client->getGoogleAdsServiceClient()->search($customerId, $query);
            
            // If we can iterate without error, connection is good
            foreach ($response->iterateAllElements() as $row) {
                return true;
            }
            
            return true;
        } catch (\Exception $e) {
            $this->log('Connection test failed: ' . $e->getMessage());
            return false;
        }
    }
}