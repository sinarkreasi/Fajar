<?php
/**
 * Exception Handler
 *
 * Handles exceptions thrown by the plugin.
 *
 * @package ViraInsight\Exceptions
 */

declare(strict_types=1);

namespace ViraInsight\Exceptions;

class Handler
{
    /**
     * Handle an exception
     */
    public function handle(\Throwable $exception): void
    {
        // Log the exception
        $this->log($exception);

        // Display error in debug mode
        if (defined('WP_DEBUG') && WP_DEBUG) {
            echo '<div class="error">';
            echo '<p><strong>Vira Insight Error:</strong> ' . esc_html($exception->getMessage()) . '</p>';
            echo '<pre>' . esc_html($exception->getTraceAsString()) . '</pre>';
            echo '</div>';
        }
    }

    /**
     * Log the exception
     */
    private function log(\Throwable $exception): void
    {
        $logFile = VRIN_PLUGIN_DIR . 'storage/logs/error.log';
        $message = sprintf(
            "[%s] %s in %s:%s\n%s\n\n",
            date('Y-m-d H:i:s'),
            $exception->getMessage(),
            $exception->getFile(),
            $exception->getLine(),
            $exception->getTraceAsString()
        );

        error_log($message, 3, $logFile);
    }
}
