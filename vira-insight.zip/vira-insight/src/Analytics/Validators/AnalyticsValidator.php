<?php

namespace ViraInsight\Analytics\Validators;

class AnalyticsValidator
{
    public function validateDateRange($start, $end): bool
    {
        return strtotime($start) && strtotime($end);
    }
}
