<?php

namespace ViraInsight\Analytics\Services;

use ViraInsight\Analytics\Repositories\AnalyticsRepository;

class AnalyticsService
{
    protected AnalyticsRepository $repo;

    public function __construct(AnalyticsRepository $repo)
    {
        $this->repo = $repo;
    }

    public function getOverview()
    {
        return [
            'traffic' => 0,
            'impressions' => 0,
            'clicks' => 0,
        ];
    }
}
