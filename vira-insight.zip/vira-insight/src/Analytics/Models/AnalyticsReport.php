<?php

namespace ViraInsight\Analytics\Models;

class AnalyticsReport
{
    public string $date;
    public array $metrics = [];

    public function __construct($date, array $metrics)
    {
        $this->date = $date;
        $this->metrics = $metrics;
    }
}
