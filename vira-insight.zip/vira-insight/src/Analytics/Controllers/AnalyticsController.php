<?php

namespace ViraInsight\Analytics\Controllers;

use ViraInsight\Core\Controller;

class AnalyticsController extends Controller
{
    public function index()
    {
        return $this->view('analytics.index', [
            'title' => __('Analytics Overview')
        ]);
    }
}
