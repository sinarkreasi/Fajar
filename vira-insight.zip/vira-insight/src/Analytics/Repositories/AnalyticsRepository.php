<?php

namespace ViraInsight\Analytics\Repositories;

use ViraInsight\Contracts\RepositoryInterface;

class AnalyticsRepository implements RepositoryInterface
{
    public function all()
    {
        return [];
    }

    public function find($id)
    {
        return null;
    }

    public function create(array $data)
    {
        return $data;
    }

    public function update($id, array $data)
    {
        return true;
    }

    public function delete($id)
    {
        return true;
    }
}
