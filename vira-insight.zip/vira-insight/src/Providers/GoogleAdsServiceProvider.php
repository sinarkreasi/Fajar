<?php
/**
 * Google Ads Service Provider
 *
 * Registers Google Ads-related services.
 *
 * @package ViraInsight\Providers
 */

declare(strict_types=1);

namespace ViraInsight\Providers;

use ViraInsight\Core\ServiceProvider;
use ViraInsight\Core\EventEmitter;

class GoogleAdsServiceProvider extends ServiceProvider
{
    /**
     * Register services
     */
    public function register(): void
    {
        $this->container->singleton('google_ads.analyzer', function () {
            return new \ViraInsight\GoogleAds\Services\AnalyzerService();
        });

        $this->container->singleton(\ViraInsight\GoogleAds\Repositories\GoogleAdsRepository::class, function () {
            return new \ViraInsight\GoogleAds\Repositories\GoogleAdsRepository();
        });

        $this->container->singleton(\ViraInsight\GoogleAds\Services\GoogleAdsService::class, function ($container) {
            return new \ViraInsight\GoogleAds\Services\GoogleAdsService(
                $container->make('events'),
                $container->make(\ViraInsight\GoogleAds\Repositories\GoogleAdsRepository::class)
            );
        });
    }

    /**
     * Boot services
     */
    public function boot(): void
    {
        // Register admin menu
        EventEmitter::getInstance()->on('admin.menu.register', function () {
            $this->registerAdminMenu();
        });

        // Enqueue assets
        EventEmitter::getInstance()->on('admin.assets.enqueue', function () {
            $this->enqueueAssets();
        });

        // Register AJAX handlers
        $this->registerAjaxHandlers();
    }

    /**
     * Register admin menu
     */
    private function registerAdminMenu(): void
    {
        add_submenu_page(
            'vira-insight',
            __('Google Ads', 'vira-insight'),
            __('Google Ads', 'vira-insight'),
            'manage_options',
            'vira-insight-google-ads',
            function () {
                $controller = new \ViraInsight\GoogleAds\Controllers\GoogleAdsController();
                $controller->index();
            }
        );
    }

    /**
     * Enqueue assets
     */
    private function enqueueAssets(): void
    {
        $screen = get_current_screen();
        
        // Only enqueue on Google Ads pages
        if ($screen && strpos($screen->id, 'vira-insight-google-ads') !== false) {
            // Enqueue CSS
            wp_enqueue_style(
                'vrin-google-ads',
                VRIN_PLUGIN_URL . 'resources/styles/google-ads.css',
                [],
                VRIN_VERSION
            );

            // Enqueue JS
            wp_enqueue_script(
                'vrin-google-ads-campaign',
                VRIN_PLUGIN_URL . 'resources/scripts/google-ads-campaign.js',
                ['jquery'],
                VRIN_VERSION,
                true
            );

            wp_enqueue_script(
                'vrin-google-ads-admin',
                VRIN_PLUGIN_URL . 'resources/scripts/google-ads-admin.js',
                ['jquery'],
                VRIN_VERSION,
                true
            );

            // Localize script
            wp_localize_script('vrin-google-ads-admin', 'vrinAjax', [
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'restUrl' => rest_url('vrin/v1'),
                'nonce' => wp_create_nonce('wp_rest'),
            ]);
        }
    }

    /**
     * Register AJAX handlers
     */
    private function registerAjaxHandlers(): void
    {
        $controller = new \ViraInsight\GoogleAds\Controllers\GoogleAdsController();

        add_action('wp_ajax_vrin_save_google_ads_settings', [$controller, 'saveSettings']);
        add_action('wp_ajax_vrin_test_google_ads_connection', [$controller, 'testConnection']);
        add_action('wp_ajax_vrin_manual_google_ads_sync', [$controller, 'manualSync']);
        add_action('wp_ajax_vrin_reset_google_ads_sync', [$controller, 'resetSyncSchedule']);
        add_action('wp_ajax_vrin_get_google_ads_logs', [$controller, 'getSyncLogs']);
    }
}
