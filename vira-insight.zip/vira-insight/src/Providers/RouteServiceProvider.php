<?php
/**
 * Route Service Provider
 *
 * Registers REST API routes.
 *
 * @package ViraInsight\Providers
 */

declare(strict_types=1);

namespace ViraInsight\Providers;

use ViraInsight\Core\ServiceProvider;
use ViraInsight\Core\EventEmitter;

class RouteServiceProvider extends ServiceProvider
{
    /**
     * Register services
     */
    public function register(): void
    {
        // Register router
        $this->container->singleton('router', function () {
            return new \ViraInsight\Http\Routing\Router();
        });
    }

    /**
     * Boot services
     */
    public function boot(): void
    {
        // Listen for REST routes registration
        EventEmitter::getInstance()->on('rest.routes.register', function () {
            $this->registerRoutes();
        });
    }

    /**
     * Register routes
     */
    private function registerRoutes(): void
    {
        // Load API routes
        if (file_exists(VRIN_PLUGIN_DIR . 'routes/api.php')) {
            require_once VRIN_PLUGIN_DIR . 'routes/api.php';
        }
    }
}
