<?php
/**
 * SEO Service Provider
 *
 * Registers SEO-related services.
 *
 * @package ViraInsight\Providers
 */

declare(strict_types=1);

namespace ViraInsight\Providers;

use ViraInsight\Core\ServiceProvider;
use ViraInsight\Core\EventEmitter;

class SEOServiceProvider extends ServiceProvider
{
    /**
     * Register services
     */
    public function register(): void
    {
        $this->container->singleton('seo.analyzer', function () {
            return new \ViraInsight\SEO\Services\AnalyzerService();
        });

        $this->container->singleton('seo.scoring', function () {
            return new \ViraInsight\SEO\Services\ScoringService();
        });
    }

    /**
     * Boot services
     */
    public function boot(): void
    {
        // Register admin menu
        EventEmitter::getInstance()->on('admin.menu.register', function () {
            $this->registerAdminMenu();
        });
    }

    /**
     * Register admin menu
     */
    private function registerAdminMenu(): void
    {
        add_submenu_page(
            'vira-insight',
            __('SEO Analysis', 'vira-insight'),
            __('SEO', 'vira-insight'),
            'manage_options',
            'vira-insight-seo',
            function () {
                $controller = new \ViraInsight\SEO\Controllers\SEOController();
                $controller->index();
            }
        );
    }
}
