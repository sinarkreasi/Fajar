<?php
/**
 * Extension Service Provider
 *
 * Registers extension-related services.
 *
 * @package ViraInsight\Providers
 */

declare(strict_types=1);

namespace ViraInsight\Providers;

use ViraInsight\Core\ServiceProvider;
use ViraInsight\Core\EventEmitter;

class ExtensionServiceProvider extends ServiceProvider
{
    /**
     * Register services
     */
    public function register(): void
    {
        $this->container->singleton('extensions', function () {
            return \ViraInsight\Core\ExtensionManager::getInstance();
        });
    }

    /**
     * Boot services
     */
    public function boot(): void
    {
        // Register admin menu
        EventEmitter::getInstance()->on('admin.menu.register', function () {
            $this->registerAdminMenu();
        });
    }

    /**
     * Register admin menu
     */
    private function registerAdminMenu(): void
    {
        add_submenu_page(
            'vira-insight',
            __('Extensions', 'vira-insight'),
            __('Extensions', 'vira-insight'),
            'manage_options',
            'vira-insight-extensions',
            function () {
                $controller = new \ViraInsight\UI\Admin\Controllers\ExtensionsController();
                $controller->index();
            }
        );
    }
}
