<?php
/**
 * View Service Provider
 *
 * Registers view-related services.
 *
 * @package ViraInsight\Providers
 */

declare(strict_types=1);

namespace ViraInsight\Providers;

use ViraInsight\Core\ServiceProvider;

class ViewServiceProvider extends ServiceProvider
{
    /**
     * Register services
     */
    public function register(): void
    {
        $this->container->singleton('view', function () {
            return new \ViraInsight\Core\View();
        });
    }
}
