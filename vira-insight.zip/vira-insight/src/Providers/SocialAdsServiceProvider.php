<?php
/**
 * Social Ads Service Provider
 *
 * Registers Social Ads-related services.
 *
 * @package ViraInsight\Providers
 */

declare(strict_types=1);

namespace ViraInsight\Providers;

use ViraInsight\Core\ServiceProvider;
use ViraInsight\Core\EventEmitter;

class SocialAdsServiceProvider extends ServiceProvider
{
    /**
     * Register services
     */
    public function register(): void
    {
        $this->container->singleton('social_ads.analyzer', function () {
            return new \ViraInsight\SocialAds\Services\AnalyzerService();
        });
    }

    /**
     * Boot services
     */
    public function boot(): void
    {
        // Register admin menu
        EventEmitter::getInstance()->on('admin.menu.register', function () {
            $this->registerAdminMenu();
        });
    }

    /**
     * Register admin menu
     */
    private function registerAdminMenu(): void
    {
        add_submenu_page(
            'vira-insight',
            __('Social Ads', 'vira-insight'),
            __('Social Ads', 'vira-insight'),
            'manage_options',
            'vira-insight-social-ads',
            function () {
                $controller = new \ViraInsight\SocialAds\Controllers\SocialAdsController();
                $controller->index();
            }
        );
    }
}
