<?php
/**
 * App Service Provider
 *
 * Registers core application services.
 *
 * @package ViraInsight\Providers
 */

declare(strict_types=1);

namespace ViraInsight\Providers;

use ViraInsight\Core\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register services
     */
    public function register(): void
    {
        // Register core services
        $this->container->singleton('app', function () {
            return \ViraInsight\Core\Kernel::getInstance();
        });
    }

    /**
     * Boot services
     */
    public function boot(): void
    {
        // Add custom actions
        $this->addAction('init', [$this, 'init']);
        $this->addAction('admin_init', [$this, 'adminInit']);
    }

    /**
     * Initialize plugin
     */
    public function init(): void
    {
        // Load text domain
        load_plugin_textdomain(
            'vira-insight',
            false,
            dirname(VRIN_PLUGIN_BASENAME) . '/resources/lang'
        );
    }

    /**
     * Admin initialization
     */
    public function adminInit(): void
    {
        // Register settings
        register_setting('vrin_settings', 'vrin_settings', [
            'sanitize_callback' => [$this, 'sanitizeSettings'],
        ]);
    }

    /**
     * Sanitize settings
     */
    public function sanitizeSettings($input): array
    {
        $sanitized = [];

        if (isset($input['seo_enabled'])) {
            $sanitized['seo_enabled'] = (bool) $input['seo_enabled'];
        }

        if (isset($input['google_ads_enabled'])) {
            $sanitized['google_ads_enabled'] = (bool) $input['google_ads_enabled'];
        }

        if (isset($input['social_ads_enabled'])) {
            $sanitized['social_ads_enabled'] = (bool) $input['social_ads_enabled'];
        }

        if (isset($input['cache_enabled'])) {
            $sanitized['cache_enabled'] = (bool) $input['cache_enabled'];
        }

        if (isset($input['cache_ttl'])) {
            $sanitized['cache_ttl'] = absint($input['cache_ttl']);
        }

        return $sanitized;
    }
}
