<?php
/**
 * SEO Controller
 *
 * Handles SEO-related requests.
 *
 * @package ViraInsight\SEO\Controllers
 */

declare(strict_types=1);

namespace ViraInsight\SEO\Controllers;

use ViraInsight\Http\Controllers\BaseController;
use ViraInsight\SEO\Services\AnalyzerService;
use ViraInsight\SEO\Services\ScoringService;

class SEOController extends BaseController
{
    /**
     * Analyzer service
     */
    private AnalyzerService $analyzer;

    /**
     * Scoring service
     */
    private ScoringService $scoring;

    /**
     * Constructor
     */
    public function __construct()
    {
        parent::__construct();
        $this->analyzer = new AnalyzerService();
        $this->scoring = new ScoringService();
    }

    /**
     * Display SEO dashboard
     */
    public function index(): void
    {
        if (!$this->checkCapability()) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'vira-insight'));
        }

        $this->render('admin.seo.index', [
            'title' => __('SEO Analysis', 'vira-insight'),
        ]);
    }

    /**
     * Analyze a post (REST endpoint)
     */
    public function analyzePost(\WP_REST_Request $request): \WP_REST_Response
    {
        $postId = (int) $request->get_param('post_id');

        if (!$postId || $postId < 1) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'Valid Post ID is required',
            ], 400);
        }

        // Get analysis
        $analysis = $this->analyzer->analyze($postId);

        if (isset($analysis['error'])) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => $analysis['error'],
            ], 404);
        }

        // Calculate score
        $score = $this->scoring->calculateScore($analysis);
        $analysis['score'] = $score;
        $analysis['grade'] = $this->scoring->getGrade($score);
        $analysis['recommendations'] = $this->scoring->getRecommendations($analysis);

        // Save analysis
        $this->saveAnalysis($postId, $analysis, $score);

        return new \WP_REST_Response([
            'success' => true,
            'data' => $analysis,
        ], 200);
    }

    /**
     * Get analysis history
     */
    public function getHistory(\WP_REST_Request $request): \WP_REST_Response
    {
        global $wpdb;
        $table = $wpdb->prefix . 'vrin_seo_analysis';

        $results = $wpdb->get_results(
            "SELECT * FROM {$table} ORDER BY created_at DESC LIMIT 50",
            ARRAY_A
        );

        return new \WP_REST_Response([
            'success' => true,
            'data' => $results,
        ], 200);
    }

    /**
     * Save analysis to database
     */
    private function saveAnalysis(int $postId, array $analysis, int $score): void
    {
        global $wpdb;
        $table = $wpdb->prefix . 'vrin_seo_analysis';

        $wpdb->replace($table, [
            'post_id' => $postId,
            'score' => $score,
            'analysis_data' => wp_json_encode($analysis),
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql'),
        ], ['%d', '%d', '%s', '%s', '%s']);
    }
}
