<?php
/**
 * SEO Scoring Service
 *
 * Calculates SEO scores based on analysis data.
 *
 * @package ViraInsight\SEO\Services
 */

declare(strict_types=1);

namespace ViraInsight\SEO\Services;

class ScoringService
{
    /**
     * Calculate overall SEO score
     */
    public function calculateScore(array $analysis): int
    {
        $score = 0;
        $maxScore = 100;

        // Title score (20 points)
        if ($analysis['title_analysis']['optimal']) {
            $score += 20;
        } else {
            $score += 10;
        }

        // Content length score (20 points)
        if ($analysis['content_analysis']['optimal']) {
            $score += 20;
        } elseif ($analysis['content_analysis']['word_count'] >= 200) {
            $score += 10;
        }

        // Meta description score (15 points)
        if ($analysis['meta_analysis']['description']['optimal']) {
            $score += 15;
        } elseif ($analysis['meta_analysis']['description']['exists']) {
            $score += 7;
        }

        // Readability score (15 points)
        $fleschScore = $analysis['readability']['flesch_score'];
        if ($fleschScore >= 60) {
            $score += 15;
        } elseif ($fleschScore >= 40) {
            $score += 10;
        } else {
            $score += 5;
        }

        // Headings score (10 points)
        $headings = $analysis['content_analysis']['heading_count'];
        if (($headings['h2'] + $headings['h3']) >= 2) {
            $score += 10;
        } elseif (($headings['h2'] + $headings['h3']) >= 1) {
            $score += 5;
        }

        // Internal links score (10 points)
        if ($analysis['internal_links']['optimal']) {
            $score += 10;
        } elseif ($analysis['internal_links']['internal_count'] >= 1) {
            $score += 5;
        }

        // Keyword usage score (10 points)
        if (count($analysis['keyword_density']['top_keywords']) >= 5) {
            $score += 10;
        } elseif (count($analysis['keyword_density']['top_keywords']) >= 3) {
            $score += 5;
        }

        return min($score, $maxScore);
    }

    /**
     * Get score grade
     */
    public function getGrade(int $score): string
    {
        if ($score >= 90) return 'A+';
        if ($score >= 80) return 'A';
        if ($score >= 70) return 'B';
        if ($score >= 60) return 'C';
        if ($score >= 50) return 'D';
        return 'F';
    }

    /**
     * Get recommendations
     */
    public function getRecommendations(array $analysis): array
    {
        $recommendations = [];

        if (!$analysis['title_analysis']['optimal']) {
            $recommendations[] = [
                'type' => 'warning',
                'message' => 'Optimize your title length to 30-60 characters.',
                'priority' => 'high',
            ];
        }

        if (!$analysis['content_analysis']['optimal']) {
            $recommendations[] = [
                'type' => 'warning',
                'message' => 'Add more content. Aim for at least 300 words.',
                'priority' => 'high',
            ];
        }

        if (!$analysis['meta_analysis']['description']['exists']) {
            $recommendations[] = [
                'type' => 'error',
                'message' => 'Add a meta description (120-160 characters).',
                'priority' => 'critical',
            ];
        }

        if ($analysis['readability']['flesch_score'] < 60) {
            $recommendations[] = [
                'type' => 'info',
                'message' => 'Improve readability by using shorter sentences and simpler words.',
                'priority' => 'medium',
            ];
        }

        if (!$analysis['internal_links']['optimal']) {
            $recommendations[] = [
                'type' => 'info',
                'message' => 'Add more internal links (at least 2-3).',
                'priority' => 'medium',
            ];
        }

        return $recommendations;
    }
}
