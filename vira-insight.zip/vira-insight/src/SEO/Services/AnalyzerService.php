<?php
/**
 * SEO Analyzer Service
 *
 * Performs on-page SEO analysis.
 *
 * @package ViraInsight\SEO\Services
 */

declare(strict_types=1);

namespace ViraInsight\SEO\Services;

class AnalyzerService
{
    /**
     * Analyze a post
     */
    public function analyze(int $postId): array
    {
        $post = get_post($postId);

        if (!$post) {
            return ['error' => 'Post not found'];
        }

        $content = $post->post_content;
        $title = $post->post_title;

        return [
            'post_id' => $postId,
            'title_analysis' => $this->analyzeTitle($title),
            'content_analysis' => $this->analyzeContent($content),
            'meta_analysis' => $this->analyzeMeta($postId),
            'readability' => $this->calculateReadability($content),
            'keyword_density' => $this->analyzeKeywordDensity($content),
            'internal_links' => $this->analyzeInternalLinks($content),
            'score' => 0, // Will be calculated by ScoringService
        ];
    }

    /**
     * Analyze title
     */
    private function analyzeTitle(string $title): array
    {
        $length = strlen($title);
        $wordCount = str_word_count($title);

        return [
            'length' => $length,
            'word_count' => $wordCount,
            'optimal' => $length >= 30 && $length <= 60,
            'recommendations' => $this->getTitleRecommendations($length),
        ];
    }

    /**
     * Analyze content
     */
    private function analyzeContent(string $content): array
    {
        $cleanContent = wp_strip_all_tags($content);
        $wordCount = str_word_count($cleanContent);
        $characterCount = strlen($cleanContent);

        return [
            'word_count' => $wordCount,
            'character_count' => $characterCount,
            'paragraph_count' => substr_count($content, '<p>'),
            'heading_count' => $this->countHeadings($content),
            'optimal' => $wordCount >= 300,
            'recommendations' => $this->getContentRecommendations($wordCount),
        ];
    }

    /**
     * Analyze meta tags
     */
    private function analyzeMeta(int $postId): array
    {
        $metaDescription = get_post_meta($postId, '_meta_description', true);
        $metaKeywords = get_post_meta($postId, '_meta_keywords', true);

        $descLength = strlen($metaDescription);

        return [
            'description' => [
                'exists' => !empty($metaDescription),
                'length' => $descLength,
                'optimal' => $descLength >= 120 && $descLength <= 160,
            ],
            'keywords' => [
                'exists' => !empty($metaKeywords),
                'count' => !empty($metaKeywords) ? count(explode(',', $metaKeywords)) : 0,
            ],
        ];
    }

    /**
     * Calculate readability score
     */
    private function calculateReadability(string $content): array
    {
        $cleanContent = wp_strip_all_tags($content);
        $sentences = preg_split('/[.!?]+/', $cleanContent, -1, PREG_SPLIT_NO_EMPTY);
        $sentenceCount = count($sentences);
        $wordCount = str_word_count($cleanContent);
        $syllableCount = $this->countSyllables($cleanContent);

        // Flesch Reading Ease Score
        if ($sentenceCount > 0 && $wordCount > 0) {
            $avgWordsPerSentence = $wordCount / $sentenceCount;
            $avgSyllablesPerWord = $syllableCount / $wordCount;
            $fleschScore = 206.835 - (1.015 * $avgWordsPerSentence) - (84.6 * $avgSyllablesPerWord);
            $fleschScore = max(0, min(100, $fleschScore));
        } else {
            $fleschScore = 0;
        }

        return [
            'flesch_score' => round($fleschScore, 2),
            'reading_level' => $this->getReadingLevel($fleschScore),
            'avg_words_per_sentence' => $sentenceCount > 0 ? round($wordCount / $sentenceCount, 2) : 0,
        ];
    }

    /**
     * Analyze keyword density
     */
    private function analyzeKeywordDensity(string $content): array
    {
        $cleanContent = strtolower(wp_strip_all_tags($content));
        $words = str_word_count($cleanContent, 1);
        $totalWords = count($words);

        if ($totalWords === 0) {
            return ['top_keywords' => []];
        }

        $wordFreq = array_count_values($words);

        // Filter out common words
        $stopWords = ['the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'is', 'was', 'are', 'were'];
        $wordFreq = array_diff_key($wordFreq, array_flip($stopWords));

        arsort($wordFreq);
        $topKeywords = array_slice($wordFreq, 0, 10);

        $keywordData = [];
        foreach ($topKeywords as $word => $count) {
            $keywordData[] = [
                'keyword' => $word,
                'count' => $count,
                'density' => round(($count / $totalWords) * 100, 2),
            ];
        }

        return ['top_keywords' => $keywordData];
    }

    /**
     * Analyze internal links
     */
    private function analyzeInternalLinks(string $content): array
    {
        $siteUrl = get_site_url();
        preg_match_all('/<a[^>]+href="([^"]+)"[^>]*>/i', $content, $matches);

        $internalLinks = 0;
        $externalLinks = 0;

        foreach ($matches[1] as $url) {
            if (strpos($url, $siteUrl) === 0 || strpos($url, '/') === 0) {
                $internalLinks++;
            } else {
                $externalLinks++;
            }
        }

        return [
            'internal_count' => $internalLinks,
            'external_count' => $externalLinks,
            'total_count' => $internalLinks + $externalLinks,
            'optimal' => $internalLinks >= 2,
        ];
    }

    /**
     * Count headings
     */
    private function countHeadings(string $content): array
    {
        return [
            'h1' => substr_count($content, '<h1'),
            'h2' => substr_count($content, '<h2'),
            'h3' => substr_count($content, '<h3'),
            'h4' => substr_count($content, '<h4'),
            'h5' => substr_count($content, '<h5'),
            'h6' => substr_count($content, '<h6'),
        ];
    }

    /**
     * Count syllables (simplified)
     */
    private function countSyllables(string $text): int
    {
        $words = str_word_count(strtolower($text), 1);
        $syllableCount = 0;

        foreach ($words as $word) {
            $syllableCount += preg_match_all('/[aeiouy]+/', $word);
        }

        return $syllableCount;
    }

    /**
     * Get reading level
     */
    private function getReadingLevel(float $score): string
    {
        if ($score >= 90) return 'Very Easy';
        if ($score >= 80) return 'Easy';
        if ($score >= 70) return 'Fairly Easy';
        if ($score >= 60) return 'Standard';
        if ($score >= 50) return 'Fairly Difficult';
        if ($score >= 30) return 'Difficult';
        return 'Very Difficult';
    }

    /**
     * Get title recommendations
     */
    private function getTitleRecommendations(int $length): array
    {
        $recommendations = [];

        if ($length < 30) {
            $recommendations[] = 'Title is too short. Aim for 30-60 characters.';
        } elseif ($length > 60) {
            $recommendations[] = 'Title is too long. Aim for 30-60 characters.';
        } else {
            $recommendations[] = 'Title length is optimal.';
        }

        return $recommendations;
    }

    /**
     * Get content recommendations
     */
    private function getContentRecommendations(int $wordCount): array
    {
        $recommendations = [];

        if ($wordCount < 300) {
            $recommendations[] = 'Content is too short. Aim for at least 300 words.';
        } elseif ($wordCount < 600) {
            $recommendations[] = 'Consider adding more content for better SEO (600+ words).';
        } else {
            $recommendations[] = 'Content length is good.';
        }

        return $recommendations;
    }
}
