<?php
/**
 * Social Ads Controller
 *
 * Handles Social Ads-related requests.
 *
 * @package ViraInsight\SocialAds\Controllers
 */

declare(strict_types=1);

namespace ViraInsight\SocialAds\Controllers;

use ViraInsight\Http\Controllers\BaseController;
use ViraInsight\SocialAds\Services\AnalyzerService;

class SocialAdsController extends BaseController
{
    /**
     * Analyzer service
     */
    private AnalyzerService $analyzer;

    /**
     * Constructor
     */
    public function __construct()
    {
        parent::__construct();
        $this->analyzer = new AnalyzerService();
    }

    /**
     * Display Social Ads dashboard
     */
    public function index(): void
    {
        if (!$this->checkCapability()) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'vira-insight'));
        }

        $this->render('admin.social-ads.index', [
            'title' => __('Social Ads Insights', 'vira-insight'),
        ]);
    }

    /**
     * Analyze ad performance (REST endpoint)
     */
    public function analyzeAd(\WP_REST_Request $request): \WP_REST_Response
    {
        $adData = [
            'platform' => sanitize_text_field($request->get_param('platform') ?? 'facebook'),
            'impressions' => intval($request->get_param('impressions') ?? 0),
            'engagements' => intval($request->get_param('engagements') ?? 0),
            'likes' => intval($request->get_param('likes') ?? 0),
            'shares' => intval($request->get_param('shares') ?? 0),
            'comments' => intval($request->get_param('comments') ?? 0),
            'clicks' => intval($request->get_param('clicks') ?? 0),
            'spend' => floatval($request->get_param('spend') ?? 0),
            'revenue' => floatval($request->get_param('revenue') ?? 0),
            'reach' => intval($request->get_param('reach') ?? 0),
            'frequency' => floatval($request->get_param('frequency') ?? 1),
            'targeting_type' => sanitize_text_field($request->get_param('targeting_type') ?? 'broad'),
        ];

        // Calculate derived metrics
        $adData['engagement_rate'] = $adData['impressions'] > 0
            ? ($adData['engagements'] / $adData['impressions']) * 100
            : 0;
        $adData['ctr'] = $adData['impressions'] > 0
            ? ($adData['clicks'] / $adData['impressions']) * 100
            : 0;
        $adData['roas'] = $adData['spend'] > 0
            ? $adData['revenue'] / $adData['spend']
            : 0;

        $analysis = $this->analyzer->analyzeAdPerformance($adData);

        return new \WP_REST_Response([
            'success' => true,
            'data' => $analysis,
        ], 200);
    }

    /**
     * Estimate content performance (REST endpoint)
     */
    public function estimateContent(\WP_REST_Request $request): \WP_REST_Response
    {
        $contentData = [
            'text' => sanitize_textarea_field($request->get_param('text') ?? ''),
            'has_video' => (bool) $request->get_param('has_video'),
            'has_image' => (bool) $request->get_param('has_image'),
        ];

        $estimate = $this->analyzer->estimateContentPerformance($contentData);

        return new \WP_REST_Response([
            'success' => true,
            'data' => $estimate,
        ], 200);
    }
}
