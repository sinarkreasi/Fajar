<?php
/**
 * Social Ads Analyzer Service
 *
 * Provides social ad performance analysis (Base free version).
 *
 * @package ViraInsight\SocialAds\Services
 */

declare(strict_types=1);

namespace ViraInsight\SocialAds\Services;

class AnalyzerService
{
    /**
     * Analyze ad performance
     */
    public function analyzeAdPerformance(array $adData): array
    {
        return [
            'performance_score' => $this->calculatePerformanceScore($adData),
            'engagement_analysis' => $this->analyzeEngagement($adData),
            'audience_insights' => $this->analyzeAudience($adData),
            'roas_analysis' => $this->analyzeROAS($adData),
            'recommendations' => $this->getRecommendations($adData),
        ];
    }

    /**
     * Calculate performance score
     */
    private function calculatePerformanceScore(array $data): int
    {
        $score = 40; // Base score

        // Engagement rate
        $engagementRate = $data['engagement_rate'] ?? 0;
        if ($engagementRate >= 5) {
            $score += 20;
        } elseif ($engagementRate >= 3) {
            $score += 15;
        } elseif ($engagementRate >= 1) {
            $score += 10;
        }

        // CTR
        $ctr = $data['ctr'] ?? 0;
        if ($ctr >= 3) {
            $score += 20;
        } elseif ($ctr >= 2) {
            $score += 15;
        } elseif ($ctr >= 1) {
            $score += 10;
        }

        // ROAS
        $roas = $data['roas'] ?? 0;
        if ($roas >= 4) {
            $score += 20;
        } elseif ($roas >= 2) {
            $score += 15;
        } elseif ($roas >= 1) {
            $score += 10;
        }

        return min($score, 100);
    }

    /**
     * Analyze engagement
     */
    private function analyzeEngagement(array $data): array
    {
        $impressions = $data['impressions'] ?? 0;
        $engagements = $data['engagements'] ?? 0;
        $likes = $data['likes'] ?? 0;
        $shares = $data['shares'] ?? 0;
        $comments = $data['comments'] ?? 0;

        $engagementRate = $impressions > 0 ? ($engagements / $impressions) * 100 : 0;

        return [
            'total_engagements' => $engagements,
            'engagement_rate' => round($engagementRate, 2),
            'likes' => $likes,
            'shares' => $shares,
            'comments' => $comments,
            'status' => $this->getEngagementStatus($engagementRate),
        ];
    }

    /**
     * Analyze audience
     */
    private function analyzeAudience(array $data): array
    {
        $platform = $data['platform'] ?? 'facebook';
        $targetingType = $data['targeting_type'] ?? 'broad';

        return [
            'platform' => $platform,
            'targeting_type' => $targetingType,
            'reach' => $data['reach'] ?? 0,
            'frequency' => $data['frequency'] ?? 1,
            'audience_quality' => $this->assessAudienceQuality($data),
        ];
    }

    /**
     * Analyze ROAS
     */
    private function analyzeROAS(array $data): array
    {
        $spend = $data['spend'] ?? 0;
        $revenue = $data['revenue'] ?? 0;

        $roas = $spend > 0 ? $revenue / $spend : 0;

        return [
            'roas' => round($roas, 2),
            'spend' => $spend,
            'revenue' => $revenue,
            'profit' => round($revenue - $spend, 2),
            'status' => $this->getROASStatus($roas),
            'benchmark' => 2.0,
        ];
    }

    /**
     * Get recommendations
     */
    private function getRecommendations(array $data): array
    {
        $recommendations = [];

        $engagementRate = $data['engagement_rate'] ?? 0;
        if ($engagementRate < 1) {
            $recommendations[] = [
                'type' => 'warning',
                'message' => 'Low engagement rate. Consider improving creative content and targeting.',
                'priority' => 'high',
            ];
        }

        $ctr = $data['ctr'] ?? 0;
        if ($ctr < 1) {
            $recommendations[] = [
                'type' => 'warning',
                'message' => 'Low CTR. Test different ad formats and calls-to-action.',
                'priority' => 'high',
            ];
        }

        $roas = $data['roas'] ?? 0;
        if ($roas < 1) {
            $recommendations[] = [
                'type' => 'error',
                'message' => 'ROAS is below break-even. Review targeting, creative, and pricing.',
                'priority' => 'critical',
            ];
        } elseif ($roas < 2) {
            $recommendations[] = [
                'type' => 'info',
                'message' => 'ROAS can be improved. Consider optimization strategies.',
                'priority' => 'medium',
            ];
        }

        $frequency = $data['frequency'] ?? 1;
        if ($frequency > 3) {
            $recommendations[] = [
                'type' => 'warning',
                'message' => 'High frequency detected. Audience may be experiencing ad fatigue. Expand targeting or refresh creative.',
                'priority' => 'medium',
            ];
        }

        return $recommendations;
    }

    /**
     * Get engagement status
     */
    private function getEngagementStatus(float $rate): string
    {
        if ($rate >= 5) return 'excellent';
        if ($rate >= 3) return 'good';
        if ($rate >= 1) return 'average';
        return 'poor';
    }

    /**
     * Get ROAS status
     */
    private function getROASStatus(float $roas): string
    {
        if ($roas >= 4) return 'excellent';
        if ($roas >= 2) return 'good';
        if ($roas >= 1) return 'break_even';
        return 'losing';
    }

    /**
     * Assess audience quality
     */
    private function assessAudienceQuality(array $data): string
    {
        $engagementRate = $data['engagement_rate'] ?? 0;
        $ctr = $data['ctr'] ?? 0;

        if ($engagementRate >= 3 && $ctr >= 2) return 'high';
        if ($engagementRate >= 1 && $ctr >= 1) return 'medium';
        return 'low';
    }

    /**
     * Estimate content performance
     */
    public function estimateContentPerformance(array $contentData): array
    {
        $textLength = strlen($contentData['text'] ?? '');
        $hasVideo = $contentData['has_video'] ?? false;
        $hasImage = $contentData['has_image'] ?? false;

        $scoreMultiplier = 1;

        if ($hasVideo) $scoreMultiplier += 0.5;
        if ($hasImage && !$hasVideo) $scoreMultiplier += 0.3;
        if ($textLength > 0 && $textLength <= 125) $scoreMultiplier += 0.2;

        $baseEngagement = 2.0; // Base engagement rate
        $estimatedEngagement = $baseEngagement * $scoreMultiplier;

        return [
            'estimated_engagement_rate' => round($estimatedEngagement, 2),
            'score_multiplier' => round($scoreMultiplier, 2),
            'content_quality' => $this->getContentQualityRating($scoreMultiplier),
            'suggestions' => $this->getContentSuggestions($contentData),
        ];
    }

    /**
     * Get content quality rating
     */
    private function getContentQualityRating(float $multiplier): string
    {
        if ($multiplier >= 1.5) return 'excellent';
        if ($multiplier >= 1.2) return 'good';
        if ($multiplier >= 1.0) return 'average';
        return 'needs_improvement';
    }

    /**
     * Get content suggestions
     */
    private function getContentSuggestions(array $data): array
    {
        $suggestions = [];

        if (!($data['has_video'] ?? false)) {
            $suggestions[] = 'Consider adding video content for higher engagement.';
        }

        if (!($data['has_image'] ?? false) && !($data['has_video'] ?? false)) {
            $suggestions[] = 'Add visual content (image or video) to improve performance.';
        }

        $textLength = strlen($data['text'] ?? '');
        if ($textLength > 125) {
            $suggestions[] = 'Shorten text to 125 characters or less for better engagement.';
        } elseif ($textLength === 0) {
            $suggestions[] = 'Add descriptive text to provide context.';
        }

        return $suggestions;
    }
}
