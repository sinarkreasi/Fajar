<?php

namespace ViraInsight\Jobs;

class RunAnalyticsJob
{
    public array $params;

    public function __construct(array $params = [])
    {
        $this->params = $params;
    }

    public function handle()
    {
        // run logic here later
        return true;
    }
}
