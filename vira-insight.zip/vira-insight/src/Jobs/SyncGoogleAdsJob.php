<?php

namespace ViraInsight\Jobs;

class SyncGoogleAdsJob
{
    public string $accountId;

    public function __construct(string $accountId)
    {
        $this->accountId = $accountId;
    }

    public function handle()
    {
        return true;
    }
}
