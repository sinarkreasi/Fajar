<?php

namespace ViraInsight\Jobs;

class SyncSocialAdsJob
{
    public string $platform;

    public function __construct(string $platform)
    {
        $this->platform = $platform;
    }

    public function handle()
    {
        return true;
    }
}
