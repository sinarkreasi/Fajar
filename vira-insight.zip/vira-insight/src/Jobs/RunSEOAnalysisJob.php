<?php

namespace ViraInsight\Jobs;

class RunSEOAnalysisJob
{
    public int $postId;

    public function __construct(int $postId)
    {
        $this->postId = $postId;
    }

    public function handle()
    {
        return true;
    }
}
