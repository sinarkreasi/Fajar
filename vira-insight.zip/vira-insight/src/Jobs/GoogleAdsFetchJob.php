<?php

namespace ViraInsight\Jobs;

use ViraInsight\GoogleAds\Services\GoogleAdsService;

class GoogleAdsFetchJob
{
    public static function run(): bool
    {
        try {
            $service = vrin_app(GoogleAdsService::class);

            $customerId = get_option('vrin_google_ads_customer_id');

            if (!$customerId) {
                error_log('[ViraInsight] Google Ads Customer ID not configured');
                return false;
            }

            $result = $service->fetchCampaignStats($customerId);

            if ($result) {
                do_action('vrin_google_ads_synced');
                error_log('[ViraInsight] Google Ads data synced successfully');
            }

            return $result;
        } catch (\Exception $e) {
            error_log('[ViraInsight] Google Ads fetch job failed: ' . $e->getMessage());
            return false;
        }
    }
}