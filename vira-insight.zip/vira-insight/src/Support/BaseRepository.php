<?php

namespace ViraInsight\Support;

abstract class BaseRepository
{
    protected string $table;

    public function __construct()
    {
        global $wpdb;

        // Allow "vira_insight_xxx" table naming rules
        $this->table = $wpdb->prefix . $this->table;
    }

    protected function db()
    {
        global $wpdb;
        return $wpdb;
    }

    /**
     * Find row by ID.
     */
    public function find(int $id)
    {
        return $this->db()->get_row(
            $this->db()->prepare("SELECT * FROM {$this->table} WHERE id = %d", $id),
            ARRAY_A
        );
    }

    /**
     * Get all rows, optional limit.
     */
    public function all(int $limit = 1000): array
    {
        return $this->db()->get_results(
            $this->db()->prepare("SELECT * FROM {$this->table} LIMIT %d", $limit),
            ARRAY_A
        );
    }

    /**
     * Insert new row.
     */
    public function insert(array $data): int
    {
        $this->db()->insert($this->table, $data);
        return (int) $this->db()->insert_id;
    }

    /**
     * Update by ID.
     */
    public function update(int $id, array $data): bool
    {
        return (bool) $this->db()->update(
            $this->table,
            $data,
            ['id' => $id]
        );
    }

    /**
     * Delete row by ID.
     */
    public function delete(int $id): bool
    {
        return (bool) $this->db()->delete(
            $this->table,
            ['id' => $id]
        );
    }

    /**
     * Run custom safe query.
     */
    protected function query(string $sql, array $params = [])
    {
        if (!empty($params)) {
            $sql = $this->db()->prepare($sql, $params);
        }

        return $this->db()->get_results($sql, ARRAY_A);
    }
}