<?php

namespace ViraInsight\Support;

use ViraInsight\Core\EventEmitter;
use ViraInsight\Core\Cache;

abstract class BaseService
{
    protected EventEmitter $events;

    public function __construct(EventEmitter $events)
    {
        $this->events = $events;
    }

    /**
     * Dispatch a domain event.
     */
    protected function dispatch(string $event, $payload = null): void
    {
        $this->events->dispatch($event, $payload);
    }

    /**
     * Log debug information to WordPress debug.log
     */
    protected function log($message): void
    {
        if (defined('WP_DEBUG') && WP_DEBUG === true) {
            error_log('[ViraInsight] ' . print_r($message, true));
        }
    }

    /**
     * Simple validator wrapper (extend if needed)
     */
    protected function validate(array $data, array $rules): bool
    {
        // Minimalist validation, expandable later
        foreach ($rules as $field => $rule) {
            if ($rule === 'required' && empty($data[$field])) {
                return false;
            }
        }

        return true;
    }

    /**
     * Cache helper
     */
    protected function cacheGet(string $key, $default = null)
    {
        return Cache::get($key, $default);
    }

    protected function cachePut(string $key, $value, int $ttl = 3600): void
    {
        Cache::put($key, $value, $ttl);
    }

    protected function cacheForget(string $key): void
    {
        Cache::forget($key);
    }
}