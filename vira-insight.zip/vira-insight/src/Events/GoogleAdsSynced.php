<?php

namespace ViraInsight\Events;

class GoogleAdsSynced
{
    public string $accountId;

    public function __construct(string $accountId)
    {
        $this->accountId = $accountId;
    }
}
