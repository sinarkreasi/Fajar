<?php

namespace ViraInsight\Events;

class SEOAnalysisTriggered
{
    public int $postId;

    public function __construct(int $postId)
    {
        $this->postId = $postId;
    }
}
