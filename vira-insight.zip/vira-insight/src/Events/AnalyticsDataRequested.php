<?php

namespace ViraInsight\Events;

class AnalyticsDataRequested
{
    public array $payload;

    public function __construct(array $payload = [])
    {
        $this->payload = $payload;
    }
}
