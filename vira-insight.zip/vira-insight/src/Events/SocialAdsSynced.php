<?php

namespace ViraInsight\Events;

class SocialAdsSynced
{
    public string $platform;

    public function __construct(string $platform)
    {
        $this->platform = $platform;
    }
}
