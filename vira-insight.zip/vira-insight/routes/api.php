<?php
/**
 * REST API Routes
 *
 * Register all REST API routes for the plugin.
 *
 * @package ViraInsight
 */

declare(strict_types=1);

use ViraInsight\SEO\Controllers\SEOController;
use ViraInsight\GoogleAds\Controllers\GoogleAdsController;
use ViraInsight\SocialAds\Controllers\SocialAdsController;
use ViraInsight\UI\Admin\Controllers\SettingsController;
use ViraInsight\UI\Admin\Controllers\ExtensionsController;

// SEO Routes
register_rest_route('vrin/v1', '/seo/analyze', [
    'methods' => 'POST',
    'callback' => [new SEOController(), 'analyzePost'],
    'permission_callback' => function () {
        return current_user_can('edit_posts');
    },
]);

register_rest_route('vrin/v1', '/seo/history', [
    'methods' => 'GET',
    'callback' => [new SEOController(), 'getHistory'],
    'permission_callback' => function () {
        return current_user_can('edit_posts');
    },
]);

// Google Ads Routes
register_rest_route('vrin/v1', '/google-ads/analyze', [
    'methods' => 'POST',
    'callback' => [new GoogleAdsController(), 'analyzeCampaign'],
    'permission_callback' => function () {
        return current_user_can('manage_options');
    },
]);

register_rest_route('vrin/v1', '/google-ads/projections', [
    'methods' => 'POST',
    'callback' => [new GoogleAdsController(), 'getProjections'],
    'permission_callback' => function () {
        return current_user_can('manage_options');
    },
]);

register_rest_route('vrin/v1', '/google-ads/stats', [
    'methods' => 'GET',
    'callback' => [new GoogleAdsController(), 'stats'],
    'permission_callback' => function () {
        return current_user_can('manage_options');
    },
]);

register_rest_route('vrin/v1', '/google-ads/quick-stats', [
    'methods' => 'GET',
    'callback' => [new GoogleAdsController(), 'quickStats'],
    'permission_callback' => function () {
        return current_user_can('manage_options');
    },
]);

// Social Ads Routes
register_rest_route('vrin/v1', '/social-ads/analyze', [
    'methods' => 'POST',
    'callback' => [new SocialAdsController(), 'analyzeAd'],
    'permission_callback' => function () {
        return current_user_can('manage_options');
    },
]);

register_rest_route('vrin/v1', '/social-ads/estimate-content', [
    'methods' => 'POST',
    'callback' => [new SocialAdsController(), 'estimateContent'],
    'permission_callback' => function () {
        return current_user_can('manage_options');
    },
]);

// Settings Routes
register_rest_route('vrin/v1', '/settings', [
    'methods' => 'GET',
    'callback' => [new SettingsController(), 'getSettings'],
    'permission_callback' => function () {
        return current_user_can('manage_options');
    },
]);

register_rest_route('vrin/v1', '/settings', [
    'methods' => 'POST',
    'callback' => [new SettingsController(), 'saveSettings'],
    'permission_callback' => function () {
        return current_user_can('manage_options');
    },
]);

// Extension Routes
register_rest_route('vrin/v1', '/extensions/install', [
    'methods' => 'POST',
    'callback' => [new ExtensionsController(), 'install'],
    'permission_callback' => function () {
        return current_user_can('manage_options');
    },
]);

register_rest_route('vrin/v1', '/extensions/activate', [
    'methods' => 'POST',
    'callback' => [new ExtensionsController(), 'activate'],
    'permission_callback' => function () {
        return current_user_can('manage_options');
    },
]);

register_rest_route('vrin/v1', '/extensions/deactivate', [
    'methods' => 'POST',
    'callback' => [new ExtensionsController(), 'deactivate'],
    'permission_callback' => function () {
        return current_user_can('manage_options');
    },
]);

register_rest_route('vrin/v1', '/extensions/uninstall', [
    'methods' => 'POST',
    'callback' => [new ExtensionsController(), 'uninstall'],
    'permission_callback' => function () {
        return current_user_can('manage_options');
    },
]);
