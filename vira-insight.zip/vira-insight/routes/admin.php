<?php
/**
 * Admin Routes
 *
 * Register admin menu items.
 *
 * @package ViraInsight
 */

declare(strict_types=1);

use ViraInsight\UI\Admin\Controllers\DashboardController;

// Register main admin menu and submenus
add_action('admin_menu', function () {
    DashboardController::registerMenu();
});

// Enqueue admin assets
add_action('admin_enqueue_scripts', function () {
    DashboardController::enqueueAssets();
});
