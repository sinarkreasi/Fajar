<?php
/**
 * Plugin Name: Vira Insight
 * Plugin URI: https://viraloka.com/pro/vira-insights
 * Description: SEO analysis, Google Ads intelligence, and Social Ads insights platform with premium extension support.
 * Version: 1.0.0
 * Requires at least: 6.8
 * Requires PHP: 8.2
 * Author: Viraloka
 * Author URI: https://viraloka.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: vira-insight
 *
 * @package ViraInsight
 */

declare(strict_types=1);

namespace ViraInsight;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('VRIN_VERSION', '1.0.0');
define('VRIN_PLUGIN_FILE', __FILE__);
define('VRIN_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('VRIN_PLUGIN_URL', plugin_dir_url(__FILE__));
define('VRIN_PLUGIN_BASENAME', plugin_basename(__FILE__));
define('VRIN_MIN_PHP_VERSION', '8.2');
define('VRIN_MIN_WP_VERSION', '6.8');

// Check PHP version
if (version_compare(PHP_VERSION, VRIN_MIN_PHP_VERSION, '<')) {
    add_action('admin_notices', function () {
        echo '<div class="error"><p>';
        printf(
            esc_html__('Vira Insight requires PHP %s or higher. You are running PHP %s.', 'vira-insight'),
            esc_html(VRIN_MIN_PHP_VERSION),
            esc_html(PHP_VERSION)
        );
        echo '</p></div>';
    });
    return;
}

// Check WordPress version
if (version_compare(get_bloginfo('version'), VRIN_MIN_WP_VERSION, '<')) {
    add_action('admin_notices', function () {
        echo '<div class="error"><p>';
        printf(
            esc_html__('Vira Insight requires WordPress %s or higher. You are running WordPress %s.', 'vira-insight'),
            esc_html(VRIN_MIN_WP_VERSION),
            esc_html(get_bloginfo('version'))
        );
        echo '</p></div>';
    });
    return;
}

// Load Composer autoloader or manual autoloader
if (file_exists(VRIN_PLUGIN_DIR . 'vendor/autoload.php')) {
    require_once VRIN_PLUGIN_DIR . 'vendor/autoload.php';
} else {
    require_once VRIN_PLUGIN_DIR . 'autoload.php';
}

// Bootstrap the application
require_once VRIN_PLUGIN_DIR . 'bootstrap/app.php';

// Boot the kernel
use ViraInsight\Core\Kernel;

$kernel = Kernel::getInstance();

// Plugin activation hook
register_activation_hook(__FILE__, function () use ($kernel) {
    $kernel->activate();
});

// Plugin deactivation hook
register_deactivation_hook(__FILE__, function () use ($kernel) {
    $kernel->deactivate();
});

// Initialize the plugin
add_action('plugins_loaded', function () use ($kernel) {
    $kernel->boot();
});

// Uninstall hook (static method required)
register_uninstall_hook(__FILE__, [Kernel::class, 'uninstall']);
