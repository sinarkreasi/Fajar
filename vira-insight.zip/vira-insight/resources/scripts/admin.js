document.addEventListener("DOMContentLoaded", function () {

    window.ViraInsight = {
        ajax(action, data = {}, callback = null) {
            const body = new FormData();
            body.append("action", action);

            for (let key in data) {
                body.append(key, data[key]);
            }

            fetch(ajaxurl, {
                method: "POST",
                credentials: "same-origin",
                body
            })
                .then(res => res.json())
                .then(json => callback && callback(json))
                .catch(err => console.error("ViraInsight AJAX Error:", err));
        },

        toast(message) {
            alert(message);
        }
    };

});
