/**
 * Google Ads Campaign Stats JavaScript
 *
 * @package ViraInsight
 */

(function($) {
    'use strict';

    class GoogleAdsCampaignStats {
        constructor() {
            this.endpoint = vrinAjax.restUrl + '/google-ads/stats';
            this.init();
        }

        init() {
            this.bindEvents();
            this.loadCampaignStats();
        }

        bindEvents() {
            $('#refresh-campaigns').on('click', () => {
                this.loadCampaignStats();
            });
        }

        loadCampaignStats() {
            this.showLoading();

            $.ajax({
                url: this.endpoint,
                method: 'GET',
                headers: {
                    'X-WP-Nonce': vrinAjax.nonce
                }
            })
            .done((response) => {
                this.hideLoading();
                
                if (response.success && response.data) {
                    this.renderCampaignStats(response.data);
                } else {
                    this.showError(response.message || 'Failed to load campaign data');
                }
            })
            .fail((xhr) => {
                this.hideLoading();
                
                let message = 'Network error occurred';
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    message = xhr.responseJSON.message;
                }
                
                this.showError(message);
            });
        }

        renderCampaignStats(campaigns) {
            const tbody = $('#campaigns-tbody');
            tbody.empty();

            if (!campaigns || campaigns.length === 0) {
                this.showEmpty();
                return;
            }

            campaigns.forEach(campaign => {
                const row = this.createCampaignRow(campaign);
                tbody.append(row);
            });

            this.showTable();
        }

        createCampaignRow(campaign) {
            const ctr = parseFloat(campaign.ctr || 0).toFixed(2);
            const avgCpc = this.formatCurrency(campaign.avg_cpc || 0);
            const cost = this.formatCostMicros(campaign.cost_micros || 0);
            const updatedAt = this.formatDate(campaign.updated_at);

            return `
                <tr>
                    <td class="campaign-name">
                        <strong>${this.escapeHtml(campaign.name || 'Unnamed Campaign')}</strong>
                        <small class="campaign-id">ID: ${campaign.campaign_id}</small>
                    </td>
                    <td class="impressions">${this.formatNumber(campaign.impressions || 0)}</td>
                    <td class="clicks">${this.formatNumber(campaign.clicks || 0)}</td>
                    <td class="ctr">
                        <span class="ctr-value ${this.getCtrClass(ctr)}">${ctr}%</span>
                    </td>
                    <td class="avg-cpc">${avgCpc}</td>
                    <td class="cost">${cost}</td>
                    <td class="updated-at">${updatedAt}</td>
                </tr>
            `;
        }

        formatCurrency(micros) {
            const amount = micros / 1000000; // Convert micros to currency
            return new Intl.NumberFormat('en-US', {
                style: 'currency',
                currency: 'USD'
            }).format(amount);
        }

        formatCostMicros(micros) {
            return this.formatCurrency(micros);
        }

        formatNumber(num) {
            return new Intl.NumberFormat().format(num);
        }

        formatDate(dateString) {
            if (!dateString) return '-';
            
            const date = new Date(dateString);
            return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], {
                hour: '2-digit',
                minute: '2-digit'
            });
        }

        getCtrClass(ctr) {
            const ctrValue = parseFloat(ctr);
            if (ctrValue >= 5) return 'ctr-excellent';
            if (ctrValue >= 3) return 'ctr-good';
            if (ctrValue >= 1) return 'ctr-average';
            return 'ctr-poor';
        }

        escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        showLoading() {
            $('#campaigns-loading').show();
            $('#campaigns-table-container').hide();
            $('#campaigns-empty').hide();
            $('#campaigns-error').hide();
        }

        hideLoading() {
            $('#campaigns-loading').hide();
        }

        showTable() {
            $('#campaigns-table-container').show();
            $('#campaigns-empty').hide();
            $('#campaigns-error').hide();
        }

        showEmpty() {
            $('#campaigns-table-container').hide();
            $('#campaigns-empty').show();
            $('#campaigns-error').hide();
        }

        showError(message) {
            $('#campaigns-table-container').hide();
            $('#campaigns-empty').hide();
            $('#campaigns-error-message').text(message);
            $('#campaigns-error').show();
        }
    }

    // Initialize when document is ready
    $(document).ready(function() {
        if ($('#vrin-google-ads-campaign-stats').length) {
            new GoogleAdsCampaignStats();
        }
    });

})(jQuery);