/**
 * Google Ads Admin JavaScript
 *
 * @package ViraInsight
 */

(function($) {
    'use strict';

    class GoogleAdsAdmin {
        constructor() {
            this.init();
        }

        init() {
            this.bindEvents();
            this.loadQuickStats();
            this.updateSyncStatus();
        }

        bindEvents() {
            // Settings form
            $('#vrin-google-ads-settings-form').on('submit', (e) => {
                this.saveSettings(e);
            });

            // Test connection
            $('#test-connection').on('click', () => {
                this.testConnection();
            });

            // Manual sync
            $('#sync-now, #manual-sync').on('click', () => {
                this.manualSync();
            });

            // Reset sync schedule
            $('#reset-sync').on('click', () => {
                this.resetSyncSchedule();
            });

            // View sync logs
            $('#view-sync-logs').on('click', (e) => {
                e.preventDefault();
                this.toggleSyncLogs();
            });

            // Stats period change
            $('#stats-period').on('change', () => {
                this.loadQuickStats();
            });
        }

        saveSettings(e) {
            e.preventDefault();

            const formData = new FormData(e.target);
            const data = Object.fromEntries(formData.entries());

            this.showFeedback('Saving configuration...', 'info');

            $.ajax({
                url: vrinAjax.ajaxUrl,
                method: 'POST',
                data: {
                    action: 'vrin_save_google_ads_settings',
                    nonce: data.vrin_google_ads_nonce,
                    settings: data
                }
            })
            .done((response) => {
                if (response.success) {
                    this.showFeedback('Configuration saved successfully!', 'success');
                    
                    // Update status badge
                    $('.vrin-status-badge')
                        .removeClass('vrin-status-disconnected')
                        .addClass('vrin-status-connected')
                        .text('Connected');
                    
                    // Show additional buttons
                    $('#test-connection, #sync-now').show();
                } else {
                    this.showFeedback(response.data || 'Failed to save configuration', 'error');
                }
            })
            .fail(() => {
                this.showFeedback('Network error occurred', 'error');
            });
        }

        testConnection() {
            this.showFeedback('Testing connection...', 'info');

            $.ajax({
                url: vrinAjax.ajaxUrl,
                method: 'POST',
                data: {
                    action: 'vrin_test_google_ads_connection',
                    nonce: vrinAjax.nonce
                }
            })
            .done((response) => {
                if (response.success) {
                    this.showFeedback('Connection successful!', 'success');
                } else {
                    this.showFeedback(response.data || 'Connection failed', 'error');
                }
            })
            .fail(() => {
                this.showFeedback('Network error occurred', 'error');
            });
        }

        manualSync() {
            const $button = $('#sync-now, #manual-sync');
            const originalText = $button.text();
            
            $button.text('Syncing...').prop('disabled', true);
            this.updateSyncStatus('running');

            $.ajax({
                url: vrinAjax.ajaxUrl,
                method: 'POST',
                data: {
                    action: 'vrin_manual_google_ads_sync',
                    nonce: vrinAjax.nonce
                }
            })
            .done((response) => {
                if (response.success) {
                    this.showFeedback('Sync completed successfully!', 'success');
                    this.updateSyncStatus('success');
                    this.loadQuickStats();
                    
                    // Refresh campaign stats if component exists
                    if (window.GoogleAdsCampaignStats) {
                        window.GoogleAdsCampaignStats.loadCampaignStats();
                    }
                } else {
                    this.showFeedback(response.data || 'Sync failed', 'error');
                    this.updateSyncStatus('error');
                }
            })
            .fail(() => {
                this.showFeedback('Network error occurred', 'error');
                this.updateSyncStatus('error');
            })
            .always(() => {
                $button.text(originalText).prop('disabled', false);
            });
        }

        resetSyncSchedule() {
            $.ajax({
                url: vrinAjax.ajaxUrl,
                method: 'POST',
                data: {
                    action: 'vrin_reset_google_ads_sync',
                    nonce: vrinAjax.nonce
                }
            })
            .done((response) => {
                if (response.success) {
                    this.showFeedback('Sync schedule reset successfully!', 'success');
                    location.reload(); // Refresh to show updated schedule
                } else {
                    this.showFeedback(response.data || 'Failed to reset schedule', 'error');
                }
            })
            .fail(() => {
                this.showFeedback('Network error occurred', 'error');
            });
        }

        toggleSyncLogs() {
            const $logs = $('#sync-logs');
            
            if ($logs.is(':visible')) {
                $logs.slideUp();
                return;
            }

            $logs.slideDown();
            
            // Load logs if not already loaded
            if ($('#sync-logs-content').text() === 'Loading logs...') {
                this.loadSyncLogs();
            }
        }

        loadSyncLogs() {
            $.ajax({
                url: vrinAjax.ajaxUrl,
                method: 'POST',
                data: {
                    action: 'vrin_get_google_ads_logs',
                    nonce: vrinAjax.nonce
                }
            })
            .done((response) => {
                if (response.success) {
                    $('#sync-logs-content').text(response.data || 'No logs available');
                } else {
                    $('#sync-logs-content').text('Failed to load logs');
                }
            })
            .fail(() => {
                $('#sync-logs-content').text('Network error occurred');
            });
        }

        loadQuickStats() {
            const period = $('#stats-period').val() || '7days';
            
            this.showQuickStatsLoading();

            $.ajax({
                url: vrinAjax.restUrl + '/google-ads/quick-stats',
                method: 'GET',
                data: { period: period },
                headers: {
                    'X-WP-Nonce': vrinAjax.nonce
                }
            })
            .done((response) => {
                this.hideQuickStatsLoading();
                
                if (response.success && response.data) {
                    this.renderQuickStats(response.data);
                } else {
                    this.showQuickStatsEmpty();
                }
            })
            .fail(() => {
                this.hideQuickStatsLoading();
                this.showQuickStatsError('Failed to load statistics');
            });
        }

        renderQuickStats(stats) {
            $('#total-campaigns').text(this.formatNumber(stats.campaigns || 0));
            $('#total-impressions').text(this.formatNumber(stats.impressions || 0));
            $('#total-clicks').text(this.formatNumber(stats.clicks || 0));
            $('#average-ctr').text((stats.ctr || 0).toFixed(2) + '%');
            $('#total-cost').text(this.formatCurrency(stats.cost || 0));
            $('#average-cpc').text(this.formatCurrency(stats.cpc || 0));

            this.showQuickStatsGrid();
        }

        updateSyncStatus(status) {
            if (!status) return;

            const $indicator = $('.vrin-sync-indicator');
            const $status = $('#sync-status');

            $indicator.removeClass('success error running never').addClass(status);
            
            let statusText = '';
            switch (status) {
                case 'success':
                    statusText = 'Success';
                    break;
                case 'error':
                    statusText = 'Error';
                    break;
                case 'running':
                    statusText = 'Running';
                    break;
                default:
                    statusText = 'Not Started';
            }

            $status.removeClass().addClass('vrin-status-' + status).text(statusText);

            if (status === 'success') {
                $('#last-sync-time').text('Just now');
            }
        }

        showFeedback(message, type) {
            const $feedback = $('#settings-feedback');
            $feedback
                .removeClass('vrin-notice-info vrin-notice-success vrin-notice-error')
                .addClass('vrin-notice vrin-notice-' + type)
                .html('<p>' + this.escapeHtml(message) + '</p>')
                .slideDown();

            // Auto-hide success messages
            if (type === 'success') {
                setTimeout(() => {
                    $feedback.slideUp();
                }, 3000);
            }
        }

        showQuickStatsLoading() {
            $('#quick-stats-loading').show();
            $('#quick-stats-grid').hide();
            $('#quick-stats-empty').hide();
            $('#quick-stats-error').hide();
        }

        hideQuickStatsLoading() {
            $('#quick-stats-loading').hide();
        }

        showQuickStatsGrid() {
            $('#quick-stats-grid').show();
            $('#quick-stats-empty').hide();
            $('#quick-stats-error').hide();
        }

        showQuickStatsEmpty() {
            $('#quick-stats-grid').hide();
            $('#quick-stats-empty').show();
            $('#quick-stats-error').hide();
        }

        showQuickStatsError(message) {
            $('#quick-stats-grid').hide();
            $('#quick-stats-empty').hide();
            $('#quick-stats-error-message').text(message);
            $('#quick-stats-error').show();
        }

        formatNumber(num) {
            return new Intl.NumberFormat().format(num);
        }

        formatCurrency(micros) {
            const amount = micros / 1000000;
            return new Intl.NumberFormat('en-US', {
                style: 'currency',
                currency: 'USD'
            }).format(amount);
        }

        escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
    }

    // Initialize when document is ready
    $(document).ready(function() {
        if ($('#vrin-google-ads-settings').length || $('#vrin-google-ads-sync-status').length) {
            new GoogleAdsAdmin();
        }
    });

})(jQuery);