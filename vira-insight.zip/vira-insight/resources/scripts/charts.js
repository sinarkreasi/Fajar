window.ViraInsightCharts = {
    renderChart(selector, config) {
        if (typeof Chart === "undefined") {
            console.error("Chart.js not loaded");
            return;
        }

        const ctx = document.getElementById(selector);
        if (!ctx) return;

        return new Chart(ctx, config);
    }
};
