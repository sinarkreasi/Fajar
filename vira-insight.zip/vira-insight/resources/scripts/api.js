export const InsightAPI = {
    get(url) {
        return fetch(url, { method: "GET" }).then(r => r.json());
    },

    post(url, data) {
        return fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(data)
        }).then(r => r.json());
    }
};
