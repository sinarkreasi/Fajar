<?php

namespace ViraInsight\Resources\Components;

class AdminCard
{
    public static function render(string $title, string $content, array $attrs = []): string
    {
        $id = $attrs['id'] ?? '';
        $class = $attrs['class'] ?? 'vi-card';

        ob_start();
        ?>
        <div id="<?= esc_attr($id); ?>" class="<?= esc_attr($class); ?>">
            <h3 class="vi-card-title"><?= esc_html($title); ?></h3>
            <div class="vi-card-content">
                <?= $content; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}
