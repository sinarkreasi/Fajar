<?php

namespace ViraInsight\Resources\Components;

class TableView
{
    public static function render(array $columns, array $rows): string
    {
        ob_start();
        ?>
        <table class="vi-table">
            <thead>
                <tr>
                    <?php foreach ($columns as $col): ?>
                        <th><?= esc_html($col); ?></th>
                    <?php endforeach; ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($rows as $row): ?>
                    <tr>
                        <?php foreach ($row as $cell): ?>
                            <td><?= esc_html($cell); ?></td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php
        return ob_get_clean();
    }
}
