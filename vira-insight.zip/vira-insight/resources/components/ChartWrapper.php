<?php

namespace ViraInsight\Resources\Components;

class ChartWrapper
{
    public static function render(string $chartId, array $options = []): string
    {
        $height = $options['height'] ?? '300px';

        return sprintf(
            '<canvas id="%s" style="width:100%%;height:%s;"></canvas>',
            esc_attr($chartId),
            esc_attr($height)
        );
    }
}
