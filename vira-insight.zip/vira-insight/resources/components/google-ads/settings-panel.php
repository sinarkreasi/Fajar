<?php
/**
 * Google Ads Settings Panel Component
 *
 * @package ViraInsight
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

$current_settings = [
    'dev_token' => get_option('vrin_google_ads_dev_token', ''),
    'client_id' => get_option('vrin_google_ads_client_id', ''),
    'client_secret' => get_option('vrin_google_ads_client_secret', ''),
    'refresh_token' => get_option('vrin_google_ads_refresh_token', ''),
    'login_customer_id' => get_option('vrin_google_ads_login_customer_id', ''),
    'customer_id' => get_option('vrin_google_ads_customer_id', ''),
];

$is_configured = !empty($current_settings['dev_token']) && !empty($current_settings['client_id']);
?>

<div id="vrin-google-ads-settings" class="vrin-card">
    <div class="vrin-card-header">
        <h3><?php esc_html_e('Google Ads API Configuration', 'vira-insight'); ?></h3>
        <div class="vrin-card-actions">
            <span class="vrin-status-badge <?php echo $is_configured ? 'vrin-status-connected' : 'vrin-status-disconnected'; ?>">
                <?php echo $is_configured ? esc_html__('Connected', 'vira-insight') : esc_html__('Not Connected', 'vira-insight'); ?>
            </span>
        </div>
    </div>
    
    <div class="vrin-card-body">
        <?php if (!$is_configured): ?>
        <div class="vrin-notice vrin-notice-warning">
            <p><?php esc_html_e('Google Ads API is not configured. Please enter your API credentials below to enable automatic data synchronization.', 'vira-insight'); ?></p>
        </div>
        <?php endif; ?>

        <form id="vrin-google-ads-settings-form">
            <?php wp_nonce_field('vrin_google_ads_settings', 'vrin_google_ads_nonce'); ?>
            
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="dev_token"><?php esc_html_e('Developer Token', 'vira-insight'); ?></label>
                    </th>
                    <td>
                        <input type="password" 
                               id="dev_token" 
                               name="dev_token" 
                               value="<?php echo esc_attr($current_settings['dev_token']); ?>" 
                               class="regular-text" 
                               placeholder="<?php esc_attr_e('Enter your Google Ads Developer Token', 'vira-insight'); ?>">
                        <p class="description">
                            <?php esc_html_e('Your Google Ads API Developer Token. Required for API access.', 'vira-insight'); ?>
                        </p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="client_id"><?php esc_html_e('OAuth Client ID', 'vira-insight'); ?></label>
                    </th>
                    <td>
                        <input type="text" 
                               id="client_id" 
                               name="client_id" 
                               value="<?php echo esc_attr($current_settings['client_id']); ?>" 
                               class="regular-text" 
                               placeholder="<?php esc_attr_e('Enter OAuth Client ID', 'vira-insight'); ?>">
                        <p class="description">
                            <?php esc_html_e('OAuth 2.0 Client ID from Google Cloud Console.', 'vira-insight'); ?>
                        </p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="client_secret"><?php esc_html_e('OAuth Client Secret', 'vira-insight'); ?></label>
                    </th>
                    <td>
                        <input type="password" 
                               id="client_secret" 
                               name="client_secret" 
                               value="<?php echo esc_attr($current_settings['client_secret']); ?>" 
                               class="regular-text" 
                               placeholder="<?php esc_attr_e('Enter OAuth Client Secret', 'vira-insight'); ?>">
                        <p class="description">
                            <?php esc_html_e('OAuth 2.0 Client Secret from Google Cloud Console.', 'vira-insight'); ?>
                        </p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="refresh_token"><?php esc_html_e('Refresh Token', 'vira-insight'); ?></label>
                    </th>
                    <td>
                        <input type="password" 
                               id="refresh_token" 
                               name="refresh_token" 
                               value="<?php echo esc_attr($current_settings['refresh_token']); ?>" 
                               class="regular-text" 
                               placeholder="<?php esc_attr_e('Enter Refresh Token', 'vira-insight'); ?>">
                        <p class="description">
                            <?php esc_html_e('OAuth 2.0 Refresh Token for API authentication.', 'vira-insight'); ?>
                        </p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="login_customer_id"><?php esc_html_e('Login Customer ID', 'vira-insight'); ?></label>
                    </th>
                    <td>
                        <input type="text" 
                               id="login_customer_id" 
                               name="login_customer_id" 
                               value="<?php echo esc_attr($current_settings['login_customer_id']); ?>" 
                               class="regular-text" 
                               placeholder="<?php esc_attr_e('e.g., 1234567890', 'vira-insight'); ?>">
                        <p class="description">
                            <?php esc_html_e('Manager account customer ID (without dashes).', 'vira-insight'); ?>
                        </p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="customer_id"><?php esc_html_e('Customer ID', 'vira-insight'); ?></label>
                    </th>
                    <td>
                        <input type="text" 
                               id="customer_id" 
                               name="customer_id" 
                               value="<?php echo esc_attr($current_settings['customer_id']); ?>" 
                               class="regular-text" 
                               placeholder="<?php esc_attr_e('e.g., 1234567890', 'vira-insight'); ?>">
                        <p class="description">
                            <?php esc_html_e('Target Google Ads account customer ID (without dashes).', 'vira-insight'); ?>
                        </p>
                    </td>
                </tr>
            </table>
            
            <div class="vrin-form-actions">
                <button type="submit" class="button button-primary">
                    <?php esc_html_e('Save Configuration', 'vira-insight'); ?>
                </button>
                
                <?php if ($is_configured): ?>
                <button type="button" class="button button-secondary" id="test-connection">
                    <?php esc_html_e('Test Connection', 'vira-insight'); ?>
                </button>
                
                <button type="button" class="button button-secondary" id="sync-now">
                    <?php esc_html_e('Sync Now', 'vira-insight'); ?>
                </button>
                <?php endif; ?>
            </div>
        </form>
        
        <div id="settings-feedback" style="display: none; margin-top: 15px;"></div>
    </div>
</div>