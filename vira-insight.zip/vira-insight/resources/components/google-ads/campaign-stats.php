<?php
/**
 * Google Ads Campaign Stats Component
 *
 * @package ViraInsight
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}
?>

<div id="vrin-google-ads-campaign-stats" class="vrin-card">
    <div class="vrin-card-header">
        <h3><?php esc_html_e('Google Ads Campaign Overview', 'vira-insight'); ?></h3>
        <div class="vrin-card-actions">
            <button type="button" class="vrin-btn vrin-btn-sm" id="refresh-campaigns">
                <?php esc_html_e('Refresh', 'vira-insight'); ?>
            </button>
        </div>
    </div>
    
    <div class="vrin-card-body">
        <div class="vrin-loading" id="campaigns-loading" style="display: none;">
            <div class="vrin-spinner"></div>
            <p><?php esc_html_e('Loading campaign data...', 'vira-insight'); ?></p>
        </div>
        
        <div class="vrin-table-container" id="campaigns-table-container">
            <table class="vrin-table" id="campaigns-table">
                <thead>
                    <tr>
                        <th><?php esc_html_e('Campaign Name', 'vira-insight'); ?></th>
                        <th><?php esc_html_e('Impressions', 'vira-insight'); ?></th>
                        <th><?php esc_html_e('Clicks', 'vira-insight'); ?></th>
                        <th><?php esc_html_e('CTR', 'vira-insight'); ?></th>
                        <th><?php esc_html_e('Avg CPC', 'vira-insight'); ?></th>
                        <th><?php esc_html_e('Cost', 'vira-insight'); ?></th>
                        <th><?php esc_html_e('Last Updated', 'vira-insight'); ?></th>
                    </tr>
                </thead>
                <tbody id="campaigns-tbody">
                    <!-- Data will be loaded via JavaScript -->
                </tbody>
            </table>
        </div>
        
        <div class="vrin-empty-state" id="campaigns-empty" style="display: none;">
            <div class="vrin-empty-icon">📊</div>
            <h4><?php esc_html_e('No Campaign Data', 'vira-insight'); ?></h4>
            <p><?php esc_html_e('No Google Ads campaign data found. Make sure your Google Ads account is connected and campaigns are running.', 'vira-insight'); ?></p>
        </div>
        
        <div class="vrin-error-state" id="campaigns-error" style="display: none;">
            <div class="vrin-error-icon">⚠️</div>
            <h4><?php esc_html_e('Error Loading Data', 'vira-insight'); ?></h4>
            <p id="campaigns-error-message"></p>
        </div>
    </div>
</div>