<?php
/**
 * Google Ads Quick Stats Component
 *
 * @package ViraInsight
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}
?>

<div id="vrin-google-ads-quick-stats" class="vrin-card">
    <div class="vrin-card-header">
        <h3><?php esc_html_e('Quick Statistics', 'vira-insight'); ?></h3>
        <div class="vrin-card-actions">
            <select id="stats-period" class="vrin-select-sm">
                <option value="today"><?php esc_html_e('Today', 'vira-insight'); ?></option>
                <option value="yesterday"><?php esc_html_e('Yesterday', 'vira-insight'); ?></option>
                <option value="7days" selected><?php esc_html_e('Last 7 days', 'vira-insight'); ?></option>
                <option value="30days"><?php esc_html_e('Last 30 days', 'vira-insight'); ?></option>
            </select>
        </div>
    </div>
    
    <div class="vrin-card-body">
        <div class="vrin-loading" id="quick-stats-loading" style="display: none;">
            <div class="vrin-spinner"></div>
            <p><?php esc_html_e('Loading statistics...', 'vira-insight'); ?></p>
        </div>
        
        <div class="vrin-stats-grid" id="quick-stats-grid">
            <div class="vrin-stat-item">
                <div class="vrin-stat-value" id="total-campaigns">-</div>
                <div class="vrin-stat-label"><?php esc_html_e('Active Campaigns', 'vira-insight'); ?></div>
            </div>
            
            <div class="vrin-stat-item">
                <div class="vrin-stat-value" id="total-impressions">-</div>
                <div class="vrin-stat-label"><?php esc_html_e('Total Impressions', 'vira-insight'); ?></div>
            </div>
            
            <div class="vrin-stat-item">
                <div class="vrin-stat-value" id="total-clicks">-</div>
                <div class="vrin-stat-label"><?php esc_html_e('Total Clicks', 'vira-insight'); ?></div>
            </div>
            
            <div class="vrin-stat-item">
                <div class="vrin-stat-value" id="average-ctr">-</div>
                <div class="vrin-stat-label"><?php esc_html_e('Average CTR', 'vira-insight'); ?></div>
            </div>
            
            <div class="vrin-stat-item">
                <div class="vrin-stat-value" id="total-cost">-</div>
                <div class="vrin-stat-label"><?php esc_html_e('Total Cost', 'vira-insight'); ?></div>
            </div>
            
            <div class="vrin-stat-item">
                <div class="vrin-stat-value" id="average-cpc">-</div>
                <div class="vrin-stat-label"><?php esc_html_e('Average CPC', 'vira-insight'); ?></div>
            </div>
        </div>
        
        <div class="vrin-empty-state" id="quick-stats-empty" style="display: none;">
            <div class="vrin-empty-icon">📊</div>
            <h4><?php esc_html_e('No Data Available', 'vira-insight'); ?></h4>
            <p><?php esc_html_e('No campaign data found for the selected period.', 'vira-insight'); ?></p>
        </div>
        
        <div class="vrin-error-state" id="quick-stats-error" style="display: none;">
            <div class="vrin-error-icon">⚠️</div>
            <h4><?php esc_html_e('Error Loading Statistics', 'vira-insight'); ?></h4>
            <p id="quick-stats-error-message"></p>
        </div>
    </div>
</div>