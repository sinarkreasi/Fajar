<?php
/**
 * Google Ads Sync Status Component
 *
 * @package ViraInsight
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

$last_sync = get_option('vrin_google_ads_last_sync', '');
$sync_status = get_option('vrin_google_ads_sync_status', 'never');
$next_sync = wp_next_scheduled('vrin_google_ads_fetch');
?>

<div id="vrin-google-ads-sync-status" class="vrin-card">
    <div class="vrin-card-header">
        <h3><?php esc_html_e('Synchronization Status', 'vira-insight'); ?></h3>
        <div class="vrin-card-actions">
            <span class="vrin-sync-indicator <?php echo esc_attr($sync_status); ?>"></span>
        </div>
    </div>
    
    <div class="vrin-card-body">
        <div class="vrin-sync-info">
            <div class="vrin-sync-item">
                <strong><?php esc_html_e('Last Sync:', 'vira-insight'); ?></strong>
                <span id="last-sync-time">
                    <?php 
                    if ($last_sync) {
                        echo esc_html(human_time_diff(strtotime($last_sync), current_time('timestamp')) . ' ago');
                    } else {
                        esc_html_e('Never', 'vira-insight');
                    }
                    ?>
                </span>
            </div>
            
            <div class="vrin-sync-item">
                <strong><?php esc_html_e('Status:', 'vira-insight'); ?></strong>
                <span id="sync-status" class="vrin-status-<?php echo esc_attr($sync_status); ?>">
                    <?php 
                    switch ($sync_status) {
                        case 'success':
                            esc_html_e('Success', 'vira-insight');
                            break;
                        case 'error':
                            esc_html_e('Error', 'vira-insight');
                            break;
                        case 'running':
                            esc_html_e('Running', 'vira-insight');
                            break;
                        default:
                            esc_html_e('Not Started', 'vira-insight');
                    }
                    ?>
                </span>
            </div>
            
            <div class="vrin-sync-item">
                <strong><?php esc_html_e('Next Sync:', 'vira-insight'); ?></strong>
                <span id="next-sync-time">
                    <?php 
                    if ($next_sync) {
                        echo esc_html(human_time_diff($next_sync, current_time('timestamp')) . ' from now');
                    } else {
                        esc_html_e('Not scheduled', 'vira-insight');
                    }
                    ?>
                </span>
            </div>
            
            <div class="vrin-sync-item">
                <strong><?php esc_html_e('Frequency:', 'vira-insight'); ?></strong>
                <span><?php esc_html_e('Every hour', 'vira-insight'); ?></span>
            </div>
        </div>
        
        <?php if ($sync_status === 'error'): ?>
        <div class="vrin-notice vrin-notice-error">
            <p>
                <?php esc_html_e('Last synchronization failed. Check the error logs or try manual sync.', 'vira-insight'); ?>
                <a href="#" id="view-sync-logs"><?php esc_html_e('View Logs', 'vira-insight'); ?></a>
            </p>
        </div>
        <?php endif; ?>
        
        <div class="vrin-sync-actions">
            <button type="button" class="button button-secondary" id="manual-sync">
                <?php esc_html_e('Manual Sync', 'vira-insight'); ?>
            </button>
            
            <button type="button" class="button button-secondary" id="reset-sync">
                <?php esc_html_e('Reset Schedule', 'vira-insight'); ?>
            </button>
        </div>
        
        <div id="sync-logs" style="display: none; margin-top: 15px;">
            <h4><?php esc_html_e('Recent Sync Logs', 'vira-insight'); ?></h4>
            <div class="vrin-logs-container">
                <pre id="sync-logs-content"><?php esc_html_e('Loading logs...', 'vira-insight'); ?></pre>
            </div>
        </div>
    </div>
</div>