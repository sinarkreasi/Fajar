<?php
/**
 * Extensions View
 *
 * @package ViraInsight
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap vrin-extensions">
    <h1><?php echo esc_html($title); ?></h1>

    <div class="vrin-card">
        <h2><?php esc_html_e('Install Extension', 'vira-insight'); ?></h2>
        <div class="vrin-card-content">
            <form id="vrin-extension-upload-form" enctype="multipart/form-data">
                <p>
                    <input type="file" name="extension_file" id="extension_file" accept=".zip">
                </p>
                <p class="submit">
                    <button type="submit" class="button button-primary"><?php esc_html_e('Install Extension', 'vira-insight'); ?></button>
                </p>
            </form>
        </div>
    </div>

    <div class="vrin-extensions-list">
        <h2><?php esc_html_e('Installed Extensions', 'vira-insight'); ?></h2>

        <?php if (empty($extensions)) : ?>
            <p><?php esc_html_e('No extensions installed.', 'vira-insight'); ?></p>
        <?php else : ?>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php esc_html_e('Extension', 'vira-insight'); ?></th>
                        <th><?php esc_html_e('Version', 'vira-insight'); ?></th>
                        <th><?php esc_html_e('Author', 'vira-insight'); ?></th>
                        <th><?php esc_html_e('Status', 'vira-insight'); ?></th>
                        <th><?php esc_html_e('Actions', 'vira-insight'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($extensions as $slug => $extension) : ?>
                        <?php $isActive = in_array($slug, $active); ?>
                        <tr>
                            <td><strong><?php echo esc_html($extension['manifest']['name']); ?></strong></td>
                            <td><?php echo esc_html($extension['manifest']['version']); ?></td>
                            <td><?php echo esc_html($extension['manifest']['author']); ?></td>
                            <td>
                                <?php if ($isActive) : ?>
                                    <span class="vrin-badge vrin-badge-success"><?php esc_html_e('Active', 'vira-insight'); ?></span>
                                <?php else : ?>
                                    <span class="vrin-badge vrin-badge-secondary"><?php esc_html_e('Inactive', 'vira-insight'); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($isActive) : ?>
                                    <button class="button vrin-deactivate-extension" data-slug="<?php echo esc_attr($slug); ?>">
                                        <?php esc_html_e('Deactivate', 'vira-insight'); ?>
                                    </button>
                                <?php else : ?>
                                    <button class="button button-primary vrin-activate-extension" data-slug="<?php echo esc_attr($slug); ?>">
                                        <?php esc_html_e('Activate', 'vira-insight'); ?>
                                    </button>
                                <?php endif; ?>
                                <button class="button button-link-delete vrin-uninstall-extension" data-slug="<?php echo esc_attr($slug); ?>">
                                    <?php esc_html_e('Delete', 'vira-insight'); ?>
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>
