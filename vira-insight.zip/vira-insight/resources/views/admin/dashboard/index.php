<?php
/**
 * Dashboard View
 *
 * @package ViraInsight
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap vrin-dashboard">
    <h1><?php echo esc_html($title); ?></h1>

    <div class="vrin-dashboard-grid">
        <!-- Summary Cards -->
        <div class="vrin-card">
            <h2><?php esc_html_e('SEO Analysis', 'vira-insight'); ?></h2>
            <div class="vrin-card-content">
                <p class="vrin-stat">
                    <span class="vrin-stat-value"><?php echo esc_html(isset($data['recent_seo_analyses']) && is_array($data['recent_seo_analyses']) ? count($data['recent_seo_analyses']) : 0); ?></span>
                    <span class="vrin-stat-label"><?php esc_html_e('Recent Analyses', 'vira-insight'); ?></span>
                </p>
                <a href="<?php echo esc_url(admin_url('admin.php?page=vira-insight-seo')); ?>" class="button button-primary">
                    <?php esc_html_e('View SEO Dashboard', 'vira-insight'); ?>
                </a>
            </div>
        </div>

        <div class="vrin-card">
            <h2><?php esc_html_e('Google Ads', 'vira-insight'); ?></h2>
            <div class="vrin-card-content">
                <p class="vrin-stat">
                    <span class="vrin-stat-value"><?php echo (isset($data['google_ads_enabled']) && $data['google_ads_enabled']) ? esc_html__('Active', 'vira-insight') : esc_html__('Inactive', 'vira-insight'); ?></span>
                    <span class="vrin-stat-label"><?php esc_html_e('Status', 'vira-insight'); ?></span>
                </p>
                <a href="<?php echo esc_url(admin_url('admin.php?page=vira-insight-google-ads')); ?>" class="button button-primary">
                    <?php esc_html_e('View Google Ads', 'vira-insight'); ?>
                </a>
            </div>
        </div>

        <div class="vrin-card">
            <h2><?php esc_html_e('Social Ads', 'vira-insight'); ?></h2>
            <div class="vrin-card-content">
                <p class="vrin-stat">
                    <span class="vrin-stat-value"><?php echo (isset($data['social_ads_enabled']) && $data['social_ads_enabled']) ? esc_html__('Active', 'vira-insight') : esc_html__('Inactive', 'vira-insight'); ?></span>
                    <span class="vrin-stat-label"><?php esc_html_e('Status', 'vira-insight'); ?></span>
                </p>
                <a href="<?php echo esc_url(admin_url('admin.php?page=vira-insight-social-ads')); ?>" class="button button-primary">
                    <?php esc_html_e('View Social Ads', 'vira-insight'); ?>
                </a>
            </div>
        </div>

        <div class="vrin-card">
            <h2><?php esc_html_e('Extensions', 'vira-insight'); ?></h2>
            <div class="vrin-card-content">
                <p class="vrin-stat">
                    <span class="vrin-stat-value"><?php echo esc_html(isset($data['active_extensions']) ? $data['active_extensions'] : 0); ?></span>
                    <span class="vrin-stat-label"><?php esc_html_e('Active Extensions', 'vira-insight'); ?></span>
                </p>
                <a href="<?php echo esc_url(admin_url('admin.php?page=vira-insight-extensions')); ?>" class="button button-primary">
                    <?php esc_html_e('Manage Extensions', 'vira-insight'); ?>
                </a>
            </div>
        </div>
    </div>

    <!-- Recent SEO Analyses -->
    <?php if (isset($data['recent_seo_analyses']) && is_array($data['recent_seo_analyses']) && !empty($data['recent_seo_analyses'])) : ?>
    <div class="vrin-section">
        <h2><?php esc_html_e('Recent SEO Analyses', 'vira-insight'); ?></h2>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th><?php esc_html_e('Post ID', 'vira-insight'); ?></th>
                    <th><?php esc_html_e('Score', 'vira-insight'); ?></th>
                    <th><?php esc_html_e('Date', 'vira-insight'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($data['recent_seo_analyses'] as $analysis) : ?>
                <tr>
                    <td><?php echo esc_html($analysis['post_id']); ?></td>
                    <td>
                        <span class="vrin-score vrin-score-<?php echo esc_attr($analysis['score'] >= 70 ? 'good' : ($analysis['score'] >= 50 ? 'medium' : 'poor')); ?>">
                            <?php echo esc_html($analysis['score']); ?>/100
                        </span>
                    </td>
                    <td><?php echo esc_html($analysis['created_at']); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php else : ?>
    <div class="vrin-section">
        <h2><?php esc_html_e('Recent SEO Analyses', 'vira-insight'); ?></h2>
        <div class="vrin-card">
            <div class="vrin-card-content">
                <p><?php esc_html_e('No SEO analyses yet. Go to SEO menu to analyze your first post!', 'vira-insight'); ?></p>
                <a href="<?php echo esc_url(admin_url('admin.php?page=vira-insight-seo')); ?>" class="button button-primary">
                    <?php esc_html_e('Analyze Now', 'vira-insight'); ?>
                </a>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>
