<?php
/**
 * Social Ads Dashboard View
 *
 * @package ViraInsight
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap vrin-social-ads-dashboard">
    <h1><?php echo esc_html($title); ?></h1>

    <div class="vrin-notice vrin-notice-info">
        <p><?php esc_html_e('This is the free base version. Upgrade to premium extensions for Meta/TikTok API integration.', 'vira-insight'); ?></p>
    </div>

    <div class="vrin-card">
        <h2><?php esc_html_e('Ad Performance Analyzer', 'vira-insight'); ?></h2>
        <div class="vrin-card-content">
            <p><?php esc_html_e('Enter your social ad metrics to analyze performance.', 'vira-insight'); ?></p>

            <form id="vrin-social-ads-form">
                <table class="form-table">
                    <tr>
                        <th><?php esc_html_e('Platform', 'vira-insight'); ?></th>
                        <td>
                            <select name="platform" class="regular-text">
                                <option value="facebook">Facebook</option>
                                <option value="instagram">Instagram</option>
                                <option value="tiktok">TikTok</option>
                                <option value="twitter">Twitter/X</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Impressions', 'vira-insight'); ?></th>
                        <td><input type="number" name="impressions" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Engagements', 'vira-insight'); ?></th>
                        <td><input type="number" name="engagements" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Clicks', 'vira-insight'); ?></th>
                        <td><input type="number" name="clicks" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Spend ($)', 'vira-insight'); ?></th>
                        <td><input type="number" step="0.01" name="spend" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Revenue ($)', 'vira-insight'); ?></th>
                        <td><input type="number" step="0.01" name="revenue" class="regular-text"></td>
                    </tr>
                </table>

                <p class="submit">
                    <button type="submit" class="button button-primary"><?php esc_html_e('Analyze Ad', 'vira-insight'); ?></button>
                </p>
            </form>

            <div id="vrin-social-ads-results" style="display: none; margin-top: 20px;"></div>
        </div>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Check if vrinData is defined
    if (typeof vrinData === 'undefined') {
        console.error('vrinData is not defined. Admin scripts may not be enqueued correctly.');
        alert('Error: Plugin scripts not loaded correctly. Please refresh the page.');
        return;
    }

    console.log('Social Ads - REST URL:', vrinData.restUrl);
    console.log('Social Ads - Nonce:', vrinData.nonce ? 'Present' : 'Missing');

    $('#vrin-social-ads-form').on('submit', function(e) {
        e.preventDefault();

        // Get form data
        const formData = {
            platform: $('select[name="platform"]').val() || 'facebook',
            impressions: parseInt($('input[name="impressions"]').val()) || 0,
            engagements: parseInt($('input[name="engagements"]').val()) || 0,
            clicks: parseInt($('input[name="clicks"]').val()) || 0,
            spend: parseFloat($('input[name="spend"]').val()) || 0,
            revenue: parseFloat($('input[name="revenue"]').val()) || 0,
            likes: 0,
            shares: 0,
            comments: 0,
            reach: 0,
            frequency: 1,
            targeting_type: 'broad'
        };

        console.log('Analyzing social ad with data:', formData);

        // Show loading state
        const $button = $(this).find('button[type="submit"]');
        const originalText = $button.text();
        $button.text('Analyzing...').prop('disabled', true);

        $.ajax({
            url: vrinData.restUrl + '/social-ads/analyze',
            method: 'POST',
            data: formData,
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', vrinData.nonce);
            },
            success: function(response) {
                console.log('Response:', response);

                if (response.success) {
                    displayResults(response.data);
                } else {
                    alert('Error: ' + (response.message || 'Unknown error occurred'));
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', {
                    status: xhr.status,
                    statusText: xhr.statusText,
                    responseText: xhr.responseText,
                    error: error
                });

                let errorMessage = 'Error analyzing ad.';

                if (xhr.status === 404) {
                    errorMessage = 'API endpoint not found. Please check if the plugin is activated correctly.';
                } else if (xhr.status === 403 || xhr.status === 401) {
                    errorMessage = 'Permission denied. You may not have the required capabilities.';
                } else if (xhr.status === 500) {
                    errorMessage = 'Server error. Please check the error logs.';
                } else if (xhr.responseJSON && xhr.responseJSON.message) {
                    errorMessage = xhr.responseJSON.message;
                }

                alert(errorMessage + '\n\nStatus: ' + xhr.status + '\nSee browser console for details.');
            },
            complete: function() {
                $button.text(originalText).prop('disabled', false);
            }
        });
    });

    function displayResults(data) {
        let html = '<div class="vrin-analysis-results">';

        // Performance Score
        html += '<h3>Ad Performance Analysis</h3>';
        html += '<p><strong>Performance Score:</strong> ' + data.performance_score + '/100</p>';

        // Engagement Analysis
        if (data.engagement_analysis) {
            html += '<h4>Engagement Metrics</h4>';
            html += '<p><strong>Total Engagements:</strong> ' + data.engagement_analysis.total_engagements + '</p>';
            html += '<p><strong>Engagement Rate:</strong> ' + data.engagement_analysis.engagement_rate + '% (' + data.engagement_analysis.status + ')</p>';
        }

        // ROAS Analysis
        if (data.roas_analysis) {
            html += '<h4>Return on Ad Spend (ROAS)</h4>';
            html += '<p><strong>ROAS:</strong> ' + data.roas_analysis.roas + 'x (' + data.roas_analysis.status + ')</p>';
            html += '<p><strong>Spend:</strong> $' + data.roas_analysis.spend + '</p>';
            html += '<p><strong>Revenue:</strong> $' + data.roas_analysis.revenue + '</p>';
            html += '<p><strong>Profit:</strong> $' + data.roas_analysis.profit + '</p>';
            html += '<p><strong>Benchmark:</strong> ' + data.roas_analysis.benchmark + 'x</p>';
        }

        // Audience Insights
        if (data.audience_insights) {
            html += '<h4>Audience Insights</h4>';
            html += '<p><strong>Platform:</strong> ' + data.audience_insights.platform + '</p>';
            html += '<p><strong>Targeting:</strong> ' + data.audience_insights.targeting_type + '</p>';
            html += '<p><strong>Audience Quality:</strong> ' + data.audience_insights.audience_quality + '</p>';
        }

        // Recommendations
        if (data.recommendations && data.recommendations.length > 0) {
            html += '<h4>Recommendations</h4>';
            html += '<ul>';
            data.recommendations.forEach(function(rec) {
                html += '<li class="vrin-rec-' + rec.type + '">[' + rec.priority.toUpperCase() + '] ' + rec.message + '</li>';
            });
            html += '</ul>';
        }

        html += '</div>';

        $('#vrin-social-ads-results').html(html).slideDown();
    }
});
</script>
