<?php
/**
 * Settings View
 *
 * @package ViraInsight
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap vrin-settings">
    <h1><?php echo esc_html($title); ?></h1>

    <form method="post" action="options.php">
        <?php settings_fields('vrin_settings'); ?>

        <table class="form-table">
            <tr>
                <th scope="row"><?php esc_html_e('SEO Analysis', 'vira-insight'); ?></th>
                <td>
                    <label>
                        <input type="checkbox" name="vrin_settings[seo_enabled]" value="1" <?php checked($settings['seo_enabled'] ?? true, true); ?>>
                        <?php esc_html_e('Enable SEO analysis features', 'vira-insight'); ?>
                    </label>
                </td>
            </tr>
            <tr>
                <th scope="row"><?php esc_html_e('Google Ads', 'vira-insight'); ?></th>
                <td>
                    <label>
                        <input type="checkbox" name="vrin_settings[google_ads_enabled]" value="1" <?php checked($settings['google_ads_enabled'] ?? true, true); ?>>
                        <?php esc_html_e('Enable Google Ads features', 'vira-insight'); ?>
                    </label>
                </td>
            </tr>
            <tr>
                <th scope="row"><?php esc_html_e('Social Ads', 'vira-insight'); ?></th>
                <td>
                    <label>
                        <input type="checkbox" name="vrin_settings[social_ads_enabled]" value="1" <?php checked($settings['social_ads_enabled'] ?? true, true); ?>>
                        <?php esc_html_e('Enable Social Ads features', 'vira-insight'); ?>
                    </label>
                </td>
            </tr>
            <tr>
                <th scope="row"><?php esc_html_e('Cache', 'vira-insight'); ?></th>
                <td>
                    <label>
                        <input type="checkbox" name="vrin_settings[cache_enabled]" value="1" <?php checked($settings['cache_enabled'] ?? true, true); ?>>
                        <?php esc_html_e('Enable caching', 'vira-insight'); ?>
                    </label>
                    <br>
                    <label>
                        <?php esc_html_e('Cache TTL (seconds):', 'vira-insight'); ?>
                        <input type="number" name="vrin_settings[cache_ttl]" value="<?php echo esc_attr($settings['cache_ttl'] ?? 3600); ?>" class="small-text">
                    </label>
                </td>
            </tr>
        </table>

        <?php submit_button(); ?>
    </form>
</div>
