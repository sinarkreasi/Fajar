<?php
/**
 * SEO Dashboard View
 *
 * @package ViraInsight
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap vrin-seo-dashboard">
    <h1><?php echo esc_html($title); ?></h1>

    <div class="vrin-seo-analyzer">
        <div class="vrin-card">
            <h2><?php esc_html_e('Analyze Post/Page', 'vira-insight'); ?></h2>
            <div class="vrin-card-content">
                <form id="vrin-seo-analyze-form">
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="post_id"><?php esc_html_e('Post/Page ID', 'vira-insight'); ?></label>
                            </th>
                            <td>
                                <input type="number" id="post_id" name="post_id" class="regular-text" required>
                                <p class="description"><?php esc_html_e('Enter the post or page ID to analyze.', 'vira-insight'); ?></p>
                            </td>
                        </tr>
                    </table>
                    <p class="submit">
                        <button type="submit" class="button button-primary">
                            <?php esc_html_e('Analyze', 'vira-insight'); ?>
                        </button>
                    </p>
                </form>

                <div id="vrin-seo-results" style="display: none; margin-top: 20px;">
                    <h3><?php esc_html_e('Analysis Results', 'vira-insight'); ?></h3>
                    <div id="vrin-seo-results-content"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Check if vrinData is defined
    if (typeof vrinData === 'undefined') {
        console.error('vrinData is not defined. Admin scripts may not be enqueued correctly.');
        alert('Error: Plugin scripts not loaded correctly. Please refresh the page.');
        return;
    }

    console.log('REST URL:', vrinData.restUrl);
    console.log('Nonce:', vrinData.nonce ? 'Present' : 'Missing');

    $('#vrin-seo-analyze-form').on('submit', function(e) {
        e.preventDefault();

        const postId = $('#post_id').val();

        if (!postId || postId < 1) {
            alert('Please enter a valid post ID.');
            return;
        }

        // Show loading state
        const $button = $(this).find('button[type="submit"]');
        const originalText = $button.text();
        $button.text('Analyzing...').prop('disabled', true);

        console.log('Analyzing post ID:', postId);
        console.log('API URL:', vrinData.restUrl + '/seo/analyze');

        $.ajax({
            url: vrinData.restUrl + '/seo/analyze',
            method: 'POST',
            data: { post_id: postId },
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', vrinData.nonce);
            },
            success: function(response) {
                console.log('Response:', response);

                if (response.success) {
                    displayResults(response.data);
                } else {
                    alert('Error: ' + (response.message || 'Unknown error occurred'));
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', {
                    status: xhr.status,
                    statusText: xhr.statusText,
                    responseText: xhr.responseText,
                    error: error
                });

                let errorMessage = 'Error analyzing post.';

                if (xhr.status === 404) {
                    errorMessage = 'API endpoint not found. Please check if the plugin is activated correctly.';
                } else if (xhr.status === 403 || xhr.status === 401) {
                    errorMessage = 'Permission denied. You may not have the required capabilities.';
                } else if (xhr.status === 500) {
                    errorMessage = 'Server error. Please check the error logs.';
                } else if (xhr.responseJSON && xhr.responseJSON.message) {
                    errorMessage = xhr.responseJSON.message;
                }

                alert(errorMessage + '\n\nStatus: ' + xhr.status + '\nSee browser console for details.');
            },
            complete: function() {
                $button.text(originalText).prop('disabled', false);
            }
        });
    });

    function displayResults(data) {
        let html = '<div class="vrin-analysis-results">';
        html += '<p><strong>Score:</strong> ' + data.score + '/100 (' + data.grade + ')</p>';
        html += '<p><strong>Word Count:</strong> ' + data.content_analysis.word_count + '</p>';
        html += '<p><strong>Readability:</strong> ' + data.readability.reading_level + ' (' + data.readability.flesch_score + ')</p>';

        if (data.recommendations && data.recommendations.length > 0) {
            html += '<h4>Recommendations:</h4><ul>';
            data.recommendations.forEach(function(rec) {
                html += '<li class="vrin-rec-' + rec.type + '">' + rec.message + '</li>';
            });
            html += '</ul>';
        }

        html += '</div>';

        $('#vrin-seo-results-content').html(html);
        $('#vrin-seo-results').slideDown();
    }
});
</script>
