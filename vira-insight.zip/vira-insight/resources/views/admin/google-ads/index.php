<?php
/**
 * Google Ads Dashboard View
 *
 * @package ViraInsight
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap vrin-google-ads-dashboard">
    <h1><?php echo esc_html($title); ?></h1>

    <div class="vrin-notice vrin-notice-info">
        <p><?php esc_html_e('Comprehensive Google Ads management with API integration and real-time synchronization.', 'vira-insight'); ?></p>
    </div>

    <!-- Top Row: Quick Stats and Sync Status -->
    <div class="vrin-dashboard-row">
        <?php 
        $component_path = VRIN_PLUGIN_DIR . 'resources/components/google-ads/quick-stats.php';
        if (file_exists($component_path)) {
            include $component_path;
        }
        ?>
        
        <?php 
        $component_path = VRIN_PLUGIN_DIR . 'resources/components/google-ads/sync-status.php';
        if (file_exists($component_path)) {
            include $component_path;
        }
        ?>
    </div>

    <!-- Settings Panel -->
    <div class="vrin-dashboard-full">
        <?php 
        $component_path = VRIN_PLUGIN_DIR . 'resources/components/google-ads/settings-panel.php';
        if (file_exists($component_path)) {
            include $component_path;
        }
        ?>
    </div>

    <!-- Campaign Stats -->
    <div class="vrin-dashboard-full">
        <?php 
        $component_path = VRIN_PLUGIN_DIR . 'resources/components/google-ads/campaign-stats.php';
        if (file_exists($component_path)) {
            include $component_path;
        }
        ?>
    </div>

    <div class="vrin-card">
        <h2><?php esc_html_e('Campaign Health Analyzer', 'vira-insight'); ?></h2>
        <div class="vrin-card-content">
            <p><?php esc_html_e('Enter your campaign metrics manually to get insights and recommendations.', 'vira-insight'); ?></p>

            <form id="vrin-google-ads-form">
                <table class="form-table">
                    <tr>
                        <th><?php esc_html_e('CTR (%)', 'vira-insight'); ?></th>
                        <td><input type="number" step="0.01" name="ctr" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('CPC ($)', 'vira-insight'); ?></th>
                        <td><input type="number" step="0.01" name="cpc" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Quality Score (1-10)', 'vira-insight'); ?></th>
                        <td><input type="number" min="1" max="10" name="quality_score" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Conversion Rate (%)', 'vira-insight'); ?></th>
                        <td><input type="number" step="0.01" name="conversion_rate" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Daily Budget ($)', 'vira-insight'); ?></th>
                        <td><input type="number" step="0.01" name="daily_budget" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Amount Spent ($)', 'vira-insight'); ?></th>
                        <td><input type="number" step="0.01" name="spent" class="regular-text"></td>
                    </tr>
                </table>

                <p class="submit">
                    <button type="submit" class="button button-primary"><?php esc_html_e('Analyze Campaign', 'vira-insight'); ?></button>
                </p>
            </form>

            <div id="vrin-ads-results" style="display: none; margin-top: 20px;"></div>
        </div>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Check if vrinData is defined
    if (typeof vrinData === 'undefined') {
        console.error('vrinData is not defined. Admin scripts may not be enqueued correctly.');
        alert('Error: Plugin scripts not loaded correctly. Please refresh the page.');
        return;
    }

    console.log('Google Ads - REST URL:', vrinData.restUrl);
    console.log('Google Ads - Nonce:', vrinData.nonce ? 'Present' : 'Missing');

    $('#vrin-google-ads-form').on('submit', function(e) {
        e.preventDefault();

        // Get form data
        const formData = {
            ctr: parseFloat($('input[name="ctr"]').val()) || 0,
            cpc: parseFloat($('input[name="cpc"]').val()) || 0,
            quality_score: parseInt($('input[name="quality_score"]').val()) || 0,
            conversion_rate: parseFloat($('input[name="conversion_rate"]').val()) || 0,
            daily_budget: parseFloat($('input[name="daily_budget"]').val()) || 0,
            spent: parseFloat($('input[name="spent"]').val()) || 0,
            industry_avg_cpc: 2.0 // Default industry average
        };

        console.log('Analyzing campaign with data:', formData);

        // Show loading state
        const $button = $(this).find('button[type="submit"]');
        const originalText = $button.text();
        $button.text('Analyzing...').prop('disabled', true);

        $.ajax({
            url: vrinData.restUrl + '/google-ads/analyze',
            method: 'POST',
            data: formData,
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', vrinData.nonce);
            },
            success: function(response) {
                console.log('Response:', response);

                if (response.success) {
                    displayResults(response.data);
                } else {
                    alert('Error: ' + (response.message || 'Unknown error occurred'));
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', {
                    status: xhr.status,
                    statusText: xhr.statusText,
                    responseText: xhr.responseText,
                    error: error
                });

                let errorMessage = 'Error analyzing campaign.';

                if (xhr.status === 404) {
                    errorMessage = 'API endpoint not found. Please check if the plugin is activated correctly.';
                } else if (xhr.status === 403 || xhr.status === 401) {
                    errorMessage = 'Permission denied. You may not have the required capabilities.';
                } else if (xhr.status === 500) {
                    errorMessage = 'Server error. Please check the error logs.';
                } else if (xhr.responseJSON && xhr.responseJSON.message) {
                    errorMessage = xhr.responseJSON.message;
                }

                alert(errorMessage + '\n\nStatus: ' + xhr.status + '\nSee browser console for details.');
            },
            complete: function() {
                $button.text(originalText).prop('disabled', false);
            }
        });
    });

    function displayResults(data) {
        let html = '<div class="vrin-analysis-results">';

        // Health Score
        html += '<h3>Campaign Health Analysis</h3>';
        html += '<p><strong>Health Score:</strong> ' + data.health_score + '/100</p>';

        // Budget Pacing
        if (data.budget_pacing) {
            html += '<h4>Budget Pacing</h4>';
            html += '<p><strong>Pacing:</strong> ' + data.budget_pacing.pacing_percentage + '% (' + data.budget_pacing.status + ')</p>';
            html += '<p><strong>Projected Spend:</strong> $' + data.budget_pacing.projected_spend + '</p>';
        }

        // CTR Analysis
        if (data.ctr_analysis) {
            html += '<h4>Click-Through Rate</h4>';
            html += '<p><strong>CTR:</strong> ' + data.ctr_analysis.value + '% (' + data.ctr_analysis.status + ')</p>';
            html += '<p><strong>Benchmark:</strong> ' + data.ctr_analysis.benchmark + '%</p>';
            html += '<p>' + (data.ctr_analysis.above_benchmark ? '✓ Above benchmark' : '✗ Below benchmark') + '</p>';
        }

        // CPC Analysis
        if (data.cpc_analysis) {
            html += '<h4>Cost Per Click</h4>';
            html += '<p><strong>CPC:</strong> $' + data.cpc_analysis.value + ' (' + data.cpc_analysis.status + ')</p>';
            html += '<p><strong>Industry Average:</strong> $' + data.cpc_analysis.industry_average + '</p>';
            if (data.cpc_analysis.savings_opportunity > 0) {
                html += '<p class="vrin-rec-warning">Potential savings: $' + data.cpc_analysis.savings_opportunity.toFixed(2) + ' per click</p>';
            }
        }

        // Recommendations
        if (data.recommendations && data.recommendations.length > 0) {
            html += '<h4>Recommendations</h4>';
            html += '<ul>';
            data.recommendations.forEach(function(rec) {
                html += '<li class="vrin-rec-' + rec.type + '">[' + rec.priority.toUpperCase() + '] ' + rec.message + '</li>';
            });
            html += '</ul>';
        }

        html += '</div>';

        $('#vrin-ads-results').html(html).slideDown();
    }
});
</script>
