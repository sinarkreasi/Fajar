# Vira Insight - Implementation Documentation

## Overview

Vira Insight is WP plugin that provides SEO analysis, Google Ads intelligence, and Social Ads insights with a premium extension system.

## Architecture

### Laravel-Style Structure

The plugin follows a clean, modular architecture inspired by Laravel:

```
vira-insight/
├── bootstrap/          # Application bootstrapping
├── config/            # Configuration files
├── routes/            # Route definitions (admin, api)
├── src/               # Source code
│   ├── Core/         # Kernel, Container, EventEmitter, Cache, View
│   ├── Http/         # Controllers, Routing, Middleware
│   ├── Providers/    # Service Providers
│   ├── SEO/          # SEO module
│   ├── GoogleAds/    # Google Ads module
│   ├── SocialAds/    # Social Ads module
│   └── UI/           # Admin interface
├── resources/         # Views, assets, languages
├── extensions/        # Premium extensions
└── storage/          # Cache, logs, compiled views
```

## Core Components

### 1. Kernel (`src/Core/Kernel.php`)

The kernel is the heart of the application:

- **Singleton pattern** - Ensures single instance
- **Service container** - Manages dependency injection
- **Provider loading** - Auto-loads and boots service providers
- **Event system** - Bootstraps event listeners
- **Extension loading** - Auto-discovers and loads extensions
- **Hook registration** - Registers WordPress hooks
- **Lifecycle management** - Handles activation/deactivation/uninstall

#### Key Methods:
- `boot()` - Bootstraps the entire application
- `activate()` - Creates database tables, sets defaults
- `deactivate()` - Cleanup on deactivation
- `uninstall()` - Complete cleanup on uninstall

### 2. Service Container (`src/Core/Container.php`)

Lightweight dependency injection container:

- **Bind** - Register services
- **Singleton** - Register shared instances
- **Make** - Resolve services from container
- **Instance** - Register existing instances

Example:
```php
$container->singleton('cache', fn() => new Cache());
$cache = $container->make('cache');
```

### 3. Event Emitter (`src/Core/EventEmitter.php`)

Internal event system for decoupled architecture:

- **on()** - Register event listeners
- **once()** - Register one-time listeners
- **dispatch()** - Fire events
- **Async support** - Queue listeners for background processing

Events fired:
- `plugin.activated`
- `plugin.deactivated`
- `extension.installed`
- `extension.activated`
- `seo.analysis.completed`
- `analytics.data.synced`

### 4. Service Providers

Service providers organize registration and bootstrapping:

- **AppServiceProvider** - Core application services
- **SEOServiceProvider** - SEO module services
- **GoogleAdsServiceProvider** - Google Ads services
- **SocialAdsServiceProvider** - Social Ads services
- **ExtensionServiceProvider** - Extension management
- **RouteServiceProvider** - API routes
- **ViewServiceProvider** - View rendering

Each provider implements:
- `register()` - Bind services to container
- `boot()` - Perform bootstrapping after all providers registered

### 5. Extension Manager (`src/Core/ExtensionManager.php`)

Manages premium extensions:

- **discover()** - Auto-discover extensions
- **install()** - Upload and validate ZIP files
- **activate()** - Enable extensions
- **deactivate()** - Disable extensions
- **validateLicense()** - Check license via API

Extension structure:
```
extensions/
└── example-extension/
    ├── manifest.json      # Metadata
    ├── Extension.php      # Entry point
    ├── src/              # Additional classes
    └── views/            # Templates
```

### 6. Cache System (`src/Core/Cache.php`)

Unified caching layer supporting:

- **Transients** - WordPress transients API
- **Object cache** - WordPress object cache
- **File cache** - Custom file-based cache

Methods:
- `get($key, $default)` - Retrieve cached value
- `set($key, $value, $ttl)` - Store value
- `remember($key, $ttl, $callback)` - Get or compute and cache
- `flush()` - Clear all cache

### 7. View System (`src/Core/View.php`)

Template rendering with caching:

- Dot notation for views: `admin.dashboard.index`
- Automatic caching of compiled views
- Data extraction to variables
- PHP template engine

Example:
```php
$view = new View();
$view->render('admin.dashboard.index', ['title' => 'Dashboard']);
```

## Modules

### SEO Module

**Components:**
- `AnalyzerService` - Performs on-page SEO analysis
  - Title optimization
  - Content analysis (word count, readability)
  - Meta tag analysis
  - Keyword density
  - Internal link analysis
  - Heading structure

- `ScoringService` - Calculates SEO scores
  - 100-point scoring system
  - Letter grades (A+ to F)
  - Actionable recommendations

- `SEOController` - Handles requests
  - `analyzePost()` - Analyze post/page
  - `getHistory()` - Get analysis history

**Database Table:**
```sql
wp_vrin_seo_analysis
├── id
├── post_id
├── score
├── analysis_data (JSON)
├── created_at
└── updated_at
```

### Google Ads Module

**Base Features (Free):**
- Campaign health scoring
- Budget pacing analysis
- CTR/CPC analysis
- Performance projections

**Premium Features (Extension):**
- Google Ads API integration
- Auto-sync campaign data
- Anomaly detection
- Advanced recommendations

**Components:**
- `AnalyzerService` - Campaign analysis
- `GoogleAdsController` - Request handling

### Social Ads Module

**Base Features (Free):**
- Ad performance scoring
- Engagement analysis
- ROAS calculation
- Content performance estimation

**Premium Features (Extension):**
- Meta/TikTok API integration
- Audience clustering
- Advanced analytics

**Components:**
- `AnalyzerService` - Ad analysis
- `SocialAdsController` - Request handling

## REST API

All features accessible via REST API:

### SEO Endpoints
- `POST /vira-insight/v1/seo/analyze` - Analyze post
- `GET /vira-insight/v1/seo/history` - Get history

### Google Ads Endpoints
- `POST /vira-insight/v1/google-ads/analyze` - Analyze campaign
- `POST /vira-insight/v1/google-ads/projections` - Get projections

### Social Ads Endpoints
- `POST /vira-insight/v1/social-ads/analyze` - Analyze ad
- `POST /vira-insight/v1/social-ads/estimate-content` - Estimate content performance

### Settings Endpoints
- `GET /vira-insight/v1/settings` - Get settings
- `POST /vira-insight/v1/settings` - Save settings

### Extension Endpoints
- `POST /vira-insight/v1/extensions/install` - Install extension
- `POST /vira-insight/v1/extensions/activate` - Activate extension
- `POST /vira-insight/v1/extensions/deactivate` - Deactivate extension
- `POST /vira-insight/v1/extensions/uninstall` - Uninstall extension

## Security

### Input Sanitization
- All input sanitized using WordPress functions
- `sanitize_text_field()`
- `sanitize_email()`
- `sanitize_textarea_field()`
- `esc_url_raw()`

### Output Escaping
- All output escaped:
- `esc_html()`
- `esc_attr()`
- `esc_url()`
- `wp_kses_post()`

### Capability Checks
- Admin features require `manage_options`
- Analytics viewing requires `edit_posts`
- Extension management requires `manage_options`

### Nonce Verification
- All AJAX requests verified with nonces
- REST API uses WordPress REST nonce

### File Upload Security
- MIME type validation
- File size limits (10MB)
- Blocked extensions: php, exe, sh, bat
- ZIP file scanning for dangerous files

## Performance Optimizations

1. **Lazy Loading**
   - Service providers loaded conditionally
   - Admin assets only on plugin pages

2. **Caching**
   - View compilation caching
   - API response caching
   - Database query caching

3. **Database**
   - Prepared statements
   - Indexed columns
   - Efficient queries

4. **Asset Management**
   - Minified CSS/JS in build
   - Conditional asset loading
   - No inline assets

## Extension Development

### Creating an Extension

1. Create folder in `/extensions/`
2. Add `manifest.json`:
```json
{
  "name": "My Extension",
  "version": "1.0.0",
  "namespace": "ViraInsight\\Extensions\\MyExtension",
  "entry_point": "Extension.php"
}
```

3. Create `Extension.php`:
```php
namespace ViraInsight\Extensions\MyExtension;

class Extension {
    public function boot(): void {
        // Register hooks, routes, etc.
    }
}
```

4. Zip the folder and upload via Extensions page

### Available Hooks

Extensions can hook into:
- WordPress actions/filters
- Plugin events via EventEmitter
- REST API routes
- Admin menus

## Database Schema

### SEO Analysis Table
```sql
CREATE TABLE wp_vrin_seo_analysis (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    post_id BIGINT NOT NULL,
    score INT NOT NULL,
    analysis_data LONGTEXT NOT NULL,
    created_at DATETIME,
    updated_at DATETIME,
    KEY post_id (post_id)
);
```

### Google Ads Data Table
```sql
CREATE TABLE wp_vrin_google_ads_data (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    campaign_id VARCHAR(255) NOT NULL,
    campaign_data LONGTEXT NOT NULL,
    synced_at DATETIME,
    KEY campaign_id (campaign_id)
);
```

### Social Ads Data Table
```sql
CREATE TABLE wp_vrin_social_ads_data (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    platform VARCHAR(50) NOT NULL,
    ad_id VARCHAR(255) NOT NULL,
    ad_data LONGTEXT NOT NULL,
    synced_at DATETIME,
    KEY platform_ad (platform, ad_id)
);
```

## Configuration

All configuration in `/config/`:

- `app.php` - Application settings, providers
- `cache.php` - Cache driver, TTL
- `security.php` - Security settings
- `extensions.php` - Extension settings

## Development

### Setup
```bash
# Install dependencies
composer install
npm install

# Build assets
npm run build

# Development mode
npm run dev
```

### Testing
```bash
# Run PHP tests
composer test

# Code standards
composer cs
composer cbf
```

## Deployment

1. Run `composer install --no-dev --optimize-autoloader`
2. Run `npm run build`
3. Remove development files
4. Zip the plugin folder
5. Upload to WordPress

## License

GPL-2.0-or-later

## Support

For support, visit: https://virainsight.com/support
