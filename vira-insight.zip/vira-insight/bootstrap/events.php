<?php
/**
 * Event Listeners Registration
 *
 * Register all event listeners for the application.
 *
 * @package ViraInsight
 */

declare(strict_types=1);

namespace ViraInsight;

use ViraInsight\Core\EventEmitter;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

$emitter = EventEmitter::getInstance();

// System events
$emitter->on('plugin.activated', [\ViraInsight\Listeners\PluginActivatedListener::class, 'handle']);
$emitter->on('plugin.deactivated', [\ViraInsight\Listeners\PluginDeactivatedListener::class, 'handle']);

// Extension events
$emitter->on('extension.installed', [\ViraInsight\Listeners\ExtensionInstalledListener::class, 'handle']);
$emitter->on('extension.activated', [\ViraInsight\Listeners\ExtensionActivatedListener::class, 'handle']);
$emitter->on('extension.deactivated', [\ViraInsight\Listeners\ExtensionDeactivatedListener::class, 'handle']);

// SEO events
$emitter->on('seo.analysis.completed', [\ViraInsight\Listeners\SEOAnalysisCompletedListener::class, 'handle']);

// Analytics events
$emitter->on('analytics.data.synced', [\ViraInsight\Listeners\AnalyticsSyncedListener::class, 'handle']);

return $emitter;
