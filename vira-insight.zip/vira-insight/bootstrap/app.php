<?php
/**
 * Bootstrap Application
 *
 * This file bootstraps the application by loading configuration,
 * setting up error handling, and preparing the environment.
 *
 * @package ViraInsight
 */

declare(strict_types=1);

namespace ViraInsight;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Set error reporting for development
if (defined('WP_DEBUG') && WP_DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
}

// Load configuration files
$config = [];

$configFiles = [
    'app' => VRIN_PLUGIN_DIR . 'config/app.php',
    'cache' => VRIN_PLUGIN_DIR . 'config/cache.php',
    'security' => VRIN_PLUGIN_DIR . 'config/security.php',
    'extensions' => VRIN_PLUGIN_DIR . 'config/extensions.php',
    'google-ads' => VRIN_PLUGIN_DIR . 'config/google-ads.php',
];

foreach ($configFiles as $key => $file) {
    if (file_exists($file)) {
        $config[$key] = require $file;
    }
}

// Store config globally
if (!defined('VRIN_CONFIG')) {
    define('VRIN_CONFIG', $config);
}

// Create necessary directories
$directories = [
    VRIN_PLUGIN_DIR . 'storage/cache',
    VRIN_PLUGIN_DIR . 'storage/logs',
    VRIN_PLUGIN_DIR . 'storage/views',
];

foreach ($directories as $dir) {
    if (!file_exists($dir)) {
        wp_mkdir_p($dir);
    }

    // Add index.php for security
    $indexFile = $dir . '/index.php';
    if (!file_exists($indexFile)) {
        file_put_contents($indexFile, '<?php // Silence is golden.');
    }
}

// Set up custom exception handler
if (class_exists('ViraInsight\Exceptions\Handler')) {
    set_exception_handler([new \ViraInsight\Exceptions\Handler(), 'handle']);
}

// Helper functions
if (!function_exists('vrin_app')) {
    /**
     * Get service from container
     */
    function vrin_app(string $abstract = null)
    {
        $container = \ViraInsight\Core\Container::getInstance();
        
        if ($abstract === null) {
            return $container;
        }
        
        return $container->make($abstract);
    }
}

if (!function_exists('config')) {
    /**
     * Get configuration value
     */
    function config(string $key, $default = null)
    {
        $kernel = \ViraInsight\Core\Kernel::getInstance();
        return $kernel->getConfig($key, $default);
    }
}

return $config;
