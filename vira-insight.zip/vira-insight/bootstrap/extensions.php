<?php
/**
 * Extensions Bootstrap
 *
 * Load and register all installed extensions.
 *
 * @package ViraInsight
 */

declare(strict_types=1);

namespace ViraInsight;

use ViraInsight\Core\ExtensionManager;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

$extensionManager = ExtensionManager::getInstance();

// Auto-discover and load extensions
$extensionManager->discover();
$extensionManager->loadActive();

return $extensionManager;
