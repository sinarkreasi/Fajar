# Vira Insight

**Contributors:** Vira Insight Team
**Requires at least:** WordPress 6.8
**Tested up to:** WordPress 6.8
**Requires PHP:** 8.2+
**Stable tag:** 1.0.0
**License:** GPL v2 or later
**License URI:** https://www.gnu.org/licenses/gpl-2.0.html

Comprehensive SEO analysis, Google Ads intelligence, and Social Ads insights platform with premium extension support.

## Description

Vira Insight is a powerful WordPress plugin that provides:

- **SEO Intelligence & Analysis** - On-page analysis, content scoring, meta audit, keyword placement, and more
- **Google Ads Analytics** - Campaign diagnostics, budget pacing, performance optimization
- **Social Ads Insights** - Meta Ads, TikTok Ads performance tracking and optimization
- **Premium Extensions** - Modular add-on system for advanced features

Built with enterprise-grade architecture following Laravel-style patterns for maintainability, performance, and security.

## Features

### SEO Analysis (Free)
- On-page SEO analysis
- Content scoring engine
- Title and meta tag audit
- Keyword placement analysis
- Content readability checks
- Internal link monitoring
- Indexing status tracking

### Google Ads (Base Free + Premium Extensions)
- Campaign health indicators
- Budget pacing estimator
- CTR/CPC projections
- Premium: API integration, auto-sync, anomaly detection

### Social Ads (Base Free + Premium Extensions)
- Manual insights tracker
- Content performance estimator
- Audience analysis
- Premium: Meta/TikTok API integration, ROAS prediction

### Extension System
- Upload and activate premium extensions
- License validation
- Isolated module architecture

## Installation

1. Upload the `vira-insight` folder to `/wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Navigate to Vira Insight in the admin menu to configure

## Requirements

- WordPress 6.8 or higher
- PHP 8.2 or higher
- MySQL 5.7+ or MariaDB 10.3+

## Changelog

### 1.0.0
- Initial release
- SEO analysis core
- Google Ads base features
- Social Ads base features
- Extension manager system
