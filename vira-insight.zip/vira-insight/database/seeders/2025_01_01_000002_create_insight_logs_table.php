<?php

use WPRewriter\Database\Migration;
use WPRewriter\Database\Schema\Blueprint;

return new class extends Migration
{
    public function up()
    {
        $this->schema->create('insight_logs', function (Blueprint $table) {
            $table->id();
            $table->string('reference_type'); // report, task, module, etc
            $table->unsignedBigInteger('reference_id')->nullable();
            $table->text('message');
            $table->string('level')->default('info'); // info, warning, error
            $table->timestamps();
        });
    }

    public function down()
    {
        $this->schema->drop('insight_logs');
    }
};
