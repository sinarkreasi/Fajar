<?php

namespace ViraInsight\Database\Seeders;

use ViraInsight\Database\Factories\InsightLogFactory;
use ViraInsight\Support\DB;

class InsightLogSeeder
{
    public function run(): void
    {
        for ($i = 0; $i < 20; $i++) {
            DB::table('insight_logs')->insert(
                InsightLogFactory::make()
            );
        }
    }
}
