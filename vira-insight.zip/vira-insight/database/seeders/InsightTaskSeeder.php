<?php

namespace ViraInsight\Database\Seeders;

use ViraInsight\Database\Factories\InsightTaskFactory;
use ViraInsight\Support\DB;

class InsightTaskSeeder
{
    public function run(): void
    {
        for ($i = 0; $i < 10; $i++) {
            DB::table('insight_tasks')->insert(
                InsightTaskFactory::make()
            );
        }
    }
}
