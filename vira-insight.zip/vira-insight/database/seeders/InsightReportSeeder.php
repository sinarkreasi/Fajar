<?php

namespace ViraInsight\Database\Seeders;

use ViraInsight\Database\Factories\InsightReportFactory;
use ViraInsight\Support\DB;

class InsightReportSeeder
{
    public function run(): void
    {
        for ($i = 0; $i < 10; $i++) {
            DB::table('insight_reports')->insert(
                InsightReportFactory::make()
            );
        }
    }
}
