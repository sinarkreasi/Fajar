<?php

return function ($wpdb) {
    $table = $wpdb->prefix . "vrin_google_ads_stats";

    $charset = $wpdb->get_charset_collate();

    $sql = "
        CREATE TABLE IF NOT EXISTS `$table` (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            campaign_id BIGINT NOT NULL,
            name VARCHAR(255),
            clicks BIGINT DEFAULT 0,
            impressions BIGINT DEFAULT 0,
            ctr DECIMAL(10,4) DEFAULT 0,
            avg_cpc BIGINT DEFAULT 0,
            cost_micros BIGINT DEFAULT 0,
            updated_at DATETIME,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_campaign_id (campaign_id),
            INDEX idx_updated_at (updated_at)
        ) $charset;
    ";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
};