<?php

use WPRewriter\Database\Migration;
use WPRewriter\Database\Schema\Blueprint;

return new class extends Migration
{
    public function up()
    {
        $this->schema->create('insight_tasks', function (Blueprint $table) {
            $table->id();
            $table->string('module'); // SEO, GoogleAds, SocialAds
            $table->string('action'); // crawl, sync, analyze, etc
            $table->text('params')->nullable();
            $table->string('status')->default('queued'); // queued, running, done, failed
            $table->timestamps();
        });
    }

    public function down()
    {
        $this->schema->drop('insight_tasks');
    }
};
