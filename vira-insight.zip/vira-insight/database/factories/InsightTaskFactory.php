<?php

namespace ViraInsight\Database\Factories;

use Faker\Generator;

class InsightTaskFactory
{
    public static function make(array $override = []): array
    {
        $faker = new Generator();

        return array_merge([
            'module' => $faker->randomElement(['SEO', 'GoogleAds', 'SocialAds']),
            'action' => $faker->randomElement(['crawl', 'sync', 'analyze']),
            'params' => json_encode(['param' => $faker->word]),
            'status' => 'queued',
        ], $override);
    }
}
