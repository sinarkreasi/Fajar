<?php

namespace ViraInsight\Database\Factories;

use Faker\Generator;

class InsightLogFactory
{
    public static function make(array $override = []): array
    {
        $faker = new Generator();

        return array_merge([
            'reference_type' => $faker->randomElement(['report', 'task', 'module']),
            'reference_id'   => $faker->randomNumber(),
            'message'        => $faker->sentence,
            'level'          => $faker->randomElement(['info', 'warning', 'error']),
        ], $override);
    }
}
