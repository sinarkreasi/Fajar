<?php

use WPRewriter\Database\Migration;
use WPRewriter\Database\Schema\Blueprint;

return new class extends Migration
{
    public function up()
    {
        $this->schema->create('insight_reports', function (Blueprint $table) {
            $table->id();
            $table->string('type')->index(); // seo, google_ads, social_ads, analytics
            $table->text('payload')->nullable();
            $table->string('status')->default('pending'); // pending, processed, failed
            $table->timestamps();
        });
    }

    public function down()
    {
        $this->schema->drop('insight_reports');
    }
};
