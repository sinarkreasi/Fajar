<?php

namespace ViraInsight\Database\Factories;

use Faker\Generator;
use ViraInsight\SEO\Models\InsightReport;

class InsightReportFactory
{
    public static function make(array $override = []): array
    {
        $faker = new Generator();

        return array_merge([
            'type'    => $faker->randomElement(['seo', 'google_ads', 'social_ads', 'analytics']),
            'payload' => json_encode(['sample' => $faker->sentence]),
            'status'  => 'pending',
        ], $override);
    }
}
