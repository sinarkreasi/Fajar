<?php
/**
 * Application Configuration
 *
 * @package ViraInsight
 */

declare(strict_types=1);

return [
    /*
    |--------------------------------------------------------------------------
    | Plugin Name
    |--------------------------------------------------------------------------
    */
    'name' => 'Vira Insight',

    /*
    |--------------------------------------------------------------------------
    | Plugin Slug
    |--------------------------------------------------------------------------
    */
    'slug' => 'vira-insight',

    /*
    |--------------------------------------------------------------------------
    | Plugin Prefix
    |--------------------------------------------------------------------------
    */
    'prefix' => 'vrin',

    /*
    |--------------------------------------------------------------------------
    | Plugin Version
    |--------------------------------------------------------------------------
    */
    'version' => VRIN_VERSION,

    /*
    |--------------------------------------------------------------------------
    | Service Providers
    |--------------------------------------------------------------------------
    |
    | List of service providers to be loaded by the kernel
    */
    'providers' => [
        \ViraInsight\Providers\AppServiceProvider::class,
        \ViraInsight\Providers\SEOServiceProvider::class,
        \ViraInsight\Providers\GoogleAdsServiceProvider::class,
        \ViraInsight\Providers\SocialAdsServiceProvider::class,
        \ViraInsight\Providers\ExtensionServiceProvider::class,
        \ViraInsight\Providers\RouteServiceProvider::class,
        \ViraInsight\Providers\ViewServiceProvider::class,
    ],

    /*
    |--------------------------------------------------------------------------
    | Lazy Providers
    |--------------------------------------------------------------------------
    |
    | Providers that should only be loaded when needed
    */
    'lazy_providers' => [
        'seo' => \ViraInsight\Providers\SEOServiceProvider::class,
        'google_ads' => \ViraInsight\Providers\GoogleAdsServiceProvider::class,
        'social_ads' => \ViraInsight\Providers\SocialAdsServiceProvider::class,
    ],

    /*
    |--------------------------------------------------------------------------
    | Debug Mode
    |--------------------------------------------------------------------------
    */
    'debug' => defined('WP_DEBUG') && WP_DEBUG,

    /*
    |--------------------------------------------------------------------------
    | Plugin Capabilities
    |--------------------------------------------------------------------------
    */
    'capabilities' => [
        'manage_vira_insight' => 'manage_options',
        'view_analytics' => 'edit_posts',
        'manage_extensions' => 'manage_options',
    ],
];
