<?php
/**
 * Google Ads Configuration
 *
 * @package ViraInsight
 */

return [
    'developer_token' => get_option('vrin_google_ads_dev_token', ''),
    'client_id' => get_option('vrin_google_ads_client_id', ''),
    'client_secret' => get_option('vrin_google_ads_client_secret', ''),
    'refresh_token' => get_option('vrin_google_ads_refresh_token', ''),
    'login_customer_id' => get_option('vrin_google_ads_login_customer_id', ''),
];