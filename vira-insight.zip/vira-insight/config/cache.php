<?php
/**
 * Cache Configuration
 *
 * @package ViraInsight
 */

declare(strict_types=1);

return [
    /*
    |--------------------------------------------------------------------------
    | Default Cache Driver
    |--------------------------------------------------------------------------
    |
    | Supported: "transient", "object", "file"
    */
    'driver' => 'transient',

    /*
    |--------------------------------------------------------------------------
    | Cache Prefix
    |--------------------------------------------------------------------------
    */
    'prefix' => 'vrin_cache_',

    /*
    |--------------------------------------------------------------------------
    | Default Cache TTL (in seconds)
    |--------------------------------------------------------------------------
    */
    'ttl' => 3600, // 1 hour

    /*
    |--------------------------------------------------------------------------
    | Cache Stores
    |--------------------------------------------------------------------------
    */
    'stores' => [
        'transient' => [
            'driver' => 'transient',
            'prefix' => 'vrin_',
        ],

        'object' => [
            'driver' => 'object',
            'group' => 'vira_insight',
        ],

        'file' => [
            'driver' => 'file',
            'path' => VRIN_PLUGIN_DIR . 'storage/cache',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Cache Tags
    |--------------------------------------------------------------------------
    */
    'tags' => [
        'seo' => 'vrin_seo',
        'google_ads' => 'vrin_google_ads',
        'social_ads' => 'vrin_social_ads',
        'extensions' => 'vrin_extensions',
        'views' => 'vrin_views',
    ],
];
