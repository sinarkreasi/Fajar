# Example Extension for Vira Insight

This is an example extension that demonstrates how to create modular add-ons for Vira Insight.

## Features

- Demonstrates extension architecture
- Shows how to register admin menus
- Shows how to register REST API endpoints
- Shows how to listen to plugin events

## Structure

```
example-extension/
├── manifest.json       # Extension metadata
├── Extension.php       # Main extension class
├── src/               # Additional classes (optional)
└── views/             # View templates (optional)
```

## Creating Your Own Extension

1. Copy this folder and rename it
2. Update `manifest.json` with your extension details
3. Update the namespace in `Extension.php`
4. Implement your custom functionality
5. Zip the folder
6. Upload via Vira Insight Extensions manager

## Hooks Available

- `seo.analysis.completed` - Triggered when SEO analysis completes
- `extension.activated` - Triggered when extension is activated
- `extension.deactivated` - Triggered when extension is deactivated

## License

GPL-2.0-or-later
