<?php
/**
 * Example Extension
 *
 * This is an example extension demonstrating how to create
 * modular add-ons for Vira Insight.
 *
 * @package ViraInsight\Extensions\ExampleExtension
 */

declare(strict_types=1);

namespace ViraInsight\Extensions\ExampleExtension;

use ViraInsight\Core\ServiceProvider;
use ViraInsight\Core\EventEmitter;

class Extension
{
    /**
     * Boot the extension
     */
    public function boot(): void
    {
        // Register hooks
        add_action('admin_menu', [$this, 'registerMenu']);

        // Register REST routes
        add_action('rest_api_init', [$this, 'registerRestRoutes']);

        // Listen to events
        EventEmitter::getInstance()->on('seo.analysis.completed', [$this, 'onSEOAnalysisCompleted']);
    }

    /**
     * Register admin menu
     */
    public function registerMenu(): void
    {
        add_submenu_page(
            'vira-insight',
            __('Example Extension', 'vira-insight'),
            __('Example Extension', 'vira-insight'),
            'manage_options',
            'vira-insight-example-extension',
            [$this, 'renderPage']
        );
    }

    /**
     * Render extension page
     */
    public function renderPage(): void
    {
        echo '<div class="wrap">';
        echo '<h1>' . esc_html__('Example Extension', 'vira-insight') . '</h1>';
        echo '<p>' . esc_html__('This is an example extension for Vira Insight.', 'vira-insight') . '</p>';
        echo '</div>';
    }

    /**
     * Register REST routes
     */
    public function registerRestRoutes(): void
    {
        register_rest_route('vira-insight/v1', '/example/hello', [
            'methods' => 'GET',
            'callback' => [$this, 'helloEndpoint'],
            'permission_callback' => function () {
                return current_user_can('manage_options');
            },
        ]);
    }

    /**
     * Example REST endpoint
     */
    public function helloEndpoint(\WP_REST_Request $request): \WP_REST_Response
    {
        return new \WP_REST_Response([
            'success' => true,
            'message' => 'Hello from Example Extension!',
        ], 200);
    }

    /**
     * Handle SEO analysis completed event
     */
    public function onSEOAnalysisCompleted($payload): void
    {
        $postId = $payload['post_id'] ?? 0;
        error_log("Example Extension: SEO analysis completed for post {$postId}");

        // Add custom analysis logic here
    }
}
