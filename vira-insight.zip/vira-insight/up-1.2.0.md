## Google Ads Automation

Ini bukan cuma “contoh snippet”, tapi arsitektur lengkap: flow data → file apa yang perlu dibuat → logika inti → cara ambil data otomatis pakai Google Ads API (Google Ads API v16, PHP 8.2+ SDK).

1. Requirement

Mandatory:

Google Cloud Project
Google Ads API enabled

Developer Token

OAuth Client (Client ID + Client Secret)

Refresh Token

Customer ID

2. Credential Storage (Recommended)

Untuk keamanan + WordPress standard:

/wp-content/vira-insight/config/google-ads.php


Format:

return [
    'developer_token' => ENV('VRIN_GOOGLE_ADS_DEV_TOKEN'),
    'client_id' => ENV('VRIN_GOOGLE_ADS_CLIENT_ID'),
    'client_secret' => ENV('VRIN_GOOGLE_ADS_CLIENT_SECRET'),
    'refresh_token' => ENV('VRIN_GOOGLE_ADS_REFRESH_TOKEN'),
    'login_customer_id' => ENV('VRIN_GOOGLE_ADS_LOGIN_CUSTOMER_ID'),
];


User mengisi credential via Settings → disimpan di wp_options → loader akan merge ke config file saat runtime.

3. Add New Service: GoogleAdsService.php

/src/Services/GoogleAds/GoogleAdsService.php

<?php

namespace ViraInsight\Services\GoogleAds;

use Google\Ads\GoogleAds\Lib\V16\GoogleAdsClientBuilder;
use Google\Ads\GoogleAds\Lib\OAuth2TokenBuilder;
use ViraInsight\Services\BaseService;
use ViraInsight\Repositories\GoogleAds\GoogleAdsRepository;

class GoogleAdsService extends BaseService
{
    protected $client;
    protected $repository;

    public function __construct(GoogleAdsRepository $repository)
    {
        $this->repository = $repository;
        $this->client = $this->bootClient();
    }

    protected function bootClient()
    {
        $oauth = (new OAuth2TokenBuilder())
            ->withClientId(config('google-ads.client_id'))
            ->withClientSecret(config('google-ads.client_secret'))
            ->withRefreshToken(config('google-ads.refresh_token'))
            ->build();

        return (new GoogleAdsClientBuilder())
            ->withDeveloperToken(config('google-ads.developer_token'))
            ->withLoginCustomerId(config('google-ads.login_customer_id'))
            ->withOAuth2Credential($oauth)
            ->build();
    }

    public function fetchCampaignStats($customerId)
    {
        $query = "
            SELECT 
              campaign.id,
              campaign.name,
              metrics.clicks,
              metrics.impressions,
              metrics.ctr,
              metrics.average_cpc,
              metrics.cost_micros
            FROM campaign
            WHERE campaign.status = 'ENABLED'
        ";

        $response = $this->client->getGoogleAdsServiceClient()
            ->search($customerId, $query);

        $data = [];

        foreach ($response->iterateAllElements() as $row) {
            $data[] = [
                'campaign_id'   => $row->getCampaign()->getId(),
                'name'          => $row->getCampaign()->getName(),
                'clicks'        => $row->getMetrics()->getClicks(),
                'impressions'   => $row->getMetrics()->getImpressions(),
                'ctr'           => $row->getMetrics()->getCtr(),
                'avg_cpc'       => $row->getMetrics()->getAverageCpc(),
                'cost_micros'   => $row->getMetrics()->getCostMicros(),
            ];
        }

        return $this->repository->storeCampaignStats($data);
    }
}

4. Add Repository

/src/Repositories/GoogleAds/GoogleAdsRepository.php

<?php

namespace ViraInsight\Repositories\GoogleAds;

use ViraInsight\Repositories\BaseRepository;
use wpdb;

class GoogleAdsRepository extends BaseRepository
{
    protected $table = 'vrin_google_ads_stats';

    public function storeCampaignStats(array $items)
    {
        global $wpdb;

        foreach ($items as $row) {
            $wpdb->insert("{$wpdb->prefix}{$this->table}", [
                'campaign_id' => $row['campaign_id'],
                'name'        => $row['name'],
                'clicks'      => $row['clicks'],
                'impressions' => $row['impressions'],
                'ctr'         => $row['ctr'],
                'avg_cpc'     => $row['avg_cpc'],
                'cost_micros' => $row['cost_micros'],
                'updated_at'  => current_time('mysql'),
            ]);
        }

        return true;
    }
}

5. Migration

/database/migrations/2025_01_01_000000_create_google_ads_stats_table.php

<?php

return function ($wpdb) {
    $table = $wpdb->prefix . "vrin_google_ads_stats";

    $charset = $wpdb->get_charset_collate();

    $sql = "
        CREATE TABLE IF NOT EXISTS `$table` (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            campaign_id BIGINT NOT NULL,
            name VARCHAR(255),
            clicks BIGINT DEFAULT 0,
            impressions BIGINT DEFAULT 0,
            ctr DECIMAL(10,4) DEFAULT 0,
            avg_cpc BIGINT DEFAULT 0,
            cost_micros BIGINT DEFAULT 0,
            updated_at DATETIME,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        ) $charset;
    ";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
};

6. Add Job (Automatic Fetch every hour)

/src/Jobs/GoogleAdsFetchJob.php

<?php

namespace ViraInsight\Jobs;

use ViraInsight\Services\GoogleAds\GoogleAdsService;

class GoogleAdsFetchJob
{
    public static function run()
    {
        $service = vrin_app(GoogleAdsService::class);

        $customerId = get_option('vrin_google_ads_customer_id');

        if (!$customerId) {
            return false;
        }

        $service->fetchCampaignStats($customerId);

        do_action('vrin_google_ads_synced');
    }
}


Register cron event di bootstrap plugin:

if (! wp_next_scheduled('vrin_google_ads_fetch')) {
    wp_schedule_event(time(), 'hourly', 'vrin_google_ads_fetch');
}

add_action('vrin_google_ads_fetch', ['ViraInsight\Jobs\GoogleAdsFetchJob', 'run']);

7. Controller untuk AJAX/API Endpoint

/src/Controllers/GoogleAdsController.php

<?php

namespace ViraInsight\Controllers;

use ViraInsight\Repositories\GoogleAds\GoogleAdsRepository;

class GoogleAdsController
{
    public function stats()
    {
        $repo = vrin_app(GoogleAdsRepository::class);

        wp_send_json_success($repo->all());
    }
}


Route:

/wp-json/vrin/v1/google-ads/stats

8. Real-Time Dashboard Component

/resources/components/google-ads/campaign-stats.php

(Template AMP-friendly & tanpa inline CSS)

<div id="vrin-google-ads-campaign-stats" class="vrin-card">
    <h3>Google Ads Campaign Overview</h3>
    <div class="vrin-table" data-endpoint="/wp-json/vrin/v1/google-ads/stats"></div>
</div>


JS:

/resources/scripts/google-ads-campaign.js


Tanpa inline JS di template.

9. Event Emitted

vrin_google_ads_synced → bisa dipakai extension lain untuk:

Alert notif (email/slack)

Sinkronisasi dashboard marketing

Integrasi ke Vira Ranking

10. Flow Runtime
Cron → Job → Service → Google Ads API → Repository → DB → Controller → Dashboard Component