<?php
/**
 * Database installation and management
 *
 * @package Vira_Store
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Database management class
 */
class VRSTORE_Database {
    /**
     * Singleton instance
     *
     * @var VRSTORE_Database|null
     */
    private static ?VRSTORE_Database $instance = null;

	/**
	 * Database version
	 *
	 * @var string
	 */
	private string $db_version = '1.9.0';

	/**
	 * Query cache
	 *
	 * @var array
	 */
	private array $query_cache = [];

	/**
	 * Cache expiration time (in seconds)
	 *
	 * @var int
	 */
	private int $cache_expire = 300; // 5 minutes

	/**
	 * Connection retry attempts
	 *
	 * @var int
	 */
	private int $max_retries = 3;

    /**
     * Get singleton instance
     *
     * @return VRSTORE_Database
     */
    public static function get_instance(): VRSTORE_Database {
        if (null === self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        // Install/update database on activation
        add_action('init', [$this, 'check_database_version']);
        
        // Also check on admin_init for better reliability
        add_action('admin_init', [$this, 'check_database_version']);
    }

    /**
     * Check database version and update if needed
     *
     * @return void
     */
    public function check_database_version(): void {
        $installed_version = get_option('vrstore_db_version', '0');
        
        if (version_compare($installed_version, $this->db_version, '<')) {
            // Run migrations first
            $this->run_migrations($installed_version);
            
            $result = $this->install_database();
            if ($result) {
                update_option('vrstore_db_version', $this->db_version);
            }
        }
    }

    /**
     * Install database tables
     *
     * @return bool True on success, false on failure
     */
    public function install_database(): bool {
        global $wpdb;

        // Check if we have database connection
        if (!$wpdb || $wpdb->last_error) {
            return false;
        }
        
        // Check database permissions
        $test_query = $wpdb->query("SELECT 1");
        if ($test_query === false) {
            return false;
        }

        $charset_collate = $wpdb->get_charset_collate();

        // Customers table
        $customers_table = $wpdb->prefix . 'vrstore_customers';
        $customers_sql = "CREATE TABLE $customers_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) DEFAULT 0,
            email varchar(100) NOT NULL,
            first_name varchar(100) DEFAULT '',
            last_name varchar(100) DEFAULT '',
            company varchar(200) DEFAULT '',
            phone varchar(20) DEFAULT '',
            address_line_1 varchar(255) DEFAULT '',
            address_line_2 varchar(255) DEFAULT '',
            city varchar(100) DEFAULT '',
            state varchar(100) DEFAULT '',
            postal_code varchar(20) DEFAULT '',
            country varchar(2) DEFAULT '',
            date_of_birth date DEFAULT NULL,
            status varchar(20) DEFAULT 'active',
            notes text DEFAULT '',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY email (email),
            KEY user_id (user_id),
            KEY status (status),
            KEY created_at (created_at)
        ) $charset_collate;";

        // Orders table
        $orders_table = $wpdb->prefix . 'vrstore_orders';
        $orders_sql = "CREATE TABLE $orders_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            order_number varchar(50) NOT NULL,
            customer_id bigint(20) DEFAULT 0,
            customer_email varchar(100) NOT NULL,
            customer_name varchar(200) DEFAULT '',
            customer_address text DEFAULT '',
            product_id bigint(20) NOT NULL,
            product_name varchar(500) NOT NULL,
            product_price decimal(10,2) NOT NULL,
            currency varchar(10) DEFAULT 'USD',
            license_type varchar(100) DEFAULT NULL,
            license_type_label varchar(200) DEFAULT NULL,
            payment_method varchar(50) DEFAULT '',
            payment_status varchar(20) DEFAULT 'pending',
            payment_id varchar(100) DEFAULT '',
            transaction_id varchar(100) DEFAULT '',
            license_key varchar(100) DEFAULT '',
            download_token varchar(100) DEFAULT '',
            download_count int(11) DEFAULT 0,
            download_limit int(11) DEFAULT -1,
            status varchar(20) DEFAULT 'pending',
            order_status varchar(20) DEFAULT 'pending',
            order_notes text DEFAULT '',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            expires_at datetime NULL,
            ip_address varchar(45) DEFAULT '',
            country varchar(100) DEFAULT '',
            city varchar(100) DEFAULT '',
            order_date datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY order_number (order_number),
            KEY customer_id (customer_id),
            KEY customer_email (customer_email),
            KEY product_id (product_id),
            KEY payment_status (payment_status),
            KEY status (status),
            KEY order_status (order_status),
            KEY license_type (license_type),
            KEY ip_address (ip_address),
            KEY country (country),
            KEY order_date (order_date),
            KEY created_at (created_at)
        ) $charset_collate;";

        // Licenses table
        $licenses_table = $wpdb->prefix . 'vrstore_licenses';
        $licenses_sql = "CREATE TABLE $licenses_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            license_key varchar(100) NOT NULL,
            product_id bigint(20) NOT NULL,
            order_id bigint(20) NOT NULL,
            customer_id bigint(20) DEFAULT 0,
            customer_email varchar(100) NOT NULL,
            status varchar(20) DEFAULT 'active',
            license_type_slug varchar(100) DEFAULT NULL,
            activation_limit int(11) DEFAULT 1,
            activation_count int(11) DEFAULT 0,
            activated_sites longtext DEFAULT '',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            expires_at datetime NULL,
            PRIMARY KEY (id),
            UNIQUE KEY license_key (license_key),
            KEY product_id (product_id),
            KEY order_id (order_id),
            KEY customer_id (customer_id),
            KEY customer_email (customer_email),
            KEY status (status),
            KEY license_type_slug (license_type_slug),
            KEY created_at (created_at)
        ) $charset_collate;";

        // License activations table
        $activations_table = $wpdb->prefix . 'vrstore_license_activations';
        $activations_sql = "CREATE TABLE $activations_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            license_id bigint(20) NOT NULL,
            license_key varchar(100) NOT NULL,
            site_url varchar(500) NOT NULL,
            site_name varchar(200) DEFAULT '',
            activation_token varchar(100) NOT NULL,
            status varchar(20) DEFAULT 'active',
            user_agent text DEFAULT '',
            ip_address varchar(45) DEFAULT '',
            activated_at datetime DEFAULT CURRENT_TIMESTAMP,
            deactivated_at datetime NULL,
            last_check datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY license_id (license_id),
            KEY license_key (license_key),
            KEY site_url (site_url(255)),
            KEY activation_token (activation_token),
            KEY status (status),
            KEY activated_at (activated_at)
        ) $charset_collate;";

        // API keys table
        $api_keys_table = $wpdb->prefix . 'vrstore_api_keys';
        $api_keys_sql = "CREATE TABLE $api_keys_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            key_name varchar(100) NOT NULL,
            api_key varchar(100) NOT NULL,
            api_secret varchar(100) NOT NULL,
            permissions longtext DEFAULT '',
            last_used datetime NULL,
            created_by bigint(20) DEFAULT 0,
            status varchar(20) DEFAULT 'active',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            expires_at datetime NULL,
            PRIMARY KEY (id),
            UNIQUE KEY api_key (api_key),
            KEY key_name (key_name),
            KEY status (status),
            KEY created_by (created_by),
            KEY created_at (created_at)
        ) $charset_collate;";

        // Download logs table
        $download_logs_table = $wpdb->prefix . 'vrstore_download_logs';
        $download_logs_sql = "CREATE TABLE $download_logs_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            order_id bigint(20) NOT NULL,
            product_id bigint(20) NOT NULL,
            customer_email varchar(100) NOT NULL,
            download_token varchar(100) DEFAULT '',
            file_name varchar(500) DEFAULT '',
            file_url varchar(1000) DEFAULT '',
            ip_address varchar(45) DEFAULT '',
            user_agent text DEFAULT '',
            license_key varchar(100) DEFAULT '',
            download_method varchar(50) DEFAULT '',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            download_date datetime DEFAULT CURRENT_TIMESTAMP,
            downloaded_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY order_id (order_id),
            KEY product_id (product_id),
            KEY customer_email (customer_email),
            KEY download_token (download_token),
            KEY license_key (license_key),
            KEY download_method (download_method),
            KEY created_at (created_at),
            KEY download_date (download_date),
            KEY downloaded_at (downloaded_at)
        ) $charset_collate;";

        // Payment logs table
        $payment_logs_table = $wpdb->prefix . 'vrstore_payment_logs';
        $payment_logs_sql = "CREATE TABLE $payment_logs_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            order_id bigint(20) DEFAULT 0,
            payment_method varchar(50) NOT NULL,
            payment_status varchar(20) NOT NULL,
            payment_id varchar(100) DEFAULT '',
            transaction_id varchar(100) DEFAULT '',
            amount decimal(10,2) NOT NULL,
            currency varchar(10) DEFAULT 'USD',
            gateway_response longtext DEFAULT '',
            ip_address varchar(45) DEFAULT '',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY order_id (order_id),
            KEY payment_method (payment_method),
            KEY payment_status (payment_status),
            KEY payment_id (payment_id),
            KEY transaction_id (transaction_id),
            KEY created_at (created_at)
        ) $charset_collate;";

        // Plugin versions table - NEW
        $plugin_versions_table = $wpdb->prefix . 'vrstore_plugin_versions';
        $plugin_versions_sql = "CREATE TABLE $plugin_versions_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            product_id bigint(20) NOT NULL,
            version varchar(50) NOT NULL,
            file_id bigint(20) DEFAULT NULL,
            file_path varchar(1000) DEFAULT '',
            file_name varchar(500) DEFAULT '',
            file_size bigint(20) DEFAULT 0,
            changelog text DEFAULT '',
            upgrade_notice text DEFAULT '',
            requires_wp varchar(20) DEFAULT '',
            requires_php varchar(20) DEFAULT '',
            tested_wp varchar(20) DEFAULT '',
            license_tiers longtext DEFAULT '',
            is_active tinyint(1) DEFAULT 1,
            release_date datetime DEFAULT CURRENT_TIMESTAMP,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY product_version (product_id, version),
            KEY product_id (product_id),
            KEY version (version),
            KEY file_id (file_id),
            KEY is_active (is_active),
            KEY release_date (release_date),
            KEY created_at (created_at)
        ) $charset_collate;";

        // License tiers table - NEW
        $license_tiers_table = $wpdb->prefix . 'vrstore_license_tiers';
        $license_tiers_sql = "CREATE TABLE $license_tiers_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            tier_slug varchar(100) NOT NULL,
            tier_name varchar(200) NOT NULL,
            tier_description text DEFAULT '',
            max_version varchar(50) DEFAULT '',
            update_priority int(11) DEFAULT 0,
            features longtext DEFAULT '',
            is_active tinyint(1) DEFAULT 1,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY tier_slug (tier_slug),
            KEY tier_name (tier_name),
            KEY is_active (is_active),
            KEY update_priority (update_priority),
            KEY created_at (created_at)
        ) $charset_collate;";

        // Update download tokens table - NEW
        $update_tokens_table = $wpdb->prefix . 'vrstore_update_tokens';
        $update_tokens_sql = "CREATE TABLE $update_tokens_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            token varchar(100) NOT NULL,
            license_key varchar(100) NOT NULL,
            product_id bigint(20) NOT NULL,
            version_id bigint(20) NOT NULL,
            site_url varchar(500) NOT NULL,
            expires_at datetime NOT NULL,
            used_at datetime NULL,
            ip_address varchar(45) DEFAULT '',
            user_agent text DEFAULT '',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY token (token),
            KEY license_key (license_key),
            KEY product_id (product_id),
            KEY version_id (version_id),
            KEY site_url (site_url(255)),
            KEY expires_at (expires_at),
            KEY created_at (created_at)
        ) $charset_collate;";

        // Coupons table
        $coupons_table = $wpdb->prefix . 'vrstore_coupons';
        $coupons_sql = "CREATE TABLE $coupons_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            code varchar(100) NOT NULL,
            description text,
            discount_type enum('percentage','fixed') NOT NULL DEFAULT 'percentage',
            discount_value decimal(10,2) NOT NULL DEFAULT '0.00',
            minimum_amount decimal(10,2) DEFAULT NULL,
            maximum_discount decimal(10,2) DEFAULT NULL,
            usage_limit int(11) DEFAULT NULL,
            usage_count int(11) NOT NULL DEFAULT '0',
            usage_limit_per_user int(11) DEFAULT NULL,
            start_date datetime DEFAULT NULL,
            end_date datetime DEFAULT NULL,
            status enum('active','inactive','expired') NOT NULL DEFAULT 'active',
            product_ids text,
            category_ids text,
            exclude_product_ids text,
            exclude_category_ids text,
            individual_use tinyint(1) NOT NULL DEFAULT '0',
            exclude_sale_items tinyint(1) NOT NULL DEFAULT '0',
            created_by bigint(20) NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY code (code),
            KEY status (status),
            KEY created_by (created_by),
            KEY start_date (start_date),
            KEY end_date (end_date)
        ) $charset_collate;";

        // Coupon usage table
        $coupon_usage_table = $wpdb->prefix . 'vrstore_coupon_usage';
        $coupon_usage_sql = "CREATE TABLE $coupon_usage_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            coupon_id bigint(20) NOT NULL,
            user_id bigint(20) DEFAULT NULL,
            order_id bigint(20) DEFAULT NULL,
            discount_amount decimal(10,2) NOT NULL DEFAULT '0.00',
            used_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY coupon_id (coupon_id),
            KEY user_id (user_id),
            KEY order_id (order_id),
            KEY used_at (used_at)
        ) $charset_collate;";

        // Domains table
        $domains_table = $wpdb->prefix . 'vrstore_domains';
        $domains_sql = "CREATE TABLE $domains_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            domain varchar(255) NOT NULL,
            name varchar(255) DEFAULT NULL,
            description text,
            registrar varchar(100) DEFAULT NULL,
            status enum('active','inactive','expired','pending','suspended') NOT NULL DEFAULT 'active',
            registration_date date DEFAULT NULL,
            expiry_date date DEFAULT NULL,
            auto_renew tinyint(1) NOT NULL DEFAULT '0',
            ssl_enabled tinyint(1) NOT NULL DEFAULT '0',
            ssl_issuer varchar(100) DEFAULT NULL,
            ssl_expiry_date date DEFAULT NULL,
            monitoring_enabled tinyint(1) NOT NULL DEFAULT '1',
            notification_email varchar(255) DEFAULT NULL,
            notification_days int(11) NOT NULL DEFAULT '30',
            last_checked datetime DEFAULT NULL,
            last_status varchar(50) DEFAULT NULL,
            response_time int(11) DEFAULT NULL,
            uptime_percentage decimal(5,2) DEFAULT NULL,
            created_by bigint(20) NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY domain (domain),
            KEY status (status),
            KEY created_by (created_by),
            KEY expiry_date (expiry_date),
            KEY ssl_expiry_date (ssl_expiry_date),
            KEY monitoring_enabled (monitoring_enabled)
        ) $charset_collate;";

        // Domain monitoring logs table
        $domain_logs_table = $wpdb->prefix . 'vrstore_domain_logs';
        $domain_logs_sql = "CREATE TABLE $domain_logs_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            domain_id bigint(20) NOT NULL,
            check_type enum('uptime','ssl','whois','dns') NOT NULL,
            status enum('success','warning','error') NOT NULL,
            response_time int(11) DEFAULT NULL,
            response_code int(11) DEFAULT NULL,
            message text,
            details longtext,
            checked_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY domain_id (domain_id),
            KEY check_type (check_type),
            KEY status (status),
            KEY checked_at (checked_at)
        ) $charset_collate;";

        // Domain notifications table
        $domain_notifications_table = $wpdb->prefix . 'vrstore_domain_notifications';
        $domain_notifications_sql = "CREATE TABLE $domain_notifications_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            domain_id bigint(20) NOT NULL,
            notification_type enum('domain_expiry','ssl_expiry','downtime','dns_issue') NOT NULL,
            status enum('pending','sent','failed') NOT NULL DEFAULT 'pending',
            recipient_email varchar(255) NOT NULL,
            subject varchar(255) NOT NULL,
            message text,
            scheduled_at datetime NOT NULL,
            sent_at datetime DEFAULT NULL,
            attempts int(11) NOT NULL DEFAULT '0',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY domain_id (domain_id),
            KEY notification_type (notification_type),
            KEY status (status),
            KEY scheduled_at (scheduled_at)
        ) $charset_collate;";

        // License domain activations table (for Domain Monitor)
        $license_domain_activations_table = $wpdb->prefix . 'vrstore_license_domain_activations';
        $license_domain_activations_sql = "CREATE TABLE $license_domain_activations_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            license_key varchar(100) NOT NULL,
            domain varchar(255) NOT NULL,
            product_id varchar(50) DEFAULT '',
            customer_id bigint(20) DEFAULT 0,
            status enum('active','inactive','suspended') NOT NULL DEFAULT 'active',
            activated_at datetime DEFAULT CURRENT_TIMESTAMP,
            deactivated_at datetime NULL,
            last_checked datetime DEFAULT CURRENT_TIMESTAMP,
            last_response_time int(11) DEFAULT NULL,
            domain_accessible tinyint(1) DEFAULT NULL,
            activation_ip varchar(45) DEFAULT '',
            user_agent text DEFAULT '',
            deactivation_reason varchar(100) DEFAULT '',
            PRIMARY KEY (id),
            UNIQUE KEY license_domain (license_key, domain),
            KEY license_key (license_key),
            KEY domain (domain),
            KEY status (status),
            KEY activated_at (activated_at),
            KEY customer_id (customer_id)
        ) $charset_collate;";

        // License activation logs table (for Domain Monitor)
        $license_activation_logs_table = $wpdb->prefix . 'vrstore_license_activation_logs';
        $license_activation_logs_sql = "CREATE TABLE $license_activation_logs_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            license_key varchar(100) NOT NULL,
            domain varchar(255) NOT NULL,
            action enum('activation','deactivation','check','validation') NOT NULL,
            success tinyint(1) NOT NULL DEFAULT 1,
            error_message text DEFAULT '',
            ip_address varchar(45) DEFAULT '',
            user_agent text DEFAULT '',
            attempt_time datetime DEFAULT CURRENT_TIMESTAMP,
            response_data longtext DEFAULT '',
            PRIMARY KEY (id),
            KEY license_key (license_key),
            KEY domain (domain),
            KEY action (action),
            KEY success (success),
            KEY attempt_time (attempt_time)
        ) $charset_collate;";

        // Download tracking table
        $download_tracking_table = $wpdb->prefix . 'vrstore_download_tracking';
        $download_tracking_sql = "CREATE TABLE $download_tracking_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            product_id bigint(20) NOT NULL,
            order_id varchar(50) NOT NULL,
            user_id bigint(20) DEFAULT NULL,
            customer_name varchar(255) DEFAULT NULL,
            customer_email varchar(255) DEFAULT NULL,
            file_name varchar(255) NOT NULL,
            file_url text NOT NULL,
            file_type varchar(50) DEFAULT 'unknown',
            ip_address varchar(45) DEFAULT NULL,
            user_agent text DEFAULT NULL,
            download_date datetime DEFAULT CURRENT_TIMESTAMP,
            file_size bigint(20) DEFAULT NULL,
            download_type varchar(20) DEFAULT 'single',
            download_process varchar(20) DEFAULT 'immediate',
            PRIMARY KEY (id),
            KEY product_id (product_id),
            KEY order_id (order_id),
            KEY user_id (user_id),
            KEY customer_email (customer_email),
            KEY ip_address (ip_address),
            KEY download_date (download_date),
            KEY download_type (download_type),
            KEY download_process (download_process)
        ) $charset_collate;";

        // License notifications table (for Domain Monitor)
        $license_notifications_table = $wpdb->prefix . 'vrstore_license_notifications';
        $license_notifications_sql = "CREATE TABLE $license_notifications_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            license_key varchar(100) NOT NULL,
            domain varchar(255) NOT NULL,
            notification_type enum('expiry_warning','security_alert','activation_limit') NOT NULL,
            recipient_email varchar(255) NOT NULL,
            subject varchar(255) NOT NULL,
            message text,
            status enum('pending','sent','failed') NOT NULL DEFAULT 'pending',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            sent_at datetime NULL,
            attempts int(11) NOT NULL DEFAULT 0,
            PRIMARY KEY (id),
            KEY license_key (license_key),
            KEY domain (domain),
            KEY notification_type (notification_type),
            KEY status (status),
            KEY created_at (created_at),
            KEY scheduled_at (created_at)
        ) $charset_collate;";

        // Email confirmations table
        $email_confirmations_table = $wpdb->prefix . 'vrstore_email_confirmations';
        $email_confirmations_sql = "CREATE TABLE $email_confirmations_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            confirmation_token varchar(100) NOT NULL,
            confirmation_code varchar(6) NOT NULL,
            email varchar(255) NOT NULL,
            context varchar(50) NOT NULL DEFAULT 'registration',
            status enum('pending','confirmed','expired') NOT NULL DEFAULT 'pending',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            expires_at datetime NOT NULL,
            confirmed_at datetime NULL,
            attempts int(11) NOT NULL DEFAULT 0,
            max_attempts int(11) NOT NULL DEFAULT 3,
            PRIMARY KEY (id),
            UNIQUE KEY confirmation_token (confirmation_token),
            KEY user_id (user_id),
            KEY confirmation_code (confirmation_code),
            KEY email (email),
            KEY status (status),
            KEY context (context),
            KEY expires_at (expires_at),
            KEY created_at (created_at)
        ) $charset_collate;";

        // Support tickets table
        $support_tickets_table = $wpdb->prefix . 'vrstore_support_tickets';
        $support_tickets_sql = "CREATE TABLE $support_tickets_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            ticket_number varchar(50) NOT NULL,
            customer_id bigint(20) NOT NULL,
            customer_email varchar(255) NOT NULL,
            customer_name varchar(255) DEFAULT '',
            product_id bigint(20) DEFAULT NULL,
            order_id bigint(20) DEFAULT NULL,
            subject varchar(500) NOT NULL,
            message longtext NOT NULL,
            status enum('open','pending','in_progress','resolved','closed') NOT NULL DEFAULT 'open',
            priority enum('low','normal','high','urgent') NOT NULL DEFAULT 'normal',
            assigned_to bigint(20) DEFAULT NULL,
            last_reply_by enum('customer','admin') DEFAULT 'customer',
            last_reply_at datetime DEFAULT CURRENT_TIMESTAMP,
            admin_unread_count int(11) NOT NULL DEFAULT 1,
            customer_unread_count int(11) NOT NULL DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            resolved_at datetime NULL,
            closed_at datetime NULL,
            PRIMARY KEY (id),
            UNIQUE KEY ticket_number (ticket_number),
            KEY customer_id (customer_id),
            KEY customer_email (customer_email),
            KEY product_id (product_id),
            KEY order_id (order_id),
            KEY status (status),
            KEY priority (priority),
            KEY assigned_to (assigned_to),
            KEY last_reply_by (last_reply_by),
            KEY last_reply_at (last_reply_at),
            KEY created_at (created_at)
        ) $charset_collate;";

        // Support ticket replies table
        $support_replies_table = $wpdb->prefix . 'vrstore_support_replies';
        $support_replies_sql = "CREATE TABLE $support_replies_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            ticket_id bigint(20) NOT NULL,
            reply_by enum('customer','admin') NOT NULL,
            user_id bigint(20) DEFAULT NULL,
            user_name varchar(255) DEFAULT '',
            user_email varchar(255) DEFAULT '',
            message longtext NOT NULL,
            attachments longtext DEFAULT '',
            is_private tinyint(1) NOT NULL DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY ticket_id (ticket_id),
            KEY reply_by (reply_by),
            KEY user_id (user_id),
            KEY is_private (is_private),
            KEY created_at (created_at)
        ) $charset_collate;";

        // Currency rates table
        $currency_rates_table = $wpdb->prefix . 'vrstore_currency_rates';
        $currency_rates_sql = "CREATE TABLE $currency_rates_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            currency_code varchar(3) NOT NULL,
            currency_name varchar(100) NOT NULL,
            currency_symbol varchar(10) NOT NULL,
            exchange_rate decimal(15,8) NOT NULL DEFAULT 1.00000000,
            is_active tinyint(1) NOT NULL DEFAULT 1,
            last_updated datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY currency_code (currency_code),
            KEY is_active (is_active),
            KEY last_updated (last_updated)
        ) $charset_collate;";

        // Security log table
        $security_log_table = $wpdb->prefix . 'vrstore_security_log';
        $security_log_sql = "CREATE TABLE $security_log_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            timestamp datetime DEFAULT CURRENT_TIMESTAMP,
            event_type varchar(50) NOT NULL,
            message text NOT NULL,
            ip_address varchar(45) NOT NULL,
            user_agent text,
            context longtext,
            PRIMARY KEY (id),
            KEY event_type (event_type),
            KEY timestamp (timestamp),
            KEY ip_address (ip_address)
        ) $charset_collate;";

        // Include WordPress database upgrade functions
        if (!function_exists('dbDelta')) {
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        }
        
        if (!function_exists('dbDelta')) {
            return false;
        }

        $tables_created = true;
        $errors = [];
        $created_tables = [];
        $failed_tables = [];

        $tables = [
            'customers' => $customers_sql,
            'orders' => $orders_sql,
            'licenses' => $licenses_sql,
            'license_activations' => $activations_sql,
            'api_keys' => $api_keys_sql,
            'download_logs' => $download_logs_sql,
            'payment_logs' => $payment_logs_sql,
            'plugin_versions' => $plugin_versions_sql,
            'license_tiers' => $license_tiers_sql,
            'update_tokens' => $update_tokens_sql,
            'coupons' => $coupons_sql,
            'coupon_usage' => $coupon_usage_sql,
            'domains' => $domains_sql,
            'domain_logs' => $domain_logs_sql,
            'domain_notifications' => $domain_notifications_sql,
            'license_domain_activations' => $license_domain_activations_sql,
            'license_activation_logs' => $license_activation_logs_sql,
            'license_notifications' => $license_notifications_sql,
            'download_tracking' => $download_tracking_sql,
            'email_confirmations' => $email_confirmations_sql,
            'support_tickets' => $support_tickets_sql,
            'support_replies' => $support_replies_sql,
            'currency_rates' => $currency_rates_sql,
            'security_log' => $security_log_sql
        ];

        foreach ($tables as $table_name => $sql) {
            // Clear any previous errors
            $wpdb->last_error = '';
            
            // Execute dbDelta
            $result = dbDelta($sql);
            
            // Check if table was created successfully
            $table_full_name = $wpdb->prefix . 'vrstore_' . $table_name;
            $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_full_name'");
            
            if ($table_exists === $table_full_name) {
                $created_tables[] = $table_name;
            } else {
                $tables_created = false;
                $failed_tables[] = $table_name;
                $error_msg = "Failed to create table: $table_full_name";
                
                if (!empty($wpdb->last_error)) {
                    $error_msg .= " - Error: " . $wpdb->last_error;
                }
                
                $errors[] = $error_msg;
            }
        }

        // Insert default data only if tables were created successfully
        if ($tables_created) {
            $this->insert_default_data();
        } else {
            // Store detailed error information for admin display
            update_option('vrstore_db_install_errors', [
                'errors' => $errors,
                'created_tables' => $created_tables,
                'failed_tables' => $failed_tables,
                'timestamp' => current_time('mysql')
            ]);
        }

        return $tables_created;
    }

    /**
     * Insert default data
     *
     * @return void
     */
    private function insert_default_data(): void {
        global $wpdb;

        // Insert default API key for admin
        $api_keys_table = $wpdb->prefix . 'vrstore_api_keys';
        
        $existing_key = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id FROM $api_keys_table WHERE key_name = %s",
                'Default Admin Key'
            )
        );

        if (!$existing_key) {
            $api_key = 'vrstore_' . wp_generate_password(32, false);
            $api_secret = wp_generate_password(64, true);
            
            $wpdb->insert(
                $api_keys_table,
                [
                    'key_name' => 'Default Admin Key',
                    'api_key' => $api_key,
                    'api_secret' => wp_hash($api_secret),
                    'permissions' => wp_json_encode(['read', 'write', 'delete']),
                    'created_by' => get_current_user_id(),
                    'status' => 'active'
                ],
                ['%s', '%s', '%s', '%s', '%d', '%s']
            );

            // Store the plain secret temporarily for display
            update_option('vrstore_default_api_secret', $api_secret, false);
        }
    }

    /**
     * Get table name with prefix
     *
     * @param string $table Table name without prefix
     * @return string
     */
    public function get_table_name(string $table): string {
        global $wpdb;
        return $wpdb->prefix . 'vrstore_' . $table;
    }

    /**
     * Check if all required tables exist
     *
     * @return array Array of missing tables
     */
    public function get_missing_tables(): array {
        global $wpdb;
        
        $required_tables = [
            'customers',
            'orders',
            'licenses', 
            'license_activations',
            'api_keys',
            'download_logs',
            'payment_logs',
            'coupons',
            'coupon_usage',
            'domains',
            'domain_logs',
            'domain_notifications',
            'license_domain_activations',
            'license_activation_logs',
            'license_notifications',
            'download_tracking',
            'email_confirmations',
            'support_tickets',
            'support_replies'
        ];
        
        $missing_tables = [];
        
        foreach ($required_tables as $table) {
            $table_name = $this->get_table_name($table);
            if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") !== $table_name) {
                $missing_tables[] = $table;
            }
        }
        
        return $missing_tables;
    }

    /**
     * Table existence cache
     *
     * @var array
     */
    private static array $table_cache = [];

    /**
     * Check if table exists with caching
     *
     * @param string $table Table name without prefix
     * @param bool $force_refresh Force refresh cache
     * @return bool
     */
    public function table_exists(string $table, bool $force_refresh = false): bool {
        global $wpdb;
        $table_name = $this->get_table_name($table);
        
        // Check cache first unless forced refresh
        if (!$force_refresh && isset(self::$table_cache[$table_name])) {
            return self::$table_cache[$table_name];
        }
        
        // Query database and cache result
        $exists = $wpdb->get_var("SHOW TABLES LIKE '$table_name'") === $table_name;
        self::$table_cache[$table_name] = $exists;
        
        return $exists;
    }

    /**
     * Clear table existence cache
     *
     * @return void
     */
    public function clear_table_cache(): void {
        self::$table_cache = [];
        $this->query_cache = [];
    }

    /**
     * Execute query with caching and retry logic
     *
     * @param string $query SQL query
     * @param array $params Query parameters
     * @param bool $use_cache Whether to use cache
     * @return mixed Query result
     */
    private function execute_cached_query(string $query, array $params = [], bool $use_cache = true) {
        global $wpdb;
        
        // Generate cache key
        $cache_key = md5($query . serialize($params));
        
        // Check cache first
        if ($use_cache && isset($this->query_cache[$cache_key])) {
            $cached_data = $this->query_cache[$cache_key];
            if (time() - $cached_data['timestamp'] < $this->cache_expire) {
                return $cached_data['result'];
            }
            unset($this->query_cache[$cache_key]);
        }
        
        // Execute query with retry logic
        $result = null;
        $attempts = 0;
        $last_error = null;
        
        while ($attempts < $this->max_retries) {
            $attempts++;
            
            try {
                // Clear previous error
                $wpdb->last_error = '';
                
                // Execute query
                if (!empty($params)) {
                    $result = $wpdb->get_results($wpdb->prepare($query, $params));
                } else {
                    $result = $wpdb->get_results($query);
                }
                
                // Check for database errors
                if (!empty($wpdb->last_error)) {
                    $last_error = $wpdb->last_error;
                    
                    // If it's a connection error, wait and retry
                    if (strpos($last_error, 'MySQL server has gone away') !== false ||
                        strpos($last_error, 'Lost connection') !== false) {
                        sleep(1 * $attempts); // Exponential backoff
                        continue;
                    } else {
                        // Other errors, don't retry
                        break;
                    }
                }
                
                // Success, break out of retry loop
                break;
                
            } catch (Exception $e) {
                $last_error = $e->getMessage();
                if ($attempts < $this->max_retries) {
                    sleep(1 * $attempts); // Exponential backoff
                }
            }
        }
        
        // Log if we had to retry
        if ($attempts > 1 && defined('WP_DEBUG') && WP_DEBUG) {
            // Query required multiple attempts, but succeeded
        }
        
        // Cache successful result
        if ($use_cache && $result !== false && empty($wpdb->last_error)) {
            $this->query_cache[$cache_key] = [
                'result' => $result,
                'timestamp' => time()
            ];
            
            // Limit cache size to prevent memory issues
            if (count($this->query_cache) > 50) {
                // Remove oldest entries
                $this->query_cache = array_slice($this->query_cache, -40, null, true);
            }
        }
        
        return $result;
    }

    /**
     * Secure database connection check with enhanced validation
     *
     * @return bool True if connection is secure and valid
     */
    private function validate_database_connection(): bool {
        global $wpdb;
        
        // Check if wpdb exists
        if (!$wpdb) {
            return false;
        }
        
        // Check for previous connection errors
        if ($wpdb->last_error) {
            return false;
        }
        
        // Test connection with a simple, safe query
        $test_result = $wpdb->get_var("SELECT 1 as test");
        
        // Validate result
        if ($test_result !== '1') {
            return false;
        }
        
        // Check if we have necessary privileges
        $privileges = $wpdb->get_results("SHOW GRANTS", ARRAY_A);
        if (empty($privileges)) {
            return false;
        }
        
        return true;
    }

    /**
     * Get optimized table status with indexing information
     *
     * @param string $table_name Table name
     * @return array Table status information
     */
    public function get_table_status(string $table_name): array {
        global $wpdb;
        
        $full_table_name = $this->get_table_name($table_name);
        
        // Get table status
        $status = $wpdb->get_row($wpdb->prepare(
            "SHOW TABLE STATUS LIKE %s",
            $full_table_name
        ), ARRAY_A);
        
        if (!$status) {
            return [];
        }
        
        // Get index information
        $indexes = $wpdb->get_results($wpdb->prepare(
            "SHOW INDEX FROM %s",
            $full_table_name
        ), ARRAY_A);
        
        return [
            'name' => $status['Name'],
            'rows' => $status['Rows'],
            'data_length' => $status['Data_length'],
            'index_length' => $status['Index_length'],
            'auto_increment' => $status['Auto_increment'],
            'created' => $status['Create_time'],
            'updated' => $status['Update_time'],
            'indexes' => array_column($indexes, 'Key_name'),
            'engine' => $status['Engine']
        ];
    }

    /**
     * Get detailed database status information
     *
     * @return array
     */
    public function get_database_status(): array {
        global $wpdb;
        
        $status = [
            'connection' => false,
            'tables' => [],
            'missing_tables' => [],
            'errors' => [],
            'last_install_errors' => get_option('vrstore_db_install_errors', []),
            'db_version' => get_option('vrstore_db_version', '0'),
            'current_version' => $this->db_version
        ];
        
        // Check database connection
        if ($wpdb && !$wpdb->last_error) {
            $test_query = $wpdb->query("SELECT 1");
            $status['connection'] = ($test_query !== false);
        }
        
        if (!$status['connection']) {
            $status['errors'][] = 'Database connection failed';
            return $status;
        }
        
        // Check each table
        $required_tables = [
            'customers', 'orders', 'licenses', 'license_activations', 'api_keys',
            'download_logs', 'payment_logs', 'coupons', 'coupon_usage',
            'domains', 'domain_logs', 'domain_notifications',
            'license_domain_activations', 'license_activation_logs',
            'license_notifications', 'download_tracking', 'email_confirmations',
            'support_tickets', 'support_replies'
        ];
        
        foreach ($required_tables as $table) {
            $table_name = $this->get_table_name($table);
            $exists = $wpdb->get_var("SHOW TABLES LIKE '$table_name'") === $table_name;
            
            $status['tables'][$table] = [
                'exists' => $exists,
                'full_name' => $table_name
            ];
            
            if (!$exists) {
                $status['missing_tables'][] = $table;
            }
        }
        
        return $status;
    }
    
    /**
     * Repair missing database tables
     *
     * @return array Result with success status and details
     */
    public function repair_database(): array {
        // Only allow for admin users
        if (!current_user_can('manage_options')) {
            return [
                'success' => false,
                'message' => 'Insufficient permissions',
                'details' => []
            ];
        }
        
        // Get current status
        $status = $this->get_database_status();
        
        if (empty($status['missing_tables'])) {
            return [
                'success' => true,
                'message' => 'No missing tables found. Database is healthy.',
                'details' => $status
            ];
        }
        
        // Clear previous error flags
        delete_option('vrstore_db_install_failed');
        delete_option('vrstore_db_install_errors');
        
        // Attempt to install database
        $result = $this->install_database();
        
        if ($result) {
            update_option('vrstore_db_version', $this->db_version);
            
            return [
                'success' => true,
                'message' => 'Database tables repaired successfully.',
                'details' => $this->get_database_status()
            ];
        } else {
            $errors = get_option('vrstore_db_install_errors', []);
            
            return [
                'success' => false,
                'message' => 'Database repair failed. Check error logs for details.',
                'details' => [
                    'status' => $this->get_database_status(),
                    'errors' => $errors
                ]
            ];
        }
    }

    /**
     * Force reinstall database tables (for admin repair)
     *
     * @return bool
     */
    public function force_reinstall(): bool {
        // Only allow for admin users
        if (!current_user_can('manage_options')) {
            return false;
        }
        
        // Drop existing tables first
        $this->drop_tables();
        
        // Reinstall tables
        $result = $this->install_database();
        
        if ($result) {
            update_option('vrstore_db_version', $this->db_version);
        }
        
        return $result;
    }

    /**
     * Run database migrations based on version
     *
     * @param string $from_version Current installed version
     * @return void
     */
    private function run_migrations(string $from_version): void {
        global $wpdb;
        
        // Migration for version 1.5.1 - Add missing columns to license_domain_activations table
        if (version_compare($from_version, '1.5.1', '<')) {
            $table_name = $wpdb->prefix . 'vrstore_license_domain_activations';
            
            // Check if table exists
            if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") === $table_name) {
                // Check if columns already exist
                $columns = $wpdb->get_results("SHOW COLUMNS FROM $table_name");
                $column_names = array_column($columns, 'Field');
                
                // Add last_response_time column if it doesn't exist
                if (!in_array('last_response_time', $column_names)) {
                    $wpdb->query("ALTER TABLE $table_name ADD COLUMN last_response_time int(11) DEFAULT NULL AFTER last_checked");
                }
                
                // Add domain_accessible column if it doesn't exist
                if (!in_array('domain_accessible', $column_names)) {
                    $wpdb->query("ALTER TABLE $table_name ADD COLUMN domain_accessible tinyint(1) DEFAULT NULL AFTER last_response_time");
                }
            }
        }
        
        // Migration for version 1.5.2 - Add missing columns to download_logs table
        if (version_compare($from_version, '1.5.2', '<')) {
            $table_name = $wpdb->prefix . 'vrstore_download_logs';
            
            // Check if table exists
            if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") === $table_name) {
                // Check if columns already exist
                $columns = $wpdb->get_results("SHOW COLUMNS FROM $table_name");
                $column_names = array_column($columns, 'Field');
                
                // Add license_key column if it doesn't exist
                if (!in_array('license_key', $column_names)) {
                    $wpdb->query("ALTER TABLE $table_name ADD COLUMN license_key varchar(100) DEFAULT '' AFTER user_agent");
                    $wpdb->query("ALTER TABLE $table_name ADD INDEX license_key (license_key)");
                }
                
                // Add download_method column if it doesn't exist
                if (!in_array('download_method', $column_names)) {
                    $wpdb->query("ALTER TABLE $table_name ADD COLUMN download_method varchar(50) DEFAULT 'direct' AFTER license_key");
                    $wpdb->query("ALTER TABLE $table_name ADD INDEX download_method (download_method)");
                }
                
                // Modify download_token to allow NULL/empty values if needed
                $wpdb->query("ALTER TABLE $table_name MODIFY download_token varchar(100) DEFAULT ''");
            }
        }
        
        // Migration for version 1.5.3 - Add missing columns to orders table
        if (version_compare($from_version, '1.5.3', '<')) {
            $table_name = $wpdb->prefix . 'vrstore_orders';
            
            // Check if table exists
            if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") === $table_name) {
                // Check if columns already exist
                $columns = $wpdb->get_results("SHOW COLUMNS FROM $table_name");
                $column_names = array_column($columns, 'Field');
                
                // Add ip_address column if it doesn't exist
                if (!in_array('ip_address', $column_names)) {
                    $wpdb->query("ALTER TABLE $table_name ADD COLUMN ip_address varchar(45) DEFAULT '' AFTER license_key");
                    $wpdb->query("ALTER TABLE $table_name ADD INDEX ip_address (ip_address)");
                }
                
                // Add country column if it doesn't exist
                if (!in_array('country', $column_names)) {
                    $wpdb->query("ALTER TABLE $table_name ADD COLUMN country varchar(100) DEFAULT '' AFTER ip_address");
                    $wpdb->query("ALTER TABLE $table_name ADD INDEX country (country)");
                }
                
                // Add city column if it doesn't exist
                if (!in_array('city', $column_names)) {
                    $wpdb->query("ALTER TABLE $table_name ADD COLUMN city varchar(100) DEFAULT '' AFTER country");
                }
                
                // Add order_date column if it doesn't exist
                if (!in_array('order_date', $column_names)) {
                    $wpdb->query("ALTER TABLE $table_name ADD COLUMN order_date datetime DEFAULT CURRENT_TIMESTAMP AFTER city");
                    $wpdb->query("ALTER TABLE $table_name ADD INDEX order_date (order_date)");
			}
		}
		
		// Migration for version 1.5.4 - Add download_type and download_process columns to download_tracking table
		if (version_compare($from_version, '1.5.4', '<')) {
			$table_name = $wpdb->prefix . 'vrstore_download_tracking';
			
			// Check if table exists
			if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") === $table_name) {
				// Check if columns already exist
				$columns = $wpdb->get_results("SHOW COLUMNS FROM $table_name");
				$column_names = array_column($columns, 'Field');
				
				// Add download_type column if it doesn't exist
				if (!in_array('download_type', $column_names)) {
					$wpdb->query("ALTER TABLE $table_name ADD COLUMN download_type varchar(20) DEFAULT 'single' AFTER file_size");
					$wpdb->query("ALTER TABLE $table_name ADD INDEX download_type (download_type)");
				}
				
				// Add download_process column if it doesn't exist
				if (!in_array('download_process', $column_names)) {
					$wpdb->query("ALTER TABLE $table_name ADD COLUMN download_process varchar(20) DEFAULT 'immediate' AFTER download_type");
					$wpdb->query("ALTER TABLE $table_name ADD INDEX download_process (download_process)");
				}
				
				// Update existing records to have default values if they are NULL
				$wpdb->query("UPDATE $table_name SET download_type = 'single' WHERE download_type IS NULL OR download_type = ''");
				$wpdb->query("UPDATE $table_name SET download_process = 'immediate' WHERE download_process IS NULL OR download_process = ''");
			}
		}
	}
    }

    /**
     * Drop all plugin tables (used on uninstall)
     *
     * @return void
     */
    public function drop_tables(): void {
        global $wpdb;

        $tables = [
            'vrstore_domain_notifications',
            'vrstore_domain_logs',
            'vrstore_domains',
            'vrstore_coupon_usage',
            'vrstore_coupons',
            'vrstore_customers',
            'vrstore_orders',
            'vrstore_licenses',
            'vrstore_license_activations',
            'vrstore_license_domain_activations',
            'vrstore_license_activation_logs',
            'vrstore_license_notifications',
            'vrstore_api_keys',
            'vrstore_download_logs',
            'vrstore_payment_logs',
            'vrstore_download_tracking',
            'vrstore_course_analytics',
            'vrstore_course_enrollments',
            'vrstore_course_progress',
            'vrstore_lesson_completions',
            'vrstore_course_certificates',
            'vrstore_video_tracking'
        ];

        foreach ($tables as $table) {
            $table_name = $wpdb->prefix . $table;
            $wpdb->query("DROP TABLE IF EXISTS $table_name");
        }

        // Delete database version option
        delete_option('vrstore_db_version');
        delete_option('vrstore_default_api_secret');
    }
}
