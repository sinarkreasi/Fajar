<?php
/**
 * License System Initialization and Migration
 *
 * @package Vira_Store
 * @since 1.0.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Initialize and migrate license system
 */
class VRSTORE_License_System_Init {
    
    /**
     * Run all initialization and migration tasks
     *
     * @return array Results of migration
     */
    public static function run_all_migrations(): array {
        $results = [];
        
        // 1. Fix pricing mode inconsistency
        $results['pricing_mode'] = self::fix_pricing_mode();
        
        // 2. Sync activation counts
        $results['activation_counts'] = self::sync_activation_counts();
        
        // 3. Normalize site URLs
        $results['site_urls'] = self::normalize_site_urls();
        
        // 4. Validate and fix license type slugs
        $results['license_slugs'] = self::fix_license_type_slugs();
        
        // 5. Clear all caches
        $results['cache_clear'] = self::clear_all_caches();
        
        return $results;
    }
    
    /**
     * Fix pricing mode inconsistency (Issue #16)
     *
     * @return array Result
     */
    public static function fix_pricing_mode(): array {
        global $wpdb;
        
        $products = $wpdb->get_results(
            "SELECT post_id FROM {$wpdb->postmeta} 
             WHERE meta_key = '_vrstore_pricing_mode'"
        );
        
        $fixed = 0;
        foreach ($products as $product) {
            delete_post_meta($product->post_id, '_vrstore_pricing_mode');
            $fixed++;
        }
        
        return [
            'success' => true,
            'fixed' => $fixed,
            'message' => "Removed pricing mode from {$fixed} products"
        ];
    }
    
    /**
     * Sync activation counts (Issue #8)
     *
     * @return array Result
     */
    public static function sync_activation_counts(): array {
        global $wpdb;
        
        $licenses_table = $wpdb->prefix . 'vrstore_licenses';
        
        // Check if table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$licenses_table'") !== $licenses_table) {
            return [
                'success' => false,
                'message' => 'Licenses table does not exist'
            ];
        }
        
        $licenses = $wpdb->get_results(
            "SELECT license_key FROM $licenses_table",
            ARRAY_A
        );
        
        $synced = 0;
        foreach ($licenses as $license) {
            VRSTORE_License_Helper::sync_activation_count($license['license_key']);
            $synced++;
        }
        
        return [
            'success' => true,
            'synced' => $synced,
            'message' => "Synced activation counts for {$synced} licenses"
        ];
    }
    
    /**
     * Normalize all site URLs (Issue #5)
     *
     * @return array Result
     */
    public static function normalize_site_urls(): array {
        global $wpdb;
        
        $activations_table = $wpdb->prefix . 'vrstore_license_activations';
        
        // Check if table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$activations_table'") !== $activations_table) {
            return [
                'success' => false,
                'message' => 'Activations table does not exist'
            ];
        }
        
        $activations = $wpdb->get_results(
            "SELECT id, site_url FROM $activations_table",
            ARRAY_A
        );
        
        $normalized = 0;
        foreach ($activations as $activation) {
            $old_url = $activation['site_url'];
            $new_url = VRSTORE_License_Helper::normalize_site_url($old_url);
            
            if ($old_url !== $new_url) {
                $wpdb->update(
                    $activations_table,
                    ['site_url' => $new_url],
                    ['id' => $activation['id']],
                    ['%s'],
                    ['%d']
                );
                $normalized++;
            }
        }
        
        return [
            'success' => true,
            'normalized' => $normalized,
            'message' => "Normalized {$normalized} site URLs"
        ];
    }
    
    /**
     * Fix license type slugs (Issue #19)
     *
     * @return array Result
     */
    public static function fix_license_type_slugs(): array {
        $settings = get_option('vrstore_settings', []);
        $custom_types = $settings['custom_license_types'] ?? [];
        
        if (empty($custom_types)) {
            return [
                'success' => true,
                'fixed' => 0,
                'message' => 'No custom license types to fix'
            ];
        }
        
        global $wpdb;
        $updated = 0;
        $used_slugs = [];
        
        foreach ($custom_types as &$type) {
            $old_slug = $type['slug'] ?? '';
            $label = $type['label'] ?? '';
            
            if (empty($label)) {
                continue;
            }
            
            // Generate proper slug
            $new_slug = VRSTORE_License_Helper::generate_unique_slug($label, $used_slugs);
            $used_slugs[] = $new_slug;
            
            if ($old_slug !== $new_slug) {
                // Update slug
                $type['slug'] = $new_slug;
                
                // Update all products using this slug
                $products = $wpdb->get_results(
                    "SELECT post_id, meta_value FROM {$wpdb->postmeta} 
                     WHERE meta_key = '_vrstore_product_license_pricing'",
                    ARRAY_A
                );
                
                foreach ($products as $product) {
                    $pricing = maybe_unserialize($product['meta_value']);
                    if (is_array($pricing) && isset($pricing[$old_slug])) {
                        $pricing[$new_slug] = $pricing[$old_slug];
                        unset($pricing[$old_slug]);
                        update_post_meta($product['post_id'], '_vrstore_product_license_pricing', $pricing);
                    }
                }
                
                // Update all licenses
                $wpdb->update(
                    $wpdb->prefix . 'vrstore_licenses',
                    ['license_type_slug' => $new_slug],
                    ['license_type_slug' => $old_slug],
                    ['%s'],
                    ['%s']
                );
                
                $updated++;
            }
        }
        
        // Save updated settings
        $settings['custom_license_types'] = $custom_types;
        update_option('vrstore_settings', $settings);
        
        return [
            'success' => true,
            'fixed' => $updated,
            'message' => "Fixed {$updated} license type slugs"
        ];
    }
    
    /**
     * Clear all caches (Issue #15)
     *
     * @return array Result
     */
    public static function clear_all_caches(): array {
        // Clear WordPress object cache
        wp_cache_flush();
        
        // Clear license-specific caches
        VRSTORE_License_Helper::clear_caches();
        
        // Clear transients
        global $wpdb;
        $wpdb->query(
            "DELETE FROM {$wpdb->options} 
             WHERE option_name LIKE '_transient_vrstore_%' 
             OR option_name LIKE '_transient_timeout_vrstore_%'"
        );
        
        return [
            'success' => true,
            'message' => 'All caches cleared successfully'
        ];
    }
    
    /**
     * Validate system integrity
     *
     * @return array Validation results
     */
    public static function validate_system(): array {
        $issues = [];
        
        // Check for duplicate license type slugs
        $settings = get_option('vrstore_settings', []);
        $custom_types = $settings['custom_license_types'] ?? [];
        $slugs = array_column($custom_types, 'slug');
        $duplicate_slugs = array_diff_assoc($slugs, array_unique($slugs));
        
        if (!empty($duplicate_slugs)) {
            $issues[] = 'Duplicate license type slugs found: ' . implode(', ', $duplicate_slugs);
        }
        
        // Check for invalid prices
        foreach ($custom_types as $type) {
            if (isset($type['regular_price']) && $type['regular_price'] < 0) {
                $issues[] = "Invalid price for license type: {$type['label']}";
            }
        }
        
        // Check for orphaned activations
        global $wpdb;
        $orphaned = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->prefix}vrstore_license_activations a
             LEFT JOIN {$wpdb->prefix}vrstore_licenses l ON a.license_key = l.license_key
             WHERE l.license_key IS NULL"
        );
        
        if ($orphaned > 0) {
            $issues[] = "{$orphaned} orphaned activations found";
        }
        
        // Check for mismatched activation counts
        $mismatched = $wpdb->get_results(
            "SELECT l.license_key, l.activation_count, COUNT(a.id) as actual_count
             FROM {$wpdb->prefix}vrstore_licenses l
             LEFT JOIN {$wpdb->prefix}vrstore_license_activations a 
                ON l.license_key = a.license_key AND a.status = 'active'
             GROUP BY l.license_key
             HAVING l.activation_count != actual_count",
            ARRAY_A
        );
        
        if (!empty($mismatched)) {
            $issues[] = count($mismatched) . " licenses with mismatched activation counts";
        }
        
        return [
            'valid' => empty($issues),
            'issues' => $issues,
            'message' => empty($issues) ? 'System validation passed' : 'Issues found: ' . implode('; ', $issues)
        ];
    }
}
