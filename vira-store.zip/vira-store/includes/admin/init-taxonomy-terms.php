<?php
/**
 * Initialize default terms for product taxonomies
 *
 * @package Vira_Store
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class to initialize taxonomy terms
 * No default terms - admin can freely add categories and tags as needed
 */
class VRSTORE_Init_Taxonomy_Terms {
    
    /**
     * Initialize taxonomy terms
     * Empty by design - admin can add categories and tags manually
     *
     * @return void
     */
    public static function init() {
        // No default terms created
        // Admin can freely add product categories and tags through WordPress admin
    }
}

// Run on plugin activation
register_activation_hook(VRSTORE_PLUGIN_FILE, [VRSTORE_Init_Taxonomy_Terms::class, 'init']);
