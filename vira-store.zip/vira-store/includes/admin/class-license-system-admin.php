<?php
/**
 * License System Admin Page
 *
 * @package Vira_Store
 * @since 1.0.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Admin page for license system management
 */
class VRSTORE_License_System_Admin {
    
    /**
     * Initialize admin page
     */
    public static function init(): void {
        add_action('admin_menu', [__CLASS__, 'add_admin_menu'], 100);
        add_action('admin_post_vrstore_run_migrations', [__CLASS__, 'handle_run_migrations']);
        add_action('admin_post_vrstore_validate_system', [__CLASS__, 'handle_validate_system']);
    }
    
    /**
     * Add admin menu
     */
    public static function add_admin_menu(): void {
        add_submenu_page(
            'vrstore-dashboard',
            __('License System', 'vira-store'),
            __('License System', 'vira-store'),
            'manage_options',
            'vrstore-license-system',
            [__CLASS__, 'render_admin_page']
        );
    }
    
    /**
     * Render admin page
     */
    public static function render_admin_page(): void {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }
        
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__('License System Management', 'vira-store'); ?></h1>
            
            <?php self::render_system_status(); ?>
            
            <div class="card" style="max-width: 800px; margin-top: 20px;">
                <h2><?php echo esc_html__('System Migrations', 'vira-store'); ?></h2>
                <p><?php echo esc_html__('Run these migrations to fix known issues and ensure system consistency.', 'vira-store'); ?></p>
                
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                    <?php wp_nonce_field('vrstore_migrations', 'vrstore_migrations_nonce'); ?>
                    <input type="hidden" name="action" value="vrstore_run_migrations">
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row"><?php echo esc_html__('Fix Pricing Mode', 'vira-store'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="migrations[]" value="pricing_mode" checked>
                                    <?php echo esc_html__('Remove deprecated pricing mode meta from products', 'vira-store'); ?>
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php echo esc_html__('Sync Activation Counts', 'vira-store'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="migrations[]" value="activation_counts" checked>
                                    <?php echo esc_html__('Synchronize activation counts with actual activations', 'vira-store'); ?>
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php echo esc_html__('Normalize Site URLs', 'vira-store'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="migrations[]" value="site_urls" checked>
                                    <?php echo esc_html__('Standardize all site URLs for consistent matching', 'vira-store'); ?>
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php echo esc_html__('Fix License Type Slugs', 'vira-store'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="migrations[]" value="license_slugs" checked>
                                    <?php echo esc_html__('Validate and fix license type slugs', 'vira-store'); ?>
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php echo esc_html__('Clear Caches', 'vira-store'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="migrations[]" value="cache_clear" checked>
                                    <?php echo esc_html__('Clear all license-related caches', 'vira-store'); ?>
                                </label>
                            </td>
                        </tr>
                    </table>
                    
                    <?php submit_button(__('Run Selected Migrations', 'vira-store'), 'primary', 'submit', false); ?>
                </form>
            </div>
            
            <div class="card" style="max-width: 800px; margin-top: 20px;">
                <h2><?php echo esc_html__('System Validation', 'vira-store'); ?></h2>
                <p><?php echo esc_html__('Check for system integrity issues.', 'vira-store'); ?></p>
                
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                    <?php wp_nonce_field('vrstore_validate', 'vrstore_validate_nonce'); ?>
                    <input type="hidden" name="action" value="vrstore_validate_system">
                    <?php submit_button(__('Validate System', 'vira-store'), 'secondary', 'submit', false); ?>
                </form>
            </div>
            
            <?php self::render_documentation(); ?>
        </div>
        <?php
    }
    
    /**
     * Render system status
     */
    private static function render_system_status(): void {
        global $wpdb;
        
        // Get statistics
        $licenses_count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}vrstore_licenses");
        $activations_count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}vrstore_license_activations WHERE status = 'active'");
        $settings = get_option('vrstore_settings', []);
        $license_types_count = count($settings['custom_license_types'] ?? []);
        
        ?>
        <div class="notice notice-info" style="padding: 15px;">
            <h3 style="margin-top: 0;"><?php echo esc_html__('System Status', 'vira-store'); ?></h3>
            <p>
                <strong><?php echo esc_html__('Total Licenses:', 'vira-store'); ?></strong> <?php echo esc_html($licenses_count); ?><br>
                <strong><?php echo esc_html__('Active Activations:', 'vira-store'); ?></strong> <?php echo esc_html($activations_count); ?><br>
                <strong><?php echo esc_html__('License Types:', 'vira-store'); ?></strong> <?php echo esc_html($license_types_count); ?>
            </p>
        </div>
        <?php
    }
    
    /**
     * Render documentation
     */
    private static function render_documentation(): void {
        ?>
        <div class="card" style="max-width: 800px; margin-top: 20px;">
            <h2><?php echo esc_html__('Documentation', 'vira-store'); ?></h2>
            
            <h3><?php echo esc_html__('What do these migrations do?', 'vira-store'); ?></h3>
            
            <h4><?php echo esc_html__('Fix Pricing Mode', 'vira-store'); ?></h4>
            <p><?php echo esc_html__('Removes the deprecated _vrstore_pricing_mode meta key from all products. The system now uses unified license pricing only.', 'vira-store'); ?></p>
            
            <h4><?php echo esc_html__('Sync Activation Counts', 'vira-store'); ?></h4>
            <p><?php echo esc_html__('Ensures the activation_count field in the licenses table matches the actual number of active activations. Fixes race condition issues.', 'vira-store'); ?></p>
            
            <h4><?php echo esc_html__('Normalize Site URLs', 'vira-store'); ?></h4>
            <p><?php echo esc_html__('Standardizes all site URLs by removing protocols, paths, ports, and converting to lowercase. Fixes deactivation matching issues.', 'vira-store'); ?></p>
            
            <h4><?php echo esc_html__('Fix License Type Slugs', 'vira-store'); ?></h4>
            <p><?php echo esc_html__('Validates and fixes license type slugs to ensure they are URL-safe and unique. Updates all products and licenses using old slugs.', 'vira-store'); ?></p>
            
            <h4><?php echo esc_html__('Clear Caches', 'vira-store'); ?></h4>
            <p><?php echo esc_html__('Clears all WordPress object caches, transients, and license-specific caches to ensure fresh data.', 'vira-store'); ?></p>
            
            <h3><?php echo esc_html__('When should I run migrations?', 'vira-store'); ?></h3>
            <ul>
                <li><?php echo esc_html__('After updating the plugin', 'vira-store'); ?></li>
                <li><?php echo esc_html__('If you notice inconsistent license behavior', 'vira-store'); ?></li>
                <li><?php echo esc_html__('If activation/deactivation is not working correctly', 'vira-store'); ?></li>
                <li><?php echo esc_html__('After changing license type settings', 'vira-store'); ?></li>
            </ul>
            
            <h3><?php echo esc_html__('Is it safe to run migrations?', 'vira-store'); ?></h3>
            <p><?php echo esc_html__('Yes, these migrations are designed to be safe and idempotent (can be run multiple times). However, we recommend backing up your database before running migrations on a production site.', 'vira-store'); ?></p>
        </div>
        <?php
    }
    
    /**
     * Handle run migrations
     */
    public static function handle_run_migrations(): void {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to perform this action.'));
        }
        
        check_admin_referer('vrstore_migrations', 'vrstore_migrations_nonce');
        
        $selected_migrations = $_POST['migrations'] ?? [];
        $results = [];
        
        if (in_array('pricing_mode', $selected_migrations, true)) {
            $results['pricing_mode'] = VRSTORE_License_System_Init::fix_pricing_mode();
        }
        
        if (in_array('activation_counts', $selected_migrations, true)) {
            $results['activation_counts'] = VRSTORE_License_System_Init::sync_activation_counts();
        }
        
        if (in_array('site_urls', $selected_migrations, true)) {
            $results['site_urls'] = VRSTORE_License_System_Init::normalize_site_urls();
        }
        
        if (in_array('license_slugs', $selected_migrations, true)) {
            $results['license_slugs'] = VRSTORE_License_System_Init::fix_license_type_slugs();
        }
        
        if (in_array('cache_clear', $selected_migrations, true)) {
            $results['cache_clear'] = VRSTORE_License_System_Init::clear_all_caches();
        }
        
        // Store results in transient
        set_transient('vrstore_migration_results', $results, 60);
        
        // Redirect back
        wp_redirect(add_query_arg([
            'page' => 'vrstore-license-system',
            'migration_complete' => '1'
        ], admin_url('admin.php')));
        exit;
    }
    
    /**
     * Handle validate system
     */
    public static function handle_validate_system(): void {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to perform this action.'));
        }
        
        check_admin_referer('vrstore_validate', 'vrstore_validate_nonce');
        
        $results = VRSTORE_License_System_Init::validate_system();
        
        // Store results in transient
        set_transient('vrstore_validation_results', $results, 60);
        
        // Redirect back
        wp_redirect(add_query_arg([
            'page' => 'vrstore-license-system',
            'validation_complete' => '1'
        ], admin_url('admin.php')));
        exit;
    }
}

// Initialize
VRSTORE_License_System_Admin::init();
