<?php
/**
 * Main plugin functionality
 *
 * @package Vira_Store
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Main plugin class for core functionality
 */
class Viraloka {
    /**
     * Singleton instance
     *
     * @var Viraloka|null
     */
    private static ?Viraloka $instance = null;

    /**
     * Get singleton instance
     *
     * @return Viraloka
     */
    public static function get_instance(): Viraloka {
        if (null === self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        // Initialize components
        $this->init_components();

        // Register hooks
        $this->register_hooks();
    }

    /**
     * Initialize components
     *
     * @return void
     */
    private function init_components(): void {
        // Load component classes
        $this->load_classes();

        // Initialize session manager (must be early)
        $this->init_session_manager();

        // Initialize licensing system
        $this->init_licensing_system();

        // Initialize REST API
        $this->init_rest_api();

        // Initialize shortcodes
        $this->init_shortcodes();

        // Initialize cart
        $this->init_cart();

        // Initialize payment gateways
        $this->init_payment_gateways();
        
        // Initialize admin menu
        $this->init_admin_menu();
        
        // Initialize assets
        $this->init_assets();
        
        // Initialize affiliate system
        $this->init_affiliate_system();
    }

    /**
     * Load component classes
     *
     * @return void
     */
    private function load_classes(): void {
        // Load database class first (it's in includes/ directory)
        $database_file = VRSTORE_PLUGIN_DIR . 'includes/class-database.php';
        if (file_exists($database_file)) {
            require_once $database_file;
        }
        
        // Include class files from classes subdirectory
        $class_files = [
            'class-session-manager.php', // Load session manager first
            'class-license-helper.php', // NEW: License helper utilities
            'class-product.php',
            'class-license.php',
            'class-extended-support.php', // Extended Support system
            'class-api.php',
            'class-shortcodes.php',
            'class-cart.php',
            'class-payment.php',
            'class-settings.php',
            'class-assets.php',
            'class-security.php',
            'class-plugin-update-security.php', // Plugin update security
            'class-admin-menu.php',
            'class-coupon.php',
            'class-domain-monitor.php',
            'class-pdf-certificate.php',
            'class-affiliate.php', // Affiliate system
        ];
        
        // Load license system initialization
        $init_file = VRSTORE_PLUGIN_DIR . 'includes/class-license-system-init.php';
        if (file_exists($init_file)) {
            require_once $init_file;
        }
        
        // Load license system admin (only in admin)
        if (is_admin()) {
            $admin_file = VRSTORE_PLUGIN_DIR . 'includes/admin/class-license-system-admin.php';
            if (file_exists($admin_file)) {
                require_once $admin_file;
            }
        }

        foreach ($class_files as $file) {
            $file_path = VRSTORE_PLUGIN_DIR . 'includes/classes/' . $file;
            if (file_exists($file_path)) {
                require_once $file_path;
            }
        }
    }

    /**
     * Register hooks
     *
     * @return void
     */
    private function register_hooks(): void {
        // Admin hooks
        // Menu is now handled by VRSTORE_Settings class
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);

        // Frontend hooks
        add_action('wp_enqueue_scripts', [$this, 'enqueue_frontend_assets']);

        // AJAX hooks
        add_action('wp_ajax_vrstore_process_license', [$this, 'process_license']);
        add_action('wp_ajax_nopriv_vrstore_process_license', [$this, 'process_license']);
    }

    /**
     * Initialize licensing system
     *
     * @return void
     */
    private function init_licensing_system(): void {
        // Licensing is now handled by main plugin class
        // This method is kept for backwards compatibility
    }

    /**
     * Initialize REST API
     *
     * @return void
     */
    private function init_rest_api(): void {
        // Initialize REST API if class exists
        if (class_exists('VRSTORE_API')) {
            add_action('rest_api_init', function() {
                VRSTORE_API::get_instance()->register_routes();
            });
        }
    }

    /**
     * Initialize shortcodes
     *
     * @return void
     */
    private function init_shortcodes(): void {
        // Initialize shortcodes if class exists
        if (class_exists('VRSTORE_Shortcodes')) {
            // Just get the instance - shortcodes are registered in the constructor
            VRSTORE_Shortcodes::get_instance();
        }
    }

    /**
     * Initialize cart
     *
     * @return void
     */
    private function init_cart(): void {
        // Initialize cart if class exists
        if (class_exists('VRSTORE_Cart')) {
            // Just get the instance - cart handlers are registered in the constructor
            VRSTORE_Cart::get_instance();
        }
    }

    /**
     * Initialize payment gateways
     *
     * @return void
     */
    private function init_payment_gateways(): void {
        // Initialize payment gateways if class exists
        if (class_exists('VRSTORE_Payment')) {
            // Just get the instance - gateways are registered in the constructor
            VRSTORE_Payment::get_instance();
        }
    }

    /**
     * Initialize admin menu
     *
     * @return void
     */
    private function init_admin_menu(): void {
        // Initialize admin menu if class exists
        if (class_exists('VRSTORE_Admin_Menu')) {
            // Just get the instance - admin menu and AJAX handlers are registered in the constructor
            VRSTORE_Admin_Menu::get_instance();
        }
    }
    
    /**
     * Initialize assets
     *
     * @return void
     */
    private function init_assets(): void {
        // Initialize assets if class exists
        if (class_exists('VRSTORE_Assets')) {
            // Just get the instance - assets are registered in the constructor
            VRSTORE_Assets::get_instance();
        }
    }
    
    /**
     * Initialize affiliate system
     *
     * @return void
     */
    private function init_affiliate_system(): void {
        // Initialize affiliate system if class exists
        if (class_exists('VRSTORE_Affiliate')) {
            // Just get the instance - affiliate system is registered in the constructor
            VRSTORE_Affiliate::get_instance();
        }
    }
    

    /**
     * Render admin page
     *
     * @return void
     */
    public function render_admin_page(): void {
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            return;
        }

        // Include admin page template
        include VRSTORE_PLUGIN_DIR . 'views/admin-page.php';
    }

    /**
     * Render products page
     *
     * @return void
     */
    public function render_products_page(): void {
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            return;
        }

        // Include products page template
        include VRSTORE_PLUGIN_DIR . 'views/products-page.php';
    }

    /**
     * Render licenses page
     *
     * @return void
     */
    public function render_licenses_page(): void {
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            return;
        }

        // Include licenses page template
        include VRSTORE_PLUGIN_DIR . 'views/licenses-page.php';
    }

    /**
     * Render settings page
     *
     * @return void
     */
    public function render_settings_page(): void {
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            return;
        }

        // Include settings page template
        include VRSTORE_PLUGIN_DIR . 'views/settings-page.php';
    }

    /**
     * Enqueue admin assets
     *
     * @param string $hook Current admin page
     * @return void
     */
    public function enqueue_admin_assets(string $hook): void {
        // Only enqueue on plugin admin pages
        if (strpos((string)$hook, 'vira-store') === false) {
            return;
        }

        // Enqueue admin styles
        wp_enqueue_style(
            'vrstore-admin',
            VRSTORE_PLUGIN_URL . 'assets/css/admin.css',
            [],
            VRSTORE_VERSION
        );

        // Enqueue admin scripts
        wp_enqueue_script(
            'vrstore-admin',
            VRSTORE_PLUGIN_URL . 'assets/js/admin.js',
            ['jquery'],
            VRSTORE_VERSION,
            true
        );

        // Localize script
        wp_localize_script(
            'vrstore-admin',
            'vrstore_admin',
            [
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('vrstore_admin_nonce'),
            ]
        );
    }

    /**
     * Enqueue frontend assets
     *
     * @return void
     */
    public function enqueue_frontend_assets(): void {
        // Enqueue frontend styles
        wp_enqueue_style(
            'vrstore-frontend',
            VRSTORE_PLUGIN_URL . 'assets/css/frontend.css',
            [],
            VRSTORE_VERSION
        );

        // Enqueue frontend scripts
        wp_enqueue_script(
            'vrstore-frontend',
            VRSTORE_PLUGIN_URL . 'assets/js/frontend.js',
            ['jquery'],
            VRSTORE_VERSION,
            true
        );

        // Localize script
        wp_localize_script(
            'vrstore-frontend',
            'vrstore_frontend',
            [
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('vrstore_frontend_nonce'),
            ]
        );
    }

    /**
     * Initialize session manager
     *
     * @return void
     */
    private function init_session_manager(): void {
        // Only initialize session manager when appropriate (not during wp-cron, admin, etc.)
        if (class_exists('VRSTORE_Session_Manager')) {
            VRSTORE_Session_Manager::get_instance_if_needed();
        }
    }

    /**
     * Process license AJAX request
     *
     * @return void
     */
    public function process_license(): void {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'] ?? '')), 'vrstore_frontend_nonce')) {
            wp_send_json_error(['message' => __('Invalid nonce.', 'vira-store')]);
        }

        // Check license key
        if (!isset($_POST['license_key']) || empty($_POST['license_key'])) {
            wp_send_json_error(['message' => __('License key is required.', 'vira-store')]);
        }

        // Sanitize license key
        $license_key = sanitize_text_field(wp_unslash(($_POST['license_key'] ?? "")));

        // Process license key
        if (class_exists('VRSTORE_License')) {
            $result = VRSTORE_License::get_instance()->validate_license($license_key);

            if ($result['valid']) {
                wp_send_json_success($result);
            } else {
                wp_send_json_error($result);
            }
        } else {
            wp_send_json_error(['message' => __('License system is not available.', 'vira-store')]);
        }

        wp_die();
    }
}

// Initialize Viraloka
Viraloka::get_instance();