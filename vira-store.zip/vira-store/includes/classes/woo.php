<?php
/**
 * WooCommerce integration for Vira Store
 *
 * When enabled, this class maps WooCommerce orders to Vira Store orders
 * and triggers license creation using the existing VRSTORE_License class.
 *
 * @package Vira_Store
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('VRSTORE_Woo_Integration')) {
    class VRSTORE_Woo_Integration {
        /** Singleton instance */
        private static ?VRSTORE_Woo_Integration $instance = null;

        /** Get instance */
        public static function get_instance(): VRSTORE_Woo_Integration {
            if (null === self::$instance) {
                self::$instance = new self();
            }
            return self::$instance;
        }

        private function __construct() {
            // Only initialize when WooCommerce is active and integration enabled in settings
            add_action('init', [$this, 'maybe_init'], 20);
        }

        public function maybe_init(): void {
            // Check setting
            if (!class_exists('VRSTORE_Settings')) {
                return;
            }

            $settings = VRSTORE_Settings::get_instance();
            $enabled = $settings->get_setting('enable_woocommerce', false);

            if (!$enabled) {
                return;
            }

            if (!class_exists('WooCommerce')) {
                // Woo not active; admin notice handled elsewhere
                return;
            }

            // Hook into WooCommerce order lifecycle
            // When an order is created/processed
            add_action('woocommerce_checkout_order_processed', [$this, 'handle_wc_order_processed'], 10, 1);

            // When order status becomes completed (payment finished)
            add_action('woocommerce_order_status_completed', [$this, 'handle_wc_order_completed'], 10, 1);

            // Refunds/cancellations: revoke or deactivate licenses when configured
            add_action('woocommerce_order_status_refunded', [$this, 'handle_wc_order_refunded'], 10, 1);
            add_action('woocommerce_order_status_cancelled', [$this, 'handle_wc_order_cancelled'], 10, 1);
        }

        /**
         * Handle when WooCommerce creates an order (checkout processed)
         * We'll create a corresponding Vira Store order (pending) and create pending licenses if applicable.
         *
         * @param int $order_id WooCommerce order ID
         */
        public function handle_wc_order_processed(int $order_id): void {
            try {
                $wc_order = wc_get_order($order_id);
                if (!$wc_order) {
                    return;
                }

                // Prevent duplicate mapping: check if Woo order already has a vrstore order id
                $existing = get_post_meta($order_id, '_vrstore_order_id', true);
                if (!empty($existing)) {
                    return;
                }

                // Build vrstore order_data from WC order
                $customer_name = trim($wc_order->get_billing_first_name() . ' ' . $wc_order->get_billing_last_name());
                $customer_email = $wc_order->get_billing_email() ?: $wc_order->get_billing_email();

                $payment_method = $wc_order->get_payment_method() ?: 'woocommerce';
                $status = 'pending';
                $payment_status = $wc_order->is_paid() ? 'completed' : 'pending';

                $cart_items = [];

                foreach ($wc_order->get_items() as $item_id => $item) {
                    $product = $item->get_product();
                    if (!$product) {
                        continue;
                    }

                    // Try to get mapped Vira Store product ID from product meta
                    $mapped_product_id = get_post_meta($product->get_id(), '_vrstore_product_id', true);

                    // If mapping is empty attempt to detect if this WC product represents a Vira Store course
                    $is_course = false;
                    $use_product_id = 0;

                    if (!empty($mapped_product_id)) {
                        $use_product_id = intval($mapped_product_id);
                        // If mapped post is a course, mark as course
                        $mapped_post = get_post($use_product_id);
                        if ($mapped_post && $mapped_post->post_type === 'vrstore_course') {
                            $is_course = true;
                        }
                    } else {
                        // If the Woo product itself stores a flag indicating it's a course mapping
                        $prod_flag = get_post_meta($product->get_id(), '_vrstore_is_course', true);
                        if ($prod_flag) {
                            // Try to use a provided course id meta
                            $course_id = get_post_meta($product->get_id(), '_vrstore_course_id', true);
                            if ($course_id) {
                                $use_product_id = intval($course_id);
                                $is_course = true;
                            }
                        }
                    }

                    // Build common item data
                    $line = [
                        'product_id' => $use_product_id,
                        'product_name' => $item->get_name(),
                        'quantity' => intval($item->get_quantity()),
                        'price' => floatval($wc_order->get_item_total($item, false)),
                    ];

                    // If this line is a course mapping, ensure license generation will be disabled by flag
                    if ($is_course) {
                        $line['item_type'] = 'course_purchase';
                        // also set flag so that VRSTORE_Order will not try to generate license for course (VRSTORE_Course ensures course meta disables license generation too)
                        $line['disable_license'] = true;
                    }

                    // If product contains special meta for license type (for example when buying extended support via WC)
                    // read from item meta keys that plugins may set (best-effort)
                    $license_type = $item->get_meta('vrstore_license_type', true);
                    if (!$license_type) {
                        $license_type = $item->get_meta('_vrstore_license_type', true);
                    }

                    if ($license_type) {
                        $line['license_type'] = sanitize_text_field($license_type);
                    }

                    // Detect extended support indicator in product SKU or meta
                    $item_type = $item->get_meta('vrstore_item_type', true) ?: '';
                    if (!$item_type && $product) {
                        $item_type = get_post_meta($product->get_id(), '_vrstore_item_type', true) ?: '';
                    }

                    if ($item_type && empty($line['item_type'])) {
                        $line['item_type'] = sanitize_text_field($item_type);
                    }

                    $cart_items[] = $line;
                }

                // Build order payload
                $order_data = [
                    'customer_name' => $customer_name ?: $wc_order->get_billing_first_name() ?: 'Customer',
                    'customer_email' => sanitize_email($customer_email ?: $wc_order->get_billing_email()),
                    'payment_method' => sanitize_text_field($payment_method),
                    'status' => $status,
                    'payment_status' => $payment_status,
                    'currency' => $wc_order->get_currency() ?: get_option('vrstore_currency', 'USD'),
                    'total' => floatval($wc_order->get_total()),
                    'user_id' => intval($wc_order->get_user_id() ?: 0),
                    'transaction_id' => $wc_order->get_transaction_id() ?: '',
                    'cart_items' => $cart_items,
                ];

                // Create Vira Store order using database method if available
                if (class_exists('VRSTORE_Order')) {
                    // Prefer database table creation when available
                    $order_id_vr = VRSTORE_Order::create_order_in_database($order_data);
                    if ($order_id_vr) {
                        // Save mapping on Woo order to avoid duplicates
                        update_post_meta($order_id, '_vrstore_order_id', intval($order_id_vr));

                        // Store license key or pending status will be created by VRSTORE_Order logic
                        if (!empty($order_data['cart_items'])) {
                            // Attempt to propagate license keys back to Woo order meta for convenience
                            $licenses = [];
                            // Try to fetch license created by VRSTORE_Order: look up vrstore_orders table by inserted id
                            global $wpdb;
                            $orders_table = $wpdb->prefix . 'vrstore_orders';
                            $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $orders_table WHERE id = %d", $order_id_vr));
                            if ($row && isset($row->license_key) && !empty($row->license_key)) {
                                update_post_meta($order_id, '_vrstore_license_key', $row->license_key);
                            }
                        }
                    }
                }
            } catch (Exception $e) {
                // Don't break checkout; just log when debug
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log('VRSTORE Woo integration error (processed): ' . $e->getMessage());
                }
            }
        }

        /**
         * Handle when WooCommerce order is completed: ensure Vira Store order/payment status is updated
         * and activate any pending licenses.
         *
         * @param int $order_id WooCommerce order ID
         */
        public function handle_wc_order_completed(int $order_id): void {
            try {
                $wc_order = wc_get_order($order_id);
                if (!$wc_order) {
                    return;
                }

                $mapped = get_post_meta($order_id, '_vrstore_order_id', true);
                if (empty($mapped)) {
                    // No mapped VR order: create one now with completed status
                    $this->handle_wc_order_processed($order_id);
                    $mapped = get_post_meta($order_id, '_vrstore_order_id', true);
                }

                if ($mapped && class_exists('VRSTORE_Order')) {
                    // Update payment and order status in VRSTORE
                    $vr_order_id = intval($mapped);
                    VRSTORE_Order::update_payment_status($vr_order_id, 'completed');
                    VRSTORE_Order::update_order_status($vr_order_id, 'completed');

                    // If VRSTORE_License class is available, ensure any pending licenses are activated
                    if (class_exists('VRSTORE_License')) {
                        // VRSTORE_Order.activate_pending_licenses_for_order will be called by update_* above

                        // Optionally copy license keys from vrstore_orders table to Woo order meta
                        global $wpdb;
                        $orders_table = $wpdb->prefix . 'vrstore_orders';
                        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $orders_table WHERE id = %d", $vr_order_id));
                        if ($row && !empty($row->license_key)) {
                            update_post_meta($order_id, '_vrstore_license_key', $row->license_key);
                        } else {
                            // Try to lookup licenses table for licenses with this order id
                            $licenses_table = $wpdb->prefix . 'vrstore_licenses';
                            if ($wpdb->get_var("SHOW TABLES LIKE '$licenses_table'") === $licenses_table) {
                                $license = $wpdb->get_row($wpdb->prepare("SELECT * FROM $licenses_table WHERE order_id = %d LIMIT 1", $vr_order_id));
                                if ($license && !empty($license->license_key)) {
                                    update_post_meta($order_id, '_vrstore_license_key', $license->license_key);
                                }
                            }
                        }
                    }
                }
            } catch (Exception $e) {
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log('VRSTORE Woo integration error (completed): ' . $e->getMessage());
                }
            }
        }

        /**
         * Handle refunded orders: deactivate associated licenses if setting enabled
         *
         * @param int $order_id Woo order ID
         */
        public function handle_wc_order_refunded(int $order_id): void {
            try {
                if (!class_exists('VRSTORE_Settings')) {
                    return;
                }

                $settings = VRSTORE_Settings::get_instance();
                $revoke = $settings->get_setting('woocommerce_revoke_license_on_refund', false);
                if (!$revoke) {
                    return;
                }

                $mapped = get_post_meta($order_id, '_vrstore_order_id', true);
                if (empty($mapped)) {
                    return;
                }

                if (!class_exists('VRSTORE_License')) {
                    return;
                }

                global $wpdb;
                $licenses_table = $wpdb->prefix . 'vrstore_licenses';
                if ($wpdb->get_var("SHOW TABLES LIKE '$licenses_table'") !== $licenses_table) {
                    return;
                }

                // Find licenses for this vrstore order
                $licenses = $wpdb->get_results($wpdb->prepare("SELECT * FROM $licenses_table WHERE order_id = %d", intval($mapped)));

                if (empty($licenses)) {
                    return;
                }

                foreach ($licenses as $license) {
                    if (empty($license->license_key)) {
                        continue;
                    }

                    // Deactivate license using existing API; best-effort domain/site_url param empty
                    $license_class = VRSTORE_License::get_instance();
                    try {
                        // The deactivate_license expects site_url in this project; pass empty and let implementation handle it
                        $license_class->deactivate_license($license->license_key, '');
                    } catch (Exception $ex) {
                        if (defined('WP_DEBUG') && WP_DEBUG) {
                            error_log('VRSTORE Woo integration error while deactivating license: ' . $ex->getMessage());
                        }
                    }
                }
            } catch (Exception $e) {
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log('VRSTORE Woo integration error (refunded): ' . $e->getMessage());
                }
            }
        }

        /**
         * Handle cancelled orders: treat similarly to refunds if configured
         *
         * @param int $order_id Woo order ID
         */
        public function handle_wc_order_cancelled(int $order_id): void {
            // Reuse refund logic
            $this->handle_wc_order_refunded($order_id);
        }
    }

    // Initialize integration when plugin components are loaded
    add_action('wp_loaded', function() {
        if (class_exists('VRSTORE_Woo_Integration')) {
            VRSTORE_Woo_Integration::get_instance();
        }
    }, 20);
}
