<?php
/**
 * Enhanced Security Class with Rate Limiting and Advanced Protection
 *
 * @package Vira_Store
 * @since 1.0.0
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

/**
 * VRSTORE_Enhanced_Security Class
 *
 * Provides advanced security features including rate limiting, threat detection,
 * comprehensive input validation, and security monitoring.
 *
 * @since 1.0.0
 */
class VRSTORE_Enhanced_Security {

    /**
     * Instance of this class.
     *
     * @since 1.0.0
     * @var VRSTORE_Enhanced_Security|null
     */
    private static ?VRSTORE_Enhanced_Security $instance = null;

    /**
     * Rate limiting rules
     *
     * @var array
     */
    private array $rate_limits = [
        'api_requests' => ['limit' => 100, 'window' => 3600], // 100 requests per hour
        'license_validate' => ['limit' => 50, 'window' => 3600], // 50 validations per hour
        'license_activate' => ['limit' => 10, 'window' => 3600], // 10 activations per hour
        'order_create' => ['limit' => 5, 'window' => 300], // 5 orders per 5 minutes
        'login_attempts' => ['limit' => 5, 'window' => 900], // 5 attempts per 15 minutes
        'file_downloads' => ['limit' => 20, 'window' => 3600], // 20 downloads per hour
    ];

    /**
     * Blocked IP addresses
     *
     * @var array
     */
    private array $blocked_ips = [];

    /**
     * Suspicious patterns
     *
     * @var array
     */
    private array $suspicious_patterns = [
        'sql_injection' => [
            '/union\s+select/i',
            '/select\s+.*\s+from/i',
            '/insert\s+into/i',
            '/delete\s+from/i',
            '/update\s+.*\s+set/i',
            '/drop\s+table/i',
        ],
        'xss_attempts' => [
            '/<script[^>]*>/i',
            '/<iframe[^>]*>/i',
            '/javascript:/i',
            '/on\w+\s*=/i',
            '/<img[^>]+src[^>]*=/i',
        ],
        'path_traversal' => [
            '/\.\.\//i',
            '/\.\.\\\\/i',
            '/etc\/passwd/i',
            '/proc\/self\/environ/i',
        ],
    ];

    /**
     * Constructor.
     *
     * @since 1.0.0
     */
    private function __construct() {
        $this->init_hooks();
        $this->load_blocked_ips();
    }

    /**
     * Get instance of this class.
     *
     * @since 1.0.0
     * @return VRSTORE_Enhanced_Security
     */
    public static function get_instance(): VRSTORE_Enhanced_Security {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Initialize hooks.
     *
     * @since 1.0.0
     */
    private function init_hooks(): void {
        // Early security checks
        add_action('init', [$this, 'early_security_checks'], 1);
        
        // Request filtering
        add_action('init', [$this, 'filter_requests'], 5);
        
        // Rate limiting for AJAX requests
        add_action('wp_ajax_vrstore_validate_license', [$this, 'rate_limit_license_validation'], 1);
        add_action('wp_ajax_nopriv_vrstore_validate_license', [$this, 'rate_limit_license_validation'], 1);
        
        // Enhanced security headers
        add_action('send_headers', [$this, 'add_enhanced_security_headers']);
        
        // Monitor file access patterns
        add_action('wp_ajax_vrstore_download', [$this, 'rate_limit_downloads'], 1);
        
        // Clean old rate limit data
        add_action('vrstore_security_cleanup', [$this, 'cleanup_old_data']);
        if (!wp_next_scheduled('vrstore_security_cleanup')) {
            wp_schedule_event(time(), 'daily', 'vrstore_security_cleanup');
        }
    }

    /**
     * Perform early security checks
     *
     * @since 1.0.0
     */
    public function early_security_checks(): void {
        $client_ip = $this->get_client_ip();
        
        // Check if IP is blocked
        if ($this->is_ip_blocked($client_ip)) {
            $this->block_request('IP blocked due to suspicious activity');
        }
        
        // Check for suspicious user agents
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        if ($this->is_suspicious_user_agent($user_agent)) {
            $this->log_security_event('suspicious_user_agent', 'warning', [
                'user_agent' => $user_agent,
                'ip' => $client_ip
            ]);
        }
    }

    /**
     * Filter incoming requests for malicious content
     *
     * @since 1.0.0
     */
    public function filter_requests(): void {
        $request_data = array_merge($_GET, $_POST, $_SERVER);
        
        foreach ($request_data as $key => $value) {
            if (is_string($value) && $this->contains_malicious_patterns($value)) {
                $this->log_security_event('malicious_request_detected', 'error', [
                    'key' => $key,
                    'value' => substr($value, 0, 100), // Log first 100 chars only
                    'ip' => $this->get_client_ip(),
                    'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? ''
                ]);
                
                // Temporarily block IP after multiple attempts
                $this->increment_threat_score($this->get_client_ip());
            }
        }
    }

    /**
     * Check if content contains malicious patterns
     *
     * @param string $content Content to check
     * @return bool True if malicious patterns found
     */
    private function contains_malicious_patterns(string $content): bool {
        foreach ($this->suspicious_patterns as $category => $patterns) {
            foreach ($patterns as $pattern) {
                if (preg_match($pattern, $content)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Rate limit API requests
     *
     * @param string $action Action being performed
     * @param string $identifier Unique identifier (IP, user ID, etc.)
     * @return bool True if within rate limit
     */
    public function check_rate_limit(string $action, string $identifier = ''): bool {
        if (empty($identifier)) {
            $identifier = $this->get_client_ip();
        }
        
        if (!isset($this->rate_limits[$action])) {
            return true; // No limit defined
        }
        
        $limit_config = $this->rate_limits[$action];
        $cache_key = "vrstore_rate_limit_{$action}_{$identifier}";
        
        $current_count = get_transient($cache_key) ?: 0;
        
        if ($current_count >= $limit_config['limit']) {
            $this->log_security_event('rate_limit_exceeded', 'warning', [
                'action' => $action,
                'identifier' => $identifier,
                'count' => $current_count,
                'limit' => $limit_config['limit']
            ]);
            return false;
        }
        
        set_transient($cache_key, $current_count + 1, $limit_config['window']);
        return true;
    }

    /**
     * Rate limit license validation requests
     */
    public function rate_limit_license_validation(): void {
        if (!$this->check_rate_limit('license_validate')) {
            wp_die(
                esc_html__('Rate limit exceeded. Please try again later.', 'vira-store'),
                esc_html__('Too Many Requests', 'vira-store'),
                ['response' => 429]
            );
        }
    }

    /**
     * Rate limit download requests
     */
    public function rate_limit_downloads(): void {
        if (!$this->check_rate_limit('file_downloads')) {
            wp_die(
                esc_html__('Download rate limit exceeded. Please try again later.', 'vira-store'),
                esc_html__('Too Many Requests', 'vira-store'),
                ['response' => 429]
            );
        }
    }

    /**
     * Add enhanced security headers
     */
    public function add_enhanced_security_headers(): void {
        if (headers_sent()) {
            return;
        }
        
        // Basic security headers
        header('X-XSS-Protection: 1; mode=block');
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: SAMEORIGIN');
        header('Referrer-Policy: strict-origin-when-cross-origin');
        
        // Enhanced CSP for better XSS protection
        $csp_policies = [
            "default-src 'self'",
            "script-src 'self' 'unsafe-inline' https://www.paypal.com https://www.paypalobjects.com https://www.sandbox.paypal.com https://pay.google.com https://js-agent.newrelic.com https://bam.nr-data.net https://gwk.gopayapi.com https://integration-gwk.gopayapi.com",
            "style-src 'self' 'unsafe-inline'",
            "img-src 'self' data: https:",
            "font-src 'self' data:",
            "connect-src 'self' https://api.paypal.com https://www.paypal.com https://www.sandbox.paypal.com",
            "frame-src 'self' https://www.paypal.com https://www.sandbox.paypal.com https://www.youtube.com https://www.youtube-nocookie.com",
            "worker-src 'self' blob:",
            "object-src 'none'",
            "base-uri 'self'",
            "form-action 'self'"
        ];
        
        header('Content-Security-Policy: ' . implode('; ', $csp_policies));
        
        // Permissions Policy (formerly Feature Policy)
        header('Permissions-Policy: geolocation=(), microphone=(), camera=()');
        
        // HSTS for HTTPS sites
        if (is_ssl()) {
            header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
        }
    }

    /**
     * Get client IP address securely
     *
     * @return string Client IP address
     */
    public function get_client_ip(): string {
        $ip_keys = [
            'HTTP_CF_CONNECTING_IP', // Cloudflare
            'HTTP_X_REAL_IP', // Nginx
            'HTTP_X_FORWARDED_FOR', // Load balancers
            'HTTP_CLIENT_IP',
            'REMOTE_ADDR'
        ];
        
        foreach ($ip_keys as $key) {
            if (!empty($_SERVER[$key])) {
                $ips = explode(',', $_SERVER[$key]);
                $ip = trim($ips[0]);
                
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                    return $ip;
                }
            }
        }
        
        return $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    }

    /**
     * Check if IP is blocked
     *
     * @param string $ip IP address
     * @return bool True if blocked
     */
    private function is_ip_blocked(string $ip): bool {
        return in_array($ip, $this->blocked_ips, true) || 
               get_transient("vrstore_blocked_ip_{$ip}") !== false;
    }

    /**
     * Block request and return 403
     *
     * @param string $reason Reason for blocking
     */
    private function block_request(string $reason = 'Access denied'): void {
        $this->log_security_event('request_blocked', 'error', [
            'reason' => $reason,
            'ip' => $this->get_client_ip(),
            'uri' => $_SERVER['REQUEST_URI'] ?? '',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? ''
        ]);
        
        wp_die(
            esc_html__('Access denied.', 'vira-store'),
            esc_html__('Security Error', 'vira-store'),
            ['response' => 403]
        );
    }

    /**
     * Check for suspicious user agents
     *
     * @param string $user_agent User agent string
     * @return bool True if suspicious
     */
    private function is_suspicious_user_agent(string $user_agent): bool {
        $suspicious_agents = [
            'curl',
            'wget',
            'python',
            'scanner',
            'bot',
            'crawl',
            'spider',
            'scraper'
        ];
        
        $user_agent_lower = strtolower($user_agent);
        
        foreach ($suspicious_agents as $agent) {
            if (strpos($user_agent_lower, $agent) !== false) {
                return true;
            }
        }
        
        return false;
    }

    /**
     * Increment threat score for IP
     *
     * @param string $ip IP address
     */
    private function increment_threat_score(string $ip): void {
        $score_key = "vrstore_threat_score_{$ip}";
        $current_score = get_transient($score_key) ?: 0;
        $new_score = $current_score + 1;
        
        set_transient($score_key, $new_score, HOUR_IN_SECONDS);
        
        // Block IP if threat score is too high
        if ($new_score >= 5) {
            set_transient("vrstore_blocked_ip_{$ip}", true, DAY_IN_SECONDS);
            $this->log_security_event('ip_auto_blocked', 'error', [
                'ip' => $ip,
                'threat_score' => $new_score
            ]);
        }
    }

    /**
     * Validate and sanitize input with comprehensive checks
     *
     * @param mixed $input Input data
     * @param string $type Expected type
     * @param array $options Additional validation options
     * @return mixed Sanitized input or false on failure
     */
    public function validate_input($input, string $type = 'text', array $options = []) {
        if (is_null($input)) {
            return $options['allow_null'] ?? false ? null : false;
        }
        
        switch ($type) {
            case 'email':
                $email = sanitize_email($input);
                if (!is_email($email)) {
                    return false;
                }
                // Check for disposable email domains if configured
                if ($options['check_disposable'] ?? false) {
                    if ($this->is_disposable_email($email)) {
                        return false;
                    }
                }
                return $email;
                
            case 'url':
                $url = esc_url_raw($input);
                if (!filter_var($url, FILTER_VALIDATE_URL)) {
                    return false;
                }
                // Check allowed domains if specified
                if (!empty($options['allowed_domains'])) {
                    $domain = parse_url($url, PHP_URL_HOST);
                    if (!in_array($domain, $options['allowed_domains'], true)) {
                        return false;
                    }
                }
                return $url;
                
            case 'domain':
                $domain = strtolower(trim($input));
                $domain = preg_replace('/^https?:\/\//', '', $domain);
                $domain = rtrim($domain, '/');
                
                if (!filter_var('http://' . $domain, FILTER_VALIDATE_URL)) {
                    return false;
                }
                return $domain;
                
            case 'license_key':
                $key = sanitize_text_field($input);
                // Validate license key format
                if (!preg_match('/^[A-Z0-9\-]+$/', $key)) {
                    return false;
                }
                if (strlen($key) < 10 || strlen($key) > 50) {
                    return false;
                }
                return $key;
                
            case 'int':
                $value = intval($input);
                if (isset($options['min']) && $value < $options['min']) {
                    return false;
                }
                if (isset($options['max']) && $value > $options['max']) {
                    return false;
                }
                return $value;
                
            case 'float':
                $value = floatval($input);
                if (isset($options['min']) && $value < $options['min']) {
                    return false;
                }
                if (isset($options['max']) && $value > $options['max']) {
                    return false;
                }
                return $value;
                
            case 'text':
            default:
                $text = sanitize_text_field($input);
                if (isset($options['max_length']) && strlen($text) > $options['max_length']) {
                    return false;
                }
                if ($this->contains_malicious_patterns($text)) {
                    return false;
                }
                return $text;
        }
    }

    /**
     * Check if email is from a disposable email provider
     *
     * @param string $email Email address
     * @return bool True if disposable
     */
    private function is_disposable_email(string $email): bool {
        $domain = substr(strrchr($email, "@"), 1);
        $disposable_domains = get_transient('vrstore_disposable_domains');
        
        if ($disposable_domains === false) {
            // Load common disposable domains
            $disposable_domains = [
                '10minutemail.com', 'tempmail.org', 'guerrillamail.com',
                'mailinator.com', 'throwaway.email', 'temp-mail.org'
            ];
            set_transient('vrstore_disposable_domains', $disposable_domains, WEEK_IN_SECONDS);
        }
        
        return in_array($domain, $disposable_domains, true);
    }

    /**
     * Load blocked IPs from database/cache
     */
    private function load_blocked_ips(): void {
        $this->blocked_ips = get_transient('vrstore_blocked_ips') ?: [];
        
        // Add manually blocked IPs from settings if any
        $settings = get_option('vrstore_settings', []);
        if (!empty($settings['blocked_ips'])) {
            $manual_blocks = array_map('trim', explode("\n", $settings['blocked_ips']));
            $this->blocked_ips = array_merge($this->blocked_ips, $manual_blocks);
        }
    }

    /**
     * Clean up old security data
     */
    public function cleanup_old_data(): void {
        global $wpdb;
        
        // Clean up old transients (WordPress doesn't always remove all custom transients)
        // First, delete expired timeout entries
        $table = $wpdb->options;
        $now = time();
        $timeout_like = "_transient_timeout_vrstore_%";

        $expired_timeouts = $wpdb->get_col( $wpdb->prepare(
            "SELECT option_name FROM $table WHERE option_name LIKE %s AND option_value < %d",
            $timeout_like,
            $now
        ) );

        if (!empty($expired_timeouts)) {
            foreach ($expired_timeouts as $opt_name) {
                $wpdb->delete($table, ['option_name' => $opt_name]);
            }
        }

        // Now clean up transient values that do not have a corresponding timeout entry
        $transient_like = '_transient_vrstore_%';
        $all_transients = $wpdb->get_col( $wpdb->prepare("SELECT option_name FROM $table WHERE option_name LIKE %s", $transient_like) );

        if (!empty($all_transients)) {
            // Build set of timeout option names that still exist
            $existing_timeouts = $wpdb->get_col( $wpdb->prepare("SELECT option_name FROM $table WHERE option_name LIKE %s", $timeout_like) );
            $keep = [];
            foreach ($existing_timeouts as $t) {
                // Convert timeout option name to transient name
                // timeout option names are like _transient_timeout_vrstore_xyz -> _transient_vrstore_xyz
                $keep[] = ' _transient_' . substr($t, 19);
            }

            foreach ($all_transients as $trans_opt) {
                // If this transient has no matching timeout, delete it
                if (!in_array($trans_opt, $keep, true)) {
                    $wpdb->delete($table, ['option_name' => $trans_opt]);
                }
            }
        }
        
        // Clean up old security logs
        $logs = get_option('vrstore_security_logs', []);
        if (count($logs) > 5000) {
            $logs = array_slice($logs, -2000); // Keep last 2000 entries
            update_option('vrstore_security_logs', $logs);
        }
    }

    /**
     * Log security events with enhanced information
     *
     * @param string $event Event type
     * @param string $level Severity level
     * @param array $context Additional context
     */
    public function log_security_event(string $event, string $level = 'info', array $context = []): void {
        // Always log critical events to error log
        if (in_array($level, ['error', 'critical']) || (defined('WP_DEBUG') && WP_DEBUG)) {
            // Enhanced security event would be logged to error log in debug mode
        }
        
        // Enhanced context
        $enhanced_context = array_merge($context, [
            'timestamp' => time(),
            'ip' => $this->get_client_ip(),
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'request_uri' => $_SERVER['REQUEST_URI'] ?? '',
            'user_id' => get_current_user_id() ?: 0,
            'session_id' => session_id() ?: wp_get_session_token()
        ]);
        
        $log_entry = [
            'event' => $event,
            'level' => $level,
            'context' => $enhanced_context,
            'time' => current_time('mysql')
        ];
        
        // Store in database if logging is enabled
        if (get_option('vrstore_enable_security_logging', 'yes') === 'yes') {
            $logs = get_option('vrstore_security_logs', []);
            $logs[] = $log_entry;
            
            // Limit memory usage
            if (count($logs) > 1000) {
                $logs = array_slice($logs, -800);
            }
            
            update_option('vrstore_security_logs', $logs);
        }
        
        // Send critical alerts if configured
        if (in_array($level, ['error', 'critical'])) {
            $this->send_security_alert($event, $enhanced_context);
        }
    }

    /**
     * Send security alert to administrators
     *
     * @param string $event Event type
     * @param array $context Event context
     */
    private function send_security_alert(string $event, array $context): void {
        $settings = get_option('vrstore_settings', []);
        
        if (empty($settings['security_alerts_email'])) {
            return;
        }
        
        $subject = sprintf('[%s] Security Alert: %s', get_bloginfo('name'), $event);
        $message = sprintf(
            "A security event has been detected on your website:\n\nEvent: %s\nIP Address: %s\nTime: %s\nUser Agent: %s\nRequest URI: %s\n\nFull Context:\n%s",
            $event,
            $context['ip'],
            $context['time'] ?? current_time('mysql'),
            $context['user_agent'],
            $context['request_uri'],
            print_r($context, true)
        );
        
        wp_mail($settings['security_alerts_email'], $subject, $message);
    }

    /**
     * Generate secure nonce with additional entropy
     *
     * @param string $action Action name
     * @return string Secure nonce
     */
    public function generate_secure_nonce(string $action): string {
        $additional_entropy = $this->get_client_ip() . $_SERVER['HTTP_USER_AGENT'] ?? '';
        return wp_create_nonce($action . $additional_entropy);
    }

    /**
     * Verify secure nonce
     *
     * @param string $nonce Nonce to verify
     * @param string $action Action name
     * @return bool True if valid
     */
    public function verify_secure_nonce(string $nonce, string $action): bool {
        $additional_entropy = $this->get_client_ip() . $_SERVER['HTTP_USER_AGENT'] ?? '';
        return wp_verify_nonce($nonce, $action . $additional_entropy);
    }
}
