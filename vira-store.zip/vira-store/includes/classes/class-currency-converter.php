<?php
/**
 * Currency Converter Class
 *
 * Handles currency conversion with IP-based detection and manual rate management
 *
 * @package Vira_Store
 * @since 1.0.1
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Currency Converter class
 */
class VRSTORE_Currency_Converter {
    
    /**
     * Singleton instance
     *
     * @var VRSTORE_Currency_Converter|null
     */
    private static ?VRSTORE_Currency_Converter $instance = null;

    /**
     * Supported currencies
     *
     * @var array
     */
    private array $supported_currencies = [
        'USD' => ['name' => 'US Dollar', 'symbol' => '$', 'code' => 'USD'],
        'EUR' => ['name' => 'Euro', 'symbol' => '€', 'code' => 'EUR'],
        'GBP' => ['name' => 'British Pound', 'symbol' => '£', 'code' => 'GBP'],
        'JPY' => ['name' => 'Japanese Yen', 'symbol' => '¥', 'code' => 'JPY'],
        'IDR' => ['name' => 'Indonesian Rupiah', 'symbol' => 'Rp', 'code' => 'IDR'],
        'CNY' => ['name' => 'Chinese Yuan', 'symbol' => '¥', 'code' => 'CNY'],
        'AUD' => ['name' => 'Australian Dollar', 'symbol' => 'A$', 'code' => 'AUD'],
        'BRL' => ['name' => 'Brazilian Real', 'symbol' => 'R$', 'code' => 'BRL'],
        'CAD' => ['name' => 'Canadian Dollar', 'symbol' => 'C$', 'code' => 'CAD'],
        'HKD' => ['name' => 'Hong Kong Dollar', 'symbol' => 'HK$', 'code' => 'HKD'],
        'INR' => ['name' => 'Indian Rupee', 'symbol' => '₹', 'code' => 'INR'],
        'MXN' => ['name' => 'Mexican Peso', 'symbol' => '$', 'code' => 'MXN'],
        'MYR' => ['name' => 'Malaysian Ringgit', 'symbol' => 'RM', 'code' => 'MYR'],
        'NZD' => ['name' => 'New Zealand Dollar', 'symbol' => 'NZ$', 'code' => 'NZD'],
        'PHP' => ['name' => 'Philippine Peso', 'symbol' => '₱', 'code' => 'PHP'],
        'THB' => ['name' => 'Thai Baht', 'symbol' => '฿', 'code' => 'THB'],
        'SGD' => ['name' => 'Singapore Dollar', 'symbol' => 'S$', 'code' => 'SGD'],
        'VND' => ['name' => 'Vietnamese Dong', 'symbol' => '₫', 'code' => 'VND'],
        'ZAR' => ['name' => 'South African Rand', 'symbol' => 'R', 'code' => 'ZAR']
    ];

    /**
     * Country to currency mapping
     *
     * @var array
     */
    private array $country_currency_map = [
        'US' => 'USD', 'United States' => 'USD',
        'GB' => 'GBP', 'United Kingdom' => 'GBP',
        'DE' => 'EUR', 'FR' => 'EUR', 'IT' => 'EUR', 'ES' => 'EUR', 'NL' => 'EUR',
        'AT' => 'EUR', 'BE' => 'EUR', 'FI' => 'EUR', 'IE' => 'EUR', 'PT' => 'EUR',
        'JP' => 'JPY', 'Japan' => 'JPY',
        'ID' => 'IDR', 'Indonesia' => 'IDR',
        'CN' => 'CNY', 'China' => 'CNY',
        'AU' => 'AUD', 'Australia' => 'AUD',
        'BR' => 'BRL', 'Brazil' => 'BRL',
        'CA' => 'CAD', 'Canada' => 'CAD',
        'HK' => 'HKD', 'Hong Kong' => 'HKD',
        'IN' => 'INR', 'India' => 'INR',
        'MX' => 'MXN', 'Mexico' => 'MXN',
        'MY' => 'MYR', 'Malaysia' => 'MYR',
        'NZ' => 'NZD', 'New Zealand' => 'NZD',
        'PH' => 'PHP', 'Philippines' => 'PHP',
        'TH' => 'THB', 'Thailand' => 'THB',
        'SG' => 'SGD', 'Singapore' => 'SGD',
        'VN' => 'VND', 'Vietnam' => 'VND',
        'ZA' => 'ZAR', 'South Africa' => 'ZAR'
    ];

    /**
     * Get singleton instance
     *
     * @return VRSTORE_Currency_Converter
     */
    public static function get_instance(): VRSTORE_Currency_Converter {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        add_action('init', [$this, 'maybe_handle_currency_switch'], 0);
        add_action('init', [$this, 'init']);
    }

    /**
     * Initialize the currency converter
     *
     * @return void
     */
    public function init(): void {
        // Initialize hooks
        add_action('wp_ajax_vrstore_update_currency_rates', [$this, 'ajax_update_currency_rates']);
        add_action('wp_ajax_vrstore_fetch_currency_rates', [$this, 'ajax_fetch_currency_rates']);
        add_action('wp_ajax_vrstore_get_user_currency', [$this, 'ajax_get_user_currency']);
        add_action('wp_ajax_nopriv_vrstore_get_user_currency', [$this, 'ajax_get_user_currency']);
        add_action('wp_ajax_vrstore_switch_currency', [$this, 'ajax_switch_currency']);
        add_action('wp_ajax_nopriv_vrstore_switch_currency', [$this, 'ajax_switch_currency']);
    }

    /**
     * Get supported currencies
     *
     * @return array
     */
    public function get_supported_currencies(): array {
        return $this->supported_currencies;
    }

    /**
     * Get base currency from settings
     *
     * @return string
     */
    public function get_base_currency(): string {
        $settings = VRSTORE_Settings::get_instance();
        return $settings->get_setting('currency', 'USD');
    }

    /**
     * Get user's currency based on IP detection
     *
     * @param bool $exclude_admin Whether to exclude admin users from IP detection
     * @return string
     */
    public function get_user_currency(bool $exclude_admin = true): string {
        // Check if currency conversion is enabled
        $settings = VRSTORE_Settings::get_instance();
        $conversion_enabled = $settings->get_setting('enable_currency_conversion', '');
        if ($conversion_enabled !== 'on' && $conversion_enabled !== 'yes' && $conversion_enabled !== true) {
            return $this->get_base_currency();
        }

        // Exclude admin users from IP detection for consistency in reports
        if ($exclude_admin && current_user_can('manage_options')) {
            return $this->get_base_currency();
        }

        // Check if user has manually set currency in session
        $session_currency = $this->get_session_currency();
        if ($session_currency && isset($this->supported_currencies[$session_currency])) {
            return $session_currency;
        }

        // Detect currency based on IP
        $detected_currency = $this->detect_currency_by_ip();
        
        // Store in session for future requests
        $this->set_session_currency($detected_currency);
        
        return $detected_currency;
    }

    /**
     * Detect currency based on user's IP address
     *
     * @return string
     */
    private function detect_currency_by_ip(): string {
        $user_ip = $this->get_user_ip();
        
        if (empty($user_ip) || $user_ip === '127.0.0.1' || $user_ip === '::1') {
            return $this->get_base_currency();
        }

        // Use cached result if available
        $cache_key = 'vrstore_ip_currency_' . md5($user_ip);
        $cached_currency = get_transient($cache_key);
        
        if ($cached_currency && isset($this->supported_currencies[$cached_currency])) {
            return $cached_currency;
        }

        // Try to get country from IP using free service
        $country_code = $this->get_country_from_ip($user_ip);
        
        if ($country_code && isset($this->country_currency_map[$country_code])) {
            $currency = $this->country_currency_map[$country_code];
            
            // Cache for 24 hours
            set_transient($cache_key, $currency, DAY_IN_SECONDS);
            
            return $currency;
        }

        return $this->get_base_currency();
    }

    /**
     * Get user's IP address
     *
     * @return string
     */
    private function get_user_ip(): string {
        $ip_keys = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 
                   'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR'];
        
        foreach ($ip_keys as $key) {
            if (array_key_exists($key, $_SERVER) && !empty($_SERVER[$key])) {
                $ip = sanitize_text_field($_SERVER[$key]);
                
                // Handle comma-separated IPs (from proxies)
                if (strpos($ip, ',') !== false) {
                    $ip = trim(explode(',', $ip)[0]);
                }
                
                // Validate IP
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                    return $ip;
                }
            }
        }
        
        return '';
    }

    /**
     * Get country code from IP address
     *
     * @param string $ip
     * @return string|null
     */
    private function get_country_from_ip(string $ip): ?string {
        // Use ip-api.com (free service with 1000 requests per month)
        $api_url = "http://ip-api.com/json/{$ip}?fields=countryCode";
        
        $response = wp_remote_get($api_url, [
            'timeout' => 5,
            'user-agent' => 'Vira Store Plugin'
        ]);
        
        if (is_wp_error($response)) {
            return null;
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (isset($data['countryCode']) && !empty($data['countryCode'])) {
            return strtoupper($data['countryCode']);
        }
        
        return null;
    }

    /**
     * Get currency from session
     *
     * @return string|null
     */
    private function get_session_currency(): ?string {
        // Prefer session manager, then fall back to cookie
        $session_manager = class_exists('VRSTORE_Session_Manager') ? VRSTORE_Session_Manager::get_instance_if_needed() : null;

        if ($session_manager && session_status() === PHP_SESSION_ACTIVE) {
            $val = $session_manager->get_session_data('vrstore_user_currency');
            if (!empty($val)) {
                $val = strtoupper(sanitize_text_field($val));
                return isset($this->supported_currencies[$val]) ? $val : null;
            }
        } elseif (session_status() === PHP_SESSION_ACTIVE && isset($_SESSION['vrstore_user_currency'])) {
            $val = strtoupper(sanitize_text_field($_SESSION['vrstore_user_currency']));
            return isset($this->supported_currencies[$val]) ? $val : null;
        }

        // Cookie fallback for caching/CDN awareness
        if (!empty($_COOKIE['vrstore_user_currency'])) {
            $cookie_val = strtoupper(sanitize_text_field(wp_unslash($_COOKIE['vrstore_user_currency'])));
            if (isset($this->supported_currencies[$cookie_val])) {
                return $cookie_val;
            }
        }

        return null;
    }

    /**
     * Set currency in session
     *
     * @param string $currency
     * @return void
     */
    private function set_session_currency(string $currency): void {
        $supported = $this->get_supported_currencies();
        if (!isset($supported[$currency])) {
            return;
        }

        // Prefer centralized session manager
        $session_manager = class_exists('VRSTORE_Session_Manager') ? VRSTORE_Session_Manager::get_instance_if_needed() : null;
        if ($session_manager) {
            $session_manager->start_session();
            $session_manager->set_session_data('vrstore_user_currency', $currency);
        } else {
            // Fallback: only touch native session in safe contexts
            if (!is_admin() && !wp_doing_ajax()) {
                if (session_status() === PHP_SESSION_NONE && !headers_sent()) {
                    @session_start();
                }
                if (session_status() === PHP_SESSION_ACTIVE) {
                    $_SESSION['vrstore_user_currency'] = $currency;
                }
            }
        }

        // Set a cookie for caching/CDN and for fallback when session not available
        if (!headers_sent()) {
            $cookie_opts = [
                'expires'  => time() + (DAY_IN_SECONDS * 30),
                'path'     => defined('COOKIEPATH') && COOKIEPATH ? COOKIEPATH : '/',
                'domain'   => defined('COOKIE_DOMAIN') ? COOKIE_DOMAIN : '',
                'secure'   => is_ssl(),
                'httponly' => true,
                'samesite' => 'Lax',
            ];
            setcookie('vrstore_user_currency', $currency, $cookie_opts);
        }
    }

    /**
     * Get currency exchange rate
     *
     * @param string $from_currency
     * @param string $to_currency
     * @return float
     */
    public function get_exchange_rate(string $from_currency, string $to_currency): float {
        if ($from_currency === $to_currency) {
            return 1.0;
        }

        $rates = get_option('vrstore_currency_rates', []);
        
        // If converting from base currency (USD)
        if ($from_currency === $this->get_base_currency()) {
            return (float) ($rates[$to_currency] ?? 1.0);
        }
        
        // If converting to base currency (USD)
        if ($to_currency === $this->get_base_currency()) {
            $rate = (float) ($rates[$from_currency] ?? 1.0);
            return $rate > 0 ? (1.0 / $rate) : 1.0;
        }
        
        // Converting between two non-base currencies
        $from_rate = (float) ($rates[$from_currency] ?? 1.0);
        $to_rate = (float) ($rates[$to_currency] ?? 1.0);
        
        if ($from_rate > 0) {
            return $to_rate / $from_rate;
        }
        
        return 1.0;
    }

    /**
     * Convert amount between currencies
     *
     * @param float $amount
     * @param string $from_currency
     * @param string $to_currency
     * @return float
     */
    public function convert_amount(float $amount, string $from_currency, string $to_currency): float {
        // Check if currency conversion is enabled
        $settings = VRSTORE_Settings::get_instance();
        $conversion_enabled = $settings->get_setting('enable_currency_conversion', '');
        if ($conversion_enabled !== 'on' && $conversion_enabled !== 'yes' && $conversion_enabled !== true) {
            return $amount; // Return original amount if conversion is disabled
        }

        if ($from_currency === $to_currency) {
            return $amount;
        }

        $rate = $this->get_exchange_rate($from_currency, $to_currency);
        return round($amount * $rate, 2);
    }

    /**
     * Convert price to user's currency (wrapper for convert_amount)
     *
     * @param float $amount
     * @param string $to_currency
     * @return float
     */
    public function convert_price(float $amount, string $to_currency = ''): float {
        if (empty($to_currency)) {
            $to_currency = $this->get_user_currency();
        }
        
        $base_currency = $this->get_base_currency();
        return $this->convert_amount($amount, $base_currency, $to_currency);
    }

    /**
     * Format currency amount (converts from base currency first)
     *
     * @param float $amount Base currency amount
     * @param string $currency Target currency
     * @param bool $use_km_formatting Whether to use K/M formatting for large numbers
     * @return string
     */
    public function format_price(float $amount, string $currency = '', bool $use_km_formatting = false): string {
        // Determine target currency (fallback to user currency if not provided)
        if ($currency === '') {
            $currency = $this->get_user_currency();
        }
    
        // Convert from base to target currency
        $converted = $this->convert_price($amount, $currency);
    
        // Format with currency symbol and proper decimals
        return $this->format_currency($converted, $currency, $use_km_formatting);
    }
    
    /**
     * Format already converted currency amount (no conversion)
     *
     * @param float $amount Already converted amount
     * @param string $currency Currency code
     * @param bool $use_km_formatting Whether to use K/M formatting for large numbers
     * @return string
     */
    public function format_converted_price(float $amount, string $currency = '', bool $use_km_formatting = false): string {
        // Determine currency (fallback to user currency if not provided)
        if ($currency === '') {
            $currency = $this->get_user_currency();
        }
    
        // Format without conversion (amount is already converted)
        return $this->format_currency($amount, $currency, $use_km_formatting);
    }

    /**
     * Format currency amount with symbol and decimals
     *
     * @param float $amount
     * @param string $currency
     * @param bool $use_km_formatting Whether to use K/M formatting for large numbers
     * @return string
     */
    public function format_currency(float $amount, string $currency, bool $use_km_formatting = false): string {
        $currency_info = $this->supported_currencies[$currency] ?? $this->supported_currencies['USD'];
        $symbol = $currency_info['symbol'];
        
        // Apply K/M formatting for large numbers if requested
        if ($use_km_formatting) {
            $formatted_number = $this->format_large_number($amount, $currency);
        } else {
            // Format based on currency
            switch ($currency) {
                case 'JPY':
                case 'VND':
                case 'IDR':
                    // No decimal places for these currencies
                    $formatted_number = number_format($amount, 0);
                    break;
                default:
                    $formatted_number = number_format($amount, 2);
                    break;
            }
        }
        
        return $symbol . $formatted_number;
    }
    
    /**
     * Format large numbers with K/M suffixes
     *
     * @param float $amount
     * @param string $currency
     * @return string
     */
    private function format_large_number(float $amount, string $currency): string {
        // Determine if currency should use decimals
        $use_decimals = !in_array($currency, ['JPY', 'VND', 'IDR']);
        
        if ($amount >= 1000000) {
            $formatted = $amount / 1000000;
            $suffix = 'M';
        } elseif ($amount >= 1000) {
            $formatted = $amount / 1000;
            $suffix = 'K';
        } else {
            // For amounts less than 1000, use regular formatting
            return $use_decimals ? number_format($amount, 2) : number_format($amount, 0);
        }
        
        // Format the reduced number
        if ($use_decimals) {
            // For currencies with decimals, show 1 decimal place for K/M
            $formatted_str = number_format($formatted, 1);
            // Remove .0 if it's a whole number
            if (substr($formatted_str, -2) === '.0') {
                $formatted_str = substr($formatted_str, 0, -2);
            }
        } else {
            // For currencies without decimals, round to whole numbers
            $formatted_str = number_format(round($formatted), 0);
        }
        
        return $formatted_str . $suffix;
    }

    /**
     * Update currency rates (admin only)
     *
     * @param array $rates
     * @return bool
     */
    public function update_currency_rates(array $rates): bool {
        if (!current_user_can('manage_options')) {
            return false;
        }

        $sanitized_rates = [];
        foreach ($rates as $currency => $rate) {
            if (isset($this->supported_currencies[$currency])) {
                $sanitized_rates[$currency] = (float) $rate;
            }
        }

        return update_option('vrstore_currency_rates', $sanitized_rates);
    }

    /**
     * Get all currency rates
     *
     * @return array
     */
    public function get_currency_rates(): array {
        return get_option('vrstore_currency_rates', []);
    }

    /**
     * AJAX handler for updating currency rates
     *
     * @return void
     */
    public function ajax_update_currency_rates(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_currency_nonce')) {
            wp_die(__('Security check failed', 'vira-store'));
        }

        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_die(__('Insufficient permissions', 'vira-store'));
        }

        $rates = $_POST['rates'] ?? [];
        
        if ($this->update_currency_rates($rates)) {
            wp_send_json_success(__('Currency rates updated successfully', 'vira-store'));
        } else {
            wp_send_json_error(__('Failed to update currency rates', 'vira-store'));
        }
    }

    /**
     * AJAX handler for fetching currency rates from external API
     *
     * @return void
     */
    public function ajax_fetch_currency_rates(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_admin_nonce')) {
            wp_send_json_error(__('Security check failed', 'vira-store'));
        }

        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Insufficient permissions', 'vira-store'));
        }

        // Fetch rates from external API (using exchangerate-api.com as example)
        $api_url = 'https://api.exchangerate-api.com/v4/latest/USD';
        $response = wp_remote_get($api_url, [
            'timeout' => 30,
            'headers' => [
                'User-Agent' => 'Vira Store Plugin'
            ]
        ]);

        if (is_wp_error($response)) {
            wp_send_json_error(__('Failed to fetch currency rates from API', 'vira-store'));
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (!$data || !isset($data['rates'])) {
            wp_send_json_error(__('Invalid response from currency API', 'vira-store'));
        }

        // Filter rates to only include supported currencies
        $supported_rates = [];
        foreach ($this->supported_currencies as $currency => $info) {
            if (isset($data['rates'][$currency])) {
                $supported_rates[$currency] = $data['rates'][$currency];
            }
        }

        wp_send_json_success([
            'rates' => $supported_rates,
            'message' => __('Currency rates fetched successfully', 'vira-store')
        ]);
    }

    /**
     * AJAX handler for getting user currency
     *
     * @return void
     */
    public function ajax_get_user_currency(): void {
        $currency = $this->get_user_currency(false); // Don't exclude admin for frontend requests
        $currency_info = $this->supported_currencies[$currency];
        
        wp_send_json_success([
            'currency' => $currency,
            'symbol' => $currency_info['symbol'],
            'name' => $currency_info['name']
        ]);
    }
    
    /**
     * AJAX handler for switching currency
     *
     * @return void
     */
    public function ajax_switch_currency(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_frontend_nonce')) {
            wp_send_json_error(__('Security check failed', 'vira-store'));
        }
        
        $new_currency = sanitize_text_field($_POST['currency'] ?? '');
        
        // Validate currency
        if (!isset($this->supported_currencies[$new_currency])) {
            wp_send_json_error(__('Invalid currency', 'vira-store'));
        }
        
        // Set the currency in session
        $this->set_session_currency($new_currency);
        
        // Get currency info and rates
        $currency_info = $this->supported_currencies[$new_currency];
        $rates = $this->get_currency_rates();
        
        wp_send_json_success([
            'currency' => $new_currency,
            'symbol' => $currency_info['symbol'],
            'name' => $currency_info['name'],
            'rates' => $rates
        ]);
    }
    /**
     * Handle currency switch via request parameter (?vrstore_currency=CODE)
     * Accepts GET or POST. Validates and persists to session (and cookie fallback).
     */
    public function maybe_handle_currency_switch(): void {
        // Quick exit if disabled
        $settings = VRSTORE_Settings::get_instance();
        $conversion_enabled = $settings->get_setting('enable_currency_conversion', '');
        if ($conversion_enabled !== 'on' && $conversion_enabled !== 'yes' && $conversion_enabled !== true) {
            return;
        }

        // Read from GET first, then POST
        $raw = null;
        if (isset($_GET['vrstore_currency'])) {
            $raw = $_GET['vrstore_currency'];
        } elseif (isset($_POST['vrstore_currency'])) {
            $raw = $_POST['vrstore_currency'];
        }
        if ($raw === null) {
            return;
        }

        $currency = strtoupper(sanitize_text_field(wp_unslash($raw)));
        $supported = $this->get_supported_currencies();
        if (!isset($supported[$currency])) {
            return; // ignore invalid currency
        }

        // Light CSRF mitigation: allow GET from same host or presence of nonce; for POST require nonce
        $referer_ok = false;
        if (!empty($_SERVER['HTTP_HOST']) && !empty($_SERVER['HTTP_REFERER'])) {
            $ref = wp_parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST);
            $host = $_SERVER['HTTP_HOST'];
            if (!empty($ref) && strcasecmp((string) $ref, (string) $host) === 0) {
                $referer_ok = true;
            }
        }
        $nonce_ok = false;
        if (isset($_REQUEST['_vrstore_currency_nonce'])) {
            $nonce_ok = (bool) wp_verify_nonce(sanitize_text_field(wp_unslash($_REQUEST['_vrstore_currency_nonce'])), 'vrstore_currency_switch');
        }
        if (isset($_POST['vrstore_currency']) && !$nonce_ok) {
            return;
        }
        if (isset($_GET['vrstore_currency']) && !$referer_ok && !$nonce_ok) {
            if (is_admin()) {
                return;
            }
        }

        // Persist selection via session/cookie
        $this->set_session_currency($currency);
    }

    /**
     * Public wrapper to set currency in session
     */
    public function set_session_currency_public(string $currency): void {
        $supported = $this->get_supported_currencies();
        if (!isset($supported[$currency])) {
            return;
        }
        $this->set_session_currency($currency);
    }
}

// Initialize the currency converter
VRSTORE_Currency_Converter::get_instance();