<?php
/**
 * Login Attempts Handler Class
 *
 * @package Vira_Store
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * VRSTORE_Login_Attempts Class
 *
 * This class handles login attempt limiting and brute force protection.
 *
 * @since 1.0.0
 */
class VRSTORE_Login_Attempts {

    /**
     * Instance of this class.
     *
     * @since 1.0.0
     * @var object
     */
    protected static $instance = null;

    /**
     * Settings instance.
     *
     * @since 1.0.0
     * @var VRSTORE_Settings
     */
    private $settings;

    /**
     * Database table name for login attempts.
     *
     * @since 1.0.0
     * @var string
     */
    private $table_name;

    /**
     * Return an instance of this class.
     *
     * @since 1.0.0
     * @return object A single instance of this class.
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Constructor.
     *
     * @since 1.0.0
     */
    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'vrstore_login_attempts';
        $this->settings = VRSTORE_Settings::get_instance();
        
        // Create table if needed
        $this->maybe_create_table();
        
        // Hook into WordPress login actions
        add_action( 'wp_login_failed', array( $this, 'record_failed_login' ) );
        add_action( 'wp_login', array( $this, 'clear_user_attempts' ), 10, 2 );
        
        // Clean up old attempts daily
        add_action( 'wp_scheduled_delete', array( $this, 'cleanup_old_attempts' ) );
    }

    /**
     * Create login attempts table if it doesn't exist.
     *
     * @since 1.0.0
     * @return void
     */
    private function maybe_create_table() {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS {$this->table_name} (
            id int(11) NOT NULL AUTO_INCREMENT,
            ip_address varchar(45) NOT NULL,
            username varchar(255) NOT NULL,
            email varchar(255) NOT NULL,
            attempt_time datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            user_agent varchar(500) DEFAULT NULL,
            PRIMARY KEY (id),
            KEY ip_address (ip_address),
            KEY username (username),
            KEY email (email),
            KEY attempt_time (attempt_time)
        ) $charset_collate;";

        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta( $sql );
    }

    /**
     * Check if login attempts should be limited for the current request.
     *
     * @since 1.0.0
     * @param string $username Username or email attempting to login.
     * @return array Array with 'allowed' boolean and 'message' string.
     */
    public function is_login_allowed( $username ) {
        // Check if feature is enabled
        if ( $this->settings->get_setting( 'enable_login_attempts_limit', 'on' ) !== 'on' ) {
            return array( 'allowed' => true, 'message' => '' );
        }

        $tracking_method = $this->settings->get_setting( 'login_attempts_tracking_method', 'both' );
        $max_attempts = intval( $this->settings->get_setting( 'max_login_attempts', 5 ) );
        $lockout_duration = intval( $this->settings->get_setting( 'login_lockout_duration', 15 ) );

        $ip_address = $this->get_client_ip();
        $current_time = current_time( 'mysql' );
        $lockout_time = date( 'Y-m-d H:i:s', strtotime( $current_time ) - ( $lockout_duration * 60 ) );

        global $wpdb;

        $where_conditions = array();
        $where_values = array();

        // Build WHERE conditions based on tracking method
        switch ( $tracking_method ) {
            case 'ip':
                $where_conditions[] = 'ip_address = %s';
                $where_values[] = $ip_address;
                break;
            
            case 'email':
                // For email/username tracking, we need to handle both username and email
                $user = get_user_by( 'login', $username );
                if ( ! $user ) {
                    $user = get_user_by( 'email', $username );
                }
                
                if ( $user ) {
                    $where_conditions[] = '(username = %s OR email = %s)';
                    $where_values[] = $user->user_login;
                    $where_values[] = $user->user_email;
                } else {
                    $where_conditions[] = '(username = %s OR email = %s)';
                    $where_values[] = $username;
                    $where_values[] = $username;
                }
                break;
            
            case 'both':
            default:
                // For both tracking, count attempts for either IP or username/email
                $user = get_user_by( 'login', $username );
                if ( ! $user ) {
                    $user = get_user_by( 'email', $username );
                }
                
                if ( $user ) {
                    $where_conditions[] = '(ip_address = %s OR username = %s OR email = %s)';
                    $where_values[] = $ip_address;
                    $where_values[] = $user->user_login;
                    $where_values[] = $user->user_email;
                } else {
                    $where_conditions[] = '(ip_address = %s OR username = %s OR email = %s)';
                    $where_values[] = $ip_address;
                    $where_values[] = $username;
                    $where_values[] = $username;
                }
                break;
        }

        // Count recent attempts within lockout period
        $where_values[] = $lockout_time;
        
        $query = "SELECT COUNT(*) FROM {$this->table_name} WHERE " . implode( ' AND ', $where_conditions ) . " AND attempt_time > %s";
        $attempt_count = $wpdb->get_var( $wpdb->prepare( $query, $where_values ) );

        if ( $attempt_count >= $max_attempts ) {
            // Check when the lockout period will end
            $conditions_for_latest = $where_conditions; // Use the same conditions as counting query
            $values_for_latest = array_slice( $where_values, 0, -1 ); // Remove the time condition value
            
            if ( ! empty( $conditions_for_latest ) ) {
                $latest_attempt_query = "SELECT attempt_time FROM {$this->table_name} WHERE " . implode( ' AND ', $conditions_for_latest ) . " ORDER BY attempt_time DESC LIMIT 1";
                $latest_attempt = $wpdb->get_var( $wpdb->prepare( $latest_attempt_query, $values_for_latest ) );
            } else {
                $latest_attempt_query = "SELECT attempt_time FROM {$this->table_name} ORDER BY attempt_time DESC LIMIT 1";
                $latest_attempt = $wpdb->get_var( $latest_attempt_query );
            }
            
            if ( $latest_attempt ) {
                $lockout_end = strtotime( $latest_attempt ) + ( $lockout_duration * 60 );
                $remaining_time = max( 0, $lockout_end - time() );
                $remaining_minutes = ceil( $remaining_time / 60 );
                
                $message = $this->settings->get_setting( 
                    'login_lockout_message', 
                    'Too many failed login attempts. Your account has been locked for {duration} minutes. Please try again later.'
                );
                
                $message = str_replace( 
                    array( '{attempts}', '{duration}', '{remaining_time}' ),
                    array( $max_attempts, $lockout_duration, $remaining_minutes ),
                    $message
                );
                
                // Send notification if enabled
                if ( $this->settings->get_setting( 'enable_login_attempt_notifications', 'on' ) === 'on' ) {
                    $this->send_lockout_notification( $username, $ip_address, $attempt_count );
                }
                
                return array( 'allowed' => false, 'message' => $message );
            }
        }

        return array( 'allowed' => true, 'message' => '' );
    }

    /**
     * Record a failed login attempt.
     *
     * @since 1.0.0
     * @param string $username Username or email that failed to login.
     * @return void
     */
    public function record_failed_login_attempt( $username ) {
        // Check if feature is enabled
        if ( $this->settings->get_setting( 'enable_login_attempts_limit', 'on' ) !== 'on' ) {
            return;
        }

        global $wpdb;

        $ip_address = $this->get_client_ip();
        $user_agent = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( $_SERVER['HTTP_USER_AGENT'] ) : '';
        
        // Get user email if possible
        $email = $username;
        $user = get_user_by( 'login', $username );
        if ( ! $user ) {
            $user = get_user_by( 'email', $username );
        }
        if ( $user ) {
            $username = $user->user_login;
            $email = $user->user_email;
        }

        $wpdb->insert(
            $this->table_name,
            array(
                'ip_address' => $ip_address,
                'username' => $username,
                'email' => $email,
                'attempt_time' => current_time( 'mysql' ),
                'user_agent' => $user_agent
            ),
            array( '%s', '%s', '%s', '%s', '%s' )
        );
    }

    /**
     * WordPress hook handler for failed logins.
     *
     * @since 1.0.0
     * @param string $username Username that failed to login.
     * @return void
     */
    public function record_failed_login( $username ) {
        $this->record_failed_login_attempt( $username );
    }

    /**
     * Clear login attempts for a user after successful login.
     *
     * @since 1.0.0
     * @param string $user_login Username.
     * @param WP_User $user User object.
     * @return void
     */
    public function clear_user_attempts( $user_login, $user ) {
        // Check if feature is enabled
        if ( $this->settings->get_setting( 'enable_login_attempts_limit', 'on' ) !== 'on' ) {
            return;
        }

        global $wpdb;

        $tracking_method = $this->settings->get_setting( 'login_attempts_tracking_method', 'both' );
        $ip_address = $this->get_client_ip();

        $where_conditions = array();
        $where_values = array();

        // Clear attempts based on tracking method
        switch ( $tracking_method ) {
            case 'ip':
                $where_conditions[] = 'ip_address = %s';
                $where_values[] = $ip_address;
                break;
            
            case 'email':
                $where_conditions[] = '(username = %s OR email = %s)';
                $where_values[] = $user->user_login;
                $where_values[] = $user->user_email;
                break;
            
            case 'both':
            default:
                $where_conditions[] = '(ip_address = %s OR username = %s OR email = %s)';
                $where_values[] = $ip_address;
                $where_values[] = $user->user_login;
                $where_values[] = $user->user_email;
                break;
        }

        $query = "DELETE FROM {$this->table_name} WHERE " . implode( ' AND ', $where_conditions );
        $wpdb->query( $wpdb->prepare( $query, $where_values ) );
    }

    /**
     * Clean up old login attempts (older than 24 hours).
     *
     * @since 1.0.0
     * @return void
     */
    public function cleanup_old_attempts() {
        global $wpdb;

        $cleanup_time = date( 'Y-m-d H:i:s', strtotime( '-24 hours' ) );
        
        $wpdb->query( 
            $wpdb->prepare( 
                "DELETE FROM {$this->table_name} WHERE attempt_time < %s", 
                $cleanup_time 
            ) 
        );
    }

    /**
     * Send lockout notification to admin.
     *
     * @since 1.0.0
     * @param string $username Username that was locked out.
     * @param string $ip_address IP address of the attempt.
     * @param int $attempt_count Number of attempts made.
     * @return void
     */
    private function send_lockout_notification( $username, $ip_address, $attempt_count ) {
        $admin_email = get_option( 'admin_email' );
        $site_name = get_option( 'blogname' );
        $lockout_duration = intval( $this->settings->get_setting( 'login_lockout_duration', 15 ) );
        
        $subject = sprintf( 
            '[%s] Account Locked Due to Failed Login Attempts', 
            $site_name 
        );
        
        $message = sprintf(
            "A user account has been locked due to too many failed login attempts.\n\n" .
            "Details:\n" .
            "Username: %s\n" .
            "IP Address: %s\n" .
            "Failed Attempts: %d\n" .
            "Lockout Duration: %d minutes\n" .
            "Time: %s\n\n" .
            "This is an automated security notification from your ViraStore plugin.\n" .
            "If you believe this is a legitimate user having trouble logging in, you can reset their password or contact them directly.",
            $username,
            $ip_address,
            $attempt_count,
            $lockout_duration,
            current_time( 'mysql' )
        );
        
        wp_mail( $admin_email, $subject, $message );
    }

    /**
     * Get client IP address.
     *
     * @since 1.0.0
     * @return string Client IP address.
     */
    private function get_client_ip() {
        $ip_keys = array( 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_CLIENT_IP', 'REMOTE_ADDR' );
        
        foreach ( $ip_keys as $key ) {
            if ( array_key_exists( $key, $_SERVER ) === true ) {
                $ip = sanitize_text_field( $_SERVER[ $key ] );
                
                if ( strpos( $ip, ',' ) !== false ) {
                    $ip = explode( ',', $ip )[0];
                }
                
                $ip = trim( $ip );
                
                if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) !== false ) {
                    return $ip;
                }
            }
        }
        
        // Fallback to REMOTE_ADDR
        return isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( $_SERVER['REMOTE_ADDR'] ) : '127.0.0.1';
    }

    /**
     * Get login attempt statistics.
     *
     * @since 1.0.0
     * @param string $period Period to check ('24h', '7d', '30d').
     * @return array Statistics array.
     */
    public function get_attempt_statistics( $period = '24h' ) {
        global $wpdb;

        switch ( $period ) {
            case '7d':
                $time_limit = date( 'Y-m-d H:i:s', strtotime( '-7 days' ) );
                break;
            case '30d':
                $time_limit = date( 'Y-m-d H:i:s', strtotime( '-30 days' ) );
                break;
            case '24h':
            default:
                $time_limit = date( 'Y-m-d H:i:s', strtotime( '-24 hours' ) );
                break;
        }

        $total_attempts = $wpdb->get_var( 
            $wpdb->prepare( 
                "SELECT COUNT(*) FROM {$this->table_name} WHERE attempt_time > %s", 
                $time_limit 
            ) 
        );

        $unique_ips = $wpdb->get_var( 
            $wpdb->prepare( 
                "SELECT COUNT(DISTINCT ip_address) FROM {$this->table_name} WHERE attempt_time > %s", 
                $time_limit 
            ) 
        );

        $top_ips = $wpdb->get_results( 
            $wpdb->prepare( 
                "SELECT ip_address, COUNT(*) as attempt_count FROM {$this->table_name} WHERE attempt_time > %s GROUP BY ip_address ORDER BY attempt_count DESC LIMIT 10", 
                $time_limit 
            ) 
        );

        return array(
            'total_attempts' => intval( $total_attempts ),
            'unique_ips' => intval( $unique_ips ),
            'top_ips' => $top_ips,
            'period' => $period
        );
    }
}