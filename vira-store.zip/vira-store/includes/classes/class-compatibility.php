<?php
/**
 * Theme and Plugin Compatibility Handler
 *
 * Handles compatibility with popular WordPress themes and plugins
 * to ensure optimal performance and functionality.
 *
 * @package ViraStore
 * @since 1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * VRSTORE_Compatibility Class
 *
 * Manages theme and plugin compatibility for ViraStore
 */
class VRSTORE_Compatibility {

    /**
     * Instance of this class
     *
     * @var VRSTORE_Compatibility
     */
    private static $instance = null;

    /**
     * Current active theme
     *
     * @var string
     */
    private $active_theme;

    /**
     * Active plugins list
     *
     * @var array
     */
    private $active_plugins;

    /**
     * Compatibility mode enabled
     *
     * @var bool
     */
    private $compatibility_mode;

    /**
     * Supported themes list
     *
     * @var array
     */
    private $supported_themes = [
        'hello-elementor' => 'Hello Elementor',
        'twentytwentyfour' => 'Twenty Twenty-Four',
        'twentytwentythree' => 'Twenty Twenty-Three',
        'twentytwentytwo' => 'Twenty Twenty-Two',
        'blocksy' => 'Blocksy',
        'kadence' => 'Kadence',
        'astra' => 'Astra',
        'generatepress' => 'GeneratePress',
        'oceanwp' => 'OceanWP',
        'neve' => 'Neve',
        'storefront' => 'Storefront',
        'customify' => 'Customify',
        'hestia' => 'Hestia',
        'sydney' => 'Sydney',
        'zakra' => 'Zakra',
        'colormag' => 'ColorMag',
        'flash' => 'Flash',
        'shapely' => 'Shapely',
        'asgaros' => 'Asgaros',
        'bento' => 'Bento'
    ];

    /**
     * Supported plugins list
     *
     * @var array
     */
    private $supported_plugins = [
        'elementor/elementor.php' => 'Elementor',
        'gutenberg/gutenberg.php' => 'Gutenberg',
        'woocommerce/woocommerce.php' => 'WooCommerce',
        'contact-form-7/wp-contact-form-7.php' => 'Contact Form 7',
        'yoast-seo/wp-seo.php' => 'Yoast SEO',
        'wp-rocket/wp-rocket.php' => 'WP Rocket',
        'litespeed-cache/litespeed-cache.php' => 'LiteSpeed Cache',
        'w3-total-cache/w3-total-cache.php' => 'W3 Total Cache',
        'wp-super-cache/wp-cache.php' => 'WP Super Cache',
        'autoptimize/autoptimize.php' => 'Autoptimize',
        'jetpack/jetpack.php' => 'Jetpack',
        'akismet/akismet.php' => 'Akismet',
        'wordfence/wordfence.php' => 'Wordfence Security',
        'all-in-one-seo-pack/all_in_one_seo_pack.php' => 'All in One SEO',
        'wp-optimize/wp-optimize.php' => 'WP-Optimize',
        'updraftplus/updraftplus.php' => 'UpdraftPlus',
        'mailchimp-for-wp/mailchimp-for-wp.php' => 'Mailchimp for WordPress',
        'ninja-forms/ninja-forms.php' => 'Ninja Forms',
        'wpforms-lite/wpforms.php' => 'WPForms',
        'really-simple-ssl/rlrsssl-really-simple-ssl.php' => 'Really Simple SSL'
    ];

    /**
     * Get instance of this class
     *
     * @return VRSTORE_Compatibility
     */
    public static function get_instance(): VRSTORE_Compatibility {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        $this->active_theme = get_template();
        $this->active_plugins = get_option('active_plugins', []);
        $this->compatibility_mode = $this->get_compatibility_setting();
        
        $this->init();
    }

    /**
     * Initialize compatibility features
     *
     * @return void
     */
    private function init(): void {
        if (!$this->compatibility_mode) {
            return;
        }

        // Theme compatibility hooks
        add_action('after_setup_theme', [$this, 'setup_theme_compatibility']);
        
        // Plugin compatibility hooks
        add_action('plugins_loaded', [$this, 'setup_plugin_compatibility']);
        
        // CSS/JS compatibility
        add_action('wp_enqueue_scripts', [$this, 'enqueue_compatibility_assets'], 999);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_compatibility_assets'], 999);
        
        // Content filters for better integration
        add_filter('the_content', [$this, 'filter_course_content'], 10);
        add_filter('vrstore_course_template', [$this, 'filter_course_template'], 10, 2);
    }

    /**
     * Get compatibility setting - always return true for automatic compatibility
     *
     * @return bool
     */
    private function get_compatibility_setting(): bool {
        // Always return true to enable automatic compatibility for all themes
        return true;
    }

    /**
     * Setup theme-specific compatibility
     *
     * @return void
     */
    public function setup_theme_compatibility(): void {
        switch ($this->active_theme) {
            case 'hello-elementor':
                $this->setup_hello_elementor_compatibility();
                break;
            case 'blocksy':
                $this->setup_blocksy_compatibility();
                break;
            case 'kadence':
                $this->setup_kadence_compatibility();
                break;
            case 'astra':
                $this->setup_astra_compatibility();
                break;
            case 'generatepress':
                $this->setup_generatepress_compatibility();
                break;
            case 'oceanwp':
                $this->setup_oceanwp_compatibility();
                break;
            case 'neve':
                $this->setup_neve_compatibility();
                break;
            default:
                $this->setup_default_theme_compatibility();
                break;
        }
    }

    /**
     * Setup plugin-specific compatibility
     *
     * @return void
     */
    public function setup_plugin_compatibility(): void {
        // Elementor compatibility
        if ($this->is_plugin_active('elementor/elementor.php')) {
            $this->setup_elementor_compatibility();
        }

        // WooCommerce compatibility
        if ($this->is_plugin_active('woocommerce/woocommerce.php')) {
            $this->setup_woocommerce_compatibility();
        }

        // Cache plugins compatibility
        if ($this->is_plugin_active('wp-rocket/wp-rocket.php')) {
            $this->setup_wp_rocket_compatibility();
        }

        if ($this->is_plugin_active('litespeed-cache/litespeed-cache.php')) {
            $this->setup_litespeed_compatibility();
        }

        if ($this->is_plugin_active('w3-total-cache/w3-total-cache.php')) {
            $this->setup_w3tc_compatibility();
        }

        // SEO plugins compatibility
        if ($this->is_plugin_active('yoast-seo/wp-seo.php')) {
            $this->setup_yoast_compatibility();
        }
    }

    /**
     * Hello Elementor theme compatibility
     *
     * @return void
     */
    private function setup_hello_elementor_compatibility(): void {
        // Ensure proper container classes
        add_filter('vrstore_course_container_class', function($classes) {
            return $classes . ' hello-elementor-course-container';
        });

        // Fix header/footer integration
        add_action('wp_head', function() {
            if (is_singular('vrstore_course')) {
                echo '<style>.vrstore-course-wrapper { margin-top: 20px; }</style>';
            }
        });
    }

    /**
     * Blocksy theme compatibility
     *
     * @return void
     */
    private function setup_blocksy_compatibility(): void {
        // Integrate with Blocksy's container system
        add_filter('vrstore_course_wrapper_class', function($classes) {
            return $classes . ' ct-container-fluid';
        });

        // Match Blocksy's typography
        add_action('wp_head', function() {
            if (is_singular('vrstore_course')) {
                echo '<style>
                    .vrstore-course-content { 
                        font-family: var(--theme-font-family, inherit); 
                        line-height: var(--theme-line-height, 1.6);
                    }
                </style>';
            }
        });
    }

    /**
     * Kadence theme compatibility
     *
     * @return void
     */
    private function setup_kadence_compatibility(): void {
        // Use Kadence container classes
        add_filter('vrstore_course_container_class', function($classes) {
            return $classes . ' content-wrap';
        });

        // Integrate with Kadence's color scheme
        add_action('wp_head', function() {
            if (is_singular('vrstore_course')) {
                echo '<style>
                    .vrstore-course-meta { 
                        color: var(--global-palette-8, #718096); 
                    }
                    .vrstore-course-price {
                        color: var(--global-palette-3, #3182CE);
                    }
                </style>';
            }
        });
    }

    /**
     * Astra theme compatibility
     *
     * @return void
     */
    private function setup_astra_compatibility(): void {
        // Use Astra's container system
        add_filter('vrstore_course_container_class', function($classes) {
            return $classes . ' ast-container';
        });

        // Match Astra's button styles
        add_action('wp_head', function() {
            if (is_singular('vrstore_course')) {
                echo '<style>
                    .vrstore-enroll-button {
                        border-radius: var(--ast-border-radius-fields, 2px);
                        font-weight: var(--ast-font-weight-button, 600);
                    }
                </style>';
            }
        });
    }

    /**
     * GeneratePress theme compatibility
     *
     * @return void
     */
    private function setup_generatepress_compatibility(): void {
        // Use GP container classes
        add_filter('vrstore_course_container_class', function($classes) {
            return $classes . ' inside-article';
        });
    }

    /**
     * OceanWP theme compatibility
     *
     * @return void
     */
    private function setup_oceanwp_compatibility(): void {
        // Use OceanWP container
        add_filter('vrstore_course_container_class', function($classes) {
            return $classes . ' clr';
        });
    }

    /**
     * Neve theme compatibility
     *
     * @return void
     */
    private function setup_neve_compatibility(): void {
        // Use Neve container
        add_filter('vrstore_course_container_class', function($classes) {
            return $classes . ' nv-content-wrap';
        });
    }

    /**
     * Default theme compatibility
     *
     * @return void
     */
    private function setup_default_theme_compatibility(): void {
        // Generic WordPress theme compatibility
        add_filter('vrstore_course_container_class', function($classes) {
            return $classes . ' wp-block-group';
        });
    }

    /**
     * Elementor plugin compatibility
     *
     * @return void
     */
    private function setup_elementor_compatibility(): void {
        // Register Elementor widgets if needed
        add_action('elementor/widgets/widgets_registered', function() {
            // Future: Register ViraStore Elementor widgets
        });

        // Ensure proper CSS loading in Elementor editor
        add_action('elementor/editor/after_enqueue_styles', function() {
            wp_enqueue_style('vrstore-elementor-editor', VRSTORE_PLUGIN_URL . 'assets/css/elementor-editor.css', [], VRSTORE_VERSION);
        });
    }

    /**
     * WooCommerce compatibility
     *
     * @return void
     */
    private function setup_woocommerce_compatibility(): void {
        // Ensure cart integration works properly
        add_filter('woocommerce_add_to_cart_fragments', function($fragments) {
            // Update cart fragments for course products
            return $fragments;
        });
    }

    /**
     * WP Rocket compatibility
     *
     * @return void
     */
    private function setup_wp_rocket_compatibility(): void {
        // Exclude course progress from caching
        add_filter('rocket_cache_reject_uri', function($uris) {
            $uris[] = '/course/(.*)';
            $uris[] = '/lesson/(.*)';
            return $uris;
        });
    }

    /**
     * LiteSpeed Cache compatibility
     *
     * @return void
     */
    private function setup_litespeed_compatibility(): void {
        // Exclude dynamic course content from caching
        add_action('init', function() {
            if (is_singular('vrstore_course') && is_user_logged_in()) {
                do_action('litespeed_control_set_nocache', 'vrstore course page');
            }
        });
    }

    /**
     * W3 Total Cache compatibility
     *
     * @return void
     */
    private function setup_w3tc_compatibility(): void {
        // Exclude course pages from page caching for logged-in users
        add_filter('w3tc_can_cache', function($can_cache) {
            if (is_singular('vrstore_course') && is_user_logged_in()) {
                return false;
            }
            return $can_cache;
        });
    }

    /**
     * Yoast SEO compatibility
     *
     * @return void
     */
    private function setup_yoast_compatibility(): void {
        // Add course schema markup
        add_filter('wpseo_schema_graph_pieces', function($pieces, $context) {
            if (is_singular('vrstore_course')) {
                $pieces[] = new VRSTORE_Course_Schema($context);
            }
            return $pieces;
        }, 10, 2);
    }

    /**
     * Enqueue compatibility assets for frontend
     *
     * @return void
     */
    public function enqueue_compatibility_assets(): void {
        if (!is_singular('vrstore_course') && !is_post_type_archive('vrstore_course')) {
            return;
        }

        // Theme-specific CSS
        $theme_css = $this->get_theme_specific_css();
        if ($theme_css) {
            wp_add_inline_style('vrstore-frontend', $theme_css);
        }

        // Plugin-specific CSS
        $plugin_css = $this->get_plugin_specific_css();
        if ($plugin_css) {
            wp_add_inline_style('vrstore-frontend', $plugin_css);
        }
    }

    /**
     * Enqueue compatibility assets for admin
     *
     * @return void
     */
    public function enqueue_admin_compatibility_assets(): void {
        $screen = get_current_screen();
        if (!$screen || $screen->post_type !== 'vrstore_course') {
            return;
        }

        // Admin compatibility CSS
        $admin_css = $this->get_admin_compatibility_css();
        if ($admin_css) {
            wp_add_inline_style('vrstore-admin', $admin_css);
        }
    }

    /**
     * Get theme-specific CSS
     *
     * @return string
     */
    private function get_theme_specific_css(): string {
        $css = '';

        switch ($this->active_theme) {
            case 'hello-elementor':
                $css .= '
                    .vrstore-course-wrapper { 
                        max-width: 1140px; 
                        margin: 0 auto; 
                        padding: 0 15px; 
                    }
                ';
                break;
            case 'blocksy':
                $css .= '
                    .vrstore-course-content { 
                        --theme-button-border-radius: 3px; 
                    }
                ';
                break;
            case 'kadence':
                $css .= '
                    .vrstore-course-sidebar { 
                        background: var(--global-palette-9, #f7fafc); 
                        border-radius: 8px; 
                    }
                ';
                break;
        }

        return $css;
    }

    /**
     * Get plugin-specific CSS
     *
     * @return string
     */
    private function get_plugin_specific_css(): string {
        $css = '';

        if ($this->is_plugin_active('elementor/elementor.php')) {
            $css .= '
                .elementor-widget-vrstore-course { 
                    margin-bottom: 20px; 
                }
            ';
        }

        return $css;
    }

    /**
     * Get admin compatibility CSS
     *
     * @return string
     */
    private function get_admin_compatibility_css(): string {
        return '
            .vrstore-compatibility-notice {
                background: #d1ecf1;
                border-left: 4px solid #17a2b8;
                padding: 12px;
                margin: 15px 0;
            }
        ';
    }

    /**
     * Filter course content for better theme integration
     *
     * @param string $content
     * @return string
     */
    public function filter_course_content(string $content): string {
        if (!is_singular('vrstore_course')) {
            return $content;
        }

        // Add theme-specific wrapper classes
        $wrapper_class = apply_filters('vrstore_course_wrapper_class', 'vrstore-course-wrapper');
        
        return '<div class="' . esc_attr($wrapper_class) . '">' . $content . '</div>';
    }

    /**
     * Filter course template for theme compatibility
     *
     * @param string $template
     * @param string $template_name
     * @return string
     */
    public function filter_course_template(string $template, string $template_name): string {
        // Check if theme has custom course templates
        $theme_template = locate_template(['vrstore/' . $template_name, 'vrstore-' . $template_name]);
        
        if ($theme_template) {
            return $theme_template;
        }

        return $template;
    }

    /**
     * Check if plugin is active
     *
     * @param string $plugin
     * @return bool
     */
    private function is_plugin_active(string $plugin): bool {
        return in_array($plugin, $this->active_plugins) || array_key_exists($plugin, get_mu_plugins());
    }

    /**
     * Get supported themes list
     *
     * @return array
     */
    public function get_supported_themes(): array {
        return $this->supported_themes;
    }

    /**
     * Get supported plugins list
     *
     * @return array
     */
    public function get_supported_plugins(): array {
        return $this->supported_plugins;
    }

    /**
     * Get current theme compatibility status
     *
     * @return array
     */
    public function get_theme_compatibility_status(): array {
        return [
            'theme' => $this->active_theme,
            'theme_name' => wp_get_theme()->get('Name'),
            'supported' => array_key_exists($this->active_theme, $this->supported_themes),
            'compatibility_mode' => $this->compatibility_mode
        ];
    }

    /**
     * Get active plugins compatibility status
     *
     * @return array
     */
    public function get_plugins_compatibility_status(): array {
        $status = [];
        
        foreach ($this->supported_plugins as $plugin_file => $plugin_name) {
            $status[] = [
                'plugin' => $plugin_file,
                'name' => $plugin_name,
                'active' => $this->is_plugin_active($plugin_file),
                'supported' => true
            ];
        }

        return $status;
    }
    
}

// Initialize compatibility if not in admin or during AJAX
if (!is_admin() || wp_doing_ajax()) {
    VRSTORE_Compatibility::get_instance();
}