<?php
/**
 * File Protection Class
 *
 * Enhanced file protection for product files with security, validation, and license integration
 *
 * @package Vira_Store
 * @since 1.0.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Enhanced file protection and management system
 */
class VRSTORE_File_Protection {

    /**
     * Handle certificate download
     *
     * @param int $course_id Course ID (used as product_id for certificates)
     * @param int $user_id User ID
     */
    private function handle_certificate_download(int $course_id, int $user_id): void {
        // Check if PDF Certificate class exists
        if (!class_exists('VRSTORE_PDF_Certificate')) {
            wp_die(__('Certificate system not available.', 'vira-store'), __('Service Unavailable', 'vira-store'), ['response' => 503]);
        }

        $certificate_instance = VRSTORE_PDF_Certificate::get_instance();
        
        // Check if certification is enabled for this course
        $certification_enabled = get_post_meta($course_id, '_vrstore_course_certification', true);
        if (!$certification_enabled) {
            wp_die(__('Certification is not enabled for this course.', 'vira-store'), __('Access Denied', 'vira-store'), ['response' => 403]);
        }
        
        // Verify course completion
        if (!$certificate_instance->is_course_completed($course_id, $user_id)) {
            wp_die(__('Course not completed yet.', 'vira-store'), __('Access Denied', 'vira-store'), ['response' => 403]);
        }

        // Check if user has access to the course certificate (supports all course types)
        if (!$certificate_instance->user_has_certificate_access($course_id, $user_id)) {
            wp_die(__('You do not have access to this course certificate.', 'vira-store'), __('Access Denied', 'vira-store'), ['response' => 403]);
        }

        // Generate certificate
        $certificate_html = $certificate_instance->generate_certificate($course_id, $user_id);
        
        if (!$certificate_html) {
            wp_die(__('Failed to generate certificate.', 'vira-store'), __('Internal Server Error', 'vira-store'), ['response' => 500]);
        }

        // Get course and user info for filename
        $course = get_post($course_id);
        $user = get_user_by('ID', $user_id);
        $filename = sanitize_file_name('certificate-' . $course->post_title . '-' . $user->display_name . '.html');

        // Set headers for download
        header('Content-Type: text/html; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Cache-Control: no-cache, must-revalidate');
        header('Expires: Sat, 26 Jul 1997 05:00:00 GMT');

        // Security headers
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: DENY');
        header('X-XSS-Protection: 1; mode=block');

        // Track certificate download in download_tracking table
        $this->track_certificate_download($course_id, $user_id, $filename);

        // Log the download
        VRSTORE_Security::log_security_event(
            'Certificate downloaded successfully',
            'info',
            [
                'course_id' => $course_id,
                'user_id' => $user_id,
                'filename' => $filename
            ]
        );

        echo $certificate_html;
        exit;
    }

    /**
     * Track certificate download in the download_tracking table
     *
     * @param int $course_id Course ID
     * @param int $user_id User ID
     * @param string $filename Certificate filename
     * @return void
     */
    private function track_certificate_download(int $course_id, int $user_id, string $filename): void {
        global $wpdb;
        
        $download_table = $wpdb->prefix . 'vrstore_download_tracking';
        
        // Check if download tracking table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$download_table'") !== $download_table) {
            return; // Table doesn't exist, skip tracking
        }
        
        // Get user data
        $user = get_user_by('ID', $user_id);
        if (!$user) {
            return;
        }
        
        // Try to find the order ID for this course purchase
        $order_id = 0;
        $orders_table = $wpdb->prefix . 'vrstore_orders';
        if ($wpdb->get_var("SHOW TABLES LIKE '$orders_table'") === $orders_table) {
            // Look for the most recent completed order for this course and customer
            $order = $wpdb->get_row($wpdb->prepare(
                "SELECT id FROM $orders_table 
                 WHERE customer_email = %s 
                   AND product_id = %d 
                   AND (payment_status = 'completed' OR order_status = 'completed')
                 ORDER BY created_at DESC 
                 LIMIT 1",
                $user->user_email,
                $course_id
            ));
            
            if ($order) {
                $order_id = $order->id;
            }
        }
        
        // Get user IP address
        $ip_address = '';
        if (isset($_SERVER['HTTP_CF_CONNECTING_IP'])) {
            $ip_address = sanitize_text_field($_SERVER['HTTP_CF_CONNECTING_IP']);
        } elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip_address = sanitize_text_field($_SERVER['HTTP_X_FORWARDED_FOR']);
        } elseif (isset($_SERVER['REMOTE_ADDR'])) {
            $ip_address = sanitize_text_field($_SERVER['REMOTE_ADDR']);
        }
        
        // Get user agent
        $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field($_SERVER['HTTP_USER_AGENT']) : '';
        
        // Insert download tracking record
        $wpdb->insert(
            $download_table,
            [
                'product_id' => $course_id,
                'order_id' => $order_id,
                'user_id' => $user_id,
                'customer_name' => $user->display_name ?: $user->user_login,
                'customer_email' => $user->user_email,
                'file_name' => $filename,
                'file_url' => 'certificate://course-' . $course_id, // Special URL format for certificates
                'file_type' => 'certificate',
                'ip_address' => $ip_address,
                'user_agent' => $user_agent,
                'download_date' => current_time('mysql'),
                'file_size' => strlen($filename), // Approximate size
                'download_type' => 'single',
                'download_process' => 'immediate'
            ],
            [
                '%d', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s'
            ]
        );
    }

    /**
     * Singleton instance
     *
     * @var VRSTORE_File_Protection|null
     */
    private static ?VRSTORE_File_Protection $instance = null;

    /**
     * Allowed file extensions
     *
     * @var array
     */
    private array $allowed_file_types;

    /**
     * Max file size in bytes
     *
     * @var int
     */
    private int $max_file_size;

    /**
     * Security settings
     *
     * @var array
     */
    private array $security_settings;

    /**
     * Protected file extensions that require authentication
     *
     * @var array
     */
    private array $protected_file_types;

    /**
     * Get singleton instance
     *
     * @return VRSTORE_File_Protection
     */
    public static function get_instance(): VRSTORE_File_Protection {
        if (null === self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Get translated text with conditional loading check.
     *
     * @since 1.0.0
     * @param string $text The text to translate.
     * @return string
     */
    private function get_translated_text( $text ) {
        if ( vrstore_is_textdomain_ready() ) {
            return esc_html__( $text, 'vira-store' );
        }
        return esc_html( $text );
    }

    /**
     * Constructor
     */
    private function __construct() {
        $this->init_settings();
        $this->init_hooks();
    }

    /**
     * Initialize settings
     */
    private function init_settings(): void {
        // Get plugin settings
        $settings = get_option('vrstore_settings', []);

        // Default allowed file types
        $this->allowed_file_types = apply_filters('vrstore_allowed_file_types', [
            // Archives
            'zip', '7z', 'rar', 'tar', 'gz', 'bz2',
            // Documents
            'pdf', 'doc', 'docx', 'txt', 'rtf', 'odt',
            // Executables (with caution)
            'exe', 'msi', 'dmg', 'pkg', 'deb', 'rpm',
            // Scripts (for plugins/themes)
            'php', 'js', 'css', 'html', 'xml', 'json',
            // Media (for assets)
            'jpg', 'jpeg', 'png', 'gif', 'svg', 'webp',
            'mp4', 'webm', 'ogg', 'mp3', 'wav', 'flac',
        ]);

        // Default max file size (100MB)
        $this->max_file_size = apply_filters('vrstore_max_file_size', 100 * 1024 * 1024);

        // Security settings
        $this->security_settings = apply_filters('vrstore_file_security_settings', [
            'enable_virus_scanning' => $settings['enable_virus_scanning'] ?? false,
            'enable_url_validation' => $settings['enable_url_validation'] ?? true,
            'enable_file_encryption' => $settings['enable_file_encryption'] ?? false,
            'allowed_domains' => $settings['allowed_external_domains'] ?? [],
            'blocked_domains' => $settings['blocked_external_domains'] ?? ['localhost', '127.0.0.1'],
            'require_https' => $settings['require_https_for_external_files'] ?? true,
            'enable_download_logging' => $settings['enable_download_logging'] ?? true,
            'max_daily_downloads' => $settings['max_daily_downloads_per_license'] ?? 50,
            'enable_direct_access_protection' => $settings['enable_direct_access_protection'] ?? true,
            // Enhanced protection settings
            'enable_enhanced_archive_protection' => $settings['enable_enhanced_archive_protection'] ?? true,
            'enable_enhanced_document_protection' => $settings['enable_enhanced_document_protection'] ?? true,
            'block_suspicious_user_agents' => $settings['block_suspicious_user_agents'] ?? true,
            'enable_hotlink_protection' => $settings['enable_hotlink_protection'] ?? true,
            'unauthorized_access_handling' => $settings['unauthorized_access_handling'] ?? 'show_404',
            'enable_access_attempt_logging' => $settings['enable_access_attempt_logging'] ?? true,
            'max_unauthorized_attempts' => $settings['max_unauthorized_attempts'] ?? 10,
            'temp_block_duration' => $settings['temp_block_duration'] ?? 60,
        ]);

        // Protected file types that require authentication
        $this->protected_file_types = apply_filters('vrstore_protected_file_types', [
            // Archives
            'zip', '7z', 'rar', 'tar', 'gz', 'bz2',
            // Documents
            'pdf', 'doc', 'docx', 'txt', 'rtf', 'odt',
            // Executables
            'exe', 'msi', 'dmg', 'pkg', 'deb', 'rpm',
            // Scripts
            'php', 'js', 'css', 'html', 'xml', 'json',
            // Media (premium content)
            'mp4', 'webm', 'ogg', 'mp3', 'wav', 'flac',
            // Other sensitive files
            'sql', 'db', 'log', 'ini', 'conf'
        ]);
    }

    /**
     * Initialize hooks
     */
    private function init_hooks(): void {
        // File upload validation
        add_filter('wp_handle_upload_prefilter', [$this, 'validate_upload'], 10);
        add_filter('wp_handle_upload', [$this, 'post_upload_processing'], 10);

        // File access control - use template_redirect for better handling
        add_action('template_redirect', [$this, 'handle_secure_file_access'], 1);
        add_action('init', [$this, 'protect_direct_file_access'], 5);

        // External URL validation
        add_filter('vrstore_validate_external_url', [$this, 'validate_external_url'], 10, 2);

        // License-based access control
        add_filter('vrstore_can_access_file', [$this, 'check_license_access'], 10, 4);

        // Admin ajax handlers for file operations
        add_action('wp_ajax_vrstore_validate_file_upload', [$this, 'ajax_validate_file_upload']);
        add_action('wp_ajax_vrstore_validate_external_url', [$this, 'ajax_validate_external_url']);

        // Clean up temporary files
        add_action('wp_scheduled_delete', [$this, 'cleanup_temp_files']);

        // Template filters for file display
        add_filter('vrstore_display_product_files', [$this, 'filter_product_files_display'], 10, 3);

        // Direct access protection
        add_action('init', [$this, 'setup_direct_access_protection'], 5);
        add_action('wp_loaded', [$this, 'handle_protected_file_request'], 1);

        // Rewrite rules for secure downloads
        add_action('init', [$this, 'add_rewrite_rules']);
        add_filter('query_vars', [$this, 'add_query_vars']);
        add_action('template_redirect', [$this, 'handle_secure_download_request'], 1);
        
        // Admin settings
        add_action('admin_init', [$this, 'add_admin_settings']);
    }

    /**
     * Validate file upload
     *
     * @param array $file Upload file data
     * @return array Modified file data or WP_Error
     */
    public function validate_upload(array $file): array {
        // Check file extension
        $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        
        if (!in_array($file_extension, $this->allowed_file_types, true)) {
            $file['error'] = sprintf(
                __('File type "%s" is not allowed. Allowed types: %s', 'vira-store'),
                $file_extension,
                implode(', ', $this->allowed_file_types)
            );
            return $file;
        }

        // Check file size
        if ($file['size'] > $this->max_file_size) {
            $file['error'] = sprintf(
                __('File size exceeds maximum allowed size of %s.', 'vira-store'),
                size_format($this->max_file_size)
            );
            return $file;
        }

        // Check MIME type
        $allowed_mimes = get_allowed_mime_types();
        $file_type = wp_check_filetype($file['name'], $allowed_mimes);
        
        if (!$file_type['type']) {
            $file['error'] = __('File type is not supported.', 'vira-store');
            return $file;
        }

        // Virus scanning (if enabled and available)
        if ($this->security_settings['enable_virus_scanning']) {
            $scan_result = $this->scan_file_for_threats($file['tmp_name']);
            if (!$scan_result['safe']) {
                $file['error'] = $scan_result['message'];
                return $file;
            }
        }

        // Log the upload attempt
        

        return $file;
    }

    /**
     * Post upload processing
     *
     * @param array $upload Upload result data
     * @return array Modified upload data
     */
    public function post_upload_processing(array $upload): array {
        if (isset($upload['file'])) {
            // Encrypt file if enabled
            if ($this->security_settings['enable_file_encryption']) {
                $encrypted_file = $this->encrypt_uploaded_file($upload['file']);
                if ($encrypted_file) {
                    $upload['file'] = $encrypted_file;
                    $upload['url'] = str_replace($upload['file'], $encrypted_file, $upload['url']);
                }
            }

            // Set file permissions
            chmod($upload['file'], 0644);
        }

        return $upload;
    }

    /**
     * Validate external URL
     *
     * @param string $url External URL to validate
     * @param int $product_id Product ID (optional)
     * @return array Validation result
     */
    public function validate_external_url(string $url, int $product_id = 0): array {
        // Basic URL validation
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            return [
                'is_valid' => false,
                'valid' => false, // Keep for backward compatibility
                'errors' => [__('Invalid URL format.', 'vira-store')],
                'message' => __('Invalid URL format.', 'vira-store'),
                'security_level' => 'error'
            ];
        }

        $parsed_url = wp_parse_url($url);
        $domain = $parsed_url['host'] ?? '';
        
        // Special handling for YouTube URLs - they should always be allowed
        $is_youtube = $this->is_youtube_url($url);
        if ($is_youtube) {
            return [
                'is_valid' => true,
                'valid' => true,
                'errors' => [],
                'message' => __('YouTube URL is valid and accessible.', 'vira-store'),
                'security_level' => 'success',
                'domain' => $domain,
                'scheme' => $parsed_url['scheme'],
                'is_youtube' => true
            ];
        }

        // Check for blocked domains (skip for YouTube)
        foreach ($this->security_settings['blocked_domains'] as $blocked_domain) {
            if (stripos($domain, $blocked_domain) !== false) {
                return [
                    'is_valid' => false,
                    'valid' => false, // Keep for backward compatibility
                    'errors' => [sprintf($this->get_translated_text('Domain "%s" is blocked for security reasons.'), $domain)],
                    'message' => sprintf($this->get_translated_text('Domain "%s" is blocked for security reasons.'), $domain),
                    'security_level' => 'error'
                ];
            }
        }

        // Check HTTPS requirement (skip for YouTube as it's handled above)
        if ($this->security_settings['require_https'] && $parsed_url['scheme'] !== 'https') {
            return [
                'is_valid' => false,
                'valid' => false, // Keep for backward compatibility
                'errors' => [$this->get_translated_text('HTTPS is required for external file URLs.')],
                'message' => $this->get_translated_text('HTTPS is required for external file URLs.'),
                'security_level' => 'warning'
            ];
        }

        // Check allowed domains (if specified, skip for YouTube)
        if (!empty($this->security_settings['allowed_domains'])) {
            $domain_allowed = false;
            foreach ($this->security_settings['allowed_domains'] as $allowed_domain) {
                if (stripos($domain, $allowed_domain) !== false) {
                    $domain_allowed = true;
                    break;
                }
            }

            if (!$domain_allowed) {
                return [
                    'is_valid' => false,
                    'valid' => false, // Keep for backward compatibility
                    'errors' => [sprintf(__('Domain "%s" is not in the allowed domains list.', 'vira-store'), $domain)],
                    'message' => sprintf(__('Domain "%s" is not in the allowed domains list.', 'vira-store'), $domain),
                    'security_level' => 'warning'
                ];
            }
        }

        // Check if URL is accessible
        $accessibility = $this->check_url_accessibility($url);
        
        // Log URL validation
        if (!$accessibility['accessible']) {
    VRSTORE_Security::log_security_event(
        'External URL validated: ' . $url,
        'warning',
        [
            'url' => $url,
            'domain' => $domain,
            'product_id' => $product_id,
            'accessible' => $accessibility['accessible'],
            'user_id' => get_current_user_id(),
        ]
    );
}

        return [
            'is_valid' => true,
            'valid' => true, // Keep for backward compatibility
            'errors' => [],
            'message' => __('URL is valid and accessible.', 'vira-store'),
            'security_level' => 'success',
            'accessibility' => $accessibility,
            'domain' => $domain,
            'scheme' => $parsed_url['scheme']
        ];
    }

    /**
     * Validate uploaded file
     *
     * @param string $file_url File URL to validate
     * @param int $product_id Product ID (optional)
     * @return array Validation result
     */
    public function validate_uploaded_file(string $file_url, int $product_id = 0): array {
        // Check if file URL is valid
        if (empty($file_url) || !filter_var($file_url, FILTER_VALIDATE_URL)) {
            return [
                'is_valid' => false,
                'errors' => [__('Invalid file URL.', 'vira-store')],
                'security_level' => 'error'
            ];
        }

        // Get attachment ID from URL
        $attachment_id = attachment_url_to_postid($file_url);
        
        if (!$attachment_id) {
            return [
                'is_valid' => false,
                'errors' => [__('File not found in media library.', 'vira-store')],
                'security_level' => 'error'
            ];
        }

        // Get file path
        $file_path = get_attached_file($attachment_id);
        
        if (!$file_path || !file_exists($file_path)) {
            return [
                'is_valid' => false,
                'errors' => [__('Physical file not found on server.', 'vira-store')],
                'security_level' => 'error'
            ];
        }

        $errors = [];
        $warnings = [];

        // Check file extension
        $file_extension = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
        if (!in_array($file_extension, $this->allowed_file_types, true)) {
            $errors[] = sprintf(
                $this->get_translated_text('File type "%s" is not allowed. Allowed types: %s'),
                $file_extension,
                implode(', ', $this->allowed_file_types)
            );
        }

        // Check file size
        $file_size = filesize($file_path);
        if ($file_size > $this->max_file_size) {
            $errors[] = sprintf(
                $this->get_translated_text('File size exceeds maximum allowed size of %s.'),
                size_format($this->max_file_size)
            );
        }

        // Virus scanning (if enabled)
        if ($this->security_settings['enable_virus_scanning']) {
            $scan_result = $this->scan_file_for_threats($file_path);
            if (!$scan_result['safe']) {
                $errors[] = $scan_result['message'];
            }
        }

        // Check file permissions
        if (!is_readable($file_path)) {
            $warnings[] = $this->get_translated_text('File may not be accessible due to permission restrictions.');
        }

        // Determine validation result
        $is_valid = empty($errors);
        $security_level = !empty($errors) ? 'error' : (!empty($warnings) ? 'warning' : 'success');

        // Log validation attempt
        if (!$is_valid) {
    VRSTORE_Security::log_security_event(
        'Uploaded file validated: ' . basename($file_path),
        'warning',
        [
            'file_url' => $file_url,
            'file_path' => $file_path,
            'file_size' => $file_size,
            'file_extension' => $file_extension,
            'product_id' => $product_id,
            'is_valid' => $is_valid,
            'user_id' => get_current_user_id(),
        ]
    );
}

        return [
            'is_valid' => $is_valid,
            'errors' => array_merge($errors, $warnings),
            'security_level' => $security_level,
            'file_info' => [
                'size' => $file_size,
                'extension' => $file_extension,
                'mime_type' => get_post_mime_type($attachment_id),
                'attachment_id' => $attachment_id
            ]
        ];
    }

    /**
     * Check license-based file access
     *
     * @param bool $can_access Current access permission
     * @param int $product_id Product ID
     * @param int $user_id User ID
     * @param string $file_url File URL
     * @return bool Whether user can access the file
     */
    public function check_license_access(bool $can_access, int $product_id, int $user_id, string $file_url): bool {
        // Skip if already denied
        if (!$can_access) {
            return false;
        }

        // Skip check for administrators
        if (user_can($user_id, 'manage_options')) {
            return true;
        }

        // Special handling for certificate downloads (when called from process_secure_download with file_index = 999)
        // Check if this is a certificate download by examining the call stack or checking if product_id is a course
        $post = get_post($product_id);
        if ($post && $post->post_type === 'vrstore_course') {
            // This is a course certificate download - use course access logic instead of license logic
            if (class_exists('VRSTORE_PDF_Certificate')) {
                $certificate_instance = VRSTORE_PDF_Certificate::get_instance();
                $has_certificate_access = $certificate_instance->user_has_certificate_access($product_id, $user_id);
                
                if ($has_certificate_access) {
                    VRSTORE_Security::log_security_event(
                        'Certificate access granted for course',
                        'info',
                        [
                            'user_id' => $user_id,
                            'course_id' => $product_id,
                            'access_type' => 'certificate_download'
                        ]
                    );
                    return true;
                } else {
                    VRSTORE_Security::log_security_event(
                        'Certificate access denied for course',
                        'warning',
                        [
                            'user_id' => $user_id,
                            'course_id' => $product_id,
                            'access_type' => 'certificate_download'
                        ]
                    );
                    return false;
                }
            }
        }

        // Get user's licenses for this product
        $user_licenses = $this->get_user_licenses($user_id, $product_id);

        if (empty($user_licenses)) {
            VRSTORE_Security::log_security_event(
                'File access denied: No valid license',
                'warning',
                [
                    'user_id' => $user_id,
                    'product_id' => $product_id,
                    'file_url' => $file_url,
                ]
            );
            return false;
        }

        // Check if any license allows file access
        foreach ($user_licenses as $license) {
            if ($this->is_license_valid_for_file_access($license, $file_url)) {
                // Check download limits
                if (!$this->check_download_limits($license, $user_id)) {
                    VRSTORE_Security::log_security_event(
                        'File access denied: Download limit exceeded',
                        'warning',
                        [
                            'user_id' => $user_id,
                            'product_id' => $product_id,
                            'license_key' => $license['key'],
                            'file_url' => $file_url,
                        ]
                    );
                    return false;
                }

                // Log successful access
                

                // Record download
                $this->record_download($license, $user_id, $file_url);
                
                return true;
            }
        }

        // No valid license found
        VRSTORE_Security::log_security_event(
            'File access denied: Invalid license',
            'warning',
            [
                'user_id' => $user_id,
                'product_id' => $product_id,
                'file_url' => $file_url,
                'licenses_found' => count($user_licenses),
            ]
        );

        return false;
    }

    /**
     * Handle secure file access
     */
    public function handle_secure_file_access(): void {
        // Check if this is a secure download request
        if (!isset($_GET['vrstore_secure_download'])) {
            return;
        }

        $download_token = sanitize_text_field($_GET['vrstore_secure_download']);
        $this->process_secure_download($download_token);
    }

    /**
     * Process secure download
     *
     * @param string $download_token Secure download token
     */
    private function process_secure_download(string $download_token): void {
        // Log the download attempt
        
        
        // Verify and decode the download token
        $download_data = $this->verify_download_token($download_token);
        
        if (!$download_data) {
            VRSTORE_Security::log_security_event(
                'Invalid download token received',
                'warning',
                ['token_preview' => substr($download_token, 0, 20) . '...']
            );
            wp_die(__('Invalid or expired download link.', 'vira-store'), __('Access Denied', 'vira-store'), ['response' => 403]);
        }

        // Extract data
        $product_id = $download_data['product_id'];
        $file_index = $download_data['file_index'];
        $user_id = $download_data['user_id'];
        $expires = $download_data['expires'];
        
        

        // Check if token has expired
        if (time() > $expires) {
            VRSTORE_Security::log_security_event(
                'Download token has expired',
                'warning',
                ['expires' => date('Y-m-d H:i:s', $expires), 'current_time' => date('Y-m-d H:i:s')]
            );
            wp_die(__('Download link has expired.', 'vira-store'), __('Access Denied', 'vira-store'), ['response' => 403]);
        }

        // Check user permissions
        if (!apply_filters('vrstore_can_access_file', true, $product_id, $user_id, '')) {
            VRSTORE_Security::log_security_event(
                'Download access denied by permission filter',
                'warning',
                ['product_id' => $product_id, 'user_id' => $user_id]
            );
            wp_die(__('You do not have permission to download this file.', 'vira-store'), __('Access Denied', 'vira-store'), ['response' => 403]);
        }

        // Special handling for certificate downloads (file_index = 999)
        if ($file_index === 999) {
            $this->handle_certificate_download($product_id, $user_id);
            return;
        }

        // Get product files
        $product_files = get_post_meta($product_id, '_vrstore_product_files', true);
        
        if (empty($product_files) || !isset($product_files[$file_index])) {
            VRSTORE_Security::log_security_event(
                'Product file not found',
                'error',
                [
                    'product_id' => $product_id, 
                    'file_index' => $file_index,
                    'total_files' => is_array($product_files) ? count($product_files) : 0
                ]
            );
            wp_die($this->get_translated_text('File not found.'), $this->get_translated_text('Not Found'), ['response' => 404]);
        }

        $file = $product_files[$file_index];
        
        

        // Handle different file types
        if (isset($file['type']) && $file['type'] === 'upload') {
            $this->serve_internal_file($file, $product_id, $user_id);
        } else {
            $this->serve_external_file($file, $product_id, $user_id);
        }
    }

    /**
     * Generate secure download token
     *
     * @param int $product_id Product ID
     * @param int $file_index File index
     * @param int $user_id User ID
     * @param int $expires Expiration timestamp
     * @return string Secure download token
     */
    public function generate_download_token(int $product_id, int $file_index, int $user_id, int $expires = 0): string {
        if (!$expires) {
            $expires = time() + (24 * HOUR_IN_SECONDS); // 24 hours default
        }

        $data = [
            'product_id' => $product_id,
            'file_index' => $file_index,
            'user_id' => $user_id,
            'expires' => $expires,
            'nonce' => wp_create_nonce('vrstore_download_' . $product_id . '_' . $file_index . '_' . $user_id)
        ];

        // Encrypt the data
        $encrypted_data = VRSTORE_Security::encrypt_data(wp_json_encode($data));
        
        return base64_encode($encrypted_data);
    }

    /**
     * Verify download token
     *
     * @param string $token Download token
     * @return array|false Download data or false if invalid
     */
    private function verify_download_token(string $token) {
        try {
            // Decode and decrypt
            $encrypted_data = base64_decode($token);
            $decrypted_data = VRSTORE_Security::decrypt_data($encrypted_data);
            $data = json_decode($decrypted_data, true);

            if (!$data || !isset($data['product_id'], $data['file_index'], $data['user_id'], $data['expires'], $data['nonce'])) {
                return false;
            }

            // Verify nonce
            if (!wp_verify_nonce($data['nonce'], 'vrstore_download_' . $data['product_id'] . '_' . $data['file_index'] . '_' . $data['user_id'])) {
                return false;
            }

            return $data;
        } catch (Exception $e) {
            VRSTORE_Security::log_security_event(
                'Download token verification failed: ' . $e->getMessage(),
                'error',
                ['token' => substr($token, 0, 20) . '...'] // Log partial token for debugging
            );
            return false;
        }
    }

    /**
     * Scan file for threats
     *
     * @param string $file_path Path to file
     * @return array Scan result
     */
    private function scan_file_for_threats(string $file_path): array {
        // Apply filter to allow custom virus scanning implementations
        $scan_result = apply_filters('vrstore_virus_scan_result', null, $file_path);
        
        if ($scan_result !== null) {
            return $scan_result;
        }

        // Basic threat detection
        $threats_found = [];

        // Check for suspicious patterns in file content
        if (is_readable($file_path)) {
            $content = file_get_contents($file_path);
            
            // PHP threat patterns
            $php_threats = [
                'eval\s*\(',
                'exec\s*\(',
                'system\s*\(',
                'shell_exec\s*\(',
                'base64_decode\s*\(',
                'gzinflate\s*\(',
                'str_rot13\s*\(',
            ];

            foreach ($php_threats as $pattern) {
                if (preg_match('/' . $pattern . '/i', $content)) {
                    $threats_found[] = 'Suspicious PHP code detected';
                    break;
                }
            }

            // JavaScript threats
            $js_threats = [
                'document\.write\s*\(',
                'eval\s*\(',
                'innerHTML\s*=',
                'outerHTML\s*=',
            ];

            foreach ($js_threats as $pattern) {
                if (preg_match('/' . $pattern . '/i', $content)) {
                    $threats_found[] = 'Suspicious JavaScript code detected';
                    break;
                }
            }
        }

        return [
            'safe' => empty($threats_found),
            'message' => empty($threats_found) 
                ? $this->get_translated_text('File passed security scan.')
                : $this->get_translated_text('Security threat detected: ') . implode(', ', $threats_found)
        ];
    }

    /**
     * Check URL accessibility
     *
     * @param string $url URL to check
     * @return array Accessibility result
     */
    private function check_url_accessibility(string $url): array {
        // Use WordPress HTTP API for checking
        $response = wp_remote_head($url, [
            'timeout' => 10,
            'redirection' => 3,
            'user-agent' => 'ViraStore/1.0.0 File Validator'
        ]);

        if (is_wp_error($response)) {
            return [
                'accessible' => false,
                'message' => $response->get_error_message(),
                'status_code' => 0
            ];
        }

        $status_code = wp_remote_retrieve_response_code($response);
        $accessible = $status_code >= 200 && $status_code < 400;

        return [
            'accessible' => $accessible,
            'message' => $accessible ? __('URL is accessible.', 'vira-store') : sprintf(__('HTTP %d response.', 'vira-store'), $status_code),
            'status_code' => $status_code,
            'headers' => wp_remote_retrieve_headers($response)
        ];
    }

    /**
     * Get user licenses for product
     *
     * @param int $user_id User ID
     * @param int $product_id Product ID
     * @return array Array of license data
     */
    private function get_user_licenses(int $user_id, int $product_id): array {
        // Check if license class is available
        if (!class_exists('VRSTORE_License')) {
            return [];
        }

        $licenses = [];

        // Use modern table-based license system only
        global $wpdb;
        $licenses_table = $wpdb->prefix . 'vrstore_licenses';
        
        if ($wpdb->get_var("SHOW TABLES LIKE '$licenses_table'") === $licenses_table) {
            $db_licenses = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM $licenses_table WHERE customer_email = (SELECT user_email FROM {$wpdb->users} WHERE ID = %d) AND product_id = %d AND status = 'active'",
                $user_id,
                $product_id
            ), ARRAY_A);

            foreach ($db_licenses as $db_license) {
                $licenses[] = [
                    'id' => $db_license['id'],
                    'key' => $db_license['license_key'],
                    'status' => $db_license['status'],
                    'expiry_date' => $db_license['expires_at'] ?? '',
                    'activation_limit' => $db_license['activation_limit'],
                    'activation_count' => $db_license['activation_count'],
                    'product' => ['id' => $db_license['product_id']],
                    'user' => ['id' => $user_id]
                ];
            }
        }

        return $licenses;
    }

    /**
     * Check if license is valid for file access
     *
     * @param array $license License data
     * @param string $file_url File URL
     * @return bool Whether license allows file access
     */
    private function is_license_valid_for_file_access(array $license, string $file_url): bool {
        // Check license status
        if ($license['status'] !== 'active') {
            return false;
        }

        // Check expiry
        if (!empty($license['expiry_date']) && strtotime($license['expiry_date']) < time()) {
            return false;
        }

        // Apply filters for custom license validation
        return apply_filters('vrstore_license_allows_file_access', true, $license, $file_url);
    }

    /**
     * Check download limits
     *
     * @param array $license License data
     * @param int $user_id User ID
     * @return bool Whether user is within download limits
     */
    private function check_download_limits(array $license, int $user_id): bool {
        if (!$this->security_settings['enable_download_logging']) {
            return true; // Skip limit check if logging is disabled
        }

        $max_daily_downloads = $this->security_settings['max_daily_downloads'];
        if ($max_daily_downloads <= 0) {
            return true; // No limit set
        }

        // Count downloads in the last 24 hours
        global $wpdb;
        $download_logs_table = $wpdb->prefix . 'vrstore_download_logs';
        
        $daily_downloads = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $download_logs_table 
             WHERE customer_email = (SELECT user_email FROM {$wpdb->users} WHERE ID = %d) 
             AND created_at >= %s",
            $user_id,
            date('Y-m-d H:i:s', time() - DAY_IN_SECONDS)
        ));

        return $daily_downloads < $max_daily_downloads;
    }

    /**
     * Record download
     *
     * @param array $license License data
     * @param int $user_id User ID
     * @param string $file_url File URL
     */
    private function record_download(array $license, int $user_id, string $file_url): void {
        if (!$this->security_settings['enable_download_logging']) {
            return;
        }

        global $wpdb;
        $download_logs_table = $wpdb->prefix . 'vrstore_download_logs';

        $user = get_user_by('id', $user_id);
        $user_email = $user ? $user->user_email : '';

        $wpdb->insert(
            $download_logs_table,
            [
                'order_id' => 0, // Will be updated if we can find the order
                'product_id' => $license['product']['id'] ?? 0,
                'customer_email' => $user_email,
                'file_name' => basename($file_url),
                'file_url' => $file_url,
                'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
                'license_key' => $license['key'] ?? '',
                'download_method' => 'secure_token',
                'created_at' => current_time('mysql')
            ],
            [
                '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s'
            ]
        );
    }

    /**
     * Resolve file path from various possible formats
     *
     * @param array $file File data array
     * @return string Resolved file path
     */
    private function resolve_file_path(array $file): string {
        // Get the file URL from various possible keys
        $file_url = $file['url'] ?? $file['file'] ?? '';
        
        if (empty($file_url)) {
            return '';
        }
        
        // If it's already a file path, return it
        if (strpos($file_url, 'http') !== 0 && file_exists($file_url)) {
            return $file_url;
        }
        
        // If it's an attachment ID, get the file path
        if (is_numeric($file_url)) {
            $attachment_path = get_attached_file($file_url);
            if ($attachment_path && file_exists($attachment_path)) {
                return $attachment_path;
            }
        }
        
        // Convert URL to file path
        $upload_dir = wp_upload_dir();
        
        // Handle different URL formats
        $possible_paths = [];
        
        // Standard URL to path conversion
        $possible_paths[] = str_replace($upload_dir['baseurl'], $upload_dir['basedir'], $file_url);
        
        // Handle URLs with different protocols
        $possible_paths[] = str_replace('https://', 'http://', $file_url);
        $possible_paths[] = str_replace('http://', 'https://', $file_url);
        
        // Handle relative URLs
        if (strpos($file_url, '/') === 0) {
            $possible_paths[] = ABSPATH . ltrim($file_url, '/');
            $possible_paths[] = $upload_dir['basedir'] . $file_url;
        }
        
        // Try attachment URL to post ID conversion
        $attachment_id = attachment_url_to_postid($file_url);
        if ($attachment_id) {
            $attachment_path = get_attached_file($attachment_id);
            if ($attachment_path) {
                $possible_paths[] = $attachment_path;
            }
        }
        
        // Return the first existing file path
        foreach ($possible_paths as $path) {
            if (!empty($path) && file_exists($path)) {
                return $path;
            }
        }
        
        // If no path found, return the original converted path for error reporting
        return str_replace($upload_dir['baseurl'], $upload_dir['basedir'], $file_url);
    }
    
    /**
     * Serve internal file securely
     *
     * @param array $file File data
     * @param int $product_id Product ID
     * @param int $user_id User ID
     */
    private function serve_internal_file(array $file, int $product_id, int $user_id): void {
        // Better file path resolution with multiple fallback methods
        $file_path = $this->resolve_file_path($file);

        if (!file_exists($file_path)) {
            // Log the attempted file path for debugging
            VRSTORE_Security::log_security_event(
                'File not found during download: ' . $file_path,
                'warning',
                [
                    'file_data' => $file,
                    'product_id' => $product_id,
                    'user_id' => $user_id,
                    'attempted_path' => $file_path
                ]
            );
            wp_die(__('File not found on server.', 'vira-store'), __('Not Found', 'vira-store'), ['response' => 404]);
        }

        // Security headers
        $this->set_download_headers($file);

        // Serve file
        if ($this->security_settings['enable_file_encryption'] && strpos($file_path, '.encrypted') !== false) {
            $this->serve_encrypted_file($file_path, $file);
        } else {
            $this->serve_regular_file($file_path, $file);
        }
    }

    /**
     * Serve external file (redirect with validation)
     *
     * @param array $file File data
     * @param int $product_id Product ID
     * @param int $user_id User ID
     */
    private function serve_external_file(array $file, int $product_id, int $user_id): void {
        // Get the actual file URL (support both 'url' and 'file' keys)
        $file_url = $file['url'] ?? $file['file'] ?? '';
        
        if (empty($file_url)) {
            wp_die(__('Invalid file URL.', 'vira-store'), __('Access Denied', 'vira-store'), ['response' => 403]);
        }
        
        // Validate URL one more time before redirecting
        $validation = $this->validate_external_url($file_url, $product_id);
        
        if (!$validation['is_valid'] && !$validation['valid']) { // Check both keys for backward compatibility
            wp_die($validation['message'], __('Access Denied', 'vira-store'), ['response' => 403]);
        }

        // Log external file access
        VRSTORE_Security::log_security_event(
            'External file access: ' . $file_url,
            'info',
            [
                'product_id' => $product_id,
                'user_id' => $user_id,
                'file_name' => $file['name'] ?? 'Unknown',
                'file_url' => $file_url
            ]
        );

        // Redirect to external URL
        wp_redirect($file_url);
        exit;
    }

    /**
     * Set download headers
     *
     * @param array $file File data
     */
    private function set_download_headers(array $file): void {
        // Prevent caching
        header('Cache-Control: no-cache, no-store, must-revalidate');
        header('Pragma: no-cache');
        header('Expires: 0');

        // Security headers
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: DENY');
        header('X-XSS-Protection: 1; mode=block');

        // Content disposition
        header('Content-Disposition: attachment; filename="' . sanitize_file_name($file['name']) . '"');
        
        // Content type
        $mime_type = get_allowed_mime_types();
        $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        
        foreach ($mime_type as $ext => $mime) {
            if (strpos($ext, $file_ext) !== false) {
                header('Content-Type: ' . $mime);
                break;
            }
        }
    }

    /**
     * Serve regular file
     *
     * @param string $file_path File path
     * @param array $file File data
     */
    private function serve_regular_file(string $file_path, array $file): void {
        header('Content-Length: ' . filesize($file_path));
        
        // Use readfile for better memory management
        readfile($file_path);
        exit;
    }

    /**
     * Serve encrypted file
     *
     * @param string $file_path Encrypted file path
     * @param array $file File data
     */
    private function serve_encrypted_file(string $file_path, array $file): void {
        // Decrypt file content
        $encrypted_content = file_get_contents($file_path);
        $decrypted_content = VRSTORE_Security::decrypt_data($encrypted_content);

        header('Content-Length: ' . strlen($decrypted_content));
        
        echo $decrypted_content;
        exit;
    }

    /**
     * Encrypt uploaded file
     *
     * @param string $file_path Original file path
     * @return string|false Encrypted file path or false on failure
     */
    private function encrypt_uploaded_file(string $file_path) {
        try {
            $content = file_get_contents($file_path);
            $encrypted_content = VRSTORE_Security::encrypt_data($content);
            
            $encrypted_path = $file_path . '.encrypted';
            file_put_contents($encrypted_path, $encrypted_content);
            
            // Remove original file
            unlink($file_path);
            
            return $encrypted_path;
        } catch (Exception $e) {
            VRSTORE_Security::log_security_event(
                'File encryption failed: ' . $e->getMessage(),
                'error',
                ['file_path' => $file_path]
            );
            return false;
        }
    }

    /**
     * Get file security status
     *
     * @param array $file File data
     * @param int $product_id Product ID
     * @return array Security status information
     */
    public function get_file_security_status(array $file, int $product_id): array {
        $status = [
            'level' => 'success',
            'message' => __('File is secure', 'vira-store'),
            'checks' => []
        ];

        if ($file['type'] === 'upload') {
            // Internal file checks
            $file_path = str_replace(wp_upload_dir()['baseurl'], wp_upload_dir()['basedir'], $file['url']);
            
            $status['checks']['file_exists'] = [
                'status' => file_exists($file_path),
                'message' => file_exists($file_path) ? __('File exists on server', 'vira-store') : __('File not found on server', 'vira-store')
            ];

            $status['checks']['file_permissions'] = [
                'status' => is_readable($file_path),
                'message' => is_readable($file_path) ? __('File has correct permissions', 'vira-store') : __('File permission issues detected', 'vira-store')
            ];

            if ($this->security_settings['enable_file_encryption']) {
                $is_encrypted = strpos($file_path, '.encrypted') !== false;
                $status['checks']['encryption'] = [
                    'status' => $is_encrypted,
                    'message' => $is_encrypted ? $this->get_translated_text('File is encrypted') : $this->get_translated_text('File is not encrypted')
                ];
            }
        } else {
            // External URL checks
            $url_validation = $this->validate_external_url($file['url'], $product_id);
            $status['checks']['url_validation'] = [
                'status' => $url_validation['valid'],
                'message' => $url_validation['message']
            ];

            if ($url_validation['valid'] && isset($url_validation['accessibility'])) {
                $status['checks']['url_accessibility'] = [
                    'status' => $url_validation['accessibility']['accessible'],
                    'message' => $url_validation['accessibility']['message']
                ];
            }
        }

        // Determine overall security level
        $failed_checks = array_filter($status['checks'], function($check) {
            return !$check['status'];
        });

        if (!empty($failed_checks)) {
            $status['level'] = 'warning';
            $status['message'] = sprintf($this->get_translated_text('%d security check(s) failed'), count($failed_checks));
        }

        return $status;
    }

    /**
     * AJAX handler for file upload validation
     */
    public function ajax_validate_file_upload(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_file_validation')) {
            wp_die('Security check failed.');
        }

        // Check capabilities
        if (!current_user_can('edit_posts')) {
            wp_die('Insufficient permissions.');
        }

        $attachment_id = absint($_POST['attachment_id'] ?? 0);
        $product_id = absint($_POST['product_id'] ?? 0);

        if (!$attachment_id) {
            wp_send_json_error(['message' => __('Invalid attachment ID.', 'vira-store')]);
        }

        $attachment = get_post($attachment_id);
        if (!$attachment || $attachment->post_type !== 'attachment') {
            wp_send_json_error(['message' => __('Attachment not found.', 'vira-store')]);
        }

        $file_url = wp_get_attachment_url($attachment_id);
        $file_path = get_attached_file($attachment_id);

        $file_data = [
            'name' => $attachment->post_title,
            'url' => $file_url,
            'type' => 'upload'
        ];

        // Run security checks
        $security_status = $this->get_file_security_status($file_data, $product_id);

        wp_send_json_success([
            'security_status' => $security_status,
            'file_info' => [
                'name' => $file_data['name'],
                'size' => filesize($file_path),
                'type' => $attachment->post_mime_type,
            ]
        ]);
    }

    /**
     * AJAX handler for external URL validation
     */
    public function ajax_validate_external_url(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_file_validation')) {
            wp_die('Security check failed.');
        }

        // Check capabilities
        if (!current_user_can('edit_posts')) {
            wp_die('Insufficient permissions.');
        }

        $url = esc_url_raw($_POST['url'] ?? '');
        $product_id = absint($_POST['product_id'] ?? 0);

        if (empty($url)) {
            wp_send_json_error(['message' => __('URL is required.', 'vira-store')]);
        }

        $validation_result = $this->validate_external_url($url, $product_id);

        if ($validation_result['valid']) {
            wp_send_json_success($validation_result);
        } else {
            wp_send_json_error($validation_result);
        }
    }

    /**
     * Cleanup temporary files
     */
    public function cleanup_temp_files(): void {
        // Clean up old encrypted temp files
        $upload_dir = wp_upload_dir();
        $temp_files = glob($upload_dir['basedir'] . '/*.temp.*');

        foreach ($temp_files as $temp_file) {
            if (filemtime($temp_file) < (time() - DAY_IN_SECONDS)) {
                unlink($temp_file);
            }
        }
    }

    /**
     * Generate secure download URL
     *
     * @param int $product_id Product ID
     * @param int $file_index File index
     * @param int $user_id User ID
     * @param int $expires Expiration time (optional)
     * @return string Secure download URL
     */
    public function generate_secure_download_url(int $product_id, int $file_index, int $user_id, int $expires = 0): string {
        $token = $this->generate_download_token($product_id, $file_index, $user_id, $expires);
        
        return add_query_arg([
            'vrstore_secure_download' => $token
        ], home_url());
    }

    /**
     * Validate file metadata and generate security report
     *
     * @param array $files Array of file data
     * @param int $product_id Product ID
     * @return array Security report for all files
     */
    public function validate_files_security(array $files, int $product_id): array {
        $report = [
            'overall_status' => 'success',
            'total_files' => count($files),
            'secure_files' => 0,
            'warning_files' => 0,
            'error_files' => 0,
            'file_reports' => []
        ];

        foreach ($files as $index => $file) {
            $file_status = $this->get_file_security_status($file, $product_id);
            $report['file_reports'][$index] = $file_status;

            switch ($file_status['level']) {
                case 'success':
                    $report['secure_files']++;
                    break;
                case 'warning':
                    $report['warning_files']++;
                    break;
                case 'error':
                    $report['error_files']++;
                    break;
            }
        }

        // Determine overall status
        if ($report['error_files'] > 0) {
            $report['overall_status'] = 'error';
        } elseif ($report['warning_files'] > 0) {
            $report['overall_status'] = 'warning';
        }

        return $report;
    }

    /**
     * Get security recommendations for file configuration
     *
     * @param array $files Array of file data
     * @return array Security recommendations
     */
    public function get_security_recommendations(array $files): array {
        $recommendations = [];

        foreach ($files as $file) {
            if ($file['type'] === 'url') {
                $parsed_url = wp_parse_url($file['url']);
                
                // Recommend HTTPS
                if ($parsed_url['scheme'] === 'http') {
                    $recommendations[] = sprintf(
                        __('Consider using HTTPS for external URL: %s', 'vira-store'),
                        $file['name']
                    );
                }

                // Check for suspicious domains
                if (in_array($parsed_url['host'], ['bit.ly', 'tinyurl.com', 't.co'], true)) {
                    $recommendations[] = sprintf(
                        __('URL shortener detected for %s. Consider using direct URLs for better security.', 'vira-store'),
                        $file['name']
                    );
                }
            }
        }

        // General recommendations
        if (count($files) > 5) {
            $recommendations[] = __('Consider organizing files into categories or using a file management system for better organization.', 'vira-store');
        }

        if (!$this->security_settings['enable_file_encryption']) {
            $recommendations[] = __('Enable file encryption in settings for enhanced security of uploaded files.', 'vira-store');
        }

        return $recommendations;
    }

    /**
     * Protect direct file access for non-customers
     */
    public function protect_direct_file_access(): void {
        // Only run on frontend
        if (is_admin() || wp_doing_ajax() || wp_doing_cron()) {
            return;
        }

        // Check if this is a direct file access attempt
        $request_uri = $_SERVER['REQUEST_URI'] ?? '';
        $upload_dir = wp_upload_dir();
        $upload_url_path = str_replace(home_url(), '', $upload_dir['baseurl']);

        // Check if accessing a file in the uploads directory
        if (strpos($request_uri, $upload_url_path) === false) {
            return;
        }

        // Check if this is a product file
        $file_url = home_url() . $request_uri;
        $product_id = $this->get_product_id_by_file_url($file_url);
        
        if (!$product_id) {
            return; // Not a product file
        }

        // Allow access for administrators
        if (current_user_can('manage_options')) {
            return;
        }

        // Check if user has valid license for this product
        $user_id = get_current_user_id();
        if (!$user_id) {
            $this->block_file_access(__('You must be logged in to access this file.', 'vira-store'));
            return;
        }

        // Check license access
        $can_access = apply_filters('vrstore_can_access_file', true, $product_id, $user_id, $file_url);
        
        if (!$can_access) {
            $this->block_file_access(__('You do not have permission to access this file. Please purchase the product first.', 'vira-store'));
            return;
        }

        // Log authorized direct access
        VRSTORE_Security::log_security_event(
            'Direct file access authorized: ' . basename($file_url),
            'info',
            [
                'user_id' => $user_id,
                'product_id' => $product_id,
                'file_url' => $file_url,
                'access_method' => 'direct'
            ]
        );
    }

    /**
     * Get product ID by file URL
     *
     * @param string $file_url File URL to check
     * @return int|false Product ID or false if not found
     */
    private function get_product_id_by_file_url(string $file_url) {
        global $wpdb;
        
        // Query all products to find the one containing this file
        $products = get_posts([
            'post_type' => 'vrstore_product',
            'posts_per_page' => -1,
            'post_status' => 'publish',
            'meta_query' => [
                [
                    'key' => '_vrstore_product_files',
                    'value' => $file_url,
                    'compare' => 'LIKE'
                ]
            ]
        ]);

        foreach ($products as $product) {
            $product_files = get_post_meta($product->ID, '_vrstore_product_files', true);
            if (is_array($product_files)) {
                foreach ($product_files as $file) {
                    if (isset($file['url']) && $file['url'] === $file_url) {
                        return $product->ID;
                    }
                }
            }
        }

        return false;
    }

    /**
     * Block file access with appropriate response
     *
     * @param string $message Error message
     */
    private function block_file_access(string $message): void {
        // Log unauthorized access attempt
        VRSTORE_Security::log_security_event(
            'Unauthorized file access blocked: ' . ($_SERVER['REQUEST_URI'] ?? ''),
            'warning',
            [
                'user_id' => get_current_user_id(),
                'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
                'request_uri' => $_SERVER['REQUEST_URI'] ?? ''
            ]
        );

        // Send 403 Forbidden response
        status_header(403);
        wp_die($message, __('Access Denied', 'vira-store'), ['response' => 403]);
    }

    /**
     * Filter product files display for non-customers
     *
     * @param array $files Product files
     * @param int $product_id Product ID
     * @param int $user_id User ID (0 for non-logged-in users)
     * @return array Filtered files
     */
    public function filter_product_files_display(array $files, int $product_id, int $user_id = 0): array {
        // Always show files to administrators
        if (current_user_can('manage_options')) {
            return $files;
        }

        // If no user ID provided, get current user
        if (!$user_id) {
            $user_id = get_current_user_id();
        }

        // For non-logged-in users, hide all files except YouTube videos
        if (!$user_id) {
            return $this->filter_files_for_non_customers($files);
        }

        // Check if user has valid license first
        $user_licenses = $this->get_user_licenses($user_id, $product_id);
        
        if (!empty($user_licenses)) {
            // User has valid license, show all files
            return $files;
        }

        // If no license found, check if user has completed orders for this product
        // This handles cases where license creation failed but order was completed
        if ($this->user_has_completed_order($user_id, $product_id)) {
            // User has completed order, show all files
            return $files;
        }

        // User has no access, filter files
        return $this->filter_files_for_non_customers($files);
    }

    /**
     * Filter files for non-customers (show only YouTube videos and hide others)
     *
     * @param array $files Product files
     * @return array Filtered files
     */
    private function filter_files_for_non_customers(array $files): array {
        $filtered_files = [];

        foreach ($files as $file) {
            // Get file URL for checking
            $file_url = $file['url'] ?? $file['file'] ?? '';
            
            // Allow YouTube videos
            if ($this->is_youtube_url($file_url)) {
                $filtered_files[] = $file;
                continue;
            }

            // Determine file type for better messaging
            $file_type_label = __('Protected File', 'vira-store');
            if (strpos($file_url, 'drive.google.com') !== false) {
                $file_type_label = __('Google Drive File', 'vira-store');
            } elseif (strpos($file_url, 'dropbox.com') !== false) {
                $file_type_label = __('Dropbox File', 'vira-store');
            } elseif (strpos($file_url, 'http') === 0) {
                $file_type_label = __('External File', 'vira-store');
            } elseif (!empty($file_url)) {
                $file_type_label = __('Download File', 'vira-store');
            }

            // Hide other files but show informative placeholder
            $filtered_files[] = [
                'name' => $file['name'] ?? $file_type_label,
                'url' => '#',
                'type' => 'protected',
                'size' => $file['size'] ?? 0,
                'protected' => true,
                'original_type' => $file['type'] ?? '',
                'message' => $this->get_translated_text('This file is available after purchase.')
            ];
        }

        return $filtered_files;
    }

    /**
     * Check if URL is a YouTube URL
     *
     * @param string $url URL to check
     * @return bool True if YouTube URL
     */
    private function is_youtube_url(string $url): bool {
        $youtube_domains = [
            'youtube.com',
            'www.youtube.com',
            'youtu.be',
            'm.youtube.com'
        ];

        $parsed_url = wp_parse_url($url);
        $host = $parsed_url['host'] ?? '';

        return in_array(strtolower($host), $youtube_domains, true);
    }

    /**
     * Check if user has completed order for product
     *
     * @param int $user_id User ID
     * @param int $product_id Product ID
     * @return bool True if user has completed order
     */
    private function user_has_completed_order(int $user_id, int $product_id): bool {
        global $wpdb;
        $orders_table = $wpdb->prefix . 'vrstore_orders';
        
        // Check if orders table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$orders_table'") !== $orders_table) {
            return false;
        }
        
        // Get user email
        $user = get_userdata($user_id);
        if (!$user) {
            return false;
        }
        
        // Check for completed orders
        $completed_orders = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $orders_table 
             WHERE customer_email = %s 
             AND product_id = %d 
             AND payment_status = 'completed' 
             AND order_status = 'completed'",
            $user->user_email,
            $product_id
        ));
        
        return $completed_orders > 0;
    }

    /**
     * Setup direct access protection for uploads directory
     *
     * @since 1.0.0
     */
    public function setup_direct_access_protection(): void {
        if (!$this->security_settings['enable_direct_access_protection']) {
            return;
        }

        // Generate .htaccess rules for uploads directory
        $this->generate_htaccess_protection();
    }

    /**
     * Generate .htaccess rules to protect direct file access
     *
     * @since 1.0.0
     */
    private function generate_htaccess_protection(): void {
        $upload_dir = wp_upload_dir();
        $htaccess_file = trailingslashit($upload_dir['basedir']) . '.htaccess';

        // Create protected file extensions pattern
        $extensions = implode('|', array_map('preg_quote', $this->protected_file_types));
        
        $htaccess_rules = "# ViraStore Enhanced File Protection Rules\n";
        $htaccess_rules .= "# Generated on " . date('Y-m-d H:i:s') . "\n";
        $htaccess_rules .= "# Protects ZIP, RAR, PDF and other sensitive files from direct access\n\n";
        
        // Enhanced protection for specific file types with multiple layers
        $htaccess_rules .= "# Primary protection - Block direct access to protected file types\n";
        $htaccess_rules .= "<FilesMatch \"\.({$extensions})$\">\n";
        $htaccess_rules .= "    <RequireAll>\n";
        $htaccess_rules .= "        Require all denied\n";
        $htaccess_rules .= "    </RequireAll>\n";
        $htaccess_rules .= "</FilesMatch>\n\n";
        
        // Additional protection for archives if enabled
        if ($this->security_settings['enable_enhanced_archive_protection']) {
            $htaccess_rules .= "# Enhanced protection for archive files\n";
            $htaccess_rules .= "<FilesMatch \"\.(zip|rar|7z|tar|gz|bz2)$\">\n";
            $htaccess_rules .= "    <RequireAll>\n";
            $htaccess_rules .= "        Require all denied\n";
            $htaccess_rules .= "    </RequireAll>\n";
            $htaccess_rules .= "</FilesMatch>\n\n";
        }
        
        // Additional protection for documents if enabled
        if ($this->security_settings['enable_enhanced_document_protection']) {
            $htaccess_rules .= "# Enhanced protection for document files\n";
            $htaccess_rules .= "<FilesMatch \"\.(pdf|doc|docx|xls|xlsx|ppt|pptx)$\">\n";
            $htaccess_rules .= "    <RequireAll>\n";
            $htaccess_rules .= "        Require all denied\n";
            $htaccess_rules .= "    </RequireAll>\n";
            $htaccess_rules .= "</FilesMatch>\n\n";
        }
        
        // Block suspicious user agents if enabled
        if ($this->security_settings['block_suspicious_user_agents']) {
            $htaccess_rules .= "# Block suspicious user agents from accessing protected files\n";
            $htaccess_rules .= "<FilesMatch \"\.({$extensions})$\">\n";
            $htaccess_rules .= "    SetEnvIfNoCase User-Agent \"(bot|crawler|spider|scraper|wget|curl|download|manager)\" block_ua\n";
            $htaccess_rules .= "    <RequireAll>\n";
            $htaccess_rules .= "        Require all denied\n";
            $htaccess_rules .= "        Require not env block_ua\n";
            $htaccess_rules .= "    </RequireAll>\n";
            $htaccess_rules .= "</FilesMatch>\n\n";
        }
        
        // Prevent hotlinking if enabled
        if ($this->security_settings['enable_hotlink_protection']) {
            $htaccess_rules .= "# Prevent hotlinking of protected files\n";
            $htaccess_rules .= "RewriteEngine On\n";
            $htaccess_rules .= "RewriteCond %{HTTP_REFERER} !^$\n";
            $htaccess_rules .= "RewriteCond %{HTTP_REFERER} !^https?://(www\.)?{$_SERVER['HTTP_HOST']} [NC]\n";
            $htaccess_rules .= "RewriteCond %{REQUEST_URI} \.({$extensions})$ [NC]\n";
            $htaccess_rules .= "RewriteRule .* - [F,L]\n\n";
        }
        
        // Redirect protected file requests to secure download handler
        $htaccess_rules .= "# Redirect protected file access to secure download system\n";
        $htaccess_rules .= "RewriteCond %{REQUEST_FILENAME} -f\n";
        $htaccess_rules .= "RewriteCond %{REQUEST_URI} \.({$extensions})$ [NC]\n";
        $htaccess_rules .= "RewriteCond %{QUERY_STRING} !vrstore_token= [NC]\n";
        $htaccess_rules .= "RewriteRule ^(.*)$ " . home_url('/vrstore-secure-download/') . "?file=$1&blocked=1 [R=302,L]\n\n";
        
        // Enhanced security headers for all files
        $htaccess_rules .= "# Enhanced security headers\n";
        $htaccess_rules .= "<IfModule mod_headers.c>\n";
        $htaccess_rules .= "    # Prevent MIME type sniffing\n";
        $htaccess_rules .= "    Header always set X-Content-Type-Options nosniff\n";
        $htaccess_rules .= "    # Prevent framing\n";
        $htaccess_rules .= "    Header always set X-Frame-Options DENY\n";
        $htaccess_rules .= "    # Control referrer information\n";
        $htaccess_rules .= "    Header always set Referrer-Policy strict-origin-when-cross-origin\n";
        $htaccess_rules .= "    # Prevent XSS attacks\n";
        $htaccess_rules .= "    Header always set X-XSS-Protection \"1; mode=block\"\n";
        $htaccess_rules .= "    # Content Security Policy for downloads\n";
        $htaccess_rules .= "    Header always set Content-Security-Policy \"default-src 'self'; script-src 'none'; object-src 'none';\"\n";
        $htaccess_rules .= "</IfModule>\n\n";
        
        // Block direct access to common sensitive file patterns
        $htaccess_rules .= "# Block access to sensitive file patterns\n";
        $htaccess_rules .= "<FilesMatch \"(^#.*#|\.#.*|.*~|\.bak|\.backup|\.old|\.orig|\.save|\.swp|\.tmp)$\">\n";
        $htaccess_rules .= "    <RequireAll>\n";
        $htaccess_rules .= "        Require all denied\n";
        $htaccess_rules .= "    </RequireAll>\n";
        $htaccess_rules .= "</FilesMatch>\n\n";
        
        // Rate limiting for file access attempts
        $htaccess_rules .= "# Rate limiting for file access (if mod_evasive is available)\n";
        $htaccess_rules .= "<IfModule mod_evasive24.c>\n";
        $htaccess_rules .= "    DOSHashTableSize    2048\n";
        $htaccess_rules .= "    DOSPageCount        5\n";
        $htaccess_rules .= "    DOSPageInterval     1\n";
        $htaccess_rules .= "    DOSSiteCount        50\n";
        $htaccess_rules .= "    DOSSiteInterval     1\n";
        $htaccess_rules .= "    DOSBlockingPeriod   600\n";
        $htaccess_rules .= "</IfModule>\n\n";
        
        $htaccess_rules .= "# End ViraStore Enhanced File Protection Rules\n";

        // Read existing .htaccess content
        $existing_content = '';
        if (file_exists($htaccess_file)) {
            $existing_content = file_get_contents($htaccess_file);
            
            // Remove old ViraStore rules if they exist
            $existing_content = preg_replace(
                '/# ViraStore.*?File Protection Rules.*?# End ViraStore.*?File Protection Rules\n/s',
                '',
                $existing_content
            );
        }

        // Combine new rules with existing content
        $new_content = $htaccess_rules . $existing_content;

        // Write the .htaccess file with proper permissions
        if (!file_put_contents($htaccess_file, $new_content)) {
            error_log('ViraStore: Failed to write enhanced .htaccess protection rules to ' . $htaccess_file);
        } else {
            // Set proper file permissions
            chmod($htaccess_file, 0644);
            error_log('ViraStore: Successfully updated enhanced .htaccess protection rules');
            
            // Log the protection update
            VRSTORE_Security::log_security_event(
                'Enhanced file protection rules updated',
                'info',
                [
                    'protected_extensions' => $this->protected_file_types,
                    'htaccess_file' => $htaccess_file,
                    'timestamp' => current_time('mysql')
                ]
            );
        }
    }

    /**
     * Add rewrite rules for secure downloads
     *
     * @since 1.0.0
     */
    public function add_rewrite_rules(): void {
        // Main secure download endpoint
        add_rewrite_rule(
            '^vrstore-secure-download/?$',
            'index.php?vrstore_secure_download=1',
            'top'
        );
        
        // Token-based download endpoint
        add_rewrite_rule(
            '^vrstore-download/([^/]+)/?$',
            'index.php?vrstore_download_token=$matches[1]',
            'top'
        );
        
        // Direct file protection - intercept protected file requests
        $extensions = implode('|', array_map('preg_quote', $this->protected_file_types));
        add_rewrite_rule(
            '^wp-content/uploads/(.+\.(' . $extensions . '))$',
            'index.php?vrstore_protected_file=$matches[1]',
            'top'
        );
        
        // Flush rewrite rules if they haven't been flushed yet
        if (get_option('virastore_rewrite_rules_flushed') !== '1') {
            flush_rewrite_rules();
            update_option('virastore_rewrite_rules_flushed', '1');
        }
    }

    /**
     * Add query vars for secure downloads
     *
     * @since 1.0.0
     * @param array $vars Query vars
     * @return array Modified query vars
     */
    public function add_query_vars(array $vars): array {
        $vars[] = 'vrstore_secure_download';
        $vars[] = 'vrstore_download_token';
        $vars[] = 'vrstore_protected_file';
        return $vars;
    }

    /**
     * Handle protected file requests
     *
     * @since 1.0.0
     */
    public function handle_protected_file_request(): void {
        if (!$this->security_settings['enable_direct_access_protection']) {
            return;
        }

        // Check if this is a direct file access attempt
        $request_uri = $_SERVER['REQUEST_URI'] ?? '';
        $upload_dir = wp_upload_dir();
        $upload_url_path = wp_parse_url($upload_dir['baseurl'], PHP_URL_PATH);

        if (strpos($request_uri, $upload_url_path) === 0) {
            $file_extension = strtolower(pathinfo($request_uri, PATHINFO_EXTENSION));
            
            if (in_array($file_extension, $this->protected_file_types, true)) {
                // Log the unauthorized access attempt
                VRSTORE_Security::log_security_event(
                    'Unauthorized direct file access attempt',
                    'warning',
                    [
                        'file_path' => $request_uri,
                        'user_ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
                        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
                        'referer' => $_SERVER['HTTP_REFERER'] ?? 'none'
                    ]
                );

                // Redirect to secure download or show access denied
                $this->handle_unauthorized_access($request_uri);
            }
        }
    }

    /**
     * Handle secure download requests
     *
     * @since 1.0.0
     */
    public function handle_secure_download_request(): void {
        $secure_download = get_query_var('vrstore_secure_download');
        $download_token = get_query_var('vrstore_download_token');
        $protected_file = get_query_var('vrstore_protected_file');

        if ($secure_download || $download_token || $protected_file) {
            if ($download_token) {
                // Handle token-based download
                $this->process_secure_download($download_token);
            } elseif ($protected_file) {
                // Handle protected file access through rewrite
                $this->process_protected_file_access($protected_file);
            } else {
                // Handle file parameter download
                $file = isset($_GET['file']) ? sanitize_text_field($_GET['file']) : '';
                if ($file) {
                    $this->process_file_download($file);
                }
            }
        }
    }

    /**
     * Process protected file access with validation middleware
     *
     * @since 1.0.0
     * @param string $file_path Relative file path from uploads directory
     */
    private function process_protected_file_access(string $file_path): void {
        // Sanitize and validate file path
        $file_path = ltrim($file_path, '/');
        $upload_dir = wp_upload_dir();
        $full_path = trailingslashit($upload_dir['basedir']) . $file_path;

        // Security validation middleware
        if (!$this->validate_file_access($full_path, $file_path)) {
            $this->handle_unauthorized_access($file_path);
            return;
        }

        // Check file extension is protected
        $file_extension = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
        if (!in_array($file_extension, $this->protected_file_types, true)) {
            // Not a protected file type, allow normal access
            $this->serve_file_directly($full_path);
            return;
        }

        // Apply access control for protected files
        $access_granted = $this->check_file_access_permissions($file_path, $full_path);
        
        if ($access_granted) {
            $this->serve_protected_file($full_path, $file_path);
        } else {
            $this->handle_unauthorized_access($file_path);
        }
    }

    /**
     * Validate file access with security middleware
     *
     * @since 1.0.0
     * @param string $full_path Full file system path
     * @param string $relative_path Relative path from uploads
     * @return bool True if access is valid
     */
    private function validate_file_access(string $full_path, string $relative_path): bool {
        // Check if file exists and is readable
        if (!file_exists($full_path) || !is_file($full_path) || !is_readable($full_path)) {
            error_log("ViraStore: File access denied - file not found or not readable: {$full_path}");
            return false;
        }

        // Prevent directory traversal attacks
        $upload_dir = wp_upload_dir();
        $real_upload_path = realpath($upload_dir['basedir']);
        $real_file_path = realpath($full_path);
        
        if (!$real_file_path || strpos($real_file_path, $real_upload_path) !== 0) {
            error_log("ViraStore: File access denied - directory traversal attempt: {$relative_path}");
            return false;
        }

        // Check file size limits (prevent serving extremely large files)
        $max_file_size = apply_filters('vrstore_max_protected_file_size', 100 * 1024 * 1024); // 100MB default
        if (filesize($full_path) > $max_file_size) {
            error_log("ViraStore: File access denied - file too large: {$relative_path}");
            return false;
        }

        // Check for malicious file patterns
        $dangerous_patterns = [
            '/\.php$/i',
            '/\.phtml$/i',
            '/\.php\d$/i',
            '/\.htaccess$/i',
            '/\.htpasswd$/i',
            '/web\.config$/i'
        ];

        foreach ($dangerous_patterns as $pattern) {
            if (preg_match($pattern, $relative_path)) {
                error_log("ViraStore: File access denied - dangerous file type: {$relative_path}");
                return false;
            }
        }

        return true;
    }

    /**
     * Process file download with authentication
     *
     * @since 1.0.0
     * @param string $file_path Relative file path
     */
    private function process_file_download(string $file_path): void {
        // Sanitize and validate file path
        $file_path = ltrim($file_path, '/');
        $upload_dir = wp_upload_dir();
        $full_path = trailingslashit($upload_dir['basedir']) . $file_path;

        // Security checks
        if (!file_exists($full_path) || !is_file($full_path)) {
            wp_die(__('File not found.', 'vira-store'), __('File Not Found', 'vira-store'), ['response' => 404]);
        }

        // Prevent directory traversal
        $real_path = realpath($full_path);
        $upload_real_path = realpath($upload_dir['basedir']);
        
        if (strpos($real_path, $upload_real_path) !== 0) {
            wp_die(__('Access denied.', 'vira-store'), __('Access Denied', 'vira-store'), ['response' => 403]);
        }
    }

    /**
     * Check file access permissions with enhanced validation
     *
     * @since 1.0.0
     * @param string $file_path Relative file path
     * @param string $full_path Full file system path
     * @return bool True if access is granted
     */
    private function check_file_access_permissions(string $file_path, string $full_path): bool {
        // Apply rate limiting for file access
        if (!$this->check_access_rate_limit()) {
            error_log("ViraStore: File access denied - rate limit exceeded for IP: " . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
            return false;
        }

        // Check user authentication
        if (!is_user_logged_in()) {
            // Allow public access for certain file types if configured
            $public_access_types = apply_filters('vrstore_public_access_file_types', []);
            $file_extension = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
            
            if (!in_array($file_extension, $public_access_types, true)) {
                error_log("ViraStore: File access denied - user not logged in: {$file_path}");
                return false;
            }
        }

        $user_id = get_current_user_id();

        // Find associated product for this file
        $product_id = $this->find_product_by_file($file_path);
        
        if (!$product_id) {
            // Check if file is in a public directory or has public access
            if ($this->is_public_file($file_path)) {
                return true;
            }
            
            error_log("ViraStore: File access denied - no associated product: {$file_path}");
            return false;
        }

        // Check user capabilities and permissions
        $can_access = false;

        // Admin users can access all files
        if (current_user_can('manage_options')) {
            $can_access = true;
        }
        // Check if user has purchased the product
        elseif ($user_id && $this->user_has_purchased_product($user_id, $product_id)) {
            $can_access = true;
        }
        // Check for temporary access tokens
        elseif ($this->check_temporary_access_token($file_path)) {
            $can_access = true;
        }

        // Apply custom filters for access control
        $can_access = apply_filters('vrstore_can_access_file', $can_access, $product_id, $user_id, $file_path);

        if ($can_access) {
            // Log successful access
            VRSTORE_Security::log_security_event(
                'Protected file access granted',
                'info',
                [
                    'file_path' => $file_path,
                    'product_id' => $product_id,
                    'user_id' => $user_id,
                    'user_ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
                    'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
                ]
            );
        } else {
            // Log access denial
            VRSTORE_Security::log_security_event(
                'Protected file access denied',
                'warning',
                [
                    'file_path' => $file_path,
                    'product_id' => $product_id,
                    'user_id' => $user_id,
                    'user_ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
                    'reason' => 'insufficient_permissions'
                ]
            );
        }

        return $can_access;
    }

    /**
     * Check access rate limiting to prevent abuse
     *
     * @since 1.0.0
     * @return bool True if within rate limits
     */
    private function check_access_rate_limit(): bool {
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $rate_limit_key = 'vrstore_file_access_' . md5($ip);
        
        $current_count = get_transient($rate_limit_key) ?: 0;
        $max_requests = apply_filters('vrstore_file_access_rate_limit', 100); // 100 requests per hour
        $time_window = apply_filters('vrstore_file_access_rate_window', 3600); // 1 hour
        
        if ($current_count >= $max_requests) {
            return false;
        }
        
        set_transient($rate_limit_key, $current_count + 1, $time_window);
        return true;
    }

    /**
     * Check if file is in a public directory or has public access
     *
     * @since 1.0.0
     * @param string $file_path Relative file path
     * @return bool True if file is public
     */
    private function is_public_file(string $file_path): bool {
        $public_directories = apply_filters('vrstore_public_file_directories', [
            'public/',
            'samples/',
            'previews/'
        ]);

        foreach ($public_directories as $public_dir) {
            if (strpos($file_path, $public_dir) === 0) {
                return true;
            }
        }

        return false;
    }

    /**
     * Check for temporary access tokens
     *
     * @since 1.0.0
     * @param string $file_path File path
     * @return bool True if valid token exists
     */
    private function check_temporary_access_token(string $file_path): bool {
        $token = $_GET['access_token'] ?? '';
        
        if (empty($token)) {
            return false;
        }

        $token_data = get_transient('vrstore_access_token_' . $token);
        
        if (!$token_data || !is_array($token_data)) {
            return false;
        }

        // Check if token is for this specific file
        if (isset($token_data['file_path']) && $token_data['file_path'] === $file_path) {
            // Delete token after use (single-use)
            delete_transient('vrstore_access_token_' . $token);
            return true;
        }

        return false;
    }

    /**
     * Handle unauthorized access attempts with enhanced security
     *
     * @since 1.0.0
     * @param string $request_uri Requested URI
     */
    private function handle_unauthorized_access(string $request_uri): void {
        // Extract file path from URI
        $upload_dir = wp_upload_dir();
        $upload_url_path = wp_parse_url($upload_dir['baseurl'], PHP_URL_PATH);
        $file_path = str_replace($upload_url_path, '', $request_uri);
        $file_path = ltrim($file_path, '/');
        
        // Get file extension for logging
        $file_extension = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
        
        // Enhanced security logging
        VRSTORE_Security::log_security_event(
            'Unauthorized file access attempt blocked',
            'warning',
            [
                'file_path' => $file_path,
                'file_extension' => $file_extension,
                'request_uri' => $request_uri,
                'user_ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
                'referer' => $_SERVER['HTTP_REFERER'] ?? 'none',
                'user_id' => get_current_user_id(),
                'timestamp' => current_time('mysql'),
                'blocked_reason' => is_user_logged_in() ? 'insufficient_permissions' : 'not_authenticated'
            ]
        );
        
        // Check if this is a repeated attempt from the same IP
        $this->check_and_handle_repeated_attempts();
        
        // Check if user is logged in
        if (!is_user_logged_in()) {
            // Handle based on configured unauthorized access handling
            $handling_method = $this->security_settings['unauthorized_access_handling'] ?? 'show_404';
            
            switch ($handling_method) {
                case 'show_404':
                    // Show a generic 404 to avoid revealing file existence
                    status_header(404);
                    nocache_headers();
                    wp_die(
                        __('The requested file could not be found.', 'vira-store'),
                        __('File Not Found', 'vira-store'),
                        [
                            'response' => 404,
                            'back_link' => true
                        ]
                    );
                    break;
                    
                case 'redirect_login':
                    // Redirect to login with return URL
                    $secure_url = home_url('/vrstore-secure-download/?file=' . urlencode($file_path));
                    $login_url = wp_login_url($secure_url);
                    wp_redirect($login_url);
                    exit;
                    break;
                    
                case 'show_access_denied':
                default:
                    // Show access denied message
                    status_header(403);
                    nocache_headers();
                    wp_die(
                        __('You must be logged in to access this file.', 'vira-store'),
                        __('Access Denied', 'vira-store'),
                        [
                            'response' => 403,
                            'back_link' => true
                        ]
                    );
                    break;
            }
        }

        // User is logged in but doesn't have access
        // Check if they have any valid licenses for this file
        $product_id = $this->find_product_by_file($file_path);
        if ($product_id) {
            $user_id = get_current_user_id();
            $has_license = VRSTORE_License::user_has_valid_license($user_id, $product_id);
            
            if (!$has_license) {
                // Redirect to product page to purchase
                $product_url = get_permalink($product_id);
                wp_redirect($product_url . '?access_denied=1');
                exit;
            }
        }
        
        // Generic access denied for authenticated users
        status_header(403);
        nocache_headers();
        wp_die(
            __('You do not have permission to access this file.', 'vira-store'),
            __('Access Denied', 'vira-store'),
            [
                'response' => 403,
                'back_link' => true
            ]
        );
    }
    
    /**
     * Check and handle repeated unauthorized access attempts
     *
     * @since 1.0.0
     */
    private function check_and_handle_repeated_attempts(): void {
        $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $transient_key = 'vrstore_failed_access_' . md5($ip_address);
        
        $attempts = get_transient($transient_key) ?: 0;
        $attempts++;
        
        // Get configured limits from settings
        $max_attempts = $this->security_settings['max_unauthorized_attempts'] ?? 10;
        $block_duration = $this->security_settings['temp_block_duration'] ?? 60; // minutes
        
        // Set transient for 1 hour
        set_transient($transient_key, $attempts, HOUR_IN_SECONDS);
        
        // If more than configured attempts in an hour, temporarily block
        if ($attempts > $max_attempts) {
            VRSTORE_Security::log_security_event(
                'IP temporarily blocked for repeated unauthorized access attempts',
                'critical',
                [
                    'ip_address' => $ip_address,
                    'attempts' => $attempts,
                    'max_attempts' => $max_attempts,
                    'block_duration' => $block_duration . ' minutes',
                    'timestamp' => current_time('mysql')
                ]
            );
            
            // Return 429 Too Many Requests
            status_header(429);
            nocache_headers();
            wp_die(
                sprintf(
                    __('Too many failed access attempts (%d/%d). Please try again in %d minutes.', 'vira-store'),
                    $attempts,
                    $max_attempts,
                    $block_duration
                ),
                __('Rate Limited', 'vira-store'),
                [
                    'response' => 429,
                    'back_link' => false
                ]
            );
        }
    }

    /**
     * Find product associated with a file
     *
     * @since 1.0.0
     * @param string $file_path File path
     * @return int|false Product ID or false if not found
     */
    private function find_product_by_file(string $file_path) {
        global $wpdb;

        // Search in product files meta
        $results = $wpdb->get_results($wpdb->prepare("
            SELECT post_id, meta_value 
            FROM {$wpdb->postmeta} 
            WHERE meta_key = '_vrstore_product_files' 
            AND meta_value LIKE %s
        ", '%' . $wpdb->esc_like($file_path) . '%'));

        foreach ($results as $result) {
            $product_files = maybe_unserialize($result->meta_value);
            if (is_array($product_files)) {
                foreach ($product_files as $file) {
                    $file_url = $file['url'] ?? '';
                    if (strpos($file_url, $file_path) !== false) {
                        return $result->post_id;
                    }
                }
            }
        }

        return false;
    }

    /**
     * Serve file with proper headers and security
     *
     * @since 1.0.0
     * @param string $file_path Full file path
     */
    private function serve_file(string $file_path): void {
        // Get file info
        $file_size = filesize($file_path);
        $file_name = basename($file_path);
        $mime_type = wp_check_filetype($file_name)['type'] ?? 'application/octet-stream';

        // Set security headers
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: DENY');
        header('X-XSS-Protection: 1; mode=block');
        header('Referrer-Policy: strict-origin-when-cross-origin');

        // Set download headers
        header('Content-Type: ' . $mime_type);
        header('Content-Length: ' . $file_size);
        header('Content-Disposition: attachment; filename="' . $file_name . '"');
        header('Cache-Control: private, no-cache, no-store, must-revalidate');
        header('Pragma: no-cache');
        header('Expires: 0');

        // Handle range requests for large files
        $this->handle_range_request($file_path, $file_size);

        // Output file content
        readfile($file_path);
        exit;
    }

    /**
     * Handle HTTP range requests for large file downloads
     *
     * @since 1.0.0
     * @param string $file_path File path
     * @param int $file_size File size
     */
    private function handle_range_request(string $file_path, int $file_size): void {
        $range = $_SERVER['HTTP_RANGE'] ?? '';
        
        if (empty($range)) {
            header('HTTP/1.1 200 OK');
            return;
        }

        // Parse range header
        if (!preg_match('/bytes=(\d+)-(\d*)/', $range, $matches)) {
            header('HTTP/1.1 416 Requested Range Not Satisfiable');
            header('Content-Range: bytes */' . $file_size);
            exit;
        }

        $start = intval($matches[1]);
        $end = !empty($matches[2]) ? intval($matches[2]) : $file_size - 1;

        // Validate range
        if ($start > $end || $start >= $file_size || $end >= $file_size) {
            header('HTTP/1.1 416 Requested Range Not Satisfiable');
            header('Content-Range: bytes */' . $file_size);
            exit;
        }

        // Set partial content headers
        header('HTTP/1.1 206 Partial Content');
        header('Accept-Ranges: bytes');
        header('Content-Range: bytes ' . $start . '-' . $end . '/' . $file_size);
        header('Content-Length: ' . ($end - $start + 1));

        // Output partial content
        $fp = fopen($file_path, 'rb');
        fseek($fp, $start);
        
        $buffer_size = 8192;
        $bytes_remaining = $end - $start + 1;
        
        while ($bytes_remaining > 0 && !feof($fp)) {
            $bytes_to_read = min($buffer_size, $bytes_remaining);
            echo fread($fp, $bytes_to_read);
            $bytes_remaining -= $bytes_to_read;
            
            if (ob_get_level()) {
                ob_flush();
            }
            flush();
        }
        
        fclose($fp);
        exit;
    }

    /**
     * Serve secure file for plugin updates and other protected downloads
     *
     * @since 1.0.0
     * @param string $file_path Full path to the file
     * @param string $file_name Original filename for download
     * @param array $options Additional options for file serving
     * @return void
     */
    public function serve_secure_file(string $file_path, string $file_name, array $options = []): void {
        // Validate file exists and is readable
        if (!file_exists($file_path) || !is_readable($file_path)) {
            wp_die(
                esc_html__('File not found or not accessible.', 'vira-store'),
                esc_html__('File Not Found', 'vira-store'),
                ['response' => 404]
            );
        }

        // Security check - ensure file is within allowed directories
        $real_file_path = realpath($file_path);
        $upload_dir = wp_upload_dir();
        $allowed_paths = [
            realpath($upload_dir['basedir']),
            realpath(WP_CONTENT_DIR . '/uploads'),
            realpath(ABSPATH . 'wp-content/uploads')
        ];

        $is_allowed_path = false;
        foreach ($allowed_paths as $allowed_path) {
            if ($allowed_path && strpos($real_file_path, $allowed_path) === 0) {
                $is_allowed_path = true;
                break;
            }
        }

        if (!$is_allowed_path) {
            VRSTORE_Security::log_security_event(
                'Attempted access to file outside allowed directories',
                'warning',
                [
                    'file_path' => $file_path,
                    'real_path' => $real_file_path,
                    'user_ip' => $_SERVER['REMOTE_ADDR'] ?? '',
                    'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? ''
                ]
            );
            
            wp_die(
                esc_html__('Access denied.', 'vira-store'),
                esc_html__('Access Denied', 'vira-store'),
                ['response' => 403]
            );
        }

        // Get file information
        $file_size = filesize($file_path);
        $file_extension = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $mime_type = wp_check_filetype($file_name)['type'] ?? 'application/octet-stream';

        // Validate file size against limits
        $max_size = $options['max_size'] ?? $this->max_file_size;
        if ($file_size > $max_size) {
            wp_die(
                sprintf(
                    esc_html__('File size exceeds maximum allowed size of %s.', 'vira-store'),
                    size_format($max_size)
                ),
                esc_html__('File Too Large', 'vira-store'),
                ['response' => 413]
            );
        }

        // Check if file type is allowed
        if (!in_array($file_extension, $this->allowed_file_types, true)) {
            wp_die(
                sprintf(
                    esc_html__('File type "%s" is not allowed for download.', 'vira-store'),
                    $file_extension
                ),
                esc_html__('File Type Not Allowed', 'vira-store'),
                ['response' => 403]
            );
        }

        // Set security headers
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: DENY');
        header('X-XSS-Protection: 1; mode=block');
        header('Referrer-Policy: strict-origin-when-cross-origin');
        header('X-Robots-Tag: noindex, nofollow, noarchive, nosnippet');

        // Set download headers
        header('Content-Type: ' . $mime_type);
        header('Content-Length: ' . $file_size);
        header('Content-Disposition: attachment; filename="' . sanitize_file_name($file_name) . '"');
        header('Cache-Control: private, no-cache, no-store, must-revalidate');
        header('Pragma: no-cache');
        header('Expires: 0');

        // Add custom headers if provided
        if (!empty($options['headers']) && is_array($options['headers'])) {
            foreach ($options['headers'] as $header_name => $header_value) {
                header(sanitize_text_field($header_name) . ': ' . sanitize_text_field($header_value));
            }
        }

        // Handle range requests for large files (resume support)
        $this->handle_range_request($file_path, $file_size);

        // Log the download if enabled
        if ($this->security_settings['enable_download_logging']) {
            $this->log_secure_file_download($file_path, $file_name, $options);
        }

        // Clear any output buffers to prevent corruption
        if (ob_get_level()) {
            ob_end_clean();
        }

        // Output file content efficiently
        $this->output_file_content($file_path, $file_size);
        exit;
    }

    /**
     * Log secure file download
     *
     * @since 1.0.0
     * @param string $file_path File path
     * @param string $file_name File name
     * @param array $options Download options
     * @return void
     */
    private function log_secure_file_download(string $file_path, string $file_name, array $options = []): void {
        global $wpdb;

        // Get user information
        $user_id = get_current_user_id();
        $user = $user_id ? get_user_by('ID', $user_id) : null;

        // Get IP address
        $ip_address = '';
        if (isset($_SERVER['HTTP_CF_CONNECTING_IP'])) {
            $ip_address = sanitize_text_field($_SERVER['HTTP_CF_CONNECTING_IP']);
        } elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip_address = sanitize_text_field($_SERVER['HTTP_X_FORWARDED_FOR']);
        } elseif (isset($_SERVER['REMOTE_ADDR'])) {
            $ip_address = sanitize_text_field($_SERVER['REMOTE_ADDR']);
        }

        // Prepare log data
        $log_data = [
            'product_id' => $options['product_id'] ?? 0,
            'order_id' => $options['order_id'] ?? 0,
            'user_id' => $user_id,
            'customer_name' => $user ? $user->display_name : 'Guest',
            'customer_email' => $user ? $user->user_email : '',
            'file_name' => $file_name,
            'file_url' => $file_path,
            'file_type' => pathinfo($file_name, PATHINFO_EXTENSION),
            'file_size' => filesize($file_path),
            'ip_address' => $ip_address,
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'download_date' => current_time('mysql'),
            'download_type' => $options['download_type'] ?? 'secure_download',
            'download_process' => 'secure_file_protection'
        ];

        // Insert into download logs table if it exists
        $download_logs_table = $wpdb->prefix . 'vrstore_download_logs';
        if ($wpdb->get_var("SHOW TABLES LIKE '$download_logs_table'") === $download_logs_table) {
            $wpdb->insert(
                $download_logs_table,
                $log_data,
                ['%d', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s']
            );
        }

        // Also log to download tracking table if it exists
        $tracking_table = $wpdb->prefix . 'vrstore_download_tracking';
        if ($wpdb->get_var("SHOW TABLES LIKE '$tracking_table'") === $tracking_table) {
            $wpdb->insert(
                $tracking_table,
                $log_data,
                ['%d', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s']
            );
        }

        // Log security event
        VRSTORE_Security::log_security_event(
            'Secure file download completed',
            'info',
            [
                'file_name' => $file_name,
                'file_size' => filesize($file_path),
                'user_id' => $user_id,
                'ip_address' => $ip_address,
                'download_type' => $options['download_type'] ?? 'secure_download'
            ]
        );
    }

    /**
     * Output file content efficiently with memory management
     *
     * @since 1.0.0
     * @param string $file_path File path
     * @param int $file_size File size
     * @return void
     */
    private function output_file_content(string $file_path, int $file_size): void {
        $fp = fopen($file_path, 'rb');
        if (!$fp) {
            wp_die(
                esc_html__('Unable to read file.', 'vira-store'),
                esc_html__('File Read Error', 'vira-store'),
                ['response' => 500]
            );
        }

        // Use appropriate buffer size based on file size
        $buffer_size = $file_size > 10 * 1024 * 1024 ? 64 * 1024 : 8 * 1024; // 64KB for large files, 8KB for smaller

        // Output file in chunks to manage memory usage
        while (!feof($fp)) {
            $chunk = fread($fp, $buffer_size);
            if ($chunk === false) {
                break;
            }
            echo $chunk;
            
            // Flush output to prevent memory buildup
            if (ob_get_level()) {
                ob_flush();
            }
            flush();
        }

        fclose($fp);
    }

    /**
     * Remove .htaccess protection rules on deactivation
     *
     * @since 1.0.0
     */
    public static function remove_htaccess_protection(): void {
        $upload_dir = wp_upload_dir();
        $htaccess_file = trailingslashit($upload_dir['basedir']) . '.htaccess';

        if (file_exists($htaccess_file)) {
            $content = file_get_contents($htaccess_file);
            
            // Remove ViraStore rules
            $content = preg_replace(
                '/# ViraStore File Protection Rules.*?# End ViraStore File Protection Rules\n/s',
                '',
                $content
            );
            
            // Write back the cleaned content
            file_put_contents($htaccess_file, $content);
        }
        
        // Clean up rewrite rules option
        delete_option('virastore_rewrite_rules_flushed');
    }

    /**
     * Add admin settings for file protection configuration
     *
     * @since 1.0.0
     */
    public function add_admin_menu(): void {
        add_options_page(
            __('ViraStore File Protection', 'vira-store'),
            __('File Protection', 'vira-store'),
            'manage_options',
            'vrstore-file-protection',
            [$this, 'render_admin_page']
        );
    }

    /**
     * Add admin settings for file protection configuration
     *
     * @since 1.0.0
     */
    public function add_admin_settings(): void {
        // Register settings for the main ViraStore settings page (Advanced tab)
        register_setting('vrstore_settings_advanced', 'vrstore_protected_file_types', [
            'sanitize_callback' => [$this, 'sanitize_file_types']
        ]);
        
        register_setting('vrstore_settings_advanced', 'vrstore_enable_direct_access_protection');
        
        register_setting('vrstore_settings_advanced', 'vrstore_file_access_rate_limit', [
            'sanitize_callback' => 'absint'
        ]);
        
        register_setting('vrstore_settings_advanced', 'vrstore_public_directories', [
            'sanitize_callback' => [$this, 'sanitize_public_directories']
        ]);
        
        register_setting('vrstore_settings_advanced', 'vrstore_max_file_size_mb', [
            'sanitize_callback' => 'absint'
        ]);
    }

    /**
     * Render settings section description
     *
     * @since 1.0.0
     */
    public function render_settings_section(): void {
        echo '<p>' . esc_html__('Configure file protection settings to secure your digital products and prevent unauthorized access.', 'vira-store') . '</p>';
    }

    /**
     * Render protected file types field
     *
     * @since 1.0.0
     */
    public function render_protected_file_types_field(): void {
        $file_types = get_option('vrstore_protected_file_types', $this->protected_file_types);
        $file_types_string = is_array($file_types) ? implode(', ', $file_types) : '';
        
        echo '<input type="text" name="vrstore_protected_file_types" value="' . esc_attr($file_types_string) . '" class="regular-text" />';
        echo '<p class="description">' . esc_html__('Comma-separated list of file extensions to protect (e.g., zip, pdf, doc, mp4)', 'vira-store') . '</p>';
    }

    /**
     * Render direct access protection field
     *
     * @since 1.0.0
     */
    public function render_direct_access_protection_field(): void {
        $enabled = $this->security_settings['enable_direct_access_protection'] ?? true;
        
        echo '<label>';
        echo '<input type="checkbox" name="vrstore_security_settings[enable_direct_access_protection]" value="1" ' . checked($enabled, true, false) . ' />';
        echo ' ' . esc_html__('Enable direct access protection for uploaded files', 'vira-store');
        echo '</label>';
        echo '<p class="description">' . esc_html__('When enabled, protected files cannot be accessed directly via URL and must go through the secure download system.', 'vira-store') . '</p>';
    }

    /**
     * Render rate limit field
     *
     * @since 1.0.0
     */
    public function render_rate_limit_field(): void {
        $rate_limit = get_option('vrstore_file_access_rate_limit', 100);
        
        echo '<input type="number" name="vrstore_file_access_rate_limit" value="' . esc_attr($rate_limit) . '" min="1" max="1000" class="small-text" />';
        echo ' ' . esc_html__('requests per hour per IP address', 'vira-store');
        echo '<p class="description">' . esc_html__('Maximum number of file access requests allowed per IP address per hour to prevent abuse.', 'vira-store') . '</p>';
    }

    /**
     * Render public directories field
     *
     * @since 1.0.0
     */
    public function render_public_directories_field(): void {
        $directories = get_option('vrstore_public_file_directories', ['public/', 'samples/', 'previews/']);
        $directories_string = is_array($directories) ? implode(', ', $directories) : '';
        
        echo '<input type="text" name="vrstore_public_file_directories" value="' . esc_attr($directories_string) . '" class="regular-text" />';
        echo '<p class="description">' . esc_html__('Comma-separated list of directory paths that should allow public access (relative to uploads directory)', 'vira-store') . '</p>';
    }

    /**
     * Render max file size field
     *
     * @since 1.0.0
     */
    public function render_max_file_size_field(): void {
        $max_size = get_option('vrstore_max_protected_file_size', 100);
        
        echo '<input type="number" name="vrstore_max_protected_file_size" value="' . esc_attr($max_size) . '" min="1" max="1024" class="small-text" />';
        echo ' ' . esc_html__('MB', 'vira-store');
        echo '<p class="description">' . esc_html__('Maximum file size that can be served through the protected download system.', 'vira-store') . '</p>';
    }

    /**
     * Sanitize file types input
     *
     * @since 1.0.0
     * @param string $input Raw input
     * @return array Sanitized file types
     */
    public function sanitize_file_types(string $input): array {
        $types = array_map('trim', explode(',', $input));
        $types = array_filter($types, function($type) {
            return !empty($type) && preg_match('/^[a-zA-Z0-9]+$/', $type);
        });
        
        return array_values($types);
    }

    /**
     * Sanitize public directories input
     *
     * @since 1.0.0
     * @param string $input Raw input
     * @return array Sanitized directories
     */
    public function sanitize_public_directories(string $input): array {
        $directories = array_map('trim', explode(',', $input));
        $directories = array_filter($directories, function($dir) {
            return !empty($dir) && !strpos($dir, '..');
        });
        
        // Ensure trailing slash
        $directories = array_map(function($dir) {
            return trailingslashit($dir);
        }, $directories);
        
        return array_values($directories);
    }

    /**
     * Render the admin page for file protection settings
     *
     * @since 1.0.0
     */
    public function render_admin_page(): void {
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('vrstore_security_settings');
                do_settings_sections('vrstore_security_settings');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }
}
