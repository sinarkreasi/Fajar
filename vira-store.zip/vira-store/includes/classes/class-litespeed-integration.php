<?php
/**
 * LiteSpeed Cache Integration Class
 *
 * Handles integration with LiteSpeed Cache plugin for better performance.
 *
 * @package ViraStore
 * @subpackage Classes
 * @since 1.0.0
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * VRSTORE_LiteSpeed_Integration class.
 *
 * @since 1.0.0
 */
class VRSTORE_LiteSpeed_Integration {

    /**
     * Instance of this class.
     *
     * @since 1.0.0
     * @var VRSTORE_LiteSpeed_Integration
     */
    private static $instance = null;

    /**
     * LiteSpeed Cache API instance.
     *
     * @since 1.0.0
     * @var object
     */
    private $litespeed_api = null;

    /**
     * Settings instance.
     *
     * @since 1.0.0
     * @var VRSTORE_Settings
     */
    private $settings;

    /**
     * Constructor.
     *
     * @since 1.0.0
     */
    private function __construct() {
        $this->settings = VRSTORE_Settings::get_instance();
        $this->init();
    }

    /**
     * Get instance of this class.
     *
     * @since 1.0.0
     * @return VRSTORE_LiteSpeed_Integration
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Get translated text with conditional loading check.
     *
     * @since 1.0.0
     * @param string $text The text to translate.
     * @return string
     */
    private function get_translated_text( $text ) {
        if ( vrstore_is_textdomain_ready() ) {
            return esc_html__( $text, 'vira-store' );
        }
        return esc_html( $text );
    }

    /**
     * Initialize the integration.
     *
     * @since 1.0.0
     * @return void
     */
    private function init() {
        // Only initialize if LiteSpeed Cache is active and integration is enabled
        if ( ! $this->is_litespeed_active() || ! $this->is_integration_enabled() ) {
            return;
        }

        $this->setup_litespeed_api();
        $this->add_hooks();
    }

    /**
     * Setup LiteSpeed Cache API.
     *
     * @since 1.0.0
     * @return void
     */
    private function setup_litespeed_api() {
        if ( class_exists( 'LiteSpeed\API' ) ) {
            $this->litespeed_api = \LiteSpeed\API::cls();
        }
    }

    /**
     * Add WordPress hooks.
     *
     * @since 1.0.0
     * @return void
     */
    private function add_hooks() {
        // Purge cache on order creation/update
        add_action( 'vrstore_order_created', array( $this, 'purge_order_cache' ), 10, 1 );
        add_action( 'vrstore_order_created_in_database', array( $this, 'purge_order_cache' ), 10, 1 );
        add_action( 'vrstore_order_updated', array( $this, 'purge_order_cache' ), 10, 1 );
        add_action( 'vrstore_order_status_changed', array( $this, 'purge_order_cache' ), 10, 1 );

        // Purge cache on license operations
        add_action( 'vrstore_license_generated', array( $this, 'purge_license_cache' ), 10, 1 );
        add_action( 'vrstore_license_activated', array( $this, 'purge_license_cache' ), 10, 1 );
        add_action( 'vrstore_license_deactivated', array( $this, 'purge_license_cache' ), 10, 1 );

        // Purge cache on product updates
        add_action( 'vrstore_product_updated', array( $this, 'purge_product_cache' ), 10, 1 );
        add_action( 'vrstore_product_deleted', array( $this, 'purge_product_cache' ), 10, 1 );

        // Purge cache on settings changes
        add_action( 'vrstore_settings_updated', array( $this, 'purge_settings_cache' ), 10, 1 );

        // Purge cache on cart operations
        add_action( 'vrstore_cart_updated', array( $this, 'purge_cart_cache' ), 10, 1 );
        add_action( 'vrstore_cart_item_added', array( $this, 'purge_cart_cache' ), 10, 1 );
        add_action( 'vrstore_cart_item_removed', array( $this, 'purge_cart_cache' ), 10, 1 );
        add_action( 'vrstore_cart_cleared', array( $this, 'purge_cart_cache' ), 10, 1 );

        // Add ESI blocks for dynamic content
        add_action( 'wp_head', array( $this, 'add_esi_blocks' ) );

        // Exclude certain pages from caching
        add_filter( 'litespeed_cache_is_cacheable', array( $this, 'exclude_pages_from_cache' ), 10, 1 );

        // Exclude AJAX requests from caching
        add_filter( 'litespeed_cache_is_cacheable', array( $this, 'exclude_ajax_from_cache' ), 10, 1 );

        // Add custom vary headers for dynamic content
        add_filter( 'litespeed_cache_vary', array( $this, 'add_vary_headers' ), 10, 1 );

        // Add cache tags
        add_action( 'wp', array( $this, 'add_cache_tags' ) );

        // Handle AJAX requests
        add_action( 'wp_ajax_vrstore_purge_litespeed_cache', array( $this, 'handle_manual_purge' ) );
        add_action( 'wp_ajax_nopriv_vrstore_purge_litespeed_cache', array( $this, 'handle_manual_purge' ) );

        // Add ESI AJAX handlers for dynamic content
        add_action( 'wp_ajax_vrstore_esi_cart_content', array( $this, 'handle_esi_cart_content' ) );
        add_action( 'wp_ajax_nopriv_vrstore_esi_cart_content', array( $this, 'handle_esi_cart_content' ) );
        add_action( 'wp_ajax_vrstore_esi_user_content', array( $this, 'handle_esi_user_content' ) );
        add_action( 'wp_ajax_nopriv_vrstore_esi_user_content', array( $this, 'handle_esi_user_content' ) );

        // Configure LiteSpeed settings on activation
        add_action( 'init', array( $this, 'configure_litespeed_settings' ) );
    }

    /**
     * Check if LiteSpeed Cache is active.
     *
     * @since 1.0.0
     * @return bool
     */
    public function is_litespeed_active() {
        return class_exists( 'LiteSpeed\Core' ) || function_exists( 'run_litespeed_cache' );
    }

    /**
     * Check if integration is enabled in settings.
     *
     * @since 1.0.0
     * @return bool
     */
    public function is_integration_enabled() {
        return $this->settings->get_setting( 'litespeed_cache_enabled', false );
    }

    /**
     * Purge cache for order-related pages.
     *
     * @since 1.0.0
     * @param int $order_id Order ID.
     * @return void
     */
    public function purge_order_cache( $order_id ) {
        if ( ! $this->settings->get_setting( 'litespeed_purge_on_order', true ) ) {
            return;
        }

        $tags = array(
            'vrstore_order_' . $order_id,
            'vrstore_orders',
            'vrstore_admin_orders',
        );

        $this->purge_cache_by_tags( $tags );

        // Also purge account page if user is logged in
        $order = vrstore_get_order( $order_id );
        $user_id = vrstore_get_user_id_from_data( $order );
        if ( $user_id ) {
            $this->purge_cache_by_tags( array( 'vrstore_user_' . $user_id ) );
        }
    }

    /**
     * Purge cache for license-related pages.
     *
     * @since 1.0.0
     * @param int $license_id License ID.
     * @return void
     */
    public function purge_license_cache( $license_id ) {
        $tags = array(
            'vrstore_license_' . $license_id,
            'vrstore_licenses',
            'vrstore_admin_licenses',
        );

        $this->purge_cache_by_tags( $tags );

        // Also purge user-specific cache
        $license = vrstore_get_license( $license_id );
        $user_id = vrstore_get_user_id_from_data( $license );
        if ( $user_id ) {
            $this->purge_cache_by_tags( array( 'vrstore_user_' . $user_id ) );
        }
    }

    /**
     * Purge cache for product-related pages.
     *
     * @since 1.0.0
     * @param int $product_id Product ID.
     * @return void
     */
    public function purge_product_cache( $product_id ) {
        $tags = array(
            'vrstore_product_' . $product_id,
            'vrstore_products',
            'vrstore_store',
        );

        $this->purge_cache_by_tags( $tags );
    }

    /**
     * Purge cache for settings-related pages.
     *
     * @since 1.0.0
     * @param string $setting_key Setting key that was updated.
     * @return void
     */
    public function purge_settings_cache( $setting_key ) {
        $tags = array(
            'vrstore_settings',
            'vrstore_admin',
        );

        // If store settings changed, purge store pages
        if ( strpos( $setting_key, 'store_' ) === 0 ) {
            $tags[] = 'vrstore_store';
        }

        $this->purge_cache_by_tags( $tags );
    }

    /**
     * Purge cache for cart-related operations.
     *
     * @since 1.0.0
     * @param int|string $user_id_or_session User ID or session identifier.
     * @return void
     */
    public function purge_cart_cache( $user_id_or_session = null ) {
        $tags = array(
            'vrstore_cart',
            'vrstore_store',
        );

        // Add user-specific cache tags if available
        if ( $user_id_or_session ) {
            if ( is_numeric( $user_id_or_session ) ) {
                $tags[] = 'vrstore_user_' . $user_id_or_session;
            } else {
                $tags[] = 'vrstore_session_' . md5( $user_id_or_session );
            }
        } elseif ( is_user_logged_in() ) {
            $tags[] = 'vrstore_user_' . get_current_user_id();
        }

        $this->purge_cache_by_tags( $tags );

        // Also trigger purge of ESI content
        do_action( 'vrstore_cart_cache_purged', $user_id_or_session );
    }

    /**
     * Purge cache by tags.
     *
     * @since 1.0.0
     * @param array $tags Cache tags to purge.
     * @return void
     */
    private function purge_cache_by_tags( $tags ) {
        if ( ! $this->litespeed_api || empty( $tags ) ) {
            return;
        }

        foreach ( $tags as $tag ) {
            if ( method_exists( $this->litespeed_api, 'purge_tag' ) ) {
                $this->litespeed_api->purge_tag( $tag );
            } elseif ( function_exists( 'litespeed_purge_single_post' ) ) {
                // Fallback for older versions
                litespeed_purge_single_post( $tag );
            }
        }

        do_action( 'vrstore_litespeed_cache_purged', $tags );
    }

    /**
     * Add ESI blocks for dynamic content.
     *
     * @since 1.0.0
     * @return void
     */
    public function add_esi_blocks() {
        if ( ! is_admin() && $this->settings->get_setting( 'litespeed_esi_enabled', false ) ) {
            // Add ESI block for user-specific content
            if ( is_user_logged_in() ) {
                echo '<!-- esi:include src="/wp-admin/admin-ajax.php?action=vrstore_esi_user_content" -->';
            }

            // Add ESI block for cart content on store pages
            if ( $this->is_store_page() || $this->is_product_page() ) {
                echo '<!-- esi:include src="/wp-admin/admin-ajax.php?action=vrstore_esi_cart_content" -->';
            }
            
            // Add JavaScript cache busting for Buy Now/Cart buttons
            if ( $this->is_store_page() || $this->is_product_page() || $this->has_buy_button() ) {
                echo '<script type="text/javascript">';
                echo 'if (typeof vrstore_cache_bust === "undefined") {';
                echo 'var vrstore_cache_bust = Date.now();';
                echo 'document.addEventListener("DOMContentLoaded", function() {';
                echo 'if (typeof jQuery !== "undefined") {';
                echo 'jQuery(document).trigger("vrstore_cache_busted", [vrstore_cache_bust]);';
                echo '}';
                echo '});';
                echo '}';
                echo '</script>';
            }
        }
        
        // Add nonce refresh mechanism for cached pages
        if ( $this->has_vira_store_shortcode() || $this->has_buy_button() ) {
            $this->add_nonce_refresh_script();
        }
    }
    
    /**
     * Add nonce refresh script for cached pages
     *
     * @since 1.0.0
     * @return void
     */
    private function add_nonce_refresh_script() {
        ?>
        <script type="text/javascript">
        (function() {
            // Refresh nonces on page load if cached
            if (typeof vrstore_ajax !== 'undefined' && vrstore_ajax.nonce_refresh) {
                // Nonce already refreshed, skip
                return;
            }
            
            // Check if we need to refresh nonce
            var shouldRefresh = false;
            
            // Check if page might be cached (has old timestamp)
            if (document.querySelector('.vrstore-buy-button-container')) {
                shouldRefresh = true;
            }
            
            if (shouldRefresh && typeof jQuery !== 'undefined') {
                jQuery(document).ready(function($) {
                    // Refresh nonce via AJAX
                    $.ajax({
                        url: (typeof vrstore_ajax !== 'undefined' && vrstore_ajax.ajax_url) 
                            ? vrstore_ajax.ajax_url 
                            : (typeof ajaxurl !== 'undefined' ? ajaxurl : '/wp-admin/admin-ajax.php'),
                        type: 'POST',
                        data: {
                            action: 'vrstore_refresh_checkout_nonce'
                        },
                        success: function(response) {
                            if (response.success && response.data && response.data.nonce) {
                                // Update nonce in localized script data
                                if (typeof vrstore_ajax !== 'undefined') {
                                    vrstore_ajax.nonce = response.data.nonce;
                                    vrstore_ajax.nonce_refresh = true;
                                }
                                
                                // Update hidden nonce fields
                                $('input[name="vrstore_frontend_nonce"], input[name="nonce"]').each(function() {
                                    if ($(this).data('action') === 'vrstore_frontend_nonce' || 
                                        $(this).closest('.vrstore-buy-button-container').length) {
                                        $(this).val(response.data.nonce);
                                    }
                                });
                                
                                // Update meta tag if exists
                                $('meta[name="vrstore-nonce"]').attr('content', response.data.nonce);
                            }
                        },
                        error: function() {
                            // Silent fail - nonce might still be valid
                        }
                    });
                });
            }
        })();
        </script>
        <?php
    }

    /**
     * Exclude certain pages from caching.
     *
     * @since 1.0.0
     * @param bool $cacheable Whether the page is cacheable.
     * @return bool
     */
    public function exclude_pages_from_cache( $cacheable ) {
        // Never cache if we're doing AJAX
        if ( wp_doing_ajax() ) {
            return false;
        }

        // Never cache if we're in admin
        if ( is_admin() ) {
            return false;
        }

        // Never cache POST requests (form submissions)
        if ( isset( $_SERVER['REQUEST_METHOD'] ) && $_SERVER['REQUEST_METHOD'] === 'POST' ) {
            return false;
        }

        $exclude_pages = $this->settings->get_setting( 'litespeed_exclude_pages', array() );

        if ( ! empty( $exclude_pages ) ) {
            global $wp;
            $current_url = home_url( $wp->request );

            foreach ( $exclude_pages as $page ) {
                if ( strpos( $current_url, $page ) !== false ) {
                    return false;
                }
            }
        }

        // Always exclude checkout, cart, and account pages
        if ( $this->is_checkout_page() || $this->is_account_page() || $this->is_cart_page() ) {
            return false;
        }

        // Exclude pages with Vira Store shortcodes that require dynamic content
        if ( $this->has_vira_store_shortcode() ) {
            // For product/store pages, use ESI instead of full exclusion
            // But for buy button pages, exclude to prevent nonce caching
            if ( $this->is_product_page() || $this->has_buy_button() ) {
                return false;
            }
        }

        // Exclude REST API endpoints that handle dynamic content
        if ( $this->is_rest_api_request() ) {
            $rest_route = $this->get_rest_route();
            if ( $rest_route && ( 
                strpos( $rest_route, 'vrstore' ) === 0 || 
                strpos( $rest_route, 'vrstore-moota' ) === 0 
            ) ) {
                return false;
            }
        }

        return $cacheable;
    }
    
    /**
     * Check if current page has Vira Store shortcodes
     *
     * @since 1.0.0
     * @return bool
     */
    private function has_vira_store_shortcode() {
        global $post;
        
        if ( ! is_singular() || ! is_a( $post, 'WP_Post' ) ) {
            return false;
        }
        
        $vrstore_shortcodes = array(
            'vrstore_checkout',
            'vrstore_cart',
            'vrstore_account',
            'vrstore_product',
            'vrstore_products',
            'vrstore_store',
            'vrstore_categories',
            'vrstore_dashboard',
            'vrstore_orders',
            'vrstore_licenses'
        );
        
        foreach ( $vrstore_shortcodes as $shortcode ) {
            if ( has_shortcode( $post->post_content, $shortcode ) ) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Check if page has buy button shortcode or content
     *
     * @since 1.0.0
     * @return bool
     */
    private function has_buy_button() {
        global $post;
        
        if ( ! is_singular() || ! is_a( $post, 'WP_Post' ) ) {
            return false;
        }
        
        // Check for buy button shortcode
        if ( has_shortcode( $post->post_content, 'vrstore_buy_button' ) ) {
            return true;
        }
        
        // Check for product page with buy button
        if ( is_singular( 'vrstore_product' ) || is_singular( 'vrstore_course' ) ) {
            return true;
        }
        
        // Check if content contains buy button class
        if ( strpos( $post->post_content, 'vrstore-buy-button' ) !== false ) {
            return true;
        }
        
        return false;
    }
    
    /**
     * Check if current request is REST API
     *
     * @since 1.0.0
     * @return bool
     */
    private function is_rest_api_request() {
        return defined( 'REST_REQUEST' ) && REST_REQUEST;
    }
    
    /**
     * Get current REST API route
     *
     * @since 1.0.0
     * @return string|false
     */
    private function get_rest_route() {
        if ( ! $this->is_rest_api_request() ) {
            return false;
        }
        
        return isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( $_SERVER['REQUEST_URI'] ) : false;
    }

    /**
     * Exclude AJAX requests from caching.
     *
     * @since 1.0.0
     * @param bool $cacheable Whether the page is cacheable.
     * @return bool
     */
    public function exclude_ajax_from_cache( $cacheable ) {
        // If not an AJAX request, return original cacheable status
        if ( ! wp_doing_ajax() ) {
            return $cacheable;
        }

        // Get the AJAX action
        $action = sanitize_text_field( $_REQUEST['action'] ?? '' );

        // List of ViraStore AJAX actions that should never be cached
        $excluded_actions = array(
            // Cart operations (Buy Now functionality)
            'vrstore_add_to_cart',
            'vrstore_update_cart',
            'vrstore_remove_cart_item',
            'vrstore_clear_cart',
            'vrstore_update_cart_quantity',
            'vrstore_bulk_remove_items',
            'vrstore_bulk_save_later',
            'vrstore_add_course_to_cart',
            'vrstore_buy_now',
            
            // Coupon operations
            'vrstore_apply_coupon',
            'vrstore_remove_coupon',
            
            // Checkout operations
            'vrstore_check_customer_exists',
            'vrstore_refresh_checkout_nonce',
            'vrstore_process_checkout',
            
            // User operations
            'vrstore_register_user',
            'vrstore_login_user',
            'vrstore_logout_user',
            
            // Admin operations
            'vrstore_purge_litespeed_cache',
            'vrstore_export_orders_csv',
            'vrstore_export_customers_csv',
            
            // ESI content handlers
            'vrstore_esi_cart_content',
            'vrstore_esi_user_content',
            
            // Payment operations
            'vrstore_process_payment',
            'vrstore_payment_callback',
            'vrstore_process_tripay_payment',
            'vrstore_process_paypal_payment',
            'vrstore_process_xendit_payment',
            'vrstore_process_moota_payment',
            
            // Moota payment operations
            'vrstore_moota_process_payment',
            'vrstore_moota_check_payment',
            'vrstore_get_moota_banks',
            
            // License operations
            'vrstore_activate_license',
            'vrstore_deactivate_license',
            'vrstore_check_license_status'
        );

        // Allow filtering of excluded actions
        $excluded_actions = apply_filters( 'vrstore_litespeed_excluded_ajax_actions', $excluded_actions );

        // If this is a ViraStore AJAX action, don't cache
        if ( in_array( $action, $excluded_actions, true ) ) {
            return false;
        }

        return $cacheable;
    }

    /**
     * Add custom vary headers for dynamic content.
     *
     * @since 1.0.0
     * @param array $vary Current vary headers.
     * @return array
     */
    public function add_vary_headers( $vary ) {
        // Always add nonce hash cookie to vary headers for pages with forms
        if ( $this->has_vira_store_shortcode() || $this->has_buy_button() ) {
            $vary[] = 'Cookie:vrstore_nonce_hash';
            $vary[] = 'Cookie:vrstore_cart';
            $vary[] = 'Cookie:vrstore_session';
        }

        // Add vary headers for cart-dependent content
        if ( $this->is_store_page() || $this->is_product_page() || $this->has_buy_button() ) {
            $vary[] = 'Cookie:vrstore_cart';
            $vary[] = 'Cookie:vrstore_nonce_hash';
            $vary[] = 'Cookie:wordpress_logged_in';
        }

        // Add vary headers for user-specific content
        if ( $this->is_account_page() || is_user_logged_in() ) {
            $vary[] = 'Cookie:wordpress_logged_in';
            $vary[] = 'Cookie:vrstore_nonce_hash';
        }

        return array_unique( $vary );
    }

    /**
     * Add cache tags to pages.
     *
     * @since 1.0.0
     * @return void
     */
    public function add_cache_tags() {
        if ( ! $this->litespeed_api ) {
            return;
        }

        $tags = array();

        // Add general ViraStore tag
        $tags[] = 'vrstore';

        // Add page-specific tags
        if ( $this->is_store_page() ) {
            $tags[] = 'vrstore_store';
        }

        if ( $this->is_product_page() ) {
            $product_id = get_the_ID();
            $tags[] = 'vrstore_product_' . $product_id;
        }

        if ( $this->is_account_page() && is_user_logged_in() ) {
            $tags[] = 'vrstore_user_' . get_current_user_id();
        }

        if ( is_admin() ) {
            $tags[] = 'vrstore_admin';
        }

        // Apply tags
        foreach ( $tags as $tag ) {
            if ( method_exists( $this->litespeed_api, 'tag' ) ) {
                $this->litespeed_api->tag( $tag );
            }
        }

        do_action( 'vrstore_litespeed_cache_tags_added', $tags );
    }

    /**
     * Handle manual cache purge via AJAX.
     *
     * @since 1.0.0
     * @return void
     */
    public function handle_manual_purge() {
        // Verify nonce
        if ( ! wp_verify_nonce( $_POST['nonce'], 'vrstore_purge_cache' ) ) {
            wp_die( $this->get_translated_text( 'Security check failed.' ) );
        }

        // Check permissions
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( $this->get_translated_text( 'You do not have permission to perform this action.' ) );
        }

        $purge_type = sanitize_text_field( $_POST['purge_type'] ?? 'all' );

        switch ( $purge_type ) {
            case 'all':
                $this->purge_all_cache();
                break;
            case 'store':
                $this->purge_cache_by_tags( array( 'vrstore_store', 'vrstore_products' ) );
                break;
            case 'orders':
                $this->purge_cache_by_tags( array( 'vrstore_orders', 'vrstore_admin_orders' ) );
                break;
            case 'licenses':
                $this->purge_cache_by_tags( array( 'vrstore_licenses', 'vrstore_admin_licenses' ) );
                break;
        }

        wp_send_json_success( array(
            'message' => $this->get_translated_text( 'Cache purged successfully.' ),
        ) );
    }

    /**
     * Purge all ViraStore-related cache.
     *
     * @since 1.0.0
     * @return void
     */
    public function purge_all_cache() {
        if ( $this->litespeed_api && method_exists( $this->litespeed_api, 'purge_all' ) ) {
            $this->litespeed_api->purge_all();
        } elseif ( function_exists( 'litespeed_purge_all' ) ) {
            litespeed_purge_all();
        }

        do_action( 'vrstore_litespeed_all_cache_purged' );
    }

    /**
     * Check if current page is a store page.
     *
     * @since 1.0.0
     * @return bool
     */
    private function is_store_page() {
        global $post;
        
        // Check if current page has store-related shortcodes
        if ( is_singular() && is_a( $post, 'WP_Post' ) ) {
            if ( has_shortcode( $post->post_content, 'vrstore_products' ) ||
                 has_shortcode( $post->post_content, 'vrstore_store' ) ||
                 has_shortcode( $post->post_content, 'vrstore_categories' ) ) {
                return true;
            }
        }
        
        // Check if this is a configured store page
        $store_page_id = $this->settings->get_setting( 'store_page', 0 );
        if ( $store_page_id && is_page( $store_page_id ) ) {
            return true;
        }
        
        // Check if we're viewing product archives or taxonomy pages
        if ( is_post_type_archive( 'vrstore_product' ) || 
             is_tax( 'vrstore_category' ) || 
             is_tax( 'vrstore_tag' ) ) {
            return true;
        }
        
        return false;
    }

    /**
     * Check if current page is a product page.
     *
     * @since 1.0.0
     * @return bool
     */
    private function is_product_page() {
        global $post;
        
        // Check if current page is a ViraStore product
        if ( is_singular( 'vrstore_product' ) ) {
            return true;
        }
        
        // Check if current page has product shortcodes
        if ( is_singular() && is_a( $post, 'WP_Post' ) ) {
            if ( has_shortcode( $post->post_content, 'vrstore_product' ) ) {
                return true;
            }
        }
        
        return false;
    }

    /**
     * Check if current page is a checkout page.
     *
     * @since 1.0.0
     * @return bool
     */
    private function is_checkout_page() {
        global $post;
        
        // Check if current page has checkout shortcode
        if ( is_singular() && is_a( $post, 'WP_Post' ) ) {
            if ( has_shortcode( $post->post_content, 'vrstore_checkout' ) ) {
                return true;
            }
        }
        
        // Check if this is a configured checkout page
        $checkout_page_id = $this->settings->get_setting( 'checkout_page', 0 );
        if ( $checkout_page_id && is_page( $checkout_page_id ) ) {
            return true;
        }
        
        return false;
    }

    /**
     * Check if current page is an account page.
     *
     * @since 1.0.0
     * @return bool
     */
    private function is_account_page() {
        global $post;
        
        // Check if current page has account shortcode
        if ( is_singular() && is_a( $post, 'WP_Post' ) ) {
            if ( has_shortcode( $post->post_content, 'vrstore_account' ) ||
                 has_shortcode( $post->post_content, 'vrstore_dashboard' ) ||
                 has_shortcode( $post->post_content, 'vrstore_orders' ) ||
                 has_shortcode( $post->post_content, 'vrstore_licenses' ) ) {
                return true;
            }
        }
        
        // Check if this is a configured account page
        $account_page_id = $this->settings->get_setting( 'account_page', 0 );
        if ( $account_page_id && is_page( $account_page_id ) ) {
            return true;
        }
        
        return false;
    }

    /**
     * Check if current page is a cart page.
     *
     * @since 1.0.0
     * @return bool
     */
    private function is_cart_page() {
        global $post;

        if ( is_singular() && is_a( $post, 'WP_Post' ) ) {
            if ( has_shortcode( $post->post_content, 'vrstore_cart' ) ) {
                return true;
            }
        }

        $cart_page_id = $this->settings->get_setting( 'cart_page', 0 );
        if ( $cart_page_id && is_page( $cart_page_id ) ) {
            return true;
        }

        return false;
    }

    /**
     * Handle ESI cart content.
     *
     * @since 1.0.0
     * @return void
     */
    public function handle_esi_cart_content() {
        // Ensure we have cart functionality
        if ( ! class_exists( 'VRSTORE_Cart' ) ) {
            wp_die( 'Cart not available' );
        }

        $cart = VRSTORE_Cart::get_instance();
        $cart_count = $cart->get_cart_count();
        $cart_total = $cart->get_cart_total();

        // Output minimal HTML for cart display
        echo '<div class="vrstore-cart-esi-content">';
        echo '<span class="cart-count">' . esc_html( $cart_count ) . '</span>';
        echo '<span class="cart-total">' . esc_html( vrstore_format_price( $cart_total ) ) . '</span>';
        echo '</div>';

        wp_die(); // This is required for AJAX
    }

    /**
     * Handle ESI user content.
     *
     * @since 1.0.0
     * @return void
     */
    public function handle_esi_user_content() {
        if ( is_user_logged_in() ) {
            $user = wp_get_current_user();
            echo '<div class="vrstore-user-esi-content">';
            echo '<span class="user-name">' . esc_html( $user->display_name ) . '</span>';
            echo '<span class="user-role">' . esc_html( implode( ', ', $user->roles ) ) . '</span>';
            echo '</div>';
        } else {
            echo '<div class="vrstore-user-esi-content guest"></div>';
        }

        wp_die(); // This is required for AJAX
    }

    /**
     * Configure LiteSpeed Cache settings for optimal ViraStore performance.
     *
     * @since 1.0.0
     * @return void
     */
    public function configure_litespeed_settings() {
        // Only run once and only if LiteSpeed is active
        if ( ! $this->is_litespeed_active() || get_option( 'vrstore_litespeed_configured' ) ) {
            return;
        }

        // Set cache exclusion cookies
        $this->set_cache_exclusion_cookies();

        // Set cache exclusion URLs
        $this->set_cache_exclusion_urls();

        // Mark as configured
        update_option( 'vrstore_litespeed_configured', true );
    }

    /**
     * Set cache exclusion cookies.
     *
     * @since 1.0.0
     * @return void
     */
    private function set_cache_exclusion_cookies() {
        $cookies = array(
            'vrstore_cart',
            'vrstore_session',
            'vrstore_user_role',
            'vrstore_checkout_step',
            'vrstore_nonce_hash',
            'wordpress_logged_in', // WordPress login cookie
            'wordpress_test_cookie' // WordPress test cookie
        );

        // Apply filter to allow customization
        $cookies = apply_filters( 'vrstore_litespeed_exclusion_cookies', $cookies );

        // If LiteSpeed API is available, set the cookies
        if ( $this->litespeed_api && method_exists( $this->litespeed_api, 'set_cache_exclude_cookies' ) ) {
            foreach ( $cookies as $cookie ) {
                $this->litespeed_api->set_cache_exclude_cookies( $cookie );
            }
        }
        
        // Also set cookies via hooks for LiteSpeed
        add_action( 'init', array( $this, 'set_nonce_hash_cookie' ), 1 );
    }

    /**
     * Set nonce hash cookie for cache exclusion
     *
     * @since 1.0.0
     * @return void
     */
    public function set_nonce_hash_cookie() {
        // Set nonce hash cookie on pages with Vira Store content
        if ( $this->has_vira_store_shortcode() || $this->has_buy_button() ) {
            $nonce = wp_create_nonce( 'vrstore_frontend_nonce' );
            $nonce_hash = md5( $nonce . time() );
            
            // Set cookie if not already set or if expired
            if ( ! isset( $_COOKIE['vrstore_nonce_hash'] ) || 
                 ( isset( $_COOKIE['vrstore_nonce_hash'] ) && 
                   $_COOKIE['vrstore_nonce_hash'] !== $nonce_hash ) ) {
                setcookie( 'vrstore_nonce_hash', $nonce_hash, time() + 3600, '/', '', is_ssl(), false );
            }
        }
    }

    /**
     * Set cache exclusion URLs.
     *
     * @since 1.0.0
     * @return void
     */
    private function set_cache_exclusion_urls() {
        $urls = array(
            '/wp-admin/admin-ajax.php',
            '/wp-admin/admin-post.php'
        );

        // Add custom URLs based on settings
        $settings = $this->settings->get_setting( 'litespeed_exclude_pages', array() );
        if ( ! empty( $settings ) ) {
            $urls = array_merge( $urls, $settings );
        }

        // Apply filter to allow customization
        $urls = apply_filters( 'vrstore_litespeed_exclusion_urls', $urls );

        // Store for future reference
        update_option( 'vrstore_litespeed_excluded_urls', $urls );
    }

    /**
     * Get LiteSpeed Cache configuration recommendations.
     *
     * @since 1.0.0
     * @return array
     */
    public function get_configuration_recommendations() {
        return array(
            'cache_ttl' => array(
                'label'       => $this->get_translated_text( 'Cache TTL' ),
                'recommended' => '86400', // 24 hours
                'description' => $this->get_translated_text( 'Recommended cache time-to-live for store pages.' ),
            ),
            'exclude_cookies' => array(
                'label'       => $this->get_translated_text( 'Exclude Cookies' ),
                'recommended' => 'vrstore_cart,vrstore_session,vrstore_user_role',
                'description' => $this->get_translated_text( 'Cookies that should exclude pages from caching.' ),
            ),
            'exclude_urls' => array(
                'label'       => $this->get_translated_text( 'Exclude URLs' ),
                'recommended' => '/wp-admin/admin-ajax.php,/wp-admin/admin-post.php',
                'description' => $this->get_translated_text( 'URLs that should be excluded from caching.' ),
            ),
            'purge_rules' => array(
                'label'       => $this->get_translated_text( 'Purge Rules' ),
                'recommended' => 'Automatic purging on cart/order/license changes',
                'description' => $this->get_translated_text( 'Automatic cache purging configuration.' ),
            ),
            'esi_support' => array(
                'label'       => $this->get_translated_text( 'ESI Support' ),
                'recommended' => 'Enable for cart count and user info',
                'description' => $this->get_translated_text( 'Edge Side Includes for dynamic content.' ),
            ),
        );
    }
}
