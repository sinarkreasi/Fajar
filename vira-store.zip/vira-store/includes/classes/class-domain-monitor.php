<?php
/**
 * Domain monitoring class for license activation tracking
 *
 * @package Vira_Store
 * @since 1.0.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Domain monitoring class for tracking customer license activations
 * Monitors which domains customers are using their license keys on
 */
class VRSTORE_Domain_Monitor {
    /**
     * Singleton instance
     *
     * @var VRSTORE_Domain_Monitor|null
     */
    private static ?VRSTORE_Domain_Monitor $instance = null;

    /**
     * Database instance
     *
     * @var VRSTORE_Database
     */
    private VRSTORE_Database $db;

    /**
     * Maximum activation attempts per day per license
     *
     * @var int
     */
    private int $max_activation_attempts = 10;

    /**
     * Grace period for expired licenses (in days)
     *
     * @var int
     */
    private int $grace_period_days = 7;

    /**
     * Get singleton instance
     *
     * @return VRSTORE_Domain_Monitor
     */
    public static function get_instance(): VRSTORE_Domain_Monitor {
        if (null === self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Get translated text with conditional loading check.
     *
     * @since 1.0.0
     * @param string $text The text to translate.
     * @return string
     */
    private function get_translated_text( $text ) {
        if ( vrstore_is_textdomain_ready() ) {
            return esc_html__( $text, 'vira-store' );
        }
        return esc_html( $text );
    }

    /**
     * Constructor
     */
    private function __construct() {
        $this->db = VRSTORE_Database::get_instance();
        
        // Initialize hooks
        add_action('init', [$this, 'init']);
        
        // API hooks for license activation/deactivation
        add_action('wp_ajax_vrstore_activate_license', [$this, 'ajax_activate_license']);
        add_action('wp_ajax_vrstore_deactivate_license', [$this, 'ajax_deactivate_license']);
        add_action('wp_ajax_vrstore_check_license', [$this, 'ajax_check_license']);
        
        // No-priv versions for external API calls
        add_action('wp_ajax_nopriv_vrstore_activate_license', [$this, 'ajax_activate_license']);
        add_action('wp_ajax_nopriv_vrstore_deactivate_license', [$this, 'ajax_deactivate_license']);
        add_action('wp_ajax_nopriv_vrstore_check_license', [$this, 'ajax_check_license']);
        
        // Admin AJAX handlers
        add_action('wp_ajax_vrstore_get_domain_activations', [$this, 'ajax_get_domain_activations']);
        add_action('wp_ajax_vrstore_force_deactivate_domain', [$this, 'ajax_force_deactivate_domain']);
        add_action('wp_ajax_vrstore_refresh_domain_status', [$this, 'ajax_refresh_domain_status']);
        
        // Frontend AJAX handlers for logged-in users (domain management from customer portal)
        add_action('wp_ajax_vrstore_activate_domain', [$this, 'ajax_activate_domain_frontend']);
        add_action('wp_ajax_vrstore_deactivate_domain', [$this, 'ajax_deactivate_domain_frontend']);
        
        // Unified frontend AJAX handlers
        add_action('wp_ajax_vrstore_activate_domain_unified', [$this, 'ajax_activate_domain_unified']);
        add_action('wp_ajax_vrstore_deactivate_domain_unified', [$this, 'ajax_deactivate_domain_unified']);
        
        // Force domain status refresh for frontend
        add_action('wp_ajax_vrstore_force_domain_status_refresh', [$this, 'ajax_force_domain_status_refresh']);
    }

    /**
     * Initialize the domain monitoring system
     */
    public function init(): void {
        // Domain monitoring cron jobs are disabled for production
        // Uncomment the lines below to enable automatic domain monitoring
        /*
        // Schedule domain monitoring checks
        if (!wp_next_scheduled('vrstore_domain_monitoring_check')) {
            wp_schedule_event(time(), 'hourly', 'vrstore_domain_monitoring_check');
        }
        add_action('vrstore_domain_monitoring_check', [$this, 'run_monitoring_checks']);
        
        // Schedule notification checks
        if (!wp_next_scheduled('vrstore_domain_notification_check')) {
            wp_schedule_event(time(), 'twicedaily', 'vrstore_domain_notification_check');
        }
        add_action('vrstore_domain_notification_check', [$this, 'check_and_send_notifications']);
        
        // Schedule daily cleanup
        if (!wp_next_scheduled('vrstore_domain_cleanup')) {
            wp_schedule_event(time(), 'daily', 'vrstore_domain_cleanup');
        }
        add_action('vrstore_domain_cleanup', [$this, 'cleanup_old_logs']);
        */
    }

    /**
     * Activate license on a domain
     *
     * @param string $license_key License key
     * @param string $domain      Domain name
     * @param string $product_id  Product ID (optional)
     * @return array Activation result
     */
    public function activate_license(string $license_key, string $domain, string $product_id = ''): array {
        // Validate inputs
        if (empty($license_key) || empty($domain)) {
            return [
                'success' => false,
                'error' => 'missing_required_fields',
                'message' => $this->get_translated_text('License key and domain are required.')
            ];
        }

        // Clean domain name
        $domain = $this->sanitize_domain($domain);

        // Validate domain format
        if (!$this->is_valid_domain($domain)) {
            return [
                'success' => false,
                'error' => 'invalid_domain',
                'message' => $this->get_translated_text('Invalid domain format.')
            ];
        }

        // Check activation attempts limit (before transaction)
        if (!$this->check_activation_attempts($license_key)) {
            return [
                'success' => false,
                'error' => 'too_many_attempts',
                'message' => $this->get_translated_text('Too many activation attempts today. Please try again tomorrow.')
            ];
        }

        global $wpdb;
        $licenses_table = $this->db->get_table_name('licenses');
        $activations_table = $this->db->get_table_name('license_domain_activations');

        // START TRANSACTION - Move ALL validation inside for race condition prevention
        $wpdb->query('START TRANSACTION');

        try {
            // Get license with exclusive lock
            $license = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $licenses_table WHERE license_key = %s FOR UPDATE",
                $license_key
            ), ARRAY_A);

            if (!$license) {
                $wpdb->query('ROLLBACK');
                return [
                    'success' => false,
                    'error' => 'license_not_found',
                    'message' => $this->get_translated_text('License key not found.')
                ];
            }

            // Check license status
            $status = isset($license['status']) ? sanitize_text_field($license['status']) : 'active';
            if ($status !== 'active') {
                $wpdb->query('ROLLBACK');
                return [
                    'success' => false,
                    'error' => 'license_' . $status,
                    'message' => $this->get_translated_text('License is not active.')
                ];
            }

            // Check expiration
            $expires_at = $license['expires_at'] ?? $license['expiry_date'] ?? null;
            if (!empty($expires_at) && $expires_at !== '0000-00-00' && $expires_at !== '0000-00-00 00:00:00') {
                $expires_timestamp = strtotime($expires_at);
                if ($expires_timestamp !== false) {
                    $grace_end = $expires_timestamp + ($this->grace_period_days * 24 * 60 * 60);
                    if (time() > $grace_end) {
                        $wpdb->query('ROLLBACK');
                        return [
                            'success' => false,
                            'error' => 'license_expired',
                            'message' => $this->get_translated_text('License has expired.')
                        ];
                    }
                }
            }

            // Check if domain already activated (with lock)
            $existing_activation = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $activations_table WHERE license_key = %s AND domain = %s FOR UPDATE",
                $license_key,
                $domain
            ), ARRAY_A);

            if ($existing_activation && $existing_activation['status'] === 'active') {
                $wpdb->query('COMMIT');
                return [
                    'success' => true,
                    'message' => $this->get_translated_text('License is already active on this domain.'),
                    'activation' => $existing_activation,
                    'already_active' => true
                ];
            }

            // Check activation limit WITH LOCKED DATA
            $activation_limit = intval($license['activation_limit']) ?: 1;
            $activation_count = intval($license['activation_count']) ?: 0;

            if ($activation_count >= $activation_limit && $activation_limit > 0) {
                $wpdb->query('ROLLBACK');
                return [
                    'success' => false,
                    'error' => 'max_domains_reached',
                    'message' => sprintf(
                        $this->get_translated_text('License has reached activation limit (%d/%d).'),
                        $activation_count,
                        $activation_limit
                    )
                ];
            }

            // Create activation record (already inside transaction from create_domain_activation)
            // Note: create_domain_activation has its own transaction, so we commit here first
            $wpdb->query('COMMIT');
            
            $activation_id = $this->create_domain_activation($license_key, $domain, $license, $product_id);
        
            if (!$activation_id) {
                return [
                    'success' => false,
                    'error' => 'activation_failed',
                    'message' => $this->get_translated_text('Failed to activate license on domain.')
                ];
            }

            // Get activation data
            $activation = $this->get_domain_activation_by_id($activation_id);
        
            // Immediately check domain status to update last_checked with fresh timestamp
            if ($activation) {
                $this->check_domain_status($activation);
                // Clear object cache for this activation
                wp_cache_delete('domain_activation_' . $activation_id, 'vrstore');
                wp_cache_delete('license_domains_' . $license_key, 'vrstore');
                
                // Re-fetch activation data with updated timestamp
                $activation = $this->get_domain_activation_by_id($activation_id);
            }

            // Send activation notification if enabled
            $this->maybe_send_activation_notification($activation);
            
            // Clear cache for this license key to ensure fresh data on next load
            $args_variants = [
                ['status' => 'active', 'per_page' => 100],
                ['status' => 'active', 'per_page' => 20],
                ['status' => '', 'per_page' => 100],
                ['status' => '', 'per_page' => 20]
            ];
            foreach ($args_variants as $args) {
                $cache_key = 'vrstore_license_domain_activations_' . md5($license_key . serialize($args));
                delete_transient($cache_key);
            }

            return [
                'success' => true,
                'message' => $this->get_translated_text('License activated successfully.'),
                'activation' => $activation,
                'license' => [
                    'key' => $license_key,
                    'status' => $license['status'],
                    'expires' => $license['expires_at'] ?? $license['expiry_date'] ?? null,
                    'max_domains' => $activation_limit
                ],
                // Debug information
                'debug_info' => [
                    'activation_time' => current_time('mysql'),
                    'server_timestamp' => time(),
                    'timezone' => wp_timezone_string(),
                    'activation_id' => $activation_id
                ]
            ];

        } catch (Exception $e) {
            $wpdb->query('ROLLBACK');
            error_log('ViraStore: License activation exception: ' . $e->getMessage());
            return [
                'success' => false,
                'error' => 'activation_exception',
                'message' => $this->get_translated_text('An error occurred during license activation.')
            ];
        }
    }

    /**
     * Deactivate license from a domain
     *
     * @param string $license_key License key
     * @param string $domain      Domain name
     * @return array Deactivation result
     */
    public function deactivate_license(string $license_key, string $domain): array {
        // Validate inputs
        if (empty($license_key) || empty($domain)) {
            return [
                'success' => false,
                'error' => 'missing_required_fields',
                'message' => $this->get_translated_text('License key and domain are required.')
            ];
        }

        // Clean domain name
        $domain = $this->sanitize_domain($domain);



        // Check if domain activation exists
        $activation = $this->get_domain_activation($license_key, $domain);
        if (!$activation) {
            return [
                'success' => false,
                'error' => 'activation_not_found',
                'message' => $this->get_translated_text('No active license found for this domain.')
            ];
        }

        // Deactivate
        if ($this->deactivate_domain_license($activation['id'])) {
            // Clear cache for this license key to ensure fresh data on next load
            wp_cache_delete('license_domains_' . $license_key, 'vrstore');
            $args_variants = [
                ['status' => 'active', 'per_page' => 100],
                ['status' => 'active', 'per_page' => 20],
                ['status' => '', 'per_page' => 100],
                ['status' => '', 'per_page' => 20]
            ];
            foreach ($args_variants as $args) {
                $cache_key = 'vrstore_license_domain_activations_' . md5($license_key . serialize($args));
                delete_transient($cache_key);
            }
            
            return [
                'success' => true,
                'message' => $this->get_translated_text('License deactivated successfully.'),
                'activation' => $activation
            ];
        }

        return [
            'success' => false,
            'error' => 'deactivation_failed',
            'message' => $this->get_translated_text('Failed to deactivate license.')
        ];
    }

    /**
     * Check license status for a domain
     *
     * @param string $license_key License key
     * @param string $domain      Domain name
     * @return array License status
     */
    public function check_license(string $license_key, string $domain = ''): array {
        if (empty($license_key)) {
            return [
                'valid' => false,
                'error' => 'missing_license_key',
                'message' => $this->get_translated_text('License key is required.')
            ];
        }

        // Check if license exists
        $license_check = $this->check_license_validity($license_key);
        if (!$license_check['valid']) {
            return $license_check;
        }

        $license = $license_check['license'];
        $result = [
            'valid' => true,
            'license' => [
                'key' => $license_key,
                'status' => $license['status'],
                'expires' => $license['expires_at'],
                'max_domains' => intval($license['activation_limit']) ?: 1
            ]
        ];

        // If domain provided, check domain-specific activation
        if (!empty($domain)) {
            $domain = $this->sanitize_domain($domain);
            $activation = $this->get_domain_activation($license_key, $domain);
            
            if ($activation) {
                $result['domain_activation'] = $activation;
                $result['activated_on_domain'] = $activation['status'] === 'active';
            } else {
                $result['activated_on_domain'] = false;
            }
        }

        // Get all active domains for this license
        $active_domains = $this->get_active_domains_for_license($license_key);
        $result['active_domains'] = array_column($active_domains, 'domain');
        $result['domains_count'] = count($active_domains);

        return $result;
    }

    /**
     * Get domain activations for a license
     *
     * @param string $license_key License key
     * @param array  $args        Query arguments
     * @return array Domain activations with pagination
     */
    public function get_license_domain_activations(string $license_key, array $args = []): array {
        global $wpdb;

        $defaults = [
            'per_page' => 20,
            'page' => 1,
            'status' => '',
            'orderby' => 'activated_at',
            'order' => 'DESC'
        ];

        $args = wp_parse_args($args, $defaults);
        $table = $this->db->get_table_name('license_domain_activations');

        // Build WHERE clause
        $where_conditions = ['license_key = %s'];
        $where_values = [$license_key];

        if (!empty($args['status'])) {
            $where_conditions[] = 'status = %s';
            $where_values[] = $args['status'];
        }

        $where_clause = 'WHERE ' . implode(' AND ', $where_conditions);

        // Build ORDER BY clause
        $allowed_orderby = ['domain', 'status', 'activated_at', 'last_checked', 'deactivated_at'];
        $orderby = in_array($args['orderby'], $allowed_orderby) ? $args['orderby'] : 'activated_at';
        $order = strtoupper($args['order']) === 'ASC' ? 'ASC' : 'DESC';

        // Get total count
        $count_query = "SELECT COUNT(*) FROM $table $where_clause";
        
        // Ensure all where_values are scalar to prevent wpdb->prepare array error
        $safe_where_values = [];
        foreach ($where_values as $value) {
            if (is_scalar($value)) {
                $safe_where_values[] = $value;
            } else {
                // Convert non-scalar values to strings or handle appropriately
                $safe_where_values[] = is_null($value) ? '' : (string) $value;
            }
        }
        
        $prepared_count_query = call_user_func_array(
            [$wpdb, 'prepare'],
            array_merge([$count_query], $safe_where_values)
        );
        $total_items = (int) $wpdb->get_var($prepared_count_query);

        // Get activations
        $offset = ($args['page'] - 1) * $args['per_page'];
        $limit_clause = $wpdb->prepare('LIMIT %d, %d', $offset, $args['per_page']);

        $query = "SELECT * FROM $table $where_clause ORDER BY $orderby $order $limit_clause";
        $prepared_query = call_user_func_array(
            [$wpdb, 'prepare'],
            array_merge([$query], $safe_where_values)
        );
        $activations = $wpdb->get_results($prepared_query, ARRAY_A);

        $result = [
            'activations' => $activations,
            'total_items' => $total_items,
            'total_pages' => ceil($total_items / $args['per_page']),
            'current_page' => $args['page'],
            'per_page' => $args['per_page']
        ];
        
        // Cache result for 5 minutes
        $cache_key = 'vrstore_license_domain_activations_' . md5($license_key . serialize($args));
        set_transient($cache_key, $result, 5 * MINUTE_IN_SECONDS);
        
        return $result;
    }

    /**
     * Get domain activations across all licenses with filtering
     *
     * @param array $args Query arguments
     * @return array Domain activations with pagination
     */
    public function get_domain_activations(array $args = []): array {
        global $wpdb;

        // Check if required table exists
        if (!$this->db->table_exists('license_domain_activations')) {
            return [
                'activations' => [],
                'total_items' => 0,
                'total_pages' => 0,
                'current_page' => 1,
                'per_page' => 20
            ];
        }

        $defaults = [
            'per_page' => 20,
            'page' => 1,
            'status' => '',
            'domain' => '',
            'license_key' => '',
            'product_id' => '',
            'search' => '',
            'license_type' => '',
            'orderby' => 'activated_at',
            'order' => 'DESC'
        ];

        $args = wp_parse_args($args, $defaults);
        $activations_table = $this->db->get_table_name('license_domain_activations');
        $licenses_table = $this->db->get_table_name('licenses');

        // Build WHERE clause
        $where_conditions = [];
        $where_values = [];
        $join_license_table = false;

        if (!empty($args['status'])) {
            $where_conditions[] = 'a.status = %s';
            $where_values[] = $args['status'];
        }

        if (!empty($args['domain'])) {
            $where_conditions[] = 'a.domain LIKE %s';
            $where_values[] = '%' . $wpdb->esc_like($args['domain']) . '%';
        }

        if (!empty($args['license_key'])) {
            $where_conditions[] = 'a.license_key = %s';
            $where_values[] = $args['license_key'];
        }

        if (!empty($args['product_id'])) {
            $where_conditions[] = 'a.product_id = %s';
            $where_values[] = $args['product_id'];
        }

        if (!empty($args['search'])) {
            $where_conditions[] = '(a.domain LIKE %s OR a.license_key LIKE %s)';
            $search_term = '%' . $wpdb->esc_like($args['search']) . '%';
            $where_values[] = $search_term;
            $where_values[] = $search_term;
        }

        // Handle license type filtering
        if (!empty($args['license_type'])) {
            $join_license_table = true;
            $where_conditions[] = 'l.license_type_slug = %s';
            $where_values[] = $args['license_type'];
        }

        // Build FROM and JOIN clauses
        if ($join_license_table) {
            $from_clause = "FROM $activations_table a LEFT JOIN $licenses_table l ON a.license_key = l.license_key";
            $select_clause = "SELECT a.*";
        } else {
            $from_clause = "FROM $activations_table a";
            $select_clause = "SELECT a.*";
        }

        $where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

        // Build ORDER BY clause
        $allowed_orderby = ['domain', 'license_key', 'status', 'activated_at', 'last_checked', 'deactivated_at'];
        $orderby = in_array($args['orderby'], $allowed_orderby) ? $args['orderby'] : 'activated_at';
        $order = strtoupper($args['order']) === 'ASC' ? 'ASC' : 'DESC';

        // Get total count
        $count_query = "SELECT COUNT(*) $from_clause $where_clause";
        if (!empty($where_values)) {
            $count_query = $wpdb->prepare($count_query, ...$where_values);
        }
        $total_items = (int) $wpdb->get_var($count_query);

        // Get activations
        $offset = ($args['page'] - 1) * $args['per_page'];
        $limit_clause = $wpdb->prepare('LIMIT %d, %d', $offset, $args['per_page']);

        $query = "$select_clause $from_clause $where_clause ORDER BY a.$orderby $order $limit_clause";
        if (!empty($where_values)) {
            $query = $wpdb->prepare($query, ...$where_values);
        }

        $activations = $wpdb->get_results($query, ARRAY_A);

        return [
            'activations' => $activations,
            'total_items' => $total_items,
            'total_pages' => ceil($total_items / $args['per_page']),
            'current_page' => $args['page'],
            'per_page' => $args['per_page']
        ];
    }

    /**
     * Get domain monitoring statistics
     *
     * @return array Statistics
     */
    public function get_statistics(): array {
        global $wpdb;

        // Check if required tables exist
        if (!$this->db->table_exists('license_domain_activations') || 
            !$this->db->table_exists('license_activation_logs') ||
            !$this->db->table_exists('licenses')) {
            return [
                'total_activations' => 0,
                'status_counts' => [],
                'today_attempts' => 0,
                'failed_attempts' => 0,
                'expiring_soon' => 0
            ];
        }

        $activations_table = $this->db->get_table_name('license_domain_activations');
        $logs_table = $this->db->get_table_name('license_activation_logs');

        // Activation counts by status
        $status_counts = $wpdb->get_results(
            "SELECT status, COUNT(*) as count FROM $activations_table GROUP BY status",
            ARRAY_A
        );

        $status_stats = [];
        if ($status_counts) {
            foreach ($status_counts as $row) {
                $status_stats[$row['status']] = (int) $row['count'];
            }
        }

        // Today's activation attempts
        $today_attempts = $wpdb->get_var(
            "SELECT COUNT(*) FROM $logs_table 
             WHERE DATE(attempt_time) = CURDATE()"
        );

        // Failed attempts in last 24 hours
        $failed_attempts = $wpdb->get_var(
            "SELECT COUNT(*) FROM $logs_table 
             WHERE attempt_time >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
             AND success = 0"
        );

        // Licenses with expiring domains (next 30 days)
        $expiring_soon = $wpdb->get_var(
            "SELECT COUNT(DISTINCT a.license_key) FROM $activations_table a
             JOIN {$this->db->get_table_name('licenses')} l ON a.license_key = l.license_key
             WHERE a.status = 'active'
             AND l.expires_at BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)"
        );

        return [
            'total_activations' => array_sum($status_stats),
            'status_counts' => $status_stats,
            'today_attempts' => (int) $today_attempts ?: 0,
            'failed_attempts' => (int) $failed_attempts ?: 0,
            'expiring_soon' => (int) $expiring_soon ?: 0
        ];
    }

    /**
     * Run monitoring checks for active domain activations
     */
    public function run_monitoring_checks(): void {
        global $wpdb;

        // Check if required table exists
        if (!$this->db->table_exists('license_domain_activations')) {
            return;
        }

        // Check if monitoring is already running (prevent concurrent execution)
        $monitoring_lock = get_transient('vrstore_domain_monitoring_lock');
        if ($monitoring_lock) {
            return;
        }

        // Set lock for 30 minutes
        set_transient('vrstore_domain_monitoring_lock', time(), 30 * MINUTE_IN_SECONDS);

        $activations_table = $this->db->get_table_name('license_domain_activations');
        
        // Get active domain activations that need checking with limit to prevent memory issues
        $activations = $wpdb->get_results(
            "SELECT * FROM $activations_table 
             WHERE status = 'active' 
             AND (last_checked IS NULL OR last_checked < DATE_SUB(NOW(), INTERVAL 1 HOUR))
             ORDER BY last_checked ASC
             LIMIT 100",
            ARRAY_A
        );

        if (!$activations) {
            delete_transient('vrstore_domain_monitoring_lock');
            return;
        }

        foreach ($activations as $activation) {
            $this->check_domain_status($activation);
            
            // Add small delay to prevent overwhelming servers
            usleep(100000); // 0.1 seconds
        }

        // Release lock
        delete_transient('vrstore_domain_monitoring_lock');
    }

    /**
     * Check and send notifications
     */
    public function check_and_send_notifications(): void {
        $this->check_expiry_notifications();
        $this->check_suspicious_activity_notifications();
        $this->process_pending_notifications();
    }

    /**
     * Clean up old logs and expired activations
     */
    public function cleanup_old_logs(): void {
        global $wpdb;

        // Check if required tables exist
        if (!$this->db->table_exists('license_activation_logs') || 
            !$this->db->table_exists('license_notifications')) {
            return;
        }

        $logs_table = $this->db->get_table_name('license_activation_logs');
        $notifications_table = $this->db->get_table_name('license_notifications');

        // Keep activation logs for 90 days
        $wpdb->query(
            "DELETE FROM $logs_table WHERE attempt_time < DATE_SUB(NOW(), INTERVAL 90 DAY)"
        );

        // Keep notifications for 180 days
        $wpdb->query(
            "DELETE FROM $notifications_table WHERE created_at < DATE_SUB(NOW(), INTERVAL 180 DAY)"
        );

        // Deactivate licenses that have been expired for more than grace period
        $this->deactivate_expired_licenses();
    }

    /* === AJAX HANDLERS === */

    /**
     * AJAX handler for license activation
     */
    public function ajax_activate_license(): void {
        // Rate limiting check
        $ip = $this->get_client_ip();
        $rate_limit_key = 'vrstore_activation_rate_' . $ip . '_' . date('Y-m-d-H');
        $attempts = get_transient($rate_limit_key) ?: 0;
        
        if ($attempts >= 20) { // Max 20 attempts per hour per IP
            wp_send_json_error([
                'error' => 'rate_limit_exceeded',
                'message' => __('Too many activation attempts. Please try again later.', 'vira-store')
            ]);
            return;
        }
        
        set_transient($rate_limit_key, $attempts + 1, HOUR_IN_SECONDS);
        
        // Check if we have required parameters - prioritize POST, fallback to GET
        $license_key = '';
        $domain = '';
        $product_id = '';
        
        if (isset($_POST['license_key'])) {
            $license_key = sanitize_text_field(wp_unslash($_POST['license_key']));
        } elseif (isset($_GET['license_key'])) {
            $license_key = sanitize_text_field(wp_unslash($_GET['license_key']));
        }
        
        if (isset($_POST['domain'])) {
            $domain = sanitize_text_field(wp_unslash($_POST['domain']));
        } elseif (isset($_GET['domain'])) {
            $domain = sanitize_text_field(wp_unslash($_GET['domain']));
        }
        
        if (isset($_POST['product_id'])) {
            $product_id = sanitize_text_field(wp_unslash($_POST['product_id']));
        } elseif (isset($_GET['product_id'])) {
            $product_id = sanitize_text_field(wp_unslash($_GET['product_id']));
        }

        if (empty($license_key) || empty($domain)) {
            wp_send_json_error([
                'error' => 'missing_parameters',
                'message' => __('License key and domain are required.', 'vira-store')
            ]);
            return;
        }

        // Validate license key format
        if (strlen($license_key) < 10 || strlen($license_key) > 100) {
            wp_send_json_error([
                'error' => 'invalid_license_format',
                'message' => __('Invalid license key format.', 'vira-store')
            ]);
            return;
        }

        $result = $this->activate_license($license_key, $domain, $product_id);

        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }

    /**
     * AJAX handler for license deactivation
     */
    public function ajax_deactivate_license(): void {
        $license_key = sanitize_text_field($_POST['license_key'] ?? $_GET['license_key'] ?? '');
        $domain = sanitize_text_field($_POST['domain'] ?? $_GET['domain'] ?? '');

        if (empty($license_key) || empty($domain)) {
            wp_send_json_error([
                'error' => 'missing_parameters',
                'message' => __('License key and domain are required.', 'vira-store')
            ]);
        }

        $result = $this->deactivate_license($license_key, $domain);

        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }

    /**
     * AJAX handler for license checking
     */
    public function ajax_check_license(): void {
        // Rate limiting check
        $ip = $this->get_client_ip();
        $rate_limit_key = 'vrstore_check_rate_' . $ip . '_' . date('Y-m-d-H');
        $attempts = get_transient($rate_limit_key) ?: 0;
        
        if ($attempts >= 100) { // Max 100 checks per hour per IP
            wp_send_json_error([
                'error' => 'rate_limit_exceeded',
                'message' => __('Too many license checks. Please try again later.', 'vira-store')
            ]);
            return;
        }
        
        set_transient($rate_limit_key, $attempts + 1, HOUR_IN_SECONDS);
        
        // Sanitize inputs - prioritize POST, fallback to GET
        $license_key = '';
        $domain = '';
        
        if (isset($_POST['license_key'])) {
            $license_key = sanitize_text_field(wp_unslash($_POST['license_key']));
        } elseif (isset($_GET['license_key'])) {
            $license_key = sanitize_text_field(wp_unslash($_GET['license_key']));
        }
        
        if (isset($_POST['domain'])) {
            $domain = sanitize_text_field(wp_unslash($_POST['domain']));
        } elseif (isset($_GET['domain'])) {
            $domain = sanitize_text_field(wp_unslash($_GET['domain']));
        }

        if (empty($license_key)) {
            wp_send_json_error([
                'error' => 'missing_license_key',
                'message' => __('License key is required.', 'vira-store')
            ]);
            return;
        }
        
        // Validate license key format
        if (strlen($license_key) < 10 || strlen($license_key) > 100) {
            wp_send_json_error([
                'error' => 'invalid_license_format',
                'message' => __('Invalid license key format.', 'vira-store')
            ]);
            return;
        }

        $result = $this->check_license($license_key, $domain);

        if ($result['valid']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }

    /**
     * AJAX handler for getting domain activations (admin)
     */
    public function ajax_get_domain_activations(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_admin_nonce')) {
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'vira-store')]);
        }

        $args = [
            'page' => intval($_POST['page'] ?? 1),
            'per_page' => intval($_POST['per_page'] ?? 20),
            'status' => sanitize_text_field($_POST['status'] ?? ''),
            'search' => sanitize_text_field($_POST['search'] ?? ''),
            'license_key' => sanitize_text_field($_POST['license_key'] ?? ''),
        ];

        $result = $this->get_domain_activations($args);
        wp_send_json_success($result);
    }

    /**
     * AJAX handler for force deactivating a domain (admin)
     */
    public function ajax_force_deactivate_domain(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_admin_nonce')) {
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'vira-store')]);
        }

        $activation_id = intval($_POST['activation_id'] ?? 0);

        if (!$activation_id) {
            wp_send_json_error(['message' => __('Invalid activation ID.', 'vira-store')]);
        }

        if ($this->deactivate_domain_license($activation_id, 'admin_forced')) {
            wp_send_json_success([
                'message' => __('Domain activation has been deactivated.', 'vira-store')
            ]);
        } else {
            wp_send_json_error(['message' => __('Failed to deactivate domain.', 'vira-store')]);
        }
    }

    /**
     * AJAX handler for refreshing domain status (admin)
     */
    public function ajax_refresh_domain_status(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_admin_nonce')) {
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'vira-store')]);
        }

        $activation_id = intval($_POST['activation_id'] ?? 0);

        if (!$activation_id) {
            wp_send_json_error(['message' => __('Invalid activation ID.', 'vira-store')]);
        }

        $activation = $this->get_domain_activation_by_id($activation_id);
        if (!$activation) {
            wp_send_json_error(['message' => __('Activation not found.', 'vira-store')]);
        }

        $status = $this->check_domain_status($activation);

        wp_send_json_success([
            'message' => __('Domain status refreshed.', 'vira-store'),
            'status' => $status
        ]);
    }
    
    /**
     * AJAX handler for activating domain from frontend
     */
    public function ajax_activate_domain_frontend(): void {
        // Check if user is logged in
        if (!is_user_logged_in()) {
            wp_send_json_error([
                'error' => 'not_logged_in',
                'message' => __('You must be logged in to manage domains.', 'vira-store')
            ]);
        }
        
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_frontend_nonce')) {
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
        }
        
        $license_key = sanitize_text_field($_POST['license_key'] ?? '');
        $domain = sanitize_text_field($_POST['domain'] ?? '');
        $product_id = sanitize_text_field($_POST['product_id'] ?? '');
        $current_user_id = get_current_user_id();
        
        if (empty($license_key) || empty($domain)) {
            wp_send_json_error([
                'error' => 'missing_parameters',
                'message' => __('License key and domain are required.', 'vira-store')
            ]);
        }
        
        // Check if user owns this license
        $owns_license = $this->user_owns_license($current_user_id, $license_key);
        
        if (!$owns_license) {
            wp_send_json_error([
                'error' => 'permission_denied',
                'message' => __('You do not have permission to manage this license.', 'vira-store')
            ]);
        }
        
        $result = $this->activate_license($license_key, $domain, $product_id);
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }
    
    /**
     * AJAX handler for deactivating domain from frontend
     */
    public function ajax_deactivate_domain_frontend(): void {
        // Check if user is logged in
        if (!is_user_logged_in()) {
            wp_send_json_error([
                'error' => 'not_logged_in',
                'message' => __('You must be logged in to manage domains.', 'vira-store')
            ]);
        }
        
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_frontend_nonce')) {
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
        }
        
        $license_key = sanitize_text_field($_POST['license_key'] ?? '');
        $domain = sanitize_text_field($_POST['domain'] ?? '');
        $current_user_id = get_current_user_id();
        
        if (empty($license_key) || empty($domain)) {
            wp_send_json_error([
                'error' => 'missing_parameters',
                'message' => __('License key and domain are required.', 'vira-store')
            ]);
        }
        
        // Check if user owns this license
        if (!$this->user_owns_license($current_user_id, $license_key)) {
            wp_send_json_error([
                'error' => 'permission_denied',
                'message' => __('You do not have permission to manage this license.', 'vira-store')
            ]);
        }
        
        $result = $this->deactivate_license($license_key, $domain);
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }
    
    /**
     * AJAX handler for unified domain activation from frontend
     */
    public function ajax_activate_domain_unified(): void {
        // Check if user is logged in
        if (!is_user_logged_in()) {
            wp_send_json_error([
                'error' => 'not_logged_in',
                'message' => __('You must be logged in to manage domains.', 'vira-store')
            ]);
            return;
        }
        
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_frontend_nonce')) {
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
            return;
        }
        
        $domain = sanitize_text_field($_POST['domain'] ?? '');
        $customer_id_from_post = isset($_POST['customer_id']) ? intval($_POST['customer_id']) : 0;
        $current_user_id = get_current_user_id();
        
        // Security: Always use current logged-in user ID, ignore customer_id from POST (can be manipulated)
        // But validate that it matches if provided (for consistency check)
        if ($customer_id_from_post > 0 && $customer_id_from_post !== $current_user_id) {
            // Log potential security issue but don't block (user might have multiple accounts)
            error_log('ViraStore: Customer ID mismatch in unified activation. POST: ' . $customer_id_from_post . ', Current User: ' . $current_user_id);
        }
        
        if (empty($domain)) {
            wp_send_json_error([
                'error' => 'missing_domain',
                'message' => __('Domain name is required.', 'vira-store')
            ]);
            return;
        }
        
        // Validate domain format (match JavaScript validation)
        $domain_clean = $this->sanitize_domain($domain);
        if (!$this->is_valid_domain($domain_clean)) {
            wp_send_json_error([
                'error' => 'invalid_domain',
                'message' => __('Invalid domain format.', 'vira-store')
            ]);
            return;
        }
        
        // Get user's email to verify customer ownership (security: use current user, not POST data)
        $user = wp_get_current_user();
        if (!$user || !$user->user_email) {
            wp_send_json_error([
                'error' => 'user_not_found',
                'message' => __('User information not found.', 'vira-store')
            ]);
            return;
        }
        
        // Get all licenses for this customer (by email, not by customer_id from POST)
        $customer_licenses = $this->get_customer_licenses_by_email($user->user_email);
        
        if (empty($customer_licenses)) {
            wp_send_json_error([
                'error' => 'no_licenses_found',
                'message' => __('No valid licenses found for your account.', 'vira-store')
            ]);
        }
        
        // Try to activate on the first available license with capacity
        $activation_result = null;
        $license_used = null;
        
        foreach ($customer_licenses as $license) {
            // Check if this license has available activation slots
            $active_domains = $this->get_active_domains_for_license($license['license_key']);
            $max_domains = intval($license['activation_limit']) ?: 1;
            
            if (count($active_domains) < $max_domains) {
                // Try to activate on this license
                $result = $this->activate_license($license['license_key'], $domain, $license['product_id'] ?? '');
                
                if ($result['success']) {
                    $activation_result = $result;
                    $license_used = $license;
                    break;
                }
            }
        }
        
        if (!$activation_result) {
            wp_send_json_error([
                'error' => 'activation_failed',
                'message' => __('Failed to activate domain. All licenses may have reached their activation limit or no valid licenses available.', 'vira-store')
            ]);
        }
        
        // Add the license information to the result
        $activation_result['license_used'] = [
            'license_key' => $license_used['license_key'],
            'product_name' => $license_used['product_name'] ?? '',
            'license_type' => $license_used['license_type_slug'] ?? ''
        ];
        
        // Include current timestamp for frontend display
        $activation_result['server_time'] = current_time('mysql');
        $activation_result['timestamp'] = time();
        
        // Force an immediate domain status check to sync timestamps
        if (isset($activation_result['activation']['id'])) {
            $fresh_activation = $this->get_domain_activation_by_id($activation_result['activation']['id']);
            if ($fresh_activation) {
                $this->check_domain_status($fresh_activation);
                // Update the activation result with the fresh timestamp
                $updated_activation = $this->get_domain_activation_by_id($activation_result['activation']['id']);
                if ($updated_activation) {
                    $activation_result['activation']['last_checked'] = $updated_activation['last_checked'];
                }
            }
        }
        
        // Clear domain activation cache for this customer
        $this->clear_domain_activations_cache($customer_licenses);
        
        wp_send_json_success($activation_result);
    }
    
    /**
     * AJAX handler for unified domain deactivation from frontend
     */
    public function ajax_deactivate_domain_unified(): void {
        // Check if user is logged in
        if (!is_user_logged_in()) {
            wp_send_json_error([
                'error' => 'not_logged_in',
                'message' => __('You must be logged in to manage domains.', 'vira-store')
            ]);
            return;
        }
        
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_frontend_nonce')) {
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
            return;
        }
        
        $license_key = sanitize_text_field($_POST['license_key'] ?? '');
        $domain = sanitize_text_field($_POST['domain'] ?? '');
        $current_user_id = get_current_user_id();
        
        if (empty($license_key)) {
            wp_send_json_error([
                'error' => 'missing_license_key',
                'message' => __('License key is required.', 'vira-store')
            ]);
            return;
        }
        
        if (empty($domain)) {
            wp_send_json_error([
                'error' => 'missing_domain',
                'message' => __('Domain name is required.', 'vira-store')
            ]);
            return;
        }
        
        // Validate license key format
        if (strlen($license_key) < 10 || strlen($license_key) > 100) {
            wp_send_json_error([
                'error' => 'invalid_license_format',
                'message' => __('Invalid license key format.', 'vira-store')
            ]);
            return;
        }
        
        // Validate domain format
        $domain_clean = $this->sanitize_domain($domain);
        if (!$this->is_valid_domain($domain_clean)) {
            wp_send_json_error([
                'error' => 'invalid_domain',
                'message' => __('Invalid domain format.', 'vira-store')
            ]);
            return;
        }
        
        // Check if user owns this license (security: validate ownership)
        if (!$this->user_owns_license($current_user_id, $license_key)) {
            wp_send_json_error([
                'error' => 'permission_denied',
                'message' => __('You do not have permission to manage this license.', 'vira-store')
            ]);
            return;
        }
        
        // Use cleaned domain for deactivation
        $result = $this->deactivate_license($license_key, $domain_clean);
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }
    
    /**
     * AJAX handler for forcing domain status refresh
     */
    public function ajax_force_domain_status_refresh(): void {
        // Check if user is logged in
        if (!is_user_logged_in()) {
            wp_send_json_error([
                'error' => 'not_logged_in',
                'message' => __('You must be logged in to refresh domain status.', 'vira-store')
            ]);
            return;
        }
        
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_frontend_nonce')) {
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
            return;
        }
        
        $current_user_id = get_current_user_id();
        $user = wp_get_current_user();
        
        if (!$user || !$user->user_email) {
            wp_send_json_error([
                'error' => 'user_not_found',
                'message' => __('User information not found.', 'vira-store')
            ]);
            return;
        }
        
        // Security: Ignore customer_id from POST, use current user's email (can't be manipulated)
        // Note: customer_id parameter may be sent but is not trusted for security reasons
        
        // Get all domain activations for this user's email
        $customer_licenses = $this->get_customer_licenses_by_email($user->user_email);
        
        if (empty($customer_licenses)) {
            wp_send_json_error([
                'error' => 'no_licenses_found',
                'message' => __('No licenses found for your account.', 'vira-store')
            ]);
        }
        
        // Get all license keys for this customer
        $license_keys = array_column($customer_licenses, 'license_key');
        
        global $wpdb;
        $activations_table = $this->db->get_table_name('license_domain_activations');
        
        if (empty($license_keys)) {
            wp_send_json_success([
                'message' => __('No domain activations to refresh.', 'vira-store'),
                'refreshed_count' => 0
            ]);
        }
        
        // Get all active domain activations for this customer's licenses
        $placeholders = implode(',', array_fill(0, count($license_keys), '%s'));
        $query = "SELECT * FROM $activations_table WHERE license_key IN ($placeholders) AND status = 'active'";
        $prepared_query = $wpdb->prepare($query, ...$license_keys);
        $activations = $wpdb->get_results($prepared_query, ARRAY_A);
        
        $refreshed_count = 0;
        
        // Force refresh each activation's status
        foreach ($activations as $activation) {
            $this->check_domain_status($activation);
            $refreshed_count++;
        }
        
        // Clear any cached data
        foreach ($license_keys as $license_key) {
            wp_cache_delete('license_domains_' . $license_key, 'vrstore');
        }
        
        // Ensure database changes are committed
        if (method_exists($wpdb, 'flush')) {
            $wpdb->flush();
        }
        
        wp_send_json_success([
            'message' => sprintf(__('Refreshed %d domain activation(s).', 'vira-store'), $refreshed_count),
            'refreshed_count' => $refreshed_count,
            'timestamp' => current_time('mysql')
        ]);
    }
    
    /* === PRIVATE HELPER METHODS === */

    /**
     * Sanitize domain name
     *
     * @param string $domain Domain name
     * @return string Sanitized domain
     */
    private function sanitize_domain(string $domain): string {
        // Remove protocol if present
        $domain = preg_replace('#^https?://#', '', $domain);
        // Remove trailing slash and paths
        $domain = explode('/', $domain)[0];
        // Remove port numbers
        $domain = explode(':', $domain)[0];
        // Convert to lowercase
        return strtolower(trim($domain));
    }

    /**
     * Validate domain format
     *
     * @param string $domain Domain name
     * @return bool Valid domain
     */
    private function is_valid_domain(string $domain): bool {
        // Basic domain validation
        if (empty($domain) || strlen($domain) > 253) {
            return false;
        }

        // Check for valid domain pattern
        $pattern = '/^[a-z0-9]([a-z0-9\-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9\-]{0,61}[a-z0-9])?)*$/';
        
        return preg_match($pattern, $domain) && 
               !filter_var($domain, FILTER_VALIDATE_IP) && // Not an IP address
               strpos($domain, '.') !== false; // Must contain at least one dot
    }

    /**
     * Check activation attempts limit
     *
     * @param string $license_key License key
     * @return bool Within limits
     */
    private function check_activation_attempts(string $license_key): bool {
        global $wpdb;

        $logs_table = $this->db->get_table_name('license_activation_logs');
        
        $attempts = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $logs_table 
             WHERE license_key = %s 
             AND DATE(attempt_time) = CURDATE()",
            $license_key
        ));

        return intval($attempts) < $this->max_activation_attempts;
    }

    /**
     * Check license validity
     *
     * @param string $license_key License key
     * @return array License check result
     */
    private function check_license_validity(string $license_key): array {
        // Sanitize license key
        $license_key = sanitize_text_field(trim($license_key));
        
        if (empty($license_key)) {
            return [
                'valid' => false,
                'error' => 'empty_license_key',
                'message' => __('License key cannot be empty.', 'vira-store')
            ];
        }
        
        global $wpdb;

        $licenses_table = $this->db->get_table_name('licenses');
        
        // Check if table exists
        if (!$this->db->table_exists('licenses')) {
            return [
                'valid' => false,
                'error' => 'table_not_found',
                'message' => __('License system not properly initialized.', 'vira-store')
            ];
        }
        
        $license = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $licenses_table WHERE license_key = %s",
            $license_key
        ), ARRAY_A);

        if (!$license) {
            return [
                'valid' => false,
                'error' => 'license_not_found',
                'message' => __('License key not found.', 'vira-store')
            ];
        }

        // Check license status
        $status = isset($license['status']) ? sanitize_text_field($license['status']) : 'active';
        if ($status !== 'active') {
            $status_messages = [
                'inactive' => __('License is inactive.', 'vira-store'),
                'suspended' => __('License is suspended.', 'vira-store'),
                'expired' => __('License has expired.', 'vira-store')
            ];

            return [
                'valid' => false,
                'error' => 'license_' . $status,
                'message' => $status_messages[$status] ?? __('License is not active.', 'vira-store'),
                'license' => $license
            ];
        }

        // Check expiration (handle both expires_at and expiry_date for backward compatibility)
        $expires_at = $license['expires_at'] ?? $license['expiry_date'] ?? null;
        
        if (!empty($expires_at) && $expires_at !== '0000-00-00' && $expires_at !== '0000-00-00 00:00:00') {
            $expires_timestamp = strtotime($expires_at);
            
            if ($expires_timestamp !== false) {
                $grace_end = $expires_timestamp + ($this->grace_period_days * 24 * 60 * 60);
                
                if (time() > $grace_end) {
                    // Auto-update status to expired if beyond grace period
                    if ($status !== 'expired') {
                        $wpdb->update(
                            $licenses_table,
                            ['status' => 'expired', 'updated_at' => current_time('mysql')],
                            ['license_key' => $license_key],
                            ['%s', '%s'],
                            ['%s']
                        );
                    }
                    
                    return [
                        'valid' => false,
                        'error' => 'license_expired',
                        'message' => __('License has expired.', 'vira-store'),
                        'license' => $license
                    ];
                }
            }
        }

        return [
            'valid' => true,
            'license' => $license
        ];
    }

    /**
     * Get active domains for a license
     *
     * @param string $license_key License key
     * @return array Active domains
     */
    private function get_active_domains_for_license(string $license_key): array {
        global $wpdb;

        $activations_table = $this->db->get_table_name('license_domain_activations');
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $activations_table WHERE license_key = %s AND status = 'active'",
            $license_key
        ), ARRAY_A);
    }

    /**
     * Get domain activation
     *
     * @param string $license_key License key
     * @param string $domain      Domain name
     * @return array|null Domain activation
     */
    private function get_domain_activation(string $license_key, string $domain): ?array {
        global $wpdb;

        $activations_table = $this->db->get_table_name('license_domain_activations');
        
        $activation = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $activations_table WHERE license_key = %s AND domain = %s ORDER BY activated_at DESC LIMIT 1",
            $license_key,
            $domain
        ), ARRAY_A);

        return $activation ?: null;
    }

    /**
     * Get domain activation by ID
     *
     * @param int $activation_id Activation ID
     * @return array|null Domain activation
     */
    private function get_domain_activation_by_id(int $activation_id): ?array {
        global $wpdb;

        $activations_table = $this->db->get_table_name('license_domain_activations');
        
        $activation = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $activations_table WHERE id = %d",
            $activation_id
        ), ARRAY_A);

        return $activation ?: null;
    }

    /**
     * Create domain activation
     *
     * @param string $license_key License key
     * @param string $domain      Domain name
     * @param array  $license     License data
     * @param string $product_id  Product ID
     * @return int|false Activation ID or false
     */
    private function create_domain_activation(string $license_key, string $domain, array $license, string $product_id = '') {
        global $wpdb;

        $activations_table = $this->db->get_table_name('license_domain_activations');
        
        // Deactivate any existing activation for this license/domain combination
        $wpdb->update(
            $activations_table,
            [
                'status' => 'inactive',
                'deactivated_at' => current_time('mysql'),
                'deactivation_reason' => 'reactivation'
            ],
            [
                'license_key' => $license_key,
                'domain' => $domain,
                'status' => 'active'
            ],
            ['%s', '%s', '%s'],
            ['%s', '%s', '%s']
        );

        // Create new activation with fresh timestamps
        $current_mysql_time = current_time('mysql');
        
        // Sanitize user agent
        $user_agent = '';
        if (isset($_SERVER['HTTP_USER_AGENT'])) {
            $user_agent = sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT']));
            $user_agent = substr($user_agent, 0, 500); // Limit length
        }
        
        // Use transaction to prevent race conditions
        $wpdb->query('START TRANSACTION');
        
        try {
            // Double-check domain activation doesn't exist (with lock)
            $existing = $wpdb->get_row($wpdb->prepare(
                "SELECT id FROM $activations_table WHERE license_key = %s AND domain = %s AND status = 'active' FOR UPDATE",
                $license_key,
                $domain
            ));
            
            if ($existing) {
                $wpdb->query('COMMIT');
                return $existing->id; // Return existing activation ID
            }
            
            $result = $wpdb->insert(
                $activations_table,
                [
                    'license_key' => sanitize_text_field($license_key),
                    'domain' => sanitize_text_field($domain),
                    'product_id' => sanitize_text_field($product_id),
                    'customer_id' => isset($license['customer_id']) ? absint($license['customer_id']) : 0,
                    'status' => 'active',
                    'activated_at' => $current_mysql_time,
                    'last_checked' => $current_mysql_time,
                    'activation_ip' => $this->get_client_ip(),
                    'user_agent' => $user_agent,
                    'domain_accessible' => null, // Will be checked later
                    'last_response_time' => null
                ],
                ['%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%d']
            );
            
            if ($result === false) {
                $wpdb->query('ROLLBACK');
                error_log('ViraStore: Failed to insert domain activation: ' . $wpdb->last_error);
                return false;
            }
            
            $activation_id = $wpdb->insert_id;
            $wpdb->query('COMMIT');
            
            return $activation_id;
        } catch (Exception $e) {
            $wpdb->query('ROLLBACK');
            error_log('ViraStore: Domain activation creation exception: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Deactivate domain license
     *
     * @param int    $activation_id Activation ID
     * @param string $reason        Deactivation reason
     * @return bool Success
     */
    private function deactivate_domain_license(int $activation_id, string $reason = 'manual'): bool {
        global $wpdb;

        $activations_table = $this->db->get_table_name('license_domain_activations');
        
        $result = $wpdb->update(
            $activations_table,
            [
                'status' => 'inactive',
                'deactivated_at' => current_time('mysql'),
                'deactivation_reason' => $reason
            ],
            ['id' => $activation_id],
            ['%s', '%s', '%s'],
            ['%d']
        );

        return $result !== false;
    }

    /**
     * Delete domain activation (permanently removes from database)
     * Only allows deletion of inactive activations
     *
     * @param int $activation_id Activation ID
     * @return bool Success
     */
    private function delete_domain_activation(int $activation_id): bool {
        global $wpdb;

        $activations_table = $this->db->get_table_name('license_domain_activations');
        
        // First verify the activation exists and is inactive
        $activation = $wpdb->get_row($wpdb->prepare(
            "SELECT status FROM $activations_table WHERE id = %d",
            $activation_id
        ));

        if (!$activation) {
            return false; // Activation doesn't exist
        }

        if ($activation->status !== 'inactive') {
            return false; // Can only delete inactive activations
        }

        // Permanently delete the record
        $result = $wpdb->delete(
            $activations_table,
            ['id' => $activation_id],
            ['%d']
        );

        return $result !== false;
    }

    /**
     * Check domain status
     *
     * @param array $activation Activation data
     * @return array Status check result
     */
    private function check_domain_status(array $activation): array {
        global $wpdb;

        // Validate activation data
        if (empty($activation['domain']) || empty($activation['license_key']) || empty($activation['id'])) {
            return [
                'license_valid' => false,
                'domain_accessible' => false,
                'response_time' => null,
                'last_checked' => current_time('mysql'),
                'error' => 'invalid_activation_data'
            ];
        }

        $domain = sanitize_text_field($activation['domain']);
        $license_key = sanitize_text_field($activation['license_key']);
        $activation_id = absint($activation['id']);

        // Validate domain format before checking
        if (!$this->is_valid_domain($domain)) {
            return [
                'license_valid' => false,
                'domain_accessible' => false,
                'response_time' => null,
                'last_checked' => current_time('mysql'),
                'error' => 'invalid_domain'
            ];
        }

        // Check if license is still valid
        $license_check = $this->check_license_validity($license_key);
        
        // Ensure we always get a fresh timestamp
        $fresh_timestamp = current_time('mysql');
        $status = [
            'license_valid' => $license_check['valid'],
            'domain_accessible' => false,
            'response_time' => null,
            'last_checked' => $fresh_timestamp
        ];

        // Check domain accessibility with proper error handling
        $start_time = microtime(true);
        $url = 'https://' . $domain;
        
        // Sanitize URL to prevent SSRF attacks
        $url = esc_url_raw($url, ['https']);
        if (empty($url) || strpos($url, 'https://') !== 0) {
            $status['domain_accessible'] = false;
            $status['response_time'] = 0;
        } else {
            $response = wp_remote_get($url, [
                'timeout' => 10,
                'sslverify' => true, // Always verify SSL for security
                'user-agent' => 'Vira Store License Checker/1.0',
                'redirection' => 5,
                'httpversion' => '1.1'
            ]);

            if (!is_wp_error($response)) {
                $response_code = wp_remote_retrieve_response_code($response);
                $status['domain_accessible'] = $response_code >= 200 && $response_code < 400;
            } else {
                // Log error but don't fail the check
                $status['domain_accessible'] = false;
                error_log('ViraStore: Domain check error for ' . $domain . ': ' . $response->get_error_message());
            }
        }

        $status['response_time'] = round((microtime(true) - $start_time) * 1000);

        // Update activation record (check if table exists first)
        $activations_table = $this->db->get_table_name('license_domain_activations');
        $table_exists = $this->db->table_exists('license_domain_activations');
        
        if ($table_exists) {
            $update_result = $wpdb->update(
                $activations_table,
                [
                    'last_checked' => $status['last_checked'],
                    'last_response_time' => $status['response_time'],
                    'domain_accessible' => $status['domain_accessible'] ? 1 : 0
                ],
                ['id' => $activation_id],
                ['%s', '%d', '%d'],
                ['%d']
            );
            
            if ($update_result === false) {
                error_log('ViraStore: Failed to update domain status: ' . $wpdb->last_error);
            }
        }

        // If license is no longer valid, deactivate
        if (!$license_check['valid']) {
            $this->deactivate_domain_license($activation_id, 'license_invalid');
        }

        return $status;
    }

    /**
     * Check for expiry notifications
     */
    private function check_expiry_notifications(): void {
        global $wpdb;

        $activations_table = $this->db->get_table_name('license_domain_activations');
        $licenses_table = $this->db->get_table_name('licenses');

        // Get activations for licenses expiring soon
        $expiring_activations = $wpdb->get_results(
            "SELECT a.*, l.expires_at, l.customer_id 
             FROM $activations_table a
             JOIN $licenses_table l ON a.license_key = l.license_key
             WHERE a.status = 'active'
             AND l.expires_at BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)",
            ARRAY_A
        );

        foreach ($expiring_activations as $activation) {
            $this->schedule_expiry_notification($activation);
        }
    }

    /**
     * Check for suspicious activity notifications
     */
    private function check_suspicious_activity_notifications(): void {
        global $wpdb;

        $logs_table = $this->db->get_table_name('license_activation_logs');

        // Check for multiple failed attempts from same IP
        $suspicious_ips = $wpdb->get_results(
            "SELECT ip_address, COUNT(*) as attempts
             FROM $logs_table 
             WHERE attempt_time >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
             AND success = 0
             GROUP BY ip_address
             HAVING attempts > 5",
            ARRAY_A
        );

        foreach ($suspicious_ips as $ip_data) {
            $this->schedule_security_notification('suspicious_ip_activity', [
                'ip_address' => $ip_data['ip_address'],
                'failed_attempts' => $ip_data['attempts']
            ]);
        }
    }

    /**
     * Schedule expiry notification
     *
     * @param array $activation Activation data
     */
    private function schedule_expiry_notification(array $activation): void {
        global $wpdb;

        $notifications_table = $this->db->get_table_name('license_notifications');
        
        // Check if notification already sent today
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $notifications_table 
             WHERE license_key = %s 
             AND notification_type = 'expiry_warning'
             AND DATE(created_at) = CURDATE()",
            $activation['license_key']
        ));

        if ($existing) {
            return;
        }

        $days_until_expiry = intval($wpdb->get_var($wpdb->prepare(
            "SELECT DATEDIFF(%s, CURDATE())",
            $activation['expires_at']
        )));

        $wpdb->insert(
            $notifications_table,
            [
                'license_key' => $activation['license_key'],
                'domain' => $activation['domain'],
                'notification_type' => 'expiry_warning',
                'recipient_email' => $this->get_customer_email($activation['customer_id']),
                'subject' => sprintf(
                    __('License Expiry Notice - %s expires in %d days', 'vira-store'),
                    $activation['domain'],
                    $days_until_expiry
                ),
                'message' => $this->get_expiry_notification_message($activation, $days_until_expiry),
                'status' => 'pending',
                'created_at' => current_time('mysql')
            ],
            ['%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s']
        );
    }

    /**
     * Schedule security notification
     *
     * @param string $type Notification type
     * @param array  $data Notification data
     */
    private function schedule_security_notification(string $type, array $data): void {
        global $wpdb;

        $notifications_table = $this->db->get_table_name('license_notifications');
        
        $wpdb->insert(
            $notifications_table,
            [
                'license_key' => '',
                'domain' => '',
                'notification_type' => $type,
                'recipient_email' => get_option('admin_email'),
                'subject' => $this->get_security_notification_subject($type, $data),
                'message' => $this->get_security_notification_message($type, $data),
                'status' => 'pending',
                'created_at' => current_time('mysql')
            ],
            ['%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s']
        );
    }

    /**
     * Process pending notifications
     */
    private function process_pending_notifications(): void {
        global $wpdb;

        $notifications_table = $this->db->get_table_name('license_notifications');
        
        $notifications = $wpdb->get_results(
            "SELECT * FROM $notifications_table 
             WHERE status = 'pending' 
             AND created_at <= NOW()
             ORDER BY created_at ASC 
             LIMIT 10",
            ARRAY_A
        );

        foreach ($notifications as $notification) {
            $this->send_notification($notification);
        }
    }

    /**
     * Send notification
     *
     * @param array $notification Notification data
     */
    private function send_notification(array $notification): void {
        global $wpdb;

        $notifications_table = $this->db->get_table_name('license_notifications');
        
        $sent = wp_mail(
            $notification['recipient_email'],
            $notification['subject'],
            $notification['message'],
            ['Content-Type: text/html; charset=UTF-8']
        );

        // Update notification status
        $wpdb->update(
            $notifications_table,
            [
                'status' => $sent ? 'sent' : 'failed',
                'sent_at' => $sent ? current_time('mysql') : null
            ],
            ['id' => $notification['id']],
            ['%s', '%s'],
            ['%d']
        );
    }

    /**
     * Get customer email
     *
     * @param int $customer_id Customer ID
     * @return string Customer email
     */
    private function get_customer_email(int $customer_id): string {
        global $wpdb;

        if (!$customer_id) {
            return get_option('admin_email');
        }

        $customers_table = $this->db->get_table_name('customers');
        $email = $wpdb->get_var($wpdb->prepare(
            "SELECT email FROM $customers_table WHERE id = %d",
            $customer_id
        ));

        return $email ?: get_option('admin_email');
    }

    /**
     * Get expiry notification message
     *
     * @param array $activation        Activation data
     * @param int   $days_until_expiry Days until expiry
     * @return string Message
     */
    private function get_expiry_notification_message(array $activation, int $days_until_expiry): string {
        $site_name = get_bloginfo('name');
        
        return sprintf(
            __('<p>Hello,</p><p>This is a reminder that your license for domain <strong>%1$s</strong> will expire in <strong>%2$d days</strong> on <strong>%3$s</strong>.</p><p>To ensure uninterrupted service, please renew your license before the expiration date.</p><p>License Key: %4$s</p><p>Best regards,<br>%5$s Team</p>', 'vira-store'),
            $activation['domain'],
            $days_until_expiry,
            date('F j, Y', strtotime($activation['expires_at'])),
            $activation['license_key'],
            $site_name
        );
    }

    /**
     * Get security notification subject
     *
     * @param string $type Notification type
     * @param array  $data Notification data
     * @return string Subject
     */
    private function get_security_notification_subject(string $type, array $data): string {
        switch ($type) {
            case 'suspicious_ip_activity':
                return sprintf(
                    __('Security Alert: Suspicious license activation attempts from %s', 'vira-store'),
                    $data['ip_address']
                );
            default:
                return __('Security Alert: Suspicious Activity Detected', 'vira-store');
        }
    }

    /**
     * Get security notification message
     *
     * @param string $type Notification type
     * @param array  $data Notification data
     * @return string Message
     */
    private function get_security_notification_message(string $type, array $data): string {
        $site_name = get_bloginfo('name');
        
        switch ($type) {
            case 'suspicious_ip_activity':
                return sprintf(
                    __('<p>Security Alert</p><p>We detected %1$d failed license activation attempts from IP address <strong>%2$s</strong> in the last hour.</p><p>This may indicate attempted unauthorized access to your license system.</p><p>Please review your license activation logs and consider implementing additional security measures if necessary.</p><p>Best regards,<br>%3$s Security Team</p>', 'vira-store'),
                    $data['failed_attempts'],
                    $data['ip_address'],
                    $site_name
                );
            default:
                return __('Suspicious activity has been detected in your license system.', 'vira-store');
        }
    }

    /**
     * Deactivate expired licenses
     */
    private function deactivate_expired_licenses(): void {
        global $wpdb;

        // Check if required tables exist
        if (!$this->db->table_exists('license_domain_activations') || 
            !$this->db->table_exists('licenses')) {
            return;
        }

        $activations_table = $this->db->get_table_name('license_domain_activations');
        $licenses_table = $this->db->get_table_name('licenses');

        // Deactivate domain activations for licenses expired beyond grace period
        $expired_cutoff = date('Y-m-d H:i:s', time() - ($this->grace_period_days * 24 * 60 * 60));

        $wpdb->query($wpdb->prepare(
            "UPDATE $activations_table a
             JOIN $licenses_table l ON a.license_key = l.license_key
             SET a.status = 'inactive', 
                 a.deactivated_at = NOW(),
                 a.deactivation_reason = 'license_expired'
             WHERE a.status = 'active'
             AND l.expires_at < %s",
            $expired_cutoff
        ));
    }

    /**
     * Maybe send activation notification
     *
     * @param array $activation Activation data
     */
    private function maybe_send_activation_notification(array $activation): void {
        $send_notifications = get_option('vrstore_send_activation_notifications', false);
        
        if (!$send_notifications) {
            return;
        }

        // Check if required table exists
        if (!$this->db->table_exists('license_notifications')) {
            return;
        }

        global $wpdb;
        $notifications_table = $this->db->get_table_name('license_notifications');
        
        $wpdb->insert(
            $notifications_table,
            [
                'license_key' => $activation['license_key'],
                'domain' => $activation['domain'],
                'notification_type' => 'new_activation',
                'recipient_email' => get_option('admin_email'),
                'subject' => sprintf(
                    __('New License Activation: %s', 'vira-store'),
                    $activation['domain']
                ),
                'message' => sprintf(
                    __('<p>A license has been activated on a new domain:</p><p><strong>License Key:</strong> %1$s<br><strong>Domain:</strong> %2$s<br><strong>Time:</strong> %3$s</p>', 'vira-store'),
                    $activation['license_key'],
                    $activation['domain'],
                    $activation['activated_at']
                ),
                'status' => 'pending',
                'created_at' => current_time('mysql')
            ],
            ['%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s']
        );
    }

    /**
     * Check if user owns a license
     *
     * @param int    $user_id     User ID
     * @param string $license_key License key
     * @return bool User owns license
     */
    private function user_owns_license(int $user_id, string $license_key): bool {
        global $wpdb;
        
        // Get user data
        $user = get_user_by('id', $user_id);
        if (!$user) {
            // User not found
            return false;
        }
        
        // Check if user has a customer record and if that customer owns the license
        $customers_table = $this->db->get_table_name('customers');
        $licenses_table = $this->db->get_table_name('licenses');
        
        // Debug: Checking license ownership
        if (defined('WP_DEBUG') && WP_DEBUG) {
            // Checking license ownership
        }
        
        // First, try to find customer by user email
        $customer = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $customers_table WHERE email = %s",
            $user->user_email
        ), ARRAY_A);
        
        $license = null;
        
        if ($customer) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                // Customer found
            }
            
            // Check if this customer owns the license by customer_id
            $license = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $licenses_table WHERE license_key = %s AND customer_id = %d",
                $license_key,
                $customer['id']
            ), ARRAY_A);
        }
        
        // If no customer record or no license found by customer_id, try by email directly
        if (!$license) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                // Trying license lookup by customer email
            }
            
            $license = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $licenses_table WHERE license_key = %s AND customer_email = %s",
                $license_key,
                $user->user_email
            ), ARRAY_A);
            
            if ($license && $customer && empty($license['customer_id'])) {
                // Update the license with the customer_id for future lookups
                $wpdb->update(
                    $licenses_table,
                    ['customer_id' => $customer['id']],
                    ['id' => $license['id']],
                    ['%d'],
                    ['%d']
                );
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    // Updated license customer ID
                }
            }
        }
        
        if (!$license) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                // User does not own license
            }
            return false;
        }
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            // User owns license
        }
        return true;
    }
    
    /**
     * Get client IP address
     *
     * @return string IP address
     */
    private function get_client_ip(): string {
        $ip_keys = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'HTTP_CLIENT_IP', 'REMOTE_ADDR'];
        
        foreach ($ip_keys as $key) {
            if (isset($_SERVER[$key]) && !empty($_SERVER[$key])) {
                $ip_string = sanitize_text_field(wp_unslash($_SERVER[$key]));
                
                // Handle comma-separated IPs (take first valid one)
                if (strpos($ip_string, ',') !== false) {
                    $ips = explode(',', $ip_string);
                    foreach ($ips as $ip_candidate) {
                        $ip_candidate = trim($ip_candidate);
                        // Validate IP - allow both public and private IPs
                        if (filter_var($ip_candidate, FILTER_VALIDATE_IP)) {
                            // Prefer public IPs, but accept private if that's all we have
                            if (filter_var($ip_candidate, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                                return $ip_candidate;
                            }
                        }
                    }
                    // If we got here, try the first IP even if private
                    $ip_candidate = trim($ips[0]);
                    if (filter_var($ip_candidate, FILTER_VALIDATE_IP)) {
                        return $ip_candidate;
                    }
                } else {
                    $ip = trim($ip_string);
                    // Validate IP - allow both public and private IPs
                    if (filter_var($ip, FILTER_VALIDATE_IP)) {
                        // Prefer public IPs, but accept private if that's all we have
                        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                            return $ip;
                        }
                    }
                }
            }
        }
        
        // Fallback to REMOTE_ADDR (may be private IP)
        $fallback_ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '0.0.0.0';
        return filter_var($fallback_ip, FILTER_VALIDATE_IP) ? $fallback_ip : '0.0.0.0';
    }
    
    /**
     * Get customer licenses by email
     *
     * @param string $email Customer email
     * @return array Customer licenses
     */
    private function get_customer_licenses_by_email(string $email): array {
        global $wpdb;
        
        $licenses_table = $this->db->get_table_name('licenses');
        $customers_table = $this->db->get_table_name('customers');
        
        // First try to get licenses via customer_id
        $customer = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $customers_table WHERE email = %s",
            $email
        ), ARRAY_A);
        
        $licenses = [];
        
        if ($customer) {
            // Get licenses by customer_id
            $licenses_by_customer_id = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM $licenses_table WHERE customer_id = %d AND status = 'active'",
                $customer['id']
            ), ARRAY_A);
            
            if ($licenses_by_customer_id) {
                $licenses = array_merge($licenses, $licenses_by_customer_id);
            }
        }
        
        // Also get licenses by customer_email (fallback for older records)
        $licenses_by_email = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $licenses_table WHERE customer_email = %s AND status = 'active'",
            $email
        ), ARRAY_A);
        
        if ($licenses_by_email) {
            // Avoid duplicates
            $existing_keys = array_column($licenses, 'license_key');
            foreach ($licenses_by_email as $license) {
                if (!in_array($license['license_key'], $existing_keys)) {
                    $licenses[] = $license;
                }
            }
        }
        
        return $licenses;
    }
    
    /**
     * Clear domain activations cache for customer's licenses
     *
     * @param array $customer_licenses Array of customer licenses
     * @return void
     */
    private function clear_domain_activations_cache(array $customer_licenses): void {
        foreach ($customer_licenses as $license) {
            $license_key = $license['license_key'];
            
            // Clear various cache keys that might contain domain activation data
            wp_cache_delete('license_domains_' . $license_key, 'vrstore');
            
            // Clear the transient cache used by get_license_domain_activations
            $args_variants = [
                ['status' => 'active', 'per_page' => 100],
                ['status' => 'active', 'per_page' => 20],
                ['status' => '', 'per_page' => 100],
                ['status' => '', 'per_page' => 20]
            ];
            
            foreach ($args_variants as $args) {
                $cache_key = 'vrstore_license_domain_activations_' . md5($license_key . serialize($args));
                delete_transient($cache_key);
            }
        }
        
        // Also clear any general domain activation cache
        wp_cache_flush(); // Clear all object cache to be safe
    }
}

// Initialize the domain monitoring system
VRSTORE_Domain_Monitor::get_instance();
