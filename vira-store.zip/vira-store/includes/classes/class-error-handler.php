<?php
/**
 * Enhanced Error Handler and Logger
 *
 * @package Vira_Store
 * @since 1.0.0
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

/**
 * VRSTORE_Error_Handler Class
 *
 * Provides comprehensive error handling, logging, performance monitoring,
 * and debugging capabilities for the Vira Store plugin.
 *
 * @since 1.0.0
 */
class VRSTORE_Error_Handler {

    /**
     * Instance of this class.
     *
     * @since 1.0.0
     * @var VRSTORE_Error_Handler|null
     */
    private static ?VRSTORE_Error_Handler $instance = null;

    /**
     * Error levels and their priorities
     *
     * @var array
     */
    private array $error_levels = [
        'debug' => 1,
        'info' => 2,
        'notice' => 3,
        'warning' => 4,
        'error' => 5,
        'critical' => 6,
        'emergency' => 7,
    ];

    /**
     * Log rotation settings
     *
     * @var array
     */
    private array $log_settings = [
        'max_size' => 5242880, // 5MB
        'max_files' => 10,
        'retention_days' => 30,
    ];

    /**
     * Performance monitoring data
     *
     * @var array
     */
    private array $performance_data = [];

    /**
     * Error context stack
     *
     * @var array
     */
    private array $context_stack = [];

    /**
     * Constructor.
     *
     * @since 1.0.0
     */
    private function __construct() {
        $this->init_hooks();
        $this->init_performance_monitoring();
    }

    /**
     * Get instance of this class.
     *
     * @since 1.0.0
     * @return VRSTORE_Error_Handler
     */
    public static function get_instance(): VRSTORE_Error_Handler {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Initialize hooks.
     *
     * @since 1.0.0
     */
    private function init_hooks(): void {
        // Register shutdown handler for fatal errors
        register_shutdown_function([$this, 'handle_shutdown']);
        
        // Set custom error handler if debug mode is enabled
        if (defined('WP_DEBUG') && WP_DEBUG) {
            set_error_handler([$this, 'handle_error'], E_ALL);
            set_exception_handler([$this, 'handle_exception']);
        }
        
        // WordPress hooks
        add_action('wp_loaded', [$this, 'check_system_health']);
        add_action('vrstore_cleanup_logs', [$this, 'cleanup_old_logs']);
        
        // Schedule log cleanup
        if (!wp_next_scheduled('vrstore_cleanup_logs')) {
            wp_schedule_event(time(), 'daily', 'vrstore_cleanup_logs');
        }
    }

    /**
     * Initialize performance monitoring
     */
    private function init_performance_monitoring(): void {
        $this->performance_data['plugin_start'] = microtime(true);
        $this->performance_data['memory_start'] = memory_get_usage(true);
        $this->performance_data['queries_start'] = get_num_queries();
    }

    /**
     * Log error with enhanced context and formatting
     *
     * @param string $level Error level
     * @param string $message Error message
     * @param array $context Additional context data
     * @param string $component Component name
     */
    public function log(string $level, string $message, array $context = [], string $component = 'core'): void {
        // Validate log level
        if (!isset($this->error_levels[$level])) {
            $level = 'info';
        }
        
        // Check if we should log this level
        if (!$this->should_log($level)) {
            return;
        }
        
        // Create enhanced context
        $enhanced_context = $this->build_context($context, $component);
        
        // Format log entry
        $log_entry = $this->format_log_entry($level, $message, $enhanced_context);
        
        // Write to appropriate destinations
        $this->write_log($log_entry, $level);
        
        // Handle critical errors
        if (in_array($level, ['critical', 'emergency'])) {
            $this->handle_critical_error($message, $enhanced_context);
        }
    }

    /**
     * Log debug information
     */
    public function debug(string $message, array $context = [], string $component = 'core'): void {
        $this->log('debug', $message, $context, $component);
    }

    /**
     * Log informational message
     */
    public function info(string $message, array $context = [], string $component = 'core'): void {
        $this->log('info', $message, $context, $component);
    }

    /**
     * Log warning
     */
    public function warning(string $message, array $context = [], string $component = 'core'): void {
        $this->log('warning', $message, $context, $component);
    }

    /**
     * Log error
     */
    public function error(string $message, array $context = [], string $component = 'core'): void {
        $this->log('error', $message, $context, $component);
    }

    /**
     * Log critical error
     */
    public function critical(string $message, array $context = [], string $component = 'core'): void {
        $this->log('critical', $message, $context, $component);
    }

    /**
     * Start performance timer
     */
    public function start_timer(string $name): void {
        $this->performance_data['timers'][$name] = [
            'start' => microtime(true),
            'memory_start' => memory_get_usage(true)
        ];
    }

    /**
     * End performance timer and log results
     */
    public function end_timer(string $name, bool $log_result = true): array {
        if (!isset($this->performance_data['timers'][$name])) {
            return ['error' => 'Timer not found'];
        }
        
        $timer = $this->performance_data['timers'][$name];
        $end_time = microtime(true);
        $end_memory = memory_get_usage(true);
        
        $result = [
            'duration' => round(($end_time - $timer['start']) * 1000, 2), // milliseconds
            'memory_used' => $end_memory - $timer['memory_start'],
            'memory_peak' => memory_get_peak_usage(true)
        ];
        
        if ($log_result) {
            $this->debug("Performance timer: {$name}", $result, 'performance');
        }
        
        unset($this->performance_data['timers'][$name]);
        return $result;
    }

    /**
     * Monitor database query performance
     */
    public function monitor_query_performance(): array {
        global $wpdb;
        
        $queries_end = get_num_queries();
        $queries_count = $queries_end - ($this->performance_data['queries_start'] ?? 0);
        
        $performance_data = [
            'queries_count' => $queries_count,
            'slow_queries' => []
        ];
        
        // Check for slow queries if query debugging is enabled
        if (defined('SAVEQUERIES') && SAVEQUERIES && isset($wpdb->queries)) {
            foreach ($wpdb->queries as $query_data) {
                $duration = floatval($query_data[1]);
                if ($duration > 0.1) { // Queries slower than 100ms
                    $performance_data['slow_queries'][] = [
                        'sql' => substr($query_data[0], 0, 200) . '...',
                        'duration' => round($duration * 1000, 2),
                        'calling_function' => $query_data[2] ?? 'unknown'
                    ];
                }
            }
        }
        
        return $performance_data;
    }

    /**
     * Handle PHP errors
     */
    public function handle_error($errno, $errstr, $errfile, $errline): bool {
        // Don't handle errors that are not in error_reporting
        if (!(error_reporting() & $errno)) {
            return false;
        }
        
        $level = $this->map_php_error_level($errno);
        
        $this->log($level, "PHP {$level}: {$errstr}", [
            'file' => $errfile,
            'line' => $errline,
            'errno' => $errno
        ], 'php');
        
        return true;
    }

    /**
     * Handle exceptions
     */
    public function handle_exception($exception): void {
        $this->log('critical', 'Uncaught exception: ' . $exception->getMessage(), [
            'exception_class' => get_class($exception),
            'file' => $exception->getFile(),
            'line' => $exception->getLine(),
            'trace' => $exception->getTraceAsString()
        ], 'exception');
    }

    /**
     * Handle fatal errors on shutdown
     */
    public function handle_shutdown(): void {
        $error = error_get_last();
        
        if ($error && in_array($error['type'], [E_ERROR, E_CORE_ERROR, E_COMPILE_ERROR, E_PARSE])) {
            $this->log('critical', 'Fatal error: ' . $error['message'], [
                'file' => $error['file'],
                'line' => $error['line'],
                'type' => $error['type']
            ], 'fatal');
        }
        
        // Log final performance metrics
        $this->log_final_performance();
    }

    /**
     * Check system health and log warnings
     */
    public function check_system_health(): void {
        $health_issues = [];
        
        // Check PHP version
        if (version_compare(PHP_VERSION, '8.2', '<')) {
            $health_issues[] = 'PHP version ' . PHP_VERSION . ' is below recommended 8.2+';
        }
        
        // Check memory limit
        $memory_limit = wp_convert_hr_to_bytes(ini_get('memory_limit'));
        if ($memory_limit < 256 * 1024 * 1024) { // Less than 256MB
            $health_issues[] = 'Memory limit ' . ini_get('memory_limit') . ' may be insufficient';
        }
        
        // Check database connection
        global $wpdb;
        if ($wpdb->last_error) {
            $health_issues[] = 'Database connection issues detected: ' . $wpdb->last_error;
        }
        
        // Check required extensions
        $required_extensions = ['openssl', 'curl', 'json', 'mbstring'];
        foreach ($required_extensions as $extension) {
            if (!extension_loaded($extension)) {
                $health_issues[] = "Required PHP extension '{$extension}' is not loaded";
            }
        }
        
        // Log health issues
        if (!empty($health_issues)) {
            $this->warning('System health check failed', [
                'issues' => $health_issues
            ], 'system');
        }
    }

    /**
     * Build enhanced context for log entries
     */
    private function build_context(array $context, string $component): array {
        $enhanced_context = [
            'timestamp' => time(),
            'datetime' => current_time('c'),
            'component' => $component,
            'memory_usage' => memory_get_usage(true),
            'memory_peak' => memory_get_peak_usage(true),
            'user_id' => get_current_user_id() ?: 0,
            'ip_address' => $this->get_client_ip(),
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'request_uri' => $_SERVER['REQUEST_URI'] ?? '',
            'http_method' => $_SERVER['REQUEST_METHOD'] ?? '',
            'php_version' => PHP_VERSION,
            'wp_version' => get_bloginfo('version'),
            'plugin_version' => VRSTORE_VERSION ?? '1.0.0'
        ];
        
        // Add context stack if available
        if (!empty($this->context_stack)) {
            $enhanced_context['context_stack'] = $this->context_stack;
        }
        
        // Merge with provided context
        return array_merge($enhanced_context, $context);
    }

    /**
     * Format log entry
     */
    private function format_log_entry(string $level, string $message, array $context): array {
        return [
            'level' => strtoupper($level),
            'message' => $message,
            'context' => $context,
            'formatted' => sprintf(
                '[%s] [%s] [%s] %s | Memory: %s | Context: %s',
                $context['datetime'],
                strtoupper($level),
                $context['component'],
                $message,
                size_format($context['memory_usage']),
                wp_json_encode(array_intersect_key($context, array_flip(['user_id', 'ip_address', 'request_uri'])))
            )
        ];
    }

    /**
     * Write log entry to appropriate destinations
     */
    private function write_log(array $log_entry, string $level): void {
        // Always log to PHP error log if debug is enabled or level is critical
        if ((defined('WP_DEBUG') && WP_DEBUG) || in_array($level, ['error', 'critical', 'emergency'])) {
            // Log entry would be written to error log in debug mode
        }
        
        // Write to custom log file if enabled
        if (get_option('vrstore_enable_file_logging', 'no') === 'yes') {
            $this->write_to_file($log_entry);
        }
        
        // Store in database if enabled
        if (get_option('vrstore_enable_db_logging', 'no') === 'yes') {
            $this->write_to_database($log_entry);
        }
    }

    /**
     * Write log to file with rotation
     */
    private function write_to_file(array $log_entry): void {
        $log_dir = WP_CONTENT_DIR . '/vrstore-logs/';
        
        // Create log directory if it doesn't exist
        if (!is_dir($log_dir)) {
            wp_mkdir_p($log_dir);
            
            // Add htaccess protection
            file_put_contents($log_dir . '.htaccess', "Deny from all\n");
        }
        
        $log_file = $log_dir . 'vrstore-' . date('Y-m-d') . '.log';
        
        // Check file size for rotation
        if (file_exists($log_file) && filesize($log_file) > $this->log_settings['max_size']) {
            $this->rotate_log_file($log_file);
        }
        
        // Write log entry
        file_put_contents(
            $log_file,
            $log_entry['formatted'] . "\n",
            FILE_APPEND | LOCK_EX
        );
    }

    /**
     * Write log to database
     */
    private function write_to_database(array $log_entry): void {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'vrstore_error_logs';
        
        // Create table if it doesn't exist
        $this->ensure_log_table_exists();
        
        $wpdb->insert(
            $table_name,
            [
                'level' => $log_entry['level'],
                'message' => $log_entry['message'],
                'context' => wp_json_encode($log_entry['context']),
                'component' => $log_entry['context']['component'],
                'created_at' => current_time('mysql')
            ],
            ['%s', '%s', '%s', '%s', '%s']
        );
    }

    /**
     * Rotate log file
     */
    private function rotate_log_file(string $log_file): void {
        $base_name = pathinfo($log_file, PATHINFO_FILENAME);
        $extension = pathinfo($log_file, PATHINFO_EXTENSION);
        $dir = dirname($log_file);
        
        // Find next rotation number
        $rotation = 1;
        while (file_exists("{$dir}/{$base_name}.{$rotation}.{$extension}") && $rotation < $this->log_settings['max_files']) {
            $rotation++;
        }
        
        // Move current log to rotated name
        rename($log_file, "{$dir}/{$base_name}.{$rotation}.{$extension}");
    }

    /**
     * Cleanup old logs
     */
    public function cleanup_old_logs(): void {
        // Clean up old log files
        $log_dir = WP_CONTENT_DIR . '/vrstore-logs/';
        if (is_dir($log_dir)) {
            $files = glob($log_dir . '*.log*');
            $cutoff_time = time() - ($this->log_settings['retention_days'] * DAY_IN_SECONDS);
            
            foreach ($files as $file) {
                if (filemtime($file) < $cutoff_time) {
                    unlink($file);
                }
            }
        }
        
        // Clean up database logs
        global $wpdb;
        $table_name = $wpdb->prefix . 'vrstore_error_logs';
        if ($wpdb->get_var("SHOW TABLES LIKE '{$table_name}'") === $table_name) {
            $wpdb->query($wpdb->prepare(
                "DELETE FROM {$table_name} WHERE created_at < %s",
                date('Y-m-d H:i:s', time() - ($this->log_settings['retention_days'] * DAY_IN_SECONDS))
            ));
        }
    }

    /**
     * Handle critical errors
     */
    private function handle_critical_error(string $message, array $context): void {
        // Send email notification if configured
        $admin_email = get_option('vrstore_critical_error_email', get_option('admin_email'));
        
        if ($admin_email && !get_transient('vrstore_critical_error_sent')) {
            $subject = sprintf('[%s] Critical Error Detected', get_bloginfo('name'));
            $body = sprintf(
                "A critical error has been detected on your website:\n\nMessage: %s\n\nContext:\n%s\n\nTime: %s\nURL: %s",
                $message,
                print_r($context, true),
                current_time('c'),
                home_url($_SERVER['REQUEST_URI'] ?? '')
            );
            
            wp_mail($admin_email, $subject, $body);
            
            // Prevent spam - only send one critical error email per hour
            set_transient('vrstore_critical_error_sent', true, HOUR_IN_SECONDS);
        }
    }

    /**
     * Ensure log table exists
     */
    private function ensure_log_table_exists(): void {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'vrstore_error_logs';
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS {$table_name} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            level varchar(20) NOT NULL,
            message text NOT NULL,
            context longtext,
            component varchar(50) DEFAULT 'core',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY level (level),
            KEY component (component),
            KEY created_at (created_at)
        ) {$charset_collate};";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    /**
     * Map PHP error levels to log levels
     */
    private function map_php_error_level(int $errno): string {
        switch ($errno) {
            case E_ERROR:
            case E_CORE_ERROR:
            case E_COMPILE_ERROR:
            case E_PARSE:
                return 'critical';
            case E_WARNING:
            case E_CORE_WARNING:
            case E_COMPILE_WARNING:
                return 'warning';
            case E_NOTICE:
            case E_USER_NOTICE:
                return 'notice';
            default:
                return 'info';
        }
    }

    /**
     * Check if we should log this level
     */
    private function should_log(string $level): bool {
        $min_level = get_option('vrstore_min_log_level', 'warning');
        $min_priority = $this->error_levels[$min_level] ?? 4;
        $current_priority = $this->error_levels[$level] ?? 1;
        
        return $current_priority >= $min_priority;
    }

    /**
     * Get client IP address
     */
    private function get_client_ip(): string {
        $ip_keys = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'];
        
        foreach ($ip_keys as $key) {
            if (!empty($_SERVER[$key])) {
                $ip = trim(explode(',', $_SERVER[$key])[0]);
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
        
        return '127.0.0.1';
    }

    /**
     * Log final performance metrics
     */
    private function log_final_performance(): void {
        $end_time = microtime(true);
        $end_memory = memory_get_usage(true);
        
        $performance_metrics = [
            'total_execution_time' => round(($end_time - $this->performance_data['plugin_start']) * 1000, 2),
            'memory_used' => $end_memory - $this->performance_data['memory_start'],
            'memory_peak' => memory_get_peak_usage(true),
            'queries_performance' => $this->monitor_query_performance()
        ];
        
        $this->debug('Plugin execution completed', $performance_metrics, 'performance');
    }

    /**
     * Add context to the context stack
     */
    public function push_context(string $context): void {
        $this->context_stack[] = $context;
    }

    /**
     * Remove context from the context stack
     */
    public function pop_context(): void {
        array_pop($this->context_stack);
    }

    /**
     * Get current performance data
     */
    public function get_performance_data(): array {
        return array_merge($this->performance_data, [
            'current_memory' => memory_get_usage(true),
            'peak_memory' => memory_get_peak_usage(true),
            'current_queries' => get_num_queries()
        ]);
    }
}
