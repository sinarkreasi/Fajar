<?php
/**
 * Shortcodes Class
 *
 * @package Vira_Store
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * VRSTORE_Shortcodes Class
 *
 * This class handles all shortcodes for the plugin.
 *
 * @since 1.0.0
 */
class VRSTORE_Shortcodes {

	/**
	 * Instance of this class.
	 *
	 * @since 1.0.0
	 * @var object
	 */
	protected static $instance = null;

	/**
	 * Get translated text with fallback for when textdomain is not loaded.
	 *
	 * @since 1.0.0
	 * @param string $text Text to translate.
	 * @return string Translated text or original text if textdomain not loaded.
	 */
	private function get_translated_text( $text ) {
		// Check if textdomain is loaded
		if ( is_textdomain_loaded( 'vira-store' ) ) {
			return esc_html__( $text, 'vira-store' );
		}
		// Return escaped text without translation if textdomain not loaded
		return esc_html( $text );
	}

	/**
	 * Return an instance of this class.
	 *
	 * @since 1.0.0
	 * @return object A single instance of this class.
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		// Register shortcodes after init to ensure textdomain is loaded
		add_action( 'init', array( $this, 'register_shortcodes' ), 15 );
        
        // Register admin-post action for account update
        add_action( 'admin_post_vrstore_update_account', array( $this, 'process_account_update' ) );
        
		// Initialize AJAX handlers
		$this->init_ajax_handlers();
		
		// Initialize Google OAuth handlers
		$this->init_google_oauth_handlers();
	}

	/**
	 * Register shortcodes.
	 *
	 * @since 1.0.0
	 */
	public function register_shortcodes() {
	add_shortcode( 'vrstore_products', array( $this, 'products_shortcode' ) );
        add_shortcode( 'vrstore_product', array( $this, 'product_shortcode' ) );
        add_shortcode( 'vrstore_buy_button', array( $this, 'buy_button_shortcode' ) );
        add_shortcode( 'vrstore_cart', array( $this, 'cart_shortcode' ) );
        add_shortcode( 'vrstore_checkout', array( $this, 'checkout_shortcode' ) );
        add_shortcode( 'vrstore_account', array( $this, 'account_shortcode' ) );
        add_shortcode( 'vrstore_license', array( $this, 'license_shortcode' ) );
        add_shortcode( 'vrstore_thank_you', array( $this, 'thank_you_shortcode' ) );
        add_shortcode( 'vrstore_currency_switcher', array( $this, 'currency_switcher_shortcode' ) );
        add_shortcode( 'vrstore_courses', array( $this, 'courses_shortcode' ) );
        add_shortcode( 'vrstore_affiliates', array( $this, 'affiliates_shortcode' ) );
	}

	/**
	 * Products shortcode.
	 *
	 * @since 1.0.0
	 * @param array $atts Shortcode attributes.
	 * @return string Shortcode output.
	 */
	public function products_shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'category'    => '',
				'tag'         => '',
				'limit'       => 10,
				'columns'     => 3,
				'orderby'     => 'date',
				'order'       => 'DESC',
				'show_filter' => 'yes',
				'show_search' => 'yes',
			),
			$atts,
			'vrstore_products'
		);

		// Ensure frontend assets are enqueued for products page
		$this->enqueue_products_assets();

		// Sanitize attributes.
		$category    = sanitize_text_field( $atts['category'] );
		$tag         = sanitize_text_field( $atts['tag'] );
		$limit       = absint( $atts['limit'] );
		$columns     = absint( $atts['columns'] );
		$orderby     = sanitize_text_field( $atts['orderby'] );
		$order       = sanitize_text_field( $atts['order'] );
		$show_filter = 'yes' === $atts['show_filter'];
		$show_search = 'yes' === $atts['show_search'];

		// Query arguments.
		$args = array(
			'post_type'      => 'vrstore_product',
			'posts_per_page' => $limit,
			'orderby'        => $orderby,
			'order'          => $order,
			'post_status'    => array('publish'), // Only published products
		);

		// Add category filter.
		if ( ! empty( $category ) ) {
			$args['tax_query'][] = array(
				'taxonomy' => 'vrstore_product_cat',
				'field'    => 'slug',
				'terms'    => explode( ',', $category ),
			);
		}

		// Add tag filter.
		if ( ! empty( $tag ) ) {
			$args['tax_query'][] = array(
				'taxonomy' => 'vrstore_product_tag',
				'field'    => 'slug',
				'terms'    => explode( ',', $tag ),
			);
		}

		// Apply visibility filters
		if (class_exists('VRSTORE_Product')) {
			$args = VRSTORE_Product::apply_visibility_filters($args, 'catalog');
		}

		// Get products.
		$products = new WP_Query( $args );

		// Start output buffer.
		ob_start();

		// Include template.
		include VRSTORE_PLUGIN_DIR . 'views/shortcodes/products.php';

		// Return output buffer.
		return ob_get_clean();
	}



	/**
	 * Thank you shortcode.
	 *
	 * @since 1.0.0
	 * @param array $atts Shortcode attributes.
	 * @return string Shortcode output.
	 */
	public function thank_you_shortcode( $atts ) {
		$atts = shortcode_atts(
			array(),
			$atts,
			'vrstore_thank_you'
		);

		// Get currency converter instance
		$currency_converter = VRSTORE_Currency_Converter::get_instance();

		// Get order ID from URL parameter - can be string (VRSTORE-xxx-xxx) or integer
		$order_id_param = isset( $_GET['vrstore_order_id'] ) ? sanitize_text_field( $_GET['vrstore_order_id'] ) : '';
		$order_id = 0;
		
		// Check if order ID is numeric (legacy integer ID) or string format (VRSTORE-xxx-xxx)
		if ( is_numeric( $order_id_param ) ) {
			$order_id = intval( $order_id_param );
		} else {
			// For string format, we'll use the order number to find the order
			$order_id = $order_id_param;
		}

		// Initialize variables.
		$order_data = null;
		$license_data = null;

		// Get order data if order ID is provided.
		if ( $order_id ) {
			// Get order data from database table - try by ID first, then by order number
			global $wpdb;
			$orders_table = $wpdb->prefix . 'vrstore_orders';
			
			if ( is_numeric( $order_id ) ) {
				// Get order by ID
				$raw_order_data = $wpdb->get_row( $wpdb->prepare(
					"SELECT * FROM $orders_table WHERE id = %d",
					$order_id
				), ARRAY_A );
			} else {
				// Get order by order number (string format like VRSTORE-xxx-xxx)
				$raw_order_data = $wpdb->get_row( $wpdb->prepare(
					"SELECT * FROM $orders_table WHERE order_number = %s",
					$order_id
				), ARRAY_A );
			}
			
			if ( $raw_order_data ) {
				// Debug Extended Support order data from database
				$is_extended_support_db = (
					($raw_order_data['product_id'] == 0 || is_string($raw_order_data['product_id'])) && 
					!empty($raw_order_data['product_name']) && 
					strpos($raw_order_data['product_name'], 'Extended Support') !== false
				);
				
				if ($is_extended_support_db) {
					// Log what's actually in the database for Extended Support orders
					error_log("VR Store Extended Support DB Data: product_price={$raw_order_data['product_price']}, currency={$raw_order_data['currency']}, product_name={$raw_order_data['product_name']}");
				}
				
				// Get product details
				$product_id = $raw_order_data['product_id'];
				$product_name = $raw_order_data['product_name'];
				$product_post = get_post( $product_id );
				if ( $product_post ) {
					$product_name = $product_post->post_title; // Use actual product title
				}

				// Map order data to template format
				$order_data = array(
					'id' => $raw_order_data['id'],
					'order_number' => $raw_order_data['order_number'],
					'customer_name' => $raw_order_data['customer_name'],
					'customer_email' => $raw_order_data['customer_email'],
					'payment_gateway' => $raw_order_data['payment_method'],
					'status' => $raw_order_data['order_status'],
					'payment_status' => $raw_order_data['payment_status'],
					'price' => $raw_order_data['product_price'],
					'currency' => $raw_order_data['currency'],
					'date' => $raw_order_data['created_at'],
					'product_title' => $product_name,
					'product_id' => $product_id,
					'license_key' => $raw_order_data['license_key'] ?? '',
					'raw_db_data' => $raw_order_data // Include raw data for debugging
				);

				// Get license data if applicable
				if ( $product_id && !empty( $raw_order_data['license_key'] ) ) {
					// Get license data for this order from licenses table
					$license_data = $wpdb->get_row( $wpdb->prepare(
						"SELECT * FROM {$wpdb->prefix}vrstore_licenses WHERE order_id = %d OR license_key = %s",
						$raw_order_data['id'],
						$raw_order_data['license_key']
					), ARRAY_A );
				}
			}
		}

		// Enqueue frontend assets for thank you page
		$this->enqueue_checkout_assets();

		// Start output buffer.
		ob_start();

		// Include template.
		include VRSTORE_PLUGIN_DIR . 'views/shortcodes/thank-you.php';

		// Return output buffer.
		return ob_get_clean();
	}

	/**
	 * Single product shortcode.
	 *
	 * @since 1.0.0
	 * @param array $atts Shortcode attributes.
	 * @return string Shortcode output.
	 */
	public function product_shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'id' => 0,
			),
			$atts,
			'vrstore_product'
		);

		// Ensure frontend assets are enqueued for single product
		$this->enqueue_products_assets();

		// Sanitize attributes.
		$product_id = absint( $atts['id'] );

		// Check if product exists.
		if ( ! $product_id || 'vrstore_product' !== get_post_type( $product_id ) ) {
			return '<p>' . esc_html( $this->get_translated_text( 'Product not found.' ) ) . '</p>';
		}

		// Check if product is visible to current user
		if (class_exists('VRSTORE_Product') && !VRSTORE_Product::is_product_visible($product_id, 'single')) {
			return '<p>' . esc_html( $this->get_translated_text( 'This product is not available.' ) ) . '</p>';
		}

		// Get product.
		$product = get_post( $product_id );

		// Start output buffer.
		ob_start();

		// Include template.
		include VRSTORE_PLUGIN_DIR . 'views/shortcodes/product.php';

		// Return output buffer.
		return ob_get_clean();
	}

	/**
	 * AJAX handler for getting product downloads.
	 *
	 * @since 1.0.0
	 */
	public function ajax_get_product_downloads() {
		// Check if user is logged in
		if ( ! is_user_logged_in() ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'Please log in to access downloads.' )
			) );
		}

		// Get parameters
		$product_id = absint( $_POST['product_id'] ?? 0 );
		$order_id = sanitize_text_field( $_POST['order_id'] ?? '' );
		
		// Add debug logging
		// Debug logging removed
		
		if ( ! $product_id || ! $order_id ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'Invalid product or order information.' )
			) );
		}
		
		// Verify user has access to this order
		$current_user = wp_get_current_user();
		global $wpdb;
		$orders_table = $wpdb->prefix . 'vrstore_orders';
		
		// Check order ownership
		$order = null;
		if ( is_numeric( $order_id ) ) {
			$order = $wpdb->get_row( $wpdb->prepare(
				"SELECT * FROM $orders_table WHERE id = %d AND customer_email = %s AND payment_status = 'completed'",
				$order_id,
				$current_user->user_email
			), ARRAY_A );
		} else {
			$order = $wpdb->get_row( $wpdb->prepare(
				"SELECT * FROM $orders_table WHERE order_number = %s AND customer_email = %s AND payment_status = 'completed'",
				$order_id,
				$current_user->user_email
			), ARRAY_A );
		}
		
		if ( ! $order ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'Order not found or access denied.' )
			) );
		}
		
		// Verify product matches order
		if ( $order['product_id'] != $product_id ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'Product does not match the order.' )
			) );
		}

		// Check download limits
		$limit_check = $this->check_download_limits( $current_user->ID, $this->get_user_ip_address() );
		if ( ! $limit_check['allowed'] ) {
			wp_send_json_error( array(
				'message' => $limit_check['message']
			) );
		}

		// Get product files
		$product_files = get_post_meta( $product_id, '_vrstore_product_files', true );
		
		if ( empty( $product_files ) || ! is_array( $product_files ) ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'No download files found for this product.' )
			) );
		}
		
		// Process files to generate secure download URLs
		$processed_files = array();
		$file_protection = VRSTORE_File_Protection::get_instance();
		
		foreach ( $product_files as $file_index => $file ) {
			// Normalize file data - handle different key formats
			$file_url = $file['url'] ?? $file['file'] ?? '';
			$file_name = $file['name'] ?? 'Download ' . ( $file_index + 1 );
			$file_type = $file['type'] ?? 'url';
			
			// Skip empty files
			if ( empty( $file_url ) ) {
				continue;
			}
			
			$processed_file = array(
				'name' => $file_name,
				'type' => $file_type,
				'size' => $file['size'] ?? null,
				'original_url' => $file_url // Keep original for debugging
			);
			
			try {
				// Generate secure download URL using the file protection system
				$secure_url = $file_protection->generate_secure_download_url(
					$product_id,
					$file_index,
					$current_user->ID,
					time() + ( 2 * HOUR_IN_SECONDS ) // 2 hours expiration
				);
				
				$processed_file['url'] = $secure_url;
				$processed_files[] = $processed_file;
				
			} catch ( Exception $e ) {
				// Log error but continue with other files
				VRSTORE_Security::log_security_event(
					'Failed to generate secure URL for file: ' . $e->getMessage(),
					'warning',
					[
						'product_id' => $product_id,
						'file_index' => $file_index,
						'file_data' => $file,
						'user_id' => $current_user->ID
					]
				);
				
				// Add file with error message instead of failing completely
				$processed_file['url'] = '#';
				$processed_file['error'] = 'Unable to generate secure download link';
				$processed_files[] = $processed_file;
			}
		}
		
		if ( empty( $processed_files ) ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'No valid download files found.' )
			) );
		}
		
		// Track download access for each file
		$this->track_download_access( $product_id, $order, $current_user, $processed_files );
		
		wp_send_json_success( array(
			'files' => $processed_files,
			'product_title' => get_the_title( $product_id ),
			'message' => sprintf( $this->get_translated_text( 'Found %d download file(s).' ), count( $processed_files ) )
		) );
	}

	/**
	 * Track download access for analytics and monitoring.
	 *
	 * @since 1.0.0
	 * @param int $product_id Product ID.
	 * @param array $order Order data.
	 * @param WP_User $user Current user.
	 * @param array $files Processed files array.
	 */
	private function track_download_access( $product_id, $order, $user, $files ) {
		global $wpdb;
		$tracking_table = $wpdb->prefix . 'vrstore_download_tracking';
		
		// Get user IP address
		$ip_address = $this->get_user_ip_address();
		
		// Get user agent
		$user_agent = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( $_SERVER['HTTP_USER_AGENT'] ) : '';
		
		// Determine download type based on file count
		$file_count = count( $files );
		$download_type = ( $file_count === 1 ) ? 'single' : 'multiple';
		$download_process = ( $file_count === 1 ) ? 'immediate' : 'modal';
		
		// Track the download validation event (when modal is opened/single file prepared)
		$this->track_download_validation( $product_id, $order, $user, $download_type, $download_process, $file_count );
		
		// Track each file access
		foreach ( $files as $file ) {
			// Skip files with errors
			if ( isset( $file['error'] ) ) {
				continue;
			}
			
			// Determine file size if available
			$file_size = null;
			if ( isset( $file['size'] ) && is_numeric( $file['size'] ) ) {
				$file_size = intval( $file['size'] );
			}
			
			// Insert tracking record
			$wpdb->insert(
				$tracking_table,
				array(
					'product_id' => $product_id,
					'order_id' => $order['id'],
					'user_id' => $user->ID,
					'customer_name' => sanitize_text_field( $order['customer_name'] ),
					'customer_email' => sanitize_email( $order['customer_email'] ),
					'file_name' => sanitize_text_field( $file['name'] ),
					'file_url' => esc_url_raw( $file['original_url'] ?? $file['url'] ),
					'file_type' => sanitize_text_field( $file['type'] ),
					'ip_address' => $ip_address,
					'user_agent' => $user_agent,
					'download_date' => current_time( 'mysql' ),
					'file_size' => $file_size,
					'download_type' => $download_type,
					'download_process' => $download_process
				),
				array(
					'%d', // product_id
					'%d', // order_id
					'%d', // user_id
					'%s', // customer_name
					'%s', // customer_email
					'%s', // file_name
					'%s', // file_url
					'%s', // file_type
					'%s', // ip_address
					'%s', // user_agent
					'%s', // download_date
					'%d', // file_size
					'%s', // download_type
					'%s'  // download_process
				)
			);
		}
	}
	
	/**
	 * Track download validation events.
	 *
	 * This method tracks when downloads are validated/prepared, differentiating between
	 * single file downloads (immediate) and multiple file downloads (modal-based).
	 *
	 * @since 1.0.0
	 * @param int $product_id Product ID.
	 * @param array $order Order data.
	 * @param WP_User $user Current user.
	 * @param string $download_type Type of download ('single' or 'multiple').
	 * @param string $download_process Process type ('immediate' or 'modal').
	 * @param int $file_count Number of files being downloaded.
	 */
	private function track_download_validation( $product_id, $order, $user, $download_type, $download_process, $file_count ) {
		global $wpdb;
		$validation_table = $wpdb->prefix . 'vrstore_download_validation';
		
		// Check if validation table exists, create if not
		$this->ensure_validation_table_exists();
		
		// Get user IP address and user agent
		$ip_address = $this->get_user_ip_address();
		$user_agent = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( $_SERVER['HTTP_USER_AGENT'] ) : '';
		
		// Insert validation tracking record
		$wpdb->insert(
			$validation_table,
			array(
				'product_id' => $product_id,
				'order_id' => $order['id'],
				'user_id' => $user->ID,
				'customer_name' => sanitize_text_field( $order['customer_name'] ),
				'customer_email' => sanitize_email( $order['customer_email'] ),
				'download_type' => sanitize_text_field( $download_type ),
				'download_process' => sanitize_text_field( $download_process ),
				'file_count' => intval( $file_count ),
				'ip_address' => $ip_address,
				'user_agent' => $user_agent,
				'validation_date' => current_time( 'mysql' ),
				'session_id' => $this->get_or_create_session_id()
			),
			array(
				'%d', // product_id
				'%d', // order_id
				'%d', // user_id
				'%s', // customer_name
				'%s', // customer_email
				'%s', // download_type
				'%s', // download_process
				'%d', // file_count
				'%s', // ip_address
				'%s', // user_agent
				'%s', // validation_date
				'%s'  // session_id
			)
		);
		
		// Log security event for monitoring
		if ( class_exists( 'VRSTORE_Security' ) ) {
			VRSTORE_Security::log_security_event(
				'Download validation tracked',
				'info',
				array(
					'product_id' => $product_id,
					'order_id' => $order['id'],
					'user_id' => $user->ID,
					'download_type' => $download_type,
					'download_process' => $download_process,
					'file_count' => $file_count,
					'ip_address' => $ip_address
				)
			);
		}
	}
	
	/**
	 * Ensure the download validation table exists.
	 *
	 * @since 1.0.0
	 */
	private function ensure_validation_table_exists() {
		global $wpdb;
		$validation_table = $wpdb->prefix . 'vrstore_download_validation';
		
		// Check if table exists
		$table_exists = $wpdb->get_var( $wpdb->prepare(
			"SELECT table_name FROM information_schema.tables WHERE table_schema = %s AND table_name = %s",
			DB_NAME,
			$validation_table
		) );
		
		if ( ! $table_exists ) {
			$this->create_validation_table();
		}
	}
	
	/**
	 * Create the download validation table.
	 *
	 * @since 1.0.0
	 */
	private function create_validation_table() {
		global $wpdb;
		$validation_table = $wpdb->prefix . 'vrstore_download_validation';
		
		$charset_collate = $wpdb->get_charset_collate();
		
		$sql = "CREATE TABLE $validation_table (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			product_id bigint(20) unsigned NOT NULL,
			order_id bigint(20) unsigned NOT NULL,
			user_id bigint(20) unsigned NOT NULL,
			customer_name varchar(255) NOT NULL,
			customer_email varchar(255) NOT NULL,
			download_type varchar(20) NOT NULL DEFAULT 'single',
			download_process varchar(20) NOT NULL DEFAULT 'immediate',
			file_count int(11) NOT NULL DEFAULT 1,
			ip_address varchar(45) DEFAULT NULL,
			user_agent text DEFAULT NULL,
			validation_date datetime NOT NULL,
			session_id varchar(255) DEFAULT NULL,
			PRIMARY KEY (id),
			KEY product_id (product_id),
			KEY order_id (order_id),
			KEY user_id (user_id),
			KEY download_type (download_type),
			KEY download_process (download_process),
			KEY validation_date (validation_date),
			KEY ip_address (ip_address)
		) $charset_collate;";
		
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		dbDelta( $sql );
	}
	
	/**
	 * Get or create a session ID for tracking purposes.
	 *
	 * @since 1.0.0
	 * @return string Session ID.
	 */
	private function get_or_create_session_id() {
		if ( ! session_id() ) {
			// Use global helper function for safe session handling
			vrstore_start_session();
		}
		
		$session_id = session_id();
		
		// Fallback if session is not available
		if ( empty( $session_id ) ) {
			$session_id = 'fallback_' . wp_generate_uuid4();
		}
		
		return $session_id;
	}
	
	/**
	 * Get user IP address with proxy support.
	 *
	 * @since 1.0.0
	 * @return string User IP address.
	 */
	private function get_user_ip_address() {
		// Check for various proxy headers
		$ip_headers = array(
			'HTTP_CF_CONNECTING_IP',     // Cloudflare
			'HTTP_CLIENT_IP',            // Proxy
			'HTTP_X_FORWARDED_FOR',      // Load balancer/proxy
			'HTTP_X_FORWARDED',          // Proxy
			'HTTP_X_CLUSTER_CLIENT_IP',  // Cluster
			'HTTP_FORWARDED_FOR',        // Proxy
			'HTTP_FORWARDED',            // Proxy
			'REMOTE_ADDR'                // Standard
		);
		
		foreach ( $ip_headers as $header ) {
			if ( ! empty( $_SERVER[ $header ] ) ) {
				$ip = sanitize_text_field( $_SERVER[ $header ] );
				
				// Handle comma-separated IPs (X-Forwarded-For can contain multiple IPs)
				if ( strpos( $ip, ',' ) !== false ) {
					$ip = trim( explode( ',', $ip )[0] );
				}
				
				// Validate IP address
				if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) ) {
					return $ip;
				}
			}
		}
		
		// Fallback to REMOTE_ADDR even if it's a private IP
		return isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( $_SERVER['REMOTE_ADDR'] ) : '0.0.0.0';
	}

	/**
	 * Check download limits based on daily limits and location restrictions.
	 *
	 * @since 1.0.0
	 * @param int $user_id User ID.
	 * @param string $ip_address IP address.
	 * @return array Array with 'allowed' boolean and 'message' string.
	 */
	private function check_download_limits( $user_id, $ip_address ) {
		// Get settings
		$settings = get_option( 'vrstore_settings', array() );
		
		// Check if download limits are enabled
		if ( empty( $settings['enable_download_limits'] ) ) {
			return array( 'allowed' => true, 'message' => '' );
		}
		
		// Exclude administrators if setting is enabled
		if ( ! empty( $settings['exclude_admin_from_limits'] ) && user_can( $user_id, 'manage_options' ) ) {
			return array( 'allowed' => true, 'message' => '' );
		}
		
		// Check daily download limits first
		$daily_limit = intval( $settings['daily_download_limit_per_user'] ?? 10 );
		if ( $daily_limit > 0 ) {
			$daily_limit_check = $this->check_daily_download_limit( $user_id, $ip_address, $daily_limit, $settings );
			if ( ! $daily_limit_check['allowed'] ) {
				return $daily_limit_check;
			}
		}
		
		// Check if location restrictions are enabled
		if ( empty( $settings['restrict_downloads_by_location'] ) ) {
			return array( 'allowed' => true, 'message' => '' );
		}
		
		global $wpdb;
		
		// Get the user's first order location
		$first_order_location = $this->get_user_first_order_location( $user_id );
		if ( ! $first_order_location ) {
			// No previous orders, allow download
			return array( 'allowed' => true, 'message' => '' );
		}
		
		// Get current location based on IP
		$current_location = $this->get_location_from_ip( $ip_address );
		
		// Get restriction type
		$restriction_type = $settings['location_restriction_type'] ?? 'country';
		
		// Check location match based on restriction type
		$location_match = false;
		$first_location_display = '';
		$current_location_display = '';
		
		switch ( $restriction_type ) {
			case 'ip':
				$location_match = ( $first_order_location['ip'] === $ip_address );
				$first_location_display = $first_order_location['ip'];
				$current_location_display = $ip_address;
				break;
			case 'country':
				$location_match = ( $first_order_location['country'] === $current_location['country'] );
				$first_location_display = $first_order_location['country'];
				$current_location_display = $current_location['country'];
				break;
			case 'city':
				$location_match = ( $first_order_location['city'] === $current_location['city'] && $first_order_location['country'] === $current_location['country'] );
				$first_location_display = $first_order_location['city'] . ', ' . $first_order_location['country'];
				$current_location_display = $current_location['city'] . ', ' . $current_location['country'];
				break;
		}
		
		if ( ! $location_match ) {
			$message = str_replace(
				array( '{restriction_type}', '{first_order_location}', '{current_location}' ),
				array( $restriction_type, $first_location_display, $current_location_display ),
				$settings['location_restriction_message'] ?? 'Download access denied. Downloads are restricted to the {restriction_type} of your first order ({first_order_location}). Your current location is {current_location}.'
			);
			return array( 'allowed' => false, 'message' => $message );
		}
		
		// Location matches, allow download
		return array( 'allowed' => true, 'message' => '' );
	}

	/**
	 * Check daily download limit for a user.
	 *
	 * @since 1.0.0
	 * @param int $user_id User ID.
	 * @param string $ip_address User IP address.
	 * @param int $daily_limit Daily download limit.
	 * @param array $settings Plugin settings array.
	 * @return array Array with 'allowed' boolean and 'message' string.
	 */
	private function check_daily_download_limit( $user_id, $ip_address, $daily_limit, $settings ) {
		global $wpdb;
		
		// Get today's date for comparison
		$today = current_time( 'Y-m-d' );
		
		// Count today's downloads for this user
		$download_table = $wpdb->prefix . 'vrstore_download_tracking';
		$downloads_today = $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM $download_table WHERE user_id = %d AND DATE(download_date) = %s",
			$user_id,
			$today
		) );
		
		// Check if limit is exceeded
		if ( intval( $downloads_today ) >= $daily_limit ) {
			// Get tomorrow's date for reset time
			$tomorrow = date( 'Y-m-d H:i:s', strtotime( 'tomorrow 00:00:00', current_time( 'timestamp' ) ) );
			$reset_time = date_i18n( get_option( 'time_format' ), strtotime( $tomorrow ) );
			
			// Get custom message or use default
			$message = $settings['download_limit_message'] ?? 'Download limit exceeded. You have reached the maximum of {limit} downloads per {period}. Please try again after {reset_time}.';
			
			// Replace placeholders in message
			$message = str_replace(
				array( '{limit}', '{period}', '{reset_time}' ),
				array( $daily_limit, 'day', $reset_time ),
				$message
			);
			
			return array( 'allowed' => false, 'message' => $message );
		}
		
		// Limit not exceeded
		return array( 'allowed' => true, 'message' => '' );
	}

	/**
	 * Get user's first order location.
	 *
	 * @since 1.0.0
	 * @param int $user_id User ID.
	 * @return array|false Array with location data or false if no orders found.
	 */
	private function get_user_first_order_location( $user_id ) {
		global $wpdb;
		
		$orders_table = $wpdb->prefix . 'vrstore_orders';
		
		$first_order = $wpdb->get_row( $wpdb->prepare(
			"SELECT ip_address, country, city FROM $orders_table WHERE customer_id = %d ORDER BY order_date ASC LIMIT 1",
			$user_id
		), ARRAY_A );
		
		if ( ! $first_order ) {
			return false;
		}
		
		return array(
			'ip' => $first_order['ip_address'] ?? '',
			'country' => $first_order['country'] ?? '',
			'city' => $first_order['city'] ?? ''
		);
	}

	/**
	 * Get location information from IP address.
	 *
	 * @since 1.0.0
	 * @param string $ip_address IP address.
	 * @return array Array with location data.
	 */
	private function get_location_from_ip( $ip_address ) {
		// For localhost/development, return default values
		if ( $ip_address === '127.0.0.1' || $ip_address === '::1' || strpos( $ip_address, '192.168.' ) === 0 || strpos( $ip_address, '10.' ) === 0 ) {
			return array(
				'country' => 'Local',
				'city' => 'Development'
			);
		}
		
		// Try to get location from a free IP geolocation service
		$response = wp_remote_get( 'http://ip-api.com/json/' . $ip_address . '?fields=status,country,city' );
		
		if ( is_wp_error( $response ) ) {
			return array(
				'country' => 'Unknown',
				'city' => 'Unknown'
			);
		}
		
		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );
		
		if ( $data && $data['status'] === 'success' ) {
			return array(
				'country' => $data['country'] ?? 'Unknown',
				'city' => $data['city'] ?? 'Unknown'
			);
		}
		
		return array(
			'country' => 'Unknown',
			'city' => 'Unknown'
		);
	}

	/**
	 * Render authentication form
	 *
     * @since 1.0.0
     * @param array $atts Shortcode attributes.
     * @return string Shortcode output.
     */
    public function cart_shortcode( $atts ) {
        $atts = shortcode_atts(
            array(
                'show_pending' => 'yes', // Show pending orders
            ),
            $atts,
            'vrstore_cart'
        );

        // Session is handled by session manager automatically
        $cart_instance = VRSTORE_Cart::get_instance();

        // Start output buffer.
        ob_start();

        // Get cart items from cart instance
        $cart_items = $cart_instance->get_cart();
        
        // Get pending orders if user is logged in
        $pending_orders = array();
        if ( is_user_logged_in() && $atts['show_pending'] === 'yes' ) {
            $pending_orders = $this->get_pending_orders( get_current_user_id() );
        }
        
        // Get settings instance
        $settings = VRSTORE_Settings::get_instance();
        
        // Get product instance for price formatting
        $product_instance = VRSTORE_Product::get_instance();

        // Get currency converter instance
        $currency_converter = VRSTORE_Currency_Converter::get_instance();

        // Include template.
        include VRSTORE_PLUGIN_DIR . 'views/shortcodes/cart.php';

        // Return output buffer.
        return ob_get_clean();
    }




    /**
     * Checkout shortcode.
	 *
	 * @since 1.0.0
	 * @param array $atts Shortcode attributes.
	 * @return string Shortcode output.
	 */
	public function checkout_shortcode( $atts ) {
		$atts = shortcode_atts(
			array(),
			$atts,
			'vrstore_checkout'
		);

		// Ensure frontend assets are enqueued for checkout
		$this->enqueue_checkout_assets();

		// Ensure cart session is initialized
		$cart_instance = VRSTORE_Cart::get_instance();
		// Session is handled by session manager automatically

	// Handle Extended Support parameter
	if ( isset( $_GET['extended_support'] ) && ! empty( $_GET['extended_support'] ) ) {
		error_log('ViraStore: Checkout shortcode - Processing Extended Support parameter: ' . $_GET['extended_support']);
		$this->handle_extended_support_checkout( sanitize_text_field( $_GET['extended_support'] ), $cart_instance );
		
		// Force session sync after Extended Support handling
		$cart_instance->ensure_session();
	}

	// Get cart items from cart instance
	$cart_items = $cart_instance->get_cart();
	error_log('ViraStore: Checkout shortcode - Cart items after Extended Support handling: ' . print_r($cart_items, true));
		
		// Get currency converter instance
		$currency_converter = VRSTORE_Currency_Converter::get_instance();

		// Check if cart is empty - but allow PayPal payment mode even with empty cart
		// (cart might be empty because order was already created)
		$is_paypal_payment_mode = isset($_GET['vrstore_payment']) && $_GET['vrstore_payment'] === 'paypal';
		
		if ( empty( $cart_items ) && ! $is_paypal_payment_mode ) {
			$cart_page = get_option( 'vrstore_cart_page' );
			$cart_url = $cart_page ? get_permalink( $cart_page ) : home_url();
			$products_page = get_option( 'vrstore_products_page' );
			$products_url = $products_page ? get_permalink( $products_page ) : home_url();
			
			return '<div class="vrstore-checkout-empty">' .
				'<h3>' . esc_html( $this->get_translated_text( 'Your cart is empty' ) ) . '</h3>' .
			'<p>' . esc_html( $this->get_translated_text( 'You need to add some products to your cart before you can checkout.' ) ) . '</p>' .
			'<div class="vrstore-checkout-actions">' .
			'<a href="' . esc_url( $products_url ) . '" class="vrstore-button vrstore-button-primary">' . esc_html( $this->get_translated_text( 'Continue Shopping' ) ) . '</a>' .
			'<a href="' . esc_url( $cart_url ) . '" class="vrstore-button vrstore-button-secondary">' . esc_html( $this->get_translated_text( 'View Cart' ) ) . '</a>' .
				'</div>' .
				'</div>';
		}

		// Get payment gateways.
		// If PayPal payment mode is active, ensure PayPal gateway is available even if cart is empty
		$payment_gateways = $this->get_payment_gateways();
		
		// If PayPal payment mode is active but PayPal gateway not in list, add it
		if ($is_paypal_payment_mode && !isset($payment_gateways['paypal'])) {
			if (class_exists('VRSTORE_Payment')) {
				$payment_instance = VRSTORE_Payment::get_instance();
				$all_gateways = $payment_instance->get_available_gateways();
				if (isset($all_gateways['paypal'])) {
					$payment_gateways['paypal'] = $all_gateways['paypal'];
				}
			}
		}
		
		// Get Google login settings for checkout
		$google_login_enabled = false;
		$google_client_id = '';
		$google_redirect_uri = '';
		if ( class_exists( 'VRSTORE_Settings' ) ) {
			try {
				$settings = VRSTORE_Settings::get_instance();
				$google_login_enabled = $settings->get_setting( 'enable_google_login', '' ) === 'on';
				$google_client_id = $settings->get_setting( 'google_client_id', '' );
				$google_redirect_uri = $settings->get_setting( 'google_redirect_uri', home_url('/') . '?vrstore_google_callback=1' );
			} catch ( Exception $e ) {
				// Settings not available, default to false
			}
		}

		// Check if this is a PayPal payment redirect (vrstore_payment=paypal)
		$paypal_payment_mode = false;
		$paypal_payment_data = null;
		if (isset($_GET['vrstore_payment']) && $_GET['vrstore_payment'] === 'paypal' && isset($_GET['order_id'])) {
			$paypal_order_id = absint($_GET['order_id']);
			if ($paypal_order_id > 0) {
				$paypal_payment_data = get_transient("vrstore_paypal_payment_" . $paypal_order_id);
				if ($paypal_payment_data && isset($paypal_payment_data['show_form']) && $paypal_payment_data['show_form']) {
					$paypal_payment_mode = true;
					
					// If cart is empty but we have PayPal payment mode, get order items for display
					if (empty($cart_items) && class_exists('VRSTORE_Order')) {
						$order_data = VRSTORE_Order::get_order($paypal_order_id);
						if ($order_data && !empty($order_data['cart_items'])) {
							// Use order cart items for display purposes (don't modify actual cart)
							$cart_items = $order_data['cart_items'];
							error_log(
								"ViraStore Checkout: Using order cart items for display - Order: #" . 
								$paypal_order_id . 
								", Items: " . 
								count($cart_items)
							);
						}
					}
					
					error_log(
						"ViraStore Checkout: PayPal payment mode detected - Order: " .
							$paypal_order_id .
							", Cart items for display: " .
							(count($cart_items) > 0 ? count($cart_items) : 0),
					);
				}
			}
		}

		// Start output buffer.
		ob_start();

		// Include template - pass PayPal payment mode and data
		$vrstore_paypal_payment_mode = $paypal_payment_mode;
		$vrstore_paypal_payment_data = $paypal_payment_data;
		include VRSTORE_PLUGIN_DIR . 'views/shortcodes/checkout.php';

		// Return output buffer.
		return ob_get_clean();
	}

	/**
	 * Account shortcode.
	 *
	 * @since 1.0.0
	 * @param array $atts Shortcode attributes.
	 * @return string Shortcode output.
	 */
	public function account_shortcode( $atts ) {
		$atts = shortcode_atts(
			array(),
			$atts,
			'vrstore_account'
		);

		// Get currency converter instance
		$currency_converter = VRSTORE_Currency_Converter::get_instance();

		// Ensure frontend assets are enqueued for account page
		$this->enqueue_account_assets();

		// Check if user is logged in.
		if ( ! is_user_logged_in() ) {
			// Return custom login/register interface
			ob_start();
			$this->render_login_register_interface();
			return ob_get_clean();
		}
		
		// Additional user validation
		$current_user = wp_get_current_user();
		if ( ! $current_user || ! $current_user->exists() ) {
			return '<div class="vrstore-account-container"><div class="vrstore-error">User session error. Please log out and log in again.</div></div>';
		}
		
		// Check if user has valid email
		if ( empty( $current_user->user_email ) ) {
			return '<div class="vrstore-account-container"><div class="vrstore-error">Account error: No email address found.</div></div>';
		}

		// Get current user.
		$user_id = get_current_user_id();

		// Check and fix any missing licenses before displaying account data
		if ( class_exists( 'VRSTORE_Order' ) ) {
			$fixed_count = VRSTORE_Order::fix_missing_licenses();
		}

		// Get user purchases.
		$purchases = $this->get_user_purchases( $user_id );

		// Get user licenses.
		$licenses = $this->get_user_licenses( $user_id );

		// Define account labels for template.
		$account_labels = array(
			'my_account'         => $this->get_translated_text( 'My Account' ),
			'hello'              => $this->get_translated_text( 'Hello, %s!' ),
			'email'              => $this->get_translated_text( 'Email: %s' ),
			'tab_dashboard'      => $this->get_translated_text( 'Dashboard' ),
			'tab_purchases'      => $this->get_translated_text( 'Purchases' ),
			'tab_licenses'       => $this->get_translated_text( 'Licenses' ),
			'tab_account'        => $this->get_translated_text( 'Account Details' ),
			'order'              => $this->get_translated_text( 'Order' ),
			'date'               => $this->get_translated_text( 'Date' ),
			'product'            => $this->get_translated_text( 'Product' ),
			'total'              => $this->get_translated_text( 'Total' ),
			'status'             => $this->get_translated_text( 'Status' ),
			'actions'            => $this->get_translated_text( 'Actions' ),
			'download'           => $this->get_translated_text( 'Download' ),
			'no_purchases'       => $this->get_translated_text( 'You have not made any purchases yet.' ),
			'license_key'        => $this->get_translated_text( 'License Key' ),
			'license_type'       => $this->get_translated_text( 'License Type' ),
			'activations'        => $this->get_translated_text( 'Activations' ),
			'expiry_date'        => $this->get_translated_text( 'Expiry Date' ),
			'manage'             => $this->get_translated_text( 'Manage' ),
			'never'              => $this->get_translated_text( 'Never' ),
			'license_details'    => $this->get_translated_text( 'License Details: %s' ),
			'license_key_label'  => $this->get_translated_text( 'License Key:' ),
			'status_label'       => $this->get_translated_text( 'Status:' ),
			'activations_label'  => $this->get_translated_text( 'Activations:' ),
			'expiry_date_label'  => $this->get_translated_text( 'Expiry Date:' ),
			'unlimited'          => $this->get_translated_text( '%s (Unlimited)' ),
			'activations_limit'  => $this->get_translated_text( '%1$s / %2$s' ),
			'total_purchases'    => $this->get_translated_text( 'Total Purchases' ),
			'active_licenses'    => $this->get_translated_text( 'Active Licenses' ),
			'total_spent'        => $this->get_translated_text( 'Total Spent' ),
			'recent_purchases'   => $this->get_translated_text( 'Recent Purchases' ),
			'view_all_purchases' => $this->get_translated_text( 'View All Purchases' ),
			'view_all_licenses'  => $this->get_translated_text( 'View All Licenses' ),
			'no_purchases'       => $this->get_translated_text( 'No purchases yet.' ),
			'no_licenses'        => $this->get_translated_text( 'No licenses yet.' ),
			'unknown_product'    => $this->get_translated_text( 'Unknown Product' ),
			'unknown_status'     => $this->get_translated_text( 'Unknown' ),
			'na'                 => $this->get_translated_text( 'N/A' ),
			'expired'            => $this->get_translated_text( 'Expired' ),

			'account_created'    => $this->get_translated_text( 'Your account has been created successfully!' ),
		);

		// Start output buffer.
		ob_start();

		// Include template.
		include VRSTORE_PLUGIN_DIR . 'views/shortcodes/account.php';

		// Get output buffer content
		return ob_get_clean();
	}

	/**
	 * License shortcode.
	 *
	 * @since 1.0.0
	 * @param array $atts Shortcode attributes.
	 * @return string Shortcode output.
	 */
	public function license_shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'product_id' => 0,
			),
			$atts,
			'vrstore_license'
		);

		// Sanitize attributes.
		$product_id = absint( $atts['product_id'] );

		// Check if product exists.
		if ( ! $product_id || 'vrstore_product' !== get_post_type( $product_id ) ) {
			return '<p>' . esc_html( $this->get_translated_text( 'Product not found.' ) ) . '</p>';
		}

		// Get product.
		$product = get_post( $product_id );

		// Get current domain.
		$domain = isset( $_SERVER['HTTP_HOST'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) : '';

		// Start output buffer.
		ob_start();

		// Include template.
		include VRSTORE_PLUGIN_DIR . 'views/shortcodes/license.php';

		// Return output buffer.
		return ob_get_clean();
	}

	/**
	 * Buy button shortcode.
	 *
	 * @since 1.0.0
	 * @param array $atts Shortcode attributes.
	 * @return string Shortcode output.
	 */
	public function buy_button_shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'id'          => 0,
				'text'        => '',
				'class'       => '',
				'style'       => '',
				'show_price'  => 'yes',
				'license_type' => '',
				'redirect'    => 'cart', // 'cart' or 'checkout'
			),
			$atts,
			'vrstore_buy_button'
		);

		// Ensure frontend assets are enqueued for buy button
		$this->enqueue_products_assets();

		// Sanitize attributes.
		$product_id = absint( $atts['id'] );
		$button_text = sanitize_text_field( $atts['text'] );
		$button_class = sanitize_text_field( $atts['class'] );
		$button_style = sanitize_text_field( $atts['style'] );
		$show_price = 'yes' === $atts['show_price'];
		$license_type = sanitize_text_field( $atts['license_type'] );
		$redirect = sanitize_text_field( $atts['redirect'] );

		// Check if product or course exists.
		$post_type = get_post_type( $product_id );
		if ( ! $product_id || ( 'vrstore_product' !== $post_type && 'vrstore_course' !== $post_type ) ) {
			return '<p class="vrstore-error">' . esc_html( $this->get_translated_text( 'Product or course not found.' ) ) . '</p>';
		}

		// Get product or course.
		$product = get_post( $product_id );

		// Check if product/course is published
		if ( 'publish' !== $product->post_status ) {
			$item_type = 'vrstore_course' === $post_type ? 'Course' : 'Product';
			return '<p class="vrstore-error">' . esc_html( $this->get_translated_text( $item_type . ' is not available.' ) ) . '</p>';
		}

		// Get product instance for price formatting
		if ( ! class_exists( 'VRSTORE_Product' ) ) {
			return '<p class="vrstore-error">' . esc_html( $this->get_translated_text( 'Product system is not available.' ) ) . '</p>';
		}

		$product_instance = VRSTORE_Product::get_instance();
		$settings = class_exists( 'VRSTORE_Settings' ) ? VRSTORE_Settings::get_instance() : null;

		// Get product or course pricing information
		if ( 'vrstore_course' === $post_type ) {
			$price = get_post_meta( $product_id, '_vrstore_course_price', true );
			$sale_price = get_post_meta( $product_id, '_vrstore_course_sale_price', true );
			$is_free = get_post_meta( $product_id, '_vrstore_course_is_free', true );
			// Override price if course is marked as free
			if ( $is_free ) {
				$price = 0;
				$sale_price = 0;
			}
		} else {
			$price = get_post_meta( $product_id, '_vrstore_product_price', true );
			$sale_price = get_post_meta( $product_id, '_vrstore_product_sale_price', true );
		}
		$currency = $settings ? $settings->get_setting( 'currency', 'USD' ) : 'USD';
		$currency_symbol = VRSTORE_Product::get_currency_symbol( $currency );

		// Get custom license types and pricing
		$custom_license_types = $settings ? $settings->get_setting( 'custom_license_types', array() ) : array();
		$license_pricing_data = get_post_meta( $product_id, '_vrstore_product_license_pricing', true );
		$custom_license_pricing = $settings ? $settings->get_setting( 'custom_license_pricing', array() ) : array();
		
		// Get license type availability settings for this product
		$license_availability = get_post_meta( $product_id, '_vrstore_product_license_availability', true );
		if ( ! is_array( $license_availability ) ) {
			$license_availability = array();
		}
				
		// Filter license types based on availability
		if ( ! empty( $license_availability ) ) {
			$available_license_types = array();
			foreach ( $custom_license_types as $type ) {
				$slug = isset( $type['slug'] ) ? $type['slug'] : sanitize_title( $type['label'] );
				// Show license type if it's explicitly enabled
				// Note: The admin saves false for disabled types, so we only check for explicit true
				if ( isset( $license_availability[ $slug ] ) && $license_availability[ $slug ] === true ) {
					$available_license_types[] = $type;
				}
				// If no availability setting exists for this slug, show it by default (backward compatibility)
				elseif ( ! isset( $license_availability[ $slug ] ) ) {
					$available_license_types[] = $type;
				}
			}
			$custom_license_types = $available_license_types;
		}

		// Determine the pricing to display
		$display_price = $price;
		$display_sale_price = $sale_price;
		$selected_license_type = '';

		// If a specific license type is requested, validate and use its pricing
		if ( ! empty( $license_type ) && ! empty( $custom_license_types ) ) {
			$license_type_found = false;
			foreach ( $custom_license_types as $type ) {
				$type_slug = isset( $type['slug'] ) ? $type['slug'] : sanitize_title( $type['label'] );
				if ( $type_slug === $license_type ) {
					$selected_license_type = $type_slug;
					$license_type_found = true;
					
					// Check for per-product license pricing override
					if ( isset( $license_pricing_data[ $type_slug ] ) && is_array( $license_pricing_data[ $type_slug ] ) ) {
						$display_price = $license_pricing_data[ $type_slug ]['price'] ?? $price;
						$display_sale_price = $license_pricing_data[ $type_slug ]['sale_price'] ?? $sale_price;
					} elseif ( isset( $custom_license_pricing[ $type_slug ] ) && is_array( $custom_license_pricing[ $type_slug ] ) ) {
						$display_price = $custom_license_pricing[ $type_slug ]['price'] ?? $price;
						$display_sale_price = $custom_license_pricing[ $type_slug ]['sale_price'] ?? $sale_price;
					} else {
						$display_price = $type['regular_price'] ?? $price;
						$display_sale_price = $type['sale_price'] ?? $sale_price;
					}
					break;
				}
			}
			
			// If requested license type is not available for this product, show error
			if ( ! $license_type_found ) {
				return '<p class="vrstore-error">' . esc_html( sprintf( $this->get_translated_text( 'License type "%s" is not available for this product.' ), $license_type ) ) . '</p>';
			}
		}

        // If base pricing is empty but we have license types, try to get the cheapest license price
        if ( ( empty( $display_price ) || floatval( $display_price ) <= 0 ) && 
             ( empty( $display_sale_price ) || floatval( $display_sale_price ) <= 0 ) && 
             empty( $selected_license_type ) && 
             ! empty( $custom_license_types ) ) {
            
            // Find the cheapest license type price to display
            $cheapest_price = null;
            $cheapest_sale_price = null;
            
            foreach ( $custom_license_types as $type ) {
                $type_slug = isset( $type['slug'] ) ? $type['slug'] : sanitize_title( $type['label'] );
                $type_price = null;
                $type_sale_price = null;
                
                // Check for per-product license pricing override
                if ( isset( $license_pricing_data[ $type_slug ] ) && is_array( $license_pricing_data[ $type_slug ] ) ) {
                    $type_price = $license_pricing_data[ $type_slug ]['price'] ?? null;
                    $type_sale_price = $license_pricing_data[ $type_slug ]['sale_price'] ?? null;
                } elseif ( isset( $custom_license_pricing[ $type_slug ] ) && is_array( $custom_license_pricing[ $type_slug ] ) ) {
                    $type_price = $custom_license_pricing[ $type_slug ]['price'] ?? null;
                    $type_sale_price = $custom_license_pricing[ $type_slug ]['sale_price'] ?? null;
                } else {
                    $type_price = $type['regular_price'] ?? null;
                    $type_sale_price = $type['sale_price'] ?? null;
                }
                
                // Track cheapest prices
                if ( $type_price !== null && is_numeric( $type_price ) && floatval( $type_price ) >= 0 ) {
                    if ( $cheapest_price === null || floatval( $type_price ) < floatval( $cheapest_price ) ) {
                        $cheapest_price = $type_price;
                    }
                }
                
                if ( $type_sale_price !== null && is_numeric( $type_sale_price ) && floatval( $type_sale_price ) >= 0 ) {
                    if ( $cheapest_sale_price === null || floatval( $type_sale_price ) < floatval( $cheapest_sale_price ) ) {
                        $cheapest_sale_price = $type_sale_price;
                    }
                }
            }
            
            // Use the cheapest prices if found
            if ( $cheapest_price !== null ) {
                $display_price = $cheapest_price;
            }
            if ( $cheapest_sale_price !== null ) {
                $display_sale_price = $cheapest_sale_price;
            }
        }
        
        // Format prices using currency converter - use same approach as product.php
        $currency_converter = VRSTORE_Currency_Converter::get_instance();
        $formatted_price = '';
        $formatted_sale_price = '';

        if ( ! empty( $display_price ) && is_numeric( $display_price ) && floatval( $display_price ) > 0 ) {
            // Use same approach as product.php - single format_price call with no K/M formatting
            $formatted_price = $currency_converter->format_price( floatval( $display_price ), '', false );
        } elseif ( floatval( $display_price ) === 0.0 ) {
            // Handle free products
            $formatted_price = $this->get_translated_text( 'Free' );
        }

        if ( ! empty( $display_sale_price ) && is_numeric( $display_sale_price ) && floatval( $display_sale_price ) > 0 ) {
            // Use same approach as product.php - single format_price call with no K/M formatting
            $formatted_sale_price = $currency_converter->format_price( floatval( $display_sale_price ), '', false );
        } elseif ( floatval( $display_sale_price ) === 0.0 ) {
            // Handle free sale products
            $formatted_sale_price = $this->get_translated_text( 'Free' );
        }
        
        // Debug: Log pricing issues for troubleshooting
        if ( empty( $formatted_price ) && empty( $formatted_sale_price ) && WP_DEBUG ) {
            error_log( sprintf( 
                'VRSTORE Buy Button: No valid price found for product ID %d. Raw price: %s, Sale price: %s, License type: %s',
                $product_id,
                var_export( $display_price, true ),
                var_export( $display_sale_price, true ),
                $selected_license_type
            ) );
        }

		// Determine button text
		if ( empty( $button_text ) ) {
			if ( 'vrstore_course' === $post_type ) {
				// For courses, use different text based on whether it's free or paid
				if ( ( isset( $is_free ) && $is_free ) || ( floatval( $display_price ) === 0.0 && floatval( $display_sale_price ) === 0.0 ) ) {
					$button_text = $this->get_translated_text( 'Enroll for Free' );
				} else {
					$button_text = $this->get_translated_text( 'Enroll Now' );
				}
			} else {
				$button_text = $this->get_translated_text( 'Add to Cart' );
			}
		}


		// Start output buffer.
		ob_start();

		// Include template.
		include VRSTORE_PLUGIN_DIR . 'views/shortcodes/buy-button.php';

		// Return output buffer.
		return ob_get_clean();
	}

	/**
	 * Get payment gateways.
	 *
	 * @since 1.0.0
	 * @return array Payment gateways.
	 */
	private function get_payment_gateways() {
		if ( class_exists( 'VRSTORE_Payment' ) ) {
			$payment_instance = VRSTORE_Payment::get_instance();
			return $payment_instance->get_available_gateways();
		}
		return array();
	}

	/**
	 * Generate math captcha based on settings.
	 *
	 * @since 1.0.0
	 * @return array Array containing question, answer, and HTML.
	 */
	private function generate_math_captcha() {
		// Get settings
		$settings = VRSTORE_Settings::get_instance();
		$is_enabled = $settings->get_setting( 'enable_math_captcha', 'on' ) === 'on';
		
		if ( ! $is_enabled ) {
			return array(
				'question' => '',
				'answer' => '',
				'html' => ''
			);
		}
		
		$difficulty = $settings->get_setting( 'math_captcha_difficulty', 'easy' );
		$operations = $settings->get_setting( 'math_captcha_operations', array( 'addition' => 'on', 'subtraction' => 'on' ) );
		
		// Set number ranges based on difficulty
		switch ( $difficulty ) {
			case 'medium':
				$min = 1;
				$max = 50;
				break;
			case 'hard':
				$min = 1;
				$max = 100;
				break;
			default: // easy
				$min = 1;
				$max = 10;
				break;
		}
		
		// Get enabled operations
		$enabled_ops = array();
		if ( isset( $operations['addition'] ) && $operations['addition'] === 'on' ) {
			$enabled_ops[] = 'addition';
		}
		if ( isset( $operations['subtraction'] ) && $operations['subtraction'] === 'on' ) {
			$enabled_ops[] = 'subtraction';
		}
		if ( isset( $operations['multiplication'] ) && $operations['multiplication'] === 'on' ) {
			$enabled_ops[] = 'multiplication';
		}
		
		// Default to addition if no operations enabled
		if ( empty( $enabled_ops ) ) {
			$enabled_ops = array( 'addition' );
		}
		
		// Select random operation
		$operation = $enabled_ops[ array_rand( $enabled_ops ) ];
		
		// Generate numbers and calculate answer
		$num1 = rand( $min, $max );
		$num2 = rand( $min, $max );
		
		switch ( $operation ) {
			case 'subtraction':
				// Ensure positive result
				if ( $num1 < $num2 ) {
					$temp = $num1;
					$num1 = $num2;
					$num2 = $temp;
				}
				$answer = $num1 - $num2;
				$question = $num1 . ' - ' . $num2;
				break;
			case 'multiplication':
				// Use smaller numbers for multiplication
				$num1 = rand( 1, min( 10, $max ) );
				$num2 = rand( 1, min( 10, $max ) );
				$answer = $num1 * $num2;
				$question = $num1 . ' × ' . $num2;
				break;
			default: // addition
				$answer = $num1 + $num2;
				$question = $num1 . ' + ' . $num2;
				break;
		}
		
		return array(
			'question' => $question,
			'answer' => $answer,
			'html' => $question
		);
	}

	/**
	 * Enqueue frontend assets for checkout.
	 *
	 * @since 1.0.0
	 */
	private function enqueue_checkout_assets() {
		// Enqueue frontend styles
		wp_enqueue_style(
			'vrstore-frontend',
			VRSTORE_PLUGIN_URL . 'assets/css/frontend.css',
			array(),
			VRSTORE_VERSION
		);

		// Enqueue frontend scripts
		wp_enqueue_script(
			'vrstore-frontend',
			VRSTORE_PLUGIN_URL . 'assets/js/frontend.js',
			array( 'jquery' ),
			VRSTORE_VERSION,
			true
		);

		// Get settings instance
		$settings = VRSTORE_Settings::get_instance();

		// Localize frontend script
		wp_localize_script(
			'vrstore-frontend',
			'vrstore_frontend',
			array(
				'ajax_url'             => admin_url( 'admin-ajax.php' ),
				'nonce'               => wp_create_nonce( 'vrstore_frontend_nonce' ),
				'adding_to_cart'       => $this->get_translated_text( 'Adding...' ),
				'ajax_error'           => $this->get_translated_text( 'An error occurred. Please try again.' ),
				'required_field'       => $this->get_translated_text( 'This field is required.' ),
				'invalid_email'        => $this->get_translated_text( 'Please enter a valid email address.' ),
				'license_key_required' => $this->get_translated_text( 'Please enter a license key.' ),
				'activating'           => $this->get_translated_text( 'Activating...' ),
				'activate'             => $this->get_translated_text( 'Activate' ),
				'deactivating'         => $this->get_translated_text( 'Deactivating...' ),
				'deactivate'           => $this->get_translated_text( 'Deactivate' ),
				'confirm_remove'       => $this->get_translated_text( 'Are you sure you want to remove this item from your cart?' ),
				'cart_empty'           => $this->get_translated_text( 'Your cart is empty.' ),
				// Currency settings
				'currency'             => $settings->get_setting( 'currency', 'USD' ),
				'currency_position'    => $settings->get_setting( 'currency_position', 'left' ),
				'currency_symbol'      => VRSTORE_Product::get_currency_symbol( $settings->get_setting( 'currency', 'USD' ) ),
				'decimal_number'       => $settings->get_setting( 'decimal_number', '2' ),
				'decimal_separator'    => $settings->get_setting( 'decimal_separator', '.' ),
			'thousand_separator'   => $settings->get_setting( 'thousand_separator', ',' ),
			'redirecting'          => $this->get_translated_text( 'Redirecting...' ),
			)
		);
	}

	/**
	 * Enqueue frontend assets for account page.
	 *
	 * @since 1.0.0
	 */
	private function enqueue_account_assets() {
		// Force enqueue assets even if already loaded
		// This ensures they're available when shortcode renders
		
		// Enqueue frontend styles - force re-enqueue if already loaded
		if ( ! wp_style_is( 'vrstore-frontend', 'enqueued' ) ) {
			wp_enqueue_style(
				'vrstore-frontend',
				VRSTORE_PLUGIN_URL . 'assets/css/frontend.css',
				array(),
				VRSTORE_VERSION
			);
		}

		// Enqueue enhanced frontend scripts for account functionality
		if ( ! wp_script_is( 'vrstore-frontend-enhanced', 'enqueued' ) ) {
			wp_enqueue_script(
				'vrstore-frontend-enhanced',
				VRSTORE_PLUGIN_URL . 'assets/js/frontend-enhanced.js',
				array( 'jquery' ),
				VRSTORE_VERSION,
				true
			);
		}

		// Enqueue domain management JavaScript
		if ( ! wp_script_is( 'vrstore-domain-management', 'enqueued' ) ) {
			wp_enqueue_script(
				'vrstore-domain-management',
				VRSTORE_PLUGIN_URL . 'assets/js/domain-management.js',
				array( 'jquery' ),
				VRSTORE_VERSION,
				true
			);
		}

		// Also enqueue basic frontend script for fallback
		if ( ! wp_script_is( 'vrstore-frontend', 'enqueued' ) ) {
			wp_enqueue_script(
				'vrstore-frontend',
				VRSTORE_PLUGIN_URL . 'assets/js/frontend.js',
				array( 'jquery' ),
				VRSTORE_VERSION,
				true
			);
		}



		// Get settings instance
		$settings = VRSTORE_Settings::get_instance();

		// Localize enhanced frontend script (always localize to ensure data is available)
		wp_localize_script(
			'vrstore-frontend-enhanced',
			'vrstore_frontend',
			array(
				'ajax_url'             => admin_url( 'admin-ajax.php' ),
				'nonce'               => wp_create_nonce( 'vrstore_frontend_nonce' ),
				'adding_to_cart'       => $this->get_translated_text( 'Adding...' ),
				'ajax_error'           => $this->get_translated_text( 'An error occurred. Please try again.' ),
				'required_field'       => $this->get_translated_text( 'This field is required.' ),
				'invalid_email'        => $this->get_translated_text( 'Please enter a valid email address.' ),
				'license_key_required' => $this->get_translated_text( 'Please enter a license key.' ),
				'activating'           => $this->get_translated_text( 'Activating...' ),
				'activate'             => $this->get_translated_text( 'Activate' ),
				'deactivating'         => $this->get_translated_text( 'Deactivating...' ),
				'deactivate'           => $this->get_translated_text( 'Deactivate' ),
				'confirm_remove'       => $this->get_translated_text( 'Are you sure you want to remove this item from your cart?' ),
				'cart_empty'           => $this->get_translated_text( 'Your cart is empty.' ),
				// Currency settings
				'currency'             => $settings->get_setting( 'currency', 'USD' ),
				'currency_position'    => $settings->get_setting( 'currency_position', 'left' ),
				'currency_symbol'      => VRSTORE_Product::get_currency_symbol( $settings->get_setting( 'currency', 'USD' ) ),
				'decimal_number'       => $settings->get_setting( 'decimal_number', '2' ),
				'decimal_separator'    => $settings->get_setting( 'decimal_separator', '.' ),
			'thousand_separator'   => $settings->get_setting( 'thousand_separator', ',' ),
			'refreshing'           => $this->get_translated_text( 'Refreshing...' ),
			'copy_success'         => $this->get_translated_text( 'Copied to clipboard!' ),
			'copy_error'           => $this->get_translated_text( 'Failed to copy to clipboard.' ),
			'redirecting'          => $this->get_translated_text( 'Redirecting...' ),
			)
		);
		
		// Localize domain management script with AJAX data
		wp_localize_script(
			'vrstore-domain-management',
			'vrstore_ajax',
			array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'vrstore_frontend_nonce' ),
				'customer_id' => get_current_user_id() // Pass user ID for validation (server validates ownership)
			)
		);

		// Localize domain management strings
		wp_localize_script(
			'vrstore-domain-management',
			'vrstore_domain_strings',
			array(
				'domain_required'       => $this->get_translated_text( 'Please enter a domain name.' ),
				'domain_invalid'        => $this->get_translated_text( 'Please enter a valid domain name.' ),
				'activation_success'    => $this->get_translated_text( 'Domain activated successfully!' ),
				'deactivation_success'  => $this->get_translated_text( 'Domain deactivated successfully!' ),
				'activation_error'      => $this->get_translated_text( 'Failed to activate domain. Please try again.' ),
				'deactivation_error'    => $this->get_translated_text( 'Failed to deactivate domain. Please try again.' ),
				'refresh_error'         => $this->get_translated_text( 'Failed to refresh domains. Please try again.' ),
				'limit_reached'         => $this->get_translated_text( 'Activation limit reached. Please deactivate a domain first.' ),
				'confirm_deactivation'  => $this->get_translated_text( 'Are you sure you want to deactivate this domain?' ),
				'processing'            => $this->get_translated_text( 'Processing...' ),
				'network_error'         => $this->get_translated_text( 'Network error. Please check your connection and try again.' )
			)
		);
		
		// Also localize the basic frontend script for compatibility
		wp_localize_script(
			'vrstore-frontend',
			'vrstore_frontend_basic',
			array(
				'ajax_url'             => admin_url( 'admin-ajax.php' ),
				'nonce'               => wp_create_nonce( 'vrstore_frontend_nonce' ),
				'currency'             => $settings->get_setting( 'currency', 'USD' ),
				'currency_symbol'      => VRSTORE_Product::get_currency_symbol( $settings->get_setting( 'currency', 'USD' ) ),
			)
		);
	}

	/**
	 * Enqueue frontend assets for products page.
	 *
	 * @since 1.0.0
	 */
	private function enqueue_products_assets() {
		// Enqueue frontend styles
		wp_enqueue_style(
			'vrstore-frontend',
			VRSTORE_PLUGIN_URL . 'assets/css/frontend.css',
			array(),
			VRSTORE_VERSION
		);

		// Enqueue frontend scripts
		wp_enqueue_script(
			'vrstore-frontend',
			VRSTORE_PLUGIN_URL . 'assets/js/frontend.js',
			array( 'jquery' ),
			VRSTORE_VERSION,
			true
		);

		// Get settings instance
		$settings = VRSTORE_Settings::get_instance();

		// Localize frontend script
		wp_localize_script(
			'vrstore-frontend',
			'vrstore_frontend',
			array(
				'ajax_url'             => admin_url( 'admin-ajax.php' ),
				'nonce'               => wp_create_nonce( 'vrstore_frontend_nonce' ),
				'adding_to_cart'       => $this->get_translated_text( 'Adding...' ),
				'ajax_error'           => $this->get_translated_text( 'An error occurred. Please try again.' ),
				'required_field'       => $this->get_translated_text( 'This field is required.' ),
				'invalid_email'        => $this->get_translated_text( 'Please enter a valid email address.' ),
				'license_key_required' => $this->get_translated_text( 'Please enter a license key.' ),
				'activating'           => $this->get_translated_text( 'Activating...' ),
				'activate'             => $this->get_translated_text( 'Activate' ),
				'deactivating'         => $this->get_translated_text( 'Deactivating...' ),
				'deactivate'           => $this->get_translated_text( 'Deactivate' ),
				'confirm_remove'       => $this->get_translated_text( 'Are you sure you want to remove this item from your cart?' ),
				'cart_empty'           => $this->get_translated_text( 'Your cart is empty.' ),
				// Currency settings
				'currency'             => $settings->get_setting( 'currency', 'USD' ),
				'currency_symbol'      => VRSTORE_Product::get_currency_symbol( $settings->get_setting( 'currency', 'USD' ) ),
				'currency_position'    => $settings->get_setting( 'currency_position', 'left' ),
				'decimal_separator'    => $settings->get_setting( 'decimal_separator', '.' ),
				'thousand_separator'   => $settings->get_setting( 'thousand_separator', ',' ),
				'number_of_decimals'   => $settings->get_setting( 'number_of_decimals', 2 ),
			)
		);
	}

	/**
	 * Get user purchases.
	 *
	 * @since 1.0.0
	 * @param int $user_id User ID.
	 * @return array User purchases.
	 */
	private function get_user_purchases( $user_id ) {
		$purchases = array();
		
		// Get user email for matching orders
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return apply_filters( 'vrstore_user_purchases', $purchases, $user_id );
		}
		
		// Check if user has customer role or has made orders
		$has_customer_role = in_array( 'customer', $user->roles );
		$user_email = $user->user_email;
		
		global $wpdb;
		$orders_table = $wpdb->prefix . 'vrstore_orders';
		
		// Check if orders table exists
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$orders_table'" ) !== $orders_table ) {
			return apply_filters( 'vrstore_user_purchases', $purchases, $user_id );
		}
		
		// Check if user has any orders (for users without customer role)
		if ( ! $has_customer_role ) {
			$order_count = $wpdb->get_var( $wpdb->prepare(
				"SELECT COUNT(*) FROM $orders_table WHERE customer_email = %s",
				$user_email
			) );
			
			// If user has no orders and no customer role, return empty
			if ( ! $order_count ) {
				return apply_filters( 'vrstore_user_purchases', $purchases, $user_id );
			}
			
			// User has orders but no customer role - let's assign the role for future access
			if ( $order_count > 0 ) {
				$user->add_role( 'customer' );
				// Customer role added to user with existing orders
			}
		}
		
		// Get orders by user email
		$orders = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM $orders_table WHERE customer_email = %s ORDER BY created_at DESC",
			$user_email
		), ARRAY_A );
		
		foreach ( $orders as $order ) {
			// Get product details
			$product_id = $order['product_id'];
			$product_title = $order['product_name'];
			
			// Handle Extended Support products
			if ( is_string( $product_id ) && strpos( $product_id, 'extended_support_' ) === 0 ) {
				// Extract actual product ID from extended support string
				$parts = explode( '_', $product_id );
				if ( count( $parts ) >= 3 ) {
					$actual_product_id = intval( $parts[2] );
					$license_type = $order['license_type_label'] ?: ( $order['license_type'] ?: 'Standard' );
					
					// Get license type configuration to determine months
					$months = 12; // Default Extended Support duration
					if ( ! empty( $order['license_type'] ) ) {
						$settings = get_option( 'vrstore_settings', [] );
						$custom_license_types = $settings['custom_license_types'] ?? [];
						foreach ( $custom_license_types as $type ) {
							if ( $type['slug'] === $order['license_type'] && ! empty( $type['expiry_days'] ) ) {
								$months = max( 1, round( $type['expiry_days'] / 30 ) );
								break;
							}
						}
					}
					
					// Get the actual product title to create better description
					$associated_product_title = '';
					if ($actual_product_id > 0) {
						$product_post = get_post($actual_product_id);
						if ($product_post && $product_post->post_title) {
							$associated_product_title = $product_post->post_title;
						}
					}
					
					if ($associated_product_title) {
						$product_title = sprintf( '%s - Extended Support (%s / %d months)', $associated_product_title, $license_type, $months );
					} else {
						$product_title = sprintf( 'Extended Support (%s / %d months)', $license_type, $months );
					}
				} else {
					$product_title = 'Extended Support';
				}
			} else {
				// Handle regular products
				$product_post = get_post( $product_id );
				if ( $product_post && $product_post->post_type === 'vrstore_product' ) {
					$product_title = $product_post->post_title;
				}
			}
			
			// Prepare download URL (if order is completed)
			$download_url = '';
			if ( 'completed' === strtolower( $order['payment_status'] ) && 'completed' === strtolower( $order['order_status'] ) ) {
				// Check if product has downloadable files
				$download_files = get_post_meta( $product_id, '_vrstore_product_files', true );
				if ( ! empty( $download_files ) && is_array( $download_files ) ) {
					// Apply file protection filter
					$filtered_files = apply_filters( 'vrstore_display_product_files', $download_files, $product_id, $user_id );
					
					// Only generate download URL if user has access to files (not just protected placeholders)
					$has_accessible_files = false;
					foreach ( $filtered_files as $file ) {
						if ( ! isset( $file['protected'] ) || ! $file['protected'] ) {
							$has_accessible_files = true;
							break;
						}
					}
					
					if ( $has_accessible_files ) {
						// Generate secure download URL using the new system
						$file_protection = VRSTORE_File_Protection::get_instance();
						$secure_token = $file_protection->generate_download_token($product_id, 0, $user_id);
						
						if ($secure_token) {
							$download_url = add_query_arg([
								'vrstore_secure_download' => $secure_token
							], home_url());
						}
					}
				}
			}
			
			// Get global currency setting for consistency
			$settings = null;
			if ( class_exists( 'VRSTORE_Settings' ) ) {
				$settings = VRSTORE_Settings::get_instance();
				$global_currency = $settings->get_setting( 'currency', 'USD' );
			} else {
				$global_currency = 'USD';
			}
			
			// Use order currency if available, otherwise fall back to global setting
			$currency_to_use = ! empty( $order['currency'] ) ? $order['currency'] : $global_currency;
			
			// Format the purchase data for the template
			$purchases[] = array(
				'order_id' => $order['order_number'] ? $order['order_number'] : $order['id'],
				'date' => $order['created_at'],
				'product_title' => $product_title,
				'product_id' => $product_id,
				'total' => floatval( $order['product_price'] ),
				'currency' => $currency_to_use,
				'status' => ucfirst( $order['payment_status'] ),
				'order_status' => ucfirst( $order['order_status'] ),
				'payment_status' => ucfirst( $order['payment_status'] ),
				'payment_method' => $order['payment_method'],
				'download_url' => $download_url,
				'license_key' => $order['license_key'] ?: ''
			);
		}

		return apply_filters( 'vrstore_user_purchases', $purchases, $user_id );
	}

	/**
	 * Get user licenses.
	 *
	 * @since 1.0.0
	 * @param int $user_id User ID.
	 * @return array User licenses.
	 */
	private function get_user_licenses( $user_id ) {
		$licenses = array();
		$processed_license_keys = array(); // To avoid duplicates
		
		// Get user email for matching licenses in database table
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return apply_filters( 'vrstore_user_licenses', $licenses, $user_id );
		}
		
		$user_email = $user->user_email;
		
		global $wpdb;
		$licenses_table = $wpdb->prefix . 'vrstore_licenses';
		$customers_table = $wpdb->prefix . 'vrstore_customers';
		
		// First, get customer ID by email
		$customer = null;
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$customers_table'" ) === $customers_table ) {
			$customer = $wpdb->get_row( $wpdb->prepare(
				"SELECT * FROM $customers_table WHERE email = %s",
				$user_email
			), ARRAY_A );
		}
		
		// Get licenses from database table using customer_id or customer_email
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$licenses_table'" ) === $licenses_table ) {
			$db_licenses = array();
			
			// If customer record exists, try customer_id first
			if ( $customer ) {
				$db_licenses = $wpdb->get_results( $wpdb->prepare(
					"SELECT * FROM $licenses_table 
					 WHERE customer_id = %d 
					   AND product_id NOT LIKE 'extended_support_%' 
					   AND product_id != '0' 
					   AND product_id IS NOT NULL 
					   AND product_id > 0 
					 ORDER BY created_at DESC",
					$customer['id']
				), ARRAY_A );
			}
			
			// If no licenses found by customer_id or no customer record, try customer_email
			if ( empty( $db_licenses ) ) {
				$db_licenses = $wpdb->get_results( $wpdb->prepare(
					"SELECT * FROM $licenses_table 
					 WHERE customer_email = %s 
					   AND product_id NOT LIKE 'extended_support_%' 
					   AND product_id != '0' 
					   AND product_id IS NOT NULL 
					   AND product_id > 0 
					 ORDER BY created_at DESC",
					$user_email
				), ARRAY_A );
			}
			
			// Extended Support orders no longer create virtual licenses
			// Extended Support is treated as a service, not a licensable product
			
			foreach ( $db_licenses as $db_license ) {
				$license_key = $db_license['license_key'];
				
				// Skip if we've already processed this license key
				if ( in_array( $license_key, $processed_license_keys ) ) {
					continue;
				}
				
				// Check if the license is associated with a paid order
				if ( ! empty( $db_license['order_id'] ) ) {
					$orders_table = $wpdb->prefix . 'vrstore_orders';
					if ( $wpdb->get_var( "SHOW TABLES LIKE '$orders_table'" ) === $orders_table ) {
						$order = $wpdb->get_row( $wpdb->prepare(
							"SELECT payment_status, order_status FROM $orders_table WHERE id = %d LIMIT 1",
							$db_license['order_id']
						), ARRAY_A );
						
						// Skip license if payment is still pending
						if ( $order && (
							strtolower( $order['payment_status'] ) === 'pending' ||
							strtolower( $order['order_status'] ) === 'pending'
						) ) {
							continue;
						}
					}
				}
				
				$processed_license_keys[] = $license_key;
				
				// Get product details
				$product_id = $db_license['product_id'];
				
				// Handle Extended Support products
				if ( is_string( $product_id ) && strpos( $product_id, 'extended_support_' ) === 0 ) {
					// Extract actual product ID from extended support string
					$parts = explode( '_', $product_id );
					if ( count( $parts ) >= 3 ) {
						$actual_product_id = intval( $parts[2] );
						$license_type = $db_license['license_type_slug'] ?: 'Standard';
						
						// Get license type configuration to determine months
						$months = 12; // Default Extended Support duration
						if ( ! empty( $db_license['license_type_slug'] ) ) {
							$settings = get_option( 'vrstore_settings', [] );
							$custom_license_types = $settings['custom_license_types'] ?? [];
							foreach ( $custom_license_types as $type ) {
								if ( $type['slug'] === $db_license['license_type_slug'] && ! empty( $type['expiry_days'] ) ) {
									$months = max( 1, round( $type['expiry_days'] / 30 ) );
									break;
								}
							}
						}
						
						$license_type_label = ucfirst( str_replace( '-', ' ', $license_type ) );
					// Get the actual product title to create better description
					$associated_product_title = '';
					if ($actual_product_id > 0) {
						$product_post = get_post($actual_product_id);
						if ($product_post && $product_post->post_title) {
							$associated_product_title = $product_post->post_title;
						}
					}
					
					if ($associated_product_title) {
						$product_title = sprintf( '%s - Extended Support (%s / %d months)', $associated_product_title, $license_type_label, $months );
					} else {
						$product_title = sprintf( 'Extended Support (%s / %d months)', $license_type_label, $months );
					}
					} else {
						$product_title = 'Extended Support';
					}
					// Extended Support products don't need license generation check
				} else {
					// Handle regular products
					$product_title = get_the_title( $product_id );
					
					// Skip products with disabled license generation
					$disable_license_generation = get_post_meta( $product_id, '_vrstore_disable_license_generation', true );
					if ( $disable_license_generation ) {
						continue;
					}
				}
				
				// Get real domain activations using the domain monitor (skip for Extended Support)
				$activations = array();
				if ( ! ( is_string( $product_id ) && strpos( $product_id, 'extended_support_' ) === 0 ) && class_exists( 'VRSTORE_Domain_Monitor' ) ) {
					$domain_monitor = VRSTORE_Domain_Monitor::get_instance();
					$domain_activations_data = $domain_monitor->get_license_domain_activations( $license_key, array(
						'status' => 'active',
						'per_page' => 100
					) );
					
					if ( ! empty( $domain_activations_data['activations'] ) ) {
						foreach ( $domain_activations_data['activations'] as $activation ) {
							$activations[] = array(
								'site' => $activation['domain'],
								'site_url' => $activation['domain'],
								'domain' => $activation['domain'],
								'date' => $activation['activated_at'],
								'activation_date' => $activation['activated_at'],
								'status' => $activation['status'],
								'ip' => $activation['activation_ip'] ?: '',
								'last_checked' => $activation['last_checked'] ?: '',
								'domain_accessible' => $activation['domain_accessible'] ?? null
							);
						}
					}
				}
				
			// Get license type slug, with fallback to order data if empty
			$license_type_slug = $db_license['license_type_slug'] ?: '';
			if ( empty( $license_type_slug ) && ! empty( $db_license['order_id'] ) ) {
				// Try to get license type from the associated order
				$orders_table = $wpdb->prefix . 'vrstore_orders';
				if ( $wpdb->get_var( "SHOW TABLES LIKE '$orders_table'" ) === $orders_table ) {
					$order = $wpdb->get_row( $wpdb->prepare(
						"SELECT license_type FROM $orders_table WHERE id = %d LIMIT 1",
						$db_license['order_id']
					), ARRAY_A );
					if ( $order && ! empty( $order['license_type'] ) ) {
						$license_type_slug = $order['license_type'];
					}
				}
			}
			
			// Prepare license data with license type slug
			$license_data = array(
				'id' => 'db_' . $db_license['id'], // Prefix to distinguish from post ID
				'license_key' => $license_key,
				'product_id' => $product_id,
				'product_title' => $product_title ?: $this->get_translated_text( 'Unknown Product' ),
				'status' => ucfirst( $db_license['status'] ?: 'active' ),
				'activation_limit' => intval( $db_license['activation_limit'] ?: 1 ),
				'activation_count' => count( $activations ), // Use actual count from domain activations
				'activations' => $activations,
				'license_type_slug' => $license_type_slug,
				'expiry_date' => $db_license['expires_at'] ?: '',
				'created_date' => $db_license['created_at'],
				'source' => 'database'
			);
				
				// Calculate proper expiry date based on license type configuration
				$license_data['expiry_date'] = $this->calculate_license_expiry_date( $license_data );
				
				$licenses[] = $license_data;
			}
		}
		
		// Legacy post-based license system has been removed
		// All licenses are now managed through the modern table-based system above

		return apply_filters( 'vrstore_user_licenses', $licenses, $user_id );
	}

	/**
	 * Get customer data by user ID or email.
	 *
	 * @since 1.0.0
	 * @param mixed $identifier User ID or email address.
	 * @return array|false Customer data or false if not found.
	 */
	private function get_customer_data( $identifier ) {
		$customer_data = array();
		
		// Determine if identifier is email or user ID
		if ( is_email( $identifier ) ) {
			$user = get_user_by( 'email', $identifier );
			$email = $identifier;
		} else {
			$user = get_userdata( intval( $identifier ) );
			$email = $user ? $user->user_email : '';
		}
		
		if ( ! $user && ! $email ) {
			return false;
		}
		
		// Build customer data array
		$customer_data = array(
			'user_id' => $user ? $user->ID : 0,
			'email' => $email,
			'first_name' => $user ? $user->first_name : '',
			'last_name' => $user ? $user->last_name : '',
			'display_name' => $user ? $user->display_name : '',
			'user_registered' => $user ? $user->user_registered : '',
			'is_wp_user' => (bool) $user
		);
		
		// Get additional customer data from orders if available
		global $wpdb;
		$orders_table = $wpdb->prefix . 'vrstore_orders';
		
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$orders_table'" ) === $orders_table ) {
			$latest_order = $wpdb->get_row( $wpdb->prepare(
				"SELECT * FROM $orders_table WHERE customer_email = %s ORDER BY created_at DESC LIMIT 1",
				$email
			), ARRAY_A );
			
			if ( $latest_order ) {
				$customer_data['customer_name'] = $latest_order['customer_name'];
				$customer_data['last_order_date'] = $latest_order['created_at'];
				$customer_data['total_orders'] = $wpdb->get_var( $wpdb->prepare(
					"SELECT COUNT(*) FROM $orders_table WHERE customer_email = %s",
					$email
				) );
				$customer_data['total_spent'] = $wpdb->get_var( $wpdb->prepare(
					"SELECT SUM(product_price) FROM $orders_table WHERE customer_email = %s AND payment_status = 'completed'",
					$email
				) );
			}
		}
		
		return $customer_data;
	}

	/**
	 * Match licenses to customer by email or user ID.
	 *
	 * @since 1.0.0
	 * @param mixed $identifier User ID or email address.
	 * @return array Array of matched licenses.
	 */
	private function match_customer_licenses( $identifier ) {
		$customer_data = $this->get_customer_data( $identifier );
		
		if ( ! $customer_data ) {
			return array();
		}
		
		// Use the user_id if available, otherwise fall back to email matching
		if ( $customer_data['user_id'] > 0 ) {
			return $this->get_user_licenses( $customer_data['user_id'] );
		} else {
			// For non-WordPress users, match by email from database only
			return $this->get_licenses_by_email( $customer_data['email'] );
		}
	}

	/**
	 * Get licenses by customer email (for non-WordPress users).
	 *
	 * @since 1.0.0
	 * @param string $email Customer email.
	 * @return array Array of licenses.
	 */
	private function get_licenses_by_email( $email ) {
		$licenses = array();
		
		global $wpdb;
		$licenses_table = $wpdb->prefix . 'vrstore_licenses';
		
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$licenses_table'" ) !== $licenses_table ) {
			return $licenses;
		}
		
		$db_licenses = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM $licenses_table WHERE customer_email = %s ORDER BY created_at DESC",
			$email
		), ARRAY_A );
		
		foreach ( $db_licenses as $db_license ) {
			$product_id = $db_license['product_id'];
			$product_title = get_the_title( $product_id );
			
			// Skip products with disabled license generation
			$disable_license_generation = get_post_meta( $product_id, '_vrstore_disable_license_generation', true );
			if ( $disable_license_generation ) {
				continue;
			}
			
			// Get activation data
			$activations_table = $wpdb->prefix . 'vrstore_license_activations';
			$activations = array();
			if ( $wpdb->get_var( "SHOW TABLES LIKE '$activations_table'" ) === $activations_table ) {
				$activation_records = $wpdb->get_results( $wpdb->prepare(
					"SELECT * FROM $activations_table WHERE license_id = %d ORDER BY activated_at DESC",
					$db_license['id']
				), ARRAY_A );
				
				foreach ( $activation_records as $activation ) {
					$activations[] = array(
						'site' => $activation['site_url'],
						'site_url' => $activation['site_url'],
						'date' => $activation['activated_at'],
						'activation_date' => $activation['activated_at'],
						'ip' => $activation['ip_address'] ?: ''
					);
				}
			}
			
			// Prepare license data with license type slug
			$license_data = array(
				'id' => 'email_' . $db_license['id'],
				'license_key' => $db_license['license_key'],
				'product_id' => $product_id,
				'product_title' => $product_title ?: __( 'Unknown Product', 'vira-store' ),
				'status' => ucfirst( $db_license['status'] ?: 'active' ),
				'activation_limit' => intval( $db_license['activation_limit'] ?: 1 ),
				'activation_count' => intval( $db_license['activation_count'] ?: 0 ),
				'activations' => $activations,
				'license_type_slug' => $db_license['license_type_slug'] ?: '',
				'expiry_date' => $db_license['expires_at'] ?: '',
				'created_date' => $db_license['created_at'],
				'source' => 'email_only'
			);
			
			// Calculate proper expiry date based on license type configuration
			$license_data['expiry_date'] = $this->calculate_license_expiry_date( $license_data );
			
			$licenses[] = $license_data;
		}
		
		return $licenses;
	}

	/**
	 * Calculate proper expiry date for a license based on its type configuration.
	 *
	 * @since 1.0.0
	 * @param array $license License data from database.
	 * @return string Properly calculated expiry date or original if no custom type.
	 */
	private function calculate_license_expiry_date( $license ) {
		// Get original expiry date from license
		$original_expiry = $license['expiry_date'] ?? $license['expires_at'] ?? '';
		
		// If no license type slug, return original expiry date
		if ( empty( $license['license_type_slug'] ) ) {
			return $original_expiry;
		}
		
		// Get custom license types from settings
		$settings = get_option( 'vrstore_settings', [] );
		$custom_license_types = $settings['custom_license_types'] ?? [];
		
		// Find the license type configuration
		foreach ( $custom_license_types as $type ) {
			if ( ( $type['slug'] ?? '' ) === $license['license_type_slug'] ) {
				// Check if this license type has specific expiry configuration
				if ( isset( $type['expiry_months'] ) && is_numeric( $type['expiry_months'] ) ) {
					$expiry_months = absint( $type['expiry_months'] );
					
					// If expiry_months is 0, it's a lifetime license
					if ( $expiry_months === 0 ) {
						return ''; // Empty string means lifetime/never expires
					}
					
					// Calculate expiry date from license creation date + expiry months
					$created_date = $license['created_date'] ?? $license['created_at'] ?? current_time( 'mysql' );
					return date( 'Y-m-d H:i:s', strtotime( $created_date . ' +' . $expiry_months . ' months' ) );
				} else {
					// License type found but no expiry configuration - return original expiry
					return $original_expiry;
				}
			}
		}
		
		// If no custom configuration found, return original expiry date
		return $original_expiry;
	}

	/**
	 * Get orders by customer email (for non-WordPress users).
	 *
	 * @since 1.0.0
	 * @param string $email Customer email.
	 * @return array Array of orders.
	 */
	private function get_orders_by_email( $email ) {
		$orders = array();
		
		global $wpdb;
		$orders_table = $wpdb->prefix . 'vrstore_orders';
		
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$orders_table'" ) !== $orders_table ) {
			return $orders;
		}
		
		$db_orders = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM $orders_table WHERE customer_email = %s ORDER BY created_at DESC",
			$email
		), ARRAY_A );
		
		foreach ( $db_orders as $order ) {
			$product_id = $order['product_id'];
			$product_title = $order['product_name'];
			$product_post = get_post( $product_id );
			if ( $product_post && $product_post->post_type === 'vrstore_product' ) {
				$product_title = $product_post->post_title;
			}
			
			// Prepare download URL (if order is completed)
			$download_url = '';
			if ( 'completed' === strtolower( $order['payment_status'] ) && 'completed' === strtolower( $order['order_status'] ) ) {
				$download_files = get_post_meta( $product_id, '_vrstore_product_files', true );
				if ( ! empty( $download_files ) && is_array( $download_files ) ) {
					// Generate secure download URL using the new system
					$file_protection = VRSTORE_File_Protection::get_instance();
					$user = get_user_by('email', $email);
					$user_id = $user ? $user->ID : 0;
					$secure_token = $file_protection->generate_download_token($product_id, 0, $user_id);
					
					if ($secure_token) {
						$download_url = add_query_arg([
							'vrstore_secure_download' => $secure_token
						], home_url());
					}
				}
			}
			
			$orders[] = array(
				'order_id' => $order['order_number'] ? $order['order_number'] : $order['id'],
				'date' => $order['created_at'],
				'product_title' => $product_title,
				'product_id' => $product_id,
				'total' => floatval( $order['product_price'] ),
				'currency' => $order['currency'] ?: 'USD',
				'status' => ucfirst( $order['payment_status'] ),
				'order_status' => ucfirst( $order['order_status'] ),
				'payment_status' => ucfirst( $order['payment_status'] ),
				'payment_method' => $order['payment_method'],
				'download_url' => $download_url,
				'license_key' => $order['license_key'] ?: ''
			);
		}
		
		return $orders;
	}

	/**
	 * Validate customer access to data.
	 *
	 * @since 1.0.0
	 * @param mixed $identifier User ID or email.
	 * @param string $data_type Type of data being accessed.
	 * @return bool True if access is allowed.
	 */
	private function validate_customer_access( $identifier, $data_type = 'general' ) {
		// If user is logged in, check if they own the data
		if ( is_user_logged_in() ) {
			$current_user_id = get_current_user_id();
			$current_user = get_userdata( $current_user_id );
			
			// Check if accessing own data
			if ( is_numeric( $identifier ) && intval( $identifier ) === $current_user_id ) {
				return true;
			}
			
			if ( is_email( $identifier ) && $identifier === $current_user->user_email ) {
				return true;
			}
		}
		
		// For non-logged-in users, additional validation might be needed
		// This could include session tokens, temporary access keys, etc.
		// For now, we'll be restrictive and only allow logged-in users
		
		return false;
	}

	/**
	 * Initialize AJAX handlers for customer area functionality.
	 *
	 * @since 1.0.0
	 */
	private function init_ajax_handlers() {
		// AJAX handlers for both logged-in and logged-out users
		add_action( 'wp_ajax_vrstore_activate_license', array( $this, 'ajax_activate_license' ) );
		add_action( 'wp_ajax_vrstore_deactivate_license', array( $this, 'ajax_deactivate_license' ) );
		add_action( 'wp_ajax_vrstore_copy_license_key', array( $this, 'ajax_copy_license_key' ) );
		add_action( 'wp_ajax_vrstore_refresh_account_data', array( $this, 'ajax_refresh_account_data' ) );
		
		// Enhanced domain management AJAX handlers (handled by Domain Monitor class)
		add_action( 'wp_ajax_vrstore_get_domain_activations', array( $this, 'ajax_get_domain_activations' ) );
		
        // Admin post handlers for form submissions
        add_action( 'admin_post_vrstore_update_account', array( $this, 'process_account_update' ) );
        
        // AJAX handlers for custom login/register/forgot password
        add_action( 'wp_ajax_nopriv_vrstore_custom_login', array( $this, 'ajax_custom_login' ) );
        add_action( 'wp_ajax_nopriv_vrstore_custom_register', array( $this, 'ajax_custom_register' ) );
        add_action( 'wp_ajax_nopriv_vrstore_forgot_password', array( $this, 'ajax_forgot_password' ) );
        add_action( 'wp_ajax_vrstore_forgot_password', array( $this, 'ajax_forgot_password' ) );
        add_action( 'wp_ajax_nopriv_vrstore_reset_password', array( $this, 'ajax_reset_password' ) );
        add_action( 'wp_ajax_vrstore_reset_password', array( $this, 'ajax_reset_password' ) );
        
        
        // AJAX handler for account updates (logged-in users only)
        add_action( 'wp_ajax_vrstore_update_account', array( $this, 'ajax_update_account' ) );
        
        // AJAX handler for customer profile updates (logged-in users only)
        add_action( 'wp_ajax_vrstore_update_customer_profile', array( $this, 'ajax_update_customer_profile' ) );
        
        // AJAX handler for getting product downloads (logged-in users only)
        add_action( 'wp_ajax_vrstore_get_product_downloads', array( $this, 'ajax_get_product_downloads' ) );
        
		// Frontend support ticket AJAX handlers for logged-in users
		add_action('wp_ajax_vrstore_create_support_ticket', array($this, 'ajax_create_support_ticket'));
		add_action('wp_ajax_vrstore_get_my_ticket_details', array($this, 'ajax_get_my_ticket_details'));
		add_action('wp_ajax_vrstore_add_customer_ticket_reply', array($this, 'ajax_add_customer_ticket_reply'));
		add_action('wp_ajax_vrstore_check_ticket_lock_status', array($this, 'ajax_check_ticket_lock_status'));
		
		// Extended Support AJAX handlers for logged-in users
        add_action('wp_ajax_vrstore_get_extended_support_pricing', array($this, 'ajax_get_extended_support_pricing'));
        add_action('wp_ajax_vrstore_purchase_extended_support', array($this, 'ajax_purchase_extended_support'));
        
        // Handle Extended Support parameter on any page
        add_action('wp', array($this, 'handle_extended_support_global'));
        
        // Note: Cart-related AJAX handlers are now handled by VRSTORE_Cart class
        // to ensure proper redirect functionality and avoid conflicts
	}
	
	

	/**
	 * AJAX handler for license activation.
	 *
	 * @since 1.0.0
	 */
	public function ajax_activate_license() {
		// Verify nonce
		if ( ! wp_verify_nonce( $_POST['nonce'], 'vrstore_frontend_nonce' ) ) {
			wp_die( $this->get_translated_text( 'Security check failed.' ) );
		}

		// Check if user is logged in
		if ( ! is_user_logged_in() ) {
			wp_send_json_error( array(
				'message' => esc_html__( 'Please log in to activate licenses.', 'vira-store' )
			) );
		}

		// Get license data
		$license_key = sanitize_text_field( $_POST['license_key'] ?? '' );
		$domain = sanitize_text_field( $_POST['domain'] ?? '' );
		$product_id = absint( $_POST['product_id'] ?? 0 );

		if ( empty( $license_key ) ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'License key is required.' )
			) );
		}

		if ( empty( $domain ) ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'Domain is required.' )
			) );
		}

		// Get license class instance
		if ( class_exists( 'VRSTORE_License' ) ) {
			$license_class = VRSTORE_License::get_instance();
			$activation_result = $license_class->activate_license( $license_key, $product_id, $domain );

			if ( is_wp_error( $activation_result ) ) {
				wp_send_json_error( array(
					'message' => $activation_result->get_error_message()
				) );
			} else {
				wp_send_json_success( array(
					'message' => esc_html__( 'License activated successfully!', 'vira-store' ),
					'status' => esc_html__( 'Active', 'vira-store' )
				) );
			}
		} else {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'License system is not available.' )
			) );
		}
	}

	/**
	 * AJAX handler for license deactivation.
	 *
	 * @since 1.0.0
	 */
	public function ajax_deactivate_license() {
		// Verify nonce
		if ( ! wp_verify_nonce( $_POST['nonce'], 'vrstore_frontend_nonce' ) ) {
			wp_die( $this->get_translated_text( 'Security check failed.' ) );
		}

		// Check if user is logged in
		if ( ! is_user_logged_in() ) {
			wp_send_json_error( array(
				'message' => esc_html__( 'Please log in to deactivate licenses.', 'vira-store' )
			) );
		}

		// Get license data
		$license_key = sanitize_text_field( $_POST['license_key'] ?? '' );
		$domain = sanitize_text_field( $_POST['domain'] ?? '' );
		$product_id = absint( $_POST['product_id'] ?? 0 );

		if ( empty( $license_key ) ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'License key is required.' )
			) );
		}

		if ( empty( $domain ) ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'Domain is required.' )
			) );
		}

		// Get license class instance
		if ( class_exists( 'VRSTORE_License' ) ) {
			$license_class = VRSTORE_License::get_instance();
			$deactivation_result = $license_class->deactivate_license( $license_key, $product_id, $domain );

			if ( is_wp_error( $deactivation_result ) ) {
				wp_send_json_error( array(
					'message' => $deactivation_result->get_error_message()
				) );
			} else {
				wp_send_json_success( array(
					'message' => $this->get_translated_text( 'License deactivated successfully!' ),
					'status' => $this->get_translated_text( 'Inactive' )
				) );
			}
		} else {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'License system is not available.' )
			) );
		}
	}

	/**
	 * AJAX handler for copying license key.
	 *
	 * @since 1.0.0
	 */
	public function ajax_copy_license_key() {
		// This is mainly handled client-side, but we can log the action
		wp_send_json_success( array(
			'message' => $this->get_translated_text( 'License key copied to clipboard.' )
		) );
	}

	/**
	 * AJAX handler for refreshing account data.
	 *
	 * @since 1.0.0
	 */
	public function ajax_refresh_account_data() {
		// Verify nonce
		if ( ! wp_verify_nonce( $_POST['nonce'], 'vrstore_frontend_nonce' ) ) {
			wp_die( $this->get_translated_text( 'Security check failed.' ) );
		}

		// Check if user is logged in
		if ( ! is_user_logged_in() ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'Please log in to refresh account data.' )
			) );
		}

		$user_id = get_current_user_id();
		$data_type = sanitize_text_field( $_POST['data_type'] ?? 'all' );

		$response_data = array();

		if ( 'purchases' === $data_type || 'all' === $data_type ) {
			$purchases = $this->get_user_purchases( $user_id );
			$response_data['purchases'] = $purchases;
		}

		if ( 'licenses' === $data_type || 'all' === $data_type ) {
			$licenses = $this->get_user_licenses( $user_id );
			$response_data['licenses'] = $licenses;
		}

		wp_send_json_success( array(
			'message' => $this->get_translated_text( 'Account data refreshed successfully.' ),
			'data' => $response_data
		) );
	}

	/**
	 * AJAX handler for getting domain activations for a license.
	 *
	 * @since 1.0.0
	 */
	public function ajax_get_domain_activations() {
		// Verify nonce
		if ( ! wp_verify_nonce( $_POST['nonce'], 'vrstore_frontend_nonce' ) ) {
			wp_die( $this->get_translated_text( 'Security check failed.' ) );
		}

		// Check if user is logged in
		if ( ! is_user_logged_in() ) {
			wp_send_json_error( array(
				'message' => esc_html__( 'Please log in to view domain activations.', 'vira-store' )
			) );
		}

		$license_key = sanitize_text_field( $_POST['license_key'] ?? '' );
		$user_id = get_current_user_id();
		$user = get_userdata( $user_id );

		if ( empty( $license_key ) ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'License key is required.' )
			) );
		}

		// Verify user owns this license
		if ( ! $this->verify_license_ownership( $license_key, $user->user_email ) ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'Access denied. License not found or does not belong to your account.' )
			) );
		}

		// Get domain activations from domain monitor
		if ( class_exists( 'VRSTORE_Domain_Monitor' ) ) {
			$domain_monitor = VRSTORE_Domain_Monitor::get_instance();
			$activations = $domain_monitor->get_license_domain_activations( $license_key );
			
			// Get license details for activation limits
			$license_data = $this->get_license_data_by_key( $license_key );
			
			wp_send_json_success( array(
				'activations' => $activations,
				'license_data' => $license_data,
				'activation_limit' => intval( $license_data['activation_limit'] ?? 1 ),
				'current_count' => count( $activations )
			) );
		} else {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'Domain monitoring system is not available.' )
			) );
		}
	}

	/**
	 * AJAX handler for activating a domain.
	 *
	 * @since 1.0.0
	 */
	public function ajax_activate_domain() {
		// Verify nonce
		if ( ! wp_verify_nonce( $_POST['nonce'], 'vrstore_frontend_nonce' ) ) {
			wp_die( esc_html__( 'Security check failed.', 'vira-store' ) );
		}

		// Check if user is logged in
		if ( ! is_user_logged_in() ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'Please log in to activate domains.' )
			) );
		}

		$license_key = sanitize_text_field( $_POST['license_key'] ?? '' );
		$domain = sanitize_text_field( $_POST['domain'] ?? '' );
		$product_id = absint( $_POST['product_id'] ?? 0 );
		$user_id = get_current_user_id();
		$user = get_userdata( $user_id );

		if ( empty( $license_key ) ) {
			wp_send_json_error( array(
				'message' => esc_html__( 'License key is required.', 'vira-store' )
			) );
		}

		if ( empty( $domain ) ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'Domain is required.' )
			) );
		}

		// Verify user owns this license
		if ( ! $this->verify_license_ownership( $license_key, $user->user_email ) ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'Access denied. License not found or does not belong to your account.' )
			) );
		}

		// Validate domain format
		if ( ! $this->validate_domain_format( $domain ) ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'Invalid domain format. Please enter a valid domain (e.g., example.com).' )
			) );
		}

		// Check activation limits
		$license_data = $this->get_license_data_by_key( $license_key );
		if ( ! $this->check_activation_limit( $license_key, $license_data ) ) {
			wp_send_json_error( array(
				'message' => sprintf(
					$this->get_translated_text( 'Activation limit reached. This license allows maximum %d activations.' ),
					intval( $license_data['activation_limit'] ?? 1 )
				)
			) );
		}

		// Attempt activation using License class
		if ( class_exists( 'VRSTORE_License' ) ) {
			$license_class = VRSTORE_License::get_instance();
			$activation_result = $license_class->activate_license( $license_key, $product_id, $domain );

			if ( is_wp_error( $activation_result ) ) {
				wp_send_json_error( array(
					'message' => $activation_result->get_error_message()
				) );
			} else {
				wp_send_json_success( array(
					'message' => $this->get_translated_text( 'Domain activated successfully!' ),
					'domain' => $domain,
					'status' => 'active'
				) );
			}
		} else {
			wp_send_json_error( array(
				'message' => esc_html__( 'License system is not available.', 'vira-store' )
			) );
		}
	}

	/**
	 * AJAX handler for deactivating a domain.
	 *
	 * @since 1.0.0
	 */
	public function ajax_deactivate_domain() {
		// Verify nonce
		if ( ! wp_verify_nonce( $_POST['nonce'], 'vrstore_frontend_nonce' ) ) {
			wp_die( esc_html__( 'Security check failed.', 'vira-store' ) );
		}

		// Check if user is logged in
		if ( ! is_user_logged_in() ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'Please log in to deactivate domains.' )
			) );
		}

		$license_key = sanitize_text_field( $_POST['license_key'] ?? '' );
		$domain = sanitize_text_field( $_POST['domain'] ?? '' );
		$product_id = absint( $_POST['product_id'] ?? 0 );
		$user_id = get_current_user_id();
		$user = get_userdata( $user_id );

		if ( empty( $license_key ) ) {
			wp_send_json_error( array(
				'message' => esc_html__( 'License key is required.', 'vira-store' )
			) );
		}

		if ( empty( $domain ) ) {
			wp_send_json_error( array(
				'message' => esc_html__( 'Domain is required.', 'vira-store' )
			) );
		}

		// Verify user owns this license
		if ( ! $this->verify_license_ownership( $license_key, $user->user_email ) ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'Access denied. License not found or does not belong to your account.' )
			) );
		}

		// Attempt deactivation using License class
		if ( class_exists( 'VRSTORE_License' ) ) {
			$license_class = VRSTORE_License::get_instance();
			$deactivation_result = $license_class->deactivate_license( $license_key, $product_id, $domain );

			if ( is_wp_error( $deactivation_result ) ) {
				wp_send_json_error( array(
					'message' => $deactivation_result->get_error_message()
				) );
			} else {
				wp_send_json_success( array(
					'message' => $this->get_translated_text( 'Domain deactivated successfully!' ),
					'domain' => $domain,
					'status' => 'inactive'
				) );
			}
		} else {
			wp_send_json_error( array(
				'message' => esc_html__( 'License system is not available.', 'vira-store' )
			) );
		}
	}





	/**
	 * AJAX handler for getting detailed license information.
	 *
	 * @since 1.0.0
	 */
	public function ajax_get_license_details() {
		// Verify nonce
		if ( ! wp_verify_nonce( $_POST['nonce'], 'vrstore_frontend_nonce' ) ) {
			wp_die( esc_html__( 'Security check failed.', 'vira-store' ) );
		}

		// Check if user is logged in
		if ( ! is_user_logged_in() ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'Please log in to view license details.' )
			) );
		}

		$license_key = sanitize_text_field( $_POST['license_key'] ?? '' );
		$user_id = get_current_user_id();
		$user = get_userdata( $user_id );

		if ( empty( $license_key ) ) {
			wp_send_json_error( array(
				'message' => esc_html__( 'License key is required.', 'vira-store' )
			) );
		}

		// Verify user owns this license
		if ( ! $this->verify_license_ownership( $license_key, $user->user_email ) ) {
			wp_send_json_error( array(
				'message' => esc_html__( 'Access denied. License not found or does not belong to your account.', 'vira-store' )
			) );
		}

		// Get license data
		$license_data = $this->get_license_data_by_key( $license_key );
		if ( ! $license_data ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'License not found.' )
			) );
		}

		// Get domain activations
		$domain_activations = array();
		if ( class_exists( 'VRSTORE_Domain_Monitor' ) ) {
			$domain_monitor = VRSTORE_Domain_Monitor::get_instance();
			$domain_activations = $domain_monitor->get_license_domain_activations( $license_key );
		}

		// Get license type information
		$license_type_info = $this->get_license_type_info_for_display( $license_data['license_type_slug'] ?? '' );

		wp_send_json_success( array(
			'license_data' => $license_data,
			'domain_activations' => $domain_activations,
			'license_type_info' => $license_type_info,
			'activation_limit' => intval( $license_data['activation_limit'] ?? 1 ),
			'current_activations' => count( $domain_activations ),
			'can_activate_more' => $this->check_activation_limit( $license_key, $license_data )
		) );
	}

	/**
	 * Verify that a license key belongs to the specified email address.
	 *
	 * @since 1.0.0
	 * @param string $license_key License key to verify.
	 * @param string $customer_email Customer email to verify against.
	 * @return bool True if license belongs to customer.
	 */
	private function verify_license_ownership( $license_key, $customer_email ) {
		global $wpdb;
		$licenses_table = $wpdb->prefix . 'vrstore_licenses';
		
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$licenses_table'" ) !== $licenses_table ) {
			return false;
		}
		
		// First try to find license by license key and customer email
		$license = $wpdb->get_row( $wpdb->prepare(
			"SELECT id, customer_email, customer_id FROM $licenses_table WHERE license_key = %s AND customer_email = %s",
			$license_key,
			$customer_email
		), ARRAY_A );
		
		// If not found by email, try to update license with current user's customer_id if applicable
		if ( ! $license && is_user_logged_in() ) {
			$user_id = get_current_user_id();
			$license_by_key = $wpdb->get_row( $wpdb->prepare(
				"SELECT id, customer_email, customer_id FROM $licenses_table WHERE license_key = %s",
				$license_key
			), ARRAY_A );
			
			if ( $license_by_key && $license_by_key['customer_email'] === $customer_email && empty( $license_by_key['customer_id'] ) ) {
				// Update the license with the current user's customer_id for future lookups
				$wpdb->update(
					$licenses_table,
					[ 'customer_id' => $user_id ],
					[ 'id' => $license_by_key['id'] ],
					[ '%d' ],
					[ '%d' ]
				);
				$license = $license_by_key;
			}
		}
		
		return ! empty( $license );
	}

	/**
	 * Get license data by license key.
	 *
	 * @since 1.0.0
	 * @param string $license_key License key to look up.
	 * @return array|false License data or false if not found.
	 */
	private function get_license_data_by_key( $license_key ) {
		global $wpdb;
		$licenses_table = $wpdb->prefix . 'vrstore_licenses';
		
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$licenses_table'" ) !== $licenses_table ) {
			return false;
		}
		
		$license = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM $licenses_table WHERE license_key = %s",
			$license_key
		), ARRAY_A );
		
		return $license ?: false;
	}

	/**
	 * Validate domain format.
	 *
	 * @since 1.0.0
	 * @param string $domain Domain to validate.
	 * @return bool True if domain format is valid.
	 */
	private function validate_domain_format( $domain ) {
		// Remove protocol if present
		$domain = preg_replace( '/^https?:\/\//i', '', $domain );
		// Remove trailing slash
		$domain = rtrim( $domain, '/' );
		// Remove www prefix for validation
		$domain = preg_replace( '/^www\./i', '', $domain );
		
		// Basic domain validation
		return filter_var( $domain, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME ) !== false;
	}

	/**
	 * Check if license can accommodate more activations.
	 *
	 * @since 1.0.0
	 * @param string $license_key License key to check.
	 * @param array $license_data License data (optional, will fetch if not provided).
	 * @return bool True if more activations are allowed.
	 */
	private function check_activation_limit( $license_key, $license_data = null ) {
		if ( ! $license_data ) {
			$license_data = $this->get_license_data_by_key( $license_key );
			if ( ! $license_data ) {
				return false;
			}
		}
		
		$activation_limit = intval( $license_data['activation_limit'] ?? 1 );
		
		// Unlimited activations (0 or negative limit)
		if ( $activation_limit <= 0 ) {
			return true;
		}
		
		// Get current activation count from domain activations
		if ( class_exists( 'VRSTORE_Domain_Monitor' ) ) {
			$domain_monitor = VRSTORE_Domain_Monitor::get_instance();
			$current_activations = $domain_monitor->get_license_domain_activations( $license_key );
			$current_count = count( $current_activations );
			
			return $current_count < $activation_limit;
		}
		
		return false;
	}

	/**
	 * Get license type information for display.
	 *
	 * @since 1.0.0
	 * @param string $license_type_slug License type slug.
	 * @return array License type information with label and color.
	 */
	private function get_license_type_info_for_display( $license_type_slug ) {
		if ( empty( $license_type_slug ) ) {
			return array(
				'slug' => 'custom',
				'label' => 'Custom License',
				'color' => '#0073aa'
			);
		}
		
		// Get custom license types from settings
		$settings = get_option( 'vrstore_settings', [] );
		$custom_license_types = $settings['custom_license_types'] ?? [];
		
		// Default info
		$type_info = array(
			'slug' => $license_type_slug,
			'label' => ucfirst( str_replace( '_', ' ', $license_type_slug ) ),
			'color' => $this->generate_license_type_color( $license_type_slug )
		);
		
		// Find custom configuration
		foreach ( $custom_license_types as $type ) {
			if ( ( $type['slug'] ?? '' ) === $license_type_slug ) {
				$type_info['label'] = $type['label'] ?? $type_info['label'];
				$type_info['color'] = $type['color'] ?? $type_info['color'];
				break;
			}
		}
		
		return $type_info;
	}

	/**
	 * Generate a consistent color for license type.
	 *
	 * @since 1.0.0
	 * @param string $license_type_slug License type slug.
	 * @return string Hex color code.
	 */
	private function generate_license_type_color( $license_type_slug ) {
		// Predefined colors for common license types
		$predefined_colors = array(
			'basic' => '#28a745',      // Green
			'premium' => '#dc3545',    // Red
			'enterprise' => '#6f42c1', // Purple
			'pro' => '#fd7e14',        // Orange
			'business' => '#20c997',   // Teal
			'personal' => '#6c757d',   // Gray
			'developer' => '#e83e8c',  // Pink
			'lifetime' => '#ffc107'    // Yellow
		);
		
		$slug_lower = strtolower( $license_type_slug );
		
		// Return predefined color if available
		if ( isset( $predefined_colors[$slug_lower] ) ) {
			return $predefined_colors[$slug_lower];
		}
		
		// Generate color from slug hash
		$hash = md5( $license_type_slug );
		$r = hexdec( substr( $hash, 0, 2 ) );
		$g = hexdec( substr( $hash, 2, 2 ) );
		$b = hexdec( substr( $hash, 4, 2 ) );
		
		// Ensure good contrast by adjusting brightness
		$brightness = ( $r * 299 + $g * 587 + $b * 114 ) / 1000;
		if ( $brightness > 150 ) {
			$r = max( 0, $r - 50 );
			$g = max( 0, $g - 50 );
			$b = max( 0, $b - 50 );
		}
		
		return sprintf( '#%02x%02x%02x', $r, $g, $b );
	}
	
	/**
	 * Process account update form submission.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function process_account_update() {
		// Verify nonce
		if ( ! isset( $_POST['vrstore_update_account_nonce'] ) || ! wp_verify_nonce( $_POST['vrstore_update_account_nonce'], 'vrstore_update_account_nonce' ) ) {
			wp_die( esc_html__( 'Security check failed.', 'vira-store' ) );
		}

		// Check if user is logged in
		if ( ! is_user_logged_in() ) {
			wp_die( esc_html__( 'You must be logged in to update your account.', 'vira-store' ) );
		}

		$user_id = get_current_user_id();
		$account_page_id = get_option( 'vrstore_account_page' );
		$account_page = get_permalink( $account_page_id );
		
		// Fallback if account page is not set or invalid
		if ( ! $account_page || ! $account_page_id || get_post_status( $account_page_id ) !== 'publish' ) {
			// Try to find the current page (referrer)
			$account_page = wp_get_referer();
			
			// If no referrer, fallback to home page
			if ( ! $account_page ) {
				$account_page = home_url();
			}
		}

		// Sanitize input data
		$first_name = isset( $_POST['vrstore_first_name'] ) ? sanitize_text_field( $_POST['vrstore_first_name'] ) : '';
		$last_name = isset( $_POST['vrstore_last_name'] ) ? sanitize_text_field( $_POST['vrstore_last_name'] ) : '';
		$display_name = isset( $_POST['vrstore_display_name'] ) ? sanitize_text_field( $_POST['vrstore_display_name'] ) : '';
		$email = isset( $_POST['vrstore_email'] ) ? sanitize_email( $_POST['vrstore_email'] ) : '';
		$company = isset( $_POST['vrstore_company'] ) ? sanitize_text_field( $_POST['vrstore_company'] ) : '';
		$phone = isset( $_POST['vrstore_phone'] ) ? sanitize_text_field( $_POST['vrstore_phone'] ) : '';
		$current_password = isset( $_POST['vrstore_current_password'] ) ? $_POST['vrstore_current_password'] : '';
		$new_password = isset( $_POST['vrstore_new_password'] ) ? $_POST['vrstore_new_password'] : '';
		$confirm_password = isset( $_POST['vrstore_confirm_password'] ) ? $_POST['vrstore_confirm_password'] : '';

		// Validate required fields
		if ( empty( $first_name ) ) {
			wp_die( esc_html__( 'First name is required.', 'vira-store' ) );
		}
		
		if ( empty( $last_name ) ) {
			wp_die( esc_html__( 'Last name is required.', 'vira-store' ) );
		}
		
		if ( empty( $display_name ) ) {
			wp_die( esc_html__( 'Display name is required.', 'vira-store' ) );
		}
		
		// Validate email
		if ( empty( $email ) || ! is_email( $email ) ) {
			wp_die( esc_html__( 'Please enter a valid email address.', 'vira-store' ) );
		}
		
		// Validate phone number format if provided
		if ( ! empty( $phone ) ) {
			// Remove all non-numeric characters for validation
			$phone_numbers_only = preg_replace( '/[^0-9]/', '', $phone );
			if ( strlen( $phone_numbers_only ) < 7 || strlen( $phone_numbers_only ) > 15 ) {
				wp_die( esc_html__( 'Please enter a valid phone number.', 'vira-store' ) );
			}
		}

		// Check if email is already in use by another user
		$user_data = get_userdata( $user_id );
		if ( $email !== $user_data->user_email ) {
			$existing_user = get_user_by( 'email', $email );
			if ( $existing_user && $existing_user->ID !== $user_id ) {
				wp_die( esc_html__( 'This email address is already in use.', 'vira-store' ) );
			}
		}

		// Prepare user data for update
		$user_args = array(
			'ID' => $user_id,
			'first_name' => $first_name,
			'last_name' => $last_name,
			'display_name' => $display_name,
			'user_email' => $email
		);

		// Handle password change if requested
		if ( ! empty( $new_password ) ) {
			// Verify current password
			if ( empty( $current_password ) || ! wp_check_password( $current_password, $user_data->user_pass, $user_id ) ) {
				wp_die( $this->get_translated_text( 'Current password is incorrect.' ) );
			}

			// Validate password strength
			if ( strlen( $new_password ) < 6 ) {
				wp_die( $this->get_translated_text( 'Password must be at least 6 characters long.' ) );
			}
			
			// Validate password confirmation
			if ( $new_password !== $confirm_password ) {
				wp_die( $this->get_translated_text( 'Password confirmation does not match.' ) );
			}

			$user_args['user_pass'] = $new_password;
		}

		// Update user data
		$result = wp_update_user( $user_args );

		if ( is_wp_error( $result ) ) {
			wp_die( $result->get_error_message() );
		}
		
		// Update user meta fields
		update_user_meta( $user_id, 'vrstore_company', $company );
		update_user_meta( $user_id, 'vrstore_phone', $phone );
		
		// Redirect back to account page with success message
		$redirect_url = add_query_arg( 'account_updated', 'true', $account_page );
		wp_safe_redirect( $redirect_url );
		exit;
	}

	/**
	 * Handle custom login via AJAX - optimized for performance.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function ajax_custom_login() {
		// Set time limit for login request
		set_time_limit(30);
		
		// Log login attempt start
		error_log('ViraStore: AJAX login request started at ' . date('Y-m-d H:i:s'));
		
		// Quick check if user is already logged in
		if ( is_user_logged_in() ) {
			error_log('ViraStore: User already logged in, returning success');
			wp_send_json_success( array(
				'message' => $this->get_translated_text( 'You are already logged in.' ),
				'redirect_url' => home_url()
			) );
			return;
		}
		
		// Streamlined nonce verification - try most common first
		$nonce_valid = false;
		if ( isset( $_POST['nonce'] ) && !empty( $_POST['nonce'] ) ) {
			$nonce = $_POST['nonce'];
			// Try most likely nonce first
			if ( wp_verify_nonce( $nonce, 'vrstore_login' ) ) {
				$nonce_valid = true;
			} elseif ( wp_verify_nonce( $nonce, 'vrstore_custom_auth' ) ) {
				$nonce_valid = true;
			} elseif ( wp_verify_nonce( $nonce, 'vrstore_frontend_nonce' ) ) {
				$nonce_valid = true;
			}
		}
		
		if ( ! $nonce_valid ) {
			error_log('ViraStore: Login nonce verification failed');
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'Security check failed. Please refresh the page and try again.' )
			) );
			return;
		}
		
		// Get form data with faster sanitization
		$username = trim( sanitize_text_field( $_POST['username'] ?? '' ) );
		$password = $_POST['password'] ?? '';
		$remember = isset( $_POST['remember'] ) && ( $_POST['remember'] === 'true' || $_POST['remember'] === true );
		
		// Quick validation
		if ( empty( $username ) || empty( $password ) ) {
			error_log('ViraStore: Login failed - empty username or password');
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'Please enter both username and password.' )
			) );
			return;
		}
		
		// Check login attempt limits
		if ( class_exists( 'VRSTORE_Login_Attempts' ) ) {
			$login_attempts = VRSTORE_Login_Attempts::get_instance();
			$attempt_check = $login_attempts->is_login_allowed( $username );
			
			if ( ! $attempt_check['allowed'] ) {
				error_log('ViraStore: Login blocked due to too many attempts for: ' . $username);
				wp_send_json_error( array(
					'message' => $attempt_check['message']
				) );
				return;
			}
		}
		
		// Skip math captcha check for performance unless explicitly required
		// Only check if math_captcha field is actually submitted
		if ( isset( $_POST['math_captcha'] ) && isset( $_POST['math_answer'] ) ) {
			$math_captcha = intval( $_POST['math_captcha'] );
			$math_answer = intval( $_POST['math_answer'] );
			
			if ( $math_captcha !== $math_answer ) {
				error_log('ViraStore: Login failed - math captcha incorrect');
				wp_send_json_error( array(
					'message' => $this->get_translated_text( 'Incorrect answer to the math question. Please try again.' )
				) );
				return;
			}
		}
		
		// Minimal session cleanup - only clear auth cookie
		wp_clear_auth_cookie();
		
		// Attempt authentication with minimal credentials array
		$credentials = array(
			'user_login'    => $username,
			'user_password' => $password,
			'remember'      => $remember
		);
		
		error_log('ViraStore: Attempting wp_signon for user: ' . $username);
		$user = wp_signon( $credentials, false ); // Don't use SSL check for speed
		
		if ( is_wp_error( $user ) ) {
			// Record failed login attempt
			if ( class_exists( 'VRSTORE_Login_Attempts' ) ) {
				$login_attempts = VRSTORE_Login_Attempts::get_instance();
				$login_attempts->record_failed_login_attempt( $username );
			}
			
			// Simple error handling
			$error_code = $user->get_error_code();
			error_log('ViraStore: Login failed - ' . $error_code . ': ' . $user->get_error_message());
			
			$error_message = $this->get_translated_text( 'Invalid username or password. Please try again.' );
			
			wp_send_json_error( array(
				'message' => $error_message
			) );
			return;
		}
		
		// Login successful - clear any failed attempts and set user quickly
		if ( class_exists( 'VRSTORE_Login_Attempts' ) ) {
			$login_attempts = VRSTORE_Login_Attempts::get_instance();
			$login_attempts->clear_user_attempts( $user->user_login, $user );
		}
		
		wp_set_current_user( $user->ID );
		wp_set_auth_cookie( $user->ID, $remember, false ); // Skip SSL check for speed
		
		// Minimal session cleanup
		if ( session_status() === PHP_SESSION_ACTIVE ) {
			unset( $_SESSION['vrstore_checkout_in_progress'] );
			unset( $_SESSION['vrstore_checkout_completed'] );
		}
		
	error_log('ViraStore: Login successful for user ID: ' . $user->ID);
	
	// Get the account page URL for redirect
	$account_page_url = $this->get_account_page_url();
	if ( ! $account_page_url ) {
		$account_page_url = home_url();
	}
	
	wp_send_json_success( array(
		'message' => $this->get_translated_text( 'Login successful! Redirecting...' ),
		'user_id' => $user->ID,
		'redirect_url' => $account_page_url
	) );
	}
	
	/**
	 * Handle custom registration via AJAX.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function ajax_custom_register() {
		// Check if registration is enabled
		if ( ! get_option( 'users_can_register' ) ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'User registration is currently not allowed.' )
			) );
		}
		
		// Verify nonce
		if ( ! wp_verify_nonce( $_POST['nonce'], 'vrstore_custom_auth' ) ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'Security check failed.' )
			) );
		}
		
		// Get form data
		$username = sanitize_text_field( $_POST['username'] ?? '' );
		$email = sanitize_email( $_POST['email'] ?? '' );
		$password = $_POST['password'] ?? '';
		$math_captcha = intval( $_POST['math_captcha'] ?? 0 );
		$math_answer = intval( $_POST['math_answer'] ?? 0 );
		
		// Validate inputs
		if ( empty( $username ) || empty( $email ) || empty( $password ) ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'Please fill in all required fields.' )
			) );
		}
		
		// Validate math captcha if enabled
		$settings = VRSTORE_Settings::get_instance();
		$is_captcha_enabled = $settings->get_setting( 'enable_math_captcha', 'on' ) === 'on';
		
		if ( $is_captcha_enabled && $math_captcha !== $math_answer ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'Incorrect answer to the math question. Please try again.' )
			) );
		}
		
	if ( ! is_email( $email ) ) {
		wp_send_json_error( array(
			'message' => $this->get_translated_text( 'Please enter a valid email address.' )
		) );
	}
	
	// Check for disposable email addresses
	if ( class_exists( 'VRSTORE_Disposable_Email_Detector' ) ) {
		$disposable_detector = VRSTORE_Disposable_Email_Detector::get_instance();
		if ( $disposable_detector->is_blocking_enabled() && $disposable_detector->is_disposable_email( $email ) ) {
			wp_send_json_error( array(
				'message' => $disposable_detector->get_block_message()
			) );
		}
	}
	
	if ( strlen( $password ) < 6 ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'Password must be at least 6 characters long.' )
			) );
		}
		
		// Check if username already exists
		if ( username_exists( $username ) ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'Username already exists. Please choose a different username.' )
			) );
		}
		
		// Check if email already exists
		if ( email_exists( $email ) ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'Email address is already registered. Please use a different email.' )
			) );
		}
		
		// Create user
		$user_id = wp_create_user( $username, $password, $email );
		
		if ( is_wp_error( $user_id ) ) {
			wp_send_json_error( array(
				'message' => $user_id->get_error_message()
			) );
		}
		
	// Add customer role
	$user = new WP_User( $user_id );
	$user->add_role( 'customer' );
	
	// Send email confirmation if enabled
	if ( class_exists( 'VRSTORE_Email_Confirmation' ) ) {
		$email_confirmation = VRSTORE_Email_Confirmation::get_instance();
		if ( $email_confirmation->is_confirmation_enabled() ) {
			$email_confirmation->send_confirmation_email( $user_id, 'registration' );
		}
	}
	
	// Auto-login the user after registration
	wp_set_current_user( $user_id );
	wp_set_auth_cookie( $user_id, true );
		
		// Get proper redirect URL
		$redirect_url = $this->get_account_page_url();
		if ( ! $redirect_url ) {
			$redirect_url = home_url();
		}
		
		wp_send_json_success( array(
			'message' => $this->get_translated_text( 'Registration successful! You are now logged in.' ),
			'redirect_url' => $redirect_url
		) );
	}
	
	/**
	 * Get count of pending orders for a user.
	 *
	 * @since 1.0.0
	 * @param int $user_id User ID.
	 * @return int Number of pending orders.
	 */


	/**
	 * Get pending orders for a user.
	 *
	 * @since 1.0.0
	 * @param int $user_id User ID.
	 * @return array Array of pending orders.
	 */
	private function get_pending_orders( $user_id ) {
		global $wpdb;
		
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return array();
		}
		
		$orders_table = $wpdb->prefix . 'vrstore_orders';
		
		// Check if table exists
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$orders_table'" ) !== $orders_table ) {
			return array();
		}
		
		// Get pending orders for this user's email
		$pending_orders = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM $orders_table 
			 WHERE customer_email = %s 
			 AND (payment_status = 'pending' OR order_status = 'pending')
			 ORDER BY created_at DESC",
			$user->user_email
		), ARRAY_A );
		
		return $pending_orders ?: array();
	}

	/**
	 * Get the account page URL.
	 *
	 * @since 1.0.0
	 * @return string|false Account page URL or false if not found.
	 */
	private function get_account_page_url() {
		// Get the account page ID from settings
		if ( class_exists( 'VRSTORE_Settings' ) ) {
			$settings = VRSTORE_Settings::get_instance();
			$account_page_id = $settings->get_setting( 'account_page' );
			
			if ( $account_page_id && get_post_status( $account_page_id ) === 'publish' ) {
				return get_permalink( $account_page_id );
			}
		}
		
		// Fallback: Look for a page with the vrstore_account shortcode
		global $wpdb;
		$page = $wpdb->get_row( $wpdb->prepare(
			"SELECT ID FROM {$wpdb->posts} WHERE post_content LIKE %s AND post_status = 'publish' AND post_type = 'page' LIMIT 1",
			'%[vrstore_account%'
		) );
		
		if ( $page ) {
			return get_permalink( $page->ID );
		}
		
		return false;
	}
	
	/**
	 * Handle account update via AJAX.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function ajax_update_account() {
		// Check if user is logged in
		if ( ! is_user_logged_in() ) {
			wp_send_json_error( array(
				'message' => esc_html__( 'You must be logged in to update your account.', 'vira-store' )
			) );
		}
		
		// Verify nonce
		if ( ! wp_verify_nonce( $_POST['nonce'], 'vrstore_update_account_nonce' ) ) {
			wp_send_json_error( array(
				'message' => esc_html__( 'Security check failed.', 'vira-store' )
			) );
		}
		
		$user_id = get_current_user_id();
		
		// Sanitize input data
		$first_name = sanitize_text_field( $_POST['first_name'] ?? '' );
		$last_name = sanitize_text_field( $_POST['last_name'] ?? '' );
		$display_name = sanitize_text_field( $_POST['display_name'] ?? '' );
		$email = sanitize_email( $_POST['email'] ?? '' );
		$company = sanitize_text_field( $_POST['company'] ?? '' );
		$phone = sanitize_text_field( $_POST['phone'] ?? '' );
		$current_password = $_POST['current_password'] ?? '';
		$new_password = $_POST['new_password'] ?? '';
		$confirm_password = $_POST['confirm_password'] ?? '';
		
		// Validate email
		if ( empty( $email ) || ! is_email( $email ) ) {
			wp_send_json_error( array(
				'message' => esc_html__( 'Please enter a valid email address.', 'vira-store' )
			) );
		}
		
		// Check if email is already in use by another user
		$user_data = get_userdata( $user_id );
		if ( $email !== $user_data->user_email ) {
			$existing_user = get_user_by( 'email', $email );
			if ( $existing_user && $existing_user->ID !== $user_id ) {
				wp_send_json_error( array(
					'message' => esc_html__( 'This email address is already in use.', 'vira-store' )
				) );
			}
		}
		
		// Prepare user data for update
		$user_args = array(
			'ID' => $user_id,
			'first_name' => $first_name,
			'last_name' => $last_name,
			'display_name' => $display_name,
			'user_email' => $email
		);
		
		// Handle password change if requested
		if ( ! empty( $new_password ) ) {
			// Verify current password
			if ( empty( $current_password ) || ! wp_check_password( $current_password, $user_data->user_pass, $user_id ) ) {
				wp_send_json_error( array(
					'message' => esc_html__( 'Current password is incorrect.', 'vira-store' )
				) );
			}
			
			// Validate password confirmation
			if ( $new_password !== $confirm_password ) {
				wp_send_json_error( array(
					'message' => esc_html__( 'New password and confirmation password do not match.', 'vira-store' )
				) );
			}
			
			// Validate password strength
			if ( strlen( $new_password ) < 6 ) {
				wp_send_json_error( array(
					'message' => esc_html__( 'Password must be at least 6 characters long.', 'vira-store' )
				) );
			}
			
			$user_args['user_pass'] = $new_password;
		}
		
		// Update user data
		$result = wp_update_user( $user_args );
		
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array(
				'message' => $result->get_error_message()
			) );
		}
		
		// Update company and phone user meta
		update_user_meta( $user_id, 'vrstore_company', $company );
		update_user_meta( $user_id, 'vrstore_phone', $phone );
		
		wp_send_json_success( array(
			'message' => esc_html__( 'Account updated successfully!', 'vira-store' )
		) );
	}

	/**
	 * AJAX handler for customer profile updates
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function ajax_update_customer_profile() {
		// Check if user is logged in
		if ( ! is_user_logged_in() ) {
			error_log('ViraStore: Profile update failed - user not logged in');
			wp_send_json_error( array(
				'message' => esc_html__( 'You must be logged in to update your profile.', 'vira-store' )
			) );
		}
		
		// Verify nonce
		if ( ! wp_verify_nonce( $_POST['vrstore_profile_nonce'], 'vrstore_edit_profile' ) ) {
			error_log('ViraStore: Profile update failed - nonce verification failed');
			wp_send_json_error( array(
				'message' => esc_html__( 'Security check failed.', 'vira-store' )
			) );
		}
		
		$user_id = get_current_user_id();
		// Sanitize input data
		$first_name = sanitize_text_field( $_POST['first_name'] ?? '' );
		$last_name = sanitize_text_field( $_POST['last_name'] ?? '' );
		$display_name = sanitize_text_field( $_POST['display_name'] ?? '' );
		$email = sanitize_email( $_POST['user_email'] ?? '' );
		$phone = sanitize_text_field( $_POST['billing_phone'] ?? '' );
		$city = sanitize_text_field( $_POST['billing_city'] ?? '' );
		
		// Validate email
		if ( empty( $email ) || ! is_email( $email ) ) {
			error_log('ViraStore: Profile update failed - invalid email: ' . $email);
			wp_send_json_error( array(
				'message' => esc_html__( 'Please enter a valid email address.', 'vira-store' )
			) );
		}
		
		// Check if email is already in use by another user
		$user_data = get_userdata( $user_id );
		if ( $email !== $user_data->user_email ) {
			$existing_user = get_user_by( 'email', $email );
			if ( $existing_user && $existing_user->ID !== $user_id ) {
				error_log('ViraStore: Profile update failed - email already in use: ' . $email);
				wp_send_json_error( array(
					'message' => esc_html__( 'This email address is already in use.', 'vira-store' )
				) );
			}
		}
		
		// Prepare user data for update
		$user_args = array(
			'ID' => $user_id,
			'first_name' => $first_name,
			'last_name' => $last_name,
			'display_name' => $display_name,
			'user_email' => $email
		);
		
		// Update user data
		$result = wp_update_user( $user_args );
		
		if ( is_wp_error( $result ) ) {
			error_log('ViraStore: Profile update failed - wp_update_user error: ' . $result->get_error_message());
			wp_send_json_error( array(
				'message' => $result->get_error_message()
			) );
		}
		
		// Update phone and city user meta (using billing fields for consistency with admin)
		update_user_meta( $user_id, 'billing_phone', $phone );
		update_user_meta( $user_id, 'billing_city', $city );
		
		error_log('ViraStore: Profile update successful for user ID: ' . $user_id);
		wp_send_json_success( array(
			'message' => esc_html__( 'Profile updated successfully!', 'vira-store' )
		) );
	}



	/**
	 * Render custom login/register interface for non-logged-in users.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private function render_login_register_interface() {
		// Get site logo URL
		$custom_logo_id = get_theme_mod( 'custom_logo' );
		$logo_url = '';
		if ( $custom_logo_id ) {
			$logo_url = wp_get_attachment_image_url( $custom_logo_id, 'medium' );
		}

		// If no custom logo, try to get site icon
		if ( empty( $logo_url ) ) {
			$site_icon_id = get_option( 'site_icon' );
			if ( $site_icon_id ) {
				$logo_url = wp_get_attachment_image_url( $site_icon_id, 'medium' );
			}
		}

		// Fallback text if no logo available
		$site_name = get_bloginfo( 'name' );
		$login_url = wp_login_url( get_permalink() );
		$register_url = wp_registration_url();
		$is_registration_enabled = get_option( 'users_can_register' );
		
		// Check if Google login is enabled
		$google_login_enabled = false;
		if ( class_exists( 'VRSTORE_Settings' ) ) {
			try {
				$settings = VRSTORE_Settings::get_instance();
				$google_login_enabled = $settings->get_setting( 'enable_google_login', '' ) === 'on';
			} catch ( Exception $e ) {
				// Settings not available, default to false
			}
		}
		
		// Check for URL parameters to show messages or switch forms
		$action = sanitize_text_field( $_GET['action'] ?? '' );
		$show_registration = $action === 'register';
		$show_forgot_password = $action === 'forgot-password';
		$show_reset_password = $action === 'reset-password';
		$registration_success = isset( $_GET['registration'] ) && $_GET['registration'] === 'success';
		$logged_out = isset( $_GET['logged_out'] ) && $_GET['logged_out'] === 'true';
		$login_error = isset( $_GET['login_error'] ) ? sanitize_text_field( $_GET['login_error'] ) : '';
		$reset_token = sanitize_text_field( $_GET['token'] ?? '' );
		
		// Output the login/register interface
		?>
		<div class="vrstore-auth-container">
			<div class="vrstore-auth-box">
				<!-- Site Logo/Brand -->
				<div class="vrstore-auth-brand">
					<?php if ( $logo_url ) : ?>
						<img src="<?php echo esc_url( $logo_url ); ?>" alt="<?php echo esc_attr( $site_name ); ?>" class="vrstore-auth-logo" />
					<?php else : ?>
						<h2 class="vrstore-auth-title"><?php echo esc_html( $site_name ); ?></h2>
					<?php endif; ?>
				</div>

				<!-- Success/Error Messages -->
				<?php if ( $registration_success ) : ?>
					<div class="vrstore-auth-message vrstore-message vrstore-message-success">
						<span><?php esc_html_e( 'Registration successful! You can now sign in with your new account.', 'vira-store' ); ?></span>
						<button type="button" class="vrstore-message-close" aria-label="<?php esc_attr_e( 'Close', 'vira-store' ); ?>">&times;</button>
					</div>
				<?php endif; ?>
				
				<?php if ( $logged_out ) : ?>
					<div class="vrstore-auth-message vrstore-message vrstore-message-info">
						<span><?php esc_html_e( 'You have been logged out successfully.', 'vira-store' ); ?></span>
						<button type="button" class="vrstore-message-close" aria-label="<?php esc_attr_e( 'Close', 'vira-store' ); ?>">&times;</button>
					</div>
				<?php endif; ?>
				
				<?php if ( $login_error ) : ?>
					<div class="vrstore-auth-message vrstore-message vrstore-message-error">
						<span><?php echo esc_html( urldecode( $login_error ) ); ?></span>
						<button type="button" class="vrstore-message-close" aria-label="<?php esc_attr_e( 'Close', 'vira-store' ); ?>">&times;</button>
					</div>
				<?php endif; ?>

				<!-- Google Login -->
				<?php if ( $google_login_enabled ) : ?>
					<?php 
					// Get Google OAuth settings
					$google_client_id = $settings ? $settings->get_setting( 'google_client_id', '' ) : '';
					$google_client_secret = $settings ? $settings->get_setting( 'google_client_secret', '' ) : '';
					$google_redirect_uri = $settings ? $settings->get_setting( 'google_redirect_uri', home_url('/') . '?vrstore_google_callback=1' ) : home_url('/') . '?vrstore_google_callback=1';
					
					if ( ! empty( $google_client_id ) && ! empty( $google_client_secret ) ) :
					?>
					<div class="vrstore-google-login-container">
						<div class="vrstore-google-login-header">
							<h3><?php echo esc_html( $this->get_translated_text( 'Sign in with Google' ) ); ?></h3>
							<p><?php echo esc_html( $this->get_translated_text( 'Use your Google account to sign in quickly and securely.' ) ); ?></p>
						</div>
						
						<div class="vrstore-google-login-button-container">
							<button type="button" id="vrstore-google-login-btn" class="vrstore-google-login-btn" 
								data-client-id="<?php echo esc_attr( $google_client_id ); ?>"
								data-redirect-uri="<?php echo esc_attr( $google_redirect_uri ); ?>">
								<svg class="vrstore-google-icon" width="18" height="18" viewBox="0 0 18 18">
									<path fill="#4285F4" d="M18 9.2c0-.6-.1-1.3-.1-1.9H9.2v3.6h5c-.2 1.1-.9 2.1-1.9 2.8v2.3h3.1c1.8-1.7 2.8-4.1 2.8-7z"/>
									<path fill="#34A853" d="M9.2 18c2.6 0 4.7-.9 6.3-2.4l-3.1-2.3c-.9.6-2 1-3.2 1-2.5 0-4.6-1.7-5.3-4h-3.2v2.4C2.8 15.8 5.7 18 9.2 18z"/>
									<path fill="#FBBC04" d="M3.9 10.7c-.2-.6-.3-1.2-.3-1.8s.1-1.2.3-1.8V4.7H.7C.2 6 0 7.6 0 9.2s.2 3.2.7 4.5l3.2-2.5z"/>
									<path fill="#EA4335" d="M9.2 3.6c1.4 0 2.7.5 3.7 1.4l2.8-2.8C14.1.5 11.9 0 9.2 0 5.7 0 2.8 2.2 1.7 5.3l3.2 2.5c.7-2.3 2.8-4 5.3-4z"/>
								</svg>
								<span><?php echo esc_html( $this->get_translated_text( 'Continue with Google' ) ); ?></span>
							</button>
						</div>
						
						<div class="vrstore-divider">
							<span><?php echo esc_html( $this->get_translated_text( 'or' ) ); ?></span>
						</div>
						
						<div class="vrstore-traditional-login-toggle">
							<p><a href="#" id="vrstore-show-traditional-login"><?php echo esc_html( $this->get_translated_text( 'Use email and password instead' ) ); ?></a></p>
						</div>
					</div>
					
					<!-- Traditional login forms (initially hidden) -->
					<div id="vrstore-traditional-login-forms" style="display: none;">
					<?php else : ?>
					<div class="vrstore-google-login-error">
						<p><?php echo esc_html( $this->get_translated_text( 'Google login is enabled but not properly configured. Please contact your administrator.' ) ); ?></p>
						<p><small><?php echo esc_html( $this->get_translated_text( 'Missing Google Client ID or Client Secret.' ) ); ?></small></p>
					</div>
					<div id="vrstore-traditional-login-forms">
					<?php endif; ?>
				<?php else : ?>
					<!-- Tab Navigation -->
					<?php if ( ! $show_reset_password ) : ?>
					<div class="vrstore-auth-tabs">
					<button type="button" class="vrstore-auth-tab <?php echo ! $show_registration && ! $show_forgot_password ? 'active' : ''; ?>" data-tab="signin">
						<?php echo esc_html( $this->get_translated_text( 'Sign in' ) ); ?>
					</button>
					<?php if ( $is_registration_enabled ) : ?>
						<button type="button" class="vrstore-auth-tab <?php echo $show_registration ? 'active' : ''; ?>" data-tab="signup">
							<?php echo esc_html( $this->get_translated_text( 'Sign up' ) ); ?>
						</button>
					<?php endif; ?>
				</div>
				<?php endif; ?>

				<!-- Sign In Form -->
				<div id="vrstore-signin-form" class="vrstore-auth-form <?php echo ! $show_registration && ! $show_forgot_password ? 'active' : ''; ?>">
					<form id="vrstore-login-form" method="post">
						<div class="vrstore-form-group">
							<label for="vrstore_username"><?php echo esc_html( $this->get_translated_text( 'Username or Email' ) ); ?></label>
							<input type="text" name="username" id="vrstore_username" class="vrstore-form-control" required />
						</div>

						<div class="vrstore-form-group">
							<label for="vrstore_password"><?php echo esc_html( $this->get_translated_text( 'Password' ) ); ?></label>
							<input type="password" name="password" id="vrstore_password" class="vrstore-form-control" required />
						</div>

						<div class="vrstore-form-group vrstore-checkbox-group">
							<label class="vrstore-checkbox-label">
								<input type="checkbox" name="remember" value="true" />
								<span class="vrstore-checkmark"></span>
								<?php echo esc_html( $this->get_translated_text( 'Remember Me' ) ); ?>
							</label>
						</div>

						<?php
					// Generate math captcha for login
					$login_captcha = $this->generate_math_captcha();
					if ( ! empty( $login_captcha['question'] ) ) :
					?>
					<div class="vrstore-form-group">
						<label for="vrstore_math_captcha"><?php echo esc_html( $this->get_translated_text( 'What is' ) ); ?> <?php echo esc_html( $login_captcha['html'] ); ?>?</label>
						<input type="number" name="math_captcha" id="vrstore_math_captcha" class="vrstore-form-control" required />
						<input type="hidden" name="math_answer" value="<?php echo esc_attr( $login_captcha['answer'] ); ?>" />
					</div>
					<?php endif; ?>

						<button type="submit" class="vrstore-auth-submit">
							<?php echo esc_html( $this->get_translated_text( 'Sign In' ) ); ?>
						</button>

						<input type="hidden" name="redirect_to" value="<?php echo esc_url( isset( $_GET['redirect_to'] ) ? $_GET['redirect_to'] : get_permalink() ); ?>" />
						<input type="hidden" name="nonce" value="<?php echo wp_create_nonce( 'vrstore_custom_auth' ); ?>" />
					</form>

					<div class="vrstore-auth-links">
						<a href="#" class="vrstore-forgot-password vrstore-auth-link" data-tab="forgot-password">
							<?php echo esc_html( $this->get_translated_text( 'Forgot Password?' ) ); ?>
						</a>
					</div>
				</div>

				<?php if ( $is_registration_enabled ) : ?>
					<!-- Sign Up Form -->
					<div id="vrstore-signup-form" class="vrstore-auth-form <?php echo $show_registration ? 'active' : ''; ?>">
						<form id="vrstore-register-form" method="post">
							<div class="vrstore-form-group">
								<label for="vrstore_reg_username"><?php echo esc_html( $this->get_translated_text( 'Username' ) ); ?></label>
								<input type="text" name="username" id="vrstore_reg_username" class="vrstore-form-control" required />
							</div>

							<div class="vrstore-form-group">
								<label for="vrstore_reg_email"><?php echo esc_html( $this->get_translated_text( 'Email Address' ) ); ?></label>
								<input type="email" name="email" id="vrstore_reg_email" class="vrstore-form-control" required />
							</div>

							<div class="vrstore-form-group">
								<label for="vrstore_reg_password"><?php echo esc_html( $this->get_translated_text( 'Password' ) ); ?></label>
								<input type="password" name="password" id="vrstore_reg_password" class="vrstore-form-control" required />
								<small class="vrstore-form-hint"><?php echo esc_html( $this->get_translated_text( 'Minimum 6 characters' ) ); ?></small>
							</div>

							<div class="vrstore-form-group">
								<label for="vrstore_reg_password_confirm"><?php echo esc_html( $this->get_translated_text( 'Confirm Password' ) ); ?></label>
								<input type="password" name="password_confirm" id="vrstore_reg_password_confirm" class="vrstore-form-control" required />
							</div>



						<?php
					// Generate math captcha for registration
					$reg_captcha = $this->generate_math_captcha();
					if ( ! empty( $reg_captcha['question'] ) ) :
					?>
					<div class="vrstore-form-group">
						<label for="vrstore_reg_math_captcha"><?php echo esc_html( $this->get_translated_text( 'What is' ) ); ?> <?php echo esc_html( $reg_captcha['html'] ); ?>?</label>
						<input type="number" name="math_captcha" id="vrstore_reg_math_captcha" class="vrstore-form-control" required />
						<input type="hidden" name="math_answer" value="<?php echo esc_attr( $reg_captcha['answer'] ); ?>" />
					</div>
					<?php endif; ?>

							<button type="submit" class="vrstore-auth-submit">
								<?php echo esc_html( $this->get_translated_text( 'Sign up' ) ); ?>
							</button>

							<input type="hidden" name="nonce" value="<?php echo wp_create_nonce( 'vrstore_custom_auth' ); ?>" />
						</form>

						<div class="vrstore-auth-links">
							<p class="vrstore-terms-notice">
								<?php echo esc_html( $this->get_translated_text( 'By creating an account, you agree to our Terms of Service and Privacy Policy.' ) ); ?>
							</p>
						</div>
					</div>
				<?php endif; ?>

				<!-- Forgot Password Form -->
				<div id="vrstore-forgot-password-form" class="vrstore-auth-form <?php echo $show_forgot_password ? 'active' : ''; ?>">
					<?php if ( isset( $_GET['reset'] ) && $_GET['reset'] === 'sent' ) : ?>
						<div class="vrstore-auth-message vrstore-message vrstore-message-success">
							<span><?php echo esc_html( $this->get_translated_text( 'Password reset email has been sent. Please check your inbox and follow the instructions.' ) ); ?></span>
							<button type="button" class="vrstore-message-close" aria-label="<?php esc_attr_e( 'Close', 'vira-store' ); ?>">&times;</button>
						</div>
					<?php endif; ?>
					
					<form id="vrstore-forgot-password-form-element" method="post">
						<div class="vrstore-form-group">
							<label for="vrstore_reset_email"><?php echo esc_html( $this->get_translated_text( 'Email Address' ) ); ?></label>
							<input type="email" name="email" id="vrstore_reset_email" class="vrstore-form-control" required />
							<small class="vrstore-form-hint"><?php echo esc_html( $this->get_translated_text( 'Enter your email address to receive a password reset link.' ) ); ?></small>
						</div>

						<?php
						// Generate math captcha for forgot password
						$forgot_captcha = $this->generate_math_captcha();
						if ( ! empty( $forgot_captcha['question'] ) ) :
						?>
						<div class="vrstore-form-group">
							<label for="vrstore_forgot_math_captcha"><?php echo esc_html( $this->get_translated_text( 'What is' ) ); ?> <?php echo esc_html( $forgot_captcha['html'] ); ?>?</label>
							<input type="number" name="math_captcha" id="vrstore_forgot_math_captcha" class="vrstore-form-control" required />
							<input type="hidden" name="math_answer" value="<?php echo esc_attr( $forgot_captcha['answer'] ); ?>" />
						</div>
						<?php endif; ?>

						<button type="submit" class="vrstore-auth-submit">
							<?php echo esc_html( $this->get_translated_text( 'Send Reset Link' ) ); ?>
						</button>

						<input type="hidden" name="action" value="vrstore_forgot_password" />
						<input type="hidden" name="nonce" value="<?php echo wp_create_nonce( 'vrstore_forgot_password_nonce' ); ?>" />
					</form>

					<div class="vrstore-auth-links">
						<a href="<?php echo esc_url( get_permalink() ); ?>" class="vrstore-back-to-signin">
							<?php echo esc_html( $this->get_translated_text( 'Back to Sign In' ) ); ?>
						</a>
					</div>
				</div>

				<!-- Password Reset Form -->
				<?php if ( $show_reset_password && ! empty( $reset_token ) ) : ?>
					<?php $reset_result = $this->validate_reset_token( $reset_token ); ?>
					<div id="vrstore-reset-password-form" class="vrstore-auth-form active">
						<?php if ( $reset_result['valid'] ) : ?>
							<h3><?php echo esc_html( $this->get_translated_text( 'Set New Password' ) ); ?></h3>
							<form id="vrstore-reset-password-form-element" method="post">
								<div class="vrstore-form-group">
									<label for="vrstore_new_password"><?php echo esc_html( $this->get_translated_text( 'New Password' ) ); ?></label>
									<input type="password" name="new_password" id="vrstore_new_password" class="vrstore-form-control" required minlength="6" />
									<small class="vrstore-form-hint"><?php echo esc_html( $this->get_translated_text( 'Minimum 6 characters' ) ); ?></small>
								</div>

								<div class="vrstore-form-group">
									<label for="vrstore_confirm_password"><?php echo esc_html( $this->get_translated_text( 'Confirm New Password' ) ); ?></label>
									<input type="password" name="confirm_password" id="vrstore_confirm_password" class="vrstore-form-control" required minlength="6" />
								</div>

								<button type="submit" class="vrstore-auth-submit">
									<?php echo esc_html( $this->get_translated_text( 'Reset Password' ) ); ?>
								</button>

								<input type="hidden" name="token" value="<?php echo esc_attr( $reset_token ); ?>" />
								<input type="hidden" name="action" value="vrstore_reset_password" />
								<input type="hidden" name="nonce" value="<?php echo wp_create_nonce( 'vrstore_reset_password_nonce' ); ?>" />
							</form>
						<?php else : ?>
							<div class="vrstore-auth-message vrstore-message vrstore-message-error">
								<span><?php echo esc_html( $reset_result['message'] ); ?></span>
							</div>
							<div class="vrstore-auth-links">
								<a href="<?php echo esc_url( add_query_arg( 'action', 'forgot-password', get_permalink() ) ); ?>" class="vrstore-request-new-link">
									<?php echo esc_html( $this->get_translated_text( 'Request New Reset Link' ) ); ?>
								</a>
							</div>
						<?php endif; ?>
					</div>
				<?php endif; ?>
				</div> <!-- End traditional login forms -->
			<?php endif; ?> <!-- End Google login conditional -->
			</div>
		</div>
		<?php
	}

	/**
	 * Clean up login-related session data that might interfere with authentication
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private function cleanup_login_session() {
		// Clean up session data using session manager
		if (class_exists('VRSTORE_Session_Manager')) {
			$session_manager = VRSTORE_Session_Manager::get_instance_if_needed();
			if ($session_manager) {
				$session_manager->set_session_data('vrstore_checkout_in_progress', null);
				$session_manager->set_session_data('vrstore_login_attempts', null);
				$session_manager->set_session_data('vrstore_login_redirect', null);
			}
		} elseif ( session_status() === PHP_SESSION_ACTIVE ) {
			// Fallback to direct session access
			// Remove any stale checkout session data
			if ( isset( $_SESSION['vrstore_checkout_in_progress'] ) ) {
				unset( $_SESSION['vrstore_checkout_in_progress'] );
			}
			
			// Clear old login attempt data
			if ( isset( $_SESSION['vrstore_login_attempts'] ) ) {
				unset( $_SESSION['vrstore_login_attempts'] );
			}
			
			// Clear any redirect conflicts
			if ( isset( $_SESSION['vrstore_login_redirect'] ) ) {
				unset( $_SESSION['vrstore_login_redirect'] );
			}
		}
	}
	
	/**
	 * Enhance search query to search in product content and meta fields
	 *
	 * @since 1.0.0
	 * @param string $search Search SQL
	 * @param WP_Query $wp_query Query object
	 * @return string Enhanced search SQL
	 */
	public function enhance_search_query( $search, $wp_query ) {
		global $wpdb;
		
		// Only enhance for our product search
		if ( empty( $search ) || ! $wp_query->is_search() || $wp_query->get( 'post_type' ) !== 'vrstore_product' ) {
			return $search;
		}
		
		$search_term = $wp_query->get( 's' );
		if ( empty( $search_term ) ) {
			return $search;
		}
		
		$search_term = $wpdb->esc_like( $search_term );
		$search_term_like = '%' . $search_term . '%';
		
		// Enhanced search: title, content, excerpt, and specific meta fields
		$search = $wpdb->prepare(
			" AND (({$wpdb->posts}.post_title LIKE %s)",
			$search_term_like
		);
		$search .= $wpdb->prepare(
			" OR ({$wpdb->posts}.post_content LIKE %s)",
			$search_term_like
		);
		$search .= $wpdb->prepare(
			" OR ({$wpdb->posts}.post_excerpt LIKE %s)",
			$search_term_like
		);
		
		// Search in product meta fields
		$search .= $wpdb->prepare(
			" OR EXISTS (
				SELECT 1 FROM {$wpdb->postmeta} 
				WHERE {$wpdb->postmeta}.post_id = {$wpdb->posts}.ID 
				AND {$wpdb->postmeta}.meta_key IN ('_vrstore_product_short_description', '_vrstore_product_features') 
				AND {$wpdb->postmeta}.meta_value LIKE %s
			)",
			$search_term_like
		);
		
		$search .= ") ";
		
		return $search;
	}

	/**
	 * Initialize Google OAuth handlers.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private function init_google_oauth_handlers() {
		// Handle Google OAuth callback
		add_action( 'init', array( $this, 'handle_google_oauth_callback' ) );
		
		// AJAX handlers for Google login
		add_action( 'wp_ajax_vrstore_google_auth', array( $this, 'ajax_google_auth' ) );
		add_action( 'wp_ajax_nopriv_vrstore_google_auth', array( $this, 'ajax_google_auth' ) );
	}

	/**
	 * Handle Google OAuth callback.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function handle_google_oauth_callback() {
		// Check if this is a Google OAuth callback
		if ( ! isset( $_GET['vrstore_google_callback'] ) ) {
			return;
		}
		
		// Check for authorization code
		if ( ! isset( $_GET['code'] ) ) {
			// Handle error case
			$error = isset( $_GET['error'] ) ? sanitize_text_field( $_GET['error'] ) : 'unknown_error';
			$error_description = isset( $_GET['error_description'] ) ? sanitize_text_field( $_GET['error_description'] ) : 'Unknown error occurred';
			
			// Log the error for debugging
			error_log( 'ViraStore Google Login: OAuth error received. Error: ' . $error . ', Description: ' . $error_description );
			
			// Provide user-friendly error messages for common issues
			if ( $error === 'access_denied' ) {
				$error_description = 'You cancelled the Google login. Please try again if you want to continue.';
			} elseif ( $error === 'invalid_request' ) {
				$error_description = 'Invalid request. Please check your Google OAuth configuration.';
			} elseif ( $error === 'redirect_uri_mismatch' ) {
				$error_description = 'Redirect URI mismatch. Please ensure the redirect URI in your Google Cloud Console matches: ' . home_url('/') . '?vrstore_google_callback=1';
			}
			
			// Redirect to account page with error (or checkout page if coming from checkout)
			$redirect_url = $this->get_account_page_url();
			if ( ! empty( $_GET['state'] ) ) {
				$decoded_state = json_decode( base64_decode( $_GET['state'] ), true );
				if ( isset( $decoded_state['redirect_url'] ) ) {
					$redirect_url = esc_url_raw( $decoded_state['redirect_url'] );
				}
			}
			
			if ( $redirect_url ) {
				wp_redirect( add_query_arg( array(
					'login_error' => urlencode( 'Google login failed: ' . $error_description )
				), $redirect_url ) );
				exit;
			}
			return;
		}
		
		$auth_code = sanitize_text_field( $_GET['code'] );
		$state = isset( $_GET['state'] ) ? sanitize_text_field( $_GET['state'] ) : '';
		
		// Validate auth code
		if ( empty( $auth_code ) ) {
			error_log( 'ViraStore Google Login: Empty authorization code received' );
			$account_page_url = $this->get_account_page_url();
			if ( $account_page_url ) {
				wp_redirect( add_query_arg( array(
					'login_error' => urlencode( 'Google login failed: Invalid authorization code' )
				), $account_page_url ) );
				exit;
			}
			return;
		}
		
		// Get Google OAuth settings
		$settings = null;
		if ( class_exists( 'VRSTORE_Settings' ) ) {
			try {
				$settings = VRSTORE_Settings::get_instance();
			} catch ( Exception $e ) {
				error_log( 'ViraStore Google Login: Failed to get settings instance. Error: ' . $e->getMessage() );
			}
		}
		
		if ( ! $settings ) {
			error_log( 'ViraStore Google Login: Settings instance not available' );
			$account_page_url = $this->get_account_page_url();
			if ( $account_page_url ) {
				wp_redirect( add_query_arg( array(
					'login_error' => urlencode( 'Google login failed: Configuration error' )
				), $account_page_url ) );
				exit;
			}
			return;
		}
		
		$google_client_id = $settings->get_setting( 'google_client_id', '' );
		$google_client_secret = $settings->get_setting( 'google_client_secret', '' );
		$google_redirect_uri = $settings->get_setting( 'google_redirect_uri', home_url('/') . '?vrstore_google_callback=1' );
		
		if ( empty( $google_client_id ) || empty( $google_client_secret ) ) {
			error_log( 'ViraStore Google Login: Missing Google OAuth credentials. Client ID: ' . ( ! empty( $google_client_id ) ? 'Set' : 'Empty' ) . ', Client Secret: ' . ( ! empty( $google_client_secret ) ? 'Set' : 'Empty' ) );
			$account_page_url = $this->get_account_page_url();
			if ( $account_page_url ) {
				wp_redirect( add_query_arg( array(
					'login_error' => urlencode( 'Google login failed: OAuth credentials not configured. Please contact the administrator.' )
				), $account_page_url ) );
				exit;
			}
			return;
		}
		
		// Normalize redirect URI - ensure it matches what Google expects
		// Google is very strict about redirect URIs - they must match exactly
		$actual_redirect_uri = home_url('/') . '?vrstore_google_callback=1';
		
		// Normalize both URIs for comparison (remove trailing slashes, ensure consistent encoding)
		$normalized_settings_uri = rtrim( $google_redirect_uri, '/' );
		$normalized_actual_uri = rtrim( $actual_redirect_uri, '/' );
		
		// Parse and compare URLs to handle different formats
		$settings_url_parts = parse_url( $normalized_settings_uri );
		$actual_url_parts = parse_url( $normalized_actual_uri );
		
		// Compare scheme, host, path, and query
		$settings_comparison = ( $settings_url_parts['scheme'] ?? '' ) . '://' . 
							  ( $settings_url_parts['host'] ?? '' ) . 
							  ( $settings_url_parts['path'] ?? '/' ) . 
							  '?' . ( $settings_url_parts['query'] ?? '' );
		$actual_comparison = ( $actual_url_parts['scheme'] ?? '' ) . '://' . 
							( $actual_url_parts['host'] ?? '' ) . 
							( $actual_url_parts['path'] ?? '/' ) . 
							'?' . ( $actual_url_parts['query'] ?? '' );
		
		if ( $settings_comparison !== $actual_comparison ) {
			// Log mismatch for debugging
			error_log( 'ViraStore Google Login: Redirect URI mismatch detected. Settings: ' . $google_redirect_uri . ', Expected: ' . $actual_redirect_uri );
			error_log( 'ViraStore Google Login: Normalized comparison - Settings: ' . $settings_comparison . ', Expected: ' . $actual_comparison );
			// Use the actual redirect URI to ensure consistency with what Google expects
			$google_redirect_uri = $actual_redirect_uri;
		}
		
		// Exchange authorization code for access token
		$token_response = $this->exchange_google_auth_code( $auth_code, $google_client_id, $google_client_secret, $google_redirect_uri );
		
		if ( ! $token_response || isset( $token_response['error'] ) ) {
			$error_msg = 'Failed to authenticate with Google';
			if ( is_array( $token_response ) && isset( $token_response['error'] ) ) {
				$error_msg = isset( $token_response['error_description'] ) 
					? $token_response['error_description'] 
					: ( isset( $token_response['error'] ) ? $token_response['error'] : $error_msg );
			}
			
			// Log detailed error for debugging
			error_log( 'ViraStore Google Login: Token exchange failed. Error: ' . print_r( $token_response, true ) );
			
			$account_page_url = $this->get_account_page_url();
			if ( $account_page_url ) {
				wp_redirect( add_query_arg( array(
					'login_error' => urlencode( 'Google login failed: ' . $error_msg )
				), $account_page_url ) );
				exit;
			}
			return;
		}
		
		if ( ! isset( $token_response['access_token'] ) || empty( $token_response['access_token'] ) ) {
			error_log( 'ViraStore Google Login: Access token missing in response: ' . print_r( $token_response, true ) );
			$account_page_url = $this->get_account_page_url();
			if ( $account_page_url ) {
				wp_redirect( add_query_arg( array(
					'login_error' => urlencode( 'Google login failed: Access token not received' )
				), $account_page_url ) );
				exit;
			}
			return;
		}
		
		$access_token = $token_response['access_token'];
		
		// Get user info from Google
		$user_info = $this->get_google_user_info( $access_token );
		
		if ( ! $user_info || isset( $user_info['error'] ) ) {
			$error_msg = 'Failed to get user information from Google';
			if ( is_array( $user_info ) && isset( $user_info['error'] ) ) {
				if ( isset( $user_info['error']['message'] ) ) {
					$error_msg = $user_info['error']['message'];
				} elseif ( isset( $user_info['error'] ) && is_string( $user_info['error'] ) ) {
					$error_msg = $user_info['error'];
				}
			}
			
			// Log detailed error for debugging
			error_log( 'ViraStore Google Login: Failed to get user info. Error: ' . print_r( $user_info, true ) );
			
			$account_page_url = $this->get_account_page_url();
			if ( $account_page_url ) {
				wp_redirect( add_query_arg( array(
					'login_error' => urlencode( 'Google login failed: ' . $error_msg )
				), $account_page_url ) );
				exit;
			}
			return;
		}
		
		// Process Google user and login/register
		$login_result = $this->process_google_user_login( $user_info );
		
		if ( $login_result['success'] ) {
			// Redirect to account page or specified redirect URL
			$redirect_url = $this->get_account_page_url();
			if ( ! empty( $state ) ) {
				$decoded_state = json_decode( base64_decode( $state ), true );
				if ( isset( $decoded_state['redirect_url'] ) ) {
					$redirect_url = esc_url_raw( $decoded_state['redirect_url'] );
				}
			}
			
			wp_redirect( $redirect_url );
			exit;
		} else {
			// Redirect with error
			$account_page_url = $this->get_account_page_url();
			if ( $account_page_url ) {
				wp_redirect( add_query_arg( array(
					'login_error' => urlencode( $login_result['message'] )
				), $account_page_url ) );
				exit;
			}
		}
	}

	/**
	 * Exchange Google authorization code for access token.
	 *
	 * @since 1.0.0
	 * @param string $auth_code Authorization code from Google.
	 * @param string $client_id Google Client ID.
	 * @param string $client_secret Google Client Secret.
	 * @param string $redirect_uri Redirect URI.
	 * @return array|false Token response or false on failure.
	 */
	private function exchange_google_auth_code( $auth_code, $client_id, $client_secret, $redirect_uri ) {
		$token_url = 'https://oauth2.googleapis.com/token';
		
		// Validate inputs
		if ( empty( $auth_code ) || empty( $client_id ) || empty( $client_secret ) || empty( $redirect_uri ) ) {
			error_log( 'ViraStore Google Login: Missing required parameters for token exchange' );
			return false;
		}
		
		$token_data = array(
			'code' => $auth_code,
			'client_id' => $client_id,
			'client_secret' => $client_secret,
			'redirect_uri' => $redirect_uri,
			'grant_type' => 'authorization_code'
		);
		
		$response = wp_remote_post( $token_url, array(
			'headers' => array(
				'Content-Type' => 'application/x-www-form-urlencoded'
			),
			'body' => http_build_query( $token_data ),
			'timeout' => 30,
			'sslverify' => true
		) );
		
		if ( is_wp_error( $response ) ) {
			error_log( 'ViraStore Google Login: Token exchange HTTP error: ' . $response->get_error_message() );
			return false;
		}
		
		$response_code = wp_remote_retrieve_response_code( $response );
		if ( $response_code !== 200 ) {
			$response_message = wp_remote_retrieve_response_message( $response );
			error_log( 'ViraStore Google Login: Token exchange failed with HTTP ' . $response_code . ': ' . $response_message );
		}
		
		$body = wp_remote_retrieve_body( $response );
		if ( empty( $body ) ) {
			error_log( 'ViraStore Google Login: Empty response body from token exchange' );
			return false;
		}
		
		$token_response = json_decode( $body, true );
		
		if ( json_last_error() !== JSON_ERROR_NONE ) {
			error_log( 'ViraStore Google Login: Failed to parse token response JSON. Error: ' . json_last_error_msg() . ', Body: ' . $body );
			return false;
		}
		
		return $token_response;
	}

	/**
	 * Get Google user information using access token.
	 *
	 * @since 1.0.0
	 * @param string $access_token Google access token.
	 * @return array|false User information or false on failure.
	 */
	private function get_google_user_info( $access_token ) {
		if ( empty( $access_token ) ) {
			error_log( 'ViraStore Google Login: Empty access token provided' );
			return false;
		}
		
		// Use the recommended v3 API endpoint instead of v2
		$userinfo_url = 'https://www.googleapis.com/oauth2/v3/userinfo?access_token=' . urlencode( $access_token );
		
		$response = wp_remote_get( $userinfo_url, array(
			'timeout' => 30,
			'sslverify' => true,
			'headers' => array(
				'Authorization' => 'Bearer ' . $access_token
			)
		) );
		
		if ( is_wp_error( $response ) ) {
			error_log( 'ViraStore Google Login: User info HTTP error: ' . $response->get_error_message() );
			return false;
		}
		
		$response_code = wp_remote_retrieve_response_code( $response );
		if ( $response_code !== 200 ) {
			$response_message = wp_remote_retrieve_response_message( $response );
			$body = wp_remote_retrieve_body( $response );
			error_log( 'ViraStore Google Login: User info failed with HTTP ' . $response_code . ': ' . $response_message . ', Body: ' . $body );
			return false;
		}
		
		$body = wp_remote_retrieve_body( $response );
		if ( empty( $body ) ) {
			error_log( 'ViraStore Google Login: Empty response body from user info endpoint' );
			return false;
		}
		
		$user_info = json_decode( $body, true );
		
		if ( json_last_error() !== JSON_ERROR_NONE ) {
			error_log( 'ViraStore Google Login: Failed to parse user info JSON. Error: ' . json_last_error_msg() . ', Body: ' . $body );
			return false;
		}
		
		return $user_info;
	}

	/**
	 * Process Google user login/registration.
	 *
	 * @since 1.0.0
	 * @param array $user_info Google user information.
	 * @return array Result with success status and message.
	 */
	private function process_google_user_login( $user_info ) {
		if ( empty( $user_info['email'] ) ) {
			return array(
				'success' => false,
				'message' => $this->get_translated_text( 'No email address provided by Google.' )
			);
		}
		
		$email = sanitize_email( $user_info['email'] );
		$first_name = isset( $user_info['given_name'] ) ? sanitize_text_field( $user_info['given_name'] ) : '';
		$last_name = isset( $user_info['family_name'] ) ? sanitize_text_field( $user_info['family_name'] ) : '';
		$full_name = isset( $user_info['name'] ) ? sanitize_text_field( $user_info['name'] ) : '';
		$google_id = isset( $user_info['id'] ) ? sanitize_text_field( $user_info['id'] ) : '';
		
		// Check if user already exists
		$existing_user = get_user_by( 'email', $email );
		
		if ( $existing_user ) {
			// User exists, log them in
			wp_set_current_user( $existing_user->ID );
			wp_set_auth_cookie( $existing_user->ID, true );
			
			// Update Google ID if not set
			if ( $google_id && ! get_user_meta( $existing_user->ID, 'vrstore_google_id', true ) ) {
				update_user_meta( $existing_user->ID, 'vrstore_google_id', $google_id );
			}
			
			return array(
				'success' => true,
				'message' => $this->get_translated_text( 'Login successful!' ),
				'user_id' => $existing_user->ID
			);
		} else {
			// Check if registration is enabled
			if ( ! get_option( 'users_can_register' ) ) {
				return array(
					'success' => false,
					'message' => $this->get_translated_text( 'User registration is currently disabled.' )
				);
			}
			
			// Create new user
			$username = $this->generate_username_from_email( $email );
			$password = wp_generate_password( 12, false );
			
			$user_data = array(
				'user_login' => $username,
				'user_email' => $email,
				'user_pass' => $password,
				'first_name' => $first_name,
				'last_name' => $last_name,
				'display_name' => $full_name ? $full_name : $first_name . ' ' . $last_name,
				'role' => 'customer'
			);
			
			$user_id = wp_insert_user( $user_data );
			
			if ( is_wp_error( $user_id ) ) {
				return array(
					'success' => false,
					'message' => $this->get_translated_text( 'Failed to create user account: ' ) . $user_id->get_error_message()
				);
			}
			
			// Store Google ID
			if ( $google_id ) {
				update_user_meta( $user_id, 'vrstore_google_id', $google_id );
			}
			
			// Mark as Google user
			update_user_meta( $user_id, 'vrstore_google_user', true );
			
			// Log the user in
			wp_set_current_user( $user_id );
			wp_set_auth_cookie( $user_id, true );
			
			return array(
				'success' => true,
				'message' => $this->get_translated_text( 'Account created and login successful!' ),
				'user_id' => $user_id
			);
		}
	}

	/**
	 * Generate unique username from email.
	 *
	 * @since 1.0.0
	 * @param string $email Email address.
	 * @return string Generated username.
	 */
	private function generate_username_from_email( $email ) {
		$username = sanitize_user( substr( $email, 0, strpos( $email, '@' ) ) );
		
		// Make sure username is unique
		if ( username_exists( $username ) ) {
			$i = 1;
			while ( username_exists( $username . $i ) ) {
				$i++;
			}
			$username = $username . $i;
		}
		
		return $username;
	}

	/**
	 * AJAX handler for creating customer support ticket.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function ajax_create_support_ticket() {
		// Check if user is logged in
		if ( ! is_user_logged_in() ) {
			wp_send_json_error( array( 'message' => __('You must be logged in to create a support ticket.', 'vira-store') ) );
		}
		
		// Verify nonce
		if ( ! wp_verify_nonce( $_POST['nonce'] ?? '', 'vrstore_frontend_nonce' ) ) {
			wp_send_json_error( array( 'message' => __('Security check failed.', 'vira-store') ) );
		}
		
		$user_id = get_current_user_id();
		$user = get_userdata($user_id);
		
		// Check if ticket support is locked due to expired licenses
		if (class_exists('VRSTORE_License')) {
			$license_class = VRSTORE_License::get_instance();
			$lock_status = $license_class->is_ticket_support_locked($user_id);
			
			if ($lock_status['locked']) {
				wp_send_json_error( array( 
					'message' => $lock_status['message'],
					'locked' => true,
					'show_extended_support' => true
				) );
			}
		}
		
		// Get form data
		$subject = sanitize_text_field($_POST['subject'] ?? '');
		$message = wp_kses_post($_POST['message'] ?? '');
		$product_id = intval($_POST['product_id'] ?? 0);
		$priority = sanitize_text_field($_POST['priority'] ?? 'normal');
		
		// Validate input - comprehensive validation for all priorities
		if (empty($subject) || empty($message)) {
			wp_send_json_error( array( 'message' => __('Subject and message are required.', 'vira-store') ) );
		}
		
		// Enhanced validation - apply consistent minimum lengths regardless of priority
		if (strlen($subject) < 5) {
			wp_send_json_error( array( 'message' => __('Subject must be at least 5 characters long.', 'vira-store') ) );
		}
		
		if (strlen($message) < 20) {
			wp_send_json_error( array( 'message' => __('Message must be at least 20 characters long.', 'vira-store') ) );
		}
		
		// Validate priority
		$valid_priorities = ['low', 'normal', 'high', 'urgent'];
		if (!in_array($priority, $valid_priorities)) {
			$priority = 'normal';
		}
		
		// Generate unique ticket number
		$ticket_number = 'VRST-' . date('Ymd') . '-' . sprintf('%04d', rand(1000, 9999));
		
		// Ensure ticket number is unique
		global $wpdb;
		$tickets_table = $wpdb->prefix . 'vrstore_support_tickets';
		while ($wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $tickets_table WHERE ticket_number = %s", $ticket_number)) > 0) {
			$ticket_number = 'VRST-' . date('Ymd') . '-' . sprintf('%04d', rand(1000, 9999));
		}
		
		// Get order ID if product is specified
		$order_id = null;
		if ($product_id > 0) {
			$orders_table = $wpdb->prefix . 'vrstore_orders';
			$order = $wpdb->get_row($wpdb->prepare(
				"SELECT id FROM $orders_table WHERE customer_email = %s AND product_id = %d ORDER BY created_at DESC LIMIT 1",
				$user->user_email,
				$product_id
			));
			if ($order) {
				$order_id = $order->id;
			}
		}
		
		// Check if table exists first
		if ($wpdb->get_var("SHOW TABLES LIKE '$tickets_table'") != $tickets_table) {
			// Try to trigger database update
			if (class_exists('VRSTORE_Database')) {
				$db = VRSTORE_Database::get_instance();
				$db->check_database_version();
			}
			
			// Check again
			if ($wpdb->get_var("SHOW TABLES LIKE '$tickets_table'") != $tickets_table) {
				wp_send_json_error( array( 'message' => __('Support tickets table does not exist. Please contact administrator.', 'vira-store') ) );
			}
		}
		
		// Insert ticket
		$result = $wpdb->insert(
			$tickets_table,
			[
				'ticket_number' => $ticket_number,
				'customer_id' => $user_id,
				'customer_name' => $user->display_name ?: $user->user_login,
				'customer_email' => $user->user_email,
				'subject' => $subject,
				'message' => $message,
				'product_id' => $product_id > 0 ? $product_id : null,
				'order_id' => $order_id,
				'status' => 'open',
				'priority' => $priority,
				'customer_unread_count' => 0,
				'admin_unread_count' => 1, // New ticket is unread for admin
				'last_reply_by' => 'customer',
				'last_reply_at' => current_time('mysql'),
				'created_at' => current_time('mysql')
			],
			['%s', '%d', '%s', '%s', '%s', '%s', '%d', '%d', '%s', '%s', '%d', '%d', '%s', '%s', '%s']
		);
		
		if ($result === false) {
			$error_msg = $wpdb->last_error ?: 'Unknown database error';
		// Ticket creation failed
			wp_send_json_error( array( 'message' => __('Failed to create support ticket. Please try again.', 'vira-store') . ' Error: ' . $error_msg ) );
		}
		
		// Get the inserted ticket ID for email notifications
		$ticket_id = $wpdb->insert_id;
		
		// Prepare ticket data for email notifications
		$ticket_data = [
			'ticket_number' => $ticket_number,
			'customer_id' => $user_id,
			'customer_name' => $user->display_name ?: $user->user_login,
			'customer_email' => $user->user_email,
			'subject' => $subject,
			'message' => $message,
			'product_id' => $product_id > 0 ? $product_id : null,
			'order_id' => $order_id,
			'status' => 'open',
			'priority' => $priority,
			'created_at' => current_time('mysql')
		];
		
		// Trigger email notifications
		do_action('vrstore_support_ticket_created', $ticket_id, $ticket_data);
		
		wp_send_json_success( array( 
			'message' => sprintf(__('Support ticket %s created successfully! We will respond as soon as possible.', 'vira-store'), $ticket_number),
			'ticket_number' => $ticket_number
		) );
	}
	
	/**
	 * AJAX handler for getting customer's ticket details.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function ajax_get_my_ticket_details() {
		// Check if user is logged in
		if ( ! is_user_logged_in() ) {
			wp_send_json_error( array( 'message' => __('You must be logged in to view tickets.', 'vira-store') ) );
		}
		
		// Verify nonce
		if ( ! wp_verify_nonce( $_POST['nonce'] ?? '', 'vrstore_frontend_nonce' ) ) {
			wp_send_json_error( array( 'message' => __('Security check failed.', 'vira-store') ) );
		}
		
		$user_id = get_current_user_id();
		$ticket_id = intval($_POST['ticket_id'] ?? 0);
		
		if (!$ticket_id) {
			wp_send_json_error( array( 'message' => __('Invalid ticket ID.', 'vira-store') ) );
		}
		
		global $wpdb;
		$tickets_table = $wpdb->prefix . 'vrstore_support_tickets';
		$replies_table = $wpdb->prefix . 'vrstore_support_replies';
		
		// Get ticket details - ensure customer owns this ticket
		$ticket = $wpdb->get_row($wpdb->prepare(
			"SELECT st.*, p.post_title as product_title
			 FROM $tickets_table st
			 LEFT JOIN {$wpdb->posts} p ON st.product_id = p.ID
			 WHERE st.id = %d AND st.customer_id = %d",
			$ticket_id,
			$user_id
		));
		
		if (!$ticket) {
			wp_send_json_error( array( 'message' => __('Ticket not found or access denied.', 'vira-store') ) );
		}
		
		// Get all replies (exclude private notes from admin)
		$replies = $wpdb->get_results($wpdb->prepare(
			"SELECT * FROM $replies_table 
			 WHERE ticket_id = %d AND (reply_by = 'customer' OR is_private = 0) 
			 ORDER BY created_at ASC",
			$ticket_id
		));
		
		// Mark customer unread messages as read
		$wpdb->update(
			$tickets_table,
			['customer_unread_count' => 0],
			['id' => $ticket_id],
			['%d'],
			['%d']
		);
		
		ob_start();
		?>
		<div class="vrstore-customer-ticket-details">
			<div class="ticket-header">
				<div class="ticket-meta">
					<div class="ticket-info">
						<span><strong><?php _e('Ticket #:', 'vira-store'); ?></strong> <?php echo esc_html($ticket->ticket_number); ?></span>
						<span><strong><?php _e('Product:', 'vira-store'); ?></strong> <?php echo esc_html($ticket->product_title ?: __('General', 'vira-store')); ?></span>
						<span><strong><?php _e('Status:', 'vira-store'); ?></strong> 
							<span class="vrstore-status-badge vrstore-ticket-status-<?php echo esc_attr($ticket->status); ?>">
								<?php echo esc_html(ucfirst($ticket->status)); ?>
							</span>
						</span>
						<span><strong><?php _e('Priority:', 'vira-store'); ?></strong>
							<span class="vrstore-priority-badge vrstore-ticket-priority-<?php echo esc_attr($ticket->priority); ?>">
								<?php echo esc_html(ucfirst($ticket->priority)); ?>
							</span>
						</span>
						<span><strong><?php _e('Created:', 'vira-store'); ?></strong> <?php echo esc_html(mysql2date('M j, Y g:i A', $ticket->created_at)); ?></span>
					</div>
				</div>
			</div>
			
			<div class="ticket-conversation">
				<!-- Original ticket message -->
				<div class="ticket-message customer-message">
					<div class="message-header">
						<strong><?php echo esc_html($ticket->customer_name); ?></strong>
						<span class="message-time"><?php echo esc_html(mysql2date('M j, Y g:i A', $ticket->created_at)); ?></span>
						<span class="message-type customer-badge"><?php _e('You', 'vira-store'); ?></span>
					</div>
					<div class="message-content">
						<?php echo wp_kses_post(wpautop($ticket->message)); ?>
					</div>
				</div>
				
				<!-- Replies -->
				<?php foreach ($replies as $reply): ?>
					<?php $is_admin = $reply->reply_by === 'admin'; ?>
					<div class="ticket-message <?php echo $is_admin ? 'admin-message' : 'customer-message'; ?>">
						<div class="message-header">
							<strong><?php echo esc_html($reply->user_name ?: ($is_admin ? __('Support Agent', 'vira-store') : __('You', 'vira-store'))); ?></strong>
							<span class="message-time"><?php echo esc_html(mysql2date('M j, Y g:i A', $reply->created_at)); ?></span>
							<span class="message-type <?php echo $is_admin ? 'admin-badge' : 'customer-badge'; ?>">
								<?php echo $is_admin ? __('Support Agent', 'vira-store') : __('You', 'vira-store'); ?>
							</span>
						</div>
						<div class="message-content">
							<?php echo wp_kses_post(wpautop($reply->message)); ?>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
			
			<?php if (in_array($ticket->status, ['open', 'pending', 'in_progress'])): ?>
				<div class="customer-reply-form">
					<h4><?php _e('Add Reply', 'vira-store'); ?></h4>
					<form id="vrstore-customer-reply-form" data-ticket-id="<?php echo esc_attr($ticket->id); ?>">
						<div class="form-group">
							<label for="vrstore-customer-reply-message"><?php _e('Your Reply:', 'vira-store'); ?></label>
							<textarea id="vrstore-customer-reply-message" name="message" rows="4" required placeholder="<?php esc_attr_e('Enter your response...', 'vira-store'); ?>"></textarea>
						</div>
						<button type="submit" class="vrstore-btn vrstore-btn-primary"><?php _e('Send Reply', 'vira-store'); ?></button>
					</form>
				</div>
			<?php else: ?>
				<div class="ticket-closed-notice">
					<p><?php _e('This ticket has been closed. If you need further assistance, please create a new ticket.', 'vira-store'); ?></p>
				</div>
			<?php endif; ?>
		</div>
		<?php
		$html_content = ob_get_clean();
		
		wp_send_json_success( array(
			'html' => $html_content
		) );
	}
	
	/**
	 * AJAX handler for adding customer reply to ticket.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function ajax_add_customer_ticket_reply() {
		// Check if user is logged in
		if ( ! is_user_logged_in() ) {
			wp_send_json_error( array( 'message' => __('You must be logged in to reply to tickets.', 'vira-store') ) );
		}
		
		// Verify nonce
		if ( ! wp_verify_nonce( $_POST['nonce'] ?? '', 'vrstore_frontend_nonce' ) ) {
			wp_send_json_error( array( 'message' => __('Security check failed.', 'vira-store') ) );
		}
		
		$user_id = get_current_user_id();
		$user = get_userdata($user_id);
		
		// Check if ticket support is locked due to expired licenses
		if (class_exists('VRSTORE_License')) {
			$license_class = VRSTORE_License::get_instance();
			$lock_status = $license_class->is_ticket_support_locked($user_id);
			
			if ($lock_status['locked']) {
				wp_send_json_error( array( 
					'message' => $lock_status['message'],
					'locked' => true,
					'show_extended_support' => true
				) );
			}
		}
		
		$ticket_id = intval($_POST['ticket_id'] ?? 0);
		$message = wp_kses_post($_POST['message'] ?? '');
		
		if (!$ticket_id || !$message) {
			wp_send_json_error( array( 'message' => __('Invalid parameters.', 'vira-store') ) );
		}
		
		global $wpdb;
		$tickets_table = $wpdb->prefix . 'vrstore_support_tickets';
		$replies_table = $wpdb->prefix . 'vrstore_support_replies';
		
		// Verify ticket ownership and that it's not closed
		$ticket = $wpdb->get_row($wpdb->prepare(
			"SELECT * FROM $tickets_table WHERE id = %d AND customer_id = %d",
			$ticket_id,
			$user_id
		));
		
		if (!$ticket) {
			wp_send_json_error( array( 'message' => __('Ticket not found or access denied.', 'vira-store') ) );
		}
		
		if (in_array($ticket->status, ['resolved', 'closed'])) {
			wp_send_json_error( array( 'message' => __('Cannot reply to a closed or resolved ticket.', 'vira-store') ) );
		}
		
		// Insert reply
		$reply_result = $wpdb->insert(
			$replies_table,
			[
				'ticket_id' => $ticket_id,
				'reply_by' => 'customer',
				'user_id' => $user_id,
				'user_name' => $user->display_name ?: $user->user_login,
				'user_email' => $user->user_email,
				'message' => $message,
				'is_private' => 0,
				'created_at' => current_time('mysql')
			],
			['%d', '%s', '%d', '%s', '%s', '%s', '%d', '%s']
		);
		
		if ($reply_result === false) {
			wp_send_json_error( array( 'message' => __('Failed to add reply.', 'vira-store') ) );
		}
		
		// Update ticket info and admin unread count
		$update_result = $wpdb->update(
			$tickets_table,
			[
				'last_reply_by' => 'customer',
				'last_reply_at' => current_time('mysql'),
				'admin_unread_count' => ($ticket->admin_unread_count + 1),
				'status' => 'pending' // Mark as pending when customer replies
			],
			['id' => $ticket_id],
			['%s', '%s', '%d', '%s'],
			['%d']
		);
		
		if ($update_result !== false) {
			// Prepare reply data for email notifications
			$reply_data = [
				'reply_by' => 'customer',
				'user_id' => $user_id,
				'user_name' => $user->display_name ?: $user->user_login,
				'user_email' => $user->user_email,
				'message' => $message,
				'is_private' => 0,
				'created_at' => current_time('mysql')
			];
			
			// Convert ticket object to array for consistency
			$ticket_data = (array) $ticket;
			
			// Trigger email notification for customer reply
			do_action('vrstore_support_ticket_reply_added', $ticket_id, $reply_data, $ticket_data);
			
			wp_send_json_success( array(
				'message' => __('Reply added successfully.', 'vira-store')
			) );
		} else {
			wp_send_json_error( array( 'message' => __('Reply added but failed to update ticket.', 'vira-store') ) );
		}
	}
	
	/**
	 * AJAX handler to check if ticket support is locked due to expired licenses
	 *
	 * @since 1.0.0
	 */
	public function ajax_check_ticket_lock_status() {
		// Verify nonce
		if ( ! wp_verify_nonce( $_POST['nonce'], 'vrstore_frontend_nonce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', 'vira-store' ) ) );
		}

		// Check if user is logged in
		if ( ! is_user_logged_in() ) {
			wp_send_json_error( array( 'message' => __( 'You must be logged in to check ticket status.', 'vira-store' ) ) );
		}

		$user_id = get_current_user_id();
		
		// Check if ticket support is locked due to expired licenses
		if (class_exists('VRSTORE_License')) {
			$license_class = VRSTORE_License::get_instance();
			$lock_status = $license_class->is_ticket_support_locked($user_id);
			
			wp_send_json_success($lock_status);
		} else {
			wp_send_json_success(array(
				'locked' => false,
				'message' => ''
			));
		}
	}
	
	/**
	 * AJAX handler to get Extended Support pricing for customer's licenses
	 *
	 * @since 1.0.0
	 */
	public function ajax_get_extended_support_pricing() {
		// Verify nonce - support both frontend and custom auth nonces
		$nonce_verified = false;
		$nonce = $_POST['nonce'] ?? '';
		
		if ( wp_verify_nonce( $nonce, 'vrstore_frontend_nonce' ) ) {
			$nonce_verified = true;
		} elseif ( wp_verify_nonce( $nonce, 'vrstore_custom_auth' ) ) {
			$nonce_verified = true;
		} elseif ( wp_verify_nonce( $nonce, 'vrstore_checkout' ) ) {
			$nonce_verified = true;
		}
		
		if ( ! $nonce_verified ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', 'vira-store' ) ) );
		}

		// Check if user is logged in
		if ( ! is_user_logged_in() ) {
			wp_send_json_error( array( 'message' => __( 'You must be logged in to view extended support pricing.', 'vira-store' ) ) );
		}

		$user_id = get_current_user_id();
		
		// Get user email for matching licenses in database table
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			wp_send_json_error( array( 'message' => __( 'User not found.', 'vira-store' ) ) );
		}
		
		$user_email = $user->user_email;
		
		// Get customer's licenses using the same logic as get_user_licenses
		global $wpdb;
		$licenses_table = $wpdb->prefix . 'vrstore_licenses';
		$customers_table = $wpdb->prefix . 'vrstore_customers';
		
		// First, get customer ID by email
		$customer = null;
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$customers_table'" ) === $customers_table ) {
			$customer = $wpdb->get_row( $wpdb->prepare(
				"SELECT * FROM $customers_table WHERE email = %s",
				$user_email
			), ARRAY_A );
		}
		
		// Get licenses from database table using customer_id or customer_email
		// Exclude any Extended Support-related licenses or invalid product IDs
		$customer_licenses = array();
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$licenses_table'" ) === $licenses_table ) {
			// If customer record exists, try customer_id first
			if ( $customer ) {
				$customer_licenses = $wpdb->get_results( $wpdb->prepare(
					"SELECT * FROM $licenses_table 
					 WHERE customer_id = %d 
					 AND status = 'active' 
					 AND product_id > 0 
					 AND product_id NOT LIKE 'extended_support_%%' 
					 ORDER BY created_at DESC",
					$customer['id']
				) );
			}
			
			// If no licenses found by customer_id or no customer record, try customer_email
			if ( empty( $customer_licenses ) ) {
				$customer_licenses = $wpdb->get_results( $wpdb->prepare(
					"SELECT * FROM $licenses_table 
					 WHERE customer_email = %s 
					 AND status = 'active' 
					 AND product_id > 0 
					 AND product_id NOT LIKE 'extended_support_%%' 
					 ORDER BY created_at DESC",
					$user_email
				) );
			}
		}

		if ( empty( $customer_licenses ) ) {
			wp_send_json_error( array( 'message' => __( 'No active licenses found for extended support.', 'vira-store' ) ) );
		}

		// Get Extended Support configuration from settings
		$settings = get_option( 'vrstore_settings', array() );
		$license_types = isset( $settings['custom_license_types'] ) ? $settings['custom_license_types'] : array();
		
		// Get proper currency and conversion settings
		$settings_instance = VRSTORE_Settings::get_instance();
		$base_currency = $settings_instance->get_setting( 'currency', 'USD' );
		$current_currency = $settings_instance->get_current_currency();
		
		// Get currency converter instance for proper conversion
		$currency_converter = VRSTORE_Currency_Converter::get_instance();
		$user_currency = $currency_converter->get_user_currency();
		
		$currency_symbol = VRSTORE_Product::get_currency_symbol( $user_currency );

		// Build HTML content
		$html = '<div class="vrstore-extended-support-pricing" data-currency="' . esc_attr( $currency_symbol ) . '" data-base-currency="' . esc_attr( $base_currency ) . '" data-current-currency="' . esc_attr( $user_currency ) . '" data-converted="true">';
		$html .= '<div class="vrstore-extended-support-header">';
		$html .= '<h4>' . __( 'Extended Support Pricing', 'vira-store' ) . '</h4>';
		$html .= '<p>' . __( 'Extend your support period for your active licenses. Select the number of months you want to add.', 'vira-store' ) . '</p>';
		$html .= '</div>';

		$has_pricing = false;
		$processed_license_ids = array(); // Track processed licenses to prevent duplicates
		
		foreach ( $customer_licenses as $license ) {
			// Skip if we've already processed this license ID
			if ( in_array( $license->id, $processed_license_ids ) ) {
				continue;
			}
			$processed_license_ids[] = $license->id;
			$license_type_slug = $license->license_type_slug ?? '';
			
			// Find pricing for this license type
			$extended_support_price = 0;
			$license_type_name = '';
			foreach ( $license_types as $type ) {
				$type_slug = $type['slug'] ?? '';
				if ( $type_slug === $license_type_slug && isset( $type['extended_support_price'] ) && $type['extended_support_price'] > 0 ) {
					$extended_support_price = floatval( $type['extended_support_price'] );
					$license_type_name = $type['name'] ?? ucfirst( str_replace( '_', ' ', $license_type_slug ) );
					break;
				}
			}

		if ( $extended_support_price > 0 ) {
				// Get and validate product title
				$product_title = get_the_title( $license->product_id );
				
				// Skip this license if product doesn't exist or has no title
				if ( empty( $product_title ) || $product_title === 'Auto Draft' || $license->product_id <= 0 ) {
					continue;
				}
				
				// Also ensure the product post actually exists and is published
				$product_post = get_post( $license->product_id );
				if ( ! $product_post || $product_post->post_status !== 'publish' || $product_post->post_type !== 'vrstore_product' ) {
					continue;
				}
				
				// Check if license generation is enabled for this product
				// Extended Support should only be available for products that actually generate licenses
				$disable_license_generation = get_post_meta( $license->product_id, '_vrstore_disable_license_generation', true );
				if ( $disable_license_generation ) {
					continue;
				}
				
				// Convert price from base currency to user currency
				$displayed_price = $currency_converter->convert_price( $extended_support_price, $user_currency );
				
				// Debug log the conversion
				if (defined('WP_DEBUG') && WP_DEBUG) {
					error_log(sprintf(
						'Extended Support Pricing: base_price=%s, user_currency=%s, converted_price=%s, base_currency=%s',
						$extended_support_price,
						$user_currency,
						$displayed_price,
						$base_currency
					));
				}
				
				$has_pricing = true;
				$html .= '<div class="vrstore-extended-support-item" data-license-id="' . esc_attr( $license->id ) . '" data-license-type="' . esc_attr( $license_type_slug ) . '" data-price="' . esc_attr( $displayed_price ) . '" data-base-price="' . esc_attr( $extended_support_price ) . '">';
				
				// Add selection checkbox
				$html .= '<div class="vrstore-item-selection">';
				$html .= '<label class="vrstore-checkbox-label">';
				$html .= '<input type="checkbox" class="vrstore-support-item-checkbox" value="' . esc_attr( $license->id ) . '" />';
				$html .= '<span class="vrstore-checkbox-custom"></span>';
				$html .= __( 'Select for Extended Support', 'vira-store' );
				$html .= '</label>';
				$html .= '</div>';
				
				$html .= '<div class="vrstore-extended-support-item-content">';
				$html .= '<div class="vrstore-license-info">';
				$html .= '<h5>' . esc_html( $product_title ) . '</h5>';
				$html .= '<p><strong>' . __( 'License Type:', 'vira-store' ) . '</strong> ' . esc_html( $license_type_name ) . '</p>';
				$html .= '<p><strong>' . __( 'License Key:', 'vira-store' ) . '</strong> ' . esc_html( substr( $license->license_key, 0, 8 ) . '...' ) . '</p>';
				// Format price based on current currency - use currency converter for consistency
				// $displayed_price is now converted, so use format_converted_price to avoid double conversion
				$formatted_price = $currency_converter->format_converted_price( $displayed_price, $user_currency );
				$html .= '<p><strong>' . __( 'Price per month:', 'vira-store' ) . '</strong> ' . $formatted_price . '</p>';
				$html .= '</div>';
				
				$html .= '<div class="vrstore-quantity-controls" style="opacity: 0.5; pointer-events: none;">';
				$html .= '<label>' . __( 'Months:', 'vira-store' ) . '</label>';
				$html .= '<div class="vrstore-quantity-wrapper">';
				$html .= '<button type="button" class="vrstore-quantity-btn vrstore-quantity-minus">-</button>';
				$html .= '<input type="number" class="vrstore-quantity-input" value="1" min="1" max="12" disabled />';
				$html .= '<button type="button" class="vrstore-quantity-btn vrstore-quantity-plus">+</button>';
				$html .= '</div>';
				$html .= '<div class="vrstore-item-total-wrapper">';
				$formatted_total = $currency_converter->format_converted_price( $displayed_price, $user_currency );
				$html .= '<span class="vrstore-item-total">' . $formatted_total . '</span>';
				$html .= '</div>';
				$html .= '</div>';
				$html .= '</div>';
				$html .= '</div>';
			}
		}

		if ( ! $has_pricing ) {
			$html .= '<div class="vrstore-no-pricing">';
			$html .= '<p>' . __( 'Extended support pricing is not configured for your license types. Please contact support for assistance.', 'vira-store' ) . '</p>';
			$html .= '</div>';
		}
		$total_html = '';
		if ( $has_pricing ) {
			$total_html = '<div class="vrstore-extended-support-total-wrapper">';
			$total_html .= '<div class="vrstore-total-line">';
			$zero_total = $currency_converter->format_converted_price( 0, $user_currency );
			$total_html .= '<strong>' . __( 'Total:', 'vira-store' ) . ' <span id="vrstore-extended-support-total">' . $zero_total . '</span></strong>';
			$total_html .= '</div>';
			$total_html .= '</div>';
		}

		$html .= '</div>';

		wp_send_json_success( array(
			'html' => $html,
			'total_html' => $total_html,
			'has_pricing' => $has_pricing
		) );
	}

	/**
	 * AJAX handler to purchase Extended Support
	 *
	 * @since 1.0.0
	 */
	public function ajax_purchase_extended_support() {
		// Verify nonce - support both frontend and custom auth nonces
		$nonce_verified = false;
		$nonce = $_POST['nonce'] ?? '';
		
		if ( wp_verify_nonce( $nonce, 'vrstore_frontend_nonce' ) ) {
			$nonce_verified = true;
		} elseif ( wp_verify_nonce( $nonce, 'vrstore_custom_auth' ) ) {
			$nonce_verified = true;
		} elseif ( wp_verify_nonce( $nonce, 'vrstore_checkout' ) ) {
			$nonce_verified = true;
		}
		
		if ( ! $nonce_verified ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', 'vira-store' ) ) );
		}

		// Check if user is logged in
		if ( ! is_user_logged_in() ) {
			wp_send_json_error( array( 'message' => __( 'You must be logged in to purchase extended support.', 'vira-store' ) ) );
		}

		$user_id = get_current_user_id();
		$items = isset( $_POST['items'] ) ? $_POST['items'] : array();

		if ( empty( $items ) ) {
			wp_send_json_error( array( 'message' => __( 'No items selected for extended support.', 'vira-store' ) ) );
		}

		// Get user email for matching licenses in database table
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			wp_send_json_error( array( 'message' => __( 'User not found.', 'vira-store' ) ) );
		}
		
		$user_email = $user->user_email;
		
		// Get customer record
		global $wpdb;
		$licenses_table = $wpdb->prefix . 'vrstore_licenses';
		$customers_table = $wpdb->prefix . 'vrstore_customers';
		
		$customer = null;
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$customers_table'" ) === $customers_table ) {
			$customer = $wpdb->get_row( $wpdb->prepare(
				"SELECT * FROM $customers_table WHERE email = %s",
				$user_email
			), ARRAY_A );
		}

		// Get currency converter and user currency for proper price handling
		$currency_converter = VRSTORE_Currency_Converter::get_instance();
		$user_currency = $currency_converter->get_user_currency();
		$settings_instance = VRSTORE_Settings::get_instance();
		$base_currency = $settings_instance->get_setting( 'currency', 'USD' );
		
		// Validate and sanitize items
		$validated_items = array();
		$total_amount = 0;

		foreach ( $items as $item ) {
			$license_id = intval( $item['license_id'] );
			$months = intval( $item['months'] );
			$price_from_frontend = floatval( $item['price'] ); // This is already converted to user currency

			if ( $license_id <= 0 || $months <= 0 || $price_from_frontend <= 0 ) {
				continue;
			}

			// Verify license belongs to user using proper customer lookup
			$license = null;
			if ( $customer ) {
				// Try with customer_id first
				$license = $wpdb->get_row( $wpdb->prepare(
					"SELECT * FROM $licenses_table WHERE id = %d AND customer_id = %d AND status = 'active'",
					$license_id,
					$customer['id']
				) );
			}
			
			// If not found by customer_id, try by customer_email
			if ( ! $license ) {
				$license = $wpdb->get_row( $wpdb->prepare(
					"SELECT * FROM $licenses_table WHERE id = %d AND customer_email = %s AND status = 'active'",
					$license_id,
					$user_email
				) );
			}

			if ( ! $license ) {
				continue;
			}

			// Calculate item total using converted price from frontend
			$item_total = $price_from_frontend * $months;
			$total_amount += $item_total;

			// Get product title for better descriptions
			$product_title = '';
			if ($license->product_id > 0) {
				$product_post = get_post($license->product_id);
				if ($product_post && $product_post->post_title) {
					$product_title = $product_post->post_title;
				}
			}
			
			$validated_items[] = array(
				'license_id' => $license_id,
				'license_key' => $license->license_key,
				'license_type' => $license->license_type_slug ?? '',
				'product_id' => $license->product_id,
				'product_title' => $product_title, // Add product title for better descriptions
				'months' => $months,
				'price_per_month' => $price_from_frontend, // Store the converted price
				'price_per_month_user_currency' => $price_from_frontend, // Explicit field for converted price
				'total' => $item_total
			);
		}

		if ( empty( $validated_items ) ) {
			wp_send_json_error( array( 'message' => __( 'No valid items found for extended support purchase.', 'vira-store' ) ) );
		}

		// For now, we'll create a simple order record
		// In a full implementation, this would integrate with your payment system
		// Use user currency since prices are already converted
		$order_data = array(
			'customer_id' => $user_id,
			'order_type' => 'extended_support',
			'items' => $validated_items,
			'total_amount' => $total_amount, // Total in user's currency
			'currency' => $user_currency, // Use user's currency for the order
			'base_currency' => $base_currency, // Store base currency for reference
			'prices_converted' => true, // Flag to indicate prices are already converted
			'status' => 'pending',
			'created_at' => current_time( 'mysql' )
		);

	// Store order in transient for payment processing with longer expiry and better key
	$order_key = 'vrstore_extended_support_' . $user_id . '_' . wp_generate_uuid4();
	error_log('ViraStore: Extended Support - Storing order data in transient: ' . $order_key);
	error_log('ViraStore: Extended Support - Order data: ' . print_r($order_data, true));
	
	// Store with 2 hour expiry and also store in user meta as backup
	set_transient( $order_key, $order_data, 2 * HOUR_IN_SECONDS );
	update_user_meta( $user_id, '_vrstore_pending_extended_support', $order_data );
	
	// Verify transient was stored
	$stored_data = get_transient( $order_key );
	error_log('ViraStore: Extended Support - Verified stored transient data: ' . print_r($stored_data, true));

		// Get checkout URL using auto-detection
		$settings = VRSTORE_Settings::get_instance();
		$checkout_url = $settings->get_checkout_url();
		error_log('ViraStore: Extended Support - Checkout URL: ' . $checkout_url);
		$redirect_url = add_query_arg( 'extended_support', $order_key, $checkout_url );
		error_log('ViraStore: Extended Support - Redirect URL: ' . $redirect_url);

		// Redirect to checkout page with order data
		wp_send_json_success( array(
			'message' => __( 'Extended support purchase initiated successfully!', 'vira-store' ),
			'order_key' => $order_key,
			'total_amount' => $total_amount,
			'redirect_url' => $redirect_url
		) );
	}

	/**
	 * Handle Extended Support parameter globally on any page
	 *
	 * @since 1.0.0
	 */
	public function handle_extended_support_global() {
		// Check if Extended Support parameter is present
		if ( isset( $_GET['extended_support'] ) && ! empty( $_GET['extended_support'] ) ) {
			$order_key = sanitize_text_field( $_GET['extended_support'] );
			error_log('ViraStore: Extended Support global handler called with order key: ' . $order_key);
			
			// Get current page info
			$settings = VRSTORE_Settings::get_instance();
			$checkout_url = $settings->get_checkout_url();
			$current_url = home_url( $_SERVER['REQUEST_URI'] );
			$is_checkout_page = (strpos($current_url, $checkout_url) !== false);
			
			error_log('ViraStore: Extended Support - Current URL: ' . $current_url);
			error_log('ViraStore: Extended Support - Checkout URL: ' . $checkout_url);
			error_log('ViraStore: Extended Support - Is checkout page: ' . ($is_checkout_page ? 'yes' : 'no'));
			
			// Get cart instance
			$cart_instance = VRSTORE_Cart::get_instance();
			
			// Process Extended Support checkout
			$this->handle_extended_support_checkout( $order_key, $cart_instance );
			
			// Only redirect if we're NOT already on the checkout page
			if ( !$is_checkout_page && $checkout_url !== home_url() ) {
				error_log('ViraStore: Extended Support - Redirecting to checkout: ' . $checkout_url);
				wp_redirect( $checkout_url );
				exit;
			} else {
				error_log('ViraStore: Extended Support - Already on checkout page, no redirect needed');
				// Remove the parameter from URL to clean it up
				if (isset($_GET['extended_support'])) {
					unset($_GET['extended_support']);
				}
			}
		}
	}
	
	/**
	 * Handle Extended Support checkout parameter
	 *
	 * @since 1.0.0
	 * @param string $order_key The Extended Support order key
	 * @param VRSTORE_Cart $cart_instance Cart instance
	 */
	private function handle_extended_support_checkout( $order_key, $cart_instance ) {
		// Debug logging
		error_log('ViraStore: Extended Support checkout handler called with order key: ' . $order_key);
		
	// Get Extended Support order data from transient with retry mechanism
	$order_data = get_transient( $order_key );
	
	// If transient is empty, try a few more times with small delays (caching issue)
	$retry_count = 0;
	while ( ( ! $order_data || ! isset( $order_data['order_type'] ) ) && $retry_count < 3 ) {
		$retry_count++;
		error_log('ViraStore: Extended Support - Transient empty, retry attempt: ' . $retry_count);
		usleep(100000); // Wait 100ms
		$order_data = get_transient( $order_key );
	}
	
	// If still no data, try to get from user meta as fallback
	if ( ( ! $order_data || ! isset( $order_data['order_type'] ) ) && is_user_logged_in() ) {
		$user_id = get_current_user_id();
		$backup_data = get_user_meta( $user_id, '_vrstore_pending_extended_support', true );
		if ( $backup_data && isset( $backup_data['order_type'] ) && $backup_data['order_type'] === 'extended_support' ) {
			$order_data = $backup_data;
			error_log('ViraStore: Extended Support - Using backup data from user meta');
			// Clean up the backup after use
			delete_user_meta( $user_id, '_vrstore_pending_extended_support' );
		}
	}
		
		// Debug: Log transient data
		error_log('ViraStore: Extended Support order data from transient: ' . print_r($order_data, true));
		
		if ( ! $order_data || ! isset( $order_data['order_type'] ) || $order_data['order_type'] !== 'extended_support' ) {
			error_log('ViraStore: Extended Support - Invalid or missing order data after retries. Order data: ' . print_r($order_data, true));
			
			// Try to get all transients to debug
			global $wpdb;
			$transients = $wpdb->get_results(
				"SELECT option_name, option_value FROM {$wpdb->options} 
				WHERE option_name LIKE '_transient_vrstore_extended_support_%' 
				ORDER BY option_name DESC LIMIT 10"
			);
			error_log('ViraStore: Extended Support - Available transients: ' . print_r($transients, true));
			return;
		}
		
		// Check if user matches the order (allow guest users when customer_id is 0)
		if ( $order_data['customer_id'] > 0 && ( ! is_user_logged_in() || get_current_user_id() != $order_data['customer_id'] ) ) {
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				// Authentication failed - customer ID mismatch
			}
			return;
		}
		
	// Ensure session is initialized before cart operations
	$cart_instance->ensure_session();
	
	// Wait a moment to ensure session is fully ready
	usleep(50000); // 50ms delay
	
	// Clear existing cart to avoid conflicts
	$cart_instance->clear_cart();
	
	// Verify cart is empty after clearing
	$cart_after_clear = $cart_instance->get_cart();
	error_log('ViraStore: Extended Support - Cart after clearing: ' . print_r($cart_after_clear, true));
		
		// Add Extended Support items to cart
		if ( isset( $order_data['items'] ) && is_array( $order_data['items'] ) ) {
			foreach ( $order_data['items'] as $item ) {
				// Create a virtual Extended Support product for cart
				$item_price = isset( $item['price_per_month'] ) ? $item['price_per_month'] : ( $item['price'] ?? 0 );
				
				// Get product title for better naming
				$product_title = isset($item['product_title']) ? $item['product_title'] : '';
				if (empty($product_title) && isset($item['product_id']) && $item['product_id'] > 0) {
					$product_post = get_post($item['product_id']);
					if ($product_post && $product_post->post_title) {
						$product_title = $product_post->post_title;
					}
				}
				
				// Create descriptive product name with associated product
				$license_type_display = ucfirst(str_replace('-', ' ', $item['license_type']));
				if (!empty($product_title)) {
					$product_name = sprintf(
						__( '%s - Extended Support (%s / %d months)', 'vira-store' ),
						$product_title,
						$license_type_display,
						$item['months']
					);
				} else {
					$product_name = sprintf(
						__( 'Extended Support (%s / %d months)', 'vira-store' ),
						$license_type_display,
						$item['months']
					);
				}
				
				$cart_item = array(
					'product_id' => 'extended_support_' . $item['license_id'],
					'product_name' => $product_name,
					'price' => $item_price * $item['months'], // Total price for the months selected
					'quantity' => 1,
					'license_id' => $item['license_id'],
					'license_type' => $item['license_type'],
					'months' => $item['months'],
					'price_per_month' => $item_price, // Store the per-month price for reference
					'item_type' => 'extended_support',
					'associated_product_title' => $product_title, // Store for reference
					'currency' => $order_data['currency'], // Store the currency of the already-converted price
					'price_already_converted' => true // Flag to prevent double conversion
				);
				
				// Add to cart using Extended Support method
				error_log('ViraStore: Extended Support - Adding item to cart: ' . print_r($cart_item, true));
				$add_result = $cart_instance->add_extended_support_to_cart( $cart_item );
				
				if ( $add_result ) {
					error_log('ViraStore: Extended Support - Item added successfully');
				} else {
					error_log('ViraStore: Extended Support - Failed to add item to cart');
				}
				
				// Verify item was added to cart
				$cart_contents = $cart_instance->get_cart();
				error_log('ViraStore: Extended Support - Cart contents after adding item: ' . print_r($cart_contents, true));
		}
	}
	
	// Final verification of cart contents
	$final_cart = $cart_instance->get_cart();
	error_log('ViraStore: Extended Support - Final cart contents: ' . print_r($final_cart, true));
	error_log('ViraStore: Extended Support - Final cart count: ' . $cart_instance->get_cart_count());
	
	// Delete the transient as it's no longer needed
	delete_transient( $order_key );
	}


	/**
	 * Currency switcher shortcode.
	 *
	 * @since 1.0.0
	 * @param array $atts Shortcode attributes.
	 * @return string Shortcode output.
	 */
	public function currency_switcher_shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'style' => 'dropdown', // dropdown, buttons, flags
				'show_flags' => 'no',
				'show_symbols' => 'yes',
				'currencies' => '', // comma-separated list, empty = all supported
			),
			$atts,
			'vrstore_currency_switcher'
		);

		// Check if currency conversion is enabled
		$settings = VRSTORE_Settings::get_instance();
		$conversion_enabled = $settings->get_setting('enable_currency_conversion', '');
		if ($conversion_enabled !== 'on' && $conversion_enabled !== 'yes' && $conversion_enabled !== true) {
			return '';
		}

		$currency_converter = VRSTORE_Currency_Converter::get_instance();
		$supported_currencies = $currency_converter->get_supported_currencies();
		$current_currency = $currency_converter->get_user_currency(false);

		// Filter currencies if specified
		if (!empty($atts['currencies'])) {
			$specified = array_map('trim', explode(',', $atts['currencies']));
			$filtered_currencies = [];
			foreach ($specified as $code) {
				if (isset($supported_currencies[strtoupper($code)])) {
					$filtered_currencies[strtoupper($code)] = $supported_currencies[strtoupper($code)];
				}
			}
			$supported_currencies = $filtered_currencies;
		}

		ob_start();
		?>
		<div class="vrstore-currency-switcher" data-style="<?php echo esc_attr($atts['style']); ?>">
			<?php if ($atts['style'] === 'dropdown') : ?>
				<select id="vrstore-currency-select" class="vrstore-currency-select">
					<?php foreach ($supported_currencies as $code => $info) : ?>
						<option value="<?php echo esc_attr($code); ?>" <?php selected($current_currency, $code); ?>>
							<?php 
							if ($atts['show_symbols'] === 'yes') {
								echo esc_html($info['symbol'] . ' ' . $code);
							} else {
								echo esc_html($code . ' - ' . $info['name']);
							}
							?>
						</option>
					<?php endforeach; ?>
				</select>
			<?php elseif ($atts['style'] === 'buttons') : ?>
				<div class="vrstore-currency-buttons">
					<?php foreach ($supported_currencies as $code => $info) : ?>
						<button type="button" class="vrstore-btn vrstore-btn-sm currency-button <?php echo $current_currency === $code ? 'active' : ''; ?>" 
						        data-currency="<?php echo esc_attr($code); ?>">
							<?php 
							if ($atts['show_symbols'] === 'yes') {
								echo esc_html($info['symbol']);
							} else {
								echo esc_html($code);
							}
							?>
						</button>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * AJAX handler for forgot password requests.
	 *
	 * @since 1.0.0
	 */
	public function ajax_forgot_password() {
		// Verify nonce
		if ( ! wp_verify_nonce( $_POST['nonce'] ?? '', 'vrstore_forgot_password_nonce' ) ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'Security check failed. Please try again.' )
			) );
		}

		// Get and validate email
		$email = sanitize_email( $_POST['email'] ?? '' );
		if ( empty( $email ) || ! is_email( $email ) ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'Please enter a valid email address.' )
			) );
		}

		// Validate math captcha if enabled
		$math_captcha = absint( $_POST['math_captcha'] ?? 0 );
		$math_answer = absint( $_POST['math_answer'] ?? 0 );
		if ( $math_answer > 0 && $math_captcha !== $math_answer ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'Incorrect answer. Please try again.' )
			) );
		}

		// Check if user exists
		$user = get_user_by( 'email', $email );
		if ( ! $user ) {
			// For security, don't reveal whether email exists or not
			wp_send_json_success( array(
				'message' => $this->get_translated_text( 'If an account with this email exists, a password reset link has been sent.' )
			) );
		}

		// Check if user can reset password (not blocked, etc.)
		if ( ! $user->exists() ) {
			wp_send_json_success( array(
				'message' => $this->get_translated_text( 'If an account with this email exists, a password reset link has been sent.' )
			) );
		}

		// Generate reset token and save to database
		$reset_token = $this->generate_password_reset_token( $user->ID );
		if ( ! $reset_token ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'Failed to generate reset token. Please try again.' )
			) );
		}

		// Send password reset email
		$email_sent = $this->send_password_reset_email( $user, $reset_token );
		if ( ! $email_sent ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'Failed to send reset email. Please try again.' )
			) );
		}

		// Return success message
		wp_send_json_success( array(
			'message' => $this->get_translated_text( 'Password reset link has been sent to your email address.' )
		) );
	}

	/**
	 * Generate password reset token and store in database.
	 *
	 * @since 1.0.0
	 * @param int $user_id User ID.
	 * @return string|false Reset token on success, false on failure.
	 */
	private function generate_password_reset_token( $user_id ) {
		global $wpdb;

		// Create password reset tokens table if not exists
		$this->create_password_reset_table();

		$token = wp_generate_uuid4();
		$expires_at = date( 'Y-m-d H:i:s', strtotime( '+1 hour' ) ); // Token expires in 1 hour

		// Clean up old tokens for this user
		$reset_tokens_table = $wpdb->prefix . 'vrstore_password_resets';
		$wpdb->delete(
			$reset_tokens_table,
			array( 'user_id' => $user_id ),
			array( '%d' )
		);

		// Insert new token
		$result = $wpdb->insert(
			$reset_tokens_table,
			array(
				'user_id' => $user_id,
				'token' => $token,
				'expires_at' => $expires_at,
				'created_at' => current_time( 'mysql' )
			),
			array( '%d', '%s', '%s', '%s' )
		);

		return $result !== false ? $token : false;
	}

	/**
	 * Create password reset tokens table.
	 *
	 * @since 1.0.0
	 */
	private function create_password_reset_table() {
		global $wpdb;
		$table_name = $wpdb->prefix . 'vrstore_password_resets';

		// Check if table already exists
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) === $table_name ) {
			return;
		}

		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE $table_name (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned NOT NULL,
			token varchar(255) NOT NULL,
			expires_at datetime NOT NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY token (token),
			KEY user_id (user_id),
			KEY expires_at (expires_at)
		) $charset_collate;";

		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		dbDelta( $sql );
	}

	/**
	 * Send password reset email to user.
	 *
	 * @since 1.0.0
	 * @param WP_User $user User object.
	 * @param string $token Reset token.
	 * @return bool True on success, false on failure.
	 */
	private function send_password_reset_email( $user, $token ) {
		// Generate reset URL
		$account_page_id = get_option( 'vrstore_account_page' );
		if ( $account_page_id ) {
			$reset_url = add_query_arg(
				array(
					'action' => 'reset-password',
					'token' => $token
				),
				get_permalink( $account_page_id )
			);
		} else {
			// Fallback to current page
			$reset_url = add_query_arg(
				array(
					'action' => 'reset-password',
					'token' => $token
				),
				home_url()
			);
		}

		$site_name = get_bloginfo( 'name' );
		$subject = sprintf( $this->get_translated_text( '[%s] Password Reset Request' ), $site_name );

		$message = sprintf(
			$this->get_translated_text( 'Hello %s,' ) . "\n\n" .
			$this->get_translated_text( 'You have requested a password reset for your account on %s.' ) . "\n\n" .
			$this->get_translated_text( 'Please click the following link to reset your password:' ) . "\n" .
			'%s' . "\n\n" .
			$this->get_translated_text( 'This link will expire in 1 hour for security reasons.' ) . "\n\n" .
			$this->get_translated_text( 'If you did not request this password reset, please ignore this email.' ) . "\n\n" .
			$this->get_translated_text( 'Best regards,' ) . "\n" .
			'%s',
			$user->display_name,
			$site_name,
			$reset_url,
			$site_name
		);

		// Set email headers
		$headers = array(
			'Content-Type: text/plain; charset=UTF-8',
			'From: ' . $site_name . ' <noreply@' . wp_parse_url( home_url(), PHP_URL_HOST ) . '>'
		);

		return wp_mail( $user->user_email, $subject, $message, $headers );
	}

	/**
	 * Validate password reset token.
	 *
	 * @since 1.0.0
	 * @param string $token Reset token.
	 * @return array Validation result with 'valid' boolean and 'message' string.
	 */
	private function validate_reset_token( $token ) {
		if ( empty( $token ) ) {
			return array(
				'valid' => false,
				'message' => $this->get_translated_text( 'Invalid reset link. Please request a new one.' )
			);
		}

		global $wpdb;
		$table_name = $wpdb->prefix . 'vrstore_password_resets';

		// Get token from database
		$token_data = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM $table_name WHERE token = %s AND expires_at > NOW()",
			$token
		), ARRAY_A );

		if ( ! $token_data ) {
			return array(
				'valid' => false,
				'message' => $this->get_translated_text( 'Reset link has expired or is invalid. Please request a new one.' )
			);
		}

		// Check if user still exists
		$user = get_userdata( $token_data['user_id'] );
		if ( ! $user ) {
			return array(
				'valid' => false,
				'message' => $this->get_translated_text( 'User account not found.' )
			);
		}

		return array(
			'valid' => true,
			'user_id' => $token_data['user_id'],
			'message' => ''
		);
	}

	/**
	 * AJAX handler for password reset.
	 *
	 * @since 1.0.0
	 */
	public function ajax_reset_password() {
		// Verify nonce
		if ( ! wp_verify_nonce( $_POST['nonce'] ?? '', 'vrstore_reset_password_nonce' ) ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'Security check failed. Please try again.' )
			) );
		}

		// Get and validate input
		$token = sanitize_text_field( $_POST['token'] ?? '' );
		$new_password = $_POST['new_password'] ?? '';
		$confirm_password = $_POST['confirm_password'] ?? '';

		if ( empty( $new_password ) || empty( $confirm_password ) ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'Please fill in all required fields.' )
			) );
		}

		if ( $new_password !== $confirm_password ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'Passwords do not match.' )
			) );
		}

		if ( strlen( $new_password ) < 6 ) {
			wp_send_json_error( array(
				'message' => $this->get_translated_text( 'Password must be at least 6 characters long.' )
			) );
		}

		// Validate token
		$token_validation = $this->validate_reset_token( $token );
		if ( ! $token_validation['valid'] ) {
			wp_send_json_error( array(
				'message' => $token_validation['message']
			) );
		}

		$user_id = $token_validation['user_id'];

		// Update user password
		wp_set_password( $new_password, $user_id );

		// Delete used token
		global $wpdb;
		$table_name = $wpdb->prefix . 'vrstore_password_resets';
		$wpdb->delete( $table_name, array( 'token' => $token ), array( '%s' ) );

		// Send confirmation email
		$user = get_userdata( $user_id );
		if ( $user ) {
			$this->send_password_changed_email( $user );
		}

		wp_send_json_success( array(
			'message' => $this->get_translated_text( 'Password reset successfully! You can now sign in with your new password.' )
		) );
	}

	/**
	 * Send password changed confirmation email.
	 *
	 * @since 1.0.0
	 * @param WP_User $user User object.
	 * @return bool True on success, false on failure.
	 */
	private function send_password_changed_email( $user ) {
		$site_name = get_bloginfo( 'name' );
		$subject = sprintf( $this->get_translated_text( '[%s] Password Changed Successfully' ), $site_name );

		$message = sprintf(
			$this->get_translated_text( 'Hello %s,' ) . "\n\n" .
			$this->get_translated_text( 'Your password has been successfully changed for your account on %s.' ) . "\n\n" .
			$this->get_translated_text( 'If you did not make this change, please contact support immediately.' ) . "\n\n" .
			$this->get_translated_text( 'Best regards,' ) . "\n" .
			'%s',
			$user->display_name,
			$site_name,
			$site_name
		);

		// Set email headers
		$headers = array(
			'Content-Type: text/plain; charset=UTF-8',
			'From: ' . $site_name . ' <noreply@' . wp_parse_url( home_url(), PHP_URL_HOST ) . '>'
		);

		return wp_mail( $user->user_email, $subject, $message, $headers );
	}

	/**
	 * Courses shortcode.
	 *
	 * @since 1.0.0
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public function courses_shortcode( $atts ) {
		// Parse shortcode attributes
		$atts = shortcode_atts( array(
			'posts_per_page' => 12,
			'category' => '',
			'orderby' => 'date',
			'order' => 'DESC',
			'show_search' => 'true',
			'show_filters' => 'true',
			'show_pagination' => 'true',
		), $atts, 'vrstore_courses' );

		// Sanitize attributes
		$posts_per_page = intval( $atts['posts_per_page'] );
		$category = sanitize_text_field( $atts['category'] );
		$orderby = sanitize_text_field( $atts['orderby'] );
		$order = sanitize_text_field( $atts['order'] );
		$show_search = filter_var( $atts['show_search'], FILTER_VALIDATE_BOOLEAN );
		$show_filters = filter_var( $atts['show_filters'], FILTER_VALIDATE_BOOLEAN );
		$show_pagination = filter_var( $atts['show_pagination'], FILTER_VALIDATE_BOOLEAN );

		// Get current page for pagination
		$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;

		// Build query arguments
		$query_args = array(
			'post_type' => 'vrstore_course',
			'post_status' => 'publish',
			'posts_per_page' => $posts_per_page,
			'paged' => $paged,
			'orderby' => $orderby,
			'order' => $order,
		);

		// Add category filter if specified
		if ( !empty( $category ) ) {
			$query_args['tax_query'] = array(
				array(
					'taxonomy' => 'vrstore_course_cat',
					'field' => 'slug',
					'terms' => $category,
				),
			);
		}
		
		// Exclude hidden courses from shortcode display
		$query_args['meta_query'] = array(
			'relation' => 'OR',
			array(
				'key' => '_vrstore_course_visibility',
				'compare' => 'NOT EXISTS'
			),
			array(
				'key' => '_vrstore_course_visibility',
				'value' => 'hidden',
				'compare' => '!='
			)
		);

		// Handle search query
		if ( isset( $_GET['s'] ) && !empty( $_GET['s'] ) ) {
			$query_args['s'] = sanitize_text_field( $_GET['s'] );
		}

		// Create custom query
		$courses_query = new WP_Query( $query_args );

		// Start output buffering
		ob_start();

		// Set global query for template compatibility
		global $wp_query;
		$original_query = $wp_query;
		$wp_query = $courses_query;

		// Include the courses template
		$template_path = VRSTORE_PLUGIN_DIR . 'views/course/courses.php';
		if ( file_exists( $template_path ) ) {
			// Override template variables for shortcode context
			$show_header = false; // Don't show page header in shortcode
			include $template_path;
		} else {
			echo '<p>' . esc_html__( 'Courses template not found.', 'vira-store' ) . '</p>';
		}

		// Restore original query
		$wp_query = $original_query;
		wp_reset_postdata();

		// Return buffered content
		return ob_get_clean();
	}

	/**
	 * Affiliates shortcode.
	 *
	 * @since 1.0.0
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public function affiliates_shortcode( $atts ) {
		// Parse shortcode attributes
		$atts = shortcode_atts( array(
			'view' => 'dashboard', // dashboard, registration, or both
			'customer_only' => 'false', // restrict to existing customers
		), $atts, 'vrstore_affiliates' );

		// Sanitize attributes
		$view = sanitize_text_field( $atts['view'] );
		$customer_only = filter_var( $atts['customer_only'], FILTER_VALIDATE_BOOLEAN );

		// Check if user is logged in
		if ( ! is_user_logged_in() ) {
			return '<div class="vrstore-affiliate-notice">' . 
				   '<p>' . esc_html__( 'Please log in to access the affiliate program.', 'vira-store' ) . '</p>' .
				   '</div>';
		}

		$current_user = wp_get_current_user();
		$user_id = $current_user->ID;

		// Check if customer_only is enabled and user has purchases
		if ( $customer_only ) {
			$has_purchases = $this->user_has_purchases( $user_id );
			if ( ! $has_purchases ) {
				return '<div class="vrstore-affiliate-notice">' . 
					   '<p>' . esc_html__( 'You must be an existing customer to join our affiliate program.', 'vira-store' ) . '</p>' .
					   '</div>';
			}
		}

		// Get affiliate instance
		$affiliate = VRSTORE_Affiliate::get_instance();
		
		// Check if user is already an affiliate
		$is_affiliate = $affiliate->is_affiliate( $user_id );

		// Start output buffering
		ob_start();

		// Enqueue affiliate assets
		$this->enqueue_affiliate_assets();

		// Display based on view and affiliate status
		if ( $view === 'registration' && ! $is_affiliate ) {
			$this->display_affiliate_registration();
		} elseif ( $view === 'dashboard' && $is_affiliate ) {
			$this->display_affiliate_dashboard( $user_id );
		} elseif ( $view === 'both' ) {
			if ( $is_affiliate ) {
				$this->display_affiliate_dashboard( $user_id );
			} else {
				$this->display_affiliate_registration();
			}
		} else {
			// Default behavior
			if ( $is_affiliate ) {
				$this->display_affiliate_dashboard( $user_id );
			} else {
				$this->display_affiliate_registration();
			}
		}

		// Return buffered content
		return ob_get_clean();
	}

	/**
	 * Check if user has made purchases.
	 *
	 * @param int $user_id User ID.
	 * @return bool
	 */
	private function user_has_purchases( $user_id ) {
		global $wpdb;
		
		$orders = $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM {$wpdb->prefix}vrstore_orders 
			 WHERE user_id = %d AND status = 'completed'",
			$user_id
		) );
		
		return $orders > 0;
	}

	/**
	 * Enqueue affiliate assets.
	 */
	private function enqueue_affiliate_assets() {
		// Enqueue CSS
		wp_enqueue_style(
			'vrstore-affiliate',
			VRSTORE_PLUGIN_URL . 'assets/css/affiliate.css',
			[],
			VRSTORE_VERSION
		);

		// Enqueue JavaScript
		wp_enqueue_script(
			'vrstore-affiliate',
			VRSTORE_PLUGIN_URL . 'assets/js/affiliate.js',
			['jquery'],
			VRSTORE_VERSION,
			true
		);

		// Localize script
		wp_localize_script(
			'vrstore-affiliate',
			'vrstore_affiliate',
			[
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'nonce' => wp_create_nonce( 'vrstore_affiliate_nonce' ),
				'messages' => [
					'registering' => esc_html__( 'Registering...', 'vira-store' ),
					'success' => esc_html__( 'Registration successful!', 'vira-store' ),
					'error' => esc_html__( 'An error occurred. Please try again.', 'vira-store' ),
					'copied' => esc_html__( 'Link copied to clipboard!', 'vira-store' ),
				]
			]
		);
	}

	/**
	 * Display affiliate registration form.
	 */
	private function display_affiliate_registration() {
		$template_path = VRSTORE_PLUGIN_DIR . 'views/shortcodes/affiliates.php';
		if ( file_exists( $template_path ) ) {
			// Set variables for template - indicate logged-in user who is not yet an affiliate
			$affiliate_data = false; // false means show registration form for logged-in user
			$stats = null;
			include $template_path;
		} else {
			echo '<div class="vrstore-affiliate-registration">';
			echo '<h3>' . esc_html__( 'Join Our Affiliate Program', 'vira-store' ) . '</h3>';
			echo '<form id="vrstore-affiliate-registration-form" method="post">';
			wp_nonce_field( 'vrstore_affiliate_register', 'vrstore_affiliate_nonce' );
			echo '<p>' . esc_html__( 'Earn commissions by promoting our products!', 'vira-store' ) . '</p>';
			echo '<button type="submit" class="vrstore-btn vrstore-btn-primary">' . esc_html__( 'Join Now', 'vira-store' ) . '</button>';
			echo '</form>';
			echo '</div>';
		}
	}

	/**
	 * Display affiliate dashboard.
	 *
	 * @param int $user_id User ID.
	 */
	private function display_affiliate_dashboard( $user_id ) {
		$template_path = VRSTORE_PLUGIN_DIR . 'views/shortcodes/affiliates.php';
		if ( file_exists( $template_path ) ) {
			// Get affiliate data for template
			$affiliate = VRSTORE_Affiliate::get_instance();
			$affiliate_data = $affiliate->get_affiliate_by_user_id( $user_id );
			$stats = $affiliate->get_affiliate_statistics( $affiliate_data->id );
			
			include $template_path;
		} else {
			// Fallback dashboard
			$affiliate = VRSTORE_Affiliate::get_instance();
			$affiliate_data = $affiliate->get_affiliate_by_user_id( $user_id );
			$stats = $affiliate->get_affiliate_statistics( $affiliate_data->id );
			
			echo '<div class="vrstore-affiliate-dashboard">';
			echo '<h3>' . esc_html__( 'Affiliate Dashboard', 'vira-store' ) . '</h3>';
			
			// Affiliate link
			echo '<div class="vrstore-affiliate-link">';
			echo '<label>' . esc_html__( 'Your Affiliate Link:', 'vira-store' ) . '</label>';
			echo '<input type="text" value="' . esc_attr( home_url( '?ref=' . $affiliate_data->affiliate_code ) ) . '" readonly>';
			echo '<button type="button" class="vrstore-copy-link">' . esc_html__( 'Copy', 'vira-store' ) . '</button>';
			echo '</div>';
			
			// Statistics
			echo '<div class="vrstore-affiliate-stats">';
			echo '<div class="stat-item">';
			echo '<span class="stat-label">' . esc_html__( 'Total Visits:', 'vira-store' ) . '</span>';
			echo '<span class="stat-value">' . esc_html( $stats['visits'] ) . '</span>';
			echo '</div>';
			echo '<div class="stat-item">';
			echo '<span class="stat-label">' . esc_html__( 'Total Commissions:', 'vira-store' ) . '</span>';
			echo '<span class="stat-value">$' . esc_html( number_format( $stats['total_commissions'], 2 ) ) . '</span>';
			echo '</div>';
			echo '</div>';
			
			echo '</div>';
		}
	}
}
