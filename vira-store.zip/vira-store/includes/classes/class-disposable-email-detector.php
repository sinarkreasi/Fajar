<?php
/**
 * Disposable Email Detector Class for Vira Store
 *
 * Detects and blocks temporary/disposable email addresses.
 *
 * @package Vira_Store
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * VRSTORE_Disposable_Email_Detector Class
 *
 * Handles detection and blocking of disposable email addresses.
 *
 * @since 1.0.0
 */
class VRSTORE_Disposable_Email_Detector {

    /**
     * Instance of this class.
     *
     * @since 1.0.0
     * @var object
     */
    private static $instance = null;

    /**
     * Settings instance.
     *
     * @since 1.0.0
     * @var VRSTORE_Settings
     */
    private $settings;

    /**
     * Common disposable email domains.
     *
     * @since 1.0.0
     * @var array
     */
    private $disposable_domains = array(
        '10minutemail.com', '10minutemail.net', '20minutemail.com', '33mail.com',
        'guerrillamail.com', 'guerrillamailblock.com', 'sharklasers.com',
        'tempmail.org', 'temp-mail.org', 'mailinator.com', 'trashmail.com',
        'throwaway.email', 'yopmail.com', 'maildrop.cc', 'jetable.org',
        'spamgourmet.com', 'mailnesia.com', 'dispostable.com', 'fakeinbox.com',
        'tempinbox.com', 'emailondeck.com', 'tempail.com', 'mohmal.com',
        'mytemp.email', 'temp-mail.io', 'tmailor.com', 'gmx.us',
        'burnermail.io', 'minuteinbox.com', 'tempr.email', 'mailtemp.info',
        'tmpeml.info', 'anonymbox.com', 'incognitomail.org', 'dropmail.me',
        'getnada.com', 'mail7.io', 'inboxkitten.com', 'guerrillamail.net',
        'guerrillamail.org', 'guerrillamail.biz', 'spam4.me', 'mvrht.com',
        'grr.la', 'guerrillamailblock.com', 'pokemail.net', '0-mail.com'
    );

    /**
     * Constructor.
     *
     * @since 1.0.0
     */
    private function __construct() {
        $this->settings = VRSTORE_Settings::get_instance();
        
        // Initialize hooks
        $this->init_hooks();
    }

    /**
     * Get instance of this class.
     *
     * @since 1.0.0
     * @return VRSTORE_Disposable_Email_Detector
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        
        return self::$instance;
    }

    /**
     * Get translated text with fallback.
     *
     * @since 1.0.0
     * @param string $text Text to translate.
     * @return string
     */
    private function get_translated_text( $text ) {
        if ( vrstore_is_textdomain_ready() ) {
            return esc_html__( $text, 'vira-store' );
        }
        return esc_html( $text );
    }

    /**
     * Initialize hooks.
     *
     * @since 1.0.0
     * @return void
     */
    private function init_hooks() {
        // Hook into registration validation
        add_filter( 'vrstore_validate_registration_email', array( $this, 'validate_registration_email' ), 10, 2 );
        
        // Hook into checkout validation
        add_filter( 'vrstore_validate_checkout_email', array( $this, 'validate_checkout_email' ), 10, 2 );
    }

    /**
     * Check if disposable email blocking is enabled.
     *
     * @since 1.0.0
     * @return bool
     */
    public function is_blocking_enabled() {
        return $this->settings->get_setting( 'enable_disposable_email_blocking' ) === 'on';
    }

    /**
     * Validate registration email.
     *
     * @since 1.0.0
     * @param array  $errors Existing validation errors.
     * @param string $email  Email address.
     * @return array
     */
    public function validate_registration_email( $errors, $email ) {
        if ( ! $this->is_blocking_enabled() ) {
            return $errors;
        }

        if ( $this->is_disposable_email( $email ) ) {
            $message = $this->settings->get_setting( 'disposable_email_message', 
                'Disposable or temporary email addresses are not allowed. Please use a permanent email address.'
            );
            $errors[] = $message;
        }

        return $errors;
    }

    /**
     * Validate checkout email.
     *
     * @since 1.0.0
     * @param array  $errors Existing validation errors.
     * @param string $email  Email address.
     * @return array
     */
    public function validate_checkout_email( $errors, $email ) {
        if ( ! $this->is_blocking_enabled() ) {
            return $errors;
        }

        if ( $this->is_disposable_email( $email ) ) {
            $message = $this->settings->get_setting( 'disposable_email_message', 
                'Disposable or temporary email addresses are not allowed. Please use a permanent email address.'
            );
            $errors['email'] = $message;
        }

        return $errors;
    }

    /**
     * Check if email is disposable.
     *
     * @since 1.0.0
     * @param string $email Email address.
     * @return bool
     */
    public function is_disposable_email( $email ) {
        if ( empty( $email ) || ! is_email( $email ) ) {
            return false;
        }

        $domain = strtolower( substr( strrchr( $email, '@' ), 1 ) );
        
        // Check against built-in list
        if ( in_array( $domain, $this->disposable_domains, true ) ) {
            return true;
        }

        // Check against custom blocked domains
        $custom_domains = $this->get_custom_blocked_domains();
        if ( in_array( $domain, $custom_domains, true ) ) {
            return true;
        }

        // Check for common patterns
        if ( $this->matches_disposable_patterns( $domain ) ) {
            return true;
        }

        return false;
    }

    /**
     * Get custom blocked domains from settings.
     *
     * @since 1.0.0
     * @return array
     */
    private function get_custom_blocked_domains() {
        $custom_domains_text = $this->settings->get_setting( 'custom_blocked_domains', '' );
        
        if ( empty( $custom_domains_text ) ) {
            return array();
        }

        // Split by lines and clean up
        $domains = explode( "\n", $custom_domains_text );
        $clean_domains = array();

        foreach ( $domains as $domain ) {
            $domain = strtolower( trim( $domain ) );
            
            // Skip empty lines and comments
            if ( empty( $domain ) || substr( $domain, 0, 1 ) === '#' ) {
                continue;
            }

            // Remove protocol if present
            $domain = preg_replace( '/^https?:\/\//', '', $domain );
            
            // Remove www prefix
            $domain = preg_replace( '/^www\./', '', $domain );
            
            // Remove trailing slash
            $domain = rtrim( $domain, '/' );

            if ( ! empty( $domain ) && strpos( $domain, '.' ) !== false ) {
                $clean_domains[] = $domain;
            }
        }

        return array_unique( $clean_domains );
    }

    /**
     * Check if domain matches disposable email patterns.
     *
     * @since 1.0.0
     * @param string $domain Domain name.
     * @return bool
     */
    private function matches_disposable_patterns( $domain ) {
        // Common patterns for disposable email services
        $patterns = array(
            '/^temp.*\./',     // tempmail, temporary, etc.
            '/^throw.*\./',    // throwaway
            '/^fake.*\./',     // fakeinbox, fakemail
            '/^trash.*\./',    // trashmail
            '/^spam.*\./',     // spam4me, spamgourmet
            '/^guerr.*\./',    // guerrillamail variants
            '/.*temp.*\./',    // anything with 'temp' in it
            '/.*fake.*\./',    // anything with 'fake' in it
            '/.*trash.*\./',   // anything with 'trash' in it
            '/.*throw.*\./',   // anything with 'throw' in it
            '/.*spam.*\./',    // anything with 'spam' in it
            '/.*disposable.*\./', // anything with 'disposable'
            '/.*burner.*\./',  // burner emails
            '/.*minute.*\./',  // minute mail variants
            '/\d{1,2}min.*\./', // 10min, 20min etc.
        );

        foreach ( $patterns as $pattern ) {
            if ( preg_match( $pattern, $domain ) ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Get block message for disposable emails.
     *
     * @since 1.0.0
     * @return string
     */
    public function get_block_message() {
        return $this->settings->get_setting( 'disposable_email_message', 
            $this->get_translated_text( 'Disposable or temporary email addresses are not allowed. Please use a permanent email address.' )
        );
    }

    /**
     * Add domain to custom blocked list.
     *
     * @since 1.0.0
     * @param string $domain Domain to block.
     * @return bool
     */
    public function add_blocked_domain( $domain ) {
        $domain = strtolower( trim( $domain ) );
        
        if ( empty( $domain ) ) {
            return false;
        }

        $custom_domains = $this->get_custom_blocked_domains();
        
        if ( ! in_array( $domain, $custom_domains, true ) ) {
            $custom_domains[] = $domain;
            $domains_text = implode( "\n", $custom_domains );
            
            // Update settings
            $settings = get_option( 'vrstore_settings', array() );
            $settings['custom_blocked_domains'] = $domains_text;
            update_option( 'vrstore_settings', $settings );
            
            return true;
        }

        return false;
    }

    /**
     * Remove domain from custom blocked list.
     *
     * @since 1.0.0
     * @param string $domain Domain to unblock.
     * @return bool
     */
    public function remove_blocked_domain( $domain ) {
        $domain = strtolower( trim( $domain ) );
        $custom_domains = $this->get_custom_blocked_domains();
        
        $key = array_search( $domain, $custom_domains, true );
        if ( $key !== false ) {
            unset( $custom_domains[ $key ] );
            $domains_text = implode( "\n", $custom_domains );
            
            // Update settings
            $settings = get_option( 'vrstore_settings', array() );
            $settings['custom_blocked_domains'] = $domains_text;
            update_option( 'vrstore_settings', $settings );
            
            return true;
        }

        return false;
    }

    /**
     * Get all blocked domains (built-in + custom).
     *
     * @since 1.0.0
     * @return array
     */
    public function get_all_blocked_domains() {
        return array_merge( $this->disposable_domains, $this->get_custom_blocked_domains() );
    }
}
