<?php
/**
 * Session Manager Class
 *
 * Centralized session management to prevent conflicts and nonce failures
 *
 * @package Vira_Store
 * @since 1.0.0
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

/**
 * VRSTORE_Session_Manager Class
 *
 * Handles all session operations in a centralized manner to prevent
 * conflicts that can cause nonce verification failures.
 *
 * @since 1.0.0
 */
class VRSTORE_Session_Manager {

    /**
     * Instance of this class.
     *
     * @since 1.0.0
     * @var VRSTORE_Session_Manager|null
     */
    private static ?VRSTORE_Session_Manager $instance = null;

    /**
     * Whether session has been started
     *
     * @var bool
     */
    private bool $session_started = false;

    /**
     * Session configuration
     *
     * @var array
     */
    private array $session_config = [
        'name' => 'vrstore_session',
        'lifetime' => 86400, // 24 hours
        'path' => '/',
        'secure' => null, // Auto-detect based on HTTPS
        'httponly' => true,
        'samesite' => 'Lax'
    ];

    /**
     * Constructor.
     *
     * @since 1.0.0
     */
    private function __construct() {
        $this->init_session_config();
        // Use template_redirect instead of init to avoid headers already sent issues
        add_action('template_redirect', [$this, 'maybe_start_session'], 1);
        // Also handle AJAX requests that need sessions
        add_action('wp_ajax_vrstore_add_to_cart', [$this, 'maybe_start_session'], 1);
        add_action('wp_ajax_nopriv_vrstore_add_to_cart', [$this, 'maybe_start_session'], 1);
        add_action('wp_ajax_vrstore_remove_cart_item', [$this, 'maybe_start_session'], 1);
        add_action('wp_ajax_nopriv_vrstore_remove_cart_item', [$this, 'maybe_start_session'], 1);
        add_action('wp_ajax_vrstore_update_cart_quantity', [$this, 'maybe_start_session'], 1);
        add_action('wp_ajax_nopriv_vrstore_update_cart_quantity', [$this, 'maybe_start_session'], 1);
        add_action('wp_ajax_vrstore_apply_coupon', [$this, 'maybe_start_session'], 1);
        add_action('wp_ajax_nopriv_vrstore_apply_coupon', [$this, 'maybe_start_session'], 1);
        add_action('wp_ajax_vrstore_process_checkout', [$this, 'maybe_start_session'], 1);
        add_action('wp_ajax_nopriv_vrstore_process_checkout', [$this, 'maybe_start_session'], 1);
        add_action('wp_logout', [$this, 'destroy_session']);
        add_action('wp_ajax_vrstore_refresh_nonce', [$this, 'ajax_refresh_nonce']);
        add_action('wp_ajax_nopriv_vrstore_refresh_nonce', [$this, 'ajax_refresh_nonce']);
    }

    /**
     * Get instance of this class.
     *
     * @since 1.0.0
     * @return VRSTORE_Session_Manager
     */
    public static function get_instance(): VRSTORE_Session_Manager {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Get instance only if appropriate context
     *
     * @since 1.0.0
     * @return VRSTORE_Session_Manager|null
     */
    public static function get_instance_if_needed(): ?VRSTORE_Session_Manager {
        // Don't create instance during inappropriate contexts
        if (wp_doing_cron()) {
            return null;
        }
        
        // Allow sessions during checkout processing (admin-post.php)
        if (is_admin() && !wp_doing_ajax()) {
            // Check if this is a checkout request
            $is_checkout_request = (
                isset($_POST['action']) && $_POST['action'] === 'vrstore_process_checkout'
            ) || (
                defined('VRSTORE_CHECKOUT_IN_PROGRESS') && VRSTORE_CHECKOUT_IN_PROGRESS
            ) || (
                isset($_POST['vrstore_checkout_nonce']) || 
                isset($_POST['vrstore_reg_username']) || 
                isset($_POST['vrstore_payment_method'])
            );
            
            if (!$is_checkout_request) {
                return null;
            }
        }
        
        // Allow AJAX requests even if headers are sent (session can still be read)
        if (wp_doing_ajax()) {
            return self::get_instance();
        }
        
        // For non-AJAX requests, check if headers are sent
        if (headers_sent()) {
            return null;
        }

        return self::get_instance();
    }

    /**
     * Initialize session configuration
     *
     * @since 1.0.0
     */
    private function init_session_config(): void {
        // Auto-detect secure based on HTTPS
        if ($this->session_config['secure'] === null) {
            $this->session_config['secure'] = is_ssl();
        }
    }

    /**
     * Determine if session is needed for current request
     *
     * @since 1.0.0
     * @return bool
     */
    private function needs_session(): bool {
        // Always start session for AJAX requests that might need cart access
        if (wp_doing_ajax()) {
            return true;
        }

        // Check if we're on cart or checkout pages
        global $post;
        if ($post && has_shortcode($post->post_content, 'vrstore_cart')) {
            return true;
        }

        if ($post && has_shortcode($post->post_content, 'vrstore_checkout')) {
            return true;
        }

        if ($post && has_shortcode($post->post_content, 'vrstore_account')) {
            return true;
        }

        // Check if cart data exists in cookies (user has items)
        if (!empty($_COOKIE['vrstore_cart_items'])) {
            return true;
        }

        return false;
    }

    /**
     * Start session with proper configuration
     *
     * @since 1.0.0
     * @return bool
     */
    public function start_session(): bool {
        // If we already marked as started, nothing to do
        if ($this->session_started) {
            return true;
        }

        // If a session is already active (possibly started elsewhere), don't early-return.
        // Instead, mark as started and ensure our session keys exist.
        if (session_status() === PHP_SESSION_ACTIVE) {
            $this->session_started = true;
            $this->init_session_data();
            return true;
        }

        // Don't start if headers already sent
        if (headers_sent($file, $line)) {
            error_log(sprintf(
                'ViraStore: Cannot start session - headers already sent by %s on line %d. URL: %s, User Agent: %s',
                $file ?: 'unknown file',
                $line ?: 0,
                $_SERVER['REQUEST_URI'] ?? 'unknown',
                $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
            ));
            return false;
        }

        try {
            // Configure session parameters
            session_name($this->session_config['name']);
            
            // Set session cookie parameters
            $cookie_params = [
                'lifetime' => $this->session_config['lifetime'],
                'path' => $this->session_config['path'],
                'secure' => $this->session_config['secure'],
                'httponly' => $this->session_config['httponly'],
                'samesite' => $this->session_config['samesite']
            ];
            
            if (!empty($this->session_config['domain'])) {
                $cookie_params['domain'] = $this->session_config['domain'];
            }
            
            session_set_cookie_params($cookie_params);

            // Start the session
            if (session_start()) {
                $this->session_started = true;
                $this->init_session_data();
                return true;
            }
        } catch (Exception $e) {
            error_log('ViraStore: Session start exception: ' . $e->getMessage());
        }

        return false;
    }

    /**
     * Initialize session data
     *
     * @since 1.0.0
     */
    private function init_session_data(): void {
        if (!isset($_SESSION['vrstore_cart'])) {
            $_SESSION['vrstore_cart'] = [];
        }

        if (!isset($_SESSION['vrstore_applied_coupon'])) {
            $_SESSION['vrstore_applied_coupon'] = null;
        }

        if (!isset($_SESSION['vrstore_session_started'])) {
            $_SESSION['vrstore_session_started'] = time();
        }

        // Store nonce creation time for debugging
        if (!isset($_SESSION['vrstore_nonce_created'])) {
            $_SESSION['vrstore_nonce_created'] = time();
        }
    }

    /**
     * Get session data
     *
     * @since 1.0.0
     * @param string $key
     */
    public function get_session_data(string $key) {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            return null;
        }
        return $_SESSION[$key] ?? null;
    }

    /**
     * Set session data
     *
     * @since 1.0.0
     * @param string $key
     * @param mixed $value
     * @return bool
     */
    public function set_session_data(string $key, $value): bool {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            return false;
        }
        $_SESSION[$key] = $value;
        return true;
    }

    /**
     * Maybe start session
     *
     * @since 1.0.0
     */
    public function maybe_start_session(): void {
        if ($this->needs_session()) {
            $this->start_session();
        }
    }

    /**
     * Destroy session on logout
     *
     * @since 1.0.0
     */
    public function destroy_session(): void {
        if (session_status() === PHP_SESSION_ACTIVE) {
            // Clear only our keys to avoid interfering with other plugins
            unset($_SESSION['vrstore_cart'], $_SESSION['vrstore_applied_coupon'], $_SESSION['vrstore_session_started'], $_SESSION['vrstore_nonce_created']);
        }
    }

    /**
     * AJAX: Refresh nonce for checkout to avoid expiration issues
     *
     * @since 1.0.0
     */
    public function ajax_refresh_nonce(): void {
        check_ajax_referer('vrstore_refresh_nonce', 'nonce');
        
        // Ensure session is started so we can store timing info
        $this->start_session();
        
        $new_nonce = wp_create_nonce('vrstore_checkout');
        $_SESSION['vrstore_nonce_created'] = time();
        
        wp_send_json_success([
            'nonce' => $new_nonce,
            'created' => $_SESSION['vrstore_nonce_created']
        ]);
    }
}