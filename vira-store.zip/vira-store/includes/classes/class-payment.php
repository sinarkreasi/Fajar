<?php
/**
 * Payment Gateway Integration Class
 *
 * @package Vira_Store
 * @since 1.0.0
 */

// Exit if accessed directly.
if (!defined("ABSPATH")) {
    exit();
}

/**
 * VRSTORE_Payment Class
 *
 * Handles payment gateway integration for TriPay.
 *
 * @since 1.0.0
 */
class VRSTORE_Payment
{
    /**
     * Instance of this class.
     *
     * @since 1.0.0
     * @var object
     */
    protected static $instance = null;

    /**
     * Available payment gateways.
     *
     * @since 1.0.0
     * @var array
     */
    private $gateways = [];

    /**
     * Constructor.
     *
     * @since 1.0.0
     */
    public function __construct()
    {
        // Initialize payment gateways.
        $this->init_gateways();

        // Register hooks.
        add_action("init", [$this, "process_payment_return"]);
        
        // AJAX handler for refreshing payment channels
        add_action("wp_ajax_vrstore_refresh_tripay_channels", [$this, "ajax_refresh_tripay_channels"]);
        add_action("wp_ajax_nopriv_vrstore_refresh_tripay_channels", [$this, "ajax_refresh_tripay_channels"]);
        add_action("wp_ajax_vrstore_process_tripay_payment", [
            $this,
            "ajax_process_tripay_payment",
        ]);
        add_action("wp_ajax_nopriv_vrstore_process_tripay_payment", [
            $this,
            "ajax_process_tripay_payment",
        ]);
    }

    /**
     * Get translated text with conditional loading check.
     *
     * @since 1.0.0
     * @param string $text The text to translate.
     * @return string
     */
    private function get_translated_text($text)
    {
        if (vrstore_is_textdomain_ready()) {
            return esc_html__($text, "vira-store");
        }
        return esc_html($text);
    }

    /**
     * Return an instance of this class.
     *
     * @since 1.0.0
     * @return object A single instance of this class.
     */
    public static function get_instance()
    {
        // If the single instance hasn't been set, set it now.
        if (null === self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Initialize payment gateways.
     *
     * @since 1.0.0
     */
    private function init_gateways()
    {
        // Get enabled gateways from settings - handle both old and new formats
        $settings = get_option("vrstore_settings", []);
        $enabled_gateways_option = isset($settings["enabled_gateways"])
            ? $settings["enabled_gateways"]
            : get_option("vrstore_enabled_gateways", ["tripay" => "on"]);

        // Convert multicheck format to simple array of enabled keys
        $enabled_gateways = [];
        if (is_array($enabled_gateways_option)) {
            foreach ($enabled_gateways_option as $key => $value) {
                if (
                    "on" === $value ||
                    true === $value ||
                    "1" === $value ||
                    1 === $value
                ) {
                    $enabled_gateways[] = $key;
                }
            }
        }

        // Fallback to default if no gateways are enabled
        if (empty($enabled_gateways)) {
            $enabled_gateways = ["tripay"];
        }

        // Initialize TriPay gateway if enabled.
        if (in_array("tripay", $enabled_gateways, true)) {
            $this->gateways["tripay"] = [
                "name" => $this->get_translated_text("TriPay"),
                "description" => $this->get_translated_text(
                    "Pay using various payment methods via TriPay.",
                ),
                "icon" => "money",
                "enabled" => true,
                "callback" => [$this, "process_tripay_payment"],
            ];
        }

        // Initialize PayPal gateway if enabled and addon is active.
        // Note: Gateway registration via filter happens below, but we also manually add it
        // here if enabled in settings to ensure it appears even if filter hasn't run yet
        if (
            in_array("paypal", $enabled_gateways, true) &&
            $this->is_paypal_addon_active()
        ) {
            $this->gateways["paypal"] = [
                "name" => $this->get_translated_text("PayPal"),
                "description" => $this->get_translated_text(
                    "Pay securely with your PayPal account or credit card.",
                ),
                "icon" => "paypal",
                "enabled" => true,
                "callback" => [$this, "process_paypal_payment"],
            ];
        } elseif (
            !in_array("paypal", $enabled_gateways, true) &&
            $this->is_paypal_addon_active()
        ) {
            // PayPal addon is active but not enabled in settings
            // Still add it but mark as disabled so it can be enabled via settings
            // This allows admin to see it's available
        }

        // Initialize Manual Transfer Bank gateway if enabled.
        if (in_array("manual", $enabled_gateways, true)) {
            $this->gateways["manual"] = [
                "name" => $this->get_translated_text("Transfer Bank"),
                "icon" => "bank",
                "enabled" => true,
            ];
        }

        // Apply filters to allow adding custom gateways.
        // IMPORTANT: This allows addons (like PayPal) to register their gateways
        // Filters registered with priority 5+ will run before this
        $this->gateways = apply_filters(
            "vrstore_payment_gateways",
            $this->gateways,
        );
        
        // If PayPal addon is active but gateway wasn't added via filter and isn't enabled,
        // ensure the gateway structure is preserved from filter (addon may have registered it)
        // This handles cases where filter runs after initial gateway setup
    }
    
    /**
     * Refresh gateways - call this when addons might have registered later
     * 
     * @since 1.0.0
     * @return void
     */
    public function refresh_gateways() {
        // Re-apply filters to pick up any late-registering gateways
        $this->gateways = apply_filters(
            "vrstore_payment_gateways",
            $this->gateways,
        );
    }

    /**
     * Check if PayPal addon plugin is active.
     *
     * @since 1.0.0
     * @return bool True if PayPal addon is active.
     */
    private function is_paypal_addon_active()
    {
        // Check if PayPal addon plugin is active
        return class_exists("ViraStore_PayPal") ||
            is_plugin_active("virastore-paypal/virastore-paypal.php");
    }

    /**
     * Get available payment gateways.
     *
     * @since 1.0.0
     * @return array Available payment gateways.
     */
    public function get_available_gateways()
    {
        // Refresh gateways before returning to ensure late-registering addons are included
        // This handles the case where PayPal addon registers after VRSTORE_Payment initialization
        $this->refresh_gateways();
        
        // Filter out disabled gateways (but include PayPal if addon is active, even if not in enabled list)
        $filtered_gateways = [];
        $settings = get_option("vrstore_settings", []);
        $enabled_gateways_option = isset($settings["enabled_gateways"])
            ? $settings["enabled_gateways"]
            : get_option("vrstore_enabled_gateways", ["tripay" => "on"]);
        
        $enabled_gateways = [];
        if (is_array($enabled_gateways_option)) {
            foreach ($enabled_gateways_option as $key => $value) {
                if (
                    "on" === $value ||
                    true === $value ||
                    "1" === $value ||
                    1 === $value
                ) {
                    $enabled_gateways[] = $key;
                }
            }
        }
        
        foreach ($this->gateways as $gateway_id => $gateway) {
            // Include gateway if:
            // 1. It's in enabled list, OR
            // 2. It's PayPal and addon is active (always show PayPal when addon is active)
            // 3. Gateway has 'enabled' => true set (for addon-registered gateways)
            $is_enabled_in_settings = in_array($gateway_id, $enabled_gateways, true);
            $is_paypal_active = ($gateway_id === "paypal" && $this->is_paypal_addon_active());
            $is_explicitly_enabled = isset($gateway["enabled"]) && $gateway["enabled"] === true;
            
            if ($is_enabled_in_settings || $is_paypal_active || $is_explicitly_enabled) {
                $filtered_gateways[$gateway_id] = $gateway;
            }
        }
        
        return $filtered_gateways;
    }

    /**
     * Process payment via AJAX.
     *
     * @since 1.0.0
     */
    public function ajax_process_payment()
    {
        // Check nonce.
        if (
            !isset($_POST["vrstore_payment_nonce"]) ||
            !wp_verify_nonce(
                sanitize_text_field(
                    wp_unslash($_POST["vrstore_payment_nonce"]),
                ),
                "vrstore_payment_nonce",
            )
        ) {
            wp_send_json_error([
                "message" => $this->get_translated_text(
                    "Security check failed.",
                ),
            ]);
        }

        // Check if user is logged in.
        if (!is_user_logged_in()) {
            wp_send_json_error([
                "message" => $this->get_translated_text(
                    "You must be logged in to make a purchase.",
                ),
            ]);
        }

        // Get payment data.
        $payment_gateway = isset($_POST["payment_gateway"])
            ? sanitize_text_field(wp_unslash($_POST["payment_gateway"]))
            : "";
        $product_id = isset($_POST["product_id"])
            ? absint($_POST["product_id"])
            : 0;
        $customer_name = isset($_POST["customer_name"])
            ? sanitize_text_field(wp_unslash($_POST["customer_name"]))
            : "";
        $customer_email = isset($_POST["customer_email"])
            ? sanitize_email(wp_unslash($_POST["customer_email"]))
            : "";

        // Validate payment data.
        if (
            empty($payment_gateway) ||
            empty($product_id) ||
            empty($customer_name) ||
            empty($customer_email)
        ) {
            wp_send_json_error([
                "message" => $this->get_translated_text(
                    "Please fill in all required fields.",
                ),
            ]);
        }

        // Check if payment gateway is valid.
        if (
            !isset($this->gateways[$payment_gateway]) ||
            !$this->gateways[$payment_gateway]["enabled"]
        ) {
            wp_send_json_error([
                "message" => $this->get_translated_text(
                    "Invalid payment gateway.",
                ),
            ]);
        }

        // Get product data.
        $product_instance = VRSTORE_Product::get_instance();
        $product = $product_instance->get_product($product_id);

        // Check if product exists.
        if (!$product) {
            wp_send_json_error([
                "message" => $this->get_translated_text("Product not found."),
            ]);
        }

        // Get product price.
        $price = $product["sale_price"]
            ? $product["sale_price"]
            : $product["price"];

        // Get cart instance to check for applied coupons
        $cart = null;
        if (class_exists("VRSTORE_Cart")) {
            $cart = VRSTORE_Cart::get_instance();
        }

        // Calculate totals with potential discount
        $subtotal = $price;
        $discount_amount = 0;
        $total = $price;
        $coupon_code = "";

        if ($cart) {
            $discount_amount = $cart->get_discount_amount();
            $total = $price - $discount_amount;
            $applied_coupon = $cart->get_applied_coupon();
            if ($applied_coupon && $discount_amount > 0) {
                $coupon_code = $applied_coupon["code"];
            }
        }

        // Get current currency from settings
        $settings = VRSTORE_Settings::get_instance();
        $current_currency = $settings->get_setting("currency", "USD");

        // Create order data.
        $order_data = [
            "product_id" => $product_id,
            "product_title" => $product["title"],
            "price" => $price,
            "total" => $total,
            "currency" => $current_currency,
            "customer_name" => $customer_name,
            "customer_email" => $customer_email,
            "payment_gateway" => $payment_gateway,
            "payment_method" => $payment_gateway,
            "user_id" => get_current_user_id(),
            "date" => current_time("mysql"),
            "status" => "pending",
        ];

        // Add coupon information if applicable
        if ($discount_amount > 0 && !empty($coupon_code)) {
            $order_data["discount_amount"] = $discount_amount;
            $order_data["coupon_code"] = $coupon_code;
        }

        // Process payment based on gateway.
        switch ($payment_gateway) {
            case "tripay":
                $result = $this->process_tripay_payment($order_data);
                break;

            case "paypal":
                $result = $this->process_paypal_payment($order_data);
                break;

            case "xendit":
                $result = $this->process_xendit_payment($order_data);
                break;

            case "moota":
                $result = $this->process_moota_payment($order_data);
                break;

            case "manual":
                $result = $this->process_manual_payment($order_data);
                break;

            default:
                $result = apply_filters(
                    "vrstore_process_payment_" . $payment_gateway,
                    false,
                    $order_data,
                );
                break;
        }

        // Check if payment processing was successful.
        if (is_wp_error($result)) {
            wp_send_json_error(["message" => $result->get_error_message()]);
        } elseif (!$result) {
            wp_send_json_error([
                "message" => $this->get_translated_text(
                    "Payment processing failed.",
                ),
            ]);
        } else {
            wp_send_json_success($result);
        }
    }

    /**
     * Process TriPay payment.
     *
     * @since 1.0.0
     * @param array $order_data Order data.
     * @return array|WP_Error Payment result or error.
     */
    public function process_tripay_payment($order_data)
    {
        $order_id = isset($order_data["order_id"])
            ? absint($order_data["order_id"])
            : 0;
        $existing_order = $order_id
            ? VRSTORE_Order::get_order($order_id)
            : null;

        // Get TriPay API keys from vrstore_settings array
        $test_mode = $this->get_tripay_setting("tripay_test_mode", "on") === "on";
        $api_key = $test_mode
            ? $this->get_tripay_setting("tripay_test_api_key", "")
            : $this->get_tripay_setting("tripay_live_api_key", "");
        $private_key = $test_mode
            ? $this->get_tripay_setting("tripay_test_private_key", "")
            : $this->get_tripay_setting("tripay_live_private_key", "");
        $merchant_code = $test_mode
            ? $this->get_tripay_setting("tripay_test_merchant_code", "")
            : $this->get_tripay_setting("tripay_live_merchant_code", "");

        // Check if TriPay keys are set.
        if (empty($api_key) || empty($private_key) || empty($merchant_code)) {
            // Enhanced debugging for missing credentials
            $missing = [];
            if (empty($api_key)) $missing[] = 'API Key';
            if (empty($private_key)) $missing[] = 'Private Key';
            if (empty($merchant_code)) $missing[] = 'Merchant Code';
            error_log(sprintf(
                'ViraStore TriPay: Missing credentials - Mode: %s, Missing: %s',
                $test_mode ? 'Test' : 'Live',
                implode(', ', $missing)
            ));
            return new WP_Error(
                "tripay_not_configured",
                $this->get_translated_text(
                    "TriPay is not properly configured. Missing: " . implode(", ", $missing),
                ),
            );
        }
        
        // Log successful configuration (without sensitive data)
        error_log(sprintf(
            'ViraStore TriPay: Payment processing - Mode: %s, API Key: %s, Merchant Code: %s',
            $test_mode ? 'Test' : 'Live',
            !empty($api_key) ? 'Set' : 'Missing',
            !empty($merchant_code) ? substr($merchant_code, 0, 2) . '***' : 'Missing'
        ));

        // Determine payment channel selected by customer.
        $payment_channel =
            $order_data["tripay_method"] ??
            ($order_data["payment_channel"] ?? "");
        if (
            empty($payment_channel) &&
            isset($order_data["payment_method"]) &&
            "tripay" !== $order_data["payment_method"]
        ) {
            $payment_channel = sanitize_text_field(
                $order_data["payment_method"],
            );
        }
        if (empty($payment_channel) && isset($_POST["tripay_method"])) {
            $payment_channel = sanitize_text_field(
                wp_unslash($_POST["tripay_method"]),
            );
        }

        if (empty($payment_channel)) {
            return new WP_Error(
                "tripay_method_missing",
                $this->get_translated_text("TriPay payment method is missing."),
            );
        }

        // Determine order totals and customer data.
        $customer_name = isset($order_data["customer_name"])
            ? sanitize_text_field($order_data["customer_name"])
            : $existing_order["customer_name"] ?? "";
        $customer_email = isset($order_data["customer_email"])
            ? sanitize_email($order_data["customer_email"])
            : $existing_order["customer_email"] ?? "";
        $customer_phone = isset($order_data["customer_phone"])
            ? sanitize_text_field($order_data["customer_phone"])
            : "";

        if (empty($customer_email)) {
            return new WP_Error(
                "tripay_missing_email",
                $this->get_translated_text(
                    "Customer email is required for TriPay payments.",
                ),
            );
        }

        $total_amount = isset($order_data["total"])
            ? floatval($order_data["total"])
            : 0;
        if ($total_amount <= 0 && $existing_order) {
            $total_amount = floatval($existing_order["total"]);
        }

        if ($total_amount <= 0) {
            return new WP_Error(
                "tripay_invalid_total",
                $this->get_translated_text(
                    "Cannot process payment for zero total order.",
                ),
            );
        }

        // Get order currency
        $order_currency = isset($order_data["currency"])
            ? strtoupper($order_data["currency"])
            : "USD";
        
        // TriPay requires IDR currency - convert if needed
        $amount_idr = $total_amount;
        if ($order_currency !== "IDR") {
            // Convert to IDR using currency converter
            if (class_exists("VRSTORE_Currency_Converter")) {
                $currency_converter = VRSTORE_Currency_Converter::get_instance();
                $amount_idr = $currency_converter->convert_amount(
                    $total_amount,
                    $order_currency,
                    "IDR"
                );
            } else {
                // Fallback: Use default rate if converter not available
                $usd_to_idr_rate = 16000; // Default rate
                if ($order_currency === "USD") {
                    $amount_idr = $total_amount * $usd_to_idr_rate;
                }
            }
        }
        
        // TriPay minimum amount is 10,000 IDR
        $min_amount_idr = 10000;
        if ($amount_idr < $min_amount_idr) {
            error_log(sprintf(
                'ViraStore TriPay Error: Amount too low - %s IDR (minimum: %s IDR)',
                $amount_idr,
                $min_amount_idr
            ));
            return new WP_Error(
                "tripay_amount_too_low",
                sprintf(
                    $this->get_translated_text(
                        "Payment amount is too low. Minimum amount is Rp %s (approximately %s %s).",
                    ),
                    number_format($min_amount_idr, 0, ',', '.'),
                    number_format($min_amount_idr / 16000, 2),
                    $order_currency
                ),
            );
        }
        
        // Round to integer (IDR doesn't use decimals)
        $amount = max(1, (int) round($amount_idr));

        // Determine order reference and label.
        $order_number =
            $existing_order["order_number"] ??
            ($order_data["order_number"] ?? "");
        $reference_seed = $order_number
            ? preg_replace("/[^A-Za-z0-9-]/", "", $order_number)
            : ($order_id ?:
            time());
        $merchant_ref = "VRSTORE-" . $reference_seed;

        // Build TriPay order items.
        $order_items = [];
        if (
            !empty($order_data["cart_items"]) &&
            is_array($order_data["cart_items"])
        ) {
            $cart_helper = class_exists("VRSTORE_Cart")
                ? VRSTORE_Cart::get_instance()
                : null;
            foreach ($order_data["cart_items"] as $index => $cart_item) {
                $quantity = isset($cart_item["quantity"])
                    ? max(1, absint($cart_item["quantity"]))
                    : 1;
                $item_total = 0;
                if ($cart_helper) {
                    $item_price = $cart_helper->get_item_price($cart_item);
                    // Convert item price to IDR if needed
                    $item_price_idr = $item_price;
                    if ($order_currency !== "IDR" && class_exists("VRSTORE_Currency_Converter")) {
                        $currency_converter = VRSTORE_Currency_Converter::get_instance();
                        $item_price_idr = $currency_converter->convert_amount(
                            $item_price,
                            $order_currency,
                            "IDR"
                        );
                    } elseif ($order_currency === "USD") {
                        // Fallback conversion
                        $item_price_idr = $item_price * 16000;
                    }
                    $item_total = (int) round($item_price_idr * $quantity);
                }
                if ($item_total <= 0) {
                    // Distribute amount evenly if item price calculation failed
                    $item_total = (int) round(
                        $amount / max(1, count($order_data["cart_items"])),
                    );
                }

                $product_id = $cart_item["product_id"] ?? "";
                $item_name = $cart_item["name"] ?? "";
                if (empty($item_name) && $product_id) {
                    $product_post = get_post(
                        is_numeric($product_id) ? absint($product_id) : 0,
                    );
                    if ($product_post && $product_post->post_title) {
                        $item_name = $product_post->post_title;
                    }
                }
                if (empty($item_name)) {
                    $item_name = sprintf("Item %d", $index + 1);
                }

                $order_items[] = [
                    "sku" => "VRSTORE-" . ($product_id ?: $index + 1),
                    "name" => $item_name,
                    "price" => max(1, $item_total),
                    "quantity" => $quantity,
                ];
            }
        }

        if (empty($order_items)) {
            $label = $order_number
                ? sprintf("%s", $order_number)
                : ($order_id
                    ? "#" . $order_id
                    : time());
            $order_items[] = [
                "sku" => $merchant_ref,
                "name" => sprintf("Order %s", $label),
                "price" => $amount,
                "quantity" => 1,
            ];
        }

        try {
            $callback_url = home_url("/wp-json/vrstore/v1/webhooks/tripay");
            
            // Get return URL (thank you page) - validate it exists
            $thank_you_page_id = get_option("vrstore_thank_you_page", 0);
            $return_url = $thank_you_page_id ? get_permalink($thank_you_page_id) : null;
            
            // Fallback to home URL with order parameter if thank you page not set
            if (empty($return_url)) {
                $return_url = add_query_arg(
                    ["vrstore_order_id" => $order_id],
                    home_url()
                );
                error_log(
                    "ViraStore TriPay: Thank you page not configured, using fallback URL: " . $return_url
                );
            } else {
                // Add order ID to return URL
                $return_url = add_query_arg(
                    ["vrstore_order_id" => $order_id],
                    $return_url
                );
            }

            $tripay_data = [
                "method" => $payment_channel,
                "merchant_ref" => $merchant_ref,
                "amount" => $amount,
                "customer_name" => $customer_name,
                "customer_email" => $customer_email,
                "customer_phone" => $customer_phone,
                "order_items" => $order_items,
                "callback_url" => $callback_url,
                "return_url" => $return_url,
                "expired_time" => time() + 24 * 60 * 60,
            ];

            $tripay_data["signature"] = $this->generate_tripay_signature(
                $merchant_code,
                $merchant_ref,
                $tripay_data["amount"],
                $private_key,
            );

            $api_url = $test_mode
                ? "https://tripay.co.id/api-sandbox/transaction/create"
                : "https://tripay.co.id/api/transaction/create";

            // Enhanced logging for TriPay API request
            error_log(sprintf(
                'ViraStore TriPay: Initiating payment - Order: %s, Amount: %d, Channel: %s, Mode: %s',
                $merchant_ref,
                $amount,
                $payment_channel,
                $test_mode ? 'sandbox' : 'production'
            ));

            $response = $this->make_tripay_request(
                $api_url,
                $tripay_data,
                $api_key,
                $merchant_code,
                $private_key,
            );

            if (is_wp_error($response)) {
                // Enhanced error logging with full details
                error_log(sprintf(
                    'ViraStore TriPay API Error: %s | Order: %s | Amount: %d | Channel: %s',
                    $response->get_error_message(),
                    $merchant_ref,
                    $amount,
                    $payment_channel
                ));
                return $response;
            }

            if (!isset($response["success"]) || !$response["success"]) {
                $error_message = isset($response["message"])
                    ? $response["message"]
                    : $this->get_translated_text("TriPay API error");

                // Log API response failure
                error_log(sprintf(
                    'ViraStore TriPay API Response Failed: %s | Order: %s | Response: %s',
                    $error_message,
                    $merchant_ref,
                    wp_json_encode($response)
                ));

                return new WP_Error("tripay_api_error", $error_message);
            }

            // Validate response data structure
            if (!isset($response["data"]) || !is_array($response["data"])) {
                error_log(
                    "ViraStore TriPay ERROR: Invalid response data structure. Response: " . wp_json_encode($response)
                );
                return new WP_Error(
                    "tripay_invalid_response",
                    $this->get_translated_text("Invalid response from TriPay API.")
                );
            }

            $tripay_transaction = $response["data"];

            // Validate required transaction data
            if (empty($tripay_transaction["reference"])) {
                error_log(
                    "ViraStore TriPay ERROR: Missing transaction reference in response."
                );
                return new WP_Error(
                    "tripay_missing_reference",
                    $this->get_translated_text("TriPay transaction reference is missing.")
                );
            }

            if (empty($tripay_transaction["checkout_url"])) {
                error_log(
                    "ViraStore TriPay ERROR: Missing checkout URL in response. Reference: " . $tripay_transaction["reference"]
                );
                return new WP_Error(
                    "tripay_missing_checkout_url",
                    $this->get_translated_text("TriPay checkout URL is missing.")
                );
            }

            // Log successful API response
            error_log(sprintf(
                'ViraStore TriPay: Payment created successfully - Reference: %s, Checkout URL: %s, Amount: %d',
                $tripay_transaction["reference"],
                $tripay_transaction["checkout_url"],
                $tripay_transaction["amount"] ?? 0
            ));

            if ($order_id) {
                $this->record_tripay_transaction_for_order(
                    $order_id,
                    $payment_channel,
                    $tripay_transaction,
                );
            } else {
                $order_data["payment_method"] = "tripay";
                $order_data["transaction_id"] =
                    $tripay_transaction["reference"];
                $order_data["tripay_data"] = wp_json_encode(
                    $tripay_transaction,
                );
                $order_data["status"] = "pending";
                $order_id = $this->save_order($order_data);

                if (!$order_id) {
                    return new WP_Error(
                        "order_save_failed",
                        $this->get_translated_text("Failed to save order."),
                    );
                }
            }

            // Ensure redirect_url is set (use checkout_url as primary source)
            $redirect_url = $tripay_transaction["checkout_url"] ?? "";
            
            // Validate redirect URL before returning
            if (!wp_http_validate_url($redirect_url)) {
                error_log(
                    "ViraStore TriPay ERROR: Invalid checkout URL format: " . $redirect_url
                );
                return new WP_Error(
                    "tripay_invalid_checkout_url",
                    $this->get_translated_text("Invalid TriPay checkout URL received.")
                );
            }

            return [
                "success" => true,
                "order_id" => $order_id,
                "tripay_reference" => $tripay_transaction["reference"],
                "checkout_url" => $redirect_url,
                "redirect_url" => $redirect_url, // Ensure both fields are set
                "payment_method" => $payment_channel,
                "amount" => isset($tripay_transaction["amount"]) ? intval($tripay_transaction["amount"]) : $amount,
                "expired_time" => isset($tripay_transaction["expired_time"]) ? $tripay_transaction["expired_time"] : null,
                "message" => $this->get_translated_text(
                    "Redirecting to TriPay payment page...",
                ),
            ];
        } catch (Exception $e) {
            return new WP_Error("tripay_error", $e->getMessage());
        }
    }

    /**
     * Persist TriPay transaction details against an existing order.
     *
     * @since 1.0.0
     * @param int   $order_id Order ID.
     * @param string $payment_channel TriPay payment channel code.
     * @param array $transaction TriPay transaction payload.
     * @return void
     */
    private function record_tripay_transaction_for_order(
        int $order_id,
        string $payment_channel,
        array $transaction,
    ) {
        if ($order_id <= 0) {
            return;
        }

        $reference = isset($transaction["reference"])
            ? sanitize_text_field($transaction["reference"])
            : "";

        if (get_post($order_id)) {
            update_post_meta($order_id, "_vrstore_transaction_id", $reference);
            update_post_meta($order_id, "_vrstore_tripay_data", $transaction);
            update_post_meta($order_id, "_vrstore_payment_method", "tripay");
            update_post_meta(
                $order_id,
                "_vrstore_payment_channel",
                sanitize_text_field($payment_channel),
            );
        }

        global $wpdb;
        $orders_table = $wpdb->prefix . "vrstore_orders";
        if (
            $wpdb->get_var(
                $wpdb->prepare("SHOW TABLES LIKE %s", $orders_table),
            ) === $orders_table
        ) {
            $wpdb->update(
                $orders_table,
                [
                    "payment_method" => "tripay",
                    "transaction_id" => $reference,
                    "updated_at" => current_time("mysql"),
                ],
                ["id" => $order_id],
                ["%s", "%s", "%s"],
                ["%d"],
            );
        }
    }

    /**
     * Process Manual Transfer Bank payment.
     *
     * @since 1.0.0
     * @param array $order_data Order data.
     * @return array|WP_Error Payment result or error.
     */
    private function process_manual_payment($order_data)
    {
        // Save order with status 'pending' and payment gateway 'manual'.
        $order_id = VRSTORE_Order::create_order($order_data);
        if (!$order_id) {
            return new WP_Error(
                "manual_order_failed",
                $this->get_translated_text(
                    "Failed to create order for manual payment.",
                ),
            );
        }

        // Optionally, send instructions email here.

        return [
            "order_id" => $order_id,
            "redirect_url" => add_query_arg(
                ["vrstore_order_id" => $order_id],
                get_permalink(get_option("vrstore_thank_you_page", 0)),
            ),
            "message" => $this->get_translated_text(
                "Order placed! Please follow the bank transfer instructions to complete your payment.",
            ),
        ];
    }

    /**
     * Process PayPal payment.
     *
     * @since 1.0.0
     * @param array $order_data Order data.
     * @return array|WP_Error Payment result or error.
     */
    public function process_paypal_payment($order_data)
    {
        error_log(
            "ViraStore PayPal: Starting process_paypal_payment with data: " .
                print_r($order_data, true),
        );

        $order_id = isset($order_data["order_id"])
            ? absint($order_data["order_id"])
            : 0;
        if (!$order_id) {
            if (empty($order_data["payment_method"])) {
                $order_data["payment_method"] = "paypal";
            }
            $order_data["status"] = $order_data["status"] ?? "pending";
            $order_id = $this->save_order($order_data);
            if (!$order_id) {
                error_log("ViraStore PayPal ERROR: Failed to create order");
                return new WP_Error(
                    "paypal_order_failed",
                    $this->get_translated_text(
                        "Failed to create order for PayPal payment.",
                    ),
                );
            }
            error_log("ViraStore PayPal: Order created with ID: " . $order_id);
        }

        $order_data["order_id"] = $order_id;

        // Check if PayPal addon is available
        if (class_exists("ViraStore_PayPal")) {
            error_log("ViraStore PayPal: ViraStore_PayPal class found");
            $paypal_addon = ViraStore_PayPal::get_instance();
            if (method_exists($paypal_addon, "process_payment")) {
                error_log("ViraStore PayPal: process_payment method exists");

                // Prepare payment data for PayPal addon with proper structure
                // CRITICAL FIX: Add 'amount' field that payment processor expects
                // Handle potential currency conversion issues
                $raw_amount = isset($order_data["total"])
                    ? $order_data["total"]
                    : (isset($order_data["price"])
                        ? $order_data["price"]
                        : 0);

                // Ensure amount is a valid numeric value (handle currency conversion arrays)
                if (is_array($raw_amount)) {
                    error_log(
                        "ViraStore PayPal: Amount is array, extracting numeric value: " .
                            print_r($raw_amount, true),
                    );
                    $amount = is_numeric($raw_amount[0])
                        ? floatval($raw_amount[0])
                        : 0;
                } else {
                    $amount = floatval($raw_amount);
                }

                // Additional validation
                if (!is_numeric($amount) || $amount <= 0) {
                    error_log(
                        "ViraStore PayPal ERROR: Invalid amount calculated - Raw: " .
                            var_export($raw_amount, true) .
                            ", Processed: " .
                            var_export($amount, true),
                    );
                    return new WP_Error(
                        "paypal_invalid_amount",
                        $this->get_translated_text(
                            "Invalid payment amount. Please refresh the page and try again.",
                        ),
                    );
                }

                $currency = isset($order_data["currency"])
                    ? $order_data["currency"]
                    : "USD";

                $payment_data = [
                    "order_id" => $order_id,
                    "amount" => $amount, // CRITICAL: Payment processor expects 'amount' not 'total'
                    "total" => $amount, // Keep total for compatibility
                    "currency" => $currency,
                    "payment_method" => "paypal",
                    "order_data" => $order_data,
                    "customer_name" => isset($order_data["customer_name"])
                        ? $order_data["customer_name"]
                        : "",
                    "customer_email" => isset($order_data["customer_email"])
                        ? $order_data["customer_email"]
                        : "",
                    "return_url" => $this->get_return_url($order_id),
                    "cancel_url" => $this->get_cancel_url($order_id),
                ];

                error_log(
                    "ViraStore PayPal: Prepared payment data: " .
                        print_r($payment_data, true),
                );

                // Let PayPal addon handle the payment processing
                $result = $paypal_addon->process_payment($payment_data);

                error_log(
                    "ViraStore PayPal: Result from addon: " .
                        print_r($result, true),
                );

                return $result;
            } else {
                error_log(
                    "ViraStore PayPal ERROR: process_payment method not found",
                );
            }
        } else {
            error_log(
                "ViraStore PayPal ERROR: ViraStore_PayPal class not found",
            );
        }

        // Fallback: Return error if PayPal addon is not available
        error_log("ViraStore PayPal ERROR: PayPal addon not available");
        return new WP_Error(
            "paypal_not_available",
            $this->get_translated_text(
                "PayPal payment is not available. Please select a different payment method.",
            ),
        );
    }

    /**
     * Process Xendit payment.
     *
     * @since 1.0.0
     * @param array $order_data Order data.
     * @return array|WP_Error Payment result or error.
     */
    public function process_xendit_payment($order_data)
    {
        error_log(
            "ViraStore Xendit: Starting process_xendit_payment with data: " .
                print_r($order_data, true),
        );

        $order_id = isset($order_data["order_id"])
            ? absint($order_data["order_id"])
            : 0;
        if (!$order_id) {
            if (empty($order_data["payment_method"])) {
                $order_data["payment_method"] = "xendit";
            }
            $order_data["status"] = $order_data["status"] ?? "pending";
            $order_id = $this->save_order($order_data);
            if (!$order_id) {
                error_log("ViraStore Xendit ERROR: Failed to create order");
                return new WP_Error(
                    "xendit_order_failed",
                    $this->get_translated_text(
                        "Failed to create order for Xendit payment.",
                    ),
                );
            }
            error_log("ViraStore Xendit: Order created with ID: " . $order_id);
        }

        $order_data["order_id"] = $order_id;

        // Check if Xendit addon is available
        if (class_exists("ViraStore_Xendit")) {
            error_log("ViraStore Xendit: ViraStore_Xendit class found");
            $xendit_addon = ViraStore_Xendit::get_instance();
            if (method_exists($xendit_addon, "process_payment")) {
                error_log("ViraStore Xendit: process_payment method exists");

                // Prepare payment data for Xendit addon
                $raw_amount = isset($order_data["total"])
                    ? $order_data["total"]
                    : (isset($order_data["price"])
                        ? $order_data["price"]
                        : 0);

                // Ensure amount is a valid numeric value
                if (is_array($raw_amount)) {
                    error_log(
                        "ViraStore Xendit: Amount is array, extracting numeric value: " .
                            print_r($raw_amount, true),
                    );
                    $amount = is_numeric($raw_amount[0])
                        ? floatval($raw_amount[0])
                        : 0;
                } else {
                    $amount = floatval($raw_amount);
                }

                // Additional validation
                if (!is_numeric($amount) || $amount <= 0) {
                    error_log(
                        "ViraStore Xendit ERROR: Invalid amount calculated - Raw: " .
                            var_export($raw_amount, true) .
                            ", Processed: " .
                            var_export($amount, true),
                    );
                    return new WP_Error(
                        "xendit_invalid_amount",
                        $this->get_translated_text(
                            "Invalid payment amount. Please refresh the page and try again.",
                        ),
                    );
                }

                $currency = isset($order_data["currency"])
                    ? $order_data["currency"]
                    : "USD";

                $payment_data = [
                    "order_id" => $order_id,
                    "amount" => $amount,
                    "total" => $amount,
                    "currency" => $currency,
                    "payment_method" => "xendit",
                    "order_data" => $order_data,
                    "customer_name" => isset($order_data["customer_name"])
                        ? $order_data["customer_name"]
                        : "",
                    "customer_email" => isset($order_data["customer_email"])
                        ? $order_data["customer_email"]
                        : "",
                    "return_url" => $this->get_return_url($order_id),
                    "cancel_url" => $this->get_cancel_url($order_id),
                ];

                error_log(
                    "ViraStore Xendit: Prepared payment data: " .
                        print_r($payment_data, true),
                );

                // Let Xendit addon handle the payment processing
                $result = $xendit_addon->process_payment($payment_data);

                error_log(
                    "ViraStore Xendit: Result from addon: " .
                        print_r($result, true),
                );

                return $result;
            } else {
                error_log(
                    "ViraStore Xendit ERROR: process_payment method not found",
                );
            }
        } else {
            error_log(
                "ViraStore Xendit ERROR: ViraStore_Xendit class not found",
            );
        }

        // Fallback: Return error if Xendit addon is not available
        error_log("ViraStore Xendit ERROR: Xendit addon not available");
        return new WP_Error(
            "xendit_not_available",
            $this->get_translated_text(
                "Xendit payment is not available. Please select a different payment method.",
            ),
        );
    }

    /**
     * Process Moota payment.
     *
     * @since 1.0.0
     * @param array $order_data Order data.
     * @return array|WP_Error Payment result or error.
     */
    public function process_moota_payment($order_data)
    {
        error_log(
            "ViraStore Moota: Starting process_moota_payment with data: " .
                print_r($order_data, true),
        );

        // Check if Moota gateway class is available
        if (!class_exists("ViraStore_Moota_Gateway")) {
            error_log("ViraStore Moota ERROR: ViraStore_Moota_Gateway class not found");
            return new WP_Error(
                "moota_not_available",
                $this->get_translated_text(
                    "Moota payment gateway is not available. Please try another payment method.",
                ),
            );
        }

        // Get Moota gateway instance
        $moota_gateway = ViraStore_Moota_Gateway::get_instance();
        
        // Check if gateway is enabled
        if (!$moota_gateway->is_enabled()) {
            error_log("ViraStore Moota ERROR: Gateway not enabled");
            return new WP_Error(
                "moota_not_enabled",
                $this->get_translated_text(
                    "Moota payment gateway is not enabled.",
                ),
            );
        }

        // Get bank accounts
        $bank_accounts = $moota_gateway->get_bank_accounts();
        
        if (empty($bank_accounts)) {
            error_log("ViraStore Moota ERROR: No bank accounts configured");
            return new WP_Error(
                "moota_no_banks",
                $this->get_translated_text(
                    "No bank accounts configured for Moota payment.",
                ),
            );
        }

        // Get selected bank account or use the first one
        $selected_bank = isset($order_data["vrstore_moota_bank"])
            ? sanitize_text_field($order_data["vrstore_moota_bank"])
            : "";
        
        $selected_bank_account = null;
        if (!empty($selected_bank)) {
            foreach ($bank_accounts as $account) {
                $bank_id = $account["moota_bank_id"] ?? ($account["account_number"] ?? "");
                if ($bank_id === $selected_bank) {
                    $selected_bank_account = $account;
                    break;
                }
            }
        }
        
        // Fallback to first bank account if no match found
        if (!$selected_bank_account) {
            $selected_bank_account = reset($bank_accounts);
        }

        // Create or get order
        $order_id = isset($order_data["order_id"])
            ? absint($order_data["order_id"])
            : 0;
        
        if (!$order_id) {
            if (empty($order_data["payment_method"])) {
                $order_data["payment_method"] = "moota";
            }
            $order_data["status"] = $order_data["status"] ?? "pending";
            $order_id = $this->save_order($order_data);
            
            if (!$order_id) {
                error_log("ViraStore Moota ERROR: Failed to create order");
                return new WP_Error(
                    "moota_order_failed",
                    $this->get_translated_text(
                        "Failed to create order for Moota payment.",
                    ),
                );
            }
            error_log("ViraStore Moota: Order created with ID: " . $order_id);
        }

        // Get order total
        $amount = isset($order_data["total"])
            ? floatval($order_data["total"])
            : (isset($order_data["price"]) ? floatval($order_data["price"]) : 0);

        // Update order with payment method and bank info
        update_post_meta($order_id, "_vrstore_payment_method", "moota");
        update_post_meta($order_id, "_vrstore_payment_status", "pending");
        update_post_meta($order_id, "_vrstore_moota_selected_bank", $selected_bank_account);

        // Store Moota payment data
        $moota_payment_data = array(
            "order_id" => $order_id,
            "amount" => $amount,
            "currency" => $order_data["currency"] ?? "USD",
            "status" => "pending",
            "created_at" => current_time("mysql"),
            "expected_amount" => $amount,
            "selected_bank" => $selected_bank_account,
            "reference" => (string) $order_id,
        );
        
        update_post_meta($order_id, "_vrstore_moota_payment_data", $moota_payment_data);

        // Update order status to pending
        VRSTORE_Order::update_order_status($order_id, "pending");
        VRSTORE_Order::update_payment_status($order_id, "pending");

        // Get thank you page URL
        $thank_you_page_id = get_option("vrstore_thank_you_page", 0);
        $return_url = $thank_you_page_id 
            ? get_permalink($thank_you_page_id) 
            : home_url();
        
        $return_url = add_query_arg(
            ["vrstore_order_id" => $order_id],
            $return_url
        );

        error_log("ViraStore Moota: Payment initiated for order #" . $order_id);

        return [
            "order_id" => $order_id,
            "redirect_url" => $return_url,
            "message" => $this->get_translated_text(
                "Order created successfully! Please complete your bank transfer. Payment will be automatically verified.",
            ),
        ];
    }

    /**
     * Get return URL for payment success.
     *
     * @since 1.0.0
     * @param int $order_id Order ID.
     * @return string
     */
    private function get_return_url($order_id)
    {
        $thank_you_page_id = get_option("vrstore_thank_you_page", 0);
        if ($thank_you_page_id) {
            $thank_you_url = get_permalink($thank_you_page_id);
            return add_query_arg("order_id", $order_id, $thank_you_url);
        }
        return home_url();
    }

    /**
     * Get cancel URL for payment cancellation.
     *
     * @since 1.0.0
     * @param int $order_id Order ID.
     * @return string
     */
    private function get_cancel_url($order_id)
    {
        $checkout_page_id = get_option("vrstore_checkout_page", 0);
        if ($checkout_page_id) {
            $checkout_url = get_permalink($checkout_page_id);
            return add_query_arg(
                [
                    "order_id" => $order_id,
                    "payment_error" => "cancelled",
                ],
                $checkout_url,
            );
        }
        return home_url();
    }

    /**
     * Process payment return from payment gateway.
     *
     * @since 1.0.0
     */
    public function process_payment_return()
    {
        // Check if this is a payment return page.
        if (!isset($_GET["vrstore_payment_return"])) {
            return;
        }

        // Get payment gateway.
        $payment_gateway = isset($_GET["payment_gateway"])
            ? sanitize_text_field(wp_unslash($_GET["payment_gateway"]))
            : "";

        // Process payment return based on gateway.
        switch ($payment_gateway) {
            case "tripay":
                $this->process_tripay_return();
                break;

            default:
                do_action("vrstore_process_payment_return_" . $payment_gateway);
                break;
        }
    }

    /**
     * Process TriPay payment return.
     *
     * @since 1.0.0
     */
    private function process_tripay_return()
    {
        // Get order ID and merchant reference from URL.
        $order_id = isset($_GET["order_id"]) ? absint($_GET["order_id"]) : 0;
        $merchant_ref = isset($_GET["merchant_ref"])
            ? sanitize_text_field(wp_unslash($_GET["merchant_ref"]))
            : "";

        if ($order_id <= 0) {
            error_log("ViraStore TriPay Return: Invalid order ID: " . $order_id);
            wp_redirect(home_url());
            exit();
        }

        // Get order to verify it exists
        $order = $this->get_order($order_id);
        if (!$order) {
            error_log("ViraStore TriPay Return: Order not found: " . $order_id);
            wp_redirect(home_url());
            exit();
        }

        // Note: Don't automatically mark as completed - webhook handles that
        // This return handler just redirects to thank you page

        // Don't generate licenses here - webhook handles payment completion
        // License generation happens in webhook handler when payment status is PAID

        // Get thank you page URL
        $thank_you_page_id = get_option("vrstore_thank_you_page", 0);
        $thank_you_url = $thank_you_page_id ? get_permalink($thank_you_page_id) : null;
        
        if (empty($thank_you_url)) {
            // Fallback to home URL with order parameter
            $thank_you_url = add_query_arg(
                ["vrstore_order_id" => $order_id],
                home_url()
            );
        } else {
            // Add order ID to thank you page URL
            $thank_you_url = add_query_arg(
                ["vrstore_order_id" => $order_id],
                $thank_you_url
            );
        }

        // Ensure no output before redirect
        while (ob_get_level()) {
            ob_end_clean();
        }

        
        wp_redirect($thank_you_url, 302);
        exit();
    }

    /**
     * Save order to database.
     *
     * @since 1.0.0
     * @param array $order_data Order data.
     * @return int|false Order ID or false on failure.
     */
    private function save_order($order_data)
    {
        // Use the proper VRSTORE_Order::create_order method which handles both
        // the custom database table and post creation
        return VRSTORE_Order::create_order($order_data);
    }

    /**
     * Get order data.
     *
     * @since 1.0.0
     * @param int $order_id Order ID.
     * @return array|false Order data or false if not found.
     */
    private function get_order($order_id)
    {
        // Use the unified order system to get order data
        return VRSTORE_Order::get_order($order_id);
    }

    /**
     * Update order status.
     *
     * @since 1.0.0
     * @param int    $order_id Order ID.
     * @param string $status   New status.
     * @return bool True on success, false on failure.
     */
    private function update_order_status($order_id, $status)
    {
        // Use the unified order system to update order status
        return VRSTORE_Order::update_order_status($order_id, $status);
    }

    /**
     * Process successful payment webhook.
     *
     * @since 1.0.0
     * @param string $gateway      Payment gateway.
     * @param string $transaction_id Transaction ID.
     * @param string $status       Payment status.
     * @return bool True on success, false on failure.
     */
    public function process_successful_payment(
        $gateway,
        $transaction_id,
        $status,
    ) {
        global $wpdb;

        // In a real implementation, you would query your orders table to find the order.
        // For this example, we'll use a direct query to find the order by transaction ID.

        // Get all posts of type vrstore_order.
        $orders = get_posts([
            "post_type" => "vrstore_order",
            "post_status" => "publish",
            "numberposts" => -1,
        ]);

        // Find the order with matching transaction ID.
        $order_id = 0;
        foreach ($orders as $order) {
            $order_data = get_post_meta(
                $order->ID,
                "_vrstore_order_data",
                true,
            );
            if (
                $order_data &&
                isset($order_data["transaction_id"]) &&
                $order_data["transaction_id"] === $transaction_id
            ) {
                $order_id = $order->ID;
                break;
            }
        }

        // Check if order was found.
        if (!$order_id) {
            return false;
        }

        // Update order status.
        $this->update_order_status($order_id, $status);

        // If payment was successful, generate license key.
        if ("completed" === $status) {
            $order_data = $this->get_order($order_id);
            if ($order_data) {
                $license = VRSTORE_License::get_instance();

                // Handle cart items with license types or single product
                if (
                    isset($order_data["cart_items"]) &&
                    is_array($order_data["cart_items"])
                ) {
                    // Process each cart item
                    foreach ($order_data["cart_items"] as $cart_item) {
                        $license_type_slug = isset($cart_item["license_type"])
                            ? $cart_item["license_type"]
                            : "";
                        $license->generate_license_on_purchase(
                            $cart_item["product_id"],
                            $order_data["user_id"],
                            $license_type_slug,
                        );
                    }
                } else {
                    // Single product purchase (legacy)
                    $license->generate_license_on_purchase(
                        $order_data["product_id"],
                        $order_data["user_id"],
                    );
                }
            }
        }

        return true;
    }

    /**
     * Generate TriPay signature for API request
     *
     * @since 1.0.0
     * @param string $merchant_code TriPay merchant code
     * @param string $merchant_ref Merchant reference for the order
     * @param int    $amount Transaction amount
     * @param string $private_key TriPay private key
     * @return string Generated signature
     */
    private function generate_tripay_signature(
        $merchant_code,
        $merchant_ref,
        $amount,
        $private_key,
    ) {
        $payload = $merchant_code . $merchant_ref . (int) $amount;
        return hash_hmac("sha256", $payload, $private_key);
    }

    /**
     * Make HTTP request to TriPay API
     *
     * @since 1.0.0
     * @param string $url API endpoint URL
     * @param array  $data Request data
     * @param string $api_key TriPay API key
     * @param string $merchant_code TriPay merchant code
     * @param string $private_key TriPay private key
     * @return array|WP_Error Response data or error
     */
    private function make_tripay_request(
        $url,
        $data,
        $api_key,
        $merchant_code,
        $private_key,
    ) {
        $merchant_ref = isset($data["merchant_ref"])
            ? $data["merchant_ref"]
            : "";
        $amount = isset($data["amount"]) ? (int) $data["amount"] : 0;
        $signature = $this->generate_tripay_signature(
            $merchant_code,
            $merchant_ref,
            $amount,
            $private_key,
        );
        $data["signature"] = $signature;

        // Prepare headers
        $headers = [
            "Authorization" => "Bearer " . $api_key,
            "Content-Type" => "application/json",
            "X-Signature" => $signature,
        ];

        // Make POST request
        $response = wp_remote_post($url, [
            "timeout" => 30,
            "headers" => $headers,
            "body" => wp_json_encode($data),
            "data_format" => "body",
        ]);

        // Check for request error
        if (is_wp_error($response)) {
            return new WP_Error(
                "tripay_request_failed",
                $response->get_error_message(),
            );
        }

        // Get response code
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);

        // Decode JSON response
        $decoded_response = json_decode($response_body, true);

        // Check for HTTP errors
        if ($response_code !== 200) {
            $error_message = isset($decoded_response["message"])
                ? $decoded_response["message"]
                : "HTTP Error " . $response_code;
            
            // Enhanced error logging for transaction creation
            error_log(sprintf(
                'ViraStore TriPay API HTTP Error - Code: %s, Message: %s, Response: %s',
                $response_code,
                $error_message,
                substr($response_body, 0, 500)
            ));
            
            // Check if it's an IP whitelist error for transaction endpoint
            if ($response_code === 403 && (stripos($error_message, 'Unauthorized IP') !== false || stripos($error_message, 'Whitelist IP') !== false)) {
                error_log('ViraStore TriPay: IP whitelist error on transaction creation endpoint');
            }
            
            return new WP_Error("tripay_http_error", $error_message);
        }

        // Return decoded response
        return $decoded_response;
    }

    /**
     * Get server's public IP address
     * 
     * @since 1.0.0
     * @return string Public IP address
     */
    private function get_server_public_ip()
    {
        // Try multiple methods to get the actual public IP
        // Method 1: Check if we can get it from an external service (cached)
        $cached_ip = get_transient('vrstore_server_public_ip');
        if ($cached_ip !== false) {
            return $cached_ip;
        }
        
        // Method 2: Try to get from SERVER_ADDR (if it's a public IP)
        if (isset($_SERVER['SERVER_ADDR'])) {
            $server_addr = sanitize_text_field($_SERVER['SERVER_ADDR']);
            if (filter_var($server_addr, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                set_transient('vrstore_server_public_ip', $server_addr, DAY_IN_SECONDS);
                return $server_addr;
            }
        }
        
        // Method 3: Try to get from external service (non-blocking, cached)
        // Use a simple HTTP service to get public IP
        $response = wp_remote_get('https://api.ipify.org?format=json', [
            'timeout' => 3,
            'sslverify' => true
        ]);
        
        if (!is_wp_error($response)) {
            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);
            if (isset($data['ip']) && filter_var($data['ip'], FILTER_VALIDATE_IP)) {
                set_transient('vrstore_server_public_ip', $data['ip'], DAY_IN_SECONDS);
                return $data['ip'];
            }
        }
        
        // Fallback: return a placeholder with instructions
        return 'YOUR_SERVER_IP';
    }

    /**
     * Get TriPay setting from vrstore_settings array
     * Includes backward compatibility for old separate option names
     *
     * @since 1.0.0
     * @param string $key Setting key
     * @param mixed $default Default value
     * @return mixed Setting value
     */
    private function get_tripay_setting($key, $default = "")
    {
        $settings = get_option("vrstore_settings", []);
        
        // Check in vrstore_settings array first (new format)
        if (isset($settings[$key])) {
            return $settings[$key];
        }
        
        // Backward compatibility: check old separate option names
        $old_option_name = "vrstore_" . $key;
        $old_value = get_option($old_option_name, null);
        if ($old_value !== null) {
            // Migrate old value to new format for future use
            $settings[$key] = $old_value;
            update_option("vrstore_settings", $settings);
            return $old_value;
        }
        
        return $default;
    }

    /**
     * Get available TriPay payment channels
     *
     * @since 1.0.0
     * @return array|WP_Error Available payment channels or error
     */
    public function get_tripay_payment_channels()
    {
        // Get TriPay API settings from vrstore_settings array
        $test_mode = $this->get_tripay_setting("tripay_test_mode", "on") === "on";
        $api_key = $test_mode
            ? $this->get_tripay_setting("tripay_test_api_key", "")
            : $this->get_tripay_setting("tripay_live_api_key", "");

        // Enhanced debugging for configuration issues
        $settings = get_option("vrstore_settings", []);
        error_log(sprintf(
            'ViraStore TriPay: Configuration check - Test Mode: %s, API Key Present: %s, Mode: %s',
            $test_mode ? 'Yes' : 'No',
            !empty($api_key) ? 'Yes' : 'No',
            $test_mode ? 'Test' : 'Live'
        ));
        
        if (empty($api_key)) {
            // Log detailed debug information
            $key_name = $test_mode ? 'tripay_test_api_key' : 'tripay_live_api_key';
            error_log(sprintf(
                'ViraStore TriPay: API key missing - Looking for: %s, Settings keys available: %s',
                $key_name,
                implode(', ', array_keys($settings))
            ));
            return new WP_Error(
                "tripay_not_configured",
                $this->get_translated_text("TriPay API key not configured."),
            );
        }

        // API URL for getting payment channels
        $api_url = $test_mode
            ? "https://tripay.co.id/api-sandbox/merchant/payment-channel"
            : "https://tripay.co.id/api/merchant/payment-channel";

        // Make GET request
        $response = wp_remote_get($api_url, [
            "timeout" => 30,
            "headers" => [
                "Authorization" => "Bearer " . $api_key,
                "Content-Type" => "application/json",
            ],
        ]);

        if (is_wp_error($response)) {
            return $response;
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        $decoded_response = json_decode($response_body, true);

        if (
            $response_code !== 200 ||
            !isset($decoded_response["success"]) ||
            !$decoded_response["success"]
        ) {
            $error_message = isset($decoded_response["message"])
                ? $decoded_response["message"]
                : "Failed to get payment channels";
            
            // Check for IP whitelist error specifically
            $is_ip_whitelist_error = (
                $response_code === 403 || 
                stripos($error_message, 'Unauthorized IP') !== false ||
                stripos($error_message, 'Whitelist IP') !== false
            );
            
            // Enhanced error logging
            error_log(sprintf(
                'ViraStore TriPay: API Error - Code: %s, Message: %s, Response: %s',
                $response_code,
                $error_message,
                substr($response_body, 0, 200)
            ));
            
            // Store IP whitelist error flag temporarily (for checkout page display only)
            // Use transient that expires quickly - don't persist errors
            if ($is_ip_whitelist_error) {
                // Try to extract IP from error message (TriPay includes it)
                $detected_ip = 'unknown';
                if (preg_match('/IP \((.+?)\)/', $error_message, $matches)) {
                    $detected_ip = $matches[1];
                } else {
                    // Fallback: try to get server's public IP
                    $detected_ip = $this->get_server_public_ip();
                }
                
                // Store temporarily (expires in 5 minutes) - only for current request context
                set_transient('vrstore_tripay_ip_whitelist_error', [
                    'ip' => $detected_ip,
                    'timestamp' => time(),
                    'message' => $error_message,
                    'error_code' => $response_code
                ], 5 * MINUTE_IN_SECONDS);
            }
            
            // Return error with specific code for IP whitelist issues
            $error_code = $is_ip_whitelist_error ? "tripay_ip_whitelist_error" : "tripay_channels_error";
            return new WP_Error($error_code, $error_message);
        }
        
        // Clear IP whitelist error if API call succeeds
        delete_option('vrstore_tripay_ip_whitelist_error');
        delete_transient('vrstore_tripay_ip_whitelist_error');

        // Log successful API call
        if (isset($decoded_response["data"]) && is_array($decoded_response["data"])) {
            error_log(sprintf(
                'ViraStore TriPay: Successfully fetched %d payment channels',
                count($decoded_response["data"])
            ));
        }

        return $decoded_response["data"];
    }

    /**
     * AJAX handler to refresh TriPay payment channels
     * Clears error flag and retries fetching channels
     *
     * @since 1.0.0
     * @return void
     */
    public function ajax_refresh_tripay_channels()
    {
        // Verify nonce for security
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'vrstore_refresh_tripay_channels')) {
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
        }

        // Clear the error flag to force a fresh API call
        delete_option('vrstore_tripay_ip_whitelist_error');
        delete_transient('vrstore_tripay_ip_whitelist_error');
        
        // Clear cached public IP to get fresh detection
        delete_transient('vrstore_server_public_ip');
        
        // Try to fetch channels again
        $channels = $this->get_tripay_payment_channels(true);
        
        if (is_wp_error($channels)) {
            wp_send_json_error([
                'message' => $channels->get_error_message(),
                'code' => $channels->get_error_code()
            ]);
        } else {
            wp_send_json_success([
                'message' => __('Payment channels refreshed successfully!', 'vira-store'),
                'channels_count' => is_array($channels) ? count($channels) : 0
            ]);
        }
    }

    /**
     * Handle TriPay callback/webhook
     *
     * @since 1.0.0
     */
    public function handle_tripay_callback()
    {
        // Enhanced logging - webhook received
        // Get raw POST data
        $raw_post_data = file_get_contents("php://input");
        $callback_data = json_decode($raw_post_data, true);

        if (!$callback_data) {
            error_log('ViraStore TriPay Webhook Error: Invalid JSON data');
            http_response_code(400);
            echo "Invalid JSON data";
            exit();
        }

        // Verify callback signature - get from vrstore_settings array
        $test_mode = $this->get_tripay_setting("tripay_test_mode", "on") === "on";
        $private_key = $test_mode
            ? $this->get_tripay_setting("tripay_test_private_key", "")
            : $this->get_tripay_setting("tripay_live_private_key", "");

        $received_signature = isset($_SERVER["HTTP_X_CALLBACK_SIGNATURE"])
            ? $_SERVER["HTTP_X_CALLBACK_SIGNATURE"]
            : "";
        $calculated_signature = hash_hmac(
            "sha256",
            $raw_post_data,
            $private_key,
        );

        if ($received_signature !== $calculated_signature) {
            error_log(sprintf(
                'ViraStore TriPay Webhook Error: Invalid signature | Received: %s | Calculated: %s',
                substr($received_signature, 0, 20) . '...',
                substr($calculated_signature, 0, 20) . '...'
            ));
            http_response_code(401);
            echo "Invalid signature";
            exit();
        }


        // Process callback based on event type
        if (
            isset($callback_data["event"]) &&
            $callback_data["event"] === "payment_status"
        ) {
            $reference = $callback_data["reference"];
            $status = $callback_data["status"];
            $amount = $callback_data["amount"] ?? 0;

            // Update order status based on TriPay status
            switch ($status) {
                case "PAID":
                    error_log(sprintf(
                        'ViraStore TriPay: Payment PAID - Reference: %s, Amount: %d',
                        $reference,
                        $amount
                    ));
                    $order_id = $this->update_order_status_by_transaction_id(
                        $reference,
                        "completed",
                    );
                    if ($order_id) {
                        error_log(sprintf(
                            'ViraStore TriPay: Order #%d marked as completed, license generation triggered',
                            $order_id
                        ));
                    } else {
                        error_log(sprintf(
                            'ViraStore TriPay Warning: Order not found for reference: %s',
                            $reference
                        ));
                    }
                    break;
                case "EXPIRED":
                case "FAILED":
                    error_log(sprintf(
                        'ViraStore TriPay: Payment %s - Reference: %s',
                        $status,
                        $reference
                    ));
                    $this->update_order_status_by_transaction_id(
                        $reference,
                        "failed",
                    );
                    break;
                case "REFUND":
                    error_log(sprintf(
                        'ViraStore TriPay: Payment REFUNDED - Reference: %s, Amount: %d',
                        $reference,
                        $amount
                    ));
                    $this->update_order_status_by_transaction_id(
                        $reference,
                        "refunded",
                    );
                    break;
                default:
                    error_log(sprintf(
                        'ViraStore TriPay: Unknown payment status: %s for reference: %s',
                        $status,
                        $reference
                    ));
            }
        }

        // Send success response to TriPay
        http_response_code(200);
        echo "OK";
        exit();
    }

    /**
     * Update order status by transaction ID
     *
     * @since 1.0.0
     * @param string $transaction_id Transaction ID
     * @param string $status New status
     * @return int|false Order ID on success, false on failure
     */
    private function update_order_status_by_transaction_id(
        $transaction_id,
        $status,
    ) {
        global $wpdb;

        // Find order by transaction ID
        $postmeta_table = $wpdb->postmeta;
        $order_id = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT post_id FROM {$postmeta_table} WHERE meta_key = %s AND meta_value = %s",
                "_vrstore_transaction_id",
                $transaction_id,
            ),
        );

        if (!$order_id) {
            $order_id = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT post_id FROM {$postmeta_table} WHERE meta_key = %s AND meta_value = %s",
                    "transaction_id",
                    $transaction_id,
                ),
            );
        }

        if (!$order_id) {
            $orders_table = $wpdb->prefix . "vrstore_orders";
            if (
                $wpdb->get_var(
                    $wpdb->prepare("SHOW TABLES LIKE %s", $orders_table),
                ) === $orders_table
            ) {
                $order_id = $wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT id FROM {$orders_table} WHERE transaction_id = %s",
                        $transaction_id,
                    ),
                );
            }
        }

        if (!$order_id) {
            error_log(
                "ViraStore: Order not found for transaction ID: " .
                    $transaction_id,
            );
            return false;
        }

        $update_result = VRSTORE_Order::update_order_status((int) $order_id, $status);

        if ($update_result) {
            error_log(sprintf(
                'ViraStore: Order #%d status updated to "%s" for transaction: %s',
                $order_id,
                $status,
                $transaction_id
            ));
            return (int) $order_id;
        } else {
            error_log(sprintf(
                'ViraStore: Failed to update order #%d status for transaction: %s',
                $order_id,
                $transaction_id
            ));
            return false;
        }
    }

    /**
     * AJAX handler for TriPay payment processing
     *
     * @since 1.0.0
     */
    public function ajax_process_tripay_payment()
    {
        // Check nonce
        if (
            !isset($_POST["vrstore_checkout_nonce"]) ||
            !wp_verify_nonce(
                sanitize_text_field(
                    wp_unslash($_POST["vrstore_checkout_nonce"]),
                ),
                "vrstore_checkout",
            )
        ) {
            wp_send_json_error([
                "message" => $this->get_translated_text(
                    "Security check failed.",
                ),
            ]);
        }

        // Check if user is logged in
        if (!is_user_logged_in()) {
            wp_send_json_error([
                "message" => $this->get_translated_text(
                    "You must be logged in to make a purchase.",
                ),
            ]);
        }

        // Get form data
        $payment_method = isset($_POST["vrstore_payment_method"])
            ? sanitize_text_field(wp_unslash($_POST["vrstore_payment_method"]))
            : "";
        $tripay_method = isset($_POST["tripay_method"])
            ? sanitize_text_field(wp_unslash($_POST["tripay_method"]))
            : "";
        $customer_name = isset($_POST["vrstore_username"])
            ? sanitize_text_field(wp_unslash($_POST["vrstore_username"]))
            : "";
        $customer_email = isset($_POST["vrstore_email"])
            ? sanitize_email(wp_unslash($_POST["vrstore_email"]))
            : "";

        // Validate required fields
        if (empty($payment_method) || $payment_method !== "tripay") {
            wp_send_json_error([
                "message" => $this->get_translated_text(
                    "Invalid payment method.",
                ),
            ]);
        }

        if (empty($tripay_method)) {
            wp_send_json_error([
                "message" => $this->get_translated_text(
                    "Please select a TriPay payment method.",
                ),
            ]);
        }

        if (empty($customer_name) || empty($customer_email)) {
            wp_send_json_error([
                "message" => $this->get_translated_text(
                    "Please fill in all required fields.",
                ),
            ]);
        }

        // Get cart items
        $cart = VRSTORE_Cart::get_instance();
        $cart_items = $cart->get_cart();

        if (empty($cart_items)) {
            wp_send_json_error([
                "message" => $this->get_translated_text("Your cart is empty."),
            ]);
        }

        // Process the first cart item (assuming single item checkout for now)
        $cart_item = reset($cart_items);
        $product_id = $cart_item["product_id"];

        // Get product data
        try {
            $product_instance = VRSTORE_Product::get_instance();
            $product = $product_instance->get_product($product_id);
        } catch (Exception $e) {
            error_log('ViraStore TriPay Error: Exception getting product - ' . $e->getMessage());
            $product = false;
        } catch (Error $e) {
            error_log('ViraStore TriPay Error: Fatal error getting product - ' . $e->getMessage());
            $product = false;
        }
        
        if (!$product) {
            error_log('ViraStore TriPay Error: Product not found for ID: ' . $product_id);
            wp_send_json_error([
                "message" => $this->get_translated_text("Product not found."),
            ]);
        }

        // Get current currency from settings
        $settings = VRSTORE_Settings::get_instance();
        $current_currency = $settings->get_setting("currency", "USD");

        // Calculate totals with potential discount
        // Use cart's get_item_price() which handles license-based pricing correctly
        $price = $cart->get_item_price($cart_item);
        
        // If price is still 0, try to get from product license pricing
        if (empty($price) || $price <= 0) {
            if (!empty($cart_item["license_type"]) && class_exists("VRSTORE_License")) {
                $license_instance = VRSTORE_License::get_instance();
                $license_price = $license_instance->get_license_type_price(
                    intval($product_id),
                    $cart_item["license_type"],
                    'sale'
                );
                if ($license_price > 0) {
                    $price = $license_price;
                }
            }
        }
        
        // Final fallback to product price if still empty
        if (empty($price) || $price <= 0) {
            $price = $product["sale_price"] ? $product["sale_price"] : $product["price"];
        }
        
        // Validate price
        if (empty($price) || $price <= 0) {
            error_log('ViraStore TriPay Error: Price is still empty or zero after all attempts');
            wp_send_json_error([
                "message" => $this->get_translated_text(
                    "Unable to determine product price. Please contact support.",
                ),
            ]);
        }
        
        $discount_amount = $cart->get_discount_amount();
        $total = $price - $discount_amount;
        
        // Validate total
        if ($total <= 0) {
            error_log('ViraStore TriPay Error: Total is zero or negative: ' . $total);
            wp_send_json_error([
                "message" => $this->get_translated_text(
                    "Invalid order total. Please contact support.",
                ),
            ]);
        }
        
        $applied_coupon = $cart->get_applied_coupon();
        $coupon_code = "";

        if ($applied_coupon && $discount_amount > 0) {
            $coupon_code = $applied_coupon["code"];
        }

        // Create order data
        $order_data = [
            "product_id" => $product_id,
            "product_title" => $product["title"],
            "price" => $price,
            "total" => $total,
            "currency" => $current_currency,
            "customer_name" => $customer_name,
            "customer_email" => $customer_email,
            "payment_gateway" => "tripay",
            "payment_method" => "tripay",
            "tripay_method" => $tripay_method,
            "payment_channel" => $tripay_method,
            "user_id" => get_current_user_id(),
            "date" => current_time("mysql"),
            "status" => "pending",
            "cart_items" => [$cart_item],
        ];

        // Add coupon information if applicable
        if ($discount_amount > 0 && !empty($coupon_code)) {
            $order_data["discount_amount"] = $discount_amount;
            $order_data["coupon_code"] = $coupon_code;
        }

        // Process TriPay payment
        $result = $this->process_tripay_payment($order_data);

        // Enhanced error logging
        if (is_wp_error($result)) {
            error_log(sprintf(
                'ViraStore TriPay Error: %s (Code: %s)',
                $result->get_error_message(),
                $result->get_error_code()
            ));
            wp_send_json_error(["message" => $result->get_error_message()]);
        } elseif (!$result) {
            error_log('ViraStore TriPay Error: process_tripay_payment returned false/null');
            wp_send_json_error([
                "message" => $this->get_translated_text(
                    "Payment processing failed.",
                ),
            ]);
        } elseif (!isset($result["success"]) || !$result["success"]) {
            error_log('ViraStore TriPay Error: Result missing success flag. Result: ' . wp_json_encode($result));
            wp_send_json_error([
                "message" => $this->get_translated_text(
                    "Payment processing failed. Invalid response from payment gateway.",
                ),
            ]);
        } else {
            // Clear cart on successful payment initiation
            $cart->clear_cart();

            wp_send_json_success($result);
        }
    }
}
