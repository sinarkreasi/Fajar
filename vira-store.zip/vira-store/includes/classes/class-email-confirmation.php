<?php
/**
 * Email Confirmation Class for Vira Store
 *
 * Handles email confirmation functionality for user registration
 * and checkout processes.
 *
 * @package Vira_Store
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * VRSTORE_Email_Confirmation Class
 *
 * Manages email confirmation for user registration and checkout.
 *
 * @since 1.0.0
 */
class VRSTORE_Email_Confirmation {

    /**
     * Instance of this class.
     *
     * @since 1.0.0
     * @var object
     */
    private static $instance = null;

    /**
     * Database instance.
     *
     * @since 1.0.0
     * @var VRSTORE_Database
     */
    private $db;

    /**
     * Settings instance.
     *
     * @since 1.0.0
     * @var VRSTORE_Settings
     */
    private $settings;

    /**
     * Constructor.
     *
     * @since 1.0.0
     */
    private function __construct() {
        $this->db = VRSTORE_Database::get_instance();
        $this->settings = VRSTORE_Settings::get_instance();
        
        // Initialize hooks
        $this->init_hooks();
        
        // Schedule cleanup of expired confirmations
        $this->schedule_cleanup();
    }

    /**
     * Get instance of this class.
     *
     * @since 1.0.0
     * @return VRSTORE_Email_Confirmation
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        
        return self::$instance;
    }

    /**
     * Get translated text with fallback.
     *
     * @since 1.0.0
     * @param string $text Text to translate.
     * @return string
     */
    private function get_translated_text( $text ) {
        if ( vrstore_is_textdomain_ready() ) {
            return esc_html__( $text, 'vira-store' );
        }
        return esc_html( $text );
    }

    /**
     * Initialize hooks.
     *
     * @since 1.0.0
     * @return void
     */
    private function init_hooks() {
        // Handle confirmation requests
        add_action( 'template_redirect', array( $this, 'handle_confirmation_request' ) );
        
        // AJAX handlers
        add_action( 'wp_ajax_vrstore_resend_confirmation', array( $this, 'ajax_resend_confirmation' ) );
        add_action( 'wp_ajax_nopriv_vrstore_resend_confirmation', array( $this, 'ajax_resend_confirmation' ) );
        
        add_action( 'wp_ajax_vrstore_confirm_email_code', array( $this, 'ajax_confirm_email_code' ) );
        add_action( 'wp_ajax_nopriv_vrstore_confirm_email_code', array( $this, 'ajax_confirm_email_code' ) );
        
        // Hook into user registration
        add_action( 'vrstore_user_registered', array( $this, 'send_confirmation_email' ), 10, 2 );
        
        // Hook into checkout process
        add_action( 'vrstore_checkout_complete', array( $this, 'handle_checkout_confirmation' ), 10, 2 );
        
        // Scheduled cleanup
        add_action( 'vrstore_cleanup_email_confirmations', array( $this, 'cleanup_expired_confirmations' ) );
    }

    /**
     * Schedule cleanup of expired confirmations.
     *
     * @since 1.0.0
     * @return void
     */
    private function schedule_cleanup() {
        if ( ! wp_next_scheduled( 'vrstore_cleanup_email_confirmations' ) ) {
            wp_schedule_event( time(), 'daily', 'vrstore_cleanup_email_confirmations' );
        }
    }

    /**
     * Check if email confirmation is enabled.
     *
     * @since 1.0.0
     * @return bool
     */
    public function is_confirmation_enabled() {
        return $this->settings->get_setting( 'enable_email_confirmation' ) === 'on';
    }

    /**
     * Send confirmation email to user.
     *
     * @since 1.0.0
     * @param int    $user_id User ID.
     * @param string $email   Email address (optional).
     * @return bool
     */
    public function send_confirmation_email( $user_id, $email = '' ) {
        if ( ! $this->is_confirmation_enabled() ) {
            return false;
        }

        // Get user data
        $user = get_userdata( $user_id );
        if ( ! $user ) {
            return false;
        }

        $email = $email ?: $user->user_email;
        
        // Check if user already confirmed
        if ( $this->is_email_confirmed( $user_id ) ) {
            return false;
        }

        // Generate confirmation code
        $confirmation_code = $this->generate_confirmation_code();
        $confirmation_token = wp_generate_password( 32, false );
        
        // Get expiry hours
        $expiry_hours = intval( $this->settings->get_setting( 'email_confirmation_expiry', 24 ) );
        $expires_at = $expiry_hours > 0 ? date( 'Y-m-d H:i:s', time() + ( $expiry_hours * 3600 ) ) : null;
        
        // Store confirmation data
        $confirmation_id = $this->store_confirmation_data( $user_id, $email, $confirmation_code, $confirmation_token, $expires_at );
        
        if ( ! $confirmation_id ) {
            return false;
        }

        // Get delay setting
        $delay_minutes = intval( $this->settings->get_setting( 'email_confirmation_delay', 0 ) );
        
        if ( $delay_minutes > 0 ) {
            // Schedule email to be sent later
            wp_schedule_single_event( 
                time() + ( $delay_minutes * 60 ), 
                'vrstore_send_delayed_confirmation_email', 
                array( $confirmation_id ) 
            );
            
            // Add hook for delayed sending
            add_action( 'vrstore_send_delayed_confirmation_email', array( $this, 'send_delayed_confirmation_email' ) );
            
            return true;
        } else {
            // Send immediately
            return $this->send_confirmation_email_now( $confirmation_id );
        }
    }

    /**
     * Generate confirmation code.
     *
     * @since 1.0.0
     * @return string
     */
    private function generate_confirmation_code() {
        return strtoupper( wp_generate_password( 8, false ) );
    }

    /**
     * Store confirmation data in database.
     *
     * @since 1.0.0
     * @param int    $user_id           User ID.
     * @param string $email             Email address.
     * @param string $confirmation_code Confirmation code.
     * @param string $confirmation_token Confirmation token.
     * @param string $expires_at        Expiry datetime.
     * @return int|false Confirmation ID or false on failure.
     */
    private function store_confirmation_data( $user_id, $email, $confirmation_code, $confirmation_token, $expires_at ) {
        global $wpdb;
        
        $table_name = $this->db->get_table_name( 'email_confirmations' );
        
        // Delete any existing confirmation for this user
        $wpdb->delete( $table_name, array( 'user_id' => $user_id ), array( '%d' ) );
        
        // Insert new confirmation
        $result = $wpdb->insert(
            $table_name,
            array(
                'user_id' => $user_id,
                'email' => $email,
                'confirmation_code' => $confirmation_code,
                'confirmation_token' => $confirmation_token,
                'status' => 'pending',
                'expires_at' => $expires_at,
                'created_at' => current_time( 'mysql' ),
            ),
            array( '%d', '%s', '%s', '%s', '%s', '%s', '%s' )
        );
        
        return $result ? $wpdb->insert_id : false;
    }

    /**
     * Send confirmation email now.
     *
     * @since 1.0.0
     * @param int $confirmation_id Confirmation ID.
     * @return bool
     */
    public function send_confirmation_email_now( $confirmation_id ) {
        global $wpdb;
        
        $table_name = $this->db->get_table_name( 'email_confirmations' );
        
        // Get confirmation data
        $confirmation = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM $table_name WHERE id = %d AND status = 'pending'",
            $confirmation_id
        ), ARRAY_A );
        
        if ( ! $confirmation ) {
            return false;
        }

        // Get user data
        $user = get_userdata( $confirmation['user_id'] );
        if ( ! $user ) {
            return false;
        }

        // Prepare email content
        $confirmation_link = $this->get_confirmation_link( $confirmation['confirmation_token'] );
        $site_name = get_bloginfo( 'name' );
        
        $subject = $this->settings->get_setting( 'email_confirmation_subject', 'Please confirm your email address - {site_name}' );
        $body = $this->settings->get_setting( 'email_confirmation_body', 
            "Dear {customer_name},\n\nThank you for registering with {site_name}.\n\nTo complete your registration and activate your account, please click the link below:\n{confirmation_link}\n\nAlternatively, you can enter the confirmation code: {confirmation_code}\n\nIf you did not create this account, please ignore this email.\n\nRegards,\n{site_name}"
        );

        // Replace placeholders
        $replacements = array(
            '{site_name}' => $site_name,
            '{customer_name}' => $user->display_name ?: $user->user_login,
            '{confirmation_link}' => $confirmation_link,
            '{confirmation_code}' => $confirmation['confirmation_code'],
        );

        $subject = str_replace( array_keys( $replacements ), array_values( $replacements ), $subject );
        $body = str_replace( array_keys( $replacements ), array_values( $replacements ), $body );

        // Get email settings
        $from_name = $this->settings->get_setting( 'email_from_name', $site_name );
        $from_email = $this->settings->get_setting( 'email_from_email', get_bloginfo( 'admin_email' ) );

        // Set headers
        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $from_name . ' <' . $from_email . '>'
        );

        // Send email
        $sent = wp_mail( $confirmation['email'], $subject, nl2br( $body ), $headers );
        
        if ( $sent ) {
            // Update sent status
            $wpdb->update(
                $table_name,
                array( 'sent_at' => current_time( 'mysql' ) ),
                array( 'id' => $confirmation_id ),
                array( '%s' ),
                array( '%d' )
            );
        }

        return $sent;
    }

    /**
     * Send delayed confirmation email.
     *
     * @since 1.0.0
     * @param int $confirmation_id Confirmation ID.
     * @return void
     */
    public function send_delayed_confirmation_email( $confirmation_id ) {
        $this->send_confirmation_email_now( $confirmation_id );
    }

    /**
     * Get confirmation link.
     *
     * @since 1.0.0
     * @param string $token Confirmation token.
     * @return string
     */
    private function get_confirmation_link( $token ) {
        return add_query_arg(
            array(
                'vrstore_action' => 'confirm_email',
                'token' => $token,
            ),
            home_url()
        );
    }

    /**
     * Handle confirmation request.
     *
     * @since 1.0.0
     * @return void
     */
    public function handle_confirmation_request() {
        if ( ! isset( $_GET['vrstore_action'] ) || $_GET['vrstore_action'] !== 'confirm_email' ) {
            return;
        }

        $token = sanitize_text_field( $_GET['token'] ?? '' );
        if ( empty( $token ) ) {
            $this->show_confirmation_error( $this->get_translated_text( 'Invalid confirmation link.' ) );
            return;
        }

        $result = $this->confirm_email_by_token( $token );
        
        if ( $result['success'] ) {
            $this->show_confirmation_success( $result['message'] );
        } else {
            $this->show_confirmation_error( $result['message'] );
        }
    }

    /**
     * Confirm email by token.
     *
     * @since 1.0.0
     * @param string $token Confirmation token.
     * @return array
     */
    public function confirm_email_by_token( $token ) {
        global $wpdb;
        
        $table_name = $this->db->get_table_name( 'email_confirmations' );
        
        // Get confirmation data
        $confirmation = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM $table_name WHERE confirmation_token = %s AND status = 'pending'",
            $token
        ), ARRAY_A );
        
        if ( ! $confirmation ) {
            return array(
                'success' => false,
                'message' => $this->get_translated_text( 'Invalid or expired confirmation link.' )
            );
        }

        // Check expiry
        if ( $confirmation['expires_at'] && strtotime( $confirmation['expires_at'] ) < time() ) {
            return array(
                'success' => false,
                'message' => $this->get_translated_text( 'Confirmation link has expired. Please request a new one.' )
            );
        }

        // Update confirmation status
        $updated = $wpdb->update(
            $table_name,
            array(
                'status' => 'confirmed',
                'confirmed_at' => current_time( 'mysql' ),
            ),
            array( 'id' => $confirmation['id'] ),
            array( '%s', '%s' ),
            array( '%d' )
        );

        if ( ! $updated ) {
            return array(
                'success' => false,
                'message' => $this->get_translated_text( 'Failed to confirm email. Please try again.' )
            );
        }

        // Update user meta to mark email as confirmed
        update_user_meta( $confirmation['user_id'], 'vrstore_email_confirmed', true );
        update_user_meta( $confirmation['user_id'], 'vrstore_email_confirmed_at', current_time( 'mysql' ) );

        return array(
            'success' => true,
            'message' => $this->get_translated_text( 'Email confirmed successfully! Your account is now active.' ),
            'user_id' => $confirmation['user_id']
        );
    }

    /**
     * Confirm email by code.
     *
     * @since 1.0.0
     * @param string $code Confirmation code.
     * @param string $email Email address.
     * @return array
     */
    public function confirm_email_by_code( $code, $email ) {
        global $wpdb;
        
        $table_name = $this->db->get_table_name( 'email_confirmations' );
        
        // Get confirmation data
        $confirmation = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM $table_name WHERE confirmation_code = %s AND email = %s AND status = 'pending'",
            strtoupper( $code ),
            $email
        ), ARRAY_A );
        
        if ( ! $confirmation ) {
            return array(
                'success' => false,
                'message' => $this->get_translated_text( 'Invalid confirmation code or email address.' )
            );
        }

        // Check expiry
        if ( $confirmation['expires_at'] && strtotime( $confirmation['expires_at'] ) < time() ) {
            return array(
                'success' => false,
                'message' => $this->get_translated_text( 'Confirmation code has expired. Please request a new one.' )
            );
        }

        // Update confirmation status
        $updated = $wpdb->update(
            $table_name,
            array(
                'status' => 'confirmed',
                'confirmed_at' => current_time( 'mysql' ),
            ),
            array( 'id' => $confirmation['id'] ),
            array( '%s', '%s' ),
            array( '%d' )
        );

        if ( ! $updated ) {
            return array(
                'success' => false,
                'message' => $this->get_translated_text( 'Failed to confirm email. Please try again.' )
            );
        }

        // Update user meta
        update_user_meta( $confirmation['user_id'], 'vrstore_email_confirmed', true );
        update_user_meta( $confirmation['user_id'], 'vrstore_email_confirmed_at', current_time( 'mysql' ) );

        return array(
            'success' => true,
            'message' => $this->get_translated_text( 'Email confirmed successfully! Your account is now active.' ),
            'user_id' => $confirmation['user_id']
        );
    }

    /**
     * Check if email is confirmed.
     *
     * @since 1.0.0
     * @param int $user_id User ID.
     * @return bool
     */
    public function is_email_confirmed( $user_id ) {
        return (bool) get_user_meta( $user_id, 'vrstore_email_confirmed', true );
    }

    /**
     * Handle checkout confirmation.
     *
     * @since 1.0.0
     * @param int   $order_id Order ID.
     * @param array $order_data Order data.
     * @return void
     */
    public function handle_checkout_confirmation( $order_id, $order_data ) {
        if ( ! $this->is_confirmation_enabled() ) {
            return;
        }

        // Check if user was created during checkout
        if ( ! empty( $order_data['user_created'] ) && ! empty( $order_data['user_id'] ) ) {
            $this->send_confirmation_email( $order_data['user_id'], $order_data['customer_email'] );
        }
    }

    /**
     * Show confirmation success message.
     *
     * @since 1.0.0
     * @param string $message Success message.
     * @return void
     */
    private function show_confirmation_success( $message ) {
        $this->show_confirmation_message( $message, 'success' );
    }

    /**
     * Show confirmation error message.
     *
     * @since 1.0.0
     * @param string $message Error message.
     * @return void
     */
    private function show_confirmation_error( $message ) {
        $this->show_confirmation_message( $message, 'error' );
    }

    /**
     * Show confirmation message.
     *
     * @since 1.0.0
     * @param string $message Message text.
     * @param string $type    Message type (success/error).
     * @return void
     */
    private function show_confirmation_message( $message, $type = 'success' ) {
        $account_page_id = $this->settings->get_setting( 'account_page' );
        $redirect_url = $account_page_id ? get_permalink( $account_page_id ) : home_url();
        
        $redirect_url = add_query_arg( 
            array(
                'vrstore_confirmation_' . $type => urlencode( $message )
            ), 
            $redirect_url 
        );
        
        wp_redirect( $redirect_url );
        exit;
    }

    /**
     * AJAX handler for resending confirmation email.
     *
     * @since 1.0.0
     * @return void
     */
    public function ajax_resend_confirmation() {
        check_ajax_referer( 'vrstore_frontend_nonce', 'nonce' );

        $email = sanitize_email( $_POST['email'] ?? '' );
        if ( empty( $email ) ) {
            wp_send_json_error( array( 'message' => $this->get_translated_text( 'Email address is required.' ) ) );
        }

        $user = get_user_by( 'email', $email );
        if ( ! $user ) {
            wp_send_json_error( array( 'message' => $this->get_translated_text( 'User not found.' ) ) );
        }

        if ( $this->is_email_confirmed( $user->ID ) ) {
            wp_send_json_error( array( 'message' => $this->get_translated_text( 'Email is already confirmed.' ) ) );
        }

        $sent = $this->send_confirmation_email( $user->ID, $email );
        
        if ( $sent ) {
            wp_send_json_success( array( 'message' => $this->get_translated_text( 'Confirmation email sent successfully.' ) ) );
        } else {
            wp_send_json_error( array( 'message' => $this->get_translated_text( 'Failed to send confirmation email.' ) ) );
        }
    }

    /**
     * AJAX handler for confirming email with code.
     *
     * @since 1.0.0
     * @return void
     */
    public function ajax_confirm_email_code() {
        check_ajax_referer( 'vrstore_frontend_nonce', 'nonce' );

        $code = sanitize_text_field( $_POST['code'] ?? '' );
        $email = sanitize_email( $_POST['email'] ?? '' );

        if ( empty( $code ) || empty( $email ) ) {
            wp_send_json_error( array( 'message' => $this->get_translated_text( 'Code and email are required.' ) ) );
        }

        $result = $this->confirm_email_by_code( $code, $email );

        if ( $result['success'] ) {
            wp_send_json_success( $result );
        } else {
            wp_send_json_error( $result );
        }
    }

    /**
     * Cleanup expired confirmations.
     *
     * @since 1.0.0
     * @return void
     */
    public function cleanup_expired_confirmations() {
        global $wpdb;
        
        $table_name = $this->db->get_table_name( 'email_confirmations' );
        
        // Delete expired confirmations
        $wpdb->query(
            "DELETE FROM $table_name WHERE expires_at IS NOT NULL AND expires_at < NOW()"
        );
        
        // Delete old confirmed entries (keep for 30 days)
        $wpdb->query(
            "DELETE FROM $table_name WHERE status = 'confirmed' AND confirmed_at < DATE_SUB(NOW(), INTERVAL 30 DAY)"
        );
    }
}
