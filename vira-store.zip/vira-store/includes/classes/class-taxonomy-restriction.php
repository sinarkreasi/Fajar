<?php
/**
 * Taxonomy Restriction Class
 *
 * Handles taxonomy-based content restrictions with required purchase products/courses.
 * Allows administrators to set purchase requirements on taxonomy terms (categories, tags, etc.)
 * and restricts access to posts based on those taxonomy restrictions.
 *
 * @package Vira_Store
 * @since   1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Taxonomy Restriction Class
 */
class VRSTORE_Taxonomy_Restriction {

    /**
     * Single instance of the class
     *
     * @var VRSTORE_Taxonomy_Restriction
     */
    private static $instance = null;

    /**
     * Supported taxonomies for restrictions
     *
     * @var array
     */
    private $supported_taxonomies = [
        'category',
        'post_tag',
        'vrstore_product_cat',
        'vrstore_product_tag',
        'vrstore_course_cat',
        'vrstore_course_tag'
    ];

    /**
     * Get single instance of the class
     *
     * @return VRSTORE_Taxonomy_Restriction
     */
    public static function get_instance(): VRSTORE_Taxonomy_Restriction {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        $this->init_hooks();
    }

    /**
     * Initialize hooks
     *
     * @return void
     */
    private function init_hooks(): void {
        // Add taxonomy meta fields
        foreach ($this->supported_taxonomies as $taxonomy) {
            add_action("{$taxonomy}_add_form_fields", [$this, 'add_taxonomy_restriction_fields']);
            add_action("{$taxonomy}_edit_form_fields", [$this, 'edit_taxonomy_restriction_fields']);
            add_action("edited_{$taxonomy}", [$this, 'save_taxonomy_restriction_fields']);
            add_action("created_{$taxonomy}", [$this, 'save_taxonomy_restriction_fields']);
        }

        // Add admin columns
        foreach ($this->supported_taxonomies as $taxonomy) {
            add_filter("manage_edit-{$taxonomy}_columns", [$this, 'add_taxonomy_restriction_column']);
            add_filter("manage_{$taxonomy}_custom_column", [$this, 'display_taxonomy_restriction_column'], 10, 3);
        }

        // Filter content on frontend
        add_filter('the_content', [$this, 'filter_taxonomy_restricted_content'], 15);
        add_action('pre_get_posts', [$this, 'filter_taxonomy_restricted_posts']);

        // Add admin scripts and styles
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_scripts']);
    }

    /**
     * Add restriction fields to taxonomy add form
     *
     * @param string $taxonomy Current taxonomy slug
     * @return void
     */
    public function add_taxonomy_restriction_fields($taxonomy): void {
        ?>
        <div class="form-field term-restriction-wrap">
            <label for="vrstore_taxonomy_restricted">
                <?php echo vrstore_is_textdomain_ready() ? esc_html__('Content Restriction', 'vira-store') : 'Content Restriction'; ?>
            </label>
            <input type="checkbox" name="vrstore_taxonomy_restricted" id="vrstore_taxonomy_restricted" value="1">
            <p class="description">
                <?php echo vrstore_is_textdomain_ready() ? esc_html__('Enable content restriction for posts in this taxonomy', 'vira-store') : 'Enable content restriction for posts in this taxonomy'; ?>
            </p>
        </div>

        <div class="form-field term-restriction-settings" id="vrstore-taxonomy-restriction-settings" style="display: none;">
            <label for="vrstore_required_products">
                <?php echo vrstore_is_textdomain_ready() ? esc_html__('Required Products', 'vira-store') : 'Required Products'; ?>
            </label>
            <select name="vrstore_required_products[]" id="vrstore_required_products" multiple="multiple" style="width: 100%; height: 120px;">
                <?php $this->render_product_options(); ?>
            </select>
            <p class="description">
                <?php echo vrstore_is_textdomain_ready() ? esc_html__('Select products that users must purchase to access posts in this taxonomy', 'vira-store') : 'Select products that users must purchase to access posts in this taxonomy'; ?>
            </p>

            <label for="vrstore_required_courses">
                <?php echo vrstore_is_textdomain_ready() ? esc_html__('Required Courses', 'vira-store') : 'Required Courses'; ?>
            </label>
            <select name="vrstore_required_courses[]" id="vrstore_required_courses" multiple="multiple" style="width: 100%; height: 120px;">
                <?php $this->render_course_options(); ?>
            </select>
            <p class="description">
                <?php echo vrstore_is_textdomain_ready() ? esc_html__('Select courses that users must purchase to access posts in this taxonomy', 'vira-store') : 'Select courses that users must purchase to access posts in this taxonomy'; ?>
            </p>

            <label for="vrstore_restriction_message">
                <?php echo vrstore_is_textdomain_ready() ? esc_html__('Restriction Message', 'vira-store') : 'Restriction Message'; ?>
            </label>
            <textarea name="vrstore_restriction_message" id="vrstore_restriction_message" rows="4" style="width: 100%;" placeholder="<?php echo esc_attr__('This content is restricted. Please purchase the required products or courses to access it.', 'vira-store'); ?>"></textarea>
            <p class="description">
                <?php echo vrstore_is_textdomain_ready() ? esc_html__('Custom message to display when content is restricted', 'vira-store') : 'Custom message to display when content is restricted'; ?>
            </p>
        </div>
        <?php
    }

    /**
     * Add restriction fields to taxonomy edit form
     *
     * @param WP_Term $term Current term object
     * @return void
     */
    public function edit_taxonomy_restriction_fields($term): void {
        $restricted = get_term_meta($term->term_id, '_vrstore_taxonomy_restricted', true);
        $required_products = get_term_meta($term->term_id, '_vrstore_required_products', true) ?: [];
        $required_courses = get_term_meta($term->term_id, '_vrstore_required_courses', true) ?: [];
        $restriction_message = get_term_meta($term->term_id, '_vrstore_restriction_message', true);
        ?>
        <tr class="form-field term-restriction-wrap">
            <th scope="row">
                <label for="vrstore_taxonomy_restricted">
                    <?php echo vrstore_is_textdomain_ready() ? esc_html__('Content Restriction', 'vira-store') : 'Content Restriction'; ?>
                </label>
            </th>
            <td>
                <input type="checkbox" name="vrstore_taxonomy_restricted" id="vrstore_taxonomy_restricted" value="1" <?php checked($restricted, '1'); ?>>
                <p class="description">
                    <?php echo vrstore_is_textdomain_ready() ? esc_html__('Enable content restriction for posts in this taxonomy', 'vira-store') : 'Enable content restriction for posts in this taxonomy'; ?>
                </p>
            </td>
        </tr>

        <tr class="form-field term-restriction-settings" id="vrstore-taxonomy-restriction-settings" style="<?php echo $restricted ? '' : 'display: none;'; ?>">
            <th scope="row">
                <label for="vrstore_required_products">
                    <?php echo vrstore_is_textdomain_ready() ? esc_html__('Required Products', 'vira-store') : 'Required Products'; ?>
                </label>
            </th>
            <td>
                <select name="vrstore_required_products[]" id="vrstore_required_products" multiple="multiple" style="width: 100%; height: 120px;">
                    <?php $this->render_product_options($required_products); ?>
                </select>
                <p class="description">
                    <?php echo vrstore_is_textdomain_ready() ? esc_html__('Select products that users must purchase to access posts in this taxonomy', 'vira-store') : 'Select products that users must purchase to access posts in this taxonomy'; ?>
                </p>
            </td>
        </tr>

        <tr class="form-field term-restriction-settings">
            <th scope="row">
                <label for="vrstore_required_courses">
                    <?php echo vrstore_is_textdomain_ready() ? esc_html__('Required Courses', 'vira-store') : 'Required Courses'; ?>
                </label>
            </th>
            <td>
                <select name="vrstore_required_courses[]" id="vrstore_required_courses" multiple="multiple" style="width: 100%; height: 120px;">
                    <?php $this->render_course_options($required_courses); ?>
                </select>
                <p class="description">
                    <?php echo vrstore_is_textdomain_ready() ? esc_html__('Select courses that users must purchase to access posts in this taxonomy', 'vira-store') : 'Select courses that users must purchase to access posts in this taxonomy'; ?>
                </p>
            </td>
        </tr>

        <tr class="form-field term-restriction-settings">
            <th scope="row">
                <label for="vrstore_restriction_message">
                    <?php echo vrstore_is_textdomain_ready() ? esc_html__('Restriction Message', 'vira-store') : 'Restriction Message'; ?>
                </label>
            </th>
            <td>
                <textarea name="vrstore_restriction_message" id="vrstore_restriction_message" rows="4" style="width: 100%;" placeholder="<?php echo esc_attr__('This content is restricted. Please purchase the required products or courses to access it.', 'vira-store'); ?>"><?php echo esc_textarea($restriction_message); ?></textarea>
                <p class="description">
                    <?php echo vrstore_is_textdomain_ready() ? esc_html__('Custom message to display when content is restricted', 'vira-store') : 'Custom message to display when content is restricted'; ?>
                </p>
            </td>
        </tr>
        <?php
    }

    /**
     * Save taxonomy restriction fields
     *
     * @param int $term_id Term ID
     * @return void
     */
    public function save_taxonomy_restriction_fields($term_id): void {
        // Verify nonce if available
        if (isset($_POST['_wpnonce']) && !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_wpnonce'])), 'update-tag_' . $term_id)) {
            return;
        }

        // Save restriction status
        if (isset($_POST['vrstore_taxonomy_restricted'])) {
            update_term_meta($term_id, '_vrstore_taxonomy_restricted', '1');
        } else {
            delete_term_meta($term_id, '_vrstore_taxonomy_restricted');
        }

        // Save required products
        if (isset($_POST['vrstore_required_products']) && is_array($_POST['vrstore_required_products'])) {
            $required_products = array_map('intval', wp_unslash($_POST['vrstore_required_products']));
            update_term_meta($term_id, '_vrstore_required_products', $required_products);
        } else {
            delete_term_meta($term_id, '_vrstore_required_products');
        }

        // Save required courses
        if (isset($_POST['vrstore_required_courses']) && is_array($_POST['vrstore_required_courses'])) {
            $required_courses = array_map('intval', wp_unslash($_POST['vrstore_required_courses']));
            update_term_meta($term_id, '_vrstore_required_courses', $required_courses);
        } else {
            delete_term_meta($term_id, '_vrstore_required_courses');
        }

        // Save restriction message
        if (isset($_POST['vrstore_restriction_message'])) {
            $message = sanitize_textarea_field(wp_unslash($_POST['vrstore_restriction_message']));
            update_term_meta($term_id, '_vrstore_restriction_message', $message);
        } else {
            delete_term_meta($term_id, '_vrstore_restriction_message');
        }
    }

    /**
     * Add restriction column to taxonomy list table
     *
     * @param array $columns Existing columns
     * @return array Modified columns
     */
    public function add_taxonomy_restriction_column($columns): array {
        $columns['vrstore_restriction'] = vrstore_is_textdomain_ready() ? __('Restriction', 'vira-store') : 'Restriction';
        return $columns;
    }

    /**
     * Display restriction column content
     *
     * @param string $content Column content
     * @param string $column_name Column name
     * @param int $term_id Term ID
     * @return string Column content
     */
    public function display_taxonomy_restriction_column($content, $column_name, $term_id): string {
        if ($column_name === 'vrstore_restriction') {
            $restricted = get_term_meta($term_id, '_vrstore_taxonomy_restricted', true);
            if ($restricted) {
                $required_products = get_term_meta($term_id, '_vrstore_required_products', true) ?: [];
                $required_courses = get_term_meta($term_id, '_vrstore_required_courses', true) ?: [];
                
                $restrictions = [];
                if (!empty($required_products)) {
                    $restrictions[] = sprintf(
                        vrstore_is_textdomain_ready() ? __('%d Products', 'vira-store') : '%d Products',
                        count($required_products)
                    );
                }
                if (!empty($required_courses)) {
                    $restrictions[] = sprintf(
                        vrstore_is_textdomain_ready() ? __('%d Courses', 'vira-store') : '%d Courses',
                        count($required_courses)
                    );
                }
                
                if (!empty($restrictions)) {
                    $content = '<span class="vrstore-restriction-active" style="color: #d63638; font-weight: 600;">';
                    $content .= '<span class="dashicons dashicons-lock" style="font-size: 14px; vertical-align: middle;"></span> ';
                    $content .= implode(', ', $restrictions);
                    $content .= '</span>';
                } else {
                    $content = '<span style="color: #d63638;">' . (vrstore_is_textdomain_ready() ? __('Restricted (No Requirements)', 'vira-store') : 'Restricted (No Requirements)') . '</span>';
                }
            } else {
                $content = '<span style="color: #46b450;">' . (vrstore_is_textdomain_ready() ? __('Public', 'vira-store') : 'Public') . '</span>';
            }
        }
        return $content;
    }

    /**
     * Render product options for select dropdown
     *
     * @param array $selected_products Selected product IDs
     * @return void
     */
    private function render_product_options($selected_products = []): void {
        $products = get_posts([
            'post_type' => 'vrstore_product',
            'post_status' => 'publish',
            'numberposts' => -1,
            'orderby' => 'title',
            'order' => 'ASC'
        ]);

        foreach ($products as $product) {
            $selected = in_array($product->ID, $selected_products) ? 'selected="selected"' : '';
            echo '<option value="' . esc_attr($product->ID) . '" ' . $selected . '>' . esc_html($product->post_title) . '</option>';
        }
    }

    /**
     * Render course options for select dropdown
     *
     * @param array $selected_courses Selected course IDs
     * @return void
     */
    private function render_course_options($selected_courses = []): void {
        $courses = get_posts([
            'post_type' => 'vrstore_course',
            'post_status' => 'publish',
            'numberposts' => -1,
            'orderby' => 'title',
            'order' => 'ASC'
        ]);

        foreach ($courses as $course) {
            $selected = in_array($course->ID, $selected_courses) ? 'selected="selected"' : '';
            echo '<option value="' . esc_attr($course->ID) . '" ' . $selected . '>' . esc_html($course->post_title) . '</option>';
        }
    }

    /**
     * Filter content based on taxonomy restrictions
     *
     * @param string $content Post content
     * @return string Filtered content
     */
    public function filter_taxonomy_restricted_content($content): string {
        // Skip if in admin or not a single post
        if (is_admin() || !is_singular()) {
            return $content;
        }

        global $post;
        if (!$post) {
            return $content;
        }

        // Check if this post has taxonomy restrictions
        $has_taxonomy_restrictions = $this->post_has_taxonomy_restrictions($post->ID);
        
        if ($has_taxonomy_restrictions) {
            // Taxonomy restrictions override content restriction metabox
            // Remove the content restriction filter to prevent conflicts
            remove_filter('the_content', [$this->get_content_restriction_instance(), 'filter_restricted_content'], 20);
            
            // Check if user has access to this post based on taxonomy restrictions
            if (!$this->user_has_taxonomy_access($post->ID)) {
            // Get first 30 words of content for preview
            $content_preview = $this->get_content_preview($content, 30);
            $restriction_message = $this->get_taxonomy_restriction_message($post->ID);
            $required_items = $this->get_post_required_items($post->ID);
            
            $restricted_content = '<div class="vrstore-taxonomy-restricted-content">';
            
            // Content preview section
            if (!empty($content_preview)) {
                $restricted_content .= '<div class="vrstore-content-preview">';
                $restricted_content .= $content_preview;
                $restricted_content .= '<div class="vrstore-content-fade"></div>';
                $restricted_content .= '</div>';
            }
            
            // Restriction notice
            $restricted_content .= '<div class="vrstore-restriction-notice">';
            $restricted_content .= '<div class="vrstore-restriction-header">';
            $restricted_content .= '<span class="dashicons dashicons-lock"></span>';
            $restricted_content .= '<h4>' . (vrstore_is_textdomain_ready() ? __('Restricted Content', 'vira-store') : 'Restricted Content') . '</h4>';
            $restricted_content .= '</div>';
            $restricted_content .= '<p class="vrstore-restriction-message">' . esc_html($restriction_message) . '</p>';
            
            // Purchase buttons section
            if (!empty($required_items['products']) || !empty($required_items['courses'])) {
                $restricted_content .= '<div class="vrstore-purchase-options">';
                $restricted_content .= '<h5>' . (vrstore_is_textdomain_ready() ? __('Purchase Required:', 'vira-store') : 'Purchase Required:') . '</h5>';
                $restricted_content .= '<div class="vrstore-purchase-buttons">';
                
                // Add product purchase buttons
                foreach ($required_items['products'] as $product_id) {
                    $product = get_post($product_id);
                    if ($product) {
                        $product_price = get_post_meta($product_id, '_vrstore_price', true);
                        $currency = get_option('vrstore_currency', 'USD');
                        $currency_symbol = $this->get_currency_symbol($currency);
                        
                        $restricted_content .= '<div class="vrstore-purchase-item">';
                        $restricted_content .= '<div class="vrstore-item-info">';
                        $restricted_content .= '<span class="vrstore-item-type-badge vrstore-product-badge">Product</span>';
                        $restricted_content .= '<h6>' . esc_html($product->post_title) . '</h6>';
                        if ($product_price) {
                            $restricted_content .= '<span class="vrstore-item-price">' . esc_html($currency_symbol . $product_price) . '</span>';
                        }
                        $restricted_content .= '</div>';
                        $restricted_content .= '<a href="#" class="vrstore-btn vrstore-btn-primary vrstore-purchase-btn" data-product-id="' . esc_attr($product_id) . '">';
                        $restricted_content .= (vrstore_is_textdomain_ready() ? __('Purchase Product', 'vira-store') : 'Purchase Product');
                        $restricted_content .= '</a>';
                        $restricted_content .= '</div>';
                    }
                }
                
                // Add course purchase buttons
                foreach ($required_items['courses'] as $course_id) {
                    $course = get_post($course_id);
                    if ($course) {
                        $course_price = get_post_meta($course_id, '_vrstore_course_price', true);
                        $currency = get_option('vrstore_currency', 'USD');
                        $currency_symbol = $this->get_currency_symbol($currency);
                        
                        $restricted_content .= '<div class="vrstore-purchase-item">';
                        $restricted_content .= '<div class="vrstore-item-info">';
                        $restricted_content .= '<span class="vrstore-item-type-badge vrstore-course-badge">Course</span>';
                        $restricted_content .= '<h6>' . esc_html($course->post_title) . '</h6>';
                        if ($course_price) {
                            $restricted_content .= '<span class="vrstore-item-price">' . esc_html($currency_symbol . $course_price) . '</span>';
                        }
                        $restricted_content .= '</div>';
                        $restricted_content .= '<a href="#" class="vrstore-btn vrstore-btn-primary vrstore-purchase-btn" data-course-id="' . esc_attr($course_id) . '">';
                        $restricted_content .= (vrstore_is_textdomain_ready() ? __('Purchase Course', 'vira-store') : 'Purchase Course');
                        $restricted_content .= '</a>';
                        $restricted_content .= '</div>';
                    }
                }
                
                $restricted_content .= '</div>'; // .vrstore-purchase-buttons
                $restricted_content .= '</div>'; // .vrstore-purchase-options
            }
            
            $restricted_content .= '</div>'; // .vrstore-restriction-notice
            $restricted_content .= '</div>'; // .vrstore-taxonomy-restricted-content
            
            return $restricted_content;
            } else {
                // User has access - show full content including any restricted content from metabox
                $restricted_content = get_post_meta($post->ID, '_vrstore_restricted_content', true);
                if ($restricted_content) {
                    $content .= $this->render_unlocked_content($restricted_content);
                }
                return $content;
            }
        }

        return $content;
    }

    /**
     * Filter posts in queries based on taxonomy restrictions
     *
     * @param WP_Query $query Query object
     * @return void
     */
    public function filter_taxonomy_restricted_posts($query): void {
        // Skip if in admin, not main query, or user is logged in as admin
        if (is_admin() || !$query->is_main_query() || current_user_can('manage_options')) {
            return;
        }

        // Only filter on archive pages and home page
        if (!is_home() && !is_archive() && !is_search()) {
            return;
        }

        // Get current user's purchased products and courses
        $user_id = get_current_user_id();
        if (!$user_id) {
            return; // Let non-logged-in users see all posts for now
        }

        $user_products = $this->get_user_purchased_products($user_id);
        $user_courses = $this->get_user_purchased_courses($user_id);

        // Get all restricted taxonomy terms
        $restricted_terms = $this->get_all_restricted_terms();
        
        if (empty($restricted_terms)) {
            return;
        }

        // Build tax_query to exclude posts from restricted taxonomies the user doesn't have access to
        $tax_query = $query->get('tax_query') ?: [];
        
        foreach ($restricted_terms as $term_data) {
            $term_id = $term_data['term_id'];
            $taxonomy = $term_data['taxonomy'];
            $required_products = $term_data['required_products'];
            $required_courses = $term_data['required_courses'];
            
            // Check if user has access to this term
            $has_access = false;
            
            if (!empty($required_products)) {
                foreach ($required_products as $product_id) {
                    if (in_array($product_id, $user_products)) {
                        $has_access = true;
                        break;
                    }
                }
            }
            
            if (!$has_access && !empty($required_courses)) {
                foreach ($required_courses as $course_id) {
                    if (in_array($course_id, $user_courses)) {
                        $has_access = true;
                        break;
                    }
                }
            }
            
            // If user doesn't have access, exclude posts from this term
            if (!$has_access) {
                $tax_query[] = [
                    'taxonomy' => $taxonomy,
                    'field'    => 'term_id',
                    'terms'    => $term_id,
                    'operator' => 'NOT IN'
                ];
            }
        }
        
        if (!empty($tax_query)) {
            $tax_query['relation'] = 'AND';
            $query->set('tax_query', $tax_query);
        }
    }

    /**
     * Check if user has access to post based on taxonomy restrictions
     *
     * @param int $post_id Post ID
     * @return bool True if user has access, false otherwise
     */
    private function user_has_taxonomy_access($post_id): bool {
        $user_id = get_current_user_id();
        
        // Allow access for administrators
        if (current_user_can('manage_options')) {
            return true;
        }

        // Get all taxonomies for this post
        $post_taxonomies = get_object_taxonomies(get_post_type($post_id));
        
        foreach ($post_taxonomies as $taxonomy) {
            if (!in_array($taxonomy, $this->supported_taxonomies)) {
                continue;
            }
            
            $terms = wp_get_post_terms($post_id, $taxonomy, ['fields' => 'ids']);
            
            if (is_wp_error($terms) || empty($terms)) {
                continue;
            }
            
            foreach ($terms as $term_id) {
                $restricted = get_term_meta($term_id, '_vrstore_taxonomy_restricted', true);
                
                if (!$restricted) {
                    continue;
                }
                
                $required_products = get_term_meta($term_id, '_vrstore_required_products', true) ?: [];
                $required_courses = get_term_meta($term_id, '_vrstore_required_courses', true) ?: [];
                
                // If no requirements are set but restriction is enabled, deny access
                if (empty($required_products) && empty($required_courses)) {
                    return false;
                }
                
                // Check if user has purchased required products/courses
                if (!$this->user_has_required_purchases($user_id, $required_products, $required_courses)) {
                    return false;
                }
            }
        }
        
        return true;
    }

    /**
     * Get taxonomy restriction message for a post
     *
     * @param int $post_id Post ID
     * @return string Restriction message
     */
    private function get_taxonomy_restriction_message($post_id): string {
        $post_taxonomies = get_object_taxonomies(get_post_type($post_id));
        
        foreach ($post_taxonomies as $taxonomy) {
            if (!in_array($taxonomy, $this->supported_taxonomies)) {
                continue;
            }
            
            $terms = wp_get_post_terms($post_id, $taxonomy);
            
            if (is_wp_error($terms) || empty($terms)) {
                continue;
            }
            
            foreach ($terms as $term) {
                $restricted = get_term_meta($term->term_id, '_vrstore_taxonomy_restricted', true);
                
                if ($restricted) {
                    $message = get_term_meta($term->term_id, '_vrstore_restriction_message', true);
                    
                    if (!empty($message)) {
                        return $message;
                    }
                }
            }
        }
        
        return vrstore_is_textdomain_ready() ? 
            __('This content is restricted. Please purchase the required products or courses to access it.', 'vira-store') :
            'This content is restricted. Please purchase the required products or courses to access it.';
    }

    /**
     * Check if user has required purchases
     *
     * @param int $user_id User ID
     * @param array $required_products Required product IDs
     * @param array $required_courses Required course IDs
     * @return bool True if user has required purchases, false otherwise
     */
    private function user_has_required_purchases($user_id, $required_products = [], $required_courses = []): bool {
        if (empty($required_products) && empty($required_courses)) {
            return true;
        }
        
        $user_products = $this->get_user_purchased_products($user_id);
        $user_courses = $this->get_user_purchased_courses($user_id);
        
        // Check if user has any of the required products
        if (!empty($required_products)) {
            foreach ($required_products as $product_id) {
                if (in_array($product_id, $user_products)) {
                    return true;
                }
            }
        }
        
        // Check if user has any of the required courses
        if (!empty($required_courses)) {
            foreach ($required_courses as $course_id) {
                if (in_array($course_id, $user_courses)) {
                    return true;
                }
            }
        }
        
        return false;
    }

    /**
     * Get user's purchased products
     *
     * @param int $user_id User ID
     * @return array Array of purchased product IDs
     */
    private function get_user_purchased_products($user_id): array {
        global $wpdb;
        
        $products = $wpdb->get_col($wpdb->prepare("
            SELECT DISTINCT product_id 
            FROM {$wpdb->prefix}vrstore_orders 
            WHERE customer_id = %d 
            AND (payment_status = 'completed' OR order_status = 'completed')
        ", $user_id));
        
        return array_map('intval', $products ?: []);
    }

    /**
     * Get user's purchased courses
     *
     * @param int $user_id User ID
     * @return array Array of purchased course IDs
     */
    private function get_user_purchased_courses($user_id): array {
        // Get from course enrollments
        $enrolled_courses = get_user_meta($user_id, '_vrstore_enrolled_courses', true) ?: [];
        
        // Also get from course enrollments meta (alternative format)
        $course_enrollments = get_user_meta($user_id, '_vrstore_course_enrollments', true) ?: [];
        if (is_array($course_enrollments)) {
            foreach ($course_enrollments as $enrollment) {
                if (isset($enrollment['course_id'])) {
                    $enrolled_courses[] = $enrollment['course_id'];
                }
            }
        }
        
        // Get courses from completed purchases
        $purchased_courses = $this->get_user_purchased_products($user_id);
        $course_ids = [];
        
        foreach ($purchased_courses as $product_id) {
            $post_type = get_post_type($product_id);
            $is_course = ($post_type === 'vrstore_course') || get_post_meta($product_id, '_vrstore_is_course', true);
            
            if ($is_course) {
                $course_ids[] = $product_id;
            }
        }
        
        return array_unique(array_merge($enrolled_courses, $course_ids));
    }

    /**
     * Get all restricted taxonomy terms
     *
     * @return array Array of restricted term data
     */
    private function get_all_restricted_terms(): array {
        global $wpdb;
        
        $restricted_terms = [];
        
        foreach ($this->supported_taxonomies as $taxonomy) {
            $terms = $wpdb->get_results($wpdb->prepare("
                SELECT t.term_id, t.name, tt.taxonomy
                FROM {$wpdb->terms} t
                INNER JOIN {$wpdb->term_taxonomy} tt ON t.term_id = tt.term_id
                INNER JOIN {$wpdb->termmeta} tm ON t.term_id = tm.term_id
                WHERE tt.taxonomy = %s
                AND tm.meta_key = '_vrstore_taxonomy_restricted'
                AND tm.meta_value = '1'
            ", $taxonomy));
            
            foreach ($terms as $term) {
                $required_products = get_term_meta($term->term_id, '_vrstore_required_products', true) ?: [];
                $required_courses = get_term_meta($term->term_id, '_vrstore_required_courses', true) ?: [];
                
                $restricted_terms[] = [
                    'term_id' => $term->term_id,
                    'taxonomy' => $term->taxonomy,
                    'name' => $term->name,
                    'required_products' => $required_products,
                    'required_courses' => $required_courses
                ];
            }
        }
        
        return $restricted_terms;
    }

    /**
     * Get content preview with specified word count
     *
     * @param string $content Full content
     * @param int $word_count Number of words to show
     * @return string Content preview
     */
    private function get_content_preview($content, $word_count = 30): string {
        // Strip HTML tags and shortcodes
        $content = wp_strip_all_tags(strip_shortcodes($content));
        
        // Split into words
        $words = explode(' ', $content);
        
        // Get first N words
        if (count($words) > $word_count) {
            $preview_words = array_slice($words, 0, $word_count);
            return implode(' ', $preview_words) . '...';
        }
        
        return $content;
    }

    /**
     * Get required products and courses for a post
     *
     * @param int $post_id Post ID
     * @return array Array with 'products' and 'courses' keys
     */
    private function get_post_required_items($post_id): array {
        $required_items = [
            'products' => [],
            'courses' => []
        ];
        
        // Get all taxonomies for this post
        $post_taxonomies = get_object_taxonomies(get_post_type($post_id));
        
        foreach ($post_taxonomies as $taxonomy) {
            if (!in_array($taxonomy, $this->supported_taxonomies)) {
                continue;
            }
            
            $terms = wp_get_post_terms($post_id, $taxonomy, ['fields' => 'ids']);
            
            if (is_wp_error($terms) || empty($terms)) {
                continue;
            }
            
            foreach ($terms as $term_id) {
                $restricted = get_term_meta($term_id, '_vrstore_taxonomy_restricted', true);
                
                if (!$restricted) {
                    continue;
                }
                
                $required_products = get_term_meta($term_id, '_vrstore_required_products', true) ?: [];
                $required_courses = get_term_meta($term_id, '_vrstore_required_courses', true) ?: [];
                
                // Merge with existing requirements
                $required_items['products'] = array_unique(array_merge($required_items['products'], $required_products));
                $required_items['courses'] = array_unique(array_merge($required_items['courses'], $required_courses));
            }
        }
        
        return $required_items;
    }

    /**
     * Get currency symbol
     *
     * @param string $currency Currency code
     * @return string Currency symbol
     */
    private function get_currency_symbol($currency): string {
        $symbols = [
            'USD' => '$',
            'EUR' => '€',
            'GBP' => '£',
            'JPY' => '¥',
            'AUD' => 'A$',
            'CAD' => 'C$',
            'CHF' => 'CHF',
            'CNY' => '¥',
            'SEK' => 'kr',
            'NZD' => 'NZ$',
            'MXN' => '$',
            'SGD' => 'S$',
            'HKD' => 'HK$',
            'NOK' => 'kr',
            'PHP' => '₱',
            'DKK' => 'kr',
            'HUF' => 'Ft',
            'CZK' => 'Kč',
            'ILS' => '₪',
            'CLP' => '$',
            'PLN' => 'zł',
            'BRL' => 'R$',
            'TWD' => 'NT$',
            'THB' => '฿',
            'MYR' => 'RM',
            'TRY' => '₺',
            'RUB' => '₽',
            'INR' => '₹',
            'KRW' => '₩'
        ];
        
        return isset($symbols[$currency]) ? $symbols[$currency] : $currency;
    }

    /**
     * Enqueue admin scripts and styles
     *
     * @param string $hook_suffix Current admin page
     * @return void
     */
    public function enqueue_admin_scripts($hook_suffix): void {
        // Only load on taxonomy edit pages
        if (!in_array($hook_suffix, ['edit-tags.php', 'term.php'])) {
            return;
        }
        
        // Check if we're editing a supported taxonomy
        $taxonomy = isset($_GET['taxonomy']) ? sanitize_text_field(wp_unslash($_GET['taxonomy'])) : '';
        if (!in_array($taxonomy, $this->supported_taxonomies)) {
            return;
        }
        
        wp_enqueue_script(
            'vrstore-taxonomy-restriction-admin',
            VRSTORE_PLUGIN_URL . 'assets/js/taxonomy-restriction-admin.js',
            ['jquery'],
            VRSTORE_VERSION,
            true
        );
        
        wp_enqueue_style(
            'vrstore-taxonomy-restriction-admin',
            VRSTORE_PLUGIN_URL . 'assets/css/taxonomy-restriction-admin.css',
            [],
            VRSTORE_VERSION
        );
    }

    /**
     * Check if post has taxonomy restrictions
     *
     * @param int $post_id Post ID
     * @return bool True if post has taxonomy restrictions, false otherwise
     */
    private function post_has_taxonomy_restrictions($post_id): bool {
        $post_taxonomies = get_object_taxonomies(get_post_type($post_id));
        
        foreach ($post_taxonomies as $taxonomy) {
            if (!in_array($taxonomy, $this->supported_taxonomies)) {
                continue;
            }
            
            $terms = wp_get_post_terms($post_id, $taxonomy, ['fields' => 'ids']);
            
            if (is_wp_error($terms) || empty($terms)) {
                continue;
            }
            
            foreach ($terms as $term_id) {
                $restricted = get_term_meta($term_id, '_vrstore_taxonomy_restricted', true);
                if ($restricted) {
                    return true;
                }
            }
        }
        
        return false;
    }

    /**
     * Get content restriction instance
     *
     * @return VRSTORE_Content_Restriction Content restriction instance
     */
    private function get_content_restriction_instance(): VRSTORE_Content_Restriction {
        return VRSTORE_Content_Restriction::get_instance();
    }

    /**
     * Render unlocked content (similar to content restriction class)
     *
     * @param string $content Restricted content to render
     * @return string Rendered content
     */
    private function render_unlocked_content($content): string {
        if (empty($content)) {
            return '';
        }

        return '<div class="vrstore-unlocked-content">' . wp_kses_post($content) . '</div>';
    }
}

// Initialize the class
VRSTORE_Taxonomy_Restriction::get_instance();