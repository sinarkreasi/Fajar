<?php
/**
 * Checkout processing class
 *
 * @package Vira_Store
 */

// Exit if accessed directly
if (!defined("ABSPATH")) {
    exit();
}

/**
 * Checkout processing class
 */
class VRSTORE_Checkout
{
    /**
     * Singleton instance
     *
     * @var VRSTORE_Checkout|null
     */
    private static ?VRSTORE_Checkout $instance = null;

    /**
     * Get singleton instance
     *
     * @return VRSTORE_Checkout
     */
    public static function get_instance(): VRSTORE_Checkout
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Get translated text with conditional loading check.
     *
     * @since 1.0.0
     * @param string $text The text to translate.
     * @return string
     */
    private function get_translated_text($text)
    {
        if (is_textdomain_loaded("vira-store")) {
            return esc_html__($text, "vira-store");
        }
        return esc_html($text);
    }

    /**
     * Constructor
     */
    private function __construct()
    {
        $this->init();

        // Add very high priority filter to override login redirects during checkout
        add_filter(
            "login_redirect",
            [$this, "override_login_redirect_for_checkout"],
            1,
            3,
        );
    }

    /**
     * Initialize the class
     *
     * @return void
     */
    private function init(): void
    {
        // Add early hook to detect admin-post.php checkout requests
        add_action(
            "admin_post_vrstore_process_checkout",
            [$this, "disable_login_redirects_for_checkout"],
            1,
        );
        add_action(
            "admin_post_nopriv_vrstore_process_checkout",
            [$this, "disable_login_redirects_for_checkout"],
            1,
        );

        // Handle checkout form submission
        add_action("admin_post_vrstore_process_checkout", [
            $this,
            "process_checkout",
        ]);
        add_action("admin_post_nopriv_vrstore_process_checkout", [
            $this,
            "process_checkout",
        ]);

        // Handle AJAX customer check
        add_action("wp_ajax_vrstore_check_customer_exists", [
            $this,
            "ajax_check_customer_exists",
        ]);
        add_action("wp_ajax_nopriv_vrstore_check_customer_exists", [
            $this,
            "ajax_check_customer_exists",
        ]);

        // Handle AJAX nonce refresh for checkout
        add_action("wp_ajax_vrstore_refresh_checkout_nonce", [
            $this,
            "ajax_refresh_checkout_nonce",
        ]);
        add_action("wp_ajax_nopriv_vrstore_refresh_checkout_nonce", [
            $this,
            "ajax_refresh_checkout_nonce",
        ]);

        // Handle AJAX payment processing for TriPay
        add_action("wp_ajax_vrstore_process_tripay_payment", [
            $this,
            "ajax_process_tripay_payment",
        ]);
        add_action("wp_ajax_nopriv_vrstore_process_tripay_payment", [
            $this,
            "ajax_process_tripay_payment",
        ]);

        // Prevent WordPress login redirects during checkout processing
        add_action(
            "login_redirect",
            [$this, "prevent_login_redirect_during_checkout"],
            10,
            3,
        );
    }

    /**
     * Process checkout form submission
     *
     * @return void
     */
    public function process_checkout(): void
    {
        // Start output buffering immediately to prevent any output before redirect
        if (!ob_get_level()) {
            ob_start();
        }
        // Use session manager for centralized session handling
        if (class_exists("VRSTORE_Session_Manager")) {
            $session_manager = VRSTORE_Session_Manager::get_instance_if_needed();
            if ($session_manager) {
                $session_manager->set_session_data(
                    "vrstore_checkout_in_progress",
                    true,
                );
            }
        } else {
            // Fallback using global helper function
            vrstore_set_session_data("vrstore_checkout_in_progress", true);
        }

        // Set global constant flag for maximum reliability
        if (!defined("VRSTORE_CHECKOUT_IN_PROGRESS")) {
            define("VRSTORE_CHECKOUT_IN_PROGRESS", true);
        }

        // Enhanced nonce verification for security with comprehensive handling for existing customers
        $nonce_valid = false;
        $nonce_debug_info = [
            "timestamp" => date("Y-m-d H:i:s"),
            "user_logged_in" => is_user_logged_in(),
            "current_user_id" => get_current_user_id(),
            "user_agent" => $_SERVER["HTTP_USER_AGENT"] ?? "unknown",
            "ip_address" => $_SERVER["REMOTE_ADDR"] ?? "unknown",
        ];

        if (isset($_POST["vrstore_checkout_nonce"])) {
            $nonce = $_POST["vrstore_checkout_nonce"];
            $nonce_debug_info["submitted_nonce"] =
                substr($nonce, 0, 10) . "...";
            $nonce_debug_info["nonce_length"] = strlen($nonce);

            // Generate a fresh nonce for comparison
            $fresh_nonce = wp_create_nonce("vrstore_checkout");
            $nonce_debug_info["fresh_nonce"] =
                substr($fresh_nonce, 0, 10) . "...";
            $nonce_debug_info["nonce_tick"] = wp_nonce_tick();

            // Method 1: Try standard nonce verification
            $standard_verify = wp_verify_nonce($nonce, "vrstore_checkout");
            if ($standard_verify) {
                $nonce_valid = true;
                $nonce_debug_info["method"] = "standard";
                $nonce_debug_info["verify_result"] = $standard_verify;
            }
            // Method 2: For existing customers, try verification with explicit user context
            elseif (is_user_logged_in()) {
                $current_user_id = get_current_user_id();
                $nonce_debug_info["user_context_check"] = true;

                if ($current_user_id > 0) {
                    // Try verifying against the current tick explicitly
                    $current_tick_verify = wp_verify_nonce(
                        $nonce,
                        "vrstore_checkout",
                        wp_nonce_tick(),
                    );
                    if ($current_tick_verify) {
                        $nonce_valid = true;
                        $nonce_debug_info["method"] = "current_tick";
                        $nonce_debug_info[
                            "verify_result"
                        ] = $current_tick_verify;
                    }
                }
            }

            // Method 3: Check against previous tick (covers nonce lifetime overlap)
            if (!$nonce_valid) {
                $previous_tick_verify = wp_verify_nonce(
                    $nonce,
                    "vrstore_checkout",
                    wp_nonce_tick() - 1,
                );
                if ($previous_tick_verify) {
                    $nonce_valid = true;
                    $nonce_debug_info["method"] = "previous_tick";
                    $nonce_debug_info["verify_result"] = $previous_tick_verify;
                }
            }

            // Method 4: Final fallback - check if nonce was generated within reasonable timeframe
            if (!$nonce_valid) {
                // Try verifying with extended time range (2 previous ticks)
                $extended_verify = wp_verify_nonce(
                    $nonce,
                    "vrstore_checkout",
                    wp_nonce_tick() - 2,
                );
                if ($extended_verify) {
                    $nonce_valid = true;
                    $nonce_debug_info["method"] = "extended_tick";
                    $nonce_debug_info["verify_result"] = $extended_verify;
                    $nonce_debug_info["warning"] = "nonce_aged_but_valid";
                }
            }

            // Additional debugging info
            $nonce_debug_info["all_verify_attempts"] = [
                "standard" => $standard_verify,
                "current_tick" => $current_tick_verify ?? null,
                "previous_tick" => $previous_tick_verify ?? null,
                "extended_tick" => $extended_verify ?? null,
            ];
        } else {
            $nonce_debug_info["error"] = "no_nonce_submitted";
            $nonce_debug_info["post_keys"] = array_keys($_POST);
        }

        // Log nonce verification for debugging
        error_log(
            sprintf(
                $nonce_valid ? "true" : "false",
                json_encode($nonce_debug_info),
            ),
        );

        if (!$nonce_valid) {
            $redirect_url = add_query_arg(
                [
                    "vrstore_error" => urlencode(
                        $this->get_translated_text(
                            "Security check failed. Please try again.",
                        ),
                    ),
                ],
                wp_get_referer(),
            );
            wp_redirect($redirect_url);
            exit();
        }

        // Enhanced data handling for existing customers after login
        // Check if registration form data is provided (from the new unified flow)
        $reg_username = sanitize_text_field(
            $_POST["vrstore_reg_username"] ?? "",
        );
        $reg_email = sanitize_email($_POST["vrstore_reg_email"] ?? "");
        $reg_password = $_POST["vrstore_reg_password"] ?? "";

        // Use registration data if provided, otherwise use checkout data
        $username = !empty($reg_username)
            ? $reg_username
            : sanitize_text_field($_POST["vrstore_username"] ?? "");
        $email = !empty($reg_email)
            ? $reg_email
            : sanitize_email($_POST["vrstore_email"] ?? "");
        $password = !empty($reg_password)
            ? $reg_password
            : $_POST["vrstore_password"] ?? "";
        $payment_method = sanitize_text_field(
            $_POST["vrstore_payment_method"] ?? "",
        );

        // Special handling for logged-in users - use their data if form fields are empty
        if (is_user_logged_in()) {
            $current_user = wp_get_current_user();
            $current_user_id = $current_user->ID;

            // If username/email are empty, use logged-in user's data
            if (empty($username)) {
                $username = $current_user->user_login;
                error_log(
                    "ViraStore Checkout: Using logged-in user username: " .
                        $username,
                );
            }
            if (empty($email)) {
                $email = $current_user->user_email;
                error_log(
                    "ViraStore Checkout: Using logged-in user email: " . $email,
                );
            }

            // For logged-in users, password is not required for checkout
            $password = "";

            error_log(
                sprintf(
                    "ViraStore Checkout: Processing for logged-in user - ID: %d, Username: %s, Email: %s",
                    $current_user_id,
                    $username,
                    $email,
                ),
            );
        }

        // Check if customer already exists
        $existing_user = get_user_by("email", $email);

        // Enhanced validation for logged-in vs guest users
        $errors = [];
        $is_logged_in_user = is_user_logged_in();

        // Username validation - more lenient for logged-in users
        if (empty($username)) {
            if (!$is_logged_in_user) {
                $errors[] = $this->get_translated_text("Username is required.");
            } else {
                error_log(
                    "ViraStore Checkout Warning: Username empty for logged-in user, using fallback",
                );
            }
        }

        // Email validation - essential for all users
        if (empty($email) || !is_email($email)) {
            $errors[] = $this->get_translated_text(
                "Valid email address is required.",
            );
        } else {
            // Check for disposable email addresses (skip for logged-in users to avoid issues)
            if (
                !$is_logged_in_user &&
                class_exists("VRSTORE_Disposable_Email_Detector")
            ) {
                $disposable_detector = VRSTORE_Disposable_Email_Detector::get_instance();
                if (
                    $disposable_detector->is_blocking_enabled() &&
                    $disposable_detector->is_disposable_email($email)
                ) {
                    $errors[] = $disposable_detector->get_block_message();
                }
            }
        }

        // Password validation - skip for logged-in users
        if (!$is_logged_in_user) {
            if (!$existing_user) {
                // New customer - password is required
                if (empty($password) || strlen($password) < 6) {
                    $errors[] = $this->get_translated_text(
                        "Password must be at least 6 characters long.",
                    );
                }
            } else {
                // Existing customer - check login attempts limit before password verification
                if (!empty($password)) {
                    // Check login attempts limit before attempting authentication
                    if (class_exists("VRSTORE_Login_Attempts")) {
                        $login_attempts = VRSTORE_Login_Attempts::get_instance();
                        $attempt_check = $login_attempts->is_login_allowed(
                            $email,
                        );

                        if (!$attempt_check["allowed"]) {
                            $errors[] = $attempt_check["message"];
                        } else {
                            // Verify password only if login attempts are allowed
                            if (
                                !wp_check_password(
                                    $password,
                                    $existing_user->user_pass,
                                    $existing_user->ID,
                                )
                            ) {
                                // Record failed login attempt
                                $login_attempts->record_failed_login_attempt(
                                    $email,
                                );
                                $errors[] = $this->get_translated_text(
                                    "Incorrect password for existing account.",
                                );
                            }
                        }
                    } else {
                        // Fallback if Login Attempts class is not available
                        if (
                            !wp_check_password(
                                $password,
                                $existing_user->user_pass,
                                $existing_user->ID,
                            )
                        ) {
                            $errors[] = $this->get_translated_text(
                                "Incorrect password for existing account.",
                            );
                        }
                    }
                }
            }
        } else {
            error_log(
                "ViraStore Checkout: Skipping password validation for logged-in user",
            );
        }

        if (empty($payment_method)) {
            $errors[] = $this->get_translated_text(
                "Payment method is required.",
            );
        } else {
            // Validate that the selected payment method is enabled
            // Get enabled gateways from settings - handle both old and new formats
            $settings = get_option("vrstore_settings", []);
            $enabled_gateways = isset($settings["enabled_gateways"])
                ? $settings["enabled_gateways"]
                : get_option("vrstore_enabled_gateways", ["tripay" => "on"]);
            $enabled_gateway_keys = [];
            if (is_array($enabled_gateways)) {
                foreach ($enabled_gateways as $key => $value) {
                    if (
                        "on" === $value ||
                        true === $value ||
                        "1" === $value ||
                        1 === $value
                    ) {
                        $enabled_gateway_keys[] = $key;
                    }
                }
            }
            // Fallback to default if no gateways are enabled
            if (empty($enabled_gateway_keys)) {
                $enabled_gateway_keys = ["tripay"];
            }
            if (!in_array($payment_method, $enabled_gateway_keys, true)) {
                $errors[] = $this->get_translated_text(
                    "Selected payment method is not available.",
                );
            }
        }

        // Check if cart is not empty
        $cart = VRSTORE_Cart::get_instance();
        // Session is handled by session manager - no need to manually ensure
        $cart_items = $cart->get_cart();

        // Debug logging for cart status
        error_log(
            sprintf(
                "ViraStore Checkout Debug: Cart status - Items count: %d, Session status: %s, Cart items: %s",
                is_array($cart_items) ? count($cart_items) : 0,
                session_status() === PHP_SESSION_ACTIVE ? "Active" : "Inactive",
                is_array($cart_items) ? json_encode($cart_items) : "null",
            ),
        );

        if (empty($cart_items)) {
            // Try to get cart from cookies as fallback
            $cart_from_cookies = isset($_COOKIE["vrstore_cart_items"])
                ? json_decode(
                    stripslashes($_COOKIE["vrstore_cart_items"]),
                    true,
                )
                : null;

            error_log(
                sprintf(
                    "ViraStore Checkout Debug: Cart empty, checking cookies - Cookie data: %s",
                    $cart_from_cookies
                        ? json_encode($cart_from_cookies)
                        : "null",
                ),
            );

            if (!empty($cart_from_cookies) && is_array($cart_from_cookies)) {
                // Restore cart from cookies
                $cart_items = $cart_from_cookies;
                error_log(
                    "ViraStore Checkout Debug: Cart restored from cookies",
                );
            } else {
                $errors[] = $this->get_translated_text("Your cart is empty.");
            }
        }

        // If there are errors, redirect back with error messages
        if (!empty($errors)) {
            $error_message = implode("<br>", $errors);
            $redirect_url = add_query_arg(
                [
                    "vrstore_error" => urlencode($error_message),
                ],
                wp_get_referer(),
            );
            wp_redirect($redirect_url);
            exit();
        }

        // Create or get user account
        $account_result = $this->create_customer_account(
            $username,
            $email,
            $password,
        );

        if (is_wp_error($account_result)) {
            $redirect_url = add_query_arg(
                [
                    "vrstore_error" => urlencode(
                        $account_result->get_error_message(),
                    ),
                ],
                wp_get_referer(),
            );
            wp_redirect($redirect_url);
            exit();
        }

        $user_id = $account_result["user_id"];
        $account_created = $account_result["account_created"] ?? false;

        // Ensure checkout flags are set before login
        $_SESSION["vrstore_checkout_in_progress"] = true;
        if (!defined("VRSTORE_CHECKOUT_IN_PROGRESS")) {
            define("VRSTORE_CHECKOUT_IN_PROGRESS", true);
        }

        // Completely disable login redirect class during checkout
        $this->disable_login_redirect_during_checkout();

        // Always log the user in during checkout with improved cookie handling
        if (!is_user_logged_in() || get_current_user_id() != $user_id) {
            // Clear any existing authentication
            wp_clear_auth_cookie();

            // Set the current user
            wp_set_current_user($user_id);

            // Set authentication cookie with remember=true and secure settings
            wp_set_auth_cookie($user_id, true, is_ssl());

            // Ensure session is clean for future logins
            if (session_status() === PHP_SESSION_ACTIVE) {
                // Store minimal checkout data only
                $_SESSION["vrstore_last_login_method"] = "checkout";
                $_SESSION["vrstore_last_login_time"] = time();
            }

            // Delay wp_login action until after redirect is set up to prevent login redirect interference
            // We'll trigger this manually after the redirect is prepared
        }

        // Get currency from unified settings system
        $currency = "USD"; // Default fallback
        if (class_exists("VRSTORE_Settings")) {
            $settings_instance = VRSTORE_Settings::get_instance();
            $currency = $settings_instance->get_setting("currency", "USD");
            error_log(
                "ViraStore Checkout: Base currency from settings: {$currency}",
            );
        } else {
            // Fallback to legacy options
            $currency = get_option("vrstore_currency", "USD");
            if (empty($currency)) {
                $currency = sanitize_text_field(
                    $_POST["vrstore_currency"] ?? "USD",
                );
            }
            error_log("ViraStore Checkout: Using legacy currency: {$currency}");
        }

        // Also check what the currency converter thinks the user currency should be
        if (class_exists("VRSTORE_Currency_Converter")) {
            $currency_converter = VRSTORE_Currency_Converter::get_instance();
            $user_currency = $currency_converter->get_user_currency();
            error_log(
                "ViraStore Checkout: Currency converter user currency: {$user_currency}",
            );
        }

        // Check if cart contains Extended Support items - use their currency instead
        $extended_support_detected = false;
        foreach ($cart_items as $cart_item) {
            if (
                isset($cart_item["product_id"]) &&
                is_string($cart_item["product_id"]) &&
                strpos($cart_item["product_id"], "extended_support") === 0
            ) {
                $extended_support_detected = true;
                // Extended Support items have already-converted prices in their specified currency
                if (
                    isset($cart_item["currency"]) &&
                    !empty($cart_item["currency"])
                ) {
                    $currency = $cart_item["currency"];
                    error_log(
                        "ViraStore Checkout: Using Extended Support currency: {$currency}",
                    );
                    break; // Use the first Extended Support item's currency
                } else {
                    // Fallback: if Extended Support item doesn't have currency, use user currency
                    if (class_exists("VRSTORE_Currency_Converter")) {
                        $currency_converter = VRSTORE_Currency_Converter::get_instance();
                        $currency = $currency_converter->get_user_currency();
                        error_log(
                            "ViraStore Checkout: Extended Support fallback to user currency: {$currency}",
                        );
                    }
                    break;
                }
            }
        }

        // Calculate order totals with currency conversion handling
        $subtotal = $cart->get_cart_total();
        $discount_amount = $cart->get_discount_amount();
        $total = $cart->get_cart_total_with_discount();
        $applied_coupon = $cart->get_applied_coupon();

        // Ensure total is a valid numeric value (handle currency conversion issues)
        if (is_array($total)) {
            error_log(
                "ViraStore Checkout: Total is array, extracting numeric value: " .
                    print_r($total, true),
            );
            $total = is_numeric($total[0]) ? floatval($total[0]) : 0;
        } else {
            $total = floatval($total);
        }

        // Validate total amount
        if (!is_numeric($total) || $total <= 0) {
            error_log(
                "ViraStore Checkout ERROR: Invalid total amount: " .
                    var_export($total, true),
            );
            $redirect_url = add_query_arg(
                [
                    "vrstore_error" => urlencode(
                        $this->get_translated_text(
                            "Invalid order total. Please refresh your cart and try again.",
                        ),
                    ),
                ],
                wp_get_referer(),
            );
            wp_redirect($redirect_url);
            exit();
        }

        // Enhanced logging for Extended Support orders
        $has_extended_support = false;
        foreach ($cart_items as $cart_item) {
            if (
                isset($cart_item["product_id"]) &&
                is_string($cart_item["product_id"]) &&
                strpos($cart_item["product_id"], "extended_support") === 0
            ) {
                $has_extended_support = true;
                error_log(
                    sprintf(
                        "ViraStore Checkout Extended Support Item: product_id=%s, price=%s, currency=%s, price_already_converted=%s",
                        $cart_item["product_id"],
                        $cart_item["price"] ?? "null",
                        $cart_item["currency"] ?? "null",
                        isset($cart_item["price_already_converted"])
                            ? ($cart_item["price_already_converted"]
                                ? "true"
                                : "false")
                            : "null",
                    ),
                );
                break;
            }
        }

        error_log(
            sprintf(
                "ViraStore Checkout Debug: Has Extended Support: %s, Subtotal: %s, Total: %s, Currency: %s",
                $has_extended_support ? "yes" : "no",
                $subtotal,
                $total,
                $currency,
            ),
        );

        // Prepare order data
        $order_data = [
            "customer_name" => $username,
            "customer_email" => $email,
            "payment_method" => $payment_method,
            "user_id" => $user_id,
            "total" => $total,
            "currency" => $currency,
            "cart_items" => $cart_items,
            "status" => "pending",
            "payment_status" => "pending",
        ];

        // Add discount information if applicable
        if ($discount_amount > 0 && $applied_coupon) {
            $order_data["discount_amount"] = $discount_amount;
            $order_data["coupon_code"] = $applied_coupon["code"];
        }

        // Create order in database table with Extended Support logging
        error_log(
            sprintf(
                "ViraStore: Creating order - User ID: %d, Total: %s, Currency: %s, Payment Method: %s, Has Extended Support: %s",
                $user_id,
                $total,
                $currency,
                $payment_method,
                $has_extended_support ? "yes" : "no",
            ),
        );

        $order_id = VRSTORE_Order::create_order_in_database($order_data);

        if (!$order_id) {
            error_log(
                "ViraStore: Order creation failed - Order data: " .
                    json_encode($order_data),
            );
            $redirect_url = add_query_arg(
                [
                    "vrstore_error" => urlencode(
                        $this->get_translated_text(
                            "Failed to create order. Please try again.",
                        ),
                    ),
                ],
                wp_get_referer(),
            );
            wp_redirect($redirect_url);
            exit();
        }

        error_log(
            sprintf(
                "ViraStore: Order created successfully - Order ID: %d, User ID: %d, Total: %s",
                $order_id,
                $user_id,
                $total,
            ),
        );

        // Order created successfully

        // Store account creation info in session for thank you page
        if ($account_created) {
            // Use session manager to set checkout completed flag
            if (class_exists("VRSTORE_Session_Manager")) {
                $session_manager = VRSTORE_Session_Manager::get_instance_if_needed();
                if ($session_manager) {
                    $session_manager->set_session_data(
                        "vrstore_checkout_completed",
                        true,
                    );
                }
            } else {
                // Fallback using global helper function
                vrstore_set_session_data("vrstore_checkout_completed", true);
            }
        }

        // Clear checkout in progress flag since we're about to redirect
        // Clear checkout session data using session manager
        if (class_exists("VRSTORE_Session_Manager")) {
            $session_manager = VRSTORE_Session_Manager::get_instance_if_needed();
            if ($session_manager) {
                $session_manager->set_session_data(
                    "vrstore_checkout_in_progress",
                    null,
                );
                $session_manager->set_session_data(
                    "vrstore_login_attempts",
                    null,
                );
            }
        } elseif (session_status() === PHP_SESSION_ACTIVE) {
            // Fallback to direct session access
            if (isset($_SESSION["vrstore_checkout_in_progress"])) {
                unset($_SESSION["vrstore_checkout_in_progress"]);
            }

            // Clear any stale login-related session data that might interfere
            if (isset($_SESSION["vrstore_login_attempts"])) {
                unset($_SESSION["vrstore_login_attempts"]);
            }
        }

        // Process payment based on method - pass user_id for login action
        $this->process_payment(
            $order_id,
            $payment_method,
            $_POST,
            $account_created,
            $user_id,
            $cart_items,
            $total,
            $currency,
        );
    }

    /**
     * Create customer account automatically
     *
     * @param string $username Customer username
     * @param string $email Customer email
     * @param string $password Customer password (optional for existing customers)
     * @return int|WP_Error User ID on success, WP_Error on failure
     */
    private function create_customer_account(
        string $username,
        string $email,
        string $password,
    ) {
        // Check if user already exists
        $existing_user = get_user_by("email", $email);

        if ($existing_user) {
            // For existing users, password verification is optional
            if (!empty($password)) {
                // If password is provided, verify it
                if (
                    !wp_check_password(
                        $password,
                        $existing_user->user_pass,
                        $existing_user->ID,
                    )
                ) {
                    return new WP_Error(
                        "invalid_credentials",
                        __(
                            "Incorrect password for existing account.",
                            "vira-store",
                        ),
                    );
                }
            }
            // Update display name if different
            $update_needed = false;
            $update_data = ["ID" => $existing_user->ID];

            if ($existing_user->display_name !== $username) {
                $update_data["display_name"] = $username;
                $update_needed = true;
            }

            if ($update_needed) {
                wp_update_user($update_data);
            }

            // Ensure customer role is assigned
            $user = new WP_User($existing_user->ID);
            if (!in_array("customer", $user->roles)) {
                $user->add_role("customer");
            }

            return [
                "user_id" => $existing_user->ID,
                "account_created" => false,
            ];
        }

        // Generate username from email
        $generated_username = $this->generate_username($email);

        // Log account creation attempt for debugging
        error_log(sprintf($email, $generated_username));

        // Create new user
        $user_data = [
            "user_login" => $generated_username,
            "user_email" => $email,
            "user_pass" => $password,
            "display_name" => $generated_username,
            "role" => "customer",
        ];

        $user_id = wp_insert_user($user_data);

        if (is_wp_error($user_id)) {
            error_log(
                sprintf(
                    "ViraStore: Failed to create customer account - Error: %s, Email: %s, Username: %s",
                    $user_id->get_error_message(),
                    $email,
                    $generated_username,
                ),
            );
            return $user_id;
        }

        // Log successful account creation
        error_log(sprintf($user_id, $email, $generated_username));

        // Send email confirmation if enabled
        if (class_exists("VRSTORE_Email_Confirmation")) {
            $email_confirmation = VRSTORE_Email_Confirmation::get_instance();
            if ($email_confirmation->is_confirmation_enabled()) {
                $email_confirmation->send_confirmation_email(
                    $user_id,
                    "checkout",
                );
            } else {
                // Send welcome email only if confirmation is disabled
                $this->send_welcome_email($user_id, $email, $username);
            }
        } else {
            // Send welcome email (fallback)
            $this->send_welcome_email($user_id, $email, $username);
        }

        return [
            "user_id" => $user_id,
            "account_created" => true,
        ];
    }

    /**
     * Generate unique username from email
     *
     * @param string $email Email address
     * @return string
     */
    private function generate_username(string $email): string
    {
        // Extract username part from email
        $email_parts = explode("@", $email);
        $base_username = sanitize_user($email_parts[0]);

        // Ensure minimum length
        if (strlen($base_username) < 3) {
            $base_username = "customer_" . $base_username;
        }

        // Remove any remaining invalid characters
        $base_username = preg_replace("/[^a-zA-Z0-9_-]/", "", $base_username);

        // If username is empty after sanitization, use a default
        if (empty($base_username)) {
            $base_username = "customer";
        }

        // Ensure username is unique
        $username = $base_username;
        $counter = 1;
        $max_attempts = 100; // Prevent infinite loops

        while (username_exists($username) && $counter <= $max_attempts) {
            $username = $base_username . "_" . $counter;
            $counter++;
        }

        // Final fallback if all attempts failed
        if (username_exists($username)) {
            $username = "customer_" . time() . "_" . wp_rand(100, 999);
        }

        return $username;
    }

    /**
     * Send welcome email to new customer
     *
     * @param int $user_id User ID
     * @param string $email Email address
     * @param string $username Username
     * @return void
     */
    private function send_welcome_email(
        int $user_id,
        string $email,
        string $username,
    ): void {
        $subject = sprintf(
            __("Welcome to %s!", "vira-store"),
            get_bloginfo("name"),
        );

        $message = sprintf(
            __(
                'Hello %s,\n\nWelcome to %s! Your account has been created successfully.\n\nYou can now log in to your account to view your orders and manage your profile.\n\nThank you for choosing us!\n\nBest regards,\n%s Team',
                "vira-store",
            ),
            $username,
            get_bloginfo("name"),
            get_bloginfo("name"),
        );

        wp_mail($email, $subject, $message);
    }

    /**
     * Process payment based on selected method
     *
     * @param int $order_id Order ID
     * @param string $payment_method Payment method
     * @param array $form_data Form data
     * @param bool $account_created Whether account was created during checkout
     * @param int $user_id User ID for delayed login action
     * @return void
     */
    private function process_payment(
        int $order_id,
        string $payment_method,
        array $form_data,
        bool $account_created = false,
        int $user_id = 0,
        array $cart_items = [],
        float $order_total = 0.0,
        string $currency = "USD",
    ): void {
        switch ($payment_method) {
            case "tripay":
                $this->process_tripay_payment(
                    $order_id,
                    $form_data,
                    $account_created,
                    $user_id,
                    $cart_items,
                    $order_total,
                    $currency,
                );
                break;

            case "paypal":
                $this->process_paypal_payment(
                    $order_id,
                    $form_data,
                    $account_created,
                    $user_id,
                    $cart_items,
                    $order_total,
                    $currency,
                );
                break;

            case "xendit":
                $this->process_xendit_payment(
                    $order_id,
                    $form_data,
                    $account_created,
                    $user_id,
                    $cart_items,
                    $order_total,
                    $currency,
                );
                break;

            case "manual":
                $this->process_manual_payment(
                    $order_id,
                    $account_created,
                    $user_id,
                );
                break;

            case "moota":
                $this->process_moota_payment(
                    $order_id,
                    $form_data,
                    $account_created,
                    $user_id,
                    $cart_items,
                    $order_total,
                    $currency,
                );
                break;

            default:
                // Invalid payment method
                $redirect_url = add_query_arg(
                    [
                        "vrstore_error" => urlencode(
                            __(
                                "Invalid payment method selected.",
                                "vira-store",
                            ),
                        ),
                    ],
                    wp_get_referer(),
                );
                wp_redirect($redirect_url);
                exit();
        }
    }

    /**
     * Process TriPay payment
     *
     * @param int $order_id Order ID
     * @param array $form_data Form data
     * @param bool $account_created Whether account was created during checkout
     * @param int $user_id User ID for delayed login action
     * @return void
     */
    private function process_tripay_payment(
        int $order_id,
        array $form_data,
        bool $account_created = false,
        int $user_id = 0,
        array $cart_items = [],
        float $order_total = 0.0,
        string $currency = "USD",
    ): void {
        $selected_method = isset($form_data["vrstore_tripay_method"])
            ? sanitize_text_field($form_data["vrstore_tripay_method"])
            : "";
        if (empty($selected_method) && isset($form_data["tripay_method"])) {
            $selected_method = sanitize_text_field($form_data["tripay_method"]);
        }

        if (empty($cart_items)) {
            $order = VRSTORE_Order::get_order($order_id);
            if ($order && !empty($order["cart_items"])) {
                $cart_items = $order["cart_items"];
            }
        }

        if ($order_total <= 0) {
            $order = isset($order)
                ? $order
                : VRSTORE_Order::get_order($order_id);
            if ($order && isset($order["total"])) {
                $order_total = floatval($order["total"]);
            }
        }

        if (empty($selected_method)) {
            $this->redirect_with_error(
                $this->get_translated_text(
                    "Please select a TriPay payment channel.",
                ),
            );
        }

        if (class_exists("VRSTORE_Payment")) {
            $payment = VRSTORE_Payment::get_instance();
            if (method_exists($payment, "process_tripay_payment")) {
                $payment_payload = [
                    "order_id" => $order_id,
                    "customer_name" => sanitize_text_field(
                        $form_data["vrstore_username"] ??
                            ($form_data["customer_name"] ?? ""),
                    ),
                    "customer_email" => sanitize_email(
                        $form_data["vrstore_email"] ??
                            ($form_data["customer_email"] ?? ""),
                    ),
                    "customer_phone" => sanitize_text_field(
                        $form_data["vrstore_phone"] ??
                            ($form_data["customer_phone"] ?? ""),
                    ),
                    "total" => $order_total,
                    "currency" => $currency,
                    "cart_items" => $cart_items,
                    "tripay_method" => $selected_method,
                    "payment_channel" => $selected_method,
                ];

                $result = $payment->process_tripay_payment($payment_payload);

                if (is_wp_error($result)) {
                    VRSTORE_Order::update_payment_status($order_id, "failed");
                    $this->redirect_with_error($result->get_error_message());
                }

                // Validate redirect URL before redirecting
                if (empty($result["redirect_url"])) {
                    error_log(
                        "ViraStore Checkout: TriPay returned empty redirect_url for order: " . $order_id
                    );
                    $this->redirect_to_confirmation(
                        $order_id,
                        $this->get_translated_text(
                            "TriPay payment initiated. Please complete your payment to finalize the order.",
                        ),
                        $account_created,
                        $user_id,
                    );
                    return;
                }

                // Validate redirect URL
                $redirect_url = $result["redirect_url"];
                if (!wp_http_validate_url($redirect_url)) {
                    error_log(
                        "ViraStore Checkout ERROR: TriPay returned invalid redirect URL: " . $redirect_url
                    );
                    // Try to use checkout_url as fallback
                    if (!empty($result["checkout_url"]) && wp_http_validate_url($result["checkout_url"])) {
                        $redirect_url = $result["checkout_url"];
                        error_log(
                            "ViraStore Checkout: Using checkout_url as fallback: " . $redirect_url
                        );
                    } else {
                        // Last resort - redirect to confirmation page
                        $this->redirect_to_confirmation(
                            $order_id,
                            $this->get_translated_text(
                                "TriPay payment initiated. Please check your email for payment instructions.",
                            ),
                            $account_created,
                            $user_id,
                        );
                        return;
                    }
                }

                // Clear cart before redirect (payment initiated successfully)
                $cart = VRSTORE_Cart::get_instance();
                $cart->clear_cart();

                // Ensure no output before redirect
                while (ob_get_level()) {
                    ob_end_clean();
                }

                // Check if headers already sent
                if (headers_sent($file, $line)) {
                    error_log(
                        "ViraStore Checkout ERROR: Headers already sent in {$file} on line {$line}. Using JavaScript redirect."
                    );
                    echo '<script type="text/javascript">window.location.href = "' . esc_js($redirect_url) . '";</script>';
                    echo '<noscript><meta http-equiv="refresh" content="0;url=' . esc_url($redirect_url) . '"></noscript>';
                    exit();
                }

                error_log(
                    "ViraStore Checkout: Redirecting to TriPay payment page - URL: " . $redirect_url . ", Order ID: " . $order_id
                );

                wp_redirect($redirect_url, 302);
                exit();
            }
        }

        error_log(
            "ViraStore: TriPay payment handler unavailable, falling back for order " .
                $order_id,
        );
        $this->redirect_with_error(
            $this->get_translated_text(
                "Payment processing failed. Please try again.",
            ),
        );
    }

    /**
     * Redirect with error message
     *
     * @param string $error_message Error message
     * @return void
     */
    private function redirect_with_error(string $error_message): void
    {
        $redirect_url = add_query_arg(
            [
                "vrstore_error" => urlencode($error_message),
            ],
            wp_get_referer() ?: home_url(),
        );

        wp_redirect($redirect_url);
        exit();
    }

    /**
     * Process PayPal payment
     *
     * @param int $order_id Order ID
     * @param array $form_data Form data
     * @param bool $account_created Whether account was created during checkout
     * @param int $user_id User ID for delayed login action
     * @return void
     */
    private function process_paypal_payment(
        int $order_id,
        array $form_data,
        bool $account_created = false,
        int $user_id = 0,
        array $cart_items = [],
        float $order_total = 0.0,
        string $currency = "USD",
    ): void {
        $order_snapshot = VRSTORE_Order::get_order($order_id);
        if ($order_snapshot && !empty($order_snapshot["currency"])) {
            $currency = $order_snapshot["currency"];
        }
        if (
            empty($cart_items) &&
            $order_snapshot &&
            !empty($order_snapshot["cart_items"])
        ) {
            $cart_items = $order_snapshot["cart_items"];
        }
        if (
            $order_total <= 0 &&
            $order_snapshot &&
            isset($order_snapshot["total"])
        ) {
            $order_total = floatval($order_snapshot["total"]);
        }

        $customer_name = sanitize_text_field(
            $form_data["vrstore_username"] ??
                ($form_data["customer_name"] ??
                    ($order_snapshot["customer_name"] ?? "")),
        );
        $customer_email = sanitize_email(
            $form_data["vrstore_email"] ??
                ($form_data["customer_email"] ??
                    ($order_snapshot["customer_email"] ?? "")),
        );

        // Delegate to PayPal addon if available
        if (class_exists("ViraStore_PayPal")) {
            $paypal_addon = ViraStore_PayPal::get_instance();
            if (method_exists($paypal_addon, "process_payment")) {
                // Ensure order_total is valid
                if ($order_total <= 0 && $order_snapshot && isset($order_snapshot["total"])) {
                    $order_total = floatval($order_snapshot["total"]);
                }
                
                // Prepare payment data for PayPal addon
                // CRITICAL: Payment processor expects 'amount' or 'total', not 'order_total'
                $payment_data = [
                    "order_id" => $order_id,
                    "payment_method" => "paypal",
                    "amount" => $order_total, // Payment processor primary field
                    "total" => $order_total, // Alternative field for compatibility
                    "order_total" => $order_total, // Keep for reference
                    "currency" => $currency,
                    "customer_name" => $customer_name,
                    "customer_email" => $customer_email,
                    "form_data" => $form_data,
                    "account_created" => $account_created,
                    "user_id" => $user_id,
                    "cart_items" => $cart_items,
                    // Include order_data as fallback if processor needs nested data
                    "order_data" => [
                        "total" => $order_total,
                        "currency" => $currency,
                        "order_id" => $order_id,
                    ],
                ];

                error_log(
                    "ViraStore Checkout: PayPal payment data prepared - Order: " .
                        $order_id .
                        ", Amount: " .
                        $order_total .
                        ", Currency: " .
                        $currency,
                );

                // Let PayPal addon handle the payment processing
                error_log(
                    "ViraStore Checkout: About to call PayPal addon process_payment for order: " . $order_id
                );
                
                // Initialize result variable
                $result = null;
                
                try {
                    error_log("ViraStore Checkout: Calling PayPal addon process_payment method...");
                    $result = $paypal_addon->process_payment($payment_data);
                    error_log("ViraStore Checkout: PayPal addon process_payment returned successfully");
                    
                    // Log result immediately after call
                    if (is_null($result)) {
                        error_log("ViraStore Checkout WARNING: PayPal addon returned NULL");
                        $result = ["success" => false, "message" => "PayPal addon returned null"];
                    } elseif (!is_array($result)) {
                        error_log(
                            "ViraStore Checkout WARNING: PayPal addon returned non-array: " . gettype($result)
                        );
                        $result = [
                            "success" => false, 
                            "message" => "Invalid response type: " . gettype($result)
                        ];
                    } else {
                        error_log(
                            "ViraStore Checkout: PayPal addon result received - " .
                                "Type: " . gettype($result) . ", " .
                                "Is array: yes, " .
                                "Keys: " . implode(", ", array_keys($result))
                        );
                        
                        // Log result details (but handle potential circular references)
                        $result_copy = $result;
                        // Remove potentially large arrays for cleaner log
                        if (isset($result_copy['form_data'])) {
                            $result_copy['form_data'] = '[removed for log]';
                        }
                        if (isset($result_copy['cart_items'])) {
                            $result_copy['cart_items'] = '[removed for log]';
                        }
                        error_log(
                            "ViraStore Checkout: PayPal result details: " . print_r($result_copy, true)
                        );
                    }

                    // Validate result structure
                    if (!is_array($result)) {
                        error_log(
                            "ViraStore Checkout ERROR: PayPal addon returned non-array result: " . var_export($result, true)
                        );
                        // Create default result to prevent fatal error
                        $result = [
                            "success" => false,
                            "message" => "Invalid response from PayPal addon."
                        ];
                    }

                } catch (Exception $e) {
                    error_log(
                        "ViraStore Checkout ERROR: Exception during PayPal processing: " . $e->getMessage() . 
                        " in " . $e->getFile() . ":" . $e->getLine()
                    );
                    $result = [
                        "success" => false,
                        "message" => "Error processing PayPal payment: " . $e->getMessage()
                    ];
                } catch (Error $e) {
                    error_log(
                        "ViraStore Checkout ERROR: Fatal error during PayPal processing: " . $e->getMessage() . 
                        " in " . $e->getFile() . ":" . $e->getLine()
                    );
                    $result = [
                        "success" => false,
                        "message" => "Fatal error processing PayPal payment."
                    ];
                } catch (Throwable $e) {
                    error_log(
                        "ViraStore Checkout ERROR: Throwable during PayPal processing: " . $e->getMessage() . 
                        " in " . $e->getFile() . ":" . $e->getLine()
                    );
                    $result = [
                        "success" => false,
                        "message" => "Error processing PayPal payment."
                    ];
                }
                
                // CRITICAL: Ensure result variable exists even if PayPal addon fails
                if (!isset($result)) {
                    error_log(
                        "ViraStore Checkout CRITICAL ERROR: PayPal addon did not return a result!"
                    );
                    $result = [
                        "success" => false,
                        "message" => "PayPal payment processor did not respond."
                    ];
                }

                // Handle the result
                error_log(
                    "ViraStore Checkout: Processing result - " .
                        "Has success: " . (isset($result["success"]) ? 'yes' : 'no') . ", " .
                        "Success value: " . (isset($result["success"]) ? ($result["success"] ? 'true' : 'false') : 'N/A') . ", " .
                        "Has show_form: " . (isset($result["show_form"]) ? 'yes' : 'no') . ", " .
                        "Full result: " . print_r($result, true)
                );
                
                if (isset($result["success"]) && $result["success"]) {
                    // Check if we need to show payment form (initial flow)
                    error_log(
                        "ViraStore Checkout: Checking show_form condition - " .
                            "show_form isset: " . (isset($result["show_form"]) ? 'yes' : 'no') . ", " .
                            "show_form value: " . (isset($result["show_form"]) ? var_export($result["show_form"], true) : 'N/A')
                    );
                    
                    if (isset($result["show_form"]) && $result["show_form"]) {
                        error_log(
                            "ViraStore Checkout: PayPal requires form display - storing payment data for order: " . $order_id
                        );

                        // DO NOT clear cart yet - wait until payment is actually completed
                        // Cart should remain so checkout page can display order summary
                        
                        // Store payment data in transient for checkout page
                        set_transient(
                            "vrstore_paypal_payment_" . $order_id,
                            $result,
                            3600, // 1 hour
                        );

                        // Get checkout page URL - ensure we use the actual checkout page
                        $checkout_page_id = get_option("vrstore_checkout_page", 0);
                        if (!$checkout_page_id) {
                            // Try to find checkout page by looking for pages with checkout shortcode
                            $checkout_pages = get_posts([
                                'post_type' => 'page',
                                's' => '[vrstore_checkout]',
                                'posts_per_page' => 1,
                            ]);
                            if (!empty($checkout_pages)) {
                                $checkout_page_id = $checkout_pages[0]->ID;
                            }
                        }
                        
                        if ($checkout_page_id) {
                            $checkout_url = get_permalink($checkout_page_id);
                            if ($checkout_url) {
                                $checkout_url = add_query_arg(
                                    [
                                        "vrstore_payment" => "paypal",
                                        "order_id" => $order_id,
                                    ],
                                    $checkout_url,
                                );
                            } else {
                                $checkout_url = add_query_arg(
                                    [
                                        "vrstore_payment" => "paypal",
                                        "order_id" => $order_id,
                                    ],
                                    wp_get_referer() ?: home_url(),
                                );
                            }
                        } else {
                            // Final fallback - find checkout page by shortcode or use home
                            // NEVER use admin-post.php as redirect target
                            $checkout_pages = get_posts([
                                'post_type' => 'page',
                                's' => '[vrstore_checkout]',
                                'posts_per_page' => 1,
                            ]);
                            
                            if (!empty($checkout_pages)) {
                                $checkout_url = add_query_arg(
                                    [
                                        "vrstore_payment" => "paypal",
                                        "order_id" => $order_id,
                                    ],
                                    get_permalink($checkout_pages[0]->ID),
                                );
                            } else {
                                // Try to find page with checkout slug
                                $checkout_page = get_page_by_path('checkout');
                                if ($checkout_page) {
                                    $checkout_url = add_query_arg(
                                        [
                                            "vrstore_payment" => "paypal",
                                            "order_id" => $order_id,
                                        ],
                                        get_permalink($checkout_page->ID),
                                    );
                                } else {
                                    // Last resort - home URL with parameters (but warn in log)
                                    error_log(
                                        "ViraStore Checkout WARNING: Could not find checkout page, using home URL"
                                    );
                                    $checkout_url = add_query_arg(
                                        [
                                            "vrstore_payment" => "paypal",
                                            "order_id" => $order_id,
                                        ],
                                        home_url(),
                                    );
                                }
                            }
                        }

                        // Validate redirect URL before redirecting
                        $validated_url = wp_http_validate_url($checkout_url);
                        if (!$validated_url) {
                            // Try to make it absolute
                            if (strpos($checkout_url, 'http') !== 0) {
                                $checkout_url = home_url($checkout_url);
                            }
                            $validated_url = wp_http_validate_url($checkout_url);
                        }
                        
                        error_log(
                            "ViraStore Checkout: Redirecting to checkout with PayPal form - " .
                                "URL: {$checkout_url}, " .
                                "Validated: " . ($validated_url ? 'yes' : 'no') . ", " .
                                "Checkout Page ID: {$checkout_page_id}, " .
                                "Order ID: {$order_id}"
                        );
                        
                        // Final validation - ensure we have a valid URL
                        if (!$validated_url) {
                            error_log(
                                "ViraStore Checkout ERROR: Invalid redirect URL: {$checkout_url}"
                            );
                            // Use home URL as last resort
                            $checkout_url = add_query_arg(
                                [
                                    "vrstore_payment" => "paypal",
                                    "order_id" => $order_id,
                                ],
                                home_url(),
                            );
                            error_log(
                                "ViraStore Checkout: Using fallback URL: {$checkout_url}"
                            );
                        }

                        // Ensure no output before redirect - critical for admin-post.php
                        while (ob_get_level()) {
                            ob_end_clean();
                        }
                        
                        // Check if headers already sent (would prevent redirect)
                        if (headers_sent($file, $line)) {
                            error_log(
                                "ViraStore Checkout ERROR: Headers already sent in {$file} on line {$line}. Cannot redirect."
                            );
                            // Output JavaScript redirect as fallback
                            echo '<script type="text/javascript">window.location.href = "' . esc_js($checkout_url) . '";</script>';
                            echo '<noscript><meta http-equiv="refresh" content="0;url=' . esc_url($checkout_url) . '"></noscript>';
                            exit();
                        }
                        
                        // Use absolute URL and proper redirect status
                        if (!wp_http_validate_url($checkout_url)) {
                            // Make sure URL is absolute
                            $checkout_url = home_url($checkout_url);
                        }
                        
                        wp_redirect($checkout_url, 302); // Use 302 for temporary redirect
                        exit();
                    }

                    // Clear cart ONLY on successful payment completion (not initial form display)
                    $cart = VRSTORE_Cart::get_instance();
                    $cart->clear_cart();

                    // Redirect to PayPal or confirmation page
                    if (isset($result["redirect_url"])) {
                        wp_redirect($result["redirect_url"]);
                        exit();
                    } else {
                        $this->redirect_to_confirmation(
                            $order_id,
                            __(
                                "Redirecting to PayPal for payment...",
                                "vira-store",
                            ),
                            $account_created,
                            $user_id,
                        );
                    }
                } else {
                    // Payment failed - redirect with error
                    $error_message = isset($result["error"])
                        ? $result["error"]
                        : __("PayPal payment processing failed.", "vira-store");
                    $redirect_url = add_query_arg(
                        [
                            "vrstore_error" => urlencode($error_message),
                        ],
                        wp_get_referer(),
                    );
                    wp_redirect($redirect_url);
                    exit();
                }
                return;
            }
        }

        // Delegate to main payment class if available
        if (class_exists("VRSTORE_Payment")) {
            error_log(
                "ViraStore Checkout: Starting PayPal payment processing for order " .
                    $order_id,
            );

            $payment = VRSTORE_Payment::get_instance();
            $available_gateways = $payment->get_available_gateways();

            // Check if PayPal is available in the payment gateways
            if (
                isset($available_gateways["paypal"]) &&
                isset($available_gateways["paypal"]["callback"])
            ) {
                error_log("ViraStore Checkout: PayPal gateway is available");

                // Prepare payment data with all required fields
                $payment_data = [
                    "order_id" => $order_id,
                    "payment_method" => "paypal",
                    "form_data" => $form_data,
                    "account_created" => $account_created,
                    "user_id" => $user_id,
                    "cart_items" => $cart_items,
                    "total" => $order_total,
                    "amount" => $order_total, // CRITICAL: Add amount field
                    "currency" => $currency,
                    "customer_name" => $customer_name,
                    "customer_email" => $customer_email,
                ];

                error_log(
                    "ViraStore Checkout: Payment data prepared: " .
                        print_r($payment_data, true),
                );

                // Call the PayPal gateway callback
                $callback = $available_gateways["paypal"]["callback"];
                if (is_callable($callback)) {
                    error_log("ViraStore Checkout: Calling PayPal callback");
                    $result = call_user_func($callback, $payment_data);

                    error_log(
                        "ViraStore Checkout: PayPal callback result: " .
                            print_r($result, true),
                    );

                    // Handle the result
                    if (isset($result["success"]) && $result["success"]) {
                        // Check if we need to show payment form (initial flow)
                        if (
                            isset($result["show_form"]) &&
                            $result["show_form"]
                        ) {
                            error_log(
                                "ViraStore Checkout: PayPal requires form display - redirecting to payment page",
                            );

                            // Store payment data in session/transient for payment page
                            set_transient(
                                "vrstore_paypal_payment_" . $order_id,
                                $result,
                                3600,
                            );

                            // Redirect to payment page with PayPal form
                            $payment_page_url = add_query_arg(
                                [
                                    "vrstore_payment" => "paypal",
                                    "order_id" => $order_id,
                                ],
                                get_permalink(
                                    get_option("vrstore_checkout_page", 0),
                                ),
                            );

                            error_log(
                                "ViraStore Checkout: Redirecting to: " .
                                    $payment_page_url,
                            );
                            wp_redirect($payment_page_url);
                            exit();
                        }

                        // Clear cart on successful payment completion
                        $cart = VRSTORE_Cart::get_instance();
                        $cart->clear_cart();

                        // Redirect to PayPal or confirmation page
                        if (isset($result["redirect_url"])) {
                            error_log(
                                "ViraStore Checkout: Redirecting to: " .
                                    $result["redirect_url"],
                            );
                            wp_redirect($result["redirect_url"]);
                            exit();
                        } else {
                            error_log(
                                "ViraStore Checkout: No redirect URL, going to confirmation",
                            );
                            $this->redirect_to_confirmation(
                                $order_id,
                                __(
                                    "Redirecting to PayPal for payment...",
                                    "vira-store",
                                ),
                                $account_created,
                                $user_id,
                            );
                        }
                    } else {
                        // Payment failed - redirect with error
                        $error_message = isset($result["message"])
                            ? $result["message"]
                            : (isset($result["error"])
                                ? $result["error"]
                                : __(
                                    "PayPal payment processing failed.",
                                    "vira-store",
                                ));

                        error_log(
                            "ViraStore Checkout ERROR: PayPal payment failed - " .
                                $error_message,
                        );

                        $redirect_url = add_query_arg(
                            [
                                "vrstore_error" => urlencode($error_message),
                            ],
                            wp_get_referer(),
                        );
                        wp_redirect($redirect_url);
                        exit();
                    }
                } else {
                    error_log(
                        "ViraStore Checkout ERROR: PayPal callback is not callable",
                    );
                }
                return;
            } else {
                error_log(
                    "ViraStore Checkout ERROR: PayPal gateway not found in available gateways: " .
                        print_r(array_keys($available_gateways), true),
                );
            }
        } else {
            error_log(
                "ViraStore Checkout ERROR: VRSTORE_Payment class not found",
            );
        }

        // Fallback scenario - PayPal not available
        error_log(
            "ViraStore Checkout ERROR: PayPal payment method selected but PayPal addon not available for order " .
                $order_id,
        );

        $this->redirect_with_error(
            __(
                "PayPal payment is not available. Please select a different payment method.",
                "vira-store",
            ),
        );
    }

    /**
     * Process Xendit payment
     *
     * @param int $order_id Order ID
     * @param array $form_data Form data
     * @param bool $account_created Whether account was created during checkout
     * @param int $user_id User ID for delayed login action
     * @return void
     */
    private function process_xendit_payment(
        int $order_id,
        array $form_data,
        bool $account_created = false,
        int $user_id = 0,
        array $cart_items = [],
        float $order_total = 0.0,
        string $currency = "USD",
    ): void {
        $order_snapshot = VRSTORE_Order::get_order($order_id);
        if ($order_snapshot && !empty($order_snapshot["currency"])) {
            $currency = $order_snapshot["currency"];
        }
        if (
            empty($cart_items) &&
            $order_snapshot &&
            !empty($order_snapshot["cart_items"])
        ) {
            $cart_items = $order_snapshot["cart_items"];
        }
        if (
            $order_total <= 0 &&
            $order_snapshot &&
            isset($order_snapshot["total"])
        ) {
            $order_total = floatval($order_snapshot["total"]);
        }

        $customer_name = sanitize_text_field(
            $form_data["vrstore_username"] ??
                ($form_data["customer_name"] ??
                    ($order_snapshot["customer_name"] ?? "")),
        );
        $customer_email = sanitize_email(
            $form_data["vrstore_email"] ??
                ($form_data["customer_email"] ??
                    ($order_snapshot["customer_email"] ?? "")),
        );

        // Delegate to Xendit addon if available
        if (class_exists("ViraStore_Xendit")) {
            $xendit_addon = ViraStore_Xendit::get_instance();
            if (method_exists($xendit_addon, "process_payment")) {
                // Ensure order_total is valid
                if ($order_total <= 0 && $order_snapshot && isset($order_snapshot["total"])) {
                    $order_total = floatval($order_snapshot["total"]);
                }
                
                // Prepare payment data for Xendit addon
                // CRITICAL: Payment processor expects 'amount' or 'total', not 'order_total'
                $payment_data = [
                    "order_id" => $order_id,
                    "payment_method" => "xendit",
                    "amount" => $order_total, // Payment processor primary field
                    "total" => $order_total, // Alternative field for compatibility
                    "order_total" => $order_total, // Keep for reference
                    "currency" => $currency,
                    "customer_name" => $customer_name,
                    "customer_email" => $customer_email,
                    "form_data" => $form_data,
                    "account_created" => $account_created,
                    "user_id" => $user_id,
                    "cart_items" => $cart_items,
                    // Include order_data as fallback if processor needs nested data
                    "order_data" => [
                        "total" => $order_total,
                        "currency" => $currency,
                        "order_id" => $order_id,
                    ],
                ];

                error_log(
                    "ViraStore Checkout: Xendit payment data prepared - Order: " .
                        $order_id .
                        ", Amount: " .
                        $order_total .
                        ", Currency: " .
                        $currency,
                );

                // Let Xendit addon handle the payment processing
                error_log(
                    "ViraStore Checkout: About to call Xendit addon process_payment for order: " . $order_id
                );
                
                // Initialize result variable
                $result = null;
                
                try {
                    error_log("ViraStore Checkout: Calling Xendit addon process_payment method...");
                    $result = $xendit_addon->process_payment($payment_data);
                    error_log("ViraStore Checkout: Xendit addon process_payment returned successfully");
                    
                    // Log result immediately after call
                    if (is_null($result)) {
                        error_log("ViraStore Checkout WARNING: Xendit addon returned NULL");
                        $result = ["success" => false, "message" => "Xendit addon returned null"];
                    } elseif (!is_array($result)) {
                        error_log(
                            "ViraStore Checkout WARNING: Xendit addon returned non-array: " . gettype($result)
                        );
                        $result = [
                            "success" => false, 
                            "message" => "Invalid response type: " . gettype($result)
                        ];
                    } else {
                        error_log(
                            "ViraStore Checkout: Xendit addon result received - " .
                                "Type: " . gettype($result) . ", " .
                                "Is array: yes, " .
                                "Keys: " . implode(", ", array_keys($result))
                        );
                    }

                    // Validate result structure
                    if (!is_array($result)) {
                        error_log(
                            "ViraStore Checkout ERROR: Xendit addon returned non-array result: " . var_export($result, true)
                        );
                        // Create default result to prevent fatal error
                        $result = [
                            "success" => false,
                            "message" => "Invalid response from Xendit addon."
                        ];
                    }

                } catch (Exception $e) {
                    error_log(
                        "ViraStore Checkout ERROR: Exception during Xendit processing: " . $e->getMessage() . 
                        " in " . $e->getFile() . ":" . $e->getLine()
                    );
                    $result = [
                        "success" => false,
                        "message" => "Error processing Xendit payment: " . $e->getMessage()
                    ];
                } catch (Error $e) {
                    error_log(
                        "ViraStore Checkout ERROR: Fatal error during Xendit processing: " . $e->getMessage() . 
                        " in " . $e->getFile() . ":" . $e->getLine()
                    );
                    $result = [
                        "success" => false,
                        "message" => "Fatal error processing Xendit payment."
                    ];
                }

                // Handle result
                if (isset($result["success"]) && $result["success"]) {
                    // Clear cart before redirect (payment initiated successfully)
                    $cart = VRSTORE_Cart::get_instance();
                    $cart->clear_cart();

                    // Redirect to Xendit or confirmation page
                    if (isset($result["redirect_url"]) && !empty($result["redirect_url"])) {
                        $redirect_url = $result["redirect_url"];
                        
                        // Validate redirect URL
                        if (!wp_http_validate_url($redirect_url)) {
                            error_log(
                                "ViraStore Checkout ERROR: Xendit returned invalid redirect URL: " . $redirect_url
                            );
                            $this->redirect_to_confirmation(
                                $order_id,
                                $this->get_translated_text(
                                    "Xendit payment initiated. Please complete your payment to finalize the order.",
                                ),
                                $account_created,
                                $user_id,
                            );
                            return;
                        }

                        // Ensure no output before redirect
                        while (ob_get_level()) {
                            ob_end_clean();
                        }

                        // Check if headers already sent
                        if (headers_sent($file, $line)) {
                            error_log(
                                "ViraStore Checkout ERROR: Headers already sent in {$file} on line {$line}. Using JavaScript redirect."
                            );
                            echo '<script type="text/javascript">window.location.href = "' . esc_js($redirect_url) . '";</script>';
                            echo '<noscript><meta http-equiv="refresh" content="0;url=' . esc_url($redirect_url) . '"></noscript>';
                            exit();
                        }

                        error_log(
                            "ViraStore Checkout: Redirecting to Xendit payment page - URL: " . $redirect_url . ", Order ID: " . $order_id
                        );

                        wp_redirect($redirect_url, 302);
                        exit();
                    } else {
                        $this->redirect_to_confirmation(
                            $order_id,
                            $this->get_translated_text(
                                "Xendit payment initiated. Please complete your payment to finalize the order.",
                            ),
                            $account_created,
                            $user_id,
                        );
                    }
                } else {
                    // Payment failed - redirect with error
                    $error_message = isset($result["message"])
                        ? $result["message"]
                        : $this->get_translated_text("Xendit payment processing failed.", "vira-store");
                    $this->redirect_with_error($error_message);
                }
                return;
            }
        }

        error_log(
            "ViraStore: Xendit payment handler unavailable, falling back for order " .
                $order_id,
        );
        $this->redirect_with_error(
            $this->get_translated_text(
                "Payment processing failed. Please try again.",
            ),
        );
    }

    /**
     * Process manual payment (bank transfer)
     *
     * @param int $order_id Order ID
     * @param bool $account_created Whether account was created during checkout
     * @param int $user_id User ID for delayed login action
     * @return void
     */
    private function process_manual_payment(
        int $order_id,
        bool $account_created = false,
        int $user_id = 0,
    ): void {
        // Update order status to pending payment
        VRSTORE_Order::update_order_status($order_id, "pending");
        VRSTORE_Order::update_payment_status($order_id, "pending");

        // For manual payments, clear cart immediately since order is created
        // and user will complete payment offline
        $cart = VRSTORE_Cart::get_instance();
        $cart->clear_cart();

        // Redirect to order confirmation with payment instructions
        $this->redirect_to_confirmation(
            $order_id,
            __(
                "Order created successfully! Please complete your payment using the bank transfer details provided.",
                "vira-store",
            ),
            $account_created,
            $user_id,
        );
    }

    /**
     * Process Moota payment (bank transfer with automatic verification)
     *
     * @param int $order_id Order ID
     * @param array $form_data Form data
     * @param bool $account_created Whether account was created during checkout
     * @param int $user_id User ID for delayed login action
     * @param array $cart_items Cart items
     * @param float $order_total Order total
     * @param string $currency Currency code
     * @return void
     */
    private function process_moota_payment(
        int $order_id,
        array $form_data,
        bool $account_created = false,
        int $user_id = 0,
        array $cart_items = [],
        float $order_total = 0.0,
        string $currency = "USD",
    ): void {
        // Check if Moota gateway class is available
        if (!class_exists('ViraStore_Moota_Gateway')) {
            error_log(
                "ViraStore: Moota gateway class not available for order " .
                $order_id,
            );
            $this->redirect_with_error(
                $this->get_translated_text(
                    "Moota payment gateway is not available. Please try another payment method.",
                ),
            );
            return;
        }

        // Get selected bank account if provided
        $selected_bank = isset($form_data['vrstore_moota_bank'])
            ? sanitize_text_field($form_data['vrstore_moota_bank'])
            : '';
        
        if (empty($cart_items)) {
            $order = VRSTORE_Order::get_order($order_id);
            if ($order && !empty($order["cart_items"])) {
                $cart_items = $order["cart_items"];
            }
        }

        if ($order_total <= 0) {
            $order = isset($order)
                ? $order
                : VRSTORE_Order::get_order($order_id);
            if ($order && isset($order["total"])) {
                $order_total = floatval($order["total"]);
            }
        }

        // Get Moota gateway instance
        $moota_gateway = ViraStore_Moota_Gateway::get_instance();
        
        // Check if gateway is enabled
        if (!$moota_gateway->is_enabled()) {
            $this->redirect_with_error(
                $this->get_translated_text(
                    "Moota payment gateway is not enabled.",
                ),
            );
            return;
        }

        // Get bank accounts
        $bank_accounts = $moota_gateway->get_bank_accounts();
        
        if (empty($bank_accounts)) {
            $this->redirect_with_error(
                $this->get_translated_text(
                    "No bank accounts configured for Moota payment.",
                ),
            );
            return;
        }

        // Get the selected bank account or use the first one
        $selected_bank_account = null;
        if (!empty($selected_bank)) {
            foreach ($bank_accounts as $account) {
                $bank_id = $account['moota_bank_id'] ?? ($account['account_number'] ?? '');
                if ($bank_id === $selected_bank) {
                    $selected_bank_account = $account;
                    break;
                }
            }
        }
        
        // Fallback to first bank account if no match found
        if (!$selected_bank_account) {
            $selected_bank_account = reset($bank_accounts);
        }

        // Update order with payment method
        update_post_meta($order_id, 'vrstore_payment_method', 'moota');
        update_post_meta($order_id, 'vrstore_payment_status', 'pending');
        update_post_meta($order_id, 'vrstore_moota_selected_bank', $selected_bank_account);

        // Store Moota payment data
        $moota_payment_data = array(
            'order_id' => $order_id,
            'amount' => $order_total,
            'currency' => $currency,
            'status' => 'pending',
            'created_at' => current_time('mysql'),
            'expected_amount' => $order_total,
            'selected_bank' => $selected_bank_account,
            'reference' => (string) $order_id,
        );
        
        update_post_meta($order_id, 'vrstore_moota_payment_data', $moota_payment_data);

        // Update order status to pending
        VRSTORE_Order::update_order_status($order_id, "pending");
        VRSTORE_Order::update_payment_status($order_id, "pending");

        // Clear cart
        $cart = VRSTORE_Cart::get_instance();
        $cart->clear_cart();

        // Redirect to confirmation page with Moota payment instructions
        $success_message = __(
            "Order created successfully! Please complete your bank transfer. Payment will be automatically verified.",
            "vira-store",
        );
        
        $this->redirect_to_confirmation(
            $order_id,
            $success_message,
            $account_created,
            $user_id,
        );
    }

    /**
     * Redirect to order confirmation page
     *
     * @param int $order_id Order ID
     * @param string $success_message Custom success message
     * @param bool $account_created Whether account was created during checkout
     * @param int $user_id User ID for delayed login action
     * @return void
     */
    private function redirect_to_confirmation(
        int $order_id,
        string $success_message = "",
        bool $account_created = false,
        int $user_id = 0,
    ): void {
        // Default success message if none provided
        if (empty($success_message)) {
            $success_message = __("Order created successfully!", "vira-store");
        }

        // Proceed with normal thank you page redirect
        // Get thank you page from settings
        $settings = get_option("vrstore_settings", []);
        $thank_you_page_id = !empty($settings["thank_you_page"])
            ? $settings["thank_you_page"]
            : 0;

        // Also check for 'vrstore_thank_you_page' option (alternative setting name)
        if (!$thank_you_page_id) {
            $thank_you_page_id = get_option("vrstore_thank_you_page", 0);
        }

        if ($thank_you_page_id && get_post($thank_you_page_id)) {
            $redirect_params = [
                "vrstore_order_id" => $order_id,
                "vrstore_success" => urlencode($success_message),
            ];

            // Add account creation flag if applicable
            if ($account_created) {
                $redirect_params["vrstore_checkout_completed"] = "1";
            }

            $redirect_url = add_query_arg(
                $redirect_params,
                get_permalink($thank_you_page_id),
            );
        } else {
            // Try to find a page with 'vrstore_thank_you' shortcode
            $thank_you_page = get_posts([
                "post_type" => "page",
                "meta_query" => [
                    [
                        "key" => "_wp_page_template",
                        "value" => "thank-you",
                        "compare" => "LIKE",
                    ],
                ],
                "posts_per_page" => 1,
            ]);

            // If no specific thank you page found, look for pages containing the shortcode
            if (empty($thank_you_page)) {
                $pages_with_shortcode = get_posts([
                    "post_type" => "page",
                    "meta_query" => [
                        [
                            "key" => "_",
                            "value" => "vrstore_thank_you",
                            "compare" => "LIKE",
                        ],
                    ],
                    "s" => "[vrstore_thank_you]",
                    "posts_per_page" => 1,
                ]);
                $thank_you_page = $pages_with_shortcode;
            }

            if (!empty($thank_you_page)) {
                $redirect_params = [
                    "vrstore_order_id" => $order_id,
                    "vrstore_success" => urlencode($success_message),
                ];

                if ($account_created) {
                    $redirect_params["vrstore_checkout_completed"] = "1";
                }

                $redirect_url = add_query_arg(
                    $redirect_params,
                    get_permalink($thank_you_page[0]->ID),
                );
            } else {
                // Final fallback - create a simple thank you page URL
                $redirect_params = [
                    "vrstore_order_id" => $order_id,
                    "vrstore_success" => urlencode($success_message),
                    "vrstore_page" => "thank-you",
                ];

                if ($account_created) {
                    $redirect_params["vrstore_checkout_completed"] = "1";
                }

                $redirect_url = add_query_arg($redirect_params, home_url());
            }
        }

        // Clear session flag before redirect
        // Session is already active from cart initialization
        if (isset($_SESSION["vrstore_checkout_in_progress"])) {
            unset($_SESSION["vrstore_checkout_in_progress"]);
        }

        // Trigger delayed wp_login action now that redirect is set up
        // This happens after the checkout flags are cleared so login redirect won't interfere
        if (
            $user_id > 0 &&
            is_user_logged_in() &&
            get_current_user_id() == $user_id
        ) {
            $user_data = get_userdata($user_id);
            if ($user_data) {
                // Trigger wp_login action after redirect is prepared
                do_action("wp_login", $user_data->user_login, $user_data);
            }
        }

        wp_redirect($redirect_url);
        exit();
    }

    /**
     * Force checkout redirect instead of login redirect
     *
     * @param string $redirect_to URL to redirect to after login.
     * @param string $request Original requested redirect URL.
     * @param WP_User|WP_Error $user User object or error.
     * @return string
     */
    public function force_checkout_redirect($redirect_to, $request, $user)
    {
        // Only intercept if we have a checkout session
        $checkout_in_progress = false;

        if (class_exists("VRSTORE_Session_Manager")) {
            $session_manager = VRSTORE_Session_Manager::get_instance();
            $checkout_in_progress = $session_manager->get_session_data(
                "vrstore_checkout_in_progress",
            );
        } elseif (session_status() === PHP_SESSION_ACTIVE) {
            $checkout_in_progress = isset(
                $_SESSION["vrstore_checkout_in_progress"],
            )
                ? $_SESSION["vrstore_checkout_in_progress"]
                : false;
        }

        if ($checkout_in_progress) {
            // Return the original redirect_to to let checkout handle it
            // This prevents the login redirect from taking over
            return $redirect_to;
        }

        return $redirect_to;
    }

    /**
     * AJAX handler to refresh checkout nonce
     *
     * @return void
     */
    public function ajax_refresh_checkout_nonce(): void
    {
        // Create a fresh nonce
        $fresh_nonce = wp_create_nonce("vrstore_checkout");

        // Log nonce refresh for debugging
        error_log(
            sprintf(
                "ViraStore: Checkout nonce refreshed - User ID: %d, New nonce: %s...",
                get_current_user_id(),
                substr($fresh_nonce, 0, 10),
            ),
        );

        wp_send_json_success([
            "nonce" => $fresh_nonce,
            "timestamp" => time(),
            "user_id" => get_current_user_id(),
        ]);
    }

    /**
     * AJAX handler to check if customer exists
     *
     * @return void
     */
    public function ajax_check_customer_exists(): void
    {
        // Verify nonce
        if (
            !isset($_POST["nonce"]) ||
            !wp_verify_nonce($_POST["nonce"], "vrstore_check_customer")
        ) {
            wp_send_json_error([
                "message" => __("Security check failed.", "vira-store"),
            ]);
        }

        $email = sanitize_email($_POST["email"] ?? "");

        if (empty($email) || !is_email($email)) {
            wp_send_json_error([
                "message" => __("Invalid email address.", "vira-store"),
            ]);
        }

        // Check if user exists
        $user = get_user_by("email", $email);
        $exists = $user && $user->ID;

        wp_send_json_success([
            "exists" => $exists,
            "user_id" => $exists ? $user->ID : null,
        ]);
    }

    /**
     * Override login redirects specifically for checkout processes
     *
     * @param string $redirect_to The redirect destination URL.
     * @param string $request The redirect destination URL passed as a parameter.
     * @param WP_User|WP_Error $user WP_User object if login was successful, WP_Error object otherwise.
     * @return string
     */
    public function override_login_redirect_for_checkout(
        $redirect_to,
        $request,
        $user,
    ) {
        // Only handle successful logins
        if (is_wp_error($user) || !is_a($user, "WP_User")) {
            return $redirect_to;
        }

        // Check if this is a checkout-related request
        $is_checkout = false;

        // Check 1: POST action parameter
        if (
            isset($_POST["action"]) &&
            $_POST["action"] === "vrstore_process_checkout"
        ) {
            $is_checkout = true;
        }

        // Check 2: Checkout form fields
        if (
            isset($_POST["vrstore_checkout_nonce"]) ||
            isset($_POST["vrstore_reg_username"]) ||
            isset($_POST["vrstore_reg_email"]) ||
            isset($_POST["vrstore_payment_method"])
        ) {
            $is_checkout = true;
        }

        // Check 3: Global checkout flag
        if (
            defined("VRSTORE_CHECKOUT_IN_PROGRESS") &&
            VRSTORE_CHECKOUT_IN_PROGRESS
        ) {
            $is_checkout = true;
        }

        // Check 4: Thank you page redirect (contains order parameters)
        if (
            !empty($redirect_to) &&
            (strpos($redirect_to, "vrstore_order_id") !== false ||
                strpos($redirect_to, "vrstore_success") !== false ||
                strpos($redirect_to, "vrstore_checkout_completed") !== false)
        ) {
            $is_checkout = true;
        }

        // Check 5: Session checkout flag
        if (
            session_status() === PHP_SESSION_ACTIVE &&
            isset($_SESSION["vrstore_checkout_in_progress"]) &&
            $_SESSION["vrstore_checkout_in_progress"]
        ) {
            $is_checkout = true;
        }

        if ($is_checkout) {
            // Force return the redirect_to URL without modification
            // This prevents any other login redirect handlers from interfering
            return $redirect_to;
        }

        return $redirect_to;
    }

    /**
     * Prevent WordPress login redirects during checkout processing
     *
     * @param string $redirect_to The redirect destination URL.
     * @param string $request The redirect destination URL passed as a parameter.
     * @param WP_User|WP_Error $user WP_User object if login was successful, WP_Error object otherwise.
     * @return string
     */
    public function prevent_login_redirect_during_checkout(
        $redirect_to,
        $request,
        $user,
    ) {
        // Check if this is during a checkout process
        if (
            isset($_POST["action"]) &&
            $_POST["action"] === "vrstore_process_checkout"
        ) {
            // Let checkout handle the redirect instead
            return false;
        }

        // Check if we're in a checkout session using session manager
        $checkout_in_progress = false;
        if (class_exists("VRSTORE_Session_Manager")) {
            $session_manager = VRSTORE_Session_Manager::get_instance();
            $checkout_in_progress = $session_manager->get_session_data(
                "vrstore_checkout_in_progress",
                false,
            );
        } else {
            // Fallback using global helper function
            $checkout_in_progress = vrstore_get_session_data(
                "vrstore_checkout_in_progress",
                false,
            );
        }

        if ($checkout_in_progress) {
            // Don't interfere with checkout flow
            return false;
        }

        return $redirect_to;
    }

    /**
     * Disable login redirects at the very start of checkout process
     *
     * @return void
     */
    public function disable_login_redirects_for_checkout(): void
    {
        // Remove all login redirect filters from the login redirect class
        if (class_exists("VRSTORE_Login_Redirect")) {
            $instance = VRSTORE_Login_Redirect::get_instance();
            remove_all_filters("login_redirect");
            remove_all_filters("registration_redirect");

            // Add our own simple passthrough filter
            add_filter(
                "login_redirect",
                function ($redirect_to, $request, $user) {
                    return $redirect_to; // Just pass through without modification
                },
                999,
                3,
            );
        }
    }

    /**
     * Completely disable login redirect during checkout
     *
     * @return void
     */
    private function disable_login_redirect_during_checkout(): void
    {
        if (class_exists("VRSTORE_Login_Redirect")) {
            $login_redirect_instance = VRSTORE_Login_Redirect::get_instance();

            // Remove all login redirect filters
            remove_filter(
                "login_redirect",
                [$login_redirect_instance, "handle_login_redirect"],
                10,
            );
            remove_filter("registration_redirect", [
                $login_redirect_instance,
                "handle_registration_redirect",
            ]);

            // Add our own login redirect that forces the thank you page redirect
            add_filter(
                "login_redirect",
                [$this, "force_thank_you_redirect"],
                999,
                3,
            );
        }
    }

    /**
     * Force redirect to thank you page after checkout login
     *
     * @param string $redirect_to The redirect destination URL.
     * @param string $request The redirect destination URL passed as a parameter.
     * @param WP_User|WP_Error $user WP_User object if login was successful, WP_Error object otherwise.
     * @return string
     */
    public function force_thank_you_redirect($redirect_to, $request, $user)
    {
        // Only handle successful logins during checkout
        if (is_wp_error($user) || !is_a($user, "WP_User")) {
            return $redirect_to;
        }

        // Check if this is a checkout login by looking at POST data
        if (
            isset($_POST["action"]) &&
            $_POST["action"] === "vrstore_process_checkout"
        ) {
            // Return the checkout's intended redirect URL
            return $redirect_to;
        }

        // If redirect_to contains thank you parameters, use it
        if (
            !empty($redirect_to) &&
            (strpos($redirect_to, "vrstore_order_id") !== false ||
                strpos($redirect_to, "vrstore_success") !== false)
        ) {
            return $redirect_to;
        }

        return $redirect_to;
    }

    /**
     * AJAX handler for TriPay payment processing
     *
     * @return void
     */
    public function ajax_process_tripay_payment(): void
    {
        // Verify nonce
        if (
            !isset($_POST["vrstore_checkout_nonce"]) ||
            !wp_verify_nonce(
                $_POST["vrstore_checkout_nonce"],
                "vrstore_checkout",
            )
        ) {
            wp_send_json_error([
                "message" => __("Security check failed.", "vira-store"),
            ]);
        }

        // Get form data
        $form_data = $_POST;

        // Validate required fields - check both field names for tripay_method
        $required_fields = [
            "vrstore_email",
            "vrstore_username",
            "vrstore_payment_method",
        ];
        
        // Check for tripay_method in either format
        $tripay_method = $form_data["vrstore_tripay_method"] ?? $form_data["tripay_method"] ?? "";
        if (empty($tripay_method)) {
            wp_send_json_error([
                "message" => __("Please select a TriPay payment method.", "vira-store"),
            ]);
        }
        
        foreach ($required_fields as $field) {
            if (empty($form_data[$field])) {
                wp_send_json_error([
                    "message" => sprintf(
                        __("Required field %s is missing.", "vira-store"),
                        $field,
                    ),
                ]);
            }
        }

        // Check if payment method is TriPay
        if ($form_data["vrstore_payment_method"] !== "tripay") {
            wp_send_json_error([
                "message" => __("Invalid payment method.", "vira-store"),
            ]);
        }

        // Get cart items
        $cart = VRSTORE_Cart::get_instance();
        $cart_items = $cart->get_cart();

        if (empty($cart_items)) {
            wp_send_json_error([
                "message" => __("Your cart is empty.", "vira-store"),
            ]);
        }

        // Process the first cart item (assuming single item checkout)
        $cart_item = reset($cart_items);

        // Get current currency and convert if needed
        $settings = get_option("vrstore_settings", []);
        $store_currency = isset($settings["currency"])
            ? $settings["currency"]
            : "USD";

        // For TriPay, we'll use the store currency but ensure amount is properly formatted
        $price = isset($cart_item["price"]) ? floatval($cart_item["price"]) : 0;
        if ($price <= 0 && $cart) {
            $price = $cart->get_item_price($cart_item);
        }
        $total = $price;

        // Apply any cart discounts
        $discount_amount = $cart->get_discount_amount();
        if ($discount_amount > 0) {
            $total = $price - $discount_amount;
        }

        // Prepare order data
        $order_data = [
            "product_id" => $cart_item["product_id"],
            "product_title" => $cart_item["name"],
            "price" => $price,
            "total" => $total,
            "currency" => $store_currency,
            "customer_name" => sanitize_text_field(
                $form_data["vrstore_username"],
            ),
            "customer_email" => sanitize_email($form_data["vrstore_email"]),
            "payment_gateway" => "tripay",
            "payment_method" => "tripay",
            "tripay_method" => sanitize_text_field(
                $tripay_method,
            ),
            "payment_channel" => sanitize_text_field(
                $tripay_method,
            ),
            "user_id" => get_current_user_id(),
            "date" => current_time("mysql"),
            "status" => "pending",
            "cart_items" => [$cart_item],
        ];

        // Add discount information if applicable
        if ($discount_amount > 0) {
            $order_data["discount_amount"] = $discount_amount;
            $applied_coupon = $cart->get_applied_coupon();
            if ($applied_coupon) {
                $order_data["coupon_code"] = $applied_coupon["code"];
            }
        }

        // Process payment using the payment class
        if (class_exists("VRSTORE_Payment")) {
            $payment = VRSTORE_Payment::get_instance();
            if (method_exists($payment, "process_tripay_payment")) {
                $result = $payment->process_tripay_payment($order_data);

                if (is_wp_error($result)) {
                    error_log('ViraStore TriPay Error: ' . $result->get_error_message() . ' (Code: ' . $result->get_error_code() . ')');
                    wp_send_json_error([
                        "message" => $result->get_error_message(),
                    ]);
                }

                if (isset($result["success"]) && $result["success"]) {
                    // Clear cart on successful payment initiation
                    $cart->clear_cart();

                    // Return success with TriPay data
                    wp_send_json_success([
                        "payment_gateway" => "tripay",
                        "tripay_reference" => $result["tripay_reference"] ?? "",
                        "redirect_url" =>
                            $result["redirect_url"] ??
                            ($result["checkout_url"] ?? ""),
                        "payment_method" => $result["payment_method"] ?? "",
                        "order_id" => $result["order_id"] ?? "",
                        "message" =>
                            $result["message"] ??
                            __("Redirecting to payment...", "vira-store"),
                    ]);
                } else {
                    error_log('ViraStore TriPay Error: Result missing success flag. Result: ' . wp_json_encode($result));
                }
            }
        }

        wp_send_json_error([
            "message" => __(
                "Payment processing failed. Please try again.",
                "vira-store",
            ),
        ]);
    }
}
