<?php
/**
 * Product class
 *
 * @package Vira_Store
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Digital product management class
 */
class VRSTORE_Product {
    /**
     * Singleton instance
     *
     * @var VRSTORE_Product|null
     */
    private static ?VRSTORE_Product $instance = null;

    /**
     * Post type name
     *
     * @var string
     */
    private string $post_type = 'vrstore_product';

    /**
     * Get singleton instance
     *
     * @return VRSTORE_Product
     */
    public static function get_instance(): VRSTORE_Product {
        if (null === self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        // Register post type
        add_action('init', [$this, 'register_post_type']);

        // Register taxonomies
        add_action('init', [$this, 'register_taxonomies']);

        // Add meta boxes
        add_action('add_meta_boxes', [$this, 'add_meta_boxes']);

        // Save meta boxes
        add_action('save_post', [$this, 'save_meta_boxes'], 10, 2);

        // Add product columns
        add_filter('manage_' . $this->post_type . '_posts_columns', [$this, 'add_product_columns']);
        add_action('manage_' . $this->post_type . '_posts_custom_column', [$this, 'render_product_columns'], 10, 2);
        
        // Handle single product template display
        add_filter('the_content', [$this, 'filter_single_product_content'], 30);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_frontend_assets']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);
        
        // Add taxonomy management buttons to product edit page
        add_action('edit_form_after_title', [$this, 'add_taxonomy_management_buttons']);
        
        // Add taxonomy management buttons next to Add New button
        add_action('manage_posts_extra_tablenav', [$this, 'add_taxonomy_management_buttons_next_to_add_new']);
        
        // Add AJAX handler for product duplication
        add_action('wp_ajax_vrstore_duplicate_product', [$this, 'ajax_duplicate_product']);
        

        
        // Add duplicate action to row actions
        add_filter('post_row_actions', [$this, 'add_duplicate_row_action'], 10, 2);
    }

    /**
     * Get translated text with fallback for when textdomain is not loaded.
     *
     * @since 1.0.0
     * @param string $text Text to translate.
     * @param string $domain Text domain.
     * @return string Translated text or original text if textdomain not loaded.
     */
    private function get_translated_text( $text, $domain = 'vira-store' ) {
        // Check if textdomain is loaded
        if ( is_textdomain_loaded( $domain ) ) {
            return esc_html__( $text, $domain );
        }
        // Return escaped text without translation if textdomain not loaded
        return esc_html( $text );
    }

    /**
     * Register post type
     *
     * @return void
     */
    public function register_post_type(): void {
        // Get configurable permalink slug from settings - use fallback if settings not available
        $permalink_slug = 'digital-product'; // Default fallback
        if (class_exists('VRSTORE_Settings')) {
            try {
                $settings = VRSTORE_Settings::get_instance();
                $permalink_slug = $settings->get_setting('product_permalink_slug', 'digital-product');
            } catch (Exception $e) {
                // Use default if settings aren't ready yet
            }
        }
        
        $labels = [
            'name'               => _x('Digital Products', 'post type general name', 'vira-store'),
            'singular_name'      => _x('Digital Product', 'post type singular name', 'vira-store'),
            'menu_name'          => _x('Products', 'admin menu', 'vira-store'),
            'name_admin_bar'     => _x('Digital Product', 'add new on admin bar', 'vira-store'),
            'add_new'            => _x('Add New', 'digital product', 'vira-store'),
            'add_new_item'       => __('Add New Digital Product', 'vira-store'),
            'new_item'           => __('New Digital Product', 'vira-store'),
            'edit_item'          => __('Edit Digital Product', 'vira-store'),
            'view_item'          => __('View Digital Product', 'vira-store'),
            'all_items'          => __('Products', 'vira-store'),
            'search_items'       => __('Search Digital Products', 'vira-store'),
            'parent_item_colon'  => __('Parent Digital Products:', 'vira-store'),
            'not_found'          => __('No digital products found.', 'vira-store'),
            'not_found_in_trash' => __('No digital products found in Trash.', 'vira-store'),
        ];

        $args = [
            'labels'             => $labels,
            'description'        => __('Digital products for Vira Store.', 'vira-store'),
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => false, // Disable automatic menu - we add it manually in admin menu class
            'show_in_rest'       => true,
            'query_var'          => true,
            'rewrite'            => ['slug' => sanitize_title($permalink_slug)],
            'capability_type'    => 'post',
            'has_archive'        => true,
            'hierarchical'       => false,
            'menu_position'      => null,
            'supports'           => ['title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments'],
            'menu_icon'          => 'dashicons-download',
        ];

        register_post_type($this->post_type, $args);
    }

    /**
     * Register taxonomies
     *
     * @return void
     */
    public function register_taxonomies(): void {
        // Register category taxonomy
        $category_labels = [
            'name'              => _x('Product Categories', 'taxonomy general name', 'vira-store'),
            'singular_name'     => _x('Product Category', 'taxonomy singular name', 'vira-store'),
            'search_items'      => __('Search Product Categories', 'vira-store'),
            'all_items'         => __('All Product Categories', 'vira-store'),
            'parent_item'       => __('Parent Product Category', 'vira-store'),
            'parent_item_colon' => __('Parent Product Category:', 'vira-store'),
            'edit_item'         => __('Edit Product Category', 'vira-store'),
            'update_item'       => __('Update Product Category', 'vira-store'),
            'add_new_item'      => __('Add New Product Category', 'vira-store'),
            'new_item_name'     => __('New Product Category Name', 'vira-store'),
            'menu_name'         => __('Categories', 'vira-store'),
        ];

        $category_args = [
            'hierarchical'      => true,
            'labels'            => $category_labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => ['slug' => 'product-category'],
            'show_in_rest'      => true,
            'meta_box_cb'       => 'post_categories_meta_box',
        ];

        register_taxonomy('vrstore_product_cat', [$this->post_type], $category_args);

        // Register tag taxonomy
        $tag_labels = [
            'name'              => _x('Product Tags', 'taxonomy general name', 'vira-store'),
            'singular_name'     => _x('Product Tag', 'taxonomy singular name', 'vira-store'),
            'search_items'      => __('Search Product Tags', 'vira-store'),
            'all_items'         => __('All Product Tags', 'vira-store'),
            'parent_item'       => __('Parent Product Tag', 'vira-store'),
            'parent_item_colon' => __('Parent Product Tag:', 'vira-store'),
            'edit_item'         => __('Edit Product Tag', 'vira-store'),
            'update_item'       => __('Update Product Tag', 'vira-store'),
            'add_new_item'      => __('Add New Product Tag', 'vira-store'),
            'new_item_name'     => __('New Product Tag Name', 'vira-store'),
            'menu_name'         => __('Tags', 'vira-store'),
        ];

        $tag_args = [
            'hierarchical'      => false,
            'labels'            => $tag_labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => ['slug' => 'product-tag'],
            'show_in_rest'      => true,
            'meta_box_cb'       => 'post_tags_meta_box',
        ];

        register_taxonomy('vrstore_product_tag', [$this->post_type], $tag_args); 
    }

    /**
     * Add meta boxes
     *
     * @return void
     */
    public function add_meta_boxes(): void {
        add_meta_box(
            'vrstore_product_tabbed_settings',
            __('Product Settings', 'vira-store'),
            [$this, 'render_product_settings_meta_box'],
            $this->post_type,
            'normal',
            'high'
        );

        add_meta_box(
            'vrstore_license_type_filter',
            __('License Type', 'vira-store'),
            [$this, 'render_license_type_filter_meta_box'],
            $this->post_type,
            'side',
            'high'
        );

        add_meta_box(
            'vrstore_product_pricing_unified',
            __('Product Pricing', 'vira-store'),
            [$this, 'render_product_pricing_unified_meta_box'],
            $this->post_type,
            'side',
            'default'
        );

        add_meta_box(
            'vrstore_product_visibility',
            __('Product Visibility', 'vira-store'),
            [$this, 'render_product_visibility_meta_box'],
            $this->post_type,
            'side',
            'high'
        );

        add_meta_box(
            'vrstore_product_preorder',
            __('Pre-order Settings', 'vira-store'),
            [$this, 'render_product_preorder_meta_box'],
            $this->post_type,
            'side',
            'high'
        );
    }

    /**
     * Render tabbed product settings meta box.
     *
     * @param WP_Post $post Post object.
     * @return void
     */
    public function render_product_settings_meta_box( $post ): void {
        $tabs = array(
            'details' => array(
                'label'   => $this->get_translated_text( 'Details', 'vira-store' ),
                'content' => $this->get_product_tab_content( array( $this, 'render_product_details_meta_box' ), $post ),
            ),
            'files' => array(
                'label'   => $this->get_translated_text( 'Files', 'vira-store' ),
                'content' => $this->get_product_tab_content( array( $this, 'render_product_files_meta_box' ), $post ),
            ),
            'summary' => array(
                'label'   => $this->get_translated_text( 'Short Description', 'vira-store' ),
                'content' => $this->get_product_tab_content( array( $this, 'render_product_short_description_meta_box' ), $post ),
            ),
            'video' => array(
                'label'   => $this->get_translated_text( 'Video', 'vira-store' ),
                'content' => $this->get_product_tab_content( array( $this, 'render_product_video_meta_box' ), $post ),
            ),
            'plugin-updates' => array(
                'label'   => $this->get_translated_text( 'Plugin Updates', 'vira-store' ),
                'content' => $this->get_product_tab_content( array( $this, 'render_plugin_updates_meta_box' ), $post ),
            ),
        );

        $tabs = array_filter( $tabs, static function( $tab ) {
            return isset( $tab['content'] ) && '' !== trim( $tab['content'] );
        } );

        if ( empty( $tabs ) ) {
            echo '<p>' . esc_html__( 'No product settings available.', 'vira-store' ) . '</p>';
            return;
        }

        $first_tab = array_key_first( $tabs );

        echo '<style>
            .vrstore-product-tab-wrapper { margin-top: 10px; }
            .vrstore-product-tab-wrapper .vrstore-tab-nav { display: flex; flex-wrap: wrap; gap: 6px; border-bottom: 1px solid #dcdcde; margin-bottom: 0; padding-bottom: 0; }
            .vrstore-product-tab-wrapper .vrstore-tab-button { background: #f6f7f7; border: 1px solid #c3c4c7; border-bottom: none; border-radius: 4px 4px 0 0; padding: 6px 12px; font-size: 13px; line-height: 1.5; cursor: pointer; color: #50575e; }
            .vrstore-product-tab-wrapper .vrstore-tab-button.is-active { background: #fff; color: #1d2327; font-weight: 600; }
            .vrstore-product-tab-wrapper .vrstore-tab-panels { border: 1px solid #dcdcde; border-radius: 0 4px 4px 4px; padding: 16px; background: #fff; }
            .vrstore-product-tab-wrapper .vrstore-tab-panel { display: none; }
            .vrstore-product-tab-wrapper .vrstore-tab-panel.is-active { display: block; }
        </style>';

        echo '<div class="vrstore-product-tab-wrapper" data-default-tab="' . esc_attr( $first_tab ) . '">';
        echo '<div class="vrstore-tab-nav">';
        foreach ( $tabs as $slug => $tab ) {
            $is_active = $slug === $first_tab ? ' is-active' : '';
            echo '<button type="button" class="button vrstore-tab-button' . esc_attr( $is_active ) . '" data-tab-target="' . esc_attr( $slug ) . '">' . esc_html( $tab['label'] ) . '</button>';
        }
        echo '</div>';

        echo '<div class="vrstore-tab-panels">';
        foreach ( $tabs as $slug => $tab ) {
            $panel_class = $slug === $first_tab ? 'vrstore-tab-panel is-active' : 'vrstore-tab-panel';
            echo '<div class="' . esc_attr( $panel_class ) . '" data-tab="' . esc_attr( $slug ) . '">';
            echo $tab['content'];
            echo '</div>';
        }
        echo '</div>';
        echo '</div>';
    }

    /**
     * Capture meta box content for tab rendering.
     *
     * @param callable $callback Render callback.
     * @param WP_Post  $post     Post object.
     * @return string
     */
    private function get_product_tab_content( $callback, $post ): string {
        ob_start();
        call_user_func( $callback, $post );
        return ob_get_clean();
    }

    /**
     * Render product details meta box
     *
     * @param WP_Post $post Post object
     * @return void
     */
    public function render_product_details_meta_box($post): void {
        // Add nonce for security
        wp_nonce_field('vrstore_product_details_nonce', 'vrstore_product_details_nonce');

        // Get meta values
        $demo_url = get_post_meta($post->ID, '_vrstore_product_demo_url', true) ?: "";
        $documentation_url = get_post_meta($post->ID, '_vrstore_product_documentation_url', true) ?: "";
        $changelog = get_post_meta($post->ID, '_vrstore_product_changelog', true) ?: "";
        $features = get_post_meta($post->ID, '_vrstore_product_features', true) ?: "";
        $faq = get_post_meta($post->ID, '_vrstore_product_faq', true) ?: "";

        
        // Convert arrays to strings for textarea fields
        $features_text = is_array($features) ? implode("\n", $features) : $features;
        $faq_text = is_array($faq) ? implode("\n\n", array_map(function($item) {
            return 'Q: ' . $item['question'] . "\nA: " . $item['answer'];
        }, $faq)) : $faq;


        echo '<div class="vrstore-meta-box">';
        echo '<table class="form-table">';
        

        
        // Demo URL
        echo '<tr>';
        echo '<th><label for="vrstore_product_demo_url">' . $this->get_translated_text('Demo URL', 'vira-store') . '</label></th>';
        echo '<td>';
        echo '<input type="url" id="vrstore_product_demo_url" name="vrstore_product_demo_url" value="' . esc_attr($demo_url ?? "") . '" class="regular-text" placeholder="https://" />';
        echo '<p class="description">' . $this->get_translated_text('URL to live demo of the product', 'vira-store') . '</p>';
        echo '</td>';
        echo '</tr>';
        
        // Documentation URL
        echo '<tr>';
        echo '<th><label for="vrstore_product_documentation_url">' . $this->get_translated_text('Documentation URL', 'vira-store') . '</label></th>';
        echo '<td>';
        echo '<input type="url" id="vrstore_product_documentation_url" name="vrstore_product_documentation_url" value="' . esc_attr($documentation_url ?? "") . '" class="regular-text" placeholder="https://" />';
        echo '<p class="description">' . $this->get_translated_text('URL to product documentation', 'vira-store') . '</p>';
        echo '</td>';
        echo '</tr>';
        
        // Features
        echo '<tr>';
        echo '<th><label for="vrstore_product_features">' . $this->get_translated_text('Features', 'vira-store') . '</label></th>';
        echo '<td>';
        echo '<textarea id="vrstore_product_features" name="vrstore_product_features" rows="5" class="large-text" placeholder="' . esc_attr__('One feature per line', 'vira-store') . '">' . esc_textarea($features_text ?? "") . '</textarea>';
        echo '<p class="description">' . $this->get_translated_text('List key features, one per line', 'vira-store') . '</p>';
        echo '</td>';
        echo '</tr>';
        

        
        // Screenshots - gallery of product images
        $screenshots = get_post_meta($post->ID, '_vrstore_product_screenshots', true) ?: "";
        $screenshots_text = is_array($screenshots) ? implode(",", $screenshots) : $screenshots;
        echo '<tr>';
        echo '<th><label for="vrstore_product_screenshots">' . esc_html__('Screenshots Gallery', 'vira-store') . '</label></th>';
        echo '<td>';
        echo '<input type="text" id="vrstore_product_screenshots" name="vrstore_product_screenshots" value="' . esc_attr($screenshots_text ?? "") . '" class="large-text" placeholder="' . esc_attr__('Image attachment IDs (comma-separated) or gallery shortcode', 'vira-store') . '" />';
        echo '<br><button type="button" class="button vrstore-select-gallery" data-target="vrstore_product_screenshots">' . esc_html__('Select Images', 'vira-store') . '</button> ';
        echo '<button type="button" class="button vrstore-clear-gallery" data-target="vrstore_product_screenshots">' . esc_html__('Clear', 'vira-store') . '</button>';
        echo '<p class="description">' . esc_html__('Select images for the product gallery or enter attachment IDs manually (e.g., 123,456,789)', 'vira-store') . '</p>';
        echo '</td>';
        echo '</tr>';
                
        // FAQ
        echo '<tr>';
        echo '<th><label for="vrstore_product_faq">' . $this->get_translated_text('FAQ', 'vira-store') . '</label></th>';
        echo '<td>';
        echo '<textarea id="vrstore_product_faq" name="vrstore_product_faq" rows="8" class="large-text" placeholder="' . esc_attr__('Q: Question?\nA: Answer...\n\nQ: Another question?\nA: Another answer...', 'vira-store') . '">' . esc_textarea($faq_text ?? "") . '</textarea>';
        echo '<p class="description">' . $this->get_translated_text('Frequently asked questions. Format: Q: Question? A: Answer...', 'vira-store') . '</p>';
        echo '</td>';
        echo '</tr>';
        
        // Changelog
        echo '<tr>';
        echo '<th><label for="vrstore_product_changelog">' . $this->get_translated_text('Changelog', 'vira-store') . '</label></th>';
        echo '<td>';
        echo '<textarea id="vrstore_product_changelog" name="vrstore_product_changelog" rows="8" class="large-text" placeholder="' . esc_attr__('v1.0.0\n- Initial release\n- Feature 1\n- Feature 2', 'vira-store') . '">' . esc_textarea($changelog ?? "") . '</textarea>';
        echo '<p class="description">' . $this->get_translated_text('Version history and changes', 'vira-store') . '</p>';
        echo '</td>';
        echo '</tr>';
        
        // Disable License Generation
        $disable_license_generation = get_post_meta($post->ID, '_vrstore_disable_license_generation', true);
        echo '<tr>';
        echo '<th><label for="vrstore_disable_license_generation">' . $this->get_translated_text('License Settings', 'vira-store') . '</label></th>';
        echo '<td>';
        echo '<label><input type="checkbox" id="vrstore_disable_license_generation" name="vrstore_disable_license_generation" value="1"' . checked($disable_license_generation, '1', false) . ' /> ';
        echo $this->get_translated_text('Disable license generation for this product', 'vira-store') . '</label>';
        echo '<p class="description">' . $this->get_translated_text('Check this box if this product does not require a license key (e.g., digital content, services, etc.)', 'vira-store') . '</p>';
        echo '</td>';
        echo '</tr>';
        
        echo '</table>';
        echo '</div>';
    }

    /**
     * Render product files meta box
     *
     * @param WP_Post $post Post object
     * @return void
     */
    public function render_product_files_meta_box($post): void {
        // Add nonce for security
        wp_nonce_field('vrstore_product_files_nonce', 'vrstore_product_files_nonce');

        // Get meta values
        $files = get_post_meta($post->ID, '_vrstore_product_files', true) ?: "";
        if (!is_array($files)) {
            $files = [];
        }

        // Output fields
        echo '<div class="vrstore-product-files">';
        echo '<p>' . esc_html__('Add files for this digital product. You can upload files or provide external URLs (e.g., Google Drive, Dropbox).', 'vira-store') . '</p>';

        echo '<div class="vrstore-product-files-list">';
        if (!empty($files)) {
            foreach ($files as $index => $file) {
                $file_type = isset($file['type']) ? $file['type'] : 'url';
                echo '<div class="vrstore-product-file" data-index="' . esc_attr($index ?? "") . '">';
                echo '<div class="vrstore-file-row">';
                echo '<input type="text" name="vrstore_product_files[' . esc_attr($index ?? "") . '][name]" value="' . esc_attr($file['name'] ?? "") . '" placeholder="' . esc_attr__('File Name', 'vira-store') . '" class="vrstore-file-name" />';
                echo '<select name="vrstore_product_files[' . esc_attr($index ?? "") . '][type]" class="vrstore-file-type">';
                echo '<option value="url"' . selected($file_type, 'url', false) . '>' . $this->get_translated_text('External URL', 'vira-store') . '</option>';
                echo '<option value="upload"' . selected($file_type, 'upload', false) . '>' . $this->get_translated_text('Upload File', 'vira-store') . '</option>';
                echo '</select>';
                echo '<button type="button" class="button vrstore-remove-file">' . $this->get_translated_text('Remove', 'vira-store') . '</button>';
                echo '</div>';
                echo '<div class="vrstore-file-input-row">';
                echo '<input type="text" name="vrstore_product_files[' . esc_attr($index ?? "") . '][url]" value="' . esc_attr($file['url'] ?? "") . '" placeholder="' . esc_attr__('File URL or select upload', 'vira-store') . '" class="vrstore-file-url large-text" />';
                echo '<button type="button" class="button vrstore-upload-file" data-index="' . esc_attr($index ?? "") . '">' . $this->get_translated_text('Upload File', 'vira-store') . '</button>';
                echo '<button type="button" class="button vrstore-select-media" data-index="' . esc_attr($index ?? "") . '">' . $this->get_translated_text('Select from Media', 'vira-store') . '</button>';
                echo '</div>';
                if (!empty($file['url'])) {
                    echo '<div class="vrstore-file-preview"><small><strong>' . $this->get_translated_text('Current file:', 'vira-store') . '</strong> <a href="' . esc_url($file['url'] ?? "") . '" target="_blank">' . esc_html(basename($file['url'])) . '</a></small></div>';
                }
                echo '</div>';
            }
        } else {
            echo '<div class="vrstore-product-file" data-index="0">';
            echo '<div class="vrstore-file-row">';
            echo '<input type="text" name="vrstore_product_files[0][name]" value="" placeholder="' . esc_attr__('File Name', 'vira-store') . '" class="vrstore-file-name" />';
            echo '<select name="vrstore_product_files[0][type]" class="vrstore-file-type">';
            echo '<option value="url">' . esc_html__('External URL', 'vira-store') . '</option>';
            echo '<option value="upload">' . esc_html__('Upload File', 'vira-store') . '</option>';
            echo '</select>';
            echo '<button type="button" class="button vrstore-remove-file">' . esc_html__('Remove', 'vira-store') . '</button>';
            echo '</div>';
            echo '<div class="vrstore-file-input-row">';
            echo '<input type="text" name="vrstore_product_files[0][url]" value="" placeholder="' . esc_attr__('File URL or select upload', 'vira-store') . '" class="vrstore-file-url large-text" />';
            echo '<button type="button" class="button vrstore-upload-file" data-index="0">' . esc_html__('Upload File', 'vira-store') . '</button>';
            echo '<button type="button" class="button vrstore-select-media" data-index="0">' . esc_html__('Select from Media', 'vira-store') . '</button>';
            echo '</div>';
            echo '</div>';
        }
        echo '</div>';

        echo '<button type="button" class="button vrstore-add-file">' . esc_html__('Add File', 'vira-store') . '</button>';
        
        // Styles moved to admin.css
        
        echo '</div>';
    }

    /**
     * Render product short description meta box
     *
     * @param WP_Post $post Post object
     * @return void
     */
    public function render_product_short_description_meta_box($post): void {
        // Add nonce for security
        wp_nonce_field('vrstore_product_short_description_nonce', 'vrstore_product_short_description_nonce');

        // Get meta values
        $short_description = get_post_meta($post->ID, '_vrstore_product_short_description', true) ?: "";

        echo '<div class="vrstore-meta-box">';
        echo '<p>' . esc_html__('Enter a brief description that will be displayed on the product summary.', 'vira-store') . '</p>';
        echo '<textarea id="vrstore_product_short_description" name="vrstore_product_short_description" rows="4" class="widefat" placeholder="' . esc_attr__('Enter short product description...', 'vira-store') . '">' . esc_textarea($short_description ?? "") . '</textarea>';
        echo '</div>';
    }

    /**
     * Render product video meta box
     *
     * @param WP_Post $post Post object
     * @return void
     */
    public function render_product_video_meta_box($post): void {
        // Add nonce for security
        wp_nonce_field('vrstore_product_video_nonce', 'vrstore_product_video_nonce');

        // Get meta values
        $video_type = get_post_meta($post->ID, '_vrstore_product_video_type', true) ?: 'youtube';
        $youtube_url = get_post_meta($post->ID, '_vrstore_product_youtube_url', true) ?: '';
        $video_upload_id = get_post_meta($post->ID, '_vrstore_product_video_upload', true) ?: '';
        $license_info_text = get_post_meta($post->ID, '_vrstore_product_license_info', true) ?: '';

        echo '<div class="vrstore-product-video">';
        echo '<p>' . esc_html__('Configure video content and license information that will be displayed in a modal popup beside demo/documentation links.', 'vira-store') . '</p>';

        // Video Type Selection
        echo '<table class="form-table">';
        echo '<tr>';
        echo '<th><label for="vrstore_product_video_type">' . esc_html__('Video Type', 'vira-store') . '</label></th>';
        echo '<td>';
        echo '<select id="vrstore_product_video_type" name="vrstore_product_video_type" class="regular-text">';
        echo '<option value="youtube"' . selected($video_type, 'youtube', false) . '>' . esc_html__('YouTube', 'vira-store') . '</option>';
        echo '<option value="upload"' . selected($video_type, 'upload', false) . '>' . $this->get_translated_text('Upload Video', 'vira-store') . '</option>';
        echo '<option value="none"' . selected($video_type, 'none', false) . '>' . $this->get_translated_text('No Video', 'vira-store') . '</option>';
        echo '</select>';
        echo '<p class="description">' . $this->get_translated_text('Choose the type of video to display', 'vira-store') . '</p>';
        echo '</td>';
        echo '</tr>';

        // YouTube URL
        echo '<tr id="youtube-url-row" style="' . ($video_type !== 'youtube' ? 'display: none;' : '') . '">';
        echo '<th><label for="vrstore_product_youtube_url">' . $this->get_translated_text('YouTube URL', 'vira-store') . '</label></th>';
        echo '<td>';
        echo '<input type="url" id="vrstore_product_youtube_url" name="vrstore_product_youtube_url" value="' . esc_attr($youtube_url) . '" class="regular-text" placeholder="https://www.youtube.com/watch?v=..." />';
        echo '<p class="description">' . $this->get_translated_text('Enter the full YouTube URL', 'vira-store') . '</p>';
        echo '</td>';
        echo '</tr>';

        // Video Upload
        echo '<tr id="video-upload-row" style="' . ($video_type !== 'upload' ? 'display: none;' : '') . '">';
        echo '<th><label for="vrstore_product_video_upload">' . $this->get_translated_text('Upload Video', 'vira-store') . '</label></th>';
        echo '<td>';
        $video_url = '';
        if ($video_upload_id) {
            $video_url = wp_get_attachment_url($video_upload_id);
        }
        echo '<input type="hidden" id="vrstore_product_video_upload" name="vrstore_product_video_upload" value="' . esc_attr($video_upload_id) . '" />';
        echo '<input type="text" id="vrstore_product_video_upload_url" value="' . esc_attr($video_url) . '" class="regular-text" readonly placeholder="' . esc_attr__('No video selected', 'vira-store') . '" />';
        echo '<button type="button" class="button" id="vrstore-upload-video">' . esc_html__('Select Video', 'vira-store') . '</button>';
        echo '<button type="button" class="button" id="vrstore-remove-video" style="' . (empty($video_upload_id) ? 'display: none;' : '') . '">' . esc_html__('Remove', 'vira-store') . '</button>';
        echo '<p class="description">' . esc_html__('Upload or select a video file from media library', 'vira-store') . '</p>';
        echo '</td>';
        echo '</tr>';

        // License Information
        echo '<tr>';
        echo '<th><label for="vrstore_product_license_info">' . esc_html__('License Information', 'vira-store') . '</label></th>';
        echo '<td>';
        echo '<textarea id="vrstore_product_license_info" name="vrstore_product_license_info" rows="5" class="large-text" placeholder="' . esc_attr__('Enter detailed license information that will be displayed in the modal...', 'vira-store') . '">' . esc_textarea($license_info_text) . '</textarea>';
        echo '<p class="description">' . esc_html__('This information will be displayed in the modal popup', 'vira-store') . '</p>';
        echo '</td>';
        echo '</tr>';
        echo '</table>';
        
        echo '</div>';
    }

    /**
     * Render product visibility meta box
     *
     * @param WP_Post $post Post object
     * @return void
     */
    public function render_product_visibility_meta_box($post): void {
        // Add nonce for security
        wp_nonce_field('vrstore_product_visibility_nonce', 'vrstore_product_visibility_nonce');

        // Get current visibility setting
        $visibility = get_post_meta($post->ID, '_vrstore_product_visibility', true);
        if (empty($visibility)) {
            // Default to 'public' if no visibility is set
            $visibility = 'public';
        }

        // Get password if visibility is password protected
        $password = get_post_meta($post->ID, '_vrstore_product_password', true);
        if (empty($password) && $post->post_password) {
            $password = $post->post_password;
        }

        echo '<div class="vrstore-visibility-meta-box">';
        echo '<p><strong>' . __('Visibility:', 'vira-store') . '</strong> ';
        echo '<span id="vrstore-visibility-display">' . $this->get_visibility_label($visibility) . '</span> ';
        echo '<a href="#visibility" class="edit-visibility hide-if-no-js" role="button">' . __('Edit', 'vira-store') . '</a></p>';
        
        echo '<div id="vrstore-visibility-select" class="hide-if-js">';
        echo '<input type="hidden" name="hidden_post_password" id="hidden_post_password" value="' . esc_attr($password) . '" />';
        echo '<input type="radio" name="vrstore_product_visibility" id="vrstore-visibility-public" value="public"' . checked($visibility, 'public', false) . ' />';
        echo '<label for="vrstore-visibility-public" class="selectit">' . __('Public', 'vira-store') . '</label><br />';
        
        echo '<input type="radio" name="vrstore_product_visibility" id="vrstore-visibility-password" value="password"' . checked($visibility, 'password', false) . ' />';
        echo '<label for="vrstore-visibility-password" class="selectit">' . __('Password protected', 'vira-store') . '</label><br />';
        echo '<span id="vrstore-password-span"' . ($visibility !== 'password' ? ' style="display:none;"' : '') . '>';
        echo '<label for="vrstore_product_password">' . __('Password:', 'vira-store') . '</label> ';
        echo '<input type="text" name="vrstore_product_password" id="vrstore_product_password" value="' . esc_attr($password) . '" maxlength="20" /><br />';
        echo '</span>';
        
        echo '<input type="radio" name="vrstore_product_visibility" id="vrstore-visibility-private" value="private"' . checked($visibility, 'private', false) . ' />';
        echo '<label for="vrstore-visibility-private" class="selectit">' . __('Private', 'vira-store') . '</label><br />';
        
        echo '<input type="radio" name="vrstore_product_visibility" id="vrstore-visibility-hidden" value="hidden"' . checked($visibility, 'hidden', false) . ' />';
        echo '<label for="vrstore-visibility-hidden" class="selectit">' . __('Hidden from catalog', 'vira-store') . '</label><br />';
        
        echo '<p><a href="#visibility" class="save-post-visibility hide-if-no-js button">' . __('OK', 'vira-store') . '</a> ';
        echo '<a href="#visibility" class="cancel-post-visibility hide-if-no-js button-cancel">' . __('Cancel', 'vira-store') . '</a></p>';
        echo '</div>';
        
        echo '<p class="description">';
        echo '<strong>' . __('Public:', 'vira-store') . '</strong> ' . __('Visible to everyone', 'vira-store') . '<br/>';
        echo '<strong>' . __('Password protected:', 'vira-store') . '</strong> ' . __('Requires password to view', 'vira-store') . '<br/>';
        echo '<strong>' . __('Private:', 'vira-store') . '</strong> ' . __('Only visible to administrators', 'vira-store') . '<br/>';
        echo '<strong>' . __('Hidden from catalog:', 'vira-store') . '</strong> ' . __('Not shown in product lists but accessible via direct link', 'vira-store');
        echo '</p>';
        
        echo '</div>';
    }

    /**
     * Get visibility label for display
     *
     * @param string $visibility
     * @return string
     */
    private function get_visibility_label($visibility) {
        switch ($visibility) {
            case 'password':
                return __('Password protected', 'vira-store');
            case 'private':
                return __('Private', 'vira-store');
            case 'hidden':
                return __('Hidden from catalog', 'vira-store');
            default:
                return __('Public', 'vira-store');
        }
    }

    /**
     * Check if a product should be visible to the current user
     *
     * @param int $product_id Product ID
     * @param string $context Context where visibility is checked (catalog, single, search)
     * @return bool True if product should be visible
     */
    public static function is_product_visible($product_id, $context = 'catalog') {
        // Prevent infinite recursion during capability checks
        static $checking = [];
        if (isset($checking[$product_id])) {
            return true; // Default to visible to prevent recursion
        }
        $checking[$product_id] = true;
        
        // Get the product post
        $product = get_post($product_id);
        if (!$product || $product->post_type !== 'vrstore_product') {
            unset($checking[$product_id]);
            return false;
        }

        // Check WordPress post status first
        if (!in_array($product->post_status, ['publish', 'private'], true)) {
            unset($checking[$product_id]);
            return false;
        }

        // Get custom visibility setting
        $visibility = get_post_meta($product_id, '_vrstore_product_visibility', true);
        if (empty($visibility)) {
            $visibility = 'public'; // Default to public
        }

        $result = true; // Default result
        
        // Check visibility based on current user capabilities
        switch ($visibility) {
            case 'private':
                // Only visible to administrators - use safer capability check
                $result = current_user_can('manage_options') || current_user_can('edit_posts');
                break;

            case 'password':
                // Check if user has entered correct password or is administrator
                if (current_user_can('manage_options') || current_user_can('edit_posts')) {
                    $result = true; // Admins can always see password-protected products
                } else {
                    // For single product view, WordPress handles password protection
                    if ($context === 'single') {
                        $result = true; // Let WordPress handle the password form
                    } else {
                        // For catalog/listing, check if password has been entered
                        $result = post_password_required($product) === false;
                    }
                }
                break;

            case 'hidden':
                // Hidden from catalog but accessible via direct link
                if ($context === 'catalog' || $context === 'search') {
                    $result = false;
                } else {
                    $result = true; // Visible on single product pages
                }
                break;

            case 'public':
            default:
                $result = true;
                break;
        }
        
        unset($checking[$product_id]);
        return $result;
    }

    /**
     * Apply visibility filters to WP_Query arguments
     *
     * @param array $args WP_Query arguments
     * @param string $context Context (catalog, search, etc.)
     * @return array Modified arguments
     */
    public static function apply_visibility_filters($args, $context = 'catalog') {
        // Prevent infinite recursion during capability checks
        static $applying_filters = false;
        if ($applying_filters) {
            return $args;
        }
        $applying_filters = true;
        
        // Don't apply filters in admin or for administrators
        if (is_admin() && !wp_doing_ajax()) {
            $applying_filters = false;
            return $args;
        }

        // Add meta query to exclude hidden products from catalog listings
        if ($context === 'catalog' || $context === 'search') {
            if (!isset($args['meta_query'])) {
                $args['meta_query'] = [];
            }

            // Exclude hidden products from catalog
            $args['meta_query'][] = [
                'relation' => 'OR',
                [
                    'key'     => '_vrstore_product_visibility',
                    'value'   => 'hidden',
                    'compare' => '!='
                ],
                [
                    'key'     => '_vrstore_product_visibility',
                    'compare' => 'NOT EXISTS'
                ]
            ];

            // Check if user is admin using a safer method
            $is_admin = false;
            if (function_exists('wp_get_current_user')) {
                $current_user = wp_get_current_user();
                $is_admin = $current_user && (
                    $current_user->has_cap('manage_options') || 
                    $current_user->has_cap('edit_posts')
                );
            }
            
            // If user is not admin, also exclude private products
            if (!$is_admin) {
                $args['meta_query'][] = [
                    'relation' => 'OR',
                    [
                        'key'     => '_vrstore_product_visibility',
                        'value'   => 'private',
                        'compare' => '!='
                    ],
                    [
                        'key'     => '_vrstore_product_visibility',
                        'compare' => 'NOT EXISTS'
                    ]
                ];
            }
        }

        $applying_filters = false;
        return $args;
    }

    /**
     * Render unified product pricing meta box
     *
     * @param WP_Post $post Post object
     * @return void
     */
    public function render_product_pricing_unified_meta_box($post): void {
        // Add nonce for security
        wp_nonce_field('vrstore_product_pricing_unified_nonce', 'vrstore_product_pricing_unified_nonce');
        
        // Get current pricing mode
        $pricing_mode = get_post_meta($post->ID, '_vrstore_pricing_mode', true) ?: 'product';
        
        // Get meta values for product pricing
        $price = get_post_meta($post->ID, '_vrstore_product_price', true) ?: "";
        $sale_price = get_post_meta($post->ID, '_vrstore_product_sale_price', true) ?: "";
        $currency = get_post_meta($post->ID, '_vrstore_product_currency', true) ?: "USD";
        
        // Get license pricing data
        $license_pricing = get_post_meta($post->ID, '_vrstore_product_license_pricing', true);
        if (!is_array($license_pricing)) {
            $license_pricing = [];
        }
        
        // Get license type availability settings
        $license_availability = get_post_meta($post->ID, '_vrstore_product_license_availability', true);
        if (!is_array($license_availability)) {
            $license_availability = [];
        }
        
        // Get global currency
        $settings = VRSTORE_Settings::get_instance();
        $global_currency = $settings->get_setting('currency', 'USD');
        $currency_symbol = $this->get_currency_symbol($global_currency);
        
        echo '<div class="vrstore-meta-box vrstore-pricing-unified">';
        
        // Unified License Pricing System - no mode toggle needed
        
        // Unified License Pricing Section
        echo '<div id="license-pricing-section" class="pricing-section">';
        echo '<h4 style="margin: 0 0 15px 0; padding-bottom: 10px; border-bottom: 1px solid #ddd;">' . esc_html__('Product Pricing', 'vira-store') . '</h4>';
        
        // Get custom license types from global settings (ONLY source)
        $settings_array = get_option('vrstore_settings', []);
        $custom_license_types = $settings_array['custom_license_types'] ?? [];
        
        // Display license types (ONLY custom types - taxonomy removed)
        $all_license_types = [];
        
        // Add custom license types from settings
        if (!empty($custom_license_types) && is_array($custom_license_types)) {
            foreach ($custom_license_types as $custom_type) {
                if (isset($custom_type['label']) && !empty($custom_type['label'])) {
                    $slug = isset($custom_type['slug']) ? $custom_type['slug'] : sanitize_title($custom_type['label']);
                    $all_license_types[] = [
                        'slug' => $slug,
                        'name' => $custom_type['label'],
                        'source' => 'custom',
                        'default_price' => $custom_type['regular_price'] ?? '',
                        'default_sale_price' => $custom_type['sale_price'] ?? '',
                        'expiry_months' => $custom_type['expiry_months'] ?? '',
                        'max_activations' => $custom_type['max_activations'] ?? ''
                    ];
                }
            }
        }
        
        if (!empty($all_license_types)) {
            foreach ($all_license_types as $license_type) {
                $license_price = isset($license_pricing[$license_type['slug']]['price']) ? $license_pricing[$license_type['slug']]['price'] : '';
                $license_sale_price = isset($license_pricing[$license_type['slug']]['sale_price']) ? $license_pricing[$license_type['slug']]['sale_price'] : '';
                
                // Use default prices from global settings if no product-specific price is set
                if (empty($license_price) && isset($license_type['default_price'])) {
                    $license_price = $license_type['default_price'];
                }
                if (empty($license_sale_price) && isset($license_type['default_sale_price'])) {
                    $license_sale_price = $license_type['default_sale_price'];
                }
                
                // Check if this license type is available
                // Note: The admin saves false for disabled types, so we check for explicit true or missing setting
                $is_available = (isset($license_availability[$license_type['slug']]) && $license_availability[$license_type['slug']] === true) || 
                               !isset($license_availability[$license_type['slug']]);
                $group_opacity = $is_available ? '1' : '0.6';
                
                echo '<div class="license-pricing-group" style="margin-bottom: 20px; padding: 15px; background: #f9f9f9; border-radius: 5px; opacity: ' . $group_opacity . ';" data-license-slug="' . esc_attr($license_type['slug']) . '">';
                
                // Header with title and availability checkbox (source badge removed - all are custom now)
                echo '<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">';
                echo '<div style="display: flex; align-items: center; gap: 10px;">';
                echo '<h5 style="margin: 0; color: #333;">' . esc_html($license_type['name']) . '</h5>';
                
                // Availability checkbox
                echo '<label style="display: flex; align-items: center; gap: 5px; font-size: 12px; color: #666; cursor: pointer;">';
                echo '<input type="checkbox" ';
                echo 'name="vrstore_product_license_availability[' . esc_attr($license_type['slug']) . ']" ';
                echo 'value="1" ';
                echo 'class="license-availability-checkbox" ';
                echo 'data-license-slug="' . esc_attr($license_type['slug']) . '" ';
                echo ($is_available ? 'checked' : '') . '> ';
                echo '<span style="font-weight: 500;">' . esc_html__('Available', 'vira-store') . '</span>';
                echo '</label>';
                echo '</div>';
                echo '</div>';
                
                // Show additional info for custom license types
                if ($license_type['source'] === 'custom' && (isset($license_type['expiry_months']) || isset($license_type['max_activations']))) {
                    echo '<div style="margin-bottom: 10px; font-size: 12px; color: #666;">';
                    if (!empty($license_type['expiry_months'])) {
                        echo '<span style="margin-right: 15px;">📅 ' . sprintf($this->get_translated_text('Expires: %d months', 'vira-store'), $license_type['expiry_months']) . '</span>';
                    }
                    if (!empty($license_type['max_activations'])) {
                        echo '<span>🔑 ' . sprintf($this->get_translated_text('Max activations: %d', 'vira-store'), $license_type['max_activations']) . '</span>';
                    }
                    echo '</div>';
                }
                
                // Regular Price
                echo '<div style="margin-bottom: 10px;">';
                echo '<label for="license_price_' . esc_attr($license_type['slug']) . '" style="display: block; font-weight: bold; margin-bottom: 5px;">' . $this->get_translated_text('Regular Price', 'vira-store') . ':</label>';
                echo '<div style="display: flex; align-items: center; gap: 5px;">';
                echo '<span style="font-weight: bold;">' . esc_html($currency_symbol) . '</span>';
                echo '<input type="number" ';
                echo 'id="license_price_' . esc_attr($license_type['slug']) . '" ';
                echo 'name="vrstore_product_license_pricing[' . esc_attr($license_type['slug']) . '][price]" ';
                echo 'value="' . esc_attr($license_price) . '" ';
                echo 'step="0.01" min="0" ';
                echo 'style="width: 120px;" ';
                echo 'placeholder="0.00" ';
                echo 'class="license-price-input" ';
                echo 'data-license-slug="' . esc_attr($license_type['slug']) . '" ';
                echo 'data-default-price="' . esc_attr($license_type['default_price'] ?? '') . '" ';
                echo ($is_available ? '' : 'disabled') . ' />';

                echo '</div>';
                echo '</div>';
                
                // Sale Price
                echo '<div style="margin-bottom: 10px;">';
                echo '<label for="license_sale_price_' . esc_attr($license_type['slug']) . '" style="display: block; font-weight: bold; margin-bottom: 5px;">' . $this->get_translated_text('Sale Price', 'vira-store') . ':</label>';
                echo '<div style="display: flex; align-items: center; gap: 5px;">';
                echo '<span style="font-weight: bold;">' . esc_html($currency_symbol) . '</span>';
                echo '<input type="number" ';
                echo 'id="license_sale_price_' . esc_attr($license_type['slug']) . '" ';
                echo 'name="vrstore_product_license_pricing[' . esc_attr($license_type['slug']) . '][sale_price]" ';
                echo 'value="' . esc_attr($license_sale_price) . '" ';
                echo 'step="0.01" min="0" ';
                echo 'style="width: 125px;" ';
                echo 'placeholder="0.00" ';
                echo 'class="license-price-input" ';
                echo 'data-license-slug="' . esc_attr($license_type['slug']) . '" ';
                echo 'data-default-sale-price="' . esc_attr($license_type['default_sale_price'] ?? '') . '" ';
                echo ($is_available ? '' : 'disabled') . ' />';

                echo '</div>';
                echo '<p class="description" style="margin-top: 3px; font-size: 12px; color: #666;">' . $this->get_translated_text('Optional. Leave empty if no sale price.', 'vira-store') . '</p>';
                echo '</div>';
                
                echo '</div>';
            }
        } else {
            echo '<div style="padding: 20px; text-align: center; background: #fff3cd; border: 1px solid #ffeaa7; border-radius: 5px;">';
            echo '<p style="margin: 0 0 10px 0; font-weight: bold; color: #856404;">' . $this->get_translated_text('No License Types Found', 'vira-store') . '</p>';
            echo '<p style="margin: 0 0 15px 0; color: #856404;">' . $this->get_translated_text('Create license types in the global settings to enable per-license pricing.', 'vira-store') . '</p>';
            echo '<a href="' . esc_url(admin_url('admin.php?page=vrstore-settings-page&tab=license')) . '" class="button button-primary" target="_blank">' . $this->get_translated_text('Configure License Settings', 'vira-store') . '</a>';
            echo '</div>';
        }
        
        echo '</div>';
        
        // License pricing interface ready
        
    // License availability & filter JS moved to assets/js/admin.js and enqueued via enqueue_admin_assets()
        
    echo '</div>';
    }

    /**
     * Render license type filter meta box
     *
     * @param WP_Post $post Post object
     * @return void
     */
    public function render_license_type_filter_meta_box($post): void {
        // Get all available license types
        $settings = get_option('vrstore_settings', []);
        $custom_license_types = $settings['custom_license_types'] ?? [];
        
        // Get taxonomy-based license types
        $license_types = get_terms([
            'taxonomy' => 'vrstore_license_type',
            'hide_empty' => false,
        ]);
        
        // Combine all license types
        $all_license_types = [];
        
        // Add taxonomy-based license types
        if (!empty($license_types) && !is_wp_error($license_types)) {
            foreach ($license_types as $license_type) {
                $all_license_types[] = [
                    'slug' => $license_type->slug,
                    'name' => $license_type->name,
                    'source' => 'taxonomy'
                ];
            }
        }
        
        // Add custom license types from settings
        if (!empty($custom_license_types) && is_array($custom_license_types)) {
            foreach ($custom_license_types as $custom_type) {
                if (isset($custom_type['label']) && !empty($custom_type['label'])) {
                    $slug = isset($custom_type['slug']) ? $custom_type['slug'] : sanitize_title($custom_type['label']);
                    $all_license_types[] = [
                        'slug' => $slug,
                        'name' => $custom_type['label'],
                        'source' => 'custom'
                    ];
                }
            }
        }
        
        echo '<div class="vrstore-license-filter">';
        echo '<p><strong>' . esc_html__('Filter License Types:', 'vira-store') . '</strong></p>';
        
        if (!empty($all_license_types)) {
            echo '<select id="vrstore-license-filter-dropdown" style="width: 100%; margin-bottom: 10px;">';
            echo '<option value="all">' . esc_html__('Show All License Types', 'vira-store') . '</option>';
            
            foreach ($all_license_types as $license_type) {
                echo '<option value="' . esc_attr($license_type['slug']) . '">';
                echo esc_html($license_type['name']);
                echo '</option>';
            }
            
            echo '</select>';
            
            echo '<p class="description">' . esc_html__('Select a license type to show only that pricing option in the Product Pricing section below. you can override new product pricing from global settings.', 'vira-store') . '</p>';
        } else {
            echo '<p style="color: #666; font-style: italic;">' . esc_html__('No license types configured.', 'vira-store') . '</p>';
            echo '<a href="' . esc_url(admin_url('admin.php?page=vrstore-settings-page&tab=license')) . '" class="button button-secondary" target="_blank">' . esc_html__('Configure License Types', 'vira-store') . '</a>';
        }
        
        echo '</div>';
    }

    /**
     * Render product pre-order meta box
     *
     * @param WP_Post $post Post object
     * @return void
     */
    public function render_product_preorder_meta_box($post): void {
        // Add nonce for security
        wp_nonce_field('vrstore_product_preorder_nonce', 'vrstore_product_preorder_nonce');

        // Get meta values
        $is_preorder = get_post_meta($post->ID, '_vrstore_product_is_preorder', true);
        $preorder_release_date = get_post_meta($post->ID, '_vrstore_product_preorder_release_date', true);
        $preorder_message = get_post_meta($post->ID, '_vrstore_product_preorder_message', true);
        $preorder_discount = get_post_meta($post->ID, '_vrstore_product_preorder_discount', true);
        $preorder_limit = get_post_meta($post->ID, '_vrstore_product_preorder_limit', true);

        echo '<div class="vrstore-meta-box">';
        echo '<table class="form-table">';

        // Enable Pre-order
        echo '<tr>';
        echo '<th><label for="vrstore_product_is_preorder">' . $this->get_translated_text('Pre-order', 'vira-store') . '</label></th>';
        echo '<td>';
        echo '<label><input type="checkbox" id="vrstore_product_is_preorder" name="vrstore_product_is_preorder" value="1"' . checked($is_preorder, '1', false) . ' /> ';
        echo $this->get_translated_text('Pre-order Mode', 'vira-store') . '</label>';
        echo '<p class="description">' . $this->get_translated_text('Enable pre-order product before release', 'vira-store') . '</p>';
        echo '</td>';
        echo '</tr>';

        // Release Date
        echo '<tr class="preorder-field" style="' . ($is_preorder ? '' : 'display: none;') . '">';
        echo '<th><label for="vrstore_product_preorder_release_date">' . $this->get_translated_text('Release Date', 'vira-store') . '</label></th>';
        echo '<td>';
        echo '<input type="datetime-local" id="vrstore_product_preorder_release_date" name="vrstore_product_preorder_release_date" value="' . esc_attr($preorder_release_date) . '" class="regular-text" />';
        echo '<p class="description">' . $this->get_translated_text('When will this product be released and available for download?', 'vira-store') . '</p>';
        echo '</td>';
        echo '</tr>';

        // Pre-order Message
        echo '<tr class="preorder-field" style="' . ($is_preorder ? '' : 'display: none;') . '">';
        echo '<th><label for="vrstore_product_preorder_message">' . $this->get_translated_text('Pre-order Message', 'vira-store') . '</label></th>';
        echo '<td>';
        echo '<textarea id="vrstore_product_preorder_message" name="vrstore_product_preorder_message" rows="3" class="large-text" placeholder="' . esc_attr__('This product is available for pre-order. You will receive download access on the release date.', 'vira-store') . '">' . esc_textarea($preorder_message) . '</textarea>';
        echo '<p class="description">' . $this->get_translated_text('Custom message to display to customers about the pre-order', 'vira-store') . '</p>';
        echo '</td>';
        echo '</tr>';

        // Pre-order Discount
        echo '<tr class="preorder-field" style="' . ($is_preorder ? '' : 'display: none;') . '">';
        echo '<th><label for="vrstore_product_preorder_discount">' . $this->get_translated_text('Pre-order Discount (%)', 'vira-store') . '</label></th>';
        echo '<td>';
        echo '<input type="number" id="vrstore_product_preorder_discount" name="vrstore_product_preorder_discount" value="' . esc_attr($preorder_discount) . '" min="0" max="100" step="1" class="small-text" placeholder="0" />';
        echo '<p class="description">' . $this->get_translated_text('Optional discount percentage for pre-orders (e.g., 20 for 20% off)', 'vira-store') . '</p>';
        echo '</td>';
        echo '</tr>';

        // Pre-order Limit
        echo '<tr class="preorder-field" style="' . ($is_preorder ? '' : 'display: none;') . '">';
        echo '<th><label for="vrstore_product_preorder_limit">' . $this->get_translated_text('Pre-order Limit', 'vira-store') . '</label></th>';
        echo '<td>';
        echo '<input type="number" id="vrstore_product_preorder_limit" name="vrstore_product_preorder_limit" value="' . esc_attr($preorder_limit) . '" min="0" step="1" class="small-text" placeholder="0" />';
        echo '<p class="description">' . $this->get_translated_text('Maximum number of pre-orders allowed (0 = unlimited)', 'vira-store') . '</p>';
        echo '</td>';
        echo '</tr>';

        echo '</table>';
        echo '</div>';

        // Add JavaScript for showing/hiding pre-order fields
        echo '<script>
        jQuery(document).ready(function($) {
            $("#vrstore_product_is_preorder").change(function() {
                if ($(this).is(":checked")) {
                    $(".preorder-field").show();
                } else {
                    $(".preorder-field").hide();
                }
            });
        });
        </script>';
    }

    /**
     * Save meta boxes
     *
     * @param int     $post_id Post ID
     * @param WP_Post $post    Post object
     * @return void
     */
    public function save_meta_boxes(int $post_id, $post): void {
        // Prevent infinite recursion during save operations
        static $saving_posts = [];
        if (isset($saving_posts[$post_id])) {
            return; // Exit early to prevent recursion
        }
        $saving_posts[$post_id] = true;
        
        // Check if we're saving the correct post type
        if ($post->post_type !== $this->post_type) {
            unset($saving_posts[$post_id]);
            return;
        }

        // Check if user has permissions to save data
        if (!current_user_can('edit_post', $post_id)) {
            unset($saving_posts[$post_id]);
            return;
        }

        // Check if not an autosave
        if (wp_is_post_autosave($post_id)) {
            unset($saving_posts[$post_id]);
            return;
        }

        // Check if not a revision
        if (wp_is_post_revision($post_id)) {
            unset($saving_posts[$post_id]);
            return;
        }

        // Save product details
        if (isset($_POST['vrstore_product_details_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['vrstore_product_details_nonce'])), 'vrstore_product_details_nonce')) {
            // PHP requirement field removed
            
            // Save demo URL
            if (isset($_POST['vrstore_product_demo_url'])) {
                update_post_meta($post_id, '_vrstore_product_demo_url', esc_url_raw(wp_unslash(($_POST['vrstore_product_demo_url'] ?? ""))));
            }
            
            // Save documentation URL
            if (isset($_POST['vrstore_product_documentation_url'])) {
                update_post_meta($post_id, '_vrstore_product_documentation_url', esc_url_raw(wp_unslash(($_POST['vrstore_product_documentation_url'] ?? ""))));
            }
            
            // Save features (convert to array)
            if (isset($_POST['vrstore_product_features'])) {
                $features_text = sanitize_textarea_field(wp_unslash(($_POST['vrstore_product_features'] ?? "")));
                $features = array_filter(array_map('trim', explode("\n", $features_text)));
                update_post_meta($post_id, '_vrstore_product_features', $features);
            }
            
            // Save screenshots (as array of attachment IDs or gallery shortcode)
            if (isset($_POST['vrstore_product_screenshots'])) {
                $screenshots_input = sanitize_text_field(wp_unslash($_POST['vrstore_product_screenshots']));
                
                // Check if it's a gallery shortcode
                if (strpos($screenshots_input, '[gallery') !== false) {
                    // Store as gallery shortcode
                    update_post_meta($post_id, '_vrstore_product_screenshots', $screenshots_input);
                } else {
                    // Convert comma-separated IDs to array
                    $screenshot_ids = array_filter(array_map('trim', explode(',', $screenshots_input)));
                    $valid_ids = array_filter($screenshot_ids, 'is_numeric');
                    update_post_meta($post_id, '_vrstore_product_screenshots', $valid_ids);
                }
            }
            
            // Save FAQ (parse and structure)
            if (isset($_POST['vrstore_product_faq'])) {
                $faq_text = sanitize_textarea_field(wp_unslash(($_POST['vrstore_product_faq'] ?? "")));
                $faq_items = [];
                $lines = explode("\n", $faq_text);
                $current_question = '';
                $current_answer = '';
                
                foreach ($lines as $line) {
                    $line = trim($line ?? "");
                    if (empty($line)) continue;
                    
                    if (strpos((string)$line, 'Q:') === 0) {
                        // Save previous Q&A if exists
                        if (!empty($current_question) && !empty($current_answer)) {
                            $faq_items[] = [
                                'question' => $current_question,
                                'answer' => $current_answer
                            ];
                        }
                        $current_question = trim(substr($line, 2));
                        $current_answer = '';
                    } elseif (strpos((string)$line, 'A:') === 0) {
                        $current_answer = trim(substr($line, 2));
                    } elseif (!empty($current_answer)) {
                        $current_answer .= ' ' . $line;
                    }
                }
                
                // Save last Q&A
                if (!empty($current_question) && !empty($current_answer)) {
                    $faq_items[] = [
                        'question' => $current_question,
                        'answer' => $current_answer
                    ];
                }
                
                update_post_meta($post_id, '_vrstore_product_faq', $faq_items);
            }
            
            // Save changelog
            if (isset($_POST['vrstore_product_changelog'])) {
                update_post_meta($post_id, '_vrstore_product_changelog', wp_kses_post(wp_unslash(($_POST['vrstore_product_changelog'] ?? ""))));
            }
            
            // Save disable license generation setting
            if (isset($_POST['vrstore_disable_license_generation'])) {
                update_post_meta($post_id, '_vrstore_disable_license_generation', '1');
            } else {
                delete_post_meta($post_id, '_vrstore_disable_license_generation');
            }
        }

        // Save product files
        if (isset($_POST['vrstore_product_files_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['vrstore_product_files_nonce'])), 'vrstore_product_files_nonce')) {
            // Save files
            if (isset($_POST['vrstore_product_files']) && is_array($_POST['vrstore_product_files'])) {
                $files = [];
                $posted_files = wp_unslash(($_POST['vrstore_product_files'] ?? ""));

                foreach ($posted_files as $file) {
                    if (!empty($file['name']) && !empty($file['url'])) {
                        $files[] = [
                            'name' => sanitize_text_field($file['name'] ?? ""),
                            'url' => esc_url_raw($file['url']),
                            'type' => isset($file['type']) ? sanitize_text_field($file['type'] ?? "") : 'url',
                        ];
                    }
                }

                update_post_meta($post_id, '_vrstore_product_files', $files);
            } else {
                delete_post_meta($post_id, '_vrstore_product_files');
            }
        }

        // Save product pricing
        if (isset($_POST['vrstore_product_pricing_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['vrstore_product_pricing_nonce'])), 'vrstore_product_pricing_nonce')) {
            // Save price
            if (isset($_POST['vrstore_product_price'])) {
                $price = sanitize_text_field(wp_unslash(($_POST['vrstore_product_price'] ?? "")));
                if (!empty($price) && is_numeric($price) && floatval($price) >= 0) {
                    update_post_meta($post_id, '_vrstore_product_price', floatval($price));
                } else {
                    delete_post_meta($post_id, '_vrstore_product_price');
                }
            }

            // Save sale price
            if (isset($_POST['vrstore_product_sale_price'])) {
                $sale_price = sanitize_text_field(wp_unslash(($_POST['vrstore_product_sale_price'] ?? "")));
                if (!empty($sale_price) && is_numeric($sale_price) && floatval($sale_price) >= 0) {
                    update_post_meta($post_id, '_vrstore_product_sale_price', floatval($sale_price));
                } else {
                    delete_post_meta($post_id, '_vrstore_product_sale_price');
                }
            }

            // Save currency
            if (isset($_POST['vrstore_product_currency'])) {
                update_post_meta($post_id, '_vrstore_product_currency', sanitize_text_field(wp_unslash(($_POST['vrstore_product_currency'] ?? ""))));
            }
        }

        // Save product short description
        if (isset($_POST['vrstore_product_short_description_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['vrstore_product_short_description_nonce'])), 'vrstore_product_short_description_nonce')) {
            // Save short description
            if (isset($_POST['vrstore_product_short_description'])) {
                update_post_meta($post_id, '_vrstore_product_short_description', wp_kses_post(wp_unslash(($_POST['vrstore_product_short_description'] ?? ""))));
            }
        }

        // Save unified pricing data
        if (isset($_POST['vrstore_product_pricing_unified_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['vrstore_product_pricing_unified_nonce'])), 'vrstore_product_pricing_unified_nonce')) {
            // Pricing mode removed - using unified system only
            
            // Save product pricing (always save for backward compatibility)
            if (isset($_POST['vrstore_product_price'])) {
                $price = sanitize_text_field(wp_unslash($_POST['vrstore_product_price']));
                if (!empty($price) && is_numeric($price) && floatval($price) >= 0) {
                    update_post_meta($post_id, '_vrstore_product_price', floatval($price));
                } else {
                    delete_post_meta($post_id, '_vrstore_product_price');
                }
            }
            
            if (isset($_POST['vrstore_product_sale_price'])) {
                $sale_price = sanitize_text_field(wp_unslash($_POST['vrstore_product_sale_price']));
                if (!empty($sale_price) && is_numeric($sale_price) && floatval($sale_price) >= 0) {
                    update_post_meta($post_id, '_vrstore_product_sale_price', floatval($sale_price));
                } else {
                    delete_post_meta($post_id, '_vrstore_product_sale_price');
                }
            }
            
            // Save license pricing
            if (isset($_POST['vrstore_product_license_pricing']) && is_array($_POST['vrstore_product_license_pricing'])) {
                $license_pricing = [];
                $posted_pricing = wp_unslash($_POST['vrstore_product_license_pricing']);
                
                foreach ($posted_pricing as $license_type => $pricing_data) {
                    $license_type = sanitize_text_field($license_type);
                    
                    if (is_array($pricing_data)) {
                        $price = isset($pricing_data['price']) ? sanitize_text_field($pricing_data['price']) : '';
                        $sale_price = isset($pricing_data['sale_price']) ? sanitize_text_field($pricing_data['sale_price']) : '';
                        
                        $license_pricing_item = [];
                        
                        // Save regular price
                        if (!empty($price) && is_numeric($price) && floatval($price) >= 0) {
                            $license_pricing_item['price'] = floatval($price);
                        }
                        
                        // Save sale price
                        if (!empty($sale_price) && is_numeric($sale_price) && floatval($sale_price) >= 0) {
                            $license_pricing_item['sale_price'] = floatval($sale_price);
                        }
                        
                        // Only save if at least one price is set
                        if (!empty($license_pricing_item)) {
                            $license_pricing[$license_type] = $license_pricing_item;
                        }
                    } else {
                        // Handle legacy format (single price value)
                        $price = sanitize_text_field($pricing_data);
                        if (!empty($price) && is_numeric($price) && floatval($price) >= 0) {
                            $license_pricing[$license_type] = ['price' => floatval($price)];
                        }
                    }
                }
                
                if (!empty($license_pricing)) {
                    update_post_meta($post_id, '_vrstore_product_license_pricing', $license_pricing);
                } else {
                    delete_post_meta($post_id, '_vrstore_product_license_pricing');
                }
            }
            
            // Save license type availability settings
            if (isset($_POST['vrstore_product_license_availability']) && is_array($_POST['vrstore_product_license_availability'])) {
                $license_availability = [];
                $posted_availability = wp_unslash($_POST['vrstore_product_license_availability']);
                
                // Get all available license types to ensure we track disabled ones
                $settings = get_option('vrstore_settings', []);
                $custom_license_types = $settings['custom_license_types'] ?? [];
                $license_types = get_terms([
                    'taxonomy' => 'vrstore_license_type',
                    'hide_empty' => false,
                ]);
                
                $all_license_slugs = [];
                
                // Add taxonomy-based license types
                if (!empty($license_types) && !is_wp_error($license_types)) {
                    foreach ($license_types as $license_type) {
                        $all_license_slugs[] = $license_type->slug;
                    }
                }
                
                // Add custom license types
                if (!empty($custom_license_types) && is_array($custom_license_types)) {
                    foreach ($custom_license_types as $custom_type) {
                        if (isset($custom_type['label']) && !empty($custom_type['label'])) {
                            $slug = isset($custom_type['slug']) ? $custom_type['slug'] : sanitize_title($custom_type['label']);
                            $all_license_slugs[] = $slug;
                        }
                    }
                }
                
                // Process availability for all license types
                foreach ($all_license_slugs as $license_slug) {
                    $license_availability[$license_slug] = isset($posted_availability[$license_slug]) && $posted_availability[$license_slug] === '1';
                }
                
                update_post_meta($post_id, '_vrstore_product_license_availability', $license_availability);
            } else {
                // If no availability data is posted, set all to unavailable
                $license_availability = [];
                $settings = get_option('vrstore_settings', []);
                $custom_license_types = $settings['custom_license_types'] ?? [];
                $license_types = get_terms([
                    'taxonomy' => 'vrstore_license_type',
                    'hide_empty' => false,
                ]);
                
                $all_license_slugs = [];
                
                if (!empty($license_types) && !is_wp_error($license_types)) {
                    foreach ($license_types as $license_type) {
                        $all_license_slugs[] = $license_type->slug;
                    }
                }
                
                if (!empty($custom_license_types) && is_array($custom_license_types)) {
                    foreach ($custom_license_types as $custom_type) {
                        if (isset($custom_type['label']) && !empty($custom_type['label'])) {
                            $slug = isset($custom_type['slug']) ? $custom_type['slug'] : sanitize_title($custom_type['label']);
                            $all_license_slugs[] = $slug;
                        }
                    }
                }
                
                foreach ($all_license_slugs as $license_slug) {
                    $license_availability[$license_slug] = false;
                }
                
                update_post_meta($post_id, '_vrstore_product_license_availability', $license_availability);
            }
        }
        
        // Legacy support for old pricing nonces
        if (isset($_POST['vrstore_product_pricing_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['vrstore_product_pricing_nonce'])), 'vrstore_product_pricing_nonce')) {
            // Save price
            if (isset($_POST['vrstore_product_price'])) {
                $price = sanitize_text_field(wp_unslash($_POST['vrstore_product_price']));
                if (!empty($price) && is_numeric($price) && floatval($price) >= 0) {
                    update_post_meta($post_id, '_vrstore_product_price', floatval($price));
                } else {
                    delete_post_meta($post_id, '_vrstore_product_price');
                }
            }

            // Save sale price
            if (isset($_POST['vrstore_product_sale_price'])) {
                $sale_price = sanitize_text_field(wp_unslash($_POST['vrstore_product_sale_price']));
                if (!empty($sale_price) && is_numeric($sale_price) && floatval($sale_price) >= 0) {
                    update_post_meta($post_id, '_vrstore_product_sale_price', floatval($sale_price));
                } else {
                    delete_post_meta($post_id, '_vrstore_product_sale_price');
                }
            }

            // Save currency
            if (isset($_POST['vrstore_product_currency'])) {
                update_post_meta($post_id, '_vrstore_product_currency', sanitize_text_field(wp_unslash($_POST['vrstore_product_currency'])));
            }
        }

        // Save product video configuration
        if (isset($_POST['vrstore_product_video_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['vrstore_product_video_nonce'])), 'vrstore_product_video_nonce')) {
            $video_config = [];
            
            // Save video type
            if (isset($_POST['vrstore_product_video_type'])) {
                $video_type = sanitize_text_field(wp_unslash($_POST['vrstore_product_video_type']));
                if (in_array($video_type, ['none', 'youtube', 'upload'], true)) {
                    $video_config['type'] = $video_type;
                }
            }
            
            // Save YouTube URL if type is youtube
            if (isset($video_config['type']) && $video_config['type'] === 'youtube' && isset($_POST['vrstore_product_youtube_url'])) {
                $youtube_url = esc_url_raw(wp_unslash($_POST['vrstore_product_youtube_url']));
                if (!empty($youtube_url)) {
                    $video_config['youtube_url'] = $youtube_url;
                }
            }
            
            // Save uploaded video ID if type is upload
            if (isset($video_config['type']) && $video_config['type'] === 'upload' && isset($_POST['vrstore_product_video_upload'])) {
                $video_id = absint($_POST['vrstore_product_video_upload']);
                if ($video_id > 0) {
                    $video_config['video_id'] = $video_id;
                }
            }
            
            // Save license information
            if (isset($_POST['vrstore_product_license_info'])) {
                $license_info = wp_kses_post(wp_unslash($_POST['vrstore_product_license_info']));
                if (!empty($license_info)) {
                    $video_config['license_info'] = $license_info;
                }
            }
            
            if (!empty($video_config)) {
                update_post_meta($post_id, '_vrstore_product_video_config', $video_config);
            } else {
                delete_post_meta($post_id, '_vrstore_product_video_config');
            }
            
            // Also save individual meta fields for easier access
            if (isset($_POST['vrstore_product_video_type'])) {
                update_post_meta($post_id, '_vrstore_product_video_type', sanitize_text_field(wp_unslash($_POST['vrstore_product_video_type'])));
            }
            
            if (isset($_POST['vrstore_product_youtube_url'])) {
                update_post_meta($post_id, '_vrstore_product_youtube_url', esc_url_raw(wp_unslash($_POST['vrstore_product_youtube_url'])));
            }
            
            if (isset($_POST['vrstore_product_video_upload'])) {
                update_post_meta($post_id, '_vrstore_product_video_upload', absint($_POST['vrstore_product_video_upload']));
            }
            
            if (isset($_POST['vrstore_product_license_info'])) {
                update_post_meta($post_id, '_vrstore_product_license_info', wp_kses_post(wp_unslash($_POST['vrstore_product_license_info'])));
            }
        }

        // Save product visibility settings
        if (isset($_POST['vrstore_product_visibility_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['vrstore_product_visibility_nonce'])), 'vrstore_product_visibility_nonce')) {
            // Prevent infinite recursion during visibility save
            static $saving_visibility = [];
            if (isset($saving_visibility[$post_id])) {
                return; // Exit early to prevent recursion
            }
            $saving_visibility[$post_id] = true;
            
            if (isset($_POST['vrstore_product_visibility'])) {
                $visibility = sanitize_text_field(wp_unslash($_POST['vrstore_product_visibility']));
                $allowed_visibility = ['public', 'password', 'private', 'hidden'];
                
                if (in_array($visibility, $allowed_visibility, true)) {
                    update_post_meta($post_id, '_vrstore_product_visibility', $visibility);
                    
                    // Handle password-protected visibility
                    if ($visibility === 'password' && isset($_POST['vrstore_product_password'])) {
                        $password = sanitize_text_field(wp_unslash($_POST['vrstore_product_password']));
                        if (!empty($password)) {
                            update_post_meta($post_id, '_vrstore_product_password', $password);
                            // Temporarily remove our save hook to prevent recursion
                            remove_action('save_post', [$this, 'save_meta_boxes'], 10);
                            // Set WordPress post password for compatibility
                            wp_update_post([
                                'ID' => $post_id,
                                'post_password' => $password
                            ]);
                            // Re-add the hook
                            add_action('save_post', [$this, 'save_meta_boxes'], 10, 2);
                        }
                    } else {
                        // Remove password if not password-protected
                        delete_post_meta($post_id, '_vrstore_product_password');
                        // Temporarily remove our save hook to prevent recursion
                        remove_action('save_post', [$this, 'save_meta_boxes'], 10);
                        wp_update_post([
                            'ID' => $post_id,
                            'post_password' => ''
                        ]);
                        // Re-add the hook
                        add_action('save_post', [$this, 'save_meta_boxes'], 10, 2);
                    }
                    
                    // Set post status based on visibility
                    if ($visibility === 'private') {
                        // Temporarily remove our save hook to prevent recursion
                        remove_action('save_post', [$this, 'save_meta_boxes'], 10);
                        wp_update_post([
                            'ID' => $post_id,
                            'post_status' => 'private'
                        ]);
                        // Re-add the hook
                        add_action('save_post', [$this, 'save_meta_boxes'], 10, 2);
                    } elseif ($visibility === 'public' && get_post_status($post_id) === 'private') {
                        // Only change status if it was private before
                        // Temporarily remove our save hook to prevent recursion
                        remove_action('save_post', [$this, 'save_meta_boxes'], 10);
                        wp_update_post([
                            'ID' => $post_id,
                            'post_status' => 'publish'
                        ]);
                        // Re-add the hook
                        add_action('save_post', [$this, 'save_meta_boxes'], 10, 2);
                    }
                } else {
                    // Default to public if invalid visibility provided
                    update_post_meta($post_id, '_vrstore_product_visibility', 'public');
                }
            }
            
            unset($saving_visibility[$post_id]);
        }

        // Save plugin updates meta box
        if (isset($_POST['vrstore_plugin_updates_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['vrstore_plugin_updates_nonce'])), 'vrstore_plugin_updates_nonce')) {
            // Save plugin product settings
            if (isset($_POST['vrstore_is_plugin_product'])) {
                update_post_meta($post_id, '_vrstore_is_plugin_product', '1');
            } else {
                delete_post_meta($post_id, '_vrstore_is_plugin_product');
            }

            if (isset($_POST['vrstore_plugin_slug'])) {
                update_post_meta($post_id, '_vrstore_plugin_slug', sanitize_text_field(wp_unslash($_POST['vrstore_plugin_slug'])));
            }

            if (isset($_POST['vrstore_current_version'])) {
                update_post_meta($post_id, '_vrstore_current_version', sanitize_text_field(wp_unslash($_POST['vrstore_current_version'])));
            }

            // Save plugin versions
            if (isset($_POST['vrstore_plugin_versions']) && is_array($_POST['vrstore_plugin_versions'])) {
                $this->save_plugin_versions($post_id, wp_unslash($_POST['vrstore_plugin_versions']));
            }

            // Handle file uploads for plugin versions
            // Note: Only process if form has proper encoding for file uploads
            if (!empty($_FILES['vrstore_plugin_version_files']) && 
                isset($_FILES['vrstore_plugin_version_files']['name']) && 
                is_array($_FILES['vrstore_plugin_version_files']['name'])) {
                $this->handle_plugin_version_file_uploads($post_id, $_FILES['vrstore_plugin_version_files']);
            }
            
            // Handle version deletions - check for deleted versions that weren't in POST data
            // Get all current versions from database
            global $wpdb;
            $table_name = $wpdb->prefix . 'vrstore_plugin_versions';
            if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") === $table_name) {
                $existing_version_ids = $wpdb->get_col($wpdb->prepare(
                    "SELECT id FROM {$wpdb->prefix}vrstore_plugin_versions WHERE product_id = %d",
                    $post_id
                ));
                
                // Get version IDs from POST data
                $posted_version_ids = [];
                if (isset($_POST['vrstore_plugin_versions']) && is_array($_POST['vrstore_plugin_versions'])) {
                    foreach ($_POST['vrstore_plugin_versions'] as $key => $data) {
                        if (is_numeric($key)) {
                            $posted_version_ids[] = intval($key);
                        }
                    }
                }
                
                // Delete versions that exist in DB but not in POST (removed from form)
                $versions_to_delete = array_diff($existing_version_ids, $posted_version_ids);
                foreach ($versions_to_delete as $version_id) {
                    // Get file path before deleting
                    $file_path = $wpdb->get_var($wpdb->prepare(
                        "SELECT file_path FROM {$wpdb->prefix}vrstore_plugin_versions WHERE id = %d",
                        $version_id
                    ));
                    
                    // Delete from database
                    $wpdb->delete(
                        $wpdb->prefix . 'vrstore_plugin_versions',
                        ['id' => $version_id],
                        ['%d']
                    );
                    
                    // Delete file if it exists
                    if ($file_path && file_exists($file_path)) {
                        @unlink($file_path);
                    }
                }
            }
        }

        // Save pre-order settings
        if (isset($_POST['vrstore_product_preorder_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['vrstore_product_preorder_nonce'])), 'vrstore_product_preorder_nonce')) {
            // Save pre-order enabled status
            if (isset($_POST['vrstore_product_is_preorder'])) {
                update_post_meta($post_id, '_vrstore_product_is_preorder', '1');
            } else {
                delete_post_meta($post_id, '_vrstore_product_is_preorder');
            }

            // Save release date
            if (isset($_POST['vrstore_product_preorder_release_date'])) {
                $release_date = sanitize_text_field(wp_unslash($_POST['vrstore_product_preorder_release_date']));
                if (!empty($release_date)) {
                    update_post_meta($post_id, '_vrstore_product_preorder_release_date', $release_date);
                } else {
                    delete_post_meta($post_id, '_vrstore_product_preorder_release_date');
                }
            }

            // Save pre-order message
            if (isset($_POST['vrstore_product_preorder_message'])) {
                $message = wp_kses_post(wp_unslash($_POST['vrstore_product_preorder_message']));
                if (!empty($message)) {
                    update_post_meta($post_id, '_vrstore_product_preorder_message', $message);
                } else {
                    delete_post_meta($post_id, '_vrstore_product_preorder_message');
                }
            }

            // Save pre-order discount
            if (isset($_POST['vrstore_product_preorder_discount'])) {
                $discount = absint($_POST['vrstore_product_preorder_discount']);
                if ($discount > 0 && $discount <= 100) {
                    update_post_meta($post_id, '_vrstore_product_preorder_discount', $discount);
                } else {
                    delete_post_meta($post_id, '_vrstore_product_preorder_discount');
                }
            }

            // Save pre-order limit
            if (isset($_POST['vrstore_product_preorder_limit'])) {
                $limit = absint($_POST['vrstore_product_preorder_limit']);
                if ($limit > 0) {
                    update_post_meta($post_id, '_vrstore_product_preorder_limit', $limit);
                } else {
                    delete_post_meta($post_id, '_vrstore_product_preorder_limit');
                }
            }
        }

        unset($saving_posts[$post_id]);
    }

    /**
     * Save plugin versions to database
     *
     * @param int $product_id Product ID
     * @param array $versions_data Versions data from form
     * @return void
     */
    private function save_plugin_versions(int $product_id, array $versions_data): void {
        global $wpdb;

        // Check if table exists
        $table_name = $wpdb->prefix . 'vrstore_plugin_versions';
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") !== $table_name) {
            error_log('ViraStore: Plugin versions table does not exist. Cannot save versions.');
            return;
        }

        foreach ($versions_data as $version_key => $version_data) {
            if (empty($version_data['version'])) {
                continue;
            }

            $version = sanitize_text_field($version_data['version']);
            $changelog = isset($version_data['changelog']) ? wp_kses_post($version_data['changelog']) : '';
            $license_tiers = isset($version_data['license_tiers']) && is_array($version_data['license_tiers']) 
                ? array_map('sanitize_text_field', $version_data['license_tiers']) 
                : [];

            // Check if this is an existing version (numeric key) or new version (starts with 'new_')
            if (is_numeric($version_key)) {
                // Update existing version - check if version exists first
                $existing_version = $wpdb->get_var($wpdb->prepare(
                    "SELECT version FROM {$wpdb->prefix}vrstore_plugin_versions WHERE id = %d",
                    intval($version_key)
                ));

                if (!$existing_version) {
                    error_log('ViraStore: Attempted to update non-existent version ID: ' . $version_key);
                    continue;
                }

                // Check for duplicate version number (excluding current version)
                $duplicate_check = $wpdb->get_var($wpdb->prepare(
                    "SELECT id FROM {$wpdb->prefix}vrstore_plugin_versions 
                     WHERE product_id = %d AND version = %s AND id != %d",
                    $product_id,
                    $version,
                    intval($version_key)
                ));

                if ($duplicate_check) {
                    error_log('ViraStore: Duplicate version number detected: ' . $version . ' for product ' . $product_id);
                    continue;
                }

                // Update existing version
                $update_result = $wpdb->update(
                    $wpdb->prefix . 'vrstore_plugin_versions',
                    [
                        'version' => $version,
                        'changelog' => $changelog,
                        'license_tiers' => json_encode($license_tiers),
                        'updated_at' => current_time('mysql')
                    ],
                    ['id' => intval($version_key)],
                    ['%s', '%s', '%s', '%s'],
                    ['%d']
                );

                if ($update_result === false) {
                    error_log('ViraStore: Failed to update version ' . $version_key . ': ' . $wpdb->last_error);
                }
            } elseif (strpos($version_key, 'new_') === 0) {
                // Check for duplicate version number before inserting
                $duplicate_check = $wpdb->get_var($wpdb->prepare(
                    "SELECT id FROM {$wpdb->prefix}vrstore_plugin_versions 
                     WHERE product_id = %d AND version = %s",
                    $product_id,
                    $version
                ));

                if ($duplicate_check) {
                    error_log('ViraStore: Duplicate version number detected: ' . $version . ' for product ' . $product_id);
                    continue;
                }

                // Insert new version (file will be handled separately)
                $insert_result = $wpdb->insert(
                    $wpdb->prefix . 'vrstore_plugin_versions',
                    [
                        'product_id' => $product_id,
                        'version' => $version,
                        'changelog' => $changelog,
                        'license_tiers' => json_encode($license_tiers),
                        'file_name' => '', // Will be updated when file is uploaded
                        'file_path' => '', // Will be updated when file is uploaded
                        'file_size' => 0,
                        'is_active' => 1,
                        'release_date' => current_time('mysql'),
                        'created_at' => current_time('mysql'),
                        'updated_at' => current_time('mysql')
                    ],
                    ['%d', '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%s', '%s', '%s']
                );

                if ($insert_result === false) {
                    error_log('ViraStore: Failed to insert new version: ' . $wpdb->last_error);
                } else {
                    // Store the mapping between version_key and inserted ID for file upload matching
                    // Use a transient with the version number as key to map to version ID
                    $transient_key = 'vrstore_version_' . $product_id . '_' . $version;
                    set_transient($transient_key, $wpdb->insert_id, 300); // 5 minutes expiry
                }
            }
        }
    }

    /**
     * Handle plugin version file uploads
     *
     * @param int $product_id Product ID
     * @param array $files Files array from $_FILES
     * @return void
     */
    private function handle_plugin_version_file_uploads(int $product_id, array $files): void {
        global $wpdb;

        if (!function_exists('wp_handle_upload')) {
            require_once(ABSPATH . 'wp-admin/includes/file.php');
        }

        // Check if table exists
        $table_name = $wpdb->prefix . 'vrstore_plugin_versions';
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") !== $table_name) {
            error_log('ViraStore: Plugin versions table does not exist. Cannot upload files.');
            return;
        }

        foreach ($files['name'] as $version_key => $file_name) {
            if (empty($file_name) || $files['error'][$version_key] !== UPLOAD_ERR_OK) {
                // Log upload errors
                if ($files['error'][$version_key] !== UPLOAD_ERR_OK) {
                    $error_message = $this->get_upload_error_message($files['error'][$version_key]);
                    error_log('ViraStore: File upload error for version ' . $version_key . ': ' . $error_message);
                }
                continue;
            }

            // Validate file type - must be ZIP
            $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
            if ($file_ext !== 'zip') {
                error_log('ViraStore: Invalid file type for version ' . $version_key . '. Expected ZIP, got: ' . $file_ext);
                continue;
            }

            // Prepare file for upload
            $file_array = [
                'name' => $files['name'][$version_key],
                'type' => $files['type'][$version_key],
                'tmp_name' => $files['tmp_name'][$version_key],
                'error' => $files['error'][$version_key],
                'size' => $files['size'][$version_key]
            ];

            // Upload file with validation
            $upload_overrides = [
                'test_form' => false,
                'mimes' => ['zip' => 'application/zip'],
                'unique_filename_callback' => function($dir, $name, $ext) use ($product_id) {
                    return 'vrstore-' . $product_id . '-' . uniqid() . $ext;
                }
            ];
            
            $uploaded_file = wp_handle_upload($file_array, $upload_overrides);

            if (isset($uploaded_file['error'])) {
                error_log('ViraStore: File upload failed for version ' . $version_key . ': ' . $uploaded_file['error']);
                continue;
            }

            if (!isset($uploaded_file['file']) || !file_exists($uploaded_file['file'])) {
                error_log('ViraStore: Uploaded file not found for version ' . $version_key);
                continue;
            }

            $file_path = $uploaded_file['file'];
            $file_size = filesize($file_path);

            // Track matched version IDs to prevent duplicate matches
            static $matched_version_ids = [];
            
            // Update database record
            if (strpos($version_key, 'new_') === 0) {
                // For new versions, try to get version number from POST data
                $version_number = '';
                if (isset($_POST['vrstore_plugin_versions'][$version_key]['version'])) {
                    $version_number = sanitize_text_field($_POST['vrstore_plugin_versions'][$version_key]['version']);
                }
                
                // Try to find version by number first (most reliable)
                // Exclude already matched versions
                if (!empty($version_number)) {
                    if (empty($matched_version_ids)) {
                        $version_id = $wpdb->get_var($wpdb->prepare(
                            "SELECT id FROM {$wpdb->prefix}vrstore_plugin_versions 
                             WHERE product_id = %d AND version = %s
                             ORDER BY created_at DESC LIMIT 1",
                            $product_id,
                            $version_number
                        ));
                    } else {
                        // Use proper placeholders for NOT IN clause
                        $placeholders = implode(',', array_fill(0, count($matched_version_ids), '%d'));
                        $query = $wpdb->prepare(
                            "SELECT id FROM {$wpdb->prefix}vrstore_plugin_versions 
                             WHERE product_id = %d AND version = %s AND id NOT IN ({$placeholders})
                             ORDER BY created_at DESC LIMIT 1",
                            array_merge([$product_id, $version_number], array_map('intval', $matched_version_ids))
                        );
                        $version_id = $wpdb->get_var($query);
                    }
                }
                
                // Fallback: use transient mapping if available
                if (!$version_id && !empty($version_number)) {
                    $transient_key = 'vrstore_version_' . $product_id . '_' . $version_number;
                    $candidate_id = get_transient($transient_key);
                    if ($candidate_id && !in_array($candidate_id, $matched_version_ids)) {
                        $version_id = $candidate_id;
                        delete_transient($transient_key); // Clean up after use
                    }
                }
                
                // Final fallback: find most recent version with empty file (for compatibility)
                // Exclude already matched versions
                if (!$version_id) {
                    if (empty($matched_version_ids)) {
                        $version_id = $wpdb->get_var($wpdb->prepare(
                            "SELECT id FROM {$wpdb->prefix}vrstore_plugin_versions 
                             WHERE product_id = %d AND (file_name = '' OR file_name IS NULL) AND (file_path = '' OR file_path IS NULL)
                             ORDER BY created_at DESC LIMIT 1",
                            $product_id
                        ));
                    } else {
                        // Use proper placeholders for NOT IN clause
                        $placeholders = implode(',', array_fill(0, count($matched_version_ids), '%d'));
                        $query = $wpdb->prepare(
                            "SELECT id FROM {$wpdb->prefix}vrstore_plugin_versions 
                             WHERE product_id = %d AND (file_name = '' OR file_name IS NULL) AND (file_path = '' OR file_path IS NULL) AND id NOT IN ({$placeholders})
                             ORDER BY created_at DESC LIMIT 1",
                            array_merge([$product_id], array_map('intval', $matched_version_ids))
                        );
                        $version_id = $wpdb->get_var($query);
                    }
                }
                
                // Mark this version as matched
                if ($version_id) {
                    $matched_version_ids[] = $version_id;
                }
            } else {
                $version_id = intval($version_key);
            }

            if (!$version_id) {
                error_log('ViraStore: Could not find version record for version key: ' . $version_key);
                // Clean up uploaded file if we can't save it
                if (file_exists($file_path)) {
                    @unlink($file_path);
                }
                continue;
            }

            // Delete old file if it exists and is different
            $old_file_path = $wpdb->get_var($wpdb->prepare(
                "SELECT file_path FROM {$wpdb->prefix}vrstore_plugin_versions WHERE id = %d",
                $version_id
            ));
            
            if ($old_file_path && file_exists($old_file_path) && $old_file_path !== $file_path) {
                @unlink($old_file_path);
            }

            // Update database record
            $update_result = $wpdb->update(
                $wpdb->prefix . 'vrstore_plugin_versions',
                [
                    'file_name' => basename($file_path),
                    'file_path' => $file_path,
                    'file_size' => $file_size,
                    'updated_at' => current_time('mysql')
                ],
                ['id' => $version_id],
                ['%s', '%s', '%d', '%s'],
                ['%d']
            );

            if ($update_result === false) {
                error_log('ViraStore: Failed to update version record ' . $version_id . ' with file info: ' . $wpdb->last_error);
                // Clean up uploaded file if database update failed
                if (file_exists($file_path)) {
                    @unlink($file_path);
                }
            }
        }
    }

    /**
     * Get human-readable upload error message
     *
     * @param int $error_code PHP upload error code
     * @return string
     */
    private function get_upload_error_message(int $error_code): string {
        $error_messages = [
            UPLOAD_ERR_INI_SIZE => __('The uploaded file exceeds the upload_max_filesize directive in php.ini.', 'vira-store'),
            UPLOAD_ERR_FORM_SIZE => __('The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form.', 'vira-store'),
            UPLOAD_ERR_PARTIAL => __('The uploaded file was only partially uploaded.', 'vira-store'),
            UPLOAD_ERR_NO_FILE => __('No file was uploaded.', 'vira-store'),
            UPLOAD_ERR_NO_TMP_DIR => __('Missing a temporary folder.', 'vira-store'),
            UPLOAD_ERR_CANT_WRITE => __('Failed to write file to disk.', 'vira-store'),
            UPLOAD_ERR_EXTENSION => __('A PHP extension stopped the file upload.', 'vira-store'),
        ];

        return $error_messages[$error_code] ?? sprintf(__('Unknown upload error (code: %d)', 'vira-store'), $error_code);
    }

    /**
     * Add product columns
     *
     * @param array $columns Columns
     * @return array
     */
    public function add_product_columns(array $columns): array {
        $new_columns = [];

        // Insert thumbnail after checkbox
        foreach ($columns as $key => $value) {
            $new_columns[$key] = $value;
            
            if ($key === 'cb') {
                $new_columns['thumbnail'] = __('Image', 'vira-store');
            }
            
            // Insert visibility column before the date column
            if ($key === 'date') {
                $new_columns['visibility'] = __('Visibility', 'vira-store');
            }
        }
        
        // Keep only essential columns

        return $new_columns;
    }

    /**
     * Render product columns
     *
     * @param string $column  Column name
     * @param int    $post_id Post ID
     * @return void
     */
    public function render_product_columns(string $column, int $post_id): void {
        switch ($column) {
            case 'thumbnail':
                if (has_post_thumbnail($post_id)) {
                    echo get_the_post_thumbnail($post_id, [50, 50]);
                } else {
                    echo '<img src="' . esc_url(VRSTORE_PLUGIN_URL . 'assets/images/placeholder.svg') . '" width="50" height="50" alt="' . esc_attr__('Product image', 'vira-store') . '">';
                }
                break;
                
            case 'visibility':
                $visibility = get_post_meta($post_id, '_vrstore_product_visibility', true);
                if (empty($visibility)) {
                    $visibility = 'public'; // Default to public if not set
                }
                
                $visibility_label = $this->get_visibility_label($visibility);
                $visibility_class = 'vrstore-visibility-' . $visibility;
                
                echo '<span class="' . esc_attr($visibility_class) . '" title="' . esc_attr($visibility_label) . '">';
                
                // Add icon based on visibility
                switch ($visibility) {
                    case 'password':
                        echo '<span class="dashicons dashicons-lock" style="color: #f56e28;"></span> ';
                        break;
                    case 'private':
                        echo '<span class="dashicons dashicons-hidden" style="color: #d63638;"></span> ';
                        break;
                    case 'hidden':
                        echo '<span class="dashicons dashicons-visibility" style="color: #dba617;"></span> ';
                        break;
                    default: // public
                        echo '<span class="dashicons dashicons-visibility" style="color: #00a32a;"></span> ';
                        break;
                }
                
                echo esc_html($visibility_label);
                echo '</span>';
                break;
                
            // Removed price and version columns
        }
    }

    /**
     * Format price - delegates to Order class for consistency
     *
     * @param mixed $price    Price (string or float)
     * @param string $currency Currency
     * @return string
     */
    public function format_price($price, string $currency): string {
        // Handle empty prices (but allow zero prices)
        if ($price === '' || $price === null) {
            return '';
        }
        
        // Ensure price is numeric
        if (!is_numeric($price)) {
            return '';
        }
        
        // Convert to float
        $price_float = floatval($price);
        
        // Use Order class for consistency
        if (class_exists('VRSTORE_Order')) {
            return VRSTORE_Order::format_price($price_float, $currency);
        }
        
        // Fallback if Order class is not available
        $symbol = $this->get_currency_symbol($currency);
        return $symbol . number_format($price_float, 2);
    }

    /**
     * Get currency symbol
     *
     * @param string $currency Currency
     * @return string
     */
    public static function get_currency_symbol(string $currency): string {
        $symbols = [
            'USD' => '$',
            'EUR' => '€',
            'GBP' => '£',
            'JPY' => '¥',
            'IDR' => 'Rp',
            'AUD' => '$',
            'BRL' => 'R$',
            'CAD' => '$',
            'CNY' => '¥',
            'HKD' => '$',
            'INR' => '₹',
            'MXN' => '$',
            'MYR' => 'RM',
            'NZD' => '$',
            'PHP' => '₱',
            'SGD' => '$',
            'THB' => '฿',
            'VND' => '₫',
            'ZAR' => 'R',
        ];

        return $symbols[$currency] ?? $currency;
    }

    /**
     * Check if product is available for pre-order
     *
     * @param int $product_id Product ID
     * @return bool
     */
    public static function is_preorder_product(int $product_id): bool {
        return get_post_meta($product_id, '_vrstore_product_is_preorder', true) === '1';
    }

    /**
     * Check if pre-order is still available (not past release date and within limits)
     *
     * @param int $product_id Product ID
     * @return bool
     */
    public static function is_preorder_available(int $product_id): bool {
        if (!self::is_preorder_product($product_id)) {
            return false;
        }

        if (self::is_preorder_released($product_id)) {
            return false;
        }

        // Check pre-order limit
        $limit = get_post_meta($product_id, '_vrstore_product_preorder_limit', true);
        if (!empty($limit) && $limit > 0) {
            $current_preorders = self::get_preorder_count($product_id);
            if ($current_preorders >= $limit) {
                return false; // Limit reached
            }
        }

        return true;
    }

    /**
     * Check if pre-order release date has passed.
     *
     * @param int $product_id Product ID
     * @return bool
     */
    public static function is_preorder_released(int $product_id): bool {
        if (!self::is_preorder_product($product_id)) {
            return false;
        }

        $release_date = get_post_meta($product_id, '_vrstore_product_preorder_release_date', true);
        if (empty($release_date)) {
            return false;
        }

        $release_timestamp = strtotime($release_date);
        if (! $release_timestamp) {
            return false;
        }

        return $release_timestamp <= current_time('timestamp');
    }

    /**
     * Get current pre-order count for a product
     *
     * @param int $product_id Product ID
     * @return int
     */
    public static function get_preorder_count(int $product_id): int {
        global $wpdb;
        
        $orders_table = $wpdb->prefix . 'vrstore_orders';
        
        // Check if orders table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$orders_table'") !== $orders_table) {
            return 0;
        }
        
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $orders_table 
             WHERE product_id = %d 
               AND (order_status = 'completed' OR payment_status = 'completed')
               AND order_date >= %s",
            $product_id,
            date('Y-m-d H:i:s', strtotime('-1 year')) // Only count recent orders
        ));
        
        return (int) $count ?: 0;
    }

    /**
     * Get pre-order release date
     *
     * @param int $product_id Product ID
     * @return string|null
     */
    public static function get_preorder_release_date(int $product_id): ?string {
        return get_post_meta($product_id, '_vrstore_product_preorder_release_date', true) ?: null;
    }

    /**
     * Get pre-order message
     *
     * @param int $product_id Product ID
     * @return string
     */
    public static function get_preorder_message(int $product_id): string {
        $message = get_post_meta($product_id, '_vrstore_product_preorder_message', true);
        if (empty($message)) {
            $message = __('This product is available for pre-order. You will receive download access on the release date.', 'vira-store');
        }
        return $message;
    }

    /**
     * Calculate pre-order price with discount
     *
     * @param int $product_id Product ID
     * @param float $original_price Original price
     * @return float
     */
    public static function get_preorder_price(int $product_id, float $original_price): float {
        if (!self::is_preorder_product($product_id)) {
            return $original_price;
        }

        $discount = get_post_meta($product_id, '_vrstore_product_preorder_discount', true);
        if (empty($discount) || $discount <= 0) {
            return $original_price;
        }

        $discount_amount = ($original_price * $discount) / 100;
        return max(0, $original_price - $discount_amount);
    }

    /**
     * Get product by ID
     *
     * @param int $product_id Product ID
     * @return array|null
     */
    public function get_product(int $product_id): ?array {
        $product = get_post($product_id);

        if (!$product || $product->post_type !== $this->post_type) {
            return null;
        }

        $price = get_post_meta($product_id, '_vrstore_product_price', true) ?: "";
        $sale_price = get_post_meta($product_id, '_vrstore_product_sale_price', true) ?: "";
        $currency = get_post_meta($product_id, '_vrstore_product_currency', true) ?: "" ?: 'USD';
        $files = get_post_meta($product_id, '_vrstore_product_files', true) ?: "" ?: [];

        return [
            'id' => $product_id,
            'title' => $product->post_title,
            'description' => $product->post_content,
            'excerpt' => $product->post_excerpt,
            'price' => $price,
            'sale_price' => $sale_price,
            'currency' => $currency,
            'files' => $files,
            'permalink' => get_permalink($product_id),
            'thumbnail' => get_the_post_thumbnail_url($product_id, 'full'),
        ];
    }

    /**
     * Get products
     *
     * @param array $args Query arguments
     * @return array
     */
    public function get_products(array $args = []): array {
        $default_args = [
            'post_type' => $this->post_type,
            'post_status' => 'publish',
            'posts_per_page' => 10,
            'orderby' => 'date',
            'order' => 'DESC',
        ];

        $args = wp_parse_args($args, $default_args);

        $query = new WP_Query($args);
        $products = [];

        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $products[] = $this->get_product(get_the_ID());
            }
            wp_reset_postdata();
        }

        return $products;
    }
    
    /**
     * Filter single product content
     *
     * @param string $content Original content
     * @return string Modified content
     */
    public function filter_single_product_content(string $content): string {
        // Only apply on single product pages in the main query
        if (!is_singular($this->post_type) || !is_main_query() || !in_the_loop()) {
            return $content;
        }
        
        // Get the current post
        global $post;
        if (!$post || $post->post_type !== $this->post_type) {
            return $content;
        }
        
        // Process blocks first (WordPress 5.0+)
        if (function_exists('do_blocks')) {
            $content = do_blocks($content);
        }
        
        // Then process shortcodes
        $content = do_shortcode($content);
        
        // Prevent infinite recursion - check if we're already processing
        static $processing = false;
        if ($processing) {
            return $content;
        }
        
        $processing = true;
        
        // Get product data
        $product_id = $post->ID;
        $product = $post;
        
        // Start output buffering
        ob_start();
        
        try {
            // Include the single product template
            include VRSTORE_PLUGIN_DIR . 'views/shortcodes/product.php';
        } catch (Exception $e) {

            ob_end_clean();
            $processing = false;
            return $content;
        }
        
        // Get the template output
        $template_content = ob_get_clean();
        
        $processing = false;
        
        // Return our template instead of the original content
        return $template_content;
    }
    
    /**
     * Enqueue frontend assets
     *
     * @return void
     */
    public function enqueue_frontend_assets(): void {
        // Only enqueue on single product pages or pages with product shortcodes
        if (is_singular($this->post_type) || $this->has_product_shortcode()) {
            // Enqueue CSS
            wp_enqueue_style(
                'vrstore-frontend',
                VRSTORE_PLUGIN_URL . 'assets/css/frontend.css',
                [],
                VRSTORE_VERSION
            );

            // Enqueue pre-order and shortcode styles
            wp_enqueue_style(
                'vrstore-preorder-shortcode',
                VRSTORE_PLUGIN_URL . 'assets/css/preorder-shortcode.css',
                ['vrstore-frontend'],
                VRSTORE_VERSION
            );
            
            // Enqueue JavaScript
            wp_enqueue_script(
                'vrstore-frontend',
                VRSTORE_PLUGIN_URL . 'assets/js/frontend.js',
                ['jquery'],
                VRSTORE_VERSION,
                true
            );

            // Enqueue pre-order buy button handler
            wp_enqueue_script(
                'vrstore-preorder-buy-button',
                VRSTORE_PLUGIN_URL . 'assets/js/preorder-buy-button.js',
                ['jquery', 'vrstore-frontend'],
                VRSTORE_VERSION,
                true
            );
            
            // Localize script for AJAX
            wp_localize_script(
                'vrstore-frontend',
                'vrstore_frontend',
                [
                    'ajax_url' => admin_url('admin-ajax.php'),
                    'nonce' => wp_create_nonce('vrstore_frontend_nonce'),
                    'adding_to_cart' => __('Adding to cart...', 'vira-store'),
                    'ajax_error' => __('An error occurred. Please try again.', 'vira-store'),
                    'required_field' => __('This field is required.', 'vira-store'),
                    'invalid_email' => __('Please enter a valid email address.', 'vira-store'),
                    'license_key_required' => __('License key is required.', 'vira-store'),
                    'activating' => __('Activating...', 'vira-store'),
                    'deactivating' => __('Deactivating...', 'vira-store'),
                    'activate' => __('Activate', 'vira-store'),
                    'deactivate' => __('Deactivate', 'vira-store'),
                    'redirecting' => __('Redirecting...', 'vira-store'),
                ]
            );

            // Localize pre-order specific variables
            wp_localize_script(
                'vrstore-preorder-buy-button',
                'vrstore_preorder_vars',
                [
                    'confirm_preorder' => __('Are you sure you want to place this pre-order? You will be charged now and receive the product on the release date.', 'vira-store'),
                    'preorder_success' => __('Pre-order added to cart successfully!', 'vira-store'),
                    'preorder_error' => __('Failed to add pre-order to cart. Please try again.', 'vira-store'),
                    'release_date_passed' => __('This product has been released and is now available for regular purchase.', 'vira-store'),
                    'limit_reached' => __('Pre-order limit has been reached for this product.', 'vira-store'),
                ]
            );
        }
    }
    
    /**
     * Enqueue admin assets
     *
     * @param string $hook Current admin page hook
     * @return void
     */
    public function enqueue_admin_assets(string $hook): void {
        // Only enqueue on product related pages
        if (!function_exists('get_current_screen')) {
            return;
        }
        
        $screen = get_current_screen();
        if (!$screen || $screen->post_type !== $this->post_type) {
            return;
        }
        
        // Only on edit/new post pages and product list page
        if (!in_array($hook, ['post.php', 'post-new.php', 'edit.php'])) {
            return;
        }
        
        // Enqueue WordPress media uploader
        wp_enqueue_media();
        
        // Enqueue our admin JavaScript
        wp_enqueue_script(
            'vrstore-admin',
            VRSTORE_PLUGIN_URL . 'assets/js/admin.js',
            ['jquery', 'wp-util'],
            VRSTORE_VERSION,
            true
        );
        
        // Get license types for JavaScript
        $license_types = [];
        $settings = get_option('vrstore_settings', []);
        if (!is_array($settings)) {
            $settings = [];
        }
        $custom_license_types = $settings['custom_license_types'] ?? [];
        $taxonomy_license_types = get_terms([
            'taxonomy' => 'vrstore_license_type',
            'hide_empty' => false,
        ]);
        
        // Add custom license types first (preferred)
        if (!empty($custom_license_types)) {
            foreach ($custom_license_types as $custom_type) {
                $slug = $custom_type['slug'] ?? sanitize_title($custom_type['label'] ?? '');
                $label = $custom_type['label'] ?? ucfirst($slug);
                $license_types[] = [
                    'slug' => $slug,
                    'name' => $label,
                    'source' => 'custom'
                ];
            }
        } 
        // Add taxonomy license types if no custom types
        elseif (!empty($taxonomy_license_types) && !is_wp_error($taxonomy_license_types)) {
            foreach ($taxonomy_license_types as $license_type) {
                $license_types[] = [
                    'slug' => $license_type->slug,
                    'name' => $license_type->name,
                    'source' => 'taxonomy'
                ];
            }
        }
        
        // Extend admin script data without overwriting global configuration
        $product_admin_data = [
            'confirm_duplicate'    => __('Are you sure you want to duplicate this product?', 'vira-store'),
            'duplicating'          => __('Duplicating...', 'vira-store'),
            'duplicate_success'    => __('Product duplicated successfully!', 'vira-store'),
            'duplicate_error'      => __('Failed to duplicate product. Please try again.', 'vira-store'),
            'confirm_delete_version' => __('Are you sure you want to remove this version? This action cannot be undone.', 'vira-store'),
            'license_types'        => $license_types,
            'media_title'          => $this->get_translated_text('Select Product File'),
            'media_button'         => $this->get_translated_text('Use this file'),
            'upload_error'         => $this->get_translated_text('Upload failed. Please try again.'),
        ];

        $inline_script = 'window.vrstore_admin = window.vrstore_admin || {}; Object.assign(window.vrstore_admin, ' . wp_json_encode($product_admin_data) . ');';

        wp_add_inline_script(
            'vrstore-admin',
            $inline_script,
            'after'
        );
        
        // Make ajaxurl available globally for WordPress admin
        wp_add_inline_script(
            'vrstore-admin',
            'var ajaxurl = "' . admin_url('admin-ajax.php') . '";',
            'before'
        );
        
        // Enqueue admin CSS if it exists
        $admin_css_path = VRSTORE_PLUGIN_DIR . 'assets/css/admin.css';
        if (file_exists($admin_css_path)) {
            wp_enqueue_style(
                'vrstore-admin',
                VRSTORE_PLUGIN_URL . 'assets/css/admin.css',
                [],
                VRSTORE_VERSION
            );
        }
    }
    
    /**
     * Check if current page has product shortcode
     *
     * @return bool
     */
    private function has_product_shortcode(): bool {
        global $post;
        
        if (!$post) {
            return false;
        }
        
        // Check if content has vrstore_product or vrstore_products shortcode
        return has_shortcode($post->post_content, 'vrstore_product') || 
               has_shortcode($post->post_content, 'vrstore_products');
    }
    
    /**
     * Add taxonomy management buttons to product edit page
     *
     * @param WP_Post $post Current post object
     * @return void
     */
    public function add_taxonomy_management_buttons($post): void {
        // Only show on vrstore_product edit pages
        if (!$post || $post->post_type !== $this->post_type) {
            return;
        }
        
        // Get current screen to ensure we're on edit page
        $screen = get_current_screen();
        if (!$screen || $screen->base !== 'post') {
            return;
        }
        
        // Generate management URLs
        $category_url = admin_url('edit-tags.php?taxonomy=vrstore_product_cat&post_type=' . $this->post_type);
        $tag_url = admin_url('edit-tags.php?taxonomy=vrstore_product_tag&post_type=' . $this->post_type);
        
        echo '<div class="vrstore-taxonomy-management" style="margin: 10px 0; padding: 10px; background: #f9f9f9; border: 1px solid #ddd; border-radius: 4px;">';
        echo '<p style="margin: 0 0 10px 0; font-weight: 600;">' . esc_html__('Taxonomy Management', 'vira-store') . '</p>';
        echo '<a href="' . esc_url($category_url) . '" class="button button-secondary" style="margin-right: 10px;">';
        echo '<span class="dashicons dashicons-category" style="vertical-align: middle; margin-right: 5px;"></span>';
        echo esc_html__('Manage Product Categories', 'vira-store');
        echo '</a>';
        echo '<a href="' . esc_url($tag_url) . '" class="button button-secondary">';
        echo '<span class="dashicons dashicons-tag" style="vertical-align: middle; margin-right: 5px;"></span>';
        echo esc_html__('Manage Product Tags', 'vira-store');
        echo '</a>';
        echo '</div>';
    }
    
    /**
     * Add taxonomy management buttons next to Add New button
     *
     * @param string $which The location of the extra table nav markup: 'top' or 'bottom'
     * @return void
     */
    public function add_taxonomy_management_buttons_next_to_add_new($which): void {
        // Only show on top and only for vrstore_product post type
        if ($which !== 'top') {
            return;
        }
        
        // Get current screen
        $screen = get_current_screen();
        if (!$screen || $screen->id !== 'edit-' . $this->post_type) {
            return;
        }
        
        // Generate management URLs
        $category_url = admin_url('edit-tags.php?taxonomy=vrstore_product_cat&post_type=' . $this->post_type);
        $tag_url = admin_url('edit-tags.php?taxonomy=vrstore_product_tag&post_type=' . $this->post_type);
        
        echo '<div class="alignleft actions" style="margin-left: 10px;">';
        echo '<a href="' . esc_url($category_url) . '" class="button" style="margin-right: 5px;">';
        echo '<span class="dashicons dashicons-category" style="vertical-align: middle; margin-right: 3px;"></span>';
        echo esc_html__('Manage Categories', 'vira-store');
        echo '</a>';
        echo '<a href="' . esc_url($tag_url) . '" class="button">';
        echo '<span class="dashicons dashicons-tag" style="vertical-align: middle; margin-right: 3px;"></span>';
        echo esc_html__('Manage Tags', 'vira-store');
        echo '</a>';
        echo '</div>';
    }
    
    /**
     * Add duplicate action to post row actions
     *
     * @param array $actions Row actions
     * @param WP_Post $post Post object
     * @return array Modified actions
     */
    public function add_duplicate_row_action($actions, $post) {
        // Only add to vrstore_product post type
        if ($post->post_type !== $this->post_type) {
            return $actions;
        }
        
        // Check if user has permission to duplicate
        if (!current_user_can('edit_posts')) {
            return $actions;
        }
        
        // Create nonce for this specific post
        $nonce = wp_create_nonce('vrstore_duplicate_product_' . $post->ID);
        
        // Add duplicate action
        $actions['duplicate'] = sprintf(
            '<a href="#" class="vrstore-duplicate-product" data-product-id="%d" data-nonce="%s">%s</a>',
            $post->ID,
            esc_attr($nonce),
            __('Duplicate', 'vira-store')
        );
        
        return $actions;
    }
    
    /**
     * AJAX handler for duplicating a product
     *
     * @return void
     */
    public function ajax_duplicate_product(): void {
        // Debug logging
        // AJAX handler called
        
        // Check if user has permission
        if (!current_user_can('edit_posts')) {
            // Permission denied
            wp_send_json_error(['message' => __('Permission denied.', 'vira-store')]);
        }
        
        // Get product ID
        $product_id = intval($_POST['product_id'] ?? 0);
        if (!$product_id) {
            wp_send_json_error(['message' => __('Invalid product ID.', 'vira-store')]);
        }
        
        // Verify nonce
        $nonce = sanitize_text_field($_POST['nonce'] ?? '');
        if (!wp_verify_nonce($nonce, 'vrstore_duplicate_product_' . $product_id)) {
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
        }
        
        // Get the original product
        $original_product = get_post($product_id);
        if (!$original_product || $original_product->post_type !== $this->post_type) {
            wp_send_json_error(['message' => __('Product not found.', 'vira-store')]);
        }
        
        // Create duplicate product
        $duplicate_data = [
            'post_title' => $original_product->post_title . ' (Copy)',
            'post_content' => $original_product->post_content,
            'post_excerpt' => $original_product->post_excerpt,
            'post_status' => 'draft', // Set as draft initially
            'post_type' => $this->post_type,
            'post_author' => get_current_user_id(),
            'menu_order' => $original_product->menu_order,
        ];
        
        // Insert the duplicate post
        $duplicate_id = wp_insert_post($duplicate_data);
        
        if (is_wp_error($duplicate_id)) {
            wp_send_json_error(['message' => __('Failed to create duplicate product.', 'vira-store')]);
        }
        
        // Copy all meta data
        $meta_keys = [
            '_vrstore_product_demo_url',
            '_vrstore_product_documentation_url',
            '_vrstore_product_changelog',
            '_vrstore_product_features',
            '_vrstore_product_faq',
            '_vrstore_product_screenshots',
            '_vrstore_product_files',
            '_vrstore_product_price',
            '_vrstore_product_sale_price',
            '_vrstore_product_currency',
            '_vrstore_product_short_description',
            '_vrstore_product_video_type',
            '_vrstore_product_youtube_url',
            '_vrstore_product_video_upload',
            '_vrstore_product_license_info',
            '_vrstore_product_video_config',
            '_vrstore_disable_license_generation',
            '_vrstore_product_license_pricing',
            '_vrstore_product_license_availability',
            '_vrstore_pricing_mode',
            '_vrstore_product_visibility',
            '_vrstore_product_password',
        ];
        
        foreach ($meta_keys as $meta_key) {
            $meta_value = get_post_meta($product_id, $meta_key, true);
            if ($meta_value !== '') {
                update_post_meta($duplicate_id, $meta_key, $meta_value);
            }
        }
        
        // Copy taxonomies (categories and tags)
        $taxonomies = ['vrstore_product_cat', 'vrstore_product_tag'];
        foreach ($taxonomies as $taxonomy) {
            $terms = wp_get_object_terms($product_id, $taxonomy, ['fields' => 'ids']);
            if (!is_wp_error($terms) && !empty($terms)) {
                wp_set_object_terms($duplicate_id, $terms, $taxonomy);
            }
        }
        
        // Copy featured image
        $thumbnail_id = get_post_thumbnail_id($product_id);
        if ($thumbnail_id) {
            set_post_thumbnail($duplicate_id, $thumbnail_id);
        }
        
        $edit_link = get_edit_post_link($duplicate_id);
        
        wp_send_json_success([
            'message' => __('Product duplicated successfully!', 'vira-store'),
            'duplicate_id' => $duplicate_id,
            'edit_link' => $edit_link,
        ]);
    }
    
    /**
     * Add JavaScript for visibility meta box functionality


    /**
     * Render plugin updates meta box
     *
     * @param WP_Post $post Post object
     * @return void
     */
    public function render_plugin_updates_meta_box($post): void {
        // Add nonce for security
        wp_nonce_field('vrstore_plugin_updates_nonce', 'vrstore_plugin_updates_nonce');

        // Get meta values
        $is_plugin_product = get_post_meta($post->ID, '_vrstore_is_plugin_product', true);
        $plugin_slug = get_post_meta($post->ID, '_vrstore_plugin_slug', true);
        $current_version = get_post_meta($post->ID, '_vrstore_current_version', true);

        echo '<div class="vrstore-plugin-updates-meta-box">';
        echo '<table class="form-table">';

        // Enable Plugin Updates
        echo '<tr>';
        echo '<th><label for="vrstore_is_plugin_product">' . __('Enable Plugin Updates', 'vira-store') . '</label></th>';
        echo '<td>';
        echo '<label><input type="checkbox" id="vrstore_is_plugin_product" name="vrstore_is_plugin_product" value="1"' . checked($is_plugin_product, '1', false) . ' /> ';
        echo __('This product provides plugin updates', 'vira-store') . '</label>';
        echo '<p class="description">' . __('Enable this to allow customers to receive plugin updates based on their license.', 'vira-store') . '</p>';
        echo '</td>';
        echo '</tr>';

        // Plugin Slug
        echo '<tr class="vrstore-plugin-field' . ($is_plugin_product ? ' show' : '') . '">';
        echo '<th><label for="vrstore_plugin_slug">' . __('Plugin Slug', 'vira-store') . '</label></th>';
        echo '<td>';
        echo '<input type="text" id="vrstore_plugin_slug" name="vrstore_plugin_slug" value="' . esc_attr($plugin_slug) . '" class="regular-text" placeholder="my-plugin-name" />';
        echo '<p class="description">' . __('The unique slug for your plugin (used in update checks).', 'vira-store') . '</p>';
        echo '</td>';
        echo '</tr>';

        // Current Version
        echo '<tr class="vrstore-plugin-field' . ($is_plugin_product ? ' show' : '') . '">';
        echo '<th><label for="vrstore_current_version">' . __('Current Version', 'vira-store') . '</label></th>';
        echo '<td>';
        echo '<input type="text" id="vrstore_current_version" name="vrstore_current_version" value="' . esc_attr($current_version) . '" class="regular-text" placeholder="1.0.0" />';
        echo '<p class="description">' . __('The current version of your plugin.', 'vira-store') . '</p>';
        echo '</td>';
        echo '</tr>';

        echo '</table>';

        // Plugin Versions Management
        echo '<div class="vrstore-plugin-field' . ($is_plugin_product ? ' show' : '') . '">';
        echo '<h4>' . __('Plugin Versions', 'vira-store') . '</h4>';
        echo '<div id="vrstore-plugin-versions-list">';
        $this->render_plugin_versions_list($post->ID);
        echo '</div>';
        echo '<button type="button" class="button" id="vrstore-add-plugin-version">' . __('Add New Version', 'vira-store') . '</button>';
        echo '</div>';
        echo '</div>';
        
        // JavaScript functionality moved to assets/js/admin.js and handled by initPluginUpdates()
    }

    /**
     * Render plugin versions list
     *
     * @param int $product_id Product ID
     * @return void
     */
    private function render_plugin_versions_list(int $product_id): void {
        global $wpdb;
        
        // Check if table exists before querying
        $table_name = $wpdb->prefix . 'vrstore_plugin_versions';
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") !== $table_name) {
            echo '<p style="color: #d63638;">' . __('Plugin versions table not initialized. Please check database setup.', 'vira-store') . '</p>';
            return;
        }
        
        $versions = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}vrstore_plugin_versions WHERE product_id = %d ORDER BY release_date DESC",
            $product_id
        ));

        if (empty($versions)) {
            echo '<p>' . __('No versions added yet.', 'vira-store') . '</p>';
            return;
        }

        foreach ($versions as $version) {
            $license_tiers = json_decode($version->license_tiers, true) ?: [];
            
            echo '<div class="vrstore-plugin-version-item" style="border: 1px solid #ddd; padding: 15px; margin: 10px 0; background: #f9f9f9;">';
            echo '<table class="form-table">';
            echo '<tr><th><label>Version Number</label></th><td><input type="text" name="vrstore_plugin_versions[' . $version->id . '][version]" value="' . esc_attr($version->version) . '" class="regular-text" /></td></tr>';
            $file_info = '';
            if (!empty($version->file_name)) {
                $file_info = '<strong>' . esc_html($version->file_name) . '</strong>';
                if (!empty($version->file_size)) {
                    $file_info .= ' <span style="color: #666;">(' . size_format($version->file_size, 2) . ')</span>';
                }
                $file_info .= '<br>';
            }
            echo '<tr><th><label>Current File</label></th><td>' . $file_info . '<input type="file" name="vrstore_plugin_version_files[' . $version->id . ']" accept=".zip" /></td></tr>';
            echo '<tr><th><label>Changelog</label></th><td><textarea name="vrstore_plugin_versions[' . $version->id . '][changelog]" rows="3" class="large-text">' . esc_textarea($version->changelog) . '</textarea></td></tr>';
            echo '<tr><th><label>License Tiers</label></th><td>';
            
            // Get custom license types from settings
            $settings = get_option('vrstore_settings', []);
            $custom_license_types = $settings['custom_license_types'] ?? [];
            
            // Get legacy taxonomy license types
            $taxonomy_license_types = get_terms([
                'taxonomy' => 'vrstore_license_type',
                'hide_empty' => false,
            ]);
            
            // Display custom license types from settings first (preferred)
            if (!empty($custom_license_types)) {
                foreach ($custom_license_types as $custom_type) {
                    $slug = $custom_type['slug'] ?? sanitize_title($custom_type['label'] ?? '');
                    $label = $custom_type['label'] ?? ucfirst($slug);
                    $checked = in_array($slug, $license_tiers) ? ' checked' : '';
                    echo '<label><input type="checkbox" name="vrstore_plugin_versions[' . $version->id . '][license_tiers][]" value="' . esc_attr($slug) . '"' . $checked . ' /> ' . esc_html($label) . '</label><br>';
                }
            } 
            // Display legacy taxonomy license types if no custom types are configured
            elseif (!empty($taxonomy_license_types) && !is_wp_error($taxonomy_license_types)) {
                foreach ($taxonomy_license_types as $license_type) {
                    $checked = in_array($license_type->slug, $license_tiers) ? ' checked' : '';
                    echo '<label><input type="checkbox" name="vrstore_plugin_versions[' . $version->id . '][license_tiers][]" value="' . esc_attr($license_type->slug) . '"' . $checked . ' /> ' . esc_html($license_type->name) . '</label><br>';
                }
            } 
            // Fallback to hardcoded values if no license types are configured
            else {
                echo '<label><input type="checkbox" name="vrstore_plugin_versions[' . $version->id . '][license_tiers][]" value="basic"' . (in_array('basic', $license_tiers) ? ' checked' : '') . ' /> Basic</label><br>';
                echo '<label><input type="checkbox" name="vrstore_plugin_versions[' . $version->id . '][license_tiers][]" value="pro"' . (in_array('pro', $license_tiers) ? ' checked' : '') . ' /> Pro</label><br>';
                echo '<label><input type="checkbox" name="vrstore_plugin_versions[' . $version->id . '][license_tiers][]" value="developer"' . (in_array('developer', $license_tiers) ? ' checked' : '') . ' /> Developer</label>';
            }
            
            echo '</td></tr>';
            echo '</table>';
            echo '<button type="button" class="button vrstore-remove-version" data-version-id="' . $version->id . '" style="color: #d63638;">Remove Version</button>';
            echo '</div>';
        }
    }

    /**
     * Get plugin versions for a product
     *
     * @param int $product_id Product ID
     * @param string $license_tier License tier
     * @return array
     */
    public function get_plugin_versions(int $product_id, string $license_tier = ''): array {
        global $wpdb;
        
        // Check if table exists
        $table_name = $wpdb->prefix . 'vrstore_plugin_versions';
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") !== $table_name) {
            return [];
        }
        
        $sql = "SELECT * FROM {$wpdb->prefix}vrstore_plugin_versions WHERE product_id = %d AND is_active = 1";
        $params = [$product_id];
        
        if (!empty($license_tier)) {
            // Fix: Check if license_tier EXISTS in the JSON array
            // The license_tiers field stores JSON like: ["basic", "pro"]
            // We want versions that include this license tier OR have no restrictions (empty/NULL)
            $sql .= " AND (license_tiers LIKE %s OR license_tiers = '' OR license_tiers IS NULL)";
            // Escape the license_tier for LIKE query to prevent SQL injection
            $escaped_tier = $wpdb->esc_like($license_tier);
            // Search for the license tier in JSON format: "license_tier"
            $params[] = '%"' . $escaped_tier . '"%';
        }
        
        $sql .= " ORDER BY release_date DESC";
        
        // Use proper wpdb->prepare with correct parameter handling
        if (count($params) > 1) {
            $query = $wpdb->prepare($sql, ...$params);
        } else {
            $query = $wpdb->prepare($sql, $params[0]);
        }
        
        return $wpdb->get_results($query);
    }

    /**
     * Get latest plugin version for license tier
     *
     * @param int $product_id Product ID
     * @param string $license_tier License tier
     * @return object|null
     */
    public function get_latest_plugin_version(int $product_id, string $license_tier = ''): ?object {
        $versions = $this->get_plugin_versions($product_id, $license_tier);
        return !empty($versions) ? $versions[0] : null;
    }

    /**
     * Check if product is a plugin product
     *
     * @param int $product_id Product ID
     * @return bool
     */
    public function is_plugin_product(int $product_id): bool {
        return get_post_meta($product_id, '_vrstore_is_plugin_product', true) === '1';
    }
    
}