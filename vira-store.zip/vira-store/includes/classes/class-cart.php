<?php
/**
 * Cart Class
 *
 * @package Vira_Store
 * @since 1.0.0
 */

// Exit if accessed directly.
if (!defined("ABSPATH")) {
    exit();
}

/**
 * VRSTORE_Cart Class
 *
 * This class handles cart functionality.
 *
 * @since 1.0.0
 */
class VRSTORE_Cart
{
    /**
     * Instance of this class.
     *
     * @since 1.0.0
     * @var object
     */
    protected static $instance = null;

    /**
     * Return an instance of this class.
     *
     * @since 1.0.0
     * @return object A single instance of this class.
     */
    public static function get_instance()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Constructor.
     *
     * @since 1.0.0
     */
    public function __construct()
    {
        // Initialize secure session handling very early
        add_action("plugins_loaded", [$this, "init_session"], 1);
        add_action("init", [$this, "init_session"], 1);

        // Ensure session is started for AJAX requests
        add_action("wp_ajax_vrstore_add_to_cart", [$this, "ensure_session"], 1);
        add_action(
            "wp_ajax_nopriv_vrstore_add_to_cart",
            [$this, "ensure_session"],
            1,
        );
        add_action("wp_ajax_vrstore_update_cart", [$this, "ensure_session"], 1);
        add_action(
            "wp_ajax_nopriv_vrstore_update_cart",
            [$this, "ensure_session"],
            1,
        );

        $cache_sensitive_actions = [
            "vrstore_add_to_cart",
            "vrstore_update_cart",
            "vrstore_remove_cart_item",
            "vrstore_apply_coupon",
            "vrstore_remove_coupon",
            "vrstore_bulk_remove_items",
            "vrstore_bulk_save_later",
            "vrstore_update_cart_quantity",
            "vrstore_register_user",
        ];

        foreach ($cache_sensitive_actions as $ajax_action) {
            add_action(
                "wp_ajax_{$ajax_action}",
                [$this, "prepare_ajax_environment"],
                0,
            );
            add_action(
                "wp_ajax_nopriv_{$ajax_action}",
                [$this, "prepare_ajax_environment"],
                0,
            );
        }

        // Hook into WordPress actions
        add_action("wp_ajax_vrstore_add_to_cart", [$this, "ajax_add_to_cart"]);
        add_action("wp_ajax_nopriv_vrstore_add_to_cart", [
            $this,
            "ajax_add_to_cart",
        ]);
        add_action("wp_ajax_vrstore_update_cart", [$this, "ajax_update_cart"]);
        add_action("wp_ajax_nopriv_vrstore_update_cart", [
            $this,
            "ajax_update_cart",
        ]);
        add_action("wp_ajax_vrstore_remove_cart_item", [
            $this,
            "ajax_remove_cart_item",
        ]);
        add_action("wp_ajax_nopriv_vrstore_remove_cart_item", [
            $this,
            "ajax_remove_cart_item",
        ]);

        add_action("wp_ajax_vrstore_apply_coupon", [
            $this,
            "ajax_apply_coupon",
        ]);
        add_action("wp_ajax_nopriv_vrstore_apply_coupon", [
            $this,
            "ajax_apply_coupon",
        ]);
        add_action("wp_ajax_vrstore_remove_coupon", [
            $this,
            "ajax_remove_coupon",
        ]);
        add_action("wp_ajax_nopriv_vrstore_remove_coupon", [
            $this,
            "ajax_remove_coupon",
        ]);
        add_action("wp_ajax_vrstore_bulk_remove_items", [
            $this,
            "ajax_bulk_remove_items",
        ]);
        add_action("wp_ajax_nopriv_vrstore_bulk_remove_items", [
            $this,
            "ajax_bulk_remove_items",
        ]);
        add_action("wp_ajax_vrstore_bulk_save_later", [
            $this,
            "ajax_bulk_save_later",
        ]);
        add_action("wp_ajax_nopriv_vrstore_bulk_save_later", [
            $this,
            "ajax_bulk_save_later",
        ]);
        add_action("wp_ajax_vrstore_update_cart_quantity", [
            $this,
            "ajax_update_cart_quantity",
        ]);
        add_action("wp_ajax_nopriv_vrstore_update_cart_quantity", [
            $this,
            "ajax_update_cart_quantity",
        ]);
        add_action("wp_ajax_vrstore_register_user", [
            $this,
            "ajax_register_user",
        ]);
        add_action("wp_ajax_nopriv_vrstore_register_user", [
            $this,
            "ajax_register_user",
        ]);
        add_action("init", [$this, "handle_cart_actions"]);
    }

    /**
     * Prepare AJAX environment for cart endpoints by preventing cache.
     *
     * @since 1.0.0
     * @return void
     */
    public function prepare_ajax_environment()
    {
        $this->prevent_cache_for_ajax();
    }

    /**
     * Initialize secure session handling
     *
     * @since 1.0.0
     * @return void
     */
    public function init_session()
    {
        // Start session for all frontend requests and AJAX requests
        if (!is_admin() || wp_doing_ajax()) {
            $this->start_secure_session();
        }
    }

    /**
     * Ensure session is started for AJAX requests
     *
     * @since 1.0.0
     * @return void
     */
    public function ensure_session()
    {
        // Check both session status and $_SESSION availability
        if (session_status() !== PHP_SESSION_ACTIVE || !isset($_SESSION)) {
            $this->start_secure_session();
        }

        // Double-check session is working after start attempt
        if (session_status() === PHP_SESSION_ACTIVE && isset($_SESSION)) {
            // Initialize cart arrays if needed
            if (!isset($_SESSION["vrstore_cart"])) {
                $_SESSION["vrstore_cart"] = [];
            }
            if (!isset($_SESSION["vrstore_applied_coupon"])) {
                $_SESSION["vrstore_applied_coupon"] = null;
            }
        }
    }

    /**
     * Start a secure session with proper settings
     *
     * @since 1.0.0
     * @return void
     */
    private function start_secure_session()
    {
        // Use centralized session manager
        if (class_exists("VRSTORE_Session_Manager")) {
            $session_manager = VRSTORE_Session_Manager::get_instance_if_needed();
            if (!$session_manager) {
                return; // Skip session operations if not appropriate context
            }
            $session_manager->start_session();

            // Initialize cart data using session manager
            if (!$session_manager->get_session_data("vrstore_cart")) {
                $session_manager->set_session_data("vrstore_cart", []);
            }

            if (!$session_manager->get_session_data("vrstore_applied_coupon")) {
                $session_manager->set_session_data(
                    "vrstore_applied_coupon",
                    null,
                );
            }
        } else {
            // Fallback to original session handling if session manager not available
            if (session_status() === PHP_SESSION_NONE) {
                try {
                    if (!headers_sent()) {
                        ini_set("session.cookie_httponly", 1);
                        ini_set("session.use_only_cookies", 1);
                        ini_set("session.cookie_secure", is_ssl());
                        ini_set("session.cookie_samesite", "Lax");
                        session_name("vrstore_session");

                        if (!session_start()) {
                            error_log("ViraStore: Failed to start session");
                            return;
                        }
                    } else {
                        if (!@session_start()) {
                            error_log(
                                "ViraStore: Failed to start session - headers already sent",
                            );
                            return;
                        }
                    }
                } catch (Exception $e) {
                    error_log(
                        "ViraStore: Session start exception: " .
                            $e->getMessage(),
                    );
                    return;
                }
            }

            // Initialize cart data if not exists and session is active
            if (session_status() === PHP_SESSION_ACTIVE && isset($_SESSION)) {
                if (!isset($_SESSION["vrstore_cart"])) {
                    $_SESSION["vrstore_cart"] = [];
                }

                if (!isset($_SESSION["vrstore_applied_coupon"])) {
                    $_SESSION["vrstore_applied_coupon"] = null;
                }
            }
        }
    }

    /**
     * Prevent caching for AJAX responses to keep cart state consistent.
     *
     * @since 1.0.0
     * @return void
     */
    private function prevent_cache_for_ajax()
    {
        if (!defined("DONOTCACHEPAGE")) {
            define("DONOTCACHEPAGE", true);
        }

        if (function_exists("nocache_headers")) {
            nocache_headers();
        }

        if (
            class_exists("LiteSpeed_Cache_API") &&
            method_exists("LiteSpeed_Cache_API", "force_nocache")
        ) {
            LiteSpeed_Cache_API::force_nocache();
        }
    }

    /**
     * Check if current page needs cart session
     *
     * @since 1.0.0
     * @return bool
     */
    private function needs_cart_session()
    {
        global $post;

        // Check if we're on a page with cart/product shortcodes
        if (is_singular() && is_a($post, "WP_Post")) {
            if (
                has_shortcode($post->post_content, "vrstore_products") ||
                has_shortcode($post->post_content, "vrstore_product") ||
                has_shortcode($post->post_content, "vrstore_cart") ||
                has_shortcode($post->post_content, "vrstore_checkout")
            ) {
                return true;
            }
        }

        // Check for single product pages
        if (is_singular("vrstore_product")) {
            return true;
        }

        // Check for specific plugin pages
        $cart_page = get_option("vrstore_cart_page");
        $checkout_page = get_option("vrstore_checkout_page");
        $products_page = get_option("vrstore_products_page");

        if (is_page([$cart_page, $checkout_page, $products_page])) {
            return true;
        }

        return false;
    }

    /**
     * Handle cart form actions.
     *
     * @since 1.0.0
     * @return void
     */
    public function handle_cart_actions()
    {
        // Handle cart update
        if (
            isset($_POST["update_cart"]) &&
            isset($_POST["vrstore_cart_nonce"])
        ) {
            if (
                wp_verify_nonce(
                    $_POST["vrstore_cart_nonce"],
                    "vrstore_update_cart",
                )
            ) {
                $this->update_cart();
            }
        }

        // Handle item removal
        if (
            isset($_POST["remove_cart_item"]) &&
            isset($_POST["vrstore_cart_nonce"])
        ) {
            if (
                wp_verify_nonce(
                    $_POST["vrstore_cart_nonce"],
                    "vrstore_update_cart",
                )
            ) {
                $this->remove_cart_item(
                    sanitize_text_field($_POST["remove_cart_item"]),
                );
            }
        }
    }

    /**
     * AJAX add to cart handler.
     *
     * @since 1.0.0
     * @return void
     */
    public function ajax_add_to_cart()
    {
        // Start performance monitoring
        $start_time = microtime(true);
        $this->log_cart_debug("AJAX add to cart started", [
            "start_time" => $start_time,
        ]);

        // Session is handled by session manager via AJAX hooks
        // Session will be started automatically if needed by session manager

        // Verify session manager is available or fallback to manual session check
        if (class_exists("VRSTORE_Session_Manager")) {
            $session_manager = VRSTORE_Session_Manager::get_instance_if_needed();
            // Session manager will handle session initialization as needed if context is appropriate
        } else {
            // Fallback: ensure session is active for legacy support
            if (session_status() !== PHP_SESSION_ACTIVE) {
                $this->log_cart_debug("Session error - not active", [
                    "session_status" => session_status(),
                ]);
                wp_send_json_error([
                    "message" => esc_html__(
                        "Session error. Please refresh the page and try again.",
                        "vira-store",
                    ),
                ]);
            }
        }

        // Check nonce with multiple fallbacks
        $nonce_valid = false;
        if (isset($_POST["nonce"])) {
            if (wp_verify_nonce($_POST["nonce"], "vrstore_frontend_nonce")) {
                $nonce_valid = true;
            } elseif (wp_verify_nonce($_POST["nonce"], "vrstore_custom_auth")) {
                $nonce_valid = true;
            } elseif (wp_verify_nonce($_POST["nonce"], "vrstore_checkout")) {
                $nonce_valid = true;
            }
        }

        if (!$nonce_valid) {
            wp_send_json_error([
                "message" => esc_html__(
                    "Security check failed. Please refresh the page and try again.",
                    "vira-store",
                ),
            ]);
        }

        $product_id = absint($_POST["product_id"] ?? 0);
        $quantity = isset($_POST["quantity"]) ? absint($_POST["quantity"]) : 1;
        $license_type = isset($_POST["license_type"])
            ? sanitize_text_field($_POST["license_type"])
            : "";

        // Validate product - accept both products and courses
        $post_type = get_post_type($product_id);
        if (
            !$product_id ||
            ("vrstore_product" !== $post_type &&
                "vrstore_course" !== $post_type)
        ) {
            wp_send_json_error([
                "message" => esc_html__("Invalid product.", "vira-store"),
            ]);
        }

        // Check if product is published
        $product = get_post($product_id);
        if (!$product || $product->post_status !== "publish") {
            wp_send_json_error([
                "message" => esc_html__(
                    "This product is not available.",
                    "vira-store",
                ),
            ]);
        }

        // Add to cart
        $result = $this->add_to_cart($product_id, $quantity, $license_type);

        if ($result) {
            $cart_count = $this->get_cart_count();

            // Check for redirect settings
            $settings = get_option("vrstore_settings", []);
            $redirect_url = "";

            // Check if checkout redirect is enabled (takes priority)
            if (!empty($settings["enable_checkout_redirect"])) {
                $checkout_page_id = !empty($settings["checkout_page"])
                    ? $settings["checkout_page"]
                    : 0;
                if ($checkout_page_id) {
                    $redirect_url = get_permalink($checkout_page_id);
                }
            }
            // Otherwise check if cart redirect is enabled
            elseif (!empty($settings["enable_cart_redirect"])) {
                $cart_page_id = !empty($settings["cart_page"])
                    ? $settings["cart_page"]
                    : 0;
                if ($cart_page_id) {
                    $redirect_url = get_permalink($cart_page_id);
                }
            }

            $response_data = [
                "message" => esc_html__(
                    "Product added to cart successfully.",
                    "vira-store",
                ),
                "cart_count" => $cart_count,
            ];

            // Add redirect URL if available
            if (!empty($redirect_url)) {
                $response_data["redirect_url"] = $redirect_url;
            }

            // Log performance and success
            $end_time = microtime(true);
            $execution_time = ($end_time - $start_time) * 1000; // Convert to milliseconds
            $this->log_cart_debug("AJAX add to cart completed successfully", [
                "execution_time_ms" => round($execution_time, 2),
                "cart_count" => $cart_count,
                "product_id" => $product_id,
                "license_type" => $license_type,
                "redirect_url" => $redirect_url,
            ]);

            wp_send_json_success($response_data);
        } else {
            // Log failure
            $end_time = microtime(true);
            $execution_time = ($end_time - $start_time) * 1000;
            $this->log_cart_debug("AJAX add to cart failed", [
                "execution_time_ms" => round($execution_time, 2),
                "product_id" => $product_id,
                "license_type" => $license_type,
                "error" => "add_to_cart returned false",
            ]);

            wp_send_json_error([
                "message" => esc_html__(
                    "Failed to add product to cart.",
                    "vira-store",
                ),
            ]);
        }
    }

    /**
     * Add product to cart.
     *
     * @since 1.0.0
     * @param int    $product_id   Product ID.
     * @param int    $quantity     Quantity.
     * @param string $license_type License type.
     * @return bool
     */
    public function add_to_cart($product_id, $quantity = 1, $license_type = "")
    {
        $product_id = absint($product_id);
        $quantity = absint($quantity);

        if (!$product_id || $quantity <= 0) {
            return false;
        }

        // If no license type provided, automatically select the cheapest one
        // But only if custom license types are actually configured AND it's not a course
        if (empty($license_type)) {
            $settings = VRSTORE_Settings::get_instance();
            $custom_license_types = $settings->get_setting(
                "custom_license_types",
                [],
            );

            // Skip license type assignment for courses - they should use their own pricing
            $post_type = get_post_type($product_id);
            if (
                $post_type !== "vrstore_course" &&
                !empty($custom_license_types) &&
                is_array($custom_license_types)
            ) {
                $license_type = $this->get_cheapest_license_type($product_id);
            }
            // If no custom license types are configured OR it's a course, leave license_type empty
            // This will cause the cart to use base product/course pricing
        }

        // Create cart item key
        $cart_key = md5($product_id . $license_type);

        // Check if item already exists in cart
        $cart = $this->get_cart();

        if (isset($cart[$cart_key])) {
            // Set the quantity directly instead of adding to it
            $cart[$cart_key]["quantity"] = $quantity;
        } else {
            $cart[$cart_key] = [
                "product_id" => $product_id,
                "quantity" => $quantity,
                "license_type" => $license_type,
                "added_time" => time(),
            ];
        }

        $this->set_session_data("vrstore_cart", $cart);

        // Trigger cache purging for LiteSpeed integration
        do_action("vrstore_cart_item_added", $product_id);
        do_action("vrstore_cart_updated");

        return true;
    }

    /**
     * Get the cheapest license type for a product
     *
     * @param int $product_id Product ID
     * @return string License type slug
     */
    private function get_cheapest_license_type($product_id)
    {
        // Get settings instance
        if (!class_exists("VRSTORE_Settings")) {
            return "single"; // Default fallback
        }

        $settings = VRSTORE_Settings::get_instance();
        $custom_license_types = $settings->get_setting(
            "custom_license_types",
            [],
        );

        if (empty($custom_license_types) || !is_array($custom_license_types)) {
            return "single"; // Default fallback
        }

        // Get license pricing for this product
        $license_pricing = get_post_meta(
            $product_id,
            "_vrstore_product_license_pricing",
            true,
        );
        if (!is_array($license_pricing)) {
            $license_pricing = [];
        }

        $cheapest_license = null;
        $lowest_price = null;
        $first_valid_license = null; // Fallback to first valid license

        foreach ($custom_license_types as $type) {
            $slug = isset($type["slug"])
                ? $type["slug"]
                : sanitize_title($type["label"]);

            // Store first valid license as fallback
            if ($first_valid_license === null && !empty($slug)) {
                $first_valid_license = $slug;
            }

            $license_price = null;
            $license_sale_price = null;

            // Check for product-specific pricing first
            if (
                isset($license_pricing[$slug]) &&
                is_array($license_pricing[$slug])
            ) {
                $license_price = isset($license_pricing[$slug]["price"])
                    ? $license_pricing[$slug]["price"]
                    : null;
                $license_sale_price = isset(
                    $license_pricing[$slug]["sale_price"],
                )
                    ? $license_pricing[$slug]["sale_price"]
                    : null;
            } else {
                // Use global settings defaults
                $license_price = isset($type["regular_price"])
                    ? $type["regular_price"]
                    : null;
                $license_sale_price = isset($type["sale_price"])
                    ? $type["sale_price"]
                    : null;
            }

            // Determine effective price (sale price takes priority)
            $effective_price = null;
            if (
                $license_sale_price !== null &&
                is_numeric($license_sale_price) &&
                floatval($license_sale_price) >= 0
            ) {
                $effective_price = floatval($license_sale_price);
            } elseif (
                $license_price !== null &&
                is_numeric($license_price) &&
                floatval($license_price) >= 0
            ) {
                $effective_price = floatval($license_price);
            }

            // Track the cheapest option (including free/0 price options)
            if (
                $effective_price !== null &&
                ($lowest_price === null || $effective_price < $lowest_price)
            ) {
                $cheapest_license = $slug;
                $lowest_price = $effective_price;
            }
        }

        // Return cheapest license, or first valid license, or 'single' as final fallback
        return $cheapest_license ?: ($first_valid_license ?: "single");
    }

    /**
     * Update cart quantities.
     *
     * @since 1.0.0
     * @return void
     */
    public function update_cart()
    {
        if (
            !isset($_POST["cart_quantity"]) ||
            !is_array($_POST["cart_quantity"])
        ) {
            return;
        }

        $cart = $this->get_cart();
        $updated = false;

        foreach ($_POST["cart_quantity"] as $cart_key => $quantity) {
            $cart_key = sanitize_text_field($cart_key);
            $quantity = absint($quantity);

            if (isset($cart[$cart_key])) {
                if ($quantity > 0) {
                    $cart[$cart_key]["quantity"] = $quantity;
                } else {
                    unset($cart[$cart_key]);
                }
                $updated = true;
            }
        }

        if ($updated) {
            $this->set_session_data("vrstore_cart", $cart);
        }

        // Redirect to prevent resubmission
        wp_redirect($_SERVER["REQUEST_URI"]);
        exit();
    }

    /**
     * Remove item from cart.
     *
     * @since 1.0.0
     * @param string $cart_key Cart item key.
     * @return void
     */
    public function remove_cart_item($cart_key)
    {
        $cart_key = sanitize_text_field($cart_key);
        $cart = $this->get_cart();

        if (isset($cart[$cart_key])) {
            unset($cart[$cart_key]);
            $this->set_session_data("vrstore_cart", $cart);
        }

        // Redirect to prevent resubmission
        wp_redirect($_SERVER["REQUEST_URI"]);
        exit();
    }

    /**
     * Get cart data from session manager or fallback to $_SESSION or cookies
     *
     * @since 1.0.0
     * @param string $key Session key
     * @return mixed
     */
    private function get_session_data($key)
    {
        $data = null;

        // Try session manager first
        if (class_exists("VRSTORE_Session_Manager")) {
            $session_manager = VRSTORE_Session_Manager::get_instance_if_needed();
            if ($session_manager) {
                $data = $session_manager->get_session_data($key);
            }
        }

        // Try direct session access if manager not available
        if (
            $data === null &&
            session_status() === PHP_SESSION_ACTIVE &&
            isset($_SESSION[$key])
        ) {
            $data = $_SESSION[$key];
        }

        // If cart/coupon is empty or not set in session, hydrate from cookie
        if ($key === "vrstore_cart") {
            $cookie_cart = $this->get_cart_from_cookie();
            if (empty($data) && !empty($cookie_cart)) {
                // Prefer cookie backup when session is empty
                $data = $cookie_cart;
            }
        } elseif ($key === "vrstore_applied_coupon") {
            $cookie_coupon = $this->get_coupon_from_cookie();
            if ($data === null && $cookie_coupon !== null) {
                $data = $cookie_coupon;
            }
        }

        return $data;
    }

    /**
     * Set cart data in session manager or fallback to $_SESSION and cookies
     *
     * @since 1.0.0
     * @param string $key Session key
     * @param mixed $value Session value
     * @return void
     */
    private function set_session_data($key, $value)
    {
        $session_set = false;

        // Try session manager first
        if (class_exists("VRSTORE_Session_Manager")) {
            $session_manager = VRSTORE_Session_Manager::get_instance_if_needed();
            if ($session_manager) {
                $session_set = $session_manager->set_session_data($key, $value);
            }
        }

        // Try direct session access if session manager failed
        if (!$session_set && session_status() === PHP_SESSION_ACTIVE) {
            $_SESSION[$key] = $value;
            $session_set = true;
        }

        // Always set cookie backup for cart data
        if ($key === "vrstore_cart") {
            $this->set_cart_cookie($value);
        } elseif ($key === "vrstore_applied_coupon") {
            $this->set_coupon_cookie($value);
        }

        // If no session available, try to start one
        if (!$session_set) {
            $this->start_secure_session();
            if (session_status() === PHP_SESSION_ACTIVE) {
                $_SESSION[$key] = $value;
            }
        }
    }

    /**
     * Get cart contents.
     *
     * @since 1.0.0
     * @return array
     */
    public function get_cart()
    {
        $cart = $this->get_session_data("vrstore_cart");
        return is_array($cart) ? $cart : [];
    }

    /**
     * Get cart count.
     *
     * @since 1.0.0
     * @return int
     */
    public function get_cart_count()
    {
        $cart = $this->get_cart();
        $count = 0;

        foreach ($cart as $item) {
            $count += $item["quantity"];
        }

        return $count;
    }

    /**
     * Add Extended Support item to cart.
     *
     * @since 1.0.0
     * @param array $cart_item Extended Support cart item data.
     * @return bool
     */
    public function add_extended_support_to_cart($cart_item)
    {
        if (
            !isset($cart_item["product_id"]) ||
            !isset($cart_item["quantity"])
        ) {
            error_log(
                "ViraStore: Extended Support - Missing required cart item data",
            );
            return false;
        }

        // Ensure session is available
        $this->ensure_session();

        // Debug logging
        error_log(
            "ViraStore: Adding Extended Support item to cart: " .
                print_r($cart_item, true),
        );

        // Create cart item key for Extended Support items
        $cart_key = md5($cart_item["product_id"] . "_extended_support");

        // Get current cart
        $cart = $this->get_cart();
        error_log(
            "ViraStore: Current cart before adding Extended Support: " .
                print_r($cart, true),
        );

        // Add the complete cart item data to cart
        $cart[$cart_key] = $cart_item;
        $cart[$cart_key]["added_time"] = time();

        // Save updated cart
        $this->set_session_data("vrstore_cart", $cart);

        // Verify cart was saved
        $updated_cart = $this->get_cart();
        error_log(
            "ViraStore: Cart after adding Extended Support: " .
                print_r($updated_cart, true),
        );
        error_log(
            "ViraStore: Extended Support cart count: " .
                $this->get_cart_count(),
        );

        // Trigger cache purging for LiteSpeed integration
        do_action("vrstore_cart_item_added", $cart_item["product_id"]);
        do_action("vrstore_cart_updated");

        return true;
    }

    /**
     * Get cart total.
     *
     * @since 1.0.0
     * @return float
     */
    public function get_cart_total()
    {
        $cart = $this->get_cart();
        $total = 0;

        error_log(
            "ViraStore Cart: get_cart_total() called with cart items: " .
                print_r($cart, true),
        );

        // Check if we have mixed cart (Extended Support + regular items)
        $has_extended_support = false;
        $has_regular_products = false;

        foreach ($cart as $item) {
            if (
                isset($item["product_id"]) &&
                is_string($item["product_id"]) &&
                strpos($item["product_id"], "extended_support") === 0
            ) {
                $has_extended_support = true;
            } else {
                $has_regular_products = true;
            }
        }

        foreach ($cart as $item) {
            $item_price = $this->get_item_price($item);

            // Extended Support items store the total price (not per-item)
            if (
                isset($item["product_id"]) &&
                is_string($item["product_id"]) &&
                strpos($item["product_id"], "extended_support") === 0
            ) {
                $total += $item_price; // Already the total amount
            } else {
                // Regular products
                $item_total = $item_price * $item["quantity"];
                $total += $item_total;
            }
        }

        error_log(
            "ViraStore Cart: Final total calculated: " .
                var_export($total, true) .
                " (type: " .
                gettype($total) .
                ")",
        );

        // Ensure we return a proper float value
        $total = floatval($total);

        error_log("ViraStore Cart: Returning total as float: " . $total);

        return $total;
    }

    /**
     * Get item price based on unified custom licensing system or regular pricing.
     *
     * @since 1.0.0
     * @param array $item Cart item data.
     * @return float Item price.
     */
    public function get_item_price($item)
    {
        $price = 0;

        // Handle extended support items - they have their own pricing structure
        if (
            isset($item["product_id"]) &&
            is_string($item["product_id"]) &&
            strpos($item["product_id"], "extended_support") === 0
        ) {
            // For extended support items, use the price from the item data directly
            if (isset($item["price"])) {
                return floatval($item["price"]);
            }
            // Fallback to total if price not set
            if (isset($item["total"])) {
                return floatval($item["total"]);
            }
            return 0;
        }

        // Get basic product pricing first (only for numeric product IDs)
        if (is_numeric($item["product_id"])) {
            $post_type = get_post_type($item["product_id"]);

            // Handle courses with course-specific meta keys
            if ($post_type === "vrstore_course") {
                $regular_price = get_post_meta(
                    $item["product_id"],
                    "_vrstore_course_price",
                    true,
                );
                $sale_price = get_post_meta(
                    $item["product_id"],
                    "_vrstore_course_sale_price",
                    true,
                );
            } else {
                // Handle regular products
                $regular_price = get_post_meta(
                    $item["product_id"],
                    "_vrstore_product_price",
                    true,
                );
                $sale_price = get_post_meta(
                    $item["product_id"],
                    "_vrstore_product_sale_price",
                    true,
                );
            }

            // Start with regular price as base
            $price =
                !empty($regular_price) && is_numeric($regular_price)
                    ? floatval($regular_price)
                    : 0;

            // Override with sale price if available and greater than 0
            if (
                !empty($sale_price) &&
                is_numeric($sale_price) &&
                floatval($sale_price) > 0
            ) {
                $price = floatval($sale_price);
            }
        }

        // Try unified custom license pricing if license type is specified and product_id is numeric
        if (
            !empty($item["license_type"]) &&
            class_exists("VRSTORE_License") &&
            is_numeric($item["product_id"])
        ) {
            $license_instance = VRSTORE_License::get_instance();
            $license_price = $license_instance->get_license_type_price(
                intval($item["product_id"]),
                $item["license_type"],
            );

            // Use license price if available and is a valid number greater than 0
            // If license price is 0, fall back to base product price unless it's explicitly a free license
            if (
                $license_price !== null &&
                is_numeric($license_price) &&
                floatval($license_price) > 0
            ) {
                $price = floatval($license_price);
            } elseif (
                $license_price !== null &&
                floatval($license_price) === 0.0 &&
                $price > 0
            ) {
                // License price is 0 but base price exists - use base price unless license is explicitly free
                // Check if this is an intentionally free license or just missing pricing
                $settings = get_option("vrstore_settings", []);
                $custom_license_types = isset($settings["custom_license_types"])
                    ? $settings["custom_license_types"]
                    : [];
                $is_intentionally_free = false;

                foreach ($custom_license_types as $type) {
                    if (
                        isset($type["slug"]) &&
                        $type["slug"] === $item["license_type"]
                    ) {
                        // Check if this license type has explicit pricing set to 0
                        if (
                            (isset($type["regular_price"]) &&
                                floatval($type["regular_price"]) === 0.0) ||
                            (isset($type["sale_price"]) &&
                                floatval($type["sale_price"]) === 0.0)
                        ) {
                            $is_intentionally_free = true;
                        }
                        break;
                    }
                }

                if (!$is_intentionally_free) {
                    // Use base product price as fallback
                    // $price already contains the base price from above, so no change needed
                } else {
                    $price = 0.0; // Explicitly free license
                }
            }
            // If license_price is null, we keep the regular $price from above
            // This ensures proper fallback to regular pricing when license pricing is not configured
        }

        // Final fallback: if price is still 0 and we have a numeric product_id, try alternative price meta keys
        if ($price <= 0 && is_numeric($item["product_id"])) {
            // Try alternative meta keys that might be used
            $alt_price = get_post_meta($item["product_id"], "_price", true);
            if (
                !empty($alt_price) &&
                is_numeric($alt_price) &&
                floatval($alt_price) > 0
            ) {
                $price = floatval($alt_price);
            }
        }

        return $price;
    }

    /**
     * Clear only applied coupon without clearing cart items.
     *
     * @since 1.0.0
     * @return void
     */
    public function clear_applied_coupon()
    {
        $this->set_session_data("vrstore_applied_coupon", null);
    }

    /**
     * AJAX clear cart handler.
     *
     * @since 1.0.0
     * @return void
     */
    public function ajax_clear_cart()
    {
        // Check nonce
        if (!wp_verify_nonce($_POST["nonce"], "vrstore_frontend_nonce")) {
            wp_send_json_error([
                "message" => esc_html__("Security check failed.", "vira-store"),
            ]);
        }

        $this->clear_cart();

        wp_send_json_success([
            "message" => esc_html__("Cart cleared successfully.", "vira-store"),
            "cart_count" => 0,
            "cart_total" => 0,
        ]);
    }

    /**
     * Check if cart is empty.
     *
     * @since 1.0.0
     * @return bool
     */
    public function is_cart_empty()
    {
        $cart = $this->get_cart();
        return empty($cart);
    }

    /**
     * Clear the entire cart and related state (sessions + cookies), then fire hooks.
     *
     * @since 1.0.0
     * @return void
     */
    public function clear_cart()
    {
        // Ensure a session context exists before touching session data
        $this->ensure_session();

        // Reset cart and coupon in the session manager / session superglobal
        $this->set_session_data("vrstore_cart", []);
        $this->set_session_data("vrstore_applied_coupon", null);

        // Clear cookie fallbacks so stale carts don't reappear
        $this->clear_cart_cookies();

        // Allow integrations to react (e.g., cache purging)
        do_action("vrstore_cart_cleared");
        do_action("vrstore_cart_updated");
    }

    /**
     * Get cart item by key.
     *
     * @since 1.0.0
     * @param string $cart_key Cart item key.
     * @return array|false
     */
    public function get_cart_item($cart_key)
    {
        $cart = $this->get_cart();
        return isset($cart[$cart_key]) ? $cart[$cart_key] : false;
    }

    /**
     * Update cart item quantity.
     *
     * @since 1.0.0
     * @param string $cart_key Cart item key.
     * @param int    $quantity New quantity.
     * @return bool
     */
    public function update_cart_item_quantity($cart_key, $quantity)
    {
        $cart_key = sanitize_text_field($cart_key);
        $quantity = absint($quantity);

        // Ensure quantity is at least 1
        if ($quantity < 1) {
            $quantity = 1;
        }

        $cart = $this->get_cart();
        if (isset($cart[$cart_key])) {
            $cart[$cart_key]["quantity"] = $quantity;
            $this->set_session_data("vrstore_cart", $cart);

            // Trigger cache purging for LiteSpeed integration
            do_action("vrstore_cart_updated");

            return true;
        }

        return false;
    }

    /**
     * Apply coupon to cart.
     *
     * @since 1.0.0
     * @param string $coupon_code Coupon code.
     * @return array Result with success status and message.
     */
    public function apply_coupon($coupon_code)
    {
        $coupon_code = sanitize_text_field($coupon_code);

        if (empty($coupon_code)) {
            return [
                "success" => false,
                "message" => esc_html__(
                    "Please enter a coupon code.",
                    "vira-store",
                ),
            ];
        }

        // Get coupon instance
        if (!class_exists("VRSTORE_Coupon")) {
            return [
                "success" => false,
                "message" => esc_html__(
                    "Coupon system is not available.",
                    "vira-store",
                ),
            ];
        }

        $coupon_class = VRSTORE_Coupon::get_instance();
        $coupon = $coupon_class->get_coupon_by_code($coupon_code);

        if (!$coupon) {
            return [
                "success" => false,
                "message" => esc_html__("Invalid coupon code.", "vira-store"),
            ];
        }

        // Prepare order data for validation - now includes license type data
        $cart_total = $this->get_cart_total();
        $cart_items = $this->get_cart();
        $product_ids = [];
        $license_types = [];

        foreach ($cart_items as $item) {
            $product_ids[] = $item["product_id"];
            // Include license type information for coupon validation
            if (!empty($item["license_type"])) {
                $license_types[$item["product_id"]] = $item["license_type"];
            }
        }

        $order_data = [
            "subtotal" => $cart_total,
            "product_ids" => $product_ids,
            "license_types" => $license_types,
        ];

        // Validate coupon
        $validation = $coupon_class->validate_coupon($coupon_code, $order_data);

        if (is_wp_error($validation)) {
            return [
                "success" => false,
                "message" => $validation->get_error_message(),
            ];
        }

        // Apply coupon
        $this->set_session_data("vrstore_applied_coupon", $coupon);

        return [
            "success" => true,
            "message" => esc_html__(
                "Coupon applied successfully!",
                "vira-store",
            ),
            "coupon" => $coupon,
            "discount_amount" => $validation["discount_amount"],
        ];
    }

    /**
     * Remove applied coupon from cart.
     *
     * @since 1.0.0
     * @return array Result with success status and message.
     */
    public function remove_coupon()
    {
        $this->set_session_data("vrstore_applied_coupon", null);

        return [
            "success" => true,
            "message" => esc_html__(
                "Coupon removed successfully.",
                "vira-store",
            ),
        ];
    }

    /**
     * Get applied coupon.
     *
     * @since 1.0.0
     * @return array|null Applied coupon data or null.
     */
    public function get_applied_coupon()
    {
        $coupon = $this->get_session_data("vrstore_applied_coupon");

        if ($coupon && class_exists("VRSTORE_Coupon")) {
            $coupon_class = VRSTORE_Coupon::get_instance();
            // Re-validate the coupon to ensure it's still active and valid
            // We need to pass dummy order data for validation, as we only care if the coupon itself is valid
            $validation = $coupon_class->validate_coupon($coupon["code"], [
                "subtotal" => 0,
                "product_ids" => [],
                "license_types" => [],
            ]);

            if (is_wp_error($validation)) {
                // Coupon is no longer valid, remove it from session
                $this->set_session_data("vrstore_applied_coupon", null);
                return null;
            }
        }

        return $coupon;
    }

    /**
     * Calculate discount amount for applied coupon.
     *
     * @since 1.0.0
     * @return float Discount amount.
     */
    public function get_discount_amount()
    {
        $coupon = $this->get_applied_coupon();

        if (!$coupon || !class_exists("VRSTORE_Coupon")) {
            return 0;
        }

        $coupon_class = VRSTORE_Coupon::get_instance();
        $cart_total = $this->get_cart_total();
        $cart_items = $this->get_cart();
        $product_ids = [];
        $license_types = [];

        foreach ($cart_items as $item) {
            $product_ids[] = $item["product_id"];
            // Include license type information for discount calculation
            if (!empty($item["license_type"])) {
                $license_types[$item["product_id"]] = $item["license_type"];
            }
        }

        $order_data = [
            "subtotal" => $cart_total,
            "product_ids" => $product_ids,
            "license_types" => $license_types,
        ];

        $validation = $coupon_class->validate_coupon(
            $coupon["code"],
            $order_data,
        );

        if (is_wp_error($validation)) {
            return 0;
        }

        return $validation["discount_amount"];
    }

    /**
     * Get cart total with discount applied.
     *
     * @since 1.0.0
     * @return float Final total after discount.
     */
    public function get_cart_total_with_discount()
    {
        $subtotal = $this->get_cart_total();
        $discount = $this->get_discount_amount();

        error_log(
            "ViraStore Cart: get_cart_total_with_discount() - Subtotal: " .
                var_export($subtotal, true) .
                ", Discount: " .
                var_export($discount, true),
        );

        $final_total = max(0, $subtotal - $discount);

        error_log(
            "ViraStore Cart: Final total with discount: " .
                var_export($final_total, true) .
                " (type: " .
                gettype($final_total) .
                ")",
        );

        // Ensure we return a proper float value
        $final_total = floatval($final_total);

        return $final_total;
    }

    /**
     * AJAX apply coupon handler.
     *
     * @since 1.0.0
     * @return void
     */
    public function ajax_apply_coupon()
    {
        // Check nonce
        if (!wp_verify_nonce($_POST["nonce"], "vrstore_frontend_nonce")) {
            wp_send_json_error([
                "message" => esc_html__("Security check failed.", "vira-store"),
            ]);
        }

        $coupon_code = sanitize_text_field($_POST["coupon_code"] ?? "");
        $result = $this->apply_coupon($coupon_code);

        if ($result["success"]) {
            // Get formatted prices for display
            $settings = VRSTORE_Settings::get_instance();
            $currency = $settings->get_setting("currency", "USD");
            $product_instance = VRSTORE_Product::get_instance();

            $subtotal = $this->get_cart_total();
            $discount = $this->get_discount_amount();
            $total = $this->get_cart_total_with_discount();

            $cart_data = [
                "subtotal" => $product_instance->format_price(
                    $subtotal,
                    $currency,
                ),
                "discount" => $product_instance->format_price(
                    $discount,
                    $currency,
                ),
                "total" => $product_instance->format_price($total, $currency),
                "coupon" => $this->get_applied_coupon(),
                "raw_subtotal" => $subtotal,
                "raw_discount" => $discount,
                "raw_total" => $total,
                "cart_count" => $this->get_cart_count(),
            ];

            wp_send_json_success([
                "message" => $result["message"],
                "cart_data" => $cart_data,
            ]);
        } else {
            wp_send_json_error([
                "message" => $result["message"],
            ]);
        }
    }

    /**
     * AJAX remove coupon handler.
     *
     * @since 1.0.0
     * @return void
     */
    public function ajax_remove_coupon()
    {
        // Check nonce
        if (!wp_verify_nonce($_POST["nonce"], "vrstore_frontend_nonce")) {
            wp_send_json_error([
                "message" => esc_html__("Security check failed.", "vira-store"),
            ]);
        }

        $result = $this->remove_coupon();

        // Get formatted prices for display
        $settings = VRSTORE_Settings::get_instance();
        $currency = $settings->get_setting("currency", "USD");
        $product_instance = VRSTORE_Product::get_instance();

        $subtotal = $this->get_cart_total();
        $total = $this->get_cart_total();

        $cart_data = [
            "subtotal" => $product_instance->format_price($subtotal, $currency),
            "discount" => $product_instance->format_price(0, $currency),
            "total" => $product_instance->format_price($total, $currency),
            "coupon" => null,
            "raw_subtotal" => $subtotal,
            "raw_discount" => 0,
            "raw_total" => $total,
            "cart_count" => $this->get_cart_count(),
        ];

        wp_send_json_success([
            "message" => $result["message"],
            "cart_data" => $cart_data,
        ]);
    }

    /**
     * AJAX update cart handler.
     *
     * @since 1.0.0
     * @return void
     */
    public function ajax_update_cart()
    {
        // Check nonce
        if (!wp_verify_nonce($_POST["nonce"], "vrstore_frontend_nonce")) {
            wp_send_json_error([
                "message" => esc_html__("Security check failed.", "vira-store"),
            ]);
        }

        $cart_key = sanitize_text_field($_POST["cart_key"] ?? "");
        $product_id = absint($_POST["product_id"] ?? 0);
        $quantity = isset($_POST["quantity"]) ? absint($_POST["quantity"]) : 1;

        // Ensure quantity is at least 1
        if ($quantity < 1) {
            $quantity = 1;
        }

        if (empty($cart_key) && !$product_id) {
            wp_send_json_error([
                "message" => esc_html__("Invalid cart item.", "vira-store"),
            ]);
        }

        // Resolve cart key if not provided
        $cart_key = $this->resolve_cart_key($cart_key, $product_id);
        if (!$cart_key) {
            wp_send_json_error([
                "message" => esc_html__("Cart item not found.", "vira-store"),
            ]);
        }

        // Update cart item quantity
        $result = $this->update_cart_item_quantity($cart_key, $quantity);

        if ($result) {
            // Calculate new totals and get cart response data
            $cart_response = $this->get_cart_response_data(
                $cart_key,
                $quantity,
            );

            wp_send_json_success(
                array_merge(
                    [
                        "message" => esc_html__(
                            "Cart updated successfully.",
                            "vira-store",
                        ),
                    ],
                    $cart_response,
                ),
            );
        } else {
            wp_send_json_error([
                "message" => esc_html__("Failed to update cart.", "vira-store"),
            ]);
        }
    }

    /**
     * AJAX remove cart item handler.
     *
     * @since 1.0.0
     * @return void
     */
    public function ajax_remove_cart_item()
    {
        // Check nonce
        if (!wp_verify_nonce($_POST["nonce"], "vrstore_frontend_nonce")) {
            wp_send_json_error([
                "message" => esc_html__("Security check failed.", "vira-store"),
            ]);
        }

        $cart_key = sanitize_text_field($_POST["cart_key"] ?? "");
        $product_id = absint($_POST["product_id"] ?? 0);

        if (empty($cart_key) && !$product_id) {
            wp_send_json_error([
                "message" => esc_html__("Invalid cart item.", "vira-store"),
            ]);
        }

        // Remove from cart
        $cart = $this->get_cart();
        $updated = false;

        if (!empty($cart_key) && isset($cart[$cart_key])) {
            unset($cart[$cart_key]);
            $updated = true;
        } elseif ($product_id) {
            // Find and remove by product ID
            foreach ($cart as $key => $item) {
                if ($item["product_id"] == $product_id) {
                    unset($cart[$key]);
                    $updated = true;
                    break;
                }
            }
        }

        if ($updated) {
            $this->set_session_data("vrstore_cart", $cart);

            // Trigger cache purging for LiteSpeed integration
            do_action("vrstore_cart_item_removed", $product_id);
            do_action("vrstore_cart_updated");
        }

        // Calculate new totals
        $cart_total = $this->get_cart_total_with_discount();
        $cart_count = $this->get_cart_count();

        // Format price
        $settings = VRSTORE_Settings::get_instance();
        $currency = $settings->get_setting("currency", "USD");
        $product_instance = VRSTORE_Product::get_instance();

        $cart_total_formatted = $product_instance->format_price(
            $cart_total,
            $currency,
        );

        wp_send_json_success([
            "message" => esc_html__("Item removed from cart.", "vira-store"),
            "cart_total" => $cart_total_formatted,
            "cart_count" => $cart_count,
        ]);
    }

    /**
     * Resolve cart key from cart key or product ID
     *
     * @since 1.0.0
     * @param string $cart_key   Cart key.
     * @param int    $product_id Product ID.
     * @return string|false Cart key or false if not found.
     */
    private function resolve_cart_key($cart_key, $product_id)
    {
        if (!empty($cart_key)) {
            return $cart_key;
        }

        if (!$product_id) {
            return false;
        }

        // Find cart key by product ID
        $cart = $this->get_cart();
        foreach ($cart as $key => $item) {
            if ($item["product_id"] == $product_id) {
                return $key;
            }
        }

        return false;
    }

    /**
     * Get formatted cart response data
     *
     * @since 1.0.0
     * @param string $cart_key Cart key.
     * @param int    $quantity Quantity.
     * @return array Formatted cart data for AJAX responses.
     */
    private function get_cart_response_data($cart_key, $quantity)
    {
        // Calculate totals
        $item = $this->get_cart_item($cart_key);
        $item_price = $item ? $this->get_item_price($item) : 0;
        $item_total = $item_price * $quantity;
        $cart_total = $this->get_cart_total_with_discount();
        $cart_count = $this->get_cart_count();

        // Format prices
        $settings = VRSTORE_Settings::get_instance();
        $currency = $settings->get_setting("currency", "USD");
        $product_instance = VRSTORE_Product::get_instance();

        $item_total_formatted = $product_instance->format_price(
            $item_total,
            $currency,
        );
        $cart_total_formatted = $product_instance->format_price(
            $cart_total,
            $currency,
        );

        return [
            "item_total" => $item_total_formatted,
            "cart_total" => $cart_total_formatted,
            "cart_count" => $cart_count,
        ];
    }

    /**
     * AJAX bulk remove items handler.
     *
     * @since 1.0.0
     * @return void
     */
    public function ajax_bulk_remove_items()
    {
        // Check nonce
        if (!wp_verify_nonce($_POST["nonce"], "vrstore_frontend_nonce")) {
            wp_send_json_error([
                "message" => esc_html__("Security check failed.", "vira-store"),
            ]);
        }

        $cart_keys = isset($_POST["cart_keys"])
            ? array_map("sanitize_text_field", $_POST["cart_keys"])
            : [];

        if (empty($cart_keys)) {
            wp_send_json_error([
                "message" => esc_html__("No items selected.", "vira-store"),
            ]);
        }

        $removed_count = 0;

        // Remove each selected item
        foreach ($cart_keys as $cart_key) {
            if (isset($_SESSION["vrstore_cart"][$cart_key])) {
                unset($_SESSION["vrstore_cart"][$cart_key]);
                $removed_count++;
            }
        }

        // Calculate new totals
        $cart_total = $this->get_cart_total_with_discount();
        $cart_count = $this->get_cart_count();

        // Format price
        $settings = VRSTORE_Settings::get_instance();
        $currency = $settings->get_setting("currency", "USD");
        $product_instance = VRSTORE_Product::get_instance();
        $cart_total_formatted = $product_instance->format_price(
            $cart_total,
            $currency,
        );

        wp_send_json_success([
            "message" => sprintf(
                esc_html__("%d items removed from cart.", "vira-store"),
                $removed_count,
            ),
            "cart_total" => $cart_total_formatted,
            "cart_count" => $cart_count,
            "removed_count" => $removed_count,
        ]);
    }

    /**
     * AJAX bulk save for later handler.
     *
     * @since 1.0.0
     * @return void
     */
    public function ajax_bulk_save_later()
    {
        // Check nonce
        if (!wp_verify_nonce($_POST["nonce"], "vrstore_frontend_nonce")) {
            wp_send_json_error([
                "message" => esc_html__("Security check failed.", "vira-store"),
            ]);
        }

        $cart_keys = isset($_POST["cart_keys"])
            ? array_map("sanitize_text_field", $_POST["cart_keys"])
            : [];

        if (empty($cart_keys)) {
            wp_send_json_error([
                "message" => esc_html__("No items selected.", "vira-store"),
            ]);
        }

        $saved_count = 0;

        // Initialize saved items session if not exists
        if (!isset($_SESSION["vrstore_saved_items"])) {
            $_SESSION["vrstore_saved_items"] = [];
        }

        // Move each selected item to saved items
        foreach ($cart_keys as $cart_key) {
            if (isset($_SESSION["vrstore_cart"][$cart_key])) {
                // Move to saved items with timestamp
                $_SESSION["vrstore_saved_items"][$cart_key] =
                    $_SESSION["vrstore_cart"][$cart_key];
                $_SESSION["vrstore_saved_items"][$cart_key][
                    "saved_at"
                ] = current_time("timestamp");

                // Remove from cart
                unset($_SESSION["vrstore_cart"][$cart_key]);
                $saved_count++;
            }
        }

        // Calculate new totals
        $cart_total = $this->get_cart_total_with_discount();
        $cart_count = $this->get_cart_count();

        // Format price
        $settings = VRSTORE_Settings::get_instance();
        $currency = $settings->get_setting("currency", "USD");
        $product_instance = VRSTORE_Product::get_instance();
        $cart_total_formatted = $product_instance->format_price(
            $cart_total,
            $currency,
        );

        wp_send_json_success([
            "message" => sprintf(
                esc_html__("%d items saved for later.", "vira-store"),
                $saved_count,
            ),
            "cart_total" => $cart_total_formatted,
            "cart_count" => $cart_count,
            "saved_count" => $saved_count,
        ]);
    }

    /**
     * AJAX update cart quantity handler.
     *
     * @since 1.0.0
     * @return void
     */
    public function ajax_update_cart_quantity()
    {
        // Check nonce
        if (!wp_verify_nonce($_POST["nonce"], "vrstore_frontend_nonce")) {
            wp_send_json_error([
                "message" => esc_html__("Security check failed.", "vira-store"),
            ]);
        }

        $cart_key = sanitize_text_field($_POST["cart_key"] ?? "");
        $quantity = absint($_POST["quantity"] ?? 1);

        if (empty($cart_key)) {
            wp_send_json_error([
                "message" => esc_html__("Invalid cart item.", "vira-store"),
            ]);
        }

        // Validate quantity
        if ($quantity < 1) {
            wp_send_json_error([
                "message" => esc_html__(
                    "Quantity must be at least 1.",
                    "vira-store",
                ),
            ]);
        }

        // Update cart item quantity
        if (isset($_SESSION["vrstore_cart"][$cart_key])) {
            $_SESSION["vrstore_cart"][$cart_key]["quantity"] = $quantity;

            // Calculate item subtotal
            $item = $_SESSION["vrstore_cart"][$cart_key];
            $item_price = $this->get_item_price($item);
            $item_subtotal = $item_price * $quantity;

            // Calculate new totals
            $cart_total = $this->get_cart_total_with_discount();
            $cart_count = $this->get_cart_count();

            // Format prices
            $settings = VRSTORE_Settings::get_instance();
            $currency = $settings->get_setting("currency", "USD");
            $product_instance = VRSTORE_Product::get_instance();

            $item_subtotal_formatted = $product_instance->format_price(
                $item_subtotal,
                $currency,
            );
            $cart_total_formatted = $product_instance->format_price(
                $cart_total,
                $currency,
            );

            wp_send_json_success([
                "message" => esc_html__(
                    "Quantity updated successfully.",
                    "vira-store",
                ),
                "item_subtotal" => $item_subtotal_formatted,
                "cart_total" => $cart_total_formatted,
                "cart_count" => $cart_count,
            ]);
        } else {
            wp_send_json_error([
                "message" => esc_html__("Cart item not found.", "vira-store"),
            ]);
        }
    }

    /**
     * AJAX user registration handler for checkout.
     *
     * @since 1.0.0
     * @return void
     */
    public function ajax_register_user()
    {
        // Check if registration is enabled
        if (!get_option("users_can_register")) {
            wp_send_json_error([
                "message" => esc_html__(
                    "User registration is currently not allowed.",
                    "vira-store",
                ),
            ]);
        }

        // Verify nonce
        if (
            !wp_verify_nonce(
                $_POST["vrstore_register_nonce"],
                "vrstore_register",
            )
        ) {
            wp_send_json_error([
                "message" => esc_html__("Security check failed.", "vira-store"),
            ]);
        }

        // Get form data
        $username = sanitize_text_field($_POST["vrstore_reg_username"] ?? "");
        $email = sanitize_email($_POST["vrstore_reg_email"] ?? "");
        $password = $_POST["vrstore_reg_password"] ?? "";

        // Validate inputs
        if (empty($username) || empty($email) || empty($password)) {
            wp_send_json_error([
                "message" => esc_html__(
                    "Please fill in all required fields.",
                    "vira-store",
                ),
            ]);
        }

        if (!is_email($email)) {
            wp_send_json_error([
                "message" => esc_html__(
                    "Please enter a valid email address.",
                    "vira-store",
                ),
            ]);
        }

        if (strlen($password) < 6) {
            wp_send_json_error([
                "message" => esc_html__(
                    "Password must be at least 6 characters long.",
                    "vira-store",
                ),
            ]);
        }

        // Check if username already exists
        if (username_exists($username)) {
            wp_send_json_error([
                "message" => esc_html__(
                    "Username already exists. Please choose a different username.",
                    "vira-store",
                ),
            ]);
        }

        // Check if email already exists
        if (email_exists($email)) {
            wp_send_json_error([
                "message" => esc_html__(
                    "Email address already exists. Please use a different email or login to your existing account.",
                    "vira-store",
                ),
            ]);
        }

        // Create user
        $user_id = wp_create_user($username, $password, $email);

        if (is_wp_error($user_id)) {
            wp_send_json_error([
                "message" => $user_id->get_error_message(),
            ]);
        }

        // Set user role to customer
        $user = new WP_User($user_id);
        $user->set_role("customer");

        // Log the user in
        wp_set_current_user($user_id);
        wp_set_auth_cookie($user_id, true);

        // Send success response
        wp_send_json_success([
            "message" => esc_html__(
                "Account created successfully! You are now logged in.",
                "vira-store",
            ),
            "user_id" => $user_id,
            "username" => $username,
            "redirect" => "reload_checkout", // Special flag to reload checkout form
        ]);
    }

    /**
     * Get cart data from cookie
     *
     * @since 1.0.0
     * @return array
     */
    private function get_cart_from_cookie()
    {
        if (!isset($_COOKIE["vrstore_cart_items"])) {
            return [];
        }

        $cart_data = json_decode(
            stripslashes($_COOKIE["vrstore_cart_items"]),
            true,
        );
        return is_array($cart_data) ? $cart_data : [];
    }

    /**
     * Set cart data in cookie
     *
     * @since 1.0.0
     * @param array $cart_data Cart data
     * @return void
     */
    private function set_cart_cookie($cart_data)
    {
        if (!headers_sent()) {
            $cart_json = json_encode($cart_data);
            $expire = time() + 7 * 24 * 60 * 60; // 7 days
            setcookie(
                "vrstore_cart_items",
                $cart_json,
                $expire,
                "/",
                "",
                is_ssl(),
                true,
            );
        }
    }

    /**
     * Get applied coupon from cookie
     *
     * @since 1.0.0
     * @return array|null
     */
    private function get_coupon_from_cookie()
    {
        if (!isset($_COOKIE["vrstore_applied_coupon"])) {
            return null;
        }

        $coupon_data = json_decode(
            stripslashes($_COOKIE["vrstore_applied_coupon"]),
            true,
        );
        return is_array($coupon_data) ? $coupon_data : null;
    }

    /**
     * Set applied coupon in cookie
     *
     * @since 1.0.0
     * @param array|null $coupon_data Coupon data
     * @return void
     */
    private function set_coupon_cookie($coupon_data)
    {
        if (!headers_sent()) {
            if ($coupon_data === null) {
                // Remove cookie
                setcookie(
                    "vrstore_applied_coupon",
                    "",
                    time() - 3600,
                    "/",
                    "",
                    is_ssl(),
                    true,
                );
            } else {
                $coupon_json = json_encode($coupon_data);
                $expire = time() + 24 * 60 * 60; // 24 hours
                setcookie(
                    "vrstore_applied_coupon",
                    $coupon_json,
                    $expire,
                    "/",
                    "",
                    is_ssl(),
                    true,
                );
            }
        }
    }

    /**
     * Clear cart cookies
     *
     * @since 1.0.0
     * @return void
     */
    private function clear_cart_cookies()
    {
        if (!headers_sent()) {
            setcookie(
                "vrstore_cart_items",
                "",
                time() - 3600,
                "/",
                "",
                is_ssl(),
                true,
            );
            setcookie(
                "vrstore_applied_coupon",
                "",
                time() - 3600,
                "/",
                "",
                is_ssl(),
                true,
            );
        }
    }

    /**
     * Log cart debug information for troubleshooting performance issues
     *
     * @param string $message Debug message
     * @param array $data Additional data to log
     * @return void
     */
    private function log_cart_debug($message, $data = [])
    {
        // Only log if WP_DEBUG is enabled
        if (!defined("WP_DEBUG") || !WP_DEBUG) {
            return;
        }

        $log_data = [
            "timestamp" => current_time("mysql"),
            "message" => $message,
            "session_id" => session_id(),
            "user_id" => get_current_user_id(),
            "request_uri" => $_SERVER["REQUEST_URI"] ?? "",
            "user_agent" => substr($_SERVER["HTTP_USER_AGENT"] ?? "", 0, 100),
        ];

        if (!empty($data)) {
            $log_data = array_merge($log_data, $data);
        }

        // Debug logging removed for production
    }
}
