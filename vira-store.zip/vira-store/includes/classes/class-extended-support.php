<?php
/**
 * Extended Support Handler
 * 
 * Handles Extended Support purchases that extend the support period for existing licenses
 * 
 * @package Vira_Store
 * @since 1.0.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Extended Support class
 */
class VRSTORE_Extended_Support {
    /**
     * Singleton instance
     *
     * @var VRSTORE_Extended_Support|null
     */
    private static ?VRSTORE_Extended_Support $instance = null;

    /**
     * Get singleton instance
     *
     * @return VRSTORE_Extended_Support
     */
    public static function get_instance(): VRSTORE_Extended_Support {
        if (null === self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        // Hook into order completion to handle Extended Support purchases
        add_action('vrstore_order_completed', [$this, 'handle_extended_support_purchase'], 5, 2);
        
        // Add admin menu for Extended Support management
        add_action('admin_menu', [$this, 'add_admin_menu'], 20);
        
        // Add AJAX handlers
        add_action('wp_ajax_vrstore_extend_license_support', [$this, 'ajax_extend_license_support']);
    }

    /**
     * Handle Extended Support purchase on order completion
     *
     * @param int $order_id Order ID
     * @param array $order_data Order data
     * @return void
     */
    public function handle_extended_support_purchase(int $order_id, array $order_data): void {
        // Check if this is an Extended Support purchase
        if (empty($order_data['item_type']) || $order_data['item_type'] !== 'extended_support') {
            return;
        }

        // Validate required data
        if (empty($order_data['license_key']) || empty($order_data['extension_months'])) {
            error_log('ViraStore Extended Support: Missing required data (license_key or extension_months)');
            return;
        }

        $license_key = sanitize_text_field($order_data['license_key']);
        $extension_months = absint($order_data['extension_months']);
        $customer_email = sanitize_email($order_data['customer_email'] ?? '');

        // Extend the license support period
        $result = $this->extend_license_support($license_key, $extension_months, $order_id, $customer_email);

        if (is_wp_error($result)) {
            error_log('ViraStore Extended Support: Failed to extend license - ' . $result->get_error_message());
            
            // Optionally notify admin
            $this->notify_admin_of_failure($order_id, $license_key, $result->get_error_message());
        } else {
            // Log success
            error_log(sprintf(
                'ViraStore Extended Support: Successfully extended license %s by %d months (Order #%d)',
                $license_key,
                $extension_months,
                $order_id
            ));
            
            // Fire action for other plugins to hook into
            do_action('vrstore_license_support_extended', $result['license_id'], $extension_months, $order_id);
        }
    }

    /**
     * Extend license support period
     *
     * @param string $license_key License key to extend
     * @param int $extension_months Number of months to extend
     * @param int $order_id Optional order ID for tracking
     * @param string $customer_email Optional customer email for validation
     * @return array|WP_Error Array with license_id and new_expiry_date on success, WP_Error on failure
     */
    public function extend_license_support(string $license_key, int $extension_months, int $order_id = 0, string $customer_email = '') {
        global $wpdb;
        $licenses_table = $wpdb->prefix . 'vrstore_licenses';

        // Standardize license key
        $license_key = VRSTORE_License::standardize_license_key($license_key);

        // Validate inputs
        if (empty($license_key)) {
            return new WP_Error('invalid_license_key', __('Invalid license key provided.', 'vira-store'));
        }

        if ($extension_months <= 0) {
            return new WP_Error('invalid_extension', __('Extension period must be greater than 0 months.', 'vira-store'));
        }

        // Check if table exists
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$licenses_table'") === $licenses_table;
        if (!$table_exists) {
            return new WP_Error('table_not_found', __('License system not properly initialized.', 'vira-store'));
        }

        // Get the license
        $license = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $licenses_table WHERE license_key = %s",
            $license_key
        ));

        if (!$license) {
            return new WP_Error('license_not_found', __('License key not found.', 'vira-store'));
        }

        // Validate customer email if provided
        if (!empty($customer_email) && $license->customer_email !== $customer_email) {
            return new WP_Error('email_mismatch', __('License key does not belong to this customer.', 'vira-store'));
        }

        // Calculate new expiry date
        $current_expiry = $license->expires_at;
        $new_expiry = $this->calculate_new_expiry_date($current_expiry, $extension_months);

        // Update the license
        $result = $wpdb->update(
            $licenses_table,
            [
                'expires_at' => $new_expiry,
                'updated_at' => current_time('mysql')
            ],
            ['id' => $license->id],
            ['%s', '%s'],
            ['%d']
        );

        if ($result === false) {
            return new WP_Error('update_failed', __('Failed to update license expiry date.', 'vira-store'));
        }

        // Log the extension in order meta if order_id is provided
        if ($order_id > 0) {
            add_post_meta($order_id, '_vrstore_extended_license_id', $license->id);
            add_post_meta($order_id, '_vrstore_extended_license_key', $license_key);
            add_post_meta($order_id, '_vrstore_extension_months', $extension_months);
            add_post_meta($order_id, '_vrstore_previous_expiry', $current_expiry);
            add_post_meta($order_id, '_vrstore_new_expiry', $new_expiry);
        }

        return [
            'license_id' => $license->id,
            'license_key' => $license_key,
            'previous_expiry' => $current_expiry,
            'new_expiry' => $new_expiry,
            'extension_months' => $extension_months
        ];
    }

    /**
     * Calculate new expiry date based on current expiry and extension period
     *
     * @param string|null $current_expiry Current expiry date (MySQL format) or null
     * @param int $extension_months Number of months to extend
     * @return string New expiry date in MySQL format
     */
    private function calculate_new_expiry_date(?string $current_expiry, int $extension_months): string {
        // If no current expiry or expired, start from now
        if (empty($current_expiry) || $current_expiry === '0000-00-00' || $current_expiry === '0000-00-00 00:00:00') {
            $base_date = current_time('timestamp');
        } else {
            $expiry_timestamp = strtotime($current_expiry);
            
            // If already expired, start from now
            if ($expiry_timestamp < time()) {
                $base_date = current_time('timestamp');
            } else {
                // If still valid, extend from current expiry
                $base_date = $expiry_timestamp;
            }
        }

        // Add extension months
        $extension_days = $extension_months * 30; // Approximate (30 days per month)
        $new_expiry_timestamp = $base_date + ($extension_days * DAY_IN_SECONDS);

        return date('Y-m-d H:i:s', $new_expiry_timestamp);
    }

    /**
     * Get Extended Support history for a license
     *
     * @param string $license_key License key
     * @return array Array of extension records
     */
    public function get_license_extension_history(string $license_key): array {
        global $wpdb;

        $license_key = VRSTORE_License::standardize_license_key($license_key);

        // Get all orders that extended this license
        $orders = $wpdb->get_results($wpdb->prepare(
            "SELECT post_id as order_id, meta_value as extension_months
            FROM {$wpdb->postmeta}
            WHERE meta_key = '_vrstore_extended_license_key'
            AND meta_value = %s
            ORDER BY post_id DESC",
            $license_key
        ));

        $history = [];

        foreach ($orders as $order) {
            $order_id = $order->order_id;
            
            $history[] = [
                'order_id' => $order_id,
                'extension_months' => get_post_meta($order_id, '_vrstore_extension_months', true),
                'previous_expiry' => get_post_meta($order_id, '_vrstore_previous_expiry', true),
                'new_expiry' => get_post_meta($order_id, '_vrstore_new_expiry', true),
                'extended_at' => get_post_meta($order_id, '_vrstore_order_date', true),
            ];
        }

        return $history;
    }

    /**
     * Add admin menu for Extended Support management
     */
    public function add_admin_menu(): void {
        add_submenu_page(
            'vrstore-dashboard',
            __('Extended Support', 'vira-store'),
            __('Extended Support', 'vira-store'),
            'manage_options',
            'vrstore-extended-support',
            [$this, 'render_admin_page']
        );
    }

    /**
     * Render admin page for Extended Support management
     */
    public function render_admin_page(): void {
        ?>
        <div class="wrap">
            <h1><?php _e('Extended Support Management', 'vira-store'); ?></h1>

            <div class="card" style="max-width: 800px;">
                <h2><?php _e('Extend License Support', 'vira-store'); ?></h2>
                <p><?php _e('Manually extend the support period for a license.', 'vira-store'); ?></p>

                <form id="vrstore-extend-support-form">
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="license_key"><?php _e('License Key', 'vira-store'); ?></label>
                            </th>
                            <td>
                                <input 
                                    type="text" 
                                    id="license_key" 
                                    name="license_key" 
                                    class="regular-text" 
                                    required
                                    placeholder="XXXXX-XXXXX-XXXXX-XXXXX-XXXXX"
                                    style="text-transform: uppercase;"
                                />
                                <p class="description">
                                    <?php _e('Enter the license key to extend support for.', 'vira-store'); ?>
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="extension_months"><?php _e('Extension Period (Months)', 'vira-store'); ?></label>
                            </th>
                            <td>
                                <input 
                                    type="number" 
                                    id="extension_months" 
                                    name="extension_months" 
                                    class="small-text" 
                                    min="1" 
                                    max="120" 
                                    value="12"
                                    required
                                />
                                <p class="description">
                                    <?php _e('Number of months to extend the support period.', 'vira-store'); ?>
                                </p>
                            </td>
                        </tr>
                    </table>

                    <p class="submit">
                        <button type="submit" class="button button-primary">
                            <?php _e('Extend Support', 'vira-store'); ?>
                        </button>
                    </p>
                </form>

                <div id="vrstore-extend-support-message"></div>
            </div>

            <div class="card" style="max-width: 800px; margin-top: 20px;">
                <h2><?php _e('How Extended Support Works', 'vira-store'); ?></h2>
                <ul>
                    <li><?php _e('Extended Support extends the support expiry date for existing licenses', 'vira-store'); ?></li>
                    <li><?php _e('No new license key is generated - the existing license is extended', 'vira-store'); ?></li>
                    <li><?php _e('If the license is already expired, the extension starts from today', 'vira-store'); ?></li>
                    <li><?php _e('If the license is still valid, the extension is added to the current expiry date', 'vira-store'); ?></li>
                    <li><?php _e('All extension history is tracked and can be viewed in the license details', 'vira-store'); ?></li>
                </ul>
            </div>
        </div>

        <script>
        jQuery(document).ready(function($) {
            $('#vrstore-extend-support-form').on('submit', function(e) {
                e.preventDefault();

                var $form = $(this);
                var $button = $form.find('button[type="submit"]');
                var $message = $('#vrstore-extend-support-message');
                
                var licenseKey = $('#license_key').val().trim().toUpperCase();
                var extensionMonths = parseInt($('#extension_months').val());

                if (!licenseKey || extensionMonths <= 0) {
                    showMessage('error', '<?php _e('Please fill in all required fields.', 'vira-store'); ?>');
                    return;
                }

                $button.prop('disabled', true).text('<?php _e('Extending...', 'vira-store'); ?>');
                showMessage('info', '<?php _e('Processing extension...', 'vira-store'); ?>');

                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'vrstore_extend_license_support',
                        nonce: '<?php echo wp_create_nonce('vrstore_extend_support'); ?>',
                        license_key: licenseKey,
                        extension_months: extensionMonths
                    },
                    success: function(response) {
                        if (response.success) {
                            showMessage('success', response.data.message);
                            $form[0].reset();
                        } else {
                            showMessage('error', response.data.message || '<?php _e('Extension failed.', 'vira-store'); ?>');
                        }
                    },
                    error: function() {
                        showMessage('error', '<?php _e('Connection error. Please try again.', 'vira-store'); ?>');
                    },
                    complete: function() {
                        $button.prop('disabled', false).text('<?php _e('Extend Support', 'vira-store'); ?>');
                    }
                });

                function showMessage(type, message) {
                    var className = 'notice notice-' + type;
                    $message.html('<div class="' + className + ' inline"><p>' + message + '</p></div>');
                }
            });

            // Auto-format license key
            $('#license_key').on('input', function() {
                var value = $(this).val().toUpperCase().replace(/[^A-Z0-9-]/g, '');
                $(this).val(value);
            });
        });
        </script>
        <?php
    }

    /**
     * AJAX handler for extending license support
     */
    public function ajax_extend_license_support(): void {
        check_ajax_referer('vrstore_extend_support', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'vira-store')]);
        }

        $license_key = sanitize_text_field($_POST['license_key'] ?? '');
        $extension_months = absint($_POST['extension_months'] ?? 0);

        if (empty($license_key) || $extension_months <= 0) {
            wp_send_json_error(['message' => __('Invalid input data.', 'vira-store')]);
        }

        $result = $this->extend_license_support($license_key, $extension_months);

        if (is_wp_error($result)) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        }

        wp_send_json_success([
            'message' => sprintf(
                __('License support extended successfully by %d months. New expiry: %s', 'vira-store'),
                $extension_months,
                date_i18n(get_option('date_format'), strtotime($result['new_expiry']))
            ),
            'data' => $result
        ]);
    }

    /**
     * Notify admin of extension failure
     *
     * @param int $order_id Order ID
     * @param string $license_key License key
     * @param string $error_message Error message
     */
    private function notify_admin_of_failure(int $order_id, string $license_key, string $error_message): void {
        $admin_email = get_option('admin_email');
        $subject = sprintf(__('[%s] Extended Support Extension Failed', 'vira-store'), get_bloginfo('name'));
        
        $message = sprintf(
            __("An Extended Support purchase failed to extend the license:\n\nOrder ID: %d\nLicense Key: %s\nError: %s\n\nPlease review this order and extend the license manually if needed.", 'vira-store'),
            $order_id,
            $license_key,
            $error_message
        );

        wp_mail($admin_email, $subject, $message);
    }
}

// Initialize the Extended Support handler
VRSTORE_Extended_Support::get_instance();
