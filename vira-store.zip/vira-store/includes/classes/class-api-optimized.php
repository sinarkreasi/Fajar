<?php
/**
 * Optimized API Class for Vira Store
 * 
 * This class implements optimized API endpoints with:
 * - Multi-layer caching (Object Cache → Transients → Database)
 * - Rate limiting (per IP and per API key)
 * - Request deduplication
 * - Static JSON fallback for updates
 * - Optimized database queries
 * - Security improvements (nonce validation, request signing)
 *
 * @package Vira_Store
 * @since 2.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * VRSTORE_API_Optimized Class
 *
 * Optimized REST API endpoints with caching, rate limiting, and performance improvements.
 *
 * @since 2.0.0
 */
class VRSTORE_API_Optimized {

    /**
     * Instance of this class.
     *
     * @since 2.0.0
     * @var VRSTORE_API_Optimized|null
     */
    private static ?VRSTORE_API_Optimized $instance = null;

    /**
     * API namespace
     *
     * @since 2.0.0
     * @var string
     */
    private $namespace = 'vrstore/v1';

    /**
     * Cache group
     *
     * @since 2.0.0
     * @var string
     */
    private $cache_group = 'vrstore_api';

    /**
     * Rate limit settings
     *
     * @since 2.0.0
     * @var array
     */
    private $rate_limits = [
        'validate' => ['requests' => 100, 'period' => HOUR_IN_SECONDS],
        'activate' => ['requests' => 20, 'period' => HOUR_IN_SECONDS],
        'deactivate' => ['requests' => 20, 'period' => HOUR_IN_SECONDS],
        'update_check' => ['requests' => 60, 'period' => HOUR_IN_SECONDS],
        'domain_monitor' => ['requests' => 30, 'period' => HOUR_IN_SECONDS],
    ];

    /**
     * Cache TTL settings (in seconds)
     *
     * @since 2.0.0
     * @var array
     */
    private $cache_ttl = [
        'license_validation' => 300,      // 5 minutes
        'api_key_validation' => 900,       // 15 minutes
        'update_check' => 900,             // 15 minutes
        'product_data' => 3600,            // 1 hour
        'version_metadata' => 1800,        // 30 minutes
    ];

    /**
     * Constructor.
     *
     * @since 2.0.0
     */
    private function __construct() {
        // Initialize REST API routes
        add_action( 'rest_api_init', array( $this, 'register_routes' ) );
        
        // Add CORS headers
        add_action( 'rest_api_init', array( $this, 'add_cors_headers' ), 15 );
        
        // Add response caching headers
        add_filter( 'rest_pre_serve_request', array( $this, 'add_cache_headers' ), 10, 4 );
    }

    /**
     * Get instance of this class.
     *
     * @since 2.0.0
     * @return VRSTORE_API_Optimized
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Add CORS headers
     *
     * @since 2.0.0
     */
    public function add_cors_headers() {
        header( 'Access-Control-Allow-Origin: *' );
        header( 'Access-Control-Allow-Methods: GET, POST, OPTIONS' );
        header( 'Access-Control-Allow-Headers: Content-Type, X-VRSTORE-API-KEY, X-VRSTORE-NONCE' );
    }

    /**
     * Add cache headers to responses
     *
     * @since 2.0.0
     * @param bool $served Whether the request was served.
     * @param WP_REST_Response $result Result to send to the client.
     * @param WP_REST_Request $request Request used to generate the response.
     * @param WP_REST_Server $server Server instance.
     * @return bool
     */
    public function add_cache_headers( $served, $result, $request, $server ) {
        if ( ! $served ) {
            return $served;
        }

        $route = $request->get_route();
        
        // Add cache headers based on endpoint
        if ( strpos( $route, '/licenses/validate' ) !== false ) {
            header( 'Cache-Control: private, max-age=300' );
            header( 'X-Cache-TTL: 300' );
        } elseif ( strpos( $route, '/updates/plugin' ) !== false ) {
            header( 'Cache-Control: public, max-age=900' );
            header( 'X-Cache-TTL: 900' );
        }

        return $served;
    }

    /**
     * Register REST API routes
     *
     * @since 2.0.0
     * @return void
     */
    public function register_routes() {
        // License validation endpoint
        register_rest_route(
            $this->namespace,
            '/license/validate',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'validate_license_optimized' ),
                'permission_callback' => array( $this, 'validate_license_permissions_check_optimized' ),
                'args'                => array(
                    'license_key' => array(
                        'required'          => true,
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'product_id'  => array(
                        'required'          => true,
                        'validate_callback' => function( $param ) {
                            return is_numeric( $param );
                        },
                        'sanitize_callback' => 'absint',
                    ),
                    'nonce' => array(
                        'required'          => false,
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                ),
            )
        );

        // License activation endpoint
        register_rest_route(
            $this->namespace,
            '/license/activate',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'activate_license_optimized' ),
                'permission_callback' => array( $this, 'license_action_permissions_check_optimized' ),
                'args'                => array(
                    'license_key' => array(
                        'required'          => true,
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'product_id'  => array(
                        'required'          => true,
                        'validate_callback' => function( $param ) {
                            return is_numeric( $param );
                        },
                        'sanitize_callback' => 'absint',
                    ),
                    'site_url'    => array(
                        'required'          => true,
                        'sanitize_callback' => 'esc_url_raw',
                    ),
                    'nonce' => array(
                        'required'          => true,
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                ),
            )
        );

        // License deactivation endpoint
        register_rest_route(
            $this->namespace,
            '/license/deactivate',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'deactivate_license_optimized' ),
                'permission_callback' => array( $this, 'license_action_permissions_check_optimized' ),
                'args'                => array(
                    'license_key' => array(
                        'required'          => true,
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'product_id'  => array(
                        'required'          => true,
                        'validate_callback' => function( $param ) {
                            return is_numeric( $param );
                        },
                        'sanitize_callback' => 'absint',
                    ),
                    'site_url'    => array(
                        'required'          => true,
                        'sanitize_callback' => 'esc_url_raw',
                    ),
                    'nonce' => array(
                        'required'          => true,
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                ),
            )
        );

        // Update check endpoint
        register_rest_route(
            $this->namespace,
            '/update/check',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'check_plugin_update_optimized' ),
                'permission_callback' => array( $this, 'plugin_update_permissions_check_optimized' ),
                'args'                => array(
                    'plugin_slug' => array(
                        'required'          => true,
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'version'     => array(
                        'required'          => true,
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'license_key' => array(
                        'required'          => true,
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'site_url'    => array(
                        'required'          => true,
                        'sanitize_callback' => 'esc_url_raw',
                    ),
                ),
            )
        );

        // Domain monitor endpoint
        register_rest_route(
            $this->namespace,
            '/domain/monitor',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'monitor_domain_optimized' ),
                'permission_callback' => array( $this, 'domain_monitor_permissions_check' ),
                'args'                => array(
                    'license_key' => array(
                        'required'          => true,
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'domain' => array(
                        'required'          => true,
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                ),
            )
        );

        // Static update metadata endpoint (no authentication required)
        register_rest_route(
            $this->namespace,
            '/updates/plugin/(?P<plugin_slug>[a-zA-Z0-9\-]+)/versions.json',
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_static_update_metadata' ),
                'permission_callback' => '__return_true',
            )
        );
    }

    /**
     * Check rate limit for IP address
     *
     * @since 2.0.0
     * @param string $endpoint Endpoint name
     * @param string $ip IP address
     * @return bool|WP_Error True if within limits, WP_Error if exceeded
     */
    private function check_rate_limit( $endpoint, $ip = null ) {
        if ( ! isset( $this->rate_limits[ $endpoint ] ) ) {
            return true;
        }

        if ( ! $ip ) {
            $ip = $this->get_client_ip();
        }

        $limit = $this->rate_limits[ $endpoint ];
        $cache_key = 'rate_limit_' . $endpoint . '_' . md5( $ip );
        
        // Get current count
        $count = wp_cache_get( $cache_key, $this->cache_group );
        if ( $count === false ) {
            $count = get_transient( $cache_key );
            if ( $count === false ) {
                $count = 0;
            }
        }

        // Check if limit exceeded
        if ( $count >= $limit['requests'] ) {
            $remaining = wp_cache_get( $cache_key . '_ttl', $this->cache_group );
            if ( $remaining === false ) {
                $remaining = get_transient( $cache_key . '_ttl' );
            }
            
            return new WP_Error(
                'rate_limit_exceeded',
                sprintf( 'Rate limit exceeded. Maximum %d requests per %d seconds.', $limit['requests'], $limit['period'] ),
                array(
                    'status' => 429,
                    'retry_after' => $remaining ?: $limit['period'],
                )
            );
        }

        // Increment count
        $count++;
        $ttl = $limit['period'];
        
        // Store in cache and transient
        wp_cache_set( $cache_key, $count, $this->cache_group, $ttl );
        wp_cache_set( $cache_key . '_ttl', $ttl, $this->cache_group, $ttl );
        set_transient( $cache_key, $count, $ttl );
        set_transient( $cache_key . '_ttl', $ttl, $ttl );

        return true;
    }

    /**
     * Get client IP address
     *
     * @since 2.0.0
     * @return string
     */
    private function get_client_ip() {
        $ip_keys = array(
            'HTTP_CF_CONNECTING_IP',
            'HTTP_X_REAL_IP',
            'HTTP_X_FORWARDED_FOR',
            'REMOTE_ADDR'
        );

        foreach ( $ip_keys as $key ) {
            if ( isset( $_SERVER[ $key ] ) && ! empty( $_SERVER[ $key ] ) ) {
                $ip = sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) );
                // Handle comma-separated IPs
                if ( strpos( $ip, ',' ) !== false ) {
                    $ips = explode( ',', $ip );
                    $ip = trim( $ips[0] );
                }
                if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
                    return $ip;
                }
            }
        }

        return '0.0.0.0';
    }

    /**
     * Get cached data with fallback
     *
     * @since 2.0.0
     * @param string $key Cache key
     * @param string $group Cache group
     * @return mixed|false Cached data or false
     */
    private function get_cached( $key, $group = '' ) {
        if ( empty( $group ) ) {
            $group = $this->cache_group;
        }

        // Try object cache first
        $data = wp_cache_get( $key, $group );
        if ( $data !== false ) {
            return $data;
        }

        // Fallback to transient
        $data = get_transient( $key );
        if ( $data !== false ) {
            // Store in object cache for next time
            wp_cache_set( $key, $data, $group, $this->cache_ttl['license_validation'] );
            return $data;
        }

        return false;
    }

    /**
     * Set cached data
     *
     * @since 2.0.0
     * @param string $key Cache key
     * @param mixed $data Data to cache
     * @param int $ttl Time to live in seconds
     * @param string $group Cache group
     * @return bool
     */
    private function set_cached( $key, $data, $ttl = null, $group = '' ) {
        if ( empty( $group ) ) {
            $group = $this->cache_group;
        }

        if ( $ttl === null ) {
            $ttl = $this->cache_ttl['license_validation'];
        }

        // Store in both object cache and transient
        wp_cache_set( $key, $data, $group, $ttl );
        return set_transient( $key, $data, $ttl );
    }

    /**
     * Validate license permissions check (optimized)
     *
     * @since 2.0.0
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|bool
     */
    public function validate_license_permissions_check_optimized( $request ) {
        // Check rate limit
        $rate_check = $this->check_rate_limit( 'validate' );
        if ( is_wp_error( $rate_check ) ) {
            return $rate_check;
        }

        // Enhanced API key validation with caching
        $api_key = $request->get_header( 'X-VRSTORE-API-KEY' );
        if ( ! $api_key ) {
            return new WP_Error(
                'rest_forbidden',
                esc_html__( 'API key is required.', 'vira-store' ),
                array( 'status' => 403 )
            );
        }

        // Check cache first
        $cache_key = 'api_key_' . md5( $api_key );
        $key_record = $this->get_cached( $cache_key );

        if ( $key_record === false ) {
            // Cache miss - query database
            global $wpdb;
            $api_keys_table = $wpdb->prefix . 'vrstore_api_keys';
            
            // Check if table exists
            if ( $wpdb->get_var( "SHOW TABLES LIKE '$api_keys_table'" ) !== $api_keys_table ) {
                return new WP_Error(
                    'rest_forbidden',
                    esc_html__( 'API system not properly configured.', 'vira-store' ),
                    array( 'status' => 503 )
                );
            }
            
            // Look up API key in database
            $key_record = $wpdb->get_row( $wpdb->prepare(
                "SELECT * FROM $api_keys_table WHERE api_key = %s AND status = %s",
                $api_key,
                'active'
            ), ARRAY_A );
            
            if ( ! $key_record ) {
                return new WP_Error(
                    'rest_forbidden',
                    esc_html__( 'Invalid or inactive API key.', 'vira-store' ),
                    array( 'status' => 403 )
                );
            }
            
            // Check if API key has expired
            if ( ! empty( $key_record['expires_at'] ) && strtotime( $key_record['expires_at'] ) < time() ) {
                return new WP_Error(
                    'rest_forbidden',
                    esc_html__( 'API key has expired.', 'vira-store' ),
                    array( 'status' => 403 )
                );
            }
            
            // Cache the key record
            $this->set_cached( $cache_key, $key_record, $this->cache_ttl['api_key_validation'] );
        }

        // Update last used timestamp (async, don't block request)
        // Use a separate process or cron to batch update timestamps
        $this->schedule_api_key_timestamp_update( $key_record['id'] );

        // Store API key info for later use in the request
        $request->set_param( '_vrstore_api_key_id', $key_record['id'] );
        $request->set_param( '_vrstore_api_permissions', json_decode( $key_record['permissions'], true ) );

        return true;
    }

    /**
     * Schedule API key timestamp update (non-blocking)
     *
     * @since 2.0.0
     * @param int $key_id API key ID
     * @return void
     */
    private function schedule_api_key_timestamp_update( $key_id ) {
        // Use WordPress cron to batch update timestamps
        // This prevents write operations on every read request
        $update_key = 'api_key_update_' . $key_id;
        
        // Only schedule if not already scheduled
        if ( ! wp_next_scheduled( 'vrstore_batch_update_api_keys' ) ) {
            wp_schedule_single_event( time() + 60, 'vrstore_batch_update_api_keys' );
        }
        
        // Store key IDs to update
        $keys_to_update = get_transient( 'vrstore_api_keys_to_update' );
        if ( ! is_array( $keys_to_update ) ) {
            $keys_to_update = array();
        }
        $keys_to_update[] = $key_id;
        set_transient( 'vrstore_api_keys_to_update', array_unique( $keys_to_update ), 300 );
    }

    /**
     * License action permissions check (optimized)
     *
     * @since 2.0.0
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|bool
     */
    public function license_action_permissions_check_optimized( $request ) {
        // Check rate limit
        $endpoint = strpos( $request->get_route(), 'activate' ) !== false ? 'activate' : 'deactivate';
        $rate_check = $this->check_rate_limit( $endpoint );
        if ( is_wp_error( $rate_check ) ) {
            return $rate_check;
        }

        // Validate nonce
        $nonce = $request->get_param( 'nonce' );
        if ( empty( $nonce ) ) {
            return new WP_Error(
                'rest_forbidden',
                esc_html__( 'Nonce is required for this action.', 'vira-store' ),
                array( 'status' => 403 )
            );
        }

        // Use same API key validation as validate endpoint
        return $this->validate_license_permissions_check_optimized( $request );
    }

    /**
     * Plugin update permissions check (optimized)
     *
     * @since 2.0.0
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|bool
     */
    public function plugin_update_permissions_check_optimized( $request ) {
        // Check rate limit
        $rate_check = $this->check_rate_limit( 'update_check' );
        if ( is_wp_error( $rate_check ) ) {
            return $rate_check;
        }

        // API key validation (optional for update checks - can use license key instead)
        $api_key = $request->get_header( 'X-VRSTORE-API-KEY' );
        if ( $api_key ) {
            return $this->validate_license_permissions_check_optimized( $request );
        }

        // Allow update checks without API key if license key is provided
        return true;
    }

    /**
     * Domain monitor permissions check
     *
     * @since 2.0.0
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|bool
     */
    public function domain_monitor_permissions_check( $request ) {
        // Check rate limit
        $rate_check = $this->check_rate_limit( 'domain_monitor' );
        if ( is_wp_error( $rate_check ) ) {
            return $rate_check;
        }

        // API key validation
        $api_key = $request->get_header( 'X-VRSTORE-API-KEY' );
        if ( $api_key ) {
            return $this->validate_license_permissions_check_optimized( $request );
        }

        return true;
    }

    /**
     * Validate license (optimized with caching)
     *
     * @since 2.0.0
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|WP_REST_Response
     */
    public function validate_license_optimized( $request ) {
        $license_key = sanitize_text_field( $request['license_key'] );
        $product_id  = absint( $request['product_id'] );

        // Check cache first
        $cache_key = 'license_validate_' . md5( $license_key . '_' . $product_id );
        $cached_result = $this->get_cached( $cache_key );
        
        if ( $cached_result !== false ) {
            $response = new WP_REST_Response( $cached_result );
            $response->header( 'X-Cache', 'HIT' );
            return $response;
        }

        // Cache miss - validate license
        $license_class = VRSTORE_License::get_instance();
        $validation = $license_class->validate_license( $license_key, $product_id );

        if ( is_wp_error( $validation ) ) {
            return new WP_Error(
                $validation->get_error_code(),
                $validation->get_error_message(),
                array( 'status' => 400 )
            );
        }

        // Prepare response
        $response_data = array(
            'success' => true,
            'data'    => $validation,
            'cached'  => false,
            'cache_expires_at' => date( 'c', time() + $this->cache_ttl['license_validation'] ),
        );

        // Cache the result
        $this->set_cached( $cache_key, $response_data, $this->cache_ttl['license_validation'] );

        $response = new WP_REST_Response( $response_data );
        $response->header( 'X-Cache', 'MISS' );
        return $response;
    }

    /**
     * Activate license (optimized)
     *
     * @since 2.0.0
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|WP_REST_Response
     */
    public function activate_license_optimized( $request ) {
        $license_key = sanitize_text_field( $request['license_key'] );
        $product_id  = absint( $request['product_id'] );
        $site_url    = esc_url_raw( $request['site_url'] );

        // Validate nonce
        $nonce = $request->get_param( 'nonce' );
        if ( ! wp_verify_nonce( $nonce, 'vrstore_license_action_' . md5( $license_key . $site_url ) ) ) {
            return new WP_Error(
                'invalid_nonce',
                esc_html__( 'Invalid security nonce.', 'vira-store' ),
                array( 'status' => 403 )
            );
        }

        // Get license class instance
        $license_class = VRSTORE_License::get_instance();

        // Activate license
        $activation = $license_class->activate_license( $license_key, $product_id, $site_url );

        if ( is_wp_error( $activation ) ) {
            return new WP_Error(
                $activation->get_error_code(),
                $activation->get_error_message(),
                array( 'status' => 400 )
            );
        }

        // Clear cache for this license
        $cache_key = 'license_validate_' . md5( $license_key . '_' . $product_id );
        wp_cache_delete( $cache_key, $this->cache_group );
        delete_transient( $cache_key );

        return new WP_REST_Response(
            array(
                'success' => true,
                'data'    => $activation,
            )
        );
    }

    /**
     * Deactivate license (optimized)
     *
     * @since 2.0.0
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|WP_REST_Response
     */
    public function deactivate_license_optimized( $request ) {
        $license_key = sanitize_text_field( $request['license_key'] );
        $product_id  = absint( $request['product_id'] );
        $site_url    = esc_url_raw( $request['site_url'] );

        // Validate nonce
        $nonce = $request->get_param( 'nonce' );
        if ( ! wp_verify_nonce( $nonce, 'vrstore_license_action_' . md5( $license_key . $site_url ) ) ) {
            return new WP_Error(
                'invalid_nonce',
                esc_html__( 'Invalid security nonce.', 'vira-store' ),
                array( 'status' => 403 )
            );
        }

        // Get license class instance
        $license_class = VRSTORE_License::get_instance();

        // Deactivate license
        $deactivation = $license_class->deactivate_license( $license_key, $product_id, $site_url );

        if ( is_wp_error( $deactivation ) ) {
            return new WP_Error(
                $deactivation->get_error_code(),
                $deactivation->get_error_message(),
                array( 'status' => 400 )
            );
        }

        // Clear cache for this license
        $cache_key = 'license_validate_' . md5( $license_key . '_' . $product_id );
        wp_cache_delete( $cache_key, $this->cache_group );
        delete_transient( $cache_key );

        return new WP_REST_Response(
            array(
                'success' => true,
                'data'    => $deactivation,
            )
        );
    }

    /**
     * Check plugin update (optimized with static JSON fallback)
     *
     * @since 2.0.0
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_REST_Response|WP_Error
     */
    public function check_plugin_update_optimized( $request ) {
        $plugin_slug = $request->get_param( 'plugin_slug' );
        $current_version = $request->get_param( 'version' );
        $license_key = $request->get_param( 'license_key' );
        $site_url = $request->get_param( 'site_url' );

        // Check cache first
        $cache_key = 'update_check_' . md5( $plugin_slug . '_' . $current_version . '_' . $license_key );
        $cached_result = $this->get_cached( $cache_key );
        
        if ( $cached_result !== false ) {
            $response = new WP_REST_Response( $cached_result );
            $response->header( 'X-Cache', 'HIT' );
            return $response;
        }

        // Try static JSON file first (fastest)
        $static_json_url = rest_url( $this->namespace . '/updates/plugin/' . $plugin_slug . '/versions.json' );
        $static_data = $this->get_static_update_data( $plugin_slug );
        
        if ( $static_data !== false ) {
            // Use static data if available
            $license_instance = VRSTORE_License::get_instance();
            $license_validation = $license_instance->validate_license_key( $license_key, $static_data['product_id'] );
            
            if ( ! $license_validation['valid'] ) {
                return new WP_Error(
                    'invalid_license',
                    esc_html__( 'Invalid or expired license.', 'vira-store' ),
                    array( 'status' => 403 )
                );
            }

            $license_tier = $license_validation['license_tier'] ?? 'basic';
            $latest_version = $static_data['versions'][ $license_tier ] ?? $static_data['versions']['basic'] ?? null;

            if ( ! $latest_version ) {
                return new WP_REST_Response( array(
                    'update_available' => false,
                    'message' => esc_html__( 'No updates available for your license tier.', 'vira-store' )
                ), 200 );
            }

            $update_available = version_compare( $latest_version['version'], $current_version, '>' );

            if ( ! $update_available ) {
                $response_data = array(
                    'update_available' => false,
                    'current_version' => $current_version,
                    'latest_version' => $latest_version['version'],
                    'message' => esc_html__( 'You have the latest version.', 'vira-store' ),
                    'cached' => false,
                );
                
                $this->set_cached( $cache_key, $response_data, $this->cache_ttl['update_check'] );
                
                $response = new WP_REST_Response( $response_data );
                $response->header( 'X-Cache', 'MISS' );
                return $response;
            }

            // Generate download token
            $token = wp_generate_password( 32, false );
            $expires_at = date( 'Y-m-d H:i:s', strtotime( '+1 hour' ) );

            global $wpdb;
            $wpdb->insert(
                $wpdb->prefix . 'vrstore_update_tokens',
                array(
                    'token' => $token,
                    'license_key' => $license_key,
                    'product_id' => $static_data['product_id'],
                    'version_id' => $latest_version['id'],
                    'site_url' => $site_url,
                    'expires_at' => $expires_at,
                    'created_at' => current_time( 'mysql' )
                ),
                array( '%s', '%s', '%d', '%d', '%s', '%s', '%s' )
            );

            $response_data = array(
                'update_available' => true,
                'current_version' => $current_version,
                'latest_version' => $latest_version['version'],
                'changelog' => $latest_version['changelog'],
                'download_url' => rest_url( $this->namespace . '/updates/download/' . $token ),
                'package' => rest_url( $this->namespace . '/updates/download/' . $token ),
                'tested' => $latest_version['tested'],
                'requires_php' => $latest_version['requires_php'],
                'compatibility' => $latest_version['compatibility'] ?? array(),
                'file_size' => $latest_version['file_size'] ?? 0,
                'file_hash' => $latest_version['file_hash'] ?? '',
                'message' => esc_html__( 'Update available.', 'vira-store' ),
                'cached' => false,
                'cache_expires_at' => date( 'c', time() + $this->cache_ttl['update_check'] ),
            );

            $this->set_cached( $cache_key, $response_data, $this->cache_ttl['update_check'] );
            
            $response = new WP_REST_Response( $response_data );
            $response->header( 'X-Cache', 'MISS' );
            return $response;
        }

        // Fallback to database query if static JSON not available
        global $wpdb;

        try {
            // Find product by plugin slug
            $product_id = $wpdb->get_var( $wpdb->prepare(
                "SELECT post_id FROM {$wpdb->postmeta} 
                 WHERE meta_key = '_vrstore_plugin_slug' AND meta_value = %s",
                $plugin_slug
            ) );

            if ( ! $product_id ) {
                return new WP_Error(
                    'plugin_not_found',
                    esc_html__( 'Plugin not found.', 'vira-store' ),
                    array( 'status' => 404 )
                );
            }

            // Validate license
            $license_instance = VRSTORE_License::get_instance();
            $license_validation = $license_instance->validate_license_key( $license_key, $product_id );

            if ( ! $license_validation['valid'] ) {
                return new WP_Error(
                    'invalid_license',
                    esc_html__( 'Invalid or expired license.', 'vira-store' ),
                    array( 'status' => 403 )
                );
            }

            // Get license tier
            $license_tier = $license_validation['license_tier'] ?? 'basic';

            // Get latest version for this license tier
            $product_instance = VRSTORE_Product::get_instance();
            $latest_version = $product_instance->get_latest_plugin_version( $product_id, $license_tier );

            if ( ! $latest_version ) {
                $response_data = array(
                    'update_available' => false,
                    'message' => esc_html__( 'No updates available for your license tier.', 'vira-store' )
                );
                
                $this->set_cached( $cache_key, $response_data, $this->cache_ttl['update_check'] );
                
                return new WP_REST_Response( $response_data, 200 );
            }

            // Compare versions
            $update_available = version_compare( $latest_version->version, $current_version, '>' );

            if ( ! $update_available ) {
                $response_data = array(
                    'update_available' => false,
                    'current_version' => $current_version,
                    'latest_version' => $latest_version->version,
                    'message' => esc_html__( 'You have the latest version.', 'vira-store' )
                );
                
                $this->set_cached( $cache_key, $response_data, $this->cache_ttl['update_check'] );
                
                return new WP_REST_Response( $response_data, 200 );
            }

            // Generate secure download token
            $token = wp_generate_password( 32, false );
            $expires_at = date( 'Y-m-d H:i:s', strtotime( '+1 hour' ) );

            $wpdb->insert(
                $wpdb->prefix . 'vrstore_update_tokens',
                array(
                    'token' => $token,
                    'license_key' => $license_key,
                    'product_id' => $product_id,
                    'version_id' => $latest_version->id,
                    'site_url' => $site_url,
                    'expires_at' => $expires_at,
                    'created_at' => current_time( 'mysql' )
                ),
                array( '%s', '%s', '%d', '%d', '%s', '%s', '%s' )
            );

            $response_data = array(
                'update_available' => true,
                'current_version' => $current_version,
                'latest_version' => $latest_version->version,
                'changelog' => $latest_version->changelog,
                'download_url' => rest_url( $this->namespace . '/updates/download/' . $token ),
                'package' => rest_url( $this->namespace . '/updates/download/' . $token ),
                'tested' => get_bloginfo( 'version' ),
                'requires_php' => '8.2',
                'compatibility' => array(),
                'message' => esc_html__( 'Update available.', 'vira-store' )
            );

            $this->set_cached( $cache_key, $response_data, $this->cache_ttl['update_check'] );

            return new WP_REST_Response( $response_data, 200 );

        } catch ( Exception $e ) {
            return new WP_Error(
                'update_check_failed',
                esc_html__( 'Failed to check for updates.', 'vira-store' ),
                array( 'status' => 500 )
            );
        }
    }

    /**
     * Get static update data from JSON file
     *
     * @since 2.0.0
     * @param string $plugin_slug Plugin slug
     * @return array|false Update data or false if not available
     */
    private function get_static_update_data( $plugin_slug ) {
        // Try to get from R2/CDN first
        $r2_url = 'https://your-r2-bucket.r2.cloudflarestorage.com/updates/' . $plugin_slug . '/versions.json';
        
        $response = wp_remote_get( $r2_url, array(
            'timeout' => 5,
            'sslverify' => true,
        ) );

        if ( ! is_wp_error( $response ) && wp_remote_retrieve_response_code( $response ) === 200 ) {
            $body = wp_remote_retrieve_body( $response );
            $data = json_decode( $body, true );
            if ( $data ) {
                return $data;
            }
        }

        // Fallback to local file
        $upload_dir = wp_upload_dir();
        $file_path = $upload_dir['basedir'] . '/vrstore-updates/' . $plugin_slug . '/versions.json';
        
        if ( file_exists( $file_path ) ) {
            $content = file_get_contents( $file_path );
            $data = json_decode( $content, true );
            if ( $data ) {
                return $data;
            }
        }

        return false;
    }

    /**
     * Get static update metadata endpoint
     *
     * @since 2.0.0
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_REST_Response|WP_Error
     */
    public function get_static_update_metadata( $request ) {
        $plugin_slug = $request->get_param( 'plugin_slug' );
        
        $data = $this->get_static_update_data( $plugin_slug );
        
        if ( $data === false ) {
            return new WP_Error(
                'not_found',
                esc_html__( 'Update metadata not found.', 'vira-store' ),
                array( 'status' => 404 )
            );
        }

        $response = new WP_REST_Response( $data );
        $response->header( 'Content-Type', 'application/json' );
        $response->header( 'Cache-Control', 'public, max-age=300' );
        
        return $response;
    }

    /**
     * Monitor domain (optimized)
     *
     * @since 2.0.0
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_REST_Response|WP_Error
     */
    public function monitor_domain_optimized( $request ) {
        $license_key = sanitize_text_field( $request['license_key'] );
        $domain = sanitize_text_field( $request['domain'] );

        // Check cache
        $cache_key = 'domain_monitor_' . md5( $license_key . '_' . $domain );
        $cached_result = $this->get_cached( $cache_key );
        
        if ( $cached_result !== false ) {
            $response = new WP_REST_Response( $cached_result );
            $response->header( 'X-Cache', 'HIT' );
            return $response;
        }

        // Get domain monitor instance
        $domain_monitor = VRSTORE_Domain_Monitor::get_instance();
        $result = $domain_monitor->check_license( $license_key, $domain );

        // Cache result for 5 minutes
        $this->set_cached( $cache_key, $result, 300 );

        $response = new WP_REST_Response( $result );
        $response->header( 'X-Cache', 'MISS' );
        return $response;
    }
}

// Initialize the optimized API
add_action( 'init', function() {
    VRSTORE_API_Optimized::get_instance();
} );

// Batch update API key timestamps (runs via cron)
add_action( 'vrstore_batch_update_api_keys', function() {
    $keys_to_update = get_transient( 'vrstore_api_keys_to_update' );
    if ( ! is_array( $keys_to_update ) || empty( $keys_to_update ) ) {
        return;
    }

    global $wpdb;
    $api_keys_table = $wpdb->prefix . 'vrstore_api_keys';
    $now = current_time( 'mysql' );

    foreach ( array_unique( $keys_to_update ) as $key_id ) {
        $wpdb->update(
            $api_keys_table,
            array( 'last_used' => $now ),
            array( 'id' => $key_id ),
            array( '%s' ),
            array( '%d' )
        );
    }

    // Clear the transient
    delete_transient( 'vrstore_api_keys_to_update' );
} );

