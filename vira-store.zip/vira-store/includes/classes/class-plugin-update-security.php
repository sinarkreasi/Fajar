<?php
/**
 * Plugin Update Security Handler
 *
 * Handles security measures for the plugin update system including
 * validation, sanitization, rate limiting, and access control.
 *
 * @package Vira_Store
 * @since 1.9.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

class VRSTORE_Plugin_Update_Security {
    
    /**
     * Singleton instance
     *
     * @var VRSTORE_Plugin_Update_Security
     */
    private static $instance = null;
    
    /**
     * Rate limiting data
     *
     * @var array
     */
    private $rate_limits = [];
    
    /**
     * Security settings
     *
     * @var array
     */
    private $security_settings;
    
    /**
     * Get singleton instance
     *
     * @return VRSTORE_Plugin_Update_Security
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->init_security_settings();
        $this->init_hooks();
    }
    
    /**
     * Initialize security settings
     */
    private function init_security_settings() {
        $this->security_settings = wp_parse_args(
            get_option('vrstore_plugin_update_security', []),
            [
                'max_requests_per_hour' => 100,
                'max_requests_per_day' => 1000,
                'block_suspicious_ips' => true,
                'log_security_events' => true,
                'require_ssl' => true,
                'validate_user_agent' => true,
                'max_file_size' => 50 * 1024 * 1024, // 50MB
                'allowed_file_types' => ['zip'],
                'scan_uploaded_files' => true,
            ]
        );
    }
    
    /**
     * Initialize hooks
     */
    private function init_hooks() {
        add_action('wp_ajax_vrstore_validate_plugin_update_request', [$this, 'ajax_validate_update_request']);
        add_action('wp_ajax_nopriv_vrstore_validate_plugin_update_request', [$this, 'ajax_validate_update_request']);
        
        // Clean up rate limiting data daily
        add_action('vrstore_daily_cleanup', [$this, 'cleanup_rate_limit_data']);
        
        // Security event logging
        add_action('vrstore_security_event', [$this, 'log_security_event'], 10, 3);
    }
    
    /**
     * Validate plugin update request
     *
     * @param array $request_data Request data to validate
     * @return array Validation result
     */
    public function validate_update_request($request_data) {
        $validation_result = [
            'valid' => false,
            'errors' => [],
            'security_level' => 'low'
        ];
        
        try {
            // Check SSL requirement
            if ($this->security_settings['require_ssl'] && !is_ssl()) {
                $validation_result['errors'][] = __('SSL connection required for plugin updates.', 'vira-store');
                $this->log_security_event('ssl_required', 'Plugin update attempted without SSL', $request_data);
                return $validation_result;
            }
            
            // Validate required fields
            $required_fields = ['plugin_slug', 'version', 'license_key', 'site_url'];
            foreach ($required_fields as $field) {
                if (empty($request_data[$field])) {
                    $validation_result['errors'][] = sprintf(
                        __('Required field missing: %s', 'vira-store'),
                        $field
                    );
                }
            }
            
            if (!empty($validation_result['errors'])) {
                return $validation_result;
            }
            
            // Sanitize and validate individual fields
            $sanitized_data = $this->sanitize_request_data($request_data);
            $field_validation = $this->validate_request_fields($sanitized_data);
            
            if (!$field_validation['valid']) {
                $validation_result['errors'] = array_merge(
                    $validation_result['errors'],
                    $field_validation['errors']
                );
                return $validation_result;
            }
            
            // Check rate limiting
            $rate_limit_check = $this->check_rate_limits($request_data);
            if (!$rate_limit_check['allowed']) {
                $validation_result['errors'][] = $rate_limit_check['message'];
                $this->log_security_event('rate_limit_exceeded', 'Rate limit exceeded for plugin update', $request_data);
                return $validation_result;
            }
            
            // Validate User Agent if enabled
            if ($this->security_settings['validate_user_agent']) {
                $user_agent_validation = $this->validate_user_agent();
                if (!$user_agent_validation['valid']) {
                    $validation_result['errors'][] = $user_agent_validation['message'];
                    $this->log_security_event('invalid_user_agent', 'Invalid user agent detected', $request_data);
                    return $validation_result;
                }
            }
            
            // Check for suspicious patterns
            $suspicious_check = $this->check_suspicious_patterns($request_data);
            if ($suspicious_check['suspicious']) {
                $validation_result['errors'][] = __('Suspicious request pattern detected.', 'vira-store');
                $validation_result['security_level'] = 'high';
                $this->log_security_event('suspicious_pattern', $suspicious_check['reason'], $request_data);
                return $validation_result;
            }
            
            $validation_result['valid'] = true;
            $validation_result['data'] = $sanitized_data;
            $validation_result['security_level'] = 'normal';
            
        } catch (Exception $e) {
            $validation_result['errors'][] = __('Security validation failed.', 'vira-store');
            $this->log_security_event('validation_exception', $e->getMessage(), $request_data);
        }
        
        return $validation_result;
    }
    
    /**
     * Sanitize request data
     *
     * @param array $data Raw request data
     * @return array Sanitized data
     */
    public function sanitize_request_data($data) {
        return [
            'plugin_slug' => sanitize_text_field($data['plugin_slug'] ?? ''),
            'version' => sanitize_text_field($data['version'] ?? ''),
            'license_key' => sanitize_text_field($data['license_key'] ?? ''),
            'site_url' => esc_url_raw($data['site_url'] ?? ''),
            'user_agent' => sanitize_text_field($_SERVER['HTTP_USER_AGENT'] ?? ''),
            'ip_address' => $this->get_client_ip(),
            'timestamp' => current_time('timestamp')
        ];
    }
    
    /**
     * Validate individual request fields
     *
     * @param array $data Sanitized request data
     * @return array Validation result
     */
    private function validate_request_fields($data) {
        $result = ['valid' => true, 'errors' => []];
        
        // Validate plugin slug format
        if (!preg_match('/^[a-z0-9\-_]+$/', $data['plugin_slug'])) {
            $result['errors'][] = __('Invalid plugin slug format.', 'vira-store');
        }
        
        // Validate version format (semantic versioning)
        if (!preg_match('/^\d+\.\d+\.\d+(-[a-zA-Z0-9\-\.]+)?$/', $data['version'])) {
            $result['errors'][] = __('Invalid version format. Use semantic versioning (e.g., 1.0.0).', 'vira-store');
        }
        
        // Validate license key format
        if (strlen($data['license_key']) < 10 || strlen($data['license_key']) > 100) {
            $result['errors'][] = __('Invalid license key format.', 'vira-store');
        }
        
        // Validate site URL
        if (!filter_var($data['site_url'], FILTER_VALIDATE_URL)) {
            $result['errors'][] = __('Invalid site URL format.', 'vira-store');
        }
        
        $result['valid'] = empty($result['errors']);
        return $result;
    }
    
    /**
     * Check rate limits for requests
     *
     * @param array $request_data Request data
     * @return array Rate limit check result
     */
    private function check_rate_limits($request_data) {
        $ip = $this->get_client_ip();
        $current_time = current_time('timestamp');
        $hour_key = date('Y-m-d-H', $current_time);
        $day_key = date('Y-m-d', $current_time);
        
        // Get current counts
        $hourly_count = get_transient("vrstore_rate_limit_hour_{$ip}_{$hour_key}") ?: 0;
        $daily_count = get_transient("vrstore_rate_limit_day_{$ip}_{$day_key}") ?: 0;
        
        // Check limits
        if ($hourly_count >= $this->security_settings['max_requests_per_hour']) {
            return [
                'allowed' => false,
                'message' => __('Hourly request limit exceeded. Please try again later.', 'vira-store')
            ];
        }
        
        if ($daily_count >= $this->security_settings['max_requests_per_day']) {
            return [
                'allowed' => false,
                'message' => __('Daily request limit exceeded. Please try again tomorrow.', 'vira-store')
            ];
        }
        
        // Increment counters
        set_transient("vrstore_rate_limit_hour_{$ip}_{$hour_key}", $hourly_count + 1, HOUR_IN_SECONDS);
        set_transient("vrstore_rate_limit_day_{$ip}_{$day_key}", $daily_count + 1, DAY_IN_SECONDS);
        
        return ['allowed' => true];
    }
    
    /**
     * Validate User Agent
     *
     * @return array Validation result
     */
    private function validate_user_agent() {
        $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : '';
        
        if (empty($user_agent)) {
            return [
                'valid' => false,
                'message' => __('User agent is required.', 'vira-store')
            ];
        }
        
        // Check user agent length (prevent extremely long user agents that could be attacks)
        if (strlen($user_agent) > 512) {
            return [
                'valid' => false,
                'message' => __('Invalid user agent format.', 'vira-store')
            ];
        }
        
        // Check for suspicious user agents
        $suspicious_patterns = [
            '/bot/i',
            '/crawler/i',
            '/spider/i',
            '/scraper/i',
            '/curl/i',
            '/wget/i',
            '/python-requests/i',
            '/go-http-client/i',
            '/httpie/i',
            '/postman/i'
        ];
        
        foreach ($suspicious_patterns as $pattern) {
            if (preg_match($pattern, $user_agent)) {
                $this->log_security_event('suspicious_user_agent', 'Suspicious user agent detected', [
                    'user_agent' => substr($user_agent, 0, 200) // Limit log size
                ]);
                return [
                    'valid' => false,
                    'message' => __('Automated requests are not allowed.', 'vira-store')
                ];
            }
        }
        
        // Allow legitimate WordPress user agents
        $legitimate_patterns = [
            '/WordPress/i',
            '/WooCommerce/i',
            '/WordPress.*Update/i'
        ];
        
        foreach ($legitimate_patterns as $pattern) {
            if (preg_match($pattern, $user_agent)) {
                return ['valid' => true];
            }
        }
        
        return ['valid' => true];
    }
    
    /**
     * Check for suspicious request patterns
     *
     * @param array $request_data Request data
     * @return array Suspicious check result
     */
    private function check_suspicious_patterns($request_data) {
        $suspicious_indicators = [];
        
        // Check for SQL injection patterns
        $sql_patterns = ['/union\s+select/i', '/drop\s+table/i', '/insert\s+into/i', '/delete\s+from/i'];
        foreach ($request_data as $key => $value) {
            if (is_string($value)) {
                foreach ($sql_patterns as $pattern) {
                    if (preg_match($pattern, $value)) {
                        $suspicious_indicators[] = "SQL injection pattern in {$key}";
                    }
                }
            }
        }
        
        // Check for XSS patterns
        $xss_patterns = ['/<script/i', '/javascript:/i', '/on\w+\s*=/i'];
        foreach ($request_data as $key => $value) {
            if (is_string($value)) {
                foreach ($xss_patterns as $pattern) {
                    if (preg_match($pattern, $value)) {
                        $suspicious_indicators[] = "XSS pattern in {$key}";
                    }
                }
            }
        }
        
        // Check for path traversal
        if (strpos($request_data['plugin_slug'] ?? '', '..') !== false) {
            $suspicious_indicators[] = "Path traversal in plugin_slug";
        }
        
        return [
            'suspicious' => !empty($suspicious_indicators),
            'reason' => implode(', ', $suspicious_indicators)
        ];
    }
    
    /**
     * Validate file upload security
     *
     * @param array $file_data File upload data
     * @return array Validation result
     */
    public function validate_file_upload($file_data) {
        $result = ['valid' => false, 'errors' => []];
        
        try {
            // Check file size
            if ($file_data['size'] > $this->security_settings['max_file_size']) {
                $result['errors'][] = sprintf(
                    __('File size exceeds maximum allowed size of %s.', 'vira-store'),
                    size_format($this->security_settings['max_file_size'])
                );
            }
            
            // Check file type
            $file_extension = strtolower(pathinfo($file_data['name'], PATHINFO_EXTENSION));
            if (!in_array($file_extension, $this->security_settings['allowed_file_types'])) {
                $result['errors'][] = sprintf(
                    __('File type not allowed. Allowed types: %s', 'vira-store'),
                    implode(', ', $this->security_settings['allowed_file_types'])
                );
            }
            
            // Check MIME type
            $allowed_mime_types = ['application/zip', 'application/x-zip-compressed'];
            if (!in_array($file_data['type'], $allowed_mime_types)) {
                $result['errors'][] = __('Invalid file MIME type.', 'vira-store');
            }
            
            // Scan file if enabled
            if ($this->security_settings['scan_uploaded_files'] && empty($result['errors'])) {
                $scan_result = $this->scan_uploaded_file($file_data['tmp_name']);
                if (!$scan_result['safe']) {
                    $result['errors'][] = $scan_result['message'];
                }
            }
            
            $result['valid'] = empty($result['errors']);
            
        } catch (Exception $e) {
            $result['errors'][] = __('File validation failed.', 'vira-store');
            $this->log_security_event('file_validation_exception', $e->getMessage(), $file_data);
        }
        
        return $result;
    }
    
    /**
     * Scan uploaded file for threats
     *
     * @param string $file_path Path to uploaded file
     * @return array Scan result
     */
    private function scan_uploaded_file($file_path) {
        $result = ['safe' => true, 'message' => ''];
        
        if (empty($file_path) || !is_string($file_path)) {
            return [
                'safe' => false,
                'message' => __('Invalid file path provided.', 'vira-store')
            ];
        }
        
        // Sanitize file path to prevent directory traversal
        $file_path = realpath($file_path);
        if ($file_path === false) {
            return [
                'safe' => false,
                'message' => __('File not found for scanning.', 'vira-store')
            ];
        }
        
        // Verify file is within uploads directory (security check)
        $upload_dir = wp_upload_dir();
        $upload_path = realpath($upload_dir['basedir']);
        if ($upload_path && strpos($file_path, $upload_path) !== 0) {
            return [
                'safe' => false,
                'message' => __('File is outside allowed upload directory.', 'vira-store')
            ];
        }
        
        if (!file_exists($file_path) || !is_readable($file_path)) {
            return [
                'safe' => false,
                'message' => __('File not found or not readable for scanning.', 'vira-store')
            ];
        }
        
        // Check file size before reading
        $file_size = filesize($file_path);
        if ($file_size === false || $file_size === 0) {
            return [
                'safe' => false,
                'message' => __('Invalid file size.', 'vira-store')
            ];
        }
        
        // Limit reading to first 1MB to prevent memory issues
        $read_limit = min(1024 * 1024, $file_size);
        
        // Read file content with error handling
        $file_handle = @fopen($file_path, 'rb');
        if ($file_handle === false) {
            return [
                'safe' => false,
                'message' => __('Unable to open file for scanning.', 'vira-store')
            ];
        }
        
        $file_content = @fread($file_handle, $read_limit);
        @fclose($file_handle);
        
        if ($file_content === false) {
            return [
                'safe' => false,
                'message' => __('Unable to read file for scanning.', 'vira-store')
            ];
        }
        
        // Check for suspicious patterns
        $threat_patterns = [
            '/eval\s*\(/i',
            '/base64_decode/i',
            '/shell_exec/i',
            '/system\s*\(/i',
            '/exec\s*\(/i',
            '/passthru/i',
            '/file_get_contents\s*\(\s*["\']https?:\/\//i',
            '/preg_replace\s*\(\s*["\']\/.*\/e/i', // eval via preg_replace /e modifier
            '/create_function\s*\(/i',
            '/assert\s*\(/i',
            '/call_user_func\s*\(\s*["\'](eval|exec|system|shell_exec|passthru)/i'
        ];
        
        foreach ($threat_patterns as $pattern) {
            if (preg_match($pattern, $file_content)) {
                $this->log_security_event('suspicious_file_content', 'Suspicious pattern detected in uploaded file', [
                    'file_path' => basename($file_path),
                    'pattern' => $pattern
                ]);
                return [
                    'safe' => false,
                    'message' => __('Suspicious code detected in uploaded file.', 'vira-store')
                ];
            }
        }
        
        return $result;
    }
    
    /**
     * Get client IP address
     *
     * @return string Client IP address
     */
    public function get_client_ip(): string {
        $ip_keys = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'HTTP_CLIENT_IP', 'REMOTE_ADDR'];
        
        foreach ($ip_keys as $key) {
            if (isset($_SERVER[$key]) && !empty($_SERVER[$key])) {
                $ip_string = sanitize_text_field(wp_unslash($_SERVER[$key]));
                
                // Handle comma-separated IPs (take first valid one)
                if (strpos($ip_string, ',') !== false) {
                    $ips = explode(',', $ip_string);
                    foreach ($ips as $ip_candidate) {
                        $ip_candidate = trim($ip_candidate);
                        // Validate IP - allow both public and private IPs for internal networks
                        if (filter_var($ip_candidate, FILTER_VALIDATE_IP)) {
                            // Prefer public IPs, but accept private if that's all we have
                            if (filter_var($ip_candidate, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                                return $ip_candidate;
                            }
                        }
                    }
                    // If we got here, try the first IP even if private
                    $ip_candidate = trim($ips[0]);
                    if (filter_var($ip_candidate, FILTER_VALIDATE_IP)) {
                        return $ip_candidate;
                    }
                } else {
                    $ip = trim($ip_string);
                    // Validate IP - allow both public and private IPs
                    if (filter_var($ip, FILTER_VALIDATE_IP)) {
                        // Prefer public IPs, but accept private if that's all we have
                        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                            return $ip;
                        }
                    }
                }
            }
        }
        
        // Fallback to REMOTE_ADDR (may be private IP)
        $fallback_ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        return filter_var($fallback_ip, FILTER_VALIDATE_IP) ? $fallback_ip : '0.0.0.0';
    }
    
    /**
     * Log security event
     *
     * @param string $event_type Type of security event
     * @param string $message Event message
     * @param array $context Additional context data
     */
    public function log_security_event($event_type, $message, $context = []) {
        if (!$this->security_settings['log_security_events']) {
            return;
        }
        
        // Sanitize event type
        $event_type = sanitize_key($event_type);
        if (empty($event_type)) {
            return;
        }
        
        // Sanitize message
        $message = sanitize_text_field($message);
        if (empty($message)) {
            return;
        }
        
        $log_entry = [
            'timestamp' => current_time('mysql'),
            'event_type' => $event_type,
            'message' => $message,
            'ip_address' => $this->get_client_ip(),
            'user_agent' => sanitize_text_field($_SERVER['HTTP_USER_AGENT'] ?? ''),
            'context' => wp_json_encode($context, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
        ];
        
        // Store in database - check if table exists first
        global $wpdb;
        $table_name = $wpdb->prefix . 'vrstore_security_log';
        
        // Check if table exists
        $table_exists = $wpdb->get_var($wpdb->prepare(
            "SHOW TABLES LIKE %s",
            $table_name
        )) === $table_name;
        
        if ($table_exists) {
            $insert_result = $wpdb->insert(
                $table_name,
                $log_entry,
                ['%s', '%s', '%s', '%s', '%s', '%s']
            );
            
            if ($insert_result === false) {
                error_log('ViraStore: Failed to insert security log entry: ' . $wpdb->last_error);
            }
        } else {
            // Table doesn't exist - try to create it
            self::create_security_log_table();
            
            // Try inserting again
            $insert_result = $wpdb->insert(
                $table_name,
                $log_entry,
                ['%s', '%s', '%s', '%s', '%s', '%s']
            );
            
            if ($insert_result === false) {
                error_log('ViraStore: Failed to insert security log entry after table creation: ' . $wpdb->last_error);
            }
        }
        
        // Also log to WordPress error log for critical events
        $critical_events = ['sql_injection', 'xss_attempt', 'suspicious_pattern', 'rate_limit_exceeded'];
        if (in_array($event_type, $critical_events)) {
            error_log("ViraStore Security Event [{$event_type}]: {$message} - IP: {$log_entry['ip_address']}");
        }
    }
    
    /**
     * AJAX handler for validating update requests
     */
    public function ajax_validate_update_request() {
        // This is a public endpoint, so we don't require login
        // but we do validate the request thoroughly
        
        // Verify nonce if provided (optional for public endpoint, but recommended)
        $nonce_provided = isset($_POST['security_nonce']) && !empty($_POST['security_nonce']);
        if ($nonce_provided) {
            if (!wp_verify_nonce($_POST['security_nonce'], 'vrstore_plugin_update_nonce')) {
                wp_send_json_error([
                    'message' => __('Security check failed.', 'vira-store'),
                    'errors' => [__('Invalid nonce.', 'vira-store')]
                ]);
                return;
            }
        }
        
        // Sanitize all input data
        $request_data = [
            'plugin_slug' => isset($_POST['plugin_slug']) ? sanitize_text_field(wp_unslash($_POST['plugin_slug'])) : '',
            'version' => isset($_POST['version']) ? sanitize_text_field(wp_unslash($_POST['version'])) : '',
            'license_key' => isset($_POST['license_key']) ? sanitize_text_field(wp_unslash($_POST['license_key'])) : '',
            'site_url' => isset($_POST['site_url']) ? esc_url_raw(wp_unslash($_POST['site_url'])) : ''
        ];
        
        // Validate that required fields are not empty
        if (empty($request_data['plugin_slug']) || empty($request_data['version']) || 
            empty($request_data['license_key']) || empty($request_data['site_url'])) {
            wp_send_json_error([
                'message' => __('Missing required fields.', 'vira-store'),
                'errors' => [__('All fields are required.', 'vira-store')]
            ]);
            return;
        }
        
        $validation_result = $this->validate_update_request($request_data);
        
        if ($validation_result['valid']) {
            wp_send_json_success([
                'message' => __('Request validation passed.', 'vira-store'),
                'security_level' => $validation_result['security_level']
            ]);
        } else {
            wp_send_json_error([
                'message' => __('Request validation failed.', 'vira-store'),
                'errors' => $validation_result['errors']
            ]);
        }
    }
    
    /**
     * Clean up old rate limiting data
     */
    public function cleanup_rate_limit_data() {
        global $wpdb;
        
        // Clean up transients older than 2 days using WordPress transient API
        // Get all rate limit transients
        $transient_prefix = '_transient_vrstore_rate_limit_';
        $transient_timeout_prefix = '_transient_timeout_vrstore_rate_limit_';
        
        // Delete expired transients
        $expired_time = time() - (2 * DAY_IN_SECONDS);
        
        // Use WordPress functions to delete expired transients safely
        $transient_keys = $wpdb->get_col($wpdb->prepare(
            "SELECT option_name FROM {$wpdb->options} 
             WHERE option_name LIKE %s 
             AND option_name NOT LIKE %s
             AND CAST(option_value AS UNSIGNED) < %d",
            $transient_timeout_prefix . '%',
            $transient_timeout_prefix . '%' . $transient_timeout_prefix . '%', // Exclude duplicates
            $expired_time
        ));
        
        foreach ($transient_keys as $timeout_key) {
            // Extract transient name
            $transient_name = str_replace($transient_timeout_prefix, '', $timeout_key);
            delete_transient('vrstore_rate_limit_' . $transient_name);
        }
        
        // Also clean up by pattern matching for older format
        $old_cutoff_date = date('Y-m-d', strtotime('-2 days'));
        $old_transients = $wpdb->get_col($wpdb->prepare(
            "SELECT option_name FROM {$wpdb->options} 
             WHERE option_name LIKE %s 
             AND option_name LIKE %s",
            $transient_prefix . '%',
            '%' . $old_cutoff_date . '%'
        ));
        
        foreach ($old_transients as $transient_key) {
            $transient_name = str_replace(['_transient_', '_transient_timeout_'], '', $transient_key);
            delete_transient(str_replace('vrstore_rate_limit_', '', $transient_name));
        }
        
        // Clean up old security logs (keep 30 days)
        $table_name = $wpdb->prefix . 'vrstore_security_log';
        
        // Check if table exists before attempting to delete
        $table_exists = $wpdb->get_var($wpdb->prepare(
            "SHOW TABLES LIKE %s",
            $table_name
        )) === $table_name;
        
        if ($table_exists) {
            $deleted = $wpdb->query($wpdb->prepare(
                "DELETE FROM {$table_name} WHERE timestamp < %s",
                date('Y-m-d H:i:s', strtotime('-30 days'))
            ));
            
            if ($deleted !== false && $deleted > 0) {
                error_log("ViraStore: Cleaned up {$deleted} old security log entries.");
            }
        }
    }
    
    /**
     * Create security log table
     */
    public static function create_security_log_table() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'vrstore_security_log';
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            timestamp datetime DEFAULT CURRENT_TIMESTAMP,
            event_type varchar(50) NOT NULL,
            message text NOT NULL,
            ip_address varchar(45) NOT NULL,
            user_agent text,
            context longtext,
            PRIMARY KEY (id),
            KEY event_type (event_type),
            KEY timestamp (timestamp),
            KEY ip_address (ip_address)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
}

// Initialize the security handler
VRSTORE_Plugin_Update_Security::get_instance();