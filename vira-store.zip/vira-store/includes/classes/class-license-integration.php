<?php
/**
 * Vira Store License Integration Class
 *
 * @package ViraStore
 * @subpackage Licensing
 */

namespace ViraStore\Licensing;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Class License_Integration
 *
 * Manages the integration points for Vira Store's licensing system with other plugins.
 */
class License_Integration {

    /**
     * Constructor.
     */
    public function __construct() {
        add_filter( 'vrstore_verify_license', [ $this, 'verify_license' ], 10, 4 );
        add_action( 'vrstore_activate_license', [ $this, 'activate_license' ], 10, 3 );
        add_action( 'vrstore_deactivate_license', [ $this, 'deactivate_license' ], 10, 3 );
    }

    /**
     * Verifies a license key.
     *
     * This filter allows external plugins to hook into Vira Store's license verification process.
     *
     * @param bool   $is_valid     Initial validity status.
     * @param string $license_key  The license key to verify.
     * @param int    $product_id   The ID of the product associated with the license.
     * @param string $domain       The domain where the license is being checked.
     * @return bool True if the license is valid, false otherwise.
     */
    public function verify_license( bool $is_valid, string $license_key, int $product_id, string $domain ): bool {
        // Sanitize inputs
        $license_key = sanitize_text_field(trim($license_key));
        $product_id = absint($product_id);
        $domain = sanitize_text_field(trim($domain));
        
        // Basic validation
        if (empty($license_key) || $product_id <= 0) {
            return false;
        }
        
        // If already determined invalid, return early
        if (!$is_valid) {
            return false;
        }
        
        // Verify license using Vira Store's license system
        if (class_exists('VRSTORE_License')) {
            $license_instance = VRSTORE_License::get_instance();
            $validation = $license_instance->validate_license_key($license_key, $product_id);
            
            if (!$validation['valid']) {
                return false;
            }
            
            // If domain provided, also check domain activation status
            if (!empty($domain)) {
                if (class_exists('VRSTORE_Domain_Monitor')) {
                    $domain_monitor = VRSTORE_Domain_Monitor::get_instance();
                    $domain_check = $domain_monitor->check_license($license_key, $domain);
                    
                    // License is valid if it exists and is active (domain activation is optional)
                    return isset($domain_check['valid']) && $domain_check['valid'] === true;
                }
            }
            
            return true;
        }
        
        // Fallback to initial status if License class not available
        return $is_valid;
    }

    /**
     * Activates a license key.
     *
     * This action allows external plugins to trigger license activation within Vira Store.
     *
     * @param string $license_key  The license key to activate.
     * @param int    $product_id   The ID of the product.
     * @param string $domain       The domain where the license is being activated.
     */
    public function activate_license( string $license_key, int $product_id, string $domain ): void {
        // Sanitize inputs
        $license_key = sanitize_text_field(trim($license_key));
        $product_id = absint($product_id);
        $domain = sanitize_text_field(trim($domain));
        
        if (empty($license_key) || $product_id <= 0 || empty($domain)) {
            error_log('ViraStore License Integration: Invalid parameters for license activation');
            return;
        }
        
        // Use Domain Monitor for domain-based activations (preferred)
        if (class_exists('VRSTORE_Domain_Monitor')) {
            $domain_monitor = VRSTORE_Domain_Monitor::get_instance();
            $result = $domain_monitor->activate_license($license_key, $domain, (string)$product_id);
            
            if (!$result['success']) {
                error_log('ViraStore License Integration: Domain activation failed - ' . ($result['message'] ?? 'Unknown error'));
            }
        } elseif (class_exists('VRSTORE_License')) {
            // Fallback to legacy license activation - pass product_id for product-specific validation
            $license_instance = VRSTORE_License::get_instance();
            $site_url = 'https://' . $domain;
            $result = $license_instance->activate_license($license_key, $site_url, $product_id);
            
            if (!$result['valid']) {
                error_log('ViraStore License Integration: License activation failed - ' . ($result['message'] ?? 'Unknown error'));
            }
        }
    }

    /**
     * Deactivates a license key.
     *
     * This action allows external plugins to trigger license deactivation within Vira Store.
     *
     * @param string $license_key  The license key to deactivate.
     * @param int    $product_id   The ID of the product.
     * @param string $domain       The domain where the license is being deactivated.
     */
    public function deactivate_license( string $license_key, int $product_id, string $domain ): void {
        // Sanitize inputs
        $license_key = sanitize_text_field(trim($license_key));
        $product_id = absint($product_id);
        $domain = sanitize_text_field(trim($domain));
        
        if (empty($license_key) || empty($domain)) {
            error_log('ViraStore License Integration: Invalid parameters for license deactivation');
            return;
        }
        
        // Use Domain Monitor for domain-based deactivations (preferred)
        if (class_exists('VRSTORE_Domain_Monitor')) {
            $domain_monitor = VRSTORE_Domain_Monitor::get_instance();
            $result = $domain_monitor->deactivate_license($license_key, $domain);
            
            if (!$result['success']) {
                error_log('ViraStore License Integration: Domain deactivation failed - ' . ($result['message'] ?? 'Unknown error'));
            }
        } elseif (class_exists('VRSTORE_License')) {
            // Fallback to legacy license deactivation - pass product_id for product-specific validation
            $license_instance = VRSTORE_License::get_instance();
            $site_url = 'https://' . $domain;
            $result = $license_instance->deactivate_license($license_key, $site_url, $product_id);
            
            if (!$result['valid']) {
                error_log('ViraStore License Integration: License deactivation failed - ' . ($result['message'] ?? 'Unknown error'));
            }
        }
    }
}

// Instantiate the class to hook into WordPress actions and filters.
new License_Integration();