<?php
/**
 * Invoice Management Class
 *
 * @package Vira_Store
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * VRSTORE_Invoice Class
 *
 * This class handles invoice generation and management for completed orders.
 *
 * @since 1.0.0
 */
class VRSTORE_Invoice {

    /**
     * Instance of this class.
     *
     * @since 1.0.0
     * @var object
     */
    protected static $instance = null;

    /**
     * Return an instance of this class.
     *
     * @since 1.0.0
     * @return object A single instance of this class.
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Constructor.
     *
     * @since 1.0.0
     */
    public function __construct() {
        // Initialize hooks
        $this->init_hooks();
    }

    /**
     * Initialize hooks.
     *
     * @since 1.0.0
     * @return void
     */
    private function init_hooks() {
        // Add AJAX handlers for invoice generation
        add_action( 'wp_ajax_vrstore_generate_invoice', array( $this, 'ajax_generate_invoice' ) );
        add_action( 'wp_ajax_vrstore_download_invoice', array( $this, 'ajax_download_invoice' ) );
        add_action( 'wp_ajax_vrstore_view_invoice', array( $this, 'ajax_view_invoice' ) );
        
        // Add AJAX handlers for customer access
        add_action( 'wp_ajax_vrstore_customer_download_invoice', array( $this, 'ajax_customer_download_invoice' ) );
        add_action( 'wp_ajax_vrstore_customer_view_invoice', array( $this, 'ajax_customer_view_invoice' ) );
        
        // Handle invoice page requests using template_redirect
        add_action( 'template_redirect', array( $this, 'handle_invoice_requests' ) );
    }

    /**
     * Get translated text with conditional loading check.
     *
     * @since 1.0.0
     * @param string $text The text to translate.
     * @return string
     */
    private function get_translated_text( $text ) {
        if ( vrstore_is_textdomain_ready() ) {
            return esc_html__( $text, 'vira-store' );
        }
        return esc_html( $text );
    }

    /**
     * Generate invoice for an order.
     *
     * @since 1.0.0
     * @param int $order_id Order ID.
     * @return array Invoice data or error.
     */
    public function generate_invoice( $order_id ) {
        global $wpdb;
        
        $orders_table = $wpdb->prefix . 'vrstore_orders';
        
        // Get order details
        $order = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM $orders_table WHERE id = %d",
            $order_id
        ), ARRAY_A );
        
        if ( ! $order ) {
            return new WP_Error( 'order_not_found', $this->get_translated_text( 'Order not found.' ) );
        }
        
        // Check if order is completed
        if ( strtolower( $order['payment_status'] ) !== 'completed' || strtolower( $order['order_status'] ) !== 'completed' ) {
            return new WP_Error( 'order_not_completed', $this->get_translated_text( 'Invoice can only be generated for completed orders.' ) );
        }
        
		// Check if this is an Extended Support product (must be done first)
		$is_extended_support = (is_string($order['product_id']) && strpos($order['product_id'], 'extended_support_') === 0) ||
							   ($order['product_id'] == 0 && strpos($order['product_name'], 'Extended Support') !== false);
        
		// Get product details
		$product = null;
		$product_name = $order['product_name']; // Use the product name from order by default
		
		// For Extended Support products, always use the product name from the order
		if ($is_extended_support) {
			// Extended Support products should use the descriptive name from the order
			// The product name should already contain the correct months from the original purchase
			$product_name = !empty($order['product_name']) ? $order['product_name'] : 'Extended Support Service';
			
			// Note: We no longer try to reconstruct Extended Support descriptions here
			// because the correct product name with actual purchased months should already
			// be stored in the order during the order creation process.
			
			// If the product name doesn't already include the associated product and we have legacy format,
			// try to enhance it by checking if the original product_id was in extended_support_xxx format
			if (strpos($product_name, ' - Extended Support') === false && 
				is_string($order['product_id']) && strpos($order['product_id'], 'extended_support_') === 0) {
				
				$parts = explode('_', $order['product_id']);
				if (count($parts) >= 3) {
					$actual_product_id = intval($parts[2]);
					if ($actual_product_id > 0) {
						$product_post = get_post($actual_product_id);
						if ($product_post && $product_post->post_title) {
							// Extract the Extended Support part and prepend the product name
							if (strpos($product_name, 'Extended Support (') !== false) {
								$extended_part = substr($product_name, strpos($product_name, 'Extended Support ('));
								$product_name = $product_post->post_title . ' - ' . $extended_part;
							}
						}
					}
				}
			}
		} elseif (is_numeric($order['product_id']) && $order['product_id'] > 0) {
			// For regular products, try to get the WordPress post title if available
			$product = get_post( $order['product_id'] );
			if ($product && $product->post_title) {
				$product_name = $product->post_title;
			}
		}
        
        // Check if product has license generation disabled
        $disable_license_generation = $is_extended_support; // Extended Support never has license generation
        $license_key = '';
        
        if ( $product && !$is_extended_support ) {
            $disable_license_generation = get_post_meta( $product->ID, '_vrstore_disable_license_generation', true );
        }
        
        // Only include license key if license generation is not disabled and not Extended Support
        if ( ! $disable_license_generation && ! $is_extended_support ) {
            $license_key = $order['license_key'] ?? '';
        }
        
        // Get site information
        $site_name = get_bloginfo( 'name' );
        $site_url = get_bloginfo( 'url' );
        $site_description = get_bloginfo( 'description' );
        
        // Get logo
        $custom_logo_id = get_theme_mod( 'custom_logo' );
        $logo_url = '';
        if ( $custom_logo_id ) {
            $logo_url = wp_get_attachment_image_url( $custom_logo_id, 'full' );
        }
        
        // Prepare invoice data
        $invoice_data = array(
            'invoice_number' => $this->generate_invoice_number( $order_id ),
            'order_number' => $order['order_number'],
            'order_id' => $order_id,
            'invoice_date' => current_time( 'mysql' ),
            'order_date' => $order['created_at'],
            'customer_name' => $order['customer_name'],
            'customer_email' => $order['customer_email'],
            'product_name' => $product_name,
            'product_price' => $order['product_price'],
            'currency' => $order['currency'] ?? 'USD',
            'payment_method' => $order['payment_method'],
            'payment_status' => $order['payment_status'],
            'site_name' => $site_name,
            'site_url' => $site_url,
            'site_description' => $site_description,
            'logo_url' => $logo_url,
            'license_key' => $license_key,
            'disable_license_generation' => $disable_license_generation,
        );
        
        return $invoice_data;
    }

    /**
     * Generate unique invoice number.
     *
     * @since 1.0.0
     * @param int $order_id Order ID.
     * @return string Invoice number.
     */
    private function generate_invoice_number( $order_id ) {
        $date = date( 'Y' );
        $invoice_number = 'INV-' . $date . '-' . str_pad( $order_id, 6, '0', STR_PAD_LEFT );
        
        return apply_filters( 'vrstore_invoice_number', $invoice_number, $order_id );
    }

    /**
     * Generate invoice HTML content.
     *
     * @since 1.0.0
     * @param array $invoice_data Invoice data.
     * @return string Invoice HTML content.
     */
    public function generate_invoice_html( $invoice_data ) {
        ob_start();
        include VRSTORE_PLUGIN_DIR . 'views/invoice/invoice-template.php';
        return ob_get_clean();
    }

    /**
     * Handle invoice page requests.
     *
     * @since 1.0.0
     * @return void
     */
    public function handle_invoice_requests() {
        if ( ! isset( $_GET['vrstore_invoice'] ) ) {
            return;
        }
        
        $action = sanitize_text_field( $_GET['vrstore_invoice'] );
        $order_id = isset( $_GET['order_id'] ) ? intval( $_GET['order_id'] ) : 0;
        $nonce = isset( $_GET['nonce'] ) ? sanitize_text_field( $_GET['nonce'] ) : '';
        
        if ( ! $order_id ) {
            wp_die( $this->get_translated_text( 'Invalid order ID.' ) );
        }
        
        // Verify nonce
        if ( ! wp_verify_nonce( $nonce, 'vrstore_invoice_' . $order_id ) ) {
            wp_die( $this->get_translated_text( 'Security check failed.' ) );
        }
        
        // Check user permissions
        if ( ! $this->can_user_access_invoice( $order_id ) ) {
            wp_die( $this->get_translated_text( 'You do not have permission to access this invoice.' ) );
        }
        
        $invoice_data = $this->generate_invoice( $order_id );
        
        if ( is_wp_error( $invoice_data ) ) {
            wp_die( $invoice_data->get_error_message() );
        }
        
        switch ( $action ) {
            case 'view':
                $this->display_invoice( $invoice_data );
                break;
            case 'download':
                $this->download_invoice_pdf( $invoice_data );
                break;
            default:
                wp_die( $this->get_translated_text( 'Invalid action.' ) );
        }
    }

    /**
     * Check if user can access invoice for an order.
     *
     * @since 1.0.0
     * @param int $order_id Order ID.
     * @return bool True if user can access invoice.
     */
    private function can_user_access_invoice( $order_id ) {
        // Admin can access all invoices
        if ( current_user_can( 'manage_options' ) ) {
            return true;
        }
        
        // Customer can access their own invoices
        if ( is_user_logged_in() ) {
            global $wpdb;
            $orders_table = $wpdb->prefix . 'vrstore_orders';
            $current_user = wp_get_current_user();
            
            $order = $wpdb->get_row( $wpdb->prepare(
                "SELECT * FROM $orders_table WHERE id = %d AND customer_email = %s",
                $order_id,
                $current_user->user_email
            ) );
            
            return ! empty( $order );
        }
        
        return false;
    }

    /**
     * Display invoice in browser.
     *
     * @since 1.0.0
     * @param array $invoice_data Invoice data.
     * @return void
     */
    public function display_invoice( $invoice_data ) {
        $html = $this->generate_invoice_html( $invoice_data );
        
        // Set headers
        header( 'Content-Type: text/html; charset=utf-8' );
        
        echo $html;
        exit;
    }

    /**
     * Download invoice as PDF (simplified version - outputs HTML for now).
     *
     * @since 1.0.0
     * @param array $invoice_data Invoice data.
     * @return void
     */
    public function download_invoice_pdf( $invoice_data ) {
        $html = $this->generate_invoice_html( $invoice_data );
        $filename = 'invoice-' . $invoice_data['invoice_number'] . '.html';
        
        // Set headers for download
        header( 'Content-Type: text/html; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
        header( 'Cache-Control: private, max-age=0, must-revalidate' );
        header( 'Pragma: public' );
        
        echo $html;
        exit;
    }

    /**
     * Get invoice URL for an order.
     *
     * @since 1.0.0
     * @param int $order_id Order ID.
     * @param string $action Action (view or download).
     * @return string Invoice URL.
     */
    public function get_invoice_url( $order_id, $action = 'view' ) {
        $nonce = wp_create_nonce( 'vrstore_invoice_' . $order_id );
        
        return add_query_arg( array(
            'vrstore_invoice' => $action,
            'order_id' => $order_id,
            'nonce' => $nonce
        ), home_url() );
    }

    /**
     * AJAX handler for generating invoice.
     *
     * @since 1.0.0
     * @return void
     */
    public function ajax_generate_invoice() {
        // Verify nonce
        if ( ! wp_verify_nonce( $_POST['nonce'] ?? '', 'vrstore_admin_nonce' ) ) {
            wp_send_json_error( array( 'message' => $this->get_translated_text( 'Security check failed.' ) ) );
        }
        
        // Check user capabilities
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => $this->get_translated_text( 'Permission denied.' ) ) );
        }
        
        $order_id = intval( $_POST['order_id'] ?? 0 );
        
        if ( ! $order_id ) {
            wp_send_json_error( array( 'message' => $this->get_translated_text( 'Invalid order ID.' ) ) );
        }
        
        $invoice_data = $this->generate_invoice( $order_id );
        
        if ( is_wp_error( $invoice_data ) ) {
            wp_send_json_error( array( 'message' => $invoice_data->get_error_message() ) );
        }
        
        wp_send_json_success( array(
            'message' => $this->get_translated_text( 'Invoice generated successfully.' ),
            'invoice_url' => $this->get_invoice_url( $order_id, 'view' ),
            'download_url' => $this->get_invoice_url( $order_id, 'download' )
        ) );
    }

    /**
     * AJAX handler for customer invoice download.
     *
     * @since 1.0.0
     * @return void
     */
    public function ajax_customer_download_invoice() {
        // Check if user is logged in
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( array( 'message' => $this->get_translated_text( 'Please log in to access invoices.' ) ) );
        }
        
        $order_id = intval( $_POST['order_id'] ?? 0 );
        
        if ( ! $order_id ) {
            wp_send_json_error( array( 'message' => $this->get_translated_text( 'Invalid order ID.' ) ) );
        }
        
        // Check if user can access this invoice
        if ( ! $this->can_user_access_invoice( $order_id ) ) {
            wp_send_json_error( array( 'message' => $this->get_translated_text( 'You do not have permission to access this invoice.' ) ) );
        }
        
        $invoice_url = $this->get_invoice_url( $order_id, 'download' );
        
        wp_send_json_success( array(
            'download_url' => $invoice_url
        ) );
    }

    /**
     * AJAX handler for customer invoice view.
     *
     * @since 1.0.0
     * @return void
     */
    public function ajax_customer_view_invoice() {
        // Check if user is logged in
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( array( 'message' => $this->get_translated_text( 'Please log in to access invoices.' ) ) );
        }
        
        $order_id = intval( $_POST['order_id'] ?? 0 );
        
        if ( ! $order_id ) {
            wp_send_json_error( array( 'message' => $this->get_translated_text( 'Invalid order ID.' ) ) );
        }
        
        // Check if user can access this invoice
        if ( ! $this->can_user_access_invoice( $order_id ) ) {
            wp_send_json_error( array( 'message' => $this->get_translated_text( 'You do not have permission to access this invoice.' ) ) );
        }
        
        $invoice_url = $this->get_invoice_url( $order_id, 'view' );
        
        wp_send_json_success( array(
            'view_url' => $invoice_url
        ) );
    }

    /**
     * Check if order has completed status and can have an invoice.
     *
     * @since 1.0.0
     * @param int $order_id Order ID.
     * @return bool True if order can have an invoice.
     */
    public function can_generate_invoice( $order_id ) {
        global $wpdb;
        
        $orders_table = $wpdb->prefix . 'vrstore_orders';
        
        $order = $wpdb->get_row( $wpdb->prepare(
            "SELECT payment_status, order_status FROM $orders_table WHERE id = %d",
            $order_id
        ) );
        
        if ( ! $order ) {
            return false;
        }
        
        return strtolower( $order->payment_status ) === 'completed' && 
               strtolower( $order->order_status ) === 'completed';
    }
}
