<?php
/**
 * Login Redirect Handler for Vira Store
 *
 * Handles redirection from wp-login.php and wp-admin to custom account page
 *
 * @package Vira_Store
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * VRSTORE_Login_Redirect Class
 *
 * This class handles redirecting wp-login.php and wp-admin access to custom account page.
 *
 * @since 1.0.0
 */
class VRSTORE_Login_Redirect {

    /**
     * Instance of this class.
     *
     * @since 1.0.0
     * @var object
     */
    private static $instance = null;

    /**
     * Constructor.
     *
     * @since 1.0.0
     */
    private function __construct() {
        // Initialize hooks
        $this->init_hooks();
    }

    /**
     * Get instance of this class.
     *
     * @since 1.0.0
     * @return VRSTORE_Login_Redirect
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Initialize hooks.
     *
     * @since 1.0.0
     * @return void
     */
    private function init_hooks() {
        // Check if custom login is enabled
        if ( ! $this->is_custom_login_enabled() ) {
            return;
        }

        // Check if this is a checkout request - if so, skip all redirects
        if ( $this->is_checkout_request() ) {
            return;
        }

        // Handle login form processing before redirect (higher priority)
        add_action( 'login_init', array( $this, 'handle_login_form_submission' ), 5 );
        
        // Redirect wp-login.php requests (lower priority)
        add_action( 'login_init', array( $this, 'redirect_login_page' ), 10 );
        
        // Redirect wp-admin requests for non-logged-in users
        add_action( 'admin_init', array( $this, 'redirect_admin_access' ) );
        
        // Handle successful login redirect - but not during checkout
        add_filter( 'login_redirect', array( $this, 'handle_login_redirect' ), 10, 3 );
        
        // Handle registration redirect
        add_filter( 'registration_redirect', array( $this, 'handle_registration_redirect' ) );
        
        // Handle logout redirect
        add_filter( 'logout_redirect', array( $this, 'handle_logout_redirect' ), 10, 3 );
        
        // Handle login failures
        add_action( 'wp_login_failed', array( $this, 'handle_login_failed' ) );
        
    }

    /**
     * Check if custom login redirect is enabled.
     *
     * @since 1.0.0
     * @return bool
     */
    private function is_custom_login_enabled() {
        $settings = get_option( 'vrstore_settings', array() );
        return ! empty( $settings['enable_custom_login'] );
    }

    /**
     * Check if this is a checkout-related request.
     *
     * @since 1.0.0
     * @return bool
     */
    private function is_checkout_request() {
        // Check 1: POST action parameter
        if ( isset( $_POST['action'] ) && $_POST['action'] === 'vrstore_process_checkout' ) {
            return true;
        }
        
        // Check 2: Checkout-specific form fields
        if ( isset( $_POST['vrstore_checkout_nonce'] ) || 
             isset( $_POST['vrstore_reg_username'] ) || 
             isset( $_POST['vrstore_reg_email'] ) || 
             isset( $_POST['vrstore_payment_method'] ) ||
             isset( $_POST['vrstore_order_id'] ) ) {
            return true;
        }
        
        // Check 3: Global flag set by checkout process
        if ( defined( 'VRSTORE_CHECKOUT_IN_PROGRESS' ) && VRSTORE_CHECKOUT_IN_PROGRESS ) {
            return true;
        }
        
        // Check 4: Admin post action in URL
        if ( isset( $_GET['action'] ) && $_GET['action'] === 'vrstore_process_checkout' ) {
            return true;
        }
        
        // Check 5: Thank you page parameters in URL
        if ( isset( $_GET['vrstore_order_id'] ) || 
             isset( $_GET['vrstore_success'] ) || 
             isset( $_GET['vrstore_checkout_completed'] ) ) {
            return true;
        }
        
        // Check 6: Session flag (if session is already active)
        if ( session_status() === PHP_SESSION_ACTIVE && 
             isset( $_SESSION['vrstore_checkout_in_progress'] ) && 
             $_SESSION['vrstore_checkout_in_progress'] ) {
            return true;
        }
        
        // Check 7: Referrer contains checkout or cart keywords
        if ( ! empty( $_SERVER['HTTP_REFERER'] ) ) {
            $referer = $_SERVER['HTTP_REFERER'];
            if ( strpos( $referer, 'checkout' ) !== false || 
                 strpos( $referer, 'cart' ) !== false || 
                 strpos( $referer, 'vrstore' ) !== false ) {
                return true;
            }
        }
        
        return false;
    }

    /**
     * Get the custom account page URL.
     *
     * @since 1.0.0
     * @return string|false
     */
    private function get_account_page_url() {
        $settings = get_option( 'vrstore_settings', array() );
        $account_page_id = ! empty( $settings['account_page'] ) ? $settings['account_page'] : '';
        
        if ( $account_page_id ) {
            return get_permalink( $account_page_id );
        }
        
        return false;
    }

    /**
     * Check if user should bypass redirect (admin bypass).
     *
     * @since 1.0.0
     * @return bool
     */
    private function should_bypass_redirect() {
        // Check for admin bypass parameter
        if ( isset( $_GET['admin'] ) && $_GET['admin'] === '1' ) {
            return true;
        }
        
        // Check if user is already logged in and has admin capabilities
        if ( is_user_logged_in() && current_user_can( 'manage_options' ) ) {
            return true;
        }
        
        // Check for AJAX requests
        if ( wp_doing_ajax() ) {
            return true;
        }
        
        // Check for cron requests
        if ( wp_doing_cron() ) {
            return true;
        }
        
        // Check for REST API requests
        if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
            return true;
        }
        
        return false;
    }

    /**
     * Handle login form submission before redirect.
     *
     * @since 1.0.0
     * @return void
     */
    public function handle_login_form_submission() {
        // Only process POST requests (actual form submissions)
        if ( $_SERVER['REQUEST_METHOD'] !== 'POST' ) {
            return;
        }
        
        // Skip if user should bypass redirect
        if ( $this->should_bypass_redirect() ) {
            return;
        }
               
        // Let WordPress handle the actual authentication
        // We'll catch errors in the authenticate filter and login_failed action
        // This method just ensures POST requests don't get redirected
    }
    
    /**
     * Redirect wp-login.php requests to custom account page.
     *
     * @since 1.0.0
     * @return void
     */
    public function redirect_login_page() {
        // Skip if user should bypass redirect
        if ( $this->should_bypass_redirect() ) {
            return;
        }
        
        // Skip if user is already logged in
        if ( is_user_logged_in() ) {
            return;
        }
        
        // Skip for POST requests (form submissions) and AJAX requests
        if ( $_SERVER['REQUEST_METHOD'] === 'POST' || wp_doing_ajax() ) {
            return;
        }
        
        // Skip for specific actions that should use WordPress login
        $allowed_actions = array(
            'lostpassword',
            'retrievepassword', 
            'resetpass',
            'rp',
            'postpass',
            'logout',
            'confirmaction'
        );
        
        $action = isset( $_GET['action'] ) ? $_GET['action'] : '';
        if ( in_array( $action, $allowed_actions ) ) {
            return;
        }
        
        // Skip if this is a login error redirect (to prevent loops)
        if ( isset( $_GET['login'] ) && $_GET['login'] === 'failed' ) {
            return;
        }
        
        // Get custom account page URL
        $account_page_url = $this->get_account_page_url();
        if ( ! $account_page_url ) {
            return;
        }
        
        // Preserve redirect_to parameter for after login
        $redirect_to = isset( $_GET['redirect_to'] ) ? $_GET['redirect_to'] : '';
        if ( $redirect_to ) {
            $account_page_url = add_query_arg( 'redirect_to', urlencode( $redirect_to ), $account_page_url );
        }
        
        // If this is a registration request, show registration form by default
        if ( $action === 'register' ) {
            $account_page_url = add_query_arg( 'action', 'register', $account_page_url );
        }
        
        // Perform redirect
        wp_safe_redirect( $account_page_url );
        exit;
    }

    /**
     * Redirect wp-admin requests for non-logged-in users.
     *
     * @since 1.0.0
     * @return void
     */
    public function redirect_admin_access() {
        // Skip if user should bypass redirect
        if ( $this->should_bypass_redirect() ) {
            return;
        }
        
        // Skip if user is already logged in
        if ( is_user_logged_in() ) {
            return;
        }
        
        // Get custom account page URL
        $account_page_url = $this->get_account_page_url();
        if ( ! $account_page_url ) {
            return;
        }
        
        // Preserve the requested admin URL for after login
        $requested_url = admin_url( basename( $_SERVER['REQUEST_URI'] ) );
        $account_page_url = add_query_arg( 'redirect_to', urlencode( $requested_url ), $account_page_url );
        
        // Perform redirect
        wp_safe_redirect( $account_page_url );
        exit;
    }

    /**
     * Handle login redirect after successful authentication.
     *
     * @since 1.0.0
     * @param string $redirect_to URL to redirect to after login.
     * @param string $request Original requested redirect URL.
     * @param WP_User|WP_Error $user User object or error.
     * @return string
     */
    public function handle_login_redirect( $redirect_to, $request, $user ) {
        // Check if login was successful
        if ( ! is_wp_error( $user ) && is_a( $user, 'WP_User' ) ) {

            
            // Check if this login is happening during checkout process
            // Multiple checks to ensure we catch all checkout scenarios
            $is_checkout = false;
            
            // Check 1: POST action parameter
            if ( isset( $_POST['action'] ) && $_POST['action'] === 'vrstore_process_checkout' ) {
                $is_checkout = true;
            }
            
            // Check 2: Checkout-specific form fields
            if ( isset( $_POST['vrstore_checkout_nonce'] ) || isset( $_POST['vrstore_reg_username'] ) || isset( $_POST['vrstore_reg_email'] ) || isset( $_POST['vrstore_payment_method'] ) ) {
                $is_checkout = true;
            }
            
            // Check 3: Global flag set by checkout process
            if ( defined( 'VRSTORE_CHECKOUT_IN_PROGRESS' ) && VRSTORE_CHECKOUT_IN_PROGRESS ) {
                $is_checkout = true;
            }
            
            // Check 4: Redirect URL contains thank you or order parameters
            if ( ! empty( $redirect_to ) && ( 
                strpos( $redirect_to, 'vrstore_order_id' ) !== false ||
                strpos( $redirect_to, 'vrstore_success' ) !== false ||
                strpos( $redirect_to, 'thank-you' ) !== false ||
                strpos( $redirect_to, 'vrstore_checkout_completed' ) !== false
            )) {
                $is_checkout = true;
            }
            
            // If any checkout condition is met, skip the account redirect
            if ( $is_checkout ) {
                return $redirect_to; // Let checkout handle its own redirect
            }
            
            // Check if we're in a checkout session (legacy support)
            // Only check session if it's already started, don't force start it with different name
            if ( session_status() === PHP_SESSION_ACTIVE && isset( $_SESSION['vrstore_checkout_in_progress'] ) && $_SESSION['vrstore_checkout_in_progress'] ) {
                return $redirect_to;
            }
            
            // Check if we're in a checkout session using session manager
            $checkout_in_progress = false;
            if (class_exists('VRSTORE_Session_Manager')) {
                $session_manager = VRSTORE_Session_Manager::get_instance_if_needed();
                if ($session_manager) {
                    $checkout_in_progress = $session_manager->get_session_data('vrstore_checkout_in_progress', false);
                }
            } else {
                // Fallback using global helper function
                $checkout_in_progress = vrstore_get_session_data('vrstore_checkout_in_progress', false);
            }
            
            if ( $checkout_in_progress ) {
                return $redirect_to;
            }
            
            // If there's a specific redirect request, honor it
            if ( ! empty( $request ) && $request !== admin_url() ) {
                return $request;
            }
            
            // If redirect_to was specified, use it
            if ( ! empty( $_GET['redirect_to'] ) ) {
                return esc_url_raw( $_GET['redirect_to'] );
            }
            
            // For admins, redirect to admin dashboard
            if ( user_can( $user, 'manage_options' ) ) {
                return admin_url();
            }
            
            // For regular users, redirect to vrstore_account page
            $account_page_url = $this->get_account_page_url();
            if ( $account_page_url ) {
                return $account_page_url;
            }
            
            // Fallback: try to find a page with vrstore_account shortcode
            $pages_with_shortcode = get_posts([
                'post_type' => 'page',
                'post_status' => 'publish',
                'meta_query' => [
                    [
                        'key' => '_wp_page_template',
                        'compare' => 'EXISTS'
                    ]
                ],
                's' => '[vrstore_account]',
                'numberposts' => 1
            ]);
            
            if ( !empty($pages_with_shortcode) ) {
                return get_permalink($pages_with_shortcode[0]->ID);
            }
        }
        
        return $redirect_to;
    }

    /**
     * Handle registration redirect.
     *
     * @since 1.0.0
     * @param string $registration_redirect_url URL to redirect to after registration.
     * @return string
     */
    public function handle_registration_redirect( $registration_redirect_url ) {

        
        // Check if this registration is happening during checkout
        // If so, don't interfere with the checkout process
        if ( isset( $_POST['action'] ) && $_POST['action'] === 'vrstore_process_checkout' ) {
            return $registration_redirect_url; // Let checkout handle its own redirect
        }
        
        // Check if we're in a checkout session using session manager
        $checkout_in_progress = false;
        if (class_exists('VRSTORE_Session_Manager')) {
            $session_manager = VRSTORE_Session_Manager::get_instance();
            $checkout_in_progress = $session_manager->get_session_data('vrstore_checkout_in_progress', false);
        } else {
            // Fallback using global helper function
            $checkout_in_progress = vrstore_get_session_data('vrstore_checkout_in_progress', false);
        }
        
        if ( $checkout_in_progress ) {
            return $registration_redirect_url;
        }
        
        // Get custom account page URL
        $account_page_url = $this->get_account_page_url();
        if ( $account_page_url ) {
            // Add success message parameter
            $account_page_url = add_query_arg( 'registration', 'success', $account_page_url );
            

            
            return $account_page_url;
        }
        
        return $registration_redirect_url;
    }

    /**
     * Handle logout redirect.
     *
     * @since 1.0.0
     * @param string $logout_url URL to redirect to after logout.
     * @param string $requested_redirect_to Original requested redirect URL.
     * @param WP_User $user User object.
     * @return string
     */
    public function handle_logout_redirect( $logout_url, $requested_redirect_to, $user ) {
        // If a specific redirect was requested, honor it
        if ( ! empty( $requested_redirect_to ) ) {
            return $requested_redirect_to;
        }
        
        // Get custom account page URL
        $account_page_url = $this->get_account_page_url();
        if ( $account_page_url ) {
            // Add logout message parameter
            $account_page_url = add_query_arg( 'logged_out', 'true', $account_page_url );
            return $account_page_url;
        }
        
        return $logout_url;
    }

    /**
     * Handle login failures.
     *
     * @since 1.0.0
     * @param string $username The username used in the login attempt.
     * @return void
     */
    public function handle_login_failed( $username ) {
        // Only handle if this was a POST request (actual login attempt)
        if ( $_SERVER['REQUEST_METHOD'] !== 'POST' ) {
            return;
        }
        
        // Skip if user should bypass redirect
        if ( $this->should_bypass_redirect() ) {
            return;
        }
        
        // Get custom account page URL
        $account_page_url = $this->get_account_page_url();
        if ( ! $account_page_url ) {
            return;
        }
        

        
        // Add error message to the redirect
        $error_message = __( 'Invalid username or password. Please try again.', 'vira-store' );
        
        
        $account_page_url = add_query_arg( 'login_error', urlencode( $error_message ), $account_page_url );
        
        // Preserve redirect_to if it exists
        if ( ! empty( $_POST['redirect_to'] ) ) {
            $account_page_url = add_query_arg( 'redirect_to', urlencode( $_POST['redirect_to'] ), $account_page_url );
        }
        
        // Redirect to custom account page with error
        wp_safe_redirect( $account_page_url );
        exit;
    }
    

    /**
     * Get admin bypass URL for emergencies.
     *
     * @since 1.0.0
     * @return string
     */
    public static function get_admin_bypass_url() {
        return admin_url( '?admin=1' );
    }
}
