<?php
/**
 * License class
 *
 * @package Vira_Store
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Digital product licensing system
 */
class VRSTORE_License {
    /**
     * Singleton instance
     *
     * @var VRSTORE_License|null
     */
    private static ?VRSTORE_License $instance = null;

    /**
     * Standard expiry field name
     */
    const EXPIRY_FIELD = 'expires_at';

    /**
     * License prefix
     *
     * @var string
     */
    private string $prefix;

    /**
     * Get singleton instance
     *
     * @return VRSTORE_License
     */
    public static function get_instance(): VRSTORE_License {
        if (null === self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        // Get license prefix from settings
        $settings = get_option('vrstore_settings', []);
        $this->prefix = $settings['license_prefix'] ?? 'VRST-';

        // Legacy post type registration removed - using table-based system only

        // Add license key generation on product purchase
        add_action('vrstore_product_purchased', [$this, 'generate_license_on_purchase'], 10, 2);
        
        // Add license key generation when an order is completed
        add_action('vrstore_order_completed', [$this, 'generate_license_on_order_completion'], 10, 2);
    }

    /**
     * Standardize license key format
     *
     * @param string $key License key
     * @return string Standardized license key
     */
    public static function standardize_license_key(string $key): string {
        return strtoupper(trim($key));
    }

    /**
     * Validate license key format
     *
     * @param string $license_key License key to validate
     * @return bool True if valid format
     */
    public function validate_license_key_format(string $license_key): bool {
        // Standardize first
        $license_key = self::standardize_license_key($license_key);
        
        // Check length
        if (strlen($license_key) < 10 || strlen($license_key) > 100) {
            return false;
        }
        
        // Check format pattern (with or without prefix)
        // Format: [PREFIX-]XXXXX-XXXXX-XXXXX-XXXXX-XXXXX
        $pattern = '/^([A-Z0-9]+-)?[A-Z0-9]{5}-[A-Z0-9]{5}-[A-Z0-9]{5}-[A-Z0-9]{5}-[A-Z0-9]{5}$/';
        return preg_match($pattern, $license_key) === 1;
    }

    // Legacy post type registration method removed

    // Legacy meta box methods removed - using table-based system only

    // Legacy save_meta_boxes method removed - using table-based system only

    /**
     * Add license columns
     *
     * @param array $columns Columns
     * @return array
     */
    public function add_license_columns(array $columns): array {
        $date_column = $columns['date'] ?? '';
        unset($columns['date']);

        $columns['license_key'] = __('License Key', 'vira-store');
        $columns['product'] = __('Product', 'vira-store');
        $columns['user'] = __('User', 'vira-store');
        $columns['status'] = __('Status', 'vira-store');
        $columns['expiry_date'] = __('Expiry Date', 'vira-store');
        $columns['activations'] = __('Activations', 'vira-store');

        if ($date_column) {
            $columns['date'] = $date_column;
        }

        return $columns;
    }

    // Legacy render_license_columns method removed - using table-based system only

    /**
     * Generate license key with checksum
     *
     * @param int $product_id Product ID for checksum generation
     * @return string
     */
    public function generate_license_key(int $product_id = 0): string {
        $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $max_attempts = 100; // Prevent infinite loop
        $attempt = 0;

        // Generate unique license key (check for duplicates)
        global $wpdb;
        $licenses_table = $wpdb->prefix . 'vrstore_licenses';

        do {
            $attempt++;

            // Generate 4 groups of 5 characters
            $part1 = '';
            $part2 = '';
            $part3 = '';
            $part4 = '';

            for ($i = 0; $i < 5; $i++) {
                $part1 .= $characters[wp_rand(0, strlen($characters) - 1)];
            }
            for ($i = 0; $i < 5; $i++) {
                $part2 .= $characters[wp_rand(0, strlen($characters) - 1)];
            }
            for ($i = 0; $i < 5; $i++) {
                $part3 .= $characters[wp_rand(0, strlen($characters) - 1)];
            }
            for ($i = 0; $i < 5; $i++) {
                $part4 .= $characters[wp_rand(0, strlen($characters) - 1)];
            }

            // Calculate checksum (5th segment)
            $checksum = $this->calculate_checksum($part1, $part2, $part3, $part4, $product_id);

            // Combine into full key (no prefix, just 5 segments)
            $temp_key = "{$part1}-{$part2}-{$part3}-{$part4}-{$checksum}";
            
            // Prepend prefix if available
            $license_key = $temp_key;
            if (!empty($this->prefix)) {
                $license_key = $this->prefix . $temp_key;
            }

            // Check if key already exists (only if table exists)
            $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$licenses_table'") === $licenses_table;
            if ($table_exists) {
                $exists = $wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM $licenses_table WHERE license_key = %s",
                    $license_key
                ));

                if (!$exists) {
                    return $license_key;
                }
            } else {
                // If table doesn't exist, just return the generated key
                return $license_key;
            }
        } while ($attempt < $max_attempts);

        // Fallback: append timestamp to ensure uniqueness
        $license_key = $license_key . '-' . substr(time(), -4);
        error_log('ViraStore: License key generation exceeded max attempts, used timestamp fallback');

        return $license_key;
    }

    /**
     * Calculate checksum for license key validation
     * SERVER-SIDE ONLY - Never expose in distributed plugins
     *
     * @param string $part1 First segment
     * @param string $part2 Second segment
     * @param string $part3 Third segment
     * @param string $part4 Fourth segment
     * @param int $product_id Product ID
     * @return string 5-character checksum
     */
    private function calculate_checksum(string $part1, string $part2, string $part3, string $part4, int $product_id = 0): string {
        // Get product slug for salt
        $product_slug = 'vrstore';
        if ($product_id > 0) {
            $product = get_post($product_id);
            if ($product && isset($product->post_name)) {
                $product_slug = $product->post_name;
            }
        }

        // Product-specific salt (keep secret)
        $salt = 'VRSTORE_' . strtoupper($product_slug) . '_SECRET_SALT_v1';

        // Combine parts with salt
        $combined = $part1 . $part2 . $part3 . $part4 . $salt;

        // Generate hash
        $hash = strtoupper(md5($combined));

        // Return first 5 characters as checksum
        return substr($hash, 0, 5);
    }

    /**
     * Verify license key checksum
     * SERVER-SIDE ONLY - Never expose in client plugins
     *
     * @param string $license_key License key to verify
     * @param int $product_id Product ID (required for security)
     * @return bool True if checksum is valid
     */
    public function verify_checksum(string $license_key, int $product_id = 0): bool {
        // Standardize license key
        $license_key = self::standardize_license_key($license_key);
        
        // Remove prefix if present to get the core key parts
        // Core format: XXXXX-XXXXX-XXXXX-XXXXX-CCCCC (5 segments of 5 uppercase alphanumeric chars)
        
        // First, try to match the core pattern anywhere in the string
        if (preg_match('/([A-Z0-9]{5})-([A-Z0-9]{5})-([A-Z0-9]{5})-([A-Z0-9]{5})-([A-Z0-9]{5})$/', $license_key, $matches)) {
            // Extract parts
            $part1 = $matches[1];
            $part2 = $matches[2];
            $part3 = $matches[3];
            $part4 = $matches[4];
            $checksum = $matches[5];
        } else {
            return false;
        }

        // Calculate expected checksum with provided product_id
        $expected_checksum = $this->calculate_checksum($part1, $part2, $part3, $part4, $product_id);

        // Verify checksum matches
        return $checksum === $expected_checksum;
    }

    /**
     * Generate license on product purchase
     *
     * @param int $product_id Product ID
     * @param int $user_id    User ID
     * @param string $license_type_slug Optional license type slug
     * @return int|WP_Error
     */
    public function generate_license_on_purchase(int $product_id, int $user_id, string $license_type_slug = '') {
        // Check if license generation is disabled for this product
        $disable_license_generation = get_post_meta($product_id, '_vrstore_disable_license_generation', true);
        if ($disable_license_generation) {
            return new WP_Error('license_disabled', __('License generation is disabled for this product.', 'vira-store'));
        }
        
        // Get product
        $product = get_post($product_id);

        if (!$product || $product->post_type !== 'vrstore_product') {
            return new WP_Error('invalid_product', __('Invalid product.', 'vira-store'));
        }

        // Get user
        $user = get_user_by('id', $user_id);

        if (!$user) {
            return new WP_Error('invalid_user', __('Invalid user.', 'vira-store'));
        }

        // Generate license key with product ID for checksum
        $license_key = $this->generate_license_key($product_id);

        // Get license type-specific configuration using slug directly
        $license_config = $this->get_license_type_config($product_id, $license_type_slug);
        
        // Set expiry date based on license type configuration
        $expiry_date = $this->calculate_expiry_date($license_config['expiry_days']);
        
        // Create license in database table
        global $wpdb;
        $licenses_table = $wpdb->prefix . 'vrstore_licenses';
        
        $result = $wpdb->insert(
            $licenses_table,
            [
                'license_key' => $license_key,
                'product_id' => $product_id,
                'customer_id' => $user_id,
                'customer_email' => $user->user_email,
                'status' => 'active',
                'activation_limit' => $license_config['activation_limit'],
                'activation_count' => 0,
                'expires_at' => $expiry_date,
                'license_type_slug' => $license_type_slug,
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql')
            ],
            ['%s', '%d', '%d', '%s', '%s', '%d', '%d', '%s', '%s', '%s', '%s']
        );
        
        if ($result === false) {
            return new WP_Error('license_creation_failed', __('Failed to create license.', 'vira-store'));
        }
        
        return $wpdb->insert_id;
    }

    /**
     * Generate license on order completion
     *
     * @param int $order_id Order ID
     * @param array $order_data Order data
     * @return void
     */
    public function generate_license_on_order_completion(int $order_id, array $order_data): void {
        // Validate order data
        if (empty($order_data) || empty($order_data['customer_email'])) {
            return;
        }
        
        // Skip license generation if no product_id is provided (for Extended Support and other special cases)
        if (empty($order_data['product_id'])) {
            return;
        }
        
        $product_id = intval($order_data['product_id']);
        $customer_email = sanitize_email($order_data['customer_email']);
        $license_type_slug = sanitize_text_field($order_data['license_type'] ?? '');
        
        // Skip license generation for Extended Support orders
        // Check for Extended Support indicators: item_type or product_id = 0
        if (isset($order_data['item_type']) && $order_data['item_type'] === 'extended_support') {
            return;
        }
        
        if ($product_id === 0) {
            // Product ID of 0 typically indicates Extended Support or other special products
            return;
        }
        
        // Check if license generation is disabled for this product
        $disable_license_generation = get_post_meta($product_id, '_vrstore_disable_license_generation', true);
        if ($disable_license_generation) {
            return;
        }
        
        // Get or create user from customer email
        $user = get_user_by('email', $customer_email);
        if (!$user) {
            // Create a new user if one doesn't exist
            $user_id = wp_create_user($customer_email, wp_generate_password(), $customer_email);
            if (is_wp_error($user_id)) {
                return;
            }
            $user_id = intval($user_id);
        } else {
            $user_id = $user->ID;
        }
        
        // Check if license already exists for this specific order only (prevent double creation for same order)
        global $wpdb;
        $licenses_table = $wpdb->prefix . 'vrstore_licenses';
        $existing_license = false;
        
        if ($wpdb->get_var("SHOW TABLES LIKE '$licenses_table'") === $licenses_table) {
            // Only check if license already exists for this specific order to prevent duplicate creation
            $existing_license = $wpdb->get_row($wpdb->prepare(
                "SELECT id FROM $licenses_table WHERE order_id = %d",
                $order_id
            ));
            
            // UNLIMITED REORDERS: Removed customer/product duplicate checking
            // This allows customers to freely purchase multiple licenses for the same product
        }
        
        if ($existing_license) {
            // License already exists (either for this order or for this customer/product), skipping generation
            return;
        }
        
        // Try to create license using database table first (if available)
        // IMPORTANT: Pass product_id to generate_license_key for correct checksum calculation
        $license_key = $this->generate_license_key($product_id);
        $license_id = false;
        
        if ($wpdb->get_var("SHOW TABLES LIKE '$licenses_table'") === $licenses_table) {
            // Get license configuration based on license type
            $license_config = $this->get_license_type_config($product_id, $license_type_slug);
            $expires_at = '';
            if (!empty($license_config['expiry_days']) && $license_config['expiry_days'] > 0) {
                $expires_at = $this->calculate_expiry_date($license_config['expiry_days']);
            }
            
            // Use proper activation limit from license type config
            $activation_limit = $license_config['activation_limit'] ?? 1;
            
            $license_data = [
                'license_key' => $license_key,
                'product_id' => $product_id,
                'order_id' => $order_id,
                'customer_email' => $customer_email,
                'activation_limit' => $activation_limit, // Use proper activation limit from license type
                'status' => 'active',
                'license_type_slug' => $license_type_slug,
                'expires_at' => $expires_at
            ];
            
            $license_id = $this->create_license($license_data);
        }
        
        // Table-based license creation only - no fallback needed
        
        if ($license_id && !is_wp_error($license_id)) {
            // Fire action to allow other plugins to hook into license creation
            do_action('vrstore_license_created', $license_id, $order_id, $order_data);
        }
    }

    /**
     * Validate license
     *
     * @param string $license_key License key
     * @param int $product_id Optional product ID to validate against (0 = any product)
     * @return array
     */
    public function validate_license(string $license_key, int $product_id = 0): array {
        // Standardize and validate license key input
        $license_key = self::standardize_license_key($license_key);
        
        if (empty($license_key)) {
            return [
                'valid' => false,
                'message' => __('License key cannot be empty.', 'vira-store'),
            ];
        }
        
        // Validate format
        if (!$this->validate_license_key_format($license_key)) {
            return [
                'valid' => false,
                'message' => __('Invalid license key format.', 'vira-store'),
            ];
        }
        
        global $wpdb;
        $licenses_table = $wpdb->prefix . 'vrstore_licenses';
        
        // Check if table exists
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$licenses_table'") === $licenses_table;
        if (!$table_exists) {
            return [
                'valid' => false,
                'message' => __('License system not properly initialized.', 'vira-store'),
            ];
        }
        
        // Get license by key from table - include product_id check if provided
        if ($product_id > 0) {
            $license = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $licenses_table WHERE license_key = %s AND product_id = %d",
                $license_key,
                $product_id
            ));
            
            if (!$license) {
                return [
                    'valid' => false,
                    'message' => __('Invalid license key for this product.', 'vira-store'),
                ];
            }
        } else {
            // If no product_id specified, check license exists but warn if product_id is missing
            $license = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $licenses_table WHERE license_key = %s",
                $license_key
            ));

            if (!$license) {
                return [
                    'valid' => false,
                    'message' => __('Invalid license key.', 'vira-store'),
                ];
            }
        }

        $license_id = $license->id;
        $status = $license->status ?: 'active';
        // Use standardized expiry field
        $expiry_date = $license->{self::EXPIRY_FIELD} ?? null;
        $activation_limit = isset($license->activation_limit) ? intval($license->activation_limit) : 1;
        $activation_count = isset($license->activation_count) ? intval($license->activation_count) : 0;
        $product_id = isset($license->product_id) ? intval($license->product_id) : 0;

        // Check if license is active
        if ($status !== 'active') {
            return [
                'valid' => false,
                'message' => __('License is not active.', 'vira-store'),
            ];
        }

        // Check if license has expired
        if (!empty($expiry_date) && $expiry_date !== '0000-00-00' && $expiry_date !== '0000-00-00 00:00:00') {
            $expiry_timestamp = strtotime($expiry_date);
            if ($expiry_timestamp !== false && $expiry_timestamp < time()) {
                // Update status to expired (only update if not already expired to prevent recursion)
                if ($status !== 'expired') {
                    $wpdb->update(
                        $licenses_table,
                        ['status' => 'expired', 'updated_at' => current_time('mysql')],
                        ['id' => $license_id],
                        ['%s', '%s'],
                        ['%d']
                    );
                }

                return [
                    'valid' => false,
                    'message' => __('License has expired.', 'vira-store'),
                ];
            }
        }

        // Check if license has reached activation limit
        if ($activation_count >= $activation_limit && $activation_limit > 0) {
            return [
                'valid' => false,
                'message' => __('License has reached activation limit.', 'vira-store'),
            ];
        }

        // Get product details from license record (not from parameter)
        $product = null;
        $license_product_id = isset($license->product_id) ? intval($license->product_id) : 0;
        $license_type_slug = isset($license->license_type_slug) ? $license->license_type_slug : '';
        
        if ($license_product_id > 0) {
            $product_post = get_post($license_product_id);
            if ($product_post && $product_post->post_type === 'vrstore_product') {
                $product = [
                    'id' => $license_product_id,
                    'title' => $product_post->post_title,
                ];
            }
        }
        
        // Get license tier information if license_type_slug is available
        $license_tier = null;
        if (!empty($license_type_slug)) {
            $license_tier = $this->get_license_tier_info($license_type_slug);
        }

        return [
            'valid' => true,
            'message' => __('License is valid.', 'vira-store'),
            'license_id' => $license_id,
            'status' => $status,
            'expiry_date' => $expiry_date,
            'activation_limit' => $activation_limit,
            'activation_count' => $activation_count,
            'license_type_slug' => $license_type_slug,
            'license_tier' => $license_tier,
            'product' => $product,
            'product_id' => $license_product_id, // Include product_id in response
        ];
    }

    /**
     * Validate license key for specific product with license tier support
     *
     * @since 1.9.0
     * @param string $license_key License key
     * @param int $product_id Product ID
     * @return array
     */
    public function validate_license_key(string $license_key, int $product_id): array {
        // Sanitize and validate inputs
        $license_key = sanitize_text_field(trim($license_key));
        $product_id = absint($product_id);
        
        if (empty($license_key)) {
            return [
                'valid' => false,
                'message' => __('License key cannot be empty.', 'vira-store'),
            ];
        }
        
        if ($product_id <= 0) {
            return [
                'valid' => false,
                'message' => __('Invalid product ID.', 'vira-store'),
            ];
        }
        
        global $wpdb;
        $licenses_table = $wpdb->prefix . 'vrstore_licenses';
        
        // Check if table exists
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$licenses_table'") === $licenses_table;
        if (!$table_exists) {
            return [
                'valid' => false,
                'message' => __('License system not properly initialized.', 'vira-store'),
            ];
        }
        
        // Get license by key and product from table
        $license = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $licenses_table WHERE license_key = %s AND product_id = %d",
            $license_key,
            $product_id
        ));

        if (!$license) {
            return [
                'valid' => false,
                'message' => __('Invalid license key for this product.', 'vira-store'),
            ];
        }

        $license_id = $license->id;
        $status = $license->status ?: 'active';
        // Use standardized expiry field
        $expiry_date = $license->{self::EXPIRY_FIELD} ?? null;
        $activation_limit = isset($license->activation_limit) ? intval($license->activation_limit) : 1;
        $activation_count = isset($license->activation_count) ? intval($license->activation_count) : 0;
        $license_type_slug = $license->license_type_slug ?: 'basic';

        // Check if license is active
        if ($status !== 'active') {
            return [
                'valid' => false,
                'message' => __('License is not active.', 'vira-store'),
            ];
        }

        // Check if license has expired
        if (!empty($expiry_date) && $expiry_date !== '0000-00-00' && $expiry_date !== '0000-00-00 00:00:00') {
            $expiry_timestamp = strtotime($expiry_date);
            if ($expiry_timestamp !== false && $expiry_timestamp < time()) {
                // Update status to expired (only update if not already expired)
                if ($status !== 'expired') {
                    $wpdb->update(
                        $licenses_table,
                        ['status' => 'expired', 'updated_at' => current_time('mysql')],
                        ['id' => $license_id],
                        ['%s', '%s'],
                        ['%d']
                    );
                }

                return [
                    'valid' => false,
                    'message' => __('License has expired.', 'vira-store'),
                ];
            }
        }

        // Get license tier information
        $license_tier = $this->get_license_tier_info($license_type_slug);

        // Get product details
        $product = null;
        if ($product_id > 0) {
            $product_post = get_post($product_id);
            if ($product_post && $product_post->post_type === 'vrstore_product') {
                $product = [
                    'id' => $product_id,
                    'title' => $product_post->post_title,
                ];
            }
        }

        return [
            'valid' => true,
            'message' => __('License is valid.', 'vira-store'),
            'license_id' => $license_id,
            'status' => $status,
            'expiry_date' => $expiry_date,
            'activation_limit' => $activation_limit,
            'activation_count' => $activation_count,
            'license_type_slug' => $license_type_slug,
            'license_tier' => $license_tier,
            'product' => $product,
        ];
    }

    /**
     * Get license tier information
     *
     * @since 1.9.0
     * @param string $license_type_slug License type slug
     * @return array
     */
    public function get_license_tier_info(string $license_type_slug): array {
        // Default tier information
        $default_tier = [
            'name' => 'Basic',
            'slug' => 'basic',
            'priority' => 1,
            'update_access' => ['basic']
        ];

        if (empty($license_type_slug)) {
            return $default_tier;
        }

        // Get custom license types from settings
        $settings = get_option('vrstore_settings', []);
        $custom_license_types = $settings['custom_license_types'] ?? [];

        foreach ($custom_license_types as $type) {
            $slug = $type['slug'] ?? sanitize_title($type['label'] ?? '');
            
            if ($slug === $license_type_slug) {
                // Determine tier priority and update access based on license type
                $tier_info = [
                    'name' => $type['label'] ?? ucfirst($slug),
                    'slug' => $slug,
                    'priority' => $this->get_tier_priority($slug),
                    'update_access' => $this->get_update_access_levels($slug)
                ];

                return $tier_info;
            }
        }

        // Fallback to basic tier if license type not found
        return $default_tier;
    }

    /**
     * Get tier priority for license type
     *
     * @since 1.9.0
     * @param string $license_type_slug License type slug
     * @return int
     */
    private function get_tier_priority(string $license_type_slug): int {
        // Define tier priorities (higher number = higher tier)
        $tier_priorities = [
            'basic' => 1,
            'standard' => 2,
            'pro' => 3,
            'premium' => 4,
            'developer' => 5,
            'enterprise' => 6
        ];

        // Check for common tier keywords in the slug
        $slug_lower = strtolower($license_type_slug);
        
        foreach ($tier_priorities as $tier => $priority) {
            if (strpos($slug_lower, $tier) !== false) {
                return $priority;
            }
        }

        // Default to basic tier priority
        return 1;
    }

    /**
     * Get update access levels for license type
     *
     * @since 1.9.0
     * @param string $license_type_slug License type slug
     * @return array
     */
    private function get_update_access_levels(string $license_type_slug): array {
        $slug_lower = strtolower($license_type_slug);
        
        // Define access levels based on license type
        if (strpos($slug_lower, 'enterprise') !== false || strpos($slug_lower, 'developer') !== false) {
            return ['basic', 'standard', 'pro', 'premium', 'developer', 'enterprise'];
        } elseif (strpos($slug_lower, 'premium') !== false) {
            return ['basic', 'standard', 'pro', 'premium'];
        } elseif (strpos($slug_lower, 'pro') !== false) {
            return ['basic', 'standard', 'pro'];
        } elseif (strpos($slug_lower, 'standard') !== false) {
            return ['basic', 'standard'];
        } else {
            return ['basic'];
        }
    }

    /**
     * Activate license (FIXED - Race condition prevention + product validation)
     *
     * @param string $license_key License key
     * @param string $site_url    Site URL
     * @param int $product_id      Product ID (REQUIRED for security)
     * @return array
     */
    public function activate_license(string $license_key, string $site_url, int $product_id): array {
        // Standardize and sanitize inputs
        $license_key = self::standardize_license_key($license_key);
        $site_url = VRSTORE_License_Helper::normalize_site_url($site_url);
        $product_id = absint($product_id);
        
        if (empty($license_key) || empty($site_url)) {
            return [
                'valid' => false,
                'message' => __('License key and site URL are required.', 'vira-store'),
            ];
        }
        
        // CRITICAL: Validate product exists and is purchasable
        if ($product_id <= 0 || !VRSTORE_License_Helper::validate_product_exists($product_id)) {
            return [
                'valid' => false,
                'message' => __('Invalid product ID.', 'vira-store'),
            ];
        }
        
        // Validate license key format
        if (!$this->validate_license_key_format($license_key)) {
            return [
                'valid' => false,
                'message' => __('Invalid license key format.', 'vira-store'),
            ];
        }
        
        global $wpdb;
        $licenses_table = $wpdb->prefix . 'vrstore_licenses';
        $activations_table = $wpdb->prefix . 'vrstore_license_activations';

        // START TRANSACTION FIRST (prevents race conditions)
        $wpdb->query('START TRANSACTION');
        
        try {
            // Get license with exclusive lock FIRST
            $license = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $licenses_table WHERE license_key = %s FOR UPDATE",
                $license_key
            ), ARRAY_A);
            
            if (!$license) {
                $wpdb->query('ROLLBACK');
                return [
                    'valid' => false,
                    'message' => __('Invalid license key.', 'vira-store'),
                ];
            }
            
            // CRITICAL: Validate product binding
            if (!VRSTORE_License_Helper::validate_license_product_binding($license_key, $product_id)) {
                $wpdb->query('ROLLBACK');
                return [
                    'valid' => false,
                    'message' => __('This license key is not valid for this product.', 'vira-store'),
                ];
            }
            
            // Check license status
            if ($license->status !== 'active') {
                $wpdb->query('ROLLBACK');
                return [
                    'valid' => false,
                    'message' => __('License is not active.', 'vira-store'),
                ];
            }
            
            // Check expiry using helper
            $expiry_date = VRSTORE_License_Helper::get_expiry_date($license);
            if ($expiry_date) {
                $expiry_timestamp = strtotime($expiry_date);
                if ($expiry_timestamp !== false && $expiry_timestamp < time()) {
                    $wpdb->query('ROLLBACK');
                    return [
                        'valid' => false,
                        'message' => __('License has expired.', 'vira-store'),
                    ];
                }
            }
            
            $license_id = $license->id;
            $activation_limit = intval($license->activation_limit) ?: 1;
            $activation_count = intval($license->activation_count) ?: 0;
            
            // Check activation limit with locked data
            if ($activation_count >= $activation_limit && $activation_limit > 0) {
                $wpdb->query('ROLLBACK');
                return [
                    'valid' => false,
                    'message' => __('License has reached activation limit.', 'vira-store'),
                ];
            }

        // Check if activations table exists, if not create it
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$activations_table'") === $activations_table;
        
            // Check which column names exist in the table (handle schema differences)
            $date_column = 'activation_date'; // Default old schema
            $ip_column = 'activation_ip'; // Default old schema
            
            if ($table_exists) {
                // Check which columns exist
                $columns = $wpdb->get_col("SHOW COLUMNS FROM $activations_table");
                
                // Use newer schema if activated_at exists
                if (in_array('activated_at', $columns, true)) {
                    $date_column = 'activated_at';
                }
                
                // Use newer schema if ip_address exists
                if (in_array('ip_address', $columns, true)) {
                    $ip_column = 'ip_address';
                }
            } else {
                // Create table with newer schema (matches class-database.php)
                require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
                $charset_collate = $wpdb->get_charset_collate();
                $sql = "CREATE TABLE $activations_table (
                    id bigint(20) NOT NULL AUTO_INCREMENT,
                    license_id bigint(20) NOT NULL,
                    license_key varchar(100) NOT NULL,
                    site_url varchar(500) NOT NULL,
                    site_name varchar(200) DEFAULT '',
                    activation_token varchar(100) NOT NULL,
                    status varchar(20) DEFAULT 'active',
                    user_agent text DEFAULT '',
                    ip_address varchar(45) DEFAULT '',
                    activated_at datetime DEFAULT CURRENT_TIMESTAMP,
                    deactivated_at datetime NULL,
                    last_check datetime DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (id),
                    KEY license_id (license_id),
                    KEY license_key (license_key),
                    KEY site_url (site_url(255)),
                    KEY activation_token (activation_token),
                    KEY status (status),
                    KEY activated_at (activated_at)
                ) $charset_collate;";
                dbDelta($sql);
                
                // Verify table was created
                $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$activations_table'") === $activations_table;
                if (!$table_exists) {
                    $wpdb->query('ROLLBACK');
                    return [
                        'valid' => false,
                        'message' => __('Failed to initialize activation system.', 'vira-store'),
                    ];
                }
                
                // Set columns to new schema
                $date_column = 'activated_at';
                $ip_column = 'ip_address';
            }

            // Check if site is already activated (with lock)
            $existing_activation = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $activations_table WHERE license_id = %d AND site_url = %s FOR UPDATE",
                $license_id,
                $site_url
            ));

            if ($existing_activation) {
                $wpdb->query('COMMIT');
                // Handle both schema versions
                $activation_date_value = $existing_activation->{$date_column} ?? $existing_activation->activation_date ?? $existing_activation->activated_at ?? '';
                $activation_ip_value = $existing_activation->{$ip_column} ?? $existing_activation->activation_ip ?? $existing_activation->ip_address ?? '';
                
                return [
                    'valid' => true,
                    'message' => __('License is already activated for this site.', 'vira-store'),
                    'activation' => [
                        'site_url' => $existing_activation->site_url,
                        'activation_date' => $activation_date_value,
                        'activation_ip' => $activation_ip_value,
                    ],
                ];
            }

            // Sanitize IP address
            $activation_ip = '';
            if (isset($_SERVER['REMOTE_ADDR'])) {
                $activation_ip = sanitize_text_field($_SERVER['REMOTE_ADDR']);
            }

            // Add new activation - use correct column names based on schema
            $activation_data = [
                'license_id' => $license_id,
                'site_url' => $site_url,
            ];
            
            // Add date column (use correct name based on schema)
            $activation_data[$date_column] = current_time('mysql');
            
            // Add IP column (use correct name based on schema)
            $activation_data[$ip_column] = $activation_ip;
            
            // Add additional columns if they exist (newer schema)
            $columns = $wpdb->get_col("SHOW COLUMNS FROM $activations_table");
            if (in_array('license_key', $columns, true)) {
                // Get license key from license record
                $license_key_from_db = $wpdb->get_var($wpdb->prepare(
                    "SELECT license_key FROM $licenses_table WHERE id = %d",
                    $license_id
                ));
                if ($license_key_from_db) {
                    $activation_data['license_key'] = $license_key_from_db;
                }
            }
            if (in_array('status', $columns, true)) {
                $activation_data['status'] = 'active';
            }
            if (in_array('activation_token', $columns, true)) {
                $activation_data['activation_token'] = wp_generate_password(32, false);
            }

            // Build format array dynamically
            $format_array = ['%d', '%s']; // license_id, site_url
            $format_array[] = '%s'; // date column
            $format_array[] = '%s'; // ip column
            if (isset($activation_data['license_key'])) {
                $format_array[] = '%s'; // license_key
            }
            if (isset($activation_data['status'])) {
                $format_array[] = '%s'; // status
            }
            if (isset($activation_data['activation_token'])) {
                $format_array[] = '%s'; // activation_token
            }

            $insert_result = $wpdb->insert(
                $activations_table,
                $activation_data,
                $format_array
            );
            
            if ($insert_result === false) {
                $wpdb->query('ROLLBACK');
                error_log('ViraStore: Failed to insert activation: ' . $wpdb->last_error);
                return [
                    'valid' => false,
                    'message' => __('Failed to activate license.', 'vira-store'),
                ];
            }

            // Atomically increment activation count
            $update_result = $wpdb->query($wpdb->prepare(
                "UPDATE $licenses_table SET activation_count = activation_count + 1, updated_at = %s WHERE id = %d",
                current_time('mysql'),
                $license_id
            ));
            
            if ($update_result === false) {
                $wpdb->query('ROLLBACK');
                error_log('ViraStore: Failed to update activation count: ' . $wpdb->last_error);
                return [
                    'valid' => false,
                    'message' => __('Failed to update license activation count.', 'vira-store'),
                ];
            }
            
            $wpdb->query('COMMIT');
            
            return [
                'valid' => true,
                'message' => __('License activated successfully.', 'vira-store'),
                'activation' => [
                    'site_url' => $site_url,
                    'activation_date' => $activation_data[$date_column],
                    'activation_ip' => $activation_data[$ip_column],
                ],
            ];
        } catch (Exception $e) {
            $wpdb->query('ROLLBACK');
            error_log('ViraStore: License activation exception: ' . $e->getMessage());
            return [
                'valid' => false,
                'message' => __('An error occurred during license activation.', 'vira-store'),
            ];
        }
    }

    /**
     * Deactivate license (FIXED - URL normalization + product validation)
     *
     * @param string $license_key License key
     * @param string $site_url    Site URL
     * @param int $product_id      Product ID (REQUIRED for security)
     * @return array
     */
    public function deactivate_license(string $license_key, string $site_url, int $product_id): array {
        // Sanitize inputs
        $license_key = self::standardize_license_key($license_key);
        $site_url = VRSTORE_License_Helper::normalize_site_url($site_url);
        $product_id = absint($product_id);
        
        if (empty($license_key) || empty($site_url)) {
            return [
                'valid' => false,
                'message' => __('License key and site URL are required.', 'vira-store'),
            ];
        }
        
        global $wpdb;
        $licenses_table = $wpdb->prefix . 'vrstore_licenses';
        $activations_table = $wpdb->prefix . 'vrstore_license_activations';
        
        // Check if tables exist
        $licenses_table_exists = $wpdb->get_var("SHOW TABLES LIKE '$licenses_table'") === $licenses_table;
        $activations_table_exists = $wpdb->get_var("SHOW TABLES LIKE '$activations_table'") === $activations_table;
        
        if (!$licenses_table_exists || !$activations_table_exists) {
            return [
                'valid' => false,
                'message' => __('License system not properly initialized.', 'vira-store'),
            ];
        }
        
        // Check which column names exist in the activations table (handle schema differences)
        $date_column = 'activation_date'; // Default old schema
        $ip_column = 'activation_ip'; // Default old schema
        
        if ($activations_table_exists) {
            $columns = $wpdb->get_col("SHOW COLUMNS FROM $activations_table");
            
            // Use newer schema if activated_at exists
            if (in_array('activated_at', $columns, true)) {
                $date_column = 'activated_at';
            }
            
            // Use newer schema if ip_address exists
            if (in_array('ip_address', $columns, true)) {
                $ip_column = 'ip_address';
            }
        }
        
        // Get license by key from table - include product_id check if provided
        if ($product_id > 0) {
            $license = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $licenses_table WHERE license_key = %s AND product_id = %d",
                $license_key,
                $product_id
            ));

            if (!$license) {
                return [
                    'valid' => false,
                    'message' => __('Invalid license key for this product.', 'vira-store'),
                ];
            }
        } else {
            // If no product_id specified, check license exists
            $license = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $licenses_table WHERE license_key = %s",
                $license_key
            ));

            if (!$license) {
                return [
                    'valid' => false,
                    'message' => __('Invalid license key.', 'vira-store'),
                ];
            }
        }

        $license_id = $license->id;

        // Normalize site URL for matching (remove trailing slash, convert to lowercase)
        $normalized_site_url = rtrim(strtolower($site_url), '/');
        
        // Check if site is activated - try exact match first
        $activation = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $activations_table WHERE license_id = %d AND site_url = %s",
            $license_id,
            $site_url
        ));
        
        // If not found, try normalized match (case-insensitive, trailing slash removed)
        if (!$activation) {
            $activation = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $activations_table WHERE license_id = %d AND LOWER(TRIM(TRAILING '/' FROM site_url)) = %s",
                $license_id,
                $normalized_site_url
            ));
        }
        
        // If still not found, try LIKE match (handles http/https variations)
        if (!$activation) {
            $site_url_pattern = '%' . $wpdb->esc_like($normalized_site_url) . '%';
            $activation = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $activations_table WHERE license_id = %d AND LOWER(site_url) LIKE %s LIMIT 1",
                $license_id,
                $site_url_pattern
            ));
        }
        
        // If still not found, try finding by license_key (in case site_url format changed)
        if (!$activation && !empty($license_key)) {
            // Check if license_key column exists in activations table
            $columns = $wpdb->get_col("SHOW COLUMNS FROM $activations_table");
            if (in_array('license_key', $columns, true)) {
                $activation = $wpdb->get_row($wpdb->prepare(
                    "SELECT * FROM $activations_table WHERE license_id = %d AND license_key = %s LIMIT 1",
                    $license_id,
                    $license_key
                ));
            }
        }
        
        // If still not found, try to find ANY activation for this license (last resort)
        if (!$activation) {
            $activation = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $activations_table WHERE license_id = %d AND status = 'active' LIMIT 1",
                $license_id
            ));
            
            if ($activation && defined('WP_DEBUG') && WP_DEBUG) {
                error_log('ViraStore: Found activation by license_id only. Stored site_url: ' . $activation->site_url . ', Requested site_url: ' . $site_url);
            }
        }

        if (!$activation) {
            // Log for debugging
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('ViraStore: No activation found for license_id: ' . $license_id . ', site_url: ' . $site_url);
                $all_activations = $wpdb->get_results($wpdb->prepare(
                    "SELECT site_url, license_key FROM $activations_table WHERE license_id = %d",
                    $license_id
                ));
                if ($all_activations) {
                    error_log('ViraStore: Existing activations for this license: ' . print_r($all_activations, true));
                }
            }
            
            // Even if activation record not found, still decrement activation count
            // (in case activation record was deleted but count wasn't updated)
            $wpdb->query('START TRANSACTION');
            try {
                $update_result = $wpdb->query($wpdb->prepare(
                    "UPDATE $licenses_table SET activation_count = GREATEST(0, activation_count - 1), updated_at = %s WHERE id = %d",
                    current_time('mysql'),
                    $license_id
                ));
                
                if ($update_result !== false) {
                    $wpdb->query('COMMIT');
                    return [
                        'valid' => true,
                        'message' => __('License deactivated successfully. (Activation record not found, but activation count was decremented.)', 'vira-store'),
                    ];
                } else {
                    $wpdb->query('ROLLBACK');
                }
            } catch (Exception $e) {
                $wpdb->query('ROLLBACK');
            }
            
            return [
                'valid' => false,
                'message' => __('License is not activated for this site.', 'vira-store'),
            ];
        }
        
        // Get the actual site_url from database for deletion
        $actual_site_url = $activation->site_url;

        // Use transaction to ensure atomic operation
        $wpdb->query('START TRANSACTION');
        
        try {
            // Remove activation - use actual site_url from database
            $delete_result = $wpdb->delete(
                $activations_table,
                [
                    'license_id' => $license_id,
                    'site_url' => $actual_site_url,
                ],
                ['%d', '%s']
            );

            if ($delete_result === false) {
                $wpdb->query('ROLLBACK');
                $error_msg = $wpdb->last_error ?: 'Unknown database error';
                error_log('ViraStore: Failed to delete activation: ' . $error_msg);
                error_log('ViraStore: License ID: ' . $license_id . ', Site URL: ' . $actual_site_url);
                
                // Try alternative delete method if standard delete fails
                $alt_delete = $wpdb->query($wpdb->prepare(
                    "DELETE FROM $activations_table WHERE license_id = %d AND site_url = %s",
                    $license_id,
                    $actual_site_url
                ));
                
                if ($alt_delete === false) {
                    $wpdb->query('ROLLBACK');
                    return [
                        'valid' => false,
                        'message' => __('Failed to deactivate license. Database error: ', 'vira-store') . $error_msg,
                    ];
                }
            }

            // Atomically decrement activation count (prevent negative values)
            $update_result = $wpdb->query($wpdb->prepare(
                "UPDATE $licenses_table SET activation_count = GREATEST(0, activation_count - 1), updated_at = %s WHERE id = %d",
                current_time('mysql'),
                $license_id
            ));
            
            if ($update_result === false) {
                $wpdb->query('ROLLBACK');
                error_log('ViraStore: Failed to update activation count: ' . $wpdb->last_error);
                return [
                    'valid' => false,
                    'message' => __('Failed to update license activation count.', 'vira-store'),
                ];
            }
            
            $wpdb->query('COMMIT');
            
            return [
                'valid' => true,
                'message' => __('License deactivated successfully.', 'vira-store'),
            ];
        } catch (Exception $e) {
            $wpdb->query('ROLLBACK');
            error_log('ViraStore: License deactivation exception: ' . $e->getMessage());
            return [
                'valid' => false,
                'message' => __('An error occurred during license deactivation.', 'vira-store'),
            ];
        }
    }

    /**
     * Get license by ID
     *
     * @param int $license_id License ID
     * @return array|null
     */
    public function get_license_by_id(int $license_id): ?array {
        global $wpdb;
        $licenses_table = $wpdb->prefix . 'vrstore_licenses';
        $activations_table = $wpdb->prefix . 'vrstore_license_activations';
        
        // Get license by ID from table
        $license = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $licenses_table WHERE id = %d",
            $license_id
        ));

        if (!$license) {
            return null;
        }

        $product_id = $license->product_id;
        $user_id = $license->user_id;

        // Get activations from table
        $activations = [];
        if ($wpdb->get_var("SHOW TABLES LIKE '$activations_table'") === $activations_table) {
            // Check which columns exist
            $columns = $wpdb->get_col("SHOW COLUMNS FROM $activations_table");
            $date_col = in_array('activated_at', $columns, true) ? 'activated_at' : 'activation_date';
            $ip_col = in_array('ip_address', $columns, true) ? 'ip_address' : 'activation_ip';
            
            $activation_results = $wpdb->get_results($wpdb->prepare(
                "SELECT site_url, $date_col, $ip_col FROM $activations_table WHERE license_id = %d",
                $license_id
            ));
            
            foreach ($activation_results as $activation) {
                $activations[] = [
                    'site_url' => $activation->site_url,
                    'activation_date' => $activation->{$date_col} ?? '',
                    'activation_ip' => $activation->{$ip_col} ?? '',
                ];
            }
        }

        // Get product details
        $product = null;
        if ($product_id) {
            $product_post = get_post($product_id);
            if ($product_post && $product_post->post_type === 'vrstore_product') {
                $product = [
                    'id' => $product_id,
                    'title' => $product_post->post_title,
                ];
            }
        }

        // Get user details
        $user = null;
        if ($user_id) {
            $user_data = get_user_by('id', $user_id);
            if ($user_data) {
                $user = [
                    'id' => $user_id,
                    'name' => $user_data->display_name,
                    'email' => $user_data->user_email,
                ];
            }
        }

        return [
            'id' => $license_id,
            'key' => $license->license_key,
            'status' => $license->status ?: 'active',
            'expiry_date' => $license->expiry_date,
            'activation_limit' => $license->activation_limit ?: 1,
            'activation_count' => $license->activation_count ?: 0,
            'product' => $product,
            'user' => $user,
            'activations' => $activations,
        ];
    }

    /**
     * Get license by key
     *
     * @param string $license_key License key
     * @return array|null
     */
    public function get_license_by_key(string $license_key): ?array {
        global $wpdb;
        $licenses_table = $wpdb->prefix . 'vrstore_licenses';
        $activations_table = $wpdb->prefix . 'vrstore_license_activations';
        
        // Get license by key from table
        $license = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $licenses_table WHERE license_key = %s",
            $license_key
        ));

        if (!$license) {
            return null;
        }

        $license_id = $license->id;
        $product_id = $license->product_id;
        $user_id = $license->user_id;

        // Get activations from table
        $activations = [];
        if ($wpdb->get_var("SHOW TABLES LIKE '$activations_table'") === $activations_table) {
            // Check which columns exist
            $columns = $wpdb->get_col("SHOW COLUMNS FROM $activations_table");
            $date_col = in_array('activated_at', $columns, true) ? 'activated_at' : 'activation_date';
            $ip_col = in_array('ip_address', $columns, true) ? 'ip_address' : 'activation_ip';
            
            $activation_results = $wpdb->get_results($wpdb->prepare(
                "SELECT site_url, $date_col, $ip_col FROM $activations_table WHERE license_id = %d",
                $license_id
            ));
            
            foreach ($activation_results as $activation) {
                $activations[] = [
                    'site_url' => $activation->site_url,
                    'activation_date' => $activation->{$date_col} ?? '',
                    'activation_ip' => $activation->{$ip_col} ?? '',
                ];
            }
        }

        // Get product details
        $product = null;
        if ($product_id) {
            $product_post = get_post($product_id);
            if ($product_post && $product_post->post_type === 'vrstore_product') {
                $product = [
                    'id' => $product_id,
                    'title' => $product_post->post_title,
                ];
            }
        }

        // Get user details
        $user = null;
        if ($user_id) {
            $user_data = get_user_by('id', $user_id);
            if ($user_data) {
                $user = [
                    'id' => $user_id,
                    'name' => $user_data->display_name,
                    'email' => $user_data->user_email,
                ];
            }
        }

        return [
            'id' => $license_id,
            'key' => $license_key,
            'status' => $license->status ?: 'active',
            'expiry_date' => $license->expiry_date,
            'activation_limit' => $license->activation_limit ?: 1,
            'activation_count' => $license->activation_count ?: 0,
            'product' => $product,
            'user' => $user,
            'activations' => $activations,
        ];
    }

	/**
	 * Create license directly in database table
	 *
	 * @param array $license_data License data
	 * @return int|false License ID or false on failure
	 */
	public function create_license(array $license_data) {
		global $wpdb;
		
		$licenses_table = $wpdb->prefix . 'vrstore_licenses';
		
		// Check if table exists
		$table_exists = $wpdb->get_var("SHOW TABLES LIKE '$licenses_table'") === $licenses_table;
		if (!$table_exists) {
			error_log('ViraStore: Licenses table does not exist');
			return false;
		}
		
		// Validate required fields
		if (empty($license_data['license_key']) || empty($license_data['customer_email'])) {
			error_log('ViraStore: Missing required license data (license_key or customer_email)');
			return false;
		}
		
		// Sanitize inputs
		$license_key = sanitize_text_field(trim($license_data['license_key']));
		$customer_email = sanitize_email($license_data['customer_email']);
		
		if (empty($license_key) || empty($customer_email)) {
			error_log('ViraStore: Invalid license key or customer email after sanitization');
			return false;
		}
		
		// Check for duplicate license key
		$existing = $wpdb->get_var($wpdb->prepare(
			"SELECT COUNT(*) FROM $licenses_table WHERE license_key = %s",
			$license_key
		));
		
		if ($existing > 0) {
			error_log('ViraStore: Duplicate license key detected: ' . $license_key);
			return false;
		}
		
		// Prevent Extended Support licenses from being created
		$product_id = isset($license_data['product_id']) ? intval($license_data['product_id']) : 0;
		if (is_string($license_data['product_id'] ?? '') && strpos($license_data['product_id'], 'extended_support_') === 0) {
			// Extended Support products should not generate licenses
			return false;
		}
        
        // Prepare license data with defaults and sanitization
        $data = [
            'license_key' => $license_key,
            'product_id' => $product_id,
            'order_id' => isset($license_data['order_id']) ? absint($license_data['order_id']) : 0,
            'customer_email' => $customer_email,
            'activation_limit' => isset($license_data['activation_limit']) ? absint($license_data['activation_limit']) : 1,
            'activation_count' => 0,
            'status' => isset($license_data['status']) ? sanitize_text_field($license_data['status']) : 'active',
            'license_type_slug' => isset($license_data['license_type_slug']) ? sanitize_key($license_data['license_type_slug']) : '',
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql')
        ];
        
        // Validate status
        $allowed_statuses = ['active', 'inactive', 'suspended', 'expired'];
        if (!in_array($data['status'], $allowed_statuses, true)) {
            $data['status'] = 'active';
        }
        
        // Add expiry date if provided (only use expires_at as per table schema)
        $expiry_field = null;
        if (!empty($license_data['expires_at'])) {
            $expiry_field = sanitize_text_field($license_data['expires_at']);
            $data['expires_at'] = $expiry_field;
        } elseif (!empty($license_data['expiry_date'])) {
            $expiry_field = sanitize_text_field($license_data['expiry_date']);
            $data['expires_at'] = $expiry_field;
        }
        
        // Prepare format array
        $formats = [
            '%s', // license_key
            '%d', // product_id
            '%d', // order_id
            '%s', // customer_email
            '%d', // activation_limit
            '%d', // activation_count
            '%s', // status
            '%s', // license_type_slug
            '%s', // created_at
            '%s'  // updated_at
        ];
        
        // Add expiry field format if provided
        if (!empty($expiry_field)) {
            $formats[] = '%s'; // expires_at
        }
        
        // Insert license into database
        $result = $wpdb->insert(
            $licenses_table,
            $data,
            $formats
        );
        
        if ($result === false) {
            error_log('ViraStore: Failed to insert license: ' . $wpdb->last_error);
            return false;
        }
        
        return $wpdb->insert_id;
    }

    /**
     * Get license type configuration for a product.
     * ONLY uses custom license types (taxonomy-based system removed)
     *
     * @since 1.0.0
     * @param int $product_id Product ID.
     * @param string $license_type_slug Optional specific license type slug
     * @return array License configuration with expiry_days and activation_limit.
     */
    public function get_license_type_config(int $product_id, string $license_type_slug = ''): array {
        // Default configuration
        $default_config = array(
            'expiry_days' => 365, // 1 year default
            'activation_limit' => 1,
            'price' => 0.00 // Free by default
        );

        // Get default settings (now in months, convert to days)
        $settings = get_option('vrstore_settings', array());
        if (isset($settings['license_expiry']) && !empty($settings['license_expiry'])) {
            $expiry_months = absint($settings['license_expiry']);
            $default_config['expiry_days'] = $expiry_months * 30; // Convert months to days (approximate)
        }
        if (isset($settings['max_activations']) && !empty($settings['max_activations'])) {
            $default_config['activation_limit'] = absint($settings['max_activations']);
        }

        // Check for custom license types (ONLY source of license types)
        if (isset($settings['custom_license_types']) && !empty($settings['custom_license_types'])) {
            foreach ($settings['custom_license_types'] as $custom_type) {
                if (!empty($license_type_slug) && isset($custom_type['slug']) && $custom_type['slug'] === $license_type_slug) {
                    // Found matching custom license type
                    $custom_config = $default_config;
                    
                    // Override with custom values
                    if (isset($custom_type['regular_price']) && !empty($custom_type['regular_price'])) {
                        $custom_config['price'] = floatval($custom_type['regular_price']);
                    }
                    // Use sale price if available
                    if (isset($custom_type['sale_price']) && !empty($custom_type['sale_price'])) {
                        $custom_config['price'] = floatval($custom_type['sale_price']);
                    }
                    // Convert months to days
                    if (isset($custom_type['expiry_months']) && is_numeric($custom_type['expiry_months'])) {
                        $expiry_months = absint($custom_type['expiry_months']);
                        $custom_config['expiry_days'] = $expiry_months * 30; // Convert months to days
                    }
                    if (isset($custom_type['max_activations']) && !empty($custom_type['max_activations'])) {
                        $custom_config['activation_limit'] = absint($custom_type['max_activations']);
                    }
                    
                    return $custom_config;
                }
            }
        }

        // Return default config if no matching custom license type found
        return $default_config;
    }

    /**
     * Get license type price for a product and license type.
     *
     * @since 1.0.0
     * @param int $product_id Product ID.
     * @param string $license_type_slug Optional specific license type slug
     * @param string $price_type Type of price to get ('regular' or 'sale'). Default 'sale' (with fallback to regular).
     * @return float License type price.
     */
    public function get_license_type_price(int $product_id, string $license_type_slug = '', string $price_type = 'sale'): float {
        // 1) Per-product custom license pricing overrides (new structure) - check regardless of pricing mode
        // Read correct meta key for product license pricing
        $product_license_pricing = get_post_meta($product_id, '_vrstore_product_license_pricing', true);
        if (!empty($product_license_pricing) && isset($product_license_pricing[$license_type_slug])) {
            $license_data = $product_license_pricing[$license_type_slug];
            $regular = isset($license_data['price']) ? floatval($license_data['price']) : (isset($license_data['regular_price']) ? floatval($license_data['regular_price']) : 0.0);
            $sale = isset($license_data['sale_price']) ? floatval($license_data['sale_price']) : 0.0;

            if ($price_type === 'sale' && $sale > 0) {
                return $sale;
            }
            if ($regular > 0) {
                return $regular;
            }
        }

        // Check per-product custom license pricing map
        $custom_license_pricing = get_post_meta($product_id, '_vrstore_product_custom_license_pricing', true);
        if (is_array($custom_license_pricing) && isset($custom_license_pricing[$license_type_slug])) {
            $data = $custom_license_pricing[$license_type_slug];
            $regular = isset($data['price']) ? floatval($data['price']) : 0.0;
            $sale = isset($data['sale_price']) ? floatval($data['sale_price']) : 0.0;
            if ($price_type === 'sale' && $sale > 0) {
                return $sale;
            }
            if ($regular > 0) {
                return $regular;
            }
        }

        // 2) Fallback to settings-defined custom license types (store-wide defaults)
        $settings = get_option('vrstore_settings', array());
        if (isset($settings['custom_license_types']) && is_array($settings['custom_license_types'])) {
            foreach ($settings['custom_license_types'] as $type) {
                if (!empty($license_type_slug) && isset($type['slug']) && $type['slug'] === $license_type_slug) {
                    $regular = isset($type['regular_price']) ? floatval($type['regular_price']) : 0.0;
                    $sale = isset($type['sale_price']) ? floatval($type['sale_price']) : 0.0;
                    if ($price_type === 'sale' && $sale > 0) {
                        return $sale;
                    }
                    return $regular;
                }
            }
        }

        // 3) Final fallback to legacy config (kept for backward compatibility)
        $config = $this->get_license_type_config($product_id, $license_type_slug);
        return isset($config['price']) ? floatval($config['price']) : 0.00;
    }

    /**
     * Get all license types with their pricing for a product.
     *
     * @since 1.0.0
     * @param int $product_id Product ID.
     * @return array Array of license types with pricing information.
     */
    public function get_product_license_types_with_pricing(int $product_id): array {
        $result = array();

        // Source of truth is settings custom license types
        $settings = get_option('vrstore_settings', array());
        $custom_types = isset($settings['custom_license_types']) && is_array($settings['custom_license_types'])
            ? $settings['custom_license_types']
            : array();

        if (empty($custom_types)) {
            return $result;
        }

        $pricing_mode = get_post_meta($product_id, '_vrstore_pricing_mode', true);
        $product_license_pricing = get_post_meta($product_id, '_vrstore_product_license_pricing', true);
        $custom_license_pricing = get_post_meta($product_id, '_vrstore_product_custom_license_pricing', true);

        foreach ($custom_types as $type) {
            $slug = isset($type['slug']) ? $type['slug'] : sanitize_title($type['label'] ?? 'license');
            $name = $type['label'] ?? ucfirst($slug);

            $regular = 0.0;
            $sale = 0.0;

            // Priority: per-product license pricing map (check regardless of pricing mode)
            if (is_array($product_license_pricing) && isset($product_license_pricing[$slug])) {
                $pricing_data = $product_license_pricing[$slug];
                $regular = isset($pricing_data['price']) ? floatval($pricing_data['price']) : (isset($pricing_data['regular_price']) ? floatval($pricing_data['regular_price']) : 0.0);
                $sale = isset($pricing_data['sale_price']) ? floatval($pricing_data['sale_price']) : 0.0;
            } elseif (is_array($custom_license_pricing) && isset($custom_license_pricing[$slug])) {
                // Per-product custom overrides
                $pricing_data = $custom_license_pricing[$slug];
                $regular = isset($pricing_data['price']) ? floatval($pricing_data['price']) : 0.0;
                $sale = isset($pricing_data['sale_price']) ? floatval($pricing_data['sale_price']) : 0.0;
            } else {
                // Fallback to global defaults from settings
                $regular = isset($type['regular_price']) ? floatval($type['regular_price']) : 0.0;
                $sale = isset($type['sale_price']) ? floatval($type['sale_price']) : 0.0;
            }

            // Expiry and activations from settings
            $expiry_months = isset($type['expiry_months']) ? absint($type['expiry_months']) : 12;
            $activation_limit = isset($type['max_activations']) ? absint($type['max_activations']) : 1;

            $result[] = array(
                'id' => 0,
                'name' => $name,
                'slug' => $slug,
                'regular_price' => $regular,
                'sale_price' => $sale,
                'price' => $sale > 0 ? $sale : $regular,
                'expiry_days' => $expiry_months * 30,
                'activation_limit' => $activation_limit,
            );
        }

        return $result;
    }

    /**
     * Calculate expiry date based on days from now.
     *
     * @since 1.0.0
     * @param int $expiry_days Number of days from now.
     * @return string Expiry date in Y-m-d H:i:s format or empty string for lifetime.
     */
    public function calculate_expiry_date(int $expiry_days): string {
        if ($expiry_days <= 0) {
            // If expiry days is 0 or negative, return empty string for lifetime license
            return '';
        }

        // Return in MySQL datetime format for consistency
        return date('Y-m-d H:i:s', strtotime('+' . $expiry_days . ' days'));
    }
    
    /**
     * Check if ticket support should be locked for a user due to expired licenses.
     *
     * @since 1.0.0
     * @param int $user_id User ID to check.
     * @return array Array with 'locked' boolean and 'message' string.
     */
    public function is_ticket_support_locked(int $user_id): array {
        global $wpdb;
        
        $result = array(
            'locked' => false,
            'message' => ''
        );
        
        // Get user email
        $user = get_userdata($user_id);
        if (!$user) {
            return $result;
        }
        
        $user_email = $user->user_email;
        
        // Get all active licenses for this user
        $licenses_table = $wpdb->prefix . 'vrstore_licenses';
        $licenses = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $licenses_table WHERE (customer_email = %s OR customer_id = %d) AND status = 'active'",
            $user_email,
            $user_id
        ));
        
        if (empty($licenses)) {
            return $result; // No licenses, no restrictions
        }
        
        // Check each license for expiry and ticket locking settings
        $has_valid_license = false;
        $has_locked_expired_license = false;
        
        // Get custom license types settings
        $settings = get_option('vrstore_settings', array());
        $custom_license_types = isset($settings['custom_license_types']) && is_array($settings['custom_license_types'])
            ? $settings['custom_license_types']
            : array();
        
        foreach ($licenses as $license) {
            // Check if license is expired
            $is_expired = false;
            if (!empty($license->expiry_date) && $license->expiry_date !== '0000-00-00 00:00:00') {
                $is_expired = strtotime($license->expiry_date) < time();
            }
            
            if (!$is_expired) {
                $has_valid_license = true;
                continue; // Valid license found, user can use tickets
            }
            
            // License is expired, check if ticket locking is enabled for this license type
            $license_type_slug = $license->license_type_slug ?? '';
            
            foreach ($custom_license_types as $type) {
                $slug = isset($type['slug']) ? $type['slug'] : sanitize_title($type['label'] ?? '');
                
                if ($slug === $license_type_slug) {
                    if (isset($type['lock_tickets_on_expiry']) && $type['lock_tickets_on_expiry']) {
                        $has_locked_expired_license = true;
                        break 2; // Break out of both loops
                    }
                }
            }
        }
        
        // If user has at least one valid (non-expired) license, allow ticket access
        if ($has_valid_license) {
            return $result;
        }
        
        // If user has expired licenses with ticket locking enabled, lock ticket support
        if ($has_locked_expired_license) {
            $result['locked'] = true;
            $result['message'] = __('Your license has expired. To continue using ticket support, please purchase Extended Support.', 'vira-store');
        }
        
        return $result;
    }


}
