<?php
/**
 * Support Email Notifications Class
 *
 * Handles email notifications for support tickets including:
 * - New ticket notifications to admin and customer
 * - Reply notifications to admin and customer
 * - Status change notifications
 * - Priority change notifications
 *
 * @package Vira_Store
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * VRSTORE_Support_Email_Notifications Class
 *
 * Manages email notifications for support tickets.
 *
 * @since 1.0.0
 */
class VRSTORE_Support_Email_Notifications {

    /**
     * Instance of this class.
     *
     * @since 1.0.0
     * @var object
     */
    private static $instance = null;

    /**
     * Settings instance.
     *
     * @since 1.0.0
     * @var VRSTORE_Settings
     */
    private $settings;

    /**
     * Constructor.
     *
     * @since 1.0.0
     */
    private function __construct() {
        $this->settings = VRSTORE_Settings::get_instance();
        $this->init_hooks();
    }

    /**
     * Get instance of this class.
     *
     * @since 1.0.0
     * @return VRSTORE_Support_Email_Notifications
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        
        return self::$instance;
    }

    /**
     * Initialize hooks.
     *
     * @since 1.0.0
     * @return void
     */
    private function init_hooks() {
        // Hook into support ticket actions
        add_action( 'vrstore_support_ticket_created', array( $this, 'send_new_ticket_notifications' ), 10, 2 );
        add_action( 'vrstore_support_ticket_status_changed', array( $this, 'send_status_change_notifications' ), 10, 3 );
        add_action( 'vrstore_support_ticket_reply_added', array( $this, 'send_reply_notifications' ), 10, 3 );
        add_action( 'vrstore_support_ticket_priority_changed', array( $this, 'send_priority_change_notifications' ), 10, 3 );
    }

    /**
     * Get translated text with fallback.
     *
     * @since 1.0.0
     * @param string $text Text to translate.
     * @return string
     */
    private function get_translated_text( $text ) {
        if ( vrstore_is_textdomain_ready() ) {
            return __( $text, 'vira-store' );
        }
        return $text;
    }

    /**
     * Check if support email notifications are enabled.
     *
     * @since 1.0.0
     * @return bool
     */
    public function are_notifications_enabled() {
        return $this->settings->get_setting( 'enable_support_email_notifications', 'on' ) === 'on';
    }

    /**
     * Send new ticket notifications to both admin and customer.
     *
     * @since 1.0.0
     * @param int   $ticket_id Ticket ID.
     * @param array $ticket_data Ticket data.
     * @return void
     */
    public function send_new_ticket_notifications( $ticket_id, $ticket_data ) {
        if ( ! $this->are_notifications_enabled() ) {
            return;
        }

        // Send notification to admin
        if ( $this->settings->get_setting( 'support_notify_admin_new_ticket', 'on' ) === 'on' ) {
            $this->send_new_ticket_admin_notification( $ticket_id, $ticket_data );
        }

        // Send confirmation to customer
        if ( $this->settings->get_setting( 'support_notify_customer_new_ticket', 'on' ) === 'on' ) {
            $this->send_new_ticket_customer_notification( $ticket_id, $ticket_data );
        }
    }

    /**
     * Send reply notifications.
     *
     * @since 1.0.0
     * @param int   $ticket_id Ticket ID.
     * @param array $reply_data Reply data.
     * @param array $ticket_data Ticket data.
     * @return void
     */
    public function send_reply_notifications( $ticket_id, $reply_data, $ticket_data ) {
        if ( ! $this->are_notifications_enabled() ) {
            return;
        }

        $reply_by = $reply_data['reply_by'] ?? 'customer';

        if ( $reply_by === 'admin' ) {
            // Admin replied, notify customer
            if ( $this->settings->get_setting( 'support_notify_customer_admin_reply', 'on' ) === 'on' ) {
                $this->send_admin_reply_customer_notification( $ticket_id, $reply_data, $ticket_data );
            }
        } else {
            // Customer replied, notify admin
            if ( $this->settings->get_setting( 'support_notify_admin_customer_reply', 'on' ) === 'on' ) {
                $this->send_customer_reply_admin_notification( $ticket_id, $reply_data, $ticket_data );
            }
        }
    }

    /**
     * Send status change notifications.
     *
     * @since 1.0.0
     * @param int    $ticket_id Ticket ID.
     * @param string $old_status Old status.
     * @param string $new_status New status.
     * @return void
     */
    public function send_status_change_notifications( $ticket_id, $old_status, $new_status ) {
        if ( ! $this->are_notifications_enabled() ) {
            return;
        }

        if ( $this->settings->get_setting( 'support_notify_customer_status_change', 'on' ) === 'on' ) {
            $this->send_status_change_customer_notification( $ticket_id, $old_status, $new_status );
        }
    }

    /**
     * Send priority change notifications.
     *
     * @since 1.0.0
     * @param int    $ticket_id Ticket ID.
     * @param string $old_priority Old priority.
     * @param string $new_priority New priority.
     * @return void
     */
    public function send_priority_change_notifications( $ticket_id, $old_priority, $new_priority ) {
        if ( ! $this->are_notifications_enabled() ) {
            return;
        }

        // Priority changes are usually admin-only and may not need customer notification
        // But we can add it as an option
        if ( $this->settings->get_setting( 'support_notify_customer_priority_change', 'off' ) === 'on' ) {
            $this->send_priority_change_customer_notification( $ticket_id, $old_priority, $new_priority );
        }
    }

    /**
     * Send new ticket notification to admin.
     *
     * @since 1.0.0
     * @param int   $ticket_id Ticket ID.
     * @param array $ticket_data Ticket data.
     * @return bool
     */
    private function send_new_ticket_admin_notification( $ticket_id, $ticket_data ) {
        $admin_emails = $this->get_admin_notification_emails();
        if ( empty( $admin_emails ) ) {
            return false;
        }

        $ticket_data = $this->get_ticket_data( $ticket_id, $ticket_data );
        if ( ! $ticket_data ) {
            return false;
        }

        $subject = $this->get_email_template( 'new_ticket_admin_subject', $ticket_data );
        $body = $this->get_email_template( 'new_ticket_admin_body', $ticket_data );

        return $this->send_email( $admin_emails, $subject, $body, $ticket_data );
    }

    /**
     * Send new ticket confirmation to customer.
     *
     * @since 1.0.0
     * @param int   $ticket_id Ticket ID.
     * @param array $ticket_data Ticket data.
     * @return bool
     */
    private function send_new_ticket_customer_notification( $ticket_id, $ticket_data ) {
        $ticket_data = $this->get_ticket_data( $ticket_id, $ticket_data );
        if ( ! $ticket_data || empty( $ticket_data['customer_email'] ) ) {
            return false;
        }

        $subject = $this->get_email_template( 'new_ticket_customer_subject', $ticket_data );
        $body = $this->get_email_template( 'new_ticket_customer_body', $ticket_data );

        return $this->send_email( $ticket_data['customer_email'], $subject, $body, $ticket_data );
    }

    /**
     * Send admin reply notification to customer.
     *
     * @since 1.0.0
     * @param int   $ticket_id Ticket ID.
     * @param array $reply_data Reply data.
     * @param array $ticket_data Ticket data.
     * @return bool
     */
    private function send_admin_reply_customer_notification( $ticket_id, $reply_data, $ticket_data ) {
        $ticket_data = $this->get_ticket_data( $ticket_id, $ticket_data );
        if ( ! $ticket_data || empty( $ticket_data['customer_email'] ) ) {
            return false;
        }

        // Don't send notifications for private admin replies
        if ( ! empty( $reply_data['is_private'] ) && $reply_data['is_private'] ) {
            return false;
        }

        $ticket_data['reply_message'] = $reply_data['message'] ?? '';
        $ticket_data['reply_author'] = $reply_data['user_name'] ?? $this->get_translated_text( 'Support Team' );

        $subject = $this->get_email_template( 'admin_reply_customer_subject', $ticket_data );
        $body = $this->get_email_template( 'admin_reply_customer_body', $ticket_data );

        return $this->send_email( $ticket_data['customer_email'], $subject, $body, $ticket_data );
    }

    /**
     * Send customer reply notification to admin.
     *
     * @since 1.0.0
     * @param int   $ticket_id Ticket ID.
     * @param array $reply_data Reply data.
     * @param array $ticket_data Ticket data.
     * @return bool
     */
    private function send_customer_reply_admin_notification( $ticket_id, $reply_data, $ticket_data ) {
        $admin_emails = $this->get_admin_notification_emails();
        if ( empty( $admin_emails ) ) {
            return false;
        }

        $ticket_data = $this->get_ticket_data( $ticket_id, $ticket_data );
        if ( ! $ticket_data ) {
            return false;
        }

        $ticket_data['reply_message'] = $reply_data['message'] ?? '';

        $subject = $this->get_email_template( 'customer_reply_admin_subject', $ticket_data );
        $body = $this->get_email_template( 'customer_reply_admin_body', $ticket_data );

        return $this->send_email( $admin_emails, $subject, $body, $ticket_data );
    }

    /**
     * Send status change notification to customer.
     *
     * @since 1.0.0
     * @param int    $ticket_id Ticket ID.
     * @param string $old_status Old status.
     * @param string $new_status New status.
     * @return bool
     */
    private function send_status_change_customer_notification( $ticket_id, $old_status, $new_status ) {
        $ticket_data = $this->get_ticket_data( $ticket_id );
        if ( ! $ticket_data || empty( $ticket_data['customer_email'] ) ) {
            return false;
        }

        $ticket_data['old_status'] = ucfirst( $old_status );
        $ticket_data['new_status'] = ucfirst( $new_status );

        $subject = $this->get_email_template( 'status_change_customer_subject', $ticket_data );
        $body = $this->get_email_template( 'status_change_customer_body', $ticket_data );

        return $this->send_email( $ticket_data['customer_email'], $subject, $body, $ticket_data );
    }

    /**
     * Send priority change notification to customer.
     *
     * @since 1.0.0
     * @param int    $ticket_id Ticket ID.
     * @param string $old_priority Old priority.
     * @param string $new_priority New priority.
     * @return bool
     */
    private function send_priority_change_customer_notification( $ticket_id, $old_priority, $new_priority ) {
        $ticket_data = $this->get_ticket_data( $ticket_id );
        if ( ! $ticket_data || empty( $ticket_data['customer_email'] ) ) {
            return false;
        }

        $ticket_data['old_priority'] = ucfirst( $old_priority );
        $ticket_data['new_priority'] = ucfirst( $new_priority );

        $subject = $this->get_email_template( 'priority_change_customer_subject', $ticket_data );
        $body = $this->get_email_template( 'priority_change_customer_body', $ticket_data );

        return $this->send_email( $ticket_data['customer_email'], $subject, $body, $ticket_data );
    }

    /**
     * Get ticket data for email templates.
     *
     * @since 1.0.0
     * @param int   $ticket_id Ticket ID.
     * @param array $ticket_data Optional existing ticket data.
     * @return array|false
     */
    private function get_ticket_data( $ticket_id, $ticket_data = null ) {
        global $wpdb;

        if ( ! $ticket_data ) {
            $tickets_table = $wpdb->prefix . 'vrstore_support_tickets';
            
            $ticket = $wpdb->get_row( $wpdb->prepare(
                "SELECT st.*, u.display_name as customer_name, u.user_email as customer_email 
                 FROM {$tickets_table} st 
                 LEFT JOIN {$wpdb->users} u ON st.customer_id = u.ID 
                 WHERE st.id = %d",
                $ticket_id
            ), ARRAY_A );

            if ( ! $ticket ) {
                return false;
            }

            $ticket_data = $ticket;
        }

        // Get product title if available
        if ( ! empty( $ticket_data['product_id'] ) && is_numeric( $ticket_data['product_id'] ) ) {
            $product = get_post( $ticket_data['product_id'] );
            $ticket_data['product_title'] = $product ? $product->post_title : $this->get_translated_text( 'General' );
        } else {
            $ticket_data['product_title'] = $ticket_data['product_title'] ?? $this->get_translated_text( 'General' );
        }

        // Add site information
        $ticket_data['site_name'] = get_bloginfo( 'name' );
        $ticket_data['site_url'] = home_url();

        // Format dates
        if ( ! empty( $ticket_data['created_at'] ) ) {
            $ticket_data['created_date'] = mysql2date( 'F j, Y g:i A', $ticket_data['created_at'] );
        }

        // Create ticket URL for admin
        $ticket_data['admin_ticket_url'] = admin_url( 'admin.php?page=vrstore-customers&action=view_ticket&ticket_id=' . $ticket_id );

        // Create customer portal URL
        $account_page_id = $this->settings->get_setting( 'account_page' );
        if ( $account_page_id ) {
            $ticket_data['customer_ticket_url'] = get_permalink( $account_page_id ) . '#support';
        } else {
            $ticket_data['customer_ticket_url'] = home_url();
        }

        return $ticket_data;
    }

    /**
     * Get admin notification email addresses.
     *
     * @since 1.0.0
     * @return array
     */
    private function get_admin_notification_emails() {
        $emails = $this->settings->get_setting( 'support_admin_notification_emails', get_bloginfo( 'admin_email' ) );
        
        if ( is_string( $emails ) ) {
            $emails = array_map( 'trim', explode( ',', $emails ) );
        }

        return array_filter( $emails, 'is_email' );
    }

    /**
     * Get email template with placeholders replaced.
     *
     * @since 1.0.0
     * @param string $template_key Template key.
     * @param array  $ticket_data Ticket data for placeholders.
     * @return string
     */
    private function get_email_template( $template_key, $ticket_data ) {
        $templates = $this->get_default_templates();
        $template = $this->settings->get_setting( 'support_email_' . $template_key, $templates[ $template_key ] ?? '' );

        return $this->replace_placeholders( $template, $ticket_data );
    }

    /**
     * Replace placeholders in email templates.
     *
     * @since 1.0.0
     * @param string $template Template with placeholders.
     * @param array  $ticket_data Ticket data.
     * @return string
     */
    private function replace_placeholders( $template, $ticket_data ) {
        $placeholders = array(
            '{site_name}'           => $ticket_data['site_name'] ?? get_bloginfo( 'name' ),
            '{site_url}'            => $ticket_data['site_url'] ?? home_url(),
            '{customer_name}'       => $ticket_data['customer_name'] ?? $this->get_translated_text( 'Customer' ),
            '{customer_email}'      => $ticket_data['customer_email'] ?? '',
            '{ticket_number}'       => $ticket_data['ticket_number'] ?? '',
            '{ticket_subject}'      => $ticket_data['subject'] ?? '',
            '{ticket_message}'      => $ticket_data['message'] ?? '',
            '{ticket_status}'       => isset( $ticket_data['status'] ) ? ucfirst( $ticket_data['status'] ) : '',
            '{ticket_priority}'     => isset( $ticket_data['priority'] ) ? ucfirst( $ticket_data['priority'] ) : '',
            '{product_title}'       => $ticket_data['product_title'] ?? $this->get_translated_text( 'General' ),
            '{created_date}'        => $ticket_data['created_date'] ?? '',
            '{reply_message}'       => $ticket_data['reply_message'] ?? '',
            '{reply_author}'        => $ticket_data['reply_author'] ?? '',
            '{old_status}'          => $ticket_data['old_status'] ?? '',
            '{new_status}'          => $ticket_data['new_status'] ?? '',
            '{old_priority}'        => $ticket_data['old_priority'] ?? '',
            '{new_priority}'        => $ticket_data['new_priority'] ?? '',
            '{admin_ticket_url}'    => $ticket_data['admin_ticket_url'] ?? '',
            '{customer_ticket_url}' => $ticket_data['customer_ticket_url'] ?? '',
        );

        return str_replace( array_keys( $placeholders ), array_values( $placeholders ), $template );
    }

    /**
     * Send email using WordPress wp_mail function.
     *
     * @since 1.0.0
     * @param string|array $to Email recipients.
     * @param string       $subject Email subject.
     * @param string       $body Email body.
     * @param array        $ticket_data Ticket data for additional context.
     * @return bool
     */
    private function send_email( $to, $subject, $body, $ticket_data = array() ) {
        // Get email settings
        $from_name = $this->settings->get_setting( 'support_email_from_name', get_bloginfo( 'name' ) );
        $from_email = $this->settings->get_setting( 'support_email_from_email', get_bloginfo( 'admin_email' ) );

        // Set headers
        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $from_name . ' <' . $from_email . '>'
        );

        // Add reply-to if this is a customer notification
        if ( ! empty( $ticket_data['customer_email'] ) && is_string( $to ) && $to !== $ticket_data['customer_email'] ) {
            $headers[] = 'Reply-To: ' . $ticket_data['customer_email'];
        }

        // Convert line breaks to HTML
        $body = wpautop( $body );

        // Apply filters to allow customization
        $to = apply_filters( 'vrstore_support_email_to', $to, $ticket_data );
        $subject = apply_filters( 'vrstore_support_email_subject', $subject, $ticket_data );
        $body = apply_filters( 'vrstore_support_email_body', $body, $ticket_data );
        $headers = apply_filters( 'vrstore_support_email_headers', $headers, $ticket_data );

        return wp_mail( $to, $subject, $body, $headers );
    }

    /**
     * Get default email templates.
     *
     * @since 1.0.0
     * @return array
     */
    private function get_default_templates() {
        return array(
            // New ticket notifications
            'new_ticket_admin_subject' => $this->get_translated_text( 'New Support Ticket #{ticket_number} - {ticket_subject}' ),
            'new_ticket_admin_body' => $this->get_translated_text( 
                "A new support ticket has been created.\n\n" .
                "Ticket Details:\n" .
                "- Ticket #: {ticket_number}\n" .
                "- Subject: {ticket_subject}\n" .
                "- Customer: {customer_name} ({customer_email})\n" .
                "- Product: {product_title}\n" .
                "- Priority: {ticket_priority}\n" .
                "- Created: {created_date}\n\n" .
                "Message:\n{ticket_message}\n\n" .
                "View and respond to this ticket:\n{admin_ticket_url}"
            ),
            'new_ticket_customer_subject' => $this->get_translated_text( 'Your support ticket #{ticket_number} has been received' ),
            'new_ticket_customer_body' => $this->get_translated_text(
                "Hello {customer_name},\n\n" .
                "Thank you for contacting {site_name} support. Your ticket has been received and assigned ticket number #{ticket_number}.\n\n" .
                "Ticket Details:\n" .
                "- Subject: {ticket_subject}\n" .
                "- Product: {product_title}\n" .
                "- Priority: {ticket_priority}\n" .
                "- Created: {created_date}\n\n" .
                "Our support team will review your request and respond as soon as possible. You can track the status of your ticket in your customer portal.\n\n" .
                "View your ticket: {customer_ticket_url}\n\n" .
                "Best regards,\nThe {site_name} Support Team"
            ),

            // Reply notifications
            'admin_reply_customer_subject' => $this->get_translated_text( 'Response to your support ticket #{ticket_number}' ),
            'admin_reply_customer_body' => $this->get_translated_text(
                "Hello {customer_name},\n\n" .
                "We have responded to your support ticket #{ticket_number} - {ticket_subject}.\n\n" .
                "Response from {reply_author}:\n{reply_message}\n\n" .
                "You can reply to this ticket or view the full conversation in your customer portal:\n{customer_ticket_url}\n\n" .
                "Best regards,\nThe {site_name} Support Team"
            ),
            'customer_reply_admin_subject' => $this->get_translated_text( 'Customer reply to ticket #{ticket_number} - {ticket_subject}' ),
            'customer_reply_admin_body' => $this->get_translated_text(
                "Customer {customer_name} has replied to support ticket #{ticket_number}.\n\n" .
                "Ticket: {ticket_subject}\n" .
                "Product: {product_title}\n" .
                "Customer: {customer_name} ({customer_email})\n\n" .
                "Customer Reply:\n{reply_message}\n\n" .
                "View and respond to this ticket:\n{admin_ticket_url}"
            ),

            // Status change notifications
            'status_change_customer_subject' => $this->get_translated_text( 'Status update for your support ticket #{ticket_number}' ),
            'status_change_customer_body' => $this->get_translated_text(
                "Hello {customer_name},\n\n" .
                "The status of your support ticket #{ticket_number} - {ticket_subject} has been updated.\n\n" .
                "Status changed from: {old_status}\n" .
                "Status changed to: {new_status}\n\n" .
                "You can view your ticket for more details:\n{customer_ticket_url}\n\n" .
                "Best regards,\nThe {site_name} Support Team"
            ),

            // Priority change notifications
            'priority_change_customer_subject' => $this->get_translated_text( 'Priority update for your support ticket #{ticket_number}' ),
            'priority_change_customer_body' => $this->get_translated_text(
                "Hello {customer_name},\n\n" .
                "The priority of your support ticket #{ticket_number} - {ticket_subject} has been updated.\n\n" .
                "Priority changed from: {old_priority}\n" .
                "Priority changed to: {new_priority}\n\n" .
                "You can view your ticket for more details:\n{customer_ticket_url}\n\n" .
                "Best regards,\nThe {site_name} Support Team"
            ),
        );
    }
}
