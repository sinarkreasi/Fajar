<?php
/**
 * Content Restriction Class
 *
 * Handles content restriction functionality for posts and pages
 * with product/course purchase requirements.
 *
 * @package Vira_Store
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Content Restriction class
 */
class VRSTORE_Content_Restriction {
    
    /**
     * Singleton instance
     *
     * @var VRSTORE_Content_Restriction|null
     */
    private static ?VRSTORE_Content_Restriction $instance = null;

    /**
     * Get singleton instance
     *
     * @return VRSTORE_Content_Restriction
     */
    public static function get_instance(): VRSTORE_Content_Restriction {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        $this->init_hooks();
    }

    /**
     * Initialize hooks
     *
     * @return void
     */
    private function init_hooks(): void {
        // Add metabox to posts and pages
        add_action( 'add_meta_boxes', [ $this, 'add_content_restriction_metabox' ] );
        
        // Save metabox data
        add_action( 'save_post', [ $this, 'save_content_restriction_metabox' ], 10, 2 );
        
        // Filter content on frontend
        add_filter( 'the_content', [ $this, 'filter_restricted_content' ], 20 );
        
        // Add admin scripts
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_scripts' ] );
        
        // Add frontend scripts and styles
        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_frontend_scripts' ] );
    }

    /**
     * Add content restriction metabox
     *
     * @return void
     */
    public function add_content_restriction_metabox(): void {
        $post_types = [ 'post', 'page' ];
        
        foreach ( $post_types as $post_type ) {
            add_meta_box(
                'vrstore_content_restriction',
                vrstore_is_textdomain_ready() ? __( 'Content Restriction', 'vira-store' ) : 'Content Restriction',
                [ $this, 'render_content_restriction_metabox' ],
                $post_type,
                'normal',
                'high'
            );
        }
    }

    /**
     * Render content restriction metabox
     *
     * @param WP_Post $post Post object
     * @return void
     */
    public function render_content_restriction_metabox( $post ): void {
        // Add nonce for security
        wp_nonce_field( 'vrstore_content_restriction_nonce', 'vrstore_content_restriction_nonce' );

        // Check if post has taxonomy restrictions
        $taxonomy_restriction = VRSTORE_Taxonomy_Restriction::get_instance();
        $has_taxonomy_restrictions = $this->post_has_taxonomy_restrictions( $post->ID );

        // Get meta values
        $is_restricted = get_post_meta( $post->ID, '_vrstore_content_restricted', true );
        $required_products = get_post_meta( $post->ID, '_vrstore_required_products', true );
        $required_courses = get_post_meta( $post->ID, '_vrstore_required_courses', true );
        $restricted_content = get_post_meta( $post->ID, '_vrstore_restricted_content', true );
        $custom_message = get_post_meta( $post->ID, '_vrstore_restriction_message', true );

        // Ensure arrays
        $required_products = is_array( $required_products ) ? $required_products : [];
        $required_courses = is_array( $required_courses ) ? $required_courses : [];

        // Get available products and courses
        $products = get_posts( [
            'post_type' => 'vrstore_product',
            'post_status' => 'publish',
            'numberposts' => -1,
            'orderby' => 'title',
            'order' => 'ASC'
        ] );

        $courses = get_posts( [
            'post_type' => 'vrstore_course',
            'post_status' => 'publish',
            'numberposts' => -1,
            'orderby' => 'title',
            'order' => 'ASC'
        ] );

        ?>
        <div class="vrstore-content-restriction-metabox">
            <?php if ( $has_taxonomy_restrictions ) : ?>
                <div class="notice notice-info inline" style="margin: 0 0 15px 0; padding: 10px;">
                    <p>
                        <span class="dashicons dashicons-info" style="color: #0073aa;"></span>
                        <strong><?php echo vrstore_is_textdomain_ready() ? esc_html__( 'Taxonomy Restriction Active', 'vira-store' ) : esc_html( 'Taxonomy Restriction Active' ); ?></strong>
                    </p>
                    <p style="margin: 5px 0 0 0;">
                        <?php echo vrstore_is_textdomain_ready() ? esc_html__( 'This post has taxonomy-based restrictions that will override the content restriction settings below. The taxonomy restrictions will control access to this content.', 'vira-store' ) : esc_html( 'This post has taxonomy-based restrictions that will override the content restriction settings below. The taxonomy restrictions will control access to this content.' ); ?>
                    </p>
                </div>
            <?php endif; ?>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="vrstore_content_restricted">
                            <?php echo vrstore_is_textdomain_ready() ? esc_html__( 'Enable Content Restriction', 'vira-store' ) : esc_html( 'Enable Content Restriction' ); ?>
                        </label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" id="vrstore_content_restricted" name="vrstore_content_restricted" value="1" <?php checked( $is_restricted, '1' ); ?> />
                            <?php echo vrstore_is_textdomain_ready() ? esc_html__( 'Restrict this content to customers who have purchased specific products/courses', 'vira-store' ) : esc_html( 'Restrict this content to customers who have purchased specific products/courses' ); ?>
                        </label>
                    </td>
                </tr>
            </table>

            <div id="vrstore-restriction-settings" style="<?php echo $is_restricted ? '' : 'display: none;'; ?>">
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="vrstore_required_products">
                                <?php echo vrstore_is_textdomain_ready() ? esc_html__( 'Required Products', 'vira-store' ) : esc_html( 'Required Products' ); ?>
                            </label>
                        </th>
                        <td>
                            <select id="vrstore_required_products" name="vrstore_required_products[]" multiple="multiple" style="width: 100%; min-height: 120px;">
                                <?php foreach ( $products as $product ) : ?>
                                    <option value="<?php echo esc_attr( $product->ID ); ?>" <?php selected( in_array( $product->ID, $required_products, true ) ); ?>>
                                        <?php echo esc_html( $product->post_title ); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <p class="description">
                                <?php echo vrstore_is_textdomain_ready() ? esc_html__( 'Select products that customers must purchase to access this content. Hold Ctrl/Cmd to select multiple.', 'vira-store' ) : esc_html( 'Select products that customers must purchase to access this content. Hold Ctrl/Cmd to select multiple.' ); ?>
                            </p>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">
                            <label for="vrstore_required_courses">
                                <?php echo vrstore_is_textdomain_ready() ? esc_html__( 'Required Courses', 'vira-store' ) : esc_html( 'Required Courses' ); ?>
                            </label>
                        </th>
                        <td>
                            <select id="vrstore_required_courses" name="vrstore_required_courses[]" multiple="multiple" style="width: 100%; min-height: 120px;">
                                <?php foreach ( $courses as $course ) : ?>
                                    <option value="<?php echo esc_attr( $course->ID ); ?>" <?php selected( in_array( $course->ID, $required_courses, true ) ); ?>>
                                        <?php echo esc_html( $course->post_title ); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <p class="description">
                                <?php echo vrstore_is_textdomain_ready() ? esc_html__( 'Select courses that customers must purchase to access this content. Hold Ctrl/Cmd to select multiple.', 'vira-store' ) : esc_html( 'Select courses that customers must purchase to access this content. Hold Ctrl/Cmd to select multiple.' ); ?>
                            </p>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">
                            <label for="vrstore_restriction_message">
                                <?php echo vrstore_is_textdomain_ready() ? esc_html__( 'Custom Message for Non-Customers', 'vira-store' ) : esc_html( 'Custom Message for Non-Customers' ); ?>
                            </label>
                        </th>
                        <td>
                            <textarea id="vrstore_restriction_message" name="vrstore_restriction_message" rows="4" class="large-text" placeholder="<?php echo esc_attr( vrstore_is_textdomain_ready() ? __( 'This content is available to customers who have purchased our premium products...', 'vira-store' ) : 'This content is available to customers who have purchased our premium products...' ); ?>"><?php echo esc_textarea( $custom_message ); ?></textarea>
                            <p class="description">
                                <?php echo vrstore_is_textdomain_ready() ? esc_html__( 'Optional custom message to display to non-customers instead of the default message.', 'vira-store' ) : esc_html( 'Optional custom message to display to non-customers instead of the default message.' ); ?>
                            </p>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">
                            <label for="vrstore_restricted_content">
                                <?php echo vrstore_is_textdomain_ready() ? esc_html__( 'Restricted Content', 'vira-store' ) : esc_html( 'Restricted Content' ); ?>
                            </label>
                        </th>
                        <td>
                            <div class="vrstore-content-editor">
                                <div class="vrstore-editor-toolbar">
                                    <button type="button" class="button vrstore-format-btn" data-format="bold" title="Bold">
                                        <strong>B</strong>
                                    </button>
                                    <button type="button" class="button vrstore-format-btn" data-format="italic" title="Italic">
                                        <em>I</em>
                                    </button>
                                    <button type="button" class="button vrstore-format-btn" data-format="link" title="Link">
                                        🔗
                                    </button>
                                    <button type="button" class="button vrstore-format-btn" data-format="ul" title="Unordered List">
                                        • List
                                    </button>
                                    <button type="button" class="button vrstore-format-btn" data-format="ol" title="Ordered List">
                                        1. List
                                    </button>
                                </div>
                                <textarea id="vrstore_restricted_content" name="vrstore_restricted_content" rows="10" class="large-text" placeholder="<?php echo esc_attr( vrstore_is_textdomain_ready() ? __( 'Enter the content that will be visible only to customers who have purchased the required products/courses...', 'vira-store' ) : 'Enter the content that will be visible only to customers who have purchased the required products/courses...' ); ?>"><?php echo esc_textarea( $restricted_content ); ?></textarea>
                            </div>
                            <p class="description">
                                <?php echo vrstore_is_textdomain_ready() ? esc_html__( 'This content will only be visible to customers who have purchased the required products/courses. Basic HTML formatting is supported.', 'vira-store' ) : esc_html( 'This content will only be visible to customers who have purchased the required products/courses. Basic HTML formatting is supported.' ); ?>
                            </p>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        <?php
    }

    /**
     * Save content restriction metabox
     *
     * @param int     $post_id Post ID
     * @param WP_Post $post    Post object
     * @return void
     */
    public function save_content_restriction_metabox( int $post_id, $post ): void {
        // Check if we're saving the correct post type
        if ( ! in_array( $post->post_type, [ 'post', 'page' ], true ) ) {
            return;
        }

        // Check if user has permissions to save data
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }

        // Check if not an autosave
        if ( wp_is_post_autosave( $post_id ) ) {
            return;
        }

        // Check if not a revision
        if ( wp_is_post_revision( $post_id ) ) {
            return;
        }

        // Verify nonce
        if ( ! isset( $_POST['vrstore_content_restriction_nonce'] ) || 
             ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['vrstore_content_restriction_nonce'] ) ), 'vrstore_content_restriction_nonce' ) ) {
            return;
        }

        // Save restriction status
        if ( isset( $_POST['vrstore_content_restricted'] ) ) {
            update_post_meta( $post_id, '_vrstore_content_restricted', '1' );
        } else {
            delete_post_meta( $post_id, '_vrstore_content_restricted' );
        }

        // Save required products
        if ( isset( $_POST['vrstore_required_products'] ) && is_array( $_POST['vrstore_required_products'] ) ) {
            $required_products = array_map( 'intval', wp_unslash( $_POST['vrstore_required_products'] ) );
            update_post_meta( $post_id, '_vrstore_required_products', $required_products );
        } else {
            delete_post_meta( $post_id, '_vrstore_required_products' );
        }

        // Save required courses
        if ( isset( $_POST['vrstore_required_courses'] ) && is_array( $_POST['vrstore_required_courses'] ) ) {
            $required_courses = array_map( 'intval', wp_unslash( $_POST['vrstore_required_courses'] ) );
            update_post_meta( $post_id, '_vrstore_required_courses', $required_courses );
        } else {
            delete_post_meta( $post_id, '_vrstore_required_courses' );
        }

        // Save custom message
        if ( isset( $_POST['vrstore_restriction_message'] ) ) {
            $custom_message = sanitize_textarea_field( wp_unslash( $_POST['vrstore_restriction_message'] ) );
            update_post_meta( $post_id, '_vrstore_restriction_message', $custom_message );
        } else {
            delete_post_meta( $post_id, '_vrstore_restriction_message' );
        }

        // Save restricted content with basic HTML sanitization
        if ( isset( $_POST['vrstore_restricted_content'] ) ) {
            $restricted_content = wp_kses( wp_unslash( $_POST['vrstore_restricted_content'] ), [
                'p' => [],
                'br' => [],
                'strong' => [],
                'b' => [],
                'em' => [],
                'i' => [],
                'u' => [],
                'a' => [
                    'href' => [],
                    'title' => [],
                    'target' => [],
                ],
                'ul' => [],
                'ol' => [],
                'li' => [],
                'div' => [
                    'class' => [],
                ],
                'span' => [
                    'class' => [],
                ],
                'h1' => [],
                'h2' => [],
                'h3' => [],
                'h4' => [],
                'h5' => [],
                'h6' => [],
            ] );
            update_post_meta( $post_id, '_vrstore_restricted_content', $restricted_content );
        } else {
            delete_post_meta( $post_id, '_vrstore_restricted_content' );
        }
    }

    /**
     * Filter restricted content on frontend
     *
     * @param string $content Post content
     * @return string Modified content
     */
    public function filter_restricted_content( $content ): string {
        global $post;

        // Only process on single posts/pages
        if ( ! is_singular( [ 'post', 'page' ] ) || ! $post ) {
            return $content;
        }

        // Check if content is restricted
        $is_restricted = get_post_meta( $post->ID, '_vrstore_content_restricted', true );
        if ( ! $is_restricted ) {
            return $content;
        }

        // Admin users can always see content
        if ( current_user_can( 'manage_options' ) ) {
            $restricted_content = get_post_meta( $post->ID, '_vrstore_restricted_content', true );
            if ( $restricted_content ) {
                $content .= $this->render_unlocked_content( $restricted_content );
            }
            return $content;
        }

        // Check if user has access
        if ( $this->user_has_access( $post->ID ) ) {
            $restricted_content = get_post_meta( $post->ID, '_vrstore_restricted_content', true );
            if ( $restricted_content ) {
                $content .= $this->render_unlocked_content( $restricted_content );
            }
            return $content;
        }

        // User doesn't have access, show restriction overlay
        return $content . $this->get_restriction_overlay( $post->ID );
    }

    /**
     * Check if current user has access to restricted content
     *
     * @param int $post_id Post ID
     * @return bool
     */
    private function user_has_access( int $post_id ): bool {
        // Get current user
        $user_id = get_current_user_id();
        if ( ! $user_id ) {
            return false;
        }

        // Get required products and courses
        $required_products = get_post_meta( $post_id, '_vrstore_required_products', true );
        $required_courses = get_post_meta( $post_id, '_vrstore_required_courses', true );

        $required_products = is_array( $required_products ) ? $required_products : [];
        $required_courses = is_array( $required_courses ) ? $required_courses : [];

        // If no requirements set, deny access
        if ( empty( $required_products ) && empty( $required_courses ) ) {
            return false;
        }

        // Check if user has purchased required products/courses
        return $this->user_has_purchased_items( $user_id, $required_products, $required_courses );
    }

    /**
     * Check if user has purchased required items
     *
     * @param int   $user_id           User ID
     * @param array $required_products Required product IDs
     * @param array $required_courses  Required course IDs
     * @return bool
     */
    private function user_has_purchased_items( int $user_id, array $required_products, array $required_courses ): bool {
        global $wpdb;

        $orders_table = $wpdb->prefix . 'vrstore_orders';

        // Get user email
        $user = get_user_by( 'ID', $user_id );
        if ( ! $user ) {
            return false;
        }

        // Get user's completed orders using customer_email
        $user_orders = $wpdb->get_results( $wpdb->prepare(
            "SELECT product_id FROM $orders_table 
             WHERE customer_email = %s 
             AND payment_status = 'completed' 
             AND order_status = 'completed'",
            $user->user_email
        ) );

        if ( empty( $user_orders ) ) {
            return false;
        }

        $purchased_items = array_map( 'intval', wp_list_pluck( $user_orders, 'product_id' ) );

        // Check if user has purchased any of the required products
        if ( ! empty( $required_products ) ) {
            $has_product = ! empty( array_intersect( $required_products, $purchased_items ) );
            if ( $has_product ) {
                return true;
            }
        }

        // Check if user has purchased any of the required courses
        if ( ! empty( $required_courses ) ) {
            $has_course = ! empty( array_intersect( $required_courses, $purchased_items ) );
            if ( $has_course ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Get restriction overlay HTML
     *
     * @param int $post_id Post ID
     * @return string
     */
    private function get_restriction_overlay( int $post_id ): string {
        $required_products = get_post_meta( $post_id, '_vrstore_required_products', true );
        $required_courses = get_post_meta( $post_id, '_vrstore_required_courses', true );
        $custom_message = get_post_meta( $post_id, '_vrstore_restriction_message', true );
        $required_products = is_array( $required_products ) ? $required_products : [];
        $required_courses = is_array( $required_courses ) ? $required_courses : [];
        $all_required_items = array_merge( $required_products, $required_courses );

        ob_start();
        ?>
        <div class="vrstore-content-restriction-overlay">
            <div class="vrstore-restriction-content">
                <div class="vrstore-restriction-message">
                    <?php if ( $custom_message ) : ?>
                        <p><?php echo wp_kses_post( $custom_message ); ?></p>
                    <?php else : ?>
                        <p>
                            <?php echo vrstore_is_textdomain_ready() ? esc_html__( 'This content is restricted. Please purchase the required products to access it.', 'vira-store' ) : esc_html( 'This content is restricted. Please purchase the required products to access it.' ); ?>
                        </p>
                    <?php endif; ?>
                </div>
                
                <?php if ( ! empty( $all_required_items ) ) : ?>
                    <div class="vrstore-required-items">
                        <?php foreach ( $all_required_items as $item_id ) : 
                            $item = get_post( $item_id );
                            if ( $item ) :
                                $item_url = get_permalink( $item_id );
                                $featured_image = get_the_post_thumbnail( $item_id, 'thumbnail' );
                        ?>
                            <div class="vrstore-required-item">
                                <?php if ( $featured_image ) : ?>
                                    <div class="vrstore-item-image">
                                        <?php echo $featured_image; ?>
                                    </div>
                                <?php endif; ?>
                                <div class="vrstore-item-content">
                                    <h4><?php echo esc_html( $item->post_title ); ?></h4>
                                    <a href="<?php echo esc_url( $item_url ); ?>" class="vrstore-purchase-btn">
                                        <?php echo vrstore_is_textdomain_ready() ? esc_html__( 'Purchase Now', 'vira-store' ) : esc_html( 'Purchase Now' ); ?>
                                    </a>
                                </div>
                            </div>
                        <?php 
                            endif;
                        endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Check if post has taxonomy restrictions
     *
     * @param int $post_id Post ID
     * @return bool True if post has taxonomy restrictions, false otherwise
     */
    private function post_has_taxonomy_restrictions( int $post_id ): bool {
        $supported_taxonomies = [ 'category', 'post_tag' ];
        $post_taxonomies = get_object_taxonomies( get_post_type( $post_id ) );
        
        foreach ( $post_taxonomies as $taxonomy ) {
            if ( ! in_array( $taxonomy, $supported_taxonomies, true ) ) {
                continue;
            }
            
            $terms = wp_get_post_terms( $post_id, $taxonomy, [ 'fields' => 'ids' ] );
            
            if ( is_wp_error( $terms ) || empty( $terms ) ) {
                continue;
            }
            
            foreach ( $terms as $term_id ) {
                $restricted = get_term_meta( $term_id, '_vrstore_taxonomy_restricted', true );
                if ( $restricted ) {
                    return true;
                }
            }
        }
        
        return false;
    }

    /**
     * Enqueue admin scripts
     *
     * @param string $hook_suffix Current admin page
     * @return void
     */
    public function enqueue_admin_scripts( $hook_suffix ): void {
        global $post;

        // Only load on post/page edit screens
        if ( ! in_array( $hook_suffix, [ 'post.php', 'post-new.php' ], true ) ) {
            return;
        }

        // Only load for posts and pages
        if ( ! $post || ! in_array( $post->post_type, [ 'post', 'page' ], true ) ) {
            return;
        }

        wp_enqueue_script(
            'vrstore-content-restriction-admin',
            VRSTORE_PLUGIN_URL . 'assets/js/content-restriction-admin.js',
            [ 'jquery' ],
            VRSTORE_VERSION,
            true
        );
    }

    /**
     * Render unlocked restricted content with improved UI
     *
     * @param string $restricted_content The restricted content to display
     * @return string HTML for unlocked content
     */
    private function render_unlocked_content( string $restricted_content ): string {
        if ( empty( $restricted_content ) ) {
            return '';
        }

        $title = vrstore_is_textdomain_ready() ? __( 'Premium Content Unlocked', 'vira-store' ) : 'Premium Content Unlocked';
        $copy_text = vrstore_is_textdomain_ready() ? __( 'Copy Content', 'vira-store' ) : 'Copy Content';
        
        $html = '<div class="vrstore-restricted-content">';
        $html .= '<div class="vrstore-restricted-content-header">';
        $html .= '<h3 class="vrstore-restricted-content-title">' . esc_html( $title ) . '</h3>';
        $html .= '<button class="vrstore-copy-button" onclick="vrstoreCopyContent(this)" title="' . esc_attr( $copy_text ) . '">';
        $html .= esc_html( $copy_text );
        $html .= '</button>';
        $html .= '</div>';
        $html .= '<div class="vrstore-restricted-content-body">';
        $html .= wp_kses_post( $restricted_content );
        $html .= '</div>';
        $html .= '</div>';

        return $html;
    }

    /**
     * Enqueue frontend scripts and styles
     *
     * @return void
     */
    public function enqueue_frontend_scripts(): void {
        // Only load on single posts/pages with restrictions
        if ( ! is_singular( [ 'post', 'page' ] ) ) {
            return;
        }

        global $post;
        if ( ! $post ) {
            return;
        }

        $is_restricted = get_post_meta( $post->ID, '_vrstore_content_restricted', true );
        if ( ! $is_restricted ) {
            return;
        }

        // Check if user has access to see if we need copy functionality
        if ( current_user_can( 'manage_options' ) || $this->user_has_access( $post->ID ) ) {
            wp_enqueue_script(
                'vrstore-content-restriction-frontend',
                VRSTORE_PLUGIN_URL . 'assets/js/content-restriction-frontend.js',
                [],
                VRSTORE_VERSION,
                true
            );
        }
    }
}

// Initialize the class
VRSTORE_Content_Restriction::get_instance();