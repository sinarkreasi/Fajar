<?php
/**
 * Course Custom Post Type
 *
 * @package Vira_Store
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Course management class
 */
class VRSTORE_Course {
    /**
     * Singleton instance
     *
     * @var VRSTORE_Course|null
     */
    private static ?VRSTORE_Course $instance = null;

    /**
     * Post type name
     *
     * @var string
     */
    private string $post_type = 'vrstore_course';

    /**
     * Get singleton instance
     *
     * @return VRSTORE_Course
     */
    public static function get_instance(): VRSTORE_Course {
        if (null === self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        // Register post type
        add_action('init', [$this, 'register_post_type']);

        // Register taxonomies
        add_action('init', [$this, 'register_taxonomies']);

        // Add meta boxes
        add_action('add_meta_boxes', [$this, 'add_meta_boxes']);

        // Save meta boxes
        add_action('save_post', [$this, 'save_meta_boxes'], 10, 2);

        // Add course columns
        add_filter('manage_' . $this->post_type . '_posts_columns', [$this, 'add_course_columns']);
        add_action('manage_' . $this->post_type . '_posts_custom_column', [$this, 'render_course_columns'], 10, 2);

        // Enqueue assets
        add_action('wp_enqueue_scripts', [$this, 'enqueue_frontend_assets']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);

        // Handle single course template display
        add_filter('the_content', [$this, 'filter_single_course_content'], 25);

        // Add duplicate action to row actions
        add_filter('post_row_actions', [$this, 'add_duplicate_row_action'], 10, 2);

        // Add AJAX handler for course duplication
        add_action('wp_ajax_vrstore_duplicate_course', [$this, 'ajax_duplicate_course']);
        
        // Add course deletion cleanup hook
        add_action('delete_post', [$this, 'cleanup_course_data_on_deletion'], 10, 2);
        
        // Add admin menu for Courses in main Vira Store dashboard
        add_action('admin_menu', [$this, 'add_admin_menu'], 15);
        
        // Add AJAX handlers for course enrollment and cart integration
        add_action('wp_ajax_vrstore_add_course_to_cart', [$this, 'ajax_add_course_to_cart']);
        add_action('wp_ajax_nopriv_vrstore_add_course_to_cart', [$this, 'ajax_add_course_to_cart']);
        add_action('wp_ajax_vrstore_enroll_free_course', [$this, 'ajax_enroll_free_course']);
        add_action('wp_ajax_nopriv_vrstore_enroll_free_course', [$this, 'ajax_enroll_free_course']);
        
        // Add AJAX handler for lesson completion
        add_action('wp_ajax_vrstore_mark_lesson_complete', [$this, 'ajax_mark_lesson_complete']);
        add_action('wp_ajax_nopriv_vrstore_mark_lesson_complete', [$this, 'ajax_mark_lesson_complete']);
        
        // Add AJAX handler for video tracking
        add_action('wp_ajax_vrstore_track_video_event', [$this, 'ajax_track_video_event']);
        add_action('wp_ajax_nopriv_vrstore_track_video_event', [$this, 'ajax_track_video_event']);

        // Add AJAX handler for shortcode preview
        add_action('wp_ajax_vrstore_preview_shortcode', [$this, 'ajax_preview_shortcode']);
        add_action('wp_ajax_nopriv_vrstore_preview_shortcode', [$this, 'ajax_preview_shortcode']);
        
        // Hook into order completion to handle course enrollment
        add_action('vrstore_order_created', [$this, 'handle_course_enrollment_on_order'], 10, 2);
        add_action('vrstore_order_completed', [$this, 'handle_course_enrollment_on_order'], 10, 2);
        add_action('vrstore_payment_completed', [$this, 'handle_course_enrollment_on_order'], 10, 2);
        
        // Handle secure course material downloads
        add_action('init', [$this, 'handle_course_material_download']);
        add_action('wp_ajax_vrstore_track_material_download', [$this, 'ajax_track_material_download']);
        add_action('wp_ajax_nopriv_vrstore_track_material_download', [$this, 'ajax_track_material_download']);
        
        // Hook into comment system to handle ratings
        add_action('comment_post', [$this, 'save_comment_rating']);
        add_action('wp_insert_comment', [$this, 'update_course_average_rating']);
        
        // Add lesson URL rewrite rules
        add_action('init', [$this, 'add_lesson_rewrite_rules']);
        add_filter('query_vars', [$this, 'add_lesson_query_vars']);
        add_action('template_redirect', [$this, 'handle_lesson_template']);
        
        // Ensure courses have license generation disabled
        add_action('save_post', [$this, 'ensure_course_license_generation_disabled'], 20, 2);
        
        // Filter course visibility on frontend queries
        add_action('pre_get_posts', [$this, 'filter_course_visibility']);
        
    }

    /**
     * AJAX handler for shortcode preview
     *
     * @return void
     */
    public function ajax_preview_shortcode(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_course_frontend_nonce')) {
            wp_send_json_error(__('Security check failed.', 'vira-store'));
        }

        $shortcode = sanitize_text_field(wp_unslash($_POST['shortcode'] ?? ''));
        
        if (empty($shortcode)) {
            wp_send_json_error(__('No shortcode provided.', 'vira-store'));
        }

        // Basic shortcode validation
        if (!preg_match('/^\[.*\]$/', trim($shortcode))) {
            wp_send_json_error(__('Invalid shortcode format.', 'vira-store'));
        }

        // Process the shortcode
        try {
            $content = do_shortcode($shortcode);
            
            // If content is empty or unchanged, it might be an invalid shortcode
            if (empty($content) || $content === $shortcode) {
                wp_send_json_success([
                    'content' => '<div style="text-align: center; color: #856404; padding: 20px;"><i class="dashicons dashicons-info" style="font-size: 24px; margin-bottom: 10px; display: block;"></i><p style="margin: 0;">Shortcode processed but no content was generated.</p><small style="color: #6c757d; margin-top: 5px; display: block;">This might be normal for some shortcodes or the shortcode might not be registered.</small></div>'
                ]);
            } else {
                wp_send_json_success([
                    'content' => $content
                ]);
            }
        } catch (Exception $e) {
            wp_send_json_error(__('Error processing shortcode: ', 'vira-store') . $e->getMessage());
        }
    }

    /**
     * Get translated text with fallback for when textdomain is not loaded.
     *
     * @since 1.0.0
     * @param string $text Text to translate.
     * @param string $domain Text domain.
     * @return string Translated text or original text if textdomain not loaded.
     */
    private function get_translated_text($text, $domain = 'vira-store') {
        // Check if textdomain is loaded
        if (is_textdomain_loaded($domain)) {
            return esc_html__($text, $domain);
        }
        // Return escaped text without translation if textdomain not loaded
        return esc_html($text);
    }

    /**
     * Register post type
     *
     * @return void
     */
    public function register_post_type(): void {
        // Get configurable permalink slug from settings - use fallback if settings not available
        $permalink_slug = 'course'; // Default fallback
        if (class_exists('VRSTORE_Settings')) {
            try {
                $settings = VRSTORE_Settings::get_instance();
                $permalink_slug = $settings->get_setting('course_permalink_slug', 'course');
            } catch (Exception $e) {
                // Use default if settings aren't ready yet
            }
        }

        $labels = [
            'name'               => _x('Courses', 'post type general name', 'vira-store'),
            'singular_name'      => _x('Course', 'post type singular name', 'vira-store'),
            'menu_name'          => _x('Courses', 'admin menu', 'vira-store'),
            'name_admin_bar'     => _x('Course', 'add new on admin bar', 'vira-store'),
            'add_new'            => _x('Add New', 'course', 'vira-store'),
            'add_new_item'       => __('Add New Course', 'vira-store'),
            'new_item'           => __('New Course', 'vira-store'),
            'edit_item'          => __('Edit Course', 'vira-store'),
            'view_item'          => __('View Course', 'vira-store'),
            'all_items'          => __('All Courses', 'vira-store'),
            'search_items'       => __('Search Courses', 'vira-store'),
            'parent_item_colon'  => __('Parent Courses:', 'vira-store'),
            'not_found'          => __('No courses found.', 'vira-store'),
            'not_found_in_trash' => __('No courses found in Trash.', 'vira-store'),
        ];

        $args = [
            'labels'             => $labels,
            'description'        => __('Courses for Vira Store.', 'vira-store'),
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => false, // Will be added as submenu under Products
            'show_in_rest'       => true,
            'query_var'          => true,
            'rewrite'            => ['slug' => sanitize_title($permalink_slug)],
            'capability_type'    => 'post',
            'has_archive'        => true,
            'hierarchical'       => false,
            'menu_position'      => null,
            'supports'           => ['title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments'],
            'menu_icon'          => 'dashicons-welcome-learn-more',
        ];

        register_post_type($this->post_type, $args);
    }

    /**
     * Register taxonomies
     *
     * @return void
     */
    public function register_taxonomies(): void {
        // Register course category taxonomy
        $category_labels = [
            'name'              => _x('Categories', 'taxonomy general name', 'vira-store'),
            'singular_name'     => _x('Course Category', 'taxonomy singular name', 'vira-store'),
            'search_items'      => __('Search Course Categories', 'vira-store'),
            'all_items'         => __('All Course Categories', 'vira-store'),
            'parent_item'       => __('Parent Course Category', 'vira-store'),
            'parent_item_colon' => __('Parent Course Category:', 'vira-store'),
            'edit_item'         => __('Edit Course Category', 'vira-store'),
            'update_item'       => __('Update Course Category', 'vira-store'),
            'add_new_item'      => __('Add New Course Category', 'vira-store'),
            'new_item_name'     => __('New Course Category Name', 'vira-store'),
            'menu_name'         => __('Categories', 'vira-store'),
        ];

        $category_args = [
            'hierarchical'      => true,
            'labels'            => $category_labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => ['slug' => 'course-category'],
            'show_in_rest'      => true,
            'meta_box_cb'       => 'post_categories_meta_box',
        ];

        register_taxonomy('vrstore_course_cat', [$this->post_type], $category_args);

        // Register course tag taxonomy
        $tag_labels = [
            'name'              => _x('Tags', 'taxonomy general name', 'vira-store'),
            'singular_name'     => _x('Course Tag', 'taxonomy singular name', 'vira-store'),
            'search_items'      => __('Search Course Tags', 'vira-store'),
            'all_items'         => __('All Course Tags', 'vira-store'),
            'parent_item'       => __('Parent Course Tag', 'vira-store'),
            'parent_item_colon' => __('Parent Course Tag:', 'vira-store'),
            'edit_item'         => __('Edit Course Tag', 'vira-store'),
            'update_item'       => __('Update Course Tag', 'vira-store'),
            'add_new_item'      => __('Add New Course Tag', 'vira-store'),
            'new_item_name'     => __('New Course Tag Name', 'vira-store'),
            'menu_name'         => __('Tags', 'vira-store'),
        ];

        $tag_args = [
            'hierarchical'      => false,
            'labels'            => $tag_labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => ['slug' => 'course-tag'],
            'show_in_rest'      => true,
            'meta_box_cb'       => 'post_tags_meta_box',
        ];

        register_taxonomy('vrstore_course_tag', [$this->post_type], $tag_args);
    }

    /**
     * Add meta boxes
     *
     * @return void
     */
    public function add_meta_boxes(): void {
        add_meta_box(
            'vrstore_course_details',
            __('Course Details', 'vira-store'),
            [$this, 'render_course_details_meta_box'],
            $this->post_type,
            'normal',
            'high'
        );

        add_meta_box(
            'vrstore_course_curriculum',
            __('Course Curriculum', 'vira-store'),
            [$this, 'render_course_curriculum_meta_box'],
            $this->post_type,
            'normal',
            'high'
        );

        // Instructor metabox removed - now using WordPress author system

        add_meta_box(
            'vrstore_course_pricing',
            __('Course Pricing', 'vira-store'),
            [$this, 'render_course_pricing_meta_box'],
            $this->post_type,
            'side',
            'default'
        );
        
        add_meta_box(
            'vrstore_course_access_control',
            __('Course Access Control', 'vira-store'),
            [$this, 'render_course_access_control_meta_box'],
            $this->post_type,
            'side',
            'default'
        );
    }

    /**
     * Render course details meta box
     *
     * @param WP_Post $post Post object
     * @return void
     */
    public function render_course_details_meta_box($post): void {
        // Add nonce for security
        wp_nonce_field('vrstore_course_details_nonce', 'vrstore_course_details_nonce');

        // Get meta values
        $duration = get_post_meta($post->ID, '_vrstore_course_duration', true) ?: '';
        $level = get_post_meta($post->ID, '_vrstore_course_level', true) ?: 'beginner';
        $language = get_post_meta($post->ID, '_vrstore_course_language', true) ?: 'English';
        $objectives = get_post_meta($post->ID, '_vrstore_course_objectives', true) ?: '';
        $demo_url = get_post_meta($post->ID, '_vrstore_course_demo_url', true) ?: '';
        $certification = get_post_meta($post->ID, '_vrstore_course_certification', true) ?: '';
        $signature_image = get_post_meta($post->ID, '_vrstore_course_signature_image', true) ?: '';

        echo '<div class="vrstore-meta-box">';
        echo '<table class="form-table">';

        // Duration
        echo '<tr>';
        echo '<th><label for="vrstore_course_duration">' . $this->get_translated_text('Duration', 'vira-store') . '</label></th>';
        echo '<td>';
        echo '<input type="text" id="vrstore_course_duration" name="vrstore_course_duration" value="' . esc_attr($duration) . '" class="regular-text" placeholder="e.g., 8 weeks, 40 hours" />';
        echo '<p class="description">' . $this->get_translated_text('Course duration (e.g., 8 weeks, 40 hours)', 'vira-store') . '</p>';
        echo '</td>';
        echo '</tr>';

        // Level
        echo '<tr>';
        echo '<th><label for="vrstore_course_level">' . $this->get_translated_text('Skill Level', 'vira-store') . '</label></th>';
        echo '<td>';
        echo '<select id="vrstore_course_level" name="vrstore_course_level" class="regular-text">';
        echo '<option value="beginner"' . selected($level, 'beginner', false) . '>' . $this->get_translated_text('Beginner', 'vira-store') . '</option>';
        echo '<option value="intermediate"' . selected($level, 'intermediate', false) . '>' . $this->get_translated_text('Intermediate', 'vira-store') . '</option>';
        echo '<option value="advanced"' . selected($level, 'advanced', false) . '>' . $this->get_translated_text('Advanced', 'vira-store') . '</option>';
        echo '</select>';
        echo '</td>';
        echo '</tr>';

        // Language
        echo '<tr>';
        echo '<th><label for="vrstore_course_language">' . $this->get_translated_text('Language', 'vira-store') . '</label></th>';
        echo '<td>';
        echo '<input type="text" id="vrstore_course_language" name="vrstore_course_language" value="' . esc_attr($language) . '" class="regular-text" />';
        echo '</td>';
        echo '</tr>';

        // Demo URL
        echo '<tr>';
        echo '<th><label for="vrstore_course_demo_url">' . $this->get_translated_text('Demo URL', 'vira-store') . '</label></th>';
        echo '<td>';
        echo '<input type="url" id="vrstore_course_demo_url" name="vrstore_course_demo_url" value="' . esc_attr($demo_url) . '" class="regular-text" placeholder="https://" />';
        echo '<p class="description">' . $this->get_translated_text('URL to course demo or preview', 'vira-store') . '</p>';
        echo '</td>';
        echo '</tr>';

        // Learning Objectives
        echo '<tr>';
        echo '<th><label for="vrstore_course_objectives">' . $this->get_translated_text('Learning Objectives', 'vira-store') . '</label></th>';
        echo '<td>';
        echo '<textarea id="vrstore_course_objectives" name="vrstore_course_objectives" rows="5" class="large-text" placeholder="' . esc_attr__('What will students learn? One objective per line...', 'vira-store') . '">' . esc_textarea($objectives) . '</textarea>';
        echo '<p class="description">' . $this->get_translated_text('List learning objectives, one per line', 'vira-store') . '</p>';
        echo '</td>';
        echo '</tr>';

        // Certification
        echo '<tr>';
        echo '<th><label for="vrstore_course_certification">' . $this->get_translated_text('Certification', 'vira-store') . '</label></th>';
        echo '<td>';
        echo '<label><input type="checkbox" id="vrstore_course_certification" name="vrstore_course_certification" value="1"' . checked($certification, '1', false) . ' /> ';
        echo $this->get_translated_text('Provides certificate upon completion', 'vira-store') . '</label>';
        echo '</td>';
        echo '</tr>';

        // Instructor Signature (only show when certification is enabled)
        echo '<tr id="vrstore_signature_row" style="display: ' . ($certification ? 'table-row' : 'none') . ';">';
        echo '<th><label for="vrstore_course_signature_image">' . $this->get_translated_text('Instructor Signature', 'vira-store') . '</label></th>';
        echo '<td>';
        echo '<input type="hidden" id="vrstore_course_signature_image" name="vrstore_course_signature_image" value="' . esc_attr($signature_image) . '" />';
        echo '<button type="button" class="button" id="vrstore_upload_signature">' . $this->get_translated_text('Upload Signature', 'vira-store') . '</button>';
        echo '<button type="button" class="button" id="vrstore_remove_signature" style="display: ' . ($signature_image ? 'inline-block' : 'none') . ';">' . $this->get_translated_text('Remove Signature', 'vira-store') . '</button>';
        echo '<div id="vrstore_signature_preview" style="margin-top: 10px;">';
        if ($signature_image) {
            $signature_url = wp_get_attachment_url($signature_image);
            if ($signature_url) {
                echo '<img src="' . esc_url($signature_url) . '" style="max-width: 200px; max-height: 100px; border: 1px solid #ddd; padding: 5px;" />';
            }
        }
        echo '</div>';
        echo '<p class="description">' . $this->get_translated_text('Upload instructor signature image for certificates (recommended size: 200x100px)', 'vira-store') . '</p>';
        echo '</td>';
        echo '</tr>';

        echo '</table>';
        echo '</div>';
    }

    /**
     * Render course curriculum meta box
     *
     * @param WP_Post $post Post object
     * @return void
     */
    public function render_course_curriculum_meta_box($post): void {
        // Add nonce for security
        wp_nonce_field('vrstore_course_curriculum_nonce', 'vrstore_course_curriculum_nonce');

        // Get curriculum data
        $curriculum = get_post_meta($post->ID, '_vrstore_course_curriculum', true);
        if (!is_array($curriculum)) {
            $curriculum = [];
        }

        echo '<div class="vrstore-course-curriculum">';
        echo '<p>' . $this->get_translated_text('Add modules and lessons for this course. Each module can contain multiple lessons.', 'vira-store') . '</p>';

        echo '<div class="vrstore-curriculum-list sortable-modules">';
        if (!empty($curriculum)) {
            foreach ($curriculum as $index => $module) {
                $this->render_curriculum_module($index, $module);
            }
        } else {
            $this->render_curriculum_module(0, []);
        }
        echo '</div>';

        echo '<button type="button" class="button vrstore-add-module">' . $this->get_translated_text('Add Module', 'vira-store') . '</button>';
        echo '</div>';
    }

    /**
     * Render a single curriculum module
     *
     * @param int $index Module index
     * @param array $module Module data
     * @return void
     */
    private function render_curriculum_module($index, $module): void {
        $module_title = isset($module['title']) ? $module['title'] : '';
        $lessons = isset($module['lessons']) ? $module['lessons'] : [];

        echo '<div class="vrstore-curriculum-module" data-index="' . esc_attr($index) . '">';
        echo '<div class="module-header">';
        echo '<div class="module-controls">';
        echo '<button type="button" class="button button-small vrstore-move-module-top" data-index="' . esc_attr($index) . '" title="' . esc_attr__('Move to top', 'vira-store') . '">';
        echo '<span class="dashicons dashicons-arrow-up-alt2"></span></button>';
        echo '<button type="button" class="button button-small vrstore-move-module-bottom" data-index="' . esc_attr($index) . '" title="' . esc_attr__('Move to bottom', 'vira-store') . '">';
        echo '<span class="dashicons dashicons-arrow-down-alt2"></span></button>';
        echo '</div>';
        echo '<input type="text" name="vrstore_course_curriculum[' . $index . '][title]" value="' . esc_attr($module_title) . '" placeholder="' . esc_attr__('Module Title', 'vira-store') . '" class="module-title" />';
        echo '<button type="button" class="button vrstore-remove-module">' . $this->get_translated_text('Remove Module', 'vira-store') . '</button>';
        echo '</div>';

        echo '<div class="module-lessons sortable-lessons">';
        if (!empty($lessons)) {
            foreach ($lessons as $lesson_index => $lesson) {
                $this->render_curriculum_lesson($index, $lesson_index, $lesson);
            }
        } else {
            $this->render_curriculum_lesson($index, 0, []);
        }
        echo '</div>';

        echo '<button type="button" class="button vrstore-add-lesson" data-module="' . $index . '">' . $this->get_translated_text('Add Lesson', 'vira-store') . '</button>';
        echo '</div>';
    }

    /**
     * Render a single curriculum lesson
     *
     * @param int $module_index Module index
     * @param int $lesson_index Lesson index
     * @param array $lesson Lesson data
     * @return void
     */
    private function render_curriculum_lesson($module_index, $lesson_index, $lesson): void {
        $lesson_title = isset($lesson['title']) ? $lesson['title'] : '';
        $lesson_description = isset($lesson['description']) ? $lesson['description'] : '';
        $lesson_duration = isset($lesson['duration']) ? $lesson['duration'] : '';
        $lesson_type = isset($lesson['type']) ? $lesson['type'] : 'video_upload';
        $video_url = isset($lesson['video_url']) ? $lesson['video_url'] : '';
        $video_file = isset($lesson['video_file']) ? $lesson['video_file'] : '';
        $shortcode_content = isset($lesson['shortcode_content']) ? $lesson['shortcode_content'] : '';
        $is_free_preview = isset($lesson['is_free_preview']) ? $lesson['is_free_preview'] : false;
        $material_url = isset($lesson['material_url']) ? $lesson['material_url'] : '';
        $material_file = isset($lesson['material_file']) ? $lesson['material_file'] : '';

        echo '<div class="vrstore-curriculum-lesson" data-lesson-index="' . esc_attr($lesson_index) . '">';
        echo '<div class="lesson-row">';
        echo '<span class="lesson-drag-handle dashicons dashicons-menu" title="' . esc_attr__('Drag to reorder', 'vira-store') . '" style="cursor: move; margin-right: 8px; color: #666; vertical-align: middle;"></span>';
        echo '<input type="text" name="vrstore_course_curriculum[' . $module_index . '][lessons][' . $lesson_index . '][title]" value="' . esc_attr($lesson_title) . '" placeholder="' . esc_attr__('Lesson Title', 'vira-store') . '" class="lesson-title" style="width: 30%;" />';
        
        // Add lesson description field
        echo '<div style="margin: 10px 0; clear: both;">';
        echo '<label style="display: block; margin-bottom: 5px; font-weight: 600; color: #23282d; font-size: 13px;">' . $this->get_translated_text('Lesson Description', 'vira-store') . '</label>';
        echo '<textarea name="vrstore_course_curriculum[' . $module_index . '][lessons][' . $lesson_index . '][description]" placeholder="' . esc_attr__('Brief description of what students will learn in this lesson...', 'vira-store') . '" class="lesson-description" style="width: 100%; min-height: 80px; padding: 8px 12px; border: 1px solid #ddd; border-radius: 4px; font-size: 13px; line-height: 1.4; resize: vertical; box-sizing: border-box;">' . esc_textarea($lesson_description) . '</textarea>';
        echo '</div>';
        echo '<input type="text" name="vrstore_course_curriculum[' . $module_index . '][lessons][' . $lesson_index . '][duration]" value="' . esc_attr($lesson_duration) . '" placeholder="' . esc_attr__('5 min', 'vira-store') . '" class="lesson-duration" style="width: 15%;" />';
        echo '<select name="vrstore_course_curriculum[' . $module_index . '][lessons][' . $lesson_index . '][type]" class="lesson-type" style="width: 20%;">';
        echo '<option value="video_upload"' . selected($lesson_type, 'video_upload', false) . '>' . $this->get_translated_text('Video Upload', 'vira-store') . '</option>';
        echo '<option value="video_url"' . selected($lesson_type, 'video_url', false) . '>' . $this->get_translated_text('Video URL', 'vira-store') . '</option>';
        echo '<option value="shortcode"' . selected($lesson_type, 'shortcode', false) . '>' . $this->get_translated_text('Shortcode', 'vira-store') . '</option>';
        echo '</select>';
        echo '<button type="button" class="button vrstore-remove-lesson">' . $this->get_translated_text('Remove', 'vira-store') . '</button>';
        echo '</div>';

        // Video Upload Fields
        echo '<div class="lesson-video-upload-fields" style="' . ($lesson_type === 'video_upload' ? '' : 'display: none;') . ' margin-top: 10px; padding: 10px; background: #f9f9f9; border-radius: 4px; border-left: 4px solid #28a745;">';
        echo '<h4 style="margin: 0 0 10px 0; color: #28a745; font-size: 14px;">' . $this->get_translated_text('Video Upload', 'vira-store') . '</h4>';
        
        echo '<input type="hidden" name="vrstore_course_curriculum[' . $module_index . '][lessons][' . $lesson_index . '][video_file]" value="' . esc_attr($video_file) . '" class="lesson-video-file-id" />';
        echo '<div class="lesson-video-preview">';
        if ($video_file) {
            $video_url_file = wp_get_attachment_url($video_file);
            $video_title = get_the_title($video_file);
            echo '<div style="padding: 10px; background: white; border: 1px solid #ddd; border-radius: 4px; margin-bottom: 10px;">';
            echo '<i class="dashicons dashicons-video-alt3" style="color: #28a745; font-size: 20px; vertical-align: middle; margin-right: 8px;"></i>';
            echo '<strong>' . esc_html($video_title) . '</strong><br>';
            echo '<small style="color: #666;">' . esc_url($video_url_file) . '</small>';
            echo '</div>';
        }
        echo '</div>';
        echo '<button type="button" class="button select-video-file" data-module="' . $module_index . '" data-lesson="' . $lesson_index . '">' . $this->get_translated_text('Select Video File', 'vira-store') . '</button> ';
        if ($video_file) {
            echo '<button type="button" class="button remove-video-file" data-module="' . $module_index . '" data-lesson="' . $lesson_index . '">' . $this->get_translated_text('Remove File', 'vira-store') . '</button>';
        }
        echo '</div>';
        
        // Video URL Fields
        echo '<div class="lesson-video-url-fields" style="' . ($lesson_type === 'video_url' ? '' : 'display: none;') . ' margin-top: 10px; padding: 10px; background: #f9f9f9; border-radius: 4px; border-left: 4px solid #dc3545;">';
        echo '<h4 style="margin: 0 0 10px 0; color: #dc3545; font-size: 14px;">' . $this->get_translated_text('Video URL (YouTube, Vimeo, etc.)', 'vira-store') . '</h4>';
        
        echo '<div style="margin-bottom: 10px;">';
        echo '<label style="display: block; margin-bottom: 5px; font-weight: 600;">' . $this->get_translated_text('Video URL', 'vira-store') . '</label>';
        echo '<input type="url" name="vrstore_course_curriculum[' . $module_index . '][lessons][' . $lesson_index . '][video_url]" value="' . esc_attr($video_url) . '" placeholder="https://www.youtube.com/watch?v=... or https://vimeo.com/..." style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;" />';
        echo '<small style="color: #666; font-size: 12px; display: block; margin-top: 5px;">' . $this->get_translated_text('Supports YouTube, Vimeo, and other video platform URLs', 'vira-store') . '</small>';
        echo '</div>';
        echo '</div>';
        
        // Shortcode Fields
        echo '<div class="lesson-shortcode-fields" style="' . ($lesson_type === 'shortcode' ? '' : 'display: none;') . ' margin-top: 10px; padding: 10px; background: #f9f9f9; border-radius: 4px; border-left: 4px solid #9c27b0;">';
        echo '<h4 style="margin: 0 0 10px 0; color: #9c27b0; font-size: 14px;">' . $this->get_translated_text('Shortcode Content', 'vira-store') . '</h4>';
        
        echo '<div style="margin-bottom: 10px;">';
        echo '<label style="display: block; margin-bottom: 5px; font-weight: 600;">' . $this->get_translated_text('Shortcode', 'vira-store') . '</label>';
        echo '<textarea name="vrstore_course_curriculum[' . $module_index . '][lessons][' . $lesson_index . '][shortcode_content]" rows="4" placeholder="[your_shortcode param1=&quot;value1&quot; param2=&quot;value2&quot;]" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; font-family: monospace;">' . esc_textarea($shortcode_content) . '</textarea>';
        echo '<small style="color: #666; font-size: 12px; display: block; margin-top: 5px;">' . $this->get_translated_text('Enter any WordPress shortcode from external plugins (e.g., [video], [embed], [gallery], etc.)', 'vira-store') . '</small>';
        echo '</div>';
        echo '</div>';
        
        
        // Free preview option
        echo '<div style="margin-top: 10px;">';
        echo '<label style="display: flex; align-items: center; gap: 8px;">';
        echo '<input type="checkbox" name="vrstore_course_curriculum[' . $module_index . '][lessons][' . $lesson_index . '][is_free_preview]" value="1"' . checked($is_free_preview, '1', false) . ' />';
        echo '<span style="font-weight: 600; color: #0073aa;">' . $this->get_translated_text('Free Preview - Allow non-enrolled users to watch this lesson', 'vira-store') . '</span>';
        echo '</label>';
        echo '</div>';
        
        // Material fields (always show for all lesson types)
        echo '<div class="lesson-material-fields" style="margin-top: 10px; padding: 10px; background: #f0f8ff; border-radius: 4px; border-left: 4px solid #0073aa;">';
        
        echo '<h4 style="margin: 0 0 10px 0; color: #0073aa; font-size: 14px;">' . $this->get_translated_text('Lesson Materials', 'vira-store') . '</h4>';
        
        // Material URL field
        echo '<div style="margin-bottom: 10px;">';
        echo '<label style="display: block; margin-bottom: 5px; font-weight: 600;">' . $this->get_translated_text('Material URL (external link)', 'vira-store') . '</label>';
        echo '<input type="url" name="vrstore_course_curriculum[' . $module_index . '][lessons][' . $lesson_index . '][material_url]" value="' . esc_attr($material_url) . '" placeholder="https://example.com/resource" style="width: 100%;" />';
        echo '</div>';
        
        // Material file upload
        echo '<div style="margin-bottom: 10px;">';
        echo '<label style="display: block; margin-bottom: 5px; font-weight: 600;">' . $this->get_translated_text('Or Upload Material File', 'vira-store') . '</label>';
        echo '<input type="hidden" name="vrstore_course_curriculum[' . $module_index . '][lessons][' . $lesson_index . '][material_file]" value="' . esc_attr($material_file) . '" class="lesson-material-file-id" />';
        echo '<div class="lesson-material-preview">';
        if ($material_file) {
            $material_url_file = wp_get_attachment_url($material_file);
            $material_title = get_the_title($material_file);
            $file_ext = pathinfo($material_url_file, PATHINFO_EXTENSION);
            echo '<div style="padding: 10px; background: white; border: 1px solid #ddd; border-radius: 4px; display: flex; align-items: center; gap: 10px;">';
            echo '<i class="dashicons dashicons-media-document" style="color: #0073aa; font-size: 20px;"></i>';
            echo '<div style="flex: 1;">';
            echo '<strong>' . esc_html($material_title) . '</strong><br>';
            echo '<small style="color: #666;">' . strtoupper($file_ext) . ' • ' . size_format(filesize(get_attached_file($material_file))) . '</small>';
            echo '</div>';
            echo '</div>';
        }
        echo '</div>';
        echo '<button type="button" class="button select-material-file" data-module="' . $module_index . '" data-lesson="' . $lesson_index . '">' . $this->get_translated_text('Select Material File', 'vira-store') . '</button> ';
        if ($material_file) {
            echo '<button type="button" class="button remove-material-file" data-module="' . $module_index . '" data-lesson="' . $lesson_index . '">' . $this->get_translated_text('Remove File', 'vira-store') . '</button>';
        }
        echo '</div>';
        
        echo '</div>';
        
        echo '</div>';
        echo '</div>';
    }

    // Instructor metabox removed - now using WordPress author system

    /**
     * Render course pricing meta box
     *
     * @param WP_Post $post Post object
     * @return void
     */
    public function render_course_pricing_meta_box($post): void {
        // Add nonce for security
        wp_nonce_field('vrstore_course_pricing_nonce', 'vrstore_course_pricing_nonce');

        // Get meta values
        $price = get_post_meta($post->ID, '_vrstore_course_price', true) ?: '';
        $sale_price = get_post_meta($post->ID, '_vrstore_course_sale_price', true) ?: '';
        $currency = get_post_meta($post->ID, '_vrstore_course_currency', true) ?: 'USD';
        $is_free = get_post_meta($post->ID, '_vrstore_course_is_free', true) ?: '';
        $free_with_product = get_post_meta($post->ID, '_vrstore_course_free_with_product', true) ?: '';
        $required_product_id = get_post_meta($post->ID, '_vrstore_course_required_product_id', true) ?: '';

        // Get global currency
        $settings = null;
        if (class_exists('VRSTORE_Settings')) {
            try {
                $settings = VRSTORE_Settings::get_instance();
                $global_currency = $settings->get_setting('currency', 'USD');
                $currency_symbol = $this->get_currency_symbol($global_currency);
            } catch (Exception $e) {
                $global_currency = 'USD';
                $currency_symbol = '$';
            }
        } else {
            $global_currency = 'USD';
            $currency_symbol = '$';
        }

        echo '<div class="vrstore-meta-box">';

        // Pricing Options
        echo '<div class="pricing-options">';
        
        // Free Course Checkbox
        echo '<p><label><input type="radio" id="vrstore_course_pricing_type_free" name="vrstore_course_pricing_type" value="free"' . checked($is_free, '1', false) . ' /> ';
        echo $this->get_translated_text('This is a free course', 'vira-store') . '</label></p>';
        
        // Paid Course Option
        echo '<p><label><input type="radio" id="vrstore_course_pricing_type_paid" name="vrstore_course_pricing_type" value="paid"' . ((!$is_free && !$free_with_product) ? ' checked="checked"' : '') . ' /> ';
        echo $this->get_translated_text('This is a paid course', 'vira-store') . '</label></p>';
        
        // Free with Product Purchase Option
        echo '<p><label><input type="radio" id="vrstore_course_pricing_type_product" name="vrstore_course_pricing_type" value="product"' . checked($free_with_product, '1', false) . ' /> ';
        echo $this->get_translated_text('Free with product purchase', 'vira-store') . '</label></p>';
        
        echo '</div>';

        // Product Selection (only visible when "Free with product purchase" is selected)
        echo '<div id="product-selection-fields"' . ($free_with_product ? '' : ' style="display: none;"') . '>';
        echo '<p><label for="vrstore_course_required_product_id"><strong>' . $this->get_translated_text('Required Product', 'vira-store') . '</strong></label></p>';
        
        // Get all products
        $products = get_posts([
            'post_type' => 'vrstore_product',
            'post_status' => 'publish',
            'numberposts' => -1,
        ]);
        
        echo '<select id="vrstore_course_required_product_id" name="vrstore_course_required_product_id" class="widefat">';
        echo '<option value="">' . $this->get_translated_text('Select a product', 'vira-store') . '</option>';
        
        foreach ($products as $product) {
            echo '<option value="' . esc_attr($product->ID) . '"' . selected($required_product_id, $product->ID, false) . '>' . esc_html($product->post_title) . '</option>';
        }
        
        echo '</select>';
        echo '<p class="description">' . $this->get_translated_text('Select the product that users must purchase to access this course for free', 'vira-store') . '</p>';
        echo '</div>';

        // Regular Price Fields (only visible when "Paid course" is selected)
        echo '<div id="course-pricing-fields"' . ((!$is_free && !$free_with_product) ? '' : ' style="display: none;"') . '>';

        // Regular Price
        echo '<p><label for="vrstore_course_price"><strong>' . $this->get_translated_text('Regular Price', 'vira-store') . '</strong></label></p>';
        echo '<div style="display: flex; align-items: center; gap: 5px;">';
        echo '<span style="font-weight: bold;">' . esc_html($currency_symbol) . '</span>';
        echo '<input type="number" id="vrstore_course_price" name="vrstore_course_price" value="' . esc_attr($price) . '" step="0.01" min="0" class="widefat" placeholder="0.00" />';
        echo '</div>';

        // Sale Price
        echo '<p><label for="vrstore_course_sale_price"><strong>' . $this->get_translated_text('Sale Price', 'vira-store') . '</strong></label></p>';
        echo '<div style="display: flex; align-items: center; gap: 5px;">';
        echo '<span style="font-weight: bold;">' . esc_html($currency_symbol) . '</span>';
        echo '<input type="number" id="vrstore_course_sale_price" name="vrstore_course_sale_price" value="' . esc_attr($sale_price) . '" step="0.01" min="0" class="widefat" placeholder="0.00" />';
        echo '</div>';
        echo '<p class="description">' . $this->get_translated_text('Optional. Leave empty if no sale price. currency base main plugin setup', 'vira-store') . '</p>';

        echo '</div>';
        
        echo '</div>';
    }
    
    /**
     * Render course access control meta box
     *
     * @param WP_Post $post Post object
     * @return void
     */
    public function render_course_access_control_meta_box($post): void {
        // Add nonce for security
        wp_nonce_field('vrstore_course_access_control_nonce', 'vrstore_course_access_control_nonce');
        
        // Get meta values
        $access_period_type = get_post_meta($post->ID, '_vrstore_course_access_period_type', true) ?: 'lifetime';
        $access_period_value = get_post_meta($post->ID, '_vrstore_course_access_period_value', true) ?: '';
        $content_drip_enabled = get_post_meta($post->ID, '_vrstore_course_content_drip_enabled', true) ?: '';
        $drip_interval_type = get_post_meta($post->ID, '_vrstore_course_drip_interval_type', true) ?: 'days';
        $drip_interval_value = get_post_meta($post->ID, '_vrstore_course_drip_interval_value', true) ?: '1';
        $max_students = get_post_meta($post->ID, '_vrstore_course_max_students', true) ?: '';
        
        echo '<div class="vrstore-meta-box">';
        
        // Access Period
        echo '<div style="margin-bottom: 20px;">';
        echo '<label><strong>' . $this->get_translated_text('Course Access Period', 'vira-store') . '</strong></label>';
        echo '<div style="margin: 10px 0;">';
        
        echo '<div style="margin-bottom: 10px;">';
        echo '<label><input type="radio" name="vrstore_course_access_period_type" value="lifetime"' . checked($access_period_type, 'lifetime', false) . ' /> ';
        echo $this->get_translated_text('Lifetime Access', 'vira-store') . '</label>';
        echo '</div>';
        
        echo '<div style="margin-bottom: 10px;">';
        echo '<label><input type="radio" name="vrstore_course_access_period_type" value="limited"' . checked($access_period_type, 'limited', false) . ' /> ';
        echo $this->get_translated_text('Limited Period:', 'vira-store') . '</label>';
        echo '</div>';
        
        echo '<div style="margin-bottom: 10px; margin-left: 20px; display: flex; align-items: center; gap: 10px;" class="vrstore-limited-period-settings">';
        echo '<input type="number" name="vrstore_course_access_period_value" value="' . esc_attr($access_period_value) . '" min="1" style="width: 60px;" />';
        
        echo '<select name="vrstore_course_access_period_unit" style="width: auto;">';
        $access_period_unit = get_post_meta($post->ID, '_vrstore_course_access_period_unit', true) ?: 'months';
        echo '<option value="days"' . selected($access_period_unit, 'days', false) . '>' . $this->get_translated_text('Days', 'vira-store') . '</option>';
        echo '<option value="weeks"' . selected($access_period_unit, 'weeks', false) . '>' . $this->get_translated_text('Weeks', 'vira-store') . '</option>';
        echo '<option value="months"' . selected($access_period_unit, 'months', false) . '>' . $this->get_translated_text('Months', 'vira-store') . '</option>';
        echo '<option value="years"' . selected($access_period_unit, 'years', false) . '>' . $this->get_translated_text('Years', 'vira-store') . '</option>';
        echo '</select>';
        echo '</div>';
        
        echo '<p class="description" style="margin-top: 5px;">' . $this->get_translated_text('Set how long students can access this course after enrollment/purchase.', 'vira-store') . '</p>';
        echo '</div>';
        
        // Content Dripping
        echo '<div style="margin-bottom: 20px;">';
        echo '<label><strong>' . $this->get_translated_text('Content Dripping', 'vira-store') . '</strong></label>';
        echo '<div style="margin: 10px 0;">';
        
        echo '<div style="margin-bottom: 10px;">';
        echo '<label><input type="checkbox" name="vrstore_course_content_drip_enabled" value="1"' . checked($content_drip_enabled, '1', false) . ' /> ';
        echo $this->get_translated_text('Enable Content Dripping', 'vira-store') . '</label>';
        echo '</div>';
        
        echo '<div id="drip-settings" style="' . ($content_drip_enabled ? '' : 'display: none;') . ' margin-left: 20px; padding: 10px; background: #f9f9f9; border-radius: 4px;">';
        echo '<p style="margin: 0 0 10px 0; font-weight: 600;">' . $this->get_translated_text('Release Schedule:', 'vira-store') . '</p>';
        echo '<div style="display: flex; align-items: center; gap: 10px;">';
        echo '<input type="number" name="vrstore_course_drip_interval_value" value="' . esc_attr($drip_interval_value) . '" min="1" style="width: 60px;" />';
        echo '<select name="vrstore_course_drip_interval_type">';
        echo '<option value="days"' . selected($drip_interval_type, 'days', false) . '>' . $this->get_translated_text('Day(s)', 'vira-store') . '</option>';
        echo '<option value="weeks"' . selected($drip_interval_type, 'weeks', false) . '>' . $this->get_translated_text('Week(s)', 'vira-store') . '</option>';
        echo '</select>';
        echo '</div>';
        echo '<p class="description" style="margin: 5px 0 0 0;">' . $this->get_translated_text('Lessons will be released gradually according to this schedule.', 'vira-store') . '</p>';
        echo '</div>';
        echo '</div>';
        
        // Trial Period
        echo '<div style="margin-bottom: 20px;">';
        echo '<label><strong>' . $this->get_translated_text('Trial Access', 'vira-store') . '</strong></label>';
        $trial_enabled = get_post_meta($post->ID, '_vrstore_course_trial_enabled', true) ?: '';
        $trial_period = get_post_meta($post->ID, '_vrstore_course_trial_period', true) ?: '7';
        
        echo '<div style="margin: 10px 0;">';
        echo '<label><input type="checkbox" name="vrstore_course_trial_enabled" value="1"' . checked($trial_enabled, '1', false) . ' /> ';
        echo $this->get_translated_text('Allow free trial access', 'vira-store') . '</label>';
        echo '</div>';
        
        echo '<div id="trial-settings" style="' . ($trial_enabled ? '' : 'display: none;') . ' margin-left: 20px; display: flex; align-items: center; gap: 10px;">';
        echo '<input type="number" name="vrstore_course_trial_period" value="' . esc_attr($trial_period) . '" min="1" style="width: 60px;" />';
        echo '<span>' . $this->get_translated_text('days free trial', 'vira-store') . '</span>';
        echo '</div>';
        
        echo '<p class="description" style="margin-top: 5px;">' . $this->get_translated_text('Users can access the course for free during trial period.', 'vira-store') . '</p>';
        echo '</div>';
        
        // Course Visibility
        echo '<div style="margin-bottom: 20px;">';
        echo '<label><strong>' . $this->get_translated_text('Course Visibility', 'vira-store') . '</strong></label>';
        $visibility = get_post_meta($post->ID, '_vrstore_course_visibility', true) ?: 'public';
        $visibility_password = get_post_meta($post->ID, '_vrstore_course_visibility_password', true) ?: '';
        
        echo '<div style="margin: 10px 0;">';
        echo '<div style="margin-bottom: 10px;">';
        echo '<label><input type="radio" name="vrstore_course_visibility" value="public"' . checked($visibility, 'public', false) . ' /> ';
        echo $this->get_translated_text('Public - Visible to everyone', 'vira-store') . '</label>';
        echo '</div>';
        
        echo '<div style="margin-bottom: 10px;">';
        echo '<label><input type="radio" name="vrstore_course_visibility" value="private"' . checked($visibility, 'private', false) . ' /> ';
        echo $this->get_translated_text('Private - Visible to exist users', 'vira-store') . '</label>';
        echo '</div>';
        
        echo '<div style="margin-bottom: 10px;">';
        echo '<label><input type="radio" name="vrstore_course_visibility" value="password"' . checked($visibility, 'password', false) . ' /> ';
        echo $this->get_translated_text('Password Protected', 'vira-store') . '</label>';
        echo '</div>';
        
        echo '<div style="margin-bottom: 10px;">';
        echo '<label><input type="radio" name="vrstore_course_visibility" value="hidden"' . checked($visibility, 'hidden', false) . ' /> ';
        echo $this->get_translated_text('Hide - Course from archive', 'vira-store') . '</label>';
        echo '</div>';
        
        echo '<div id="visibility-password-field" style="' . ($visibility === 'password' ? '' : 'display: none;') . ' margin-left: 20px; margin-bottom: 10px;">';
        echo '<input type="text" name="vrstore_course_visibility_password" value="' . esc_attr($visibility_password) . '" placeholder="' . esc_attr($this->get_translated_text('Enter password', 'vira-store')) . '" style="width: 200px;" />';
        echo '</div>';
        
        echo '</div>';
        echo '<p class="description" style="margin-top: 5px;">' . $this->get_translated_text('Control who can view and access this course.', 'vira-store') . '</p>';
        echo '</div>';
        
        // Max Students Limit
        echo '<div style="margin-bottom: 20px;">';
        echo '<label><strong>' . $this->get_translated_text('Student Enrollment Limit', 'vira-store') . '</strong></label>';
        echo '<div style="margin: 10px 0;">';
        echo '<input type="number" name="vrstore_course_max_students" value="' . esc_attr($max_students) . '" min="0" style="width: 100px;" placeholder="0" />';
        echo '</div>';
        echo '<p class="description" style="margin-top: 5px;">' . $this->get_translated_text('Set the maximum number of students who can enroll in this course. Leave 0 for unlimited enrollment.', 'vira-store') . '</p>';
        echo '</div>';
        
        echo '</div>';
    }
    

    /**
     * Save meta boxes
     *
     * @param int $post_id Post ID
     * @param WP_Post $post Post object
     * @return void
     */
    public function save_meta_boxes(int $post_id, $post): void {
        // Check if we're saving the correct post type
        if ($post->post_type !== $this->post_type) {
            return;
        }

        // Check if user has permissions to save data
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }

        // Check if not an autosave
        if (wp_is_post_autosave($post_id)) {
            return;
        }

        // Check if not a revision
        if (wp_is_post_revision($post_id)) {
            return;
        }

        // Save course details
        if (isset($_POST['vrstore_course_details_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['vrstore_course_details_nonce'])), 'vrstore_course_details_nonce')) {
            $fields = [
                '_vrstore_course_duration' => 'text',
                '_vrstore_course_level' => 'text',
                '_vrstore_course_language' => 'text',
                '_vrstore_course_demo_url' => 'url',
                '_vrstore_course_objectives' => 'textarea'
            ];

            foreach ($fields as $field => $type) {
                $post_key = str_replace('_vrstore_course_', 'vrstore_course_', $field);
                if (isset($_POST[$post_key])) {
                    $value = wp_unslash($_POST[$post_key]);
                    switch ($type) {
                        case 'url':
                            update_post_meta($post_id, $field, esc_url_raw($value));
                            break;
                        case 'textarea':
                            update_post_meta($post_id, $field, wp_kses_post($value));
                            break;
                        default:
                            update_post_meta($post_id, $field, sanitize_text_field($value));
                    }
                }
            }

            // Save certification checkbox
            if (isset($_POST['vrstore_course_certification'])) {
                update_post_meta($post_id, '_vrstore_course_certification', '1');
            } else {
                delete_post_meta($post_id, '_vrstore_course_certification');
            }

            // Save signature image
            if (isset($_POST['vrstore_course_signature_image'])) {
                $signature_id = intval($_POST['vrstore_course_signature_image']);
                if ($signature_id > 0) {
                    update_post_meta($post_id, '_vrstore_course_signature_image', $signature_id);
                } else {
                    delete_post_meta($post_id, '_vrstore_course_signature_image');
                }
            }
        }

        // Save curriculum
        if (isset($_POST['vrstore_course_curriculum_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['vrstore_course_curriculum_nonce'])), 'vrstore_course_curriculum_nonce')) {
            if (isset($_POST['vrstore_course_curriculum']) && is_array($_POST['vrstore_course_curriculum'])) {
                $curriculum = [];
                $posted_curriculum = wp_unslash($_POST['vrstore_course_curriculum']);

                foreach ($posted_curriculum as $module) {
                    if (!empty($module['title'])) {
                        $curriculum_module = [
                            'title' => sanitize_text_field($module['title']),
                            'lessons' => []
                        ];

                        if (!empty($module['lessons']) && is_array($module['lessons'])) {
                            foreach ($module['lessons'] as $lesson) {
                                if (!empty($lesson['title'])) {
                                    $lesson_data = [
                                        'title' => sanitize_text_field($lesson['title']),
                                        'description' => wp_kses_post($lesson['description'] ?? ''),
                                        'duration' => sanitize_text_field($lesson['duration'] ?? ''),
                                        'type' => sanitize_text_field($lesson['type'] ?? 'video_upload'),
                                        'video_url' => esc_url_raw($lesson['video_url'] ?? ''),
                                        'video_file' => absint($lesson['video_file'] ?? 0),
                                        'shortcode_content' => wp_kses_post($lesson['shortcode_content'] ?? ''),
                                        'is_free_preview' => !empty($lesson['is_free_preview']) ? '1' : '',
                                        'material_url' => esc_url_raw($lesson['material_url'] ?? ''),
                                        'material_file' => absint($lesson['material_file'] ?? 0)
                                    ];
                                    $curriculum_module['lessons'][] = $lesson_data;
                                }
                            }
                        }

                        $curriculum[] = $curriculum_module;
                    }
                }

                update_post_meta($post_id, '_vrstore_course_curriculum', $curriculum);
            } else {
                delete_post_meta($post_id, '_vrstore_course_curriculum');
            }
        }

        // Instructor information removed - now using WordPress author system

        // Save pricing information
        if (isset($_POST['vrstore_course_pricing_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['vrstore_course_pricing_nonce'])), 'vrstore_course_pricing_nonce')) {
            // Get pricing type
            $pricing_type = isset($_POST['vrstore_course_pricing_type']) ? sanitize_text_field(wp_unslash($_POST['vrstore_course_pricing_type'])) : 'paid';
            
            // Clear all pricing related meta first
            delete_post_meta($post_id, '_vrstore_course_is_free');
            delete_post_meta($post_id, '_vrstore_course_free_with_product');
            delete_post_meta($post_id, '_vrstore_course_required_product_id');
            
            // Handle based on pricing type
            if ($pricing_type === 'free') {
                // Free course
                update_post_meta($post_id, '_vrstore_course_is_free', '1');
                // Clear pricing if it's free
                delete_post_meta($post_id, '_vrstore_course_price');
                delete_post_meta($post_id, '_vrstore_course_sale_price');
            } elseif ($pricing_type === 'product') {
                // Free with product purchase
                update_post_meta($post_id, '_vrstore_course_free_with_product', '1');
                // Clear pricing
                delete_post_meta($post_id, '_vrstore_course_price');
                delete_post_meta($post_id, '_vrstore_course_sale_price');
                
                // Save required product ID
                if (isset($_POST['vrstore_course_required_product_id'])) {
                    $product_id = absint($_POST['vrstore_course_required_product_id']);
                    if ($product_id > 0) {
                        update_post_meta($post_id, '_vrstore_course_required_product_id', $product_id);
                    }
                }
            } else {
                // Paid course
                // Save prices
                if (isset($_POST['vrstore_course_price'])) {
                    $price = sanitize_text_field(wp_unslash($_POST['vrstore_course_price']));
                    if (!empty($price) && is_numeric($price) && floatval($price) >= 0) {
                        update_post_meta($post_id, '_vrstore_course_price', floatval($price));
                    } else {
                        delete_post_meta($post_id, '_vrstore_course_price');
                    }
                }

                if (isset($_POST['vrstore_course_sale_price'])) {
                    $sale_price = sanitize_text_field(wp_unslash($_POST['vrstore_course_sale_price']));
                    if (!empty($sale_price) && is_numeric($sale_price) && floatval($sale_price) >= 0) {
                        update_post_meta($post_id, '_vrstore_course_sale_price', floatval($sale_price));
                    } else {
                        delete_post_meta($post_id, '_vrstore_course_sale_price');
                    }
                }
            }
        }
        
        // Save access control settings
        if (isset($_POST['vrstore_course_access_control_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['vrstore_course_access_control_nonce'])), 'vrstore_course_access_control_nonce')) {
            // Access period settings
            if (isset($_POST['vrstore_course_access_period_type'])) {
                update_post_meta($post_id, '_vrstore_course_access_period_type', sanitize_text_field($_POST['vrstore_course_access_period_type']));
            }
            
            if (isset($_POST['vrstore_course_access_period_value'])) {
                update_post_meta($post_id, '_vrstore_course_access_period_value', absint($_POST['vrstore_course_access_period_value']));
            }
            
            if (isset($_POST['vrstore_course_access_period_unit'])) {
                update_post_meta($post_id, '_vrstore_course_access_period_unit', sanitize_text_field($_POST['vrstore_course_access_period_unit']));
            }
            
            // Content dripping settings
            if (isset($_POST['vrstore_course_content_drip_enabled'])) {
                update_post_meta($post_id, '_vrstore_course_content_drip_enabled', '1');
            } else {
                delete_post_meta($post_id, '_vrstore_course_content_drip_enabled');
            }
            
            if (isset($_POST['vrstore_course_drip_interval_value'])) {
                update_post_meta($post_id, '_vrstore_course_drip_interval_value', absint($_POST['vrstore_course_drip_interval_value']));
            }
            
            if (isset($_POST['vrstore_course_drip_interval_type'])) {
                update_post_meta($post_id, '_vrstore_course_drip_interval_type', sanitize_text_field($_POST['vrstore_course_drip_interval_type']));
            }
            
            // Trial settings
            if (isset($_POST['vrstore_course_trial_enabled'])) {
                update_post_meta($post_id, '_vrstore_course_trial_enabled', '1');
            } else {
                delete_post_meta($post_id, '_vrstore_course_trial_enabled');
            }
            
            if (isset($_POST['vrstore_course_trial_period'])) {
                update_post_meta($post_id, '_vrstore_course_trial_period', absint($_POST['vrstore_course_trial_period']));
            }
            
            // Max students setting
            if (isset($_POST['vrstore_course_max_students'])) {
                $max_students = absint($_POST['vrstore_course_max_students']);
                update_post_meta($post_id, '_vrstore_course_max_students', $max_students);
            }
            
            // Course visibility settings
            if (isset($_POST['vrstore_course_visibility'])) {
                $visibility = sanitize_text_field($_POST['vrstore_course_visibility']);
                update_post_meta($post_id, '_vrstore_course_visibility', $visibility);
                
                // Save password if visibility is password protected
                if ($visibility === 'password' && isset($_POST['vrstore_course_visibility_password'])) {
                    $password = sanitize_text_field($_POST['vrstore_course_visibility_password']);
                    update_post_meta($post_id, '_vrstore_course_visibility_password', $password);
                } else {
                    delete_post_meta($post_id, '_vrstore_course_visibility_password');
                }
            }
        }
    }

    /**
     * Add course columns
     *
     * @param array $columns Columns
     * @return array
     */
    public function add_course_columns(array $columns): array {
        $new_columns = [];

        // Insert thumbnail after checkbox
        foreach ($columns as $key => $value) {
            $new_columns[$key] = $value;

            if ($key === 'cb') {
                $new_columns['thumbnail'] = __('Image', 'vira-store');
            }

            if ($key === 'title') {
                $new_columns['duration'] = __('Duration', 'vira-store');
                $new_columns['level'] = __('Level', 'vira-store');
                $new_columns['price'] = __('Price', 'vira-store');
                $new_columns['enrolled'] = __('Enrolled', 'vira-store');
                $new_columns['revenue'] = __('Revenue', 'vira-store');
            }
        }

        return $new_columns;
    }

    /**
     * Render course columns
     *
     * @param string $column Column name
     * @param int $post_id Post ID
     * @return void
     */
    public function render_course_columns(string $column, int $post_id): void {
        switch ($column) {
            case 'thumbnail':
                if (has_post_thumbnail($post_id)) {
                    echo get_the_post_thumbnail($post_id, [50, 50]);
                } else {
                    echo '<img src="' . esc_url(VRSTORE_PLUGIN_URL . 'assets/images/course-placeholder.svg') . '" width="50" height="50" alt="' . esc_attr__('Course image', 'vira-store') . '">';
                }
                break;

            // Instructor column removed - using WordPress Author column instead

            case 'duration':
                $duration = get_post_meta($post_id, '_vrstore_course_duration', true);
                echo !empty($duration) ? esc_html($duration) : '—';
                break;

            case 'level':
                $level = get_post_meta($post_id, '_vrstore_course_level', true);
                if (!empty($level)) {
                    echo '<span class="course-level course-level-' . esc_attr($level) . '">' . esc_html(ucfirst($level)) . '</span>';
                } else {
                    echo '—';
                }
                break;

            case 'price':
                $is_free = get_post_meta($post_id, '_vrstore_course_is_free', true);
                $free_with_product = get_post_meta($post_id, '_vrstore_course_free_with_product', true);
                
                if ($is_free) {
                    echo '<span class="course-free" title="' . esc_attr($this->get_translated_text('Free enrollment - no payment required', 'vira-store')) . '">' . $this->get_translated_text('Free', 'vira-store') . '</span>';
                } elseif ($free_with_product) {
                    $required_product_id = get_post_meta($post_id, '_vrstore_course_required_product_id', true);
                    $product_title = '';
                    if ($required_product_id) {
                        $product_title = get_the_title($required_product_id);
                    }
                    $tooltip_text = $this->get_translated_text('Free enrollement with', 'vira-store');
                    if ($product_title) {
                        $tooltip_text .= ': ' . $product_title;
                    }
                    echo '<span class="course-free-with-product" title="' . esc_attr($tooltip_text) . '">' . $this->get_translated_text('Free*', 'vira-store') . '</span>';
                } else {
                    $price = get_post_meta($post_id, '_vrstore_course_price', true);
                    $sale_price = get_post_meta($post_id, '_vrstore_course_sale_price', true);
                    
                    // Get currency from plugin settings
                    $currency = 'USD'; // Default
                    if (class_exists('VRSTORE_Settings')) {
                        try {
                            $settings = VRSTORE_Settings::get_instance();
                            $currency = $settings->get_setting('currency', 'USD');
                        } catch (Exception $e) {
                            $currency = 'USD';
                        }
                    }

                    if (!empty($sale_price)) {
                        echo '<del>' . $this->format_price_compact($price, $currency) . '</del> ';
                        echo '<span class="vrstore-sale-price">' . $this->format_price_compact($sale_price, $currency) . '</span>';
                    } elseif (!empty($price)) {
                        echo $this->format_price_compact($price, $currency);
                    } else {
                        echo '—';
                    }
                }
                break;
                
            case 'enrolled':
                // Sync the actual enrollment count first
                $enrolled_count = $this->sync_enrollment_count($post_id);
                echo $enrolled_count > 0 ? '<span class="course-enrolled-count">' . esc_html(number_format($enrolled_count)) . '</span>' : '0';
                break;
                
            case 'revenue':
                $revenue = $this->calculate_course_revenue($post_id);
                if ($revenue > 0) {
                    // Get currency from plugin settings
                    $currency = 'USD'; // Default
                    if (class_exists('VRSTORE_Settings')) {
                        try {
                            $settings = VRSTORE_Settings::get_instance();
                            $currency = $settings->get_setting('currency', 'USD');
                        } catch (Exception $e) {
                            $currency = 'USD';
                        }
                    }
                    echo '<span class="course-revenue">' . $this->format_price_compact($revenue, $currency) . '</span>';
                } else {
                    echo '—';
                }
                break;
        }
    }

    /**
     * Enqueue frontend assets
     *
     * @return void
     */
    public function enqueue_frontend_assets(): void {
        // Only enqueue on single course pages or pages with course shortcodes
        if (is_singular($this->post_type) || $this->has_course_shortcode()) {
            // Enqueue dashicons for frontend (needed for module toggles and icons)
            wp_enqueue_style('dashicons');
            
            // Enqueue CSS
            wp_enqueue_style(
                'vrstore-course-frontend',
                VRSTORE_PLUGIN_URL . 'assets/css/course.css',
                ['dashicons'],
                VRSTORE_VERSION
            );

            // Enqueue pre-order and shortcode styles
            wp_enqueue_style(
                'vrstore-preorder-shortcode',
                VRSTORE_PLUGIN_URL . 'assets/css/preorder-shortcode.css',
                ['vrstore-course-frontend'],
                VRSTORE_VERSION
            );

            // Enqueue JavaScript with new filename to bypass all caching
            wp_enqueue_script(
                'vrstore-course-frontend',
                VRSTORE_PLUGIN_URL . 'assets/js/course-new.js',
                ['jquery'],
                VRSTORE_VERSION . '-' . time(),
                true
            );

            // Enqueue shortcode preview handler
            wp_enqueue_script(
                'vrstore-shortcode-preview',
                VRSTORE_PLUGIN_URL . 'assets/js/shortcode-preview.js',
                ['jquery', 'vrstore-course-frontend'],
                VRSTORE_VERSION,
                true
            );
            
            // Enqueue lesson-specific assets if viewing a lesson
            if (get_query_var('module_index', false) !== false && get_query_var('lesson_index', false) !== false) {
                wp_enqueue_style(
                    'vrstore-lesson-frontend',
                    VRSTORE_PLUGIN_URL . 'assets/css/lesson.css',
                    [],
                    VRSTORE_VERSION
                );
                
                wp_enqueue_script(
                    'vrstore-lesson-frontend', 
                    VRSTORE_PLUGIN_URL . 'assets/js/lesson.js',
                    ['jquery'],
                    VRSTORE_VERSION,
                    true
                );
            }

            // Get settings instance for product permalink slug
            $settings = VRSTORE_Settings::get_instance();
            
            // Localize script
            wp_localize_script(
                'vrstore-course-frontend',
                'vrstore_course_frontend',
                [
                    'ajax_url' => admin_url('admin-ajax.php'),
                    'nonce' => wp_create_nonce('vrstore_course_frontend_nonce'),
                    'enrolling' => __('Enrolling...', 'vira-store'),
                    'enrolled' => __('Enrolled', 'vira-store'),
                    'enroll_error' => __('Enrollment failed. Please try again.', 'vira-store'),
                ]
            );
            
            // Also localize course data for JavaScript access
            wp_localize_script(
                'vrstore-course-frontend',
                'vrstore_course_data',
                [
                    'site_url' => home_url(),
                    'product_permalink_slug' => $settings->get_setting('product_permalink_slug', 'digital-product'),
                ]
            );
            
            // Localize current course data if on single course page
            if (is_singular($this->post_type)) {
                global $post;
                $current_course_data = $this->get_course_data($post->ID);
                wp_localize_script(
                    'vrstore-course-frontend',
                    'vrstoreCourseData',
                    [
                        'id' => $current_course_data['id'],
                        'title' => $current_course_data['title'],
                        'demoUrl' => $current_course_data['demo_url'],
                        'isFree' => !empty($current_course_data['is_free']),
                        'price' => $current_course_data['price'],
                        'salePrice' => $current_course_data['sale_price'],
                        'currency' => $current_course_data['currency'],
                    ]
                );
            }
        }
    }

    /**
     * Enqueue admin assets
     *
     * @param string $hook Current admin page hook
     * @return void
     */
    public function enqueue_admin_assets(string $hook): void {
        // Only enqueue on course related pages
        if (!function_exists('get_current_screen')) {
            return;
        }

        $screen = get_current_screen();
        if (!$screen || $screen->post_type !== $this->post_type) {
            return;
        }

        // Only on edit/new post pages and course list page
        if (!in_array($hook, ['post.php', 'post-new.php', 'edit.php'])) {
            return;
        }

        // Enqueue WordPress media uploader
        wp_enqueue_media();

        // Enqueue course admin CSS
        wp_enqueue_style(
            'vrstore-course-admin',
            VRSTORE_PLUGIN_URL . 'assets/css/course-admin.css',
            [],
            VRSTORE_VERSION
        );

        // Enqueue course admin JavaScript
        wp_enqueue_script(
            'vrstore-course-admin',
            VRSTORE_PLUGIN_URL . 'assets/js/course-admin.js',
            ['jquery', 'wp-util'],
            VRSTORE_VERSION,
            true
        );

        // Enqueue lesson types handler
        wp_enqueue_script(
            'vrstore-course-admin-lesson-types',
            VRSTORE_PLUGIN_URL . 'assets/js/course-admin-lesson-types.js',
            ['jquery', 'vrstore-course-admin'],
            VRSTORE_VERSION,
            true
        );

        // Localize script
        wp_localize_script(
            'vrstore-course-admin',
            'vrstore_course_admin',
            [
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('vrstore_course_admin_nonce'),
                'confirm_duplicate' => __('Are you sure you want to duplicate this course?', 'vira-store'),
                'duplicating' => __('Duplicating...', 'vira-store'),
                'duplicate_success' => __('Course duplicated successfully!', 'vira-store'),
                'duplicate_error' => __('Failed to duplicate course. Please try again.', 'vira-store'),
                'remove_module' => __('Are you sure you want to remove this module?', 'vira-store'),
                'remove_lesson' => __('Are you sure you want to remove this lesson?', 'vira-store'),
                'lesson_types' => [
                    'video_upload' => __('Video Upload', 'vira-store'),
                    'video_url' => __('Video URL', 'vira-store'),
                    'shortcode' => __('Shortcode', 'vira-store')
                ]
            ]
        );
        
        // Add critical CSS to fix column layout
        add_action('admin_head', [$this, 'add_critical_admin_css']);
    }

    /**
     * Check if current page has course shortcode
     *
     * @return bool
     */
    private function has_course_shortcode(): bool {
        global $post;

        if (!$post) {
            return false;
        }

        return has_shortcode($post->post_content, 'vrstore_course') ||
               has_shortcode($post->post_content, 'vrstore_courses');
    }

    /**
     * Recursion prevention flag
     *
     * @var bool
     */
    private static $is_filtering_content = false;

    /**
     * Filter single course content
     *
     * @param string $content Post content
     * @return string Modified content
     */
    public function filter_single_course_content($content) {
        // Prevent infinite recursion
        if (self::$is_filtering_content) {
            return $content;
        }
        
        if (!is_singular($this->post_type) || !in_the_loop() || !is_main_query()) {
            return $content;
        }
        
        // Allow other plugins to process shortcodes first
        if (!did_action('wp_head')) {
            return $content;
        }
        
        global $post;
        
        // Check course visibility
        $visibility = get_post_meta($post->ID, '_vrstore_course_visibility', true) ?: 'public';
        
        // Note: 'hidden' courses are allowed to display normally when accessed directly
        // They are only hidden from archive/listing queries by filter_course_visibility()
        
        // Handle private courses
        if ($visibility === 'private') {
            $user_id = get_current_user_id();
            if (!$user_id || !$this->user_has_course_access($post->ID, $user_id)) {
                return '<div class="vrstore-course-private"><h3>' . __('Private Course', 'vira-store') . '</h3><p>' . __('This is a private course. You need to be enrolled to view the content.', 'vira-store') . '</p></div>';
            }
        }
        
        // Handle password-protected courses
        if ($visibility === 'password') {
            if (!$this->check_course_password_access($post->ID)) {
                $password_error = '';
                if (isset($_POST['course_password_' . $post->ID])) {
                    $password_error = '<div class="vrstore-password-error" style="color: #d63638; margin-bottom: 15px;">' . __('Incorrect password. Please try again.', 'vira-store') . '</div>';
                }
                
                return '<div class="vrstore-course-password-form">' .
                       '<h3>' . __('Password Protected Course', 'vira-store') . '</h3>' .
                       $password_error .
                       '<form method="post">' .
                       '<p><label for="course_password_' . $post->ID . '">' . __('Enter Password:', 'vira-store') . '</label></p>' .
                       '<p><input type="password" id="course_password_' . $post->ID . '" name="course_password_' . $post->ID . '" required style="width: 200px; padding: 8px; margin-right: 10px;" />' .
                       '<input type="submit" value="' . __('Submit', 'vira-store') . '" class="button" /></p>' .
                       '</form></div>';
            }
        }
        
        // Set flag to prevent recursion
        self::$is_filtering_content = true;

        // Get course data
        $course_data = $this->get_course_data($post->ID);

        // Load course template
        ob_start();
        $template_path = VRSTORE_PLUGIN_DIR . 'views/course/course.php';
        if (file_exists($template_path)) {
            include $template_path;
        } else {
            echo '<p>Course template not found at: ' . esc_html($template_path) . '</p>';
        }
        $course_content = ob_get_clean();
        
        // Reset flag
        self::$is_filtering_content = false;

        // If no course content was generated, return original content
        if (empty($course_content)) {
            return $content . '<p>Course template failed to load.</p>';
        }

        // Replace the content entirely with our course template
        return $course_content;
    }

    /**
     * Get course instructor data from WordPress user
     *
     * @param int $course_id Course ID
     * @return array Instructor data
     */
    private function get_course_instructor_data($course_id): array {
        $post = get_post($course_id);
        if (!$post) {
            return ['name' => '', 'bio' => '', 'avatar' => '', 'website' => ''];
        }
        
        $author_id = $post->post_author;
        $author = get_user_by('ID', $author_id);
        
        if (!$author) {
            return ['name' => '', 'bio' => '', 'avatar' => '', 'website' => ''];
        }
        
        // Get user's biography from user meta
        $bio = get_user_meta($author_id, 'description', true);
        
        // Get user's website
        $website = get_user_meta($author_id, 'user_url', true) ?: $author->user_url;
        
        // Get user's avatar (using WordPress avatar system)
        $avatar_id = get_user_meta($author_id, 'vrstore_avatar_id', true);
        
        return [
            'name' => $author->display_name,
            'bio' => $bio,
            'avatar' => $avatar_id,
            'website' => $website,
            'user_id' => $author_id,
            'email' => $author->user_email
        ];
    }
    
    /**
     * Get course data
     *
     * @param int $course_id Course ID
     * @return array Course data
     */
    public function get_course_data($course_id): array {
        return [
            'id' => $course_id,
            'title' => get_the_title($course_id),
            'content' => get_post($course_id) ? get_post($course_id)->post_content : '',
            'excerpt' => get_post_field('post_excerpt', $course_id),
            'duration' => get_post_meta($course_id, '_vrstore_course_duration', true),
            'level' => get_post_meta($course_id, '_vrstore_course_level', true),
            'language' => get_post_meta($course_id, '_vrstore_course_language', true),
            'max_students' => get_post_meta($course_id, '_vrstore_course_max_students', true),
            'objectives' => get_post_meta($course_id, '_vrstore_course_objectives', true),
            'demo_url' => get_post_meta($course_id, '_vrstore_course_demo_url', true),
            'certification' => get_post_meta($course_id, '_vrstore_course_certification', true),
            'curriculum' => get_post_meta($course_id, '_vrstore_course_curriculum', true),
            'instructor' => $this->get_course_instructor_data($course_id),
            'is_free' => get_post_meta($course_id, '_vrstore_course_is_free', true),
            'price' => get_post_meta($course_id, '_vrstore_course_price', true),
            'sale_price' => get_post_meta($course_id, '_vrstore_course_sale_price', true),
            'currency' => get_post_meta($course_id, '_vrstore_course_currency', true) ?: 'USD',
            'featured_image' => get_post_thumbnail_id($course_id),
            'thumbnail' => get_the_post_thumbnail_url($course_id, 'full'),
            'permalink' => get_permalink($course_id),
        ];
    }

    /**
     * Add duplicate row action
     *
     * @param array $actions Row actions
     * @param WP_Post $post Post object
     * @return array Modified actions
     */
    public function add_duplicate_row_action($actions, $post) {
        if ($post->post_type === $this->post_type && current_user_can('edit_posts')) {
            $actions['duplicate'] = '<a href="#" class="vrstore-duplicate-course" data-course-id="' . $post->ID . '">' . __('Duplicate', 'vira-store') . '</a>';
        }
        return $actions;
    }

    /**
     * Handle AJAX course duplication
     *
     * @return void
     */
    public function ajax_duplicate_course(): void {
        // Verify nonce
        if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'] ?? '')), 'vrstore_course_admin_nonce')) {
            wp_die('Security check failed');
        }

        // Check permissions
        if (!current_user_can('edit_posts')) {
            wp_send_json_error(__('You do not have permission to duplicate courses.', 'vira-store'));
        }

        $course_id = intval($_POST['course_id'] ?? 0);
        if (!$course_id) {
            wp_send_json_error(__('Invalid course ID.', 'vira-store'));
        }

        $original_post = get_post($course_id);
        if (!$original_post || $original_post->post_type !== $this->post_type) {
            wp_send_json_error(__('Course not found.', 'vira-store'));
        }

        // Duplicate the course
        $new_post_data = [
            'post_title' => $original_post->post_title . ' (Copy)',
            'post_content' => $original_post->post_content,
            'post_excerpt' => $original_post->post_excerpt,
            'post_status' => 'draft',
            'post_type' => $this->post_type,
            'post_author' => get_current_user_id(),
        ];

        $new_course_id = wp_insert_post($new_post_data);

        if (is_wp_error($new_course_id)) {
            wp_send_json_error(__('Failed to duplicate course.', 'vira-store'));
        }

        // Duplicate meta data
        $meta_keys = [
            '_vrstore_course_duration',
            '_vrstore_course_level',
            '_vrstore_course_language',
            '_vrstore_course_objectives',
            '_vrstore_course_demo_url',
            '_vrstore_course_certification',
            '_vrstore_course_curriculum',
            '_vrstore_course_is_free',
            '_vrstore_course_price',
            '_vrstore_course_sale_price',
            '_vrstore_course_currency',
            '_vrstore_course_access_period_type',
            '_vrstore_course_access_period_value',
            '_vrstore_course_access_period_unit',
            '_vrstore_course_max_students',
            '_vrstore_course_visibility',
            '_vrstore_course_visibility_password',
        ];

        foreach ($meta_keys as $meta_key) {
            $meta_value = get_post_meta($course_id, $meta_key, true);
            if (!empty($meta_value)) {
                update_post_meta($new_course_id, $meta_key, $meta_value);
            }
        }

        // Duplicate taxonomies
        $taxonomies = ['vrstore_course_cat', 'vrstore_course_tag', 'vrstore_skill_level'];
        foreach ($taxonomies as $taxonomy) {
            $terms = wp_get_post_terms($course_id, $taxonomy, ['fields' => 'ids']);
            if (!empty($terms) && !is_wp_error($terms)) {
                wp_set_post_terms($new_course_id, $terms, $taxonomy);
            }
        }

        wp_send_json_success([
            'message' => __('Course duplicated successfully!', 'vira-store'),
            'edit_url' => admin_url('post.php?post=' . $new_course_id . '&action=edit'),
        ]);
    }

    /**
     * Format price
     *
     * @param mixed $price Price
     * @param string $currency Currency
     * @return string Formatted price
     */
    private function format_price($price, string $currency): string {
        if (empty($price)) {
            return '';
        }

        // Use currency converter if available
        if (class_exists('VRSTORE_Currency_Converter')) {
            $converter = VRSTORE_Currency_Converter::get_instance();
            return $converter->format_price((float) $price, $currency);
        }
        
        // Fallback to original formatting
        $symbol = $this->get_currency_symbol($currency);
        return $symbol . number_format((float) $price, 2);
    }
    
    /**
     * Format price with compact units (K/M) for admin columns
     *
     * @param mixed $price Price
     * @param string $currency Currency
     * @return string Formatted compact price
     */
    private function format_price_compact($price, string $currency): string {
        if (empty($price)) {
            return '';
        }
        
        $price = (float) $price;
        
        // Use currency converter if available
        if (class_exists('VRSTORE_Currency_Converter')) {
            $converter = VRSTORE_Currency_Converter::get_instance();
            return $converter->format_price($price, $currency, true); // Use compact formatting
        }
        
        // Fallback to original formatting
        $symbol = $this->get_currency_symbol($currency);
        
        if ($price >= 1000000) {
            return $symbol . round($price / 1000000, 1) . 'M';
        } elseif ($price >= 1000) {
            return $symbol . round($price / 1000, 1) . 'K';
        } else {
            return $symbol . number_format($price, ($price < 1) ? 2 : 0);
        }
    }

    /**
     * Get currency symbol
     *
     * @param string $currency Currency
     * @return string Currency symbol
     */
    private function get_currency_symbol(string $currency): string {
        $symbols = [
            'USD' => '$',
            'EUR' => '€',
            'GBP' => '£',
            'JPY' => '¥',
            'IDR' => 'Rp',
            'AUD' => '$',
            'BRL' => 'R$',
            'CAD' => '$',
            'CNY' => '¥',
            'HKD' => '$',
            'INR' => '₹',
            'MXN' => '$',
            'MYR' => 'RM',
            'NZD' => '$',
            'PHP' => '₱',
            'SGD' => '$',
            'THB' => '฿',
            'VND' => '₫',
            'ZAR' => 'R',
        ];

        return $symbols[$currency] ?? $currency;
    }
    
    /**
     * Calculate total revenue for a course
     *
     * @param int $course_id Course ID
     * @return float Total revenue
     */
    private function calculate_course_revenue(int $course_id): float {
        global $wpdb;
        
        $orders_table = $wpdb->prefix . 'vrstore_orders';
        
        // Check if orders table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$orders_table'") !== $orders_table) {
            return 0;
        }
        
        // Calculate total revenue from completed orders
        $revenue = $wpdb->get_var($wpdb->prepare(
            "SELECT SUM(product_price) 
             FROM $orders_table 
             WHERE product_id = %d 
               AND (payment_status = 'completed' OR order_status = 'completed')",
            $course_id
        ));
        
        return (float) $revenue ?: 0;
    }

    /**
     * Add Courses to main Vira Store dashboard menu
     *
     * @return void
     */
    public function add_admin_menu(): void {
        // Add Courses as submenu under main Vira Store dashboard
        add_submenu_page(
            'vrstore-dashboard',                  // Parent slug (Vira Store Dashboard)
            __('Courses', 'vira-store'),          // Page title
            __('Courses', 'vira-store'),          // Menu title
            'manage_options',                     // Capability
            'edit.php?post_type=' . $this->post_type // Menu slug (redirects to course post type)
		);
    }
    
    /**
     * Add critical admin CSS to fix layout issues
     *
     * @return void
     */
    public function add_critical_admin_css(): void {
        $screen = get_current_screen();
        if (!$screen || $screen->post_type !== $this->post_type) {
            return;
        }
        
        echo '<style>
        .wp-list-table.widefat .column-thumbnail { width: 60px; }
        .wp-list-table.widefat .column-duration { width: 80px; }
        .wp-list-table.widefat .column-level { width: 80px; }
        .wp-list-table.widefat .column-price { width: 100px; }
        .wp-list-table.widefat .column-enrolled { width: 80px; text-align: center; }
        .wp-list-table.widefat .column-revenue { width: 100px; text-align: right; }
        .wp-list-table.widefat .column-title { width: auto; }
        .wp-list-table .column-thumbnail img { max-width: 50px; height: auto; border-radius: 4px; }
        .course-level { 
            display: inline-block;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 500;
            text-transform: uppercase;
        }
        .course-level-beginner { background: #e8f5e8; color: #2e7d32; }
        .course-level-intermediate { background: #fff3e0; color: #ef6c00; }
        .course-level-advanced { background: #ffebee; color: #c62828; }
        .course-free {
            color: #2e7d32;
            font-weight: 500;
        }
        .vrstore-sale-price {
            color: #d32f2f;
            font-weight: 500;
        }
        .course-enrolled-count {
            display: inline-block;
            background: #e3f2fd;
            color: #1565c0;
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 11px;
            font-weight: 500;
        }
        .course-revenue {
            color: #2e7d32;
            font-weight: 600;
        }
        td.column-enrolled {
            text-align: center;
        }
        td.column-revenue {
            text-align: right;
        }
        </style>';
    }
    
    /**
     * AJAX handler for adding course to cart
     *
     * @return void
     */
    public function ajax_add_course_to_cart(): void {
        // Log the request for debugging
        error_log('VRSTORE Course: ajax_add_course_to_cart called with data: ' . print_r($_POST, true));
        
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_add_to_cart')) {
            error_log('VRSTORE Course: Nonce verification failed');
            wp_send_json_error(__('Security check failed.', 'vira-store'));
        }
        
        $course_id = absint($_POST['course_id'] ?? 0);
        if (!$course_id) {
            wp_send_json_error(__('Invalid course ID.', 'vira-store'));
        }
        
        // Check if course exists
        $course = get_post($course_id);
        if (!$course || $course->post_type !== $this->post_type) {
            wp_send_json_error(__('Course not found.', 'vira-store'));
        }
        
        // Get course data
        $course_data = $this->get_course_data($course_id);
        
        // Check if course is free
        if (!empty($course_data['is_free']) || (empty($course_data['price']) && empty($course_data['sale_price']))) {
            wp_send_json_error(__('This course is free. Please use the enroll button instead.', 'vira-store'));
        }
        
        // Verify course pricing without polluting with product meta keys
        $regular_price = !empty($course_data['price']) ? floatval($course_data['price']) : 0;
        $sale_price = !empty($course_data['sale_price']) ? floatval($course_data['sale_price']) : 0;
        
        // Only update the course's own pricing fields - don't add product meta keys
        // The cart system will read from course-specific meta keys
        
        // Ensure the course has a price
        if ($regular_price <= 0 && $sale_price <= 0) {
            wp_send_json_error(__('This course does not have a valid price set.', 'vira-store'));
        }
        
        // Add to cart using existing cart system
        if (class_exists('VRSTORE_Cart')) {
            error_log('VRSTORE Course: Adding course ' . $course_id . ' to cart with price ' . $regular_price);
            $cart = VRSTORE_Cart::get_instance();
            $cart_result = $cart->add_to_cart($course_id, 1, ''); // No license type for courses
            
            error_log('VRSTORE Course: Cart add result: ' . ($cart_result ? 'success' : 'failed'));
            
            if ($cart_result) {
                // Find checkout page with vrstore_checkout shortcode
                $checkout_url = $this->get_checkout_url();
                if (!$checkout_url) {
                    $checkout_url = home_url(); // Fallback to home if no checkout page found
                }
                
                // Get cart URL as well
                $cart_url = $this->get_cart_url();
                
                error_log('VRSTORE Course: URLs found - Checkout: ' . ($checkout_url ?: 'none') . ', Cart: ' . ($cart_url ?: 'none'));
                
                wp_send_json_success([
                    'message' => __('Course added to cart successfully!', 'vira-store'),
                    'checkout_url' => $checkout_url,
                    'cart_url' => $cart_url,
                    'course_title' => $course_data['title'],
                    'price' => $regular_price,
                    'sale_price' => $sale_price
                ]);
            } else {
                wp_send_json_error(__('Failed to add course to cart. Please try again.', 'vira-store'));
            }
        } else {
            wp_send_json_error(__('Cart system not available. Please try again.', 'vira-store'));
        }
    }
    
    /**
     * AJAX handler for enrolling in free course
     *
     * @return void
     */
    public function ajax_enroll_free_course(): void {
        $course_id = absint($_POST['course_id'] ?? 0);
        
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_course_enroll_' . $course_id)) {
            wp_send_json_error(__('Security check failed.', 'vira-store'));
        }
        
        if (!$course_id) {
            wp_send_json_error(__('Invalid course ID.', 'vira-store'));
        }
        
        // Check if course exists
        $course = get_post($course_id);
        if (!$course || $course->post_type !== $this->post_type) {
            wp_send_json_error(__('Course not found.', 'vira-store'));
        }
        
        // Get course data
        $course_data = $this->get_course_data($course_id);
        
        // Check if course is free or free with product purchase
        $is_free = !empty($course_data['is_free']);
        $free_with_product = get_post_meta($course_id, '_vrstore_course_free_with_product', true);
        $required_product_id = get_post_meta($course_id, '_vrstore_course_required_product_id', true);
        
        if (!$is_free && !$free_with_product && (!empty($course_data['price']) || !empty($course_data['sale_price']))) {
            wp_send_json_error(__('This course is not free.', 'vira-store'));
        }
        
        $user_id = get_current_user_id();
        
        // If course requires product purchase, handle both logged in and logged out users
        if ($free_with_product && $required_product_id) {
            $product_title = get_the_title($required_product_id);
            $product_url = get_permalink($required_product_id);
            
            if (!$user_id) {
                // User not logged in - redirect to product page with login requirement
                wp_send_json_error([
                    'message' => sprintf(
                        __('You must purchase "%s" to access this course for free. Please log in or create an account to continue.', 'vira-store'),
                        $product_title
                    ),
                    'product_url' => $product_url,
                    'product_title' => $product_title,
                    'redirect_type' => 'product_purchase'
                ]);
            }
            
            // Check if logged-in user owns the required product
            if (!$this->user_owns_product($user_id, $required_product_id)) {
                wp_send_json_error([
                    'message' => sprintf(
                        __('You must purchase "%s" to access this course for free.', 'vira-store'),
                        $product_title
                    ),
                    'product_url' => $product_url,
                    'product_title' => $product_title,
                    'redirect_type' => 'product_purchase'
                ]);
            }
        }
        
        // If user is not logged in for regular free courses, redirect to account page
        if (!$user_id) {
            $account_url = $this->get_account_url();
            if ($account_url) {
                wp_send_json_error([
                    'message' => __('Please log in or register to enroll in this course.', 'vira-store'),
                    'redirect_url' => $account_url,
                    'redirect_type' => 'account_login'
                ]);
            } else {
                // Fallback to WordPress login page if no account page found
                $login_url = wp_login_url(get_permalink($course_id));
                wp_send_json_error([
                    'message' => __('Please log in or register to enroll in this course.', 'vira-store'),
                    'redirect_url' => $login_url,
                    'redirect_type' => 'wp_login'
                ]);
            }
        }
        
        // Check if already enrolled
        $enrolled = get_user_meta($user_id, '_vrstore_enrolled_courses', true);
        if (!is_array($enrolled)) {
            $enrolled = [];
        }
        
        if (in_array($course_id, $enrolled)) {
            wp_send_json_success([
                'message' => __('You are already enrolled in this course!', 'vira-store'),
                'redirect_url' => get_permalink($course_id)
            ]);
        }
        
        // Check enrollment limit
        $max_students = get_post_meta($course_id, '_vrstore_course_max_students', true);
        if (!empty($max_students) && $max_students > 0) {
            $current_enrolled = $this->sync_enrollment_count($course_id);
            if ($current_enrolled >= $max_students) {
                wp_send_json_error([
                    'message' => __('Enrollment limit reached. This course is full.', 'vira-store'),
                    'error_type' => 'enrollment_limit_reached'
                ]);
            }
        }
        
        // Enroll user in course
        $enrolled[] = $course_id;
        update_user_meta($user_id, '_vrstore_enrolled_courses', $enrolled);
        
        // Record enrollment date for access period tracking
        update_user_meta($user_id, '_vrstore_course_enrollment_date_' . $course_id, current_time('mysql'));
        
        // Update course enrollment count
        $enrolled_count = get_post_meta($course_id, '_vrstore_course_enrolled_count', true) ?: 0;
        update_post_meta($course_id, '_vrstore_course_enrolled_count', $enrolled_count + 1);
        
        // Log enrollment
        do_action('vrstore_course_enrolled', $course_id, $user_id, 'free');
        
        wp_send_json_success([
            'message' => __('Successfully enrolled in course!', 'vira-store'),
            'redirect_url' => get_permalink($course_id)
        ]);
    }
    
    /**
     * AJAX handler for marking lesson as complete
     *
     * @return void
     */
    public function ajax_mark_lesson_complete(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_lesson_nonce')) {
            wp_send_json_error(__('Security check failed.', 'vira-store'));
        }
        
        $course_id = absint($_POST['course_id'] ?? 0);
        $module_index = absint($_POST['module_index'] ?? 0);
        $lesson_index = absint($_POST['lesson_index'] ?? 0);
        $user_id = get_current_user_id();
        
        if (!$course_id || !$user_id) {
            wp_send_json_error(__('Invalid course or user.', 'vira-store'));
        }
        
        // Check if user has access to the course
        if (!$this->user_has_course_access($course_id, $user_id)) {
            wp_send_json_error(__('You do not have access to this course.', 'vira-store'));
        }
        
        // Get existing completed lessons
        $completed_lessons = get_user_meta($user_id, '_vrstore_completed_lessons_' . $course_id, true);
        if (!is_array($completed_lessons)) {
            $completed_lessons = [];
        }
        
        // Create lesson identifier
        $lesson_id = $module_index . '_' . $lesson_index;
        
        // Add lesson to completed list if not already there
        if (!in_array($lesson_id, $completed_lessons)) {
            $completed_lessons[] = $lesson_id;
            update_user_meta($user_id, '_vrstore_completed_lessons_' . $course_id, $completed_lessons);
        }
        
        // Calculate progress
        $curriculum = get_post_meta($course_id, '_vrstore_course_curriculum', true);
        $total_lessons = 0;
        
        if (is_array($curriculum)) {
            foreach ($curriculum as $module) {
                if (!empty($module['lessons']) && is_array($module['lessons'])) {
                    $total_lessons += count($module['lessons']);
                }
            }
        }
        
        $progress_percentage = $total_lessons > 0 ? round((count($completed_lessons) / $total_lessons) * 100) : 0;
        
        wp_send_json_success([
            'message' => __('Lesson marked as complete!', 'vira-store'),
            'progress' => $progress_percentage,
            'completed_lessons' => count($completed_lessons),
            'total_lessons' => $total_lessons
        ]);
    }
    
    /**
     * Check if user has access to a course
     *
     * @param int $course_id Course ID
     * @param int $user_id User ID (0 for current user)
     * @return bool True if user has access, false otherwise
     */
    public function user_has_course_access(int $course_id, int $user_id = 0): bool {
        if (!$user_id) {
            $user_id = get_current_user_id();
        }
        
        if (!$user_id) {
            return false; // Guest users have no access
        }
        
        // Check if course exists and is published
        $course = get_post($course_id);
        if (!$course || $course->post_type !== $this->post_type || $course->post_status !== 'publish') {
            return false;
        }
        
        // Admin always has access
        if (current_user_can('manage_options')) {
            return true;
        }
        
        // Check if course is free
        $is_free = get_post_meta($course_id, '_vrstore_course_is_free', true);
        if ($is_free) {
            // For free courses, check enrollment
            $enrolled_courses = get_user_meta($user_id, '_vrstore_enrolled_courses', true);
            if (is_array($enrolled_courses) && in_array($course_id, $enrolled_courses)) {
                return $this->check_access_period($course_id, $user_id);
            }
            return false;
        }
        
        // For paid courses, check purchase/enrollment
        $enrolled_courses = get_user_meta($user_id, '_vrstore_enrolled_courses', true);
        if (is_array($enrolled_courses) && in_array($course_id, $enrolled_courses)) {
            return $this->check_access_period($course_id, $user_id);
        }
        
        // Check if user purchased the course through orders
        if ($this->user_has_purchased_course($course_id, $user_id)) {
            return $this->check_access_period($course_id, $user_id);
        }
        
        return false;
    }
    
    /**
     * Check if user has purchased a course
     *
     * @param int $course_id Course ID
     * @param int $user_id User ID
     * @return bool True if user has purchased, false otherwise
     */
    private function user_has_purchased_course(int $course_id, int $user_id): bool {
        global $wpdb;
        
        $user = get_user_by('ID', $user_id);
        if (!$user) {
            return false;
        }
        
        $orders_table = $wpdb->prefix . 'vrstore_orders';
        
        // Check if orders table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$orders_table'") !== $orders_table) {
            return false;
        }
        
        // Check for completed orders for this course
        $order_count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $orders_table 
             WHERE customer_email = %s 
               AND product_id = %d 
               AND (payment_status = 'completed' OR order_status = 'completed')",
            $user->user_email,
            $course_id
        ));
        
        return $order_count > 0;
    }
    
    /**
     * Check if user's access period is still valid
     *
     * @param int $course_id Course ID
     * @param int $user_id User ID
     * @return bool True if access period is valid, false otherwise
     */
    private function check_access_period(int $course_id, int $user_id): bool {
        $access_period_type = get_post_meta($course_id, '_vrstore_course_access_period_type', true);
        
        // If lifetime access or no access period set, return true
        if ($access_period_type !== 'limited') {
            return true;
        }
        
        $access_period_value = get_post_meta($course_id, '_vrstore_course_access_period_value', true);
        $access_period_unit = get_post_meta($course_id, '_vrstore_course_access_period_unit', true);
        
        if (!$access_period_value) {
            return true; // No limit set
        }
        
        // Get enrollment date
        $enrollment_date = get_user_meta($user_id, '_vrstore_course_enrollment_date_' . $course_id, true);
        if (!$enrollment_date) {
            // Set enrollment date to now if not set (for backward compatibility)
            $enrollment_date = current_time('mysql');
            update_user_meta($user_id, '_vrstore_course_enrollment_date_' . $course_id, $enrollment_date);
        }
        
        // Calculate expiry date
        $enrollment_timestamp = strtotime($enrollment_date);
        
        switch ($access_period_unit) {
            case 'days':
                $expiry_timestamp = $enrollment_timestamp + ($access_period_value * DAY_IN_SECONDS);
                break;
            case 'weeks':
                $expiry_timestamp = $enrollment_timestamp + ($access_period_value * WEEK_IN_SECONDS);
                break;
            case 'months':
                $expiry_timestamp = $enrollment_timestamp + ($access_period_value * MONTH_IN_SECONDS);
                break;
            case 'years':
                $expiry_timestamp = $enrollment_timestamp + ($access_period_value * YEAR_IN_SECONDS);
                break;
            default:
                return true; // Invalid unit, allow access
        }
        
        return time() < $expiry_timestamp;
    }
    
    /**
     * Save comment rating when comment is posted
     *
     * @param int $comment_id Comment ID
     * @return void
     */
    public function save_comment_rating($comment_id): void {
        if (isset($_POST['rating']) && !empty($_POST['rating'])) {
            $rating = intval($_POST['rating']);
            if ($rating >= 1 && $rating <= 5) {
                add_comment_meta($comment_id, 'rating', $rating);
            }
        }
    }
    
    /**
     * Update course average rating when new comment is added
     *
     * @param int $comment_id Comment ID
     * @return void
     */
    public function update_course_average_rating($comment_id): void {
        $comment = get_comment($comment_id);
        if (!$comment || get_post_type($comment->comment_post_ID) !== $this->post_type) {
            return;
        }
        
        $course_id = $comment->comment_post_ID;
        
        // Get all approved comments with ratings for this course
        $comments = get_comments([
            'post_id' => $course_id,
            'status' => 'approve',
            'meta_query' => [
                [
                    'key' => 'rating',
                    'compare' => 'EXISTS'
                ]
            ]
        ]);
        
        if (!empty($comments)) {
            $total_rating = 0;
            $count = 0;
            
            foreach ($comments as $review_comment) {
                $rating = get_comment_meta($review_comment->comment_ID, 'rating', true);
                if ($rating && $rating >= 1 && $rating <= 5) {
                    $total_rating += intval($rating);
                    $count++;
                }
            }
            
            if ($count > 0) {
                $average_rating = round($total_rating / $count, 1);
                update_post_meta($course_id, '_vrstore_course_average_rating', $average_rating);
                update_post_meta($course_id, '_vrstore_course_review_count', $count);
            }
        }
    }
    
    /**
     * Handle course enrollment when order is completed
     *
     * @param int $order_id Order ID
     * @param array $order_data Order data
     * @return void
     */
    public function handle_course_enrollment_on_order($order_id, $order_data): void {
        error_log('VRSTORE Course: Processing order enrollment for order ID: ' . $order_id);
        
        // Get cart items from order meta or from order data
        $cart_items = get_post_meta($order_id, '_vrstore_cart_items', true);
        
        // If not found in meta, try to get from order data
        if (empty($cart_items) && isset($order_data['cart_items'])) {
            $cart_items = $order_data['cart_items'];
        }
        
        // If still empty, try to get from order table
        if (empty($cart_items)) {
            global $wpdb;
            $orders_table = $wpdb->prefix . 'vrstore_orders';
            if ($wpdb->get_var("SHOW TABLES LIKE '$orders_table'") === $orders_table) {
                $order_row = $wpdb->get_row($wpdb->prepare(
                    "SELECT product_id FROM $orders_table WHERE id = %d",
                    $order_id
                ), ARRAY_A);
                if ($order_row && !empty($order_row['product_id'])) {
                    // Create fake cart item for single product order
                    $cart_items = [['product_id' => $order_row['product_id'], 'quantity' => 1]];
                }
            }
        }
        
        if (empty($cart_items) || !is_array($cart_items)) {
            error_log('VRSTORE Course: No cart items found in order ' . $order_id);
            return;
        }
        
        error_log('VRSTORE Course: Found ' . count($cart_items) . ' cart items to process');
        
        // Get user ID from various sources
        $user_id = get_post_meta($order_id, '_vrstore_user_id', true);
        
        // Try from order data if not in meta
        if (!$user_id && isset($order_data['user_id'])) {
            $user_id = intval($order_data['user_id']);
        }
        
        if (!$user_id) {
            // Try to get customer email and find/create user
            $customer_email = get_post_meta($order_id, '_vrstore_customer_email', true);
            if (!$customer_email && isset($order_data['customer_email'])) {
                $customer_email = $order_data['customer_email'];
            }
            
            if ($customer_email) {
                $user = get_user_by('email', $customer_email);
                $user_id = $user ? $user->ID : 0;
            }
        }
        
        if (!$user_id) {
            return; // Can't enroll without a user
        }
        
        // Check each cart item to see if it's a course or grants access to courses
        foreach ($cart_items as $item) {
            $product_id = $item['product_id'] ?? 0;
            
            // Check if this is a course
            $is_course = get_post_meta($product_id, '_vrstore_is_course', true);
            $post_type = get_post_type($product_id);
            
            if ($is_course || $post_type === $this->post_type) {
                error_log('VRSTORE Course: Processing course enrollment for product ' . $product_id . ' and user ' . $user_id);
                
                // Enroll user in course
                $this->enroll_user_in_course($product_id, $user_id, 'purchase');
            } else {
                // Check if this product grants access to any courses
                $courses_requiring_product = $this->get_courses_requiring_product($product_id);
                
                if (!empty($courses_requiring_product)) {
                    error_log('VRSTORE Course: Product ' . $product_id . ' grants access to ' . count($courses_requiring_product) . ' course(s)');
                    
                    foreach ($courses_requiring_product as $course_id) {
                        error_log('VRSTORE Course: Processing course enrollment for course ' . $course_id . ' via product ' . $product_id . ' and user ' . $user_id);
                        $this->enroll_user_in_course($course_id, $user_id, 'product_purchase');
                    }
                } else {
                    error_log('VRSTORE Course: Item ' . $product_id . ' is not a course and does not grant access to any courses (is_course: ' . $is_course . ', post_type: ' . $post_type . ')');
                }
            }
        }
    }
    
    /**
     * Enroll a user in a course
     *
     * @param int $course_id Course ID
     * @param int $user_id User ID
     * @param string $enrollment_type Type of enrollment (purchase, product_purchase, free)
     * @return bool True if enrolled successfully, false otherwise
     */
    private function enroll_user_in_course(int $course_id, int $user_id, string $enrollment_type = 'purchase'): bool {
        // Check enrollment limit before enrolling
        $max_students = get_post_meta($course_id, '_vrstore_course_max_students', true);
        if (!empty($max_students) && $max_students > 0) {
            $current_enrolled = $this->sync_enrollment_count($course_id);
            if ($current_enrolled >= $max_students) {
                error_log('VRSTORE Course: Enrollment limit reached for course ' . $course_id . '. Current: ' . $current_enrolled . ', Max: ' . $max_students);
                return false;
            }
        }
        
        // Get current enrolled courses
        $enrolled = get_user_meta($user_id, '_vrstore_enrolled_courses', true);
        if (!is_array($enrolled)) {
            $enrolled = [];
        }
        
        if (!in_array($course_id, $enrolled)) {
            $enrolled[] = $course_id;
            update_user_meta($user_id, '_vrstore_enrolled_courses', $enrolled);
            
            // Record enrollment date for access period tracking
            update_user_meta($user_id, '_vrstore_course_enrollment_date_' . $course_id, current_time('mysql'));
            
            // Update course enrollment count
            $enrolled_count = get_post_meta($course_id, '_vrstore_course_enrolled_count', true) ?: 0;
            update_post_meta($course_id, '_vrstore_course_enrolled_count', $enrolled_count + 1);
            
            error_log('VRSTORE Course: Successfully enrolled user ' . $user_id . ' in course ' . $course_id . ' via ' . $enrollment_type);
            
            // Log enrollment
            do_action('vrstore_course_enrolled', $course_id, $user_id, $enrollment_type);
            
            return true;
        } else {
            error_log('VRSTORE Course: User ' . $user_id . ' already enrolled in course ' . $course_id);
            return false;
        }
    }
    
    /**
     * Get courses that require a specific product for access
     *
     * @param int $product_id Product ID
     * @return array Array of course IDs that require this product
     */
    private function get_courses_requiring_product(int $product_id): array {
        global $wpdb;
        
        // Query for courses that have this product as their required product
        $course_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT post_id FROM {$wpdb->postmeta} 
             WHERE meta_key = '_vrstore_course_required_product_id' 
               AND meta_value = %d",
            $product_id
        ));
        
        // Filter to ensure these are actually published courses
        $valid_courses = [];
        foreach ($course_ids as $course_id) {
            $course = get_post($course_id);
            if ($course && $course->post_type === $this->post_type && $course->post_status === 'publish') {
                $valid_courses[] = intval($course_id);
            }
        }
        
        return $valid_courses;
    }
    
    /**
     * Calculate actual enrollment count for a course
     *
     * @param int $course_id Course ID
     * @return int Actual enrollment count
     */
    public function calculate_enrollment_count($course_id) {
        global $wpdb;
        
        // Get all users who have enrolled courses meta
        $enrolled_users = $wpdb->get_results(
            "SELECT user_id, meta_value FROM {$wpdb->usermeta} 
             WHERE meta_key = '_vrstore_enrolled_courses'"
        );
        
        $count = 0;
        
        foreach ($enrolled_users as $user_data) {
            $enrolled_courses = maybe_unserialize($user_data->meta_value);
            
            // Handle both array and serialized formats
            if (is_array($enrolled_courses)) {
                if (in_array($course_id, $enrolled_courses) || in_array((string) $course_id, $enrolled_courses)) {
                    $count++;
                }
            } elseif (is_string($enrolled_courses)) {
                // Handle serialized string format
                if (strpos($enrolled_courses, (string) $course_id) !== false) {
                    $count++;
                }
            }
        }
        
        return $count;
    }
    
    /**
     * Sync enrollment count for a course
     *
     * @param int $course_id Course ID
     * @return int Updated count
     */
    public function sync_enrollment_count($course_id) {
        $actual_count = $this->calculate_enrollment_count($course_id);
        update_post_meta($course_id, '_vrstore_course_enrolled_count', $actual_count);
        return $actual_count;
    }
    
    /**
     * Get checkout URL by finding page with vrstore_checkout shortcode
     *
     * @return string|false Checkout URL or false if not found
     */
    private function get_checkout_url() {
        // Check if we have cached the checkout URL
        static $checkout_url = null;
        
        if ($checkout_url !== null) {
            return $checkout_url;
        }
        
        // Query pages that contain the vrstore_checkout shortcode
        $pages = get_posts([
            'post_type' => 'page',
            'post_status' => 'publish',
            'posts_per_page' => -1,
            's' => '[vrstore_checkout]'
        ]);
        
        // If the search didn't work, manually check all pages
        if (empty($pages)) {
            $all_pages = get_pages([
                'post_status' => 'publish',
                'number' => 0
            ]);
            
            foreach ($all_pages as $page) {
                if (has_shortcode($page->post_content, 'vrstore_checkout')) {
                    $checkout_url = get_permalink($page->ID);
                    return $checkout_url;
                }
            }
        } else {
            // Double-check the first found page actually has the shortcode
            foreach ($pages as $page) {
                if (has_shortcode($page->post_content, 'vrstore_checkout')) {
                    $checkout_url = get_permalink($page->ID);
                    return $checkout_url;
                }
            }
        }
        
        // Cache false result to avoid repeated queries
        $checkout_url = false;
        return $checkout_url;
    }
    
    /**
     * Get cart URL by finding page with vrstore_cart shortcode
     *
     * @return string|false Cart URL or false if not found
     */
    private function get_cart_url() {
        // Check if we have cached the cart URL
        static $cart_url = null;
        
        if ($cart_url !== null) {
            return $cart_url;
        }
        
        // Query pages that contain the vrstore_cart shortcode
        $pages = get_posts([
            'post_type' => 'page',
            'post_status' => 'publish',
            'posts_per_page' => -1,
            's' => '[vrstore_cart]'
        ]);
        
        // If the search didn't work, manually check all pages
        if (empty($pages)) {
            $all_pages = get_pages([
                'post_status' => 'publish',
                'number' => 0
            ]);
            
            foreach ($all_pages as $page) {
                if (has_shortcode($page->post_content, 'vrstore_cart')) {
                    $cart_url = get_permalink($page->ID);
                    return $cart_url;
                }
            }
        } else {
            // Double-check the first found page actually has the shortcode
            foreach ($pages as $page) {
                if (has_shortcode($page->post_content, 'vrstore_cart')) {
                    $cart_url = get_permalink($page->ID);
                    return $cart_url;
                }
            }
        }
        
        // Cache false result to avoid repeated queries
        $cart_url = false;
        return $cart_url;
    }
    
    /**
     * Get account URL by finding page with vrstore_account shortcode
     *
     * @return string|false Account URL or false if not found
     */
    private function get_account_url() {
        // Check if we have cached the account URL
        static $account_url = null;
        
        if ($account_url !== null) {
            return $account_url;
        }
        
        // Query pages that contain the vrstore_account shortcode
        $pages = get_posts([
            'post_type' => 'page',
            'post_status' => 'publish',
            'posts_per_page' => -1,
            's' => '[vrstore_account]'
        ]);
        
        // If the search didn't work, manually check all pages
        if (empty($pages)) {
            $all_pages = get_pages([
                'post_status' => 'publish',
                'number' => 0
            ]);
            
            foreach ($all_pages as $page) {
                if (has_shortcode($page->post_content, 'vrstore_account')) {
                    $account_url = get_permalink($page->ID);
                    return $account_url;
                }
            }
        } else {
            // Double-check the first found page actually has the shortcode
            foreach ($pages as $page) {
                if (has_shortcode($page->post_content, 'vrstore_account')) {
                    $account_url = get_permalink($page->ID);
                    return $account_url;
                }
            }
        }
        
        // Cache false result to avoid repeated queries
        $account_url = false;
        return $account_url;
    }
    
    /**
     * Add lesson rewrite rules
     *
     * @return void
     */
    public function add_lesson_rewrite_rules(): void {
        add_rewrite_rule(
            '^lesson/?$',
            'index.php?vrstore_lesson=1',
            'top'
        );
        
        // Check if we need to flush rewrite rules
        if (get_option('vrstore_lesson_rewrite_flushed') !== '1') {
            flush_rewrite_rules();
            update_option('vrstore_lesson_rewrite_flushed', '1');
        }
    }
    
    /**
     * Add lesson query vars
     *
     * @param array $vars Query vars
     * @return array Modified query vars
     */
    public function add_lesson_query_vars($vars): array {
        $vars[] = 'vrstore_lesson';
        $vars[] = 'course_id';
        $vars[] = 'module_index';
        $vars[] = 'lesson_index';
        return $vars;
    }
    
    /**
     * Handle lesson template loading
     *
     * @return void
     */
    public function handle_lesson_template(): void {
        if (get_query_var('vrstore_lesson')) {
            $course_id = get_query_var('course_id');
            $module_index = get_query_var('module_index');
            $lesson_index = get_query_var('lesson_index');
            
            if ($course_id && $module_index !== '' && $lesson_index !== '') {
                // Check if user has access to the course
                $user_id = get_current_user_id();
                $has_access = $this->user_has_course_access($course_id, $user_id);
                
                // Check if this is a free preview lesson (from curriculum settings only)
                $is_free_preview = false;
                $curriculum = get_post_meta($course_id, '_vrstore_course_curriculum', true) ?: [];
                if (!empty($curriculum) && isset($curriculum[$module_index]['lessons'][$lesson_index])) {
                    $lesson_data = $curriculum[$module_index]['lessons'][$lesson_index];
                    $is_free_preview = isset($lesson_data['is_free_preview']) && $lesson_data['is_free_preview'];
                }
                
                // SECURITY: Ignore any preview parameter from URL - only use curriculum settings
                // This prevents bypassing access control with preview=1 parameter
                
                // If user doesn't have access and it's not a legitimate free preview, redirect to course page
                if (!$has_access && !$is_free_preview) {
                    $course_url = get_permalink($course_id);
                    if ($course_url) {
                        // Add a query parameter to indicate access denied
                        $redirect_url = add_query_arg('access_denied', '1', $course_url);
                        wp_redirect($redirect_url);
                        exit;
                    } else {
                        wp_die(__('Access denied. You need to enroll in this course to view this lesson.', 'vira-store'), 'Access Denied', ['response' => 403]);
                    }
                }
                
                // Set recursion prevention flag
                self::$is_filtering_content = true;
                
                // Load lesson template
                $template_path = VRSTORE_PLUGIN_DIR . 'views/course/lesson.php';
                if (file_exists($template_path)) {
                    include $template_path;
                    exit;
                } else {
                    wp_die('Lesson template not found.', 'Template Error', ['response' => 404]);
                }
            } else {
                wp_die('Invalid lesson parameters.', 'Invalid Request', ['response' => 400]);
            }
        }
    }
    
    /**
     * Check if user has provided correct password for password-protected course
     *
     * @param int $course_id Course ID
     * @return bool True if password is correct or not required
     */
    public function check_course_password_access($course_id): bool {
        $visibility = get_post_meta($course_id, '_vrstore_course_visibility', true);
        
        if ($visibility !== 'password') {
            return true; // Not password protected
        }
        
        $course_password = get_post_meta($course_id, '_vrstore_course_visibility_password', true);
        
        if (empty($course_password)) {
            return true; // No password set
        }
        
        // Check if password was provided via POST or session
        $provided_password = '';
        
        if (isset($_POST['course_password_' . $course_id])) {
            $provided_password = sanitize_text_field($_POST['course_password_' . $course_id]);
            
            // Store correct password in session
            if ($provided_password === $course_password) {
                if (!session_id()) {
                    session_start();
                }
                $_SESSION['vrstore_course_password_' . $course_id] = $provided_password;
                return true;
            }
        }
        
        // Check session for previously entered correct password
        if (!session_id()) {
            session_start();
        }
        
        if (isset($_SESSION['vrstore_course_password_' . $course_id]) && 
            $_SESSION['vrstore_course_password_' . $course_id] === $course_password) {
            return true;
        }
        
        return false;
    }
    
    /**
     * Filter courses based on visibility settings
     *
     * @param WP_Query $query Query object
     * @return void
     */
    public function filter_course_visibility($query): void {
        // Only filter main query for course post type on frontend
        if (is_admin() || !$query->is_main_query()) {
            return;
        }
        
        // Don't filter single course queries - allow direct access to hidden courses
        if (is_single() || is_singular($this->post_type)) {
            return;
        }
        
        // Only filter archive/listing queries
        $should_filter = false;
        
        // Check if this is a course archive or listing query
        if (is_post_type_archive($this->post_type)) {
            $should_filter = true;
        } elseif (is_home() && get_option('page_for_posts') == 0) {
            // Blog page showing all posts including courses
            $should_filter = true;
        } elseif (is_search()) {
            // Search results that might include courses
            $should_filter = true;
        } elseif (is_category() || is_tag()) {
            // Category/tag archives that might include courses
            $should_filter = true;
        }
        
        if (!$should_filter) {
            return;
        }
        
        // Get existing meta query
        $meta_query = $query->get('meta_query');
        if (!is_array($meta_query)) {
            $meta_query = [];
        }
        
        // Add visibility filter to exclude hidden courses from listings
        $visibility_filter = [
            'relation' => 'OR',
            [
                'key' => '_vrstore_course_visibility',
                'compare' => 'NOT EXISTS'
            ],
            [
                'key' => '_vrstore_course_visibility',
                'value' => 'hidden',
                'compare' => '!='
            ]
        ];
        
        // If we already have meta queries, wrap them properly
        if (!empty($meta_query)) {
            $meta_query = [
                'relation' => 'AND',
                $meta_query,
                $visibility_filter
            ];
        } else {
            $meta_query = $visibility_filter;
        }
        
        $query->set('meta_query', $meta_query);
    }
    
    
    /**
     * Ensure courses have license generation disabled
     *
     * @param int $post_id Post ID
     * @param WP_Post $post Post object
     * @return void
     */
    public function ensure_course_license_generation_disabled(int $post_id, $post): void {
        // Only apply to courses
        if ($post->post_type !== $this->post_type) {
            return;
        }
        
        // Skip if this is an autosave or revision
        if (wp_is_post_autosave($post_id) || wp_is_post_revision($post_id)) {
            return;
        }
        
        // Ensure license generation is disabled for this course
        $license_disabled = get_post_meta($post_id, '_vrstore_disable_license_generation', true);
        if (!$license_disabled) {
            update_post_meta($post_id, '_vrstore_disable_license_generation', '1');
        }
        
        // Also set the course flag for additional identification
        $is_course = get_post_meta($post_id, '_vrstore_is_course', true);
        if (!$is_course) {
            update_post_meta($post_id, '_vrstore_is_course', '1');
        }
    }
    
    /**
     * Handle secure course material downloads
     *
     * @return void
     */
    public function handle_course_material_download(): void {
        // Check if this is a course material download request
        if (!isset($_GET['vrstore_course_material_download'])) {
            return;
        }
        
        $download_token = sanitize_text_field($_GET['vrstore_course_material_download']);
        $course_id = absint($_GET['course_id'] ?? 0);
        $material_file = absint($_GET['material_file'] ?? 0);
        
        if (!$download_token || !$course_id || !$material_file) {
            wp_die(__('Invalid download request.', 'vira-store'), __('Access Denied', 'vira-store'), ['response' => 403]);
        }
        
        // Verify the course exists and is published
        $course = get_post($course_id);
        if (!$course || $course->post_type !== $this->post_type || $course->post_status !== 'publish') {
            wp_die(__('Course not found.', 'vira-store'), __('Not Found', 'vira-store'), ['response' => 404]);
        }
        
        // Check user permissions (must be logged in)
        if (!is_user_logged_in()) {
            wp_die(__('You must be logged in to download course materials.', 'vira-store'), __('Login Required', 'vira-store'), ['response' => 401]);
        }
        
        $current_user = wp_get_current_user();
        
        try {
            // Verify the download token using file protection system
            if (class_exists('VRSTORE_File_Protection')) {
                $file_protection = VRSTORE_File_Protection::get_instance();
                
                // Generate a token verification (simplified approach)
                // In production, you'd want to properly decode and verify the token
                
                // Get file information
                $file_url = wp_get_attachment_url($material_file);
                $file_path = get_attached_file($material_file);
                $file_name = get_the_title($material_file);
                
                if (!$file_path || !file_exists($file_path)) {
                    wp_die(__('File not found.', 'vira-store'), __('Not Found', 'vira-store'), ['response' => 404]);
                }
                
                // Log the download for tracking
                $this->log_material_download($course_id, $material_file, $current_user->ID, $file_name);
                
                // Serve the file securely
                $this->serve_course_material_file($file_path, $file_name);
                
            } else {
                // Fallback: redirect to direct file URL
                $file_url = wp_get_attachment_url($material_file);
                if ($file_url) {
                    wp_redirect($file_url);
                    exit;
                } else {
                    wp_die(__('File not found.', 'vira-store'), __('Not Found', 'vira-store'), ['response' => 404]);
                }
            }
        } catch (Exception $e) {
            wp_die(__('Download error occurred.', 'vira-store'), __('Error', 'vira-store'), ['response' => 500]);
        }
    }
    
    /**
     * Serve course material file securely
     *
     * @param string $file_path Full path to file
     * @param string $file_name File name for download
     * @return void
     */
    private function serve_course_material_file(string $file_path, string $file_name): void {
        // Security checks
        if (!is_readable($file_path)) {
            wp_die(__('File is not accessible.', 'vira-store'), __('Access Denied', 'vira-store'), ['response' => 403]);
        }
        
        // Prevent directory traversal
        $upload_dir = wp_upload_dir();
        $real_upload_path = realpath($upload_dir['basedir']);
        $real_file_path = realpath($file_path);
        
        if (!$real_file_path || strpos($real_file_path, $real_upload_path) !== 0) {
            wp_die(__('Invalid file path.', 'vira-store'), __('Access Denied', 'vira-store'), ['response' => 403]);
        }
        
        // Set appropriate headers
        $file_info = wp_check_filetype($file_path);
        $mime_type = $file_info['type'];
        
        // Force correct MIME types for common file extensions
        $file_extension = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
        if ($file_extension === 'zip') {
            $mime_type = 'application/zip';
        } elseif ($file_extension === 'pdf') {
            $mime_type = 'application/pdf';
        }
        
        // Fallback to binary stream if no MIME type detected
        if (empty($mime_type)) {
            $mime_type = 'application/octet-stream';
        }
        
        $file_size = filesize($file_path);
        
        // Clear any previous output
        if (ob_get_level()) {
            ob_end_clean();
        }
        
        // Ensure filename has proper extension
        $original_filename = basename($file_path);
        if (pathinfo($file_name, PATHINFO_EXTENSION) === '' && pathinfo($original_filename, PATHINFO_EXTENSION) !== '') {
            $file_name = $file_name . '.' . pathinfo($original_filename, PATHINFO_EXTENSION);
        }
        
        // Set headers
        header('Content-Type: ' . $mime_type);
        header('Content-Disposition: attachment; filename="' . sanitize_file_name($file_name) . '"');
        header('Content-Transfer-Encoding: binary');
        header('Accept-Ranges: bytes');
        header('Content-Length: ' . $file_size);
        header('Cache-Control: private, no-cache, no-store, must-revalidate');
        header('Pragma: no-cache');
        header('Expires: 0');
        
        // Prevent output buffering issues
        while (ob_get_level()) {
            ob_end_clean();
        }
        
        // Serve file
        readfile($file_path);
        exit;
    }
    
    /**
     * Log material download for tracking
     *
     * @param int $course_id Course ID
     * @param int $material_file Material file ID
     * @param int $user_id User ID
     * @param string $file_name File name
     * @return void
     */
    private function log_material_download(int $course_id, int $material_file, int $user_id, string $file_name): void {
        global $wpdb;
        
        // Check if download tracking table exists
        $download_table = $wpdb->prefix . 'vrstore_download_tracking';
        
        if ($wpdb->get_var("SHOW TABLES LIKE '$download_table'") === $download_table) {
            // Get proper user data for logging
            $user_data = get_userdata($user_id);
            $customer_name = '';
            $customer_email = '';
            
            if ($user_data) {
                $customer_name = $user_data->display_name ?: $user_data->user_login;
                $customer_email = $user_data->user_email;
            }
            
            // Try to find the order ID for this course purchase
            $order_id = 0;
            $orders_table = $wpdb->prefix . 'vrstore_orders';
            if ($wpdb->get_var("SHOW TABLES LIKE '$orders_table'") === $orders_table) {
                // Look for the most recent completed order for this course and customer
                $order = $wpdb->get_row($wpdb->prepare(
                    "SELECT id FROM $orders_table 
                     WHERE product_id = %d AND customer_email = %s 
                     AND (payment_status = 'completed' OR order_status = 'completed')
                     ORDER BY created_at DESC LIMIT 1",
                    $course_id,
                    $customer_email
                ));
                
                if ($order) {
                    $order_id = $order->id;
                }
            }
            
            // Get file information for better tracking
            $file_url = wp_get_attachment_url($material_file);
            $file_path = get_attached_file($material_file);
            $file_size = $file_path ? filesize($file_path) : null;
            
            // Determine file type from file extension
            $file_type = 'unknown';
            if ($file_path) {
                $file_extension = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
                $file_type = $this->get_file_type_from_extension($file_extension);
            } elseif ($file_url) {
                $file_extension = strtolower(pathinfo($file_url, PATHINFO_EXTENSION));
                $file_type = $this->get_file_type_from_extension($file_extension);
            }
            
            // Log to existing download tracking table
            $wpdb->insert(
                $download_table,
                [
                    'product_id' => $course_id,
                    'order_id' => $order_id,
                    'customer_name' => $customer_name,
                    'customer_email' => $customer_email,
                    'file_name' => $file_name,
                    'file_url' => $file_url,
                    'file_type' => $file_type,
                    'file_size' => $file_size,
                    'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
                    'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
                    'download_date' => current_time('mysql'),
                    'download_type' => 'course_material',
                    'download_process' => 'secure',
                    'user_id' => $user_id
                ],
                [
                    '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%d'
                ]
            );
        }
        
        // Also create a course-specific log entry
        $current_downloads = get_post_meta($course_id, '_vrstore_material_downloads', true);
        $current_downloads = is_numeric($current_downloads) ? intval($current_downloads) : 0;
        update_post_meta($course_id, '_vrstore_material_downloads', $current_downloads + 1);
    }
    
    /**
     * Get file type from file extension
     *
     * @param string $extension File extension
     * @return string File type
     */
    private function get_file_type_from_extension(string $extension): string {
        $type_mapping = [
            // Documents
            'pdf' => 'document',
            'doc' => 'document',
            'docx' => 'document',
            'txt' => 'document',
            'rtf' => 'document',
            'odt' => 'document',
            
            // Spreadsheets
            'xls' => 'spreadsheet',
            'xlsx' => 'spreadsheet',
            'csv' => 'spreadsheet',
            'ods' => 'spreadsheet',
            
            // Presentations
            'ppt' => 'presentation',
            'pptx' => 'presentation',
            'odp' => 'presentation',
            
            // Archives
            'zip' => 'archive',
            'rar' => 'archive',
            '7z' => 'archive',
            'tar' => 'archive',
            'gz' => 'archive',
            
            // Images
            'jpg' => 'image',
            'jpeg' => 'image',
            'png' => 'image',
            'gif' => 'image',
            'svg' => 'image',
            'bmp' => 'image',
            'webp' => 'image',
            
            // Videos
            'mp4' => 'video',
            'avi' => 'video',
            'mkv' => 'video',
            'mov' => 'video',
            'wmv' => 'video',
            'flv' => 'video',
            'webm' => 'video',
            
            // Audio
            'mp3' => 'audio',
            'wav' => 'audio',
            'flac' => 'audio',
            'aac' => 'audio',
            'ogg' => 'audio',
            
            // Code
            'html' => 'code',
            'css' => 'code',
            'js' => 'code',
            'php' => 'code',
            'py' => 'code',
            'java' => 'code',
            'cpp' => 'code',
            'c' => 'code',
            'json' => 'code',
            'xml' => 'code',
        ];
        
        return $type_mapping[$extension] ?? 'upload';
    }
    
    /**
     * AJAX handler to track material downloads
     *
     * @return void
     */
    public function ajax_track_material_download(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_lesson_nonce')) {
            wp_die('Security check failed.');
        }
        
        $course_id = absint($_POST['course_id'] ?? 0);
        $material_id = absint($_POST['material_id'] ?? 0);
        
        if (!$course_id || !$material_id) {
            wp_send_json_error(['message' => __('Invalid parameters.', 'vira-store')]);
        }
        
        // Log the download tracking event
        if (is_user_logged_in()) {
            $user_id = get_current_user_id();
            $file_name = get_the_title($material_id);
            
            $this->log_material_download($course_id, $material_id, $user_id, $file_name);
            
            wp_send_json_success(['message' => __('Download tracked successfully.', 'vira-store')]);
        } else {
            wp_send_json_error(['message' => __('User not logged in.', 'vira-store')]);
        }
    }
    
    /**
     * AJAX handler to track video events (play, pause, seek, end, etc.)
     *
     * @return void
     */
    public function ajax_track_video_event(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_lesson_nonce')) {
            wp_die('Security check failed.');
        }
        
        $course_id = absint($_POST['course_id'] ?? 0);
        $lesson_id = absint($_POST['lesson_id'] ?? 0);
        $event_type = sanitize_text_field($_POST['event_type'] ?? '');
        $video_time = floatval($_POST['video_time'] ?? 0);
        $duration = floatval($_POST['duration'] ?? 0);
        $video_url = esc_url_raw($_POST['video_url'] ?? '');
        
        // Validate required parameters
        if (!$course_id || !$lesson_id || !$event_type) {
            wp_send_json_error(['message' => __('Invalid parameters.', 'vira-store')]);
        }
        
        // Validate event type
        $allowed_events = ['play', 'pause', 'seek', 'ended', 'progress', 'fullscreen', 'mute', 'unmute'];
        if (!in_array($event_type, $allowed_events)) {
            wp_send_json_error(['message' => __('Invalid event type.', 'vira-store')]);
        }
        
        // Get user ID if logged in
        $user_id = is_user_logged_in() ? get_current_user_id() : 0;
        
        // Store video tracking data
        global $wpdb;
        
        $video_tracking_table = $wpdb->prefix . 'vrstore_video_tracking';
        
        // Check if table exists
        $table_exists = $wpdb->get_var($wpdb->prepare(
            "SHOW TABLES LIKE %s",
            $video_tracking_table
        ));
        
        if (!$table_exists) {
            wp_send_json_error(['message' => __('Video tracking table not available.', 'vira-store')]);
        }
        
        // Insert tracking data
        $result = $wpdb->insert(
            $video_tracking_table,
            [
                'course_id' => $course_id,
                'lesson_id' => $lesson_id,
                'user_id' => $user_id,
                'event_type' => $event_type,
                'video_time' => $video_time,
                'duration' => $duration,
                'video_url' => $video_url,
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
                'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
                'session_id' => session_id() ?: wp_generate_uuid4(),
                'created_at' => current_time('mysql'),
            ],
            [
                '%d', // course_id
                '%d', // lesson_id
                '%d', // user_id
                '%s', // event_type
                '%f', // video_time
                '%f', // duration
                '%s', // video_url
                '%s', // user_agent
                '%s', // ip_address
                '%s', // session_id
                '%s'  // created_at
            ]
        );
        
        if ($result !== false) {
            // Update video analytics if this is a significant event
            if (in_array($event_type, ['play', 'ended'])) {
                $this->update_video_analytics($course_id, $lesson_id, $event_type, $video_time, $duration);
            }
            
            wp_send_json_success([
                'message' => __('Video event tracked successfully.', 'vira-store'),
                'event_id' => $wpdb->insert_id
            ]);
        } else {
            wp_send_json_error([
                'message' => __('Failed to track video event.', 'vira-store'),
                'error' => $wpdb->last_error
            ]);
        }
    }
    
    /**
     * Update video analytics based on tracking events
     *
     * @param int $course_id Course ID
     * @param int $lesson_id Lesson ID
     * @param string $event_type Event type
     * @param float $video_time Current video time
     * @param float $duration Video duration
     * @return void
     */
    private function update_video_analytics(int $course_id, int $lesson_id, string $event_type, float $video_time, float $duration): void {
        global $wpdb;
        
        $video_analytics_table = $wpdb->prefix . 'vrstore_video_analytics';
        
        // Check if table exists
        $table_exists = $wpdb->get_var($wpdb->prepare(
            "SHOW TABLES LIKE %s",
            $video_analytics_table
        ));
        
        if (!$table_exists) {
            return;
        }
        
        $user_id = is_user_logged_in() ? get_current_user_id() : 0;
        $today = date('Y-m-d');
        
        // Check if analytics record exists for today
        $existing_record = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$video_analytics_table} WHERE course_id = %d AND lesson_id = %d AND date = %s",
            $course_id,
            $lesson_id,
            $today
        ));
        
        if ($existing_record) {
            // Update existing record
            $updates = [];
            $values = [];
            $formats = [];
            
            if ($event_type === 'play') {
                $updates[] = 'total_plays = total_plays + 1';
                if ($user_id > 0) {
                    $updates[] = 'unique_viewers = CASE WHEN FIND_IN_SET(%d, unique_viewer_ids) = 0 THEN unique_viewers + 1 ELSE unique_viewers END';
                    $updates[] = 'unique_viewer_ids = CASE WHEN FIND_IN_SET(%d, unique_viewer_ids) = 0 THEN CONCAT_WS(",", unique_viewer_ids, %d) ELSE unique_viewer_ids END';
                    $values[] = $user_id;
                    $values[] = $user_id;
                    $values[] = $user_id;
                    $formats = array_merge($formats, ['%d', '%d', '%d']);
                }
            } elseif ($event_type === 'ended' && $duration > 0) {
                $completion_rate = ($video_time / $duration) * 100;
                $updates[] = 'total_completions = total_completions + 1';
                $updates[] = 'avg_completion_rate = ((avg_completion_rate * total_completions - avg_completion_rate) + %f) / total_completions';
                $values[] = $completion_rate;
                $formats[] = '%f';
            }
            
            if (!empty($updates)) {
                $values[] = $course_id;
                $values[] = $lesson_id;
                $values[] = $today;
                $formats = array_merge($formats, ['%d', '%d', '%s']);
                
                $wpdb->query($wpdb->prepare(
                    "UPDATE {$video_analytics_table} SET " . implode(', ', $updates) . 
                    ", updated_at = NOW() WHERE course_id = %d AND lesson_id = %d AND date = %s",
                    $values
                ));
            }
        } else {
            // Create new analytics record
            $data = [
                'course_id' => $course_id,
                'lesson_id' => $lesson_id,
                'date' => $today,
                'total_plays' => 0,
                'total_completions' => 0,
                'unique_viewers' => 0,
                'unique_viewer_ids' => '',
                'avg_completion_rate' => 0.0,
                'avg_watch_time' => 0.0,
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql')
            ];
            
            if ($event_type === 'play') {
                $data['total_plays'] = 1;
                if ($user_id > 0) {
                    $data['unique_viewers'] = 1;
                    $data['unique_viewer_ids'] = (string)$user_id;
                }
            } elseif ($event_type === 'ended' && $duration > 0) {
                $data['total_completions'] = 1;
                $data['avg_completion_rate'] = ($video_time / $duration) * 100;
            }
            
            $wpdb->insert(
                $video_analytics_table,
                $data,
                [
                    '%d', // course_id
                    '%d', // lesson_id
                    '%s', // date
                    '%d', // total_plays
                    '%d', // total_completions
                    '%d', // unique_viewers
                    '%s', // unique_viewer_ids
                    '%f', // avg_completion_rate
                    '%f', // avg_watch_time
                    '%s', // created_at
                    '%s'  // updated_at
                ]
            );
        }
    }
    
    /**
     * Check if user owns a specific product
     *
     * @param int $user_id User ID
     * @param int $product_id Product ID
     * @return bool True if user owns the product, false otherwise
     */
    private function user_owns_product(int $user_id, int $product_id): bool {
        if (!$user_id || !$product_id) {
            return false;
        }
        
        // Get user's purchased products
        $purchased_products = get_user_meta($user_id, '_vrstore_purchased_products', true);
        if (!is_array($purchased_products)) {
            $purchased_products = [];
        }
        
        return in_array($product_id, $purchased_products);
    }
    
    /**
     * Clean up course-related data when a course is deleted
     *
     * @param int $post_id The post ID being deleted
     * @param WP_Post $post The post object being deleted
     * @return void
     */
    public function cleanup_course_data_on_deletion(int $post_id, $post): void {
        // Only process if this is a vrstore_course post type
        if (!$post || $post->post_type !== $this->post_type) {
            return;
        }
        
        global $wpdb;
        
        // Clean up course-related database tables
        $tables_to_clean = [
            'vrstore_course_analytics',
            'vrstore_course_enrollments', 
            'vrstore_course_progress',
            'vrstore_lesson_completions',
            'vrstore_course_certificates',
            'vrstore_video_tracking',
            'vrstore_video_analytics',
            'vrstore_content_analytics'
        ];
        
        foreach ($tables_to_clean as $table) {
            $table_name = $wpdb->prefix . $table;
            
            // Check if table exists before attempting to delete
            $table_exists = $wpdb->get_var($wpdb->prepare(
                "SHOW TABLES LIKE %s",
                $table_name
            ));
            
            if ($table_exists) {
                $wpdb->delete(
                    $table_name,
                    ['course_id' => $post_id],
                    ['%d']
                );
            }
        }
        
        // Clean up course-related transients and cache
        $cache_keys_to_delete = [
            "_transient_vrstore_course_analytics_{$post_id}",
            "_transient_timeout_vrstore_course_analytics_{$post_id}",
            "_transient_vrstore_video_analytics_{$post_id}",
            "_transient_timeout_vrstore_video_analytics_{$post_id}",
            "_transient_vrstore_analytics_{$post_id}",
            "_transient_timeout_vrstore_analytics_{$post_id}"
        ];
        
        foreach ($cache_keys_to_delete as $key) {
            delete_option($key);
        }
        
        // Clean up course-specific cache patterns
        $cache_patterns = [
            "video_engagement_{$post_id}_%",
            "top_performing_content_{$post_id}_%",
            "course_analytics_cache_{$post_id}_%"
        ];
        
        foreach ($cache_patterns as $pattern) {
            $wpdb->query($wpdb->prepare(
                "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
                $pattern
            ));
        }
        
        // Clear object cache if available
        if (function_exists('wp_cache_delete_group')) {
            wp_cache_delete_group("vrstore_course_{$post_id}");
        }
        
        // Log the cleanup action
        error_log("VRSTORE Course: Cleaned up all data for deleted course ID {$post_id}");
    }
    
}
