<?php
/**
 * License Helper Class - Utility methods for license system
 *
 * @package Vira_Store
 * @since 1.0.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Helper class for license operations
 */
class VRSTORE_License_Helper {
    
    /**
     * Get expiry date from license data (handles field name inconsistencies)
     * 
     * @param array $license License data
     * @return string|null Expiry date or null
     */
    public static function get_expiry_date(array $license): ?string {
        // Priority order: expires_at (standard) > expiry_date (legacy) > expires (alias)
        $expiry = $license[VRSTORE_License::EXPIRY_FIELD] ?? 
                  $license['expiry_date'] ?? 
                  $license['expires'] ?? 
                  null;
        
        // Validate date format
        if (empty($expiry) || 
            $expiry === '0000-00-00' || 
            $expiry === '0000-00-00 00:00:00') {
            return null;
        }
        
        return $expiry;
    }
    
    /**
     * Normalize site URL for consistent matching
     * 
     * @param string $url Site URL
     * @return string Normalized URL
     */
    public static function normalize_site_url(string $url): string {
        // Remove protocol
        $url = preg_replace('#^https?://#i', '', $url);
        
        // Remove path (keep only domain)
        $url = explode('/', $url)[0];
        
        // Remove port
        $url = explode(':', $url)[0];
        
        // Lowercase and trim
        $url = strtolower(trim($url));
        
        // Remove trailing dots
        $url = rtrim($url, '.');
        
        return $url;
    }
    
    /**
     * Validate product exists and is active
     * 
     * @param int $product_id Product ID
     * @return bool Product is valid
     */
    public static function validate_product_exists(int $product_id): bool {
        if ($product_id <= 0) {
            return false;
        }
        
        $product = get_post($product_id);
        
        return $product && 
               $product->post_type === 'vrstore_product' && 
               $product->post_status === 'publish';
    }
    
    /**
     * Validate license is bound to specific product
     * 
     * @param string $license_key License key
     * @param int    $product_id  Product ID
     * @return bool License is bound to product
     */
    public static function validate_license_product_binding(
        string $license_key, 
        int $product_id
    ): bool {
        global $wpdb;
        
        $licenses_table = $wpdb->prefix . 'vrstore_licenses';
        
        $license_product = $wpdb->get_var($wpdb->prepare(
            "SELECT product_id FROM $licenses_table WHERE license_key = %s",
            $license_key
        ));
        
        if (!$license_product) {
            return false;
        }
        
        return intval($license_product) === $product_id;
    }
    
    /**
     * Sync activation count with actual activations
     * 
     * @param string $license_key License key
     * @return int Actual activation count
     */
    public static function sync_activation_count(string $license_key): int {
        global $wpdb;
        
        $activations_table = $wpdb->prefix . 'vrstore_license_activations';
        $licenses_table = $wpdb->prefix . 'vrstore_licenses';
        
        // Count actual active activations
        $actual_count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $activations_table 
             WHERE license_key = %s AND status = 'active'",
            $license_key
        ));
        
        $actual_count = intval($actual_count);
        
        // Update license record
        $wpdb->update(
            $licenses_table,
            ['activation_count' => $actual_count, 'updated_at' => current_time('mysql')],
            ['license_key' => $license_key],
            ['%d', '%s'],
            ['%s']
        );
        
        return $actual_count;
    }
    
    /**
     * Convert months to days (exact calculation)
     * 
     * @param int $months Number of months
     * @return int Number of days
     */
    public static function convert_months_to_days(int $months): int {
        if ($months <= 0) {
            return 0; // Lifetime
        }
        
        // Use exact calculation based on current date
        $start = new DateTime();
        $end = clone $start;
        $end->modify("+{$months} months");
        
        return $start->diff($end)->days;
    }
    
    /**
     * Validate license type slug format
     * 
     * @param string $slug License type slug
     * @return bool Valid slug
     */
    public static function validate_license_type_slug(string $slug): bool {
        // Must be lowercase alphanumeric with hyphens only
        return !empty($slug) && preg_match('/^[a-z0-9-]+$/', $slug) === 1;
    }
    
    /**
     * Generate unique license type slug
     * 
     * @param string $label License type label
     * @param array  $existing_slugs Existing slugs to avoid
     * @return string Unique slug
     */
    public static function generate_unique_slug(string $label, array $existing_slugs = []): string {
        $slug = sanitize_title($label);
        
        if (empty($slug)) {
            $slug = 'license-' . uniqid();
        }
        
        // Ensure uniqueness
        $original_slug = $slug;
        $counter = 1;
        
        while (in_array($slug, $existing_slugs, true)) {
            $slug = $original_slug . '-' . $counter;
            $counter++;
        }
        
        return $slug;
    }
    
    /**
     * Check if license type is available for product
     * 
     * @param int    $product_id   Product ID
     * @param string $license_type License type slug
     * @return bool Available
     */
    public static function is_license_type_available(int $product_id, string $license_type): bool {
        $availability = get_post_meta($product_id, '_vrstore_product_license_availability', true);
        
        if (!is_array($availability)) {
            return true; // Default to available if not set
        }
        
        return isset($availability[$license_type]) && $availability[$license_type] === true;
    }
    
    /**
     * Get client IP address (with proxy support)
     * 
     * @return string IP address
     */
    public static function get_client_ip(): string {
        $ip_keys = [
            'HTTP_CF_CONNECTING_IP',
            'HTTP_X_REAL_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_FORWARDED',
            'HTTP_FORWARDED_FOR',
            'HTTP_FORWARDED',
            'HTTP_CLIENT_IP',
            'REMOTE_ADDR'
        ];
        
        foreach ($ip_keys as $key) {
            if (isset($_SERVER[$key]) && !empty($_SERVER[$key])) {
                $ip_string = sanitize_text_field(wp_unslash($_SERVER[$key]));
                
                // Handle comma-separated IPs (take first valid one)
                if (strpos($ip_string, ',') !== false) {
                    $ips = explode(',', $ip_string);
                    foreach ($ips as $ip_candidate) {
                        $ip_candidate = trim($ip_candidate);
                        if (filter_var($ip_candidate, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                            return $ip_candidate;
                        }
                    }
                    // Fallback to first IP even if private
                    $ip_candidate = trim($ips[0]);
                    if (filter_var($ip_candidate, FILTER_VALIDATE_IP)) {
                        return $ip_candidate;
                    }
                } else {
                    $ip = trim($ip_string);
                    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                        return $ip;
                    }
                }
            }
        }
        
        // Fallback
        $fallback_ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '0.0.0.0';
        return filter_var($fallback_ip, FILTER_VALIDATE_IP) ? $fallback_ip : '0.0.0.0';
    }
    
    /**
     * Log license operation for debugging
     * 
     * @param string $operation Operation name
     * @param array  $data      Operation data
     * @return void
     */
    public static function log_operation(string $operation, array $data): void {
        if (!defined('WP_DEBUG') || !WP_DEBUG) {
            return;
        }
        
        $log_message = sprintf(
            'ViraStore License: %s - %s',
            $operation,
            json_encode($data)
        );
        
        error_log($log_message);
    }
    
    /**
     * Clear license-related caches
     * 
     * @param string|null $license_key Optional specific license key
     * @return void
     */
    public static function clear_caches(?string $license_key = null): void {
        if ($license_key) {
            // Clear specific license caches
            wp_cache_delete('license_domains_' . $license_key, 'vrstore');
            
            $args_variants = [
                ['status' => 'active', 'per_page' => 100],
                ['status' => 'active', 'per_page' => 20],
                ['status' => '', 'per_page' => 100],
                ['status' => '', 'per_page' => 20]
            ];
            
            foreach ($args_variants as $args) {
                $cache_key = 'vrstore_license_domain_activations_' . md5($license_key . serialize($args));
                delete_transient($cache_key);
            }
        } else {
            // Clear all license caches
            wp_cache_delete('vrstore_settings', 'options');
            delete_transient('vrstore_license_types');
            delete_transient('vrstore_custom_license_types');
        }
    }
}
