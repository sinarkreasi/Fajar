<?php
/**
 * Admin Menu Class
 *
 * @package Vira_Store
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Admin menu management class
 */
class VRSTORE_Admin_Menu {
    /**
     * Singleton instance
     *
     * @var VRSTORE_Admin_Menu|null
     */
    private static ?VRSTORE_Admin_Menu $instance = null;

    /**
     * Get singleton instance
     *
     * @return VRSTORE_Admin_Menu
     */
    public static function get_instance(): VRSTORE_Admin_Menu {
        if (null === self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        // Handle redirects before any output
        add_action('admin_init', [$this, 'handle_early_actions'], 1);
        
        add_action('admin_menu', [$this, 'add_admin_menus'], 9);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);
        add_action('wp_ajax_vrstore_generate_license', [$this, 'ajax_generate_license']);
        add_action('wp_ajax_vrstore_get_license_details', [$this, 'ajax_get_license_details']);
        add_action('wp_ajax_vrstore_get_license_type_config', [$this, 'ajax_get_license_type_config']);
        add_action('wp_ajax_vrstore_save_coupon', [$this, 'ajax_save_coupon']);
        add_action('wp_ajax_vrstore_get_coupon', [$this, 'ajax_get_coupon']);
        add_action('wp_ajax_vrstore_repair_database', [$this, 'ajax_repair_database']);
        add_action('wp_ajax_vrstore_check_database_status', [$this, 'ajax_check_database_status']);
        add_action('wp_ajax_vrstore_migrate_license_types', [$this, 'ajax_migrate_license_types']);
        add_action('wp_ajax_vrstore_get_order_details', [$this, 'ajax_get_order_details']);
        add_action('wp_ajax_vrstore_update_order_status', [$this, 'ajax_update_order_status']);
        add_action('wp_ajax_vrstore_get_activation_details', [$this, 'ajax_get_activation_details']);
        add_action('wp_ajax_vrstore_assign_customer_roles', [$this, 'ajax_assign_customer_roles']);
        add_action('wp_ajax_vrstore_complete_manual_order', [$this, 'ajax_complete_manual_order']);
        add_action('wp_ajax_vrstore_get_customer_deletion_details', [$this, 'ajax_get_customer_deletion_details']);
        
        // Payment Testing AJAX handlers
        add_action('wp_ajax_vrstore_run_payment_test', [$this, 'ajax_run_payment_test']);
        add_action('wp_ajax_vrstore_clear_payment_test_logs', [$this, 'ajax_clear_payment_test_logs']);
        add_action('wp_ajax_vrstore_export_downloads', [$this, 'ajax_export_downloads']);
        add_action('wp_ajax_vrstore_clear_all_downloads', [$this, 'ajax_clear_all_downloads']);
        add_action('wp_ajax_vrstore_get_download_details', [$this, 'ajax_get_download_details']);
        
        // Invoice AJAX handlers
        add_action('wp_ajax_vrstore_admin_generate_invoice', [$this, 'ajax_admin_generate_invoice']);
        
        // Support Ticket AJAX handlers
        add_action('wp_ajax_vrstore_get_customer_tickets', [$this, 'ajax_get_customer_tickets']);
        add_action('wp_ajax_vrstore_get_ticket_details', [$this, 'ajax_get_ticket_details']);
        add_action('wp_ajax_vrstore_update_ticket_status', [$this, 'ajax_update_ticket_status']);
        add_action('wp_ajax_vrstore_add_ticket_reply', [$this, 'ajax_add_ticket_reply']);
        
        // Debug AJAX handler
        add_action('wp_ajax_vrstore_debug_support', [$this, 'ajax_debug_support']);
        
        // CSV export AJAX handlers
        add_action('wp_ajax_vrstore_export_csv', [$this, 'ajax_export_csv']);
        add_action('wp_ajax_vrstore_export_customers_csv', [$this, 'ajax_export_customers_csv']);
        add_action('wp_ajax_vrstore_export_orders_csv', [$this, 'ajax_export_orders_csv']);
        add_action('wp_ajax_vrstore_export_courses_csv', [$this, 'ajax_export_courses_csv']);
        
        // CSV download handler
        add_action('wp_ajax_vrstore_download_csv', [$this, 'ajax_download_csv']);
        
        // Course data reset AJAX handler
        add_action('wp_ajax_vrstore_reset_course_data', [$this, 'ajax_reset_course_data']);
        
        // Plugin version management AJAX handlers
        add_action('wp_ajax_vrstore_load_plugin_versions', [$this, 'ajax_load_plugin_versions']);
        add_action('wp_ajax_vrstore_update_plugin_version', [$this, 'ajax_update_plugin_version']);
        add_action('wp_ajax_vrstore_delete_plugin_version', [$this, 'ajax_delete_plugin_version']);
    }

    /**
     * Get translated text with conditional loading check.
     *
     * @since 1.0.0
     * @param string $text The text to translate.
     * @return string
     */
    private function get_translated_text( $text ) {
        if ( vrstore_is_textdomain_ready() ) {
            return esc_html__( $text, 'vira-store' );
        }
        return esc_html( $text );
    }

    /**
     * Handle actions early before any output
     *
     * @return void
     */
    public function handle_early_actions(): void {
        // Only process on plugin admin pages
        if (!isset($_GET['page'])) {
            return;
        }
        $page = sanitize_text_field($_GET['page']);
        
        // Customers: process actions early to avoid output before redirect
        if (
            $page === 'vrstore-customers' &&
            isset($_REQUEST['action'], $_REQUEST['customer_id']) &&
            in_array($_REQUEST['action'], ['activate', 'deactivate', 'delete'], true)
        ) {
            $this->process_customer_action();
            return;
        }
        
        // Coupons: process actions early to avoid output before redirect
        if (
            $page === 'vrstore-coupons' &&
            isset($_REQUEST['action'], $_REQUEST['coupon_id']) &&
            in_array($_REQUEST['action'], ['activate', 'deactivate', 'delete'], true)
        ) {
            $this->process_coupon_action();
            return;
        }
        
        // Licenses: process actions early to avoid output before redirect
        if (
            $page === 'vrstore-licenses' &&
            isset($_REQUEST['action'], $_REQUEST['license_id']) &&
            in_array($_REQUEST['action'], ['activate', 'deactivate', 'delete'], true)
        ) {
            $this->process_license_action();
            return;
        }
        
        // Orders: process actions early to avoid output before redirect
        if (
            $page === 'vrstore-orders' &&
            isset($_REQUEST['action'], $_REQUEST['order_id']) &&
            in_array($_REQUEST['action'], ['view', 'change_status', 'delete'], true)
        ) {
            $this->process_order_action();
            return;
        }
        
        // Domain Activations: process actions early to avoid output before redirect
        if (
            $page === 'vrstore-domain-activations' &&
            isset($_REQUEST['action'], $_REQUEST['activation_id']) &&
            in_array($_REQUEST['action'], ['deactivate', 'refresh', 'delete'], true)
        ) {
            $this->process_domain_activation_action();
            return;
        }
    }

    /**
     * Enqueue admin assets for plugin pages
     *
     * @param string $hook Current admin page hook
     * @return void
     */
    public function enqueue_admin_assets(string $hook): void {
        // Only enqueue on our plugin admin pages
        if (strpos($hook, 'vrstore-') === false && strpos($hook, 'vira-store_page_') === false) {
            return;
        }

        // Enqueue main admin CSS
        wp_enqueue_style(
            'vrstore-admin',
            VRSTORE_PLUGIN_URL . 'assets/css/admin.css',
            [],
            VRSTORE_VERSION
        );

        // Enqueue main admin JS
        wp_enqueue_script(
            'vrstore-admin',
            VRSTORE_PLUGIN_URL . 'assets/js/admin.js',
            ['jquery'],
            VRSTORE_VERSION,
            true
        );

        // Enqueue admin-menu.js for license management functionality
        wp_enqueue_script(
            'vrstore-admin-menu',
            VRSTORE_PLUGIN_URL . 'assets/js/admin-menu.js',
            ['jquery', 'vrstore-admin'],
            VRSTORE_VERSION,
            true
        );
        
        // Enqueue support tickets assets for customers page
        if (strpos($hook, 'vrstore-customers') !== false) {
            // Note: admin-support.css styles have been merged into admin.css
            
            wp_enqueue_script(
                'vrstore-admin-support',
                VRSTORE_PLUGIN_URL . 'assets/js/admin-support.js',
                ['jquery', 'vrstore-admin'],
                VRSTORE_VERSION,
                true
            );
            
            // Localize script with nonce
            wp_localize_script(
                'vrstore-admin-support',
                'vrstoreAjax',
                [
                    'ajax_url' => admin_url('admin-ajax.php'),
                    'nonce' => wp_create_nonce('vrstore_admin_nonce')
                ]
            );
        }

        // Enqueue plugin versions specific styles
        if (strpos($hook, 'vrstore-plugin-versions') !== false) {
            wp_enqueue_style(
                'vrstore-admin-plugin-versions',
                VRSTORE_PLUGIN_URL . 'assets/css/admin-plugin-versions.css',
                ['vrstore-admin'],
                VRSTORE_VERSION
            );
        }

        // Enqueue affiliate styles for affiliate admin pages
        if (strpos($hook, 'vrstore-affiliates') !== false) {
            wp_enqueue_style(
                'vrstore-affiliate-admin',
                VRSTORE_PLUGIN_URL . 'assets/css/affiliate.css',
                ['vrstore-admin'],
                VRSTORE_VERSION
            );
            
            wp_enqueue_script(
                'vrstore-affiliate-admin',
                VRSTORE_PLUGIN_URL . 'assets/js/affiliate.js',
                ['jquery', 'vrstore-admin'],
                VRSTORE_VERSION,
                true
            );
            
            // Localize script for affiliate admin functionality
            wp_localize_script(
                'vrstore-affiliate-admin',
                'vrstore_affiliate_ajax',
                [
                    'ajax_url' => admin_url('admin-ajax.php'),
                    'nonce' => wp_create_nonce('vrstore_affiliate_nonce')
                ]
            );
        }

        // For reports page, also enqueue Chart.js if needed
        if (strpos($hook, 'vrstore-reports') !== false) {
            wp_enqueue_script(
                'chartjs',
                'https://cdn.jsdelivr.net/npm/chart.js',
                [],
                '3.9.1',
                true
            );
        }

        // Localize script for AJAX
        wp_localize_script(
            'vrstore-admin',
            'vrstore_admin',
            [
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('vrstore_admin_nonce'),
                'course_reset_nonce' => wp_create_nonce('vrstore_admin_nonce'),
                'confirm_course_reset' => __('Are you sure you want to reset the selected course data? This action cannot be undone.', 'vira-store'),
                'reset_success' => __('Course data reset successfully!', 'vira-store'),
                'reset_error' => __('Failed to reset course data', 'vira-store'),
                'strings' => [
                    'confirm_delete' => __('Are you sure you want to delete this item?', 'vira-store'),
                    'error' => __('Error', 'vira-store'),
                    'success' => __('Success', 'vira-store'),
                    'loading' => __('Loading...', 'vira-store'),
                ]
            ]
        );
        
        // Also localize for admin-menu script
        wp_localize_script(
            'vrstore-admin-menu',
            'vrstore_admin_menu',
            [
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('vrstore_admin_nonce'),
            ]
        );
    }

    /**
     * Add admin menus
     *
     * @return void
     */
    public function add_admin_menus(): void {
        // Main dashboard menu
        add_menu_page(
            __('Vira Store', 'vira-store'),
            __('Vira Store', 'vira-store'),
            'manage_options',
            'vrstore-dashboard',
            [$this, 'render_dashboard_page'],
            plugin_dir_url(VRSTORE_PLUGIN_FILE) . 'assets/images/vira.png',
            30
        );

        // Dashboard submenu (same as main menu)
        add_submenu_page(
            'vrstore-dashboard',
            __('Dashboard', 'vira-store'),
            __('Dashboard', 'vira-store'),
            'manage_options',
            'vrstore-dashboard',
            [$this, 'render_dashboard_page']
        );

        // Products submenu - link to products post type
        add_submenu_page(
            'vrstore-dashboard',
            __('Products', 'vira-store'),
            __('Products', 'vira-store'),
            'manage_options',
            'edit.php?post_type=vrstore_product'
        );

        // Plugin Version Management submenu - positioned after Products
        add_submenu_page(
            'vrstore-dashboard',
            __('Plugin Versions', 'vira-store'),
            __('Versions', 'vira-store'),
            'manage_options',
            'vrstore-plugin-versions',
            [$this, 'render_plugin_versions_page']
        );

        // Licenses submenu - positioned after Products
        add_submenu_page(
            'vrstore-dashboard',
            __('Licenses', 'vira-store'),
            __('Licenses', 'vira-store'),
            'manage_options',
            'vrstore-licenses',
            [$this, 'render_licenses_page']
        );

        // Coupons submenu
        add_submenu_page(
            'vrstore-dashboard',
            __('Coupons', 'vira-store'),
            __('Coupons', 'vira-store'),
            'manage_options',
            'vrstore-coupons',
            [$this, 'render_coupons_page']
        );

        // Domain Activations submenu
        add_submenu_page(
            'vrstore-dashboard',
            __('Domain Activations', 'vira-store'),
            __('All Domain', 'vira-store'),
            'manage_options',
            'vrstore-domain-activations',
            [$this, 'render_domain_activations_page']
        );

        // Orders submenu
        add_submenu_page(
            'vrstore-dashboard',
            __('Orders', 'vira-store'),
            __('Orders', 'vira-store'),
            'manage_options',
            'vrstore-orders',
            [$this, 'render_orders_page']
        );

        // Customers submenu
        add_submenu_page(
            'vrstore-dashboard',
            __('Customers', 'vira-store'),
            __('Customers', 'vira-store'),
            'manage_options',
            'vrstore-customers',
            [$this, 'render_customers_page']
        );

        // Affiliates submenu
        add_submenu_page(
            'vrstore-dashboard',
            __('Affiliates', 'vira-store'),
            __('Affiliates', 'vira-store'),
            'manage_options',
            'vrstore-affiliates',
            [$this, 'render_affiliates_page']
        );

        // Reports submenu
        add_submenu_page(
            'vrstore-dashboard',
            __('Reports', 'vira-store'),
            __('Reports', 'vira-store'),
            'manage_options',
            'vrstore-reports',
            [$this, 'render_reports_page']
        );

        // Settings submenu
        add_submenu_page(
            'vrstore-dashboard',
            __('Settings', 'vira-store'),
            __('Settings', 'vira-store'),
            'manage_options',
            'vrstore-settings-page',
            [$this, 'render_settings_page']
        );
        
        // Database Tools submenu removed - now integrated into Settings > Tools tab
    }

    /**
     * Render dashboard page
     *
     * @return void
     */
    public function render_dashboard_page(): void {
        // Get statistics
        $stats = $this->get_dashboard_stats();
        
        // Include dashboard template
        include VRSTORE_PLUGIN_DIR . 'views/admin/dashboard.php';
    }

    /**
     * Render licenses page
     *
     * @return void
     */
    public function render_licenses_page(): void {
        // Display any pending notices (actions are processed early on admin_init)
        $this->display_license_notice();
        
        // Get licenses data
        $licenses = $this->get_licenses_data();
        
        // Include licenses template
        include VRSTORE_PLUGIN_DIR . 'views/admin/licenses.php';
    }

    /**
     * Render settings page
     *
     * @return void
     */
    public function render_settings_page(): void {
        // Redirect to the settings class method
        if (class_exists('VRSTORE_Settings')) {
            $settings = VRSTORE_Settings::get_instance();
            $settings->render_settings_page();
        }
    }

    /**
     * Render orders page
     *
     * @return void
     */
    public function render_orders_page(): void {
        // Display any pending notices (actions are processed early on admin_init)
        $this->display_order_notice();
        
        // Get orders data
        $orders = $this->get_orders_data();
        
        // Include orders template
        include VRSTORE_PLUGIN_DIR . 'views/admin/orders.php';
    }

    /**
     * Render reports page
     *
     * @return void
     */
    public function render_reports_page(): void {
        // Get reports data
        $reports = $this->get_reports_data();
        
        // Include reports template
        include VRSTORE_PLUGIN_DIR . 'views/admin/reports.php';
    }

    /**
     * Render coupons page
     *
     * @return void
     */
    public function render_coupons_page(): void {
        // Handle coupon actions
        $this->handle_coupon_actions();
        
        // Get coupons data
        $coupons = $this->get_coupons_data();
        
        // Include coupons template
        include VRSTORE_PLUGIN_DIR . 'views/admin/coupons.php';
    }

    /**
     * Render domain activations page
     *
     * @return void
     */
    public function render_domain_activations_page(): void {
        // Display any pending notices (actions are processed early on admin_init)
        $this->display_domain_notice();
        
        // Get domain activations data
        $activations = $this->get_domain_activations_data();
        
        // Include domain activations template
        include VRSTORE_PLUGIN_DIR . 'views/admin/domain-activations.php';
    }

    /**
     * Render plugin versions page
     *
     * @return void
     */
    public function render_plugin_versions_page(): void {
        // Get all products with plugin updates enabled
        $all_products = get_posts([
            'post_type' => 'vrstore_product',
            'post_status' => 'publish',
            'numberposts' => -1,
            'orderby' => 'title',
            'order' => 'ASC'
        ]);
        
        // Filter products based on Enable Plugin Updates and license generation settings
        $products = [];
        foreach ($all_products as $product) {
            $is_plugin_product = get_post_meta($product->ID, '_vrstore_is_plugin_product', true);
            $disable_license_generation = get_post_meta($product->ID, '_vrstore_disable_license_generation', true);
            
            // Only include products that have "Enable Plugin Updates" checked
            if ($is_plugin_product === '1') {
                // If "Enable Plugin Updates" is checked, include the product regardless of license generation setting
                $products[] = $product;
            }
            // Products with "Disable license generation" are excluded unless "Enable Plugin Updates" is also checked
        }
        
        // Handle form submissions
        if (isset($_POST['action']) && wp_verify_nonce($_POST['vrstore_plugin_version_nonce'] ?? '', 'vrstore_plugin_version_action')) {
            $this->handle_plugin_version_actions();
        }
        
        // Include plugin versions template
        include VRSTORE_PLUGIN_DIR . 'views/admin/plugin-versions.php';
    }

    /**
     * Render customers page
     *
     * @return void
     */
    public function render_customers_page(): void {
        // Handle customer actions
        $this->handle_customer_actions();
        
        // Get current action
        $action = sanitize_text_field($_GET['action'] ?? '');
        $customer_id = intval($_GET['customer_id'] ?? 0);
        
        // Handle different views
        switch ($action) {
            case 'view':
                $this->render_customer_detail_page($customer_id);
                break;
            case 'edit':
                $this->render_customer_edit_page($customer_id);
                break;
            case 'add':
                $this->render_customer_add_page();
                break;
            default:
                // Get customers data
                $customers = $this->get_customers_data();
                
                // Include customers template
                include VRSTORE_PLUGIN_DIR . 'views/admin/customers.php';
                break;
        }
    }

    /**
     * Get dashboard statistics
     *
     * @return array
     */
    private function get_dashboard_stats(): array {
        global $wpdb;
        
        $orders_table = $wpdb->prefix . 'vrstore_orders';
        $licenses_table = $wpdb->prefix . 'vrstore_licenses';
        
        // Check if tables exist
        $orders_exists = $wpdb->get_var("SHOW TABLES LIKE '$orders_table'") === $orders_table;
        $licenses_exists = $wpdb->get_var("SHOW TABLES LIKE '$licenses_table'") === $licenses_table;
        
        // Get settings instance
        $settings = VRSTORE_Settings::get_instance();
        $base_currency = $settings->get_setting('currency', 'USD');
        
        // Admin dashboard always uses base currency
        $current_currency = $base_currency;
        
        $stats = [
            'total_products' => wp_count_posts('vrstore_product')->publish,
            'total_orders' => 0,
            'total_sales' => 0,
            'total_licenses' => 0,
            'active_licenses' => 0,
            'pending_orders' => 0,
            'completed_orders' => 0,
            'recent_orders' => [],
            'top_products' => [],
            'total_coupons' => 0,
            'active_coupons' => 0,
            'total_domain_activations' => 0,
            'active_domain_activations' => 0
        ];

        if ($orders_exists) {
            // Total orders
            $stats['total_orders'] = $wpdb->get_var("SELECT COUNT(*) FROM $orders_table");
            
            // Total sales - use same logic as Orders page for consistency
            $total_sales_raw = $wpdb->get_var("SELECT SUM(product_price) FROM $orders_table WHERE payment_status = 'completed'") ?? 0;
            $stats['total_sales'] = $total_sales_raw; // Keep original amounts like Orders page does
            
            // Pending orders
            $stats['pending_orders'] = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $orders_table WHERE order_status = %s", 'pending'));
            
            // Completed orders
            $stats['completed_orders'] = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $orders_table WHERE order_status = %s", 'completed'));
            
            // Recent orders
            $stats['recent_orders'] = $wpdb->get_results("SELECT * FROM $orders_table ORDER BY created_at DESC LIMIT 5", ARRAY_A);
            
            // Top products - use same logic as Orders page for consistency
            $top_products_raw = $wpdb->get_results("
                SELECT product_id, product_name, COUNT(*) as order_count, SUM(product_price) as total_sales 
                FROM $orders_table 
                WHERE payment_status = 'completed' 
                GROUP BY product_id, product_name 
                ORDER BY order_count DESC 
                LIMIT 5
            ", ARRAY_A);
            
            // Keep original amounts like Orders page does
            $stats['top_products'] = array();
            foreach ($top_products_raw as $product) {
                $stats['top_products'][] = array(
                    'product_id' => $product['product_id'],
                    'product_name' => $product['product_name'],
                    'order_count' => $product['order_count'],
                    'total_sales' => $product['total_sales'] // Keep stored amounts as is
                );
            }
        }

        if ($licenses_exists) {
            // Total licenses
            $stats['total_licenses'] = $wpdb->get_var("SELECT COUNT(*) FROM $licenses_table");
            
            // Active licenses
            $stats['active_licenses'] = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $licenses_table WHERE status = %s", 'active'));
        }

        // Get coupon statistics
        if (class_exists('VRSTORE_Coupon')) {
            $coupon_class = VRSTORE_Coupon::get_instance();
            $coupon_stats = $coupon_class->get_coupon_statistics();
            
            $stats['total_coupons'] = $coupon_stats['total'] ?? 0;
            $stats['active_coupons'] = $coupon_stats['active'] ?? 0;
        }

        // Get domain activation statistics
        if (class_exists('VRSTORE_Domain_Monitor')) {
            $domain_monitor = VRSTORE_Domain_Monitor::get_instance();
            $domain_stats = $domain_monitor->get_statistics();
            
            $stats['total_domain_activations'] = $domain_stats['total_activations'] ?? 0;
            $stats['active_domain_activations'] = $domain_stats['active_activations'] ?? 0;
        }

        // Get affiliate statistics
        $affiliates_table = $wpdb->prefix . 'vrstore_affiliates';
        $affiliate_visits_table = $wpdb->prefix . 'vrstore_affiliate_visits';
        $affiliate_commissions_table = $wpdb->prefix . 'vrstore_affiliate_commissions';
        
        $affiliates_exists = $wpdb->get_var("SHOW TABLES LIKE '$affiliates_table'") === $affiliates_table;
        
        if ($affiliates_exists) {
            // Total affiliates
            $stats['total_affiliates'] = $wpdb->get_var("SELECT COUNT(*) FROM $affiliates_table");
            
            // Active affiliates
            $stats['active_affiliates'] = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $affiliates_table WHERE status = %s", 'active'));
            
            // Pending affiliates
            $stats['pending_affiliates'] = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $affiliates_table WHERE status = %s", 'pending'));
            
            // Total affiliate visits (if visits table exists)
            $visits_exists = $wpdb->get_var("SHOW TABLES LIKE '$affiliate_visits_table'") === $affiliate_visits_table;
            if ($visits_exists) {
                $stats['total_affiliate_visits'] = $wpdb->get_var("SELECT COUNT(*) FROM $affiliate_visits_table");
                $stats['affiliate_conversions'] = $wpdb->get_var("SELECT COUNT(*) FROM $affiliate_visits_table WHERE converted = 1");
            } else {
                $stats['total_affiliate_visits'] = 0;
                $stats['affiliate_conversions'] = 0;
            }
            
            // Total affiliate commissions (if commissions table exists)
            $commissions_exists = $wpdb->get_var("SHOW TABLES LIKE '$affiliate_commissions_table'") === $affiliate_commissions_table;
            if ($commissions_exists) {
                $stats['total_affiliate_commissions'] = $wpdb->get_var("SELECT SUM(commission_amount) FROM $affiliate_commissions_table WHERE status IN ('approved', 'paid')") ?? 0;
                $stats['pending_affiliate_commissions'] = $wpdb->get_var("SELECT SUM(commission_amount) FROM $affiliate_commissions_table WHERE status = 'pending'") ?? 0;
            } else {
                $stats['total_affiliate_commissions'] = 0;
                $stats['pending_affiliate_commissions'] = 0;
            }
        } else {
            $stats['total_affiliates'] = 0;
            $stats['active_affiliates'] = 0;
            $stats['pending_affiliates'] = 0;
            $stats['total_affiliate_visits'] = 0;
            $stats['affiliate_conversions'] = 0;
            $stats['total_affiliate_commissions'] = 0;
            $stats['pending_affiliate_commissions'] = 0;
        }

        // Get domain activation statistics from license_domain_activations table
        $license_domain_activations_table = $wpdb->prefix . 'vrstore_license_domain_activations';
        $domain_activations_exists = $wpdb->get_var("SHOW TABLES LIKE '$license_domain_activations_table'") === $license_domain_activations_table;
        
        if ($domain_activations_exists) {
            // Total domain activations
            $stats['total_domain_activations'] = $wpdb->get_var("SELECT COUNT(*) FROM $license_domain_activations_table");
            
            // Active domain activations
            $stats['active_domain_activations'] = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $license_domain_activations_table WHERE status = %s", 'active'));
            
            // Inactive domain activations
            $stats['inactive_domain_activations'] = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $license_domain_activations_table WHERE status = %s", 'inactive'));
            
            // Recent domain activations
            $stats['recent_domain_activations'] = $wpdb->get_results("
                SELECT lda.*, l.customer_email 
                FROM $license_domain_activations_table lda 
                LEFT JOIN $licenses_table l ON lda.license_key = l.license_key 
                ORDER BY lda.activated_at DESC 
                LIMIT 5
            ", ARRAY_A);
        } else {
            $stats['total_domain_activations'] = 0;
            $stats['active_domain_activations'] = 0;
            $stats['inactive_domain_activations'] = 0;
            $stats['recent_domain_activations'] = [];
        }

        return $stats;
    }

    /**
     * Get item type and tooltip text for dashboard display
     *
     * @param string $product_id Product ID
     * @param string $product_name Product name
     * @return array Array with 'type' and 'tooltip' keys
     */
    public function get_item_type_and_tooltip($product_id, $product_name): array {
        // Check if it's Extended Support
        if (strpos($product_id, 'extended_support') === 0) {
            return [
                'type' => 'Support',
                'tooltip' => $product_name
            ];
        }
        
        // Also check if product name contains extended support indicators
        if (stripos($product_name, 'extended support') !== false || 
            stripos($product_name, 'extended_support') !== false) {
            return [
                'type' => 'Support',
                'tooltip' => $product_name
            ];
        }
        
        // Check if it's a Course
        if (is_numeric($product_id)) {
            $post_type = get_post_type($product_id);
            if ($post_type === 'vrstore_course') {
                return [
                    'type' => 'Course',
                    'tooltip' => $product_name
                ];
            }
        }
        
        // Default to Product
        return [
            'type' => 'Product',
            'tooltip' => $product_name
        ];
    }

    /**
     * Get licenses data
     *
     * @return array
     */
    private function get_licenses_data(): array {
        global $wpdb;
        
        $licenses_table = $wpdb->prefix . 'vrstore_licenses';
        $activations_table = $wpdb->prefix . 'vrstore_license_activations';
        
        // Check if tables exist
        $licenses_exists = $wpdb->get_var("SHOW TABLES LIKE '$licenses_table'") === $licenses_table;
        
        $data = [
            'licenses' => [],
            'total' => 0,
            'active' => 0,
            'inactive' => 0,
            'expired' => 0
        ];

        if ($licenses_exists) {
            // Get licenses with pagination
            $per_page = 20;
            $page = isset($_GET['paged']) ? max(1, intval(($_GET['paged'] ?? ''))) : 1;
            $offset = ($page - 1) * $per_page;
            
            $licenses_raw = $wpdb->get_results($wpdb->prepare("
                SELECT l.*, p.post_title as product_name 
                FROM $licenses_table l 
                LEFT JOIN {$wpdb->posts} p ON l.product_id = p.ID 
                LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_vrstore_disable_license_generation'
                WHERE (pm.meta_value IS NULL OR pm.meta_value = '' OR pm.meta_value = '0')
                  AND l.product_id NOT LIKE 'extended_support_%'
                  AND l.product_id != '0'
                  AND l.product_id IS NOT NULL
                ORDER BY l.created_at DESC 
                LIMIT %d OFFSET %d
            ", $per_page, $offset), ARRAY_A);
            
            // Process licenses (Extended Support products are now excluded from queries)
            $data['licenses'] = $licenses_raw;
            
            // Get totals
            $data['total'] = $wpdb->get_var("
                SELECT COUNT(*) 
                FROM $licenses_table l 
                LEFT JOIN {$wpdb->posts} p ON l.product_id = p.ID 
                LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_vrstore_disable_license_generation'
                WHERE (pm.meta_value IS NULL OR pm.meta_value = '' OR pm.meta_value = '0')
                  AND l.product_id NOT LIKE 'extended_support_%'
                  AND l.product_id != '0'
                  AND l.product_id IS NOT NULL
            ");
            $data['active'] = $wpdb->get_var($wpdb->prepare("
                SELECT COUNT(*) 
                FROM $licenses_table l 
                LEFT JOIN {$wpdb->posts} p ON l.product_id = p.ID 
                LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_vrstore_disable_license_generation'
                WHERE l.status = %s AND (pm.meta_value IS NULL OR pm.meta_value = '' OR pm.meta_value = '0')
                  AND l.product_id NOT LIKE 'extended_support_%'
                  AND l.product_id != '0'
                  AND l.product_id IS NOT NULL
            ", 'active'));
            $data['inactive'] = $wpdb->get_var($wpdb->prepare("
                SELECT COUNT(*) 
                FROM $licenses_table l 
                LEFT JOIN {$wpdb->posts} p ON l.product_id = p.ID 
                LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_vrstore_disable_license_generation'
                WHERE l.status = %s AND (pm.meta_value IS NULL OR pm.meta_value = '' OR pm.meta_value = '0')
                  AND l.product_id NOT LIKE 'extended_support_%'
                  AND l.product_id != '0'
                  AND l.product_id IS NOT NULL
            ", 'inactive'));
            $data['expired'] = $wpdb->get_var($wpdb->prepare("
                SELECT COUNT(*) 
                FROM $licenses_table l 
                LEFT JOIN {$wpdb->posts} p ON l.product_id = p.ID 
                LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_vrstore_disable_license_generation'
                WHERE l.status = %s AND (pm.meta_value IS NULL OR pm.meta_value = '' OR pm.meta_value = '0')
                  AND l.product_id NOT LIKE 'extended_support_%'
                  AND l.product_id != '0'
                  AND l.product_id IS NOT NULL
            ", 'expired'));
        }

        return $data;
    }

    /**
     * Get orders data
     *
     * @return array
     */
    private function get_orders_data(): array {
        global $wpdb;
        
        $orders_table = $wpdb->prefix . 'vrstore_orders';
        
        // Check if tables exist
        $orders_exists = $wpdb->get_var("SHOW TABLES LIKE '$orders_table'") === $orders_table;
        
        $data = [
            'orders' => [],
            'total' => 0,
            'pending' => 0,
            'completed' => 0,
            'failed' => 0
        ];

        if ($orders_exists) {
            // Get filter parameters
            $status_filter = sanitize_text_field($_GET['status'] ?? '');
            $search_filter = sanitize_text_field($_GET['search'] ?? '');
            
            // Build WHERE clause
            $where_conditions = [];
            $where_params = [];
            
            if (!empty($status_filter)) {
                $where_conditions[] = 'order_status = %s';
                $where_params[] = $status_filter;
            }
            
            if (!empty($search_filter)) {
                $where_conditions[] = '(order_number LIKE %s OR customer_email LIKE %s OR product_name LIKE %s)';
                $search_term = '%' . $wpdb->esc_like($search_filter) . '%';
                $where_params[] = $search_term;
                $where_params[] = $search_term;
                $where_params[] = $search_term;
            }
            
            $where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';
            
            // Get orders with pagination and filters
            $per_page = 20;
            $page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
            $offset = ($page - 1) * $per_page;
            
            $query = "SELECT * FROM $orders_table $where_clause ORDER BY created_at DESC LIMIT %d OFFSET %d";
            $query_params = array_merge($where_params, [$per_page, $offset]);
            
            if (!empty($where_params)) {
                // Ensure all query parameters are scalar to prevent wpdb->prepare array error
                $safe_query_params = [];
                foreach ($query_params as $param) {
                    if (is_scalar($param)) {
                        $safe_query_params[] = $param;
                    } else {
                        // Convert non-scalar values to strings or handle appropriately
                        $safe_query_params[] = is_null($param) ? '' : (string) $param;
                    }
                }
                
                // Use spread operator to safely pass array parameters as individual arguments
                $prepared_query = $wpdb->prepare($query, ...$safe_query_params);
                $data['orders'] = $wpdb->get_results($prepared_query, ARRAY_A);
            } else {
                $data['orders'] = $wpdb->get_results($wpdb->prepare(
                    "SELECT * FROM $orders_table ORDER BY created_at DESC LIMIT %d OFFSET %d",
                    $per_page, $offset
                ), ARRAY_A);
            }
            
            // Handle Extended Support product names
            foreach ($data['orders'] as &$order) {
                if (is_string($order['product_id']) && strpos($order['product_id'], 'extended_support_') === 0) {
                    // Extract actual product ID from extended support string
                    $parts = explode('_', $order['product_id']);
                    if (count($parts) >= 3) {
                        $actual_product_id = intval($parts[2]);
                        $license_type = $order['license_type_label'] ?: ($order['license_type'] ?: 'Standard');
                        
                        // Get license type configuration to determine months
                        $months = 12; // Default Extended Support duration
                        if (!empty($order['license_type'])) {
                            $settings = get_option('vrstore_settings', []);
                            $custom_license_types = $settings['custom_license_types'] ?? [];
                            foreach ($custom_license_types as $type) {
                                if ($type['slug'] === $order['license_type'] && !empty($type['expiry_days'])) {
                                    $months = max(1, round($type['expiry_days'] / 30));
                                    break;
                                }
                            }
                        }
                        
                        // Get the actual product title to create better description
                        $product_title = '';
                        if ($actual_product_id > 0) {
                            $product_post = get_post($actual_product_id);
                            if ($product_post && $product_post->post_title) {
                                $product_title = $product_post->post_title;
                            }
                        }
                        
                        if ($product_title) {
                            $order['product_name'] = sprintf('%s - Extended Support (%s / %d months)', $product_title, $license_type, $months);
                        } else {
                            $order['product_name'] = sprintf('Extended Support (%s / %d months)', $license_type, $months);
                        }
                    } else {
                        $order['product_name'] = 'Extended Support';
                    }
                }
            }
            unset($order); // Break reference
            
            // Get totals (always get all totals regardless of filters)
            $data['total'] = $wpdb->get_var("SELECT COUNT(*) FROM $orders_table");
            $data['pending'] = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $orders_table WHERE order_status = %s", 'pending'));
            $data['completed'] = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $orders_table WHERE order_status = %s", 'completed'));
            $data['failed'] = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $orders_table WHERE order_status = %s", 'failed'));
        }

        return $data;
    }
    
    /**
     * Convert price from order currency to base currency for admin reporting
     * 
     * Admin reports should ALWAYS show amounts in base currency for consistency,
     * regardless of whether user-facing currency conversion is enabled.
     *
     * @param float $price Price to convert
     * @param string $from_currency Source currency
     * @param string $base_currency Target base currency
     * @return float Converted price
     */
    private function convert_price_to_base_currency($price, $from_currency, $base_currency) {
        // If currencies are the same, no conversion needed
        if ($from_currency === $base_currency) {
            return $price;
        }
        
        // For admin reports, we ALWAYS attempt conversion to base currency
        // regardless of the user-facing currency conversion setting
        
        // Get currency converter instance
        if (!class_exists('VRSTORE_Currency_Converter')) {
            // If converter not available, we can't convert so return original price
            // This maintains existing behavior for installations without currency conversion
            return $price;
        }
        
        $currency_converter = VRSTORE_Currency_Converter::get_instance();
        
        try {
            // For admin reports, we need to bypass the currency conversion enabled check
            // and directly get exchange rate and convert the amount
            
            // Get exchange rate directly (bypasses the enabled check in convert_amount)
            $reflection = new ReflectionClass($currency_converter);
            $get_rate_method = $reflection->getMethod('get_exchange_rate');
            $get_rate_method->setAccessible(true);
            
            $rate = $get_rate_method->invoke($currency_converter, $from_currency, $base_currency);
            $converted_price = round($price * $rate, 2);
            
            return $converted_price;
        } catch (Exception $e) {
            // If conversion fails, return original price
            // This handles cases where exchange rates aren't available
            return $price;
        }
    }

    /**
     * Get reports data
     *
     * @return array
     */
    private function get_reports_data(): array {
        global $wpdb;
        
        $orders_table = $wpdb->prefix . 'vrstore_orders';
        
        // Check if table exists
        $orders_exists = $wpdb->get_var("SHOW TABLES LIKE '$orders_table'") === $orders_table;
        
        // Get settings instance 
        $settings = VRSTORE_Settings::get_instance();
        // For admin reports, keep stored amounts as-is like the Orders page does
        $base_currency = $settings->get_setting('currency', 'USD');
        
        $data = [
            'daily_sales' => [],
            'monthly_sales' => [],
            'top_products' => [],
            'payment_methods' => [],
            'license_types' => [],
            'affiliate_data' => []
        ];

        if ($orders_exists) {
            // Get date range from URL parameters
            $date_from = sanitize_text_field($_GET['date_from'] ?? '');
            $date_to = sanitize_text_field($_GET['date_to'] ?? '');
            
            // Default to last 30 days if no date range specified
            if (empty($date_from) || empty($date_to)) {
                $date_from = date('Y-m-d', strtotime('-30 days'));
                $date_to = date('Y-m-d');
            }
            
            // Build date filter conditions
            $date_where = $wpdb->prepare(
                "AND DATE(created_at) >= %s AND DATE(created_at) <= %s",
                $date_from,
                $date_to
            );
            
            // Daily sales with date filtering - get individual orders for proper currency conversion
            $daily_sales_raw = $wpdb->get_results($wpdb->prepare(
                "SELECT DATE(created_at) as date, product_price, currency
                FROM $orders_table 
                WHERE payment_status = 'completed' 
                AND DATE(created_at) >= %s AND DATE(created_at) <= %s
                ORDER BY created_at DESC",
                $date_from,
                $date_to
            ), ARRAY_A);
            
            // Process daily sales and convert currencies to base currency for accurate aggregation
            $data['daily_sales'] = array();
            $daily_totals = array();
            
            foreach ($daily_sales_raw as $order) {
                $date = $order['date'];
                $price = floatval($order['product_price']);
                $order_currency = $order['currency'] ?? $base_currency;
                
                // Convert to base currency if needed
                $converted_price = $this->convert_price_to_base_currency($price, $order_currency, $base_currency);
                
                if (!isset($daily_totals[$date])) {
                    $daily_totals[$date] = ['orders' => 0, 'sales' => 0];
                }
                $daily_totals[$date]['orders']++;
                $daily_totals[$date]['sales'] += $converted_price;
            }
            
            foreach ($daily_totals as $date => $totals) {
                $data['daily_sales'][] = array(
                    'date' => $date,
                    'orders' => $totals['orders'],
                    'sales' => $totals['sales'] // Now properly converted to base currency
                );
            }
            
            // Monthly sales (last 12 months) - use same logic as Orders page for consistency
            $monthly_sales_raw = $wpdb->get_results("
                SELECT DATE_FORMAT(created_at, '%Y-%m') as month, COUNT(*) as orders, SUM(product_price) as sales 
                FROM $orders_table 
                WHERE payment_status = 'completed' 
                AND created_at >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
                GROUP BY DATE_FORMAT(created_at, '%Y-%m') 
                ORDER BY month DESC
            ", ARRAY_A);
            
            // Keep original amounts like Orders page does
            $data['monthly_sales'] = array();
            foreach ($monthly_sales_raw as $month) {
                $data['monthly_sales'][] = array(
                    'month' => $month['month'],
                    'orders' => $month['orders'],
                    'sales' => $month['sales'] // Keep stored amounts as is
                );
            }
            
            // Top products with date filtering - get individual orders for proper currency conversion
            $top_products_orders = $wpdb->get_results($wpdb->prepare(
                "SELECT product_id, product_name, product_price, currency
                FROM $orders_table 
                WHERE payment_status = 'completed' 
                AND DATE(created_at) >= %s AND DATE(created_at) <= %s
                ORDER BY created_at DESC",
                $date_from,
                $date_to
            ), ARRAY_A);
            
            // Aggregate by product with currency conversion
            $top_products_aggregated = [];
            foreach ($top_products_orders as $order) {
                $product_key = $order['product_id'] . '|' . $order['product_name'];
                $price = floatval($order['product_price']);
                $order_currency = $order['currency'] ?? $base_currency;
                
                // Convert to base currency
                $converted_price = $this->convert_price_to_base_currency($price, $order_currency, $base_currency);
                
                if (!isset($top_products_aggregated[$product_key])) {
                    $top_products_aggregated[$product_key] = [
                        'product_id' => $order['product_id'],
                        'product_name' => $order['product_name'],
                        'order_count' => 0,
                        'total_sales' => 0
                    ];
                }
                
                $top_products_aggregated[$product_key]['order_count']++;
                $top_products_aggregated[$product_key]['total_sales'] += $converted_price;
            }
            
            // Sort by order count and limit to top 10
            uasort($top_products_aggregated, function($a, $b) {
                return $b['order_count'] - $a['order_count'];
            });
            $top_products_raw = array_slice($top_products_aggregated, 0, 10);
            
            // Process product names to handle Extended Support products
            $data['top_products'] = array();
            foreach ($top_products_raw as $product) {
                $product_name = $product['product_name'];
                
                // Handle Extended Support products
                if (is_string($product['product_id']) && strpos($product['product_id'], 'extended_support_') === 0) {
                    // Extract the actual product ID from the extended support string
                    $parts = explode('_', $product['product_id']);
                    if (count($parts) >= 3) {
                        $actual_product_id = intval($parts[2]);
                        
                        // Get the license type from associated orders
                        $license_type = 'Standard'; // Default
                        $months = 12; // Default Extended Support duration
                        
                        // Try to get license type from an order with this Extended Support product
                        $sample_order = $wpdb->get_row($wpdb->prepare(
                            "SELECT license_type, license_type_label FROM $orders_table WHERE product_id = %s LIMIT 1",
                            $product['product_id']
                        ), ARRAY_A);
                        
                        if ($sample_order && !empty($sample_order['license_type_label'])) {
                            $license_type = $sample_order['license_type_label'];
                        } elseif ($sample_order && !empty($sample_order['license_type'])) {
                            $license_type = ucfirst(str_replace('-', ' ', $sample_order['license_type']));
                            
                            // Get months from license type configuration
                            $settings = get_option('vrstore_settings', []);
                            $custom_license_types = $settings['custom_license_types'] ?? [];
                            foreach ($custom_license_types as $type) {
                                if ($type['slug'] === $sample_order['license_type'] && !empty($type['expiry_days'])) {
                                    $months = max(1, round($type['expiry_days'] / 30));
                                    break;
                                }
                            }
                        }
                        
                        // Get the actual product title to create better description
                        $associated_product_title = '';
                        if ($actual_product_id > 0) {
                            $product_post = get_post($actual_product_id);
                            if ($product_post && $product_post->post_title) {
                                $associated_product_title = $product_post->post_title;
                            }
                        }
                        
                        if ($associated_product_title) {
                            $product_name = sprintf('%s - Extended Support (%s / %d months)', $associated_product_title, $license_type, $months);
                        } else {
                            $product_name = sprintf('Extended Support (%s / %d months)', $license_type, $months);
                        }
                    } else {
                        $product_name = 'Extended Support';
                    }
                }
                
                $data['top_products'][] = array(
                    'product_name' => $product_name,
                    'order_count' => $product['order_count'],
                    'total_sales' => $product['total_sales'] // Keep stored amounts as is
                );
            }
            
            // Payment methods with date filtering - get individual orders for proper currency conversion
            $payment_methods_orders = $wpdb->get_results($wpdb->prepare(
                "SELECT payment_method, product_price, currency
                FROM $orders_table 
                WHERE payment_status = 'completed' 
                AND DATE(created_at) >= %s AND DATE(created_at) <= %s
                ORDER BY created_at DESC",
                $date_from,
                $date_to
            ), ARRAY_A);
            
            // Aggregate by payment method with currency conversion
            $payment_methods_aggregated = [];
            foreach ($payment_methods_orders as $order) {
                $method = $order['payment_method'];
                $price = floatval($order['product_price']);
                $order_currency = $order['currency'] ?? $base_currency;
                
                // Convert to base currency
                $converted_price = $this->convert_price_to_base_currency($price, $order_currency, $base_currency);
                
                if (!isset($payment_methods_aggregated[$method])) {
                    $payment_methods_aggregated[$method] = [
                        'payment_method' => $method,
                        'count' => 0,
                        'total' => 0
                    ];
                }
                
                $payment_methods_aggregated[$method]['count']++;
                $payment_methods_aggregated[$method]['total'] += $converted_price;
            }
            
            // Sort by count descending
            uasort($payment_methods_aggregated, function($a, $b) {
                return $b['count'] - $a['count'];
            });
            
            $data['payment_methods'] = array_values($payment_methods_aggregated);
            
            // License type statistics - get from licenses table if available
            $licenses_table = $wpdb->prefix . 'vrstore_licenses';
            $licenses_exists = $wpdb->get_var("SHOW TABLES LIKE '$licenses_table'") === $licenses_table;
            
            if ($licenses_exists) {
                // Get individual license orders for proper currency conversion
                $license_orders = $wpdb->get_results("
                    SELECT 
                        l.license_type_slug,
                        o.product_price,
                        o.currency
                    FROM $orders_table o
                    LEFT JOIN $licenses_table l ON o.id = l.order_id
                    WHERE o.payment_status = 'completed' AND l.license_type_slug IS NOT NULL
                ", ARRAY_A);
                
                // Aggregate by license type with currency conversion
                $license_types_raw = [];
                foreach ($license_orders as $order) {
                    $slug = $order['license_type_slug'];
                    $price = floatval($order['product_price']);
                    $order_currency = $order['currency'] ?? $base_currency;
                    
                    // Convert to base currency
                    $converted_price = $this->convert_price_to_base_currency($price, $order_currency, $base_currency);
                    
                    if (!isset($license_types_raw[$slug])) {
                        $license_types_raw[$slug] = [
                            'license_type_slug' => $slug,
                            'order_count' => 0,
                            'total_revenue' => 0
                        ];
                    }
                    
                    $license_types_raw[$slug]['order_count']++;
                    $license_types_raw[$slug]['total_revenue'] += $converted_price;
                }
                
                // Sort by total revenue descending
                uasort($license_types_raw, function($a, $b) {
                    return $b['total_revenue'] <=> $a['total_revenue'];
                });
                
                $license_types_raw = array_values($license_types_raw);
                
                // Convert license type slugs to proper labels from settings
                $vrstore_settings = get_option('vrstore_settings', array());
                $custom_license_types = isset($vrstore_settings['custom_license_types']) && is_array($vrstore_settings['custom_license_types']) ? $vrstore_settings['custom_license_types'] : array();
                
                $data['license_types'] = array();
                foreach ($license_types_raw as $license_type) {
                    $slug = $license_type['license_type_slug'];
                    $label = ucfirst(str_replace('_', ' ', $slug)); // Default label
                    
                    // Find the proper label from custom license types
                    foreach ($custom_license_types as $type) {
                        if (($type['slug'] ?? '') === $slug) {
                            $label = $type['label'] ?? $label;
                            break;
                        }
                    }
                    
                    // Skip empty license types
                    if (empty($slug)) {
                        continue;
                    }
                    
                    $data['license_types'][] = array(
                        'license_type_label' => $label,
                        'order_count' => $license_type['order_count'],
                        'total_revenue' => $license_type['total_revenue'] // Keep stored amounts as is
                    );
                }
            } else {
                // Fallback when licenses table doesn't exist - get individual orders for currency conversion
                $fallback_orders = $wpdb->get_results(
                    "SELECT product_price, currency FROM $orders_table WHERE payment_status = 'completed'",
                    ARRAY_A
                );
                
                $total_revenue_converted = 0;
                foreach ($fallback_orders as $order) {
                    $price = floatval($order['product_price']);
                    $order_currency = $order['currency'] ?? $base_currency;
                    
                    // Convert to base currency
                    $converted_price = $this->convert_price_to_base_currency($price, $order_currency, $base_currency);
                    $total_revenue_converted += $converted_price;
                }
                
                $data['license_types'] = [[
                    'license_type_label' => 'Custom License',
                    'order_count' => count($fallback_orders),
                    'total_revenue' => $total_revenue_converted
                ]];
            }
        }
        
        // Get affiliate data
        $data['affiliate_data'] = $this->get_affiliate_reports_data($date_from ?? '', $date_to ?? '');

        return $data;
    }
    
    /**
     * Get affiliate reports data
     *
     * @param string $date_from
     * @param string $date_to
     * @return array
     */
    private function get_affiliate_reports_data(string $date_from = '', string $date_to = ''): array {
        global $wpdb;
        
        // Check if affiliate tables exist
        $affiliates_table = $wpdb->prefix . 'vrstore_affiliates';
        $commissions_table = $wpdb->prefix . 'vrstore_affiliate_commissions';
        $visits_table = $wpdb->prefix . 'vrstore_affiliate_visits';
        
        $tables_exist = $wpdb->get_var("SHOW TABLES LIKE '$affiliates_table'") === $affiliates_table &&
                       $wpdb->get_var("SHOW TABLES LIKE '$commissions_table'") === $commissions_table &&
                       $wpdb->get_var("SHOW TABLES LIKE '$visits_table'") === $visits_table;
                       
        if (!$tables_exist) {
            return [
                'total_affiliates' => 0,
                'active_affiliates' => 0,
                'total_commissions' => 0,
                'total_visits' => 0,
                'conversion_rate' => 0,
                'top_affiliates' => [],
                'commission_trends' => [],
                'recent_signups' => []
            ];
        }
        
        // Get settings for base currency formatting
        $settings = VRSTORE_Settings::get_instance();
        $base_currency = $settings->get_setting('currency', 'USD');
        
        // Set date range if not provided
        if (empty($date_from) || empty($date_to)) {
            $date_from = date('Y-m-d', strtotime('-30 days'));
            $date_to = date('Y-m-d');
        }
        
        // Build date conditions for commissions and visits
        $commission_date_where = $wpdb->prepare(
            "AND DATE(c.created_at) >= %s AND DATE(c.created_at) <= %s",
            $date_from,
            $date_to
        );
        
        $visit_date_where = $wpdb->prepare(
            "AND DATE(v.created_at) >= %s AND DATE(v.created_at) <= %s",
            $date_from,
            $date_to
        );
        
        // Get basic affiliate statistics
        $total_affiliates = $wpdb->get_var("SELECT COUNT(*) FROM $affiliates_table");
        $active_affiliates = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $affiliates_table WHERE status = %s",
            'active'
        ));
        
        // Get total commissions (all-time, stored in base currency)
        $total_commissions = $wpdb->get_var(
            "SELECT SUM(commission_amount) FROM $commissions_table WHERE status IN ('approved', 'paid')"
        ) ?: 0;
        
        // Get total visits in date range
        $total_visits = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $visits_table WHERE DATE(created_at) >= %s AND DATE(created_at) <= %s",
            $date_from,
            $date_to
        )) ?: 0;
        
        // Get conversions in date range
        $total_conversions = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $visits_table WHERE converted = 1 AND DATE(created_at) >= %s AND DATE(created_at) <= %s",
            $date_from,
            $date_to
        )) ?: 0;
        
        $conversion_rate = $total_visits > 0 ? ($total_conversions / $total_visits) * 100 : 0;
        
        // Get top affiliates by total commissions
        $top_affiliates = $wpdb->get_results(
            "SELECT a.id, a.name, a.email, a.affiliate_code,
                    SUM(c.commission_amount) as total_earnings,
                    COUNT(c.id) as total_commissions,
                    a.total_visits
             FROM $affiliates_table a
             LEFT JOIN $commissions_table c ON a.id = c.affiliate_id
             WHERE a.status = 'active'
             GROUP BY a.id
             ORDER BY total_earnings DESC
             LIMIT 10",
            ARRAY_A
        );
        
        // Get commission trends (daily for the selected period)
        $commission_trends = $wpdb->get_results($wpdb->prepare(
            "SELECT DATE(created_at) as date,
                    COUNT(*) as commission_count,
                    SUM(commission_amount) as commission_total
             FROM $commissions_table
             WHERE DATE(created_at) >= %s AND DATE(created_at) <= %s
             GROUP BY DATE(created_at)
             ORDER BY date ASC",
            $date_from,
            $date_to
        ), ARRAY_A);
        
        // Get recent affiliate signups (last 30 days)
        $recent_signups = $wpdb->get_results($wpdb->prepare(
            "SELECT id, name, email, affiliate_code, status, created_at
             FROM $affiliates_table
             WHERE DATE(created_at) >= %s
             ORDER BY created_at DESC
             LIMIT 10",
            date('Y-m-d', strtotime('-30 days'))
        ), ARRAY_A);
        
        return [
            'total_affiliates' => intval($total_affiliates),
            'active_affiliates' => intval($active_affiliates),
            'total_commissions' => floatval($total_commissions),
            'total_visits' => intval($total_visits),
            'total_conversions' => intval($total_conversions),
            'conversion_rate' => round($conversion_rate, 2),
            'top_affiliates' => $top_affiliates ?: [],
            'commission_trends' => $commission_trends ?: [],
            'recent_signups' => $recent_signups ?: []
        ];
    }

    /**
     * Handle license actions
     *
     * @return void
     */
    private function handle_license_actions(): void {
        if (!isset($_REQUEST['action']) || !isset($_REQUEST['license_id'])) {
            return;
        }

        $action = sanitize_text_field(($_REQUEST['action'] ?? ''));
        $license_id = intval(($_REQUEST['license_id'] ?? ''));

        // Verify nonce
        if (!wp_verify_nonce($_REQUEST['_wpnonce'] ?? '', 'vrstore_license_action')) {
            wp_die(__('Security check failed.', 'vira-store'));
        }

        global $wpdb;
        $licenses_table = $wpdb->prefix . 'vrstore_licenses';

        switch ($action) {
            case 'activate':
                $wpdb->update(
                    $licenses_table,
                    ['status' => 'active'],
                    ['id' => $license_id],
                    ['%s'],
                    ['%d']
                );
                break;

            case 'deactivate':
                $wpdb->update(
                    $licenses_table,
                    ['status' => 'inactive'],
                    ['id' => $license_id],
                    ['%s'],
                    ['%d']
                );
                break;

            case 'delete':
                $wpdb->delete(
                    $licenses_table,
                    ['id' => $license_id],
                    ['%d']
                );
                break;
        }

        // Redirect to avoid resubmission
        wp_redirect(remove_query_arg(['action', 'license_id', '_wpnonce']));
        exit;
    }


    /**
     * AJAX handler for generating license
     *
     * @return void
     */
    public function ajax_generate_license(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_admin_nonce')) {
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
        }

        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'vira-store')]);
        }

        // Get form data
        $product_id = intval($_POST['product_id'] ?? 0);
        $customer_email = sanitize_email($_POST['customer_email'] ?? '');
        $license_type_slug = sanitize_text_field($_POST['license_type'] ?? '');

        // Validate required fields
        if (empty($customer_email)) {
            wp_send_json_error(['message' => __('Customer email is required.', 'vira-store')]);
        }

        if (!is_email($customer_email)) {
            wp_send_json_error(['message' => __('Invalid email address.', 'vira-store')]);
        }

        // Generate license using License class
        if (class_exists('VRSTORE_License')) {
            $license_class = VRSTORE_License::get_instance();
            
            // Generate license key
            $license_key = $license_class->generate_license_key();
            
            // Get license type configuration
            $license_config = $license_class->get_license_type_config($product_id, $license_type_slug);
            
            // Prepare license data with automatic configuration
            $license_data = [
                'license_key' => $license_key,
                'product_id' => $product_id,
                'customer_email' => $customer_email,
                'activation_limit' => $license_config['activation_limit'] ?? 1,
                'status' => 'active',
                'license_type_slug' => $license_type_slug
            ];
            
            // Add expiry date based on license type configuration
            if (isset($license_config['expiry_days']) && $license_config['expiry_days'] > 0) {
                $expiry_date = new DateTime();
                $expiry_date->add(new DateInterval('P' . $license_config['expiry_days'] . 'D'));
                $license_data['expires_at'] = $expiry_date->format('Y-m-d H:i:s');
            }
            
            // Create license
            $license_id = $license_class->create_license($license_data);
            
            if ($license_id) {
                wp_send_json_success([
                    'message' => __('License generated successfully!', 'vira-store'),
                    'license_key' => $license_key,
                    'license_id' => $license_id
                ]);
            } else {
                // Get more detailed error information
                global $wpdb;
                $last_error = $wpdb->last_error;
                $error_message = __('Failed to create license. Please try again.', 'vira-store');
                
                if (!empty($last_error)) {
                    $error_message .= ' Database error: ' . $last_error;
                }
                
                // Check if table exists
                $licenses_table = $wpdb->prefix . 'vrstore_licenses';
                $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$licenses_table'") === $licenses_table;
                if (!$table_exists) {
                    $error_message .= ' The licenses table does not exist. Please repair the database.';
                }
                
                wp_send_json_error(['message' => $error_message]);
            }
        } else {
            wp_send_json_error(['message' => __('License class not available.', 'vira-store')]);
        }
    }

    /**
     * AJAX handler for getting license type configuration
     *
     * @return void
     */
    public function ajax_get_license_type_config(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_admin_nonce')) {
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
        }

        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'vira-store')]);
        }

        // Get form data
        $product_id = intval($_POST['product_id'] ?? 0);
        $license_type_slug = sanitize_text_field($_POST['license_type'] ?? '');

        if (empty($license_type_slug)) {
            wp_send_json_error(['message' => __('License type is required.', 'vira-store')]);
        }

        // Get license type configuration
        if (class_exists('VRSTORE_License')) {
            $license_class = VRSTORE_License::get_instance();
            $config = $license_class->get_license_type_config($product_id, $license_type_slug);
            
            // Format the response
            $response_data = [
                'activation_limit' => $config['activation_limit'] ?? 1,
                'expiry_days' => $config['expiry_days'] ?? 0
            ];
            
            // Calculate expiry date if expiry_days is set
            if (isset($config['expiry_days']) && $config['expiry_days'] > 0) {
                $expiry_date = new DateTime();
                $expiry_date->add(new DateInterval('P' . $config['expiry_days'] . 'D'));
                $response_data['expiry_date'] = $expiry_date->format('M j, Y');
            } elseif (isset($config['expiry_days']) && $config['expiry_days'] === -1) {
                $response_data['expiry_date'] = 'Never expires';
            }
            
            wp_send_json_success($response_data);
        } else {
            wp_send_json_error(['message' => __('License class not available.', 'vira-store')]);
        }
    }

    /**
     * AJAX handler for getting license details
     *
     * @return void
     */
    public function ajax_get_license_details(): void {
        try {
            // Verify nonce
            if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_admin_nonce')) {
                wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
            }

            // Check user capabilities
            if (!current_user_can('manage_options')) {
                wp_send_json_error(['message' => __('Permission denied.', 'vira-store')]);
            }

            $license_id = intval($_POST['license_id'] ?? 0);
            
            if (!$license_id) {
                wp_send_json_error(['message' => __('Invalid license ID.', 'vira-store')]);
            }

            global $wpdb;
            $licenses_table = $wpdb->prefix . 'vrstore_licenses';
            $activations_table = $wpdb->prefix . 'vrstore_license_activations';
            
            // Check if tables exist
            $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$licenses_table'");
            if (!$table_exists) {
                wp_send_json_error(['message' => __('Database tables not found. Please deactivate and reactivate the plugin.', 'vira-store')]);
            }
            
            // Get license details
            $license = $wpdb->get_row($wpdb->prepare(
                "SELECT l.*, p.post_title as product_name FROM $licenses_table l 
                 LEFT JOIN {$wpdb->posts} p ON l.product_id = p.ID 
                 WHERE l.id = %d",
                $license_id
            ), ARRAY_A);
            
            // Check for database errors
            if ($wpdb->last_error) {
                wp_send_json_error(['message' => __('Database error occurred. Please check the error logs.', 'vira-store')]);
            }
            
            if (!$license) {
                wp_send_json_error(['message' => __('License not found.', 'vira-store')]);
            }
        
        // Get license activations - check if table exists first
        $activations = [];
        $activations_table_exists = $wpdb->get_var("SHOW TABLES LIKE '$activations_table'") === $activations_table;
        if ($activations_table_exists) {
            // Check which date column exists in the table
            // Use SHOW COLUMNS to get all columns
            $all_columns = $wpdb->get_col("SHOW COLUMNS FROM $activations_table");
            
            // Determine which column to use - prefer activated_at (new schema)
            $date_column = null;
            if (in_array('activated_at', $all_columns, true)) {
                $date_column = 'activated_at';
            } elseif (in_array('activation_date', $all_columns, true)) {
                $date_column = 'activation_date';
            }
            
            // Build query with appropriate column or no ordering
            if ($date_column && in_array($date_column, ['activated_at', 'activation_date'], true)) {
                // Safely use the validated column name (already whitelisted)
                // Note: Column names cannot be used in prepare(), so we validate first
                $date_column_escaped = '`' . str_replace('`', '', $date_column) . '`';
                $query = $wpdb->prepare(
                    "SELECT * FROM {$activations_table} WHERE license_id = %d ORDER BY {$date_column_escaped} DESC",
                    $license_id
                );
                $activations = $wpdb->get_results($query, ARRAY_A);
            } else {
                // No date column found, query without ordering
                $activations = $wpdb->get_results($wpdb->prepare(
                    "SELECT * FROM {$activations_table} WHERE license_id = %d",
                    $license_id
                ), ARRAY_A);
            }
            
            // Check for database errors in activations query
            if ($wpdb->last_error) {
                error_log('ViraStore: Error loading activations: ' . $wpdb->last_error);
                wp_send_json_error(['message' => __('Database error occurred while loading activations.', 'vira-store')]);
            }
        }
        
        // Get order information if available
        $order_info = null;
        if (!empty($license['order_id'])) {
            $orders_table = $wpdb->prefix . 'vrstore_orders';
            $orders_table_exists = $wpdb->get_var("SHOW TABLES LIKE '$orders_table'") === $orders_table;
            if ($orders_table_exists) {
                $order_info = $wpdb->get_row($wpdb->prepare(
                    "SELECT order_number, order_date, total_amount, order_status, payment_status FROM $orders_table WHERE id = %d",
                    $license['order_id']
                ), ARRAY_A);
            }
        }
        
        // Get customer information
        $customer_info = null;
        if (!empty($license['customer_email'])) {
            $user = get_user_by('email', $license['customer_email']);
            if ($user) {
                $customer_info = [
                    'id' => $user->ID,
                    'name' => $user->display_name,
                    'email' => $user->user_email,
                    'role' => !empty($user->roles) ? ucfirst($user->roles[0]) : __('None', 'vira-store')
                ];
            }
        }
        
        // Build HTML response with enhanced details
        $html = '<div class="license-details" style="max-width: 100%; overflow-x: auto;">';
        
        // Main License Information Section
        $html .= '<h3 style="margin-top: 0; padding-bottom: 10px; border-bottom: 2px solid #ddd;">' . __('License Information', 'vira-store') . '</h3>';
        $html .= '<table class="wp-list-table widefat" style="margin-bottom: 20px;">';
        $html .= '<tr><th style="width: 200px;">' . $this->get_translated_text('License Key') . '</th><td><code style="font-size: 14px; padding: 5px 10px; background: #f5f5f5; border: 1px solid #ddd; border-radius: 3px;">' . esc_html($license['license_key'] ?? "") . '</code></td></tr>';
        
        // Product Information
        $product_link = '';
        if (!empty($license['product_id'])) {
            $product_link = ' <a href="' . get_edit_post_link($license['product_id']) . '" target="_blank" style="margin-left: 10px;">(' . __('Edit Product', 'vira-store') . ')</a>';
        }
        $html .= '<tr><th>' . $this->get_translated_text('Product') . '</th><td><strong>' . esc_html($license['product_name'] ?: $this->get_translated_text('Unknown')) . '</strong>' . $product_link . '</td></tr>';
        
        // License Type
        $license_type_slug = $license['license_type_slug'] ?? '';
        if (!empty($license_type_slug)) {
            $settings = get_option('vrstore_settings', array());
            $custom_license_types = isset($settings['custom_license_types']) && is_array($settings['custom_license_types']) ? $settings['custom_license_types'] : array();
            
            $license_type_label = ucfirst(str_replace('_', ' ', $license_type_slug));
            
            foreach ($custom_license_types as $type) {
                if (($type['slug'] ?? '') === $license_type_slug) {
                    $license_type_label = $type['label'] ?? $license_type_label;
                    break;
                }
            }
            
            $html .= '<tr><th>' . $this->get_translated_text('License Type') . '</th><td><span class="license-type-badge license-type-' . esc_attr($license_type_slug) . '" style="padding: 4px 8px; border-radius: 3px; background: #2271b1; color: #fff; font-size: 12px;">' . esc_html($license_type_label) . '</span></td></tr>';
        } else {
            $html .= '<tr><th>' . $this->get_translated_text('License Type') . '</th><td><span class="license-type-badge license-type-custom" style="padding: 4px 8px; border-radius: 3px; background: #666; color: #fff; font-size: 12px;">Custom License</span></td></tr>';
        }
        
        // Status
        $status_class = 'license-status-' . esc_attr($license['status'] ?? "");
        $status_color = '#666';
        if ($license['status'] === 'active') {
            $status_color = '#00a32a';
        } elseif ($license['status'] === 'expired' || $license['status'] === 'inactive') {
            $status_color = '#d63638';
        }
        $html .= '<tr><th>' . $this->get_translated_text('Status') . '</th><td><span class="license-status ' . $status_class . '" style="padding: 4px 8px; border-radius: 3px; background: ' . $status_color . '; color: #fff; font-size: 12px; font-weight: 500;">' . esc_html(ucfirst($license['status'] ?? "")) . '</span></td></tr>';
        
        // Activation Limit/Count
        $activation_text = esc_html($license['activation_count'] ?? 0) . ' / ' . ($license['activation_limit'] > 0 ? esc_html($license['activation_limit'] ?? "") : $this->get_translated_text('Unlimited'));
        $html .= '<tr><th>' . $this->get_translated_text('Activations') . '</th><td><strong>' . $activation_text . '</strong></td></tr>';
        
        // Customer Email
        $customer_display = esc_html($license['customer_email'] ?? "");
        if ($customer_info) {
            $customer_display .= ' <span style="color: #666; margin-left: 10px;">(' . esc_html($customer_info['name']) . ' - ' . esc_html($customer_info['role']) . ')</span>';
            $customer_display .= ' <a href="' . admin_url('user-edit.php?user_id=' . $customer_info['id']) . '" target="_blank" style="margin-left: 10px;">(' . __('Edit User', 'vira-store') . ')</a>';
        }
        $html .= '<tr><th>' . $this->get_translated_text('Customer Email') . '</th><td>' . $customer_display . '</td></tr>';
        
        // Dates
        $created_date = !empty($license['created_at']) ? mysql2date('F j, Y \a\t g:i A', $license['created_at']) : __('Unknown', 'vira-store');
        $html .= '<tr><th>' . __('Created', 'vira-store') . '</th><td>' . esc_html($created_date) . '</td></tr>';
        
        // Last Updated
        $updated_date = !empty($license['updated_at']) ? mysql2date('F j, Y \a\t g:i A', $license['updated_at']) : __('Never', 'vira-store');
        $html .= '<tr><th>' . __('Last Updated', 'vira-store') . '</th><td>' . esc_html($updated_date) . '</td></tr>';
        
        // Expiry date
        if (!empty($license['expires_at']) && $license['expires_at'] !== '0000-00-00' && $license['expires_at'] !== '0000-00-00 00:00:00') {
            $expires_timestamp = strtotime($license['expires_at']);
            $expires_date = mysql2date('F j, Y \a\t g:i A', $license['expires_at']);
            $is_expired = $expires_timestamp < time();
            $expires_style = $is_expired ? 'color: #d63638; font-weight: 600;' : '';
            $html .= '<tr><th>' . __('Expires', 'vira-store') . '</th><td style="' . $expires_style . '">' . esc_html($expires_date) . ($is_expired ? ' <span style="color: #d63638;">(' . __('Expired', 'vira-store') . ')</span>' : '') . '</td></tr>';
        } else {
            $html .= '<tr><th>' . __('Expires', 'vira-store') . '</th><td><em style="color: #666;">' . __('Lifetime License', 'vira-store') . '</em></td></tr>';
        }
        
        // Order Information
        if ($order_info) {
            $html .= '<tr><th>' . __('Order', 'vira-store') . '</th><td>';
            $html .= '<strong>#' . esc_html($order_info['order_number']) . '</strong> ';
            $html .= '<span style="color: #666;">(' . mysql2date('M j, Y', $order_info['order_date']) . ')</span> ';
            $html .= '<span class="order-status order-status-' . esc_attr($order_info['order_status']) . '" style="padding: 2px 6px; border-radius: 3px; margin-left: 5px;">' . esc_html(ucfirst($order_info['order_status'])) . '</span>';
            $html .= ' <a href="' . admin_url('admin.php?page=vrstore-orders&order_id=' . $license['order_id']) . '" target="_blank" style="margin-left: 10px;">(' . __('View Order', 'vira-store') . ')</a>';
            $html .= '</td></tr>';
        }
        
        $html .= '</table>';
        
        // Activations History Section
        if (!empty($activations)) {
            $html .= '<h3 style="margin-top: 30px; padding-bottom: 10px; border-bottom: 2px solid #ddd;">' . __('Activations History', 'vira-store') . ' (' . count($activations) . ')</h3>';
            $html .= '<table class="wp-list-table widefat striped" style="margin-top: 15px;">';
            $html .= '<thead><tr>';
            $html .= '<th style="width: 40%;">' . __('Site URL', 'vira-store') . '</th>';
            $html .= '<th style="width: 20%;">' . __('IP Address', 'vira-store') . '</th>';
            $html .= '<th style="width: 25%;">' . __('Activated On', 'vira-store') . '</th>';
            $html .= '<th style="width: 15%;">' . __('Status', 'vira-store') . '</th>';
            $html .= '</tr></thead>';
            $html .= '<tbody>';
            
            foreach ($activations as $activation) {
                $html .= '<tr>';
                $site_url = $activation['site_url'] ?: __('Unknown', 'vira-store');
                $html .= '<td><a href="' . esc_url($site_url) . '" target="_blank" rel="noopener">' . esc_html($site_url) . '</a></td>';
                // Handle both ip_address (new schema) and activation_ip (old schema)
                $ip_address = $activation['ip_address'] ?? $activation['activation_ip'] ?? '';
                $html .= '<td><code style="font-size: 11px;">' . esc_html($ip_address ?: __('Unknown', 'vira-store')) . '</code></td>';
                
                // Format activation date - handle both activated_at (new schema) and activation_date (old schema)
                $activation_date_value = $activation['activated_at'] ?? $activation['activation_date'] ?? '';
                $activated_date = !empty($activation_date_value) ? mysql2date('M j, Y \a\t g:i A', $activation_date_value) : __('Unknown', 'vira-store');
                $html .= '<td>' . esc_html($activated_date) . '</td>';
                
                $activation_status = $activation['status'] ?? 'active';
                $status_color = $activation_status === 'active' ? '#00a32a' : '#666';
                $html .= '<td><span style="padding: 3px 6px; border-radius: 3px; background: ' . $status_color . '; color: #fff; font-size: 11px;">' . esc_html(ucfirst($activation_status)) . '</span></td>';
                $html .= '</tr>';
            }
            
            $html .= '</tbody></table>';
        } else {
            $html .= '<div style="margin-top: 20px; padding: 15px; background: #f9f9f9; border-left: 4px solid #2271b1;">';
            $html .= '<p style="margin: 0; color: #666;"><em>' . __('No activations recorded yet.', 'vira-store') . '</em></p>';
            $html .= '</div>';
        }
        
        $html .= '</div>';
        
        wp_send_json_success($html);
        
        } catch (Exception $e) {
            wp_send_json_error(['message' => __('Error loading license details. Please try again.', 'vira-store')]);
        }
    }

    /**
     * AJAX handler for getting coupon data
     *
     * @return void
     */
    public function ajax_get_coupon(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_admin_nonce')) {
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
        }

        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'vira-store')]);
        }

        $coupon_id = intval($_POST['coupon_id'] ?? 0);
        
        if (!$coupon_id) {
            wp_send_json_error(['message' => __('Invalid coupon ID.', 'vira-store')]);
        }

        // Get coupon using Coupon class
        if (class_exists('VRSTORE_Coupon')) {
            $coupon_class = VRSTORE_Coupon::get_instance();
            $coupon = $coupon_class->get_coupon($coupon_id);
            
            if ($coupon) {
                wp_send_json_success($coupon);
            } else {
                wp_send_json_error(['message' => __('Coupon not found.', 'vira-store')]);
            }
        } else {
            wp_send_json_error(['message' => __('Coupon class not available.', 'vira-store')]);
        }
    }

    /**
     * AJAX handler for saving coupon
     *
     * @return void
     */
    public function ajax_save_coupon(): void {
        global $wpdb;
        
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_admin_nonce')) {
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
            return;
        }

        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'vira-store')]);
        }

        // Get form data
        $coupon_id = intval($_POST['coupon_id'] ?? 0);
        $code = sanitize_text_field($_POST['code'] ?? '');
        $discount_type = sanitize_text_field($_POST['discount_type'] ?? '');
        $discount_amount = floatval($_POST['discount_amount'] ?? 0);
        $minimum_amount = floatval($_POST['minimum_amount'] ?? 0);
        $usage_limit = intval($_POST['usage_limit'] ?? 0);
        $expires_at = sanitize_text_field($_POST['expires_at'] ?? '');
        $description = sanitize_textarea_field($_POST['description'] ?? '');

        // Validate required fields
        if (empty($code)) {
            wp_send_json_error(['message' => __('Coupon code is required.', 'vira-store')]);
        }

        if (!in_array($discount_type, ['percentage', 'fixed'])) {
            wp_send_json_error(['message' => __('Invalid discount type.', 'vira-store')]);
        }

        if ($discount_amount <= 0) {
            wp_send_json_error(['message' => __('Discount amount must be greater than 0.', 'vira-store')]);
        }

        if ($discount_type === 'percentage' && $discount_amount > 100) {
            wp_send_json_error(['message' => __('Percentage discount cannot be more than 100%.', 'vira-store')]);
        }

        // Prepare coupon data
        // Note: Empty arrays are converted to null for database storage
        $coupon_data = [
            'code' => $code,
            'discount_type' => $discount_type,
            'discount_value' => $discount_amount,  // Database uses 'discount_value'
            'minimum_amount' => $minimum_amount > 0 ? $minimum_amount : null,
            'usage_limit' => $usage_limit > 0 ? $usage_limit : null,
            'description' => !empty($description) ? $description : null,
            'status' => 'active'
        ];

        // Add expiry date if provided
        if (!empty($expires_at)) {
            $coupon_data['end_date'] = date('Y-m-d H:i:s', strtotime($expires_at));  // Database uses 'end_date'
        }

        // Check if database tables exist
        $db = VRSTORE_Database::get_instance();
        if (!$db->table_exists('coupons')) {
            wp_send_json_error(['message' => __('Coupons database table does not exist. Please check your installation.', 'vira-store')]);
        }

        // Save coupon using Coupon class
        if (class_exists('VRSTORE_Coupon')) {
            $coupon_class = VRSTORE_Coupon::get_instance();
            

            // Saving coupon data
            
            try {
                if ($coupon_id > 0) {
                    // Update existing coupon
                    $existing = $coupon_class->get_coupon($coupon_id);
                    
                    if (!$existing) {
                        wp_send_json_error(['message' => __('Coupon not found.', 'vira-store')]);
                        return;
                    }
                    
                    $result = $coupon_class->update_coupon($coupon_id, $coupon_data);
                    $message = __('Coupon updated successfully!', 'vira-store');
                    
                    if (!$result) {
                        // Get last database error
                        $db_error = $wpdb->last_error ? $wpdb->last_error : 'Update failed without error message';
                        
                        if (defined('WP_DEBUG') && WP_DEBUG) {
                            error_log('Database error: ' . $db_error);
                        }
                        
                        wp_send_json_error([
                            'message' => __('Failed to update coupon: ', 'vira-store') . $db_error
                        ]);
                        return;
                    }
                    
                    wp_send_json_success([
                        'message' => $message,
                        'coupon_id' => $coupon_id,
                        'reload' => true
                    ]);
                } else {
                    // Create new coupon
                    $result = $coupon_class->create_coupon($coupon_data);
                    
                    if ($result === false) {
                        // Get last database error
                        $db_error = $wpdb->last_error ? $wpdb->last_error : 'Creation failed without error message';
                        
                        // Check if table exists
                        if (!$db->table_exists('coupons')) {
                            $db_error = 'Coupons table does not exist';
                        }
                        
                        wp_send_json_error([
                            'message' => __('Failed to create coupon: ', 'vira-store') . $db_error
                        ]);
                        return;
                    }
                    
                    wp_send_json_success([
                        'message' => __('Coupon created successfully!', 'vira-store'),
                        'coupon_id' => $result,
                        'reload' => true
                    ]);
                }
            } catch (Exception $e) {
                wp_send_json_error([
                    'message' => __('Exception occurred: ', 'vira-store') . $e->getMessage()
                ]);
            }
        } else {
            wp_send_json_error(['message' => __('Coupon class not available.', 'vira-store')]);
        }
    }

    /**
     * Get coupons data
     *
     * @return array
     */
    private function get_coupons_data(): array {
        if (class_exists('VRSTORE_Coupon')) {
            $coupon_class = VRSTORE_Coupon::get_instance();
            
            $args = [
                'per_page' => 20,
                'page' => isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1,
                'search' => sanitize_text_field($_GET['search'] ?? ''),
                'status' => sanitize_text_field($_GET['status'] ?? '')
            ];
            
            return $coupon_class->get_coupons($args);
        }
        
        return [
            'coupons' => [],
            'total_items' => 0,
            'total_pages' => 0,
            'current_page' => 1
        ];
    }

    /**
     * Get domain activations data with enhanced license information
     *
     * @return array
     */
    private function get_domain_activations_data(): array {
        if (class_exists('VRSTORE_Domain_Monitor')) {
            $domain_monitor = VRSTORE_Domain_Monitor::get_instance();
            
            $args = [
                'per_page' => 20,
                'page' => isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1,
                'search' => sanitize_text_field($_GET['search'] ?? ''),
                'status' => sanitize_text_field($_GET['status'] ?? ''),
                'license_key' => sanitize_text_field($_GET['license_key'] ?? ''),
                'license_type' => sanitize_text_field($_GET['license_type'] ?? '')
            ];
            
            $activations_data = $domain_monitor->get_domain_activations($args);
            $statistics = $domain_monitor->get_statistics();
            
            // Enhance activations with license type and custom license information
            if (!empty($activations_data['activations'])) {
                $activations_data['activations'] = $this->enhance_activations_with_license_data($activations_data['activations']);
            }
            
            // Get available license types for filtering
            $license_types = $this->get_available_license_types();
            
            return array_merge($activations_data, [
                'statistics' => $statistics,
                'license_types' => $license_types
            ]);
        }
        
        return [
            'activations' => [],
            'total_items' => 0,
            'total_pages' => 0,
            'current_page' => 1,
            'statistics' => [],
            'license_types' => []
        ];
    }

    /**
     * Enhance activations with license type and custom license data
     *
     * @param array $activations Raw activation data
     * @return array Enhanced activation data
     */
    private function enhance_activations_with_license_data(array $activations): array {
        global $wpdb;
        
        // Get settings for license type configurations
        $settings = get_option('vrstore_settings', []);
        $custom_license_types = $settings['custom_license_types'] ?? [];
        
        // Get licenses table
        $licenses_table = $wpdb->prefix . 'vrstore_licenses';
        $licenses_exists = $wpdb->get_var("SHOW TABLES LIKE '$licenses_table'") === $licenses_table;
        
        if (!$licenses_exists) {
            return $activations; // Return as-is if no licenses table
        }
        
        // Get license keys for batch lookup
        $license_keys = array_unique(array_filter(array_column($activations, 'license_key')));
        
        if (empty($license_keys)) {
            return $activations;
        }
        
        // Ensure all license keys are strings to prevent wpdb->prepare array error
        $safe_license_keys = [];
        foreach ($license_keys as $key) {
            if (is_scalar($key)) {
                $safe_license_keys[] = (string) $key;
            } else {
                // Convert non-scalar values to strings or handle appropriately
                $safe_license_keys[] = is_null($key) ? '' : (string) $key;
            }
        }
        $license_keys = $safe_license_keys;
        
        if (empty($license_keys)) {
            return $activations;
        }
        
        // Batch fetch license information - handle both license_type and license_type_slug columns
        $placeholders = implode(',', array_fill(0, count($license_keys), '%s'));
        
        // Check which license type column exists
        $columns = $wpdb->get_results("DESCRIBE $licenses_table", ARRAY_A);
        $has_license_type_slug = false;
        $has_license_type = false;
        
        foreach ($columns as $column) {
            if ($column['Field'] === 'license_type_slug') {
                $has_license_type_slug = true;
            }
            if ($column['Field'] === 'license_type') {
                $has_license_type = true;
            }
        }
        
        // Build query based on available columns
        if ($has_license_type_slug) {
            $license_type_column = 'license_type_slug';
        } elseif ($has_license_type) {
            $license_type_column = 'license_type as license_type_slug';
        } else {
            $license_type_column = "'' as license_type_slug";
        }
        
        $license_info = $wpdb->get_results($wpdb->prepare(
            "SELECT license_key, $license_type_column, expires_at, customer_email FROM $licenses_table WHERE license_key IN ($placeholders)",
            ...$license_keys
        ), ARRAY_A);
        
        // Index by license key for quick lookup
        $license_lookup = [];
        foreach ($license_info as $license) {
            $license_lookup[$license['license_key']] = $license;
        }
        
        // Enhance each activation
        foreach ($activations as &$activation) {
            $license_key = $activation['license_key'] ?? '';
            
            if (!empty($license_key) && isset($license_lookup[$license_key])) {
                $license = $license_lookup[$license_key];
                
                // Add license type information
                $license_type_slug = $license['license_type_slug'] ?? '';
                
                // If license_type_slug is empty, try to get it from the associated order
                if (empty($license_type_slug)) {
                    $orders_table = $wpdb->prefix . 'vrstore_orders';
                    if ($wpdb->get_var("SHOW TABLES LIKE '$orders_table'") === $orders_table) {
                        $order = $wpdb->get_row($wpdb->prepare(
                            "SELECT license_type FROM $orders_table WHERE license_key = %s LIMIT 1",
                            $license_key
                        ));
                        if ($order && !empty($order->license_type)) {
                            $license_type_slug = $order->license_type;
                        }
                    }
                }
                
                $activation['license_type_slug'] = $license_type_slug;
                $activation['license_expires_at'] = $license['expires_at'] ?? '';
                $activation['license_customer_email'] = $license['customer_email'] ?? '';
                
                // Add license type display information
                if (!empty($activation['license_type_slug'])) {
                    $type_info = $this->get_license_type_info($activation['license_type_slug'], $custom_license_types);
                    $activation['license_type_label'] = $type_info['label'];
                    $activation['license_type_color'] = $type_info['color'];
                } else {
                    // Set default values for activations without license type
                    $activation['license_type_label'] = __('Unassigned', 'vira-store');
                    $activation['license_type_color'] = '#6c757d';
                }
            } else {
                // Set default values for activations without matching license data
                $activation['license_type_slug'] = '';
                $activation['license_type_label'] = __('Unassigned', 'vira-store');
                $activation['license_type_color'] = '#6c757d';
                $activation['license_expires_at'] = '';
                $activation['license_customer_email'] = '';
            }
        }
        
        return $activations;
    }

    /**
     * Get license type information
     *
     * @param string $license_type_slug License type slug
     * @param array $custom_license_types Custom license types configuration
     * @return array License type info with label and color
     */
    private function get_license_type_info(string $license_type_slug, array $custom_license_types): array {
        // Default values
        $info = [
            'label' => ucfirst(str_replace('_', ' ', $license_type_slug)),
            'color' => '#0073aa' // Default blue
        ];
        
        // Find in custom license types
        foreach ($custom_license_types as $type) {
            if (($type['slug'] ?? '') === $license_type_slug) {
                $info['label'] = $type['label'] ?? $info['label'];
                // Generate color based on license type for visual distinction
                $info['color'] = $this->generate_license_type_color($license_type_slug);
                break;
            }
        }
        
        return $info;
    }

    /**
     * Generate a consistent color for license type
     *
     * @param string $license_type_slug License type slug
     * @return string Hex color code
     */
    private function generate_license_type_color(string $license_type_slug): string {
        // Predefined colors for common license types
        $predefined_colors = [
            'basic' => '#28a745',      // Green
            'premium' => '#dc3545',    // Red
            'enterprise' => '#6f42c1', // Purple
            'pro' => '#fd7e14',        // Orange
            'business' => '#20c997',   // Teal
            'personal' => '#6c757d',   // Gray
            'developer' => '#e83e8c',  // Pink
            'lifetime' => '#ffc107'    // Yellow
        ];
        
        $slug_lower = strtolower($license_type_slug);
        
        // Return predefined color if available
        if (isset($predefined_colors[$slug_lower])) {
            return $predefined_colors[$slug_lower];
        }
        
        // Generate color from slug hash
        $hash = md5($license_type_slug);
        $r = hexdec(substr($hash, 0, 2));
        $g = hexdec(substr($hash, 2, 2));
        $b = hexdec(substr($hash, 4, 2));
        
        // Ensure good contrast by adjusting brightness
        $brightness = ($r * 299 + $g * 587 + $b * 114) / 1000;
        if ($brightness > 150) {
            $r = max(0, $r - 50);
            $g = max(0, $g - 50);
            $b = max(0, $b - 50);
        }
        
        return sprintf('#%02x%02x%02x', $r, $g, $b);
    }

    /**
     * Get available license types for filtering
     *
     * @return array Available license types
     */
    private function get_available_license_types(): array {
        global $wpdb;
        
        $license_types = [];
        $licenses_table = $wpdb->prefix . 'vrstore_licenses';
        $activations_table = $wpdb->prefix . 'vrstore_license_domain_activations';
        
        // Check if licenses table exists
        $licenses_exists = $wpdb->get_var("SHOW TABLES LIKE '$licenses_table'") === $licenses_table;
        $activations_exists = $wpdb->get_var("SHOW TABLES LIKE '$activations_table'") === $activations_table;
        
        if ($licenses_exists) {
            // Get unique license type slugs from database
            $db_types = $wpdb->get_results(
                "SELECT DISTINCT license_type_slug FROM $licenses_table WHERE license_type_slug IS NOT NULL AND license_type_slug != ''",
                ARRAY_A
            );
            
            $settings = get_option('vrstore_settings', []);
            $custom_license_types = $settings['custom_license_types'] ?? [];
            
            foreach ($db_types as $db_type) {
                $slug = $db_type['license_type_slug'];
                if (!empty($slug)) {
                    $type_info = $this->get_license_type_info($slug, $custom_license_types);
                    $license_types[] = [
                        'slug' => $slug,
                        'label' => $type_info['label'],
                        'color' => $type_info['color']
                    ];
                }
            }
            
            // Check if there are any activations without proper license types
            if ($activations_exists) {
                $unassigned_count = $wpdb->get_var(
                    "SELECT COUNT(*) FROM $activations_table a 
                     LEFT JOIN $licenses_table l ON a.license_key = l.license_key 
                     WHERE l.license_key IS NULL OR l.license_type_slug IS NULL OR l.license_type_slug = ''"
                );
                
                // Add "Unassigned" option if there are activations without proper license types
                if ($unassigned_count > 0) {
                    $license_types[] = [
                        'slug' => 'unassigned',
                        'label' => __('Unassigned', 'vira-store'),
                        'color' => '#6c757d'
                    ];
                }
            }
            
            // Sort by label
            usort($license_types, function($a, $b) {
                return strcmp($a['label'], $b['label']);
            });
        }
        
        return $license_types;
    }

    /**
     * Get customers data
     *
     * @return array
     */
    private function get_customers_data(): array {
        if (class_exists('VRSTORE_Customer')) {
            $customer_class = VRSTORE_Customer::get_instance();
            
            $args = [
                'number' => 20,  // Fixed: use 'number' instead of 'per_page'
                'paged' => isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1,  // Fixed: use 'paged' instead of 'page'
                'search' => sanitize_text_field($_GET['search'] ?? ''),
                'status' => sanitize_text_field($_GET['status'] ?? ''),
                'role' => 'customer'
            ];
            
            $result = $customer_class->get_customers($args);
            
            // Map the result to match template expectations
            return [
                'customers' => $result['customers'] ?? [],
                'total_items' => $result['total'] ?? 0,
                'total_pages' => $result['total_pages'] ?? 0,
                'current_page' => $args['paged']
            ];
        }
        
        return [
            'customers' => [],
            'total_items' => 0,
            'total_pages' => 0,
            'current_page' => 1
        ];
    }

     /**
      * Render customer detail page
      *
      * @param int $customer_id
      * @return void
      */
     private function render_customer_detail_page(int $customer_id): void {
         if (!$customer_id) {
             wp_die(__('Invalid customer ID.', 'vira-store'));
         }

         if (class_exists('VRSTORE_Customer')) {
             $customer_class = VRSTORE_Customer::get_instance();
             $customer = $customer_class->get_customer($customer_id);
             
             if (!$customer) {
                 wp_die(__('Customer not found.', 'vira-store'));
             }
             
             // Get customer orders and licenses using the SAME methods as the frontend
             // This ensures 100% data consistency between admin and customer views
             if (class_exists('VRSTORE_Shortcodes')) {
                 $shortcodes = VRSTORE_Shortcodes::get_instance();
                 
                 // Use reflection to access private methods (same as frontend)
                 $reflection = new ReflectionClass($shortcodes);
                 $get_user_purchases = $reflection->getMethod('get_user_purchases');
                 $get_user_purchases->setAccessible(true);
                 $get_user_licenses = $reflection->getMethod('get_user_licenses');
                 $get_user_licenses->setAccessible(true);
                 
                 // Get data using the same methods as frontend
                 $purchases = $get_user_purchases->invokeArgs($shortcodes, [$customer_id]);
                 $licenses = $get_user_licenses->invokeArgs($shortcodes, [$customer_id]);
                 
                 // For backward compatibility with admin template, also set orders
                 $orders = $purchases;
             } else {
                 // Fallback to customer class methods if shortcodes not available
                 $orders = $customer_class->get_customer_orders($customer_id, ['limit' => 20, 'order' => 'DESC']);
                 $licenses = $customer_class->get_customer_licenses($customer_id, ['limit' => 20, 'order' => 'DESC']);
                 
                 // Ensure data consistency by adding any missing fields that frontend expects
                 foreach ($orders as &$order) {
                     // Ensure all required fields are available for frontend compatibility
                     if (!isset($order['order_id'])) {
                         $order['order_id'] = $order['id'] ?? '';
                     }
                     if (!isset($order['date'])) {
                         $order['date'] = $order['created_at'] ?? '';
                     }
                     if (!isset($order['status'])) {
                         $order['status'] = $order['payment_status'] ?? $order['order_status'] ?? 'unknown';
                     }
                 }
                 
                 foreach ($licenses as &$license) {
                     // Ensure all required fields are available for frontend compatibility
                     if (!isset($license['expiry_date'])) {
                         $license['expiry_date'] = $license['expires_at'] ?? '';
                     }
                 }
             }
             
             include VRSTORE_PLUGIN_DIR . 'views/admin/customer-detail.php';
         } else {
             wp_die(__('Customer management is not available.', 'vira-store'));
         }
     }

     /**
      * Render customer edit page
      *
      * @param int $customer_id
      * @return void
      */
     private function render_customer_edit_page(int $customer_id): void {
         if (!$customer_id) {
             wp_die(__('Invalid customer ID.', 'vira-store'));
         }

         if (class_exists('VRSTORE_Customer')) {
             $customer_class = VRSTORE_Customer::get_instance();
             $customer = $customer_class->get_customer($customer_id);
             
             if (!$customer) {
                 wp_die(__('Customer not found.', 'vira-store'));
             }
             
             include VRSTORE_PLUGIN_DIR . 'views/admin/customer-edit.php';
         } else {
             wp_die(__('Customer management is not available.', 'vira-store'));
         }
     }

     /**
      * Render customer add page
      *
      * @return void
      */
     private function render_customer_add_page(): void {
         include VRSTORE_PLUGIN_DIR . 'views/admin/customer-add.php';
     }

     /**
     * Handle customer actions
     *
     * @return void
     */
    private function handle_customer_actions(): void {
        // Handle form submissions
        if (isset($_POST['action'])) {
            $action = sanitize_text_field($_POST['action']);
            
            switch ($action) {
                case 'add_customer':
                    if (wp_verify_nonce($_POST['vrstore_customer_nonce'] ?? '', 'vrstore_add_customer')) {
                        $this->process_add_customer();
                        return;
                    }
                    break;
                case 'edit_customer':
                    if (wp_verify_nonce($_POST['vrstore_customer_nonce'] ?? '', 'vrstore_edit_customer')) {
                        $this->process_edit_customer();
                        return;
                    }
                    break;
            }
        }
        
        // Check for pending notice from previous action
        $this->display_customer_notice();
    }

    /**
     * Process customer action and redirect immediately
     *
     * @return void
     */
    private function process_customer_action(): void {
        $action = sanitize_text_field($_REQUEST['action']);
        $customer_id = intval($_REQUEST['customer_id']);

        // Verify nonce
        if (!wp_verify_nonce($_REQUEST['_wpnonce'] ?? '', 'vrstore_customer_action')) {
            wp_die(__('Security check failed.', 'vira-store'));
        }

        if (!class_exists('VRSTORE_Customer')) {
            wp_redirect(remove_query_arg(['action', 'customer_id', '_wpnonce']));
            exit;
        }

        $customer_class = VRSTORE_Customer::get_instance();
        $success_message = '';
        $error_message = '';

        switch ($action) {
            case 'activate':
                $result = $customer_class->update_customer($customer_id, ['status' => 'active']);
                if ($result) {
                    $success_message = __('Customer activated successfully.', 'vira-store');
                } else {
                    $error_message = __('Failed to activate customer.', 'vira-store');
                }
                break;

            case 'deactivate':
                $result = $customer_class->update_customer($customer_id, ['status' => 'inactive']);
                if ($result) {
                    $success_message = __('Customer deactivated successfully.', 'vira-store');
                } else {
                    $error_message = __('Failed to deactivate customer.', 'vira-store');
                }
                break;

            case 'delete':
                // Additional protection at UI level - check if user is admin
                $user = get_user_by('ID', $customer_id);
                if ($user && user_can($user, 'manage_options')) {
                    $error_message = __('Cannot delete administrator users. Admin users are protected from deletion.', 'vira-store');
                } elseif ($customer_id === 1) {
                    $error_message = __('Cannot delete the primary administrator account (User ID 1).', 'vira-store');
                } else {
                    $result = $customer_class->delete_customer($customer_id);
                    if ($result && !is_wp_error($result)) {
                        $success_message = __('Customer deleted successfully.', 'vira-store');
                    } else {
                        $error_message = is_wp_error($result) ? $result->get_error_message() : __('Failed to delete customer.', 'vira-store');
                    }
                }
                break;
        }

        // Store notice message in transient
        if (!empty($success_message)) {
            set_transient('vrstore_customer_notice', ['type' => 'success', 'message' => $success_message], 30);
        } elseif (!empty($error_message)) {
            set_transient('vrstore_customer_notice', ['type' => 'error', 'message' => $error_message], 30);
        }

        // Get the redirect URL
        $redirect_url = remove_query_arg(['action', 'customer_id', '_wpnonce']);
        
        // Perform redirect immediately
        wp_redirect($redirect_url);
        exit;
    }

    /**
     * Display customer notice from transient
     *
     * @return void
     */
    private function display_customer_notice(): void {
        $notice = get_transient('vrstore_customer_notice');
        
        if (!$notice || !is_array($notice)) {
            return;
        }
        
        delete_transient('vrstore_customer_notice');
        
        $type = $notice['type'] === 'success' ? 'notice-success' : 'notice-error';
        $message = esc_html($notice['message']);
        
        add_action('admin_notices', function() use ($type, $message) {
            echo '<div class="notice ' . $type . ' is-dismissible"><p>' . $message . '</p></div>';
        });
    }

    /**
     * Process add customer form submission
     *
     * @return void
     */
    private function process_add_customer(): void {
        if (!class_exists('VRSTORE_Customer')) {
            set_transient('vrstore_customer_notice', ['type' => 'error', 'message' => __('Customer class not available.', 'vira-store')], 30);
            wp_redirect(admin_url('admin.php?page=vrstore-customers'));
            exit;
        }

        // Validate required fields
        $required_fields = ['user_login', 'user_email', 'user_pass', 'user_pass_confirm'];
        foreach ($required_fields as $field) {
            if (empty($_POST[$field])) {
                set_transient('vrstore_customer_notice', ['type' => 'error', 'message' => sprintf(__('Field %s is required.', 'vira-store'), $field)], 30);
                wp_redirect(admin_url('admin.php?page=vrstore-customers&action=add'));
                exit;
            }
        }

        // Validate password confirmation
        if ($_POST['user_pass'] !== $_POST['user_pass_confirm']) {
            set_transient('vrstore_customer_notice', ['type' => 'error', 'message' => __('Passwords do not match.', 'vira-store')], 30);
            wp_redirect(admin_url('admin.php?page=vrstore-customers&action=add'));
            exit;
        }

        // Sanitize input data
        $customer_data = [
            'user_login' => sanitize_user($_POST['user_login']),
            'user_email' => sanitize_email($_POST['user_email']),
            'user_pass' => $_POST['user_pass'], // Don't sanitize password
            'first_name' => sanitize_text_field($_POST['first_name'] ?? ''),
            'last_name' => sanitize_text_field($_POST['last_name'] ?? ''),
            'display_name' => sanitize_text_field($_POST['display_name'] ?? ''),
            'role' => sanitize_text_field($_POST['user_role'] ?? 'customer'),
            'status' => sanitize_text_field($_POST['customer_status'] ?? 'active'),
            'send_notification' => !empty($_POST['send_notification'])
        ];

        // Add billing information
        $billing_fields = ['billing_phone', 'billing_company', 'billing_address_1', 'billing_address_2', 
                          'billing_city', 'billing_state', 'billing_postcode', 'billing_country'];
        foreach ($billing_fields as $field) {
            $customer_data[$field] = sanitize_text_field($_POST[$field] ?? '');
        }

        // Add customer notes
        $customer_data['customer_notes'] = sanitize_textarea_field($_POST['customer_notes'] ?? '');

        // Auto-generate display name if empty
        if (empty($customer_data['display_name'])) {
            $customer_data['display_name'] = trim($customer_data['first_name'] . ' ' . $customer_data['last_name']);
            if (empty($customer_data['display_name'])) {
                $customer_data['display_name'] = $customer_data['user_login'];
            }
        }

        $customer_class = VRSTORE_Customer::get_instance();
        $result = $customer_class->create_customer($customer_data);

        if (is_wp_error($result)) {
            set_transient('vrstore_customer_notice', ['type' => 'error', 'message' => $result->get_error_message()], 30);
            wp_redirect(admin_url('admin.php?page=vrstore-customers&action=add'));
        } else {
            set_transient('vrstore_customer_notice', ['type' => 'success', 'message' => __('Customer created successfully.', 'vira-store')], 30);
            wp_redirect(admin_url('admin.php?page=vrstore-customers&action=view&customer_id=' . $result));
        }
        exit;
    }

    /**
     * Process edit customer form submission
     *
     * @return void
     */
    private function process_edit_customer(): void {
        $customer_id = intval($_POST['customer_id'] ?? 0);
        
        if (!$customer_id) {
            set_transient('vrstore_customer_notice', ['type' => 'error', 'message' => __('Invalid customer ID.', 'vira-store')], 30);
            wp_redirect(admin_url('admin.php?page=vrstore-customers'));
            exit;
        }

        if (!class_exists('VRSTORE_Customer')) {
            set_transient('vrstore_customer_notice', ['type' => 'error', 'message' => __('Customer class not available.', 'vira-store')], 30);
            wp_redirect(admin_url('admin.php?page=vrstore-customers'));
            exit;
        }

        // Sanitize input data
        $customer_data = [
            'display_name' => sanitize_text_field($_POST['display_name'] ?? ''),
            'user_email' => sanitize_email($_POST['user_email'] ?? ''),
            'first_name' => sanitize_text_field($_POST['first_name'] ?? ''),
            'last_name' => sanitize_text_field($_POST['last_name'] ?? ''),
            'status' => sanitize_text_field($_POST['customer_status'] ?? 'active'),
            'role' => sanitize_text_field($_POST['user_role'] ?? 'customer')
        ];

        // Add billing information
        $billing_fields = ['billing_phone', 'billing_company', 'billing_address_1', 'billing_address_2', 
                          'billing_city', 'billing_state', 'billing_postcode', 'billing_country'];
        foreach ($billing_fields as $field) {
            $customer_data[$field] = sanitize_text_field($_POST[$field] ?? '');
        }

        // Add customer notes
        $customer_data['customer_notes'] = sanitize_textarea_field($_POST['customer_notes'] ?? '');

        $customer_class = VRSTORE_Customer::get_instance();
        $result = $customer_class->update_customer($customer_id, $customer_data);

        if ($result) {
            set_transient('vrstore_customer_notice', ['type' => 'success', 'message' => __('Customer updated successfully.', 'vira-store')], 30);
            wp_redirect(admin_url('admin.php?page=vrstore-customers&action=view&customer_id=' . $customer_id));
        } else {
            set_transient('vrstore_customer_notice', ['type' => 'error', 'message' => __('Failed to update customer.', 'vira-store')], 30);
            wp_redirect(admin_url('admin.php?page=vrstore-customers&action=edit&customer_id=' . $customer_id));
        }
        exit;
    }

    /**
     * Handle coupon actions
     *
     * @return void
     */
    private function handle_coupon_actions(): void {
        // Check if we have an action to process
        if (isset($_REQUEST['action']) && isset($_REQUEST['coupon_id']) && 
            in_array($_REQUEST['action'], ['activate', 'deactivate', 'delete'])) {
            
            // Process the action immediately before any output
            $this->process_coupon_action();
            return;
        }
        
        // Check for pending notice from previous action
        $this->display_coupon_notice();
    }
    
    /**
     * Process coupon action and redirect immediately
     *
     * @return void
     */
    private function process_coupon_action(): void {
        global $wpdb;
        
        $action = sanitize_text_field($_REQUEST['action']);
        $coupon_id = intval($_REQUEST['coupon_id']);


        // Verify nonce
        if (!wp_verify_nonce($_REQUEST['_wpnonce'] ?? '', 'vrstore_coupon_action')) {
            wp_die(__('Security check failed.', 'vira-store'));
        }

        if (!class_exists('VRSTORE_Coupon')) {
            wp_redirect(remove_query_arg(['action', 'coupon_id', '_wpnonce']));
            exit;
        }

        $coupon_class = VRSTORE_Coupon::get_instance();
        $success_message = '';
        $error_message = '';
        

        $before_coupon = $coupon_class->get_coupon($coupon_id);
        
        global $wpdb;

        switch ($action) {
            case 'activate':
                $result = $coupon_class->update_coupon($coupon_id, ['status' => 'active']);
                
                if ($result) {
                    $success_message = __('Coupon activated successfully.', 'vira-store');
                } else {
                    $error_message = __('Failed to activate coupon.', 'vira-store');
                }
                break;

            case 'deactivate':
                $result = $coupon_class->update_coupon($coupon_id, ['status' => 'inactive']);
                
                if ($result) {
                    $success_message = __('Coupon deactivated successfully.', 'vira-store');
                } else {
                    $error_message = __('Failed to deactivate coupon.', 'vira-store');
                }
                break;

            case 'delete':
                $result = $coupon_class->delete_coupon($coupon_id);
                
                if ($result) {
                    $success_message = __('Coupon deleted successfully.', 'vira-store');
                } else {
                    $error_message = __('Failed to delete coupon.', 'vira-store');
                }
                break;
        }
        

        $after_coupon = $coupon_class->get_coupon($coupon_id);

        // Store notice message in transient
        if (!empty($success_message)) {
            set_transient('vrstore_coupon_notice', ['type' => 'success', 'message' => $success_message], 30);
        } elseif (!empty($error_message)) {
            set_transient('vrstore_coupon_notice', ['type' => 'error', 'message' => $error_message], 30);
        }

        // Get the redirect URL
        $redirect_url = remove_query_arg(['action', 'coupon_id', '_wpnonce']);
        
        // Perform redirect immediately
        wp_redirect($redirect_url);
        exit;
    }
    
    /**
     * Display coupon notice from transient
     *
     * @return void
     */
    private function display_coupon_notice(): void {
        $notice = get_transient('vrstore_coupon_notice');
        
        if (!$notice || !is_array($notice)) {
            return;
        }
        
        delete_transient('vrstore_coupon_notice');
        
        $type = $notice['type'] === 'success' ? 'notice-success' : 'notice-error';
        $message = esc_html($notice['message']);
        
        add_action('admin_notices', function() use ($type, $message) {
            echo '<div class="notice ' . $type . ' is-dismissible"><p>' . $message . '</p></div>';
        });
    }

    /**
     * Process license action and redirect immediately
     *
     * @return void
     */
    private function process_license_action(): void {
        $action = sanitize_text_field($_REQUEST['action'] ?? '');
        $license_id = intval($_REQUEST['license_id'] ?? 0);

        // Capability check
        if (!current_user_can('manage_options')) {
            wp_die(__('Permission denied.', 'vira-store'));
        }

        // Verify nonce
        if (!wp_verify_nonce($_REQUEST['_wpnonce'] ?? '', 'vrstore_license_action')) {
            wp_die(__('Security check failed.', 'vira-store'));
        }

        global $wpdb;
        $licenses_table = $wpdb->prefix . 'vrstore_licenses';
        $activations_table = $wpdb->prefix . 'vrstore_license_activations';

        $success_message = '';
        $error_message = '';

        switch ($action) {
            case 'activate':
                $result = $wpdb->update(
                    $licenses_table,
                    ['status' => 'active'],
                    ['id' => $license_id],
                    ['%s'],
                    ['%d']
                );
                if ($result !== false) {
                    $success_message = __('License activated successfully.', 'vira-store');
                } else {
                    $error_message = __('Failed to activate license.', 'vira-store');
                }
                break;

            case 'deactivate':
                $result = $wpdb->update(
                    $licenses_table,
                    ['status' => 'inactive'],
                    ['id' => $license_id],
                    ['%s'],
                    ['%d']
                );
                if ($result !== false) {
                    $success_message = __('License deactivated successfully.', 'vira-store');
                } else {
                    $error_message = __('Failed to deactivate license.', 'vira-store');
                }
                break;

            case 'delete':
                // Delete related activations first
                $wpdb->delete(
                    $activations_table,
                    ['license_id' => $license_id],
                    ['%d']
                );
                $result = $wpdb->delete(
                    $licenses_table,
                    ['id' => $license_id],
                    ['%d']
                );
                if ($result !== false) {
                    $success_message = __('License deleted successfully.', 'vira-store');
                } else {
                    $error_message = __('Failed to delete license.', 'vira-store');
                }
                break;
        }

        // Store notice message in transient
        if (!empty($success_message)) {
            set_transient('vrstore_license_notice', ['type' => 'success', 'message' => $success_message], 30);
        } elseif (!empty($error_message)) {
            set_transient('vrstore_license_notice', ['type' => 'error', 'message' => $error_message], 30);
        }

        // Redirect to avoid resubmission and ensure no output before headers
        $redirect_url = remove_query_arg(['action', 'license_id', '_wpnonce']);
        wp_redirect($redirect_url);
        exit;
    }

    /**
     * Display license notice from transient
     *
     * @return void
     */
    private function display_license_notice(): void {
        $notice = get_transient('vrstore_license_notice');
        
        if (!$notice || !is_array($notice)) {
            return;
        }
        
        delete_transient('vrstore_license_notice');
        
        $type = ($notice['type'] ?? '') === 'success' ? 'notice-success' : 'notice-error';
        $message = esc_html($notice['message'] ?? '');
        
        add_action('admin_notices', function() use ($type, $message) {
            echo '<div class="notice ' . $type . ' is-dismissible"><p>' . $message . '</p></div>';
        });
    }

    /**
     * Handle domain activation actions
     *
     * @return void
     */
    private function handle_domain_activation_actions(): void {
        if (!isset($_REQUEST['action']) || !isset($_REQUEST['activation_id'])) {
            return;
        }

        $action = sanitize_text_field($_REQUEST['action']);
        $activation_id = intval($_REQUEST['activation_id']);

        // Verify nonce
        if (!wp_verify_nonce($_REQUEST['_wpnonce'] ?? '', 'vrstore_domain_activation_action')) {
            wp_die(__('Security check failed.', 'vira-store'));
        }

        if (!class_exists('VRSTORE_Domain_Monitor')) {
            return;
        }

        $domain_monitor = VRSTORE_Domain_Monitor::get_instance();

        $success_message = '';
        $error_message = '';

        switch ($action) {
            case 'deactivate':
                // Use the private method through reflection or add a public method
                $reflection = new ReflectionClass($domain_monitor);
                $method = $reflection->getMethod('deactivate_domain_license');
                $method->setAccessible(true);
                
                if ($method->invoke($domain_monitor, $activation_id, 'admin_forced')) {
                    $success_message = __('Domain activation deactivated successfully.', 'vira-store');
                } else {
                    $error_message = __('Failed to deactivate domain activation.', 'vira-store');
                }
                break;

            case 'delete':
                // First verify the activation is inactive before allowing deletion
                $reflection = new ReflectionClass($domain_monitor);
                $get_method = $reflection->getMethod('get_domain_activation_by_id');
                $get_method->setAccessible(true);
                $activation = $get_method->invoke($domain_monitor, $activation_id);
                
                if ($activation && isset($activation['status']) && $activation['status'] === 'inactive') {
                    // Use the delete method through reflection
                    $delete_method = $reflection->getMethod('delete_domain_activation');
                    $delete_method->setAccessible(true);
                    
                    if ($delete_method->invoke($domain_monitor, $activation_id)) {
                        $success_message = __('Inactive domain activation deleted successfully.', 'vira-store');
                    } else {
                        $error_message = __('Failed to delete domain activation.', 'vira-store');
                    }
                } elseif ($activation && $activation['status'] !== 'inactive') {
                    $error_message = __('Only inactive domain activations can be deleted.', 'vira-store');
                } else {
                    $error_message = __('Domain activation not found.', 'vira-store');
                }
                break;

            case 'refresh':
                $reflection = new ReflectionClass($domain_monitor);
                $get_method = $reflection->getMethod('get_domain_activation_by_id');
                $get_method->setAccessible(true);
                $activation = $get_method->invoke($domain_monitor, $activation_id);
                
                if ($activation) {
                    $check_method = $reflection->getMethod('check_domain_status');
                    $check_method->setAccessible(true);
                    $check_method->invoke($domain_monitor, $activation);
                    
                    $success_message = __('Domain status refreshed successfully.', 'vira-store');
                } else {
                    $error_message = __('Failed to refresh domain status.', 'vira-store');
                }
                break;
        }

        // Store notice message in transient
        if (!empty($success_message)) {
            set_transient('vrstore_domain_notice', ['type' => 'success', 'message' => $success_message], 30);
        } elseif (!empty($error_message)) {
            set_transient('vrstore_domain_notice', ['type' => 'error', 'message' => $error_message], 30);
        }

        // Redirect to avoid resubmission
        wp_redirect(remove_query_arg(['action', 'activation_id', '_wpnonce']));
        exit;
    }

    /**
     * Process domain activation action and redirect immediately
     *
     * @return void
     */
    private function process_domain_activation_action(): void {
        $action = sanitize_text_field($_REQUEST['action']);
        $activation_id = intval($_REQUEST['activation_id']);

        // Verify nonce
        if (!wp_verify_nonce($_REQUEST['_wpnonce'] ?? '', 'vrstore_domain_activation_action')) {
            wp_die(__('Security check failed.', 'vira-store'));
        }

        if (!class_exists('VRSTORE_Domain_Monitor')) {
            wp_redirect(remove_query_arg(['action', 'activation_id', '_wpnonce']));
            exit;
        }

        $domain_monitor = VRSTORE_Domain_Monitor::get_instance();
        $success_message = '';
        $error_message = '';

        switch ($action) {
            case 'deactivate':
                // Use the private method through reflection or add a public method
                $reflection = new ReflectionClass($domain_monitor);
                $method = $reflection->getMethod('deactivate_domain_license');
                $method->setAccessible(true);
                
                if ($method->invoke($domain_monitor, $activation_id, 'admin_forced')) {
                    $success_message = __('Domain activation deactivated successfully.', 'vira-store');
                } else {
                    $error_message = __('Failed to deactivate domain activation.', 'vira-store');
                }
                break;

            case 'delete':
                // First verify the activation is inactive before allowing deletion
                $reflection = new ReflectionClass($domain_monitor);
                $get_method = $reflection->getMethod('get_domain_activation_by_id');
                $get_method->setAccessible(true);
                $activation = $get_method->invoke($domain_monitor, $activation_id);
                
                if ($activation && isset($activation['status']) && $activation['status'] === 'inactive') {
                    // Use the delete method through reflection
                    $delete_method = $reflection->getMethod('delete_domain_activation');
                    $delete_method->setAccessible(true);
                    
                    if ($delete_method->invoke($domain_monitor, $activation_id)) {
                        $success_message = __('Inactive domain activation deleted successfully.', 'vira-store');
                    } else {
                        $error_message = __('Failed to delete domain activation.', 'vira-store');
                    }
                } elseif ($activation && $activation['status'] !== 'inactive') {
                    $error_message = __('Only inactive domain activations can be deleted.', 'vira-store');
                } else {
                    $error_message = __('Domain activation not found.', 'vira-store');
                }
                break;

            case 'refresh':
                $reflection = new ReflectionClass($domain_monitor);
                $get_method = $reflection->getMethod('get_domain_activation_by_id');
                $get_method->setAccessible(true);
                $activation = $get_method->invoke($domain_monitor, $activation_id);
                
                if ($activation) {
                    $check_method = $reflection->getMethod('check_domain_status');
                    $check_method->setAccessible(true);
                    $check_method->invoke($domain_monitor, $activation);
                    
                    $success_message = __('Domain status refreshed successfully.', 'vira-store');
                } else {
                    $error_message = __('Failed to refresh domain status.', 'vira-store');
                }
                break;
        }

        // Store notice message in transient
        if (!empty($success_message)) {
            set_transient('vrstore_domain_notice', ['type' => 'success', 'message' => $success_message], 30);
        } elseif (!empty($error_message)) {
            set_transient('vrstore_domain_notice', ['type' => 'error', 'message' => $error_message], 30);
        }

        // Redirect to avoid resubmission
        wp_redirect(remove_query_arg(['action', 'activation_id', '_wpnonce']));
        exit;
    }

    /**
     * Display domain notice from transient
     *
     * @return void
     */
    private function display_domain_notice(): void {
        $notice = get_transient('vrstore_domain_notice');
        
        if (!$notice || !is_array($notice)) {
            return;
        }
        
        delete_transient('vrstore_domain_notice');
        
        $type = $notice['type'] === 'success' ? 'notice-success' : 'notice-error';
        $message = esc_html($notice['message']);
        
        add_action('admin_notices', function() use ($type, $message) {
            echo '<div class="notice ' . $type . ' is-dismissible"><p>' . $message . '</p></div>';
        });
    }

    /**
     * Handle plugin version actions
     *
     * @return void
     */
    private function handle_plugin_version_actions(): void {
        // Security validation
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'vira-store'));
        }

        // Verify nonce for security
        if (!isset($_POST['vrstore_plugin_version_nonce']) || 
            !wp_verify_nonce($_POST['vrstore_plugin_version_nonce'], 'vrstore_plugin_version_action')) {
            add_action('admin_notices', function() {
                echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('Security check failed. Please try again.', 'vira-store') . '</p></div>';
            });
            return;
        }

        // Rate limiting check
        $user_id = get_current_user_id();
        $rate_limit_key = "vrstore_plugin_actions_{$user_id}";
        $current_count = get_transient($rate_limit_key) ?: 0;
        
        if ($current_count >= 20) { // Max 20 actions per hour
            add_action('admin_notices', function() {
                echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('Too many actions performed. Please wait before trying again.', 'vira-store') . '</p></div>';
            });
            return;
        }
        
        set_transient($rate_limit_key, $current_count + 1, HOUR_IN_SECONDS);

        $action = sanitize_text_field($_POST['action'] ?? '');
        $product_id = intval($_POST['product_id'] ?? 0);
        
        if (!$product_id) {
            add_action('admin_notices', function() {
                echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('Invalid product ID.', 'vira-store') . '</p></div>';
            });
            return;
        }

        // Validate product exists and user has permission
        if (!$this->validate_product_access($product_id)) {
            add_action('admin_notices', function() {
                echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('Invalid product or insufficient permissions.', 'vira-store') . '</p></div>';
            });
            return;
        }

        // Log the action for security audit
        if (class_exists('VRSTORE_Plugin_Update_Security')) {
            $security_handler = VRSTORE_Plugin_Update_Security::get_instance();
            $security_handler->log_security_event(
                'plugin_version_action',
                "User {$user_id} performed action '{$action}' on product {$product_id}",
                ['user_id' => $user_id, 'product_id' => $product_id, 'action' => $action]
            );
        }

        try {
            switch ($action) {
                case 'add_version':
                    $this->handle_add_plugin_version($product_id);
                    break;
                case 'update_version':
                    $this->handle_update_plugin_version($product_id);
                    break;
                case 'delete_version':
                    $this->handle_delete_plugin_version($product_id);
                    break;
                default:
                    add_action('admin_notices', function() {
                        echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('Invalid action specified.', 'vira-store') . '</p></div>';
                    });
            }
        } catch (Exception $e) {
            if (class_exists('VRSTORE_Plugin_Update_Security')) {
                $security_handler = VRSTORE_Plugin_Update_Security::get_instance();
                $security_handler->log_security_event(
                    'plugin_version_error',
                    "Error in plugin version action: " . $e->getMessage(),
                    ['user_id' => $user_id, 'product_id' => $product_id, 'action' => $action]
                );
            }
            add_action('admin_notices', function() {
                echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('An error occurred while processing your request.', 'vira-store') . '</p></div>';
            });
        }
    }

    /**
     * Handle adding a new plugin version
     *
     * @param int $product_id Product ID
     * @return void
     */
    private function handle_add_plugin_version(int $product_id): void {
        // Enhanced input validation
        $version = sanitize_text_field($_POST['version'] ?? '');
        $changelog = wp_kses_post($_POST['changelog'] ?? '');
        $license_tiers = array_map('sanitize_text_field', $_POST['license_tiers'] ?? []);
        
        // Validate version format (semantic versioning)
        if (empty($version) || !preg_match('/^\d+\.\d+\.\d+(-[a-zA-Z0-9\-\.]+)?$/', $version)) {
            add_action('admin_notices', function() {
                echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('Valid version number is required (e.g., 1.0.0).', 'vira-store') . '</p></div>';
            });
            return;
        }
        
        // Validate changelog length
        if (strlen($changelog) > 5000) {
            add_action('admin_notices', function() {
                echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('Changelog is too long. Maximum 5000 characters allowed.', 'vira-store') . '</p></div>';
            });
            return;
        }
        
        // Use database table instead of post meta (aligned with class-product.php)
        global $wpdb;
        $versions_table = $wpdb->prefix . 'vrstore_plugin_versions';
        
        // Check if table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$versions_table'") !== $versions_table) {
            add_action('admin_notices', function() {
                echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('Plugin versions table does not exist. Please check database setup.', 'vira-store') . '</p></div>';
            });
            return;
        }
        
        // Check if version already exists for this product
        $existing_version = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$versions_table} WHERE product_id = %d AND version = %s",
            $product_id,
            $version
        ));
        
        if ($existing_version) {
            add_action('admin_notices', function() use ($version) {
                echo '<div class="notice notice-error is-dismissible"><p>' . sprintf(esc_html__('Version %s already exists for this product.', 'vira-store'), esc_html($version)) . '</p></div>';
            });
            return;
        }
        
        // Handle file upload first (before inserting to database)
        $file_name = '';
        $file_size = 0;
        if (isset($_FILES['plugin_file']) && $_FILES['plugin_file']['error'] === UPLOAD_ERR_OK) {
            // Use VRSTORE_Product class method for consistent file handling
            if (class_exists('VRSTORE_Product')) {
                $product_class = VRSTORE_Product::get_instance();
                $upload_result = $product_class->handle_plugin_version_file_uploads($product_id, ['plugin_file' => $_FILES['plugin_file']]);
                
                // Note: File upload will be associated with version_id after insert
                // For now, we'll insert version first, then update with file info
                $file_size = isset($_FILES['plugin_file']['size']) ? intval($_FILES['plugin_file']['size']) : 0;
            } else {
                // Fallback: basic validation
                if ($_FILES['plugin_file']['type'] !== 'application/zip' && 
                    pathinfo($_FILES['plugin_file']['name'], PATHINFO_EXTENSION) !== 'zip') {
                    add_action('admin_notices', function() {
                        echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('Only ZIP files are allowed.', 'vira-store') . '</p></div>';
                    });
                    return;
                }
            }
        }
        
        // Insert new version to database table
        $license_tiers_json = !empty($license_tiers) ? json_encode($license_tiers) : '';
        $insert_result = $wpdb->insert(
            $versions_table,
            [
                'product_id' => $product_id,
                'version' => $version,
                'changelog' => $changelog,
                'license_tiers' => $license_tiers_json,
                'file_name' => $file_name,
                'file_size' => $file_size,
                'is_active' => 1,
                'release_date' => current_time('mysql'),
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql')
            ],
            ['%d', '%s', '%s', '%s', '%s', '%d', '%d', '%s', '%s', '%s']
        );
        
        if ($insert_result === false) {
            error_log('ViraStore: Failed to insert plugin version: ' . $wpdb->last_error);
            add_action('admin_notices', function() {
                echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('Failed to save version to database. Please try again.', 'vira-store') . '</p></div>';
            });
            return;
        }
        
        $version_id = $wpdb->insert_id;
        
        // If file was uploaded, handle it now (using product class method if available)
        if (isset($_FILES['plugin_file']) && $_FILES['plugin_file']['error'] === UPLOAD_ERR_OK && $version_id) {
            if (class_exists('VRSTORE_Product')) {
                // Create a structured files array matching expected format
                $files_array = [
                    'plugin_file' => [
                        'name' => $_FILES['plugin_file']['name'],
                        'type' => $_FILES['plugin_file']['type'],
                        'tmp_name' => $_FILES['plugin_file']['tmp_name'],
                        'error' => $_FILES['plugin_file']['error'],
                        'size' => $_FILES['plugin_file']['size']
                    ]
                ];
                
                // Store version_id temporarily to associate file with correct version
                // The handle_plugin_version_file_uploads will need to match by version number
                // For modal form, we'll need to pass version_id through a different mechanism
                // For now, file upload will be handled on next product save via metabox
                // Or we can update the file info directly here
                
                $uploaded_file = wp_handle_upload($_FILES['plugin_file'], ['test_form' => false]);
                
                if ($uploaded_file && !isset($uploaded_file['error'])) {
                    // Update version record with file info
                    $wpdb->update(
                        $versions_table,
                        [
                            'file_name' => basename($uploaded_file['file']),
                            'file_path' => $uploaded_file['file'],
                            'file_size' => filesize($uploaded_file['file'])
                        ],
                        ['id' => $version_id],
                        ['%s', '%s', '%d'],
                        ['%d']
                    );
                } else {
                    error_log('ViraStore: File upload failed: ' . ($uploaded_file['error'] ?? 'Unknown error'));
                }
            }
        }
        
        // Log successful version addition
        if (class_exists('VRSTORE_Plugin_Update_Security')) {
            $security_handler = VRSTORE_Plugin_Update_Security::get_instance();
            $security_handler->log_security_event(
                'plugin_version_added',
                "Version {$version} added to product {$product_id}",
                ['product_id' => $product_id, 'version' => $version, 'version_id' => $version_id]
            );
        }
        
        add_action('admin_notices', function() use ($version) {
            echo '<div class="notice notice-success is-dismissible"><p>' . sprintf(esc_html__('Version %s added successfully.', 'vira-store'), esc_html($version)) . '</p></div>';
        });
    }

    /**
     * Handle updating an existing plugin version
     *
     * @param int $product_id Product ID
     * @return void
     */
    private function handle_update_plugin_version(int $product_id): void {
        try {
            // Enhanced input validation
            $version = sanitize_text_field($_POST['version'] ?? '');
            $changelog = wp_kses_post($_POST['changelog'] ?? '');
            $license_tiers = array_map('sanitize_text_field', $_POST['license_tiers'] ?? []);
            
            if (empty($version)) {
                add_action('admin_notices', function() {
                    echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('Version number is required.', 'vira-store') . '</p></div>';
                });
                return;
            }
            
            // Validate version format (semantic versioning)
            if (!preg_match('/^[0-9]+\.[0-9]+\.[0-9]+$/', $version)) {
                add_action('admin_notices', function() {
                    echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('Invalid version format. Please use semantic versioning (e.g., 1.0.0).', 'vira-store') . '</p></div>';
                });
                return;
            }
            
            // Validate changelog length
            if (strlen($changelog) > 5000) {
                add_action('admin_notices', function() {
                    echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('Changelog is too long. Maximum 5000 characters allowed.', 'vira-store') . '</p></div>';
                });
                return;
            }
            
            // Get existing versions
            $versions = get_post_meta($product_id, '_vrstore_plugin_versions', true) ?: [];
            
            if (!isset($versions[$version])) {
                add_action('admin_notices', function() use ($version) {
                    echo '<div class="notice notice-error is-dismissible"><p>' . sprintf(esc_html__('Version %s not found.', 'vira-store'), esc_html($version)) . '</p></div>';
                });
                return;
            }
            
            // Create backup of current version data
            $backup_version = $versions[$version];
            
            // Update version data
            $versions[$version]['changelog'] = $changelog;
            $versions[$version]['license_tiers'] = $license_tiers;
            
            // Handle file upload if provided
            if (isset($_FILES['plugin_file']) && $_FILES['plugin_file']['error'] === UPLOAD_ERR_OK) {
                // Validate file upload using security class
                $security = VRSTORE_Plugin_Update_Security::get_instance();
                $file_validation = $security->validate_file_upload($_FILES['plugin_file']);
                
                if (!$file_validation['valid']) {
                    add_action('admin_notices', function() use ($file_validation) {
                        echo '<div class="notice notice-error is-dismissible"><p>' . esc_html($file_validation['message']) . '</p></div>';
                    });
                    return;
                }
                
                $upload_result = $this->handle_plugin_file_upload($_FILES['plugin_file'], $product_id, $version);
                if (is_wp_error($upload_result)) {
                    add_action('admin_notices', function() use ($upload_result) {
                        echo '<div class="notice notice-error is-dismissible"><p>' . esc_html($upload_result->get_error_message()) . '</p></div>';
                    });
                    return;
                }
                
                // Remove old file if exists
                if (!empty($versions[$version]['file_path']) && file_exists($versions[$version]['file_path'])) {
                    unlink($versions[$version]['file_path']);
                }
                
                $versions[$version]['file_path'] = $upload_result['file_path'];
                $versions[$version]['file_name'] = $upload_result['file_name'];
                $versions[$version]['file_size'] = $upload_result['file_size'];
                $versions[$version]['file_hash'] = $upload_result['file_hash'];
            }
            
            // Add metadata
            $versions[$version]['updated_at'] = current_time('mysql');
            $versions[$version]['updated_by'] = get_current_user_id();
            
            // Atomic update with error handling
            $update_result = update_post_meta($product_id, '_vrstore_plugin_versions', $versions);
            
            if (!$update_result) {
                // Restore backup on failure
                $versions[$version] = $backup_version;
                update_post_meta($product_id, '_vrstore_plugin_versions', $versions);
                
                add_action('admin_notices', function() {
                    echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('Failed to update version. Please try again.', 'vira-store') . '</p></div>';
                });
                return;
            }
            
            // Log security event
            $security = VRSTORE_Plugin_Update_Security::get_instance();
            $security->log_security_event('plugin_version_updated', [
                'product_id' => $product_id,
                'version' => $version,
                'user_id' => get_current_user_id(),
                'ip_address' => $security->get_client_ip(),
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown'
            ]);
            
            add_action('admin_notices', function() use ($version) {
                echo '<div class="notice notice-success is-dismissible"><p>' . sprintf(esc_html__('Version %s updated successfully.', 'vira-store'), esc_html($version)) . '</p></div>';
            });
            
        } catch (Exception $e) {
            error_log('ViraStore Plugin Version Update Error: ' . $e->getMessage());
            add_action('admin_notices', function() {
                echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('An error occurred while updating the version. Please try again.', 'vira-store') . '</p></div>';
            });
        }
    }

    /**
     * Handle deleting a plugin version
     *
     * @param int $product_id Product ID
     * @return void
     */
    private function handle_delete_plugin_version(int $product_id): void {
        try {
            // Enhanced input validation
            $version = sanitize_text_field($_POST['version'] ?? '');
            
            if (empty($version)) {
                add_action('admin_notices', function() {
                    echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('Version number is required.', 'vira-store') . '</p></div>';
                });
                return;
            }
            
            // Validate version format
            if (!preg_match('/^[0-9]+\.[0-9]+\.[0-9]+$/', $version)) {
                add_action('admin_notices', function() {
                    echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('Invalid version format.', 'vira-store') . '</p></div>';
                });
                return;
            }
            
            // Get existing versions
            $versions = get_post_meta($product_id, '_vrstore_plugin_versions', true) ?: [];
            
            if (!isset($versions[$version])) {
                add_action('admin_notices', function() use ($version) {
                    echo '<div class="notice notice-error is-dismissible"><p>' . sprintf(esc_html__('Version %s not found.', 'vira-store'), esc_html($version)) . '</p></div>';
                });
                return;
            }
            
            // Create backup of version data before deletion
            $backup_version = $versions[$version];
            
            // Remove file if exists
            $file_removed = true;
            if (!empty($versions[$version]['file_path']) && file_exists($versions[$version]['file_path'])) {
                $file_removed = unlink($versions[$version]['file_path']);
                if (!$file_removed) {
                    error_log('ViraStore: Failed to delete file: ' . $versions[$version]['file_path']);
                }
            }
            
            // Remove version from array
            unset($versions[$version]);
            
            // Atomic update with error handling
            $update_result = update_post_meta($product_id, '_vrstore_plugin_versions', $versions);
            
            if (!$update_result) {
                // Restore backup on failure
                $versions[$version] = $backup_version;
                update_post_meta($product_id, '_vrstore_plugin_versions', $versions);
                
                add_action('admin_notices', function() {
                    echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('Failed to delete version. Please try again.', 'vira-store') . '</p></div>';
                });
                return;
            }
            
            // Log security event
            $security = VRSTORE_Plugin_Update_Security::get_instance();
            $security->log_security_event('plugin_version_deleted', [
                'product_id' => $product_id,
                'version' => $version,
                'user_id' => get_current_user_id(),
                'ip_address' => $security->get_client_ip(),
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown',
                'file_removed' => $file_removed
            ]);
            
            $message = $file_removed 
                ? sprintf(esc_html__('Version %s deleted successfully.', 'vira-store'), esc_html($version))
                : sprintf(esc_html__('Version %s deleted successfully, but file removal failed.', 'vira-store'), esc_html($version));
                
            add_action('admin_notices', function() use ($message) {
                echo '<div class="notice notice-success is-dismissible"><p>' . $message . '</p></div>';
            });
            
        } catch (Exception $e) {
            error_log('ViraStore Plugin Version Delete Error: ' . $e->getMessage());
            add_action('admin_notices', function() {
                echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('An error occurred while deleting the version. Please try again.', 'vira-store') . '</p></div>';
            });
        }
    }

    /**
     * Handle plugin file upload
     *
     * @param array $file Uploaded file data
     * @param int $product_id Product ID
     * @param string $version Version number
     * @return array|WP_Error Upload result or error
     */
    private function handle_plugin_file_upload(array $file, int $product_id, string $version) {
        try {
            // Enhanced file validation
            $allowed_types = ['zip'];
            $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            
            if (!in_array($file_extension, $allowed_types)) {
                return new WP_Error('invalid_file_type', __('Only ZIP files are allowed.', 'vira-store'));
            }
            
            // Validate file size (50MB max)
            $max_size = 50 * 1024 * 1024; // 50MB
            if ($file['size'] > $max_size) {
                return new WP_Error('file_too_large', sprintf(__('File size exceeds maximum allowed size of %s.', 'vira-store'), size_format($max_size)));
            }
            
            // Validate MIME type
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime_type = finfo_file($finfo, $file['tmp_name']);
            finfo_close($finfo);
            
            $allowed_mime_types = ['application/zip', 'application/x-zip-compressed'];
            if (!in_array($mime_type, $allowed_mime_types)) {
                return new WP_Error('invalid_mime_type', __('Invalid file type. Only ZIP files are allowed.', 'vira-store'));
            }
            
            // Validate file content (basic ZIP validation)
            $zip = new ZipArchive();
            $zip_result = $zip->open($file['tmp_name'], ZipArchive::CHECKCONS);
            if ($zip_result !== TRUE) {
                return new WP_Error('invalid_zip_file', __('Invalid or corrupted ZIP file.', 'vira-store'));
            }
            $zip->close();
            
            // Create upload directory with proper permissions
            $upload_dir = wp_upload_dir();
            $plugin_dir = $upload_dir['basedir'] . '/vrstore-plugins/' . $product_id;
            
            if (!file_exists($plugin_dir)) {
                if (!wp_mkdir_p($plugin_dir)) {
                    return new WP_Error('directory_creation_failed', __('Failed to create upload directory.', 'vira-store'));
                }
                
                // Set proper permissions
                chmod($plugin_dir, 0755);
                
                // Add index.php for security
                $index_content = "<?php\n// Silence is golden.\n";
                file_put_contents($plugin_dir . '/index.php', $index_content);
            }
            
            // Generate secure filename
            $filename = sanitize_file_name($version . '-' . wp_generate_password(8, false) . '.zip');
            $file_path = $plugin_dir . '/' . $filename;
            
            // Ensure file doesn't already exist
            $counter = 1;
            while (file_exists($file_path)) {
                $filename = sanitize_file_name($version . '-' . wp_generate_password(8, false) . '-' . $counter . '.zip');
                $file_path = $plugin_dir . '/' . $filename;
                $counter++;
                
                // Prevent infinite loop
                if ($counter > 100) {
                    return new WP_Error('filename_generation_failed', __('Failed to generate unique filename.', 'vira-store'));
                }
            }
            
            // Move uploaded file with error checking
            if (!move_uploaded_file($file['tmp_name'], $file_path)) {
                return new WP_Error('upload_failed', __('Failed to upload file.', 'vira-store'));
            }
            
            // Set proper file permissions
            chmod($file_path, 0644);
            
            // Generate file hash for integrity checking
            $file_hash = hash_file('sha256', $file_path);
            
            // Verify file was uploaded correctly
            if (!file_exists($file_path) || filesize($file_path) !== $file['size']) {
                // Clean up on failure
                if (file_exists($file_path)) {
                    unlink($file_path);
                }
                return new WP_Error('upload_verification_failed', __('File upload verification failed.', 'vira-store'));
            }
            
            return [
                'file_path' => $file_path,
                'file_name' => $filename,
                'file_size' => $file['size'],
                'file_hash' => $file_hash,
                'mime_type' => $mime_type,
                'uploaded_at' => current_time('mysql')
            ];
            
        } catch (Exception $e) {
            error_log('ViraStore File Upload Error: ' . $e->getMessage());
            return new WP_Error('upload_exception', __('An error occurred during file upload.', 'vira-store'));
        }
    }

    // Database tools functionality has been moved to Settings > Tools tab
    // The render_database_tools_page, ajax_repair_database, and ajax_check_database_status
    // methods have been relocated to the VRSTORE_Settings class
    
    /**
     * AJAX handler for getting order details
     *
     * @return void
     */
    public function ajax_get_order_details(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_admin_nonce')) {
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
        }

        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'vira-store')]);
        }

        $order_id = intval($_POST['order_id'] ?? 0);
        
        if (!$order_id) {
            wp_send_json_error(['message' => __('Invalid order ID.', 'vira-store')]);
        }

        global $wpdb;
        $orders_table = $wpdb->prefix . 'vrstore_orders';
        
        // Get order details
        $order = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $orders_table WHERE id = %d",
            $order_id
        ), ARRAY_A);
        
        if (!$order) {
            wp_send_json_error(['message' => __('Order not found.', 'vira-store')]);
        }
        
        // Get payment method display name
        $payment_methods = [
            'tripay' => __('TriPay', 'vira-store'),
            'manual' => __('Transfer Bank', 'vira-store')
        ];
        
        $payment_method_name = $payment_methods[$order['payment_method']] ?? ucfirst($order['payment_method']);
        
        // Format price using global currency settings
        $formatted_price = '';
        if (class_exists('VRSTORE_Product') && class_exists('VRSTORE_Settings')) {
            $product_instance = VRSTORE_Product::get_instance();
            $settings_instance = VRSTORE_Settings::get_instance();
            $global_currency = $settings_instance->get_setting('currency', 'USD');
            $formatted_price = $product_instance->format_price($order['product_price'], $global_currency);
        } else {
            $global_currency = get_option('vrstore_settings', [])['currency'] ?? 'USD';
            $formatted_price = $global_currency . ' ' . number_format($order['product_price'], 2);
        }
        
        // Build HTML response
        $html = '<div class="order-details">';
        $html .= '<table class="wp-list-table widefat">';
        $html .= '<tr><th>' . $this->get_translated_text('Order Number') . '</th><td><strong>#' . esc_html($order['order_number']) . '</strong></td></tr>';
        $html .= '<tr><th>' . $this->get_translated_text('Customer Name') . '</th><td>' . esc_html($order['customer_name']) . '</td></tr>';
        $html .= '<tr><th>' . $this->get_translated_text('Customer Email') . '</th><td><a href="mailto:' . esc_attr($order['customer_email']) . '">' . esc_html($order['customer_email']) . '</a></td></tr>';
        $html .= '<tr><th>' . $this->get_translated_text('Product') . '</th><td>' . esc_html($order['product_name']) . '</td></tr>';
        $html .= '<tr><th>' . $this->get_translated_text('Amount') . '</th><td><strong>' . esc_html($formatted_price) . '</strong></td></tr>';
        $html .= '<tr><th>' . $this->get_translated_text('Payment Method') . '</th><td>' . esc_html($payment_method_name) . '</td></tr>';
        $html .= '<tr><th>' . $this->get_translated_text('Payment Status') . '</th><td><span class="payment-status payment-status-' . esc_attr($order['payment_status']) . '">' . esc_html(ucfirst($order['payment_status'])) . '</span></td></tr>';
        $html .= '<tr><th>' . $this->get_translated_text('Order Status') . '</th><td><span class="order-status order-status-' . esc_attr($order['order_status']) . '">' . esc_html(ucfirst($order['order_status'])) . '</span></td></tr>';
        
        if (!empty($order['transaction_id'])) {
            $html .= '<tr><th>' . $this->get_translated_text('Transaction ID') . '</th><td><code>' . esc_html($order['transaction_id']) . '</code></td></tr>';
        }
        
        if (!empty($order['payment_id'])) {
            $html .= '<tr><th>' . $this->get_translated_text('Payment ID') . '</th><td><code>' . esc_html($order['payment_id']) . '</code></td></tr>';
        }
        
        if (!empty($order['license_key'])) {
            $html .= '<tr><th>' . $this->get_translated_text('License Key') . '</th><td><code>' . esc_html($order['license_key']) . '</code></td></tr>';
        }
        
        $html .= '<tr><th>' . $this->get_translated_text('Created') . '</th><td>' . esc_html(mysql2date('M j, Y g:i A', $order['created_at'])) . '</td></tr>';
        $html .= '<tr><th>' . $this->get_translated_text('Updated') . '</th><td>' . esc_html(mysql2date('M j, Y g:i A', $order['updated_at'])) . '</td></tr>';
        
        if (!empty($order['order_notes'])) {
            $html .= '<tr><th>' . $this->get_translated_text('Notes') . '</th><td>' . esc_html($order['order_notes']) . '</td></tr>';
        }
        
        $html .= '</table>';
        $html .= '</div>';
        
        wp_send_json_success($html);
    }
    
    /**
     * AJAX handler for updating order status
     *
     * @return void
     */
    public function ajax_update_order_status(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_admin_nonce')) {
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
        }

        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'vira-store')]);
        }

        $order_id = intval($_POST['order_id'] ?? 0);
        $order_status = sanitize_text_field($_POST['order_status'] ?? '');
        $payment_status = sanitize_text_field($_POST['payment_status'] ?? '');
        $order_notes = sanitize_textarea_field($_POST['order_notes'] ?? '');
        
        if (!$order_id) {
            wp_send_json_error(['message' => __('Invalid order ID.', 'vira-store')]);
        }
        
        // Validate status values
        $valid_order_statuses = ['pending', 'processing', 'completed', 'failed', 'cancelled'];
        $valid_payment_statuses = ['pending', 'completed', 'failed', 'refunded'];
        
        if (!in_array($order_status, $valid_order_statuses)) {
            wp_send_json_error(['message' => __('Invalid order status.', 'vira-store')]);
        }
        
        if (!in_array($payment_status, $valid_payment_statuses)) {
            wp_send_json_error(['message' => __('Invalid payment status.', 'vira-store')]);
        }

        global $wpdb;
        $orders_table = $wpdb->prefix . 'vrstore_orders';
        
        // Check if order exists
        $existing_order = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $orders_table WHERE id = %d",
            $order_id
        ), ARRAY_A);
        
        if (!$existing_order) {
            wp_send_json_error(['message' => __('Order not found.', 'vira-store')]);
        }
        
        // Prepare update data
        $update_data = [
            'order_status' => $order_status,
            'payment_status' => $payment_status,
            'updated_at' => current_time('mysql')
        ];
        
        // Add notes if provided
        if (!empty($order_notes)) {
            // Append new notes to existing notes
            $existing_notes = $existing_order['order_notes'] ?? '';
            $timestamp = current_time('Y-m-d H:i:s');
            $new_note = '[' . $timestamp . '] ' . $order_notes;
            
            if (!empty($existing_notes)) {
                $update_data['order_notes'] = $existing_notes . "\n" . $new_note;
            } else {
                $update_data['order_notes'] = $new_note;
            }
        }
        
        // Update order status using the unified system
        $order_status_updated = VRSTORE_Order::update_order_status($order_id, $order_status);
        $payment_status_updated = VRSTORE_Order::update_payment_status($order_id, $payment_status);
        
        // Update notes separately in database table if provided
        $notes_updated = true;
        if (!empty($order_notes)) {
            // Append new notes to existing notes
            $existing_notes = $existing_order['order_notes'] ?? '';
            $timestamp = current_time('Y-m-d H:i:s');
            $new_note = '[' . $timestamp . '] ' . $order_notes;
            
            if (!empty($existing_notes)) {
                $updated_notes = $existing_notes . "\n" . $new_note;
            } else {
                $updated_notes = $new_note;
            }
            
            $notes_result = $wpdb->update(
                $orders_table,
                ['order_notes' => $updated_notes, 'updated_at' => current_time('mysql')],
                ['id' => $order_id],
                ['%s', '%s'],
                ['%d']
            );
            $notes_updated = ($notes_result !== false);
        }
        
        if ($order_status_updated && $payment_status_updated && $notes_updated) {
            // Order status updated successfully
            
            wp_send_json_success([
                'message' => __('Order status updated successfully!', 'vira-store'),
                'order_id' => $order_id,
                'order_status' => $order_status,
                'payment_status' => $payment_status
            ]);
        } else {
            wp_send_json_error([
                'message' => __('Failed to update order status. Please try again.', 'vira-store'),
                'debug' => $wpdb->last_error
            ]);
        }
    }

    /**
     * AJAX handler for getting activation details
     *
     * @return void
     */
    public function ajax_get_activation_details(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_admin_nonce')) {
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
        }

        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'vira-store')]);
        }

        $activation_id = intval($_POST['activation_id'] ?? 0);
        
        if (!$activation_id) {
            wp_send_json_error(['message' => __('Invalid activation ID.', 'vira-store')]);
        }

        if (!class_exists('VRSTORE_Domain_Monitor')) {
            wp_send_json_error(['message' => __('Domain Monitor class not available.', 'vira-store')]);
        }

        global $wpdb;
        $activations_table = $wpdb->prefix . 'vrstore_license_domain_activations';
        $licenses_table = $wpdb->prefix . 'vrstore_licenses';
        
        // Get activation details with license information
        $activation = $wpdb->get_row($wpdb->prepare(
            "SELECT a.*, l.customer_email, l.expires_at as license_expires, l.license_type_slug, p.post_title as product_name
             FROM $activations_table a 
             LEFT JOIN $licenses_table l ON a.license_key = l.license_key
             LEFT JOIN {$wpdb->posts} p ON a.product_id = p.ID 
             WHERE a.id = %d",
            $activation_id
        ), ARRAY_A);
        
        if (!$activation) {
            wp_send_json_error(['message' => __('Activation not found.', 'vira-store')]);
        }

        // Get license type information if available
        $license_type_info = '';
        if (!empty($activation['license_type_slug'])) {
            $settings = get_option('vrstore_settings', []);
            if (isset($settings['custom_license_types'])) {
                foreach ($settings['custom_license_types'] as $type) {
                    if ($type['slug'] === $activation['license_type_slug']) {
                        $license_type_info = $type['label'] ?? ucfirst($activation['license_type_slug']);
                        break;
                    }
                }
            }
            if (empty($license_type_info)) {
                $license_type_info = ucfirst($activation['license_type_slug']);
            }
        }
        
        // Build HTML response
        $html = '<div class="activation-details">';
        $html .= '<table class="wp-list-table widefat">';
        $html .= '<tr><th>' . __('Domain', 'vira-store') . '</th><td><strong>' . esc_html($activation['domain'] ?? '') . '</strong></td></tr>';
        $html .= '<tr><th>' . __('License Key', 'vira-store') . '</th><td><code>' . esc_html($activation['license_key'] ?? '') . '</code></td></tr>';
        
        if (!empty($activation['product_name'])) {
            $html .= '<tr><th>' . $this->get_translated_text('Product') . '</th><td>' . esc_html($activation['product_name']) . '</td></tr>';
        }
        
        if (!empty($license_type_info)) {
            $html .= '<tr><th>' . $this->get_translated_text('License Type') . '</th><td><span class="license-type-badge">' . esc_html($license_type_info) . '</span></td></tr>';
        }
        
        if (!empty($activation['customer_email'])) {
            $html .= '<tr><th>' . $this->get_translated_text('Customer Email') . '</th><td><a href="mailto:' . esc_attr($activation['customer_email']) . '">' . esc_html($activation['customer_email']) . '</a></td></tr>';
        }
        
        $html .= '<tr><th>' . $this->get_translated_text('Status') . '</th><td><span class="activation-status activation-status-' . esc_attr($activation['status'] ?? '') . '">' . esc_html(ucfirst($activation['status'] ?? '')) . '</span></td></tr>';
        $html .= '<tr><th>' . $this->get_translated_text('Activated') . '</th><td>' . esc_html(mysql2date('M j, Y g:i A', $activation['activated_at'])) . '</td></tr>';
        
        if (!empty($activation['activation_ip'])) {
            $html .= '<tr><th>' . $this->get_translated_text('Activation IP') . '</th><td>' . esc_html($activation['activation_ip']) . '</td></tr>';
        }
        
        if (!empty($activation['last_checked']) && $activation['last_checked'] !== '0000-00-00 00:00:00') {
            $html .= '<tr><th>' . $this->get_translated_text('Last Checked') . '</th><td>' . esc_html(mysql2date('M j, Y g:i A', $activation['last_checked'])) . '</td></tr>';
        }
        
        if (!empty($activation['last_response_time'])) {
            $html .= '<tr><th>' . $this->get_translated_text('Response Time') . '</th><td>' . esc_html($activation['last_response_time']) . 'ms</td></tr>';
        }
        
        if (isset($activation['domain_accessible'])) {
            $accessible_text = $activation['domain_accessible'] ? $this->get_translated_text('Yes') : $this->get_translated_text('No');
            $accessible_class = $activation['domain_accessible'] ? 'text-success' : 'text-error';
            $html .= '<tr><th>' . $this->get_translated_text('Domain Accessible') . '</th><td><span class="' . $accessible_class . '">' . $accessible_text . '</span></td></tr>';
        }
        
        if (!empty($activation['license_expires']) && $activation['license_expires'] !== '0000-00-00 00:00:00') {
            $html .= '<tr><th>' . $this->get_translated_text('License Expires') . '</th><td>' . esc_html(mysql2date('M j, Y g:i A', $activation['license_expires'])) . '</td></tr>';
        }
        
        if (!empty($activation['deactivated_at']) && $activation['deactivated_at'] !== '0000-00-00 00:00:00') {
            $html .= '<tr><th>' . $this->get_translated_text('Deactivated') . '</th><td>' . esc_html(mysql2date('M j, Y g:i A', $activation['deactivated_at'])) . '</td></tr>';
        }
        
        if (!empty($activation['deactivation_reason'])) {
            $html .= '<tr><th>' . $this->get_translated_text('Deactivation Reason') . '</th><td>' . esc_html(ucwords(str_replace('_', ' ', $activation['deactivation_reason']))) . '</td></tr>';
        }
        
        if (!empty($activation['user_agent'])) {
            $html .= '<tr><th>' . $this->get_translated_text('User Agent') . '</th><td><small>' . esc_html(substr($activation['user_agent'], 0, 100)) . (strlen($activation['user_agent']) > 100 ? '...' : '') . '</small></td></tr>';
        }
        
        $html .= '</table>';
        $html .= '</div>';
        
        wp_send_json_success($html);
    }

    /**
     * Process order action and redirect immediately
     *
     * @return void
     */
    private function process_order_action(): void {
        $action = sanitize_text_field($_REQUEST['action']);
        $order_id = intval($_REQUEST['order_id']);

        // Verify nonce
        if (!wp_verify_nonce($_REQUEST['_wpnonce'] ?? '', 'vrstore_order_action')) {
            wp_die(__('Security check failed.', 'vira-store'));
        }

        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_die(__('Permission denied.', 'vira-store'));
        }

        global $wpdb;
        $orders_table = $wpdb->prefix . 'vrstore_orders';
        $success_message = '';
        $error_message = '';

        switch ($action) {
            case 'view':
                // View action just redirects to the orders page with view modal trigger
                // The actual view will be handled by JavaScript modal
                $redirect_url = add_query_arg([
                    'page' => 'vrstore-orders',
                    'view_order' => $order_id
                ], admin_url('admin.php'));
                wp_redirect($redirect_url);
                exit;

            case 'change_status':
                // Change status action redirects to orders page with status modal trigger
                // The actual status change will be handled by AJAX
                $redirect_url = add_query_arg([
                    'page' => 'vrstore-orders',
                    'change_status' => $order_id
                ], admin_url('admin.php'));
                wp_redirect($redirect_url);
                exit;

            case 'delete':
                // Check if order exists
                $existing_order = $wpdb->get_row($wpdb->prepare(
                    "SELECT * FROM $orders_table WHERE id = %d",
                    $order_id
                ), ARRAY_A);
                
                if (!$existing_order) {
                    $error_message = __('Order not found.', 'vira-store');
                } else {
                    // Delete the order
                    $result = $wpdb->delete(
                        $orders_table,
                        ['id' => $order_id],
                        ['%d']
                    );
                    
                    if ($result !== false) {
                        $success_message = __('Order deleted successfully.', 'vira-store');
                        
                        // Order deleted successfully
                    } else {
                        $error_message = __('Failed to delete order.', 'vira-store');
                    }
                }
                break;
        }

        // Store notice message in transient
        if (!empty($success_message)) {
            set_transient('vrstore_order_notice', ['type' => 'success', 'message' => $success_message], 30);
        } elseif (!empty($error_message)) {
            set_transient('vrstore_order_notice', ['type' => 'error', 'message' => $error_message], 30);
        }

        // Get the redirect URL
        $redirect_url = remove_query_arg(['action', 'order_id', '_wpnonce']);
        
        // Perform redirect immediately
        wp_redirect($redirect_url);
        exit;
    }

    /**
     * Display order notice from transient
     *
     * @return void
     */
    private function display_order_notice(): void {
        $notice = get_transient('vrstore_order_notice');
        
        if (!$notice || !is_array($notice)) {
            return;
        }
        
        delete_transient('vrstore_order_notice');
        
        $type = $notice['type'] === 'success' ? 'notice-success' : 'notice-error';
        $message = esc_html($notice['message']);
        
        add_action('admin_notices', function() use ($type, $message) {
            echo '<div class="notice ' . $type . ' is-dismissible"><p>' . $message . '</p></div>';
        });
    }

    /**
     * AJAX handler to assign customer roles to users with orders
     *
     * @return void
     */
    public function ajax_assign_customer_roles(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_admin_nonce')) {
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
        }

        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'vira-store')]);
        }

        try {
            // Get the customer class instance
            $customer = new VRSTORE_Customer();
            
            // Call the utility function to assign customer roles
            $result = $customer->assign_customer_roles_to_order_users();
            
            // Send success response with stats
            wp_send_json_success([
                'message' => sprintf(
                    __('Successfully assigned customer role to %d users. %d users already had the role.', 'vira-store'),
                    $result['assigned'],
                    $result['already_had_role']
                ),
                'stats' => $result
            ]);
            
        } catch (Exception $e) {
            wp_send_json_error([
                'message' => __('An error occurred while assigning customer roles.', 'vira-store')
            ]);
        }
    }

    /**
     * AJAX handler for repairing database tables
     *
     * @return void
     */
    public function ajax_repair_database(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_admin_nonce')) {
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
        }

        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'vira-store')]);
        }

        try {
            // Get database instance
            $database = VRSTORE_Database::get_instance();
            
            // Run database repair/creation
            $database->create_tables();
            
            wp_send_json_success([
                'message' => __('Database tables repaired successfully!', 'vira-store')
            ]);
            
        } catch (Exception $e) {
            wp_send_json_error([
                'message' => __('An error occurred while repairing database tables.', 'vira-store')
            ]);
        }
    }

    /**
     * AJAX handler for checking database status
     *
     * @return void
     */
    public function ajax_check_database_status(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_admin_nonce')) {
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
        }

        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'vira-store')]);
        }

        try {
            // Get database instance
            $database = VRSTORE_Database::get_instance();
            
            // Check table status
            $status = [
                'orders' => $database->table_exists('orders'),
                'licenses' => $database->table_exists('licenses'),
                'license_activations' => $database->table_exists('license_activations'),
                'coupons' => $database->table_exists('coupons'),
                'license_domain_activations' => $database->table_exists('license_domain_activations')
            ];
            
            $all_tables_exist = !in_array(false, $status, true);
            
            wp_send_json_success([
                'status' => $status,
                'all_tables_exist' => $all_tables_exist,
                'message' => $all_tables_exist 
                    ? __('All database tables are properly installed.', 'vira-store')
                    : __('Some database tables are missing and need repair.', 'vira-store')
            ]);
            
        } catch (Exception $e) {
            wp_send_json_error([
                'message' => __('An error occurred while checking database status.', 'vira-store')
            ]);
        }
    }

    /**
     * AJAX handler for migrating license type slugs
     *
     * @return void
     */
    public function ajax_migrate_license_types(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_admin_nonce')) {
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
        }

        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'vira-store')]);
        }

        try {
            // Run license type migration
            if (class_exists('VRSTORE_Order')) {
                $updated_count = VRSTORE_Order::migrate_license_type_slugs();
                
                wp_send_json_success([
                    'message' => sprintf(
                        __('License type migration completed! Updated %d licenses.', 'vira-store'),
                        $updated_count
                    ),
                    'updated_count' => $updated_count
                ]);
            } else {
                wp_send_json_error([
                    'message' => __('Order class not available for migration.', 'vira-store')
                ]);
            }
            
        } catch (Exception $e) {
            wp_send_json_error([
                'message' => __('An error occurred while migrating license types.', 'vira-store')
            ]);
        }
    }
    
    /**
     * AJAX handler for manually completing orders (useful for manual payments)
     *
     * @return void
     */
    public function ajax_complete_manual_order(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_admin_nonce')) {
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
        }

        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'vira-store')]);
        }
        
        $order_id = absint($_POST['order_id'] ?? 0);
        
        if (!$order_id) {
            wp_send_json_error(['message' => __('Invalid order ID.', 'vira-store')]);
        }

        try {
            // Use the order completion method we added
            if (class_exists('VRSTORE_Order')) {
                $result = VRSTORE_Order::manually_complete_order($order_id);
                
                if ($result['success']) {
                    wp_send_json_success([
                        'message' => $result['message'],
                        'licenses_activated' => $result['licenses_activated']
                    ]);
                } else {
                    wp_send_json_error(['message' => $result['message']]);
                }
            } else {
                wp_send_json_error(['message' => __('Order class not available.', 'vira-store')]);
            }
            
        } catch (Exception $e) {
            wp_send_json_error([
                'message' => __('An error occurred while completing the order.', 'vira-store')
            ]);
        }
    }
    
    /**
     * AJAX handler for getting customer deletion details
     *
     * @return void
     */
    public function ajax_get_customer_deletion_details(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_admin_nonce')) {
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
        }

        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'vira-store')]);
        }
        
        $customer_id = absint($_POST['customer_id'] ?? 0);
        
        if (!$customer_id) {
            wp_send_json_error(['message' => __('Invalid customer ID.', 'vira-store')]);
        }

        try {
            global $wpdb;
            
            // Get counts of related data that will be deleted
            $licenses_count = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}vrstore_licenses WHERE customer_id = %d",
                $customer_id
            ));
            
            $domain_activations_count = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}vrstore_license_domain_activations WHERE customer_id = %d",
                $customer_id
            ));
            
            $orders_count = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}vrstore_orders WHERE customer_id = %d",
                $customer_id
            ));
            
            $download_tracking_count = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}vrstore_download_tracking WHERE user_id = %d",
                $customer_id
            ));
            
            wp_send_json_success([
                'licenses_count' => (int) $licenses_count,
                'domain_activations_count' => (int) $domain_activations_count,
                'orders_count' => (int) $orders_count,
                'download_tracking_count' => (int) $download_tracking_count
            ]);
            
        } catch (Exception $e) {
            wp_send_json_error([
                'message' => __('An error occurred while getting customer details.', 'vira-store')
            ]);
        }
    }

    /**
     * AJAX handler for running payment tests
     *
     * @return void
     */
    public function ajax_run_payment_test(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_admin_nonce')) {
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
        }

        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'vira-store')]);
        }

        $gateway = sanitize_text_field($_POST['gateway'] ?? '');
        $amount = floatval($_POST['amount'] ?? 0);
        $test_type = sanitize_text_field($_POST['test_type'] ?? '');
        
        if (empty($gateway) || $amount <= 0 || empty($test_type)) {
            wp_send_json_error(['message' => __('Invalid test parameters.', 'vira-store')]);
        }
        
        // Check if payment testing is enabled
        $testing_enabled = get_option('vrstore_enable_payment_testing', '');
        if (empty($testing_enabled)) {
            wp_send_json_error(['message' => __('Payment testing is not enabled.', 'vira-store')]);
        }
        
        try {
            // Simulate different test scenarios based on test type
            $result = $this->execute_payment_test($gateway, $amount, $test_type);
            
            // Log the test result
            $this->log_payment_test($gateway, $amount, $test_type, $result);
            
            if ($result['success']) {
                wp_send_json_success([
                    'message' => $result['message'],
                    'transaction_id' => $result['transaction_id'] ?? null,
                    'gateway_response' => $result['gateway_response'] ?? null
                ]);
            } else {
                wp_send_json_error($result['message']);
            }
            
        } catch (Exception $e) {
            // Log the error
            $this->log_payment_test($gateway, $amount, $test_type, [
                'success' => false,
                'message' => $e->getMessage()
            ]);
            
            wp_send_json_error([
                'message' => __('Payment test failed: ', 'vira-store') . $e->getMessage()
            ]);
        }
    }

    /**
     * Execute payment test based on gateway and test type
     *
     * @param string $gateway Gateway to test
     * @param float $amount Test amount
     * @param string $test_type Type of test
     * @return array Test result
     */
    private function execute_payment_test(string $gateway, float $amount, string $test_type): array {
        $transaction_id = 'TEST_' . strtoupper($gateway) . '_' . time() . '_' . wp_rand(1000, 9999);
        
        switch ($test_type) {
            case 'connection':
                return $this->test_gateway_connection($gateway);
                
            case 'transaction':
                return $this->test_gateway_transaction($gateway, $amount, $transaction_id);
                
            case 'webhook':
                return $this->test_gateway_webhook($gateway, $amount, $transaction_id);
                
            default:
                throw new Exception(__('Invalid test type.', 'vira-store'));
        }
    }

    /**
     * Test gateway connection
     *
     * @param string $gateway Gateway to test
     * @return array Test result
     */
    private function test_gateway_connection(string $gateway): array {
        // Simulate connection test based on gateway
        switch ($gateway) {
            case 'paypal':
                $api_username = get_option('vrstore_paypal_api_username', '');
                if (empty($api_username)) {
                    return [
                        'success' => false,
                        'message' => __('PayPal API credentials not configured.', 'vira-store')
                    ];
                }
                break;
                
        }
        
        return [
            'success' => true,
            'message' => sprintf(__('%s connection test successful.', 'vira-store'), ucfirst($gateway))
        ];
    }

    /**
     * Test gateway transaction
     *
     * @param string $gateway Gateway to test
     * @param float $amount Test amount
     * @param string $transaction_id Transaction ID
     * @return array Test result
     */
    private function test_gateway_transaction(string $gateway, float $amount, string $transaction_id): array {
        // Simulate transaction test - in real implementation, this would make actual API calls
        $test_customer_email = get_option('vrstore_test_customer_email', 'test@example.com');
        
        // Simulate different outcomes based on amount
        if ($amount >= 100) {
            return [
                'success' => false,
                'message' => __('Test transaction failed: Amount too high for test mode.', 'vira-store')
            ];
        }
        
        return [
            'success' => true,
            'message' => sprintf(__('Test transaction successful for %s.', 'vira-store'), ucfirst($gateway)),
            'transaction_id' => $transaction_id,
            'gateway_response' => [
                'status' => 'completed',
                'amount' => $amount,
                'currency' => 'USD',
                'customer_email' => $test_customer_email
            ]
        ];
    }

    /**
     * Test gateway webhook
     *
     * @param string $gateway Gateway to test
     * @param float $amount Test amount
     * @param string $transaction_id Transaction ID
     * @return array Test result
     */
    private function test_gateway_webhook(string $gateway, float $amount, string $transaction_id): array {
        $webhook_url = get_option('vrstore_test_webhook_url', '');
        
        if (empty($webhook_url)) {
            return [
                'success' => false,
                'message' => __('Test webhook URL not configured.', 'vira-store')
            ];
        }
        
        // Simulate webhook test
        $webhook_data = [
            'gateway' => $gateway,
            'transaction_id' => $transaction_id,
            'amount' => $amount,
            'status' => 'completed',
            'timestamp' => current_time('mysql')
        ];
        
        // In real implementation, this would send actual webhook
        return [
            'success' => true,
            'message' => sprintf(__('Webhook test sent to %s successfully.', 'vira-store'), $webhook_url),
            'webhook_data' => $webhook_data
        ];
    }

    /**
     * Log payment test result
     *
     * @param string $gateway Gateway tested
     * @param float $amount Test amount
     * @param string $test_type Test type
     * @param array $result Test result
     * @return void
     */
    private function log_payment_test(string $gateway, float $amount, string $test_type, array $result): void {
        $logs = get_option('vrstore_payment_test_logs', []);
        
        $log_entry = [
            'timestamp' => current_time('Y-m-d H:i:s'),
            'gateway' => $gateway,
            'amount' => $amount,
            'test_type' => $test_type,
            'status' => $result['success'] ? 'success' : 'error',
            'message' => $result['message'],
            'transaction_id' => $result['transaction_id'] ?? null
        ];
        
        // Add to beginning of array
        array_unshift($logs, $log_entry);
        
        // Keep only last 50 logs
        $logs = array_slice($logs, 0, 50);
        
        update_option('vrstore_payment_test_logs', $logs);
    }

    /**
     * AJAX handler for clearing payment test logs
     *
     * @return void
     */
    public function ajax_clear_payment_test_logs(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_admin_nonce')) {
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
        }

        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'vira-store')]);
        }

        // Clear the logs
        delete_option('vrstore_payment_test_logs');
        
        wp_send_json_success([
            'message' => __('Payment test logs cleared successfully.', 'vira-store')
        ]);
    }
    
    /**
     * AJAX handler for exporting download data as CSV
     *
     * @return void
     */
    public function ajax_export_downloads(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_export_downloads')) {
            wp_die(__('Security check failed.', 'vira-store'));
        }

        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_die(__('Permission denied.', 'vira-store'));
        }
        
        global $wpdb;
        $download_table = $wpdb->prefix . 'vrstore_download_tracking';
        
        // Build WHERE clause based on filters (same logic as reports page)
        $where_conditions = [];
        $prepare_values = [];
        
        if (!empty($_POST['date_from'])) {
            $where_conditions[] = "DATE(dt.download_date) >= %s";
            $prepare_values[] = sanitize_text_field($_POST['date_from']);
        }
        
        if (!empty($_POST['date_to'])) {
            $where_conditions[] = "DATE(dt.download_date) <= %s";
            $prepare_values[] = sanitize_text_field($_POST['date_to']);
        }
        
        if (!empty($_POST['download_type'])) {
            $where_conditions[] = "dt.download_type = %s";
            $prepare_values[] = sanitize_text_field($_POST['download_type']);
        }
        
        if (!empty($_POST['file_type'])) {
            $where_conditions[] = "dt.file_type = %s";
            $prepare_values[] = sanitize_text_field($_POST['file_type']);
        }
        
        if (!empty($_POST['product_id'])) {
            $where_conditions[] = "dt.product_id = %d";
            $prepare_values[] = intval($_POST['product_id']);
        }
        
        if (!empty($_POST['customer_email'])) {
            $where_conditions[] = "dt.customer_email LIKE %s";
            $prepare_values[] = '%' . $wpdb->esc_like(sanitize_email($_POST['customer_email'])) . '%';
        }
        
        if (!empty($_POST['ip_address'])) {
            $where_conditions[] = "dt.ip_address LIKE %s";
            $prepare_values[] = '%' . $wpdb->esc_like(sanitize_text_field($_POST['ip_address'])) . '%';
        }
        
        $where_clause = '';
        if (!empty($where_conditions)) {
            $where_clause = 'WHERE ' . implode(' AND ', $where_conditions);
        }
        
        // Query for export (no LIMIT)
        $query = "SELECT dt.*, p.post_title as product_title 
                  FROM $download_table dt 
                  LEFT JOIN {$wpdb->posts} p ON dt.product_id = p.ID 
                  $where_clause 
                  ORDER BY dt.download_date DESC";
        
        if (!empty($prepare_values)) {
            $downloads = $wpdb->get_results($wpdb->prepare($query, ...$prepare_values));
        } else {
            $downloads = $wpdb->get_results($query);
        }
        
        // Set headers for CSV download
        $filename = 'vrstore-downloads-' . date('Y-m-d-H-i-s') . '.csv';
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=' . $filename);
        header('Pragma: no-cache');
        header('Expires: 0');
        
        // Create file pointer
        $output = fopen('php://output', 'w');
        
        // Add UTF-8 BOM for proper Excel compatibility
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
        
        // CSV headers
        $headers = [
            __('Download Date', 'vira-store'),
            __('Product ID', 'vira-store'),
            __('Product Title', 'vira-store'),
            __('Order ID', 'vira-store'),
            __('Customer Name', 'vira-store'),
            __('Customer Email', 'vira-store'),
            __('File Name', 'vira-store'),
            __('File Type', 'vira-store'),
            __('File Size', 'vira-store'),
            __('Download Type', 'vira-store'),
            __('Download Process', 'vira-store'),
            __('IP Address', 'vira-store'),
            __('User Agent', 'vira-store'),
            __('User ID', 'vira-store')
        ];
        
        fputcsv($output, $headers);
        
        // Add data rows
        foreach ($downloads as $download) {
            $row = [
                $download->download_date,
                $download->product_id,
                $download->product_title ?: 'Unknown Product',
                $download->order_id,
                $download->customer_name ?: 'Guest',
                $download->customer_email ?: 'N/A',
                $download->file_name,
                ucfirst($download->file_type ?: 'unknown'),
                $download->file_size ? $this->format_file_size($download->file_size) : 'N/A',
                ucfirst($download->download_type ?: 'single'),
                ucfirst($download->download_process ?: 'immediate'),
                $download->ip_address ?: 'Unknown',
                $download->user_agent ?: 'Unknown',
                $download->user_id ?: 'Guest'
            ];
            
            fputcsv($output, $row);
        }
        
        fclose($output);
        exit;
    }
    
    /**
     * Format file size for CSV export
     *
     * @param int $bytes File size in bytes
     * @return string Formatted size
     */
    private function format_file_size(int $bytes): string {
        if ($bytes === 0) return '0 Bytes';
        
        $k = 1024;
        $sizes = ['Bytes', 'KB', 'MB', 'GB'];
        $i = floor(log($bytes) / log($k));
        
        return round($bytes / pow($k, $i), 2) . ' ' . $sizes[$i];
    }
    
    /**
     * AJAX handler for clearing all download tracking data
     *
     * @return void
     */
    public function ajax_clear_all_downloads(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_admin_nonce')) {
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
        }

        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'vira-store')]);
        }
        
        global $wpdb;
        $download_table = $wpdb->prefix . 'vrstore_download_tracking';
        $validation_table = $wpdb->prefix . 'vrstore_download_validation';
        
        try {
            // Clear download tracking data
            $deleted_downloads = $wpdb->query("TRUNCATE TABLE $download_table");
            
            // Clear validation data if table exists
            $validation_table_exists = $wpdb->get_var($wpdb->prepare(
                "SELECT table_name FROM information_schema.tables WHERE table_schema = %s AND table_name = %s",
                DB_NAME,
                $validation_table
            ));
            
            $deleted_validations = 0;
            if ($validation_table_exists) {
                $deleted_validations = $wpdb->query("TRUNCATE TABLE $validation_table");
            }
            
            wp_send_json_success([
                'message' => __('All download tracking data has been cleared successfully.', 'vira-store'),
                'deleted_downloads' => $deleted_downloads !== false ? true : false,
                'deleted_validations' => $deleted_validations !== false ? true : false
            ]);
            
        } catch (Exception $e) {
            wp_send_json_error([
                'message' => sprintf(
                    __('Error clearing download data: %s', 'vira-store'), 
                    $e->getMessage()
                )
            ]);
        }
    }
    
    /**
     * AJAX handler for getting detailed download information
     *
     * @return void
     */
    public function ajax_get_download_details(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_admin_nonce')) {
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
        }

        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'vira-store')]);
        }
        
        $product_id = intval($_POST['product_id'] ?? 0);
        $order_id = sanitize_text_field($_POST['order_id'] ?? '');
        $customer_email = sanitize_email($_POST['customer_email'] ?? '');
        
        // For Course materials, order_id can be 0, so we need to handle this case differently
        if (!$product_id || !$customer_email) {
            wp_send_json_error(['message' => __('Invalid parameters.', 'vira-store')]);
        }
        
        // Check if this is a Course by getting post type
        $post_type = get_post_type($product_id);
        $is_course = ($post_type === 'vrstore_course');
        
        // For courses, order_id can be 0 (free courses or legacy data) or actual order ID (paid courses)
        // For regular products, we require a valid order_id
        if (!$is_course && (!$order_id || $order_id === '0')) {
            wp_send_json_error(['message' => __('Invalid parameters.', 'vira-store')]);
        }
        
        global $wpdb;
        $download_table = $wpdb->prefix . 'vrstore_download_tracking';
        $orders_table = $wpdb->prefix . 'vrstore_orders';
        
        // Get detailed download information
        // For Course materials, we need to handle both cases: order_id = 0 (free courses) and actual order_id (paid courses)
        if ($is_course) {
            if ($order_id == '0') {
                // Handle free courses or course materials without orders
                $downloads = $wpdb->get_results($wpdb->prepare(
                    "SELECT dt.*, p.post_title as product_title, 
                            CASE WHEN dt.order_id > 0 THEN o.order_number ELSE '' END as order_number
                     FROM $download_table dt
                     LEFT JOIN {$wpdb->posts} p ON dt.product_id = p.ID
                     LEFT JOIN $orders_table o ON dt.order_id = o.id AND dt.order_id > 0
                     WHERE dt.product_id = %d AND dt.customer_email = %s
                     ORDER BY dt.download_date DESC",
                    $product_id,
                    $customer_email
                ));
            } else {
                // Handle specific course order
                $downloads = $wpdb->get_results($wpdb->prepare(
                    "SELECT dt.*, p.post_title as product_title, o.order_number
                     FROM $download_table dt
                     LEFT JOIN {$wpdb->posts} p ON dt.product_id = p.ID
                     LEFT JOIN $orders_table o ON dt.order_id = o.id
                     WHERE dt.product_id = %d AND dt.order_id = %s AND dt.customer_email = %s
                     ORDER BY dt.download_date DESC",
                    $product_id,
                    $order_id,
                    $customer_email
                ));
            }
        } else {
            // Regular product downloads
            $downloads = $wpdb->get_results($wpdb->prepare(
                "SELECT dt.*, p.post_title as product_title, o.order_number
                 FROM $download_table dt
                 LEFT JOIN {$wpdb->posts} p ON dt.product_id = p.ID
                 LEFT JOIN $orders_table o ON dt.order_id = o.id
                 WHERE dt.product_id = %d AND dt.order_id = %s AND dt.customer_email = %s
                 ORDER BY dt.download_date DESC",
                $product_id,
                $order_id,
                $customer_email
            ));
        }
        
        if (empty($downloads)) {
            wp_send_json_error(['message' => __('No download details found.', 'vira-store')]);
        }
        
        // Get product title for modal title
        $product_title = $downloads[0]->product_title ?: ($is_course ? __('Unknown Course', 'vira-store') : __('Unknown Product', 'vira-store'));
        
        // Handle order number display for Course materials vs Products
        if ($is_course) {
            if (!empty($downloads[0]->order_number)) {
                // Paid course with order number
                $order_number = '#' . $downloads[0]->order_number;
            } elseif ($downloads[0]->order_id && $downloads[0]->order_id > 0) {
                // Paid course without order number but with order ID
                $order_number = '#' . $downloads[0]->order_id;
            } else {
                // Free course or course material without order
                $order_number = __('Course Material', 'vira-store');
            }
        } else {
            $order_number = $downloads[0]->order_number ? '#' . $downloads[0]->order_number : '#' . $order_id;
        }
        
        $modal_title = sprintf(__('Download Details: %s (%s)', 'vira-store'), $product_title, $order_number);
        
        // Build HTML content
        ob_start();
        ?>
        <div class="download-details-summary">
            <h4><?php _e('Summary', 'vira-store'); ?></h4>
            <p>
                <strong><?php echo $is_course ? _e('Course:', 'vira-store') : _e('Product:', 'vira-store'); ?></strong> <?php echo esc_html($product_title); ?><br>
                <strong><?php echo ($is_course && $order_id == '0') ? _e('Type:', 'vira-store') : _e('Order ID:', 'vira-store'); ?></strong> <?php echo esc_html($order_number); ?><br>
                <strong><?php _e('Customer:', 'vira-store'); ?></strong> 
                <?php 
                // Handle customer name display for Course materials
                $customer_name = $downloads[0]->customer_name;
                if (empty($customer_name) || $customer_name === 'Guest') {
                    // Try to get the actual user name from email
                    $user = get_user_by('email', $customer_email);
                    if ($user) {
                        $customer_name = $user->display_name;
                    } else {
                        $customer_name = $is_course ? __('Course Student', 'vira-store') : __('Guest', 'vira-store');
                    }
                }
                echo esc_html($customer_name);
                ?> (<?php echo esc_html($customer_email); ?>)<br>
                <strong><?php _e('Total Downloads:', 'vira-store'); ?></strong> <?php echo count($downloads); ?>
            </p>
        </div>
        
        <h4><?php _e('Download History', 'vira-store'); ?></h4>
        <table class="download-details-table">
            <thead>
                <tr>
                    <th><?php _e('Date & Time', 'vira-store'); ?></th>
                    <th><?php _e('File Name', 'vira-store'); ?></th>
                    <th><?php _e('File Type', 'vira-store'); ?></th>
                    <th><?php _e('Download Type', 'vira-store'); ?></th>
                    <th><?php _e('IP Address', 'vira-store'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($downloads as $download): ?>
                    <tr>
                        <td><?php echo esc_html(mysql2date('M j, Y g:i A', $download->download_date)); ?></td>
                        <td>
                            <?php echo esc_html($download->file_name); ?>
                            <?php if (!empty($download->file_size)): ?>
                                <br><small class="description"><?php echo esc_html($this->format_file_size($download->file_size)); ?></small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php 
                            $file_type = $download->file_type ?? 'unknown';
                            
                            // Special handling for certificate downloads
                            if ($file_type === 'certificate') {
                                $badge_class = 'file-type-certificate';
                                $display_type = __('Certificate', 'vira-store');
                            } else {
                                $badge_class = $file_type === 'upload' ? 'file-type-upload' : 'file-type-url';
                                $display_type = ucfirst($file_type);
                            }
                            ?>
                            <span class="file-type-badge <?php echo esc_attr($badge_class); ?>">
                                <?php echo esc_html($display_type); ?>
                            </span>
                        </td>
                        <td>
                            <?php 
                            $download_type = $download->download_type ?? 'single';
                            $process = $download->download_process ?? 'immediate';
                            ?>
                            <strong><?php echo esc_html(ucfirst($download_type)); ?></strong>
                            <br><small class="description"><?php echo esc_html(ucfirst($process)); ?></small>
                        </td>
                        <td><?php echo esc_html($download->ip_address ?: 'Unknown'); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php
        $html_content = ob_get_clean();
        
        wp_send_json_success([
            'title' => $modal_title,
            'html' => $html_content
        ]);
    }
    
    /**
     * AJAX handler for getting customer tickets
     *
     * @return void
     */
    public function ajax_get_customer_tickets(): void {
        // Verify nonce - try multiple nonce names for compatibility
        $nonce = $_POST['nonce'] ?? '';
        $nonce_valid = wp_verify_nonce($nonce, 'vrstore_admin_nonce') || 
                      wp_verify_nonce($nonce, 'vrstore_admin_action') ||
                      wp_verify_nonce($nonce, 'vrstore_frontend_nonce');
        
        if (!$nonce_valid) {
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
        }

        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'vira-store')]);
        }
        
        $customer_id = intval($_POST['customer_id'] ?? 0);
        if (!$customer_id) {
            wp_send_json_error(['message' => __('Invalid customer ID.', 'vira-store')]);
        }
        
        global $wpdb;
        $tickets_table = $wpdb->prefix . 'vrstore_support_tickets';
        $orders_table = $wpdb->prefix . 'vrstore_orders';
        
        // Check if table exists, create if it doesn't
        if ($wpdb->get_var("SHOW TABLES LIKE '$tickets_table'") != $tickets_table) {
            if (class_exists('VRSTORE_Database')) {
                $db = VRSTORE_Database::get_instance();
                $db->check_database_version();
            }
        }
        
        // If table still doesn't exist, return empty result
        if ($wpdb->get_var("SHOW TABLES LIKE '$tickets_table'") != $tickets_table) {
            wp_send_json_success([
                'title' => __('Support Tickets - No Table', 'vira-store'),
                'html' => '<div class="vrstore-empty-state"><p>' . __('Support tickets database table does not exist. Please contact administrator.', 'vira-store') . '</p></div>'
            ]);
            return;
        }
        
        // Get all tickets for this customer
        $tickets = $wpdb->get_results($wpdb->prepare(
            "SELECT st.*, p.post_title as product_title, o.order_number
             FROM $tickets_table st
             LEFT JOIN {$wpdb->posts} p ON st.product_id = p.ID
             LEFT JOIN $orders_table o ON st.order_id = o.id
             WHERE st.customer_id = %d
             ORDER BY st.created_at DESC",
            $customer_id
        ));
        
        // Get customer info
        $customer = get_userdata($customer_id);
        
        ob_start();
        ?>
        <div class="vrstore-tickets-list">
            <?php if (empty($tickets)): ?>
                <div class="vrstore-empty-state">
                    <p><?php _e('This customer has no support tickets yet.', 'vira-store'); ?></p>
                </div>
            <?php else: ?>
                <div class="vrstore-tickets-summary">
                    <p><strong><?php echo esc_html($customer->display_name); ?></strong> (<?php echo esc_html($customer->user_email); ?>)</p>
                    <p><?php printf(_n('%d support ticket', '%d support tickets', count($tickets), 'vira-store'), count($tickets)); ?></p>
                </div>
                
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php _e('Ticket #', 'vira-store'); ?></th>
                            <th><?php _e('Subject', 'vira-store'); ?></th>
                            <th><?php _e('Product', 'vira-store'); ?></th>
                            <th><?php _e('Status', 'vira-store'); ?></th>
                            <th><?php _e('Priority', 'vira-store'); ?></th>
                            <th><?php _e('Last Reply', 'vira-store'); ?></th>
                            <th><?php _e('Actions', 'vira-store'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($tickets as $ticket): ?>
                            <?php 
                            $status_class = 'ticket-status-' . $ticket->status;
                            $priority_class = 'ticket-priority-' . $ticket->priority;
                            ?>
                            <tr>
                                <td><strong><?php echo esc_html($ticket->ticket_number); ?></strong></td>
                                <td>
                                    <strong><?php echo esc_html($ticket->subject); ?></strong>
                                    <?php if ($ticket->admin_unread_count > 0): ?>
                                        <span class="vrstore-unread-badge"><?php echo esc_html($ticket->admin_unread_count); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo esc_html($ticket->product_title ?: 'General'); ?></td>
                                <td>
                                    <span class="vrstore-status-badge <?php echo esc_attr($status_class); ?>">
                                        <?php echo esc_html(ucfirst($ticket->status)); ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="vrstore-priority-badge <?php echo esc_attr($priority_class); ?>">
                                        <?php echo esc_html(ucfirst($ticket->priority)); ?>
                                    </span>
                                </td>
                                <td><?php echo esc_html(mysql2date('M j, Y g:i A', $ticket->last_reply_at)); ?></td>
                                <td>
                                    <button type="button" class="button button-small vrstore-view-ticket-details" 
                                            data-ticket-id="<?php echo esc_attr($ticket->id); ?>">
                                        <?php _e('View', 'vira-store'); ?>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        <?php
        $html_content = ob_get_clean();
        
        $customer_name = $customer ? $customer->display_name : __('Unknown Customer', 'vira-store');
        
        wp_send_json_success([
            'title' => sprintf(__('Support Tickets - %s', 'vira-store'), $customer_name),
            'html' => $html_content
        ]);
    }
    
    /**
     * AJAX handler for getting ticket details
     *
     * @return void
     */
    public function ajax_get_ticket_details(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_admin_nonce')) {
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
        }

        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'vira-store')]);
        }
        
        $ticket_id = intval($_POST['ticket_id'] ?? 0);
        if (!$ticket_id) {
            wp_send_json_error(['message' => __('Invalid ticket ID.', 'vira-store')]);
        }
        
        global $wpdb;
        $tickets_table = $wpdb->prefix . 'vrstore_support_tickets';
        $replies_table = $wpdb->prefix . 'vrstore_support_replies';
        
        // Get ticket details
        $ticket = $wpdb->get_row($wpdb->prepare(
            "SELECT st.*, p.post_title as product_title, o.order_number
             FROM $tickets_table st
             LEFT JOIN {$wpdb->posts} p ON st.product_id = p.ID
             LEFT JOIN {$wpdb->prefix}vrstore_orders o ON st.order_id = o.id
             WHERE st.id = %d",
            $ticket_id
        ));
        
        if (!$ticket) {
            wp_send_json_error(['message' => __('Ticket not found.', 'vira-store')]);
        }
        
        // Get all replies
        $replies = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $replies_table WHERE ticket_id = %d ORDER BY created_at ASC",
            $ticket_id
        ));
        
        // Mark admin unread messages as read
        $wpdb->update(
            $tickets_table,
            ['admin_unread_count' => 0],
            ['id' => $ticket_id],
            ['%d'],
            ['%d']
        );
        
        ob_start();
        ?>
        <div class="vrstore-ticket-details">
            <div class="ticket-header">
                <div class="ticket-meta">
                    <h3><?php echo esc_html($ticket->subject); ?></h3>
                    <div class="ticket-info">
                        <span><strong><?php _e('Ticket #:', 'vira-store'); ?></strong> <?php echo esc_html($ticket->ticket_number); ?></span>
                        <span><strong><?php _e('Product:', 'vira-store'); ?></strong> <?php echo esc_html($ticket->product_title ?: 'General'); ?></span>
                        <span><strong><?php _e('Created:', 'vira-store'); ?></strong> <?php echo esc_html(mysql2date('M j, Y g:i A', $ticket->created_at)); ?></span>
                    </div>
                    <div class="ticket-status-controls">
                        <label><?php _e('Status:', 'vira-store'); ?></label>
                        <select id="vrstore-ticket-status" data-ticket-id="<?php echo esc_attr($ticket->id); ?>">
                            <option value="open" <?php selected($ticket->status, 'open'); ?>><?php _e('Open', 'vira-store'); ?></option>
                            <option value="pending" <?php selected($ticket->status, 'pending'); ?>><?php _e('Pending', 'vira-store'); ?></option>
                            <option value="in_progress" <?php selected($ticket->status, 'in_progress'); ?>><?php _e('In Progress', 'vira-store'); ?></option>
                            <option value="resolved" <?php selected($ticket->status, 'resolved'); ?>><?php _e('Resolved', 'vira-store'); ?></option>
                            <option value="closed" <?php selected($ticket->status, 'closed'); ?>><?php _e('Closed', 'vira-store'); ?></option>
                        </select>
                        
                        <label><?php _e('Priority:', 'vira-store'); ?></label>
                        <select id="vrstore-ticket-priority" data-ticket-id="<?php echo esc_attr($ticket->id); ?>">
                            <option value="low" <?php selected($ticket->priority, 'low'); ?>><?php _e('Low', 'vira-store'); ?></option>
                            <option value="normal" <?php selected($ticket->priority, 'normal'); ?>><?php _e('Normal', 'vira-store'); ?></option>
                            <option value="high" <?php selected($ticket->priority, 'high'); ?>><?php _e('High', 'vira-store'); ?></option>
                            <option value="urgent" <?php selected($ticket->priority, 'urgent'); ?>><?php _e('Urgent', 'vira-store'); ?></option>
                        </select>
                    </div>
                </div>
            </div>
            
            <div class="ticket-conversation">
                <!-- Original ticket message -->
                <div class="ticket-message customer-message">
                    <div class="message-header">
                        <strong><?php echo esc_html($ticket->customer_name); ?></strong>
                        <span class="message-time"><?php echo esc_html(mysql2date('M j, Y g:i A', $ticket->created_at)); ?></span>
                        <span class="message-type customer-badge"><?php _e('Customer', 'vira-store'); ?></span>
                    </div>
                    <div class="message-content">
                        <?php echo wp_kses_post(wpautop($ticket->message)); ?>
                    </div>
                </div>
                
                <!-- Replies -->
                <?php foreach ($replies as $reply): ?>
                    <?php $is_admin = $reply->reply_by === 'admin'; ?>
                    <div class="ticket-message <?php echo $is_admin ? 'admin-message' : 'customer-message'; ?>">
                        <div class="message-header">
                            <strong><?php echo esc_html($reply->user_name ?: ($is_admin ? 'Support Agent' : 'Customer')); ?></strong>
                            <span class="message-time"><?php echo esc_html(mysql2date('M j, Y g:i A', $reply->created_at)); ?></span>
                            <span class="message-type <?php echo $is_admin ? 'admin-badge' : 'customer-badge'; ?>">
                                <?php echo $is_admin ? __('Support Agent', 'vira-store') : __('Customer', 'vira-store'); ?>
                            </span>
                        </div>
                        <div class="message-content">
                            <?php echo wp_kses_post(wpautop($reply->message)); ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <div class="ticket-reply-form">
                <h4><?php _e('Add Reply', 'vira-store'); ?></h4>
                <form id="vrstore-ticket-reply-form" data-ticket-id="<?php echo esc_attr($ticket->id); ?>">
                    <div class="form-group">
                        <label for="vrstore-reply-message"><?php _e('Your Reply:', 'vira-store'); ?></label>
                        <textarea id="vrstore-reply-message" name="message" rows="5" required placeholder="<?php esc_attr_e('Enter your response to the customer...', 'vira-store'); ?>"></textarea>
                    </div>
                    <div class="form-group">
                        <label>
                            <input type="checkbox" name="is_private" value="1"> 
                            <?php _e('Private note (not visible to customer)', 'vira-store'); ?>
                        </label>
                    </div>
                    <button type="submit" class="button button-primary"><?php _e('Send Reply', 'vira-store'); ?></button>
                </form>
            </div>
        </div>
        <?php
        $html_content = ob_get_clean();
        
        wp_send_json_success([
            'title' => sprintf(__('Ticket #%s - %s', 'vira-store'), $ticket->ticket_number, $ticket->subject),
            'html' => $html_content
        ]);
    }
    
    /**
     * AJAX handler for updating ticket status
     *
     * @return void
     */
    public function ajax_update_ticket_status(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_admin_nonce')) {
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
        }

        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'vira-store')]);
        }
        
        $ticket_id = intval($_POST['ticket_id'] ?? 0);
        $field = sanitize_text_field($_POST['field'] ?? '');
        $value = sanitize_text_field($_POST['value'] ?? '');
        
        if (!$ticket_id || !$field || !$value) {
            wp_send_json_error(['message' => __('Invalid parameters.', 'vira-store')]);
        }
        
        // Validate field
        if (!in_array($field, ['status', 'priority'])) {
            wp_send_json_error(['message' => __('Invalid field.', 'vira-store')]);
        }
        
        // Validate values
        $valid_statuses = ['open', 'pending', 'in_progress', 'resolved', 'closed'];
        $valid_priorities = ['low', 'normal', 'high', 'urgent'];
        
        if ($field === 'status' && !in_array($value, $valid_statuses)) {
            wp_send_json_error(['message' => __('Invalid status.', 'vira-store')]);
        }
        
        if ($field === 'priority' && !in_array($value, $valid_priorities)) {
            wp_send_json_error(['message' => __('Invalid priority.', 'vira-store')]);
        }
        
        global $wpdb;
        $tickets_table = $wpdb->prefix . 'vrstore_support_tickets';
        
        // Get old value for email notification
        $old_ticket = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $tickets_table WHERE id = %d",
            $ticket_id
        ), ARRAY_A);
        
        if (!$old_ticket) {
            wp_send_json_error(['message' => __('Ticket not found.', 'vira-store')]);
        }
        
        $old_value = $old_ticket[$field];
        
        $update_data = [$field => $value];
        
        // Add resolved/closed timestamps
        if ($field === 'status') {
            if ($value === 'resolved') {
                $update_data['resolved_at'] = current_time('mysql');
            } elseif ($value === 'closed') {
                $update_data['closed_at'] = current_time('mysql');
            }
        }
        
        $result = $wpdb->update(
            $tickets_table,
            $update_data,
            ['id' => $ticket_id],
            array_fill(0, count($update_data), '%s'),
            ['%d']
        );
        
        if ($result !== false) {
            // Trigger email notification for field changes
            if ($field === 'status') {
                do_action('vrstore_support_ticket_status_changed', $ticket_id, $old_value, $value);
            } elseif ($field === 'priority') {
                do_action('vrstore_support_ticket_priority_changed', $ticket_id, $old_value, $value);
            }
            
            wp_send_json_success([
                'message' => sprintf(__('Ticket %s updated successfully.', 'vira-store'), $field)
            ]);
        } else {
            wp_send_json_error(['message' => __('Failed to update ticket.', 'vira-store')]);
        }
    }
    
    /**
     * AJAX handler for adding ticket reply
     *
     * @return void
     */
    public function ajax_add_ticket_reply(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_admin_nonce')) {
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
        }

        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'vira-store')]);
        }
        
        $ticket_id = intval($_POST['ticket_id'] ?? 0);
        $message = wp_kses_post($_POST['message'] ?? '');
        $is_private = intval($_POST['is_private'] ?? 0);
        
        if (!$ticket_id || !$message) {
            wp_send_json_error(['message' => __('Invalid parameters.', 'vira-store')]);
        }
        
        $current_user = wp_get_current_user();
        
        global $wpdb;
        $tickets_table = $wpdb->prefix . 'vrstore_support_tickets';
        $replies_table = $wpdb->prefix . 'vrstore_support_replies';
        
        // Insert reply
        $reply_result = $wpdb->insert(
            $replies_table,
            [
                'ticket_id' => $ticket_id,
                'reply_by' => 'admin',
                'user_id' => $current_user->ID,
                'user_name' => $current_user->display_name,
                'user_email' => $current_user->user_email,
                'message' => $message,
                'is_private' => $is_private,
                'created_at' => current_time('mysql')
            ],
            ['%d', '%s', '%d', '%s', '%s', '%s', '%d', '%s']
        );
        
        if ($reply_result === false) {
            wp_send_json_error(['message' => __('Failed to add reply.', 'vira-store')]);
        }
        
        // Update ticket last reply info and customer unread count
        $update_result = $wpdb->update(
            $tickets_table,
            [
                'last_reply_by' => 'admin',
                'last_reply_at' => current_time('mysql'),
                'customer_unread_count' => $is_private ? 0 : 1 // Only increase if not private
            ],
            ['id' => $ticket_id],
            ['%s', '%s', '%d'],
            ['%d']
        );
        
        if ($update_result !== false) {
            // Get ticket data for email notification
            $ticket = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $tickets_table WHERE id = %d",
                $ticket_id
            ), ARRAY_A);
            
            // Prepare reply data for email notifications
            $reply_data = [
                'reply_by' => 'admin',
                'user_id' => $current_user->ID,
                'user_name' => $current_user->display_name,
                'user_email' => $current_user->user_email,
                'message' => $message,
                'is_private' => $is_private,
                'created_at' => current_time('mysql')
            ];
            
            // Trigger email notification for admin reply
            do_action('vrstore_support_ticket_reply_added', $ticket_id, $reply_data, $ticket);
            
            wp_send_json_success([
                'message' => __('Reply added successfully.', 'vira-store'),
                'reload_ticket' => true
            ]);
        } else {
            wp_send_json_error(['message' => __('Reply added but failed to update ticket.', 'vira-store')]);
        }
    }
    
    /**
     * Debug AJAX handler for testing support tickets
     *
     * @return void
     */
    public function ajax_debug_support(): void {
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'vira-store')]);
        }
        
        global $wpdb;
        $tickets_table = $wpdb->prefix . 'vrstore_support_tickets';
        
        $debug_info = [
            'ajax_working' => true,
            'current_user' => wp_get_current_user()->display_name,
            'table_exists' => ($wpdb->get_var("SHOW TABLES LIKE '$tickets_table'") == $tickets_table),
            'nonce_received' => !empty($_POST['nonce']),
            'post_data' => $_POST
        ];
        
        wp_send_json_success($debug_info);
    }
    
    /**
     * AJAX handler for exporting sales reports to CSV
     *
     * @return void
     */
    public function ajax_export_csv(): void {
        // Debug logging
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('CSV Export: AJAX handler called');
            error_log('CSV Export POST data: ' . print_r($_POST, true));
        }
        
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_admin_nonce')) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('CSV Export: Nonce verification failed');
            }
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
        }

        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'vira-store')]);
        }
        
        try {
            // Get date range from request
            $start_date = sanitize_text_field($_POST['start_date'] ?? date('Y-m-d', strtotime('-30 days')));
            $end_date = sanitize_text_field($_POST['end_date'] ?? date('Y-m-d'));
            
            // Validate dates
            if (!$this->validate_date($start_date) || !$this->validate_date($end_date)) {
                wp_send_json_error(['message' => __('Invalid date format.', 'vira-store')]);
            }
            
            // Get sales data for the specified date range
            $sales_data = $this->get_sales_data_for_export($start_date, $end_date);
            
            if (empty($sales_data)) {
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log('Sales Export Debug: No sales data found for date range: ' . $start_date . ' to ' . $end_date);
                }
                wp_send_json_error([
                    'message' => sprintf(
                        __('No sales data found for the selected date range (%s to %s). Please select a different date range or ensure there are orders in the system.', 'vira-store'),
                        $start_date, 
                        $end_date
                    )
                ]);
            }
            
            // Create CSV data
            $csv_data = $this->format_sales_data_for_csv($sales_data, $start_date, $end_date);
            
            // Generate a unique filename
            $filename = 'virastore-sales-report-' . $start_date . '-to-' . $end_date . '-' . date('Y-m-d-H-i-s') . '.csv';
            
            // Create temporary file
            $temp_file = wp_tempnam($filename);
            if (!$temp_file) {
                wp_send_json_error(['message' => __('Failed to create temporary file.', 'vira-store')]);
            }
            
            // Write CSV data to temporary file
            if (file_put_contents($temp_file, $csv_data) === false) {
                wp_send_json_error(['message' => __('Failed to write export data.', 'vira-store')]);
            }
            
            // Generate download URL
            $upload_dir = wp_upload_dir();
            $export_dir = $upload_dir['basedir'] . '/virastore-exports/';
            
            // Create export directory if it doesn't exist
            if (!file_exists($export_dir)) {
                wp_mkdir_p($export_dir);
            }
            
            // Move temp file to export directory
            $export_file = $export_dir . $filename;
            if (!rename($temp_file, $export_file)) {
                wp_send_json_error(['message' => __('Failed to save export file.', 'vira-store')]);
            }
            
            // Generate download URL
            $download_url = $upload_dir['baseurl'] . '/virastore-exports/' . $filename;
            
            wp_send_json_success([
                'message' => __('Sales report exported successfully!', 'vira-store'),
                'download_url' => $download_url,
                'filename' => $filename,
                'records_count' => count($sales_data),
                'date_range' => sprintf(__('From %s to %s', 'vira-store'), $start_date, $end_date)
            ]);
            
        } catch (Exception $e) {
            wp_send_json_error([
                'message' => __('An error occurred while exporting CSV.', 'vira-store'),
                'debug' => WP_DEBUG ? $e->getMessage() : null
            ]);
        }
    }
    
    /**
     * Validate date format
     *
     * @param string $date Date string to validate
     * @return bool
     */
    private function validate_date(string $date): bool {
        $d = DateTime::createFromFormat('Y-m-d', $date);
        return $d && $d->format('Y-m-d') === $date;
    }
    
    /**
     * Get sales data for export
     *
     * @param string $date_from Start date
     * @param string $date_to End date
     * @return array
     */
    private function get_sales_data_for_export(string $date_from, string $date_to): array {
        global $wpdb;
        $orders_table = $wpdb->prefix . 'vrstore_orders';
        
        // Debug logging
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Sales Export Debug: Date range: ' . $date_from . ' to ' . $date_to);
            error_log('Sales Export Debug: Orders table: ' . $orders_table);
            
            // Check if orders table exists
            $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$orders_table'") == $orders_table;
            error_log('Sales Export Debug: Orders table exists: ' . ($table_exists ? 'Yes' : 'No'));
            
            if ($table_exists) {
                // Check total orders count
                $total_orders = $wpdb->get_var("SELECT COUNT(*) FROM $orders_table");
                error_log('Sales Export Debug: Total orders in database: ' . $total_orders);
            }
        }
        
        $query = $wpdb->prepare(
            "SELECT 
                o.id,
                o.order_number,
                o.customer_name,
                o.customer_email,
                o.product_name,
                o.license_type,
                o.product_price as amount,
                o.payment_method,
                o.payment_status,
                o.order_status,
                o.created_at,
                p.post_title as product_title
            FROM $orders_table o
            LEFT JOIN {$wpdb->posts} p ON o.product_id = p.ID
            WHERE DATE(o.created_at) >= %s 
            AND DATE(o.created_at) <= %s
            ORDER BY o.created_at DESC",
            $date_from,
            $date_to
        );
        
        // Debug logging
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Sales Export Debug: Query: ' . $query);
        }
        
        $results = $wpdb->get_results($query, ARRAY_A);
        
        // Debug logging
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Sales Export Debug: Query returned ' . (is_array($results) ? count($results) : 0) . ' results');
            if ($wpdb->last_error) {
                error_log('Sales Export Debug: Database error: ' . $wpdb->last_error);
            }
            if (empty($results)) {
                // Check if there are any orders in the date range without JOIN
                $simple_count = $wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM $orders_table WHERE DATE(created_at) >= %s AND DATE(created_at) <= %s",
                    $date_from,
                    $date_to
                ));
                error_log('Sales Export Debug: Simple count in date range: ' . $simple_count);
            }
        }
        
        return $results ?: [];
    }
    
    /**
     * Format sales data for CSV export
     *
     * @param array $sales_data Sales data array
     * @param string $date_from Start date
     * @param string $date_to End date
     * @return string CSV formatted data
     */
    private function format_sales_data_for_csv(array $sales_data, string $date_from, string $date_to): string {
        $csv_lines = [];
        
        // Add header with export info
        $csv_lines[] = '"ViraStore Sales Report"';
        $csv_lines[] = '"Export Date: ' . date('Y-m-d H:i:s') . '"';
        $csv_lines[] = '"Date Range: ' . $date_from . ' to ' . $date_to . '"';
        $csv_lines[] = '"Total Records: ' . count($sales_data) . '"';
        $csv_lines[] = ''; // Empty line
        
        // Add column headers
        $headers = [
            'Order ID',
            'Order Number', 
            'Customer Name',
            'Customer Email',
            'Product Name',
            'License Type',
            'Amount',
            'Payment Method',
            'Payment Status',
            'Order Status',
            'Order Date',
            'Order Time'
        ];
        
        $csv_lines[] = '"' . implode('","', $headers) . '"';
        
        // Add data rows
        foreach ($sales_data as $row) {
            $order_date = new DateTime($row['created_at']);
            
            $data_row = [
                $row['id'],
                $row['order_number'] ?: 'N/A',
                $row['customer_name'] ?: 'N/A',
                $row['customer_email'] ?: 'N/A',
                $row['product_title'] ?: $row['product_name'] ?: 'N/A',
                $row['license_type'] ?: 'N/A',
                number_format((float)$row['amount'], 2),
                ucfirst($row['payment_method'] ?: 'N/A'),
                ucfirst($row['payment_status'] ?: 'N/A'),
                ucfirst($row['order_status'] ?: 'N/A'),
                $order_date->format('Y-m-d'),
                $order_date->format('H:i:s')
            ];
            
            // Escape and quote each field
            $escaped_row = array_map(function($field) {
                return '"' . str_replace('"', '""', $field) . '"';
            }, $data_row);
            
            $csv_lines[] = implode(',', $escaped_row);
        }
        
        // Add summary at the end
        $total_amount = array_sum(array_column($sales_data, 'amount'));
        $csv_lines[] = ''; // Empty line
        $csv_lines[] = '"Summary"';
        $csv_lines[] = '"Total Orders: ' . count($sales_data) . '"';
        $csv_lines[] = '"Total Amount: ' . number_format($total_amount, 2) . '"';
        
        return implode("\n", $csv_lines);
    }
    
    /**
     * AJAX handler for exporting customers to CSV
     *
     * @return void
     */
    public function ajax_export_customers_csv(): void {
        // Debug logging
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Customer CSV Export: AJAX handler called');
            error_log('Customer CSV Export POST data: ' . print_r($_POST, true));
        }
        
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_admin_nonce')) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Customer CSV Export: Nonce verification failed');
            }
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
        }

        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'vira-store')]);
        }
        
        try {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Customer CSV Export: About to get customer data');
            }
            
            // Get customer data for export
            $customers_data = $this->get_customers_data_for_export();
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Customer CSV Export: Got customer data, count: ' . (is_array($customers_data) ? count($customers_data) : 0));
            }
            
            if (empty($customers_data)) {
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log('Customer CSV Export: No customer data found');
                }
                wp_send_json_error(['message' => __('No customer data found.', 'vira-store')]);
            }
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Customer CSV Export: About to format CSV data');
            }
            
            // Create CSV data
            $csv_data = $this->format_customers_data_for_csv($customers_data);
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Customer CSV Export: CSV data formatted, length: ' . strlen($csv_data));
            }
            
            // Generate a unique filename
            $filename = 'virastore-customers-export-' . date('Y-m-d-H-i-s') . '.csv';
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Customer CSV Export: About to create temp file: ' . $filename);
            }
            
            // Create temporary file
            $temp_file = wp_tempnam($filename);
            if (!$temp_file) {
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log('Customer CSV Export: Failed to create temp file');
                }
                wp_send_json_error(['message' => __('Failed to create temporary file.', 'vira-store')]);
            }
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Customer CSV Export: Created temp file: ' . $temp_file);
            }
            
            // Write CSV data to temporary file
            if (file_put_contents($temp_file, $csv_data) === false) {
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log('Customer CSV Export: Failed to write to temp file');
                }
                wp_send_json_error(['message' => __('Failed to write export data.', 'vira-store')]);
            }
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Customer CSV Export: Written data to temp file');
            }
            
            // Generate download URL
            $upload_dir = wp_upload_dir();
            $export_dir = $upload_dir['basedir'] . '/virastore-exports/';
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Customer CSV Export: Export directory: ' . $export_dir);
            }
            
            // Create export directory if it doesn't exist
            if (!file_exists($export_dir)) {
                wp_mkdir_p($export_dir);
            }
            
            // Move temp file to export directory
            $export_file = $export_dir . $filename;
            if (!rename($temp_file, $export_file)) {
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log('Customer CSV Export: Failed to move temp file to export dir');
                }
                wp_send_json_error(['message' => __('Failed to save export file.', 'vira-store')]);
            }
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Customer CSV Export: Moved file to export directory');
            }
            
            // Generate download URL
            $download_url = $upload_dir['baseurl'] . '/virastore-exports/' . $filename;
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Customer CSV Export: Success! Download URL: ' . $download_url);
            }
            
            wp_send_json_success([
                'message' => __('Customer list exported successfully!', 'vira-store'),
                'download_url' => $download_url,
                'filename' => $filename,
                'records_count' => count($customers_data)
            ]);
            
        } catch (Exception $e) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Customer CSV Export Exception: ' . $e->getMessage());
                error_log('Customer CSV Export Exception trace: ' . $e->getTraceAsString());
            }
            wp_send_json_error([
                'message' => __('An error occurred while exporting customers CSV.', 'vira-store'),
                'debug' => WP_DEBUG ? $e->getMessage() : null
            ]);
        } catch (Error $e) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Customer CSV Export Fatal Error: ' . $e->getMessage());
                error_log('Customer CSV Export Error trace: ' . $e->getTraceAsString());
            }
            wp_send_json_error([
                'message' => __('A fatal error occurred while exporting customers CSV.', 'vira-store'),
                'debug' => WP_DEBUG ? $e->getMessage() : null
            ]);
        }
    }
    
    /**
     * Get customers data for export
     *
     * @return array
     */
    private function get_customers_data_for_export(): array {
        // Debug logging
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Customer Export Debug: Starting customer data export - using direct approach');
        }
        
        // Use direct WordPress user query for reliability
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Customer Export Debug: Getting WordPress users directly');
        }
        
        $wp_users = get_users([
            'number' => 9999,
            'orderby' => 'registered',
            'order' => 'DESC'
        ]);
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Customer Export Debug: Found ' . count($wp_users) . ' WordPress users');
        }
        
        $export_data = [];
        foreach ($wp_users as $user) {
            $export_data[] = [
                'id' => $user->ID,
                'username' => $user->user_login,
                'email' => $user->user_email,
                'display_name' => $user->display_name,
                'first_name' => get_user_meta($user->ID, 'first_name', true),
                'last_name' => get_user_meta($user->ID, 'last_name', true),
                'status' => 'active',
                'total_orders' => 0,
                'total_spent' => 0,
                'total_licenses' => 0,
                'active_licenses' => 0,
                'registered_date' => $user->user_registered,
                'last_order_date' => 'N/A'
            ];
        }
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Customer Export Debug: Processed ' . count($export_data) . ' users for export');
        }
        
        return $export_data;
    }
    
    /**
     * Format customers data for CSV export
     *
     * @param array $customers_data Customer data array
     * @return string CSV formatted data
     */
    private function format_customers_data_for_csv(array $customers_data): string {
        $csv_lines = [];
        
        // Add header with export info
        $csv_lines[] = '"ViraStore Customer Export"';
        $csv_lines[] = '"Generated on: ' . date('Y-m-d H:i:s') . '"';
        $csv_lines[] = '"Total Customers: ' . count($customers_data) . '"';
        $csv_lines[] = ''; // Empty line
        
        // Add column headers
        $headers = [
            'Customer ID',
            'Username', 
            'Email',
            'Display Name',
            'First Name',
            'Last Name',
            'Status',
            'Total Orders',
            'Total Spent',
            'Total Licenses',
            'Active Licenses',
            'Registration Date',
            'Last Order Date'
        ];
        
        $csv_lines[] = '"' . implode('","', $headers) . '"';
        
        // Add customer data rows
        foreach ($customers_data as $customer) {
            $data_row = [
                $customer['id'],
                $customer['username'],
                $customer['email'],
                $customer['display_name'],
                $customer['first_name'],
                $customer['last_name'],
                ucfirst($customer['status']),
                $customer['total_orders'],
                number_format($customer['total_spent'], 2),
                $customer['total_licenses'],
                $customer['active_licenses'],
                date('Y-m-d H:i:s', strtotime($customer['registered_date'])),
                $customer['last_order_date'] !== 'N/A' ? date('Y-m-d H:i:s', strtotime($customer['last_order_date'])) : 'N/A'
            ];
            
            // Escape and quote each field
            $escaped_row = array_map(function($field) {
                return '"' . str_replace('"', '""', $field) . '"';
            }, $data_row);
            
            $csv_lines[] = implode(',', $escaped_row);
        }
        
        // Add summary at the end
        $total_spent = array_sum(array_column($customers_data, 'total_spent'));
        $total_orders = array_sum(array_column($customers_data, 'total_orders'));
        $active_customers = count(array_filter($customers_data, function($c) { return $c['status'] === 'active'; }));
        
        $csv_lines[] = ''; // Empty line
        $csv_lines[] = '"Summary"';
        $csv_lines[] = '"Total Customers: ' . count($customers_data) . '"';
        $csv_lines[] = '"Active Customers: ' . $active_customers . '"';
        $csv_lines[] = '"Total Orders: ' . $total_orders . '"';
        $csv_lines[] = '"Total Revenue: ' . number_format($total_spent, 2) . '"';
        
        return implode("\n", $csv_lines);
    }

    /**
     * AJAX handler for exporting orders to CSV
     *
     * @return void
     */
    public function ajax_export_orders_csv(): void {
        // Debug logging
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Orders CSV Export: AJAX handler called');
            error_log('Orders CSV Export POST data: ' . print_r($_POST, true));
        }
        
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_admin_nonce')) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Orders CSV Export: Nonce verification failed');
            }
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
        }

        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'vira-store')]);
        }
        
        try {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Orders CSV Export: About to get orders data');
            }
            
            // Get orders data for export
            $orders_data = $this->get_orders_data_for_export();
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Orders CSV Export: Got orders data, count: ' . (is_array($orders_data) ? count($orders_data) : 0));
            }
            
            if (empty($orders_data)) {
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log('Orders CSV Export: No orders data found');
                }
                wp_send_json_error(['message' => __('No orders data found.', 'vira-store')]);
            }
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Orders CSV Export: About to format CSV data');
            }
            
            // Create CSV data
            $csv_data = $this->format_orders_data_for_csv($orders_data);
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Orders CSV Export: CSV data formatted, length: ' . strlen($csv_data));
            }
            
            // Generate a unique filename
            $filename = 'virastore-orders-export-' . date('Y-m-d-H-i-s') . '.csv';
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Orders CSV Export: About to create temp file: ' . $filename);
            }
            
            // Create temporary file with proper CSV extension
            $temp_dir = sys_get_temp_dir();
            $temp_file = $temp_dir . DIRECTORY_SEPARATOR . $filename;
            
            // Write CSV data to file
            if (file_put_contents($temp_file, $csv_data) === false) {
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log('Orders CSV Export: Failed to write to temp file');
                }
                wp_send_json_error(['message' => __('Failed to write CSV data.', 'vira-store')]);
            }
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Orders CSV Export: Successfully created CSV file: ' . $temp_file);
            }
            
            // Return success with download URL
            wp_send_json_success([
                'message' => __('Orders exported successfully.', 'vira-store'),
                'download_url' => admin_url('admin-ajax.php?action=vrstore_download_csv&file=' . urlencode($filename) . '&nonce=' . wp_create_nonce('vrstore_download_csv')),
                'filename' => $filename
            ]);
            
        } catch (Exception $e) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Orders CSV Export Error: ' . $e->getMessage());
            }
            wp_send_json_error(['message' => __('Export failed: ', 'vira-store') . $e->getMessage()]);
        }
    }

    /**
     * Get orders data for CSV export
     *
     * @return array
     */
    private function get_orders_data_for_export(): array {
        global $wpdb;
        
        $orders_table = $wpdb->prefix . 'vrstore_orders';
        
        // Check if table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$orders_table'") != $orders_table) {
            return [];
        }
        
        // Get all orders with related data
        $query = "
            SELECT 
                o.*,
                u.display_name as customer_name,
                u.user_email as customer_email,
                p.post_title as product_name
            FROM $orders_table o
            LEFT JOIN {$wpdb->users} u ON o.customer_id = u.ID
            LEFT JOIN {$wpdb->posts} p ON o.product_id = p.ID
            ORDER BY o.created_at DESC
        ";
        
        $results = $wpdb->get_results($query, ARRAY_A);
        
        if (!$results) {
            return [];
        }
        
        return $results;
    }

    /**
     * Format orders data for CSV export
     *
     * @param array $orders_data
     * @return string
     */
    private function format_orders_data_for_csv(array $orders_data): string {
        $csv_lines = [];
        
        // Add CSV headers
        $headers = [
            __('Order Number', 'vira-store'),
            __('Customer Name', 'vira-store'),
            __('Customer Email', 'vira-store'),
            __('Product', 'vira-store'),
            __('Amount', 'vira-store'),
            __('Currency', 'vira-store'),
            __('Payment Method', 'vira-store'),
            __('Payment Status', 'vira-store'),
            __('Order Status', 'vira-store'),
            __('Transaction ID', 'vira-store'),
            __('License Key', 'vira-store'),
            __('Date Created', 'vira-store'),
            __('Date Updated', 'vira-store')
        ];
        
        $csv_lines[] = '"' . implode('","', $headers) . '"';
        
        // Add order data
        foreach ($orders_data as $order) {
            $row = [
                $order['order_number'] ?? '',
                $order['customer_name'] ?? $order['customer_email'] ?? '',
                $order['customer_email'] ?? '',
                $order['product_name'] ?? '',
                number_format((float)($order['product_price'] ?? 0), 2),
                $order['currency'] ?? '',
                $order['payment_method'] ?? '',
                $order['payment_status'] ?? '',
                $order['order_status'] ?? '',
                $order['transaction_id'] ?? '',
                $order['license_key'] ?? '',
                $order['created_at'] ?? '',
                $order['updated_at'] ?? ''
            ];
            
            // Escape and quote each field
            $escaped_row = array_map(function($field) {
                return '"' . str_replace('"', '""', $field) . '"';
            }, $row);
            
            $csv_lines[] = implode(',', $escaped_row);
        }
        
        return implode("\n", $csv_lines);
    }
    
    /**
     * AJAX handler for downloading CSV files
     *
     * @return void
     */
    public function ajax_download_csv(): void {
        // Verify nonce
        if (!wp_verify_nonce($_GET['nonce'] ?? '', 'vrstore_download_csv')) {
            wp_die(__('Security check failed.', 'vira-store'));
        }

        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_die(__('Permission denied.', 'vira-store'));
        }
        
        $filename = sanitize_file_name($_GET['file'] ?? '');
        if (empty($filename)) {
            wp_die(__('Invalid file specified.', 'vira-store'));
        }
        
        // Get the temp file path
        $temp_file = sys_get_temp_dir() . DIRECTORY_SEPARATOR . $filename;
        
        if (!file_exists($temp_file)) {
            wp_die(__('File not found or has expired.', 'vira-store'));
        }
        
        // Set headers for download
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . filesize($temp_file));
        header('Pragma: no-cache');
        header('Expires: 0');
        
        // Output file contents
        readfile($temp_file);
        
        // Clean up temp file
        unlink($temp_file);
        
        exit;
    }

    /**
     * AJAX handler for resetting course data
     *
     * @return void
     */
    public function ajax_reset_course_data(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_admin_nonce')) {
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
        }

        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'vira-store')]);
        }

        $reset_options = $_POST['reset_options'] ?? [];
        
        if (empty($reset_options) || !is_array($reset_options)) {
            wp_send_json_error(['message' => __('No reset options selected.', 'vira-store')]);
        }

        global $wpdb;
        $results = [];
        $errors = [];

        try {
            // Reset course analytics (including video engagement analytics)
            if (in_array('analytics', $reset_options)) {
                // Check if course analytics table exists before deleting
                $table_name = $wpdb->prefix . 'vrstore_course_analytics';
                if ($this->table_exists($table_name)) {
                    $analytics_deleted = $wpdb->query("DELETE FROM {$table_name}");
                    $results[] = sprintf(__('Deleted %d course analytics records.', 'vira-store'), $analytics_deleted);
                } else {
                    $results[] = __('Course analytics table does not exist - skipped.', 'vira-store');
                }
                
                // Check if video analytics table exists before deleting
                $video_table_name = $wpdb->prefix . 'vrstore_video_analytics';
                if ($this->table_exists($video_table_name)) {
                    $video_analytics_deleted = $wpdb->query("DELETE FROM {$video_table_name}");
                    if ($video_analytics_deleted > 0) {
                        $results[] = sprintf(__('Deleted %d video engagement analytics records.', 'vira-store'), $video_analytics_deleted);
                    }
                } else {
                    $results[] = __('Video analytics table does not exist - skipped.', 'vira-store');
                }
                
                // Check if content analytics table exists before deleting
                $content_table_name = $wpdb->prefix . 'vrstore_content_analytics';
                if ($this->table_exists($content_table_name)) {
                    $content_analytics_deleted = $wpdb->query("DELETE FROM {$content_table_name}");
                    if ($content_analytics_deleted > 0) {
                        $results[] = sprintf(__('Deleted %d top performing content analytics records.', 'vira-store'), $content_analytics_deleted);
                    }
                } else {
                    $results[] = __('Content analytics table does not exist - skipped.', 'vira-store');
                }
                
                // Clear analytics-related cache and transients
                $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_vrstore_analytics_%'");
                $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_vrstore_analytics_%'");
                $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '%video_engagement_%'");
                $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '%top_performing_content_%'");
                $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '%course_analytics_cache_%'");
            }

            // Reset student progress
            if (in_array('progress', $reset_options)) {
                $progress_table_name = $wpdb->prefix . 'vrstore_student_progress';
                if ($this->table_exists($progress_table_name)) {
                    $progress_deleted = $wpdb->query("DELETE FROM {$progress_table_name}");
                    $results[] = sprintf(__('Deleted %d student progress records.', 'vira-store'), $progress_deleted);
                } else {
                    $results[] = __('Student progress table does not exist - skipped.', 'vira-store');
                }
            }

            // Reset course enrollments
            if (in_array('enrollments', $reset_options)) {
                $enrollments_table_name = $wpdb->prefix . 'vrstore_course_enrollments';
                if ($this->table_exists($enrollments_table_name)) {
                    $enrollments_deleted = $wpdb->query("DELETE FROM {$enrollments_table_name}");
                    $results[] = sprintf(__('Deleted %d course enrollment records.', 'vira-store'), $enrollments_deleted);
                } else {
                    $results[] = __('Course enrollments table does not exist - skipped.', 'vira-store');
                }
            }

            // Reset video tracking data and video engagement analytics
            if (in_array('video_tracking', $reset_options)) {
                // Check if video tracking table exists before deleting
                $video_tracking_table_name = $wpdb->prefix . 'vrstore_video_tracking';
                if ($this->table_exists($video_tracking_table_name)) {
                    $video_deleted = $wpdb->query("DELETE FROM {$video_tracking_table_name}");
                    $results[] = sprintf(__('Deleted %d video tracking records.', 'vira-store'), $video_deleted);
                } else {
                    $results[] = __('Video tracking table does not exist - skipped.', 'vira-store');
                }
                
                // Check if video analytics table exists before deleting
                $video_analytics_table_name = $wpdb->prefix . 'vrstore_video_analytics';
                if ($this->table_exists($video_analytics_table_name)) {
                    $video_analytics_deleted = $wpdb->query("DELETE FROM {$video_analytics_table_name}");
                    if ($video_analytics_deleted > 0) {
                        $results[] = sprintf(__('Deleted %d video engagement analytics records.', 'vira-store'), $video_analytics_deleted);
                    }
                } else {
                    $results[] = __('Video analytics table does not exist - skipped.', 'vira-store');
                }
                
                // Clear video analytics cache and transients
                $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_vrstore_video_analytics_%'");
                $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_vrstore_video_analytics_%'");
                $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '%video_engagement_%'");
                $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '%top_performing_content_%'");
            }

            // Clear related caches
            wp_cache_flush();
            
            // Clear any transients related to course data
            $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_vrstore_course_%'");
            $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_vrstore_course_%'");

            wp_send_json_success([
                'message' => __('Course data reset completed successfully.', 'vira-store'),
                'details' => $results
            ]);

        } catch (Exception $e) {
            wp_send_json_error([
                'message' => __('An error occurred while resetting course data.', 'vira-store'),
                'error' => $e->getMessage()
            ]);
        }
    }

    /**
     * Check if a database table exists
     *
     * @param string $table_name The table name to check
     * @return bool True if table exists, false otherwise
     */
    private function table_exists(string $table_name): bool {
        global $wpdb;
        
        $query = $wpdb->prepare("SHOW TABLES LIKE %s", $table_name);
        $result = $wpdb->get_var($query);
        
        return $result === $table_name;
    }
    
    /**
     * Handle AJAX request for courses CSV export
     *
     * @return void
     */
    public function ajax_export_courses_csv(): void {
        // Debug logging
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Courses CSV Export: AJAX handler called');
            error_log('Courses CSV Export POST data: ' . print_r($_POST, true));
            error_log('Courses CSV Export REQUEST_METHOD: ' . $_SERVER['REQUEST_METHOD']);
            error_log('Courses CSV Export Content-Type: ' . ($_SERVER['CONTENT_TYPE'] ?? 'not set'));
        }
        
        // Check if this is actually an AJAX request
        if (!wp_doing_ajax()) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Courses CSV Export: Not an AJAX request');
            }
            wp_send_json_error(['message' => __('Invalid request.', 'vira-store')]);
        }
        
        // Verify nonce
        $nonce_value = $_POST['nonce'] ?? '';
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Courses CSV Export: Nonce value received: ' . $nonce_value);
            error_log('Courses CSV Export: Expected nonce action: vrstore_admin_nonce');
        }
        
        if (!wp_verify_nonce($nonce_value, 'vrstore_admin_nonce')) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Courses CSV Export: Nonce verification failed');
            }
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
        }
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Courses CSV Export: Nonce verification passed');
        }

        // Check user capabilities
        if (!current_user_can('manage_options')) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Courses CSV Export: Permission denied');
            }
            wp_send_json_error(['message' => __('Permission denied.', 'vira-store')]);
        }
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Courses CSV Export: Nonce verified, user has permissions');
        }
        
        try {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Courses CSV Export: About to get courses data');
            }
            
            // Get courses data for export
            $courses_data = $this->get_courses_data_for_export();
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Courses CSV Export: Got courses data, count: ' . (is_array($courses_data) ? count($courses_data) : 0));
            }
            
            if (empty($courses_data)) {
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log('Courses CSV Export: No courses data found');
                }
                wp_send_json_error(['message' => __('No courses data found.', 'vira-store')]);
            }
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Courses CSV Export: About to format CSV data');
            }
            
            // Create CSV data
            $csv_data = $this->format_courses_data_for_csv($courses_data);
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Courses CSV Export: CSV data formatted, length: ' . strlen($csv_data));
            }
            
            // Generate a unique filename
            $filename = 'virastore-courses-export-' . date('Y-m-d-H-i-s') . '.csv';
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Courses CSV Export: About to create temp file: ' . $filename);
            }
            
            // Create temporary file
            $temp_file = wp_tempnam($filename);
            if (!$temp_file) {
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log('Courses CSV Export: Failed to create temp file');
                }
                wp_send_json_error(['message' => __('Failed to create temporary file.', 'vira-store')]);
            }
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Courses CSV Export: Created temp file: ' . $temp_file);
            }
            
            // Write CSV data to temporary file
            if (file_put_contents($temp_file, $csv_data) === false) {
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log('Courses CSV Export: Failed to write to temp file');
                }
                wp_send_json_error(['message' => __('Failed to write export data.', 'vira-store')]);
            }
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Courses CSV Export: Written data to temp file');
            }
            
            // Generate download URL
            $upload_dir = wp_upload_dir();
            $export_dir = $upload_dir['basedir'] . '/virastore-exports/';
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Courses CSV Export: Export directory: ' . $export_dir);
            }
            
            // Create export directory if it doesn't exist
            if (!file_exists($export_dir)) {
                wp_mkdir_p($export_dir);
            }
            
            // Move temp file to export directory
            $export_file = $export_dir . $filename;
            if (!rename($temp_file, $export_file)) {
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log('Courses CSV Export: Failed to move temp file to export dir');
                }
                wp_send_json_error(['message' => __('Failed to save export file.', 'vira-store')]);
            }
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Courses CSV Export: Moved file to export directory');
            }
            
            // Generate download URL
            $download_url = $upload_dir['baseurl'] . '/virastore-exports/' . $filename;
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Courses CSV Export: Success! Download URL: ' . $download_url);
            }
            
            wp_send_json_success([
                'message' => __('Courses list exported successfully!', 'vira-store'),
                'download_url' => $download_url,
                'filename' => $filename,
                'records_count' => count($courses_data)
            ]);
            
        } catch (Exception $e) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Courses CSV Export Exception: ' . $e->getMessage());
                error_log('Courses CSV Export Exception trace: ' . $e->getTraceAsString());
            }
            wp_send_json_error([
                'message' => __('An error occurred while exporting courses CSV.', 'vira-store'),
                'debug' => WP_DEBUG ? $e->getMessage() : null
            ]);
        } catch (Error $e) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Courses CSV Export Fatal Error: ' . $e->getMessage());
                error_log('Courses CSV Export Error trace: ' . $e->getTraceAsString());
            }
            wp_send_json_error([
                'message' => __('A fatal error occurred while exporting courses CSV.', 'vira-store'),
                'debug' => WP_DEBUG ? $e->getMessage() : null
            ]);
        }
    }
    
    /**
     * Get courses data for export
     *
     * @return array
     */
    private function get_courses_data_for_export(): array {
        // Debug logging
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Courses Export Debug: Starting courses data export');
        }
        
        // Get all courses (custom post type)
        $courses = get_posts([
            'post_type' => 'vrstore_course',
            'post_status' => ['publish', 'draft', 'private'],
            'numberposts' => -1,
            'orderby' => 'date',
            'order' => 'DESC'
        ]);
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Courses Export Debug: Found ' . count($courses) . ' courses');
        }
        
        $export_data = [];
        foreach ($courses as $course) {
            // Get course curriculum to count lessons
            $curriculum = get_post_meta($course->ID, '_vrstore_course_curriculum', true) ?: [];
            $total_lessons = 0;
            $video_lessons = 0;
            $course_duration_total = 0;
            
            foreach ($curriculum as $module) {
                if (!empty($module['lessons'])) {
                    foreach ($module['lessons'] as $lesson) {
                        $total_lessons++;
                        
                        // Count lesson types
                        $lesson_type = $lesson['type'] ?? 'video_upload';
                        if (in_array($lesson_type, ['video_upload', 'video_url'])) {
                            $video_lessons++;
                        }
                        
                        // Sum up lesson durations (in minutes)
                        if (!empty($lesson['duration']) && is_numeric($lesson['duration'])) {
                            $course_duration_total += floatval($lesson['duration']);
                        }
                    }
                }
            }
            
            // Get course pricing
            $is_free = get_post_meta($course->ID, '_vrstore_course_is_free', true);
            $free_with_product = get_post_meta($course->ID, '_vrstore_course_free_with_product', true);
            $price = get_post_meta($course->ID, '_vrstore_course_price', true) ?: '0';
            $sale_price = get_post_meta($course->ID, '_vrstore_course_sale_price', true) ?: '';
            
            // Determine pricing type
            $pricing_type = 'Paid';
            if ($is_free) {
                $pricing_type = 'Free';
            } elseif ($free_with_product) {
                $pricing_type = 'Free with Product';
                $required_product_id = get_post_meta($course->ID, '_vrstore_course_required_product_id', true);
                if ($required_product_id) {
                    $product_title = get_the_title($required_product_id);
                    $pricing_type .= ' (' . $product_title . ')';
                }
            }
            
            // Get other course meta
            $duration = get_post_meta($course->ID, '_vrstore_course_duration', true) ?: '';
            $level = get_post_meta($course->ID, '_vrstore_course_level', true) ?: '';
            $language = get_post_meta($course->ID, '_vrstore_course_language', true) ?: '';
            $certification = get_post_meta($course->ID, '_vrstore_course_certification', true) ? 'Yes' : 'No';
            
            // Get course categories
            $categories = wp_get_post_terms($course->ID, 'vrstore_course_cat');
            $category_names = !empty($categories) ? implode(', ', wp_list_pluck($categories, 'name')) : '';
            
            // Get course tags
            $tags = wp_get_post_terms($course->ID, 'vrstore_course_tag');
            $tag_names = !empty($tags) ? implode(', ', wp_list_pluck($tags, 'name')) : '';
            
            // Mock enrollment count (would come from actual tracking)
            $enrollment_count = rand(5, 100);
            
            // Format duration
            $duration_display = '';
            if ($course_duration_total > 0) {
                if ($course_duration_total >= 60) {
                    $duration_display = round($course_duration_total / 60, 1) . 'h';
                } else {
                    $duration_display = $course_duration_total . 'm';
                }
            }
            
            // Get currency from settings
            $settings = VRSTORE_Settings::get_instance();
            $currency = $settings->get_setting('currency', 'USD');
            
            $export_data[] = [
                'id' => $course->ID,
                'title' => $course->post_title,
                'slug' => $course->post_name,
                'status' => ucfirst($course->post_status),
                'pricing_type' => $pricing_type,
                'price' => $price,
                'sale_price' => $sale_price,
                'currency' => $currency,
                'total_lessons' => $total_lessons,
                'video_lessons' => $video_lessons,
                'duration_display' => $duration_display,
                'duration_minutes' => $course_duration_total,
                'level' => ucfirst($level),
                'language' => $language,
                'certification' => $certification,
                'categories' => $category_names,
                'tags' => $tag_names,
                'enrollments' => $enrollment_count,
                'created_date' => $course->post_date,
                'modified_date' => $course->post_modified,
                'author' => get_the_author_meta('display_name', $course->post_author),
                'description' => wp_trim_words(strip_tags($course->post_content), 30)
            ];
        }
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Courses Export Debug: Processed ' . count($export_data) . ' courses for export');
        }
        
        return $export_data;
    }
    
    /**
     * Format courses data for CSV export
     *
     * @param array $courses_data
     * @return string
     */
    private function format_courses_data_for_csv(array $courses_data): string {
        if (empty($courses_data)) {
            return '';
        }
        
        // CSV headers
        $headers = [
            'ID',
            'Title',
            'Slug',
            'Status',
            'Pricing Type',
            'Price',
            'Sale Price',
            'Currency',
            'Total Lessons',
            'Video Lessons',
            'Duration Display',
            'Duration Minutes',
            'Level',
            'Language',
            'Certification',
            'Categories',
            'Tags',
            'Enrollments',
            'Created Date',
            'Modified Date',
            'Author',
            'Description'
        ];
        
        // Start with headers
        $csv_content = '"' . implode('","', $headers) . '"' . "\n";
        
        // Add data rows
        foreach ($courses_data as $course) {
            $row = [
                $course['id'],
                $course['title'],
                $course['slug'],
                $course['status'],
                $course['pricing_type'],
                $course['price'],
                $course['sale_price'],
                $course['currency'],
                $course['total_lessons'],
                $course['video_lessons'],
                $course['duration_display'],
                $course['duration_minutes'],
                $course['level'],
                $course['language'],
                $course['certification'],
                $course['categories'],
                $course['tags'],
                $course['enrollments'],
                $course['created_date'],
                $course['modified_date'],
                $course['author'],
                $course['description']
            ];
            
            // Escape and wrap each field in quotes
            $escaped_row = array_map(function($field) {
                return '"' . str_replace('"', '""', $field) . '"';
            }, $row);
            
            $csv_content .= implode(',', $escaped_row) . "\n";
        }
        
        return $csv_content;
    }

    /**
     * Validate product access for current user
     *
     * @param int $product_id Product ID
     * @return bool True if user has access
     */
    private function validate_product_access(int $product_id): bool {
        // Check if product exists
        $product = get_post($product_id);
        if (!$product || $product->post_type !== 'vrstore_product') {
            return false;
        }

        // Check if user can manage this product
        if (!current_user_can('edit_post', $product_id)) {
            return false;
        }

        return true;
    }

    /**
     * AJAX handler to load plugin versions for a product
     *
     * @return void
     */
    public function ajax_load_plugin_versions(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_admin_nonce')) {
            wp_die(__('Security check failed', 'vira-store'));
        }

        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_die(__('Insufficient permissions', 'vira-store'));
        }

        $product_id = intval($_POST['product_id'] ?? 0);
        if (!$product_id || !$this->validate_product_access($product_id)) {
            wp_send_json_error(__('Invalid product ID', 'vira-store'));
        }

        // Get product versions from database table (with table existence check)
        global $wpdb;
        $versions_table = $wpdb->prefix . 'vrstore_plugin_versions';
        
        // Check if table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$versions_table'") !== $versions_table) {
            wp_send_json_success([
                'versions' => [],
                'license_types' => [],
                'product_id' => $product_id,
                'message' => __('Plugin versions table not found. Please check database setup.', 'vira-store')
            ]);
            return;
        }
        
        $versions_data = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$versions_table} WHERE product_id = %d ORDER BY release_date DESC, created_at DESC",
            $product_id
        ), ARRAY_A);
        
        // Format versions for frontend
        $versions = [];
        if (!empty($versions_data)) {
            foreach ($versions_data as $version) {
                $versions[] = [
                    'id' => $version['id'],
                    'version' => $version['version'],
                    'changelog' => $version['changelog'],
                    'license_tiers' => json_decode($version['license_tiers'], true) ?: [],
                    'file_name' => $version['file_name'],
                    'file_size' => $version['file_size'],
                    'is_active' => $version['is_active'],
                    'release_date' => $version['release_date'],
                    'created_at' => $version['created_at'],
                    'updated_at' => $version['updated_at']
                ];
            }
        }

        // Get custom license types from settings
        $settings = get_option('vrstore_settings', []);
        $custom_license_types = $settings['custom_license_types'] ?? [];
        
        // Prepare license types for frontend
        $license_types = [];
        if (!empty($custom_license_types)) {
            foreach ($custom_license_types as $type) {
                if (!empty($type['slug']) && !empty($type['label'])) {
                    $license_types[] = [
                        'slug' => sanitize_text_field($type['slug']),
                        'label' => sanitize_text_field($type['label'])
                    ];
                }
            }
        }

        // If no custom license types, fall back to taxonomy terms
        if (empty($license_types)) {
            $terms = get_terms([
                'taxonomy' => 'vrstore_license_type',
                'hide_empty' => false,
            ]);
            
            if (!is_wp_error($terms) && !empty($terms)) {
                foreach ($terms as $term) {
                    $license_types[] = [
                        'slug' => $term->slug,
                        'label' => $term->name
                    ];
                }
            }
        }

        wp_send_json_success([
            'versions' => $versions,
            'license_types' => $license_types,
            'product_id' => $product_id
        ]);
    }

    /**
     * AJAX handler to update a plugin version
     *
     * @return void
     */
    public function ajax_update_plugin_version(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_admin_nonce')) {
            wp_die(__('Security check failed', 'vira-store'));
        }

        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_die(__('Insufficient permissions', 'vira-store'));
        }

        $product_id = intval($_POST['product_id'] ?? 0);
        if (!$product_id || !$this->validate_product_access($product_id)) {
            wp_send_json_error(__('Invalid product ID', 'vira-store'));
        }

        $version_data = [
            'version' => sanitize_text_field($_POST['version'] ?? ''),
            'file_url' => esc_url_raw($_POST['file_url'] ?? ''),
            'changelog' => wp_kses_post($_POST['changelog'] ?? ''),
            'license_tiers' => array_map('sanitize_text_field', $_POST['license_tiers'] ?? []),
            'date_added' => current_time('mysql')
        ];

        // Validate required fields
        if (empty($version_data['version']) || empty($version_data['file_url'])) {
            wp_send_json_error(__('Version and file URL are required', 'vira-store'));
        }

        // Get existing versions
        $versions = get_post_meta($product_id, '_vrstore_plugin_versions', true);
        if (!is_array($versions)) {
            $versions = [];
        }

        // Add or update version
        $version_key = sanitize_key($version_data['version']);
        $versions[$version_key] = $version_data;

        // Save versions
        update_post_meta($product_id, '_vrstore_plugin_versions', $versions);

        wp_send_json_success([
            'message' => __('Version saved successfully', 'vira-store'),
            'versions' => $versions
        ]);
    }

    /**
     * AJAX handler to delete a plugin version
     *
     * @return void
     */
    public function ajax_delete_plugin_version(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_admin_nonce')) {
            wp_die(__('Security check failed', 'vira-store'));
        }

        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_die(__('Insufficient permissions', 'vira-store'));
        }

        $product_id = intval($_POST['product_id'] ?? 0);
        $version_key = sanitize_key($_POST['version_key'] ?? '');

        if (!$product_id || !$version_key || !$this->validate_product_access($product_id)) {
            wp_send_json_error(__('Invalid parameters', 'vira-store'));
        }

        // Get existing versions
        $versions = get_post_meta($product_id, '_vrstore_plugin_versions', true);
        if (!is_array($versions)) {
            $versions = [];
        }

        // Remove version
        if (isset($versions[$version_key])) {
            unset($versions[$version_key]);
            update_post_meta($product_id, '_vrstore_plugin_versions', $versions);
            wp_send_json_success([
                'message' => __('Version deleted successfully', 'vira-store'),
                'versions' => $versions
            ]);
        } else {
            wp_send_json_error(__('Version not found', 'vira-store'));
        }
    }

    /**
     * Render affiliates page
     *
     * @return void
     */
    public function render_affiliates_page(): void {
        // Handle affiliate actions
        $this->handle_affiliate_actions();
        
        // Get current action and tab
        $action = sanitize_text_field($_GET['action'] ?? '');
        $tab = sanitize_text_field($_GET['tab'] ?? 'affiliates');
        $affiliate_id = intval($_GET['affiliate_id'] ?? 0);
        
        // Handle different views
        switch ($action) {
            case 'view':
                $this->render_affiliate_detail_page($affiliate_id);
                break;
            case 'edit':
                $this->render_affiliate_edit_page($affiliate_id);
                break;
            default:
                // Handle tab navigation
                switch ($tab) {
                    case 'settings':
                        $this->render_affiliate_settings_page();
                        break;
                    case 'affiliates':
                    default:
                        // Get affiliates data
                        $affiliates = $this->get_affiliates_data();
                        $current_tab = 'affiliates';
                        
                        // Handle bulk actions
                        $this->handle_affiliate_bulk_actions();
                        
                        // Include affiliates template
                        include VRSTORE_PLUGIN_DIR . 'views/admin/affiliates.php';
                        break;
                }
                break;
        }
    }

    /**
     * Handle affiliate actions
     *
     * @return void
     */
    private function handle_affiliate_actions(): void {
        // Check if we have an action to process
        if (!isset($_POST['action']) || !wp_verify_nonce($_POST['_wpnonce'] ?? '', 'vrstore_affiliate_action')) {
            return;
        }

        $action = sanitize_text_field($_POST['action']);
        $affiliate_id = intval($_POST['affiliate_id'] ?? 0);

          switch ($action) {
              case 'approve_affiliate':
                  $this->approve_affiliate($affiliate_id);
                  break;
              case 'reject_affiliate':
                  $this->reject_affiliate($affiliate_id);
                  break;
              case 'update_commission':
                  $this->update_affiliate_commission($affiliate_id);
                  break;
              case 'update_affiliate':
                  $this->update_affiliate($affiliate_id);
                  break;
          }
    }

    /**
     * Get affiliates data
     *
     * @return array
     */
    private function get_affiliates_data(): array {
        global $wpdb;
        
        $affiliates_table = $wpdb->prefix . 'vrstore_affiliates';
        
        // Check if table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$affiliates_table'") !== $affiliates_table) {
            return [];
        }

        // Get affiliates with statistics (include unpaid_commissions from table)
        $affiliates = $wpdb->get_results("
            SELECT a.*, 
                   COUNT(DISTINCT av.id) as total_visits,
                   COUNT(DISTINCT ac.id) as total_commissions,
                   COALESCE(SUM(ac.commission_amount), 0) as total_earnings,
                   a.unpaid_commissions
            FROM {$affiliates_table} a
            LEFT JOIN {$wpdb->prefix}vrstore_affiliate_visits av ON a.id = av.affiliate_id
            LEFT JOIN {$wpdb->prefix}vrstore_affiliate_commissions ac ON a.id = ac.affiliate_id
            GROUP BY a.id
            ORDER BY a.created_at DESC
        ", ARRAY_A);

        return $affiliates ?: [];
    }

    /**
     * Approve affiliate
     *
     * @param int $affiliate_id
     * @return void
     */
    private function approve_affiliate(int $affiliate_id): void {
        global $wpdb;
        
        // Use 'active' status (correct enum value, not 'approved')
        $result = $wpdb->update(
            $wpdb->prefix . 'vrstore_affiliates',
            ['status' => 'active'],
            ['id' => $affiliate_id],
            ['%s'],
            ['%d']
        );

        if ($result !== false) {
            add_action('admin_notices', function() {
                echo '<div class="notice notice-success is-dismissible"><p>' . 
                     __('Affiliate approved successfully.', 'vira-store') . '</p></div>';
            });
        }
    }

    /**
     * Reject affiliate
     *
     * @param int $affiliate_id
     * @return void
     */
    private function reject_affiliate(int $affiliate_id): void {
        global $wpdb;
        
        // Use 'suspended' status (correct enum value - table enum is 'pending','active','suspended')
        $result = $wpdb->update(
            $wpdb->prefix . 'vrstore_affiliates',
            ['status' => 'suspended'],
            ['id' => $affiliate_id],
            ['%s'],
            ['%d']
        );

        if ($result !== false) {
            add_action('admin_notices', function() {
                echo '<div class="notice notice-success is-dismissible"><p>' . 
                     __('Affiliate rejected successfully.', 'vira-store') . '</p></div>';
            });
        }
    }

    /**
     * Update affiliate commission
     *
     * @param int $affiliate_id
     * @return void
     */
    private function update_affiliate_commission(int $affiliate_id): void {
        $commission_rate = floatval($_POST['commission_rate'] ?? 0);
        
        if ($commission_rate < 0 || $commission_rate > 100) {
            add_action('admin_notices', function() {
                echo '<div class="notice notice-error is-dismissible"><p>' . 
                     __('Commission rate must be between 0 and 100.', 'vira-store') . '</p></div>';
            });
            return;
        }

        global $wpdb;
        
        $result = $wpdb->update(
            $wpdb->prefix . 'vrstore_affiliates',
            ['commission_rate' => $commission_rate],
            ['id' => $affiliate_id],
            ['%f'],
            ['%d']
        );

        if ($result !== false) {
            add_action('admin_notices', function() {
                echo '<div class="notice notice-success is-dismissible"><p>' . 
                     __('Commission rate updated successfully.', 'vira-store') . '</p></div>';
            });
        }
    }

    /**
     * Update affiliate information
     *
     * @param int $affiliate_id
     * @return void
     */
    private function update_affiliate(int $affiliate_id): void {
        global $wpdb;
        
        // Sanitize and validate input data
        $affiliate_name = sanitize_text_field($_POST['affiliate_name'] ?? '');
        $affiliate_email = sanitize_email($_POST['affiliate_email'] ?? '');
        $affiliate_status = sanitize_text_field($_POST['affiliate_status'] ?? 'pending');
        $commission_rate = floatval($_POST['commission_rate'] ?? 0);
        $payment_method = sanitize_text_field($_POST['payment_method'] ?? 'paypal');
        $payment_details = sanitize_textarea_field($_POST['payment_details'] ?? '');
        $notes = sanitize_textarea_field($_POST['notes'] ?? '');
        
        // Validate required fields
        if (empty($affiliate_name) || empty($affiliate_email)) {
            add_action('admin_notices', function() {
                echo '<div class="notice notice-error is-dismissible"><p>' . 
                     __('Name and email are required fields.', 'vira-store') . '</p></div>';
            });
            return;
        }
        
        // Validate commission rate
        if ($commission_rate < 0 || $commission_rate > 100) {
            add_action('admin_notices', function() {
                echo '<div class="notice notice-error is-dismissible"><p>' . 
                     __('Commission rate must be between 0 and 100.', 'vira-store') . '</p></div>';
            });
            return;
        }
        
        // Validate status
        if (!in_array($affiliate_status, ['pending', 'active', 'suspended'])) {
            $affiliate_status = 'pending';
        }
        
        // Prepare update data
        $update_data = [
            'name' => $affiliate_name,
            'email' => $affiliate_email,
            'status' => $affiliate_status,
            'commission_rate' => $commission_rate,
            'payment_method' => $payment_method,
            'payment_details' => $payment_details,
            'notes' => $notes,
            'updated_at' => current_time('mysql')
        ];
        
        $update_formats = ['%s', '%s', '%s', '%f', '%s', '%s', '%s', '%s'];
        
        // Update affiliate record
        $result = $wpdb->update(
            $wpdb->prefix . 'vrstore_affiliates',
            $update_data,
            ['id' => $affiliate_id],
            $update_formats,
            ['%d']
        );
        
        if ($result !== false) {
            add_action('admin_notices', function() {
                echo '<div class="notice notice-success is-dismissible"><p>' . 
                     __('Affiliate updated successfully.', 'vira-store') . '</p></div>';
            });
        } else {
            add_action('admin_notices', function() {
                echo '<div class="notice notice-error is-dismissible"><p>' . 
                     __('Failed to update affiliate. Please try again.', 'vira-store') . '</p></div>';
            });
        }
    }

    /**
     * Render affiliate detail page
     *
     * @param int $affiliate_id
     * @return void
     */
    private function render_affiliate_detail_page(int $affiliate_id): void {
        global $wpdb;
        
        // Get affiliate data
        $affiliate = $wpdb->get_row($wpdb->prepare("
            SELECT * FROM {$wpdb->prefix}vrstore_affiliates WHERE id = %d
        ", $affiliate_id), ARRAY_A);

        if (!$affiliate) {
            echo '<div class="notice notice-error"><p>' . __('Affiliate not found.', 'vira-store') . '</p></div>';
            return;
        }

        // Get affiliate statistics (include unpaid_commissions from affiliate table)
        $stats = $wpdb->get_row($wpdb->prepare("
            SELECT 
                COUNT(DISTINCT av.id) as total_visits,
                COUNT(DISTINCT ac.id) as total_commissions,
                COALESCE(SUM(ac.commission_amount), 0) as total_earnings,
                a.unpaid_commissions
            FROM {$wpdb->prefix}vrstore_affiliates a
            LEFT JOIN {$wpdb->prefix}vrstore_affiliate_visits av ON a.id = av.affiliate_id
            LEFT JOIN {$wpdb->prefix}vrstore_affiliate_commissions ac ON a.id = ac.affiliate_id
            WHERE a.id = %d
            GROUP BY a.id
        ", $affiliate_id), ARRAY_A);
        
        // Ensure stats array is properly formatted
        if (!$stats) {
            $stats = [
                'total_visits' => 0,
                'total_commissions' => 0,
                'total_earnings' => 0,
                'unpaid_commissions' => 0
            ];
        } else {
            $stats['unpaid_commissions'] = floatval($stats['unpaid_commissions'] ?? $affiliate['unpaid_commissions'] ?? 0);
        }

        // Include affiliate detail template
        include VRSTORE_PLUGIN_DIR . 'views/admin/affiliate-detail.php';
    }

    /**
     * Render affiliate edit page
     *
     * @param int $affiliate_id
     * @return void
     */
    private function render_affiliate_edit_page(int $affiliate_id): void {
        global $wpdb;
        
        // Get affiliate data
        $affiliate = $wpdb->get_row($wpdb->prepare("
            SELECT * FROM {$wpdb->prefix}vrstore_affiliates WHERE id = %d
        ", $affiliate_id), ARRAY_A);

        if (!$affiliate) {
            echo '<div class="notice notice-error"><p>' . __('Affiliate not found.', 'vira-store') . '</p></div>';
            return;
        }

        // Include affiliate edit template
        include VRSTORE_PLUGIN_DIR . 'views/admin/affiliate-edit.php';
    }

    /**
     * Render affiliate settings page
     *
     * @return void
     */
    private function render_affiliate_settings_page(): void {
        // Handle settings form submission
        if (isset($_POST['action']) && $_POST['action'] === 'save_affiliate_settings' && wp_verify_nonce($_POST['_wpnonce'] ?? '', 'vrstore_affiliate_settings')) {
            $this->save_affiliate_settings();
        }

        // Get current settings
        $settings = $this->get_affiliate_settings();
        $current_tab = 'settings';

        // Include affiliate settings template
        include VRSTORE_PLUGIN_DIR . 'views/admin/affiliate-settings.php';
    }

    /**
     * Get affiliate settings
     *
     * @return array
     */
    private function get_affiliate_settings(): array {
        return [
            'default_commission_rate' => get_option('vrstore_affiliate_default_commission_rate', '10'),
            'auto_approve_affiliates' => get_option('vrstore_affiliate_auto_approve', '0'),
            'minimum_payout_amount' => get_option('vrstore_affiliate_minimum_payout', '50'),
            'cookie_duration' => get_option('vrstore_affiliate_cookie_duration', '30'),
            'enable_affiliate_registration' => get_option('vrstore_affiliate_enable_registration', '1'),
            'join_affiliate_requirement' => get_option('vrstore_affiliate_join_requirement', 'free'),
            'required_products' => get_option('vrstore_affiliate_required_products', []),
            'product_commissions' => get_option('vrstore_affiliate_product_commissions', []),
            'affiliate_terms_page' => get_option('vrstore_affiliate_terms_page', ''),
            'payout_methods' => get_option('vrstore_affiliate_payout_methods', ['paypal', 'bank_transfer']),
            'email_notifications' => get_option('vrstore_affiliate_email_notifications', '1'),
            'use_short_urls' => get_option('vrstore_affiliate_use_short_urls', '0'),
            'short_url_provider' => get_option('vrstore_affiliate_short_url_provider', 'dns'),
            'short_domain' => get_option('vrstore_affiliate_short_domain', ''),
            'rebrandly_api_key' => get_option('vrstore_affiliate_rebrandly_api_key', ''),
            'rebrandly_domain' => get_option('vrstore_affiliate_rebrandly_domain', ''),
            'bitly_access_token' => get_option('vrstore_affiliate_bitly_access_token', ''),
            'bitly_domain' => get_option('vrstore_affiliate_bitly_domain', ''),
            'bitly_group_guid' => get_option('vrstore_affiliate_bitly_group_guid', ''),
            'benefits_section_title' => get_option('vrstore_affiliate_benefits_section_title', 'Why Join Our Affiliate Program?'),
            'program_benefits' => get_option('vrstore_affiliate_program_benefits', ''),
            'program_description' => get_option('vrstore_affiliate_program_description', ''),
        ];
    }

    /**
     * Save affiliate settings
     *
     * @return void
     */
    private function save_affiliate_settings(): void {
        // Sanitize and save settings
        $default_commission_rate = floatval($_POST['default_commission_rate'] ?? 10);
        $auto_approve_affiliates = intval($_POST['auto_approve_affiliates'] ?? 0);
        $minimum_payout_amount = floatval($_POST['minimum_payout_amount'] ?? 50);
        $cookie_duration = intval($_POST['cookie_duration'] ?? 30);
        $enable_affiliate_registration = isset($_POST['enable_affiliate_registration']) ? 1 : 0;
        $join_affiliate_requirement = sanitize_text_field($_POST['join_affiliate_requirement'] ?? 'free');
        $required_products = array_map('intval', $_POST['required_products'] ?? []);
        $product_commissions = array_map('floatval', $_POST['product_commissions'] ?? []);
        $affiliate_terms_page = intval($_POST['affiliate_terms_page'] ?? 0);
        $payout_methods = array_map('sanitize_text_field', $_POST['payout_methods'] ?? []);
        $email_notifications = intval($_POST['email_notifications'] ?? 1);
        $use_short_urls = isset($_POST['use_short_urls']) ? 1 : 0;
        $short_url_provider = sanitize_text_field($_POST['short_url_provider'] ?? 'dns');
        $short_domain = sanitize_text_field($_POST['short_domain'] ?? '');
        
        // Rebrandly settings
        $rebrandly_api_key = sanitize_text_field($_POST['rebrandly_api_key'] ?? '');
        $rebrandly_domain = sanitize_text_field($_POST['rebrandly_domain'] ?? '');
        
        // Bitly settings
        $bitly_access_token = sanitize_text_field($_POST['bitly_access_token'] ?? '');
        $bitly_domain = sanitize_text_field($_POST['bitly_domain'] ?? '');
        $bitly_group_guid = sanitize_text_field($_POST['bitly_group_guid'] ?? '');

        // Program Benefits Settings
        $benefits_section_title = sanitize_text_field($_POST['benefits_section_title'] ?? 'Why Join Our Affiliate Program?');
        $program_benefits = sanitize_textarea_field($_POST['program_benefits'] ?? '');
        $program_description = sanitize_textarea_field($_POST['program_description'] ?? '');

        // Clean short domain - remove protocol if present
        if (!empty($short_domain)) {
            $short_domain = preg_replace('#^https?://#', '', $short_domain);
            $short_domain = trim($short_domain, '/');
        }

        // Update options
        update_option('vrstore_affiliate_default_commission_rate', $default_commission_rate);
        update_option('vrstore_affiliate_auto_approve', $auto_approve_affiliates);
        update_option('vrstore_affiliate_minimum_payout', $minimum_payout_amount);
        update_option('vrstore_affiliate_cookie_duration', $cookie_duration);
        update_option('vrstore_affiliate_enable_registration', $enable_affiliate_registration);
        update_option('vrstore_affiliate_join_requirement', $join_affiliate_requirement);
        update_option('vrstore_affiliate_required_products', $required_products);
        update_option('vrstore_affiliate_product_commissions', $product_commissions);
        update_option('vrstore_affiliate_terms_page', $affiliate_terms_page);
        update_option('vrstore_affiliate_payout_methods', $payout_methods);
        update_option('vrstore_affiliate_email_notifications', $email_notifications);
        update_option('vrstore_affiliate_use_short_urls', $use_short_urls);
        update_option('vrstore_affiliate_short_url_provider', $short_url_provider);
        update_option('vrstore_affiliate_short_domain', $short_domain);
        
        // Save Rebrandly settings
        update_option('vrstore_affiliate_rebrandly_api_key', $rebrandly_api_key);
        update_option('vrstore_affiliate_rebrandly_domain', $rebrandly_domain);
        
        // Save Bitly settings
        update_option('vrstore_affiliate_bitly_access_token', $bitly_access_token);
        update_option('vrstore_affiliate_bitly_domain', $bitly_domain);
        update_option('vrstore_affiliate_bitly_group_guid', $bitly_group_guid);

        // Save program benefits settings
        update_option('vrstore_affiliate_benefits_section_title', $benefits_section_title);
        update_option('vrstore_affiliate_program_benefits', $program_benefits);
        update_option('vrstore_affiliate_program_description', $program_description);

        // Show success message
        add_action('admin_notices', function() {
            echo '<div class="notice notice-success is-dismissible"><p>' . __('Affiliate settings saved successfully.', 'vira-store') . '</p></div>';
        });
    }

    /**
     * Handle affiliate bulk actions
     *
     * @return void
     */
    private function handle_affiliate_bulk_actions(): void {
        // Check if we have a bulk action to process
        if (!isset($_POST['action']) || $_POST['action'] !== 'bulk_affiliate_action' || 
            !wp_verify_nonce($_POST['vrstore_bulk_nonce'] ?? '', 'vrstore_affiliate_bulk_action')) {
            return;
        }

        // Check both bulk_action and bulk_action_hidden for the action
        $bulk_action = sanitize_text_field($_POST['bulk_action'] ?? $_POST['bulk_action_hidden'] ?? '');
        $affiliate_ids = array_map('intval', $_POST['affiliate'] ?? []);

        if (empty($affiliate_ids) || $bulk_action === '-1' || empty($bulk_action)) {
            return;
        }

        global $wpdb;
        $success_count = 0;
        $error_count = 0;

        foreach ($affiliate_ids as $affiliate_id) {
            switch ($bulk_action) {
                case 'approve':
                    // Use 'active' status (correct enum value, not 'approved')
                    $result = $wpdb->update(
                        $wpdb->prefix . 'vrstore_affiliates',
                        ['status' => 'active'],
                        ['id' => $affiliate_id],
                        ['%s'],
                        ['%d']
                    );
                    if ($result !== false) {
                        $success_count++;
                    } else {
                        $error_count++;
                    }
                    break;

                case 'reject':
                    // Use 'suspended' status (correct enum value - table enum is 'pending','active','suspended')
                    $result = $wpdb->update(
                        $wpdb->prefix . 'vrstore_affiliates',
                        ['status' => 'suspended'],
                        ['id' => $affiliate_id],
                        ['%s'],
                        ['%d']
                    );
                    if ($result !== false) {
                        $success_count++;
                    } else {
                        $error_count++;
                    }
                    break;

                case 'delete':
                    // First, get affiliate data to find linked customer
                    $affiliate = $wpdb->get_row($wpdb->prepare(
                        "SELECT * FROM {$wpdb->prefix}vrstore_affiliates WHERE id = %d",
                        $affiliate_id
                    ), ARRAY_A);

                    if ($affiliate) {
                        // Delete affiliate commissions
                        $wpdb->delete(
                            $wpdb->prefix . 'vrstore_affiliate_commissions',
                            ['affiliate_id' => $affiliate_id],
                            ['%d']
                        );

                        // Delete affiliate visits
                        $wpdb->delete(
                            $wpdb->prefix . 'vrstore_affiliate_visits',
                            ['affiliate_id' => $affiliate_id],
                            ['%d']
                        );

                        // Delete affiliate withdrawals
                        $wpdb->delete(
                            $wpdb->prefix . 'vrstore_affiliate_withdrawals',
                            ['affiliate_id' => $affiliate_id],
                            ['%d']
                        );

                        // Delete the affiliate record
                        $result = $wpdb->delete(
                            $wpdb->prefix . 'vrstore_affiliates',
                            ['id' => $affiliate_id],
                            ['%d']
                        );

                        // If there's a linked customer, optionally delete customer data
                        // Note: We're not deleting the WordPress user as they might have other data
                        // Only delete affiliate-specific data
                    } else {
                        $result = false;
                    }
                    break;

                default:
                    $result = false;
                    break;
            }

            if ($result !== false) {
                $success_count++;
            } else {
                $error_count++;
            }
        }

        // Show appropriate notice
        if ($success_count > 0) {
            $message = '';
            switch ($bulk_action) {
                case 'approve':
                    $message = sprintf(
                        _n('%d affiliate approved successfully.', '%d affiliates approved successfully.', $success_count, 'vira-store'),
                        $success_count
                    );
                    break;
                case 'reject':
                    $message = sprintf(
                        _n('%d affiliate rejected successfully.', '%d affiliates rejected successfully.', $success_count, 'vira-store'),
                        $success_count
                    );
                    break;
                case 'delete':
                    $message = sprintf(
                        _n('%d affiliate deleted successfully.', '%d affiliates deleted successfully.', $success_count, 'vira-store'),
                        $success_count
                    );
                    break;
            }

            if (!empty($message)) {
                add_action('admin_notices', function() use ($message) {
                    echo '<div class="notice notice-success is-dismissible"><p>' . esc_html($message) . '</p></div>';
                });
            }
        }

        if ($error_count > 0) {
            add_action('admin_notices', function() use ($error_count) {
                echo '<div class="notice notice-error is-dismissible"><p>' . 
                     sprintf(__('Failed to process %d affiliate(s).', 'vira-store'), $error_count) . '</p></div>';
            });
        }
    }
}
