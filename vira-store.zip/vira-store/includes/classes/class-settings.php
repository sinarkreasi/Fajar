<?php
/**
 * Settings Class for Vira Store
 *
 * @package Vira_Store
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * VRSTORE_Settings Class
 *
 * This class handles the settings page and options for the Vira Store plugin.
 *
 * @since 1.0.0
 */
class VRSTORE_Settings {

    /**
     * Instance of this class.
     *
     * @since 1.0.0
     * @var object
     */
    private static $instance = null;

    /**
     * Settings options.
     *
     * @since 1.0.0
     * @var array
     */
    private $options = array();

    /**
     * Settings tabs.
     *
     * @since 1.0.0
     * @var array
     */
    private $tabs = array();

    /**
     * Settings sections.
     *
     * @since 1.0.0
     * @var array
     */
    private $sections = array();

    /**
     * Settings fields.
     *
     * @since 1.0.0
     * @var array
     */
    private $fields = array();

    /**
     * Constructor.
     *
     * @since 1.0.0
     */
    private function __construct() {
        // Initialize settings on admin_init for admin area, init for frontend
        if ( is_admin() ) {
            add_action( 'admin_init', array( $this, 'init_settings' ) );
        } else {
            add_action( 'init', array( $this, 'init_frontend_settings' ), 20 );
            add_action( 'wp_enqueue_scripts', array( $this, 'localize_google_login_script' ), 20 );
        }

        // Add settings link to plugins page
        add_filter( 'plugin_action_links_' . plugin_basename( VRSTORE_PLUGIN_FILE ), array( $this, 'add_settings_link' ) );
        
        // Clear checkout URL cache when pages are updated
        add_action( 'save_post', array( $this, 'clear_checkout_url_cache' ) );
        add_action( 'delete_post', array( $this, 'clear_checkout_url_cache' ) );
        add_action( 'wp_trash_post', array( $this, 'clear_checkout_url_cache' ) );
        add_action( 'untrash_post', array( $this, 'clear_checkout_url_cache' ) );
        
        // Note: Menu registration now handled by VRSTORE_Admin_Menu class
    }

    /**
     * Get translated text with fallback for when textdomain is not loaded.
     *
     * @since 1.0.0
     * @param string $text Text to translate.
     * @param string $domain Text domain.
     * @return string Translated text or original text if textdomain not loaded.
     */
    private function get_translated_text( $text, $domain = 'vira-store' ) {
        // Check if textdomain is loaded
        if ( is_textdomain_loaded( $domain ) ) {
            return esc_html__( $text, $domain );
        }
        // Return escaped text without translation if textdomain not loaded
        return esc_html( $text );
    }

    /**
     * Get instance of this class.
     *
     * @since 1.0.0
     * @return VRSTORE_Settings
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Initialize settings.
     *
     * @since 1.0.0
     * @return void
     */
    public function init_settings() {
        // Register settings
        register_setting(
            'vrstore_settings',
            'vrstore_settings',
            array( $this, 'sanitize_settings' )
        );

        // Get settings
        $this->options = get_option( 'vrstore_settings', array() );

        // Setup settings tabs
        $this->setup_tabs();

        // Setup settings sections
        $this->setup_sections();

        // Setup settings fields
        $this->setup_fields();
    }

    /**
     * Initialize frontend settings (without admin-only functions).
     *
     * @since 1.0.0
     * @return void
     */
    public function init_frontend_settings() {
        // Get settings
        $this->options = get_option( 'vrstore_settings', array() );

        // Setup settings tabs (for translation strings)
        $this->setup_tabs();
    }

    /**
     * Localize Google login script with redirect data.
     *
     * @since 1.0.0
     * @return void
     */
    public function localize_google_login_script() {
        if ( is_admin() ) {
            return;
        }

        if ( ! wp_script_is( 'vrstore-google-login', 'registered' ) && ! wp_script_is( 'vrstore-google-login', 'enqueued' ) ) {
            return;
        }

        $cart_count = 0;
        if ( class_exists( 'VRSTORE_Cart' ) ) {
            $cart_instance = VRSTORE_Cart::get_instance();
            if ( $cart_instance && method_exists( $cart_instance, 'get_cart_count' ) ) {
                $cart_count = (int) $cart_instance->get_cart_count();
            }
        }

        wp_localize_script(
            'vrstore-google-login',
            'vrstoreGoogleLoginData',
            array(
                'checkoutUrl' => $this->get_checkout_url(),
                'cartCount'   => $cart_count,
                'loggedIn'    => is_user_logged_in(),
            )
        );
    }

    /**
     * Setup settings tabs.
     *
     * @since 1.0.0
     * @return void
     */
    private function setup_tabs() {
        // Use safe translation that checks if textdomain is loaded
        $this->tabs = array(
            'general'     => $this->get_translated_text( 'General' ),
            'store'       => $this->get_translated_text( 'Store' ),
            'payment'     => $this->get_translated_text( 'Payment' ),
            'license'     => $this->get_translated_text( 'License' ),
            'api'         => $this->get_translated_text( 'API' ),
            'integration' => $this->get_translated_text( 'Integration' ),
            'advanced'    => $this->get_translated_text( 'Advanced' ),
            'tools'       => $this->get_translated_text( 'Tools' ),
        );

        // Allow other plugins to add tabs
        $this->tabs = apply_filters( 'vrstore_settings_tabs', $this->tabs );
    }

    /**
     * Setup settings sections.
     *
     * @since 1.0.0
     * @return void
     */
    private function setup_sections() {
        $this->sections = array(
            // General tab sections
            array(
                'id'    => 'general_settings',
                'title' => $this->get_translated_text( 'General Settings' ),
                'tab'   => 'general',
            ),
            array(
                'id'    => 'email_settings',
                'title' => $this->get_translated_text( 'Email Settings' ),
                'tab'   => 'general',
            ),

            // Store tab sections
            array(
                'id'    => 'store_pages',
                'title' => $this->get_translated_text( 'Store Pages' ),
                'tab'   => 'store',
            ),
            array(
                'id'    => 'cart_settings',
                'title' => $this->get_translated_text( 'Cart Settings' ),
                'tab'   => 'store',
            ),
            array(
                'id'    => 'currency_settings',
                'title' => $this->get_translated_text( 'Currency Settings' ),
                'tab'   => 'store',
            ),

            // Payment tab sections
            array(
                'id'    => 'payment_settings',
                'title' => $this->get_translated_text( 'Payment Settings' ),
                'tab'   => 'payment',
            ),
            array(
                'id'    => 'tripay_settings',
                'title' => $this->get_translated_text( 'TriPay Settings' ),
                'tab'   => 'payment',
            ),
            array(
                'id'    => 'manual_settings',
                'title' => $this->get_translated_text( 'Transfer Bank Settings' ),
                'tab'   => 'payment',
            ),
            array(
                'id'    => 'payment_testing',
                'title' => $this->get_translated_text( 'Payment Testing' ),
                'tab'   => 'payment',
            ),


            // License tab sections
            array(
                'id'    => 'license_settings',
                'title' => $this->get_translated_text( 'License Settings' ),
                'tab'   => 'license',
            ),
            array(
                'id'    => 'license_management',
                'title' => $this->get_translated_text( 'License Management' ),
                'tab'   => 'license',
            ),
            array(
                'id'    => 'license_analytics',
                'title' => $this->get_translated_text( 'License Analytics' ),
                'tab'   => 'license',
            ),
            array(
                'id'    => 'license_bulk_operations',
                'title' => $this->get_translated_text( 'Bulk Operations' ),
                'tab'   => 'license',
            ),

            // API tab sections
            array(
                'id'    => 'api_settings',
                'title' => $this->get_translated_text( 'API Settings' ),
                'tab'   => 'api',
            ),
            array(
                'id'    => 'api_security',
                'title' => $this->get_translated_text( 'API Security' ),
                'tab'   => 'api',
            ),
            array(
                'id'    => 'api_monitoring',
                'title' => $this->get_translated_text( 'API Monitoring' ),
                'tab'   => 'api',
            ),

            // Integration tab sections
            array(
                'id'    => 'cache_integration',
                'title' => $this->get_translated_text( 'Cache Integration' ),
                'tab'   => 'integration',
            ),
            array(
                'id'    => 'webhook_integration',
                'title' => $this->get_translated_text( 'Webhook Integration' ),
                'tab'   => 'integration',
            ),
            array(
                'id'    => 'plugin_integration',
                'title' => $this->get_translated_text( 'Plugin Integration' ),
                'tab'   => 'integration',
            ),


            // Advanced tab sections
            array(
                'id'    => 'advanced_settings',
                'title' => $this->get_translated_text( 'Advanced Settings' ),
                'tab'   => 'advanced',
            ),
            array(
                'id'    => 'download_settings',
                'title' => $this->get_translated_text( 'Download Settings' ),
                'tab'   => 'advanced',
            ),
            array(
                'id'    => 'file_protection_settings',
                'title' => $this->get_translated_text( 'File Protection Settings' ),
                'tab'   => 'advanced',
            ),

            // Tools tab sections
            array(
                'id'    => 'database_tools',
                'title' => $this->get_translated_text( 'Database Tools' ),
                'tab'   => 'tools',
            ),
            array(
                'id'    => 'reset_tools',
                'title' => $this->get_translated_text( 'Reset Tools' ),
                'tab'   => 'tools',
            ),

            array(
                'id'    => 'maintenance_tools',
                'title' => $this->get_translated_text( 'Maintenance Tools' ),
                'tab'   => 'tools',
            ),
        );

        // Register sections
        foreach ( $this->sections as $section ) {
            add_settings_section(
                $section['id'],
                $section['title'],
                array( $this, 'section_callback' ),
                'vrstore_settings_' . $section['tab']
            );
        }

        // Allow other plugins to add sections
        $this->sections = apply_filters( 'vrstore_settings_sections', $this->sections );
    }

    /**
     * Setup settings fields.
     *
     * @since 1.0.0
     * @return void
     */
    private function setup_fields() {
        $this->fields = array(
            // General tab fields
            array(
                'id'          => 'store_name',
                'label'       => $this->get_translated_text( 'Store Name' ),
                'description' => $this->get_translated_text( 'Enter your store name.' ),
                'type'        => 'text',
                'section'     => 'general_settings',
                'tab'         => 'general',
                'default'     => get_bloginfo( 'name' ),
            ),
            array(
                'id'          => 'currency',
                'label'       => $this->get_translated_text( 'Currency' ),
                'description' => $this->get_translated_text( 'Select your store currency. This will be used as the base currency for all conversions.' ),
                'type'        => 'select',
                'options'     => $this->get_currencies(),
                'section'     => 'general_settings',
                'tab'         => 'general',
                'default'     => 'USD',
            ),
            array(
                'id'          => 'currency_position',
                'label'       => $this->get_translated_text( 'Currency Position' ),
                'description' => $this->get_translated_text( 'Select the position of the currency symbol.' ),
                'type'        => 'select',
                'options'     => array(
                    'left'        => $this->get_translated_text( 'Left ($99.99)' ),
                    'right'       => $this->get_translated_text( 'Right (99.99$)' ),
                    'left_space'  => $this->get_translated_text( 'Left with space ($ 99.99)' ),
                    'right_space' => $this->get_translated_text( 'Right with space (99.99 $)' ),
                ),
                'section'     => 'general_settings',
                'tab'         => 'general',
                'default'     => 'left',
            ),
            array(
                'id'          => 'thousand_separator',
                'label'       => $this->get_translated_text( 'Thousand Separator' ),
                'description' => $this->get_translated_text( 'Enter the thousand separator for prices.' ),
                'type'        => 'text',
                'section'     => 'general_settings',
                'tab'         => 'general',
                'default'     => ',',
            ),
            array(
                'id'          => 'decimal_separator',
                'label'       => $this->get_translated_text( 'Decimal Separator' ),
                'description' => $this->get_translated_text( 'Enter the decimal separator for prices.' ),
                'type'        => 'text',
                'section'     => 'general_settings',
                'tab'         => 'general',
                'default'     => '.',
            ),
            array(
                'id'          => 'decimal_number',
                'label'       => $this->get_translated_text( 'Number of Decimals' ),
                'description' => $this->get_translated_text( 'Enter the number of decimal points for prices.' ),
                'type'        => 'number',
                'section'     => 'general_settings',
                'tab'         => 'general',
                'default'     => 2,
                'min'         => 0,
                'max'         => 4,
            ),
            array(
                'id'          => 'product_permalink_slug',
                'label'       => $this->get_translated_text( 'Product Permalink Slug' ),
                'description' => $this->get_translated_text( 'Default: digital-product. Please re-save permalink when you change it.' ),
                'type'        => 'text',
                'section'     => 'general_settings',
                'tab'         => 'general',
                'default'     => 'digital-product',
            ),
            array(
                'id'          => 'enable_google_login',
                'label'       => $this->get_translated_text( 'Enable Google Login' ),
                'description' => $this->get_translated_text( 'Enable Google login and registration integration. When enabled, regular login/register forms will be hidden from [vrstore_account] shortcode.' ),
                'type'        => 'checkbox',
                'section'     => 'general_settings',
                'tab'         => 'general',
                'default'     => '',
            ),
            array(
                'id'          => 'google_client_id',
                'label'       => $this->get_translated_text( 'Google Client ID' ),
                'description' => $this->get_translated_text( 'Enter your Google OAuth Client ID. Get this from Google Cloud Console.' ),
                'type'        => 'text',
                'section'     => 'general_settings',
                'tab'         => 'general',
                'default'     => '',
            ),
            array(
                'id'          => 'google_client_secret',
                'label'       => $this->get_translated_text( 'Google Client Secret' ),
                'description' => $this->get_translated_text( 'Enter your Google OAuth Client Secret. Keep this secure and private.' ),
                'type'        => 'password',
                'section'     => 'general_settings',
                'tab'         => 'general',
                'default'     => '',
            ),
            array(
                'id'          => 'google_redirect_uri',
                'label'       => $this->get_translated_text( 'Google Redirect URI' ),
                'description' => $this->get_translated_text( 'Add this URL to your Google OAuth app: ' . home_url('/') . '?vrstore_google_callback=1' ),
                'type'        => 'text',
                'section'     => 'general_settings',
                'tab'         => 'general',
                'default'     => home_url('/') . '?vrstore_google_callback=1',
                'readonly'    => true,
            ),

            // Email settings
            array(
                'id'          => 'email_from_name',
                'label'       => $this->get_translated_text( 'From Name' ),
                'description' => $this->get_translated_text( 'Enter the name to be displayed in the From field of emails.' ),
                'type'        => 'text',
                'section'     => 'email_settings',
                'tab'         => 'general',
                'default'     => get_bloginfo( 'name' ),
            ),
            array(
                'id'          => 'email_from_email',
                'label'       => $this->get_translated_text( 'From Email' ),
                'description' => $this->get_translated_text( 'Enter the email address to be displayed in the From field of emails.' ),
                'type'        => 'email',
                'section'     => 'email_settings',
                'tab'         => 'general',
                'default'     => get_bloginfo( 'admin_email' ),
            ),
            array(
                'id'          => 'purchase_email_subject',
                'label'       => $this->get_translated_text( 'Purchase Email Subject' ),
                'description' => $this->get_translated_text( 'Enter the subject for purchase emails.' ),
                'type'        => 'text',
                'section'     => 'email_settings',
                'tab'         => 'general',
                'default'     => $this->get_translated_text( 'Your purchase from {site_name}' ),
            ),
            array(
                'id'          => 'purchase_email_body',
                'label'       => $this->get_translated_text( 'Purchase Email Body' ),
                'description' => $this->get_translated_text( 'Enter the body for purchase emails. Available tags: {site_name}, {customer_name}, {product_name}, {product_price}, {license_key}, {download_link}, {purchase_date}' ),
                'type'        => 'textarea',
                'section'     => 'email_settings',
                'tab'         => 'general',
                'default'     => "Dear {customer_name},\n\nThank you for your purchase from {site_name}.\n\nProduct: {product_name}\nPrice: {product_price}\nLicense Key: {license_key}\nDownload Link: {download_link}\nPurchase Date: {purchase_date}\n\nIf you have any questions, please contact us.\n\nRegards,\n{site_name}",
            ),
            
            // Email Confirmation Settings
            array(
                'id'          => 'enable_email_confirmation',
                'label'       => $this->get_translated_text( 'Enable Email Confirmation' ),
                'description' => $this->get_translated_text( 'Require users to confirm their email address after registration via [vrstore_account] or checkout.' ),
                'type'        => 'checkbox',
                'section'     => 'email_settings',
                'tab'         => 'general',
                'default'     => '',
            ),
            array(
                'id'          => 'email_confirmation_delay',
                'label'       => $this->get_translated_text( 'Confirmation Email Delay' ),
                'description' => $this->get_translated_text( 'Delay in minutes before sending confirmation email. Set to 0 for immediate sending.' ),
                'type'        => 'number',
                'section'     => 'email_settings',
                'tab'         => 'general',
                'default'     => 0,
                'min'         => 0,
                'max'         => 1440, // 24 hours
            ),
            array(
                'id'          => 'email_confirmation_subject',
                'label'       => $this->get_translated_text( 'Confirmation Email Subject' ),
                'description' => $this->get_translated_text( 'Subject for email confirmation messages. Available tags: {site_name}' ),
                'type'        => 'text',
                'section'     => 'email_settings',
                'tab'         => 'general',
                'default'     => $this->get_translated_text( 'Please confirm your email address - {site_name}' ),
            ),
            array(
                'id'          => 'email_confirmation_body',
                'label'       => $this->get_translated_text( 'Confirmation Email Body' ),
                'description' => $this->get_translated_text( 'Body for email confirmation messages. Available tags: {site_name}, {customer_name}, {confirmation_link}, {confirmation_code}' ),
                'type'        => 'textarea',
                'section'     => 'email_settings',
                'tab'         => 'general',
                'default'     => "Dear {customer_name},\n\nThank you for registering with {site_name}.\n\nTo complete your registration and activate your account, please click the link below:\n{confirmation_link}\n\nAlternatively, you can enter the confirmation code: {confirmation_code}\n\nIf you did not create this account, please ignore this email.\n\nRegards,\n{site_name}",
            ),
            array(
                'id'          => 'email_confirmation_expiry',
                'label'       => $this->get_translated_text( 'Confirmation Link Expiry' ),
                'description' => $this->get_translated_text( 'Hours until confirmation link expires. Set to 0 for no expiry.' ),
                'type'        => 'number',
                'section'     => 'email_settings',
                'tab'         => 'general',
                'default'     => 24,
                'min'         => 0,
                'max'         => 168, // 1 week
            ),
            
            // Disposable Email Blocking Settings
            array(
                'id'          => 'enable_disposable_email_blocking',
                'label'       => $this->get_translated_text( 'Block Disposable Emails' ),
                'description' => $this->get_translated_text( 'Block registration and purchases using temporary/disposable email addresses.' ),
                'type'        => 'checkbox',
                'section'     => 'email_settings',
                'tab'         => 'general',
                'default'     => '',
            ),
            array(
                'id'          => 'disposable_email_message',
                'label'       => $this->get_translated_text( 'Disposable Email Block Message' ),
                'description' => $this->get_translated_text( 'Message shown to users when they try to use a disposable email address.' ),
                'type'        => 'text',
                'section'     => 'email_settings',
                'tab'         => 'general',
                'default'     => $this->get_translated_text( 'Disposable or temporary email addresses are not allowed. Please use a permanent email address.' ),
            ),
            array(
                'id'          => 'custom_blocked_domains',
                'label'       => $this->get_translated_text( 'Custom Blocked Domains' ),
                'description' => $this->get_translated_text( 'Additional email domains to block (one per line). Example: tempmail.com, 10minutemail.com' ),
                'type'        => 'textarea',
                'section'     => 'email_settings',
                'tab'         => 'general',
                'default'     => '',
                'rows'        => 5,
            ),
            
            // Support Email Notification Settings
            array(
                'id'          => 'enable_support_email_notifications',
                'label'       => $this->get_translated_text( 'Enable Support Email Notifications' ),
                'description' => $this->get_translated_text( 'Send email notifications for support ticket activities (new tickets, replies, status changes).' ),
                'type'        => 'checkbox',
                'section'     => 'email_settings',
                'tab'         => 'general',
                'default'     => 'on',
            ),
            array(
                'id'          => 'support_admin_notification_emails',
                'label'       => $this->get_translated_text( 'Admin Notification Emails' ),
                'description' => $this->get_translated_text( 'Email addresses to notify for new tickets and customer replies (comma-separated).' ),
                'type'        => 'text',
                'section'     => 'email_settings',
                'tab'         => 'general',
                'default'     => get_bloginfo( 'admin_email' ),
            ),
            array(
                'id'          => 'support_email_from_name',
                'label'       => $this->get_translated_text( 'Support Email From Name' ),
                'description' => $this->get_translated_text( 'Name used in the From field of support notification emails.' ),
                'type'        => 'text',
                'section'     => 'email_settings',
                'tab'         => 'general',
                'default'     => get_bloginfo( 'name' ) . ' Support',
            ),
            array(
                'id'          => 'support_email_from_email',
                'label'       => $this->get_translated_text( 'Support Email From Address' ),
                'description' => $this->get_translated_text( 'Email address used in the From field of support notification emails.' ),
                'type'        => 'email',
                'section'     => 'email_settings',
                'tab'         => 'general',
                'default'     => 'support@' . str_replace( array( 'http://', 'https://', 'www.' ), '', home_url() ),
            ),
            array(
                'id'          => 'support_notify_admin_new_ticket',
                'label'       => $this->get_translated_text( 'Notify Admin - New Tickets' ),
                'description' => $this->get_translated_text( 'Send notifications to admin when new tickets are created.' ),
                'type'        => 'checkbox',
                'section'     => 'email_settings',
                'tab'         => 'general',
                'default'     => 'on',
            ),
            array(
                'id'          => 'support_notify_customer_new_ticket',
                'label'       => $this->get_translated_text( 'Notify Customer - New Tickets' ),
                'description' => $this->get_translated_text( 'Send confirmation emails to customers when they create new tickets.' ),
                'type'        => 'checkbox',
                'section'     => 'email_settings',
                'tab'         => 'general',
                'default'     => 'on',
            ),
            array(
                'id'          => 'support_notify_admin_customer_reply',
                'label'       => $this->get_translated_text( 'Notify Admin - Customer Replies' ),
                'description' => $this->get_translated_text( 'Send notifications to admin when customers reply to tickets.' ),
                'type'        => 'checkbox',
                'section'     => 'email_settings',
                'tab'         => 'general',
                'default'     => 'on',
            ),
            array(
                'id'          => 'support_notify_customer_admin_reply',
                'label'       => $this->get_translated_text( 'Notify Customer - Admin Replies' ),
                'description' => $this->get_translated_text( 'Send notifications to customers when admins reply to their tickets.' ),
                'type'        => 'checkbox',
                'section'     => 'email_settings',
                'tab'         => 'general',
                'default'     => 'on',
            ),
            array(
                'id'          => 'support_notify_customer_status_change',
                'label'       => $this->get_translated_text( 'Notify Customer - Status Changes' ),
                'description' => $this->get_translated_text( 'Send notifications to customers when ticket status changes.' ),
                'type'        => 'checkbox',
                'section'     => 'email_settings',
                'tab'         => 'general',
                'default'     => 'on',
            ),
            array(
                'id'          => 'support_notify_customer_priority_change',
                'label'       => $this->get_translated_text( 'Notify Customer - Priority Changes' ),
                'description' => $this->get_translated_text( 'Send notifications to customers when ticket priority changes.' ),
                'type'        => 'checkbox',
                'section'     => 'email_settings',
                'tab'         => 'general',
                'default'     => '',
            ),

            // Store page settings
            array(
                'id'          => 'cart_page',
                'label'       => $this->get_translated_text( 'Cart Page' ),
                'description' => $this->get_translated_text( 'Select the page that contains the [vrstore_cart] shortcode.' ),
                'type'        => 'select',
                'options'     => $this->get_pages_options(),
                'section'     => 'store_pages',
                'tab'         => 'store',
                'default'     => '',
            ),
            array(
                'id'          => 'checkout_page',
                'label'       => $this->get_translated_text( 'Checkout Page' ),
                'description' => $this->get_translated_text( 'Select the page that contains the [vrstore_checkout] shortcode.' ),
                'type'        => 'select',
                'options'     => $this->get_pages_options(),
                'section'     => 'store_pages',
                'tab'         => 'store',
                'default'     => '',
            ),
            array(
                'id'          => 'enable_auto_checkout_detection',
                'label'       => $this->get_translated_text( 'Auto-Detect Checkout URL' ),
                'description' => $this->get_translated_text( 'Automatically detect and use the checkout page URL based on the [vrstore_checkout] shortcode location. When enabled, the system will dynamically find pages containing this shortcode for checkout redirects.' ),
                'type'        => 'checkbox',
                'section'     => 'store_pages',
                'tab'         => 'store',
                'default'     => 'on',
            ),
            array(
                'id'          => 'account_page',
                'label'       => $this->get_translated_text( 'Account Page' ),
                'description' => $this->get_translated_text( 'Select the page that contains the [vrstore_account] shortcode.' ),
                'type'        => 'select',
                'options'     => $this->get_pages_options(),
                'section'     => 'store_pages',
                'tab'         => 'store',
                'default'     => '',
            ),
            array(
                'id'          => 'enable_custom_login',
                'label'       => $this->get_translated_text( 'Enable Custom Login/Register' ),
                'description' => $this->get_translated_text( 'Redirect all login attempts (/wp-login.php, /wp-admin) to your custom account page for non-logged-in users. Administrators can bypass this redirect by visiting /wp-admin/?admin=1 directly. AJAX, cron, and REST API requests are automatically excluded.' ),
                'type'        => 'checkbox',
                'section'     => 'store_pages',
                'tab'         => 'store',
                'default'     => '',
            ),
            array(
                'id'          => 'thank_you_page',
                'label'       => $this->get_translated_text( 'Thank You Page' ),
                'description' => $this->get_translated_text( 'Select the page that contains the [vrstore_thank_you] shortcode.' ),
                'type'        => 'select',
                'options'     => $this->get_pages_options(),
                'section'     => 'store_pages',
                'tab'         => 'store',
                'default'     => '',
            ),
            array(
                'id'          => 'course_permalink_slug',
                'label'       => $this->get_translated_text( 'Course Permalink Slug' ),
                'description' => $this->get_translated_text( 'Custom slug for course permalinks and breadcrumb navigation (e.g., "academy", "training"). This will be used as both the URL slug and breadcrumb text.' ),
                'type'        => 'text',
                'section'     => 'store_pages',
                'tab'         => 'store',
                'default'     => 'courses',
            ),
            array(
                'id'          => 'enable_cart_redirect',
                'label'       => $this->get_translated_text( 'Redirect to Cart After Add' ),
                'description' => $this->get_translated_text( 'Redirect customers to cart page after adding a product.' ),
                'type'        => 'checkbox',
                'section'     => 'cart_settings',
                'tab'         => 'store',
                'default'     => '',
            ),
            array(
                'id'          => 'enable_checkout_redirect',
                'label'       => $this->get_translated_text( 'Redirect to Checkout After Add' ),
                'description' => $this->get_translated_text( 'Redirect customers directly to checkout page after adding a product (overrides cart redirect).' ),
                'type'        => 'checkbox',
                'section'     => 'cart_settings',
                'tab'         => 'store',
                'default'     => '',
            ),
            array(
                'id'          => 'enable_ajax_cart',
                'label'       => $this->get_translated_text( 'Enable AJAX Cart' ),
                'description' => $this->get_translated_text( 'Enable AJAX functionality for cart operations.' ),
                'type'        => 'checkbox',
                'section'     => 'cart_settings',
                'tab'         => 'store',
                'default'     => 'on',
            ),

            // Currency settings
            array(
                'id'          => 'enable_currency_conversion',
                'label'       => $this->get_translated_text( 'Enable Currency Conversion' ),
                'description' => $this->get_translated_text( 'Enable automatic currency conversion based on visitor location.' ),
                'type'        => 'checkbox',
                'section'     => 'currency_settings',
                'tab'         => 'store',
                'default'     => '',
            ),
            array(
                'id'          => 'currency_rates',
                'label'       => $this->get_translated_text( 'Currency Exchange Rates' ),
                'description' => $this->get_translated_text( 'Set exchange rates for each currency relative to your store currency (set in General tab). Click "Update Rates" to refresh from external API.' ),
                'type'        => 'currency_rates',
                'section'     => 'currency_settings',
                'tab'         => 'store',
                'default'     => array(),
            ),
            array(
                'id'          => 'exclude_admin_ip_detection',
                'label'       => $this->get_translated_text( 'Exclude Admin from IP Detection' ),
                'description' => $this->get_translated_text( 'Exclude administrators from automatic currency detection for consistent reporting.' ),
                'type'        => 'checkbox',
                'section'     => 'currency_settings',
                'tab'         => 'store',
                'default'     => 'on',
            ),

            // Payment settings
            array(
                'id'          => 'test_mode',
                'label'       => $this->get_translated_text( 'Test Mode' ),
                'description' => $this->get_translated_text( 'Enable test mode for payment gateways.' ),
                'type'        => 'checkbox',
                'section'     => 'payment_settings',
                'tab'         => 'payment',
                'default'     => 'on',
            ),
            array(
                'id'          => 'enabled_gateways',
                'label'       => $this->get_translated_text( 'Enabled Gateways' ),
                'description' => $this->get_translated_text( 'Select the payment gateways to enable.' ),
                'type'        => 'multicheck',
                'options'     => $this->get_gateway_options(),
                'section'     => 'payment_settings',
                'tab'         => 'payment',
                'default'     => array( 'tripay' => 'on' ),
            ),

            // Manual Transfer Bank settings - Simplified
            array(
                'id'          => 'manual_bank_details',
                'label'       => $this->get_translated_text( 'Bank Details' ),
                'description' => $this->get_translated_text( 'Enter "Your Name ▸ Bank ABC ▸ 123456789".' ),
                'type'        => 'text',
                'section'     => 'manual_settings',
                'tab'         => 'payment',
                'default'     => '',
            ),
            array(
                'id'          => 'manual_additional_info',
                'label'       => $this->get_translated_text( 'Additional Information' ),
                'description' => $this->get_translated_text( 'Any additional bank details or reference information.' ),
                'type'        => 'textarea',
                'section'     => 'manual_settings',
                'tab'         => 'payment',
                'default'     => '',
            ),
            array(
                'id'          => 'manual_whatsapp_number',
                'label'       => $this->get_translated_text( 'WhatsApp Number' ),
                'description' => $this->get_translated_text( 'WhatsApp number for payment confirmation (include country code, e.g., +1234567890).' ),
                'type'        => 'text',
                'section'     => 'manual_settings',
                'tab'         => 'payment',
                'default'     => '',
            ),

            // TriPay settings
            array(
                'id'          => 'tripay_test_mode',
                'label'       => $this->get_translated_text( 'TriPay Test Mode' ),
                'description' => $this->get_translated_text( 'Enable to use TriPay sandbox environment for testing.' ),
                'type'        => 'checkbox',
                'section'     => 'tripay_settings',
                'tab'         => 'payment',
                'default'     => 'on',
            ),
            array(
                'id'          => 'tripay_test_api_key',
                'label'       => $this->get_translated_text( 'Test API Key' ),
                'description' => $this->get_translated_text( 'Enter your TriPay test/sandbox API key.' ),
                'type'        => 'text',
                'section'     => 'tripay_settings',
                'tab'         => 'payment',
                'default'     => '',
                'placeholder' => 'DEV-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
            ),
            array(
                'id'          => 'tripay_test_private_key',
                'label'       => $this->get_translated_text( 'Test Private Key' ),
                'description' => $this->get_translated_text( 'Enter your TriPay test/sandbox private key.' ),
                'type'        => 'password',
                'section'     => 'tripay_settings',
                'tab'         => 'payment',
                'default'     => '',
                'placeholder' => 'xxxxx-xxxxx-xxxxx-xxxxx-xxxxx',
            ),
            array(
                'id'          => 'tripay_test_merchant_code',
                'label'       => $this->get_translated_text( 'Test Merchant Code' ),
                'description' => $this->get_translated_text( 'Enter your TriPay test/sandbox merchant code.' ),
                'type'        => 'text',
                'section'     => 'tripay_settings',
                'tab'         => 'payment',
                'default'     => '',
                'placeholder' => 'T0000',
            ),
            array(
                'id'          => 'tripay_live_api_key',
                'label'       => $this->get_translated_text( 'Live API Key' ),
                'description' => $this->get_translated_text( 'Enter your TriPay production API key.' ),
                'type'        => 'text',
                'section'     => 'tripay_settings',
                'tab'         => 'payment',
                'default'     => '',
                'placeholder' => 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
            ),
            array(
                'id'          => 'tripay_live_private_key',
                'label'       => $this->get_translated_text( 'Live Private Key' ),
                'description' => $this->get_translated_text( 'Enter your TriPay production private key.' ),
                'type'        => 'password',
                'section'     => 'tripay_settings',
                'tab'         => 'payment',
                'default'     => '',
                'placeholder' => 'xxxxx-xxxxx-xxxxx-xxxxx-xxxxx',
            ),
            array(
                'id'          => 'tripay_live_merchant_code',
                'label'       => $this->get_translated_text( 'Live Merchant Code' ),
                'description' => $this->get_translated_text( 'Enter your TriPay production merchant code.' ),
                'type'        => 'text',
                'section'     => 'tripay_settings',
                'tab'         => 'payment',
                'default'     => '',
                'placeholder' => 'T0000',
            ),
            array(
                'id'          => 'tripay_callback_info',
                'label'       => $this->get_translated_text( 'Callback URL Info' ),
                'description' => sprintf(
                    $this->get_translated_text( 'Set this URL in your TriPay dashboard: %s' ),
                    '<code>' . home_url( '/wp-json/vrstore/v1/webhooks/tripay' ) . '</code>'
                ),
                'type'        => 'html',
                'section'     => 'tripay_settings',
                'tab'         => 'payment',
                'callback'    => array( $this, 'render_tripay_callback_info' ),
            ),


            // Payment Testing
            array(
                'id'          => 'enable_payment_testing',
                'label'       => $this->get_translated_text( 'Enable Payment Testing' ),
                'description' => $this->get_translated_text( 'Enable payment testing functionality for debugging and development.' ),
                'type'        => 'checkbox',
                'section'     => 'payment_testing',
                'tab'         => 'payment',
                'default'     => '',
            ),
            array(
                'id'          => 'test_payment_amounts',
                'label'       => $this->get_translated_text( 'Test Payment Amounts' ),
                'description' => $this->get_translated_text( 'Comma-separated list of test amounts for payment testing (e.g., 1.00, 5.00, 10.00).' ),
                'type'        => 'text',
                'section'     => 'payment_testing',
                'tab'         => 'payment',
                'default'     => '1.00, 5.00, 10.00, 25.00, 50.00',
                'placeholder' => '1.00, 5.00, 10.00',
            ),
            array(
                'id'          => 'test_customer_email',
                'label'       => $this->get_translated_text( 'Test Customer Email' ),
                'description' => $this->get_translated_text( 'Default email address for test transactions.' ),
                'type'        => 'email',
                'section'     => 'payment_testing',
                'tab'         => 'payment',
                'default'     => 'test@example.com',
            ),
            array(
                'id'          => 'enable_test_webhooks',
                'label'       => $this->get_translated_text( 'Enable Test Webhooks' ),
                'description' => $this->get_translated_text( 'Enable webhook testing for payment gateway integrations.' ),
                'type'        => 'checkbox',
                'section'     => 'payment_testing',
                'tab'         => 'payment',
                'default'     => '',
            ),
            array(
                'id'          => 'test_webhook_url',
                'label'       => $this->get_translated_text( 'Test Webhook URL' ),
                'description' => $this->get_translated_text( 'URL to receive test webhook notifications.' ),
                'type'        => 'url',
                'section'     => 'payment_testing',
                'tab'         => 'payment',
                'default'     => '',
                'placeholder' => 'https://webhook.site/your-unique-url',
            ),
            array(
                'id'          => 'payment_test_logs',
                'label'       => $this->get_translated_text( 'Payment Test Logs' ),
                'description' => $this->get_translated_text( 'View recent payment test transactions and results.' ),
                'type'        => 'html',
                'section'     => 'payment_testing',
                'tab'         => 'payment',
                'callback'    => array( $this, 'render_payment_test_logs' ),
                'default'     => '',
            ),
            array(
                'id'          => 'run_payment_test',
                'label'       => $this->get_translated_text( 'Run Payment Test' ),
                'description' => $this->get_translated_text( 'Execute a test payment transaction with selected gateway and amount.' ),
                'type'        => 'html',
                'section'     => 'payment_testing',
                'tab'         => 'payment',
                'callback'    => array( $this, 'render_payment_test_runner' ),
                'default'     => '',
            ),

            // License settings
            array(
                'id'          => 'license_prefix',
                'label'       => $this->get_translated_text( 'License Key Prefix' ),
                'description' => $this->get_translated_text( 'Enter a prefix for license keys.' ),
                'type'        => 'text',
                'section'     => 'license_settings',
                'tab'         => 'license',
                'default'     => 'VRSTORE-',
            ),
            array(
                'id'          => 'license_length',
                'label'       => $this->get_translated_text( 'License Key Length' ),
                'description' => $this->get_translated_text( 'Enter the length of license keys (excluding prefix).' ),
                'type'        => 'number',
                'section'     => 'license_settings',
                'tab'         => 'license',
                'default'     => 16,
                'min'         => 8,
                'max'         => 32,
            ),
            array(
                'id'          => 'license_expiry',
                'label'       => $this->get_translated_text( 'Default License Expiry' ),
                'description' => $this->get_translated_text( 'Enter the default number of months until licenses expire. Set to 0 for lifetime licenses. This can be overridden by license type settings.' ),
                'type'        => 'number',
                'section'     => 'license_settings',
                'tab'         => 'license',
                'default'     => 12,
                'min'         => 0,
            ),
            array(
                'id'          => 'max_activations',
                'label'       => $this->get_translated_text( 'Default Maximum Activations' ),
                'description' => $this->get_translated_text( 'Enter the default maximum number of activations per license. This can be overridden by license type settings.' ),
                'type'        => 'number',
                'section'     => 'license_settings',
                'tab'         => 'license',
                'default'     => 1,
                'min'         => 1,
            ),
            array(
                'id'          => 'enable_license_types',
                'label'       => $this->get_translated_text( 'Enable License Type Configuration' ),
                'description' => $this->get_translated_text( 'Enable license type-based expiration and activation limits. When enabled, you can configure different settings for each license type.' ),
                'type'        => 'checkbox',
                'section'     => 'license_settings',
                'tab'         => 'license',
                'default'     => '',
            ),
            array(
                'id'          => 'custom_license_types',
                'label'       => $this->get_translated_text( 'Custom License Types' ),
                'type'        => 'custom_license_type_config',
                'section'     => 'license_settings',
                'tab'         => 'license',
                'default'     => array(),
            ),

            // License Management Section
            array(
                'id'          => 'license_templates',
                'label'       => $this->get_translated_text( 'License Templates' ),
                'description' => $this->get_translated_text( 'Create predefined license templates for quick license generation with preset configurations.' ),
                'type'        => 'textarea',
                'section'     => 'license_management',
                'tab'         => 'license',
                'default'     => '',
            ),
            array(
                'id'          => 'auto_renewal_enabled',
                'label'       => $this->get_translated_text( 'Enable Auto-Renewal' ),
                'description' => $this->get_translated_text( 'Automatically renew licenses before expiration based on customer preferences.' ),
                'type'        => 'checkbox',
                'section'     => 'license_management',
                'tab'         => 'license',
                'default'     => '',
            ),
            array(
                'id'          => 'renewal_reminder_days',
                'label'       => $this->get_translated_text( 'Renewal Reminder (Days)' ),
                'description' => $this->get_translated_text( 'Send renewal reminders X days before license expiration.' ),
                'type'        => 'number',
                'section'     => 'license_management',
                'tab'         => 'license',
                'default'     => '30',
            ),
            array(
                'id'          => 'license_transfer_enabled',
                'label'       => $this->get_translated_text( 'Allow License Transfer' ),
                'description' => $this->get_translated_text( 'Allow customers to transfer licenses between domains or accounts.' ),
                'type'        => 'checkbox',
                'section'     => 'license_management',
                'tab'         => 'license',
                'default'     => '',
            ),

            // License Analytics Section
            array(
                'id'          => 'track_license_usage',
                'label'       => $this->get_translated_text( 'Track License Usage' ),
                'description' => $this->get_translated_text( 'Enable detailed tracking of license activations, deactivations, and usage patterns.' ),
                'type'        => 'checkbox',
                'section'     => 'license_analytics',
                'tab'         => 'license',
                'default'     => '1',
            ),
            array(
                'id'          => 'analytics_retention_days',
                'label'       => $this->get_translated_text( 'Analytics Retention (Days)' ),
                'description' => $this->get_translated_text( 'How long to keep license analytics data (0 = forever).' ),
                'type'        => 'number',
                'section'     => 'license_analytics',
                'tab'         => 'license',
                'default'     => '365',
            ),
            array(
                'id'          => 'generate_usage_reports',
                'label'       => $this->get_translated_text( 'Generate Usage Reports' ),
                'description' => $this->get_translated_text( 'Automatically generate monthly usage reports for license analytics.' ),
                'type'        => 'checkbox',
                'section'     => 'license_analytics',
                'tab'         => 'license',
                'default'     => '',
            ),
            array(
                'id'          => 'track_domain_patterns',
                'label'       => $this->get_translated_text( 'Track Domain Patterns' ),
                'description' => $this->get_translated_text( 'Analyze domain activation patterns and detect suspicious activities.' ),
                'type'        => 'checkbox',
                'section'     => 'license_analytics',
                'tab'         => 'license',
                'default'     => '1',
            ),
            array(
                'id'          => 'license_usage_alerts',
                'label'       => $this->get_translated_text( 'Usage Alerts' ),
                'description' => $this->get_translated_text( 'Send email alerts when license usage exceeds thresholds or shows unusual patterns.' ),
                'type'        => 'checkbox',
                'section'     => 'license_analytics',
                'tab'         => 'license',
                'default'     => '',
            ),
            array(
                'id'          => 'analytics_dashboard_widgets',
                'label'       => $this->get_translated_text( 'Dashboard Widgets' ),
                'description' => $this->get_translated_text( 'Display license analytics widgets on the WordPress dashboard.' ),
                'type'        => 'checkbox',
                'section'     => 'license_analytics',
                'tab'         => 'license',
                'default'     => '1',
            ),
            array(
                'id'          => 'export_analytics_data',
                'label'       => $this->get_translated_text( 'Enable Data Export' ),
                'description' => $this->get_translated_text( 'Allow exporting license analytics data to CSV/JSON formats.' ),
                'type'        => 'checkbox',
                'section'     => 'license_analytics',
                'tab'         => 'license',
                'default'     => '',
            ),
            array(
                'id'          => 'real_time_monitoring',
                'label'       => $this->get_translated_text( 'Real-time Monitoring' ),
                'description' => $this->get_translated_text( 'Enable real-time license activation/deactivation monitoring and notifications.' ),
                'type'        => 'checkbox',
                'section'     => 'license_analytics',
                'tab'         => 'license',
                'default'     => '',
            ),
            array(
                'id'          => 'analytics_api_access',
                'label'       => $this->get_translated_text( 'Analytics API Access' ),
                'description' => $this->get_translated_text( 'Provide REST API endpoints for accessing license analytics data programmatically.' ),
                'type'        => 'checkbox',
                'section'     => 'license_analytics',
                'tab'         => 'license',
                'default'     => '',
            ),

            // License Bulk Operations Section
            array(
                'id'          => 'bulk_operations_enabled',
                'label'       => $this->get_translated_text( 'Enable Bulk Operations' ),
                'description' => $this->get_translated_text( 'Allow bulk license generation, activation, deactivation, and management operations.' ),
                'type'        => 'checkbox',
                'section'     => 'license_bulk_operations',
                'tab'         => 'license',
                'default'     => '1',
            ),
            array(
                'id'          => 'bulk_generation_limit',
                'label'       => $this->get_translated_text( 'Bulk Generation Limit' ),
                'description' => $this->get_translated_text( 'Maximum number of licenses that can be generated in a single bulk operation.' ),
                'type'        => 'number',
                'section'     => 'license_bulk_operations',
                'tab'         => 'license',
                'default'     => '100',
            ),
            array(
                'id'          => 'bulk_export_format',
                'label'       => $this->get_translated_text( 'Bulk Export Format' ),
                'description' => $this->get_translated_text( 'Default format for bulk license exports.' ),
                'type'        => 'select',
                'section'     => 'license_bulk_operations',
                'tab'         => 'license',
                'options'     => array(
                    'csv'  => 'CSV',
                    'json' => 'JSON',
                    'xml'  => 'XML',
                ),
                'default'     => 'csv',
            ),
            // API settings
            array(
                'id'          => 'api_key',
                'label'       => $this->get_translated_text( 'API Key' ),
                'description' => $this->get_translated_text( 'Your API key for accessing the REST API.' ),
                'type'        => 'text',
                'section'     => 'api_settings',
                'tab'         => 'api',
                'default'     => $this->generate_api_key(),
                'readonly'    => true,
            ),
            array(
                'id'          => 'regenerate_api_key',
                'label'       => $this->get_translated_text( 'Regenerate API Key' ),
                'description' => $this->get_translated_text( 'Check this box and save settings to regenerate the API key.' ),
                'type'        => 'checkbox',
                'section'     => 'api_settings',
                'tab'         => 'api',
                'default'     => '',
            ),
            // API Security fields
            array(
                'id'          => 'api_rate_limit',
                'label'       => $this->get_translated_text( 'API Rate Limit' ),
                'description' => $this->get_translated_text( 'Maximum number of API requests per hour per IP address.' ),
                'type'        => 'number',
                'section'     => 'api_security',
                'tab'         => 'api',
                'default'     => 1000,
                'min'         => 100,
                'max'         => 10000,
            ),
            array(
                'id'          => 'api_require_ssl',
                'label'       => $this->get_translated_text( 'Require SSL' ),
                'description' => $this->get_translated_text( 'Force API requests to use HTTPS for security.' ),
                'type'        => 'checkbox',
                'section'     => 'api_security',
                'tab'         => 'api',
                'default'     => 'on',
            ),
            array(
                'id'          => 'api_enable_cors',
                'label'       => $this->get_translated_text( 'Enable CORS' ),
                'description' => $this->get_translated_text( 'Allow cross-origin requests to the API.' ),
                'type'        => 'checkbox',
                'section'     => 'api_security',
                'tab'         => 'api',
                'default'     => '',
            ),
            array(
                'id'          => 'api_allowed_origins',
                'label'       => $this->get_translated_text( 'Allowed Origins' ),
                'description' => $this->get_translated_text( 'Enter allowed origins for CORS, one per line. Use * for all origins (not recommended for production).' ),
                'type'        => 'textarea',
                'section'     => 'api_security',
                'tab'         => 'api',
                'default'     => '',
                'rows'        => 4,
            ),
            array(
                'id'          => 'api_ip_whitelist',
                'label'       => $this->get_translated_text( 'IP Whitelist' ),
                'description' => $this->get_translated_text( 'Enter allowed IP addresses for API access, one per line. Leave empty to allow all IPs.' ),
                'type'        => 'textarea',
                'section'     => 'api_security',
                'tab'         => 'api',
                'default'     => '',
                'rows'        => 4,
            ),
            array(
                'id'          => 'api_enable_2fa',
                'label'       => $this->get_translated_text( 'Enable Two-Factor Authentication' ),
                'description' => $this->get_translated_text( 'Require two-factor authentication for API access to sensitive endpoints.' ),
                'type'        => 'checkbox',
                'section'     => 'api_security',
                'tab'         => 'api',
                'default'     => '',
            ),
            array(
                'id'          => 'api_token_expiry',
                'label'       => $this->get_translated_text( 'API Token Expiry (Hours)' ),
                'description' => $this->get_translated_text( 'Automatically expire API tokens after specified hours for enhanced security.' ),
                'type'        => 'number',
                'section'     => 'api_security',
                'tab'         => 'api',
                'default'     => 24,
                'min'         => 1,
                'max'         => 8760,
            ),
            array(
                'id'          => 'api_brute_force_protection',
                'label'       => $this->get_translated_text( 'Brute Force Protection' ),
                'description' => $this->get_translated_text( 'Block IP addresses after multiple failed authentication attempts.' ),
                'type'        => 'checkbox',
                'section'     => 'api_security',
                'tab'         => 'api',
                'default'     => '1',
            ),
            array(
                'id'          => 'api_max_failed_attempts',
                'label'       => $this->get_translated_text( 'Max Failed Attempts' ),
                'description' => $this->get_translated_text( 'Number of failed attempts before blocking an IP address.' ),
                'type'        => 'number',
                'section'     => 'api_security',
                'tab'         => 'api',
                'default'     => 5,
                'min'         => 3,
                'max'         => 20,
            ),
            array(
                'id'          => 'api_block_duration',
                'label'       => $this->get_translated_text( 'Block Duration (Minutes)' ),
                'description' => $this->get_translated_text( 'How long to block an IP address after exceeding failed attempts.' ),
                'type'        => 'number',
                'section'     => 'api_security',
                'tab'         => 'api',
                'default'     => 60,
                'min'         => 5,
                'max'         => 1440,
            ),
            array(
                'id'          => 'api_security_headers',
                'label'       => $this->get_translated_text( 'Security Headers' ),
                'description' => $this->get_translated_text( 'Add security headers to API responses (X-Frame-Options, X-Content-Type-Options, etc.).' ),
                'type'        => 'checkbox',
                'section'     => 'api_security',
                'tab'         => 'api',
                'default'     => '1',
            ),
            array(
                'id'          => 'api_request_signing',
                'label'       => $this->get_translated_text( 'Request Signing' ),
                'description' => $this->get_translated_text( 'Require cryptographic signing of API requests for enhanced security.' ),
                'type'        => 'checkbox',
                'section'     => 'api_security',
                'tab'         => 'api',
                'default'     => '',
            ),
            // API Monitoring fields
            array(
                'id'          => 'api_enable_logging',
                'label'       => $this->get_translated_text( 'Enable API Logging' ),
                'description' => $this->get_translated_text( 'Log all API requests for monitoring and debugging.' ),
                'type'        => 'checkbox',
                'section'     => 'api_monitoring',
                'tab'         => 'api',
                'default'     => 'on',
            ),
            array(
                'id'          => 'api_log_retention',
                'label'       => $this->get_translated_text( 'API Log Retention' ),
                'description' => $this->get_translated_text( 'Number of days to keep API logs before automatic cleanup.' ),
                'type'        => 'number',
                'section'     => 'api_monitoring',
                'tab'         => 'api',
                'default'     => 30,
                'min'         => 1,
                'max'         => 365,
            ),
            array(
                'id'          => 'api_log_failed_requests',
                'label'       => $this->get_translated_text( 'Log Failed Requests' ),
                'description' => $this->get_translated_text( 'Log failed API requests for security monitoring.' ),
                'type'        => 'checkbox',
                'section'     => 'api_monitoring',
                'tab'         => 'api',
                'default'     => 'on',
            ),
            array(
                'id'          => 'api_performance_monitoring',
                'label'       => $this->get_translated_text( 'Performance Monitoring' ),
                'description' => $this->get_translated_text( 'Track API response times and performance metrics.' ),
                'type'        => 'checkbox',
                'section'     => 'api_monitoring',
                'tab'         => 'api',
                'default'     => '',
            ),
            array(
                'id'          => 'api_real_time_alerts',
                'label'       => $this->get_translated_text( 'Real-time Alerts' ),
                'description' => $this->get_translated_text( 'Send instant notifications for API anomalies, errors, or security threats.' ),
                'type'        => 'checkbox',
                'section'     => 'api_monitoring',
                'tab'         => 'api',
                'default'     => '',
            ),
            array(
                'id'          => 'api_response_time_threshold',
                'label'       => $this->get_translated_text( 'Response Time Threshold (ms)' ),
                'description' => $this->get_translated_text( 'Alert when API response times exceed this threshold in milliseconds.' ),
                'type'        => 'number',
                'section'     => 'api_monitoring',
                'tab'         => 'api',
                'default'     => 5000,
                'min'         => 100,
                'max'         => 30000,
            ),
            array(
                'id'          => 'api_error_rate_threshold',
                'label'       => $this->get_translated_text( 'Error Rate Threshold (%)' ),
                'description' => $this->get_translated_text( 'Alert when API error rate exceeds this percentage within an hour.' ),
                'type'        => 'number',
                'section'     => 'api_monitoring',
                'tab'         => 'api',
                'default'     => 10,
                'min'         => 1,
                'max'         => 50,
            ),
            array(
                'id'          => 'api_usage_analytics',
                'label'       => $this->get_translated_text( 'Usage Analytics' ),
                'description' => $this->get_translated_text( 'Track detailed API usage statistics and generate analytics reports.' ),
                'type'        => 'checkbox',
                'section'     => 'api_monitoring',
                'tab'         => 'api',
                'default'     => '1',
            ),
            array(
                'id'          => 'api_endpoint_monitoring',
                'label'       => $this->get_translated_text( 'Endpoint Monitoring' ),
                'description' => $this->get_translated_text( 'Monitor individual API endpoints for performance and availability.' ),
                'type'        => 'checkbox',
                'section'     => 'api_monitoring',
                'tab'         => 'api',
                'default'     => '1',
            ),
            array(
                'id'          => 'api_health_checks',
                'label'       => $this->get_translated_text( 'Health Checks' ),
                'description' => $this->get_translated_text( 'Perform automated health checks on API endpoints and services.' ),
                'type'        => 'checkbox',
                'section'     => 'api_monitoring',
                'tab'         => 'api',
                'default'     => '',
            ),
            array(
                'id'          => 'api_monitoring_dashboard',
                'label'       => $this->get_translated_text( 'Monitoring Dashboard' ),
                'description' => $this->get_translated_text( 'Display API monitoring widgets and charts on the admin dashboard.' ),
                'type'        => 'checkbox',
                'section'     => 'api_monitoring',
                'tab'         => 'api',
                'default'     => '1',
            ),
            array(
                'id'          => 'api_export_logs',
                'label'       => $this->get_translated_text( 'Export Logs' ),
                'description' => $this->get_translated_text( 'Allow exporting API logs and monitoring data for external analysis.' ),
                'type'        => 'checkbox',
                'section'     => 'api_monitoring',
                'tab'         => 'api',
                'default'     => '',
            ),
            array(
                'id'          => 'api_documentation',
                'label'       => $this->get_translated_text( 'API Documentation' ),
                'description' => $this->get_translated_text( 'View available API endpoints and their usage.' ),
                'type'        => 'api_documentation',
                'section'     => 'api_settings',
                'tab'         => 'api',
                'default'     => '',
            ),

            // Advanced settings
            array(
                'id'          => 'debug_mode',
                'label'       => $this->get_translated_text( 'Debug Mode' ),
                'description' => $this->get_translated_text( 'Enable comprehensive debug logging for troubleshooting. Includes performance monitoring, API calls, database queries, and error tracking. Logs are automatically cleaned after 30 days.' ),
                'type'        => 'checkbox',
                'section'     => 'advanced_settings',
                'tab'         => 'advanced',
                'default'     => '',
            ),
            array(
                'id'          => 'debug_level',
                'label'       => $this->get_translated_text( 'Debug Level' ),
                'description' => $this->get_translated_text( 'Select the level of debug information to log.' ),
                'type'        => 'select',
                'section'     => 'advanced_settings',
                'tab'         => 'advanced',
                'options'     => array(
                    'basic'    => $this->get_translated_text( 'Basic - Errors and warnings only' ),
                    'detailed' => $this->get_translated_text( 'Detailed - Include API calls and database queries' ),
                    'verbose'  => $this->get_translated_text( 'Verbose - Full debugging with performance metrics' )
                ),
                'default'     => 'basic',
            ),
            array(
                'id'          => 'uninstall_data',
                'label'       => $this->get_translated_text( 'Remove Data on Uninstall' ),
                'description' => $this->get_translated_text( 'Completely remove all plugin data when uninstalling. This includes: database tables (orders, licenses, customers, download logs, payment logs, course analytics, enrollments, progress tracking, video tracking), custom post types (products, orders, courses), user roles, settings, transients, user metadata, download tracking data, course progress data, domain activation logs, and scheduled tasks. <strong>Warning:</strong> This action cannot be undone!' ),
                'type'        => 'checkbox',
                'section'     => 'advanced_settings',
                'tab'         => 'advanced',
                'default'     => '',
            ),
            array(
                'id'          => 'create_backup_uninstall',
                'label'       => $this->get_translated_text( 'Create Backup before Uninstall' ),
                'description' => $this->get_translated_text( 'Automatically create a complete backup of all plugin data before uninstalling. Includes database export, settings configuration, download logs, and file attachments. Backup will be saved to wp-content/uploads/vrstore-backups/ directory.' ),
                'type'        => 'checkbox',
                'section'     => 'advanced_settings',
                'tab'         => 'advanced',
                'default'     => 'on',
            ),

            array(
                'id'          => 'cache_expiry',
                'label'       => $this->get_translated_text( 'Cache Expiry' ),
                'description' => $this->get_translated_text( 'Enter the number of hours until cache expires.' ),
                'type'        => 'number',
                'section'     => 'advanced_settings',
                'tab'         => 'advanced',
                'default'     => 24,
                'min'         => 1,
            ),
            array(
                'id'          => 'enable_math_captcha',
                'label'       => $this->get_translated_text( 'Enable Math Anti-Spam' ),
                'description' => $this->get_translated_text( 'Enable math captcha for login and registration forms to prevent spam and bot attacks.' ),
                'type'        => 'checkbox',
                'section'     => 'advanced_settings',
                'tab'         => 'advanced',
                'default'     => 'on',
            ),
            array(
                'id'          => 'math_captcha_difficulty',
                'label'       => $this->get_translated_text( 'Math Captcha Difficulty' ),
                'description' => $this->get_translated_text( 'Select the difficulty level for math captcha questions.' ),
                'type'        => 'select',
                'section'     => 'advanced_settings',
                'tab'         => 'advanced',
                'options'     => array(
                    'easy'   => $this->get_translated_text( 'Easy (1-10)' ),
                    'medium' => $this->get_translated_text( 'Medium (1-50)' ),
                    'hard'   => $this->get_translated_text( 'Hard (1-100)' ),
                ),
                'default'     => 'easy',
            ),
            array(
                'id'          => 'math_captcha_operations',
                'label'       => $this->get_translated_text( 'Allowed Operations' ),
                'description' => $this->get_translated_text( 'Select which mathematical operations to include in captcha questions.' ),
                'type'        => 'multicheck',
                'section'     => 'advanced_settings',
                'tab'         => 'advanced',
                'options'     => array(
                    'addition'       => $this->get_translated_text( 'Addition (+)' ),
                    'subtraction'    => $this->get_translated_text( 'Subtraction (-)' ),
                    'multiplication' => $this->get_translated_text( 'Multiplication (×)' ),
                ),
                'default'     => array( 'addition' => 'on', 'subtraction' => 'on' ),
            ),
            
            // Login attempt limiting settings
            array(
                'id'          => 'enable_login_attempts_limit',
                'label'       => $this->get_translated_text( 'Enable Login Attempts Limit' ),
                'description' => $this->get_translated_text( 'Enable limiting login attempts to prevent brute force attacks.' ),
                'type'        => 'checkbox',
                'section'     => 'advanced_settings',
                'tab'         => 'advanced',
                'default'     => 'on',
            ),
            array(
                'id'          => 'max_login_attempts',
                'label'       => $this->get_translated_text( 'Maximum Login Attempts' ),
                'description' => $this->get_translated_text( 'Number of failed login attempts allowed before locking the account.' ),
                'type'        => 'number',
                'section'     => 'advanced_settings',
                'tab'         => 'advanced',
                'default'     => 5,
                'min'         => 1,
                'max'         => 20,
            ),
            array(
                'id'          => 'login_lockout_duration',
                'label'       => $this->get_translated_text( 'Lockout Duration (Minutes)' ),
                'description' => $this->get_translated_text( 'Number of minutes to lock the account after exceeding maximum login attempts.' ),
                'type'        => 'number',
                'section'     => 'advanced_settings',
                'tab'         => 'advanced',
                'default'     => 15,
                'min'         => 1,
                'max'         => 1440,
            ),
            array(
                'id'          => 'login_attempts_tracking_method',
                'label'       => $this->get_translated_text( 'Tracking Method' ),
                'description' => $this->get_translated_text( 'Choose how to track login attempts - by IP address, email/username, or both.' ),
                'type'        => 'select',
                'section'     => 'advanced_settings',
                'tab'         => 'advanced',
                'options'     => array(
                    'ip'       => $this->get_translated_text( 'IP Address Only' ),
                    'email'    => $this->get_translated_text( 'Email/Username Only' ),
                    'both'     => $this->get_translated_text( 'Both IP and Email/Username' ),
                ),
                'default'     => 'both',
            ),
            array(
                'id'          => 'enable_login_attempt_notifications',
                'label'       => $this->get_translated_text( 'Enable Login Attempt Notifications' ),
                'description' => $this->get_translated_text( 'Send email notifications to admin when accounts are locked due to failed login attempts.' ),
                'type'        => 'checkbox',
                'section'     => 'advanced_settings',
                'tab'         => 'advanced',
                'default'     => 'on',
            ),
            array(
                'id'          => 'login_lockout_message',
                'label'       => $this->get_translated_text( 'Lockout Message' ),
                'description' => $this->get_translated_text( 'Message displayed when login is blocked due to too many failed attempts. Placeholders: {attempts}, {duration}, {remaining_time}' ),
                'type'        => 'textarea',
                'section'     => 'advanced_settings',
                'tab'         => 'advanced',
                'default'     => $this->get_translated_text( 'Too many failed login attempts. Your account has been locked for {duration} minutes. Please try again later.' ),
                'rows'        => 3,
            ),

            // Download settings
            array(
                'id'          => 'enable_download_limits',
                'label'       => $this->get_translated_text( 'Enable Download Limits' ),
                'description' => $this->get_translated_text( 'Enable download limits to prevent abuse and control access to digital products.' ),
                'type'        => 'checkbox',
                'section'     => 'download_settings',
                'tab'         => 'advanced',
                'default'     => '',
            ),
            array(
                'id'          => 'daily_download_limit_per_user',
                'label'       => $this->get_translated_text( 'Daily Downloads Per User' ),
                'description' => $this->get_translated_text( 'Maximum number of downloads per user per day. Set to 0 for unlimited.' ),
                'type'        => 'number',
                'section'     => 'download_settings',
                'tab'         => 'advanced',
                'default'     => 10,
                'min'         => 0,
            ),
            array(
                'id'          => 'restrict_downloads_by_location',
                'label'       => $this->get_translated_text( 'Restrict Downloads by Location' ),
                'description' => $this->get_translated_text( 'Restrict downloads based on the location of the first order. Users can only download from the same location as their first purchase.' ),
                'type'        => 'checkbox',
                'section'     => 'download_settings',
                'tab'         => 'advanced',
                'default'     => '',
            ),
            array(
                'id'          => 'location_restriction_type',
                'label'       => $this->get_translated_text( 'Location Restriction Type' ),
                'description' => $this->get_translated_text( 'Choose how strict the location restriction should be.' ),
                'type'        => 'select',
                'section'     => 'download_settings',
                'tab'         => 'advanced',
                'options'     => array(
                    'ip'      => $this->get_translated_text( 'Same IP Address' ),
                    'country' => $this->get_translated_text( 'Same Country' ),
                    'city'    => $this->get_translated_text( 'Same City' ),
                ),
                'default'     => 'country',
            ),
            array(
                'id'          => 'location_restriction_message',
                'label'       => $this->get_translated_text( 'Location Restriction Message' ),
                'description' => $this->get_translated_text( 'Message displayed when downloads are restricted due to location mismatch. Available placeholders: {restriction_type}, {first_order_location}, {current_location}' ),
                'type'        => 'textarea',
                'section'     => 'download_settings',
                'tab'         => 'advanced',
                'default'     => $this->get_translated_text( 'Download access denied. Downloads are restricted to the {restriction_type} of your first order ({first_order_location}). Your current location is {current_location}.' ),
            ),
            array(
                'id'          => 'download_limit_message',
                'label'       => $this->get_translated_text( 'Download Limit Exceeded Message' ),
                'description' => $this->get_translated_text( 'Message displayed when download limits are exceeded. Available placeholders: {limit}, {period}, {reset_time}' ),
                'type'        => 'textarea',
                'section'     => 'download_settings',
                'tab'         => 'advanced',
                'default'     => $this->get_translated_text( 'Download limit exceeded. You have reached the maximum of {limit} downloads per {period}. Please try again after {reset_time}.' ),
            ),
            array(
                'id'          => 'exclude_admin_from_limits',
                'label'       => $this->get_translated_text( 'Exclude Administrators' ),
                'description' => $this->get_translated_text( 'Exclude administrators from download limits for testing purposes.' ),
                'type'        => 'checkbox',
                'section'     => 'download_settings',
                'tab'         => 'advanced',
                'default'     => 'on',
            ),

            // File Protection Settings
            array(
                'id'          => 'protected_file_types',
                'label'       => $this->get_translated_text( 'Protected File Types' ),
                'description' => $this->get_translated_text( 'Comma-separated list of file extensions to protect (e.g., pdf,zip,doc,mp4).' ),
                'type'        => 'text',
                'section'     => 'file_protection_settings',
                'tab'         => 'advanced',
                'default'     => 'pdf,zip,doc,docx,mp4,mp3,avi,mov',
            ),
            array(
                'id'          => 'enable_direct_access_protection',
                'label'       => $this->get_translated_text( 'Enable Direct Access Protection' ),
                'description' => $this->get_translated_text( 'Prevent direct access to protected files via URL.' ),
                'type'        => 'checkbox',
                'section'     => 'file_protection_settings',
                'tab'         => 'advanced',
                'default'     => 'on',
            ),
            array(
                'id'          => 'file_access_rate_limit',
                'label'       => $this->get_translated_text( 'File Access Rate Limit' ),
                'description' => $this->get_translated_text( 'Maximum file access attempts per minute per IP address.' ),
                'type'        => 'number',
                'section'     => 'file_protection_settings',
                'tab'         => 'advanced',
                'default'     => 10,
                'min'         => 1,
                'max'         => 100,
            ),
            array(
                'id'          => 'public_directories',
                'label'       => $this->get_translated_text( 'Public Directories' ),
                'description' => $this->get_translated_text( 'Comma-separated list of directories that should remain publicly accessible (relative to uploads folder).' ),
                'type'        => 'textarea',
                'section'     => 'file_protection_settings',
                'tab'         => 'advanced',
                'default'     => 'thumbnails,previews,public',
            ),
            array(
                'id'          => 'max_file_size_mb',
                'label'       => $this->get_translated_text( 'Maximum Protected File Size (MB)' ),
                'description' => $this->get_translated_text( 'Maximum file size in MB for files that can be protected. Larger files will be excluded from protection.' ),
                'type'        => 'number',
                'section'     => 'file_protection_settings',
                'tab'         => 'advanced',
                'default'     => 100,
                'min'         => 1,
                'max'         => 1000,
            ),
            
            // Enhanced File Protection Settings
            array(
                'id'          => 'enable_enhanced_archive_protection',
                'label'       => $this->get_translated_text( 'Enhanced Archive Protection' ),
                'description' => $this->get_translated_text( 'Enable advanced protection for archive files (ZIP, RAR, 7Z, TAR, GZ) with additional security measures including user agent filtering and hotlink prevention.' ),
                'type'        => 'checkbox',
                'section'     => 'file_protection_settings',
                'tab'         => 'advanced',
                'default'     => 'on',
            ),
            array(
                'id'          => 'enable_enhanced_document_protection',
                'label'       => $this->get_translated_text( 'Enhanced Document Protection' ),
                'description' => $this->get_translated_text( 'Enable advanced protection for document files (PDF, DOC, DOCX) with additional security headers and access controls.' ),
                'type'        => 'checkbox',
                'section'     => 'file_protection_settings',
                'tab'         => 'advanced',
                'default'     => 'on',
            ),
            array(
                'id'          => 'block_suspicious_user_agents',
                'label'       => $this->get_translated_text( 'Block Suspicious User Agents' ),
                'description' => $this->get_translated_text( 'Block access from known download managers, bots, and automated tools that might attempt to bypass protection.' ),
                'type'        => 'checkbox',
                'section'     => 'file_protection_settings',
                'tab'         => 'advanced',
                'default'     => 'on',
            ),
            array(
                'id'          => 'enable_hotlink_protection',
                'label'       => $this->get_translated_text( 'Enable Hotlink Protection' ),
                'description' => $this->get_translated_text( 'Prevent other websites from directly linking to your protected files, reducing bandwidth theft and unauthorized access.' ),
                'type'        => 'checkbox',
                'section'     => 'file_protection_settings',
                'tab'         => 'advanced',
                'default'     => 'on',
            ),
            array(
                'id'          => 'unauthorized_access_handling',
                'label'       => $this->get_translated_text( 'Unauthorized Access Handling' ),
                'description' => $this->get_translated_text( 'How to handle unauthorized access attempts to protected files.' ),
                'type'        => 'select',
                'section'     => 'file_protection_settings',
                'tab'         => 'advanced',
                'default'     => 'show_404',
                'options'     => array(
                    'show_404'        => $this->get_translated_text( 'Show 404 Error (Recommended)' ),
                    'redirect_login'  => $this->get_translated_text( 'Redirect to Login Page' ),
                    'show_access_denied' => $this->get_translated_text( 'Show Access Denied Message' ),
                ),
            ),
            array(
                'id'          => 'enable_access_attempt_logging',
                'label'       => $this->get_translated_text( 'Log Access Attempts' ),
                'description' => $this->get_translated_text( 'Log all unauthorized access attempts for security monitoring and analysis.' ),
                'type'        => 'checkbox',
                'section'     => 'file_protection_settings',
                'tab'         => 'advanced',
                'default'     => 'on',
            ),
            array(
                'id'          => 'max_unauthorized_attempts',
                'label'       => $this->get_translated_text( 'Max Unauthorized Attempts' ),
                'description' => $this->get_translated_text( 'Maximum number of unauthorized access attempts per IP address per hour before temporary blocking.' ),
                'type'        => 'number',
                'section'     => 'file_protection_settings',
                'tab'         => 'advanced',
                'default'     => 10,
                'min'         => 1,
                'max'         => 100,
            ),
            array(
                'id'          => 'temp_block_duration',
                'label'       => $this->get_translated_text( 'Temporary Block Duration (minutes)' ),
                'description' => $this->get_translated_text( 'How long to temporarily block IP addresses that exceed the maximum unauthorized attempts.' ),
                'type'        => 'number',
                'section'     => 'file_protection_settings',
                'tab'         => 'advanced',
                'default'     => 60,
                'min'         => 5,
                'max'         => 1440,
            ),

            // Tools tab fields
            // Reset Tools
            array(
                'id'          => 'reset_settings',
                'label'       => $this->get_translated_text( 'Reset Settings' ),
                'description' => $this->get_translated_text( 'Restore all plugin settings to their default values. This includes licensing, API, downloads, download tracking limits, coupons, and integration settings. Current settings will be backed up automatically before reset.' ),
                'type'        => 'checkbox',
                'section'     => 'reset_tools',
                'tab'         => 'tools',
                'default'     => '',
            ),
            array(
                'id'          => 'reset_data',
                'label'       => $this->get_translated_text( 'Reset All Data' ),
                'description' => $this->get_translated_text( '<strong>Complete Plugin Reset:</strong> This will permanently remove ALL plugin data including:<br>• All database tables (orders, licenses, customers, download logs, payment logs, carts, sessions, course analytics, enrollments, progress tracking)<br>• All posts (products, orders, courses)<br>• All user metadata and customer roles<br>• All plugin options and settings<br>• All transients and cached data<br>• All download tracking data and limits<br>• All course progress, enrollments, and video tracking data<br>• All domain activation logs and license tracking<br>• All scheduled tasks and cron jobs<br><strong>⚠️ CRITICAL WARNING:</strong> This action is completely irreversible and will erase everything! Use only for complete fresh start or before uninstallation.' ),
                'type'        => 'checkbox',
                'section'     => 'reset_tools',
                'tab'         => 'tools',
                'default'     => '',
            ),
            array(
                'id'          => 'flush_cache',
                'label'       => $this->get_translated_text( 'Flush All Caches' ),
                'description' => $this->get_translated_text( 'Clear all plugin caches including transients, object cache, download tracking cache, and third-party cache integrations. This helps resolve display issues and ensures fresh data loading.' ),
                'type'        => 'checkbox',
                'section'     => 'reset_tools',
                'tab'         => 'tools',
                'default'     => '',
            ),

            // Removed compatibility tools

            // Maintenance Tools
            array(
                'id'          => 'cleanup_logs',
                'label'       => $this->get_translated_text( 'System Cleanup' ),
                'description' => $this->get_translated_text( 'Remove old log files (90+ days), expired transients, outdated session data (7+ days), old download tracking records (30+ days), and clean debug logs. Helps improve database performance and reduce storage usage.' ),
                'type'        => 'checkbox',
                'section'     => 'maintenance_tools',
                'tab'         => 'tools',
                'default'     => '',
            ),
            array(
                'id'          => 'optimize_database',
                'label'       => $this->get_translated_text( 'Database Optimization' ),
                'description' => $this->get_translated_text( 'Optimize all plugin database tables including download logs, payment logs, and core WordPress tables for improved performance. Includes defragmentation, index optimization, and space reclamation with detailed before/after statistics.' ),
                'type'        => 'checkbox',
                'section'     => 'maintenance_tools',
                'tab'         => 'tools',
                'default'     => '',
            ),
            array(
                'id'          => 'export_settings',
                'label'       => $this->get_translated_text( 'Export Configuration' ),
                'description' => $this->get_translated_text( 'Create comprehensive backup including all plugin settings, download tracking configuration, download limits, active addons configuration, site information, and version details. Export is saved securely and includes download link for easy restoration.' ),
                'type'        => 'checkbox',
                'section'     => 'maintenance_tools',
                'tab'         => 'tools',
                'default'     => '',
            ),


            // Integration tab fields - Cache Integration
            array(
                'id'          => 'litespeed_cache_enabled',
                'label'       => $this->get_translated_text( 'Enable LiteSpeed Cache Integration' ),
                'description' => $this->get_translated_text( 'Enable integration with LiteSpeed Cache plugin for better performance.' ),
                'type'        => 'checkbox',
                'section'     => 'cache_integration',
                'tab'         => 'integration',
                'default'     => '1',
            ),
            array(
                'id'          => 'litespeed_cache_status',
                'label'       => $this->get_translated_text( 'LiteSpeed Cache Status' ),
                'description' => $this->get_translated_text( 'Current status of LiteSpeed Cache plugin.' ),
                'type'        => 'html',
                'section'     => 'cache_integration',
                'tab'         => 'integration',
                'callback'    => array( $this, 'render_litespeed_status' ),
                'default'     => '',
            ),
            array(
                'id'          => 'litespeed_purge_on_order',
                'label'       => $this->get_translated_text( 'Purge Cache on Order' ),
                'description' => $this->get_translated_text( 'Automatically purge LiteSpeed cache when new orders are created.' ),
                'type'        => 'checkbox',
                'section'     => 'cache_integration',
                'tab'         => 'integration',
                'default'     => '1',
            ),
            array(
                'id'          => 'litespeed_purge_on_license',
                'label'       => $this->get_translated_text( 'Purge Cache on License Update' ),
                'description' => $this->get_translated_text( 'Automatically purge LiteSpeed cache when licenses are created or updated.' ),
                'type'        => 'checkbox',
                'section'     => 'cache_integration',
                'tab'         => 'integration',
                'default'     => '1',
            ),
            array(
                'id'          => 'litespeed_exclude_pages',
                'label'       => $this->get_translated_text( 'Exclude Pages from Cache' ),
                'description' => $this->get_translated_text( 'Comma-separated list of page IDs or slugs to exclude from LiteSpeed cache (e.g., checkout, account).' ),
                'type'        => 'textarea',
                'section'     => 'cache_integration',
                'tab'         => 'integration',
                'default'     => 'checkout,account,cart',
            ),

            // Plugin Integration
            array(
                'id'          => 'plugin_compatibility_mode',
                'label'       => $this->get_translated_text( 'Plugin Compatibility Mode' ),
                'description' => $this->get_translated_text( 'Enable compatibility mode for better integration with other plugins.' ),
                'type'        => 'checkbox',
                'section'     => 'plugin_integration',
                'tab'         => 'integration',
                'default'     => '',
            ),
            array(
                'id'          => 'detected_plugins',
                'label'       => $this->get_translated_text( 'Detected Plugins' ),
                'description' => $this->get_translated_text( 'List of detected plugins that can integrate with Vira Store.' ),
                'type'        => 'html',
                'section'     => 'plugin_integration',
                'tab'         => 'integration',
                'callback'    => array( $this, 'render_detected_plugins' ),
                'default'     => '',
            ),
            array(
                'id'          => 'woocommerce_integration',
                'label'       => $this->get_translated_text( 'WooCommerce Integration' ),
                'description' => $this->get_translated_text( 'Enable integration with WooCommerce for product synchronization.' ),
                'type'        => 'checkbox',
                'section'     => 'plugin_integration',
                'tab'         => 'integration',
                'default'     => '',
            ),
            array(
                'id'          => 'woocommerce_revoke_license_on_refund',
                'label'       => $this->get_translated_text( 'Revoke Licenses on Refund' ),
                'description' => $this->get_translated_text( 'When enabled, Vira Store will attempt to deactivate/revoke licenses when a WooCommerce order is refunded or cancelled.' ),
                'type'        => 'checkbox',
                'section'     => 'plugin_integration',
                'tab'         => 'integration',
                'default'     => '',
            ),
            array(
                'id'          => 'elementor_integration',
                'label'       => $this->get_translated_text( 'Elementor Integration' ),
                'description' => $this->get_translated_text( 'Enable Elementor widgets for Vira Store products.' ),
                'type'        => 'checkbox',
                'section'     => 'plugin_integration',
                'tab'         => 'integration',
                'default'     => '',
            ),
            array(
                'id'          => 'gutenberg_blocks',
                'label'       => $this->get_translated_text( 'Gutenberg Blocks' ),
                'description' => $this->get_translated_text( 'Enable custom Gutenberg blocks for product display.' ),
                'type'        => 'checkbox',
                'section'     => 'plugin_integration',
                'tab'         => 'integration',
                'default'     => 'on',
            ),

            // Webhook Integration
            array(
                'id'          => 'enable_webhooks',
                'label'       => $this->get_translated_text( 'Enable Webhooks' ),
                'description' => $this->get_translated_text( 'Enable webhook notifications for external integrations.' ),
                'type'        => 'checkbox',
                'section'     => 'webhook_integration',
                'tab'         => 'integration',
                'default'     => '',
            ),
            array(
                'id'          => 'webhook_endpoints',
                'label'       => $this->get_translated_text( 'Webhook Endpoints' ),
                'description' => $this->get_translated_text( 'Configure webhook URLs for different events (one per line: event_name|url).' ),
                'type'        => 'textarea',
                'section'     => 'webhook_integration',
                'tab'         => 'integration',
                'default'     => '',
                'placeholder' => 'order.completed|https://example.com/webhook\nlicense.activated|https://example.com/license-webhook',
            ),
            array(
                'id'          => 'webhook_secret',
                'label'       => $this->get_translated_text( 'Webhook Secret' ),
                'description' => $this->get_translated_text( 'Secret key for webhook signature verification.' ),
                'type'        => 'password',
                'section'     => 'webhook_integration',
                'tab'         => 'integration',
                'default'     => wp_generate_password( 32, false ),
            ),
            array(
                'id'          => 'webhook_retry_attempts',
                'label'       => $this->get_translated_text( 'Retry Attempts' ),
                'description' => $this->get_translated_text( 'Number of retry attempts for failed webhooks.' ),
                'type'        => 'number',
                'section'     => 'webhook_integration',
                'tab'         => 'integration',
                'default'     => 3,
                'min'         => 1,
                'max'         => 10,
            ),


        );

        // Register fields
        foreach ( $this->fields as $field ) {
            add_settings_field(
                'vrstore_' . $field['id'],
                $field['label'],
                array( $this, 'field_callback' ),
                'vrstore_settings_' . $this->get_section_tab( $field['section'] ),
                $field['section'],
                $field
            );
        }

        // Allow other plugins to add fields
        $this->fields = apply_filters( 'vrstore_settings_fields', $this->fields );
    }

    /**
     * Get section tab.
     *
     * @since 1.0.0
     * @param string $section_id Section ID.
     * @return string
     */
    private function get_section_tab( $section_id ) {
        foreach ( $this->sections as $section ) {
            if ( $section['id'] === $section_id ) {
                return $section['tab'];
            }
        }

        return 'general';
    }

    /**
     * Section callback.
     *
     * @since 1.0.0
     * @param array $args Section arguments.
     * @return void
     */
    public function section_callback( $args ) {
        // Handle database tools section specially
        if ( $args['id'] === 'database_tools' ) {
            $this->render_database_tools_section();
            return;
        }
        
        foreach ( $this->sections as $section ) {
            if ( $section['id'] === $args['id'] ) {
                if ( ! empty( $section['description'] ) ) {
                    echo '<p class="section-description">' . esc_html($section['description']  ?? "") . '</p>';
                }
                break;
            }
        }
    }

    /**
     * Render database tools section.
     *
     * @since 1.0.0
     * @return void
     */
    private function render_database_tools_section() {
        // Handle database repair form submission
        if ( isset( $_POST['vrstore_repair_database'] ) && wp_verify_nonce( $_POST['_wpnonce'], 'vrstore_repair_database' ) ) {
            if ( ! current_user_can( 'manage_options' ) ) {
                wp_die( $this->get_translated_text( 'Permission denied.' ) );
            }

            if ( class_exists( 'VRSTORE_Database' ) ) {
                $database = VRSTORE_Database::get_instance();
                $result = $database->repair_database();

                if ( $result['success'] ) {
                    echo '<div class="notice notice-success"><p>' . esc_html( $result['message'] ) . '</p></div>';
                } else {
                    echo '<div class="notice notice-error"><p>' . esc_html( $result['message'] ) . '</p></div>';
                }
            }
        }

        // Get database status
        if ( class_exists( 'VRSTORE_Database' ) ) {
            $database = VRSTORE_Database::get_instance();
            $status = $database->get_database_status();
        } else {
            $status = [
                'connection' => false,
                'missing_tables' => [],
                'last_error' => 'Database class not found'
            ];
        }
        ?>
        <div class="vrstore-database-tools">
            <h3><?php echo $this->get_translated_text( 'Database Status' ); ?></h3>
            <table class="form-table">
                <tr>
                    <th scope="row"><?php echo $this->get_translated_text( 'Database Connection' ); ?></th>
                    <td>
                        <span class="status-indicator <?php echo $status['connection'] ? 'status-good' : 'status-error'; ?>">
                            <?php echo $status['connection'] ? $this->get_translated_text( 'Connected' ) : $this->get_translated_text( 'Failed' ); ?>
                        </span>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php echo $this->get_translated_text( 'Tables Status' ); ?></th>
                    <td>
                        <?php if ( empty( $status['missing_tables'] ) ): ?>
                            <span class="status-indicator status-good"><?php echo $this->get_translated_text( 'All tables exist' ); ?></span>
                        <?php else: ?>
                            <span class="status-indicator status-error">
                                <?php printf( $this->get_translated_text( '%d tables missing' ), count( $status['missing_tables'] ) ); ?>
                            </span>
                            <br><small><?php echo esc_html( implode( ', ', $status['missing_tables'] ) ); ?></small>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php if ( ! empty( $status['last_error'] ) ): ?>
                <tr>
                    <th scope="row"><?php echo $this->get_translated_text( 'Last Error' ); ?></th>
                    <td>
                        <code style="color: #d63638;"><?php echo esc_html( $status['last_error'] ); ?></code>
                    </td>
                </tr>
                <?php endif; ?>
            </table>

            <?php if ( ! empty( $status['missing_tables'] ) ): ?>
            <h3><?php echo $this->get_translated_text( 'Database Repair' ); ?></h3>
            <p><?php echo $this->get_translated_text( 'Some database tables are missing. Click the button below to repair the database.' ); ?></p>
            
            <form method="post" action="">
                <?php wp_nonce_field( 'vrstore_repair_database' ); ?>
                <p>
                    <input type="submit" name="vrstore_repair_database" class="button button-primary" 
                           value="<?php echo esc_attr( $this->get_translated_text( 'Repair Database' ) ); ?>">
                </p>
            </form>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Field callback.
     *
     * @since 1.0.0
     * @param array $args Field arguments.
     * @return void
     */
    public function field_callback( $args ) {
        $default = isset( $args['default'] ) ? $args['default'] : '';
        $value = isset( $this->options[ $args['id'] ] ) ? $this->options[ $args['id'] ] : $default;
        $name  = 'vrstore_settings[' . $args['id'] . ']';

        switch ( $args['type'] ) {
            case 'text':
            case 'email':
            case 'url':
            case 'password':
                $readonly = isset( $args['readonly'] ) && $args['readonly'] ? 'readonly' : '';
                printf(
                    '<input type="%1$s" id="%2$s" name="%3$s" value="%4$s" class="regular-text" %5$s />',
                    esc_attr($args['type']  ?? ""),
                    esc_attr( 'vrstore_' . $args['id'] ),
                    esc_attr($name  ?? ""),
                    esc_attr($value  ?? ""),
                    esc_attr($readonly  ?? "")
                );
                break;
                
            case 'number':
                $readonly = isset( $args['readonly'] ) && $args['readonly'] ? 'readonly' : '';
                $min = isset( $args['min'] ) ? 'min="' . esc_attr( $args['min'] ) . '"' : '';
                $max = isset( $args['max'] ) ? 'max="' . esc_attr( $args['max'] ) . '"' : '';
                $step = isset( $args['step'] ) ? 'step="' . esc_attr( $args['step'] ) . '"' : '';
                printf(
                    '<input type="number" id="%1$s" name="%2$s" value="%3$s" class="regular-text" %4$s %5$s %6$s %7$s />',
                    esc_attr( 'vrstore_' . $args['id'] ),
                    esc_attr($name  ?? ""),
                    esc_attr($value  ?? ""),
                    $readonly,
                    $min,
                    $max,
                    $step
                );
                break;

            case 'textarea':
                printf(
                    '<textarea id="%1$s" name="%2$s" rows="5" cols="50">%3$s</textarea>',
                    esc_attr( 'vrstore_' . $args['id'] ),
                    esc_attr($name  ?? ""),
                    esc_textarea( $value )
                );
                break;

            case 'select':
                echo '<select id="' . esc_attr( 'vrstore_' . $args['id'] ) . '" name="' . esc_attr($name  ?? "") . '">';
                foreach ( $args['options'] as $key => $label ) {
                    printf(
                        '<option value="%1$s" %2$s>%3$s</option>',
                        esc_attr($key  ?? ""),
                        selected( $value, $key, false ),
                        esc_html($label  ?? "")
                    );
                }
                echo '</select>';
                break;

            case 'checkbox':
                printf(
                    '<input type="checkbox" id="%1$s" name="%2$s" value="on" %3$s />',
                    esc_attr( 'vrstore_' . $args['id'] ),
                    esc_attr($name  ?? ""),
                    checked( $value, 'on', false )
                );
                break;

            case 'multicheck':
                foreach ( $args['options'] as $key => $label ) {
                    $checked = isset( $value[ $key ] ) ? checked( $value[ $key ], 'on', false ) : '';
                    printf(
                        '<label><input type="checkbox" id="%1$s_%2$s" name="%3$s[%2$s]" value="on" %4$s /> %5$s</label><br>',
                        esc_attr( 'vrstore_' . $args['id'] ),
                        esc_attr($key  ?? ""),
                        esc_attr($name  ?? ""),
                        $checked,
                        esc_html($label  ?? "")
                    );
                }
                break;

            case 'radio':
                foreach ( $args['options'] as $key => $label ) {
                    printf(
                        '<label><input type="radio" id="%1$s_%2$s" name="%3$s" value="%2$s" %4$s /> %5$s</label><br>',
                        esc_attr( 'vrstore_' . $args['id'] ),
                        esc_attr($key  ?? ""),
                        esc_attr($name  ?? ""),
                        checked( $value, $key, false ),
                        esc_html($label  ?? "")
                    );
                }
                break;

            case 'license_type_config':
                $this->render_license_type_config_field( $args, $value, $name );
                break;

            case 'custom_license_type_config':
                $this->render_custom_license_type_config_field( $args, $value, $name );
                break;

            case 'color':
                printf(
                    '<input type="text" id="%1$s" name="%2$s" value="%3$s" class="vrstore-color-picker" />',
                    esc_attr( 'vrstore_' . $args['id'] ),
                    esc_attr($name  ?? ""),
                    esc_attr($value  ?? "")
                );
                break;

            case 'currency_rates':
                $this->render_currency_rates_field( $args, $value, $name );
                break;
                
            case 'button':
                if ( isset( $args['callback'] ) && is_callable( $args['callback'] ) ) {
                    call_user_func( $args['callback'], $args );
                } else {
                    $button_class = isset( $args['button_class'] ) ? $args['button_class'] : 'button';
                    $button_text = isset( $args['button_text'] ) ? $args['button_text'] : 'Click';
                    printf(
                        '<button type="button" class="%1$s" id="%2$s">%3$s</button>',
                        esc_attr( $button_class ),
                        esc_attr( 'vrstore_' . $args['id'] ),
                        esc_html( $button_text )
                    );
                }
                break;
        }

        if ( isset( $args['description'] ) ) {
            echo '<p class="description">' . esc_html($args['description']  ?? "") . '</p>';
        }
    }

    /**
     * Sanitize settings.
     *
     * @since 1.0.0
     * @param array $input Settings input.
     * @return array
     */
    public function sanitize_settings( $input ) {
        // Security: Verify nonce (WordPress Settings API handles this, but double-check for license tab)
        if ( ! current_user_can( 'manage_options' ) ) {
            return get_option( 'vrstore_settings', array() );
        }

        // Get existing settings to preserve values from other tabs
        $existing_options = get_option( 'vrstore_settings', array() );
        $output = $existing_options; // Start with existing settings

        // Regenerate API key if requested
        if ( isset( $input['regenerate_api_key'] ) && 'on' === $input['regenerate_api_key'] ) {
            // Generate new API key
            $new_api_key = wp_generate_password( 32, false );
            
            // Update both the settings array and the standalone option for consistency
            $input['api_key'] = $new_api_key;
            update_option( 'vrstore_api_key', $new_api_key );
            
            // Log API key regeneration for security auditing
            if ( class_exists( 'VRSTORE_Security' ) ) {
                VRSTORE_Security::log_security_event(
                    'API key regenerated',
                    'info',
                    array( 'user_id' => get_current_user_id() )
                );
            }
        }

        // Security: Sanitize and validate current tab
        $current_tab = isset( $input['active_tab'] ) ? sanitize_text_field( $input['active_tab'] ) : 'general';
        // Security: Validate tab exists in allowed tabs
        if ( ! isset( $this->tabs[ $current_tab ] ) ) {
            $current_tab = 'general';
        }
        unset($input['active_tab']); // Remove from settings to save
        

        // Filter fields to only process those from the current tab
        $current_tab_fields = array_filter( $this->fields, function( $field ) use ( $current_tab ) {
            return isset( $field['tab'] ) && $field['tab'] === $current_tab;
        } );

        foreach ( $current_tab_fields as $field ) {
            // Handle readonly fields (like API key) - preserve existing value unless regenerating
            if ( isset( $field['readonly'] ) && $field['readonly'] && $field['id'] === 'api_key' ) {
                // For API key, use regenerated value if available, otherwise keep existing
                if ( isset( $input['api_key'] ) && ! empty( $input['api_key'] ) ) {
                    $output[ $field['id'] ] = sanitize_text_field( $input['api_key'] );
                } elseif ( isset( $existing_options[ $field['id'] ] ) ) {
                    $output[ $field['id'] ] = $existing_options[ $field['id'] ];
                } else {
                    $output[ $field['id'] ] = isset( $field['default'] ) ? $field['default'] : '';
                }
                continue;
            }
            
            if ( ! isset( $input[ $field['id'] ] ) ) {
                if ( 'checkbox' === $field['type'] ) {
                    $output[ $field['id'] ] = '';
                } elseif ( 'multicheck' === $field['type'] ) {
                    $output[ $field['id'] ] = array();
                } else {
                    // For non-checkboxes, if not in input, keep existing value or use default
                    if ( isset( $existing_options[ $field['id'] ] ) ) {
                        $output[ $field['id'] ] = $existing_options[ $field['id'] ];
                    } elseif ( ! isset( $existing_options[ $field['id'] ] ) ) {
                        $output[ $field['id'] ] = isset( $field['default'] ) ? $field['default'] : '';
                    }
                }
                continue;
            }

            switch ( $field['type'] ) {
                case 'text':
                    $output[ $field['id'] ] = sanitize_text_field( $input[ $field['id'] ] );
                    break;

                case 'email':
                    $output[ $field['id'] ] = sanitize_email( $input[ $field['id'] ] );
                    break;

                case 'url':
                    $output[ $field['id'] ] = esc_url_raw( $input[ $field['id'] ] );
                    break;

                case 'number':
                    // Check if this is a decimal field (like exchange rate)
                    if ( isset( $field['step'] ) && $field['step'] != 1 ) {
                        $output[ $field['id'] ] = floatval( $input[ $field['id'] ] );
                    } else {
                        $output[ $field['id'] ] = absint( $input[ $field['id'] ] );
                    }
                    if ( isset( $field['min'] ) && $output[ $field['id'] ] < $field['min'] ) {
                        $output[ $field['id'] ] = $field['min'];
                    }
                    if ( isset( $field['max'] ) && $output[ $field['id'] ] > $field['max'] ) {
                        $output[ $field['id'] ] = $field['max'];
                    }
                    break;

                case 'textarea':
                    $output[ $field['id'] ] = sanitize_textarea_field( $input[ $field['id'] ] );
                    break;

                case 'select':
                case 'radio':
                    $output[ $field['id'] ] = sanitize_text_field( $input[ $field['id'] ] );
                    break;

                case 'checkbox':
                    $output[ $field['id'] ] = isset( $input[ $field['id'] ] ) ? 'on' : '';
                    break;

                case 'multicheck':
                    $output[ $field['id'] ] = array();
                    foreach ( $field['options'] as $key => $label ) {
                        $output[ $field['id'] ][ $key ] = isset( $input[ $field['id'] ][ $key ] ) ? 'on' : '';
                    }
                    break;

                case 'color':
                    $output[ $field['id'] ] = sanitize_hex_color( $input[ $field['id'] ] );
                    break;

                case 'currency_rates':
                    $rates_data = $this->sanitize_currency_rates( $input[ $field['id'] ] );
                    $output[ $field['id'] ] = $rates_data;
                    // Also store rates in the format expected by currency converter
                    $this->update_currency_converter_rates( $rates_data );
                    break;

                case 'password':
                    // Only update if not empty
                    if ( ! empty( $input[ $field['id'] ] ) ) {
                        $output[ $field['id'] ] = sanitize_text_field( $input[ $field['id'] ] );
                    } else {
                        $output[ $field['id'] ] = isset( $this->options[ $field['id'] ] ) ? $this->options[ $field['id'] ] : '';
                    }
                    break;

                case 'license_type_config':
                    $output[ $field['id'] ] = $this->sanitize_license_type_config( $input[ $field['id'] ] );
                    break;

                case 'custom_license_type_config':
                    $output[ $field['id'] ] = $this->sanitize_custom_license_type_config( $input[ $field['id'] ] );
                    break;

                default:
                    $output[ $field['id'] ] = sanitize_text_field( $input[ $field['id'] ] );
                    break;
            }
        }

        // Handle reset operations before returning output
        $this->handle_reset_operations( $input, $current_tab );

        // Check if product_permalink_slug changed and flush rewrite rules if needed
        if ( isset( $existing_options['product_permalink_slug'] ) && 
             isset( $output['product_permalink_slug'] ) &&
             $existing_options['product_permalink_slug'] !== $output['product_permalink_slug'] ) {
            // Schedule rewrite rules flush after settings are saved
            add_action( 'updated_option_vrstore_settings', array( $this, 'flush_rewrite_rules_after_slug_change' ) );
        }

        return $output;
    }

    // NOTE: Menu registration now handled by VRSTORE_Admin_Menu class

    /**
     * Add settings link to plugins page.
     *
     * @since 1.0.0
     * @param array $links Plugin action links.
     * @return array
     */
    public function add_settings_link( $links ) {
        $settings_link = sprintf(
            '<a href="%1$s">%2$s</a>',
            admin_url( 'admin.php?page=vrstore-settings-page' ),
            $this->get_translated_text( 'Settings' )
        );

        array_unshift( $links, $settings_link );

        return $links;
    }

    /**
     * Handle reset operations from tools tab.
     *
     * @since 1.0.0
     * @param array  $input       Settings input.
     * @param string $current_tab Current tab being processed.
     * @return void
     */
    private function handle_reset_operations( $input, $current_tab ) {
        // Only process reset operations from tools tab
        if ( 'tools' !== $current_tab ) {
            return;
        }

        // Check user capabilities
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        // Track execution time for performance monitoring
        $start_time = microtime( true );
        $operations_performed = [];

        // Handle Reset Data
        if ( isset( $input['reset_data'] ) && 'on' === $input['reset_data'] ) {
            $result = $this->reset_all_data();
            $operations_performed[] = 'reset_data';
            add_action( 'admin_notices', function() use ( $result ) {
                $class = $result['success'] ? 'notice-success' : 'notice-error';
                echo '<div class="notice ' . esc_attr( $class ) . ' is-dismissible"><p>' . 
                     esc_html( $result['message'] ) . '</p></div>';
            } );
        }

        // Handle Reset Settings
        if ( isset( $input['reset_settings'] ) && 'on' === $input['reset_settings'] ) {
            $result = $this->reset_settings_to_defaults();
            $operations_performed[] = 'reset_settings';
            add_action( 'admin_notices', function() use ( $result ) {
                $class = $result['success'] ? 'notice-success' : 'notice-error';
                echo '<div class="notice ' . esc_attr( $class ) . ' is-dismissible"><p>' . 
                     esc_html( $result['message'] ) . '</p></div>';
            } );
        }

        // Handle Flush Cache
        if ( isset( $input['flush_cache'] ) && 'on' === $input['flush_cache'] ) {
            $result = $this->flush_plugin_cache();
            $operations_performed[] = 'flush_cache';
            add_action( 'admin_notices', function() use ( $result ) {
                $class = $result['success'] ? 'notice-success' : 'notice-warning';
                echo '<div class="notice ' . esc_attr( $class ) . ' is-dismissible"><p>' . 
                     esc_html( $result['message'] ) . '</p></div>';
            } );
        }

        // Handle other tool operations with enhanced error handling
        if ( isset( $input['check_compatibility'] ) && 'on' === $input['check_compatibility'] ) {
            $result = $this->run_compatibility_check();
            $operations_performed[] = 'check_compatibility';
            add_action( 'admin_notices', function() use ( $result ) {
                $class = $result['success'] ? 'notice-success' : 'notice-warning';
                echo '<div class="notice ' . esc_attr( $class ) . ' is-dismissible"><p>' . 
                     esc_html( $result['message'] ) . '</p></div>';
            } );
        }

        if ( isset( $input['check_database'] ) && 'on' === $input['check_database'] ) {
            $result = $this->check_database_integrity();
            $operations_performed[] = 'check_database';
            add_action( 'admin_notices', function() use ( $result ) {
                $class = $result['success'] ? 'notice-success' : 'notice-error';
                echo '<div class="notice ' . esc_attr( $class ) . ' is-dismissible"><p>' . 
                     esc_html( $result['message'] ) . '</p></div>';
            } );
        }

        if ( isset( $input['cleanup_logs'] ) && 'on' === $input['cleanup_logs'] ) {
            $result = $this->cleanup_old_logs();
            $operations_performed[] = 'cleanup_logs';
            add_action( 'admin_notices', function() use ( $result ) {
                $class = $result['success'] ? 'notice-success' : 'notice-warning';
                echo '<div class="notice ' . esc_attr( $class ) . ' is-dismissible"><p>' . 
                     esc_html( $result['message'] ) . '</p></div>';
            } );
        }

        if ( isset( $input['optimize_database'] ) && 'on' === $input['optimize_database'] ) {
            $result = $this->optimize_database_tables();
            $operations_performed[] = 'optimize_database';
            add_action( 'admin_notices', function() use ( $result ) {
                $class = $result['success'] ? 'notice-success' : 'notice-error';
                echo '<div class="notice ' . esc_attr( $class ) . ' is-dismissible"><p>' . 
                     esc_html( $result['message'] ) . '</p></div>';
            } );
        }

        if ( isset( $input['export_settings'] ) && 'on' === $input['export_settings'] ) {
            $result = $this->export_plugin_settings();
            $operations_performed[] = 'export_settings';
            add_action( 'admin_notices', function() use ( $result ) {
                $class = $result['success'] ? 'notice-success' : 'notice-error';
                echo '<div class="notice ' . esc_attr( $class ) . ' is-dismissible"><p>' . 
                     esc_html( $result['message'] ) . '</p></div>';
            } );
        }

        // Log performance metrics if operations were performed
        if ( ! empty( $operations_performed ) ) {
            $execution_time = round( ( microtime( true ) - $start_time ) * 1000, 2 );
            $this->log_tool_performance( $operations_performed, $execution_time );
        }
    }

    /**
     * Log tool performance metrics for monitoring and optimization.
     *
     * @since 1.0.0
     * @param array $operations List of operations performed.
     * @param float $execution_time Execution time in milliseconds.
     * @return void
     */
    private function log_tool_performance( $operations, $execution_time ) {
        // Only log if debug mode is enabled
        $settings = get_option( 'vrstore_settings', [] );
        if ( empty( $settings['debug_mode'] ) ) {
            return;
        }

        $log_entry = [
            'timestamp' => current_time( 'mysql' ),
            'user_id' => get_current_user_id(),
            'operations' => $operations,
            'execution_time_ms' => $execution_time,
            'memory_usage' => memory_get_peak_usage( true ),
            'user_agent' => isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( $_SERVER['HTTP_USER_AGENT'] ) : 'Unknown'
        ];

        // Store performance log in transient (expires in 24 hours)
        $existing_logs = get_transient( 'vrstore_tool_performance_logs' ) ?: [];
        $existing_logs[] = $log_entry;
        
        // Keep only last 50 entries to prevent memory issues
        if ( count( $existing_logs ) > 50 ) {
            $existing_logs = array_slice( $existing_logs, -50 );
        }
        
        set_transient( 'vrstore_tool_performance_logs', $existing_logs, DAY_IN_SECONDS );

        // Performance monitoring for critical operations
        if ( $execution_time > 5000 ) { // More than 5 seconds
            // Performance warning - operation took longer than expected
        }
    }

    /**
     * Reset all plugin data including settings, database records, and files.
     * 
     * This method is designed to be future-proof and will automatically detect
     * and clean up any new vrstore_ prefixed tables, options, and data that may
     * be added in future versions of the plugin.
     *
     * @since 1.0.0
     * @return array Result array with success status and message.
     */
    private function reset_all_data() {
        global $wpdb;

        try {
            $items_processed = 0;
            $tables_cleared = 0;
            $posts_deleted = 0;
            $user_meta_deleted = 0;

            // Reset settings to defaults first
            $settings_result = $this->reset_settings_to_defaults();

            // Clear all plugin database tables - Enhanced for current and future tables
            if ( class_exists( 'VRSTORE_Database' ) ) {
                $database = VRSTORE_Database::get_instance();
                
                // Get table names - Complete list including all current and potential future tables
                $tables = [
                    // Core tables
                    $wpdb->prefix . 'vrstore_customers',
                    $wpdb->prefix . 'vrstore_orders',
                    $wpdb->prefix . 'vrstore_licenses',
                    $wpdb->prefix . 'vrstore_license_activations',
                    
                    // API and Security
                    $wpdb->prefix . 'vrstore_api_keys',
                    $wpdb->prefix . 'vrstore_sessions',
                    
                    // Commerce features
                    $wpdb->prefix . 'vrstore_coupons',
                    $wpdb->prefix . 'vrstore_coupon_usage',
                    $wpdb->prefix . 'vrstore_cart_items',
                    $wpdb->prefix . 'vrstore_cart_sessions',
                    
                    // Course and Learning Management
                    $wpdb->prefix . 'vrstore_course_analytics',
                    $wpdb->prefix . 'vrstore_course_enrollments',
                    $wpdb->prefix . 'vrstore_course_progress',
                    $wpdb->prefix . 'vrstore_lesson_completions',
                    $wpdb->prefix . 'vrstore_course_certificates',
                    $wpdb->prefix . 'vrstore_video_tracking',
                    
                    // Logging and monitoring
                    $wpdb->prefix . 'vrstore_download_logs',
                    $wpdb->prefix . 'vrstore_download_tracking',
                    $wpdb->prefix . 'vrstore_payment_logs',
                    $wpdb->prefix . 'vrstore_license_logs',
                    $wpdb->prefix . 'vrstore_domain_logs',
                    $wpdb->prefix . 'vrstore_activity_logs',
                    
                    // Communication
                    $wpdb->prefix . 'vrstore_email_queue',
                    $wpdb->prefix . 'vrstore_notifications',
                    
                    // Analytics (potential future feature)
                    $wpdb->prefix . 'vrstore_analytics',
                    $wpdb->prefix . 'vrstore_reports',
                    
                    // Integration tables (potential future feature)
                    $wpdb->prefix . 'vrstore_integrations',
                    $wpdb->prefix . 'vrstore_webhooks'
                ];

                // Dynamic table detection - Find all vrstore_ tables in database
                $dynamic_tables = $wpdb->get_results( 
                    "SHOW TABLES LIKE '{$wpdb->prefix}vrstore_%'", 
                    ARRAY_N 
                );
                
                foreach ( $dynamic_tables as $table_array ) {
                    $table_name = $table_array[0];
                    if ( ! in_array( $table_name, $tables ) ) {
                        $tables[] = $table_name; // Add any vrstore tables not in our static list
                    }
                }

                // Truncate all plugin tables
                foreach ( $tables as $table ) {
                    if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) === $table ) {
                        $count = $wpdb->get_var( "SELECT COUNT(*) FROM `{$table}`" );
                        if ( $count > 0 ) {
                            $wpdb->query( "TRUNCATE TABLE `{$table}`" );
                            $items_processed += (int) $count;
                            $tables_cleared++;
                        }
                    }
                }
            }

            // Delete all plugin posts (products, orders, courses)
            $post_types = [ 'vrstore_product', 'vrstore_order', 'vrstore_course' ]; // vrstore_license removed - using table-based system
            foreach ( $post_types as $post_type ) {
                $posts = get_posts( [
                    'post_type'      => $post_type,
                    'posts_per_page' => -1,
                    'post_status'    => 'any'
                ] );

                foreach ( $posts as $post ) {
                    wp_delete_post( $post->ID, true );
                    $posts_deleted++;
                }
            }

            // Delete all plugin user meta - Enhanced cleanup
            $user_meta_keys = [
                'vrstore_%',                    // All vrstore user meta
                '%vrstore%',                    // Any meta containing vrstore
                'wp_vrstore_%',                 // WordPress prefixed vrstore meta
                'customer_id_%',                // Customer ID associations
                'license_key_%',                // License key associations
                'download_count_%',             // Download tracking
                'last_login_vrstore',           // Login tracking
                '_vrstore_course_%',            // Course-specific user meta
                '%course_enrollment%',          // Course enrollment data
                '%course_progress%',            // Course progress tracking
                '%lesson_completion%',          // Lesson completion tracking
                '%course_completion_date%',     // Course completion dates
                '%video_progress%',             // Video watching progress
                '%course_certificate%'         // Course certificates
            ];
            
            $user_meta_deleted = 0;
            foreach ( $user_meta_keys as $meta_pattern ) {
                $deleted = $wpdb->query( $wpdb->prepare( 
                    "DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE %s", 
                    $meta_pattern 
                ) );
                $user_meta_deleted += $deleted;
            }

            // Clean up WordPress options - Comprehensive cleanup
            $option_patterns = [
                'vrstore_%',           // All plugin options
                '%vrstore%',           // Any options containing vrstore
                'widget_vrstore_%',    // Widget options
                '_transient_vrstore_%', // Transients
                '_transient_timeout_vrstore_%', // Transient timeouts
                'vrstore_version',     // Version info
                'vrstore_db_version',  // Database version
                'vrstore_settings',    // Settings (will be reset to defaults)
                'vrstore_license_check_last', // License check timestamps
                'vrstore_domain_monitor_last', // Domain monitor timestamps
                '%course_analytics_%', // Course analytics cache
                '%course_progress_%',  // Course progress cache
                '%lesson_tracking_%',  // Lesson tracking cache
                '%video_analytics_%',  // Video analytics cache
                'vrstore_course_rewrite_rules_flushed', // Course rewrite rules
            ];
            
            $options_deleted = 0;
            foreach ( $option_patterns as $option_pattern ) {
                $deleted = $wpdb->query( $wpdb->prepare(
                    "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
                    $option_pattern
                ) );
                $options_deleted += $deleted;
            }

            // Remove customer role from users (if they only have customer role)
            $customer_users = get_users( array( 'role' => 'customer' ) );
            $users_updated = 0;
            foreach ( $customer_users as $user ) {
                $user_obj = new WP_User( $user->ID );
                
                // If user only has customer role, remove it and set to subscriber
                if ( count( $user_obj->roles ) === 1 && in_array( 'customer', $user_obj->roles ) ) {
                    $user_obj->remove_role( 'customer' );
                    $user_obj->add_role( 'subscriber' );
                    $users_updated++;
                } else {
                    // Just remove customer role if they have other roles
                    $user_obj->remove_role( 'customer' );
                }
            }

            // Clear all plugin transients and cached data
            $cache_result = $this->flush_plugin_cache();

            // Clear any scheduled hooks - Enhanced cleanup
            $cron_hooks = [
                'vrstore_license_check',
                'vrstore_domain_monitor', 
                'vrstore_cleanup_logs',
                'vrstore_email_queue_process',
                'vrstore_analytics_daily',
                'vrstore_backup_data',
                'vrstore_license_expiry_check',
                'vrstore_abandoned_cart_reminder'
            ];
            
            foreach ( $cron_hooks as $hook ) {
                wp_clear_scheduled_hook( $hook );
            }

            // All plugin data has been reset

            return [
                'success' => true,
                'message' => sprintf(
                    /* translators: 1: tables cleared, 2: posts deleted, 3: user meta deleted, 4: options deleted, 5: users updated */
                    $this->get_translated_text( 'Complete plugin data reset successful! Cleared %1$d database tables, deleted %2$d posts, removed %3$d user meta entries, deleted %4$d options, and updated %5$d user roles. All settings restored to defaults and caches cleared.' ),
                    $tables_cleared,
                    $posts_deleted,
                    $user_meta_deleted,
                    $options_deleted,
                    $users_updated
                ),
                'details' => [
                    'tables_cleared' => $tables_cleared,
                    'posts_deleted' => $posts_deleted,
                    'user_meta_deleted' => $user_meta_deleted,
                    'options_deleted' => $options_deleted,
                    'users_updated' => $users_updated,
                    'items_processed' => $items_processed
                ]
            ];
            
        } catch ( Exception $e ) {
            return [
                'success' => false,
                'message' => sprintf(
                    /* translators: %s: error message */
                    $this->get_translated_text( 'Failed to reset plugin data: %s' ),
                    $e->getMessage()
                )
            ];
        }
    }

    /**
     * Reset plugin settings to default values.
     *
     * @since 1.0.0
     * @return array Result array with success status and message.
     */
    private function reset_settings_to_defaults() {
        try {
            // Get current settings count for comparison
            $current_settings = get_option( 'vrstore_settings', [] );
            $current_count = count( $current_settings );
            
            // Get default settings from main plugin file - Enhanced with all features
            $default_settings = [
                // Core settings
                'license_prefix'         => 'VRST-',
                'api_namespace'          => 'vrstore/v1',
                'store_name'             => get_bloginfo( 'name' ),
                
                // Feature toggles
                'enable_woocommerce'     => false,
                'enable_licensing'       => true,
                'enable_downloads'       => true,
                'enable_api'             => true,
                'enable_coupons'         => true,
                'enable_domain_monitor'  => false,
                'enable_custom_login'    => false, // Custom login redirect
                'enable_cart_session'    => true,  // Shopping cart sessions
                'enable_email_queue'     => false, // Email queue system
                
                // Currency settings
                'currency'               => 'USD',
                'currency_symbol'        => '$',
                'currency_position'      => 'left',
                'thousand_separator'     => ',',
                'decimal_separator'      => '.',
                'decimal_number'         => 2,
                
                // URLs and pages
                'product_permalink_slug' => 'digital-product',
                'account_page'           => 0,      // Account page ID
                'thank_you_page'         => 0,     // Thank you page ID
                'products_page'          => 0,     // Products page ID
                
                // Payment gateways
                'enabled_gateways'       => [
                    'manual' => 'on',   // Bank transfer
                    'tripay' => 'off'   // TriPay (requires setup)
                ],
                
                // System settings
                'test_mode'              => 'on',
                'debug_mode'             => '',
                'uninstall_data'         => '',
                'session_length'         => 24,     // Hours
                'api_key'                => $this->generate_api_key(),
                
                // Security settings
                'login_attempts_limit'   => 5,      // Login attempt limits
                'login_lockout_time'     => 30,     // Minutes
                'api_rate_limit'         => 1000,   // Requests per hour
                
                // Anti-spam settings
                'enable_math_captcha'    => 'on',   // Enable math captcha
                'math_captcha_difficulty' => 'easy', // Captcha difficulty
                'math_captcha_operations' => array( 'addition' => 'on', 'subtraction' => 'on' ), // Allowed operations
                
                // Email settings (for future email features)
                'email_from_name'        => get_bloginfo( 'name' ),
                'email_from_address'     => get_bloginfo( 'admin_email' ),
                'email_template'         => 'default',
                
                // License defaults
                'default_license_limit'  => 1,      // Default activation limit
                'license_expiry_days'    => 365,    // Default expiry (0 = never)
                
                // Cart settings
                'cart_session_length'    => 24,     // Hours
                'abandoned_cart_time'    => 48,     // Hours
                
                // Integration settings
                'webhook_secret'         => wp_generate_password( 32, false ),
                'integration_tokens'     => [],     // For future integrations
            ];

            // Update settings with defaults
            $updated = update_option( 'vrstore_settings', $default_settings );

            if ( ! $updated && $current_count > 0 ) {
                throw new Exception( 'Failed to update settings in database' );
            }

            // Flush rewrite rules since permalink slug might have changed
            flush_rewrite_rules();

            // Plugin settings have been reset to defaults

            return [
                'success' => true,
                'message' => sprintf(
                    /* translators: %d: number of settings reset */
                    $this->get_translated_text( 'Plugin settings have been reset to default values successfully. %d settings were restored.' ),
                    count( $default_settings )
                ),
                'settings_count' => count( $default_settings )
            ];
            
        } catch ( Exception $e ) {
            return [
                'success' => false,
                'message' => sprintf(
                    /* translators: %s: error message */
                    $this->get_translated_text( 'Failed to reset settings: %s' ),
                    $e->getMessage()
                )
            ];
        }
    }

    /**
     * Flush all plugin cache and transients.
     *
     * @since 1.0.0
     * @return array Result array with success status and message.
     */
    private function flush_plugin_cache() {
        global $wpdb;

        try {
            $items_cleared = 0;
            
            // Delete all plugin transients
            $transients_cleared = $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '%_transient_vrstore_%'" );
            $timeouts_cleared = $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '%_transient_timeout_vrstore_%'" );
            $items_cleared += $transients_cleared + $timeouts_cleared;

            // Clear object cache if available
            $object_cache_cleared = false;
            if ( function_exists( 'wp_cache_flush' ) ) {
                $object_cache_cleared = wp_cache_flush();
            }

            // Clear any plugin-specific caches
            $specific_caches = [
                'vrstore_license_check_results',
                'vrstore_domain_monitor_results', 

                'vrstore_database_status'
            ];
            
            $specific_cleared = 0;
            foreach ( $specific_caches as $cache_key ) {
                if ( delete_transient( $cache_key ) ) {
                    $specific_cleared++;
                }
            }

            // Log the cache flush
            // Plugin cache has been flushed by admin user

            return [
                'success' => true,
                'message' => sprintf(
                    /* translators: 1: transients cleared, 2: specific caches cleared */
                    $this->get_translated_text( 'Plugin cache has been flushed successfully. Cleared %1$d transients and %2$d specific caches.' ),
                    $items_cleared,
                    $specific_cleared
                ),
                'details' => [
                    'transients_cleared' => $items_cleared,
                    'specific_caches_cleared' => $specific_cleared,
                    'object_cache_flushed' => $object_cache_cleared
                ]
            ];
            
        } catch ( Exception $e ) {
            return [
                'success' => false,
                'message' => sprintf(
                    /* translators: %s: error message */
                    $this->get_translated_text( 'Failed to flush cache: %s' ),
                    $e->getMessage()
                )
            ];
        }
    }

    /**
     * Run compatibility check with other plugins and themes.
     *
     * @since 1.0.0
     * @return array
     */
    private function run_compatibility_check() {
        $issues = [];
        $warnings = [];
        
        // Removed WordPress version check
        
        // Check PHP version
        if ( version_compare( PHP_VERSION, '8.0', '<' ) ) {
            $warnings[] = sprintf( $this->get_translated_text( 'PHP version %s is outdated. Recommended: 8.0+' ), PHP_VERSION );
        }
        
        // Check for conflicting plugins
        $conflicting_plugins = [
            'woocommerce/woocommerce.php' => 'WooCommerce',
            'easy-digital-downloads/easy-digital-downloads.php' => 'Easy Digital Downloads'
        ];
        
        foreach ( $conflicting_plugins as $plugin_file => $plugin_name ) {
            if ( is_plugin_active( $plugin_file ) ) {
                $warnings[] = sprintf( $this->get_translated_text( '%s plugin detected. May cause conflicts with some features.' ), $plugin_name );
            }
        }
        
        // Check theme compatibility
        $theme = wp_get_theme();
        $known_compatible_themes = [ 'twentytwentyone', 'twentytwentytwo', 'twentytwentythree', 'astra', 'generatepress' ];
        
        if ( ! in_array( $theme->get_stylesheet(), $known_compatible_themes, true ) ) {
            $warnings[] = sprintf( $this->get_translated_text( 'Theme "%s" has not been tested with this plugin.' ), $theme->get( 'Name' ) );
        }
        
        // Check required PHP extensions
        $required_extensions = [ 'curl', 'json', 'mbstring', 'openssl' ];
        foreach ( $required_extensions as $extension ) {
            if ( ! extension_loaded( $extension ) ) {
                $issues[] = sprintf( $this->get_translated_text( 'Required PHP extension "%s" is not loaded.' ), $extension );
            }
        }
        
        // Store results in transient for future reference
        $results = [
            'issues' => $issues,
            'warnings' => $warnings,
            'checked_at' => current_time( 'mysql' )
        ];
        // Removed compatibility check transient storage
        
        // Prepare return message
        $message = $this->get_translated_text( 'Compatibility check completed.' );
        if ( ! empty( $issues ) ) {
            $message .= ' ' . sprintf( $this->get_translated_text( count( $issues ) === 1 ? '%d critical issue found.' : '%d critical issues found.' ), count( $issues ) );
        }
        if ( ! empty( $warnings ) ) {
            $message .= ' ' . sprintf( $this->get_translated_text( count( $warnings ) === 1 ? '%d warning found.' : '%d warnings found.' ), count( $warnings ) );
        }
        if ( empty( $issues ) && empty( $warnings ) ) {
            $message .= ' ' . $this->get_translated_text( 'No issues found.' );
        }
        
        return [
            'success' => empty( $issues ),
            'message' => $message,
            'data' => $results
        ];
    }

    /**
     * Check database integrity and fix issues.
     *
     * @since 1.0.0
     * @return array
     */
    private function check_database_integrity() {
        if ( ! class_exists( 'VRSTORE_Database' ) ) {
            return [
                'success' => false,
                'message' => $this->get_translated_text( 'Database class not found. Cannot perform integrity check.' )
            ];
        }
        
        global $wpdb;
        $database = VRSTORE_Database::get_instance();
        $issues_found = [];
        $fixes_applied = [];
        
        // Check if all required tables exist
        $required_tables = [
            $wpdb->prefix . 'vrstore_customers',
            $wpdb->prefix . 'vrstore_orders',
            $wpdb->prefix . 'vrstore_licenses',
            $wpdb->prefix . 'vrstore_license_activations',
            $wpdb->prefix . 'vrstore_api_keys',
            $wpdb->prefix . 'vrstore_coupons',
            $wpdb->prefix . 'vrstore_coupon_usage',
            $wpdb->prefix . 'vrstore_download_logs',
            $wpdb->prefix . 'vrstore_payment_logs'
        ];
        
        foreach ( $required_tables as $table ) {
            $table_exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) );
            if ( ! $table_exists ) {
                $issues_found[] = sprintf( $this->get_translated_text( 'Missing table: %s' ), $table );
            }
        }
        
        // Check for orphaned records
        $orphaned_licenses = $wpdb->get_var( 
            "SELECT COUNT(*) FROM {$wpdb->prefix}vrstore_licenses l 
             LEFT JOIN {$wpdb->prefix}vrstore_customers c ON l.customer_id = c.id 
             WHERE c.id IS NULL"
        );
        
        if ( $orphaned_licenses > 0 ) {
            $issues_found[] = sprintf( $this->get_translated_text( '%d orphaned license records found' ), $orphaned_licenses );
        }
        
        // Check for corrupted data
        $invalid_orders = $wpdb->get_var( 
            "SELECT COUNT(*) FROM {$wpdb->prefix}vrstore_orders 
             WHERE status NOT IN ('pending', 'processing', 'completed', 'cancelled', 'refunded')"
        );
        
        if ( $invalid_orders > 0 ) {
            $issues_found[] = sprintf( $this->get_translated_text( '%d orders with invalid status found' ), $invalid_orders );
        }
        
        // Attempt to fix issues if found
        if ( ! empty( $issues_found ) ) {
            // Try to repair/recreate missing tables
            $repair_result = $database->repair_database();
            if ( $repair_result['success'] ) {
                $fixes_applied[] = $this->get_translated_text( 'Database tables repaired/recreated' );
            }
            
            // Clean up orphaned records
            if ( $orphaned_licenses > 0 ) {
                $deleted = $wpdb->query( 
                    "DELETE l FROM {$wpdb->prefix}vrstore_licenses l 
                     LEFT JOIN {$wpdb->prefix}vrstore_customers c ON l.customer_id = c.id 
                     WHERE c.id IS NULL"
                );
                if ( $deleted > 0 ) {
                    $fixes_applied[] = sprintf( $this->get_translated_text( 'Removed %d orphaned license records' ), $deleted );
                }
            }
            
            // Fix invalid order statuses
            if ( $invalid_orders > 0 ) {
                $fixed = $wpdb->query( 
                    "UPDATE {$wpdb->prefix}vrstore_orders 
                     SET status = 'pending' 
                     WHERE status NOT IN ('pending', 'processing', 'completed', 'cancelled', 'refunded')"
                );
                if ( $fixed > 0 ) {
                    $fixes_applied[] = sprintf( $this->get_translated_text( 'Fixed %d orders with invalid status' ), $fixed );
                }
            }
        }
        
        // Prepare result message
        if ( empty( $issues_found ) ) {
            $message = $this->get_translated_text( 'Database integrity check completed. No issues found.' );
            $success = true;
        } else {
            $message = sprintf( 
                $this->get_translated_text( 'Database integrity check completed. %d issues found.' ), 
                count( $issues_found ) 
            );
            if ( ! empty( $fixes_applied ) ) {
                $message .= ' ' . sprintf( 
                    $this->get_translated_text( '%d fixes applied successfully.' ), 
                    count( $fixes_applied ) 
                );
                $success = true;
            } else {
                $message .= ' ' . $this->get_translated_text( 'Some issues could not be automatically fixed.' );
                $success = false;
            }
        }
        
        return [
            'success' => $success,
            'message' => $message,
            'data' => [
                'issues_found' => $issues_found,
                'fixes_applied' => $fixes_applied,
                'checked_at' => current_time( 'mysql' )
            ]
        ];
    }

    /**
     * Cleanup old log files.
     *
     * @since 1.0.0
     * @return array
     */
    private function cleanup_old_logs() {
        global $wpdb;
        $cleaned_items = [];
        $errors = [];
        
        // Clean up old download logs (older than 90 days)
        $download_logs_deleted = $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$wpdb->prefix}vrstore_download_logs 
                 WHERE downloaded_at < %s",
                date('Y-m-d H:i:s', strtotime('-90 days'))
            )
        );
        
        if ($download_logs_deleted !== false) {
            $cleaned_items[] = sprintf($this->get_translated_text('%d old download log entries removed'), $download_logs_deleted);
        } else {
            $errors[] = $this->get_translated_text('Failed to clean download logs');
        }
        
        // Clean up old payment logs (older than 1 year)
        $payment_logs_deleted = $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$wpdb->prefix}vrstore_payment_logs 
                 WHERE created_at < %s",
                date('Y-m-d H:i:s', strtotime('-1 year'))
            )
        );
        
        if ($payment_logs_deleted !== false) {
            $cleaned_items[] = sprintf($this->get_translated_text('%d old payment log entries removed'), $payment_logs_deleted);
        } else {
            $errors[] = $this->get_translated_text('Failed to clean payment logs');
        }
        
        // Clean up expired transients
        $expired_transients = $wpdb->query(
            "DELETE FROM {$wpdb->options} 
             WHERE option_name LIKE '_transient_timeout_vrstore_%' 
             AND option_value < UNIX_TIMESTAMP()"
        );
        
        if ($expired_transients !== false) {
            // Get list of active timeout transients first
            $active_timeouts = $wpdb->get_col(
                "SELECT CONCAT('_transient_', SUBSTRING(option_name, 20)) 
                 FROM {$wpdb->options} 
                 WHERE option_name LIKE '_transient_timeout_vrstore_%'"
            );
            
            // Clean up orphaned transient data (those without corresponding timeout entries)
            if (!empty($active_timeouts)) {
                $placeholders = implode(',', array_fill(0, count($active_timeouts), '%s'));
                $orphaned_transients = $wpdb->query(
                    $wpdb->prepare(
                        "DELETE FROM {$wpdb->options} 
                         WHERE option_name LIKE '_transient_vrstore_%' 
                         AND option_name NOT IN ($placeholders)",
                        $active_timeouts
                    )
                );
            } else {
                // If no active timeouts, delete all vrstore transients
                $orphaned_transients = $wpdb->query(
                    "DELETE FROM {$wpdb->options} 
                     WHERE option_name LIKE '_transient_vrstore_%'"
                );
            }
            
            $total_cleaned = $expired_transients + ($orphaned_transients ?: 0);
            $cleaned_items[] = sprintf($this->get_translated_text('%d expired transients removed'), $total_cleaned);
        } else {
            $errors[] = $this->get_translated_text('Failed to clean expired transients');
        }
        
        // Clean up old error logs from wp-content/debug.log if it exists
        $debug_log_path = WP_CONTENT_DIR . '/debug.log';
        if (file_exists($debug_log_path) && is_writable($debug_log_path)) {
            $log_content = file_get_contents($debug_log_path);
            $lines = explode("\n", $log_content);
            $filtered_lines = [];
            $removed_lines = 0;
            
            foreach ($lines as $line) {
                // Keep lines that don't contain vira-store errors or are recent (last 30 days)
                if (strpos($line, 'vira-store') === false || 
                    strpos($line, date('Y-m')) !== false || 
                    strpos($line, date('Y-m', strtotime('-1 month'))) !== false) {
                    $filtered_lines[] = $line;
                } else {
                    $removed_lines++;
                }
            }
            
            if ($removed_lines > 0) {
                file_put_contents($debug_log_path, implode("\n", $filtered_lines));
                $cleaned_items[] = sprintf($this->get_translated_text('%d old error log entries removed from debug.log'), $removed_lines);
            }
        }
        
        // Clean up old session data
        $cutoff_time = time() - (7 * 24 * 60 * 60); // 7 days ago
        $old_sessions = $wpdb->query(
            "DELETE FROM {$wpdb->options} 
             WHERE option_name LIKE '_vrstore_session_%' 
             AND option_value LIKE '%last_activity%' 
             AND CAST(SUBSTRING_INDEX(SUBSTRING_INDEX(option_value, 'last_activity\\\";i:', -1), ';', 1) AS UNSIGNED) < {$cutoff_time}"
        );
        
        if ($old_sessions !== false && $old_sessions > 0) {
            $cleaned_items[] = sprintf($this->get_translated_text('%d old session entries removed'), $old_sessions);
        }
        
        // Prepare result
        if (empty($errors)) {
            $success = true;
            if (empty($cleaned_items)) {
                $message = $this->get_translated_text('Log cleanup completed. No old logs found to clean.');
            } else {
                $message = $this->get_translated_text('Log cleanup completed successfully.') . ' ' . implode(', ', $cleaned_items);
            }
        } else {
            $success = false;
            $message = $this->get_translated_text('Log cleanup completed with some errors:') . ' ' . implode(', ', $errors);
            if (!empty($cleaned_items)) {
                $message .= ' ' . $this->get_translated_text('Successfully cleaned:') . ' ' . implode(', ', $cleaned_items);
            }
        }
        
        return [
            'success' => $success,
            'message' => $message,
            'data' => [
                'cleaned_items' => $cleaned_items,
                'errors' => $errors,
                'cleaned_at' => current_time('mysql')
            ]
        ];
    }

    /**
     * Optimize database tables.
     *
     * @since 1.0.0
     * @return array
     */
    private function optimize_database_tables() {
        global $wpdb;
        $optimized_tables = [];
        $errors = [];
        $total_space_saved = 0;

        $tables = [
            $wpdb->prefix . 'vrstore_customers',
            $wpdb->prefix . 'vrstore_orders',
            $wpdb->prefix . 'vrstore_licenses',
            $wpdb->prefix . 'vrstore_license_activations',
            $wpdb->prefix . 'vrstore_api_keys',
            $wpdb->prefix . 'vrstore_coupons',
            $wpdb->prefix . 'vrstore_coupon_usage',
            $wpdb->prefix . 'vrstore_download_logs',
            $wpdb->prefix . 'vrstore_payment_logs'
        ];

        foreach ( $tables as $table ) {
            // Check if table exists first
            $table_exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) );
            
            if ( ! $table_exists ) {
                $errors[] = sprintf( $this->get_translated_text( 'Table %s does not exist' ), $table );
                continue;
            }
            
            // Get table size before optimization
            $size_before = $wpdb->get_row( $wpdb->prepare( 
                "SELECT 
                    ROUND(((data_length + index_length) / 1024 / 1024), 2) AS size_mb,
                    ROUND((data_free / 1024 / 1024), 2) AS free_mb
                 FROM information_schema.TABLES 
                 WHERE table_schema = %s AND table_name = %s",
                DB_NAME, $table
            ) );
            
            // Optimize the table
            $result = $wpdb->query( "OPTIMIZE TABLE `{$table}`" );
            
            if ( $result !== false ) {
                // Get table size after optimization
                $size_after = $wpdb->get_row( $wpdb->prepare( 
                    "SELECT 
                        ROUND(((data_length + index_length) / 1024 / 1024), 2) AS size_mb,
                        ROUND((data_free / 1024 / 1024), 2) AS free_mb
                     FROM information_schema.TABLES 
                     WHERE table_schema = %s AND table_name = %s",
                    DB_NAME, $table
                ) );
                
                $space_saved = 0;
                if ( $size_before && $size_after ) {
                    $space_saved = max( 0, $size_before->free_mb );
                    $total_space_saved += $space_saved;
                }
                
                $optimized_tables[] = [
                    'table' => $table,
                    'space_saved_mb' => $space_saved,
                    'current_size_mb' => $size_after ? $size_after->size_mb : 0
                ];
            } else {
                $errors[] = sprintf( $this->get_translated_text( 'Failed to optimize table %s' ), $table );
            }
        }
        
        // Also optimize WordPress core tables that might be used by the plugin
        $wp_tables = [
            $wpdb->posts,
            $wpdb->postmeta,
            $wpdb->users,
            $wpdb->usermeta,
            $wpdb->options
        ];
        
        foreach ( $wp_tables as $table ) {
            $result = $wpdb->query( "OPTIMIZE TABLE `{$table}`" );
            if ( $result !== false ) {
                $optimized_tables[] = [
                    'table' => $table,
                    'space_saved_mb' => 0, // Don't calculate for WP core tables
                    'current_size_mb' => 0
                ];
            }
        }
        
        // Prepare result message
        if ( empty( $errors ) ) {
            $success = true;
            $message = sprintf( 
                $this->get_translated_text( 'Database optimization completed successfully. %d tables optimized.' ),
                count( $optimized_tables )
            );
            
            if ( $total_space_saved > 0 ) {
                $message .= ' ' . sprintf( 
                    $this->get_translated_text( 'Total space reclaimed: %.2f MB' ),
                    $total_space_saved
                );
            }
        } else {
            $success = count( $optimized_tables ) > 0;
            $message = sprintf( 
                $this->get_translated_text( 'Database optimization completed with %d errors. %d tables optimized successfully.' ),
                count( $errors ),
                count( $optimized_tables )
            );
        }
        
        return [
            'success' => $success,
            'message' => $message,
            'data' => [
                'optimized_tables' => $optimized_tables,
                'errors' => $errors,
                'total_space_saved_mb' => $total_space_saved,
                'optimized_at' => current_time( 'mysql' )
            ]
        ];
    }

    /**
     * Export plugin settings as backup file.
     *
     * @since 1.0.0
     * @return array
     */
    private function export_plugin_settings() {
        try {
            // Get all plugin settings
            $settings = get_option( 'vrstore_settings', [] );
            
            // Get additional plugin data
            $export_data = [
                'plugin_version' => VRSTORE_VERSION ?? '1.0.0',
                'export_date' => current_time( 'mysql' ),
                'site_url' => get_site_url(),

                'php_version' => PHP_VERSION,
                'settings' => $settings,
                'active_addons' => [], // Will be populated if addons exist
                'database_version' => get_option( 'vrstore_db_version', '1.0.0' )
            ];
            
            // Check for active addons/extensions
            $addon_settings = get_option( 'vrstore_addon_settings', [] );
            if ( ! empty( $addon_settings ) ) {
                $export_data['active_addons'] = $addon_settings;
            }
            
            // Create export filename
            $filename = 'vrstore-settings-export-' . date( 'Y-m-d-H-i-s' ) . '.json';
            $upload_dir = wp_upload_dir();
            $export_path = $upload_dir['basedir'] . '/vrstore-exports/';
            
            // Create export directory if it doesn't exist
            if ( ! file_exists( $export_path ) ) {
                wp_mkdir_p( $export_path );
                
                // Add .htaccess to protect the directory
                $htaccess_content = "Order deny,allow\nDeny from all";
                file_put_contents( $export_path . '.htaccess', $htaccess_content );
            }
            
            $full_path = $export_path . $filename;
            
            // Write export data to file
            $json_data = wp_json_encode( $export_data, JSON_PRETTY_PRINT );
            $bytes_written = file_put_contents( $full_path, $json_data );
            
            if ( $bytes_written === false ) {
                return [
                    'success' => false,
                    'message' => $this->get_translated_text( 'Failed to create export file. Check directory permissions.' )
                ];
            }
            
            // Store export info in transient for download
            $export_info = [
                'filename' => $filename,
                'full_path' => $full_path,
                'size' => filesize( $full_path ),
                'created' => current_time( 'mysql' )
            ];
            
            set_transient( 'vrstore_export_' . wp_get_current_user()->ID, $export_info, HOUR_IN_SECONDS );
            
            // Clean up old export files (keep only last 5)
            $this->cleanup_old_exports( $export_path );
            
            $download_url = add_query_arg( [
                'vrstore_action' => 'download_export',
                'file' => $filename,
                'nonce' => wp_create_nonce( 'vrstore_download_export' )
            ], admin_url( 'admin.php' ) );
            
            return [
                'success' => true,
                'message' => sprintf( 
                    $this->get_translated_text( 'Settings exported successfully. File size: %s. Click %shere%s to download.' ),
                    size_format( $export_info['size'] ),
                    '<a href="' . esc_url( $download_url ) . '" target="_blank">',
                    '</a>'
                ),
                'data' => [
                    'filename' => $filename,
                    'size' => $export_info['size'],
                    'download_url' => $download_url,
                    'settings_count' => count( $settings ),
                    'exported_at' => current_time( 'mysql' )
                ]
            ];
            
        } catch ( Exception $e ) {
            return [
                'success' => false,
                'message' => sprintf( 
                    $this->get_translated_text( 'Export failed with error: %s' ),
                    $e->getMessage()
                )
            ];
        }
    }
    
    /**
     * Clean up old export files.
     *
     * @since 1.0.0
     * @param string $export_path Export directory path.
     * @return void
     */
    private function cleanup_old_exports( $export_path ) {
        if ( ! is_dir( $export_path ) ) {
            return;
        }
        
        $files = glob( $export_path . 'vrstore-settings-export-*.json' );
        
        if ( count( $files ) > 5 ) {
            // Sort by modification time (oldest first)
            usort( $files, function( $a, $b ) {
                return filemtime( $a ) - filemtime( $b );
            } );
            
            // Remove oldest files, keep only 5 most recent
            $files_to_remove = array_slice( $files, 0, count( $files ) - 5 );
            foreach ( $files_to_remove as $file ) {
                unlink( $file );
            }
        }
    }

    /**
     * Render settings page.
     *
     * @since 1.0.0
     * @return void
     */
    public function render_settings_page() {
        // Check user capabilities
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        // Get current tab
        $current_tab = isset( $_GET['tab'] ) ? sanitize_text_field( wp_unslash( $_GET['tab'] ?? '' ) ) : 'general';

        // Check if tab exists
        if ( ! isset( $this->tabs[ $current_tab ] ) ) {
            $current_tab = 'general';
        }
        
        // Check for settings updated message
        $message = '';
        if ( isset( $_GET['settings-updated'] ) && $_GET['settings-updated'] === 'true' ) {
            $message = '<div class="notice notice-success is-dismissible"><p>' . $this->get_translated_text( 'Settings saved successfully!' ) . '</p></div>';
        }
        
        // Check for error message
        if ( isset( $_GET['error'] ) && $_GET['error'] === 'true' ) {
            $message = '<div class="notice notice-error is-dismissible"><p>' . $this->get_translated_text( 'Error saving settings. Please try again.' ) . '</p></div>';
        }

        // Render settings page
        echo '<div class="wrap">';
        
        // Display notification message
        if ( ! empty( $message ) ) {
            echo $message;
        }

        // Render tabs
        echo '<h2 class="nav-tab-wrapper">';
        foreach ( $this->tabs as $tab_id => $tab_name ) {
            $active = $current_tab === $tab_id ? ' nav-tab-active' : '';
            echo '<a href="' . esc_url( admin_url( 'admin.php?page=vrstore-settings-page&tab=' . $tab_id ) ) . '" class="nav-tab' . esc_attr($active  ?? "") . '">' . esc_html($tab_name  ?? "") . '</a>';
        }
        echo '</h2>';

        // Render settings form with documentation sidebar for General tab
        if ( 'general' === $current_tab ) {
            echo '<div class="vrstore-settings-container" style="display: flex; gap: 20px;">';
            echo '<div class="vrstore-settings-main" style="flex: 2;">';
        }
        
        echo '<form method="post" action="options.php">';
        settings_fields( 'vrstore_settings' );
        
        // Add hidden field to track current tab
        echo '<input type="hidden" name="vrstore_settings[active_tab]" value="' . esc_attr( $current_tab ) . '" />';
        
        do_settings_sections( 'vrstore_settings_' . $current_tab );
        submit_button();
        echo '</form>';
        
        if ( 'general' === $current_tab ) {
            echo '</div>'; // Close settings-main
            echo '<div class="vrstore-documentation-sidebar" style="flex: 1; background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; padding: 20px; max-height: 80vh; overflow-y: auto;">';
            $this->render_documentation_sidebar();
            echo '</div>'; // Close documentation-sidebar
            echo '</div>'; // Close settings-container
        }
        echo '</div>';
    }

    /**
     * Render payment test logs.
     *
     * @since 1.0.0
     * @return void
     */
    public function render_payment_test_logs() {
        $test_logs = get_option( 'vrstore_payment_test_logs', array() );
        
        echo '<div class="vrstore-payment-test-logs">';
        
        if ( empty( $test_logs ) ) {
            echo '<p class="description">' . esc_html__( 'No payment test logs available.', 'vira-store' ) . '</p>';
        } else {
            echo '<div class="vrstore-test-logs-container" style="max-height: 300px; overflow-y: auto; border: 1px solid #ddd; padding: 10px; background: #f9f9f9;">';
            
            // Show latest 10 logs
            $recent_logs = array_slice( array_reverse( $test_logs ), 0, 10 );
            
            foreach ( $recent_logs as $log ) {
                $status_class = $log['status'] === 'success' ? 'success' : 'error';
                $status_icon = $log['status'] === 'success' ? 'dashicons-yes-alt' : 'dashicons-dismiss';
                $status_color = $log['status'] === 'success' ? '#46b450' : '#dc3232';
                
                echo '<div class="test-log-entry" style="margin-bottom: 10px; padding: 8px; border-left: 3px solid ' . esc_attr( $status_color ) . '; background: white;">';
                echo '<div style="display: flex; align-items: center; margin-bottom: 5px;">';
                echo '<span class="dashicons ' . esc_attr( $status_icon ) . '" style="color: ' . esc_attr( $status_color ) . '; margin-right: 5px;"></span>';
                echo '<strong>' . esc_html( ucfirst( $log['status'] ) ) . '</strong>';
                echo '<span style="margin-left: auto; color: #666; font-size: 12px;">' . esc_html( $log['timestamp'] ) . '</span>';
                echo '</div>';
                echo '<div style="font-size: 13px; color: #333;">';
                echo '<strong>Gateway:</strong> ' . esc_html( $log['gateway'] ) . ' | ';
                echo '<strong>Amount:</strong> $' . esc_html( number_format( $log['amount'], 2 ) ) . '<br>';
                if ( ! empty( $log['message'] ) ) {
                    echo '<strong>Message:</strong> ' . esc_html( $log['message'] );
                }
                echo '</div>';
                echo '</div>';
            }
            
            echo '</div>';
            
            // Clear logs button
            echo '<p style="margin-top: 10px;">';
            echo '<button type="button" class="button" onclick="vrstore_clear_test_logs()">' . esc_html__( 'Clear Test Logs', 'vira-store' ) . '</button>';
            echo '</p>';
        }
        
        echo '</div>';
    }

    /**
     * Render payment test runner.
     *
     * @since 1.0.0
     * @return void
     */
    public function render_payment_test_runner() {
        $enabled_gateways = get_option( 'vrstore_enabled_gateways', array() );
        $test_amounts = get_option( 'vrstore_test_payment_amounts', '1.00, 5.00, 10.00, 25.00, 50.00' );
        $amounts_array = array_map( 'trim', explode( ',', $test_amounts ) );
        
        echo '<div class="vrstore-payment-test-runner">';
        
        if ( empty( $enabled_gateways ) ) {
            echo '<p class="description" style="color: #dc3232;">' . esc_html__( 'No payment gateways are enabled. Please enable at least one gateway to run tests.', 'vira-store' ) . '</p>';
        } else {
            echo '<div class="test-runner-form" style="background: #f9f9f9; padding: 15px; border: 1px solid #ddd;">';
            
            // Gateway selection
            echo '<div style="margin-bottom: 15px;">';
            echo '<label for="test_gateway"><strong>' . esc_html__( 'Select Gateway:', 'vira-store' ) . '</strong></label><br>';
            echo '<select id="test_gateway" style="width: 200px; margin-top: 5px;">';
            foreach ( $enabled_gateways as $gateway ) {
                $gateway_name = ucfirst( str_replace( '_', ' ', $gateway ) );
                echo '<option value="' . esc_attr( $gateway ) . '">' . esc_html( $gateway_name ) . '</option>';
            }
            echo '</select>';
            echo '</div>';
            
            // Amount selection
            echo '<div style="margin-bottom: 15px;">';
            echo '<label for="test_amount"><strong>' . esc_html__( 'Test Amount:', 'vira-store' ) . '</strong></label><br>';
            echo '<select id="test_amount" style="width: 200px; margin-top: 5px;">';
            foreach ( $amounts_array as $amount ) {
                if ( is_numeric( $amount ) && $amount > 0 ) {
                    echo '<option value="' . esc_attr( $amount ) . '">$' . esc_html( number_format( floatval( $amount ), 2 ) ) . '</option>';
                }
            }
            echo '</select>';
            echo '</div>';
            
            // Test type selection
            echo '<div style="margin-bottom: 15px;">';
            echo '<label for="test_type"><strong>' . esc_html__( 'Test Type:', 'vira-store' ) . '</strong></label><br>';
            echo '<select id="test_type" style="width: 200px; margin-top: 5px;">';
            echo '<option value="connection">' . esc_html__( 'Connection Test', 'vira-store' ) . '</option>';
            echo '<option value="transaction">' . esc_html__( 'Test Transaction', 'vira-store' ) . '</option>';
            echo '<option value="webhook">' . esc_html__( 'Webhook Test', 'vira-store' ) . '</option>';
            echo '</select>';
            echo '</div>';
            
            // Run test button
            echo '<div>';
            echo '<button type="button" class="button button-primary" onclick="vrstore_run_payment_test()">' . esc_html__( 'Run Payment Test', 'vira-store' ) . '</button>';
            echo '<span id="test_status" style="margin-left: 10px;"></span>';
            echo '</div>';
            
            echo '</div>';
            
            // Test results area
            echo '<div id="test_results" style="margin-top: 15px; display: none;">';
            echo '<h4>' . esc_html__( 'Test Results:', 'vira-store' ) . '</h4>';
            echo '<div id="test_results_content" style="background: white; padding: 10px; border: 1px solid #ddd; border-radius: 3px;"></div>';
            echo '</div>';
        }
        
        echo '</div>';
    }

    /**
     * Generate API key.
     *
     * @since 1.0.0
     * @return string
     */
    private function generate_api_key() {
        // Check settings first (primary source)
        $settings = get_option( 'vrstore_settings', array() );
        $api_key = isset( $settings['api_key'] ) ? $settings['api_key'] : '';
        
        // Fallback to standalone option for backward compatibility
        if ( empty( $api_key ) ) {
            $api_key = get_option( 'vrstore_api_key', '' );
        }

        // Generate new API key if none exists
        if ( empty( $api_key ) ) {
            $api_key = wp_generate_password( 32, false );
            
            // Store in both places for consistency
            update_option( 'vrstore_api_key', $api_key );
            
            // Also update settings if they exist
            if ( ! empty( $settings ) ) {
                $settings['api_key'] = $api_key;
                update_option( 'vrstore_settings', $settings );
            }
        }

        return $api_key;
    }

    /**
     * Get currencies.
     *
     * @since 1.0.0
     * @return array
     */
    private function get_currencies() {
        return array(
            'USD' => $this->get_translated_text( 'US Dollar ($)' ),
            'EUR' => $this->get_translated_text( 'Euro (€)' ),
            'GBP' => $this->get_translated_text( 'British Pound (£)' ),
            'JPY' => $this->get_translated_text( 'Japanese Yen (¥)' ),
            'IDR' => $this->get_translated_text( 'Indonesian Rupiah (Rp)' ),
            'AUD' => $this->get_translated_text( 'Australian Dollar ($)' ),
            'BRL' => $this->get_translated_text( 'Brazilian Real (R$)' ),
            'CAD' => $this->get_translated_text( 'Canadian Dollar ($)' ),
            'CNY' => $this->get_translated_text( 'Chinese Yuan (¥)' ),
            'HKD' => $this->get_translated_text( 'Hong Kong Dollar ($)' ),
            'INR' => $this->get_translated_text( 'Indian Rupee (₹)' ),
            'MXN' => $this->get_translated_text( 'Mexican Peso ($)' ),
            'MYR' => $this->get_translated_text( 'Malaysian Ringgit (RM)' ),
            'NZD' => $this->get_translated_text( 'New Zealand Dollar ($)' ),
            'PHP' => $this->get_translated_text( 'Philippine Peso (₱)' ),
            'SGD' => $this->get_translated_text( 'Singapore Dollar ($)' ),
            'THB' => $this->get_translated_text( 'Thai Baht (฿)' ),
            'VND' => $this->get_translated_text( 'Vietnamese Dong (₫)' ),
            'ZAR' => $this->get_translated_text( 'South African Rand (R)' ),
        );
    }

    /**
     * Get pages options for select fields.
     *
     * @since 1.0.0
     * @return array
     */
    private function get_pages_options() {
        $pages = get_pages();
        $options = array(
            '' => $this->get_translated_text( 'Select a page' ),
        );
        
        foreach ( $pages as $page ) {
            $options[ $page->ID ] = $page->post_title;
        }
        
        return $options;
    }

    /**
     * Flush rewrite rules after product permalink slug change.
     *
     * @since 1.0.0
     * @return void
     */
    public function flush_rewrite_rules_after_slug_change() {
        // Only flush once per request
        static $flushed = false;
        if ( $flushed ) {
            return;
        }
        
        // Flush rewrite rules to update the product permalink structure
        flush_rewrite_rules();
        $flushed = true;
    }

    /**
     * Get setting.
     *
     * @since 1.0.0
     * @param string $key     Setting key.
     * @param mixed  $default Default value.
     * @return mixed
     */
    public function get_setting( $key, $default = '' ) {
        $options = get_option( 'vrstore_settings', array() );

        return isset( $options[ $key ] ) ? $options[ $key ] : $default;
    }

    /**
     * Check if we're in admin report context where K/M formatting is appropriate
     *
     * @return bool
     */
    private function is_admin_report_context() {
        // Check if we're in admin reports, dashboard, or similar contexts
        $admin_pages = ['vrstore-reports', 'vrstore-dashboard', 'vrstore-admin'];
        $current_page = isset($_GET['page']) ? $_GET['page'] : '';
        return in_array($current_page, $admin_pages) || (is_admin() && strpos($current_page, 'vrstore') !== false);
    }
    
    /**
     * Convert large numbers to K/M format
     *
     * @since 1.0.0
     * @param float $amount Amount to convert
     * @return string Converted amount or original if less than 1000
     */
    private function format_large_number( $amount ) {
        if ( $amount >= 1000000 ) {
            $formatted = $amount / 1000000;
            // Remove trailing zeros and decimal point if not needed
            $formatted = rtrim( rtrim( number_format( $formatted, 2, '.', '' ), '0' ), '.' );
            return $formatted . 'M';
        } elseif ( $amount >= 1000 ) {
            $formatted = $amount / 1000;
            // Remove trailing zeros and decimal point if not needed
            $formatted = rtrim( rtrim( number_format( $formatted, 2, '.', '' ), '0' ), '.' );
            return $formatted . 'K';
        }
        return $amount;
    }

    /**
     * Format price according to currency settings.
     *
     * @since 1.0.0
     * @param float $amount Amount to format.
     * @return string Formatted price.
     */
    public function format_price( $amount ) {
        // Determine current currency based on settings and visitor location
        $currency = $this->get_current_currency();

        $currency_position = $this->get_setting( 'currency_position', 'left' );
        $thousand_separator = $this->get_setting( 'thousand_separator', ',' );
        $decimal_separator = $this->get_setting( 'decimal_separator', '.' );
        $decimal_number = intval( $this->get_setting( 'decimal_number', 2 ) );

        // If default prices are stored in USD and current currency is IDR, convert
        // BUT skip conversion for amounts that are already large (likely already converted)
        // OR for Extended Support context (already converted)
        $default_currency = $this->get_setting( 'currency', 'USD' );
        $likely_already_converted = ( $currency === 'IDR' && $amount >= 10000 ); // IDR amounts are typically large
        if ( $default_currency === 'USD' && $currency === 'IDR' && ! $likely_already_converted && ! $this->is_extended_support_context() ) {
            $amount = $this->convert_amount_if_needed( $amount, 'USD', 'IDR' );
        }

        // Get currency symbol
        $currency_symbols = array(
            'USD' => '$',
            'EUR' => '€',
            'GBP' => '£',
            'JPY' => '¥',
            'IDR' => 'Rp',
            'AUD' => '$',
            'BRL' => 'R$',
            'CAD' => '$',
            'CNY' => '¥',
            'HKD' => '$',
            'INR' => '₹',
            'MXN' => '$',
            'MYR' => 'RM',
            'NZD' => '$',
            'PHP' => '₱',
            'SGD' => '$',
            'THB' => '฿',
            'VND' => '₫',
            'ZAR' => 'R'
        );
        
        $symbol = isset( $currency_symbols[ $currency ] ) ? $currency_symbols[ $currency ] : $currency;
        
        // Only use K/M formatting for admin reports, not for product displays
        // Check if this is being called from admin context
        $is_admin_context = is_admin() || (defined('WP_CLI') && WP_CLI) || $this->is_admin_report_context();
        
        if ( $is_admin_context && $amount >= 1000 ) {
            $formatted_amount = $this->format_large_number( $amount );
        } else {
            // Always use full formatting for frontend product displays
            $formatted_amount = number_format( $amount, $decimal_number, $decimal_separator, $thousand_separator );
        }
        
        // Apply currency position
        switch ( $currency_position ) {
            case 'right':
                $formatted_price = $formatted_amount . $symbol;
                break;
            case 'left_space':
                $formatted_price = $symbol . ' ' . $formatted_amount;
                break;
            case 'right_space':
                $formatted_price = $formatted_amount . ' ' . $symbol;
                break;
            case 'left':
            default:
                $formatted_price = $symbol . $formatted_amount;
                break;
        }
        
        /**
         * Filter the formatted price.
         *
         * @since 1.0.0
         * @param string $formatted_price The formatted price string.
         * @param float  $amount          The final amount post-conversion.
         * @param string $currency        The currency code in use.
         * @param array  $settings        Currency formatting settings.
         */
        $final_price = apply_filters( 'vrstore_formatted_price', $formatted_price, $amount, $currency, array(
            'position' => $currency_position,
            'symbol' => $symbol,
            'thousand_separator' => $thousand_separator,
            'decimal_separator' => $decimal_separator,
            'decimal_number' => $decimal_number
        ) );
        
        return $final_price;
    }

    /**
     * Format already-converted price without doing currency conversion and without K/M abbreviations.
     * Use this for product prices that have already been converted.
     *
     * @since 1.0.0
     * @param float $amount Already converted amount.
     * @return string Formatted price.
     */
    public function format_converted_product_price( $amount ) {
        // Determine current currency based on settings and visitor location
        $currency = $this->get_current_currency();

        $currency_position = $this->get_setting( 'currency_position', 'left' );
        $thousand_separator = $this->get_setting( 'thousand_separator', ',' );
        $decimal_separator = $this->get_setting( 'decimal_separator', '.' );
        $decimal_number = intval( $this->get_setting( 'decimal_number', 2 ) );

        // Do NOT convert amount - it's already converted

        // Get currency symbol
        $currency_symbols = array(
            'USD' => '$',
            'EUR' => '€',
            'GBP' => '£',
            'JPY' => '¥',
            'IDR' => 'Rp',
            'AUD' => '$',
            'BRL' => 'R$',
            'CAD' => '$',
            'CNY' => '¥',
            'HKD' => '$',
            'INR' => '₹',
            'MXN' => '$',
            'MYR' => 'RM',
            'NZD' => '$',
            'PHP' => '₱',
            'SGD' => '$',
            'THB' => '฿',
            'VND' => '₫',
            'ZAR' => 'R'
        );
        
        $symbol = isset( $currency_symbols[ $currency ] ) ? $currency_symbols[ $currency ] : $currency;
        
        // Do NOT use K/M formatting for product prices - always show full amount
        $formatted_amount = number_format( $amount, $decimal_number, $decimal_separator, $thousand_separator );
        
        // Apply currency position
        switch ( $currency_position ) {
            case 'right':
                $formatted_price = $formatted_amount . $symbol;
                break;
            case 'left_space':
                $formatted_price = $symbol . ' ' . $formatted_amount;
                break;
            case 'right_space':
                $formatted_price = $formatted_amount . ' ' . $symbol;
                break;
            case 'left':
            default:
                $formatted_price = $symbol . $formatted_amount;
                break;
        }
        
        return $formatted_price;
    }

    /**
     * Format already-converted price without doing currency conversion.
     * Use this for amounts that have already been converted (e.g., from dashboard stats, reports).
     *
     * @since 1.0.0
     * @param float $amount Already converted amount.
     * @return string Formatted price.
     */
    public function format_converted_price( $amount, $force_base_currency = false ) {
        // For admin reports, always use base currency
        // For frontend, use the current currency based on settings and visitor location
        $currency = $force_base_currency ? $this->get_setting('currency', 'USD') : $this->get_current_currency();

        $currency_position = $this->get_setting( 'currency_position', 'left' );
        $thousand_separator = $this->get_setting( 'thousand_separator', ',' );
        $decimal_separator = $this->get_setting( 'decimal_separator', '.' );
        $decimal_number = intval( $this->get_setting( 'decimal_number', 2 ) );

        // Do NOT convert amount - it's already converted

        // Get currency symbol
        $currency_symbols = array(
            'USD' => '$',
            'EUR' => '€',
            'GBP' => '£',
            'JPY' => '¥',
            'IDR' => 'Rp',
            'AUD' => '$',
            'BRL' => 'R$',
            'CAD' => '$',
            'CNY' => '¥',
            'HKD' => '$',
            'INR' => '₹',
            'MXN' => '$',
            'MYR' => 'RM',
            'NZD' => '$',
            'PHP' => '₱',
            'SGD' => '$',
            'THB' => '฿',
            'VND' => '₫',
            'ZAR' => 'R'
        );
        
        $symbol = isset( $currency_symbols[ $currency ] ) ? $currency_symbols[ $currency ] : $currency;
        
        // Use K/M formatting for reports and dashboards, but NOT for product prices
        if ( $amount >= 1000 ) {
            $formatted_amount = $this->format_large_number( $amount );
        } else {
            // Format the number normally for amounts less than 1000
            $formatted_amount = number_format( $amount, $decimal_number, $decimal_separator, $thousand_separator );
        }
        
        // Apply currency position
        switch ( $currency_position ) {
            case 'right':
                $formatted_price = $formatted_amount . $symbol;
                break;
            case 'left_space':
                $formatted_price = $symbol . ' ' . $formatted_amount;
                break;
            case 'right_space':
                $formatted_price = $formatted_amount . ' ' . $symbol;
                break;
            case 'left':
            default:
                $formatted_price = $symbol . $formatted_amount;
                break;
        }
        
        /**
         * Filter the formatted converted price.
         *
         * @since 1.0.0
         * @param string $formatted_price The formatted price string.
         * @param float  $amount          The amount (already converted).
         * @param string $currency        The currency code in use.
         * @param array  $settings        Currency formatting settings.
         */
        return apply_filters( 'vrstore_formatted_converted_price', $formatted_price, $amount, $currency, array(
            'position' => $currency_position,
            'symbol' => $symbol,
            'thousand_separator' => $thousand_separator,
            'decimal_separator' => $decimal_separator,
            'decimal_number' => $decimal_number
        ) );
    }


    /**
     * Get current currency from settings.
     *
     * @since 1.0.0
     * @return string Currency code
     */
    public function get_current_currency() {
        // Check if currency conversion is enabled
        if ( $this->get_setting( 'enable_currency_conversion', 'no' ) !== 'yes' ) {
            // If conversion is disabled, always return base currency
            return $this->get_setting( 'currency', 'USD' );
        }
        
        // If conversion is enabled, delegate to currency converter for IP-based detection
        $currency_converter = VRSTORE_Currency_Converter::get_instance();
        return $currency_converter->get_user_currency();
    }
    
    /**
     * Format price specifically for admin reports using base currency only.
     * This method always uses the base currency from settings, ignoring IP detection.
     *
     * @since 1.0.0
     * @param float $amount Amount to format.
     * @return string Formatted price in base currency.
     */
    public function format_admin_price( $amount ) {
        // Always use base currency for admin context
        $currency = $this->get_setting( 'currency', 'USD' );
        
        $currency_position = $this->get_setting( 'currency_position', 'left' );
        $thousand_separator = $this->get_setting( 'thousand_separator', ',' );
        $decimal_separator = $this->get_setting( 'decimal_separator', '.' );
        $decimal_number = intval( $this->get_setting( 'decimal_number', 2 ) );
        
        // Get currency symbol
        $currency_symbols = array(
            'USD' => '$',
            'EUR' => '€',
            'GBP' => '£',
            'JPY' => '¥',
            'IDR' => 'Rp',
            'AUD' => '$',
            'BRL' => 'R$',
            'CAD' => '$',
            'CNY' => '¥',
            'HKD' => '$',
            'INR' => '₹',
            'MXN' => '$',
            'MYR' => 'RM',
            'NZD' => '$',
            'PHP' => '₱',
            'SGD' => '$',
            'THB' => '฿',
            'VND' => '₫',
            'ZAR' => 'R'
        );
        
        $symbol = isset( $currency_symbols[ $currency ] ) ? $currency_symbols[ $currency ] : $currency;
        
        // Use K/M formatting for large amounts in reports
        if ( $amount >= 1000 ) {
            $formatted_amount = $this->format_large_number( $amount );
        } else {
            $formatted_amount = number_format( $amount, $decimal_number, $decimal_separator, $thousand_separator );
        }
        
        // Apply currency position
        switch ( $currency_position ) {
            case 'right':
                $formatted_price = $formatted_amount . $symbol;
                break;
            case 'left_space':
                $formatted_price = $symbol . ' ' . $formatted_amount;
                break;
            case 'right_space':
                $formatted_price = $formatted_amount . ' ' . $symbol;
                break;
            case 'left':
            default:
                $formatted_price = $symbol . $formatted_amount;
                break;
        }
        
        return $formatted_price;
    }


    /**
     * Check if we're in Extended Support context (cart/checkout with Extended Support items).
     *
     * @since 1.0.0
     * @return bool
     */
    private function is_extended_support_context() {
        // Check if cart contains Extended Support items
        if ( class_exists( 'VRSTORE_Cart' ) ) {
            $cart_instance = VRSTORE_Cart::get_instance();
            $cart = $cart_instance->get_cart();
            
            foreach ( $cart as $item ) {
                if ( isset( $item['product_id'] ) && is_string( $item['product_id'] ) && strpos( $item['product_id'], 'extended_support' ) === 0 ) {
                    return true;
                }
            }
        }
        
        // Check URL parameters for Extended Support
        if ( isset( $_GET['extended_support'] ) || isset( $_POST['extended_support'] ) ) {
            return true;
        }
        
        return false;
    }
    

    /**
     * Render admin page.
     *
     * @since 1.0.0
     * @return void
     */
    public function render_admin_page() {
        // Check user capabilities
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        // Include dashboard view template
        $template_path = VRSTORE_PLUGIN_DIR . 'views/admin-page.php';
        if ( file_exists( $template_path ) ) {
            include $template_path;
        } else {
            echo '<div class="wrap">';
            echo '<h1>' . $this->get_translated_text( 'Vira Store Dashboard', 'vira-store' ) . '</h1>';
        echo '<p>' . $this->get_translated_text( 'Welcome to Vira Store dashboard.', 'vira-store' ) . '</p>';
            echo '</div>';
        }
    }

    /**
     * Render products page.
     *
     * @since 1.0.0
     * @return void
     */
    public function render_products_page() {
        // Check user capabilities
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        // Include products view template
        $template_path = VRSTORE_PLUGIN_DIR . 'views/products-page.php';
        if ( file_exists( $template_path ) ) {
            include $template_path;
        } else {
            echo '<div class="wrap">';
            echo '<h1>' . $this->get_translated_text( 'Products', 'vira-store' ) . '</h1>';
        echo '<p>' . $this->get_translated_text( 'Manage your products here.', 'vira-store' ) . '</p>';
            echo '</div>';
        }
    }

    /**
     * Render licenses page.
     *
     * @since 1.0.0
     * @return void
     */
    public function render_licenses_page() {
        // Check user capabilities
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        // Include licenses view template
        $template_path = VRSTORE_PLUGIN_DIR . 'views/licenses-page.php';
        if ( file_exists( $template_path ) ) {
            include $template_path;
        } else {
            echo '<div class="wrap">';
            echo '<h1>' . $this->get_translated_text( 'Licenses', 'vira-store' ) . '</h1>';
        echo '<p>' . $this->get_translated_text( 'Manage your licenses here.', 'vira-store' ) . '</p>';
            echo '</div>';
        }
    }
    
    /**
     * Render documentation sidebar for the General tab.
     *
     * @since 1.0.0
     * @return void
     */
    private function render_documentation_sidebar() {
        echo '<h3>' . $this->get_translated_text( 'Documentation', 'vira-store' ) . '</h3>';
        echo '<div class="vrstore-docs-nav" style="margin-bottom: 20px;">';
        echo '<ul style="list-style-type: disc; padding-left: 20px;">';
        echo '<li><a href="#shortcodes">' . $this->get_translated_text( 'Available Shortcodes', 'vira-store' ) . '</a></li>';
        echo '<li><a href="#templates">' . $this->get_translated_text( 'Template Files', 'vira-store' ) . '</a></li>';
        echo '<li><a href="#hooks">' . $this->get_translated_text( 'Action & Filter Hooks', 'vira-store' ) . '</a></li>';
        echo '<li><a href="#api">' . $this->get_translated_text( 'API Reference', 'vira-store' ) . '</a></li>';
        echo '<li><a href="#integration">' . $this->get_translated_text( 'Plugin Integration', 'vira-store' ) . '</a></li>';
        echo '<li><a href="#faq">' . $this->get_translated_text( 'FAQs', 'vira-store' ) . '</a></li>';
        echo '</ul>';
        echo '</div>';
        
        // Shortcodes section
        echo '<div id="shortcodes" class="vrstore-docs-section">';
        echo '<h4>' . $this->get_translated_text( 'Available Shortcodes', 'vira-store' ) . '</h4>';
        echo '<div class="vrstore-shortcode-table">';
        echo '<table class="widefat" style="border-collapse: collapse; width: 100%;">';
        echo '<thead>';
        echo '<tr>';
        echo '<th style="padding: 8px; border: 1px solid #ddd; text-align: left;">' . $this->get_translated_text( 'Shortcode', 'vira-store' ) . '</th>';
        echo '<th style="padding: 8px; border: 1px solid #ddd; text-align: left;">' . $this->get_translated_text( 'Description', 'vira-store' ) . '</th>';
        echo '</tr>';
        echo '</thead>';
        echo '<tbody>';
        
        // Product Grid
        echo '<tr>';
        echo '<td style="padding: 8px; border: 1px solid #ddd;"><code>[vrstore_products]</code></td>';
        echo '<td style="padding: 8px; border: 1px solid #ddd;">' . $this->get_translated_text( 'Display a grid of products. Optional attributes: category, limit, columns.', 'vira-store' ) . '</td>';
        echo '</tr>';
        
        // Product Page
        echo '<tr>';
        echo '<td style="padding: 8px; border: 1px solid #ddd;"><code>[vrstore_product id="123"]</code></td>';
        echo '<td style="padding: 8px; border: 1px solid #ddd;">' . $this->get_translated_text( 'Display a single product page. Required attribute: id.', 'vira-store' ) . '</td>';
        echo '</tr>';
        
        // Purchase Button
        echo '<tr>';
        echo '<td style="padding: 8px; border: 1px solid #ddd;"><code>[vrstore_buy_button id="123"]</code></td>';
        echo '<td style="padding: 8px; border: 1px solid #ddd;">' . $this->get_translated_text( 'Display a purchase button for product/course. Required attr: id. Opt: text, class.', 'vira-store' ) . '</td>';
        echo '</tr>';
        
        // Cart
        echo '<tr>';
        echo '<td style="padding: 8px; border: 1px solid #ddd;"><code>[vrstore_cart]</code></td>';
        echo '<td style="padding: 8px; border: 1px solid #ddd;">' . $this->get_translated_text( 'Display the shopping cart.', 'vira-store' ) . '</td>';
        echo '</tr>';
        
        // Checkout
        echo '<tr>';
        echo '<td style="padding: 8px; border: 1px solid #ddd;"><code>[vrstore_checkout]</code></td>';
        echo '<td style="padding: 8px; border: 1px solid #ddd;">' . $this->get_translated_text( 'Display the checkout form.', 'vira-store' ) . '</td>';
        echo '</tr>';
        
        // Purchase History
        echo '<tr>';
        echo '<td style="padding: 8px; border: 1px solid #ddd;"><code>[vrstore_account]</code></td>';
        echo '<td style="padding: 8px; border: 1px solid #ddd;">' . $this->get_translated_text( 'Display the customer portal and all report.', 'vira-store' ) . '</td>';
        echo '</tr>';
		
		// Affiliates and Courses
        echo '<tr>';
        echo '<td style="padding: 8px; border: 1px solid #ddd;"><code>[vrstore_courses] [vrstore_affiliates]</code></td>';
        echo '<td style="padding: 8px; border: 1px solid #ddd;">' . $this->get_translated_text( 'Display the course listing and affiliates portal.', 'vira-store' ) . '</td>';
        echo '</tr>';
               
        echo '</tbody>';
        echo '</table>';
        echo '</div>';
        echo '</div>'; // End shortcodes section
        
        // Templates section
        echo '<div id="templates" class="vrstore-docs-section" style="margin-top: 30px;">';
        echo '<h4>' . $this->get_translated_text( 'Template Files', 'vira-store' ) . '</h4>';
        echo '<p>' . $this->get_translated_text( 'You can override the plugin\'s template files by copying them to your theme directory in a folder called "vrstore".', 'vira-store' ) . '</p>';
        echo '<ul style="list-style-type: disc; padding-left: 20px;">';
        echo '<li><code>vrstore/products.php</code> - ' . $this->get_translated_text( 'Product grid layout', 'vira-store' ) . '</li>';
        echo '<li><code>vrstore/product.php</code> - ' . $this->get_translated_text( 'Single product page', 'vira-store' ) . '</li>';
        echo '<li><code>vrstore/cart.php</code> - ' . $this->get_translated_text( 'Shopping cart page', 'vira-store' ) . '</li>';
        echo '<li><code>vrstore/checkout.php</code> - ' . $this->get_translated_text( 'Checkout page', 'vira-store' ) . '</li>';
        echo '</ul>';
        echo '</div>'; // End templates section
        
        // Hooks section
        echo '<div id="hooks" class="vrstore-docs-section" style="margin-top: 30px;">';
        echo '<h4>' . $this->get_translated_text( 'Action & Filter Hooks', 'vira-store' ) . '</h4>';
        
        // Actions
        echo '<h5>' . $this->get_translated_text( 'Actions', 'vira-store' ) . '</h5>';
        echo '<ul style="list-style-type: disc; padding-left: 20px;">';
        echo '<li><code>vrstore_before_product_grid</code> - ' . $this->get_translated_text( 'Before the product grid is displayed', 'vira-store' ) . '</li>';
        echo '<li><code>vrstore_after_product_grid</code> - ' . $this->get_translated_text( 'After the product grid is displayed', 'vira-store' ) . '</li>';
        echo '<li><code>vrstore_before_single_product</code> - ' . $this->get_translated_text( 'Before the single product is displayed', 'vira-store' ) . '</li>';
        echo '<li><code>vrstore_after_single_product</code> - ' . $this->get_translated_text( 'After the single product is displayed', 'vira-store' ) . '</li>';
        echo '<li><code>vrstore_before_add_to_cart</code> - ' . $this->get_translated_text( 'Before the add to cart button', 'vira-store' ) . '</li>';
        echo '<li><code>vrstore_after_add_to_cart</code> - ' . $this->get_translated_text( 'After the add to cart button', 'vira-store' ) . '</li>';
        echo '<li><code>vrstore_before_checkout</code> - ' . $this->get_translated_text( 'Before the checkout form', 'vira-store' ) . '</li>';
        echo '<li><code>vrstore_after_checkout</code> - ' . $this->get_translated_text( 'After the checkout form', 'vira-store' ) . '</li>';
        echo '<li><code>vrstore_before_payment_gateways</code> - ' . $this->get_translated_text( 'Before the payment gateways section', 'vira-store' ) . '</li>';
        echo '<li><code>vrstore_after_payment_gateways</code> - ' . $this->get_translated_text( 'After the payment gateways section', 'vira-store' ) . '</li>';
        echo '<li><code>vrstore_payment_complete</code> - ' . $this->get_translated_text( 'When a payment is completed', 'vira-store' ) . '</li>';
        echo '<li><code>vrstore_license_created</code> - ' . $this->get_translated_text( 'When a license key is created', 'vira-store' ) . '</li>';
        echo '</ul>';
        
        // Filters
        echo '<h5>' . $this->get_translated_text( 'Filters', 'vira-store' ) . '</h5>';
        echo '<ul style="list-style-type: disc; padding-left: 20px;">';
        echo '<li><code>vrstore_product_price</code> - ' . $this->get_translated_text( 'Filter the product price', 'vira-store' ) . '</li>';
        echo '<li><code>vrstore_currency_symbol</code> - ' . $this->get_translated_text( 'Filter the currency symbol', 'vira-store' ) . '</li>';
        echo '<li><code>vrstore_formatted_price</code> - ' . $this->get_translated_text( 'Filter the formatted price', 'vira-store' ) . '</li>';
        echo '<li><code>vrstore_checkout_fields</code> - ' . $this->get_translated_text( 'Filter the checkout form fields', 'vira-store' ) . '</li>';
        echo '<li><code>vrstore_payment_gateways</code> - ' . $this->get_translated_text( 'Filter the available payment gateways', 'vira-store' ) . '</li>';
        echo '<li><code>vrstore_order_status_labels</code> - ' . $this->get_translated_text( 'Filter the order status labels', 'vira-store' ) . '</li>';
        echo '<li><code>vrstore_license_key_prefix</code> - ' . $this->get_translated_text( 'Filter the license key prefix', 'vira-store' ) . '</li>';
        echo '<li><code>vrstore_license_key_length</code> - ' . $this->get_translated_text( 'Filter the license key length', 'vira-store' ) . '</li>';
        echo '<li><code>vrstore_license_expiry</code> - ' . $this->get_translated_text( 'Filter the license expiry period', 'vira-store' ) . '</li>';
        echo '<li><code>vrstore_email_from_name</code> - ' . $this->get_translated_text( 'Filter the email from name', 'vira-store' ) . '</li>';
        echo '<li><code>vrstore_email_from_email</code> - ' . $this->get_translated_text( 'Filter the email from email', 'vira-store' ) . '</li>';
        echo '<li><code>vrstore_purchase_email_subject</code> - ' . $this->get_translated_text( 'Filter the purchase email subject', 'vira-store' ) . '</li>';
        echo '<li><code>vrstore_purchase_email_body</code> - ' . $this->get_translated_text( 'Filter the purchase email body', 'vira-store' ) . '</li>';
        echo '</ul>';
        echo '</div>'; // End hooks section
        
        // API Reference section
        echo '<div id="api" class="vrstore-docs-section" style="margin-top: 30px;">';
        echo '<h4>' . $this->get_translated_text( 'API Reference', 'vira-store' ) . '</h4>';
        echo '<p>' . $this->get_translated_text( 'The plugin provides several PHP functions that you can use in your theme or plugin:', 'vira-store' ) . '</p>';
        echo '<ul style="list-style-type: disc; padding-left: 20px;">';
        echo '<li><code>vrstore_get_product( $product_id )</code> - ' . $this->get_translated_text( 'Get a product by ID', 'vira-store' ) . '</li>';
        echo '<li><code>vrstore_get_products( $args )</code> - ' . $this->get_translated_text( 'Get products with optional arguments', 'vira-store' ) . '</li>';
        echo '<li><code>vrstore_format_price( $price )</code> - ' . $this->get_translated_text( 'Format a price according to currency settings', 'vira-store' ) . '</li>';
        echo '<li><code>vrstore_get_cart()</code> - ' . $this->get_translated_text( 'Get the current cart contents', 'vira-store' ) . '</li>';
        echo '<li><code>vrstore_add_to_cart( $product_id, $quantity )</code> - ' . $this->get_translated_text( 'Add a product to the cart', 'vira-store' ) . '</li>';
        echo '<li><code>vrstore_remove_from_cart( $cart_item_key )</code> - ' . $this->get_translated_text( 'Remove an item from the cart', 'vira-store' ) . '</li>';
        echo '<li><code>vrstore_get_orders( $user_id )</code> - ' . $this->get_translated_text( 'Get orders for a user', 'vira-store' ) . '</li>';
        echo '<li><code>vrstore_get_licenses( $user_id )</code> - ' . $this->get_translated_text( 'Get licenses for a user', 'vira-store' ) . '</li>';
        echo '<li><code>vrstore_verify_license( $license_key, $domain )</code> - ' . $this->get_translated_text( 'Verify a license key for a domain', 'vira-store' ) . '</li>';
        echo '</ul>';
        echo '</div>'; // End API Reference section
        
        // Plugin Integration section
        echo '<div id="integration" class="vrstore-docs-section" style="margin-top: 30px;">';
        echo '<h4>' . $this->get_translated_text( 'Plugin Integration', 'vira-store' ) . '</h4>';
        echo '<p>' . $this->get_translated_text( 'Vira Store is designed to work seamlessly with other WordPress plugins. Here are some integration examples and best practices:', 'vira-store' ) . '</p>';
        
        // WooCommerce Integration
        echo '<div class="vrstore-integration-item" style="margin-bottom: 20px;">';
        echo '<h5>' . $this->get_translated_text( 'WooCommerce Integration', 'vira-store' ) . '</h5>';
        echo '<p>' . $this->get_translated_text( 'Vira Store can work alongside WooCommerce for different product types:', 'vira-store' ) . '</p>';
        echo '<ul style="list-style-type: disc; padding-left: 20px;">';
        echo '<li>' . $this->get_translated_text( 'Use WooCommerce for physical products and Vira Store for digital products', 'vira-store' ) . '</li>';
        echo '<li>' . $this->get_translated_text( 'Share customer data using the vrstore_woocommerce_sync_customer hook', 'vira-store' ) . '</li>';
        echo '<li>' . $this->get_translated_text( 'Cross-reference orders using the vrstore_woocommerce_order_link filter', 'vira-store' ) . '</li>';
        echo '</ul>';
        echo '</div>';
               
        // Page Builders
        echo '<div class="vrstore-integration-item" style="margin-bottom: 20px;">';
        echo '<h5>' . $this->get_translated_text( 'Page Builders (Elementor, Beaver Builder, Divi)', 'vira-store' ) . '</h5>';
        echo '<p>' . $this->get_translated_text( 'Vira Store shortcodes work perfectly with page builders:', 'vira-store' ) . '</p>';
        echo '<ul style="list-style-type: disc; padding-left: 20px;">';
        echo '<li>' . $this->get_translated_text( 'Add shortcode widgets to display products in custom layouts', 'vira-store' ) . '</li>';
        echo '<li>' . $this->get_translated_text( 'Use CSS classes for custom styling: .vrstore-product, .vrstore-grid', 'vira-store' ) . '</li>';
        echo '<li>' . $this->get_translated_text( 'Leverage vrstore_product_grid_classes filter for additional styling', 'vira-store' ) . '</li>';
        echo '</ul>';
        echo '</div>';
               
        // Custom Integration Example
        echo '<div class="vrstore-integration-item" style="margin-bottom: 20px;">';
        echo '<h5>' . $this->get_translated_text( 'Custom Integration Example', 'vira-store' ) . '</h5>';
        echo '<p>' . $this->get_translated_text( 'Here\'s a code example for integrating with a custom plugin:', 'vira-store' ) . '</p>';
        echo '<pre style="background: #f4f4f4; padding: 10px; border-radius: 4px; overflow-x: auto; font-size: 12px;">';
        echo esc_html('// Hook into payment completion
add_action(\'vrstore_payment_complete\', \'my_custom_integration\', 10, 2);

function my_custom_integration($order_id, $customer_data) {
    // Your custom integration logic here
    // Example: Send data to external API
    $api_data = array(
        \'customer_email\' => $customer_data[\'email\'],
        \'product_id\' => get_post_meta($order_id, \'_vrstore_product_id\', true),
        \'license_key\' => $this->get_license_key_by_order($order_id) // Use table-based lookup
    );
    
    // Send to your API
    wp_remote_post(\'https://your-api.com/webhook\', array(
        \'body\' => json_encode($api_data),
        \'headers\' => array(\'Content-Type\' => \'application/json\')
    ));
}');
        echo '</pre>';
        echo '</div>';
        
        // Integration Best Practices
        echo '<div class="vrstore-integration-item">';
        echo '<h5>' . $this->get_translated_text( 'Integration Best Practices', 'vira-store' ) . '</h5>';
        echo '<ul style="list-style-type: disc; padding-left: 20px;">';
        echo '<li>' . $this->get_translated_text( 'Always check if Vira Store is active before using its functions', 'vira-store' ) . '</li>';
        echo '<li>' . $this->get_translated_text( 'Use proper error handling when making external API calls', 'vira-store' ) . '</li>';
        echo '<li>' . $this->get_translated_text( 'Test integrations thoroughly in a staging environment', 'vira-store' ) . '</li>';
        echo '<li>' . $this->get_translated_text( 'Use WordPress transients for caching external API responses', 'vira-store' ) . '</li>';
        echo '<li>' . $this->get_translated_text( 'Follow WordPress coding standards and security best practices', 'vira-store' ) . '</li>';
        echo '</ul>';
        echo '</div>';
        echo '</div>'; // End Plugin Integration section
        
        // FAQs section
        echo '<div id="faq" class="vrstore-docs-section" style="margin-top: 30px;">';
        echo '<h4>' . $this->get_translated_text( 'FAQs', 'vira-store' ) . '</h4>';
        
        // FAQ 1
        echo '<div class="vrstore-faq-item">';
        echo '<h5>' . $this->get_translated_text( 'How do I create a product?', 'vira-store' ) . '</h5>';
        echo '<p>' . $this->get_translated_text( 'Go to Products > Add New in the admin menu. Fill in the product details, set the price, upload a file, and publish.', 'vira-store' ) . '</p>';
        echo '</div>';
        
        // FAQ 2
        echo '<div class="vrstore-faq-item">';
        echo '<h5>' . $this->get_translated_text( 'How do I display products on my site?', 'vira-store' ) . '</h5>';
        echo '<p>' . $this->get_translated_text( 'Use the [vrstore_products] shortcode on any page or post. You can customize it with attributes like category, limit, and columns.', 'vira-store' ) . '</p>';
        echo '</div>';
        
        // FAQ 3
        echo '<div class="vrstore-faq-item">';
        echo '<h5>' . $this->get_translated_text( 'How do license keys work?', 'vira-store' ) . '</h5>';
        echo '<p>' . $this->get_translated_text( 'License keys are automatically generated when a customer purchases a product. The keys are sent in the purchase email and can be viewed in the customer\'s account.', 'vira-store' ) . '</p>';
        echo '</div>';
        
        // FAQ 4
        echo '<div class="vrstore-faq-item">';
        echo '<h5>' . $this->get_translated_text( 'How can I customize the email templates?', 'vira-store' ) . '</h5>';
        echo '<p>' . $this->get_translated_text( 'You can customize the email templates in the General tab of the settings page. You can use placeholders like {site_name}, {customer_name}, etc.', 'vira-store' ) . '</p>';
        echo '</div>';
        
        // FAQ 5
        echo '<div class="vrstore-faq-item">';
        echo '<h5>' . $this->get_translated_text( 'How do I set up payment gateways?', 'vira-store' ) . '</h5>';
        echo '<p>' . $this->get_translated_text( 'Go to the Payment tab in the settings page. Enable the payment gateways you want to use and enter your API keys.', 'vira-store' ) . '</p>';
        echo '</div>';
        
        echo '</div>'; // End FAQs section
    }

    /**
     * Render license type configuration field.
     *
     * @since 1.0.0
     * @param array $args Field arguments.
     * @param mixed $value Current value.
     * @param string $name Field name.
     * @return void
     */
    private function render_license_type_config_field( $args, $value, $name ) {
        // Security: Check user capabilities
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        // Performance: Cache license types query (transient cache for 5 minutes)
        $cache_key = 'vrstore_license_types_' . get_current_blog_id();
        $license_types = get_transient( $cache_key );
        
        if ( false === $license_types ) {
            $license_types = get_terms( array(
                'taxonomy' => 'vrstore_license_type',
                'hide_empty' => false,
                'number' => 100, // Limit to prevent performance issues
            ) );
            
            // Cache successful queries only
            if ( ! is_wp_error( $license_types ) ) {
                set_transient( $cache_key, $license_types, 5 * MINUTE_IN_SECONDS );
            }
        }

        if ( is_wp_error( $license_types ) || empty( $license_types ) ) {
            echo '<p>' . esc_html( $this->get_translated_text( 'No license types found. Please create license types first.', 'vira-store' ) ) . '</p>';
            return;
        }

        // Ensure value is an array (security: type checking)
        if ( ! is_array( $value ) ) {
            $value = array();
        }

        echo '<div class="vrstore-license-type-configs">';
        echo '<table class="widefat striped">';
        echo '<thead>';
        echo '<tr>';
        echo '<th>' . esc_html( $this->get_translated_text( 'License Type' ) ) . '</th>';
        echo '<th>' . esc_html( $this->get_translated_text( 'Price' ) ) . '</th>';
        echo '<th>' . esc_html( $this->get_translated_text( 'Expiration (Months)' ) ) . '</th>';
        echo '<th>' . esc_html( $this->get_translated_text( 'Max Activations' ) ) . '</th>';
        echo '</tr>';
        echo '</thead>';
        echo '<tbody>';

        foreach ( $license_types as $license_type ) {
            $type_id = $license_type->term_id;
            $price = isset( $value[ $type_id ]['price'] ) ? $value[ $type_id ]['price'] : '';
            $expiry = isset( $value[ $type_id ]['expiry'] ) ? $value[ $type_id ]['expiry'] : '';
            $activations = isset( $value[ $type_id ]['activations'] ) ? $value[ $type_id ]['activations'] : '';

            echo '<tr>';
            echo '<td><strong>' . esc_html( $license_type->name ) . '</strong></td>';
            echo '<td>';
            printf(
                '<input type="number" name="%s[%d][price]" value="%s" min="0" max="999999.99" step="0.01" class="small-text" placeholder="%s" />',
                esc_attr( $name ),
                esc_attr( $type_id ),
                esc_attr( $price ),
                esc_attr( $this->get_translated_text( 'Free' ) )
            );
            echo '</td>';
            echo '<td>';
            printf(
                '<input type="number" name="%s[%d][expiry]" value="%s" min="0" max="600" step="1" class="small-text" placeholder="%s" />',
                esc_attr( $name ),
                esc_attr( $type_id ),
                esc_attr( $expiry ),
                esc_attr( $this->get_translated_text( 'Default' ) )
            );
            echo '</td>';
            echo '<td>';
            printf(
                '<input type="number" name="%s[%d][activations]" value="%s" min="0" max="10000" step="1" class="small-text" placeholder="%s" />',
                esc_attr( $name ),
                esc_attr( $type_id ),
                esc_attr( $activations ),
                esc_attr( $this->get_translated_text( 'Default' ) )
            );
            echo '</td>';
            echo '</tr>';
        }

        echo '</tbody>';
        echo '</table>';
        echo '<p class="description">' . esc_html( $this->get_translated_text( 'Configure pricing, expiration and activation limits for each license type. Leave empty to use default settings. Prices will be used for license-based pricing in checkout.' ) ) . '</p>';
        echo '</div>';

        // Add some basic styling
        echo '<style>';
        echo '.vrstore-license-type-configs table { margin-top: 10px; }';
        echo '.vrstore-license-type-configs .small-text { width: 80px; }';
        echo '</style>';
    }

    /**
     * Sanitize license type configuration data.
     *
     * @since 1.0.0
     * @param mixed $input Raw input data.
     * @return array Sanitized data.
     */
    private function sanitize_license_type_config( $input ) {
        $output = array();

        // Security: Validate input type
        if ( ! is_array( $input ) ) {
            return $output;
        }

        // Security: Limit array size to prevent DoS
        if ( count( $input ) > 100 ) {
            error_log( 'ViraStore: License type config input exceeds maximum limit (100)' );
            return $output;
        }

        // Performance: Verify taxonomy terms exist in bulk (reduces queries)
        global $wpdb;
        $taxonomy = 'vrstore_license_type';
        $valid_term_ids = wp_list_pluck( get_terms( array(
            'taxonomy' => $taxonomy,
            'hide_empty' => false,
            'fields' => 'ids',
            'number' => 100,
        ) ), 'term_id' );

        foreach ( $input as $type_id => $config ) {
            // Security: Validate and sanitize type_id
            $type_id = absint( $type_id );
            if ( $type_id <= 0 || ! in_array( $type_id, $valid_term_ids, true ) ) {
                continue; // Skip invalid term IDs
            }

            // Security: Validate config is array
            if ( ! is_array( $config ) ) {
                continue;
            }

            $sanitized_config = array();

            // Security & Validation: Sanitize price with limits
            if ( isset( $config['price'] ) && $config['price'] !== '' ) {
                $price = floatval( $config['price'] );
                // Security: Limit maximum price to prevent overflow (999,999.99)
                if ( $price >= 0 && $price <= 999999.99 ) {
                    $sanitized_config['price'] = number_format( $price, 2, '.', '' );
                } else {
                    error_log( 'ViraStore: Invalid price value for license type ' . $type_id . ': ' . $price );
                }
            }

            // Security & Validation: Sanitize expiry with reasonable limits (0-600 months = 50 years max)
            if ( isset( $config['expiry'] ) && $config['expiry'] !== '' ) {
                $expiry = absint( $config['expiry'] );
                if ( $expiry >= 0 && $expiry <= 600 ) {
                    $sanitized_config['expiry'] = $expiry;
                } else {
                    error_log( 'ViraStore: Invalid expiry value for license type ' . $type_id . ': ' . $expiry );
                }
            }

            // Security & Validation: Sanitize activations with reasonable limits (1-10000)
            if ( isset( $config['activations'] ) && $config['activations'] !== '' ) {
                $activations = absint( $config['activations'] );
                if ( $activations > 0 && $activations <= 10000 ) {
                    $sanitized_config['activations'] = $activations;
                } else {
                    error_log( 'ViraStore: Invalid activations value for license type ' . $type_id . ': ' . $activations );
                }
            }

            // Only save if we have at least one valid config
            if ( ! empty( $sanitized_config ) ) {
                $output[ $type_id ] = $sanitized_config;
            }
        }

        // Performance: Clear license types cache after save
        delete_transient( 'vrstore_license_types_' . get_current_blog_id() );

        return $output;
    }

    /**
     * Render custom license type configuration field.
     *
     * @since 1.0.0
     * @param array $args Field arguments.
     * @param mixed $value Current value.
     * @param string $name Field name.
     * @return void
     */
    private function render_custom_license_type_config_field( $args, $value, $name ) {
        // Security: Check user capabilities
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        // Security: Ensure value is an array and validate structure
        if ( ! is_array( $value ) ) {
            $value = array();
        }

        // Security: Limit displayed items for performance (prevent DoS)
        $max_items = 50;
        if ( count( $value ) > $max_items ) {
            $value = array_slice( $value, 0, $max_items, true );
            echo '<div class="notice notice-warning"><p>' . esc_html( sprintf( $this->get_translated_text( 'Only the first %d license types are displayed for performance. Remove some to add more.', 'vira-store' ), $max_items ) ) . '</p></div>';
        }

        echo '<div class="vrstore-custom-license-types">';
        echo '<div id="vrstore-license-types-container">';
        
        // Display existing license types
        if ( ! empty( $value ) ) {
            $index = 0;
            foreach ( $value as $license_type_data ) {
                // Security: Validate data structure
                if ( ! is_array( $license_type_data ) ) {
                    continue;
                }
                $this->render_license_type_row( $name, $index, $license_type_data );
                $index++;
            }
        } else {
            // Show one empty row by default
            $this->render_license_type_row( $name, 0, array() );
        }
        
        echo '</div>';
        
        // Add new license type button with max limit indicator
        echo '<button type="button" id="add-license-type" class="button button-secondary" style="margin-top: 10px;" data-max-items="' . esc_attr( $max_items ) . '">' . esc_html( $this->get_translated_text( 'Add License Type' ) ) . '</button>';
        echo '<p class="description">' . esc_html( $this->get_translated_text( 'Create custom license types with their own labels, pricing, expiration (in months), and activation limits. Examples: Unlimited, Whitelabel, Personal, Business, etc. Maximum ' . $max_items . ' license types allowed.', 'vira-store' ) ) . '</p>';
               
        // JavaScript functionality moved to admin.js for better separation of concerns
        
        // Styles moved to admin.css
    }

    /**
     * Render a single license type row.
     *
     * @since 1.0.0
     * @param string $name Field name.
     * @param int $index Row index.
     * @param array $data License type data.
     * @return void
     */
    private function render_license_type_row( $name, $index, $data ) {
        // Security: Validate index is numeric and within limits
        $index = absint( $index );
        if ( $index > 100 ) {
            return; // Prevent excessive indices
        }

        // Security: Sanitize data inputs
        $label = isset( $data['label'] ) ? sanitize_text_field( $data['label'] ) : '';
        $regular_price = isset( $data['regular_price'] ) ? $data['regular_price'] : '';
        $sale_price = isset( $data['sale_price'] ) ? $data['sale_price'] : '';
        $expiry_months = isset( $data['expiry_months'] ) ? $data['expiry_months'] : '';
        $max_activations = isset( $data['max_activations'] ) ? $data['max_activations'] : '';
        // extended_support_months field removed - duration is calculated automatically
        $extended_support_price = isset( $data['extended_support_price'] ) ? $data['extended_support_price'] : '';
        $lock_tickets_on_expiry = isset( $data['lock_tickets_on_expiry'] ) ? $data['lock_tickets_on_expiry'] : false;
        
        echo '<div class="license-type-row" data-index="' . esc_attr( $index ) . '" style="background: #f9f9f9; padding: 15px; margin: 10px 0; border-radius: 4px;">';
        echo '<table class="form-table">';
        
        // License Type Label with length limit (security: prevent XSS and DoS)
        echo '<tr>';
        echo '<td><label><strong>' . esc_html__( 'License Type Label', 'vira-store' ) . '</strong></label></td>';
        echo '<td><input type="text" name="' . esc_attr( $name ) . '[' . esc_attr( $index ) . '][label]" value="' . esc_attr( $label ) . '" placeholder="e.g., Unlimited, Whitelabel" class="regular-text" maxlength="100" required /></td>';
        echo '</tr>';
        
        // Regular Price (security: max limit, validation)
        echo '<tr>';
        echo '<td><label>' . esc_html__( 'Regular Price', 'vira-store' ) . '</label></td>';
        echo '<td><input type="number" name="' . esc_attr( $name ) . '[' . esc_attr( $index ) . '][regular_price]" value="' . esc_attr( $regular_price ) . '" min="0" max="999999.99" step="0.01" class="small-text" placeholder="0.00" /></td>';
        echo '</tr>';
        
        // Sale Price (security: max limit, must be <= regular price)
        echo '<tr>';
        echo '<td><label>' . esc_html__( 'Sale Price', 'vira-store' ) . '</label></td>';
        echo '<td><input type="number" name="' . esc_attr( $name ) . '[' . esc_attr( $index ) . '][sale_price]" value="' . esc_attr( $sale_price ) . '" min="0" max="999999.99" step="0.01" class="small-text" placeholder="0.00" data-regular-price-field="' . esc_attr( $name ) . '[' . esc_attr( $index ) . '][regular_price]" />';
        echo '<span class="description" style="margin-left: 10px; color: #d63638; display: none;" id="sale-price-error-' . esc_attr( $index ) . '">' . esc_html__( 'Sale price must be less than regular price', 'vira-store' ) . '</span></td>';
        echo '</tr>';
        
        // Expiration (months) (security: reasonable limits 0-600 months)
        echo '<tr>';
        echo '<td><label>' . esc_html__( 'Expiration (months)', 'vira-store' ) . '</label></td>';
        echo '<td><input type="number" name="' . esc_attr( $name ) . '[' . esc_attr( $index ) . '][expiry_months]" value="' . esc_attr( $expiry_months ) . '" min="0" max="600" step="1" class="small-text" placeholder="0 = Lifetime" /></td>';
        echo '</tr>';
        
        // Max Activations (security: reasonable limits 1-10000)
        echo '<tr>';
        echo '<td><label>' . esc_html__( 'Max Activations', 'vira-store' ) . '</label></td>';
        echo '<td><input type="number" name="' . esc_attr( $name ) . '[' . esc_attr( $index ) . '][max_activations]" value="' . esc_attr( $max_activations ) . '" min="1" max="10000" step="1" class="small-text" placeholder="1" /></td>';
        echo '</tr>';
        
        // Extended Support Section Header
        echo '<tr class="vrstore-extended-support-header">';
        echo '<td colspan="2"><hr style="margin: 15px 0 10px 0;"><h4 style="margin: 0; color: #0073aa;">' . esc_html__( 'Extended Support Configuration', 'vira-store' ) . '</h4><p class="description" style="margin: 5px 0 10px 0;">' . esc_html__( 'Configure extended support options when license expires. Leave empty to disable extended support for this license type.', 'vira-store' ) . '</p></td>';
        echo '</tr>';
        
        // Extended Support Price (security: max limit)
        echo '<tr class="vrstore-extended-support-field">';
        echo '<td><label>' . esc_html__( 'Extended Support Price', 'vira-store' ) . '</label></td>';
        
        // Performance: Cache currency setting
        static $base_currency_cache = null;
        if ( null === $base_currency_cache ) {
            $base_currency_cache = $this->get_setting('currency', 'USD');
        }
        $base_currency = $base_currency_cache;
        
        $currency_symbols = array(
            'USD' => '$',
            'IDR' => 'Rp',
            'EUR' => '€',
            'GBP' => '£'
        );
        $currency_symbol = isset($currency_symbols[$base_currency]) ? $currency_symbols[$base_currency] : $base_currency;
        
        echo '<td><input type="number" name="' . esc_attr( $name ) . '[' . esc_attr( $index ) . '][extended_support_price]" value="' . esc_attr( $extended_support_price ) . '" min="0" max="999999.99" step="0.01" class="small-text" placeholder="0.00" /><span class="description" style="margin-left: 10px;">' . esc_html__( 'Price for the extended support period', 'vira-store' ) . ' <strong>(' . esc_html($currency_symbol) . ' ' . esc_html($base_currency) . ')</strong></span></td>';
        echo '</tr>';
        
        // Lock Ticket Support on Expiry (security: boolean validation)
        echo '<tr class="vrstore-extended-support-field">';
        echo '<td><label>' . esc_html__( 'Lock Ticket Support', 'vira-store' ) . '</label></td>';
        echo '<td><input type="checkbox" name="' . esc_attr( $name ) . '[' . esc_attr( $index ) . '][lock_tickets_on_expiry]" value="1" ' . checked( $lock_tickets_on_expiry, true, false ) . ' /> ' . esc_html__( 'Enable', 'vira-store' ) . '<span class="description" style="margin-left: 10px; display: block; margin-top: 5px;">' . esc_html__( 'When enabled, customers with expired licenses will not be able to create new tickets or reply to existing tickets until they purchase Extended Support.', 'vira-store' ) . '</span></td>';
        echo '</tr>';
        
        // Remove button (don't show for first row if it's the only one)
        // Security: Add data attribute for JS validation
        if ( $index > 0 ) {
            echo '<tr>';
            echo '<td colspan="2"><button type="button" class="remove-license-type button button-link-delete" data-index="' . esc_attr( $index ) . '">' . esc_html__( 'Remove', 'vira-store' ) . '</button></td>';
            echo '</tr>';
        }
        
        echo '</table>';
        echo '</div>';
    }

    /**
     * Sanitize custom license type configuration data.
     *
     * @since 1.0.0
     * @param mixed $input Raw input data.
     * @return array Sanitized data.
     */
    private function sanitize_custom_license_type_config( $input ) {
        $output = array();

        // Security: Validate input type
        if ( ! is_array( $input ) ) {
            return $output;
        }

        // Security: Limit array size to prevent DoS (max 50 license types)
        if ( count( $input ) > 50 ) {
            error_log( 'ViraStore: Custom license type config input exceeds maximum limit (50)' );
            $input = array_slice( $input, 0, 50, true );
        }

        // Performance: Track used slugs for duplicate detection
        $used_slugs = array();
        $used_labels = array();

        foreach ( $input as $index => $config ) {
            // Security: Validate index and config structure
            $index = absint( $index );
            if ( $index > 100 || ! is_array( $config ) ) {
                continue;
            }

            $sanitized_config = array();

            // Security: Sanitize label (required, max 100 chars)
            if ( empty( $config['label'] ) ) {
                continue; // Skip if no label
            }
            
            $sanitized_config['label'] = sanitize_text_field( $config['label'] );
            
            // Security: Validate label length
            if ( empty( $sanitized_config['label'] ) || strlen( $sanitized_config['label'] ) > 100 ) {
                error_log( 'ViraStore: Invalid label length for license type at index ' . $index );
                continue;
            }

            // Security: Check for duplicate labels
            $label_lower = strtolower( trim( $sanitized_config['label'] ) );
            if ( in_array( $label_lower, $used_labels, true ) ) {
                error_log( 'ViraStore: Duplicate license type label detected: ' . $sanitized_config['label'] );
                continue; // Skip duplicates
            }
            $used_labels[] = $label_lower;

            // Security & Validation: Sanitize regular price with limits
            $regular_price_val = null;
            if ( isset( $config['regular_price'] ) && $config['regular_price'] !== '' ) {
                $price = floatval( $config['regular_price'] );
                // Security: Limit maximum price (999,999.99)
                if ( $price >= 0 && $price <= 999999.99 ) {
                    $regular_price_val = $price;
                    $sanitized_config['regular_price'] = number_format( $price, 2, '.', '' );
                } else {
                    error_log( 'ViraStore: Invalid regular price for license type "' . $sanitized_config['label'] . '": ' . $price );
                }
            }

            // Security & Validation: Sanitize sale price with limits and comparison
            $sale_price_val = null;
            if ( isset( $config['sale_price'] ) && $config['sale_price'] !== '' ) {
                $price = floatval( $config['sale_price'] );
                // Security: Limit maximum price and validate against regular price
                if ( $price >= 0 && $price <= 999999.99 ) {
                    // Validation: Sale price must be <= regular price if both are set
                    if ( null !== $regular_price_val && $price > $regular_price_val ) {
                        error_log( 'ViraStore: Sale price exceeds regular price for license type "' . $sanitized_config['label'] . '"' );
                        // Set sale price to regular price as fallback
                        $price = $regular_price_val;
                    }
                    $sale_price_val = $price;
                    $sanitized_config['sale_price'] = number_format( $price, 2, '.', '' );
                } else {
                    error_log( 'ViraStore: Invalid sale price for license type "' . $sanitized_config['label'] . '": ' . $price );
                }
            }

            // Security & Validation: Sanitize expiry months with reasonable limits (0-600 months = 50 years)
            if ( isset( $config['expiry_months'] ) && $config['expiry_months'] !== '' ) {
                $months = absint( $config['expiry_months'] );
                if ( $months <= 600 ) {
                    $sanitized_config['expiry_months'] = $months;
                } else {
                    error_log( 'ViraStore: Invalid expiry months for license type "' . $sanitized_config['label'] . '": ' . $months );
                    $sanitized_config['expiry_months'] = 0; // Default to lifetime
                }
            }

            // Security & Validation: Sanitize max activations with reasonable limits (1-10000)
            if ( isset( $config['max_activations'] ) && $config['max_activations'] !== '' ) {
                $activations = absint( $config['max_activations'] );
                if ( $activations > 0 && $activations <= 10000 ) {
                    $sanitized_config['max_activations'] = $activations;
                } else {
                    error_log( 'ViraStore: Invalid max activations for license type "' . $sanitized_config['label'] . '": ' . $activations );
                    $sanitized_config['max_activations'] = 1; // Default to 1
                }
            } else {
                $sanitized_config['max_activations'] = 1; // Default to 1 if not set
            }
            
            // Extended support months field removed - duration is calculated automatically based on license type configuration
            
            // Security & Validation: Sanitize extended support price with limits
            if ( isset( $config['extended_support_price'] ) && $config['extended_support_price'] !== '' ) {
                $support_price = floatval( $config['extended_support_price'] );
                // Security: Limit maximum price (999,999.99)
                if ( $support_price >= 0 && $support_price <= 999999.99 ) {
                    $sanitized_config['extended_support_price'] = number_format( $support_price, 2, '.', '' );
                } else {
                    error_log( 'ViraStore: Invalid extended support price for license type "' . $sanitized_config['label'] . '": ' . $support_price );
                }
            }
            
            // Security: Sanitize lock tickets on expiry option (strict boolean check)
            $sanitized_config['lock_tickets_on_expiry'] = isset( $config['lock_tickets_on_expiry'] ) && ( $config['lock_tickets_on_expiry'] === '1' || $config['lock_tickets_on_expiry'] === 1 || $config['lock_tickets_on_expiry'] === true );

            // Security: Create a slug from the label for internal use (prevent duplicate slugs)
            $sanitized_config['slug'] = sanitize_title( $sanitized_config['label'] );
            
            // Security: Check for duplicate slugs
            if ( empty( $sanitized_config['slug'] ) || in_array( $sanitized_config['slug'], $used_slugs, true ) ) {
                // Generate unique slug by appending index if duplicate
                $base_slug = $sanitized_config['slug'] ?: 'license-type-' . $index;
                $counter = 1;
                while ( in_array( $sanitized_config['slug'], $used_slugs, true ) ) {
                    $sanitized_config['slug'] = $base_slug . '-' . $counter;
                    $counter++;
                }
            }
            $used_slugs[] = $sanitized_config['slug'];

            $output[] = $sanitized_config;
        }

        // Performance: Clear license types cache after save to ensure fresh data on next render
        delete_transient( 'vrstore_license_types_' . get_current_blog_id() );

        return $output;
    }

    /**
     * Render LiteSpeed Cache status.
     *
     * @since 1.0.0
     * @return void
     */
    public function render_litespeed_status() {
        $is_active = $this->is_litespeed_cache_active();
        $is_installed = $this->is_litespeed_cache_installed();
        
        echo '<div class="vrstore-litespeed-status">';
        
        if ( $is_active ) {
            echo '<span class="dashicons dashicons-yes-alt" style="color: #46b450;"></span> ';
            echo '<strong style="color: #46b450;">' . esc_html__( 'Active', 'vira-store' ) . '</strong>';
            echo '<p class="description">' . esc_html__( 'LiteSpeed Cache plugin is active and ready for integration.', 'vira-store' ) . '</p>';
            
            // Show LiteSpeed Cache version if available
            if ( defined( 'LSCWP_V' ) ) {
                echo '<p class="description">' . sprintf( esc_html__( 'Version: %s', 'vira-store' ), LSCWP_V ) . '</p>';
            }
        } elseif ( $is_installed ) {
            echo '<span class="dashicons dashicons-warning" style="color: #ffb900;"></span> ';
            echo '<strong style="color: #ffb900;">' . esc_html__( 'Installed but Inactive', 'vira-store' ) . '</strong>';
            echo '<p class="description">' . esc_html__( 'LiteSpeed Cache plugin is installed but not activated.', 'vira-store' ) . ' ';
            echo '<a href="' . esc_url( admin_url( 'plugins.php' ) ) . '">' . esc_html__( 'Activate it here', 'vira-store' ) . '</a></p>';
        } else {
            echo '<span class="dashicons dashicons-dismiss" style="color: #dc3232;"></span> ';
            echo '<strong style="color: #dc3232;">' . esc_html__( 'Not Installed', 'vira-store' ) . '</strong>';
            echo '<p class="description">' . esc_html__( 'LiteSpeed Cache plugin is not installed.', 'vira-store' ) . ' ';
            echo '<a href="' . esc_url( admin_url( 'plugin-install.php?s=litespeed+cache&tab=search&type=term' ) ) . '" target="_blank">' . esc_html__( 'Install it here', 'vira-store' ) . '</a></p>';
        }
        
        echo '</div>';
    }

    /**
     * Render detected plugins.
     *
     * @since 1.0.0
     * @return void
     */
    public function render_detected_plugins() {
        $detected_plugins = $this->get_detected_integration_plugins();
        
        echo '<div class="vrstore-detected-plugins">';
        
        if ( empty( $detected_plugins ) ) {
            echo '<p class="description">' . esc_html__( 'No compatible plugins detected.', 'vira-store' ) . '</p>';
        } else {
            echo '<ul style="list-style-type: disc; padding-left: 20px;">';
            foreach ( $detected_plugins as $plugin ) {
                $status_icon = $plugin['active'] ? 'dashicons-yes-alt' : 'dashicons-warning';
                $status_color = $plugin['active'] ? '#46b450' : '#ffb900';
                $status_text = $plugin['active'] ? esc_html__( 'Active', 'vira-store' ) : esc_html__( 'Inactive', 'vira-store' );
                
                echo '<li style="margin-bottom: 10px;">';
                echo '<span class="dashicons ' . esc_attr( $status_icon ) . '" style="color: ' . esc_attr( $status_color ) . ';"></span> ';
                echo '<strong>' . esc_html( $plugin['name'] ) . '</strong> - ';
                echo '<span style="color: ' . esc_attr( $status_color ) . ';">' . $status_text . '</span>';
                if ( ! empty( $plugin['description'] ) ) {
                    echo '<br><span class="description">' . esc_html( $plugin['description'] ) . '</span>';
                }
                echo '</li>';
            }
            echo '</ul>';
        }
        
        echo '</div>';
    }

    /**
     * Check if LiteSpeed Cache plugin is active.
     *
     * @since 1.0.0
     * @return bool
     */
    private function is_litespeed_cache_active() {
        return class_exists( 'LiteSpeed\Core' ) || function_exists( 'run_litespeed_cache' );
    }

    /**
     * Check if LiteSpeed Cache plugin is installed.
     *
     * @since 1.0.0
     * @return bool
     */
    private function is_litespeed_cache_installed() {
        if ( ! function_exists( 'get_plugins' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        
        $plugins = get_plugins();
        foreach ( $plugins as $plugin_file => $plugin_data ) {
            if ( strpos( $plugin_file, 'litespeed-cache' ) !== false ) {
                return true;
            }
        }
        
        return false;
    }

    /**
     * Auto-detect checkout page with [vrstore_checkout] shortcode.
     *
     * @since 1.0.0
     * @return string|null Page URL or null if not found
     */
    public function get_auto_detected_checkout_url() {
        // Check if auto-detection is enabled
        $auto_detect_enabled = $this->get_setting('enable_auto_checkout_detection', 'on');
        if ($auto_detect_enabled !== 'on') {
            return null;
        }

        // Try to get from cache first
        $cached_url = get_transient('vrstore_auto_checkout_url');
        if ($cached_url !== false) {
            return $cached_url;
        }

        // Search for pages containing the [vrstore_checkout] shortcode
        global $wpdb;
        
        $pages = $wpdb->get_results(
            "SELECT ID, post_content FROM {$wpdb->posts} 
             WHERE post_type = 'page' 
             AND post_status = 'publish' 
             AND post_content LIKE '%[vrstore_checkout%'"
        );

        $checkout_url = null;
        
        if (!empty($pages)) {
            foreach ($pages as $page) {
                // Check if the shortcode is actually present (not just in comments)
                if (has_shortcode($page->post_content, 'vrstore_checkout')) {
                    $checkout_url = get_permalink($page->ID);
                    break;
                }
            }
        }

        // Cache the result for 1 hour
        set_transient('vrstore_auto_checkout_url', $checkout_url, HOUR_IN_SECONDS);
        
        return $checkout_url;
    }

    /**
     * Get checkout URL with auto-detection fallback.
     *
     * @since 1.0.0
     * @return string Checkout URL
     */
    public function get_checkout_url() {
        // First try the manually set checkout page
        $checkout_page_id = $this->get_setting('checkout_page', '');
        if (!empty($checkout_page_id) && get_post($checkout_page_id)) {
            return get_permalink($checkout_page_id);
        }

        // Try auto-detection
        $auto_detected_url = $this->get_auto_detected_checkout_url();
        if (!empty($auto_detected_url)) {
            return $auto_detected_url;
        }

        // Fallback to home URL
        return home_url();
    }

    /**
     * Clear checkout URL cache when pages are updated.
     *
     * @since 1.0.0
     * @param int $post_id Post ID
     * @return void
     */
    public function clear_checkout_url_cache($post_id) {
        if (get_post_type($post_id) === 'page') {
            delete_transient('vrstore_auto_checkout_url');
        }
    }

    /**
     * Get detected integration plugins.
     *
     * @since 1.0.0
     * @return array
     */
    private function get_detected_integration_plugins() {
        $plugins = array();
        
        // LiteSpeed Cache
        if ( $this->is_litespeed_cache_installed() ) {
            $plugins[] = array(
                'name'        => 'LiteSpeed Cache',
                'active'      => $this->is_litespeed_cache_active(),
                'description' => esc_html__( 'Advanced caching solution for better performance.', 'vira-store' ),
            );
        }
                
        return apply_filters( 'vrstore_detected_integration_plugins', $plugins );
    }

    /**
     * Get available payment gateway options.
     *
     * @since 1.0.0
     * @return array Payment gateway options
     */
    private function get_gateway_options() {
        $gateways = array(
            'tripay'  => $this->get_translated_text( 'TriPay' ),
            'manual'  => $this->get_translated_text( 'Transfer Bank' ),
        );
        
        // Only include PayPal if the addon is active
        if ( $this->is_paypal_addon_active() ) {
            $gateways['paypal'] = $this->get_translated_text( 'PayPal' );
        }
        
        // Only include Xendit if the addon is active
        if ( $this->is_xendit_addon_active() ) {
            $gateways['xendit'] = $this->get_translated_text( 'Xendit' );
        }
        
        // Only include Moota if the addon is active and enabled
        if ( $this->is_moota_addon_active() ) {
            $gateways['moota'] = $this->get_translated_text( 'Moota' );
        }
        
        return $gateways;
    }
    
    /**
     * Check if PayPal addon is active.
     *
     * @since 1.0.0
     * @return bool True if PayPal addon is active
     */
    private function is_paypal_addon_active() {
        return class_exists( 'ViraStore_PayPal' ) || is_plugin_active( 'virastore-paypal/virastore-paypal.php' );
    }
    
    /**
     * Check if Xendit addon is active.
     *
     * @since 1.0.0
     * @return bool True if Xendit addon is active
     */
    private function is_xendit_addon_active() {
        return class_exists( 'ViraStore_Xendit' ) || is_plugin_active( 'virastore-xendit/virastore-xendit.php' );
    }
    
    /**
     * Check if Moota addon is active.
     *
     * @since 1.0.0
     * @return bool True if Moota addon is active
     */
    private function is_moota_addon_active() {
        return class_exists( 'ViraStore_Moota' ) || class_exists( 'ViraStore_Moota_Gateway' ) || is_plugin_active( 'vrstore-moota/vrstore-moota.php' );
    }
    
    /**
     * Render TriPay callback URL information
     *
     * @since 1.0.0
     * @return void
     */
    public function render_tripay_callback_info() {
        $callback_url = home_url( '/wp-json/vrstore/v1/webhooks/tripay' );
        
        echo '<div class="tripay-callback-info" style="background: #f8f9fa; padding: 15px; border-radius: 5px; border-left: 4px solid #007cba;">';
        echo '<h4 style="margin-top: 0;">' . esc_html__( 'TriPay Configuration', 'vira-store' ) . '</h4>';
        echo '<p>' . esc_html__( 'Add this callback URL to your TriPay merchant dashboard:', 'vira-store' ) . '</p>';
        echo '<p><code style="background: #fff; padding: 8px; border-radius: 3px; word-break: break-all;">' . esc_url( $callback_url ) . '</code></p>';
        echo '<button type="button" class="button button-secondary" onclick="navigator.clipboard.writeText(\'' . esc_js( $callback_url ) . '\'); this.innerText=\'Copied!\'; setTimeout(() => this.innerText=\'Copy URL\', 2000);">' . esc_html__( 'Copy URL', 'vira-store' ) . '</button>';
        
        echo '<h4>' . esc_html__( 'Setup Instructions:', 'vira-store' ) . '</h4>';
        echo '<ol style="margin-left: 20px;">';
        echo '<li>' . esc_html__( 'Get your credentials from TriPay merchant dashboard', 'vira-store' ) . '</li>';
        echo '<li>' . esc_html__( 'Fill in the API Key, Private Key, and Merchant Code above', 'vira-store' ) . '</li>';
        echo '<li>' . esc_html__( 'Add the callback URL to your TriPay dashboard settings', 'vira-store' ) . '</li>';
        echo '<li>' . esc_html__( 'Enable TriPay in the "Payment Gateways" section', 'vira-store' ) . '</li>';
        echo '<li>' . esc_html__( 'Test with a small transaction in test mode', 'vira-store' ) . '</li>';
        echo '</ol>';
        
        $settings = get_option( 'vrstore_settings', array() );
        $test_mode = isset( $settings['tripay_test_mode'] ) && $settings['tripay_test_mode'] === 'on';
        if ( $test_mode ) {
            echo '<div class="notice notice-info inline" style="margin: 15px 0; padding: 10px;">';
            echo '<strong>' . esc_html__( 'Test Mode Active', 'vira-store' ) . '</strong><br>';
            echo esc_html__( 'TriPay is currently in test mode. Use sandbox credentials and switch to live mode for production.', 'vira-store' );
            echo '</div>';
        }
        
        echo '</div>';
    }

    
    /**
     * Format price for admin reports - always uses base currency.
     * Admin should see original configured prices, not converted amounts.
     *
     * @since 1.0.0
     * @param float $amount Amount to format.
     * @param bool $use_k_formatting Whether to use K/M formatting for large amounts.
     * @return string Formatted price with correct currency.
     */
    public function format_admin_extended_support_price( $amount, $use_k_formatting = true ) {
        // Admin reports should always use the base currency as configured in settings
        // Extended Support prices stored in database may be converted, but admin should see base currency
        $currency = $this->get_setting('currency', 'USD');
        
        // Convert Extended Support amounts back to base currency for admin display
        $amount = $this->convert_extended_support_to_base_currency($amount);
        
        $currency_position = $this->get_setting( 'currency_position', 'left' );
        $thousand_separator = $this->get_setting( 'thousand_separator', ',' );
        $decimal_separator = $this->get_setting( 'decimal_separator', '.' );
        $decimal_number = intval( $this->get_setting( 'decimal_number', 2 ) );
        
        // Adjust decimal places for IDR
        if ($currency === 'IDR') {
            $decimal_number = 0;
        }
        
        // Get currency symbol
        $currency_symbols = array(
            'USD' => '$',
            'EUR' => '€',
            'GBP' => '£',
            'JPY' => '¥',
            'IDR' => 'Rp',
            'AUD' => '$',
            'BRL' => 'R$',
            'CAD' => '$',
            'CNY' => '¥',
            'HKD' => '$',
            'INR' => '₹',
            'MXN' => '$',
            'MYR' => 'RM',
            'NZD' => '$',
            'PHP' => '₱',
            'SGD' => '$',
            'THB' => '฿',
            'VND' => '₫',
            'ZAR' => 'R'
        );
        
        $symbol = isset( $currency_symbols[ $currency ] ) ? $currency_symbols[ $currency ] : $currency;
        
        // Use K/M formatting for large amounts in reports if requested
        if ( $use_k_formatting && $amount >= 1000 ) {
            $formatted_amount = $this->format_large_number( $amount );
        } else {
            $formatted_amount = number_format( $amount, $decimal_number, $decimal_separator, $thousand_separator );
        }
        
        // Apply currency position
        switch ( $currency_position ) {
            case 'right':
                $formatted_price = $formatted_amount . $symbol;
                break;
            case 'left_space':
                $formatted_price = $symbol . ' ' . $formatted_amount;
                break;
            case 'right_space':
                $formatted_price = $formatted_amount . ' ' . $symbol;
                break;
            case 'left':
            default:
                $formatted_price = $symbol . $formatted_amount;
                break;
        }
        
        return $formatted_price;
    }
    
    /**
     * Extended Support prices are now properly converted at the data aggregation level.
     * No additional conversion needed in the formatting layer.
     *
     * @since 1.0.0
     * @param float $amount Amount to return
     * @return float Same amount (no conversion needed)
     */
    private function convert_extended_support_to_base_currency($amount) {
        // Admin reports now handle currency conversion at the data level
        // so no additional conversion is needed here
        return $amount;
    }

    /**
     * Convert amount if needed based on currency conversion settings.
     *
     * @since 1.8.0
     * @param float  $amount      Amount to convert.
     * @param string $from_currency Source currency.
     * @param string $to_currency   Target currency.
     * @return float Converted amount or original if conversion disabled.
     */
    private function convert_amount_if_needed( $amount, $from_currency, $to_currency ) {
        // Check if currency conversion is enabled
        if ( $this->get_setting( 'enable_currency_conversion', 'no' ) !== 'yes' && $this->get_setting( 'enable_currency_conversion', '' ) !== 'on' ) {
            return $amount;
        }

        // If same currency, no conversion needed
        if ( $from_currency === $to_currency ) {
            return $amount;
        }

        // Get currency converter instance
        $converter = ViraStore_Currency_Converter::get_instance();
        
        // Convert the amount
        return $converter->convert_amount( $amount, $from_currency, $to_currency );
    }

    /**
     * Render currency rates field.
     *
     * @since 1.8.0
     * @param array  $args  Field arguments.
     * @param mixed  $value Field value.
     * @param string $name  Field name.
     * @return void
     */
    private function render_currency_rates_field( $args, $value, $name ) {
        $currencies = array(
            'USD' => 'US Dollar',
            'EUR' => 'Euro',
            'GBP' => 'British Pound',
            'JPY' => 'Japanese Yen',
            'IDR' => 'Indonesian Rupiah',
            'CNY' => 'Chinese Yuan',
            'AUD' => 'Australian Dollar',
            'BRL' => 'Brazilian Real',
            'CAD' => 'Canadian Dollar',
            'HKD' => 'Hong Kong Dollar',
            'INR' => 'Indian Rupee',
            'MXN' => 'Mexican Peso',
            'MYR' => 'Malaysian Ringgit',
            'NZD' => 'New Zealand Dollar',
            'PHP' => 'Philippine Peso',
            'THB' => 'Thai Baht',
            'SGD' => 'Singapore Dollar',
            'VND' => 'Vietnamese Dong',
            'ZAR' => 'South African Rand',
        );

        $base_currency = isset( $this->options['currency'] ) ? $this->options['currency'] : 'USD';
        $rates = is_array( $value ) ? $value : array();

        echo '<div id="currency-rates-container">';
        echo '<table class="widefat" style="max-width: 600px;">';
        echo '<thead><tr><th>Currency</th><th>Exchange Rate (1 ' . esc_html( $base_currency ) . ' =)</th><th>Active</th></tr></thead>';
        echo '<tbody>';

        foreach ( $currencies as $code => $name ) {
            if ( $code === $base_currency ) {
                continue; // Skip base currency
            }

            $rate = isset( $rates[ $code ]['rate'] ) ? $rates[ $code ]['rate'] : 1.0;
            $active = isset( $rates[ $code ]['active'] ) ? $rates[ $code ]['active'] : 'on';

            echo '<tr>';
            echo '<td><strong>' . esc_html( $code ) . '</strong> - ' . esc_html( $name ) . '</td>';
            echo '<td>';
            printf(
                '<input type="number" name="vrstore_settings[currency_rates][%s][rate]" value="%s" step="0.0001" min="0" class="small-text" />',
                esc_attr( $code ),
                esc_attr( $rate )
            );
            echo '</td>';
            echo '<td>';
            printf(
                '<input type="checkbox" name="vrstore_settings[currency_rates][%s][active]" value="on" %s />',
                esc_attr( $code ),
                checked( $active, 'on', false )
            );
            echo '</td>';
            echo '</tr>';
        }

        echo '</tbody>';
        echo '</table>';
        echo '<p>';
        echo '<button type="button" id="update-currency-rates" class="button button-secondary">' . esc_html__( 'Update Rates from API', 'vira-store' ) . '</button>';
        echo '<span id="currency-update-status" style="margin-left: 10px;"></span>';
        echo '</p>';
        echo '</div>';
    }

    /**
     * Sanitize currency rates field.
     *
     * @since 1.8.0
     * @param mixed $input Input value.
     * @return array Sanitized rates.
     */
    private function sanitize_currency_rates( $input ) {
        if ( ! is_array( $input ) ) {
            return array();
        }

        $sanitized = array();
        foreach ( $input as $currency => $data ) {
            if ( ! is_array( $data ) ) {
                continue;
            }

            $sanitized[ $currency ] = array(
                'rate'   => isset( $data['rate'] ) ? max( 0, floatval( $data['rate'] ) ) : 1.0,
                'active' => isset( $data['active'] ) ? 'on' : '',
            );
        }

        return $sanitized;
    }

    /**
     * Update currency converter rates in the format it expects.
     *
     * @since 1.8.0
     * @param array $rates_data Sanitized rates data from settings.
     * @return void
     */
    private function update_currency_converter_rates( $rates_data ) {
        // Convert rates data to format expected by currency converter
        $converter_rates = array();
        foreach ( $rates_data as $currency => $data ) {
            if ( isset( $data['active'] ) && $data['active'] === 'on' && isset( $data['rate'] ) ) {
                $converter_rates[ $currency ] = (float) $data['rate'];
            }
        }
        
        // Update the vrstore_currency_rates option that the converter uses
        update_option( 'vrstore_currency_rates', $converter_rates );
    }
}
