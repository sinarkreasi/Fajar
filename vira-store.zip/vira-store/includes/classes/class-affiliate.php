<?php
/**
 * Affiliate Management Class
 *
 * Handles affiliate registration, tracking, commissions, and reporting.
 *
 * @package Vira_Store
 * @since 1.0.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

class VRSTORE_Affiliate {
    
    /**
     * Single instance of the class
     *
     * @var VRSTORE_Affiliate
     */
    private static $instance = null;
    
    /**
     * Database table names
     *
     * @var string
     */
    private $affiliates_table;
    private $affiliate_visits_table;
    private $affiliate_commissions_table;
    private $affiliate_withdrawals_table;
    
    /**
     * Constructor
     */
    private function __construct() {
        global $wpdb;
        
        $this->affiliates_table = $wpdb->prefix . 'vrstore_affiliates';
        $this->affiliate_visits_table = $wpdb->prefix . 'vrstore_affiliate_visits';
        $this->affiliate_commissions_table = $wpdb->prefix . 'vrstore_affiliate_commissions';
        $this->affiliate_withdrawals_table = $wpdb->prefix . 'vrstore_affiliate_withdrawals';
        
        $this->init_hooks();
    }
    
    /**
     * Get single instance
     *
     * @return VRSTORE_Affiliate
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Initialize hooks
     */
    private function init_hooks() {
        add_action('init', array($this, 'init'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'));
        add_action('wp_ajax_vrstore_register_affiliate', array($this, 'handle_affiliate_registration'));
        add_action('wp_ajax_nopriv_vrstore_register_affiliate', array($this, 'handle_affiliate_registration'));
        add_action('wp_ajax_vrstore_refresh_affiliate_stats', array($this, 'handle_refresh_stats'));
        add_action('wp_ajax_vrstore_generate_affiliate_links', array($this, 'handle_generate_affiliate_links'));
        add_action('wp_ajax_vrstore_get_payment_history', array($this, 'handle_get_payment_history'));
        add_action('wp_ajax_vrstore_request_withdrawal', array($this, 'handle_request_withdrawal'));
        add_action('wp_ajax_vrstore_get_affiliate_performance', array($this, 'handle_get_affiliate_performance'));
        add_action('wp_ajax_vrstore_format_currency_amounts', array($this, 'handle_format_currency_amounts'));
        
        // Admin AJAX handlers
        add_action('wp_ajax_vrstore_process_withdrawal', array($this, 'handle_process_withdrawal'));
        add_action('template_redirect', array($this, 'track_affiliate_visit'));
        add_action('template_redirect', array($this, 'handle_short_url_redirect'), 1); // High priority for short URL handling
        add_action('vrstore_order_completed', array($this, 'process_affiliate_commission'), 10, 2);
    }
    
    /**
     * Initialize affiliate system
     */
    public function init() {
        $this->create_tables();
        $this->load_textdomain();
    }
    
    /**
     * Load text domain for translations
     */
    private function load_textdomain() {
        if (!is_textdomain_loaded('vira-store')) {
            load_plugin_textdomain('vira-store', false, dirname(plugin_basename(__FILE__)) . '/languages/');
        }
    }
    
    /**
     * Create database tables
     */
    public function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Check if tables already exist to avoid conflicts
        $tables_exist = $wpdb->get_var("SHOW TABLES LIKE '{$this->affiliates_table}'");
        
        if (!$tables_exist) {
            // Affiliates table
            $sql_affiliates = "CREATE TABLE {$this->affiliates_table} (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                user_id bigint(20) unsigned NOT NULL,
                affiliate_code varchar(50) NOT NULL,
                name varchar(255) DEFAULT NULL,
                email varchar(255) DEFAULT NULL,
                website_url varchar(500) DEFAULT NULL,
                promotion_methods text DEFAULT NULL,
                payment_method varchar(50) DEFAULT 'paypal',
                payment_details text DEFAULT NULL,
                commission_rate decimal(5,2) NOT NULL DEFAULT 10.00,
                status enum('pending','active','suspended') NOT NULL DEFAULT 'pending',
                total_visits bigint(20) unsigned NOT NULL DEFAULT 0,
                total_conversions bigint(20) unsigned NOT NULL DEFAULT 0,
                total_commissions decimal(10,2) NOT NULL DEFAULT 0.00,
                unpaid_commissions decimal(10,2) NOT NULL DEFAULT 0.00,
                created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY affiliate_code (affiliate_code),
                KEY user_id (user_id),
                KEY status (status)
            ) $charset_collate;";
            
            $wpdb->query($sql_affiliates);
        } else {
            // Table exists, check if we need to add missing columns
            $this->migrate_affiliate_table_columns();
        }
        
        // Check visits table
        $visits_exist = $wpdb->get_var("SHOW TABLES LIKE '{$this->affiliate_visits_table}'");
        
        // Always check visits table for missing columns
        if ($visits_exist) {
            $this->migrate_affiliate_visits_table_columns();
        }
        
        if (!$visits_exist) {
            // Affiliate visits table
            $sql_visits = "CREATE TABLE {$this->affiliate_visits_table} (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                affiliate_id bigint(20) unsigned NOT NULL,
                visitor_ip varchar(45) NOT NULL,
                user_agent text,
                referrer_url text,
                landing_page text,
                visit_source varchar(50) DEFAULT 'regular',
                short_url_provider varchar(50) DEFAULT NULL,
                converted tinyint(1) NOT NULL DEFAULT 0,
                order_id bigint(20) unsigned NULL,
                created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY affiliate_id (affiliate_id),
                KEY visitor_ip (visitor_ip),
                KEY converted (converted),
                KEY visit_source (visit_source),
                KEY short_url_provider (short_url_provider),
                KEY created_at (created_at)
            ) $charset_collate;";
            
            $wpdb->query($sql_visits);
        }
        
        // Check commissions table
        $commissions_exist = $wpdb->get_var("SHOW TABLES LIKE '{$this->affiliate_commissions_table}'");
        
        if (!$commissions_exist) {
            // Affiliate commissions table
            $sql_commissions = "CREATE TABLE {$this->affiliate_commissions_table} (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                affiliate_id bigint(20) unsigned NOT NULL,
                order_id bigint(20) unsigned NOT NULL,
                visit_id bigint(20) unsigned NULL,
                commission_amount decimal(10,2) NOT NULL,
                commission_rate decimal(5,2) NOT NULL,
                order_total decimal(10,2) NOT NULL,
                status enum('pending','approved','paid','cancelled') NOT NULL DEFAULT 'pending',
                created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY affiliate_id (affiliate_id),
                KEY order_id (order_id),
                KEY status (status),
                KEY created_at (created_at)
            ) $charset_collate;";
            
            $wpdb->query($sql_commissions);
        }
        
        // Check withdrawals table
        $withdrawals_exist = $wpdb->get_var("SHOW TABLES LIKE '{$this->affiliate_withdrawals_table}'");
        
        if (!$withdrawals_exist) {
            // Affiliate withdrawals table
            $sql_withdrawals = "CREATE TABLE {$this->affiliate_withdrawals_table} (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                affiliate_id bigint(20) unsigned NOT NULL,
                amount decimal(10,2) NOT NULL,
                status enum('pending','approved','paid','cancelled') NOT NULL DEFAULT 'pending',
                payment_method varchar(50) DEFAULT 'paypal',
                payment_details text DEFAULT NULL,
                admin_notes text DEFAULT NULL,
                requested_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                processed_at datetime NULL,
                created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY affiliate_id (affiliate_id),
                KEY status (status),
                KEY requested_at (requested_at)
            ) $charset_collate;";
            
            $wpdb->query($sql_withdrawals);
        }
    }
    
    /**
     * Migrate affiliate table columns if they don't exist
     */
    private function migrate_affiliate_table_columns() {
        global $wpdb;
        
        $columns_to_add = [
            'name' => 'varchar(255) DEFAULT NULL',
            'email' => 'varchar(255) DEFAULT NULL', 
            'website_url' => 'varchar(500) DEFAULT NULL',
            'promotion_methods' => 'text DEFAULT NULL',
            'payment_method' => 'varchar(50) DEFAULT "paypal"',
            'payment_details' => 'text DEFAULT NULL',
            'notes' => 'text DEFAULT NULL COMMENT "Admin notes about this affiliate"'
        ];
        
        foreach ($columns_to_add as $column => $definition) {
            $column_exists = $wpdb->get_results($wpdb->prepare(
                "SHOW COLUMNS FROM {$this->affiliates_table} LIKE %s",
                $column
            ));
            
            if (empty($column_exists)) {
                $sql = "ALTER TABLE {$this->affiliates_table} ADD COLUMN $column $definition AFTER affiliate_code";
                $wpdb->query($sql);
            }
        }
    }
    
    /**
     * Migrate affiliate visits table columns if they don't exist
     */
    private function migrate_affiliate_visits_table_columns() {
        global $wpdb;
        
        $columns_to_add = [
            'visit_source' => 'varchar(50) DEFAULT "regular" AFTER landing_page',
            'short_url_provider' => 'varchar(50) DEFAULT NULL AFTER visit_source'
        ];
        
        foreach ($columns_to_add as $column => $definition) {
            $column_exists = $wpdb->get_results($wpdb->prepare(
                "SHOW COLUMNS FROM {$this->affiliate_visits_table} LIKE %s",
                $column
            ));
            
            if (empty($column_exists)) {
                $sql = "ALTER TABLE {$this->affiliate_visits_table} ADD COLUMN $column $definition";
                $wpdb->query($sql);
            }
        }
        
        // Add indexes for new columns if they don't exist
        $indexes_to_add = [
            'visit_source' => 'visit_source',
            'short_url_provider' => 'short_url_provider'
        ];
        
        foreach ($indexes_to_add as $index_name => $column_name) {
            $index_exists = $wpdb->get_results($wpdb->prepare(
                "SHOW INDEX FROM {$this->affiliate_visits_table} WHERE Key_name = %s",
                $index_name
            ));
            
            if (empty($index_exists)) {
                $sql = "ALTER TABLE {$this->affiliate_visits_table} ADD INDEX {$index_name} ({$column_name})";
                $wpdb->query($sql);
            }
        }
    }
    
    /**
     * Register new affiliate
     *
     * @param int $user_id
     * @param array $data
     * @return array
     */
    public function register_affiliate($user_id, $data = array()) {
        global $wpdb;
        
        // Check if user is already an affiliate
        if ($this->is_affiliate($user_id)) {
            return array(
                'success' => false,
                'message' => __('You are already registered as an affiliate.', 'vira-store')
            );
        }
        
        // Generate unique affiliate code
        $affiliate_code = $this->generate_affiliate_code($user_id);
        
        // Get default commission rate from settings
        $settings = get_option('vrstore_affiliate_settings', array());
        $default_commission_rate = isset($settings['default_commission_rate']) ? floatval($settings['default_commission_rate']) : 10.00;
        
        // Check for product-specific commission rates if user has purchased required products
        $commission_rate = $default_commission_rate;
        $join_requirement = get_option('vrstore_affiliate_join_requirement', 'free');
        
        if ($join_requirement === 'purchase_required') {
            $required_products = get_option('vrstore_affiliate_required_products', array());
            $product_commissions = get_option('vrstore_affiliate_product_commissions', array());
            
            if (!empty($required_products) && !empty($product_commissions)) {
                // Check which required products the user has purchased
                foreach ($required_products as $product_id) {
                    if ($this->user_has_completed_purchase($user_id, array($product_id))) {
                        // User has purchased this required product, check if it has a specific commission rate
                        if (isset($product_commissions[$product_id]) && $product_commissions[$product_id] > 0) {
                            // Use the highest commission rate among purchased products
                            $product_commission = floatval($product_commissions[$product_id]);
                            if ($product_commission > $commission_rate) {
                                $commission_rate = $product_commission;
                            }
                        }
                    }
                }
            }
        }
        
        // Determine status based on auto-approve setting
        $auto_approve = isset($settings['auto_approve_affiliates']) && $settings['auto_approve_affiliates'] === '1';
        $status = $auto_approve ? 'active' : 'pending';
        
        // Prepare affiliate data
        $affiliate_data = array(
            'user_id' => $user_id,
            'affiliate_code' => $affiliate_code,
            'commission_rate' => $commission_rate,
            'status' => $status,
            'created_at' => current_time('mysql')
        );
        
        // Add additional data if provided
        if (!empty($data['affiliate_name'])) {
            $affiliate_data['name'] = $data['affiliate_name'];
        }
        if (!empty($data['affiliate_email'])) {
            $affiliate_data['email'] = $data['affiliate_email'];
        }
        if (!empty($data['website_url'])) {
            $affiliate_data['website_url'] = $data['website_url'];
        }
        if (!empty($data['promotion_methods'])) {
            $affiliate_data['promotion_methods'] = $data['promotion_methods'];
        }
        if (!empty($data['payment_method'])) {
            $affiliate_data['payment_method'] = $data['payment_method'];
        }
        if (!empty($data['payment_details'])) {
            $affiliate_data['payment_details'] = $data['payment_details'];
        }
        
        // Insert affiliate record
        $format_array = array('%d', '%s'); // user_id, affiliate_code
        
        // Add format specifiers for optional fields
        if (isset($affiliate_data['name'])) $format_array[] = '%s';
        if (isset($affiliate_data['email'])) $format_array[] = '%s';
        if (isset($affiliate_data['website_url'])) $format_array[] = '%s';
        if (isset($affiliate_data['promotion_methods'])) $format_array[] = '%s';
        if (isset($affiliate_data['payment_method'])) $format_array[] = '%s';
        if (isset($affiliate_data['payment_details'])) $format_array[] = '%s';
        
        // Add format for required fields
        $format_array[] = '%f'; // commission_rate
        $format_array[] = '%s'; // status
        $format_array[] = '%s'; // created_at
        
        $result = $wpdb->insert(
            $this->affiliates_table,
            $affiliate_data,
            $format_array
        );
        
        if ($result === false) {
            return array(
                'success' => false,
                'message' => __('Failed to register as affiliate. Please try again.', 'vira-store')
            );
        }
        
        // Send notification email to admin
        $this->send_affiliate_registration_notification($user_id, $affiliate_code);
        
        $message = $auto_approve ? 
            __('Your affiliate application has been approved! You can now start earning commissions.', 'vira-store') :
            __('Your affiliate application has been submitted and is pending approval.', 'vira-store');
        
        return array(
            'success' => true,
            'message' => $message,
            'affiliate_code' => $affiliate_code,
            'status' => $status
        );
    }
    
    /**
     * Generate unique affiliate code
     *
     * @param int $user_id
     * @return string
     */
    private function generate_affiliate_code($user_id) {
        global $wpdb;
        
        $user = get_user_by('id', $user_id);
        if (!$user || empty($user->user_login)) {
            // Fallback if user not found
            $user = get_userdata($user_id);
            if (!$user) {
                error_log('ViraStore: Cannot generate affiliate code - user not found: ' . $user_id);
                return 'AFF' . strtoupper(wp_generate_password(8, false));
            }
        }
        
        // Generate base code from username (first 6 chars) + user ID
        $username_prefix = substr($user->user_login, 0, 6);
        $username_prefix = preg_replace('/[^A-Za-z0-9]/', '', $username_prefix); // Remove special chars
        if (empty($username_prefix)) {
            $username_prefix = 'USER';
        }
        
        $base_code = strtoupper($username_prefix . $user_id);
        
        // Ensure code is within valid length (3-50 chars)
        if (strlen($base_code) > 50) {
            $base_code = substr($base_code, 0, 47) . '...';
        }
        
        $affiliate_code = $base_code;
        $counter = 1;
        $max_attempts = 100; // Prevent infinite loop
        
        // Ensure uniqueness
        while ($wpdb->get_var($wpdb->prepare("SELECT id FROM {$this->affiliates_table} WHERE affiliate_code = %s", $affiliate_code)) && $counter <= $max_attempts) {
            $suffix = (string)$counter;
            // Keep total length under 50 chars
            if (strlen($base_code . $suffix) > 50) {
                $base_code = substr($base_code, 0, 50 - strlen($suffix));
            }
            $affiliate_code = $base_code . $suffix;
            $counter++;
        }
        
        // If still not unique after max attempts, append random string
        if ($counter > $max_attempts) {
            $random_suffix = strtoupper(wp_generate_password(6, false));
            $affiliate_code = substr($base_code, 0, min(44, strlen($base_code))) . $random_suffix;
            // Final check to ensure we're within 50 char limit
            if (strlen($affiliate_code) > 50) {
                $affiliate_code = substr($affiliate_code, 0, 50);
            }
        }
        
        return $affiliate_code;
    }
    
    /**
     * Check if user is an affiliate
     *
     * @param int $user_id
     * @return bool
     */
    public function is_affiliate($user_id) {
        global $wpdb;
        
        $affiliate = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->affiliates_table} WHERE user_id = %d",
            $user_id
        ));
        
        return !empty($affiliate);
    }

    /**
     * Check if a user has at least one completed purchase.
     *
     * @param int $user_id
     * @param array|int|null $specific_product_ids Optional product/course ID(s) to check against. If null, any purchase qualifies.
     * @return bool
     */
    public function user_has_completed_purchase($user_id, $specific_product_ids = null) {
        $user = get_user_by('id', $user_id);
        if (!$user || empty($user->user_email)) {
            return false;
        }
        
        global $wpdb;
        $orders_table = $wpdb->prefix . 'vrstore_orders';
        
        // Ensure table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '{$orders_table}'") !== $orders_table) {
            return false;
        }
        
        // Build where conditions
        $where = "customer_email = %s AND LOWER(payment_status) = 'completed' AND LOWER(order_status) = 'completed'";
        $params = array($user->user_email);
        
        if (!is_null($specific_product_ids)) {
            if (!is_array($specific_product_ids)) {
                $specific_product_ids = array($specific_product_ids);
            }
            
            if (!empty($specific_product_ids)) {
                // Convert all to strings for consistent comparison
                $product_ids = array_map('strval', $specific_product_ids);
                $placeholders = implode(',', array_fill(0, count($product_ids), '%s'));
                $where .= " AND product_id IN ($placeholders)";
                $params = array_merge($params, $product_ids);
            }
        }
        
        $sql = $wpdb->prepare("SELECT COUNT(*) FROM {$orders_table} WHERE {$where}", ...$params);
        $count = intval($wpdb->get_var($sql));
        
        return $count > 0;
    }

    /**
     * Determine if a user is eligible to register as an affiliate based on settings.
     *
     * @param int $user_id
     * @return bool
     */
    public function is_user_eligible_for_affiliate($user_id) {
        $registration_enabled = get_option('vrstore_affiliate_enable_registration', '1') === '1';
        if (!$registration_enabled) {
            return apply_filters('vrstore_affiliate_user_eligible', false, $user_id, array());
        }
        
        $requirement = get_option('vrstore_affiliate_join_requirement', 'free');
        if ($requirement === 'purchase_required') {
            // Check if specific products are required
            $required_products = get_option('vrstore_affiliate_required_products', array());
            if (!is_array($required_products)) {
                $required_products = array();
            }
            
            // If specific products are required, check those. Otherwise check any purchase.
            $required_product_ids = !empty($required_products) ? $required_products : null;
            $eligible = $this->user_has_completed_purchase($user_id, $required_product_ids);
            return apply_filters('vrstore_affiliate_user_eligible', $eligible, $user_id, array());
        }
        
        return apply_filters('vrstore_affiliate_user_eligible', true, $user_id, array());
    }
    
    /**
     * Get affiliate by user ID
     *
     * @param int $user_id
     * @return object|null
     */
    public function get_affiliate_by_user_id($user_id) {
        global $wpdb;
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->affiliates_table} WHERE user_id = %d",
            $user_id
        ));
    }
    
    /**
     * Get affiliate by code
     *
     * @param string $affiliate_code
     * @return object|null
     */
    public function get_affiliate_by_code($affiliate_code) {
        global $wpdb;
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->affiliates_table} WHERE affiliate_code = %s AND status = 'active'",
            $affiliate_code
        ));
    }
    
    /**
     * Track affiliate visit
     */
    public function track_affiliate_visit() {
        if (!isset($_GET['ref']) || empty($_GET['ref'])) {
            return;
        }
        
        $affiliate_code = sanitize_text_field($_GET['ref']);
        $affiliate = $this->get_affiliate_by_code($affiliate_code);
        
        if (!$affiliate) {
            return;
        }
        
        // Store affiliate code in session/cookie for later conversion tracking
        // Use WordPress transients API instead of sessions for better compatibility
        if (function_exists('wp_get_session_token')) {
            // Use WordPress session if available
            if (!session_id()) {
                @session_start();
            }
            if (session_id()) {
                $_SESSION['vrstore_affiliate_code'] = $affiliate_code;
            }
        }
        
        // Set secure cookie for 30 days with proper flags
        $cookie_expiry = time() + (30 * 24 * 60 * 60);
        $is_https = is_ssl();
        $cookie_options = array(
            'expires' => $cookie_expiry,
            'path' => '/',
            'domain' => '',
            'secure' => $is_https, // Only send over HTTPS if site is HTTPS
            'httponly' => true, // Prevent JavaScript access (XSS protection)
            'samesite' => 'Lax' // CSRF protection
        );
        
        // PHP 7.3+ supports array format for setcookie
        if (PHP_VERSION_ID >= 70300) {
            setcookie('vrstore_affiliate_code', sanitize_text_field($affiliate_code), $cookie_options);
        } else {
            // Fallback for older PHP versions
            setcookie(
                'vrstore_affiliate_code',
                sanitize_text_field($affiliate_code),
                $cookie_expiry,
                '/',
                '',
                $is_https,
                true // httponly
            );
        }
        
        // Track the visit
        global $wpdb;
        
        $visitor_ip = $this->get_visitor_ip();
        $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field($_SERVER['HTTP_USER_AGENT']) : '';
        $referrer = isset($_SERVER['HTTP_REFERER']) ? esc_url_raw($_SERVER['HTTP_REFERER']) : '';
        $landing_page = esc_url_raw($_SERVER['REQUEST_URI']);
        
        // Determine the source of the visit (regular, short URL, or API-based short URL)
        $visit_source = 'regular';
        $short_url_provider = '';
        
        // Check if this is a short URL visit
        $use_short_urls = get_option('vrstore_affiliate_use_short_urls', '0');
        if ($use_short_urls) {
            $short_url_provider = get_option('vrstore_affiliate_short_url_provider', 'dns');
            
            // Detect visit source based on referrer or URL structure (case-insensitive)
            if (!empty($referrer)) {
                $referrer_lower = strtolower($referrer);
                
                if (strpos($referrer_lower, 'bit.ly') !== false || strpos($referrer_lower, 'bitly.com') !== false) {
                    $visit_source = 'bitly';
                    $short_url_provider = 'bitly';
                } elseif (strpos($referrer_lower, 'rebrand.ly') !== false || strpos($referrer_lower, 'rebrandly.com') !== false) {
                    $visit_source = 'rebrandly';
                    $short_url_provider = 'rebrandly';
                } else {
                    // Check for custom DNS domain
                    $short_domain = get_option('vrstore_affiliate_short_domain', '');
                    if (!empty($short_domain)) {
                        $short_domain_clean = strtolower(preg_replace('#^https?://#', '', $short_domain));
                        $current_host = strtolower($_SERVER['HTTP_HOST'] ?? '');
                        
                        if ($current_host === $short_domain_clean || strpos($referrer_lower, $short_domain_clean) !== false) {
                            $visit_source = 'dns_short';
                            $short_url_provider = 'dns';
                        }
                    }
                }
            }
        }
        
        // Check if this IP has visited recently (within 24 hours) to avoid duplicate tracking
        // Also check if visit is from same session/user agent to reduce spam
        $recent_visit = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$this->affiliate_visits_table} 
             WHERE affiliate_id = %d AND visitor_ip = %s 
             AND created_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)
             LIMIT 1",
            $affiliate->id,
            $visitor_ip
        ));
        
        if (!$recent_visit) {
            // Limit user agent length to prevent database issues
            $user_agent = strlen($user_agent) > 500 ? substr($user_agent, 0, 500) : $user_agent;
            
            // Limit referrer and landing page length
            $referrer = strlen($referrer) > 1000 ? substr($referrer, 0, 1000) : $referrer;
            $landing_page = strlen($landing_page) > 1000 ? substr($landing_page, 0, 1000) : $landing_page;
            
            $insert_result = $wpdb->insert(
                $this->affiliate_visits_table,
                array(
                    'affiliate_id' => $affiliate->id,
                    'visitor_ip' => $visitor_ip,
                    'user_agent' => $user_agent,
                    'referrer_url' => $referrer,
                    'landing_page' => $landing_page,
                    'visit_source' => $visit_source,
                    'short_url_provider' => $short_url_provider
                ),
                array('%d', '%s', '%s', '%s', '%s', '%s', '%s')
            );
            
            // Only update total if insert was successful
            if ($insert_result !== false) {
                $wpdb->query($wpdb->prepare(
                    "UPDATE {$this->affiliates_table} SET total_visits = total_visits + 1 WHERE id = %d",
                    $affiliate->id
                ));
            }
        }
    }
    
    /**
     * Process affiliate commission when order is completed
     *
     * @param int $order_id
     * @param array $order_data
     */
    public function process_affiliate_commission($order_id, $order_data) {
        // Get affiliate code from session or cookie (sanitize and validate)
        $affiliate_code = null;
        
        // Try session first
        if (function_exists('wp_get_session_token')) {
            if (!session_id()) {
                @session_start();
            }
            if (session_id() && isset($_SESSION['vrstore_affiliate_code'])) {
                $affiliate_code = sanitize_text_field($_SESSION['vrstore_affiliate_code']);
            }
        }
        
        // Fallback to cookie
        if (!$affiliate_code && isset($_COOKIE['vrstore_affiliate_code'])) {
            $affiliate_code = sanitize_text_field($_COOKIE['vrstore_affiliate_code']);
        }
        
        if (!$affiliate_code || strlen($affiliate_code) < 3 || strlen($affiliate_code) > 50) {
            return;
        }
        
        // Validate affiliate code format (alphanumeric and underscores only)
        if (!preg_match('/^[A-Za-z0-9_]+$/', $affiliate_code)) {
            error_log('ViraStore: Invalid affiliate code format detected: ' . substr($affiliate_code, 0, 10));
            return;
        }
        
        $affiliate = $this->get_affiliate_by_code($affiliate_code);
        if (!$affiliate || $affiliate->status !== 'active') {
            return;
        }
        
        global $wpdb;
        
        // Get order total and currency (sanitize and validate)
        $order_total = isset($order_data['total']) ? floatval($order_data['total']) : 0;
        $order_currency = isset($order_data['currency']) ? sanitize_text_field($order_data['currency']) : null;
        
        // Validate order total
        if ($order_total <= 0 || $order_total > 99999999.99) {
            error_log('ViraStore: Invalid order total for commission processing: ' . $order_total);
            return;
        }
        
        // Validate order currency format
        if (!empty($order_currency) && strlen($order_currency) !== 3) {
            error_log('ViraStore: Invalid currency code for order ' . $order_id . ': ' . $order_currency);
            $order_currency = null; // Use base currency if invalid
        }
        
        // Convert order total to base currency for consistent commission storage
        $base_order_total = $order_total;
        if (class_exists('VRSTORE_Currency_Converter') && !empty($order_currency)) {
            $currency_converter = VRSTORE_Currency_Converter::get_instance();
            $settings = VRSTORE_Settings::get_instance();
            $base_currency = $settings->get_setting('currency', 'USD');
            
            if ($order_currency !== $base_currency) {
                // Convert from order currency to base currency for admin reporting consistency
                $converted_amount = $currency_converter->convert_amount($order_total, $order_currency, $base_currency);
                
                // Validate converted amount
                if ($converted_amount > 0 && $converted_amount < 99999999.99) {
                    $base_order_total = $converted_amount;
                } else {
                    error_log('ViraStore: Invalid currency conversion result for order ' . $order_id);
                    // Continue with original amount if conversion fails
                }
            }
        }
        
        // Final validation of base order total
        if ($base_order_total <= 0 || $base_order_total > 99999999.99) {
            error_log('ViraStore: Invalid base order total after conversion: ' . $base_order_total);
            return;
        }
        
        // Calculate commission based on base currency amount
        $commission_rate = floatval($affiliate->commission_rate);
        
        // Validate commission rate (0-100%)
        if ($commission_rate < 0 || $commission_rate > 100) {
            error_log('ViraStore: Invalid commission rate for affiliate ' . $affiliate->id . ': ' . $commission_rate);
            $commission_rate = max(0, min(100, $commission_rate)); // Clamp to valid range
        }
        
        // Calculate commission amount
        $commission_amount = ($base_order_total * $commission_rate) / 100;
        
        // Validate commission amount (must be positive and reasonable)
        if ($commission_amount < 0) {
            error_log('ViraStore: Negative commission calculated for order ' . $order_id);
            return; // Don't process negative commissions
        }
        
        // Check for unreasonably large commissions (possible calculation error)
        if ($commission_amount > $base_order_total) {
            error_log('ViraStore: Commission exceeds order total for order ' . $order_id . '. Commission: ' . $commission_amount . ', Order Total: ' . $base_order_total);
            return; // Don't process invalid commissions
        }
        
        // Round to 2 decimal places for consistency
        $commission_amount = round($commission_amount, 2);
        
        // Prevent duplicate commission processing for same order
        $existing_commission = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$this->affiliate_commissions_table} 
             WHERE affiliate_id = %d AND order_id = %d LIMIT 1",
            $affiliate->id,
            $order_id
        ));
        
        if ($existing_commission) {
            error_log('ViraStore: Commission already exists for order ' . $order_id . ' and affiliate ' . $affiliate->id);
            return; // Commission already processed
        }
        
        // Find the visit that led to this conversion (within last 30 days)
        $visitor_ip = $this->get_visitor_ip();
        $visit = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->affiliate_visits_table} 
             WHERE affiliate_id = %d AND visitor_ip = %s AND converted = 0 
             AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
             ORDER BY created_at DESC LIMIT 1",
            $affiliate->id,
            $visitor_ip
        ));
        
        // Use database transaction for atomicity (prevents race conditions)
        $wpdb->query('START TRANSACTION');
        
        try {
            // Create commission record (store amounts in base currency for consistency)
            $insert_result = $wpdb->insert(
                $this->affiliate_commissions_table,
                array(
                    'affiliate_id' => $affiliate->id,
                    'order_id' => $order_id,
                    'visit_id' => $visit ? $visit->id : null,
                    'commission_amount' => $commission_amount,
                    'commission_rate' => $commission_rate,
                    'order_total' => $base_order_total, // Store converted amount for consistency
                    'status' => 'pending'
                ),
                array('%d', '%d', '%d', '%f', '%f', '%f', '%s')
            );
            
            if ($insert_result === false) {
                throw new Exception('Failed to insert commission record');
            }
            
            // Mark visit as converted (prevent double-conversion)
            if ($visit) {
                $update_result = $wpdb->update(
                    $this->affiliate_visits_table,
                    array('converted' => 1, 'order_id' => $order_id),
                    array('id' => $visit->id),
                    array('%d', '%d'),
                    array('%d')
                );
                
                if ($update_result === false) {
                    throw new Exception('Failed to update visit record');
                }
            }
            
            // Update affiliate totals atomically
            $update_affiliate_result = $wpdb->query($wpdb->prepare(
                "UPDATE {$this->affiliates_table} 
                 SET total_conversions = total_conversions + 1,
                     total_commissions = total_commissions + %f,
                     unpaid_commissions = unpaid_commissions + %f
                 WHERE id = %d",
                $commission_amount,
                $commission_amount,
                $affiliate->id
            ));
            
            if ($update_affiliate_result === false) {
                throw new Exception('Failed to update affiliate totals');
            }
            
            // Commit transaction
            $wpdb->query('COMMIT');
            
        } catch (Exception $e) {
            // Rollback on any error
            $wpdb->query('ROLLBACK');
            error_log('ViraStore: Commission processing failed: ' . $e->getMessage());
            return; // Exit silently to prevent breaking order processing
        }
        
        // Clear affiliate tracking (prevent reuse to avoid double commissions)
        if (session_id() && isset($_SESSION['vrstore_affiliate_code'])) {
            unset($_SESSION['vrstore_affiliate_code']);
        }
        
        // Clear cookie securely
        if (PHP_VERSION_ID >= 70300) {
            setcookie('vrstore_affiliate_code', '', array(
                'expires' => time() - 3600,
                'path' => '/',
                'secure' => is_ssl(),
                'httponly' => true,
                'samesite' => 'Lax'
            ));
        } else {
            setcookie('vrstore_affiliate_code', '', time() - 3600, '/', '', is_ssl(), true);
        }
    }
    
    /**
     * Get visitor IP address
     *
     * @return string
     */
    private function get_visitor_ip() {
        $ip_keys = array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR');
        
        foreach ($ip_keys as $key) {
            if (array_key_exists($key, $_SERVER) === true) {
                foreach (explode(',', $_SERVER[$key]) as $ip) {
                    $ip = trim($ip);
                    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                        return $ip;
                    }
                }
            }
        }
        
        return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
    }
    
    /**
     * Get affiliate statistics
     *
     * @param int $affiliate_id
     * @param string $period
     * @return array
     */
    public function get_affiliate_statistics($affiliate_id, $period = '30days') {
        global $wpdb;
        
        $date_condition = '';
        switch ($period) {
            case '7days':
                $date_condition = "AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
                break;
            case '30days':
                $date_condition = "AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
                break;
            case '90days':
                $date_condition = "AND created_at >= DATE_SUB(NOW(), INTERVAL 90 DAY)";
                break;
            case 'year':
                $date_condition = "AND created_at >= DATE_SUB(NOW(), INTERVAL 1 YEAR)";
                break;
        }
        
        // Get visit statistics
        $visits = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$this->affiliate_visits_table} WHERE affiliate_id = %d $date_condition",
            $affiliate_id
        ));
        
        $conversions = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$this->affiliate_visits_table} WHERE affiliate_id = %d AND converted = 1 $date_condition",
            $affiliate_id
        ));
        
        // Get commission statistics
        $commissions = $wpdb->get_results($wpdb->prepare(
            "SELECT 
                COUNT(*) as total_orders,
                SUM(commission_amount) as total_commissions,
                SUM(CASE WHEN status = 'pending' THEN commission_amount ELSE 0 END) as pending_commissions,
                SUM(CASE WHEN status = 'approved' THEN commission_amount ELSE 0 END) as approved_commissions,
                SUM(CASE WHEN status = 'paid' THEN commission_amount ELSE 0 END) as paid_commissions
             FROM {$this->affiliate_commissions_table} 
             WHERE affiliate_id = %d $date_condition",
            $affiliate_id
        ));
        
        $commission_data = $commissions[0] ?? (object) array(
            'total_orders' => 0,
            'total_commissions' => 0,
            'pending_commissions' => 0,
            'approved_commissions' => 0,
            'paid_commissions' => 0
        );
        
        $conversion_rate = $visits > 0 ? ($conversions / $visits) * 100 : 0;
        
        return array(
            'visits' => intval($visits),
            'conversions' => intval($conversions),
            'conversion_rate' => round($conversion_rate, 2),
            'total_orders' => intval($commission_data->total_orders),
            'total_commissions' => floatval($commission_data->total_commissions),
            'pending_commissions' => floatval($commission_data->pending_commissions),
            'approved_commissions' => floatval($commission_data->approved_commissions),
            'paid_commissions' => floatval($commission_data->paid_commissions)
        );
    }
    
    /**
     * Handle affiliate registration AJAX
     */
    public function handle_affiliate_registration() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'vrstore_affiliate_nonce')) {
            wp_send_json_error(__('Security check failed.', 'vira-store'));
            return;
        }
        
        $user_id = get_current_user_id();
        if (!$user_id) {
            wp_send_json_error(__('You must be logged in to register as an affiliate.', 'vira-store'));
            return;
        }
        
        // Enforce affiliate registration settings and eligibility
        $registration_enabled = get_option('vrstore_affiliate_enable_registration', '1') === '1';
        if (!$registration_enabled) {
            wp_send_json_error(__('Affiliate registration is currently closed.', 'vira-store'));
            return;
        }
        
        $requirement = get_option('vrstore_affiliate_join_requirement', 'free');
        if ($requirement === 'purchase_required') {
            // Check if specific products are required
            $required_products = get_option('vrstore_affiliate_required_products', array());
            if (!is_array($required_products)) {
                $required_products = array();
            }
            
            // If specific products are required, check those. Otherwise check any purchase.
            $required_product_ids = !empty($required_products) ? $required_products : null;
            
            if (!$this->user_has_completed_purchase($user_id, $required_product_ids)) {
                if (!empty($required_products)) {
                    // Get product/course titles for a more specific error message
                    $product_titles = array();
                    foreach ($required_products as $product_id) {
                        $post = get_post($product_id);
                        if ($post) {
                            $product_titles[] = $post->post_title;
                        }
                    }
                    
                    if (!empty($product_titles)) {
                        $message = sprintf(
                            __('Affiliate registration requires purchase of one of these items: %s. Please complete a qualifying purchase first.', 'vira-store'),
                            implode(', ', $product_titles)
                        );
                    } else {
                        $message = __('Affiliate registration requires a specific purchase. Please complete a qualifying purchase first.', 'vira-store');
                    }
                } else {
                    $message = __('Affiliate registration requires at least one completed purchase. Please complete a purchase first.', 'vira-store');
                }
                
                wp_send_json_error($message);
                return;
            }
        }
        
        // Sanitize and collect additional data
        $additional_data = array(
            'affiliate_name' => sanitize_text_field($_POST['affiliate_name'] ?? ''),
            'affiliate_email' => sanitize_email($_POST['affiliate_email'] ?? ''),
            'website_url' => esc_url_raw($_POST['website_url'] ?? ''),
            'promotion_methods' => sanitize_textarea_field($_POST['promotion_methods'] ?? ''),
            'payment_method' => sanitize_text_field($_POST['payment_method'] ?? 'paypal'),
            'payment_details' => sanitize_textarea_field($_POST['payment_details'] ?? ''),
            'agree_terms' => isset($_POST['agree_terms']) ? 1 : 0
        );
        
        // Validate required fields
        if (empty($additional_data['affiliate_name']) || empty($additional_data['affiliate_email'])) {
            wp_send_json_error(__('Name and email are required fields.', 'vira-store'));
            return;
        }
        
        if (!$additional_data['agree_terms']) {
            wp_send_json_error(__('You must agree to the terms and conditions.', 'vira-store'));
            return;
        }
        
        $result = $this->register_affiliate($user_id, $additional_data);
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result['message']);
        }
    }
    
    /**
     * Get affiliate stats AJAX
     */
    public function get_affiliate_stats() {
        $user_id = get_current_user_id();
        if (!$user_id) {
            wp_send_json_error(__('Access denied.', 'vira-store'));
        }
        
        $affiliate = $this->get_affiliate_by_user_id($user_id);
        if (!$affiliate) {
            wp_send_json_error(__('You are not registered as an affiliate.', 'vira-store'));
        }
        
        $period = isset($_POST['period']) ? sanitize_text_field($_POST['period']) : '30days';
        $stats = $this->get_affiliate_statistics($affiliate->id, $period);
        
        wp_send_json_success($stats);
    }
    
    /**
     * Send affiliate registration notification
     *
     * @param int $user_id
     * @param string $affiliate_code
     */
    private function send_affiliate_registration_notification($user_id, $affiliate_code) {
        $user = get_user_by('id', $user_id);
        $admin_email = get_option('admin_email');
        
        $subject = sprintf(__('[%s] New Affiliate Registration', 'vira-store'), get_bloginfo('name'));
        $message = sprintf(
            __("A new affiliate has registered:\n\nUser: %s (%s)\nAffiliate Code: %s\n\nPlease review and approve this application in the admin panel.", 'vira-store'),
            $user->display_name,
            $user->user_email,
            $affiliate_code
        );
        
        wp_mail($admin_email, $subject, $message);
    }
    
    /**
     * Get URL based on link type
     *
     * @param string $link_type
     * @return string
     */
    private function get_link_type_url($link_type) {
        switch ($link_type) {
            case 'shop':
                $url = function_exists('wc_get_page_permalink') ? wc_get_page_permalink('shop') : home_url('/shop/');
                break;
            case 'products':
                // Try to get the products page from settings, fallback to /products/
                $products_page_id = get_option('vrstore_products_page');
                $url = $products_page_id ? get_permalink($products_page_id) : home_url('/products/');
                break;
            case 'blog':
                $url = get_permalink(get_option('page_for_posts')) ?: home_url('/blog/');
                break;
            case 'contact':
                $url = home_url('/contact/');
                break;
            case 'home':
            default:
                $url = home_url();
                break;
        }
        
        // Ensure we always return a valid URL
        if (empty($url) || !filter_var($url, FILTER_VALIDATE_URL)) {
            error_log('Warning: Invalid URL generated for link type ' . $link_type . ': ' . $url);
            $url = home_url(); // Fallback to home URL
        }
        
        return $url;
    }

    /**
     * Generate affiliate link
     *
     * @param string $affiliate_code
     * @param string $url
     * @param bool $use_short_url
     * @return string
     */
    public function generate_affiliate_link($affiliate_code, $use_short_url = false, $link_type = 'home') {
        // Get the base URL based on link type
        $url = $this->get_link_type_url($link_type);
        
        if ($use_short_url) {
            return $this->generate_short_affiliate_link($affiliate_code, $url);
        }
        
        $separator = strpos($url, '?') !== false ? '&' : '?';
        return $url . $separator . 'ref=' . urlencode($affiliate_code);
    }
    
    /**
     * Generate short affiliate link
     *
     * @param string $affiliate_code
     * @param string $url
     * @return string
     */
    public function generate_short_affiliate_link($affiliate_code, $url = '') {
        // Get short URL settings
        $use_short_urls = get_option('vrstore_affiliate_use_short_urls', '0');
        $short_url_provider = get_option('vrstore_affiliate_short_url_provider', 'dns');
        
        // Ensure we have a valid base URL
        $target_url = !empty($url) ? $url : home_url();
        if (!filter_var($target_url, FILTER_VALIDATE_URL)) {
            error_log('Warning: Invalid target URL for affiliate link: ' . $target_url);
            $target_url = home_url();
        }
        
        if (!$use_short_urls) {
            // Fallback to regular link if short URLs not enabled
            $separator = strpos($target_url, '?') !== false ? '&' : '?';
            return $target_url . $separator . 'ref=' . urlencode($affiliate_code);
        }
        
        // Generate the affiliate URL with parameter
        $separator = strpos($target_url, '?') !== false ? '&' : '?';
        $affiliate_url = $target_url . $separator . 'ref=' . urlencode($affiliate_code);
        
        // Validate the final affiliate URL
        if (!filter_var($affiliate_url, FILTER_VALIDATE_URL)) {
            error_log('Warning: Invalid affiliate URL generated: ' . $affiliate_url);
            $affiliate_url = home_url('/?ref=' . urlencode($affiliate_code));
        }
        
        // Generate short URL based on provider
        switch ($short_url_provider) {
            case 'bitly':
                return $this->generate_bitly_short_url($affiliate_url, $affiliate_code);
                
            case 'rebrandly':
                return $this->generate_rebrandly_short_url($affiliate_url, $affiliate_code);
                
            case 'dns':
            default:
                return $this->generate_dns_short_url($affiliate_code);
        }
    }
    
    /**
     * Generate DNS-based short URL
     *
     * @param string $affiliate_code
     * @return string
     */
    private function generate_dns_short_url($affiliate_code) {
        $short_domain = get_option('vrstore_affiliate_short_domain', '');
        
        if (empty($short_domain)) {
            // Fallback to regular link if DNS short domain not configured
            $separator = strpos(home_url(), '?') !== false ? '&' : '?';
            return home_url() . $separator . 'ref=' . urlencode($affiliate_code);
        }
        
        // Clean domain (remove protocol if present)
        $short_domain = preg_replace('#^https?://#', '', $short_domain);
        
        // Generate short URL format: https://domain.to/affiliatecode
        return 'https://' . $short_domain . '/' . strtolower($affiliate_code);
    }
    
    /**
     * Generate Bitly short URL
     *
     * @param string $long_url
     * @param string $affiliate_code
     * @return string
     */
    private function generate_bitly_short_url($long_url, $affiliate_code) {
        // Security: Don't log sensitive information or full URLs
        error_log('Bitly: Starting URL generation for affiliate: ' . substr($affiliate_code, 0, 10));
        
        $access_token = get_option('vrstore_affiliate_bitly_access_token', '');
        $custom_domain = get_option('vrstore_affiliate_bitly_domain', '');
        $group_guid = get_option('vrstore_affiliate_bitly_group_guid', '');
        
        if (empty($access_token)) {
            error_log('Bitly Error: Access token not configured');
            return $long_url;
        }
        
        // Security: Validate access token format (should be alphanumeric)
        if (!preg_match('/^[A-Za-z0-9_-]+$/', $access_token) || strlen($access_token) < 20) {
            error_log('Bitly Error: Invalid access token format');
            return $long_url;
        }
        
        if (empty($long_url) || !filter_var($long_url, FILTER_VALIDATE_URL)) {
            error_log('Bitly Error: Invalid long URL provided: ' . $long_url);
            $long_url = home_url('/?ref=' . urlencode($affiliate_code));
            error_log('Bitly: Using fallback URL: ' . $long_url);
        }
        
        if (!preg_match('/^https?:\/\//i', $long_url)) {
            $long_url = 'https://' . ltrim($long_url, '/');
            error_log('Bitly: Added https scheme to URL: ' . $long_url);
        }

        $cache_key = 'vrstore_bitly_' . md5($affiliate_code . $long_url);
        $cached_url = get_transient($cache_key);
        if ($cached_url !== false) {
            error_log('Bitly: Using cached URL for ' . $affiliate_code . ': ' . $cached_url);
            return $cached_url;
        }

        if ($this->is_local_or_private_host($long_url)) {
            error_log('Bitly Error: Cannot create short URL for local/development URL: ' . $long_url);
            error_log('Bitly: Returning original URL as Bitly requires publicly accessible URLs');
            set_transient($cache_key, $long_url, HOUR_IN_SECONDS);
            return $long_url;
        }

        if (empty($group_guid)) {
            $group_guid = $this->get_bitly_default_group($access_token);
            if (empty($group_guid)) {
                error_log('Bitly Error: No group GUID available');
                // Cache the failure for 5 minutes to avoid repeated API calls
                set_transient($cache_key, $long_url, 5 * MINUTE_IN_SECONDS);
                return $long_url;
            }
        }
        
        // Prepare API request
        $api_url = 'https://api-ssl.bitly.com/v4/shorten';
        $headers = array(
            'Authorization' => 'Bearer ' . $access_token,
            'Content-Type' => 'application/json'
        );
        
        // Final validation before API call
        if (!filter_var($long_url, FILTER_VALIDATE_URL)) {
            error_log('Bitly Error: Final URL validation failed: ' . $long_url);
            return $long_url;
        }
        
        $body = array(
            'long_url' => $long_url,
            'group_guid' => $group_guid,
            'title' => 'Affiliate Link - ' . $affiliate_code
        );
        
        // Add custom domain if specified, otherwise use default bit.ly
        if (!empty($custom_domain)) {
            $body['domain'] = $custom_domain;
        } else {
            $body['domain'] = 'bit.ly';
        }
        
        // Debug logging (only log essential info - NEVER log tokens or sensitive data)
        error_log('Bitly API Request for affiliate: ' . substr($affiliate_code, 0, 10) . ' - Using domain: ' . esc_html($body['domain']));
        // Don't log full URLs or request body to avoid exposing sensitive data
        
        // Make API request
        $response = wp_remote_post($api_url, array(
            'headers' => $headers,
            'body' => wp_json_encode($body),
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            error_log('Bitly API Error: ' . $response->get_error_message());
            // Cache the failure for 10 minutes to avoid repeated failures
            set_transient($cache_key, $long_url, 10 * MINUTE_IN_SECONDS);
            return $long_url;
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        
        if ($response_code !== 200 && $response_code !== 201) {
            $error_data = json_decode($response_body, true);
            $error_message = isset($error_data['message']) ? $error_data['message'] : 'Unknown error';
            $error_description = isset($error_data['description']) ? $error_data['description'] : '';
            
            error_log('Bitly API Error: HTTP ' . $response_code . ' - ' . $error_message . ' - ' . $error_description);
            error_log('Bitly API Response Body: ' . substr($response_body, 0, 500));
            
            // Cache the failure for 10 minutes to avoid repeated failures
            set_transient($cache_key, $long_url, 10 * MINUTE_IN_SECONDS);
            return $long_url;
        }
        
        $data = json_decode($response_body, true);
        
        if (isset($data['link'])) {
            $short_url = isset($data['link']) ? esc_url_raw($data['link']) : '';
            if (!filter_var($short_url, FILTER_VALIDATE_URL)) {
                error_log('Bitly Error: Invalid short URL received from API');
                set_transient($cache_key, $long_url, 10 * MINUTE_IN_SECONDS);
                return $long_url;
            }
            
            // Cache the successful result for 24 hours
            set_transient($cache_key, $short_url, 24 * HOUR_IN_SECONDS);
            error_log('Bitly Success: Generated short URL for affiliate');
            return $short_url;
        }
        
        error_log('Bitly API Error: Invalid response format - ' . substr($response_body, 0, 200));
        // Cache the failure for 10 minutes
        set_transient($cache_key, $long_url, 10 * MINUTE_IN_SECONDS);
        return $long_url;
    }
    
    /**
     * Get default Bitly group GUID
     *
     * @param string $access_token
     * @return string
     */
    private function get_bitly_default_group($access_token) {
        // Check if we have a cached group GUID
        $cached_guid = get_transient('vrstore_bitly_default_group');
        if ($cached_guid !== false) {
            return $cached_guid;
        }
        
        // Make API request to get groups
        $api_url = 'https://api-ssl.bitly.com/v4/groups';
        $headers = array(
            'Authorization' => 'Bearer ' . $access_token,
            'Content-Type' => 'application/json'
        );
        
        $response = wp_remote_get($api_url, array(
            'headers' => $headers,
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            error_log('Bitly Groups API Error: ' . $response->get_error_message());
            return '';
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        
        if ($response_code !== 200) {
            error_log('Bitly Groups API Error: HTTP ' . $response_code);
            // Don't log full response body (may contain sensitive info)
            return '';
        }
        
        $data = json_decode($response_body, true);
        
        if (isset($data['groups']) && !empty($data['groups'])) {
            $group_guid = $data['groups'][0]['guid'];
            // Cache the group GUID for 24 hours
            set_transient('vrstore_bitly_default_group', $group_guid, 24 * HOUR_IN_SECONDS);
            // Also save it as an option for manual configuration
            update_option('vrstore_affiliate_bitly_group_guid', $group_guid);
            error_log('Bitly: Retrieved default group GUID - ' . $group_guid);
            return $group_guid;
        }
        
        error_log('Bitly Groups API Error: No groups found in response - ' . $response_body);
        return '';
    }
    
    /**
     * Generate Rebrandly short URL
     *
     * @param string $long_url
     * @param string $affiliate_code
     * @return string
     */
    private function generate_rebrandly_short_url($long_url, $affiliate_code) {
        $api_key = get_option('vrstore_affiliate_rebrandly_api_key', '');
        $custom_domain = get_option('vrstore_affiliate_rebrandly_domain', '');
        
        if (empty($api_key)) {
            return $long_url;
        }
        
        // Security: Validate API key format
        if (!preg_match('/^[A-Za-z0-9_-]+$/', $api_key) || strlen($api_key) < 20) {
            error_log('Rebrandly Error: Invalid API key format');
            return $long_url;
        }

        if (empty($long_url) || !filter_var($long_url, FILTER_VALIDATE_URL)) {
            error_log('Rebrandly Error: Invalid long URL provided');
            $long_url = home_url('/?ref=' . urlencode($affiliate_code));
        }

        if (!preg_match('/^https?:\/\//i', $long_url)) {
            $long_url = 'https://' . ltrim($long_url, '/');
        }
        
        // Validate final URL
        if (!filter_var($long_url, FILTER_VALIDATE_URL)) {
            error_log('Rebrandly Error: Final URL validation failed');
            $long_url = home_url('/?ref=' . urlencode($affiliate_code));
        }

        $cache_key = 'vrstore_rebrandly_' . md5($affiliate_code . $long_url);
        $cached_url = get_transient($cache_key);
        if ($cached_url !== false) {
            return $cached_url;
        }

        if ($this->is_local_or_private_host($long_url)) {
            error_log('Rebrandly Error: Cannot create short URL for local/development URL');
            set_transient($cache_key, $long_url, HOUR_IN_SECONDS);
            return $long_url;
        }

        $api_url = 'https://api.rebrandly.com/v1/links';
        $headers = array(
            'apikey' => $api_key,
            'Content-Type' => 'application/json'
        );
        
        $body = array(
            'destination' => $long_url,
            'title' => 'Affiliate Link - ' . $affiliate_code
        );
        
        if (!empty($custom_domain)) {
            $body['domain'] = array('fullName' => $custom_domain);
        }
        
        $response = wp_remote_post($api_url, array(
            'headers' => $headers,
            'body' => wp_json_encode($body),
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            error_log('Rebrandly API Error: ' . $response->get_error_message());
            set_transient($cache_key, $long_url, 10 * MINUTE_IN_SECONDS);
            return $long_url;
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        
        if ($response_code !== 200 && $response_code !== 201) {
            error_log('Rebrandly API Error: HTTP ' . $response_code . ' - ' . $response_body);
            set_transient($cache_key, $long_url, 10 * MINUTE_IN_SECONDS);
            return $long_url;
        }
        
        $data = json_decode($response_body, true);
        
        if (isset($data['shortUrl'])) {
            $short = $data['shortUrl'];
            if (!is_string($short) || empty($short)) {
                error_log('Rebrandly Error: Invalid short URL in response');
                set_transient($cache_key, $long_url, 10 * MINUTE_IN_SECONDS);
                return $long_url;
            }
            
            $short_url = preg_match('/^https?:\/\//i', $short) ? $short : 'https://' . ltrim($short, '/');
            
            // Validate the short URL before caching
            if (!filter_var($short_url, FILTER_VALIDATE_URL)) {
                error_log('Rebrandly Error: Invalid short URL format received');
                set_transient($cache_key, $long_url, 10 * MINUTE_IN_SECONDS);
                return $long_url;
            }
            
            set_transient($cache_key, esc_url_raw($short_url), 24 * HOUR_IN_SECONDS);
            return esc_url_raw($short_url);
        }
        
        error_log('Rebrandly API Error: Invalid response format');
        set_transient($cache_key, $long_url, 10 * MINUTE_IN_SECONDS);
        return $long_url;
    }

    /**
     * Check if URL is local or private host (should not be shortened with external services)
     *
     * @param string $url
     * @return bool
     */
    private function is_local_or_private_host(string $url): bool {
        if (empty($url) || !is_string($url)) {
            return false;
        }
        
        $parts = parse_url($url);
        if (!$parts || !isset($parts['host'])) {
            return false;
        }
        
        $host = strtolower(trim($parts['host']));

        if (empty($host)) {
            return false;
        }

        // Check common localhost names
        if (in_array($host, ['localhost', '127.0.0.1', '::1', '0.0.0.0'], true)) {
            return true;
        }

        // Check for .local, .test, .invalid, .example TLDs
        if (strpos($host, '.local') !== false || preg_match('/\.(test|invalid|example|dev)$/i', $host)) {
            return true;
        }

        // Check for private IP ranges
        if (filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false) {
            // If validation fails, it means it's a private/reserved IP
            if (filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                return true;
            }
        }
        
        // Check for private IPv4 ranges manually (more thorough)
        if (filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            // Private ranges: 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16, 169.254.0.0/16
            if (preg_match('/^(10\.|192\.168\.|169\.254\.|172\.(1[6-9]|2[0-9]|3[0-1])\.)/', $host)) {
                return true;
            }
        }

        return false;
    }
    
    /**
     * Handle short URL redirect
     */
    public function handle_short_url_redirect() {
        // Check if this is a short URL request
        $short_domain = get_option('vrstore_affiliate_short_domain', '');
        $use_short_urls = get_option('vrstore_affiliate_use_short_urls', '0');
        
        if (!$use_short_urls || empty($short_domain)) {
            return;
        }
        
        $current_domain = isset($_SERVER['HTTP_HOST']) ? sanitize_text_field($_SERVER['HTTP_HOST']) : '';
        if (empty($current_domain)) {
            return;
        }
        
        $short_domain_clean = preg_replace('#^https?://#', '', $short_domain);
        $short_domain_clean = strtolower(trim($short_domain_clean));
        
        // Check if current request is to the short domain (case-insensitive)
        if (strtolower($current_domain) === $short_domain_clean) {
            $request_uri = isset($_SERVER['REQUEST_URI']) ? trim($_SERVER['REQUEST_URI'], '/') : '';
            
            // Extract affiliate code from URL path (first segment before / or ?)
            $path_segments = explode('/', $request_uri);
            $affiliate_code = !empty($path_segments[0]) ? trim($path_segments[0]) : '';
            
            // Remove query string if present
            $affiliate_code = strtok($affiliate_code, '?');
            
            if (!empty($affiliate_code) && strlen($affiliate_code) >= 3 && strlen($affiliate_code) <= 50) {
                // Sanitize and validate affiliate code format
                $affiliate_code = strtoupper(sanitize_text_field($affiliate_code));
                
                // Validate format (alphanumeric and underscores only)
                if (preg_match('/^[A-Za-z0-9_]+$/', $affiliate_code)) {
                    // Verify affiliate code exists and is active
                    $affiliate = $this->get_affiliate_by_code($affiliate_code);
                    
                    if ($affiliate && $affiliate->status === 'active') {
                        // Build redirect URL with affiliate parameter
                        $redirect_url = home_url('/?ref=' . urlencode($affiliate_code));
                        
                        // Preserve any additional query parameters (sanitized)
                        if (!empty($_SERVER['QUERY_STRING'])) {
                            parse_str($_SERVER['QUERY_STRING'], $query_params);
                            // Remove ref parameter if it exists (we're adding it fresh)
                            unset($query_params['ref']);
                            if (!empty($query_params)) {
                                $redirect_url .= '&' . http_build_query($query_params);
                            }
                        }
                        
                        // Validate redirect URL to prevent open redirect
                        $redirect_url = esc_url_raw($redirect_url);
                        if (filter_var($redirect_url, FILTER_VALIDATE_URL)) {
                            wp_redirect($redirect_url, 301);
                            exit;
                        }
                    }
                }
            }
            
            // If no valid affiliate code, redirect to home page
            wp_redirect(home_url(), 302); // Use 302 for invalid codes (temporary redirect)
            exit;
        }
    }
    
    /**
     * Enqueue affiliate assets
     */
    public function enqueue_assets() {
        // Only enqueue on pages with affiliate shortcode or affiliate-related content
        if (is_singular() && (has_shortcode(get_post()->post_content, 'vrstore_affiliates') || 
            strpos(get_post()->post_content, 'vrstore-affiliate') !== false)) {
            
            // Enqueue dashicons for frontend (needed for affiliate statistics icons)
            wp_enqueue_style('dashicons');
            
            wp_enqueue_style(
                'vrstore-affiliate-css',
                plugin_dir_url(dirname(dirname(__FILE__))) . 'assets/css/affiliate.css',
                array('dashicons'),
                '1.0.2'
            );
            
            wp_enqueue_script(
                'vrstore-affiliate-js',
                plugin_dir_url(dirname(dirname(__FILE__))) . 'assets/js/affiliate.js',
                array('jquery'),
                '1.0.2',
                true
            );
            
            // Localize script for AJAX
            wp_localize_script('vrstore-affiliate-js', 'vrstore_affiliate_ajax', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('vrstore_affiliate_nonce')
            ));
        }
    }
    
    /**
     * Handle refresh stats AJAX request
     */
    public function handle_refresh_stats() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'vrstore_affiliate_nonce')) {
            wp_die(__('Security check failed.', 'vira-store'));
        }
        
        $user_id = get_current_user_id();
        if (!$user_id) {
            wp_send_json_error(array('message' => __('You must be logged in.', 'vira-store')));
        }
        
        $affiliate = $this->get_affiliate_by_user_id($user_id);
        if (!$affiliate) {
            wp_send_json_error(array('message' => __('You are not registered as an affiliate.', 'vira-store')));
        }
        
        $stats = $this->get_affiliate_statistics($affiliate->id);
        
        // Format earnings with currency conversion for frontend display
        if (class_exists('VRSTORE_Currency_Converter')) {
            $currency_converter = VRSTORE_Currency_Converter::get_instance();
            
            // Calculate total earnings
            $total_earnings = $stats['paid_commissions'] + $stats['approved_commissions'] + $stats['pending_commissions'];
            
            // Format earnings for user's preferred currency (frontend display)
            $stats['earnings'] = $currency_converter->format_price($total_earnings);
        } else {
            // Fallback without currency converter
            $total_earnings = $stats['paid_commissions'] + $stats['approved_commissions'] + $stats['pending_commissions'];
            $stats['earnings'] = '$' . number_format($total_earnings, 2);
        }
        
        wp_send_json_success(array(
            'message' => __('Statistics refreshed successfully!', 'vira-store'),
            'stats' => $stats
        ));
    }
    
    /**
     * Handle generate affiliate links AJAX request
     */
    public function handle_generate_affiliate_links() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'vrstore_affiliate_nonce')) {
            wp_die(__('Security check failed.', 'vira-store'));
        }
        
        $user_id = get_current_user_id();
        if (!$user_id) {
            wp_send_json_error(array('message' => __('You must be logged in.', 'vira-store')));
        }
        
        $affiliate = $this->get_affiliate_by_user_id($user_id);
        if (!$affiliate) {
            wp_send_json_error(array('message' => __('You are not registered as an affiliate.', 'vira-store')));
        }
        
        $link_type = sanitize_text_field($_POST['link_type'] ?? 'home');
        
        // Generate regular affiliate link
        $regular_link = $this->generate_affiliate_link($affiliate->affiliate_code, false, $link_type);
        
        // Generate short affiliate link if enabled
        $short_link = '';
        $provider = '';
        $use_short_urls = get_option('vrstore_affiliate_use_short_urls', false);
        
        if ($use_short_urls) {
            // First generate the target URL based on link type
            $target_url = $this->get_link_type_url($link_type);
            $short_link = $this->generate_short_affiliate_link($affiliate->affiliate_code, $target_url);
            $provider = get_option('vrstore_affiliate_short_url_provider', 'dns');
        }
        
        wp_send_json_success(array(
            'regular_link' => $regular_link,
            'short_link' => $short_link,
            'provider' => $provider,
            'message' => __('Affiliate links generated successfully!', 'vira-store')
        ));
    }
    
    /**
     * Handle get payment history AJAX request
     */
    public function handle_get_payment_history() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'vrstore_affiliate_nonce')) {
            wp_die(__('Security check failed.', 'vira-store'));
        }
        
        $user_id = get_current_user_id();
        if (!$user_id) {
            wp_send_json_error(array('message' => __('You must be logged in.', 'vira-store')));
        }
        
        $affiliate = $this->get_affiliate_by_user_id($user_id);
        if (!$affiliate) {
            wp_send_json_error(array('message' => __('You are not registered as an affiliate.', 'vira-store')));
        }
        
        $payments = $this->get_affiliate_payment_history($affiliate->id);
        
        wp_send_json_success(array(
            'message' => __('Payment history loaded successfully!', 'vira-store'),
            'payments' => $payments
        ));
    }
    
    /**
     * Get affiliate payment history
     *
     * @param int $affiliate_id
     * @return array
     */
    private function get_affiliate_payment_history($affiliate_id) {
        global $wpdb;
        
        // Check if withdrawals table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '{$this->affiliate_withdrawals_table}'") !== $this->affiliate_withdrawals_table) {
            return array();
        }
        
        // Get actual payment history from withdrawals table (paid withdrawals)
        $payments = $wpdb->get_results($wpdb->prepare(
            "SELECT 
                id,
                amount,
                payment_method,
                status,
                payment_details,
                processed_at,
                requested_at
             FROM {$this->affiliate_withdrawals_table} 
             WHERE affiliate_id = %d AND status = 'paid'
             ORDER BY processed_at DESC
             LIMIT 50",
            $affiliate_id
        ), ARRAY_A);
        
        // Format payments for frontend display
        $formatted_payments = array();
        foreach ($payments as $payment) {
            // Extract transaction reference from payment details if available
            $reference = 'N/A';
            if (!empty($payment['payment_details'])) {
                // Try to extract transaction ID/reference from payment details
                if (preg_match('/TXN[:\s]*([A-Z0-9]+)/i', $payment['payment_details'], $matches)) {
                    $reference = $matches[1];
                } elseif (preg_match('/([A-Z0-9]{6,20})/i', $payment['payment_details'], $matches)) {
                    $reference = substr($matches[1], 0, 20);
                }
            }
            
            $formatted_payments[] = array(
                'date' => !empty($payment['processed_at']) ? $payment['processed_at'] : $payment['requested_at'],
                'amount' => '$' . number_format(floatval($payment['amount']), 2),
                'method' => ucfirst($payment['payment_method'] ?: 'N/A'),
                'status' => $payment['status'],
                'reference' => esc_html($reference)
            );
        }
        
        return $formatted_payments;
    }

    /**
     * Handle withdrawal request AJAX
     */
    public function handle_request_withdrawal() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'vrstore_affiliate_nonce')) {
            wp_send_json_error(array('message' => __('Security check failed.', 'vira-store')));
        }
        
        $user_id = get_current_user_id();
        if (!$user_id) {
            wp_send_json_error(array('message' => __('You must be logged in.', 'vira-store')));
        }
        
        $affiliate = $this->get_affiliate_by_user_id($user_id);
        if (!$affiliate) {
            wp_send_json_error(array('message' => __('You are not registered as an affiliate.', 'vira-store')));
        }
        
        if ($affiliate->status !== 'approved') {
            wp_send_json_error(array('message' => __('Your affiliate account must be approved to request withdrawals.', 'vira-store')));
        }
        
        // Get and validate withdrawal amount
        $requested_amount = floatval($_POST['amount'] ?? 0);
        $affiliate_id = intval($_POST['affiliate_id'] ?? 0);
        
        if ($affiliate_id !== $affiliate->id) {
            wp_send_json_error(array('message' => __('Invalid affiliate ID.', 'vira-store')));
        }
        
        // Get affiliate settings for minimum payout
        $affiliate_settings = get_option('vrstore_affiliate_settings', array());
        $minimum_payout = floatval($affiliate_settings['minimum_payout_amount'] ?? 50.00);
        
        // Validate minimum amount
        if ($requested_amount < $minimum_payout) {
            wp_send_json_error(array(
                'message' => sprintf(__('Minimum withdrawal amount is $%.2f', 'vira-store'), $minimum_payout)
            ));
        }
        
        // Check if affiliate has sufficient unpaid commissions for withdrawal
        // Note: Use unpaid_commissions field, not total_commissions (which includes paid commissions)
        $unpaid_commissions = floatval($affiliate->unpaid_commissions ?? 0);
        
        // Validate withdrawal amount (must be positive)
        if ($requested_amount <= 0) {
            wp_send_json_error(array(
                'message' => __('Withdrawal amount must be greater than zero.', 'vira-store')
            ));
            return;
        }
        
        // Check for unreasonably large withdrawal requests
        if ($requested_amount > 999999.99) {
            wp_send_json_error(array(
                'message' => __('Withdrawal amount exceeds maximum limit.', 'vira-store')
            ));
            return;
        }
        
        if ($requested_amount > $unpaid_commissions) {
            wp_send_json_error(array(
                'message' => sprintf(
                    __('Insufficient unpaid commissions for this withdrawal. You have $%.2f available.', 'vira-store'),
                    $unpaid_commissions
                )
            ));
            return;
        }
        
        // Check for pending withdrawal requests
        if ($this->has_pending_withdrawal($affiliate->id)) {
            wp_send_json_error(array('message' => __('You already have a pending withdrawal request.', 'vira-store')));
        }
        
        // Create withdrawal request
        $withdrawal_id = $this->create_withdrawal_request($affiliate->id, $requested_amount);
        
        if ($withdrawal_id) {
            wp_send_json_success(array(
                'message' => sprintf(__('Withdrawal request for $%.2f has been submitted successfully!', 'vira-store'), $requested_amount),
                'withdrawal_id' => $withdrawal_id
            ));
        } else {
            wp_send_json_error(array('message' => __('Failed to create withdrawal request. Please try again.', 'vira-store')));
        }
    }

    /**
     * Check if affiliate has pending withdrawal
     */
    private function has_pending_withdrawal($affiliate_id) {
        global $wpdb;
        
        $pending_count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$this->affiliate_withdrawals_table} WHERE affiliate_id = %d AND status = 'pending'",
            $affiliate_id
        ));
        
        return $pending_count > 0;
    }

    /**
     * Create withdrawal request
     */
    private function create_withdrawal_request($affiliate_id, $amount) {
        global $wpdb;
        
        // Validate inputs
        $affiliate_id = absint($affiliate_id);
        $amount = floatval($amount);
        
        if ($affiliate_id <= 0 || $amount <= 0 || $amount > 999999.99) {
            error_log('ViraStore: Invalid withdrawal request parameters. Affiliate ID: ' . $affiliate_id . ', Amount: ' . $amount);
            return false;
        }
        
        // Check if table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '{$this->affiliate_withdrawals_table}'") !== $this->affiliate_withdrawals_table) {
            error_log('ViraStore: Withdrawals table does not exist');
            return false;
        }
        
        // Use transaction to ensure atomicity
        $wpdb->query('START TRANSACTION');
        
        try {
            $result = $wpdb->insert(
                $this->affiliate_withdrawals_table,
                array(
                    'affiliate_id' => $affiliate_id,
                    'amount' => $amount,
                    'status' => 'pending',
                    'requested_at' => current_time('mysql'),
                    'created_at' => current_time('mysql')
                ),
                array('%d', '%f', '%s', '%s', '%s')
            );
            
            if ($result === false) {
                throw new Exception('Failed to insert withdrawal request');
            }
            
            $withdrawal_id = $wpdb->insert_id;
            
            // Update affiliate unpaid_commissions (subtract requested amount)
            // This prevents double withdrawals - amount will be restored if withdrawal is cancelled
            $update_result = $wpdb->query($wpdb->prepare(
                "UPDATE {$this->affiliates_table} 
                 SET unpaid_commissions = GREATEST(0, unpaid_commissions - %f)
                 WHERE id = %d",
                $amount,
                $affiliate_id
            ));
            
            if ($update_result === false) {
                throw new Exception('Failed to update affiliate unpaid commissions');
            }
            
            $wpdb->query('COMMIT');
            return $withdrawal_id;
            
        } catch (Exception $e) {
            $wpdb->query('ROLLBACK');
            error_log('ViraStore: Withdrawal request creation failed: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Handle admin withdrawal processing AJAX request
     */
    public function handle_process_withdrawal() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_withdrawal_action')) {
            wp_send_json_error(__('Security check failed.', 'vira-store'));
        }
        
        // Check admin capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Insufficient permissions.', 'vira-store'));
        }
        
        $withdrawal_id = intval($_POST['withdrawal_id'] ?? 0);
        $affiliate_id = intval($_POST['affiliate_id'] ?? 0);
        $action = sanitize_text_field($_POST['withdrawal_action'] ?? '');
        $admin_notes = sanitize_textarea_field($_POST['admin_notes'] ?? '');
        $payment_details = sanitize_textarea_field($_POST['payment_details'] ?? '');
        
        if (!$withdrawal_id || !$affiliate_id || !$action) {
            wp_send_json_error(__('Missing required parameters.', 'vira-store'));
        }
        
        global $wpdb;
        
        // Get withdrawal details
        $withdrawal = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->affiliate_withdrawals_table} WHERE id = %d AND affiliate_id = %d",
            $withdrawal_id,
            $affiliate_id
        ));
        
        if (!$withdrawal) {
            wp_send_json_error(__('Withdrawal request not found.', 'vira-store'));
        }
        
        // Process based on action
        $update_data = array(
            'admin_notes' => $admin_notes,
            'processed_at' => current_time('mysql'),
            'updated_at' => current_time('mysql')
        );
        
        switch ($action) {
            case 'approve_withdrawal':
                if ($withdrawal->status !== 'pending') {
                    wp_send_json_error(__('Only pending withdrawals can be approved.', 'vira-store'));
                }
                $update_data['status'] = 'approved';
                break;
                
            case 'reject_withdrawal':
                if ($withdrawal->status !== 'pending') {
                    wp_send_json_error(__('Only pending withdrawals can be rejected.', 'vira-store'));
                }
                // Table enum only allows 'pending','approved','paid','cancelled', so use 'cancelled' for rejection
                $update_data['status'] = 'cancelled';
                break;
                
            case 'cancel_withdrawal':
                if ($withdrawal->status !== 'pending') {
                    wp_send_json_error(__('Only pending withdrawals can be cancelled.', 'vira-store'));
                }
                $update_data['status'] = 'cancelled';
                break;
                
            case 'mark_paid_withdrawal':
                if ($withdrawal->status !== 'approved') {
                    wp_send_json_error(__('Only approved withdrawals can be marked as paid.', 'vira-store'));
                }
                $update_data['status'] = 'paid';
                $update_data['payment_details'] = $payment_details;
                break;
                
            default:
                wp_send_json_error(__('Invalid action.', 'vira-store'));
        }
        
        // Use transaction to handle withdrawal status update and commission adjustments atomically
        $wpdb->query('START TRANSACTION');
        
        try {
            // Update withdrawal
            $result = $wpdb->update(
                $this->affiliate_withdrawals_table,
                $update_data,
                array('id' => $withdrawal_id),
                array('%s', '%s', '%s', '%s'),
                array('%d')
            );
            
            if ($result === false) {
                throw new Exception('Failed to update withdrawal status');
            }
            
            // Adjust unpaid_commissions based on status change
            $withdrawal_amount = floatval($withdrawal->amount);
            
            if ($update_data['status'] === 'paid') {
                // When paid, don't change unpaid_commissions (already deducted on request)
                // This is correct - the amount was already subtracted when request was created
            } elseif ($update_data['status'] === 'cancelled') {
                // If cancelled, restore the unpaid_commissions (add back the amount)
                $restore_result = $wpdb->query($wpdb->prepare(
                    "UPDATE {$this->affiliates_table} 
                     SET unpaid_commissions = unpaid_commissions + %f
                     WHERE id = %d",
                    $withdrawal_amount,
                    $affiliate_id
                ));
                
                if ($restore_result === false) {
                    throw new Exception('Failed to restore unpaid commissions');
                }
            }
            // For 'approved' status, keep unpaid_commissions as is (still deducted until paid)
            
            $wpdb->query('COMMIT');
            
            // Send notification email to affiliate
            $this->send_withdrawal_status_email($affiliate_id, $withdrawal, $update_data['status'], $admin_notes);
            
            wp_send_json_success(array(
                'message' => sprintf(__('Withdrawal request has been %s successfully.', 'vira-store'), $update_data['status'])
            ));
            
        } catch (Exception $e) {
            $wpdb->query('ROLLBACK');
            error_log('ViraStore: Withdrawal processing failed: ' . $e->getMessage());
            wp_send_json_error(__('Failed to update withdrawal status. Please try again.', 'vira-store'));
        }
    }

    /**
     * Get affiliate by ID
     *
     * @param int $affiliate_id
     * @return object|null
     */
    private function get_affiliate($affiliate_id) {
        global $wpdb;
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->affiliates_table} WHERE id = %d",
            $affiliate_id
        ));
    }
    
    /**
     * Send withdrawal status notification email
     */
    private function send_withdrawal_status_email($affiliate_id, $withdrawal, $new_status, $admin_notes = '') {
        $affiliate = $this->get_affiliate($affiliate_id);
        if (!$affiliate) {
            return;
        }
        
        // Get affiliate email and name (use stored email or get from user)
        $affiliate_email = !empty($affiliate->email) ? $affiliate->email : '';
        $affiliate_name = !empty($affiliate->name) ? $affiliate->name : '';
        
        // If not stored, get from user account
        if (empty($affiliate_email) || empty($affiliate_name)) {
            $user = get_user_by('id', $affiliate->user_id);
            if ($user) {
                if (empty($affiliate_email)) {
                    $affiliate_email = $user->user_email;
                }
                if (empty($affiliate_name)) {
                    $affiliate_name = $user->display_name ?: $user->user_login;
                }
            }
        }
        
        if (empty($affiliate_email)) {
            error_log('ViraStore: Cannot send withdrawal email - no email address for affiliate ID: ' . $affiliate_id);
            return;
        }
        
        $subject = sprintf(__('[%s] Withdrawal Request %s', 'vira-store'), get_bloginfo('name'), ucfirst($new_status));
        
        $message = sprintf(__('Dear %s,', 'vira-store'), esc_html($affiliate_name)) . "\n\n";
        $message .= sprintf(__('Your withdrawal request for $%.2f has been %s.', 'vira-store'), floatval($withdrawal->amount), esc_html($new_status)) . "\n\n";
        
        if (!empty($admin_notes)) {
            $message .= __('Admin Notes:', 'vira-store') . "\n" . esc_html($admin_notes) . "\n\n";
        }
        
        if ($new_status === 'paid' && !empty($withdrawal->payment_details)) {
            $message .= __('Payment Details:', 'vira-store') . "\n" . esc_html($withdrawal->payment_details) . "\n\n";
        }
        
        $message .= sprintf(__('You can view your withdrawal history at: %s', 'vira-store'), esc_url(home_url('/affiliate-dashboard/'))) . "\n\n";
        $message .= __('Best regards,', 'vira-store') . "\n" . get_bloginfo('name');
        
        wp_mail($affiliate_email, $subject, $message);
    }
    
    /**
     * Handle get affiliate performance AJAX request
     */
    public function handle_get_affiliate_performance() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'vrstore_affiliate_nonce')) {
            wp_send_json_error(__('Security check failed.', 'vira-store'));
        }
        
        $user_id = get_current_user_id();
        if (!$user_id) {
            wp_send_json_error(array('message' => __('You must be logged in.', 'vira-store')));
        }
        
        $affiliate = $this->get_affiliate_by_user_id($user_id);
        if (!$affiliate) {
            wp_send_json_error(array('message' => __('You are not registered as an affiliate.', 'vira-store')));
        }
        
        $period = sanitize_text_field($_POST['period'] ?? 'weekly');
        $performance_data = $this->get_affiliate_performance_data($affiliate->id, $period);
        
        wp_send_json_success($performance_data);
    }
    
    /**
     * Get affiliate performance data for charts
     */
    private function get_affiliate_performance_data($affiliate_id, $period = 'weekly') {
        global $wpdb;
        
        $data = [];
        $date_format = '';
        $interval = '';
        
        switch ($period) {
            case 'weekly':
                $date_format = '%a'; // Day abbreviation (Mon, Tue, etc.)
                $interval = '7 DAY';
                break;
            case 'monthly':
                $date_format = '%b %d'; // Month Day (Jan 01, etc.)
                $interval = '30 DAY';
                break;
            default:
                $date_format = '%m-%d';
                $interval = '7 DAY';
        }
        
        // Get performance data from visits and commissions
        // Security: Validate and sanitize interval to prevent SQL injection
        $valid_intervals = array(
            'weekly' => '7 DAY',
            'monthly' => '30 DAY',
            '90days' => '90 DAY',
            'year' => '1 YEAR'
        );
        
        $safe_interval = isset($valid_intervals[$period]) ? $valid_intervals[$period] : '7 DAY';
        
        // Use prepared statement with safe interval
        $query = $wpdb->prepare(
            "SELECT 
                DATE_FORMAT(v.created_at, %s) as label,
                COUNT(v.id) as visits,
                SUM(v.converted) as conversions,
                COALESCE(SUM(c.commission_amount), 0) as earnings
             FROM {$this->affiliate_visits_table} v
             LEFT JOIN {$this->affiliate_commissions_table} c ON v.order_id = c.order_id AND c.affiliate_id = %d
             WHERE v.affiliate_id = %d 
               AND v.created_at >= DATE_SUB(NOW(), INTERVAL {$safe_interval})
             GROUP BY DATE(v.created_at)
             ORDER BY v.created_at ASC",
            $date_format,
            $affiliate_id,
            $affiliate_id
        );
        
        $results = $wpdb->get_results($query);
        
        foreach ($results as $row) {
            $data[] = [
                'label' => $row->label,
                'visits' => intval($row->visits),
                'conversions' => intval($row->conversions),
                'earnings' => floatval($row->earnings),
                'value' => floatval($row->earnings) // For chart height calculation
            ];
        }
        
        return $data;
    }
    
    /**
     * Handle currency formatting AJAX request
     */
    public function handle_format_currency_amounts() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_affiliate_ajax_nonce')) {
            wp_die(json_encode(['success' => false, 'data' => 'Invalid nonce']), 403);
        }
        
        // Check if user is logged in
        if (!is_user_logged_in()) {
            wp_die(json_encode(['success' => false, 'data' => 'User not logged in']), 403);
        }
        
        $amounts = $_POST['amounts'] ?? [];
        
        if (!is_array($amounts)) {
            wp_die(json_encode(['success' => false, 'data' => 'Invalid amounts data']), 400);
        }
        
        $formatted_amounts = [];
        
        // Check if currency converter is available
        if (class_exists('VRSTORE_Currency_Converter')) {
            $currency_converter = VRSTORE_Currency_Converter::get_instance();
            
            foreach ($amounts as $amount) {
                $formatted_amounts[] = $currency_converter->format_price(floatval($amount));
            }
        } else {
            // Fallback to USD formatting
            foreach ($amounts as $amount) {
                $formatted_amounts[] = '$' . number_format(floatval($amount), 2);
            }
        }
        
        wp_send_json_success(array('formatted_amounts' => $formatted_amounts));
    }
}

