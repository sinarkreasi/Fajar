<?php
/**
 * API Class for Vira Store
 *
 * @package Vira_Store
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * VRSTORE_API Class
 *
 * This class handles all REST API endpoints for the Vira Store plugin.
 *
 * @since 1.0.0
 */
class VRSTORE_API {

    /**
     * Instance of this class.
     *
     * @since 1.0.0
     * @var VRSTORE_API|null
     */
    private static ?VRSTORE_API $instance = null;

    /**
     * API namespace
     *
     * @since 1.0.0
     * @var string
     */
    private $namespace = 'vrstore/v1';

    /**
     * Constructor.
     *
     * @since 1.0.0
     */
    private function __construct() {
        // Initialize REST API routes
        add_action( 'rest_api_init', array( $this, 'register_routes' ) );
    }

    /**
     * Get translated text with fallback for when textdomain is not loaded.
     *
     * @since 1.0.0
     * @param string $text Text to translate.
     * @param string $domain Text domain.
     * @return string Translated text or original text if textdomain not loaded.
     */
    private function get_translated_text( $text, $domain = 'vira-store' ) {
        // Check if textdomain is loaded
        if ( is_textdomain_loaded( $domain ) ) {
            return esc_html__( $text, $domain );
        }
        // Return escaped text without translation if textdomain not loaded
        return esc_html( $text );
    }

    /**
     * Get instance of this class.
     *
     * @since 1.0.0
     * @return VRSTORE_API
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Register REST API routes
     *
     * @since 1.0.0
     * @return void
     */
    public function register_routes() {
        // Products endpoints
        register_rest_route(
            $this->namespace,
            '/products',
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_products' ),
                'permission_callback' => array( $this, 'get_items_permissions_check' ),
                'args'                => $this->get_collection_params(),
            )
        );

        register_rest_route(
            $this->namespace,
            '/products/(?P<id>[\d]+)',
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_product' ),
                'permission_callback' => array( $this, 'get_item_permissions_check' ),
                'args'                => array(
                    'id' => array(
                        'validate_callback' => function( $param ) {
                            return is_numeric( $param );
                        },
                    ),
                ),
            )
        );

        // License endpoints
        register_rest_route(
            $this->namespace,
            '/licenses/validate',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'validate_license' ),
                'permission_callback' => array( $this, 'validate_license_permissions_check' ),
                'args'                => array(
                    'license_key' => array(
                        'required'          => true,
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'product_id'  => array(
                        'required'          => true,
                        'validate_callback' => function( $param ) {
                            return is_numeric( $param );
                        },
                        'sanitize_callback' => 'absint',
                    ),
                ),
            )
        );

        register_rest_route(
            $this->namespace,
            '/licenses/activate',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'activate_license' ),
                'permission_callback' => array( $this, 'license_action_permissions_check' ),
                'args'                => array(
                    'license_key' => array(
                        'required'          => true,
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'product_id'  => array(
                        'required'          => true,
                        'validate_callback' => function( $param ) {
                            return is_numeric( $param );
                        },
                        'sanitize_callback' => 'absint',
                    ),
                    'site_url'    => array(
                        'required'          => true,
                        'sanitize_callback' => 'esc_url_raw',
                    ),
                ),
            )
        );

        register_rest_route(
            $this->namespace,
            '/licenses/deactivate',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'deactivate_license' ),
                'permission_callback' => array( $this, 'license_action_permissions_check' ),
                'args'                => array(
                    'license_key' => array(
                        'required'          => true,
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'product_id'  => array(
                        'required'          => true,
                        'validate_callback' => function( $param ) {
                            return is_numeric( $param );
                        },
                        'sanitize_callback' => 'absint',
                    ),
                    'site_url'    => array(
                        'required'          => true,
                        'sanitize_callback' => 'esc_url_raw',
                    ),
                ),
            )
        );

        // Payment webhook endpoints

        register_rest_route(
            $this->namespace,
            '/webhooks/tripay',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'handle_tripay_webhook' ),
                'permission_callback' => '__return_true',
            )
        );

        // Plugin update endpoints
        register_rest_route(
            $this->namespace,
            '/updates/plugin',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'check_plugin_update' ),
                'permission_callback' => array( $this, 'plugin_update_permissions_check' ),
                'args'                => array(
                    'plugin_slug' => array(
                        'required'          => true,
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'version'     => array(
                        'required'          => true,
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'license_key' => array(
                        'required'          => true,
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'site_url'    => array(
                        'required'          => true,
                        'sanitize_callback' => 'esc_url_raw',
                    ),
                ),
            )
        );

        register_rest_route(
            $this->namespace,
            '/updates/download/(?P<token>[a-zA-Z0-9]+)',
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'download_plugin_update' ),
                'permission_callback' => '__return_true',
                'args'                => array(
                    'token' => array(
                        'required'          => true,
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                ),
            )
        );
    }

    /**
     * Check if a given request has access to get items
     *
     * @since 1.0.0
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|bool
     */
    public function get_items_permissions_check( $request ) {
        // Products are public, so anyone can view them
        return true;
    }

    /**
     * Check if a given request has access to get a specific item
     *
     * @since 1.0.0
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|bool
     */
    public function get_item_permissions_check( $request ) {
        // Products are public, so anyone can view them
        return true;
    }

    /**
     * Check if a given request has access to validate a license
     *
     * @since 1.0.0
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|bool
     */
    public function validate_license_permissions_check( $request ) {
        // Enhanced API key validation using database
        $api_key = $request->get_header( 'X-VRSTORE-API-KEY' );
        if ( ! $api_key ) {
            return new WP_Error(
                'rest_forbidden',
                esc_html__( 'API key is required.', 'vira-store' ),
                array( 'status' => 403 )
            );
        }

        // Validate API key against database
        global $wpdb;
        $api_keys_table = $wpdb->prefix . 'vrstore_api_keys';
        
        // Check if table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$api_keys_table'") !== $api_keys_table) {
            return new WP_Error(
                'rest_forbidden',
                esc_html__( 'API system not properly configured.', 'vira-store' ),
                array( 'status' => 503 )
            );
        }
        
        // Look up API key in database
        $key_record = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $api_keys_table WHERE api_key = %s AND status = %s",
            $api_key,
            'active'
        ), ARRAY_A);
        
        if (!$key_record) {
            return new WP_Error(
                'rest_forbidden',
                esc_html__( 'Invalid or inactive API key.', 'vira-store' ),
                array( 'status' => 403 )
            );
        }
        
        // Check if API key has expired
        if (!empty($key_record['expires_at']) && strtotime($key_record['expires_at']) < time()) {
            return new WP_Error(
                'rest_forbidden',
                esc_html__( 'API key has expired.', 'vira-store' ),
                array( 'status' => 403 )
            );
        }
        
        // Update last used timestamp
        $wpdb->update(
            $api_keys_table,
            ['last_used' => current_time('mysql')],
            ['id' => $key_record['id']],
            ['%s'],
            ['%d']
        );
        
        // Store API key info for later use in the request
        $request->set_param('_vrstore_api_key_id', $key_record['id']);
        $request->set_param('_vrstore_api_permissions', json_decode($key_record['permissions'], true));

        return true;
    }

    /**
     * Check if a given request has access to perform license actions
     *
     * @since 1.0.0
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|bool
     */
    public function license_action_permissions_check( $request ) {
        // Use the same permission check as validate_license
        return $this->validate_license_permissions_check( $request );
    }

    /**
     * Get a collection of products
     *
     * @since 1.0.0
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|WP_REST_Response
     */
    public function get_products( $request ) {
        // Get query parameters
        $args = array(
            'post_type'      => 'vrstore_product',
            'posts_per_page' => $request['per_page'] ? absint( $request['per_page'] ) : 10,
            'paged'          => $request['page'] ? absint( $request['page'] ) : 1,
            'post_status'    => 'publish',
        );

        // Add category filter if provided
        if ( ! empty( $request['category'] ) ) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'vrstore_product_cat',
                    'field'    => 'slug',
                    'terms'    => sanitize_text_field( $request['category'] ),
                ),
            );
        }

        // Add search filter if provided
        if ( ! empty( $request['search'] ) ) {
            $args['s'] = sanitize_text_field( $request['search'] );
        }

        // Get products
        $query    = new WP_Query( $args );
        $products = array();

        if ( $query->have_posts() ) {
            while ( $query->have_posts() ) {
                $query->the_post();
                $product_id = get_the_ID();

                // Get product data
                $product = $this->prepare_product_for_response( $product_id );

                $products[] = $product;
            }
            wp_reset_postdata();
        }

        // Set pagination headers
        $total_posts = $query->found_posts;
        $max_pages   = ceil( $total_posts / (int) $args['posts_per_page'] );

        $response = new WP_REST_Response( $products );
        $response->header( 'X-WP-Total', (int) $total_posts );
        $response->header( 'X-WP-TotalPages', (int) $max_pages );

        return $response;
    }

    /**
     * Get a single product
     *
     * @since 1.0.0
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|WP_REST_Response
     */
    public function get_product( $request ) {
        $product_id = absint( $request['id'] );

        // Check if product exists
        $product = get_post( $product_id );
        if ( empty( $product ) || 'vrstore_product' !== $product->post_type ) {
            return new WP_Error(
                'rest_product_invalid_id',
                esc_html__( 'Invalid product ID.', 'vira-store' ),
                array( 'status' => 404 )
            );
        }

        // Get product data
        $data = $this->prepare_product_for_response( $product_id );

        return new WP_REST_Response( $data );
    }

    /**
     * Validate a license key
     *
     * @since 1.0.0
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|WP_REST_Response
     */
    public function validate_license( $request ) {
        $license_key = sanitize_text_field( $request['license_key'] );
        $product_id  = absint( $request['product_id'] );

        // Get license class instance
        $license_class = VRSTORE_License::get_instance();

        // STEP 1: Verify checksum (SERVER-SIDE ONLY - cryptographic validation)
        if ( ! $license_class->verify_checksum( $license_key, $product_id ) ) {
            return new WP_REST_Response(
                array(
                    'success' => false,
                    'data'    => array(
                        'valid'   => false,
                        'status'  => 'invalid_checksum',
                        'message' => esc_html__( 'Invalid license key format or checksum.', 'vira-store' ),
                    ),
                ),
                200
            );
        }

        // STEP 2: Validate license in database
        $validation = $license_class->validate_license( $license_key, $product_id );

        if ( is_wp_error( $validation ) ) {
            return new WP_Error(
                $validation->get_error_code(),
                $validation->get_error_message(),
                array( 'status' => 400 )
            );
        }

        return new WP_REST_Response(
            array(
                'success' => true,
                'data'    => $validation,
            )
        );
    }

    /**
     * Activate a license key
     *
     * @since 1.0.0
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|WP_REST_Response
     */
    public function activate_license( $request ) {
        $license_key = sanitize_text_field( $request['license_key'] );
        $product_id  = absint( $request['product_id'] );
        $site_url    = esc_url_raw( $request['site_url'] );

        // Validate required parameters
        if ( empty( $license_key ) || empty( $site_url ) ) {
            return new WP_Error(
                'missing_parameters',
                esc_html__( 'License key and site URL are required.', 'vira-store' ),
                array( 'status' => 400 )
            );
        }

        // Get license class instance
        $license_class = VRSTORE_License::get_instance();

        // Verify checksum before activation (use product_id from request)
        if ( ! $license_class->verify_checksum( $license_key, $product_id ) ) {
            return new WP_REST_Response(
                array(
                    'success' => false,
                    'data'    => array(
                        'valid'   => false,
                        'message' => esc_html__( 'Invalid license key format or checksum.', 'vira-store' ),
                    ),
                ),
                200
            );
        }

        // Activate license - CORRECT PARAMETER ORDER: license_key, site_url, product_id
        $activation = $license_class->activate_license( $license_key, $site_url, $product_id );

        if ( is_wp_error( $activation ) ) {
            return new WP_Error(
                $activation->get_error_code(),
                $activation->get_error_message(),
                array( 'status' => 400 )
            );
        }

        return new WP_REST_Response(
            array(
                'success' => true,
                'data'    => $activation,
            )
        );
    }

    /**
     * Deactivate a license key
     *
     * @since 1.0.0
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|WP_REST_Response
     */
    public function deactivate_license( $request ) {
        $license_key = sanitize_text_field( $request['license_key'] );
        $product_id  = absint( $request['product_id'] );
        $site_url    = esc_url_raw( $request['site_url'] );

        // Validate required parameters
        if ( empty( $license_key ) || empty( $site_url ) ) {
            return new WP_Error(
                'missing_parameters',
                esc_html__( 'License key and site URL are required.', 'vira-store' ),
                array( 'status' => 400 )
            );
        }

        // Get license class instance
        $license_class = VRSTORE_License::get_instance();

        // Deactivate license - CORRECT PARAMETER ORDER: license_key, site_url, product_id
        $deactivation = $license_class->deactivate_license( $license_key, $site_url, $product_id );

        if ( is_wp_error( $deactivation ) ) {
            return new WP_Error(
                $deactivation->get_error_code(),
                $deactivation->get_error_message(),
                array( 'status' => 400 )
            );
        }

        return new WP_REST_Response(
            array(
                'success' => true,
                'data'    => $deactivation,
            )
        );
    }


    /**
     * Handle TriPay webhook/callback
     *
     * @since 1.0.0
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|WP_REST_Response
     */
    public function handle_tripay_webhook( $request ) {
        // Get the request body
        $payload = $request->get_body();
        
        if ( empty( $payload ) ) {
            return new WP_Error(
                'tripay_webhook_error',
                esc_html__( 'Empty payload received.', 'vira-store' ),
                array( 'status' => 400 )
            );
        }

        // Get TriPay private key for signature verification from vrstore_settings array
        $settings = get_option( 'vrstore_settings', array() );
        $test_mode = isset( $settings['tripay_test_mode'] ) && $settings['tripay_test_mode'] === 'on';
        $private_key = $test_mode 
            ? ( isset( $settings['tripay_test_private_key'] ) ? $settings['tripay_test_private_key'] : '' )
            : ( isset( $settings['tripay_live_private_key'] ) ? $settings['tripay_live_private_key'] : '' );
        
        if ( empty( $private_key ) ) {
            return new WP_Error(
                'tripay_webhook_error',
                esc_html__( 'TriPay private key is not configured.', 'vira-store' ),
                array( 'status' => 400 )
            );
        }

        // Verify callback signature
        $received_signature = $request->get_header( 'X-Callback-Signature' );
        if ( empty( $received_signature ) ) {
            // Try alternative header name
            $received_signature = $request->get_header( 'X-Tripay-Signature' );
        }
        
        if ( empty( $received_signature ) ) {
            return new WP_Error(
                'tripay_webhook_error',
                esc_html__( 'Missing TriPay signature header.', 'vira-store' ),
                array( 'status' => 400 )
            );
        }

        // Calculate expected signature
        $calculated_signature = hash_hmac( 'sha256', $payload, $private_key );
        
        if ( ! hash_equals( $calculated_signature, $received_signature ) ) {
            return new WP_Error(
                'tripay_webhook_error',
                esc_html__( 'Invalid TriPay callback signature.', 'vira-store' ),
                array( 'status' => 401 )
            );
        }

        try {
            $callback_data = json_decode( $payload, true );

            if ( json_last_error() !== JSON_ERROR_NONE ) {
                return new WP_Error(
                    'tripay_webhook_error',
                    esc_html__( 'Invalid JSON payload.', 'vira-store' ),
                    array( 'status' => 400 )
                );
            }

            // Process callback based on event type
            if ( isset( $callback_data['event'] ) && $callback_data['event'] === 'payment_status' ) {
                $reference = isset( $callback_data['reference'] ) ? sanitize_text_field( $callback_data['reference'] ) : '';
                $status = isset( $callback_data['status'] ) ? sanitize_text_field( $callback_data['status'] ) : '';
                $merchant_ref = isset( $callback_data['merchant_ref'] ) ? sanitize_text_field( $callback_data['merchant_ref'] ) : '';
                
                if ( empty( $reference ) || empty( $status ) ) {
                    return new WP_Error(
                        'tripay_webhook_error',
                        esc_html__( 'Missing required callback data.', 'vira-store' ),
                        array( 'status' => 400 )
                    );
                }

                // Update order status based on TriPay status
                $payment = VRSTORE_Payment::get_instance();
                switch ( $status ) {
                    case 'PAID':
                        $payment->update_order_status_by_transaction_id( $reference, 'completed' );
                        break;
                    case 'EXPIRED':
                    case 'FAILED':
                        $payment->update_order_status_by_transaction_id( $reference, 'failed' );
                        break;
                    case 'REFUND':
                        $payment->update_order_status_by_transaction_id( $reference, 'refunded' );
                        break;
                    case 'UNPAID':
                    default:
                        // Status remains pending
                        break;
                }

                return new WP_REST_Response(
                    array(
                        'success' => true,
                        'message' => 'OK', // TriPay expects simple 'OK' response
                    ),
                    200
                );
            }

            return new WP_REST_Response(
                array(
                    'success' => true,
                    'message' => 'Callback received but not processed.',
                ),
                200
            );
        } catch ( Exception $e ) {
            return new WP_Error(
                'tripay_webhook_error',
                $e->getMessage(),
                array( 'status' => 500 )
            );
        }
    }

    /**
     * Process successful payment
     *
     * @since 1.0.0
     * @param string $gateway Payment gateway (tripay).
     * @param array  $data    Payment data.
     * @return void
     */
    private function process_successful_payment( $gateway, $data ) {
        // Get order details from metadata
        $order_id = 0;
        $product_id = 0;

        if ( 'tripay' === $gateway ) {
            // Extract order ID and product ID from TriPay data
            if ( isset( $data['merchant_ref'] ) ) {
                $order_id = absint( $data['merchant_ref'] );
            }

            // Get product ID from order meta
            if ( $order_id ) {
                $product_id = get_post_meta( $order_id, 'vrstore_product_id', true );
            }
        }

        // Update order status
        if ( $order_id ) {
            update_post_meta( $order_id, 'vrstore_payment_status', 'completed' );
            update_post_meta( $order_id, 'vrstore_payment_gateway', $gateway );
            update_post_meta( $order_id, 'vrstore_payment_date', current_time( 'mysql' ) );
        }

        // Generate license if product exists
        if ( $product_id && $order_id ) {
            $license_class = VRSTORE_License::get_instance();
            $license_class->generate_license_on_purchase( $product_id, $order_id );
        }

        // Trigger action for other plugins to hook into
        do_action( 'vrstore_payment_completed', $order_id, $product_id, $gateway, $data );
    }

    /**
     * Prepare product data for API response
     *
     * @since 1.0.0
     * @param int $product_id Product ID.
     * @return array
     */
    private function prepare_product_for_response( $product_id ) {
        $product = get_post( $product_id );

        // Get product meta
        $price = get_post_meta( $product_id, 'vrstore_product_price', true );
        $sale_price = get_post_meta( $product_id, 'vrstore_product_sale_price', true );
        $version = get_post_meta( $product_id, 'vrstore_product_version', true );

        // Get product categories
        $categories = array();
        $terms = get_the_terms( $product_id, 'vrstore_product_cat' );
        if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
            foreach ( $terms as $term ) {
                $categories[] = array(
                    'id'   => $term->term_id,
                    'name' => $term->name,
                    'slug' => $term->slug,
                );
            }
        }

        // Get product tags
        $tags = array();
        $terms = get_the_terms( $product_id, 'vrstore_product_tag' );
        if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
            foreach ( $terms as $term ) {
                $tags[] = array(
                    'id'   => $term->term_id,
                    'name' => $term->name,
                    'slug' => $term->slug,
                );
            }
        }

        // Get featured image
        $featured_image = '';
        if ( has_post_thumbnail( $product_id ) ) {
            $featured_image = get_the_post_thumbnail_url( $product_id, 'full' );
        }

        // Format product data
        $data = array(
            'id'           => $product_id,
            'title'        => $product->post_title,
            'slug'         => $product->post_name,
            'content'      => $product->post_content,
            'excerpt'      => $product->post_excerpt,
            'featured_image' => $featured_image,
            'price'        => $price ? floatval( $price ) : 0,
            'sale_price'   => $sale_price ? floatval( $sale_price ) : 0,
            'version'      => $version,
            'categories'   => $categories,
            'tags'         => $tags,
            'date_created' => mysql2date( 'c', $product->post_date_gmt, false ),
            'date_modified' => mysql2date( 'c', $product->post_modified_gmt, false ),
        );

        return $data;
    }

    /**
     * Get collection parameters
     *
     * @since 1.0.0
     * @return array
     */
    public function get_collection_params() {
        return array(
            'page'     => array(
                'description'       => esc_html__( 'Current page of the collection.', 'vira-store' ),
                'type'              => 'integer',
                'default'           => 1,
                'sanitize_callback' => 'absint',
                'validate_callback' => 'rest_validate_request_arg',
                'minimum'           => 1,
            ),
            'per_page' => array(
                'description'       => esc_html__( 'Maximum number of items to be returned in result set.', 'vira-store' ),
                'type'              => 'integer',
                'default'           => 10,
                'minimum'           => 1,
                'maximum'           => 100,
                'sanitize_callback' => 'absint',
                'validate_callback' => 'rest_validate_request_arg',
            ),
            'search'   => array(
                'description'       => $this->get_translated_text( 'Limit results to those matching a string.', 'vira-store' ),
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field',
                'validate_callback' => 'rest_validate_request_arg',
            ),
            'category' => array(
                'description'       => $this->get_translated_text( 'Limit results to those in a specific category.', 'vira-store' ),
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field',
                'validate_callback' => 'rest_validate_request_arg',
            ),
        );
    }


    /**
     * Verify TriPay webhook signature
     *
     * @since 1.0.0
     * @param string $payload         The raw webhook payload.
     * @param array  $headers         Request headers.
     * @param string $webhook_secret  The webhook secret.
     * @return bool
     */
    private function verify_tripay_signature( $payload, $headers, $webhook_secret ) {
        // Get X-Callback-Signature header
        $signature = null;
        foreach ( $headers as $name => $value ) {
            if ( strtolower( $name ) === 'x-callback-signature' ) {
                $signature = $value;
                break;
            }
        }

        if ( empty( $signature ) ) {
            return false;
        }

        // Compute expected signature
        $expected_sig = hash_hmac( 'sha256', $payload, $webhook_secret );

        // Verify signature
        return hash_equals( $expected_sig, $signature );
    }

    /**
     * Check if a given request has access to plugin update endpoints
     *
     * @since 1.9.0
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_Error|bool
     */
    public function plugin_update_permissions_check( $request ) {
        // Enhanced API key validation using database
        $api_key = $request->get_header( 'X-VRSTORE-API-KEY' );
        if ( ! $api_key ) {
            return new WP_Error(
                'rest_forbidden',
                esc_html__( 'API key is required.', 'vira-store' ),
                array( 'status' => 403 )
            );
        }

        // Validate API key against database
        global $wpdb;
        $api_keys_table = $wpdb->prefix . 'vrstore_api_keys';
        
        // Check if table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$api_keys_table'") !== $api_keys_table) {
            return new WP_Error(
                'rest_forbidden',
                esc_html__( 'API system not properly configured.', 'vira-store' ),
                array( 'status' => 503 )
            );
        }
        
        // Look up API key in database
        $key_record = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $api_keys_table WHERE api_key = %s AND status = %s",
            $api_key,
            'active'
        ), ARRAY_A);
        
        if (!$key_record) {
            return new WP_Error(
                'rest_forbidden',
                esc_html__( 'Invalid or inactive API key.', 'vira-store' ),
                array( 'status' => 403 )
            );
        }
        
        // Check if API key has expired
        if (!empty($key_record['expires_at']) && strtotime($key_record['expires_at']) < time()) {
            return new WP_Error(
                'rest_forbidden',
                esc_html__( 'API key has expired.', 'vira-store' ),
                array( 'status' => 403 )
            );
        }
        
        // Update last used timestamp
        $wpdb->update(
            $api_keys_table,
            ['last_used' => current_time('mysql')],
            ['id' => $key_record['id']],
            ['%s'],
            ['%d']
        );
        
        return true;
    }

    /**
     * Check for plugin updates
     *
     * @since 1.9.0
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_REST_Response|WP_Error
     */
    public function check_plugin_update( $request ) {
        $plugin_slug = $request->get_param( 'plugin_slug' );
        $current_version = $request->get_param( 'version' );
        $license_key = $request->get_param( 'license_key' );
        $site_url = $request->get_param( 'site_url' );

        global $wpdb;

        try {
            // Find product by plugin slug
            $product_id = $wpdb->get_var($wpdb->prepare(
                "SELECT post_id FROM {$wpdb->postmeta} 
                 WHERE meta_key = '_vrstore_plugin_slug' AND meta_value = %s",
                $plugin_slug
            ));

            if (!$product_id) {
                return new WP_Error(
                    'plugin_not_found',
                    esc_html__( 'Plugin not found.', 'vira-store' ),
                    array( 'status' => 404 )
                );
            }

            // Validate license
            $license_instance = VRSTORE_License::get_instance();
            $license_validation = $license_instance->validate_license_key($license_key, $product_id);

            if (!$license_validation['valid']) {
                return new WP_Error(
                    'invalid_license',
                    esc_html__( 'Invalid or expired license.', 'vira-store' ),
                    array( 'status' => 403 )
                );
            }

            // Get license tier
            $license_tier = $license_validation['license_tier'] ?? 'basic';

            // Get latest version for this license tier
            $product_instance = VRSTORE_Product::get_instance();
            $latest_version = $product_instance->get_latest_plugin_version($product_id, $license_tier);

            if (!$latest_version) {
                return new WP_REST_Response(array(
                    'update_available' => false,
                    'message' => esc_html__( 'No updates available for your license tier.', 'vira-store' )
                ), 200);
            }

            // Compare versions
            $update_available = version_compare($latest_version->version, $current_version, '>');

            if (!$update_available) {
                return new WP_REST_Response(array(
                    'update_available' => false,
                    'current_version' => $current_version,
                    'latest_version' => $latest_version->version,
                    'message' => esc_html__( 'You have the latest version.', 'vira-store' )
                ), 200);
            }

            // Generate secure download token
            $token = wp_generate_password(32, false);
            $expires_at = date('Y-m-d H:i:s', strtotime('+1 hour'));

            $wpdb->insert(
                $wpdb->prefix . 'vrstore_update_tokens',
                [
                    'token' => $token,
                    'license_key' => $license_key,
                    'product_id' => $product_id,
                    'version_id' => $latest_version->id,
                    'site_url' => $site_url,
                    'expires_at' => $expires_at,
                    'created_at' => current_time('mysql')
                ],
                ['%s', '%s', '%d', '%d', '%s', '%s', '%s']
            );

            return new WP_REST_Response(array(
                'update_available' => true,
                'current_version' => $current_version,
                'latest_version' => $latest_version->version,
                'changelog' => $latest_version->changelog,
                'download_url' => rest_url($this->namespace . '/updates/download/' . $token),
                'package' => rest_url($this->namespace . '/updates/download/' . $token),
                'tested' => get_bloginfo('version'),
                'requires_php' => '8.2',
                'compatibility' => array(),
                'message' => esc_html__( 'Update available.', 'vira-store' )
            ), 200);

        } catch (Exception $e) {
            return new WP_Error(
                'update_check_failed',
                esc_html__( 'Failed to check for updates.', 'vira-store' ),
                array( 'status' => 500 )
            );
        }
    }

    /**
     * Download plugin update file
     *
     * @since 1.9.0
     * @param WP_REST_Request $request Full data about the request.
     * @return WP_REST_Response|WP_Error
     */
    public function download_plugin_update( $request ) {
        $token = $request->get_param( 'token' );

        global $wpdb;

        try {
            // Validate token
            $token_data = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}vrstore_update_tokens 
                 WHERE token = %s AND expires_at > %s AND used_at IS NULL",
                $token,
                current_time('mysql')
            ));

            if (!$token_data) {
                return new WP_Error(
                    'invalid_token',
                    esc_html__( 'Invalid or expired download token.', 'vira-store' ),
                    array( 'status' => 403 )
                );
            }

            // Get version file info
            $version_data = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}vrstore_plugin_versions WHERE id = %d",
                $token_data->version_id
            ));

            if (!$version_data || !file_exists($version_data->file_path)) {
                return new WP_Error(
                    'file_not_found',
                    esc_html__( 'Update file not found.', 'vira-store' ),
                    array( 'status' => 404 )
                );
            }

            // Mark token as used
            $wpdb->update(
                $wpdb->prefix . 'vrstore_update_tokens',
                ['used_at' => current_time('mysql')],
                ['id' => $token_data->id],
                ['%s'],
                ['%d']
            );

            // Log download
            $wpdb->insert(
                $wpdb->prefix . 'vrstore_download_logs',
                [
                    'license_key' => $token_data->license_key,
                    'product_id' => $token_data->product_id,
                    'file_name' => $version_data->file_name,
                    'file_size' => $version_data->file_size,
                    'download_type' => 'plugin_update',
                    'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
                    'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
                    'site_url' => $token_data->site_url,
                    'downloaded_at' => current_time('mysql')
                ],
                ['%s', '%d', '%s', '%d', '%s', '%s', '%s', '%s', '%s']
            );

            // Serve file
            $file_protection = VRSTORE_File_Protection::get_instance();
            $file_protection->serve_secure_file($version_data->file_path, $version_data->file_name);

        } catch (Exception $e) {
            return new WP_Error(
                'download_failed',
                esc_html__( 'Failed to download update.', 'vira-store' ),
                array( 'status' => 500 )
            );
        }
    }
}
