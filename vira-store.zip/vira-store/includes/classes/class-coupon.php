<?php
/**
 * Coupon management class
 *
 * @package Vira_Store
 * @since 1.0.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Coupon management class for Vira Store
 */
class VRSTORE_Coupon {
    /**
     * Singleton instance
     *
     * @var VRSTORE_Coupon|null
     */
    private static ?VRSTORE_Coupon $instance = null;

    /**
     * Database instance
     *
     * @var VRSTORE_Database
     */
    private VRSTORE_Database $db;

    /**
     * Get singleton instance
     *
     * @return VRSTORE_Coupon
     */
    public static function get_instance(): VRSTORE_Coupon {
        if (null === self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Get translated text with conditional loading check.
     *
     * @since 1.0.0
     * @param string $text The text to translate.
     * @return string
     */
    private function get_translated_text( $text ) {
        if ( vrstore_is_textdomain_ready() ) {
            return esc_html__( $text, 'vira-store' );
        }
        return esc_html( $text );
    }

    /**
     * Constructor
     */
    private function __construct() {
        $this->db = VRSTORE_Database::get_instance();
        
        // Initialize hooks
        add_action('init', [$this, 'init']);
        add_action('wp_ajax_vrstore_validate_coupon', [$this, 'ajax_validate_coupon']);
        add_action('wp_ajax_nopriv_vrstore_validate_coupon', [$this, 'ajax_validate_coupon']);
    }

    /**
     * Initialize the coupon system
     */
    public function init(): void {
        // Register coupon post meta for order integration
        add_action('vrstore_order_created', [$this, 'handle_coupon_usage'], 10, 2);
        add_action('vrstore_order_created_in_database', [$this, 'handle_coupon_usage'], 10, 2);
        
        // Clean up expired coupons daily
        if (!wp_next_scheduled('vrstore_cleanup_expired_coupons')) {
            wp_schedule_event(time(), 'daily', 'vrstore_cleanup_expired_coupons');
        }
        add_action('vrstore_cleanup_expired_coupons', [$this, 'cleanup_expired_coupons']);
    }

    /**
     * Create a new coupon
     *
     * @param array $data Coupon data
     * @return int|false Coupon ID on success, false on failure
     */
    public function create_coupon(array $data) {
        global $wpdb;
        
        // Check if required table exists
        if (!$this->db->table_exists('coupons')) {
            return false;
        }
        
        // Validate required fields
        $validation = $this->validate_coupon_data($data);
        if (is_wp_error($validation)) {
            return false;
        }

        // Sanitize and prepare data
        $coupon_data = $this->prepare_coupon_data($data);
        $coupon_data['created_by'] = get_current_user_id();

        // Insert coupon
        $table = $this->db->get_table_name('coupons');
        $result = $wpdb->insert($table, $coupon_data);

        if ($result === false) {
            return false;
        }

        $coupon_id = $wpdb->insert_id;

        // Log coupon creation
        do_action('vrstore_coupon_created', $coupon_id, $coupon_data);

        return $coupon_id;
    }

    /**
     * Update an existing coupon
     *
     * @param int   $coupon_id Coupon ID
     * @param array $data      Updated coupon data
     * @return bool Success status
     */
    public function update_coupon(int $coupon_id, array $data): bool {
        global $wpdb;
        
        // Check if required table exists
        if (!$this->db->table_exists('coupons')) {
            return false;
        }
        
        // Check if coupon exists
        $existing_coupon = $this->get_coupon($coupon_id);
        if (!$existing_coupon) {
            return false;
        }

        // Check if this is a status-only update or simple field update
        $is_simple_update = (
            count($data) === 1 && isset($data['status'])
        ) || (
            count($data) <= 3 && 
            !isset($data['code']) && 
            !isset($data['discount_value']) && 
            !isset($data['discount_type'])
        );
        
        if (!$is_simple_update) {
            // Full validation for complete updates
            $validation = $this->validate_coupon_data($data, $coupon_id);
            if (is_wp_error($validation)) {
                return false;
            }
            
            // Sanitize and prepare data
            $coupon_data = $this->prepare_coupon_data($data);
        } else {
            // Simple update - just sanitize the provided fields
            $coupon_data = [];
            if (isset($data['status'])) {
                $coupon_data['status'] = sanitize_text_field($data['status']);
            }
            if (isset($data['usage_count'])) {
                $coupon_data['usage_count'] = intval($data['usage_count']);
            }
            if (isset($data['usage_limit'])) {
                $coupon_data['usage_limit'] = intval($data['usage_limit']);
            }
        }

        // Update coupon
        $table = $this->db->get_table_name('coupons');
        $result = $wpdb->update(
            $table,
            $coupon_data,
            ['id' => $coupon_id],
            null,
            ['%d']
        );

        if ($result === false) {
            return false;
        }

        // Log coupon update
        do_action('vrstore_coupon_updated', $coupon_id, $coupon_data, $existing_coupon);

        return true;
    }

    /**
     * Delete a coupon
     *
     * @param int $coupon_id Coupon ID
     * @return bool Success status
     */
    public function delete_coupon(int $coupon_id): bool {
        global $wpdb;
        
        // Check if required tables exist
        if (!$this->db->table_exists('coupons') || !$this->db->table_exists('coupon_usage')) {
            return false;
        }
        
        // Get coupon data before deletion for logging
        $coupon = $this->get_coupon($coupon_id);
        if (!$coupon) {
            return false;
        }

        // Delete coupon usage records first
        $usage_table = $this->db->get_table_name('coupon_usage');
        $wpdb->delete($usage_table, ['coupon_id' => $coupon_id], ['%d']);

        // Delete coupon
        $table = $this->db->get_table_name('coupons');
        $result = $wpdb->delete($table, ['id' => $coupon_id], ['%d']);

        if ($result === false) {
            return false;
        }

        // Log coupon deletion
        do_action('vrstore_coupon_deleted', $coupon_id, $coupon);

        return true;
    }

    /**
     * Get a coupon by ID
     *
     * @param int $coupon_id Coupon ID
     * @return array|null Coupon data or null if not found
     */
    public function get_coupon(int $coupon_id): ?array {
        global $wpdb;
        
        // Check if required table exists
        if (!$this->db->table_exists('coupons')) {
            return null;
        }
        
        $table = $this->db->get_table_name('coupons');
        $coupon = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM $table WHERE id = %d", $coupon_id),
            ARRAY_A
        );

        return $coupon ? $this->format_coupon_data($coupon) : null;
    }

    /**
     * Get a coupon by code
     *
     * @param string $code Coupon code
     * @return array|null Coupon data or null if not found
     */
    public function get_coupon_by_code(string $code): ?array {
        global $wpdb;
        
        // Check if required table exists
        if (!$this->db->table_exists('coupons')) {
            return null;
        }
        
        $table = $this->db->get_table_name('coupons');
        $coupon = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM $table WHERE code = %s", $code),
            ARRAY_A
        );

        return $coupon ? $this->format_coupon_data($coupon) : null;
    }

    /**
     * Get coupons with pagination and filtering
     *
     * @param array $args Query arguments
     * @return array Coupons data with pagination info
     */
    public function get_coupons(array $args = []): array {
        global $wpdb;
        
        // Check if required table exists
        if (!$this->db->table_exists('coupons')) {
            return [
                'coupons' => [],
                'total_items' => 0,
                'total_pages' => 0,
                'current_page' => 1,
                'per_page' => 20
            ];
        }
        
        $defaults = [
            'per_page' => 20,
            'page' => 1,
            'status' => '',
            'search' => '',
            'orderby' => 'created_at',
            'order' => 'DESC'
        ];
        
        $args = wp_parse_args($args, $defaults);
        $table = $this->db->get_table_name('coupons');
        
        // Build WHERE clause
        $where_conditions = [];
        $where_values = [];
        
        if (!empty($args['status'])) {
            $where_conditions[] = 'status = %s';
            $where_values[] = $args['status'];
        }
        
        if (!empty($args['search'])) {
            $where_conditions[] = '(code LIKE %s OR description LIKE %s)';
            $search_term = '%' . $wpdb->esc_like($args['search']) . '%';
            $where_values[] = $search_term;
            $where_values[] = $search_term;
        }
        
        $where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';
        
        // Build ORDER BY clause
        $allowed_orderby = ['code', 'discount_value', 'usage_count', 'start_date', 'end_date', 'created_at'];
        $orderby = in_array($args['orderby'], $allowed_orderby) ? $args['orderby'] : 'created_at';
        $order = strtoupper($args['order']) === 'ASC' ? 'ASC' : 'DESC';
        
        // Get total count
        $count_query = "SELECT COUNT(*) FROM $table $where_clause";
        if (!empty($where_values)) {
            $count_query = $wpdb->prepare($count_query, ...$where_values);
        }
        $total_items = (int) $wpdb->get_var($count_query);
        
        // Get coupons
        $offset = ($args['page'] - 1) * $args['per_page'];
        $limit_clause = $wpdb->prepare('LIMIT %d, %d', $offset, $args['per_page']);
        
        $query = "SELECT * FROM $table $where_clause ORDER BY $orderby $order $limit_clause";
        if (!empty($where_values)) {
            $query = $wpdb->prepare($query, ...$where_values);
        }
        
        $coupons = $wpdb->get_results($query, ARRAY_A);
        
        // Format coupon data
        $formatted_coupons = array_map([$this, 'format_coupon_data'], $coupons);
        
        return [
            'coupons' => $formatted_coupons,
            'total_items' => $total_items,
            'total_pages' => ceil($total_items / $args['per_page']),
            'current_page' => $args['page'],
            'per_page' => $args['per_page']
        ];
    }

    /**
     * Validate a coupon for usage
     *
     * @param string $code        Coupon code
     * @param array  $order_data  Order data for validation
     * @return array|WP_Error Validation result
     */
    public function validate_coupon(string $code, array $order_data) {
        $coupon = $this->get_coupon_by_code($code);
        
        if (!$coupon) {
            return new WP_Error('invalid_coupon', __('Invalid coupon code.', 'vira-store'));
        }

        // Check if coupon is active
        if ($coupon['status'] !== 'active') {
            return new WP_Error('inactive_coupon', __('This coupon is not active.', 'vira-store'));
        }

        // Check date validity
        $now = current_time('mysql');
        
        if ($coupon['start_date'] && $now < $coupon['start_date']) {
            return new WP_Error('coupon_not_started', __('This coupon is not yet valid.', 'vira-store'));
        }
        
        if ($coupon['end_date'] && $now > $coupon['end_date']) {
            return new WP_Error('coupon_expired', $this->get_translated_text('This coupon has expired.'));
        }

        // Check usage limits
        if ($coupon['usage_limit'] && $coupon['usage_count'] >= $coupon['usage_limit']) {
            return new WP_Error('usage_limit_reached', $this->get_translated_text('This coupon has reached its usage limit.'));
        }

        // Check per-user usage limit
        if ($coupon['usage_limit_per_user']) {
            $user_usage_count = $this->get_user_coupon_usage_count($coupon['id'], get_current_user_id());
            if ($user_usage_count >= $coupon['usage_limit_per_user']) {
                return new WP_Error('user_usage_limit_reached', $this->get_translated_text('You have reached the usage limit for this coupon.'));
            }
        }

        // Check minimum amount
        if ($coupon['minimum_amount'] && $order_data['subtotal'] < $coupon['minimum_amount']) {
            return new WP_Error('minimum_amount_not_met', 
                sprintf($this->get_translated_text('Minimum order amount of %s required for this coupon.'), 
                    $this->format_price($coupon['minimum_amount'])
                )
            );
        }

        return [
            'valid' => true,
            'coupon' => $coupon,
            'discount_amount' => $this->calculate_discount($coupon, $order_data)
        ];
    }

    /**
     * Calculate discount amount for a coupon
     *
     * @param array $coupon     Coupon data
     * @param array $order_data Order data
     * @return float Discount amount
     */
    public function calculate_discount(array $coupon, array $order_data): float {
        $subtotal = $order_data['subtotal'] ?? 0;
        $discount_amount = 0;

        if ($coupon['discount_type'] === 'percentage') {
            $discount_amount = ($subtotal * $coupon['discount_value']) / 100;
            
            // Apply maximum discount limit if set
            if ($coupon['maximum_discount'] && $discount_amount > $coupon['maximum_discount']) {
                $discount_amount = $coupon['maximum_discount'];
            }
        } else {
            // Fixed discount
            $discount_amount = min($coupon['discount_value'], $subtotal);
        }

        return round($discount_amount, 2);
    }

    /**
     * Record coupon usage
     *
     * @param int   $coupon_id Coupon ID
     * @param array $usage_data Usage data
     * @return bool Success status
     */
    public function record_coupon_usage(int $coupon_id, array $usage_data): bool {
        global $wpdb;
        
        // Insert usage record
        $usage_table = $this->db->get_table_name('coupon_usage');
        $result = $wpdb->insert(
            $usage_table,
            [
                'coupon_id' => $coupon_id,
                'user_id' => $usage_data['user_id'] ?? get_current_user_id(),
                'order_id' => $usage_data['order_id'] ?? null,
                'discount_amount' => $usage_data['discount_amount'] ?? 0
            ],
            ['%d', '%d', '%d', '%f']
        );

        if ($result === false) {
            return false;
        }

        // Update coupon usage count
        $coupons_table = $this->db->get_table_name('coupons');
        $wpdb->query(
            $wpdb->prepare(
                "UPDATE $coupons_table SET usage_count = usage_count + 1 WHERE id = %d",
                $coupon_id
            )
        );

        return true;
    }

    /**
     * Get coupon usage statistics
     *
     * @param int $coupon_id Coupon ID
     * @return array Usage statistics
     */
    public function get_coupon_usage_stats(int $coupon_id): array {
        global $wpdb;
        
        $usage_table = $this->db->get_table_name('coupon_usage');
        
        $stats = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT 
                    COUNT(*) as total_usage,
                    SUM(discount_amount) as total_discount,
                    AVG(discount_amount) as avg_discount,
                    COUNT(DISTINCT user_id) as unique_users
                 FROM $usage_table 
                 WHERE coupon_id = %d",
                $coupon_id
            ),
            ARRAY_A
        );

        return [
            'total_usage' => (int) ($stats['total_usage'] ?? 0),
            'total_discount' => (float) ($stats['total_discount'] ?? 0),
            'average_discount' => (float) ($stats['avg_discount'] ?? 0),
            'unique_users' => (int) ($stats['unique_users'] ?? 0)
        ];
    }

    /**
     * AJAX handler for coupon validation
     */
    public function ajax_validate_coupon(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_frontend_nonce')) {
            wp_send_json_error(['message' => __('Security check failed.', 'vira-store')]);
        }

        $coupon_code = sanitize_text_field($_POST['coupon_code'] ?? '');
        $subtotal = floatval($_POST['subtotal'] ?? 0);

        if (empty($coupon_code)) {
            wp_send_json_error(['message' => $this->get_translated_text('Please enter a coupon code.')]);
        }

        $order_data = [
            'subtotal' => $subtotal
        ];

        $validation = $this->validate_coupon($coupon_code, $order_data);
        
        if (is_wp_error($validation)) {
            wp_send_json_error(['message' => $validation->get_error_message()]);
        }

        wp_send_json_success([
            'message' => $this->get_translated_text('Coupon applied successfully!'),
            'discount_amount' => $validation['discount_amount'],
            'discount_formatted' => $this->format_price($validation['discount_amount']),
            'coupon' => [
                'id' => $validation['coupon']['id'],
                'code' => $validation['coupon']['code'],
                'discount_type' => $validation['coupon']['discount_type'],
                'discount_value' => $validation['coupon']['discount_value']
            ]
        ]);
    }

    /**
     * Handle coupon usage when order is created
     *
     * @param int   $order_id   Order ID
     * @param array $order_data Order data
     */
    public function handle_coupon_usage(int $order_id, array $order_data): void {
        // Check for coupon_id first (direct ID), then coupon_code
        $coupon_id = null;
        
        if (!empty($order_data['coupon_id'])) {
            $coupon_id = intval($order_data['coupon_id']);
        } elseif (!empty($order_data['coupon_code'])) {
            $coupon = $this->get_coupon_by_code($order_data['coupon_code']);
            if ($coupon) {
                $coupon_id = intval($coupon['id']);
            }
        }
        
        if (!$coupon_id) {
            return;
        }

        $this->record_coupon_usage($coupon_id, [
            'user_id' => $order_data['user_id'] ?? null,
            'order_id' => $order_id,
            'discount_amount' => $order_data['discount_amount'] ?? 0
        ]);
    }

    /**
     * Clean up expired coupons
     */
    public function cleanup_expired_coupons(): void {
        global $wpdb;
        
        $table = $this->db->get_table_name('coupons');
        $now = current_time('mysql');
        
        // Update expired coupons: only where end_date is not NULL and less than now
        $query = $wpdb->prepare(
            "UPDATE $table SET status = %s WHERE status = %s AND end_date IS NOT NULL AND end_date < %s",
            'expired',
            'active',
            $now
        );
        $wpdb->query($query);
    }

    /**
     * Validate coupon data
     *
     * @param array $data      Coupon data
     * @param int   $coupon_id Coupon ID for updates (optional)
     * @return true|WP_Error Validation result
     */
    private function validate_coupon_data(array $data, int $coupon_id = 0) {
        // Required fields
        if (empty($data['code'])) {
            return new WP_Error('missing_code', $this->get_translated_text('Coupon code is required.'));
        }

        if (empty($data['discount_value']) || $data['discount_value'] <= 0) {
            return new WP_Error('invalid_discount_value', $this->get_translated_text('Discount value must be greater than 0.'));
        }

        // Check for duplicate code
        $existing_coupon = $this->get_coupon_by_code($data['code']);
        if ($existing_coupon && intval($existing_coupon['id']) !== intval($coupon_id)) {
            return new WP_Error('duplicate_code', $this->get_translated_text('This coupon code already exists.'));
        }

        // Validate discount type
        if (!in_array($data['discount_type'], ['percentage', 'fixed'])) {
            return new WP_Error('invalid_discount_type', $this->get_translated_text('Invalid discount type.'));
        }

        // Validate percentage discount
        if ($data['discount_type'] === 'percentage' && $data['discount_value'] > 100) {
            return new WP_Error('invalid_percentage', $this->get_translated_text('Percentage discount cannot exceed 100%.'));
        }

        return true;
    }

    /**
     * Prepare coupon data for database insertion
     *
     * @param array $data Raw coupon data
     * @return array Sanitized coupon data
     */
    private function prepare_coupon_data(array $data): array {
        return [
            'code' => strtoupper(sanitize_text_field($data['code'])),
            'description' => sanitize_textarea_field($data['description'] ?? ''),
            'discount_type' => sanitize_text_field($data['discount_type']),
            'discount_value' => floatval($data['discount_value']),
            'minimum_amount' => !empty($data['minimum_amount']) ? floatval($data['minimum_amount']) : null,
            'maximum_discount' => !empty($data['maximum_discount']) ? floatval($data['maximum_discount']) : null,
            'usage_limit' => !empty($data['usage_limit']) ? intval($data['usage_limit']) : null,
            'usage_limit_per_user' => !empty($data['usage_limit_per_user']) ? intval($data['usage_limit_per_user']) : null,
            'start_date' => !empty($data['start_date']) ? sanitize_text_field($data['start_date']) : null,
            'end_date' => !empty($data['end_date']) ? sanitize_text_field($data['end_date']) : null,
            'status' => sanitize_text_field($data['status'] ?? 'active')
        ];
    }

    /**
     * Format coupon data for display
     *
     * @param array $coupon Raw coupon data from database
     * @return array Formatted coupon data
     */
    private function format_coupon_data(array $coupon): array {
        return $coupon;
    }

    /**
     * Get user coupon usage count
     *
     * @param int $coupon_id Coupon ID
     * @param int $user_id   User ID
     * @return int Usage count
     */
    private function get_user_coupon_usage_count(int $coupon_id, int $user_id): int {
        global $wpdb;
        
        $usage_table = $this->db->get_table_name('coupon_usage');
        return (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM $usage_table WHERE coupon_id = %d AND user_id = %d",
                $coupon_id,
                $user_id
            )
        );
    }

    /**
     * Get coupon statistics for dashboard
     *
     * @return array Coupon statistics
     */
    public function get_coupon_statistics(): array {
        global $wpdb;
        
        $table = $this->db->get_table_name('coupons');
        
        // Check if table exists
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table'") === $table;
        
        if (!$table_exists) {
            return [
                'total' => 0,
                'active' => 0,
                'inactive' => 0,
                'expired' => 0
            ];
        }
        
        // Get total counts
        $total = (int) $wpdb->get_var("SELECT COUNT(*) FROM $table");
        $active = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table WHERE status = %s", 'active'));
        $inactive = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table WHERE status = %s", 'inactive'));
        $expired = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table WHERE status = %s", 'expired'));
        
        return [
            'total' => $total,
            'active' => $active,
            'inactive' => $inactive,
            'expired' => $expired
        ];
    }

    /**
     * Format price with currency
     *
     * @param float $amount Price amount
     * @return string Formatted price
     */
    private function format_price(float $amount): string {
        // Use the existing product format_price method
        $product = VRSTORE_Product::get_instance();
        $settings = VRSTORE_Settings::get_instance();
        $currency = $settings->get_setting('currency', 'USD');
        
        return $product->format_price($amount, $currency);
    }
}

// Initialize the coupon system
VRSTORE_Coupon::get_instance();
