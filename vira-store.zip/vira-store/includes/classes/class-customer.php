<?php
/**
 * Customer management class
 *
 * @package Vira_Store
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Customer management class
 */
class VRSTORE_Customer {
    /**
     * Singleton instance
     *
     * @var VRSTORE_Customer|null
     */
    private static ?VRSTORE_Customer $instance = null;

    /**
     * Database instance
     *
     * @var VRSTORE_Database
     */
    private VRSTORE_Database $db;

    /**
     * Get singleton instance
     *
     * @return VRSTORE_Customer
     */
    public static function get_instance(): VRSTORE_Customer {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Get translated text with conditional loading check.
     *
     * @since 1.0.0
     * @param string $text The text to translate.
     * @return string
     */
    private function get_translated_text( $text ) {
        if ( vrstore_is_textdomain_ready() ) {
            return esc_html__( $text, 'vira-store' );
        }
        return esc_html( $text );
    }

    /**
     * Constructor
     */
    private function __construct() {
        $this->db = VRSTORE_Database::get_instance();
        $this->init();
    }

    /**
     * Initialize customer management
     *
     * @return void
     */
    private function init(): void {
        // Hook into user registration to track customers
        add_action('user_register', [$this, 'on_user_register']);
        add_action('profile_update', [$this, 'on_profile_update']);
    }

    /**
     * Get all customers with pagination and filtering
     *
     * @param array $args Query arguments
     * @return array
     */
    public function get_customers(array $args = []): array {
        $defaults = [
            'role' => 'customer',
            'number' => 20,
            'paged' => 1,
            'search' => '',
            'orderby' => 'registered',
            'order' => 'DESC',
            'meta_query' => [],
            'date_query' => []
        ];

        $args = wp_parse_args($args, $defaults);

        // First try to get users with customer role
        $user_query_args = [
            'role' => $args['role'],
            'number' => $args['number'],
            'paged' => $args['paged'],
            'orderby' => $args['orderby'],
            'order' => $args['order'],
            'fields' => 'all_with_meta'
        ];

        // Add search if provided
        if (!empty($args['search'])) {
            $user_query_args['search'] = '*' . esc_attr($args['search']) . '*';
            $user_query_args['search_columns'] = ['user_login', 'user_email', 'display_name'];
        }

        // Add meta query if provided
        if (!empty($args['meta_query'])) {
            $user_query_args['meta_query'] = $args['meta_query'];
        }

        // Add date query if provided
        if (!empty($args['date_query'])) {
            $user_query_args['date_query'] = $args['date_query'];
        }

        $user_query = new WP_User_Query($user_query_args);
        $customers = $user_query->get_results();
        
        // If no customers found with 'customer' role, try to find users who made orders
        if (empty($customers) && $args['role'] === 'customer') {
            $customers_from_orders = $this->get_customers_from_orders($args);
            return $customers_from_orders;
        }

        // Enhance customer data with additional information
        $enhanced_customers = [];
        foreach ($customers as $customer) {
            $enhanced_customers[] = $this->enhance_customer_data($customer);
        }

        return [
            'customers' => $enhanced_customers,
            'total' => $user_query->get_total(),
            'total_pages' => ceil($user_query->get_total() / $args['number'])
        ];
    }

    /**
     * Get customers from orders table (fallback when no users with customer role)
     *
     * @param array $args Query arguments
     * @return array
     */
    private function get_customers_from_orders(array $args = []): array {
        global $wpdb;
        
        $orders_table = $this->db->get_table_name('orders');
        
        // Check if orders table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$orders_table'") !== $orders_table) {
            return [
                'customers' => [],
                'total' => 0,
                'total_pages' => 0
            ];
        }
        
        // Get unique customers from orders
        $per_page = $args['number'] ?? 20;
        $offset = (($args['paged'] ?? 1) - 1) * $per_page;
        $search = $args['search'] ?? '';
        
        $where_clause = '';
        $where_params = [];
        
        if (!empty($search)) {
            $where_clause = 'WHERE (customer_name LIKE %s OR customer_email LIKE %s)';
            $where_params = ['%' . $search . '%', '%' . $search . '%'];
        }
        
        $query = "SELECT 
                    customer_email,
                    customer_name,
                    COUNT(*) as total_orders,
                    SUM(CASE WHEN payment_status = 'completed' THEN product_price ELSE 0 END) as total_spent,
                    MAX(created_at) as last_order_date,
                    MIN(created_at) as first_order_date
                  FROM $orders_table 
                  $where_clause
                  GROUP BY customer_email 
                  ORDER BY last_order_date DESC 
                  LIMIT %d OFFSET %d";
                  
        $params = array_merge($where_params, [$per_page, $offset]);
        
        // Ensure all parameters are scalar values to prevent wpdb->prepare array error
        $safe_params = [];
        foreach ($params as $param) {
            if (is_scalar($param)) {
                $safe_params[] = $param;
            } else {
                // Convert non-scalar values to strings or handle appropriately
                $safe_params[] = is_null($param) ? '' : (string) $param;
            }
        }
        
        $customer_data = $wpdb->get_results($wpdb->prepare($query, ...$safe_params), ARRAY_A);
        
        // Get total count
        $count_query = "SELECT COUNT(DISTINCT customer_email) FROM $orders_table $where_clause";
        if (!empty($where_params)) {
            // Ensure where_params are scalar values
            $safe_where_params = [];
            foreach ($where_params as $param) {
                if (is_scalar($param)) {
                    $safe_where_params[] = $param;
                } else {
                    // Convert non-scalar values to strings or handle appropriately
                    $safe_where_params[] = is_null($param) ? '' : (string) $param;
                }
            }
            $total = $wpdb->get_var($wpdb->prepare($count_query, ...$safe_where_params));
        } else {
            $total = $wpdb->get_var($count_query);
        }
        
        // Format customer data
        $customers = [];
        foreach ($customer_data as $data) {
            // Try to get WordPress user by email
            $wp_user = get_user_by('email', $data['customer_email']);
            
            $customers[] = [
                'ID' => $wp_user ? $wp_user->ID : 0,
                'user_login' => $wp_user ? $wp_user->user_login : $data['customer_email'],
                'user_email' => $data['customer_email'],
                'display_name' => $data['customer_name'] ?: ($wp_user ? $wp_user->display_name : $data['customer_email']),
                'first_name' => $wp_user ? get_user_meta($wp_user->ID, 'first_name', true) : '',
                'last_name' => $wp_user ? get_user_meta($wp_user->ID, 'last_name', true) : '',
                'user_registered' => $data['first_order_date'],
                'user_status' => 0,
                'status' => 'active',
                'roles' => $wp_user ? $wp_user->roles : ['guest'],
                'total_orders' => (int) $data['total_orders'],
                'total_spent' => (float) $data['total_spent'],
                'last_order_date' => $data['last_order_date'],
                'total_licenses' => $this->get_customer_license_count($data['customer_email']),
                'active_licenses' => $this->get_customer_active_license_count($data['customer_email']),
                'avatar_url' => $wp_user ? get_avatar_url($wp_user->ID) : get_avatar_url($data['customer_email']),
                'edit_url' => $wp_user ? admin_url('admin.php?page=vrstore-customers&action=edit&customer_id=' . $wp_user->ID) : '#'
            ];
        }
        
        return [
            'customers' => $customers,
            'total' => (int) $total,
            'total_pages' => ceil($total / $per_page)
        ];
    }
    
    /**
     * Get license count for customer by email
     *
     * @param string $customer_email Customer email
     * @return int
     */
    private function get_customer_license_count(string $customer_email): int {
        global $wpdb;
        
        $licenses_table = $this->db->get_table_name('licenses');
        
        if ($wpdb->get_var("SHOW TABLES LIKE '$licenses_table'") !== $licenses_table) {
            return 0;
        }
        
        return (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $licenses_table WHERE customer_email = %s",
            $customer_email
        ));
    }
    
    /**
     * Get active license count for customer by email
     *
     * @param string $customer_email Customer email
     * @return int
     */
    private function get_customer_active_license_count(string $customer_email): int {
        global $wpdb;
        
        $licenses_table = $this->db->get_table_name('licenses');
        
        if ($wpdb->get_var("SHOW TABLES LIKE '$licenses_table'") !== $licenses_table) {
            return 0;
        }
        
        return (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $licenses_table WHERE customer_email = %s AND status = 'active'",
            $customer_email
        ));
    }

    /**
     * Get customer by ID
     *
     * @param int $customer_id Customer ID
     * @return array|null
     */
    public function get_customer(int $customer_id): ?array {
        $customer = get_user_by('ID', $customer_id);
        
        if (!$customer) {
            return null;
        }
        
        // Allow customers and any user who made orders
        $has_customer_role = in_array('customer', $customer->roles);
        $has_orders = $this->customer_has_orders($customer->user_email);
        
        if (!$has_customer_role && !$has_orders) {
            return null;
        }

        return $this->enhance_customer_data($customer);
    }
    
    /**
     * Check if customer has orders
     *
     * @param string $email Customer email
     * @return bool
     */
    private function customer_has_orders(string $email): bool {
        global $wpdb;
        
        $orders_table = $this->db->get_table_name('orders');
        
        if ($wpdb->get_var("SHOW TABLES LIKE '$orders_table'") !== $orders_table) {
            return false;
        }
        
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $orders_table WHERE customer_email = %s",
            $email
        ));
        
        return $count > 0;
    }

    /**
     * Enhance customer data with additional information
     *
     * @param WP_User $customer Customer user object
     * @return array
     */
    private function enhance_customer_data(WP_User $customer): array {
        global $wpdb;

        // Get order statistics
        $orders_table = $this->db->get_table_name('orders');
        $order_stats = $wpdb->get_row($wpdb->prepare(
            "SELECT 
                COUNT(*) as total_orders,
                SUM(CASE WHEN order_status = 'completed' THEN product_price ELSE 0 END) as total_spent,
                MAX(created_at) as last_order_date
            FROM $orders_table 
            WHERE customer_email = %s",
            $customer->user_email
        ));

        // Get license statistics
        $licenses_table = $this->db->get_table_name('licenses');
        $license_stats = $wpdb->get_row($wpdb->prepare(
            "SELECT 
                COUNT(*) as total_licenses,
                COUNT(CASE WHEN status = 'active' THEN 1 END) as active_licenses
            FROM $licenses_table 
            WHERE customer_email = %s",
            $customer->user_email
        ));

        // Get customer status from user meta or default to active
        $customer_status = get_user_meta($customer->ID, 'vrstore_customer_status', true);
        if (empty($customer_status)) {
            $customer_status = ($customer->user_status == 0) ? 'active' : 'inactive';
        }

        return [
            'ID' => $customer->ID,
            'user_login' => $customer->user_login,
            'user_email' => $customer->user_email,
            'display_name' => $customer->display_name,
            'first_name' => get_user_meta($customer->ID, 'first_name', true),
            'last_name' => get_user_meta($customer->ID, 'last_name', true),
            'user_registered' => $customer->user_registered,
            'user_status' => $customer->user_status,
            'status' => $customer_status,
            'roles' => $customer->roles,
            'total_orders' => (int) ($order_stats->total_orders ?? 0),
            'total_spent' => (float) ($order_stats->total_spent ?? 0),
            'last_order_date' => $order_stats->last_order_date ?? null,
            'total_licenses' => (int) ($license_stats->total_licenses ?? 0),
            'active_licenses' => (int) ($license_stats->active_licenses ?? 0),
            'avatar_url' => get_avatar_url($customer->ID),
            'edit_url' => admin_url('admin.php?page=vrstore-customers&action=edit&customer_id=' . $customer->ID)
        ];
    }

    /**
     * Get customer orders
     *
     * @param int $customer_id Customer ID
     * @param array $args Query arguments
     * @return array
     */
    public function get_customer_orders(int $customer_id, array $args = []): array {
        $user = get_user_by('id', $customer_id);
        if (!$user) {
            return [];
        }
        
        global $wpdb;
        
        $limit = $args['limit'] ?? 10;
        $offset = $args['offset'] ?? 0;
        $order = $args['order'] ?? 'DESC';
        
        $orders_table = $this->db->get_table_name('orders');
        
        // Check if orders table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$orders_table'") !== $orders_table) {
            return [];
        }
        
        $query = $wpdb->prepare(
            "SELECT * FROM {$orders_table} 
             WHERE customer_email = %s 
             ORDER BY created_at {$order} 
             LIMIT %d OFFSET %d",
            $user->user_email,
            $limit,
            $offset
        );
        
        $orders = $wpdb->get_results($query, ARRAY_A);
        
        $formatted_orders = [];
        foreach ($orders as $order) {
            // Handle Extended Support products
            if (is_string($order['product_id']) && strpos($order['product_id'], 'extended_support_') === 0) {
                // Extract actual product ID from extended support string
                $parts = explode('_', $order['product_id']);
                if (count($parts) >= 3) {
                    $actual_product_id = intval($parts[2]);
                    $license_type = $order['license_type_label'] ?: ($order['license_type'] ?: 'Standard');
                    
                    // Get license type configuration to determine months
                    $months = 12; // Default Extended Support duration
                    if (!empty($order['license_type'])) {
                        $settings = get_option('vrstore_settings', []);
                        $custom_license_types = $settings['custom_license_types'] ?? [];
                        foreach ($custom_license_types as $type) {
                            if ($type['slug'] === $order['license_type'] && !empty($type['expiry_days'])) {
                                $months = max(1, round($type['expiry_days'] / 30));
                                break;
                            }
                        }
                    }
                    
                    // Get the actual product title to create better description
                    $associated_product_title = '';
                    if ($actual_product_id > 0) {
                        $product_post = get_post($actual_product_id);
                        if ($product_post && $product_post->post_title) {
                            $associated_product_title = $product_post->post_title;
                        }
                    }
                    
                    if ($associated_product_title) {
                        $product_title = sprintf('%s - Extended Support (%s / %d months)', $associated_product_title, $license_type, $months);
                    } else {
                        $product_title = sprintf('Extended Support (%s / %d months)', $license_type, $months);
                    }
                } else {
                    $product_title = 'Extended Support';
                }
            } else {
                // Handle regular products
                $product_title = $order['product_id'] ? get_the_title($order['product_id']) : ($order['product_name'] ?: 'Unknown Product');
            }
            
            $formatted_orders[] = [
                'id' => $order['id'],
                'order_id' => $order['id'],
                'order_number' => $order['order_number'] ?: sprintf('ORD-%d', $order['id']),
                'product_id' => $order['product_id'],
                'product_title' => $product_title,
                'customer_name' => $order['customer_name'],
                'customer_email' => $order['customer_email'],
                'payment_method' => $order['payment_method'],
                'order_status' => $order['order_status'],
                'payment_status' => $order['payment_status'],
                'status' => $order['payment_status'] ?: $order['order_status'], // for compatibility
                'currency' => $order['currency'] ?: 'USD',
                'product_price' => $order['product_price'],
                'total' => $order['product_price'], // Use product_price as total for now
                'created_at' => $order['created_at'],
                'date' => $order['created_at'], // for compatibility with frontend
                'date_created' => $order['created_at'],
            ];
        }
        
        return $formatted_orders;
    }

    /**
     * Get customer licenses
     *
     * @param int $customer_id Customer ID
     * @param array $args Query arguments
     * @return array
     */
    public function get_customer_licenses(int $customer_id, array $args = []): array {
        $user = get_user_by('id', $customer_id);
        if (!$user) {
            return [];
        }
        
        // Use modern table-based license system
        global $wpdb;
        
        $limit = $args['limit'] ?? 10;
        $offset = $args['offset'] ?? 0;
        $order = $args['order'] ?? 'DESC';
        
        $licenses_table = $wpdb->prefix . 'vrstore_licenses';
        
        // Check if licenses table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$licenses_table'") !== $licenses_table) {
            return [];
        }
        
        // Try querying by customer_id first (modern approach)
        $query = $wpdb->prepare(
            "SELECT * FROM {$licenses_table} 
             WHERE customer_id = %d 
               AND product_id NOT LIKE 'extended_support_%' 
               AND product_id != '0' 
               AND product_id IS NOT NULL 
             ORDER BY created_at {$order} 
             LIMIT %d OFFSET %d",
            $customer_id,
            $limit,
            $offset
        );
        
        $licenses = $wpdb->get_results($query, ARRAY_A);
        
        // If no results found by customer_id, try by customer_email (legacy fallback)
        if (empty($licenses)) {
            $query = $wpdb->prepare(
                "SELECT * FROM {$licenses_table} 
                 WHERE customer_email = %s 
                   AND product_id NOT LIKE 'extended_support_%' 
                   AND product_id != '0' 
                   AND product_id IS NOT NULL 
                 ORDER BY created_at {$order} 
                 LIMIT %d OFFSET %d",
                $user->user_email,
                $limit,
                $offset
            );
            
            $licenses = $wpdb->get_results($query, ARRAY_A);
        }
        
        $formatted_licenses = [];
        foreach ($licenses as $license) {
			$product_id = $license['product_id'];
			$product_title = '';
			
			// Handle Extended Support products
			if (is_string($product_id) && strpos($product_id, 'extended_support_') === 0) {
				// Extract actual product ID from extended support string
				$parts = explode('_', $product_id);
				if (count($parts) >= 3) {
					$actual_product_id = intval($parts[2]);
					$license_type = $license['license_type_slug'] ?: 'Standard';
					
					// Get license type configuration to determine months
					$months = 12; // Default Extended Support duration
					if (!empty($license['license_type_slug'])) {
						$settings = get_option('vrstore_settings', []);
						$custom_license_types = $settings['custom_license_types'] ?? [];
						foreach ($custom_license_types as $type) {
							if ($type['slug'] === $license['license_type_slug'] && !empty($type['expiry_days'])) {
								$months = max(1, round($type['expiry_days'] / 30));
								break;
							}
						}
					}
					
					// Get the actual product title to create better description
					$associated_product_title = '';
					if ($actual_product_id > 0) {
						$product_post = get_post($actual_product_id);
						if ($product_post && $product_post->post_title) {
							$associated_product_title = $product_post->post_title;
						}
					}
					
					if ($associated_product_title) {
						$product_title = sprintf('%s - Extended Support (%s / %d months)', $associated_product_title, ucfirst(str_replace('-', ' ', $license_type)), $months);
					} else {
						$product_title = sprintf('Extended Support (%s / %d months)', ucfirst(str_replace('-', ' ', $license_type)), $months);
					}
				} else {
					$product_title = 'Extended Support';
				}
			} else {
				// Handle regular products
				$product_title = $product_id ? get_the_title($product_id) : '';
			}
            
            // Get activations count
            $activations_table = $this->db->get_table_name('license_domain_activations');
            $activations_count = 0;
            
            // Check if activations table exists before querying
            if ($wpdb->get_var("SHOW TABLES LIKE '$activations_table'") === $activations_table) {
                $activations_count = $wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM $activations_table WHERE license_key = %s AND status = 'active'",
                    $license['license_key']
                )) ?: 0;
            }
            
            $formatted_licenses[] = [
                'id' => $license['id'],
                'license_key' => $license['license_key'],
                'product_id' => $license['product_id'],
                'product_title' => $product_title,
                'product_name' => $product_title, // for admin compatibility
                'license_type_slug' => $license['license_type_slug'] ?: '',
                'status' => $license['status'] ?: 'active',
                'activation_limit' => $license['activation_limit'] ?: 1,
                'activation_count' => $license['activation_count'] ?: 0,
                'activations_count' => $activations_count, // for admin view
                'activations' => [], // Can be populated with actual activation data if needed
                'expires_at' => $license['expires_at'], // main expiry field from database
                'expiry_date' => $license['expires_at'], // for frontend compatibility
                'date_created' => $license['created_at'],
                'created_at' => $license['created_at'],
            ];
        }
        
        return $formatted_licenses;
    }

    /**
     * Create new customer
     *
     * @param array $customer_data Customer data
     * @return int|WP_Error Customer ID on success, WP_Error on failure
     */
    public function create_customer(array $customer_data) {
        $required_fields = ['user_email', 'display_name'];
        
        // Validate required fields
        foreach ($required_fields as $field) {
            if (empty($customer_data[$field])) {
                return new WP_Error('missing_field', sprintf(__('Field %s is required.', 'vira-store'), $field));
            }
        }

        // Validate email
        if (!is_email($customer_data['user_email'])) {
            return new WP_Error('invalid_email', __('Invalid email address.', 'vira-store'));
        }

        // Check if user already exists
        if (email_exists($customer_data['user_email'])) {
            return new WP_Error('email_exists', __('A user with this email already exists.', 'vira-store'));
        }

        // Generate username if not provided
        if (empty($customer_data['user_login'])) {
            $customer_data['user_login'] = $this->generate_username($customer_data['user_email']);
        }

        // Generate password if not provided
        if (empty($customer_data['user_pass'])) {
            $customer_data['user_pass'] = wp_generate_password();
        }

        // Set default role
        $customer_data['role'] = 'customer';

        // Create user
        $customer_id = wp_insert_user($customer_data);
        
        if (is_wp_error($customer_id)) {
            return $customer_id;
        }

        // Send welcome email
        $this->send_welcome_email($customer_id);

        return $customer_id;
    }

    /**
     * Update customer
     *
     * @param int $customer_id Customer ID
     * @param array $customer_data Customer data
     * @return bool|WP_Error True on success, WP_Error on failure
     */
    public function update_customer(int $customer_id, array $customer_data) {
        // Verify customer exists
        $customer = $this->get_customer($customer_id);
        if (!$customer) {
            return new WP_Error('customer_not_found', __('Customer not found.', 'vira-store'));
        }

        // Handle status field separately as user meta
        if (isset($customer_data['status'])) {
            update_user_meta($customer_id, 'vrstore_customer_status', sanitize_text_field($customer_data['status']));
            unset($customer_data['status']); // Remove from user data array
        }

        // Add customer ID to data
        $customer_data['ID'] = $customer_id;

        // Update user
        $result = wp_update_user($customer_data);
        
        if (is_wp_error($result)) {
            return $result;
        }

        return true;
    }

    /**
     * Delete customer and all related data
     *
     * @param int $customer_id Customer ID
     * @param bool $reassign_posts Whether to reassign posts
     * @return bool|WP_Error True on success, WP_Error on failure
     */
    public function delete_customer(int $customer_id, bool $reassign_posts = false) {
        global $wpdb;
        
        // PROTECTION: Never allow deletion of admin users
        $user = get_user_by('ID', $customer_id);
        if ($user && user_can($user, 'manage_options')) {
            return new WP_Error('cannot_delete_admin', __('Cannot delete administrator users. Admin users are protected from deletion.', 'vira-store'));
        }
        
        // Additional protection: Never delete user ID 1 (primary admin)
        if ($customer_id === 1) {
            return new WP_Error('cannot_delete_primary_admin', __('Cannot delete the primary administrator account (User ID 1).', 'vira-store'));
        }
        
        // Verify customer exists
        $customer = $this->get_customer($customer_id);
        if (!$customer) {
            return new WP_Error('customer_not_found', __('Customer not found.', 'vira-store'));
        }

        $customer_email = $customer['user_email'];
        
        // Start transaction for data integrity
        $wpdb->query('START TRANSACTION');
        
        try {
            // Delete license activations first (foreign key constraints)
            $licenses_table = $wpdb->prefix . 'vrstore_licenses';
            $activations_table = $wpdb->prefix . 'vrstore_license_activations';
            $domain_activations_table = $wpdb->prefix . 'vrstore_license_domain_activations';
            
            // Get all licenses for this customer first
            $license_keys = [];
            if ($wpdb->get_var("SHOW TABLES LIKE '$licenses_table'") === $licenses_table) {
                $license_keys = $wpdb->get_col($wpdb->prepare(
                    "SELECT license_key FROM $licenses_table WHERE customer_email = %s OR customer_id = %d",
                    $customer_email, $customer_id
                ));
            }
            
            // Delete domain activations (new domain management system)
            if ($wpdb->get_var("SHOW TABLES LIKE '$domain_activations_table'") === $domain_activations_table) {
                // Delete by customer_id if exists in domain activations table
                $wpdb->delete(
                    $domain_activations_table,
                    ['customer_id' => $customer_id],
                    ['%d']
                );
                
                // Also delete by license_key for this customer's licenses
                if (!empty($license_keys)) {
                    foreach ($license_keys as $license_key) {
                        $wpdb->delete(
                            $domain_activations_table,
                            ['license_key' => $license_key],
                            ['%s']
                        );
                    }
                }
            }
            
            // Delete legacy license activations
            if ($wpdb->get_var("SHOW TABLES LIKE '$activations_table'") === $activations_table) {
                // Get license IDs for this customer
                $license_ids = $wpdb->get_col($wpdb->prepare(
                    "SELECT id FROM $licenses_table WHERE customer_email = %s OR customer_id = %d",
                    $customer_email, $customer_id
                ));
                
                if (!empty($license_ids)) {
                    // Ensure all license IDs are integers to prevent wpdb->prepare array error
                    $license_ids = array_map('intval', array_filter($license_ids, 'is_numeric'));
                    
                    if (!empty($license_ids)) {
                        $license_ids_placeholder = implode(',', array_fill(0, count($license_ids), '%d'));
                        $wpdb->query($wpdb->prepare(
                            "DELETE FROM $activations_table WHERE license_id IN ($license_ids_placeholder)",
                            ...$license_ids
                        ));
                    }
                }
            }
            
            // Delete licenses
            if ($wpdb->get_var("SHOW TABLES LIKE '$licenses_table'") === $licenses_table) {
                $wpdb->delete(
                    $licenses_table,
                    ['customer_email' => $customer_email],
                    ['%s']
                );
                
                $wpdb->delete(
                    $licenses_table,
                    ['customer_id' => $customer_id],
                    ['%d']
                );
            }
            
            // Delete orders
            $orders_table = $wpdb->prefix . 'vrstore_orders';
            if ($wpdb->get_var("SHOW TABLES LIKE '$orders_table'") === $orders_table) {
                $wpdb->delete(
                    $orders_table,
                    ['customer_email' => $customer_email],
                    ['%s']
                );
            }
            
            // Delete coupon usage records (using user_id since coupon_usage table doesn't have customer_email)
            $coupon_usage_table = $wpdb->prefix . 'vrstore_coupon_usage';
            if ($wpdb->get_var("SHOW TABLES LIKE '$coupon_usage_table'") === $coupon_usage_table) {
                $wpdb->delete(
                    $coupon_usage_table,
                    ['user_id' => $customer_id],
                    ['%d']
                );
            }
            
            // Delete license activation logs (domain management system)
            $activation_logs_table = $wpdb->prefix . 'vrstore_license_activation_logs';
            if ($wpdb->get_var("SHOW TABLES LIKE '$activation_logs_table'") === $activation_logs_table) {
                // Delete logs by license keys
                if (!empty($license_keys)) {
                    foreach ($license_keys as $license_key) {
                        $wpdb->delete(
                            $activation_logs_table,
                            ['license_key' => $license_key],
                            ['%s']
                        );
                    }
                }
            }
            
            // Delete license notifications
            $notifications_table = $wpdb->prefix . 'vrstore_license_notifications';
            if ($wpdb->get_var("SHOW TABLES LIKE '$notifications_table'") === $notifications_table) {
                // Delete notifications by license keys
                if (!empty($license_keys)) {
                    foreach ($license_keys as $license_key) {
                        $wpdb->delete(
                            $notifications_table,
                            ['license_key' => $license_key],
                            ['%s']
                        );
                    }
                }
                
                // Also delete by customer email for general notifications
                $wpdb->delete(
                    $notifications_table,
                    ['recipient_email' => $customer_email],
                    ['%s']
                );
            }
            
            // Delete download logs
            $download_logs_table = $wpdb->prefix . 'vrstore_download_logs';
            if ($wpdb->get_var("SHOW TABLES LIKE '$download_logs_table'") === $download_logs_table) {
                $wpdb->delete(
                    $download_logs_table,
                    ['customer_email' => $customer_email],
                    ['%s']
                );
            }
            
            // Delete download tracking records
            $download_tracking_table = $wpdb->prefix . 'vrstore_download_tracking';
            if ($wpdb->get_var("SHOW TABLES LIKE '$download_tracking_table'") === $download_tracking_table) {
                $wpdb->delete(
                    $download_tracking_table,
                    ['user_id' => $customer_id],
                    ['%d']
                );
                
                // Also delete by customer email for additional cleanup
                $wpdb->delete(
                    $download_tracking_table,
                    ['customer_email' => $customer_email],
                    ['%s']
                );
            }
            
            // Delete payment logs (using order_id relationship since payment_logs table doesn't have customer_email)
            $payment_logs_table = $wpdb->prefix . 'vrstore_payment_logs';
            $orders_table = $wpdb->prefix . 'vrstore_orders';
            if ($wpdb->get_var("SHOW TABLES LIKE '$payment_logs_table'") === $payment_logs_table && 
                $wpdb->get_var("SHOW TABLES LIKE '$orders_table'") === $orders_table) {
                // First get order IDs for this customer
                $order_ids = $wpdb->get_col($wpdb->prepare(
                    "SELECT id FROM $orders_table WHERE customer_email = %s OR customer_id = %d",
                    $customer_email, $customer_id
                ));
                
                if (!empty($order_ids)) {
                    // Ensure all order IDs are integers
                    $order_ids = array_map('intval', array_filter($order_ids, 'is_numeric'));
                    
                    if (!empty($order_ids)) {
                        $order_ids_placeholder = implode(',', array_fill(0, count($order_ids), '%d'));
                        $wpdb->query($wpdb->prepare(
                            "DELETE FROM $payment_logs_table WHERE order_id IN ($order_ids_placeholder)",
                            ...$order_ids
                        ));
                    }
                }
            }
            
            // Delete licenses from database tables (modern license system)
            if (class_exists('VRSTORE_License')) {
                $license_class = VRSTORE_License::get_instance();
                // Delete licenses associated with this customer
                $wpdb->delete(
                    $wpdb->prefix . 'vrstore_licenses',
                    ['customer_id' => $customer_id],
                    ['%d']
                );
                $wpdb->delete(
                    $wpdb->prefix . 'vrstore_licenses',
                    ['customer_email' => $customer_email],
                    ['%s']
                );
            }
            
            // Delete order posts (legacy post-based orders)
            $order_posts = get_posts([
                'post_type' => 'vrstore_order',
                'post_status' => 'any',
                'posts_per_page' => -1,
                'meta_query' => [
                    [
                        'key' => '_vrstore_customer_email',
                        'value' => $customer_email,
                        'compare' => '='
                    ]
                ]
            ]);
            
            foreach ($order_posts as $order_post) {
                wp_delete_post($order_post->ID, true);
            }
            
            // Delete user meta related to the plugin
            $wpdb->delete(
                $wpdb->usermeta,
                [
                    'user_id' => $customer_id,
                    'meta_key' => 'vrstore_%'
                ],
                ['%d', '%s']
            );
            
            // Finally, delete the user
            $result = wp_delete_user($customer_id, $reassign_posts);
            
            if (!$result) {
                throw new Exception(__('Failed to delete customer user account.', 'vira-store'));
            }
            
            // Commit transaction
            $wpdb->query('COMMIT');
            
            // Customer and related data successfully deleted
            
            return true;
            
        } catch (Exception $e) {
            // Rollback transaction on error
            $wpdb->query('ROLLBACK');
            
            // Log deletion failure for debugging
            
            return new WP_Error('delete_failed', $e->getMessage());
        }
    }

    /**
     * Generate unique username from email
     *
     * @param string $email Email address
     * @return string
     */
    private function generate_username(string $email): string {
        $username = sanitize_user(substr($email, 0, strpos($email, '@')));
        
        // Ensure username is unique
        $original_username = $username;
        $counter = 1;
        
        while (username_exists($username)) {
            $username = $original_username . $counter;
            $counter++;
        }
        
        return $username;
    }

    /**
     * Send welcome email to new customer
     *
     * @param int $customer_id Customer ID
     * @return bool
     */
    private function send_welcome_email(int $customer_id): bool {
        $customer = get_user_by('ID', $customer_id);
        if (!$customer) {
            return false;
        }

        $subject = sprintf(__('Welcome to %s', 'vira-store'), get_bloginfo('name'));
        $message = sprintf(
            __('Hello %s,\n\nWelcome to %s! Your account has been created successfully.\n\nYou can access your account at: %s\n\nThank you!', 'vira-store'),
            $customer->display_name,
            get_bloginfo('name'),
            wp_login_url()
        );

        return wp_mail($customer->user_email, $subject, $message);
    }

    /**
     * Handle user registration
     *
     * @param int $user_id User ID
     * @return void
     */
    public function on_user_register(int $user_id): void {
        $user = get_user_by('ID', $user_id);
        
        // Only process customers
        if (!$user || !in_array('customer', $user->roles)) {
            return;
        }

        // Additional customer setup can be added here
        do_action('vrstore_customer_registered', $user_id, $user);
    }

    /**
     * Handle profile update
     *
     * @param int $user_id User ID
     * @return void
     */
    public function on_profile_update(int $user_id): void {
        $user = get_user_by('ID', $user_id);
        
        // Only process customers
        if (!$user || !in_array('customer', $user->roles)) {
            return;
        }

        // Additional customer update logic can be added here
        do_action('vrstore_customer_updated', $user_id, $user);
    }

    /**
     * Get customer statistics
     *
     * @return array
     */
    public function get_customer_stats(): array {
        global $wpdb;

        // Get total customers
        $total_customers = count_users()['avail_roles']['customer'] ?? 0;

        // Get new customers this month
        $current_month = date('Y-m-01');
        $new_customers_query = new WP_User_Query([
            'role' => 'customer',
            'date_query' => [
                [
                    'after' => $current_month,
                    'column' => 'user_registered'
                ]
            ],
            'count_total' => true
        ]);
        $new_customers = $new_customers_query->get_total();

        // Get customers with orders
        $orders_table = $this->db->get_table_name('orders');
        $customers_with_orders = $wpdb->get_var(
            "SELECT COUNT(DISTINCT customer_id) FROM $orders_table WHERE customer_id > 0"
        );

        return [
            'total_customers' => (int) $total_customers,
            'new_customers_this_month' => (int) $new_customers,
            'customers_with_orders' => (int) ($customers_with_orders ?? 0),
            'customers_without_orders' => (int) $total_customers - (int) ($customers_with_orders ?? 0)
        ];
    }

    /**
     * Assign customer role to users who have orders but no customer role
     * This is a utility function to fix existing data
     *
     * @return array Results of the assignment process
     */
    public function assign_customer_roles_to_order_users(): array {
        global $wpdb;
        
        $orders_table = $this->db->get_table_name('orders');
        
        // Check if orders table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$orders_table'") !== $orders_table) {
            return [
                'success' => false,
                'message' => 'Orders table not found',
                'users_updated' => 0
            ];
        }
        
        // Get all unique customer emails from orders
        $customer_emails = $wpdb->get_col(
            "SELECT DISTINCT customer_email FROM $orders_table WHERE customer_email != '' AND customer_email IS NOT NULL"
        );
        
        $users_updated = 0;
        $errors = [];
        
        foreach ($customer_emails as $email) {
            $user = get_user_by('email', $email);
            
            if ($user && !in_array('customer', $user->roles)) {
                $result = $user->add_role('customer');
                if ($result !== false) {
                    $users_updated++;
                } else {
                    $errors[] = sprintf('Failed to assign customer role to user %d (%s)', $user->ID, $email);
                }
            }
        }
        
        return [
            'success' => true,
            'message' => sprintf('Assigned customer role to %d users', $users_updated),
            'users_updated' => $users_updated,
            'errors' => $errors
        ];
    }
}