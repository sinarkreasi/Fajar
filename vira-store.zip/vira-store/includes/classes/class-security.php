<?php
/**
 * Security Class
 *
 * @package Vira_Store
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * VRSTORE_Security Class
 *
 * Handles security best practices throughout the plugin.
 *
 * @since 1.0.0
 */
class VRSTORE_Security {

	/**
	 * Instance of this class.
	 *
	 * @since 1.0.0
	 * @var object
	 */
	protected static $instance = null;

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		// Initialize hooks.
		$this->init_hooks();
	}

	/**
	 * Return an instance of this class.
	 *
	 * @since 1.0.0
	 * @return object A single instance of this class.
	 */
	public static function get_instance() {
		// If the single instance hasn't been set, set it now.
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Get translated text with conditional loading check.
	 *
	 * @since 1.0.0
	 * @param string $text The text to translate.
	 * @return string
	 */
	private function get_translated_text( $text ) {
		if ( vrstore_is_textdomain_ready() ) {
			return esc_html__( $text, 'vira-store' );
		}
		return esc_html( $text );
	}

	/**
	 * Initialize hooks.
	 *
	 * @since 1.0.0
	 */
	private function init_hooks() {
		// Add security headers.
		add_action( 'send_headers', array( $this, 'add_security_headers' ) );

		// Prevent direct access to plugin files.
		add_action( 'template_redirect', array( $this, 'prevent_direct_file_access' ) );

		// Prevent information disclosure in REST API.
		add_filter( 'rest_authentication_errors', array( $this, 'restrict_rest_api' ) );

		// Prevent username enumeration.
		add_action( 'init', array( $this, 'prevent_username_enumeration' ) );

		// Prevent XML-RPC attacks.
		add_filter( 'xmlrpc_enabled', '__return_false' );

		// Disable file editing in admin.
		if ( ! defined( 'DISALLOW_FILE_EDIT' ) ) {
			define( 'DISALLOW_FILE_EDIT', true );
		}
	}

	/**
	 * Add security headers.
	 *
	 * @since 1.0.0
	 */
	public function add_security_headers() {
		// X-XSS-Protection header.
		header( 'X-XSS-Protection: 1; mode=block' );

		// X-Content-Type-Options header.
		header( 'X-Content-Type-Options: nosniff' );

		// X-Frame-Options header.
		header( 'X-Frame-Options: SAMEORIGIN' );

		// Referrer-Policy header.
		header( 'Referrer-Policy: strict-origin-when-cross-origin' );

		// Content-Security-Policy header.
		$csp = "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval' https://www.paypal.com https://www.paypalobjects.com https://www.sandbox.paypal.com https://pay.google.com https://js-agent.newrelic.com https://bam.nr-data.net https://gwk.gopayapi.com https://integration-gwk.gopayapi.com https://gwk.gopayapi.com/sdk/stable/gp-container.min.js; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self' data:; connect-src 'self' https://api.paypal.com https://www.paypal.com https://www.sandbox.paypal.com https://gwk.gopayapi.com https://integration-gwk.gopayapi.com; frame-src 'self' https://www.paypal.com https://www.sandbox.paypal.com https://www.youtube.com https://www.youtube-nocookie.com https://youtube.com https://youtube-nocookie.com; worker-src 'self' blob:; object-src 'none'";
		header( "Content-Security-Policy: $csp" );
	}

	/**
	 * Prevent direct access to plugin files.
	 *
	 * @since 1.0.0
	 */
	public function prevent_direct_file_access() {
		// Check if this is a direct file access attempt.
		if ( isset( $_SERVER['SCRIPT_FILENAME'] ) && strpos( (string)$_SERVER['SCRIPT_FILENAME'], 'vira-store' ) !== false ) {
			$file = basename( ($_SERVER['SCRIPT_FILENAME'] ?? "") );

			// List of files that should not be directly accessed.
			$protected_files = array(
				'viraloka.php',
				'class-product.php',
				'class-license.php',
				'class-api.php',
				'class-settings.php',
				'class-assets.php',
				'class-shortcodes.php',
				'class-payment.php',
				'class-security.php',
			);

			if ( in_array( $file, $protected_files, true ) ) {
				wp_die( esc_html( $this->get_translated_text( 'Direct access to this file is not allowed.' ) ), esc_html( $this->get_translated_text( 'Security Error' ) ), array( 'response' => 403 ) );
			}
		}
	}

	/**
	 * Restrict REST API access to authenticated users only.
	 *
	 * @since 1.0.0
	 * @param WP_Error|null|bool $result Error from another authentication handler, null if no other handler has been applied, or true if authentication succeeded.
	 * @return WP_Error|null|bool
	 */
	public function restrict_rest_api( $result ) {
		// If a previous authentication check was applied, pass that result along.
		if ( true === $result || is_wp_error( $result ) ) {
			return $result;
		}

		// Get REST route.
		$route = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';

		// Allow access to specific endpoints.
		if ( strpos( (string)$route, '/wp/v2/posts' ) !== false || strpos( (string)$route, '/wp/v2/pages' ) !== false ) {
			return $result;
		}

		// Allow access to Vira Store API endpoints.
		if ( strpos( (string)$route, '/vrstore/v1/' ) !== false ) {
			return $result;
		}

		// Restrict access to other endpoints for non-authenticated users.
		if ( ! is_user_logged_in() ) {
			return new WP_Error(
				'rest_not_logged_in',
				$this->get_translated_text( 'You are not currently logged in.' ),
				array( 'status' => 401 )
			);
		}

		return $result;
	}

	/**
	 * Prevent username enumeration.
	 *
	 * @since 1.0.0
	 */
	public function prevent_username_enumeration() {
		// Check if author parameter is set in URL.
		if ( isset( $_GET['author'] ) ) {
			wp_redirect( home_url(), 301 );
			exit;
		}
	}

	/**
	 * Sanitize input data.
	 *
	 * @since 1.0.0
	 * @param mixed  $data    Data to sanitize.
	 * @param string $type    Type of data (text, email, url, int, float, etc.).
	 * @param bool   $allow_html Whether to allow HTML tags.
	 * @return mixed Sanitized data.
	 */
	public static function sanitize_data( $data, $type = 'text', $allow_html = false ) {
		// If data is an array, sanitize each element.
		if ( is_array( $data ) ) {
			foreach ( $data as $key => $value ) {
				$data[ $key ] = self::sanitize_data( $value, $type, $allow_html );
			}
			return $data;
		}

		// Sanitize based on type.
		switch ( $type ) {
			case 'email':
				return sanitize_email( $data );

			case 'url':
				return esc_url_raw( $data );

			case 'int':
				return intval( $data );

			case 'float':
				return floatval( $data );

			case 'key':
				return sanitize_key( $data );

			case 'title':
				return sanitize_title( $data );

			case 'html':
				return wp_kses_post( $data );

			case 'text':
			default:
				if ( $allow_html ) {
					return wp_kses_post( $data );
				} else {
					return sanitize_text_field($data ?? "");
				}
		}
	}

	/**
	 * Validate nonce.
	 *
	 * @since 1.0.0
	 * @param string $nonce   Nonce to validate.
	 * @param string $action  Action name.
	 * @return bool True if nonce is valid, false otherwise.
	 */
	public static function verify_nonce( $nonce, $action ) {
		if ( ! wp_verify_nonce( $nonce, $action ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Check user capabilities.
	 *
	 * @since 1.0.0
	 * @param string $capability Capability to check.
	 * @return bool True if user has capability, false otherwise.
	 */
	public static function check_capability( $capability ) {
		if ( ! current_user_can( $capability ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Generate secure random string.
	 *
	 * @since 1.0.0
	 * @param int    $length  Length of the string.
	 * @param string $chars   Characters to use.
	 * @return string Random string.
	 */
	public static function generate_random_string( $length = 12, $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()' ) {
		$chars_length = strlen( $chars );
		$random_string = '';

		for ( $i = 0; $i < $length; $i++ ) {
			$random_character = $chars[ wp_rand( 0, $chars_length - 1 ) ];
			$random_string .= $random_character;
		}

		return $random_string;
	}

	/**
	 * Hash sensitive data.
	 *
	 * @since 1.0.0
	 * @param string $data Data to hash.
	 * @return string Hashed data.
	 */
	public static function hash_data( $data ) {
		return wp_hash( $data );
	}

	/**
	 * Encrypt sensitive data.
	 *
	 * @since 1.0.0
	 * @param string $data Data to encrypt.
	 * @return string Encrypted data.
	 */
	public static function encrypt_data( $data ) {
		// Get encryption key.
		$key = self::get_encryption_key();

		// Generate initialization vector.
		$iv_size = openssl_cipher_iv_length( 'AES-256-CBC' );
		$iv = openssl_random_pseudo_bytes( $iv_size );

		// Encrypt data.
		$encrypted = openssl_encrypt( $data, 'AES-256-CBC', $key, 0, $iv );

		// Combine IV and encrypted data.
		$encrypted = base64_encode( $iv . $encrypted );

		return $encrypted;
	}

	/**
	 * Decrypt sensitive data.
	 *
	 * @since 1.0.0
	 * @param string $data Encrypted data.
	 * @return string Decrypted data.
	 */
	public static function decrypt_data( $data ) {
		// Get encryption key.
		$key = self::get_encryption_key();

		// Decode data.
		$data = base64_decode( $data );

		// Get initialization vector size.
		$iv_size = openssl_cipher_iv_length( 'AES-256-CBC' );

		// Extract IV and encrypted data.
		$iv = substr((string)($data), 0, $iv_size);
		$encrypted = substr((string)($data), $iv_size);

		// Decrypt data.
		$decrypted = openssl_decrypt( $encrypted, 'AES-256-CBC', $key, 0, $iv );

		return $decrypted;
	}

	/**
	 * Get encryption key.
	 *
	 * @since 1.0.0
	 * @return string Encryption key.
	 */
	private static function get_encryption_key() {
		// Use WordPress auth key as encryption key.
		if ( defined( 'AUTH_KEY' ) ) {
			return AUTH_KEY;
		}

		// Fallback to a default key (not recommended in production).
		return 'vrstore_default_encryption_key';
	}

	/**
	 * Log security events.
	 *
	 * @since 1.0.0
	 * @param string $event   Event description.
	 * @param string $level   Log level (info, warning, error).
	 * @param array  $context Additional context.
	 */
	public static function log_security_event( $event, $level = 'info', $context = array() ) {
		// Always log to error log if WP_DEBUG is enabled
		// Only log to error log if WP_DEBUG is enabled and level is not 'info'
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG && 'info' !== $level ) {
			// Security event would be logged to error log in debug mode
		}
		
		// Check if database logging is enabled.
		if ( get_option( 'vrstore_enable_security_logging', 'no' ) !== 'yes' ) {
			return;
		}

		// Get user IP address.
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';

		// Get user agent.
		$user_agent = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';

		// Get current user ID.
		$user_id = get_current_user_id();

		// Create log entry.
		$log_entry = array(
			'time'       => current_time( 'mysql' ),
			'event'      => $event,
			'level'      => $level,
			'ip'         => $ip,
			'user_agent' => $user_agent,
			'user_id'    => $user_id,
			'context'    => $context,
		);

		// Get existing logs.
		$logs = get_option( 'vrstore_security_logs', array() );

		// Add new log entry.
		$logs[] = $log_entry;

		// Limit logs to 1000 entries.
		if ( count( $logs ) > 1000 ) {
			$logs = array_slice( $logs, -1000 );
		}

		// Save logs.
		update_option( 'vrstore_security_logs', $logs );
	}
}