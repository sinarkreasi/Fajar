<?php
/**
 * PDF Certificate Generator
 *
 * @package ViraStore
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class VRSTORE_PDF_Certificate {
    
    /**
     * Check if user has access to course certificate
     * Supports paid courses, free courses, and free courses with required product purchases
     *
     * @param int $course_id Course ID
     * @param int $user_id User ID
     * @return bool True if user has certificate access
     */
    public function user_has_certificate_access($course_id, $user_id) {
        if (!$user_id || !$course_id) {
            return false;
        }
        
        // Admin always has access
        if (current_user_can('manage_options')) {
            return true;
        }
        
        // Get course data
        $is_free = get_post_meta($course_id, '_vrstore_course_is_free', true);
        $free_with_product = get_post_meta($course_id, '_vrstore_course_free_with_product', true);
        $required_product_id = get_post_meta($course_id, '_vrstore_course_required_product_id', true);
        
        // Check if user is enrolled in the course
        $enrolled_courses = get_user_meta($user_id, '_vrstore_enrolled_courses', true);
        if (!is_array($enrolled_courses)) {
            $enrolled_courses = [];
        }
        
        $is_enrolled = in_array($course_id, $enrolled_courses);
        
        // For free courses
        if ($is_free) {
            return $is_enrolled;
        }
        
        // For free courses with required product purchase
        if ($free_with_product && $required_product_id) {
            // Check if user owns the required product AND is enrolled
            if ($is_enrolled && $this->user_owns_product($user_id, $required_product_id)) {
                return true;
            }
        }
        
        // For paid courses - check enrollment or direct purchase
        if ($is_enrolled) {
            return true;
        }
        
        // Check if user purchased the course directly
        if ($this->user_has_purchased_course($course_id, $user_id)) {
            return true;
        }
        
        return false;
    }

    /**
     * Check if user owns a specific product
     *
     * @param int $user_id User ID
     * @param int $product_id Product ID
     * @return bool True if user owns the product
     */
    private function user_owns_product($user_id, $product_id) {
        if (!$user_id || !$product_id) {
            return false;
        }
        
        // Get user's purchased products
        $purchased_products = get_user_meta($user_id, '_vrstore_purchased_products', true);
        if (!is_array($purchased_products)) {
            $purchased_products = [];
        }
        
        if (in_array($product_id, $purchased_products)) {
            return true;
        }
        
        // Also check via orders table
        global $wpdb;
        $user = get_user_by('ID', $user_id);
        if (!$user) {
            return false;
        }
        
        $orders_table = $wpdb->prefix . 'vrstore_orders';
        
        // Check if orders table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$orders_table'") !== $orders_table) {
            return false;
        }
        
        // Check for completed orders for this product
        $order_count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $orders_table 
             WHERE customer_email = %s 
               AND product_id = %d 
               AND (payment_status = 'completed' OR order_status = 'completed')",
            $user->user_email,
            $product_id
        ));
        
        return $order_count > 0;
    }

    /**
     * Check if user has purchased a course
     *
     * @param int $course_id Course ID
     * @param int $user_id User ID
     * @return bool True if user has purchased the course
     */
    private function user_has_purchased_course($course_id, $user_id) {
        global $wpdb;
        
        $user = get_user_by('ID', $user_id);
        if (!$user) {
            return false;
        }
        
        $orders_table = $wpdb->prefix . 'vrstore_orders';
        
        // Check if orders table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$orders_table'") !== $orders_table) {
            return false;
        }
        
        // Check for completed orders for this course
        $order_count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $orders_table 
             WHERE customer_email = %s 
               AND product_id = %d 
               AND (payment_status = 'completed' OR order_status = 'completed')",
            $user->user_email,
            $course_id
        ));
        
        return $order_count > 0;
    }

    /**
     * Instance of this class
     */
    private static $instance = null;
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        add_action('wp_ajax_vrstore_download_certificate', array($this, 'download_certificate'));
        add_action('wp_ajax_nopriv_vrstore_download_certificate', array($this, 'download_certificate'));
        add_action('wp_ajax_vrstore_secure_certificate_download', array($this, 'handle_secure_certificate_download'));
        add_action('wp_ajax_nopriv_vrstore_secure_certificate_download', array($this, 'handle_secure_certificate_download'));
    }
    
    /**
     * Check if user has completed the course
     *
     * @param int $course_id Course ID
     * @param int $user_id User ID
     * @return bool True if course is completed
     */
    public function is_course_completed($course_id, $user_id) {
        // Get course curriculum
        $curriculum = get_post_meta($course_id, '_vrstore_course_curriculum', true);
        if (empty($curriculum) || !is_array($curriculum)) {
            return false;
        }
        
        // Count total lessons
        $total_lessons = 0;
        foreach ($curriculum as $module) {
            if (!empty($module['lessons']) && is_array($module['lessons'])) {
                $total_lessons += count($module['lessons']);
            }
        }
        
        if ($total_lessons === 0) {
            return false;
        }
        
        // Get completed lessons for this user
        $completed_lessons = get_user_meta($user_id, '_vrstore_completed_lessons_' . $course_id, true);
        if (!is_array($completed_lessons)) {
            $completed_lessons = [];
        }
        
        // Check if all lessons are completed
        return count($completed_lessons) >= $total_lessons;
    }
    
    /**
     * Generate certificate PDF
     *
     * @param int $course_id Course ID
     * @param int $user_id User ID
     * @return string|false PDF content or false on failure
     */
    public function generate_certificate($course_id, $user_id) {
        // Verify course completion
        if (!$this->is_course_completed($course_id, $user_id)) {
            return false;
        }
        
        // Get course and user data
        $course = get_post($course_id);
        $user = get_user_by('ID', $user_id);
        
        if (!$course || !$user) {
            return false;
        }
        
        // Get course data
        $course_data = [];
        if (class_exists('VRSTORE_Course')) {
            $course_instance = VRSTORE_Course::get_instance();
            $course_data = $course_instance->get_course_data($course_id);
        }
        
        $instructor_name = $course_data['instructor']['name'] ?? get_the_author_meta('display_name', $course->post_author);
        $completion_date = get_user_meta($user_id, '_vrstore_course_completion_date_' . $course_id, true);
        
        if (!$completion_date) {
            $completion_date = current_time('mysql');
            update_user_meta($user_id, '_vrstore_course_completion_date_' . $course_id, $completion_date);
        }
        
        // Generate certificate HTML
        $certificate_html = $this->get_certificate_html($course, $user, $instructor_name, $completion_date);
        
        // Convert HTML to PDF using simple HTML/CSS approach
        return $this->html_to_pdf($certificate_html, $course->post_title, $user->display_name);
    }
    
    /**
     * Get certificate HTML template
     *
     * @param WP_Post $course Course post object
     * @param WP_User $user User object
     * @param string $instructor_name Instructor name
     * @param string $completion_date Completion date
     * @return string Certificate HTML
     */
    private function get_certificate_html($course, $user, $instructor_name, $completion_date) {
        $formatted_date = date_i18n('F j, Y', strtotime($completion_date));
        $certificate_id = 'CERT-' . $course->ID . '-' . $user->ID . '-' . date('Ymd', strtotime($completion_date));
        
        // Get signature image if available
        $signature_image_id = get_post_meta($course->ID, '_vrstore_course_signature_image', true);
        $signature_image_url = '';
        if ($signature_image_id) {
            $signature_image_url = wp_get_attachment_image_url($signature_image_id, 'medium');
        }
        
        // Get website logo
        $custom_logo_id = get_theme_mod('custom_logo');
        $logo_url = '';
        if ($custom_logo_id) {
            $logo_url = wp_get_attachment_image_url($custom_logo_id, 'medium');
        }
        
        ob_start();
        ?>
        <!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Certificate of Completion</title>
    <style>
        @page {
            size: A4 landscape;
            margin: 0;
        }
        
        body {
            font-family: 'Georgia', 'Times New Roman', serif;
            margin: 0;
            padding: 40px;
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            color: #333;
            height: 100vh;
            box-sizing: border-box;
        }
        
        .certificate-container {
            background: white;
            border: 8px solid #0073aa;
            border-radius: 20px;
            padding: 60px;
            text-align: center;
            height: calc(100% - 120px);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            position: relative;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        
        .website-logo {
            position: absolute;
            top: 30px;
            left: 30px;
            max-width: 120px;
            max-height: 80px;
            opacity: 0.8;
        }
        
        .certificate-header {
            margin-bottom: 30px;
        }
        
        .certificate-title {
            font-size: 40px;
            font-weight: bold;
            color: #0073aa;
            margin: 0 0 20px 0;
            text-transform: uppercase;
            letter-spacing: 3px;
        }
        
        .certificate-subtitle {
            font-size: 20px;
            color: #666;
            margin: 0;
            font-style: italic;
        }
        
        .certificate-body {
            margin: 40px 0;
            flex: 1; /* Properti ini penting agar body mengambil sisa ruang */
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        
        .recipient-text {
            font-size: 18px;
            color: #555;
            margin-bottom: 20px;
        }
        
        .recipient-name {
            font-size: 37px;
            font-weight: bold;
            color: #0073aa;
            margin: 20px 0;
            border-bottom: 3px solid #0073aa;
            display: inline-block;
            padding-bottom: 10px;
        }
        
        .course-text {
            font-size: 15px;
            color: #555;
            margin: 30px 0 20px 0;
        }
        
        .course-name {
            font-size: 30px;
            font-weight: bold;
            color: #333;
            margin: 20px 0;
            font-style: italic;
        }
        
        .certificate-footer {
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            margin-top: auto; /* Mendorong footer ke bawah */
            padding-top: 90px;
            border-top: 2px solid #e9ecef;
        }
        
        .signature-section {
            text-align: center;
            flex: 1;
        }
        
        .signature-line {
            border-bottom: 2px solid #333;
            width: 200px;
            margin: 0 auto 10px auto;
            height: 40px;
            display: flex;
            align-items: flex-end;
            justify-content: center;
        }
        
        .signature-image {
            max-width: 220px;
            max-height: 80px;
            margin-bottom: 5px;
        }
        
        .signature-label {
            font-size: 14px;
            color: #666;
            font-weight: bold;
        }
        
        .date-section {
            text-align: center;
            flex: 1;
        }
        
        .date-value {
            font-size: 18px;
            font-weight: bold;
            color: #333;
            margin-bottom: 10px;
        }
        
        .certificate-id {
            position: absolute;
            bottom: 20px;
            right: 30px;
            font-size: 12px;
            color: #999;
            font-family: 'Courier New', monospace;
        }
        
        .decorative-border {
            position: absolute;
            top: 20px;
            left: 20px;
            right: 20px;
            bottom: 20px;
            border: 2px solid #e9ecef;
            border-radius: 15px;
            pointer-events: none;
        }
    </style>
</head>
<body>
    <div class="certificate-container">
        <div class="decorative-border"></div>
        
        <?php if ($logo_url): ?>
            <img src="<?php echo esc_url($logo_url); ?>" alt="<?php esc_attr_e('Website Logo', 'vira-store'); ?>" class="website-logo" />
        <?php endif; ?>
        
        <div class="certificate-header">
            <h1 class="certificate-title"><?php esc_html_e('Certificate of Completion', 'vira-store'); ?></h1>
            <p class="certificate-subtitle"><?php esc_html_e('This is to certify that', 'vira-store'); ?></p>
        </div>
        
        <div class="certificate-body">
            <div class="recipient-name">
                <?php
                $first_name = get_user_meta($user->ID, 'first_name', true);
                $last_name = get_user_meta($user->ID, 'last_name', true);
                echo esc_html($first_name . ' ' . $last_name);
                ?>
            </div>
            
            <p class="course-text"><?php esc_html_e('has successfully completed the course', 'vira-store'); ?></p>
            
            <div class="course-name"><?php echo esc_html($course->post_title); ?></div>
        </div>
        <div class="certificate-footer">
            <div class="signature-section">
                <div class="signature-line">
                    <?php if ($signature_image_url): ?>
                        <img src="<?php echo esc_url($signature_image_url); ?>" alt="<?php esc_attr_e('Instructor Signature', 'vira-store'); ?>" class="signature-image" />
                    <?php endif; ?>
                </div>
                <div class="signature-label"><?php echo esc_html($instructor_name); ?><br><?php esc_html_e('Instructor', 'vira-store'); ?></div>
            </div>
            
            <div class="date-section">
                <div class="date-value"><?php echo esc_html($formatted_date); ?></div>
                <div class="signature-label"><?php esc_html_e('Date of Completion', 'vira-store'); ?></div>
            </div>
        </div>
        
        <div class="certificate-id"><?php echo esc_html($certificate_id); ?></div>
    </div>
</body>
</html>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Convert HTML to PDF (simple implementation)
     *
     * @param string $html HTML content
     * @param string $course_title Course title
     * @param string $user_name User name
     * @return string PDF content
     */
    private function html_to_pdf($html, $course_title, $user_name) {
        // For a simple implementation, we'll use browser printing
        // In a production environment, you might want to use a library like TCPDF or mPDF
        
        // Set headers for PDF download
        $filename = sanitize_file_name('certificate-' . $course_title . '-' . $user_name . '.pdf');
        
        // Store the HTML temporarily for conversion
        $temp_file = wp_upload_dir()['basedir'] . '/vrstore-certificates/';
        if (!file_exists($temp_file)) {
            wp_mkdir_p($temp_file);
        }
        
        $html_file = $temp_file . 'cert-' . time() . '.html';
        file_put_contents($html_file, $html);
        
        return $html; // Return HTML for now - can be enhanced with actual PDF library
    }
    
    /**
     * Generate secure certificate download URL
     *
     * @param int $course_id Course ID
     * @param int $user_id User ID
     * @return string|false Secure download URL or false on failure
     */
    public function generate_secure_certificate_url($course_id, $user_id) {
        // Verify course completion
        if (!$this->is_course_completed($course_id, $user_id)) {
            return false;
        }

        // Check if user has access to the course
        if (class_exists('VRSTORE_Course')) {
            $course_instance = VRSTORE_Course::get_instance();
            if (!$course_instance->user_has_course_access($course_id, $user_id)) {
                return false;
            }
        }

        // Generate secure download token using file protection system
        if (class_exists('VRSTORE_File_Protection')) {
            $file_protection = VRSTORE_File_Protection::get_instance();
            
            // Use course ID as "product ID" for certificate downloads
            // File index 999 to distinguish certificates from regular files
            $expires = time() + HOUR_IN_SECONDS; // 1 hour expiration
            $secure_token = $file_protection->generate_download_token(
                $course_id,
                999, // Special index for certificates
                $user_id,
                $expires
            );

            // Create secure download URL
            $secure_url = add_query_arg([
                'vrstore_secure_download' => $secure_token
            ], home_url('/'));

            return $secure_url;
        }

        // Fallback to regular download if file protection not available
        return wp_nonce_url(
            admin_url('admin-ajax.php?action=vrstore_download_certificate&course_id=' . $course_id), 
            'vrstore_download_certificate'
        );
    }

    /**
     * Handle secure certificate download request
     */
    public function handle_secure_certificate_download() {
        // This method is no longer needed as the file protection system
        // handles certificate downloads directly through the special file index 999
        return;
    }

    /**
     * Process secure certificate download
     *
     * @param string $token Download token
     */
    private function process_secure_certificate_download($token) {
        // This method is no longer needed as the file protection system
        // handles certificate downloads directly through the special file index 999
        return;
    }
    public function download_certificate() {
        // Verify nonce - wp_nonce_url() creates '_wpnonce' parameter
        if (!wp_verify_nonce($_GET['_wpnonce'] ?? '', 'vrstore_download_certificate')) {
            wp_die(__('Security check failed.', 'vira-store'));
        }
        
        $course_id = intval($_GET['course_id'] ?? 0);
        $user_id = get_current_user_id();
        
        if (!$course_id || !$user_id) {
            wp_die(__('Invalid request.', 'vira-store'));
        }
        
        // Verify course exists and is published
        $course = get_post($course_id);
        if (!$course || $course->post_type !== 'vrstore_course' || $course->post_status !== 'publish') {
            wp_die(__('Course not found.', 'vira-store'));
        }
        
        // Check if certification is enabled for this course
        $certification_enabled = get_post_meta($course_id, '_vrstore_course_certification', true);
        if (!$certification_enabled) {
            wp_die(__('Certification is not enabled for this course.', 'vira-store'));
        }
        
        // Check if user has access to the course (supports all course types)
        if (!$this->user_has_certificate_access($course_id, $user_id)) {
            wp_die(__('You do not have access to this course certificate.', 'vira-store'));
        }
        
        // Check if course is completed
        if (!$this->is_course_completed($course_id, $user_id)) {
            wp_die(__('Course not completed yet.', 'vira-store'));
        }
        
        // Generate certificate
        $certificate_html = $this->generate_certificate($course_id, $user_id);
        
        if (!$certificate_html) {
            wp_die(__('Failed to generate certificate.', 'vira-store'));
        }
        
        // Get user info for filename
        $user = get_user_by('ID', $user_id);
        $filename = sanitize_file_name('certificate-' . $course->post_title . '-' . $user->display_name . '.html');
        
        // Set headers for download
        header('Content-Type: text/html; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Cache-Control: no-cache, must-revalidate');
        header('Expires: Sat, 26 Jul 1997 05:00:00 GMT');
        
        echo $certificate_html;
        exit;
    }
}

// Initialize the class
VRSTORE_PDF_Certificate::get_instance();