<?php
/**
 * Order management class
 *
 * @package Vira_Store
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Order management class
 */
class VRSTORE_Order {
    /**
     * Singleton instance
     *
     * @var VRSTORE_Order|null
     */
    private static ?VRSTORE_Order $instance = null;

    /**
     * Post type name
     *
     * @var string
     */
    private string $post_type = 'vrstore_order';

    /**
     * Get singleton instance
     *
     * @return VRSTORE_Order
     */
    public static function get_instance(): VRSTORE_Order {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Get translated text with conditional loading check.
     *
     * @since 1.0.0
     * @param string $text The text to translate.
     * @return string
     */
    private function get_translated_text( $text ) {
        if ( vrstore_is_textdomain_ready() ) {
            return esc_html__( $text, 'vira-store' );
        }
        return esc_html( $text );
    }

    /**
     * Constructor
     */
    private function __construct() {
        $this->init();
    }

    /**
     * Initialize the class
     *
     * @return void
     */
    private function init(): void {
        add_action('init', [$this, 'register_post_type']);
    }

    /**
     * Register order post type
     *
     * @return void
     */
    public function register_post_type(): void {
        $args = [
            'label' => $this->get_translated_text('Orders'),
            'labels' => [
                'name' => $this->get_translated_text('Orders'),
                'singular_name' => $this->get_translated_text('Order'),
                'menu_name' => $this->get_translated_text('Orders'),
                'add_new' => $this->get_translated_text('Add New Order'),
                'add_new_item' => $this->get_translated_text('Add New Order'),
                'edit_item' => $this->get_translated_text('Edit Order'),
                'new_item' => $this->get_translated_text('New Order'),
                'view_item' => $this->get_translated_text('View Order'),
                'search_items' => $this->get_translated_text('Search Orders'),
                'not_found' => $this->get_translated_text('No orders found'),
                'not_found_in_trash' => $this->get_translated_text('No orders found in trash'),
            ],
            'public' => false,
            'publicly_queryable' => false,
            'show_ui' => false,
            'show_in_menu' => false,
            'query_var' => false,
            'rewrite' => false,
            'capability_type' => 'post',
            'has_archive' => false,
            'hierarchical' => false,
            'menu_position' => null,
            'supports' => ['title'],
        ];

        register_post_type($this->post_type, $args);
    }

    /**
     * Create a new order
     *
     * @param array $order_data Order data
     * @return int|false Order ID on success, false on failure
     */
    public static function create_order(array $order_data) {
        // Validate required fields
        $required_fields = ['customer_name', 'customer_email', 'payment_method'];
        foreach ($required_fields as $field) {
            if (empty($order_data[$field])) {
                return false;
            }
        }

        // Generate order number
        $order_number = self::generate_order_number();

        // Prepare order title
        $order_title_template = vrstore_is_textdomain_ready() ? __('Order #%s - %s', 'vira-store') : 'Order #%s - %s';
        $order_title = sprintf(
            $order_title_template,
            $order_number,
            sanitize_text_field($order_data['customer_name'])
        );

        // Create order post
        $order_id = wp_insert_post([
            'post_title' => $order_title,
            'post_status' => 'publish',
            'post_type' => 'vrstore_order',
            'post_author' => $order_data['user_id'] ?? 0,
        ]);

        if (!$order_id || is_wp_error($order_id)) {
            return false;
        }

        // Add order number
        update_post_meta($order_id, '_vrstore_order_number', $order_number);

        // Add order data
        $order_meta = [
            '_vrstore_customer_name' => sanitize_text_field($order_data['customer_name']),
            '_vrstore_customer_email' => sanitize_email($order_data['customer_email']),
            '_vrstore_payment_method' => sanitize_text_field($order_data['payment_method']),
            '_vrstore_order_status' => $order_data['status'] ?? 'pending',
            '_vrstore_payment_status' => $order_data['payment_status'] ?? 'pending',
            '_vrstore_currency' => $order_data['currency'] ?? get_option('vrstore_currency', 'USD'),
            '_vrstore_order_total' => floatval($order_data['total'] ?? 0),
            '_vrstore_user_id' => intval($order_data['user_id'] ?? 0),
            '_vrstore_created_at' => current_time('mysql'),
        ];

        // Add optional fields
        if (!empty($order_data['transaction_id'])) {
            $order_meta['_vrstore_transaction_id'] = sanitize_text_field($order_data['transaction_id']);
        }

        if (!empty($order_data['cart_items'])) {
            $order_meta['_vrstore_cart_items'] = $order_data['cart_items'];
        }

        if (!empty($order_data['discount_amount'])) {
            $order_meta['_vrstore_discount_amount'] = floatval($order_data['discount_amount']);
        }

        if (!empty($order_data['coupon_code'])) {
            $order_meta['_vrstore_coupon_code'] = sanitize_text_field($order_data['coupon_code']);
        }

        // Save all meta data
        foreach ($order_meta as $key => $value) {
            update_post_meta($order_id, $key, $value);
        }

        // Trigger action for other plugins to hook into
        do_action('vrstore_order_created', $order_id, $order_data);

        return $order_id;
    }

    /**
     * Generate unique order number
     *
     * @return string
     */
    private static function generate_order_number(): string {
        $prefix = apply_filters('vrstore_order_number_prefix', 'VRSTORE');
        $timestamp = time();
        $random = wp_rand(100, 999);
        
        return $prefix . '-' . $timestamp . '-' . $random;
    }

    /**
     * Create order in database table (alternative to WordPress post)
     *
     * @param array $order_data Order data
     * @return int|false Order ID on success, false on failure
     */
    public static function create_order_in_database(array $order_data) {
        global $wpdb;
        
        // Initialize enhanced security if available
        $security = class_exists('VRSTORE_Enhanced_Security') ? VRSTORE_Enhanced_Security::get_instance() : null;
        
        // Rate limiting check for order creation
        if ($security && !$security->check_rate_limit('order_create')) {
            // Order creation rate limit exceeded
            return false;
        }
        
        // Comprehensive input validation
        $validation_errors = [];
        $required_fields = ['customer_name', 'customer_email', 'payment_method'];
        
        foreach ($required_fields as $field) {
            if (empty($order_data[$field])) {
                $validation_errors[] = "Missing required field: {$field}";
            }
        }
        
        // Enhanced validation with security checks
        if (!empty($order_data['customer_email'])) {
            if ($security) {
                $validated_email = $security->validate_input($order_data['customer_email'], 'email', ['check_disposable' => true]);
                if ($validated_email === false) {
                    $validation_errors[] = 'Invalid or disposable email address';
                } else {
                    $order_data['customer_email'] = $validated_email;
                }
            } else {
                $order_data['customer_email'] = sanitize_email($order_data['customer_email']);
                if (!is_email($order_data['customer_email'])) {
                    $validation_errors[] = 'Invalid email format';
                }
            }
        }
        
        // Validate customer name
        if (!empty($order_data['customer_name'])) {
            if ($security) {
                $validated_name = $security->validate_input($order_data['customer_name'], 'text', ['max_length' => 200]);
                if ($validated_name === false) {
                    $validation_errors[] = 'Invalid customer name';
                } else {
                    $order_data['customer_name'] = $validated_name;
                }
            } else {
                $order_data['customer_name'] = sanitize_text_field($order_data['customer_name']);
            }
        }
        
        // Log validation errors
        if (!empty($validation_errors)) {
            // Order creation validation failed
            if ($security) {
                $security->log_security_event('order_validation_failed', 'warning', [
                    'errors' => $validation_errors,
                    'order_data_keys' => array_keys($order_data)
                ]);
            }
            return false;
        }

        // Generate order number
        $order_number = self::generate_order_number();
        
        // Prepare order data for database insertion
        $orders_table = $wpdb->prefix . 'vrstore_orders';
        
		// Get first cart item for product info (simplified for now)
		$first_item = null;
		if (!empty($order_data['cart_items'])) {
			$first_item = is_array($order_data['cart_items']) ? reset($order_data['cart_items']) : null;
		}
		
		$product_id = $first_item['product_id'] ?? 0;
		$product_price = floatval($order_data['total'] ?? 0);
		
		// Check if this is an Extended Support order
		$is_extended_support_order = false;
		$original_product_id = $product_id; // Store original product_id
		if (isset($first_item['item_type']) && $first_item['item_type'] === 'extended_support') {
			$is_extended_support_order = true;
		}
        
        // Get product name from WordPress post or handle Extended Support products
        $product_name = 'Unknown Product';
        
        if ($is_extended_support_order) {
            // Handle Extended Support products
            $current_license_type = $first_item['license_type'] ?? 'Standard';
            
            // Get months from cart item data (this is the actual purchased quantity)
            $months = isset($first_item['months']) ? intval($first_item['months']) : 1; // Default to 1 month, not 12
            
            // Ensure months is at least 1
            $months = max(1, $months);
            
            $license_type_label = ucfirst(str_replace('-', ' ', $current_license_type));
            
            // Check if we have associated product title in cart item
            $associated_product_title = $first_item['associated_product_title'] ?? '';
            
            // If we have the associated product title, use it; otherwise try to extract from product_name
            if (!empty($associated_product_title)) {
                $product_name = sprintf('%s - Extended Support (%s / %d months)', $associated_product_title, $license_type_label, $months);
            } elseif (!empty($first_item['product_name']) && $first_item['product_name'] !== 'Extended Support') {
                // Use the product name from cart item if it's already descriptive
                $product_name = $first_item['product_name'];
            } else {
                // Fallback to standard format
                $product_name = sprintf('Extended Support (%s / %d months)', $license_type_label, $months);
            }
            
            // Set product_id to 0 for database storage
            $product_id = 0;
        } elseif ($product_id) {
            // Check if this is an Extended Support product (legacy format: extended_support_123)
            if (is_string($product_id) && strpos($product_id, 'extended_support_') === 0) {
                // Extract the actual product ID from the extended support string
                $parts = explode('_', $product_id);
                if (count($parts) >= 3) {
                    $actual_product_id = intval($parts[2]);
                    
                    // Get the associated product title
                    $associated_product_title = '';
                    if ($actual_product_id > 0) {
                        $product_post = get_post($actual_product_id);
                        if ($product_post && $product_post->post_title) {
                            $associated_product_title = $product_post->post_title;
                        }
                    }
                    
                    // Get license type from cart item or use default
                    $current_license_type = $first_item['license_type'] ?? 'Standard';
                    
                    // Get months from cart item data (this is the actual purchased quantity)
                    $months = isset($first_item['months']) ? intval($first_item['months']) : 1; // Default to 1 month, not 12
                    
                    // Ensure months is at least 1
                    $months = max(1, $months);
                    
                    $license_type_label = ucfirst(str_replace('-', ' ', $current_license_type));
                    
                    // Create improved product name with associated product
                    if (!empty($associated_product_title)) {
                        $product_name = sprintf('%s - Extended Support (%s / %d months)', $associated_product_title, $license_type_label, $months);
                    } else {
                        $product_name = sprintf('Extended Support (%s / %d months)', $license_type_label, $months);
                    }
                    
                    $is_extended_support_order = true;
                    $product_id = 0; // Set to 0 for database storage
                } else {
                    $product_name = 'Extended Support';
                    $is_extended_support_order = true;
                    $product_id = 0; // Set to 0 for database storage
                }
            } else {
                // Regular product handling
                $numeric_product_id = is_numeric($product_id) ? intval($product_id) : 0;
                if ($numeric_product_id > 0) {
                    $product_post = get_post($numeric_product_id);
                    if ($product_post && $product_post->post_title !== 'Auto Draft') {
                        $product_name = $product_post->post_title;
                    }
                }
            }
        }
        

        
        // Ensure we have a valid product price - if total is 0, calculate from cart items
        if ($product_price <= 0 && !empty($order_data['cart_items'])) {
            $cart_instance = VRSTORE_Cart::get_instance();
            $calculated_total = 0;
            
            foreach ($order_data['cart_items'] as $item) {
                $item_price = $cart_instance->get_item_price($item);
                $calculated_total += $item_price * ($item['quantity'] ?? 1);
            }
            
            if ($calculated_total > 0) {
                $product_price = $calculated_total;
    
            }
        }
        
        // Get license type information if available
        $license_type = $first_item['license_type'] ?? null;
        $license_type_label = null;
        
        if ($license_type) {
            // Check if it's a custom license type
            if (class_exists('VRSTORE_Settings')) {
                $settings = VRSTORE_Settings::get_instance();
                $custom_license_types = $settings->get_setting('custom_license_types', []);
                
                foreach ($custom_license_types as $custom_type) {
                    // Check both slug and sanitized label for matching (handle format inconsistencies)
                    $custom_slug = $custom_type['slug'] ?? sanitize_title($custom_type['label'] ?? '');
                    $sanitized_label = sanitize_title($custom_type['label'] ?? '');
                    
                    if ($custom_slug === $license_type || $sanitized_label === $license_type) {
                        $license_type_label = $custom_type['label'];
                        // Ensure we're using the proper slug format
                        $license_type = $custom_slug;
                        break;
                    }
                }
                
                // If not found in custom types, use formatted slug as fallback
                if (!$license_type_label) {
                    $license_type_label = ucfirst(str_replace('-', ' ', $license_type));
                }
            }
        }
        
        // Convert Extended Support prices to base currency for consistent admin reporting
        $base_currency = 'USD';
        $stored_price = $product_price;
        $stored_currency = $order_data['currency'] ?? 'USD';
        
        if ($is_extended_support_order) {
            // Get base currency from settings
            if (class_exists('VRSTORE_Settings')) {
                $settings = VRSTORE_Settings::get_instance();
                $base_currency = $settings->get_setting('currency', 'USD');
            }
            
            // Convert Extended Support price to base currency for storage
            if (class_exists('VRSTORE_Currency_Converter') && $stored_currency !== $base_currency) {
                $currency_converter = VRSTORE_Currency_Converter::get_instance();
                
                try {
                    // Get exchange rate directly (bypasses the enabled check in convert_amount)
                    $reflection = new ReflectionClass($currency_converter);
                    $get_rate_method = $reflection->getMethod('get_exchange_rate');
                    $get_rate_method->setAccessible(true);
                    
                    $rate = $get_rate_method->invoke($currency_converter, $stored_currency, $base_currency);
                    $converted_price = round($product_price * $rate, 2);
                    
                    error_log(sprintf(
                        'VR Store Extended Support DB Data: product_price=%s (before conversion), currency=%s (transaction), converted_price=%s (base %s), product_name=%s',
                        $product_price,
                        $stored_currency,
                        $converted_price,
                        $base_currency,
                        $product_name
                    ));
                    
                    // Store converted price in base currency
                    $stored_price = $converted_price;
                    $stored_currency = $base_currency;
                    
                } catch (Exception $e) {
                    // If conversion fails, log warning and store original values
                    error_log(sprintf(
                        'VR Store: Failed to convert Extended Support price from %s to %s: %s',
                        $stored_currency,
                        $base_currency,
                        $e->getMessage()
                    ));
                }
            } else {
                error_log(sprintf(
                    'VR Store Extended Support DB Data: product_price=%s, currency=%s, product_name=%s (no conversion needed)',
                    $product_price,
                    $stored_currency,
                    $product_name
                ));
            }
        }
        
        $db_order_data = [
            'order_number' => $order_number,
            'customer_email' => sanitize_email($order_data['customer_email']),
            'customer_name' => sanitize_text_field($order_data['customer_name']),
            'product_id' => is_string($product_id) && strpos($product_id, 'extended_support_') === 0 ? $product_id : intval($product_id),
            'product_name' => sanitize_text_field($product_name),
            'product_price' => floatval($stored_price),
            'currency' => sanitize_text_field($stored_currency),
            'license_type' => $license_type ? sanitize_text_field($license_type) : null,
            'license_type_label' => $license_type_label ? sanitize_text_field($license_type_label) : null,
            'payment_method' => sanitize_text_field($order_data['payment_method']),
            'payment_status' => sanitize_text_field($order_data['payment_status'] ?? 'pending'),
            'order_status' => sanitize_text_field($order_data['status'] ?? 'pending'),
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql')
        ];
        
        // Add optional fields
        if (!empty($order_data['transaction_id'])) {
            $db_order_data['transaction_id'] = sanitize_text_field($order_data['transaction_id']);
        }
        
        if (!empty($order_data['payment_id'])) {
            $db_order_data['payment_id'] = sanitize_text_field($order_data['payment_id']);
        }
        
        // Add order notes if any
        if (!empty($order_data['order_notes'])) {
            $db_order_data['order_notes'] = sanitize_textarea_field($order_data['order_notes']);
        }
        
        // Database transaction for data integrity
        $wpdb->query('START TRANSACTION');
        
        try {
            // ALLOW UNLIMITED REORDERS: Removed duplicate order check to allow customers to purchase the same product multiple times
            // This makes Vira Store work like WooCommerce where customers can freely reorder any product anytime
            
            // Insert into database
            $format_specs = [
                '%s', // order_number
                '%s', // customer_email  
                '%s', // customer_name
                is_string($product_id) && strpos($product_id, 'extended_support_') === 0 ? '%s' : '%d', // product_id (string for Extended Support, int for regular)
                '%s', // product_name
                '%f', // product_price
                '%s', // currency
                '%s', // license_type
                '%s', // license_type_label
                '%s', // payment_method
                '%s', // payment_status
                '%s', // order_status
                '%s', // created_at
                '%s'  // updated_at
            ];
            
            // Add optional fields format specs
            if (!empty($order_data['transaction_id'])) {
                $format_specs[] = '%s';
            }
            if (!empty($order_data['payment_id'])) {
                $format_specs[] = '%s';
            }
            if (!empty($order_data['order_notes'])) {
                $format_specs[] = '%s';
            }
            
            $result = $wpdb->insert(
                $orders_table,
                $db_order_data,
                $format_specs
            );
            
            if ($result === false) {
                $wpdb->query('ROLLBACK');
                // Database insert failed
                if ($security) {
                    $security->log_security_event('order_creation_db_error', 'error', [
                        'error' => $wpdb->last_error,
                        'order_data' => array_keys($db_order_data)
                    ]);
                }
                return false;
            }
        
            $order_id = $wpdb->insert_id;
            
            // Commit transaction
            $wpdb->query('COMMIT');
            
            // Log successful order creation
            if (defined('WP_DEBUG') && WP_DEBUG) {
                // Order created successfully
            }
            
        } catch (Exception $e) {
            $wpdb->query('ROLLBACK');
            // Exception during order creation
            if ($security) {
                $security->log_security_event('order_creation_exception', 'error', [
                    'exception' => $e->getMessage(),
                    'trace' => $e->getTraceAsString()
                ]);
            }
            return false;
        }
        
		// Create license key immediately for all orders (including pending ones)
		// This ensures license keys are available even for manual payment methods
		$licenses_table = $wpdb->prefix . 'vrstore_licenses';
		$existing_license = null;
		
		// Check if license generation is disabled for this product (only for numeric product IDs)
		$disable_license_generation = false;
		
		if (is_numeric($product_id)) {
			$disable_license_generation = get_post_meta($product_id, '_vrstore_disable_license_generation', true);
		}
		
		// Skip license generation for Extended Support products and products with license generation disabled
		$is_extended_support = $is_extended_support_order;
		
		if ($wpdb->get_var("SHOW TABLES LIKE '$licenses_table'") === $licenses_table && !$disable_license_generation && !$is_extended_support) {
            // ALLOW UNLIMITED REORDERS: Remove duplicate license check to enable customers to purchase multiple licenses
            // This allows existing customers to freely reorder any license type with unlimited quantity
            $existing_license = null; // Force creation of new license every time
            
            // Always generate new license key for every order (unlimited reorders enabled)
            $license_key = '';
            $license_created = false;
            
            if (class_exists('VRSTORE_License')) {
                $license_class = VRSTORE_License::get_instance();
                $license_key = $license_class->generate_license_key();
                
                // Create license in licenses table with proper status based on payment
                $license_status = ($order_data['payment_status'] === 'completed' || $order_data['status'] === 'completed') ? 'active' : 'pending';
                
                // Regular products use the license configuration from the database
                $license_config = $license_class->get_license_type_config(intval($product_id), $license_type ?: '');
                $activation_limit = $license_config['activation_limit'] ?? 1;
                
                // Calculate expiry date based on license type configuration
                $expires_at = '';
                if (isset($license_config['expiry_days']) && $license_config['expiry_days'] > 0) {
                    $expires_at = date('Y-m-d H:i:s', strtotime('+' . $license_config['expiry_days'] . ' days'));
                }
                
                
                $license_data = [
                    'license_key' => $license_key,
                    'product_id' => $product_id,
                    'order_id' => $order_id,
                    'customer_email' => $order_data['customer_email'],
                    'status' => $license_status,
                    'activation_limit' => $activation_limit, // Use proper activation limit from license type config
                    'license_type_slug' => $license_type ?: '', // Pass license type from cart item
                    'expires_at' => $expires_at // Set proper expiry date based on license type
                ];
                
                $license_id = $license_class->create_license($license_data);
                $license_created = ($license_id !== false && !is_wp_error($license_id));
            } else {
                // Fallback license key generation if License class not available
                $license_key = self::generate_license_key();
                $license_created = true; // Assume success for fallback
            }
            
            // Update order with license key
            if ($license_created) {
                $wpdb->update(
                    $orders_table,
                    ['license_key' => $license_key],
                    ['id' => $order_id],
                    ['%s'],
                    ['%d']
                );
            }
            
        }
        
        // Trigger action for other plugins to hook into
        do_action('vrstore_order_created_in_database', $order_id, $order_data);
        
        return $order_id;
    }
    
    /**
     * Generate license key
     *
     * @return string
     */
    private static function generate_license_key(): string {
        return strtoupper(wp_generate_password(24, false, false));
    }

    /**
     * Get order by ID (supports both post meta and database table)
     *
     * @param int $order_id Order ID
     * @return array|false Order data or false if not found
     */
    public static function get_order(int $order_id) {
        global $wpdb;
        $orders_table = $wpdb->prefix . 'vrstore_orders';
        
        // First try to get from database table if it exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$orders_table'") === $orders_table) {
            $order_data = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $orders_table WHERE id = %d",
                $order_id
            ), ARRAY_A);
            
            if ($order_data) {
                // Determine item_type for Extended Support detection
                $item_type = '';
                $product_id = intval($order_data['product_id'] ?? 0);
                if ($product_id === 0 && !empty($order_data['product_name']) && 
                    (strpos($order_data['product_name'], 'Extended Support') !== false)) {
                    $item_type = 'extended_support';
                }
                
                // Convert database result to expected format
                return [
                    'id' => intval($order_data['id']),
                    'order_number' => $order_data['order_number'] ?? '',
                    'customer_name' => $order_data['customer_name'] ?? '',
                    'customer_email' => $order_data['customer_email'] ?? '',
                    'payment_method' => $order_data['payment_method'] ?? '',
                    'order_status' => $order_data['order_status'] ?? 'pending',
                    'payment_status' => $order_data['payment_status'] ?? 'pending',
                    'currency' => $order_data['currency'] ?? 'USD',
                    'total' => floatval($order_data['product_price'] ?? 0),
                    'user_id' => intval($order_data['user_id'] ?? 0),
                    'transaction_id' => $order_data['transaction_id'] ?? '',
                    'product_id' => $product_id, // Essential for license generation
                    'license_type' => $order_data['license_type'] ?? '', // Essential for license generation
                    'item_type' => $item_type, // Essential for Extended Support detection
                    'cart_items' => [], // Database table doesn't store cart items directly
                    'discount_amount' => floatval($order_data['discount_amount'] ?? 0),
                    'coupon_code' => $order_data['coupon_code'] ?? '',
                    'created_at' => $order_data['created_at'] ?? '',
                    'date_created' => $order_data['created_at'] ?? '',
                ];
            }
        }
        
        // Fallback to post meta approach
        $post = get_post($order_id);
        
        if (!$post || $post->post_type !== 'vrstore_order') {
            return false;
        }
        
        // Get cart items to extract product_id, license_type, and item_type if not available in post meta
        $cart_items = get_post_meta($order_id, '_vrstore_cart_items', true);
        $product_id = 0;
        $license_type = '';
        $item_type = '';
        
        if (!empty($cart_items) && is_array($cart_items)) {
            $first_item = reset($cart_items);
            $product_id = intval($first_item['product_id'] ?? 0);
            $license_type = $first_item['license_type'] ?? '';
            $item_type = $first_item['item_type'] ?? '';
        }

        return [
            'id' => $order_id,
            'order_number' => get_post_meta($order_id, '_vrstore_order_number', true),
            'customer_name' => get_post_meta($order_id, '_vrstore_customer_name', true),
            'customer_email' => get_post_meta($order_id, '_vrstore_customer_email', true),
            'payment_method' => get_post_meta($order_id, '_vrstore_payment_method', true),
            'order_status' => get_post_meta($order_id, '_vrstore_order_status', true),
            'payment_status' => get_post_meta($order_id, '_vrstore_payment_status', true),
            'currency' => get_post_meta($order_id, '_vrstore_currency', true),
            'total' => get_post_meta($order_id, '_vrstore_order_total', true),
            'user_id' => get_post_meta($order_id, '_vrstore_user_id', true),
            'transaction_id' => get_post_meta($order_id, '_vrstore_transaction_id', true),
            'product_id' => $product_id, // Essential for license generation
            'license_type' => $license_type, // Essential for license generation  
            'item_type' => $item_type, // Essential for Extended Support detection
            'cart_items' => $cart_items ?: [],
            'discount_amount' => get_post_meta($order_id, '_vrstore_discount_amount', true),
            'coupon_code' => get_post_meta($order_id, '_vrstore_coupon_code', true),
            'created_at' => get_post_meta($order_id, '_vrstore_created_at', true),
            'date_created' => $post->post_date,
        ];
    }

    /**
     * Get order by order number
     *
     * @param string $order_number Order number
     * @return array|false Order data or false if not found
     */
    public static function get_order_by_number(string $order_number) {
        $posts = get_posts([
            'post_type' => 'vrstore_order',
            'post_status' => 'publish',
            'posts_per_page' => 1,
            'meta_query' => [
                [
                    'key' => '_vrstore_order_number',
                    'value' => sanitize_text_field($order_number),
                    'compare' => '='
                ]
            ]
        ]);

        if (empty($posts)) {
            return false;
        }

        return self::get_order($posts[0]->ID);
    }

    /**
     * Update order status (tries both database table and post meta)
     *
     * @param int $order_id Order ID
     * @param string $status New status
     * @return bool
     */
    public static function update_order_status(int $order_id, string $status): bool {
        $valid_statuses = ['pending', 'processing', 'completed', 'cancelled', 'failed'];
        
        if (!in_array($status, $valid_statuses, true)) {
            return false;
        }

        global $wpdb;
        $orders_table = $wpdb->prefix . 'vrstore_orders';
        $updated = false;
        
        // Try updating in database table first
        if ($wpdb->get_var("SHOW TABLES LIKE '$orders_table'") === $orders_table) {
            $result = $wpdb->update(
                $orders_table,
                ['order_status' => $status, 'updated_at' => current_time('mysql')],
                ['id' => $order_id],
                ['%s', '%s'],
                ['%d']
            );
            $updated = ($result !== false);
        }
        
        // Also try updating post meta as fallback
        if (!$updated || get_post($order_id)) {
            $post_updated = update_post_meta($order_id, '_vrstore_order_status', $status);
            $updated = $updated || ($post_updated !== false);
        }
        
        if ($updated) {
            do_action('vrstore_order_status_changed', $order_id, $status);
            
            // Fire order completion hook if status is completed
            if ($status === 'completed') {
                $order_data = self::get_order($order_id);
                if ($order_data) {
                    // Activate any pending licenses for this order
                    self::activate_pending_licenses_for_order($order_id);
                    do_action('vrstore_order_completed', $order_id, $order_data);
                }
            }
        }

        return $updated;
    }

    /**
     * Update payment status (tries both database table and post meta)
     *
     * @param int $order_id Order ID
     * @param string $status New payment status
     * @return bool
     */
    public static function update_payment_status(int $order_id, string $status): bool {
        $valid_statuses = ['pending', 'processing', 'completed', 'failed', 'refunded'];
        
        if (!in_array($status, $valid_statuses, true)) {
            return false;
        }

        global $wpdb;
        $orders_table = $wpdb->prefix . 'vrstore_orders';
        $updated = false;
        
        // Try updating in database table first
        if ($wpdb->get_var("SHOW TABLES LIKE '$orders_table'") === $orders_table) {
            $result = $wpdb->update(
                $orders_table,
                ['payment_status' => $status, 'updated_at' => current_time('mysql')],
                ['id' => $order_id],
                ['%s', '%s'],
                ['%d']
            );
            $updated = ($result !== false);
        }
        
        // Also try updating post meta as fallback
        if (!$updated || get_post($order_id)) {
            $post_updated = update_post_meta($order_id, '_vrstore_payment_status', $status);
            $updated = $updated || ($post_updated !== false);
        }
        
        if ($updated) {
            do_action('vrstore_payment_status_changed', $order_id, $status);
            
            // Fire order completion hook if payment status is completed
            if ($status === 'completed') {
                $order_data = self::get_order($order_id);
                if ($order_data) {
                    // Activate any pending licenses for this order
                    self::activate_pending_licenses_for_order($order_id);
                    do_action('vrstore_order_completed', $order_id, $order_data);
                }
            }
        }

        return $updated;
    }
    
    /**
     * Activate pending licenses for a completed order
     *
     * @param int $order_id Order ID
     * @return int Number of licenses activated
     */
    public static function activate_pending_licenses_for_order(int $order_id): int {
        global $wpdb;
        $licenses_table = $wpdb->prefix . 'vrstore_licenses';
        
        // Check if licenses table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$licenses_table'") !== $licenses_table) {
            return 0;
        }
        
        // Find pending licenses for this order
        $pending_licenses = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $licenses_table WHERE order_id = %d AND status = 'pending'",
            $order_id
        ), ARRAY_A);
        
        if (empty($pending_licenses)) {
            return 0;
        }
        
        $activated_count = 0;
        
        foreach ($pending_licenses as $license) {
            // Update license status to active
            $result = $wpdb->update(
                $licenses_table,
                ['status' => 'active', 'updated_at' => current_time('mysql')],
                ['id' => $license['id']],
                ['%s', '%s'],
                ['%d']
            );
            
            if ($result !== false) {
                $activated_count++;
                
            }
        }
        
        return $activated_count;
    }

    /**
     * Get orders by user ID
     *
     * @param int $user_id User ID
     * @param array $args Additional arguments
     * @return array
     */
    public static function get_user_orders(int $user_id, array $args = []): array {
        $defaults = [
            'posts_per_page' => -1,
            'post_type' => 'vrstore_order',
            'post_status' => 'publish',
            'meta_query' => [
                [
                    'key' => '_vrstore_user_id',
                    'value' => $user_id,
                    'compare' => '='
                ]
            ],
            'orderby' => 'date',
            'order' => 'DESC'
        ];

        $args = wp_parse_args($args, $defaults);
        $posts = get_posts($args);
        
        $orders = [];
        foreach ($posts as $post) {
            $orders[] = self::get_order($post->ID);
        }

        return $orders;
    }

    /**
     * Format order price with currency
     *
     * @param float $price Price
     * @param string $currency Currency code
     * @return string Formatted price
     */
    public static function format_price(float $price, string $currency = 'USD'): string {
        if (class_exists('VRSTORE_Settings')) {
            $settings = VRSTORE_Settings::get_instance();
            return $settings->format_price($price);
        }
        
        // Fallback formatting if settings class is not available
        $currency_symbols = [
            'USD' => '$',
            'EUR' => '€',
            'GBP' => '£',
            'JPY' => '¥',
            'IDR' => 'Rp',
            'AUD' => '$',
            'BRL' => 'R$',
            'CAD' => '$',
            'CNY' => '¥',
            'HKD' => '$',
            'INR' => '₹',
            'MXN' => '$',
            'MYR' => 'RM',
            'NZD' => '$',
            'PHP' => '₱',
            'SGD' => '$',
            'THB' => '฿',
            'VND' => '₫',
            'ZAR' => 'R',
        ];
        
        $symbol = $currency_symbols[$currency] ?? $currency;
        return $symbol . number_format($price, 2);
    }

    /**
     * Get order with formatted price
     *
     * @param int $order_id Order ID
     * @return array|false Order data with formatted price or false if not found
     */
    public static function get_order_with_formatted_price(int $order_id) {
        $order = self::get_order($order_id);
        
        if (!$order) {
            return false;
        }
        
        // Add formatted price
        $currency = $order['currency'] ?: 'USD';
        $total = floatval($order['total'] ?: 0);
        $order['formatted_total'] = self::format_price($total, $currency);
        
        // Add license type information if available in cart items
        if (!empty($order['cart_items']) && is_array($order['cart_items'])) {
            foreach ($order['cart_items'] as &$item) {
                if (!empty($item['license_type'])) {
                    // Get license type label
                    if (class_exists('VRSTORE_Settings')) {
                        $settings = VRSTORE_Settings::get_instance();
                        $custom_license_types = $settings->get_setting('custom_license_types', []);
                        
                        foreach ($custom_license_types as $custom_type) {
                            if (sanitize_title($custom_type['label']) === $item['license_type']) {
                                $item['license_type_label'] = $custom_type['label'];
                                break;
                            }
                        }
                        
                        // If not found in custom types, use formatted slug as fallback
                        if (empty($item['license_type_label'])) {
                            $item['license_type_label'] = ucfirst(str_replace('-', ' ', $item['license_type']));
                        }
                    }
                }
                
                // Format item price
                if (isset($item['price'])) {
                    $item['formatted_price'] = self::format_price(floatval($item['price']), $currency);
                }
            }
        }
        
        return $order;
    }

    /**
     * Get orders with formatted prices
     *
     * @param array $args Query arguments
     * @return array Orders with formatted prices
     */
    public static function get_orders_with_formatted_prices(array $args = []): array {
        $defaults = [
            'posts_per_page' => 20,
            'post_type' => 'vrstore_order',
            'post_status' => 'publish',
            'orderby' => 'date',
            'order' => 'DESC'
        ];

        $args = wp_parse_args($args, $defaults);
        $posts = get_posts($args);
        
        $orders = [];
        foreach ($posts as $post) {
            $order = self::get_order_with_formatted_price($post->ID);
            if ($order) {
                $orders[] = $order;
            }
        }

        return $orders;
    }
    
    /**
     * Fix completed orders that are missing licenses
     *
     * @since 1.0.0
     * @return int Number of orders fixed
     */
    public static function fix_missing_licenses(): int {
        global $wpdb;
        $orders_table = $wpdb->prefix . 'vrstore_orders';
        $licenses_table = $wpdb->prefix . 'vrstore_licenses';
        
        // Check if tables exist
        if ($wpdb->get_var("SHOW TABLES LIKE '$orders_table'") !== $orders_table) {
            return 0;
        }
        
        if ($wpdb->get_var("SHOW TABLES LIKE '$licenses_table'") !== $licenses_table) {
            return 0;
        }
        
        // Find completed orders without license keys
        $orders_without_licenses = $wpdb->get_results(
            "SELECT * FROM $orders_table 
             WHERE (payment_status = 'completed' OR order_status = 'completed') 
             AND (license_key IS NULL OR license_key = '')
             ORDER BY created_at DESC",
            ARRAY_A
        );
        
        $fixed_count = 0;
        
        foreach ($orders_without_licenses as $order) {
            // Check if license already exists in licenses table for this order
            $existing_license = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $licenses_table WHERE order_id = %d",
                $order['id']
            ));
            
            // If no direct order match, check for existing license with same customer, product, and license type
            if (!$existing_license) {
                $order_license_type = $order['license_type'] ?: '';
                if (!empty($order_license_type)) {
                    $existing_license = $wpdb->get_row($wpdb->prepare(
                        "SELECT * FROM $licenses_table WHERE customer_email = %s AND product_id = %d AND license_type_slug = %s AND status = 'active'",
                        $order['customer_email'],
                        $order['product_id'],
                        $order_license_type
                    ));
                } else {
                    $existing_license = $wpdb->get_row($wpdb->prepare(
                        "SELECT * FROM $licenses_table WHERE customer_email = %s AND product_id = %d AND (license_type_slug IS NULL OR license_type_slug = '') AND status = 'active'",
                        $order['customer_email'],
                        $order['product_id']
                    ));
                }
            }
            
            if ($existing_license) {
                // Update order with existing license key
                $wpdb->update(
                    $orders_table,
                    ['license_key' => $existing_license->license_key],
                    ['id' => $order['id']],
                    ['%s'],
                    ['%d']
                );
                $fixed_count++;
            } else {
                // Generate new license
                if (class_exists('VRSTORE_License')) {
                    $license_class = VRSTORE_License::get_instance();
                    $license_key = $license_class->generate_license_key();
                    
                    // Get proper activation limit based on license type
                    $license_config = $license_class->get_license_type_config($order['product_id'], $order['license_type'] ?: '');
                    $activation_limit = $license_config['activation_limit'] ?? 1;
                    
                    // Create license in licenses table
                    $license_data = [
                        'license_key' => $license_key,
                        'product_id' => $order['product_id'],
                        'order_id' => $order['id'],
                        'customer_email' => $order['customer_email'],
                        'status' => 'active',
                        'activation_limit' => $activation_limit, // Use proper activation limit from license type
                        'license_type_slug' => $order['license_type'] ?: '' // Include license type from order
                    ];
                    
                    $license_id = $license_class->create_license($license_data);
                    
                    if ($license_id && !is_wp_error($license_id)) {
                        // Update order with license key
                        $wpdb->update(
                            $orders_table,
                            ['license_key' => $license_key],
                            ['id' => $order['id']],
                            ['%s'],
                            ['%d']
                        );
                        $fixed_count++;
                        

                    }
                }
            }
        }
        
        return $fixed_count;
    }
    
    /**
     * Migrate existing licenses to populate missing license_type_slug from their associated orders
     *
     * @since 1.0.0
     * @return int Number of licenses updated
     */
    public static function migrate_license_type_slugs(): int {
        global $wpdb;
        $orders_table = $wpdb->prefix . 'vrstore_orders';
        $licenses_table = $wpdb->prefix . 'vrstore_licenses';
        
        // Check if tables exist
        if ($wpdb->get_var("SHOW TABLES LIKE '$orders_table'") !== $orders_table) {
            return 0;
        }
        
        if ($wpdb->get_var("SHOW TABLES LIKE '$licenses_table'") !== $licenses_table) {
            return 0;
        }
        
        // Find licenses without license_type_slug that have an associated order
        $licenses_needing_migration = $wpdb->get_results(
            "SELECT l.*, o.license_type 
             FROM $licenses_table l 
             LEFT JOIN $orders_table o ON l.order_id = o.id 
             WHERE (l.license_type_slug IS NULL OR l.license_type_slug = '') 
             AND o.license_type IS NOT NULL 
             AND o.license_type != ''",
            ARRAY_A
        );
        
        $updated_count = 0;
        
        foreach ($licenses_needing_migration as $license) {
            // Update the license with the license type from its order
            $result = $wpdb->update(
                $licenses_table,
                ['license_type_slug' => $license['license_type']],
                ['id' => $license['id']],
                ['%s'],
                ['%d']
            );
            
            if ($result !== false) {
                $updated_count++;
                

            }
        }
        
        return $updated_count;
    }
    
    /**
     * Manually complete an order (useful for admin)
     * This will update both payment and order status to completed and activate licenses
     *
     * @since 1.0.0
     * @param int $order_id Order ID
     * @return array Result with success status and message
     */
    public static function manually_complete_order(int $order_id): array {
        // Update payment status to completed
        $payment_updated = self::update_payment_status($order_id, 'completed');
        
        // Update order status to completed  
        $order_updated = self::update_order_status($order_id, 'completed');
        
        if ($payment_updated || $order_updated) {
            // Activate any pending licenses
            $licenses_activated = self::activate_pending_licenses_for_order($order_id);
            
            return [
                'success' => true,
                'message' => sprintf(
                    'Order #%d has been manually completed. %d license(s) activated.',
                    $order_id,
                    $licenses_activated
                ),
                'licenses_activated' => $licenses_activated
            ];
        }
        
        return [
            'success' => false, 
            'message' => 'Failed to complete order #' . $order_id,
            'licenses_activated' => 0
        ];
    }
    
    /**
     * Complete pending manual payment orders
     * 
     * This method finds orders with manual payment method that are still pending
     * and marks them as completed, triggering license generation.
     *
     * @since 1.0.0
     * @param bool $auto_complete Whether to auto-complete all pending manual orders
     * @return int Number of orders completed
     */
    public static function complete_pending_manual_orders(bool $auto_complete = false): int {
        global $wpdb;
        $orders_table = $wpdb->prefix . 'vrstore_orders';
        
        // Check if table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$orders_table'") !== $orders_table) {
            return 0;
        }
        
        // Find pending manual payment orders
        $pending_manual_orders = $wpdb->get_results(
            "SELECT * FROM $orders_table 
             WHERE payment_method = 'manual' 
             AND payment_status = 'pending' 
             AND order_status = 'pending'
             ORDER BY created_at ASC",
            ARRAY_A
        );
        
        $completed_count = 0;
        
        foreach ($pending_manual_orders as $order) {
            if ($auto_complete) {
                // Automatically complete the order
                $payment_updated = self::update_payment_status($order['id'], 'completed');
                $order_updated = self::update_order_status($order['id'], 'completed');
                
                if ($payment_updated || $order_updated) {
                    $completed_count++;
                    

                }
            }
        }
        
        return $completed_count;
    }
    
    /**
     * Get pending manual payment orders for admin review
     *
     * @since 1.0.0
     * @return array Pending manual orders
     */
    public static function get_pending_manual_orders(): array {
        global $wpdb;
        $orders_table = $wpdb->prefix . 'vrstore_orders';
        
        // Check if table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$orders_table'") !== $orders_table) {
            return [];
        }
        
        // Find pending manual payment orders
        $pending_orders = $wpdb->get_results(
            "SELECT * FROM $orders_table 
             WHERE payment_method = 'manual' 
             AND payment_status = 'pending' 
             AND order_status = 'pending'
             ORDER BY created_at ASC",
            ARRAY_A
        );
        
        return $pending_orders;
    }
}
