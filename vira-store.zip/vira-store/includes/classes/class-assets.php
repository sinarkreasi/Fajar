<?php
/**
 * Assets Manager Class
 *
 * @package Vira_Store
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * VRSTORE_Assets Class
 *
 * This class handles all asset loading for the plugin.
 *
 * @since 1.0.0
 */
class VRSTORE_Assets {

	/**
	 * Instance of this class.
	 *
	 * @since 1.0.0
	 * @var object
	 */
	protected static $instance = null;

	/**
	 * Return an instance of this class.
	 *
	 * @since 1.0.0
	 * @return object A single instance of this class.
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Get translated text with conditional loading check.
	 *
	 * @since 1.0.0
	 * @param string $text The text to translate.
	 * @return string
	 */
	private function get_translated_text( $text ) {
		if ( vrstore_is_textdomain_ready() ) {
			return esc_html__( $text, 'vira-store' );
		}
		return esc_html( $text );
	}

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		// Register hooks.
		add_action( 'admin_enqueue_scripts', array( $this, 'register_admin_assets' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'register_frontend_assets' ) );
	}

	/**
	 * Register and enqueue admin-specific styles and scripts.
	 *
	 * @since 1.0.0
	 * @param string $hook Current admin page hook.
	 */
	public function register_admin_assets( $hook ) {
		// Register admin styles.
		wp_register_style(
			'vrstore-admin',
			VRSTORE_PLUGIN_URL . 'assets/css/admin.css',
			array(),
			VRSTORE_VERSION
		);

		// Register admin scripts.
		wp_register_script(
			'vrstore-admin',
			VRSTORE_PLUGIN_URL . 'assets/js/admin.js',
			array( 'jquery', 'wp-color-picker', 'jquery-ui-sortable', 'media-upload' ),
			VRSTORE_VERSION,
			true
		);

		// Check if current page is a plugin page
		$is_vrstore_page = $this->is_vrstore_admin_page( $hook );

		// Also check for simple hook pattern - if hook contains 'vrstore' anywhere
		$is_vrstore_hook = ( strpos( $hook, 'vrstore' ) !== false );

		// Enhanced detection: Check multiple conditions for plugin pages
		$should_enqueue = (
			$is_vrstore_page || 
			$is_vrstore_hook || 
			( isset( $_GET['page'] ) && strpos( $_GET['page'], 'vrstore' ) !== false ) ||
			( $hook && strpos( $hook, 'vira-store' ) !== false )
		);

		// Only enqueue on ViraStore pages
		if ( $should_enqueue ) {
			wp_enqueue_style( 'wp-color-picker' );
			wp_enqueue_style( 'vrstore-admin' );
			wp_enqueue_script( 'vrstore-admin' );

			// Localize admin script AFTER enqueuing
			$localize_data = array(
				'ajax_url'                => admin_url( 'admin-ajax.php' ),
				'nonce'                  => wp_create_nonce( 'vrstore_admin_nonce' ),
				'file_upload_title'      => $this->get_translated_text( 'Select File' ),
				'file_upload_button'     => $this->get_translated_text( 'Use This File' ),
				'remove_file'            => $this->get_translated_text( 'Remove' ),
				'generating'             => $this->get_translated_text( 'Generating...' ),
				'generate_key'           => $this->get_translated_text( 'Generate Key' ),
				'ajax_error'             => $this->get_translated_text( 'An error occurred. Please try again.' ),
				'confirm_reset'          => $this->get_translated_text( 'Are you sure you want to reset all settings to default? This cannot be undone.' ),
				'loading'                => $this->get_translated_text( 'Loading...' ),
				'confirm_delete'         => $this->get_translated_text( 'Are you sure you want to delete this license? This action cannot be undone.' ),
				'error_email_required'   => $this->get_translated_text( 'Customer email is required.' ),
				'generating_text'        => $this->get_translated_text( 'Generating...' ),
				'license_generated'      => $this->get_translated_text( 'License generated successfully!' ),
				'license_key_label'      => $this->get_translated_text( 'License Key:' ),
				'error_label'            => $this->get_translated_text( 'Error:' ),
				'error_generating'       => $this->get_translated_text( 'Error generating license. Please try again.' ),
				'error_loading_details'  => $this->get_translated_text( 'Error loading license details.' ),
				// License type management strings
				'licenseTypeLabel'       => $this->get_translated_text( 'License Type Label' ),
				'regularPrice'           => $this->get_translated_text( 'Regular Price' ),
				'salePrice'              => $this->get_translated_text( 'Sale Price' ),
				'expirationMonths'       => $this->get_translated_text( 'Expiration (months)' ),
				'maxActivations'         => $this->get_translated_text( 'Max Activations' ),
				'remove'                 => $this->get_translated_text( 'Remove' ),
				'noLicenseTypesConfigured' => $this->get_translated_text( 'No license types configured yet. Add license types above to see the preview.' ),
				'repairDatabaseConfirm'   => $this->get_translated_text( 'Are you sure you want to repair the database? This will recreate missing tables.' ),
				'nonce'                   => wp_create_nonce( 'vrstore_admin_nonce' ),
			);
			
			wp_localize_script(
				'vrstore-admin',
				'vrstore_admin',
				$localize_data
			);

			// Enqueue Chart.js for reports page
			if ( $hook === 'vira-store_page_vrstore-reports' ) {
				wp_enqueue_script(
					'chartjs',
					'https://cdn.jsdelivr.net/npm/chart.js',
					array(),
					'4.4.0',
					true
				);
			}

			// Enqueue admin menu JavaScript (depends on admin.js)
			wp_enqueue_script(
				'vrstore-admin-menu',
				VRSTORE_PLUGIN_URL . 'assets/js/admin-menu.js',
				array( 'jquery', 'vrstore-admin' ),
				VRSTORE_VERSION,
				true
			);
			
			// Enqueue customer-add.js specifically for customer add page
			if ( isset( $_GET['page'] ) && $_GET['page'] === 'vrstore-customers' && isset( $_GET['action'] ) && $_GET['action'] === 'add' ) {
				wp_enqueue_script(
					'vrstore-customer-add',
					VRSTORE_PLUGIN_URL . 'assets/js/customer-add.js',
					array( 'jquery' ),
					VRSTORE_VERSION,
					true
				);
				
				// Localize script with translation strings
				wp_localize_script(
					'vrstore-customer-add',
					'vrstore_customer_add',
					array(
						'password_mismatch' => $this->get_translated_text( 'Passwords do not match. Please check and try again.' ),
						'password_length'   => $this->get_translated_text( 'Password must be at least 6 characters long.' ),
					)
				);
			}
			
			// Enqueue admin-support.js specifically for customers page
			if ( isset( $_GET['page'] ) && $_GET['page'] === 'vrstore-customers' ) {
				wp_enqueue_script(
					'vrstore-admin-support',
					VRSTORE_PLUGIN_URL . 'assets/js/admin-support.js',
					array( 'jquery', 'vrstore-admin' ),
					VRSTORE_VERSION,
					true
				);
			}
		}

		// Always load on dashboard for widget
		if ( 'index.php' === $hook ) {
			wp_enqueue_style( 'vrstore-admin' );
			wp_enqueue_script( 'vrstore-admin' );
			
			// Localize script for dashboard widget
			wp_localize_script(
				'vrstore-admin',
				'vrstore_admin',
				array(
					'ajax_url' => admin_url( 'admin-ajax.php' ),
					'nonce'   => wp_create_nonce( 'vrstore_admin_nonce' ),
				)
			);
		}
	}

	/**
	 * Register and enqueue frontend-specific styles and scripts.
	 *
	 * @since 1.0.0
	 */
	public function register_frontend_assets() {
		// Register frontend styles.
		wp_register_style(
			'vrstore-frontend',
			VRSTORE_PLUGIN_URL . 'assets/css/frontend.css',
			array(),
			VRSTORE_VERSION
		);

		// Register coupon styles.
		wp_register_style(
			'vrstore-coupon',
			VRSTORE_PLUGIN_URL . 'assets/css/coupon-styles.css',
			array( 'vrstore-frontend' ),
			VRSTORE_VERSION
		);

		// Register frontend scripts.
		wp_register_script(
			'vrstore-frontend',
			VRSTORE_PLUGIN_URL . 'assets/js/frontend.js',
			array( 'jquery' ),
			VRSTORE_VERSION,
			true
		);

		// Register frontend enhanced scripts.
		wp_register_script(
			'vrstore-frontend-enhanced',
			VRSTORE_PLUGIN_URL . 'assets/js/frontend-enhanced.js',
			array( 'jquery', 'vrstore-frontend' ),
			VRSTORE_VERSION,
			true
		);

		// Frontend support CSS styles have been merged into frontend.css

		// Register simple downloads script - GUARANTEED TO WORK
		wp_register_script(
			'vrstore-downloads-simple',
			VRSTORE_PLUGIN_URL . 'assets/js/downloads-simple.js',
			array( 'jquery' ),
			VRSTORE_VERSION,
			true
		);

		// Register domain management script.
		wp_register_script(
			'vrstore-domain-management',
			VRSTORE_PLUGIN_URL . 'assets/js/domain-management.js',
			array( 'jquery' ),
			VRSTORE_VERSION,
			true
		);

		// Register coupon script.
		wp_register_script(
			'vrstore-coupon-checkout',
			VRSTORE_PLUGIN_URL . 'assets/js/coupon-checkout.js',
			array( 'jquery', 'vrstore-frontend' ),
			VRSTORE_VERSION,
			true
		);

		// Register TriPay checkout script.
		wp_register_script(
			'vrstore-tripay-checkout',
			VRSTORE_PLUGIN_URL . 'assets/js/tripay-checkout.js',
			array( 'jquery', 'vrstore-frontend' ),
			VRSTORE_VERSION,
			true
		);

		// Register TriPay AJAX script.
		wp_register_script(
			'vrstore-tripay-ajax',
			VRSTORE_PLUGIN_URL . 'assets/js/tripay-ajax.js',
			array( 'jquery' ),
			VRSTORE_VERSION,
			true
		);

		// Register Google Login script.
		wp_register_script(
			'vrstore-google-login',
			VRSTORE_PLUGIN_URL . 'assets/js/google.js',
			array( 'jquery' ),
			VRSTORE_VERSION,
			true
		);

		// Get currency settings
		$settings = VRSTORE_Settings::get_instance();
		
		// Localize frontend script.
		wp_localize_script(
			'vrstore-frontend',
			'vrstore_frontend',
			array(
				'ajax_url'             => admin_url( 'admin-ajax.php' ),
				'nonce'               => wp_create_nonce( 'vrstore_frontend_nonce' ),
				'adding_to_cart'       => $this->get_translated_text( 'Adding...' ),
				'redirecting'          => $this->get_translated_text( 'Redirecting...' ),
				'ajax_error'           => $this->get_translated_text( 'An error occurred. Please try again.' ),
				'required_field'       => $this->get_translated_text( 'This field is required.' ),
				'invalid_email'        => $this->get_translated_text( 'Please enter a valid email address.' ),
				'license_key_required' => $this->get_translated_text( 'Please enter a license key.' ),
				'activating'           => $this->get_translated_text( 'Activating...' ),
				'activate'             => $this->get_translated_text( 'Activate' ),
				'deactivating'         => $this->get_translated_text( 'Deactivating...' ),
				'deactivate'           => $this->get_translated_text( 'Deactivate' ),
				'confirm_remove'       => $this->get_translated_text( 'Are you sure you want to remove this item from your cart?' ),
				'confirm_remove_specific' => $this->get_translated_text( 'Are you sure you want to remove "%s" from your cart?' ),
				'removing'             => $this->get_translated_text( 'Removing...' ),
				'remove'               => $this->get_translated_text( 'Remove' ),
				'item_removed'         => $this->get_translated_text( 'Item removed from cart' ),
				'cart_empty'           => $this->get_translated_text( 'Your cart is empty.' ),
				'cart_empty_title'     => $this->get_translated_text( 'Your cart is empty' ),
				'cart_empty_message'   => $this->get_translated_text( 'Add some products to get started!' ),
				'continue_shopping'    => $this->get_translated_text( 'Continue Shopping' ),
				'shop_url'             => home_url( '/' ),
				// Bulk Actions
				'select_items'          => $this->get_translated_text( 'Please select items to perform bulk action' ),
				'confirm_bulk_remove'   => $this->get_translated_text( 'Are you sure you want to remove %d selected items?' ),
				'bulk_removing'         => $this->get_translated_text( 'Removing selected items...' ),
				'bulk_removed'          => $this->get_translated_text( '%d items removed from cart' ),
				'bulk_saved'            => $this->get_translated_text( '%d items saved for later' ),
				'apply'                 => $this->get_translated_text( 'Apply' ),
				// Save for Later
				'save_for_later'        => $this->get_translated_text( 'Save for Later' ),
				'saving'                => $this->get_translated_text( 'Saving...' ),
				'saved_for_later'       => $this->get_translated_text( 'Item saved for later' ),
				'confirm_save_later'    => $this->get_translated_text( 'Save "%s" for later?' ),
				'error_saving_items'    => $this->get_translated_text( 'Error saving items' ),
				'bulk_items_saved'      => $this->get_translated_text( 'Selected items saved for later' ),
				// Quantity Validation
				'qty_min_error'         => $this->get_translated_text( 'Minimum quantity is %d' ),
				'qty_max_error'         => $this->get_translated_text( 'Maximum quantity is %d' ),
				'qty_invalid'           => $this->get_translated_text( 'Please enter a valid quantity' ),
				'qty_updating'          => $this->get_translated_text( 'Updating quantity...' ),
				'qty_updated'           => $this->get_translated_text( 'Quantity updated' ),
				// Currency settings
				'currency'             => $settings->get_setting( 'currency', 'USD' ),
				'currency_position'    => $settings->get_setting( 'currency_position', 'left' ),
				'currency_symbol'      => VRSTORE_Product::get_currency_symbol( $settings->get_setting( 'currency', 'USD' ) ),
				'decimal_number'       => $settings->get_setting( 'decimal_number', '2' ),
				'decimal_separator'    => $settings->get_setting( 'decimal_separator', '.' ),
				'thousand_separator'   => $settings->get_setting( 'thousand_separator', ',' ),
			)
		);

		// Localize domain management script.
		wp_localize_script(
			'vrstore-domain-management',
			'vrstore_domain_strings',
			array(
				'domain_required'      => $this->get_translated_text( 'Please enter a domain name.' ),
				'domain_invalid'       => $this->get_translated_text( 'Please enter a valid domain name.' ),
				'activation_success'   => $this->get_translated_text( 'Domain activated successfully!' ),
				'deactivation_success' => $this->get_translated_text( 'Domain deactivated successfully!' ),
				'activation_error'     => $this->get_translated_text( 'Failed to activate domain. Please try again.' ),
				'deactivation_error'   => $this->get_translated_text( 'Failed to deactivate domain. Please try again.' ),
				'refresh_error'        => $this->get_translated_text( 'Failed to refresh domains. Please try again.' ),
				'limit_reached'        => $this->get_translated_text( 'Activation limit reached. Please deactivate a domain first.' ),
				'confirm_deactivation' => $this->get_translated_text( 'Are you sure you want to deactivate this domain?' ),
				'processing'           => $this->get_translated_text( 'Processing...' ),
				'network_error'        => $this->get_translated_text( 'Network error. Please check your connection and try again.' ),
			)
		);

		// Localize downloads simple script with AJAX data
		wp_localize_script(
			'vrstore-downloads-simple',
			'vrstore_ajax',
			array(
				'url'    => admin_url( 'admin-ajax.php' ),
				'nonce'  => wp_create_nonce( 'vrstore_frontend_nonce' )
			)
		);

		// Localize domain management script with AJAX data
		wp_localize_script(
			'vrstore-domain-management',
			'vrstore_ajax',
			array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'vrstore_frontend_nonce' ),
				'customer_id' => $this->get_current_customer_id()
			)
		);

		// Only enqueue on plugin pages.
		if ( $this->is_vrstore_page() ) {
			wp_enqueue_style( 'dashicons' );
			wp_enqueue_style( 'vrstore-frontend' );
			wp_enqueue_style( 'vrstore-coupon' );
			wp_enqueue_style( 'vrstore-frontend-cart-product' );

			wp_enqueue_script( 'vrstore-frontend' );
			wp_enqueue_script( 'vrstore-frontend-enhanced' );
			wp_enqueue_script( 'vrstore-downloads-simple' );
			wp_enqueue_script( 'vrstore-domain-management' );
			wp_enqueue_script( 'vrstore-coupon-checkout' );
			wp_enqueue_script( 'vrstore-tripay-checkout' );
			wp_enqueue_script( 'vrstore-google-login' );
		}
	}

	/**
	 * Check if current admin page is a plugin page.
	 *
	 * @since 1.0.0
	 * @param string $hook Current admin page hook.
	 * @return bool True if current page is a plugin admin page, false otherwise.
	 */
	private function is_vrstore_admin_page( $hook ) {
		// Main plugin pages
		$plugin_pages = array(
			'toplevel_page_vrstore-dashboard',
			'vira-store_page_vrstore-licenses',
			'vira-store_page_vrstore-coupons',
			'vira-store_page_vrstore-domain-activations',
			'vira-store_page_vrstore-orders',
			'vira-store_page_vrstore-customers',
			'vira-store_page_vrstore-reports',
			'vira-store_page_vrstore-settings-page',
		);

		// Check main plugin pages
		if ( in_array( $hook, $plugin_pages, true ) ) {
			return true;
		}

		// Check post type pages
		global $post_type, $pagenow;
		
		if ( in_array( $pagenow, array( 'post.php', 'post-new.php', 'edit.php' ), true ) ) {
			if ( in_array( $post_type, array( 'vrstore_product', 'vrstore_course' ), true ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Check if current page is a plugin page.
	 *
	 * @since 1.0.0
	 * @return bool True if current page is a plugin page, false otherwise.
	 */
	private function is_vrstore_page() {
		// Check if shortcode is used on page.
		global $post;

		if ( is_singular() && is_a( $post, 'WP_Post' ) ) {
			// Check for shortcodes in content.
			if ( has_shortcode( $post->post_content, 'vrstore_products' ) ||
				has_shortcode( $post->post_content, 'vrstore_product' ) ||
				has_shortcode( $post->post_content, 'vrstore_course' ) ||
				has_shortcode( $post->post_content, 'vrstore_courses' ) ||
				has_shortcode( $post->post_content, 'vrstore_checkout' ) ||
				has_shortcode( $post->post_content, 'vrstore_account' ) ||
				has_shortcode( $post->post_content, 'vrstore_cart' ) ||
				has_shortcode( $post->post_content, 'vrstore_license' ) ||
				has_shortcode( $post->post_content, 'vrstore_thank_you' ) ) {
				return true;
			}
		}

		// Check for plugin pages.
		$vrstore_pages = array(
			get_option( 'vrstore_products_page' ),
			get_option( 'vrstore_checkout_page' ),
			get_option( 'vrstore_account_page' ),
			get_option( 'vrstore_thank_you_page' ),
		);

		if ( is_page( $vrstore_pages ) ) {
			return true;
		}

		// Check for single product page.
		if ( is_singular( 'vrstore_product' ) ) {
			return true;
		}
		
		// Check for single course page.
		if ( is_singular( 'vrstore_course' ) ) {
			return true;
		}

		return false;
	}
	
	/**
	 * Get current customer ID for logged-in user
	 *
	 * @since 1.0.0
	 * @return int Customer ID or 0 if not found
	 */
	private function get_current_customer_id() {
		if (!is_user_logged_in()) {
			return 0;
		}
		
		$user = wp_get_current_user();
		if (!$user) {
			return 0;
		}
		
		// Try to get customer by email
		global $wpdb;
		$db = VRSTORE_Database::get_instance();
		$customers_table = $db->get_table_name('customers');
		
		$customer = $wpdb->get_row($wpdb->prepare(
			"SELECT id FROM $customers_table WHERE email = %s",
			$user->user_email
		), ARRAY_A);
		
		return $customer ? (int)$customer['id'] : 0;
	}

}

// Initialize the Assets class.
VRSTORE_Assets::get_instance();
