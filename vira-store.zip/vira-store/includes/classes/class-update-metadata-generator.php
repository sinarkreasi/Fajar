<?php
/**
 * Static Update Metadata Generator
 * 
 * Generates static JSON files for plugin update metadata
 * These files can be served directly from CDN/R2 without PHP execution
 *
 * @package Vira_Store
 * @since 2.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * VRSTORE_Update_Metadata_Generator Class
 *
 * Generates and manages static JSON metadata files for plugin updates.
 *
 * @since 2.0.0
 */
class VRSTORE_Update_Metadata_Generator {

    /**
     * Instance of this class.
     *
     * @since 2.0.0
     * @var VRSTORE_Update_Metadata_Generator|null
     */
    private static ?VRSTORE_Update_Metadata_Generator $instance = null;

    /**
     * Get instance of this class.
     *
     * @since 2.0.0
     * @return VRSTORE_Update_Metadata_Generator
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Constructor.
     *
     * @since 2.0.0
     */
    private function __construct() {
        // Generate metadata when plugin version is published/updated
        add_action( 'save_post', array( $this, 'maybe_regenerate_metadata' ), 20, 2 );
        add_action( 'vrstore_plugin_version_published', array( $this, 'regenerate_metadata_for_product' ), 10, 1 );
    }

    /**
     * Check if we should regenerate metadata
     *
     * @since 2.0.0
     * @param int $post_id Post ID
     * @param WP_Post $post Post object
     * @return void
     */
    public function maybe_regenerate_metadata( $post_id, $post ) {
        // Only process product posts
        if ( $post->post_type !== 'vrstore_product' ) {
            return;
        }

        // Only regenerate on publish/update
        if ( $post->post_status !== 'publish' ) {
            return;
        }

        // Regenerate metadata for this product
        $this->regenerate_metadata_for_product( $post_id );
    }

    /**
     * Regenerate metadata for a specific product
     *
     * @since 2.0.0
     * @param int $product_id Product ID
     * @return bool Success
     */
    public function regenerate_metadata_for_product( $product_id ) {
        global $wpdb;

        // Get plugin slug
        $plugin_slug = get_post_meta( $product_id, '_vrstore_plugin_slug', true );
        if ( empty( $plugin_slug ) ) {
            return false;
        }

        // Get all versions for this product
        $versions_table = $wpdb->prefix . 'vrstore_plugin_versions';
        $versions = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM $versions_table WHERE product_id = %d ORDER BY version DESC",
            $product_id
        ), ARRAY_A );

        if ( empty( $versions ) ) {
            return false;
        }

        // Organize versions by license tier
        $versions_by_tier = array();
        foreach ( $versions as $version ) {
            $tier = $version['license_tier'] ?? 'basic';
            if ( ! isset( $versions_by_tier[ $tier ] ) ) {
                $versions_by_tier[ $tier ] = $version;
            }
        }

        // Build metadata structure
        $metadata = array(
            'plugin_slug' => $plugin_slug,
            'product_id' => $product_id,
            'last_updated' => current_time( 'c' ),
            'versions' => array(),
        );

        foreach ( $versions_by_tier as $tier => $version ) {
            $metadata['versions'][ $tier ] = array(
                'id' => $version['id'],
                'version' => $version['version'],
                'released_at' => $version['created_at'],
                'changelog' => $version['changelog'] ?? '',
                'file_size' => isset( $version['file_size'] ) ? intval( $version['file_size'] ) : 0,
                'file_hash' => $version['file_hash'] ?? '',
                'tested' => $version['tested'] ?? get_bloginfo( 'version' ),
                'requires_php' => $version['requires_php'] ?? '8.2',
                'compatibility' => array(
                    'wordpress' => $version['tested'] ?? '6.0+',
                    'php' => $version['requires_php'] ?? '8.2+',
                ),
            );
        }

        // Generate signature (optional, for security)
        $signature = $this->generate_signature( $metadata );
        $metadata['signature'] = $signature;

        // Save to local file
        $saved = $this->save_metadata_file( $plugin_slug, $metadata );

        // Upload to R2 if configured
        if ( $saved ) {
            $this->upload_to_r2( $plugin_slug, $metadata );
        }

        return $saved;
    }

    /**
     * Save metadata to local file
     *
     * @since 2.0.0
     * @param string $plugin_slug Plugin slug
     * @param array $metadata Metadata array
     * @return bool Success
     */
    private function save_metadata_file( $plugin_slug, $metadata ) {
        $upload_dir = wp_upload_dir();
        $base_dir = $upload_dir['basedir'] . '/vrstore-updates';
        $plugin_dir = $base_dir . '/' . $plugin_slug;

        // Create directories if they don't exist
        if ( ! file_exists( $base_dir ) ) {
            wp_mkdir_p( $base_dir );
        }
        if ( ! file_exists( $plugin_dir ) ) {
            wp_mkdir_p( $plugin_dir );
        }

        $file_path = $plugin_dir . '/versions.json';
        $json = wp_json_encode( $metadata, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );

        $result = file_put_contents( $file_path, $json );

        if ( $result !== false ) {
            // Set proper permissions
            chmod( $file_path, 0644 );
            return true;
        }

        return false;
    }

    /**
     * Upload metadata to R2 storage
     *
     * @since 2.0.0
     * @param string $plugin_slug Plugin slug
     * @param array $metadata Metadata array
     * @return bool Success
     */
    private function upload_to_r2( $plugin_slug, $metadata ) {
        // Check if R2 is configured
        $settings = get_option( 'vrstore_settings', array() );
        $r2_enabled = isset( $settings['r2_enabled'] ) && $settings['r2_enabled'] === 'on';
        
        if ( ! $r2_enabled ) {
            return false;
        }

        // Get R2 credentials
        $r2_account_id = $settings['r2_account_id'] ?? '';
        $r2_access_key = $settings['r2_access_key'] ?? '';
        $r2_secret_key = $settings['r2_secret_key'] ?? '';
        $r2_bucket = $settings['r2_bucket'] ?? '';

        if ( empty( $r2_account_id ) || empty( $r2_access_key ) || empty( $r2_secret_key ) || empty( $r2_bucket ) ) {
            return false;
        }

        // Use WordPress HTTP API with R2 S3-compatible endpoint
        $endpoint = sprintf( 'https://%s.r2.cloudflarestorage.com', $r2_account_id );
        $object_key = 'updates/' . $plugin_slug . '/versions.json';
        $url = $endpoint . '/' . $r2_bucket . '/' . $object_key;

        $json = wp_json_encode( $metadata, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );

        // Generate AWS signature v4 for R2
        $date = gmdate( 'Ymd\THis\Z' );
        $date_short = gmdate( 'Ymd' );
        $region = 'auto'; // R2 uses 'auto' as region

        $canonical_request = $this->build_canonical_request( 'PUT', '/' . $r2_bucket . '/' . $object_key, '', $date, $json );
        $string_to_sign = $this->build_string_to_sign( $date, $date_short, $region, $canonical_request );
        $signature = $this->calculate_signature( $r2_secret_key, $date_short, $region, $string_to_sign );
        $authorization = $this->build_authorization_header( $r2_access_key, $date_short, $region, $signature );

        $response = wp_remote_request( $url, array(
            'method' => 'PUT',
            'headers' => array(
                'Authorization' => $authorization,
                'Date' => $date,
                'Content-Type' => 'application/json',
                'Content-Length' => strlen( $json ),
            ),
            'body' => $json,
            'timeout' => 30,
        ) );

        return ! is_wp_error( $response ) && wp_remote_retrieve_response_code( $response ) === 200;
    }

    /**
     * Build canonical request for AWS signature
     *
     * @since 2.0.0
     * @param string $method HTTP method
     * @param string $uri URI path
     * @param string $query_string Query string
     * @param string $date Date header
     * @param string $payload Request body
     * @return string
     */
    private function build_canonical_request( $method, $uri, $query_string, $date, $payload ) {
        $canonical_headers = "host:{$_SERVER['HTTP_HOST']}\ndate:{$date}\n";
        $signed_headers = 'host;date';
        $payload_hash = hash( 'sha256', $payload );

        return implode( "\n", array(
            $method,
            $uri,
            $query_string,
            $canonical_headers,
            $signed_headers,
            $payload_hash,
        ) );
    }

    /**
     * Build string to sign
     *
     * @since 2.0.0
     * @param string $date Date
     * @param string $date_short Short date
     * @param string $region Region
     * @param string $canonical_request Canonical request
     * @return string
     */
    private function build_string_to_sign( $date, $date_short, $region, $canonical_request ) {
        $algorithm = 'AWS4-HMAC-SHA256';
        $credential_scope = $date_short . '/' . $region . '/s3/aws4_request';
        $canonical_request_hash = hash( 'sha256', $canonical_request );

        return implode( "\n", array(
            $algorithm,
            $date,
            $credential_scope,
            $canonical_request_hash,
        ) );
    }

    /**
     * Calculate signature
     *
     * @since 2.0.0
     * @param string $secret_key Secret key
     * @param string $date_short Short date
     * @param string $region Region
     * @param string $string_to_sign String to sign
     * @return string
     */
    private function calculate_signature( $secret_key, $date_short, $region, $string_to_sign ) {
        $k_date = hash_hmac( 'sha256', $date_short, 'AWS4' . $secret_key, true );
        $k_region = hash_hmac( 'sha256', $region, $k_date, true );
        $k_service = hash_hmac( 'sha256', 's3', $k_region, true );
        $k_signing = hash_hmac( 'sha256', 'aws4_request', $k_service, true );

        return hash_hmac( 'sha256', $string_to_sign, $k_signing );
    }

    /**
     * Build authorization header
     *
     * @since 2.0.0
     * @param string $access_key Access key
     * @param string $date_short Short date
     * @param string $region Region
     * @param string $signature Signature
     * @return string
     */
    private function build_authorization_header( $access_key, $date_short, $region, $signature ) {
        $credential_scope = $date_short . '/' . $region . '/s3/aws4_request';
        return sprintf(
            'AWS4-HMAC-SHA256 Credential=%s/%s, SignedHeaders=host;date, Signature=%s',
            $access_key,
            $credential_scope,
            $signature
        );
    }

    /**
     * Generate signature for metadata (HMAC-SHA256)
     *
     * @since 2.0.0
     * @param array $metadata Metadata array
     * @return string
     */
    private function generate_signature( $metadata ) {
        $secret = get_option( 'vrstore_metadata_secret', wp_generate_password( 64, true, true ) );
        if ( empty( get_option( 'vrstore_metadata_secret' ) ) ) {
            update_option( 'vrstore_metadata_secret', $secret );
        }

        // Remove signature from data before signing
        $data_to_sign = $metadata;
        unset( $data_to_sign['signature'] );
        $json = wp_json_encode( $data_to_sign, JSON_UNESCAPED_SLASHES );

        return 'hmac-sha256:' . hash_hmac( 'sha256', $json, $secret );
    }

    /**
     * Verify metadata signature
     *
     * @since 2.0.0
     * @param array $metadata Metadata array
     * @return bool
     */
    public function verify_signature( $metadata ) {
        if ( ! isset( $metadata['signature'] ) ) {
            return false;
        }

        $provided_signature = $metadata['signature'];
        $calculated_signature = $this->generate_signature( $metadata );

        return hash_equals( $calculated_signature, $provided_signature );
    }

    /**
     * Regenerate all metadata files
     *
     * @since 2.0.0
     * @return int Number of files generated
     */
    public function regenerate_all_metadata() {
        global $wpdb;

        // Get all products with plugin slugs
        $products = $wpdb->get_results(
            "SELECT p.ID, pm.meta_value as plugin_slug
             FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
             WHERE p.post_type = 'vrstore_product'
             AND p.post_status = 'publish'
             AND pm.meta_key = '_vrstore_plugin_slug'
             AND pm.meta_value != ''"
        );

        $count = 0;
        foreach ( $products as $product ) {
            if ( $this->regenerate_metadata_for_product( $product->ID ) ) {
                $count++;
            }
        }

        return $count;
    }
}

// Initialize the generator
VRSTORE_Update_Metadata_Generator::get_instance();

