<?php
/**
 * Plugin Name: Vira Store
 * Plugin URI: https://viraloka.com/pro/vira-store
 * Description: Simple digital download with license generation, monitoring domain and download, REST API, and customizable features.
 * Version: 1.0.1
 * Author: Viraloka
 * Author URI: https://viraloka.com
 * Text Domain: vira-store
 * Domain Path: /languages
 * Requires at least: 6.0
 * Requires PHP: 8.2
 * WC requires at least: 7.0 (Optional)
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('VRSTORE_VERSION', '1.0.1');
define('VRSTORE_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('VRSTORE_PLUGIN_URL', plugin_dir_url(__FILE__));
define('VRSTORE_PLUGIN_BASENAME', plugin_basename(__FILE__));
define('VRSTORE_PLUGIN_FILE', __FILE__);

// Define development environment detection
// Only enable debug info in development environments with explicit checks
define('VRSTORE_DEV_DEBUG', 
    defined('WP_DEBUG') && WP_DEBUG && 
    defined('WP_ENVIRONMENT_TYPE') && in_array(WP_ENVIRONMENT_TYPE, ['development', 'local', 'staging']) &&
    current_user_can('manage_options')
);

/**
 * Main plugin class
 */
final class Vira_Store {
    /**
     * Singleton instance
     *
     * @var Vira_Store|null
     */
    private static ?Vira_Store $instance = null;

    /**
     * Plugin settings
     *
     * @var array
     */
    private array $settings;

    /**
     * Get singleton instance
     *
     * @return Vira_Store
     */
    public static function get_instance(): Vira_Store {
        if (null === self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        // Load plugin dependencies
        $this->load_dependencies();

        // Initialize hooks
        $this->init_hooks();

        // Load settings
        $this->load_settings();
    }

    /**
     * Load plugin dependencies
     *
     * @return void
     */
    private function load_dependencies(): void {
        // Include main plugin file
        require_once VRSTORE_PLUGIN_DIR . 'includes/viraloka.php';

        // Include admin files
        $admin_files = [
            'init-taxonomy-terms.php',
            'class-tripay-test-admin.php',
        ];
        
        foreach ($admin_files as $file) {
            $file_path = VRSTORE_PLUGIN_DIR . 'includes/admin/' . $file;
            if (file_exists($file_path)) {
                require_once $file_path;
            }
        }

        // Include database class
        require_once VRSTORE_PLUGIN_DIR . 'includes/class-database.php';
        
        // Include session manager first to ensure it's available for other classes
        require_once VRSTORE_PLUGIN_DIR . 'includes/classes/class-session-manager.php';
        
        // Initialize session manager only when appropriate (not during wp-cron, admin, etc.)
        if (class_exists('VRSTORE_Session_Manager')) {
            VRSTORE_Session_Manager::get_instance_if_needed();
        }
        
        // Include class files
        $class_files = [
            'class-product.php',
            'class-course.php',
            'class-license.php',
            'class-api.php',
            'class-settings.php',
            'class-assets.php',
            'class-cart.php',
            'class-shortcodes.php',
            'class-license-integration.php',
            'woo.php',
            'class-payment.php',
            'class-security.php',
            'class-file-protection.php',
            'class-admin-menu.php',
            'class-coupon.php',
            'class-domain-monitor.php',
            'class-order.php',
            'class-checkout.php',
            'class-customer.php',
            'class-litespeed-integration.php',
            'class-login-redirect.php',
            'class-invoice.php',
            'class-email-confirmation.php',
            'class-support-email-notifications.php',
            'class-disposable-email-detector.php',
            'class-enhanced-security.php',
            'class-error-handler.php',
            'class-currency-converter.php',
            'class-login-attempts.php',
            'class-compatibility.php',
            'class-affiliate.php',
            'class-content-restriction.php',
            'class-taxonomy-restriction.php',

        ];

        foreach ($class_files as $file) {
            $file_path = VRSTORE_PLUGIN_DIR . 'includes/classes/' . $file;
            if (file_exists($file_path)) {
                require_once $file_path;
            }
        }
        
        // Include course pricing fix
        $fix_file = VRSTORE_PLUGIN_DIR . 'course-pricing-fix.php';
        if (file_exists($fix_file)) {
            require_once $fix_file;
        }
        
        // Include debug files for development and admin access
        if (current_user_can('manage_options')) {
            $debug_file = VRSTORE_PLUGIN_DIR . 'debug/debug-bitly.php';
            if (file_exists($debug_file)) {
                require_once $debug_file;
            }
        }
        
        // Admin test migration page removed - no longer needed
    }

    /**
     * Initialize hooks
     *
     * @return void
     */
    private function init_hooks(): void {
        // Register activation hook
        register_activation_hook(__FILE__, [$this, 'activate']);

        // Register deactivation hook
        register_deactivation_hook(__FILE__, [$this, 'deactivate']);

        // Load plugin textdomain on init to avoid early translation loading
        add_action('init', [$this, 'load_textdomain'], 5);
        
        // Initialize post types and core components early on init
        add_action('init', [$this, 'init_post_types'], 8);

        // Initialize plugin
        add_action('init', [$this, 'init_plugin'], 10);

        // Initialize remaining components after init to ensure post types are registered and text domain is loaded
        add_action('wp_loaded', [$this, 'init_components'], 5);
        
        // Handle template redirects
        add_action('template_redirect', [$this, 'handle_template_redirects']);
        
        // Handle file downloads
        add_action('init', [$this, 'handle_file_downloads']);
        
        // Add security headers for video embedding
        add_action('wp_head', [$this, 'add_video_security_headers']);
        
        // Hide admin bar for customer role users
        add_action('wp_loaded', [$this, 'hide_admin_bar_for_customers']);
    }

    /**
     * Load plugin textdomain.
     *
     * @return void
     */
    public function load_textdomain(): void {
        load_plugin_textdomain('vira-store', false, dirname(VRSTORE_PLUGIN_BASENAME) . '/languages');
        // Set a flag to indicate textdomain is loaded to avoid is_textdomain_loaded() calls
        if (!defined('VRSTORE_TEXTDOMAIN_LOADED')) {
            define('VRSTORE_TEXTDOMAIN_LOADED', true);
        }
    }

    /**
     * Check if textdomain is loaded without triggering WordPress.org API calls.
     *
     * @return bool
     */
    public static function is_textdomain_ready(): bool {
        return defined('VRSTORE_TEXTDOMAIN_LOADED') && VRSTORE_TEXTDOMAIN_LOADED;
    }

    /**
     * Load plugin settings
     *
     * @return void
     */
    private function load_settings(): void {
        $this->settings = get_option('vrstore_settings', []);
    }

    /**
     * Plugin activation
     *
     * @return void
     */
    public function activate(): void {
        // Clear any previous installation failure flags
        delete_option('vrstore_db_install_failed');
        delete_transient('vrstore_auto_repair_attempted');
        
        // Initialize plugin components to register post types
        
        // Ensure database class is available
        if (!class_exists('VRSTORE_Database')) {
            update_option('vrstore_db_install_failed', true);
            return;
        }
        
        // Create necessary database tables with retry mechanism
        $db = VRSTORE_Database::get_instance();
        $max_retries = 3;
        $retry_count = 0;
        $installation_success = false;
        
        while ($retry_count < $max_retries && !$installation_success) {
            $retry_count++;
            
            // Wait a moment between retries (except first attempt)
            if ($retry_count > 1) {
                sleep(1);
            }
            
            $result = $db->install_database();
            
            if ($result) {
                $installation_success = true;
            } else {
                // Check if it's the last attempt
                if ($retry_count >= $max_retries) {
                    update_option('vrstore_db_install_failed', true);
                    // Don't return here, continue with other setup tasks
                }
            }
        }
        
        // Verify table creation even if install_database returned true
        $missing_tables = $db->get_missing_tables();
        if (!empty($missing_tables)) {
            update_option('vrstore_db_install_failed', true);
        }
        
        // Initialize default settings
        $default_settings = [
            'license_prefix' => 'VRST-',
            'api_namespace' => 'vrstore/v1',
            'enable_woocommerce' => false,
            'enable_licensing' => true,
            'enable_downloads' => true,
            'enable_api' => true,
            'enable_coupons' => true,
            'enable_domain_monitor' => false,
            'store_name' => get_bloginfo('name'),
            'currency' => 'USD',
            'currency_symbol' => '$',
            'currency_position' => 'left',
            'thousand_separator' => ',',
            'decimal_separator' => '.',
            'decimal_number' => 2,
            'product_permalink_slug' => 'digital-product',
        ];

        // Only set default settings if they don't exist
        if (!get_option('vrstore_settings', "")) {
            update_option('vrstore_settings', $default_settings);
        }

        // Create customer user role
        $this->create_customer_role();

        // Initialize post types during activation to ensure they exist for rewrite rules
        $this->init_post_types();

        // Reset lesson rewrite rules flag to ensure they get flushed
        delete_option('vrstore_lesson_rewrite_flushed');
        
        // Flush rewrite rules after registering post types
        flush_rewrite_rules();
        
        // Plugin activation completed
    }

    /**
     * Plugin deactivation
     *
     * @return void
     */
    public function deactivate(): void {
        // Clean up if necessary
        flush_rewrite_rules();
    }

    /**
     * Safe translation helper that checks if textdomain is loaded
     *
     * @param string $text Text to translate
     * @param string $domain Text domain
     * @return string Translated text or original text if domain not loaded
     */
    private function get_safe_translation(string $text, string $domain = 'vira-store'): string {
        if (is_textdomain_loaded($domain)) {
            return esc_html__($text, $domain);
        }
        return esc_html($text);
    }

    /**
     * Create customer user role
     *
     * @return void
     */
    private function create_customer_role(): void {
        // Check if customer role already exists
        $customer_role = get_role('customer');
        
        if (!$customer_role) {
            // Add customer role with capabilities based on Subscriber but with additional permissions
            $subscriber_role = get_role('subscriber');
            $customer_capabilities = $subscriber_role ? $subscriber_role->capabilities : [];
            
            // Add basic customer capabilities
            $customer_capabilities = array_merge($customer_capabilities, [
                'read' => true,
                'view_vrstore_orders' => true,
                'download_vrstore_products' => true,
                'manage_vrstore_licenses' => true,
                'edit_posts' => false,
                'delete_posts' => false,
                'publish_posts' => false,
                'upload_files' => false,
                'moderate_comments' => false,
            ]);
            
            $customer_role = add_role(
                'customer',
                $this->get_safe_translation('Customer'),
                $customer_capabilities
            );
            
            // Customer role creation attempted
        } else {
            // Role exists, but let's ensure it has the necessary capabilities
            $customer_role->add_cap('view_vrstore_orders');
            $customer_role->add_cap('download_vrstore_products');
            $customer_role->add_cap('manage_vrstore_licenses');
            
            // Customer role capabilities updated
        }
        
        // Ensure the role is properly saved by flushing capabilities
        if (function_exists('wp_roles')) {
            wp_roles()->for_site();
        }
    }

    /**
     * Ensure customer role exists and has correct capabilities
     * This runs on every init to guarantee role availability
     *
     * @return void
     */
    private function ensure_customer_role(): void {
        $customer_role = get_role('customer');
        
        if (!$customer_role) {
            // Role doesn't exist, create it
            $this->create_customer_role();
        } else {
            // Role exists, but ensure it has necessary ViraStore capabilities
            $required_caps = [
                'view_vrstore_orders',
                'download_vrstore_products', 
                'manage_vrstore_licenses'
            ];
            
            $caps_added = false;
            foreach ($required_caps as $cap) {
                if (!$customer_role->has_cap($cap)) {
                    $customer_role->add_cap($cap);
                    $caps_added = true;
                }
            }
            
            // Reinit roles if we added capabilities
            if ($caps_added) {
                if (function_exists('wp_roles')) {
                    wp_roles()->for_site();
                }
            }
        }
    }

    /**
     * Initialize post types early
     *
     * @return void
     */
    public function init_post_types(): void {
        // Initialize product post type first to ensure it's available
        if (class_exists('VRSTORE_Product')) {
            VRSTORE_Product::get_instance();
        }
        
        // Initialize course post type
        if (class_exists('VRSTORE_Course')) {
            VRSTORE_Course::get_instance();
        }
        
        // Initialize order post type
        if (class_exists('VRSTORE_Order')) {
            VRSTORE_Order::get_instance();
        }
    }

    /**
     * Initialize plugin
     *
     * @return void
     */
    public function init_plugin(): void {
        // Ensure customer role exists (check on every init)
        $this->ensure_customer_role();

        // Check for database installation issues
        $this->check_database_status();

        // Check if WooCommerce is active if integration is enabled
        if ($this->get_setting('enable_woocommerce', false) && !class_exists('WooCommerce')) {
            add_action('admin_notices', function() {
                // Use safe translation that checks if textdomain is loaded
                $notice = vrstore_is_textdomain_ready() ? 
                    esc_html__('Vira Store requires WooCommerce to be installed and activated for WooCommerce integration.', 'vira-store') :
                    esc_html('Vira Store requires WooCommerce to be installed and activated for WooCommerce integration.');
                echo '<div class="error"><p>' . $notice . '</p></div>';
            });
            return;
        }
    }

    /**
     * Initialize plugin components
     *
     * @return void
     */
    public function init_components(): void {
        // Initialize error handler first for comprehensive logging
        if (class_exists('VRSTORE_Error_Handler')) {
            VRSTORE_Error_Handler::get_instance();
        }
        
        // Initialize enhanced security early
        if (class_exists('VRSTORE_Enhanced_Security')) {
            VRSTORE_Enhanced_Security::get_instance();
        }
               
        // Initialize database first
        if (class_exists('VRSTORE_Database')) {
            VRSTORE_Database::get_instance();
        }
        
        // Note: Product and Order post types are already initialized in init_post_types()
        
        // Initialize Viraloka core components
        if (class_exists('Viraloka')) {
            Viraloka::get_instance();
        }
        
        // Initialize license management
        if (class_exists('VRSTORE_License')) {
            VRSTORE_License::get_instance();
        }
        
        // Initialize API endpoints
        if (class_exists('VRSTORE_API')) {
            add_action('rest_api_init', function() {
                VRSTORE_API::get_instance()->register_routes();
            });
        }
        
        // Initialize settings
        if (class_exists('VRSTORE_Settings')) {
            VRSTORE_Settings::get_instance();
        }
        
        // Initialize assets
        if (class_exists('VRSTORE_Assets')) {
            VRSTORE_Assets::get_instance();
        }
        
        // Initialize LiteSpeed Cache integration
        if (class_exists('VRSTORE_LiteSpeed_Integration')) {
            VRSTORE_LiteSpeed_Integration::get_instance();
        }
        
        // Initialize cart (must be before shortcodes to ensure proper AJAX handlers)
        if (class_exists('VRSTORE_Cart')) {
            VRSTORE_Cart::get_instance();
        }
        
        // Initialize payment gateways
        if (class_exists('VRSTORE_Payment')) {
            VRSTORE_Payment::get_instance();
        }
        
        // Initialize Midtrans gateway
        if (class_exists('VRSTORE_Midtrans_Gateway')) {
            VRSTORE_Midtrans_Gateway::get_instance();
        }
        
        // Initialize shortcodes
        if (class_exists('VRSTORE_Shortcodes')) {
            VRSTORE_Shortcodes::get_instance();
        }
        
        // Initialize security
        if (class_exists('VRSTORE_Security')) {
            VRSTORE_Security::get_instance();
        }
        
        // Initialize file protection
        if (class_exists('VRSTORE_File_Protection')) {
            VRSTORE_File_Protection::get_instance();
        }
        
        // Initialize admin menu
        if (class_exists('VRSTORE_Admin_Menu') && is_admin()) {
            VRSTORE_Admin_Menu::get_instance();
        }
        
        // Initialize TriPay test admin page
        if (class_exists('VRSTORE_TriPay_Test_Admin') && is_admin()) {
            VRSTORE_TriPay_Test_Admin::get_instance();
        }
        
        // Initialize coupon management
        if (class_exists('VRSTORE_Coupon')) {
            VRSTORE_Coupon::get_instance();
        }
        
        // Initialize domain monitoring
        if (class_exists('VRSTORE_Domain_Monitor')) {
            VRSTORE_Domain_Monitor::get_instance();
        }
        
        // Initialize checkout processing
        if (class_exists('VRSTORE_Checkout')) {
            VRSTORE_Checkout::get_instance();
        }
        
        // Initialize customer management
        if (class_exists('VRSTORE_Customer')) {
            VRSTORE_Customer::get_instance();
        }
        
        // Initialize login redirect functionality
        if (class_exists('VRSTORE_Login_Redirect')) {
            VRSTORE_Login_Redirect::get_instance();
        }
        
        // Initialize invoice functionality
        if (class_exists('VRSTORE_Invoice')) {
            VRSTORE_Invoice::get_instance();
        }
        
        // Initialize email confirmation functionality
        if (class_exists('VRSTORE_Email_Confirmation')) {
            VRSTORE_Email_Confirmation::get_instance();
        }
        
        // Initialize support email notifications
        if (class_exists('VRSTORE_Support_Email_Notifications')) {
            VRSTORE_Support_Email_Notifications::get_instance();
        }
        
        // Initialize disposable email detection
        if (class_exists('VRSTORE_Disposable_Email_Detector')) {
            VRSTORE_Disposable_Email_Detector::get_instance();
        }
        
        // Initialize Stripe scripts handler
        if (class_exists('VRSTORE_Stripe_Scripts')) {
            VRSTORE_Stripe_Scripts::get_instance();
        }
        
        // Initialize login attempts limiter
        if (class_exists('VRSTORE_Login_Attempts')) {
            VRSTORE_Login_Attempts::get_instance();
        }
        
        // Initialize compatibility handler
        if (class_exists('VRSTORE_Compatibility')) {
            VRSTORE_Compatibility::get_instance();
        }
        
        // Initialize content restriction
        if (class_exists('VRSTORE_Content_Restriction')) {
            VRSTORE_Content_Restriction::get_instance();
        }
        
        // Initialize taxonomy restriction
        if (class_exists('VRSTORE_Taxonomy_Restriction')) {
            VRSTORE_Taxonomy_Restriction::get_instance();
        }
        
        
    }

    /**
     * Get a setting value
     *
     * @param string $key Setting key
     * @param mixed $default Default value
     * @return mixed
     */
    public function get_setting(string $key, $default = null) {
        return $this->settings[$key] ?? $default;
    }

    /**
     * Update a setting value
     *
     * @param string $key Setting key
     * @param mixed $value Setting value
     * @return bool
     */
    public function update_setting(string $key, $value): bool {
        $this->settings[$key] = $value;
        // return update_option('vrstore_settings', $this->settings); // Removed as register_setting handles saving
    }

    /**
     * Handle template redirects for fallback pages
     *
     * @return void
     */
    public function handle_template_redirects(): void {
        // Handle fallback thank you page
        if (isset($_GET['vrstore_page']) && $_GET['vrstore_page'] === 'thank-you') {
            // Check if we have order data
            $order_id = isset($_GET['vrstore_order_id']) ? sanitize_text_field($_GET['vrstore_order_id']) : '';
            $success_message = isset($_GET['vrstore_success']) ? urldecode($_GET['vrstore_success']) : '';
            
            if ($order_id) {
                // Load the thank you shortcode
                if (class_exists('VRSTORE_Shortcodes')) {
                    $shortcodes = VRSTORE_Shortcodes::get_instance();
                    
                    // Set up the environment for the shortcode
                    $_GET['vrstore_order_id'] = $order_id;
                    
                    // Generate the thank you content
                    $thank_you_content = $shortcodes->thank_you_shortcode([]);
                    
                    // Display simple thank you page
                    $this->display_fallback_thank_you_page($thank_you_content, $success_message);
                }
            } else {
                // Redirect to home if no order ID
                wp_redirect(home_url());
                exit;
            }
        }
    }
    
    /**
     * Handle file downloads for customers
     *
     * @return void
     */
    public function handle_file_downloads(): void {
        // Check if this is a download request
        if (!isset($_GET['vrstore_download']) || !isset($_GET['order_id'])) {
            return;
        }
        
        // Get parameters
        $product_id = absint($_GET['vrstore_download']);
        $order_id = sanitize_text_field($_GET['order_id']);
        
        // Verify nonce if provided
        if (isset($_GET['nonce']) && !wp_verify_nonce($_GET['nonce'], 'vrstore_download_' . $order_id)) {
            wp_die($this->get_safe_translation('Security check failed.'));
        }
        
        // Check if user is logged in
        if (!is_user_logged_in()) {
            // Redirect to login page with redirect back to this download
            $redirect_url = add_query_arg([
                'vrstore_download' => $product_id,
                'order_id' => $order_id,
                'nonce' => wp_create_nonce('vrstore_download_' . $order_id)
            ], wp_login_url());
            
            wp_redirect($redirect_url);
            exit;
        }
        
        // Get current user
        $current_user = wp_get_current_user();
        
        // Check if user has capability to download
        if (!$current_user->has_cap('download_vrstore_products')) {
            wp_die($this->get_safe_translation('You do not have permission to download this file.'));
        }
        
        // Get order details
        global $wpdb;
        $orders_table = $wpdb->prefix . 'vrstore_orders';
        
        // Try to get order by ID or order number
        if (is_numeric($order_id)) {
            $order = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $orders_table WHERE id = %d AND customer_email = %s",
                $order_id,
                $current_user->user_email
            ), ARRAY_A);
        } else {
            $order = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $orders_table WHERE order_number = %s AND customer_email = %s",
                $order_id,
                $current_user->user_email
            ), ARRAY_A);
        }
        
        // Check if order exists and belongs to user
        if (!$order) {
            wp_die($this->get_safe_translation('Order not found or does not belong to you.'));
        }
        
        // Check if order is completed
        if (strtolower($order['payment_status']) !== 'completed' || strtolower($order['order_status']) !== 'completed') {
            wp_die($this->get_safe_translation('This order is not completed yet.'));
        }
        
        // Check if product matches order
        if ($order['product_id'] != $product_id) {
            wp_die($this->get_safe_translation('Product does not match the order.'));
        }
        
        // Get product files
        $product_files = get_post_meta($product_id, '_vrstore_product_files', true);
        
        if (empty($product_files) || !is_array($product_files)) {
            wp_die($this->get_safe_translation('No files found for this product.'));
        }
        
        // Get the first available file (support both 'url' and 'file' keys)
        $file = reset($product_files);
        $file_url = '';
        $file_name = $file['name'] ?? 'download';
        
        // Check for external URL first
        if (!empty($file['url'])) {
            $file_url = $file['url'];
        }
        // Fallback to 'file' key for local files
        elseif (!empty($file['file'])) {
            $file_url = $file['file'];
        }
        
        if (empty($file_url)) {
            wp_die($this->get_safe_translation('File URL is missing.'));
        }
        
        // Log the download
        $download_logs_table = $wpdb->prefix . 'vrstore_download_logs';
        $wpdb->insert(
            $download_logs_table,
            [
                'order_id' => $order['id'],
                'product_id' => $product_id,
                'customer_email' => $current_user->user_email,
                'file_name' => $file_name,
                'file_url' => $file_url,
                'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? ''
            ],
            [
                '%d',
                '%d',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s'
            ]
        );
        
        // Update download count in order
        $wpdb->update(
            $orders_table,
            ['download_count' => $order['download_count'] + 1],
            ['id' => $order['id']],
            ['%d'],
            ['%d']
        );
        
        // Use the new secure download system
        $file_protection = VRSTORE_File_Protection::get_instance();
        
        // Generate secure download token for the first file (index 0)
        $secure_token = $file_protection->generate_download_token($product_id, 0, $current_user->ID);
        
        if ($secure_token) {
            // Redirect to secure download URL
            $secure_download_url = add_query_arg([
                'vrstore_secure_download' => $secure_token
            ], home_url());
            
            wp_redirect($secure_download_url);
            exit;
        } else {
            wp_die($this->get_safe_translation('Unable to generate secure download link.'));
        }
    }
    
    /**
     * Display fallback thank you page
     *
     * @param string $content Thank you content
     * @param string $success_message Success message
     * @return void
     */
    private function display_fallback_thank_you_page(string $content, string $success_message): void {
        // Get theme header
        get_header();
        
        echo '<div class="vrstore-fallback-thank-you" style="padding: 40px 20px; max-width: 800px; margin: 0 auto;">';
        
        if (!empty($success_message)) {
            echo '<div class="vrstore-success-message" style="background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin-bottom: 20px; border: 1px solid #c3e6cb;">';
            echo '<strong>' . esc_html($success_message) . '</strong>';
            echo '</div>';
        }
        
        echo $content;
        echo '</div>';
        
        // Get theme footer
        get_footer();
        exit;
    }

    /**
     * Add security headers to allow video embedding
     *
     * @return void
     */
    public function add_video_security_headers(): void {
        // Only add headers on product pages
        if (!is_singular('vrstore_product')) {
            return;
        }
        
        // Check if we have video content on this page
        global $post;
        $product_videos = get_post_meta($post->ID, '_vrstore_product_videos', true);
        
        if (empty($product_videos)) {
            return;
        }
        
        // Add meta tag for CSP to allow YouTube iframes
        echo '<meta http-equiv="Content-Security-Policy" content="frame-src \'self\' https://www.youtube.com https://www.youtube-nocookie.com https://youtube.com https://youtube-nocookie.com;">' . "\n";
        
        // Also add X-Frame-Options header if not already set
        if (!headers_sent()) {
            // Remove any existing X-Frame-Options that might be too restrictive
            header_remove('X-Frame-Options');
            // Set a permissive X-Frame-Options for our use case
            header('X-Frame-Options: SAMEORIGIN');
        }
    }

    /**
     * Hide admin bar for customer role users
     *
     * @return void
     */
    public function hide_admin_bar_for_customers(): void {
        // Only proceed if user is logged in
        if (!is_user_logged_in()) {
            return;
        }
        
        $current_user = wp_get_current_user();
        
        // Check if user has customer role or no admin capabilities
        if (in_array('customer', $current_user->roles) || !current_user_can('edit_posts')) {
            // Hide admin bar for customers
            show_admin_bar(false);
            
            // Also remove admin bar from frontend via filter
            add_filter('show_admin_bar', '__return_false');
        }
    }

    /**
     * Check database status and show admin notices if needed
     *
     * @return void
     */
    private function check_database_status(): void {
        // Only check in admin area
        if (!is_admin()) {
            return;
        }

        // Check if database installation failed during activation
        if (get_option('vrstore_db_install_failed', false)) {
            add_action('admin_notices', function() {
                $message = vrstore_is_textdomain_ready() ?
                    esc_html__('Vira Store: Database installation failed during plugin activation. Please check the Database Tools page for repair options.', 'vira-store') :
                    esc_html('Vira Store: Database installation failed during plugin activation. Please check the Database Tools page for repair options.');
                $tools_url = admin_url('admin.php?page=vrstore-database-tools');
                $tools_text = vrstore_is_textdomain_ready() ?
                    esc_html__('Go to Database Tools', 'vira-store') :
                    esc_html('Go to Database Tools');
                echo '<div class="error"><p>' . $message . ' <a href="' . esc_url($tools_url) . '">' . $tools_text . '</a></p></div>';
            });
            return;
        }

        // Check for missing tables
        if (class_exists('VRSTORE_Database')) {
            $db = VRSTORE_Database::get_instance();
            $missing_tables = $db->get_missing_tables();
            
            if (!empty($missing_tables)) {
                // Attempt automatic repair for non-critical pages
                $auto_repair_allowed = true;
                
                // Check if get_current_screen function exists and is available
                if (function_exists('get_current_screen')) {
                    $current_screen = get_current_screen();
                    // Don't auto-repair on plugin pages to avoid conflicts
                    if ($current_screen && strpos($current_screen->id, 'vrstore') !== false) {
                        $auto_repair_allowed = false;
                    }
                }
                
                // Don't auto-repair if user is on database tools page
                if (isset($_GET['page']) && $_GET['page'] === 'vrstore-database-tools') {
                    $auto_repair_allowed = false;
                }
                
                // Don't auto-repair if we're on any Vira Store admin page (fallback check)
                if (isset($_GET['page']) && strpos($_GET['page'], 'vrstore') !== false) {
                    $auto_repair_allowed = false;
                }
                
                // Attempt automatic repair if allowed
                if ($auto_repair_allowed && !get_transient('vrstore_auto_repair_attempted')) {
                    // Set transient to prevent repeated attempts (expires in 1 hour)
                    set_transient('vrstore_auto_repair_attempted', true, HOUR_IN_SECONDS);
                    
                    $repair_result = $db->repair_database();
                    
                    if ($repair_result['success']) {
                        add_action('admin_notices', function() use ($repair_result) {
                            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html($repair_result['message']) . '</p></div>';
                        });
                        return; // Exit early if repair was successful
                    } else {
                        // Auto-repair failed
                    }
                }
                
                // Show error notice with link to database tools
                add_action('admin_notices', function() use ($missing_tables) {
                    $table_list = implode(', ', $missing_tables);
                    $tools_url = admin_url('admin.php?page=vrstore-database-tools');
                    $message = vrstore_is_textdomain_ready() ?
                        sprintf(
                            esc_html__('Vira Store: Missing database tables detected (%s). ', 'vira-store'),
                            $table_list
                        ) :
                        sprintf(
                            esc_html('Vira Store: Missing database tables detected (%s). '),
                            $table_list
                        );
                    $repair_text = vrstore_is_textdomain_ready() ?
                        esc_html__('Repair Database', 'vira-store') :
                        esc_html('Repair Database');
                    echo '<div class="error"><p>' . $message . '<a href="' . esc_url($tools_url) . '" class="button button-primary" style="margin-left: 10px;">' . $repair_text . '</a></p></div>';
                });
            }
        }
    }
}

/**
 * Returns the main instance of Vira_Store
 *
 * @return Vira_Store
 */
function vrstore(): Vira_Store {
    return Vira_Store::get_instance();
}

// Text domain loading is handled in the init action within the class

// Initialize the main plugin instance
add_action('plugins_loaded', function() {
    vrstore();
}, 10);

// Note: Post type registration now handled by VRSTORE_Product class for proper slug configuration

/**
 * Global helper functions for conditional translation in templates
 */
if (!function_exists('vrstore_translate')) {
    /**
     * Get translated text with conditional loading check for templates
     *
     * @param string $text The text to translate
     * @param string $domain Text domain
     * @return string Translated and escaped text
     */
    function vrstore_translate($text, $domain = 'vira-store') {
        if (vrstore_is_textdomain_ready()) {
            return esc_html__($text, $domain);
        }
        return esc_html($text);
    }
}

if (!function_exists('vrstore_translate_echo')) {
    /**
     * Echo translated text with conditional loading check for templates
     *
     * @param string $text The text to translate
     * @param string $domain Text domain
     * @return void
     */
    function vrstore_translate_echo($text, $domain = 'vira-store') {
        if (vrstore_is_textdomain_ready()) {
            esc_html_e($text, $domain);
        } else {
            echo esc_html($text);
        }
    }
}

if (!function_exists('vrstore_is_textdomain_ready')) {
    /**
     * Check if textdomain is ready without triggering WordPress.org API calls
     *
     * @return bool
     */
    function vrstore_is_textdomain_ready() {
        return defined('VRSTORE_TEXTDOMAIN_LOADED') && VRSTORE_TEXTDOMAIN_LOADED;
    }
}

if (!function_exists('vrstore_translate_attr')) {
    /**
     * Get translated text for attributes with conditional loading check
     *
     * @param string $text The text to translate
     * @param string $domain Text domain
     * @return string Translated and escaped text for attributes
     */
    function vrstore_translate_attr($text, $domain = 'vira-store') {
        if (vrstore_is_textdomain_ready()) {
            return esc_attr__($text, $domain);
        }
        return esc_attr($text);
    }
}

if (!function_exists('vrstore_format_price')) {
    /**
     * Format price according to currency settings with K/M notation for large numbers
     *
     * @param float $price The price to format
     * @return string Formatted price
     */
    function vrstore_format_price($price) {
        if (class_exists('VRSTORE_Settings')) {
            $settings = VRSTORE_Settings::get_instance();
            return $settings->format_price($price);
        }
        
        // Fallback formatting if settings class is not available
        return '$' . number_format($price, 2);
    }
}

if (!function_exists('vrstore_get_order')) {
    /**
     * Get order by ID
     *
     * @param int $order_id The order ID
     * @return object|null Order object or null if not found
     */
    function vrstore_get_order($order_id) {
        if (class_exists('VRSTORE_Order')) {
            return VRSTORE_Order::get_order($order_id);
        }
        
        return null;
    }
}

if (!function_exists('vrstore_get_license')) {
    /**
     * Get license by ID - Global helper function
     *
     * @param int $license_id License ID
     * @return array|null License data or null if not found
     */
    function vrstore_get_license(int $license_id) {
        if (class_exists('VRSTORE_License')) {
            $license_instance = VRSTORE_License::get_instance();
            return $license_instance->get_license_by_id($license_id);
        }
        return null;
    }
}

if (!function_exists('vrstore_get_user_id_from_data')) {
    /**
     * Safely extract user ID from various data structures
     *
     * @param mixed $data The data structure (array, object, etc.)
     * @return int|null User ID or null if not found
     */
    function vrstore_get_user_id_from_data($data) {
        if (empty($data)) {
            return null;
        }
        
        // Handle array format (from vrstore_get_license, vrstore_get_order)
        if (is_array($data)) {
            // License format: ['user' => ['id' => 123]]
            if (isset($data['user']) && is_array($data['user']) && isset($data['user']['id'])) {
                return absint($data['user']['id']);
            }
            // Order format: ['user_id' => 123]
            if (isset($data['user_id'])) {
                return absint($data['user_id']);
            }
            // Direct ID format: ['id' => 123]
            if (isset($data['id'])) {
                return absint($data['id']);
            }
        }
        
        // Handle object format (legacy or WP_User)
        if (is_object($data)) {
            // WP_User object
            if ($data instanceof WP_User) {
                return $data->ID;
            }
            // Object with get_user_id method
            if (method_exists($data, 'get_user_id')) {
                return absint($data->get_user_id());
            }
            // Object with user_id property
            if (isset($data->user_id)) {
                return absint($data->user_id);
            }
            // Object with ID property
            if (isset($data->ID)) {
                return absint($data->ID);
            }
        }
        
        // Handle direct integer
        if (is_numeric($data)) {
            return absint($data);
        }
        
        return null;
    }
}
