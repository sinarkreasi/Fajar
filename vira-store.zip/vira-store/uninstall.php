<?php
/**
 * Uninstall Vira Store
 *
 * @package Vira_Store
 */

// Exit if accessed directly
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Check if user wants to remove all data
$settings = get_option('vrstore_settings', array());
$remove_data = isset($settings['uninstall_data']) && $settings['uninstall_data'] === 'on';

// Starting uninstall process

if ($remove_data) {
    // Include database class for table cleanup
    $database_file = plugin_dir_path(__FILE__) . 'includes/class-database.php';
    if (file_exists($database_file)) {
        require_once $database_file;
        
        // Initialize database class and drop all tables
        if (class_exists('VRSTORE_Database')) {
            $database = VRSTORE_Database::get_instance();
            $database->drop_tables();
            // Database tables dropped successfully
        }
    }
    
    // Delete all custom post types and their meta
    $post_types = ['vrstore_product', 'vrstore_course']; // vrstore_license post type removed - using table-based system
    $deleted_posts = 0;
    
    foreach ($post_types as $post_type) {
        $posts = get_posts([
            'post_type'      => $post_type,
            'post_status'    => 'any',
            'numberposts'    => -1,
            'fields'         => 'ids',
        ]);
        
        foreach ($posts as $post_id) {
            // Delete all post meta
            global $wpdb;
            $wpdb->delete($wpdb->postmeta, ['post_id' => $post_id]);
            
            // Delete the post
            if (wp_delete_post($post_id, true)) {
                $deleted_posts++;
            }
        }
    }
    
    // Custom posts deleted
    
    // Delete custom taxonomies and their terms
    $taxonomies = ['vrstore_product_cat', 'vrstore_product_tag', 'vrstore_course_cat', 'vrstore_course_tag'];
    $deleted_terms = 0;
    
    foreach ($taxonomies as $taxonomy) {
        if (taxonomy_exists($taxonomy)) {
            $terms = get_terms([
                'taxonomy'   => $taxonomy,
                'hide_empty' => false,
                'fields'     => 'ids',
            ]);
            
            if (!is_wp_error($terms) && is_array($terms)) {
                foreach ($terms as $term_id) {
                    if (wp_delete_term($term_id, $taxonomy)) {
                        $deleted_terms++;
                    }
                }
            }
            
            // Unregister the taxonomy
            unregister_taxonomy($taxonomy);
        }
    }
    
    // Taxonomy terms deleted
    
    // Delete all users with customer role (before removing the role)
    $customer_users = get_users([
        'role'   => 'customer',
        'fields' => 'ID'
    ]);
    
    $deleted_users = 0;
    $role_removals = 0;
    
    foreach ($customer_users as $user_id) {
        // Only delete if user has no other roles
        $user = get_userdata($user_id);
        if ($user && count($user->roles) === 1 && in_array('customer', $user->roles)) {
            if (wp_delete_user($user_id)) {
                $deleted_users++;
            }
        } else {
            // Just remove the customer role
            if ($user && $user->remove_role('customer')) {
                $role_removals++;
            }
        }
    }
    
    // Remove customer user role
    remove_role('customer');
    
    // Customer users and roles cleaned up
    
    // Delete all plugin options
    global $wpdb;
    $deleted_options = $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE 'vrstore_%'");
    
    // Delete all transients
    $deleted_transients = $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '%_transient_vrstore_%'");
    $deleted_timeouts = $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '%_transient_timeout_vrstore_%'");
    
    // Delete user meta related to plugin
    $deleted_usermeta = $wpdb->query("DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE 'vrstore_%'");
    $deleted_usermeta += $wpdb->query("DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE '%course_enrollment%'");
    $deleted_usermeta += $wpdb->query("DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE '%course_progress%'");
    $deleted_usermeta += $wpdb->query("DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE '%lesson_completion%'");
    $deleted_usermeta += $wpdb->query("DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE '%course_completion_date%'");
    $deleted_usermeta += $wpdb->query("DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE '%video_progress%'");
    $deleted_usermeta += $wpdb->query("DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE '%course_certificate%'");
    
    // Delete any scheduled cron jobs
    wp_clear_scheduled_hook('vrstore_daily_cleanup');
    wp_clear_scheduled_hook('vrstore_license_check');
    wp_clear_scheduled_hook('vrstore_domain_monitor');
    wp_clear_scheduled_hook('vrstore_course_analytics_daily');
    wp_clear_scheduled_hook('vrstore_course_progress_sync');
    wp_clear_scheduled_hook('vrstore_video_analytics_cleanup');
    
    // Clear any cached data
    wp_cache_flush();
    
    // Options, transients, and user meta cleaned up
    
} else {
    // Only delete basic settings if user doesn't want to remove all data
    delete_option('vrstore_settings');
    
    // Delete transients
    global $wpdb;
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '%_transient_vrstore_%'");
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '%_transient_timeout_vrstore_%'");
    
    // Basic cleanup completed (settings and transients only)
}

// Clear any cached data that has been removed
wp_cache_flush();

// Uninstall process completed successfully