/**
 * Lesson Frontend JavaScript
 *
 * @package Vira_Store
 */

(function($) {
    'use strict';

    // Global lesson data for JavaScript access
    window.vrstoreLessonData = window.vrstoreLessonData || {};

    $(document).ready(function() {
        var vrstoreLesson = {

            /**
             * Initialize all lesson functionality
             */
            init: function() {
                this.initTabs();
                this.initLessonNavigation();
                this.initMobileControls();
                this.initVideoTracking();
                this.initCompletion();
                this.initKeyboardNavigation();
                this.initVideoProtection();
                this.initYouTubeProtection();
            },

            /**
             * Initialize lesson content tabs (Description/Materials)
             */
            initTabs: function() {
                console.log('Lesson JS: Initializing tabs...');
                
                $('.lesson-tab').on('click', function(e) {
                    e.preventDefault();
                    
                    var $tab = $(this);
                    var targetTab = $tab.attr('data-tab');
                    
                    if (!targetTab) {
                        console.error('No target tab found:', $tab);
                        return;
                    }
                    
                    // Remove active classes
                    $('.lesson-tab').removeClass('active');
                    $('.lesson-tab-content').removeClass('active');
                    
                    // Add active classes
                    $tab.addClass('active');
                    $('#' + targetTab).addClass('active');
                    
                    console.log('Switched to tab:', targetTab);
                    
                    // Trigger custom event
                    $(document).trigger('vrstore:lesson:tab:changed', [targetTab]);
                });
            },

            /**
             * Initialize lesson navigation in sidebar
             */
            initLessonNavigation: function() {
                console.log('Lesson JS: Initializing lesson navigation...');
                
                $('.lesson-item').on('click', function(e) {
                    e.preventDefault();
                    
                    var $item = $(this);
                    var moduleIndex = $item.attr('data-module');
                    var lessonIndex = $item.attr('data-lesson');
                    
                    if (moduleIndex !== null && lessonIndex !== null) {
                        var courseId = window.vrstoreLessonData.courseId || $item.data('course-id');
                        
                        if (courseId) {
                            var url = new URL(window.location.href);
                            url.searchParams.set('course_id', courseId);
                            url.searchParams.set('module_index', moduleIndex);
                            url.searchParams.set('lesson_index', lessonIndex);
                            
                            console.log('Navigating to lesson:', moduleIndex, lessonIndex);
                            window.location.href = url.toString();
                        } else {
                            console.error('Course ID not found for navigation');
                        }
                    }
                });
                
                // Handle keyboard navigation in lesson list
                $('.lesson-item').on('keydown', function(e) {
                    if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        $(this).trigger('click');
                    }
                });
            },

            /**
             * Initialize mobile controls
             */
            initMobileControls: function() {
                // Add mobile menu toggle if needed
                if ($(window).width() <= 768) {
                    this.addMobileMenuToggle();
                }
                
                // Handle window resize
                $(window).on('resize', this.handleWindowResize.bind(this));
            },

            /**
             * Add mobile menu toggle
             */
            addMobileMenuToggle: function() {
                if ($('.mobile-lesson-toggle').length) {
                    return; // Already added
                }
                
                var toggleHTML = '<button class="mobile-lesson-toggle" style="position: fixed; top: 20px; left: 20px; z-index: 1001; background: #2196f3; color: white; border: none; padding: 10px; border-radius: 5px; cursor: pointer;">' +
                    '<i class="dashicons dashicons-menu"></i>' +
                    '</button>';
                
                $('body').append(toggleHTML);
                
                $('.mobile-lesson-toggle').on('click', function() {
                    $('.lesson-sidebar').toggleClass('open');
                });
                
                // Close sidebar when clicking outside
                $(document).on('click', function(e) {
                    if (!$(e.target).closest('.lesson-sidebar, .mobile-lesson-toggle').length) {
                        $('.lesson-sidebar').removeClass('open');
                    }
                });
            },

            /**
             * Handle window resize
             */
            handleWindowResize: function() {
                if ($(window).width() > 768) {
                    $('.mobile-lesson-toggle').remove();
                    $('.lesson-sidebar').removeClass('open');
                } else if ($(window).width() <= 768 && !$('.mobile-lesson-toggle').length) {
                    this.addMobileMenuToggle();
                }
            },

            /**
             * Initialize video tracking
             */
            initVideoTracking: function() {
                var self = this;
                
                // Track video play events
                $('.video-container video, .video-container iframe').on('play', function() {
                    self.trackVideoEvent('play', {
                        timestamp: Date.now()
                    });
                });
                
                // Track video pause events  
                $('.video-container video').on('pause', function() {
                    self.trackVideoEvent('pause', {
                        timestamp: Date.now()
                    });
                });
                
                // Track video completion
                $('.video-container video').on('ended', function() {
                    self.trackVideoEvent('completed', {
                        timestamp: Date.now()
                    });
                    
                    // Auto-suggest marking lesson as complete
                    self.suggestLessonCompletion();
                });
                
            },

            /**
             * Initialize video protection (disable right-click, keyboard shortcuts)
             */
            initVideoProtection: function() {
                console.log('Lesson JS: Initializing video protection...');

                // Disable right-click on all video elements
                $('.video-container video, .video-container iframe').on('contextmenu', function(e) {
                    e.preventDefault();
                    return false;
                });

                // Disable common keyboard shortcuts for video downloading/inspection
                $('.video-container').on('keydown', function(e) {
                    // Disable F12 (Developer Tools)
                    if (e.keyCode === 123) {
                        e.preventDefault();
                        return false;
                    }

                    // Disable Ctrl+Shift+I (Developer Tools)
                    if (e.ctrlKey && e.shiftKey && e.keyCode === 73) {
                        e.preventDefault();
                        return false;
                    }

                    // Disable Ctrl+Shift+J (Console)
                    if (e.ctrlKey && e.shiftKey && e.keyCode === 74) {
                        e.preventDefault();
                        return false;
                    }

                    // Disable Ctrl+U (View Source)
                    if (e.ctrlKey && e.keyCode === 85) {
                        e.preventDefault();
                        return false;
                    }

                    // Disable Ctrl+S (Save Page)
                    if (e.ctrlKey && e.keyCode === 83) {
                        e.preventDefault();
                        return false;
                    }
                });

                // Add CSS to prevent text selection on video containers
                $('.video-container').css({
                    '-webkit-user-select': 'none',
                    '-moz-user-select': 'none',
                    '-ms-user-select': 'none',
                    'user-select': 'none',
                    '-webkit-touch-callout': 'none'
                });

                // Disable drag and drop on video elements
                $('.video-container video, .video-container iframe').on('dragstart', function(e) {
                    e.preventDefault();
                    return false;
                });

                // Add protection message for right-click attempts
                $('.video-container').on('contextmenu', function(e) {
                    e.preventDefault();

                    // Show a subtle message (optional)
                    var $message = $('<div class="video-protection-message" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); background: rgba(0,0,0,0.8); color: white; padding: 10px 20px; border-radius: 5px; font-size: 14px; z-index: 1000; pointer-events: none;">Content is protected</div>');
                    $(this).append($message);

                    setTimeout(function() {
                        $message.fadeOut(500, function() {
                            $(this).remove();
                        });
                    }, 2000);

                    return false;
                });

                console.log('Video protection initialized successfully');
            },

            /**
             * Initialize enhanced YouTube video protection
             */
            initYouTubeProtection: function() {
                console.log('Lesson JS: Initializing YouTube protection...');

                var $youtubeIframes = $('.video-container iframe[src*="youtube.com"]');

                if ($youtubeIframes.length === 0) {
                    console.log('No YouTube videos found');
                    return;
                }

                $youtubeIframes.each(function() {
                    var $iframe = $(this);
                    var $container = $iframe.closest('.video-container');

                    // Add transparent overlay to prevent direct iframe interaction
                    if (!$container.find('.youtube-protection-overlay').length) {
                        var $overlay = $('<div class="youtube-protection-overlay"></div>');
                        $container.append($overlay);

                        // Disable right-click on overlay
                        $overlay.on('contextmenu', function(e) {
                            e.preventDefault();

                            // Show protection message
                            var $message = $('<div class="video-protection-message">This content is protected</div>');
                            $container.append($message);

                            setTimeout(function() {
                                $message.fadeOut(300, function() {
                                    $(this).remove();
                                });
                            }, 1500);

                            return false;
                        });

                        // Prevent any selection on overlay
                        $overlay.on('selectstart', function(e) {
                            e.preventDefault();
                            return false;
                        });

                        // Prevent drag events
                        $overlay.on('dragstart', function(e) {
                            e.preventDefault();
                            return false;
                        });
                    }

                    // Add additional iframe attributes for security
                    $iframe.attr({
                        'allowfullscreen': false,
                        'allow': 'accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture'
                    });

                    // Prevent iframe navigation via keyboard
                    $iframe.attr('tabindex', '-1');
                });

                // Global keyboard protection for YouTube videos
                $(document).on('keydown', function(e) {
                    if ($youtubeIframes.length > 0) {
                        // Prevent common screen recording shortcuts
                        // Windows + G (Game bar/screen recording)
                        if (e.key === 'g' && e.metaKey) {
                            e.preventDefault();
                            return false;
                        }

                        // Windows + Alt + R (Start recording)
                        if (e.key === 'r' && e.altKey && e.metaKey) {
                            e.preventDefault();
                            return false;
                        }

                        // Print Screen
                        if (e.key === 'PrintScreen') {
                            e.preventDefault();
                            return false;
                        }
                    }
                });

                console.log('YouTube protection initialized for ' + $youtubeIframes.length + ' video(s)');
            },

            
            /**
             * Track video events
             */
            trackVideoEvent: function(event, data) {
                console.log('Video event:', event, data);
                
                // Implement video tracking via AJAX
                if (typeof window.vrstoreLessonData.trackingEnabled !== 'undefined' && window.vrstoreLessonData.trackingEnabled) {
                    $.ajax({
                        url: window.vrstoreLessonData.ajaxUrl || '/wp-admin/admin-ajax.php',
                        method: 'POST',
                        data: {
                            action: 'vrstore_track_video_event',
                            nonce: window.vrstoreLessonData.nonce,
                            event: event,
                            course_id: window.vrstoreLessonData.courseId,
                            module_index: window.vrstoreLessonData.moduleIndex,
                            lesson_index: window.vrstoreLessonData.lessonIndex,
                            lesson_type: window.vrstoreLessonData.lessonType || 'video_upload',
                            video_time: data.video_time || 0,
                            duration: data.duration || 0,
                            video_url: data.video_url || window.vrstoreLessonData.videoUrl || '',
                            player_type: data.player_type || 'default',
                            timestamp: data.timestamp || Date.now()
                        },
                        success: function(response) {
                            console.log('Video tracking successful:', response);
                        },
                        error: function(xhr, status, error) {
                            console.log('Video tracking failed:', error);
                        }
                    });
                }
            },

            /**
             * Suggest lesson completion after video ends
             */
            suggestLessonCompletion: function() {
                if (!$('.complete-button').length) {
                    return; // Already completed or no completion button
                }
                
                var message = 'Great! You\'ve finished the video. Would you like to mark this lesson as complete?';
                if (confirm(message)) {
                    this.markLessonComplete();
                }
            },

            /**
             * Initialize lesson completion functionality
             */
            initCompletion: function() {
                var self = this;
                
                $('.complete-button').on('click', function(e) {
                    e.preventDefault();
                    self.markLessonComplete();
                });
            },

            /**
             * Mark lesson as complete
             */
            markLessonComplete: function() {
                var $button = $('.complete-button');
                var originalText = $button.text();
                
                // Show loading state
                $button.text('Marking Complete...').prop('disabled', true);
                
                // TODO: Implement AJAX call to mark lesson as complete
                var ajaxData = {
                    action: 'vrstore_mark_lesson_complete',
                    nonce: window.vrstoreLessonData.nonce || '',
                    course_id: window.vrstoreLessonData.courseId,
                    module_index: window.vrstoreLessonData.moduleIndex,
                    lesson_index: window.vrstoreLessonData.lessonIndex
                };
                
                $.ajax({
                    url: window.vrstoreLessonData.ajaxUrl || '/wp-admin/admin-ajax.php',
                    method: 'POST',
                    data: ajaxData,
                    success: function(response) {
                        if (response.success) {
                            // Update UI to show completion
                            $button.replaceWith('<span style="color: #4caf50; font-weight: 600;"><i class="dashicons dashicons-yes-alt"></i> Completed</span>');
                            
                            // Update sidebar lesson item
                            $('.lesson-item.current').addClass('completed');
                            
                            // Update progress bar with response data
                            vrstoreLesson.updateProgressBar(response.data);
                            
                            // Show completion message
                            vrstoreLesson.showCompletionMessage();
                            
                        } else {
                            $button.text('Error - Try Again').prop('disabled', false);
                            setTimeout(function() {
                                $button.text(originalText);
                            }, 2000);
                        }
                    },
                    error: function() {
                        // For now, just simulate success until AJAX is properly implemented
                        $button.replaceWith('<span style="color: #4caf50; font-weight: 600;"><i class="dashicons dashicons-yes-alt"></i> Completed</span>');
                        $('.lesson-item.current').addClass('completed');
                        vrstoreLesson.updateProgressBar();
                        vrstoreLesson.showCompletionMessage();
                    }
                });
            },

            /**
             * Update progress bar
             */
            updateProgressBar: function(response) {
                var completedLessons, totalLessons, percentage;
                
                // Use response data if available (from AJAX), otherwise calculate from DOM
                if (response && response.completed_lessons !== undefined && response.total_lessons !== undefined) {
                    completedLessons = response.completed_lessons;
                    totalLessons = response.total_lessons;
                    percentage = response.progress || 0;
                } else {
                    completedLessons = $('.lesson-item.completed').length;
                    totalLessons = $('.lesson-item').length;
                    percentage = totalLessons > 0 ? Math.round((completedLessons / totalLessons) * 100) : 0;
                }
                
                $('.progress-fill-mini').css('width', percentage + '%');
                $('.sidebar-course-progress').text(percentage + '% Complete • ' + completedLessons + ' of ' + totalLessons + ' lessons');
            },

            /**
             * Show completion message and suggest next lesson
             */
            showCompletionMessage: function() {
                var $nextButton = $('.lesson-navigation .nav-button').not('.disabled').last();
                
                if ($nextButton.length) {
                    var message = 'Lesson completed! Continue to the next lesson?';
                    if (confirm(message)) {
                        window.location.href = $nextButton.attr('href');
                    }
                } else {
                    alert('Congratulations! You have completed this lesson.');
                }
            },

            /**
             * Initialize keyboard navigation
             */
            initKeyboardNavigation: function() {
                $(document).on('keydown', this.handleKeyboardNavigation.bind(this));
            },

            /**
             * Handle keyboard navigation shortcuts
             */
            handleKeyboardNavigation: function(e) {
                // Only handle if not typing in an input
                if ($(e.target).is('input, textarea')) {
                    return;
                }
                
                switch(e.key) {
                    case 'ArrowLeft':
                        // Previous lesson
                        var $prevButton = $('.lesson-navigation .nav-button').first();
                        if ($prevButton.length && !$prevButton.hasClass('disabled')) {
                            window.location.href = $prevButton.attr('href');
                        }
                        break;
                        
                    case 'ArrowRight':
                        // Next lesson
                        var $nextButton = $('.lesson-navigation .nav-button').last();
                        if ($nextButton.length && !$nextButton.hasClass('disabled')) {
                            window.location.href = $nextButton.attr('href');
                        }
                        break;
                        
                    case 'c':
                        // Mark as complete
                        if ($('.complete-button').length) {
                            this.markLessonComplete();
                        }
                        break;
                        
                    case '1':
                        // Switch to Description tab
                        $('.lesson-tab[data-tab="description"]').trigger('click');
                        break;
                        
                    case '2':
                        // Switch to Materials tab
                        $('.lesson-tab[data-tab="materials"]').trigger('click');
                        break;
                }
            },

            /**
             * Initialize lesson progress tracking
             */
            initProgressTracking: function() {
                // Track time spent on lesson
                this.startTime = Date.now();
                
                $(window).on('beforeunload', this.trackTimeSpent.bind(this));
            },

            /**
             * Track time spent on lesson
             */
            trackTimeSpent: function() {
                if (this.startTime) {
                    var timeSpent = Date.now() - this.startTime;
                    
                    // TODO: Send time tracking data via AJAX
                    console.log('Time spent on lesson:', Math.round(timeSpent / 1000) + ' seconds');
                }
            }
        };

        // Initialize lesson functionality
        vrstoreLesson.init();
        
        // Make lesson object globally available
        window.vrstoreLesson = vrstoreLesson;
    });

    // Global functions for external access
    window.markLessonComplete = function() {
        if (window.vrstoreLesson) {
            window.vrstoreLesson.markLessonComplete();
        }
    };

    window.toggleSidebar = function() {
        $('.lesson-sidebar').toggleClass('open');
    };

    /**
     * Global function to track video events (moved from inline script)
     * @param {string} eventType - Type of event (play, pause, progress, etc.)
     * @param {number} currentTime - Current video time in seconds
     * @param {number} duration - Total video duration in seconds
     */
    window.trackVideoEvent = function(eventType, currentTime, duration) {
        if (!window.vrstoreLessonData || !window.vrstoreLessonData.trackingEnabled) {
            return;
        }

        jQuery.ajax({
            url: window.vrstoreLessonData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'vrstore_track_video_event',
                nonce: window.vrstoreLessonData.nonce,
                course_id: window.vrstoreLessonData.courseId,
                lesson_id: window.vrstoreLessonData.lessonId,
                event_type: eventType,
                video_time: currentTime,
                duration: duration,
                video_url: window.vrstoreLessonData.videoUrl || 'video_upload'
            },
            success: function(response) {
                if (response.success) {
                    console.log('Video event tracked:', eventType, currentTime);
                }
            },
            error: function(xhr, status, error) {
                console.warn('Video tracking failed:', error);
            }
        });
    };

})(jQuery);