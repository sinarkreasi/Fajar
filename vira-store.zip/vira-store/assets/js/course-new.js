/**
 * Course Frontend JavaScript - CLEAN VERSION
 *
 * @package Vira_Store
 * @version 2025-01-25-06:37:26 - FIXED REGEX ISSUES
 * @file course-new.js - NO PROBLEMATIC REGEX PATTERNS
 */

(function($) {
    'use strict';

    // Global course data for JavaScript access
    window.vrstoreCourseData = window.vrstoreCourseData || {};

    $(document).ready(function() {
        var vrstoreCourse = {
            
            /**
             * Initialize all course functionality
             */
            init: function() {
                this.initTabs();
                this.initCurriculum();
                this.initEnrollment();
                this.initBuyNow();
                this.initVideoModal();
                this.initSocialShare();
                this.initSmoothScrolling();
                this.initLazyLoading();
                this.initAccessibility();
                this.initModuleToggle();
                this.initContinueLearning();
            },
            
            /**
             * Find product URL by title (helper function for redirection)
             */
            findProductUrl: function(productTitle) {
                // Try to find product link in the current page using WordPress product structure
                var productLinks = $('a[href*="vrstore_product"], a[href*="/product/"], a[href*="product_id="], a[href*="products/"], a[href*="digital-product"]');
                var foundUrl = null;
                
                productLinks.each(function() {
                    var linkText = $(this).text().toLowerCase().trim();
                    var titleLower = productTitle.toLowerCase().trim();
                    
                    // More precise matching - check if titles match closely
                    if (linkText === titleLower || 
                        linkText.includes(titleLower) || 
                        titleLower.includes(linkText)) {
                        foundUrl = $(this).attr('href');
                        return false; // Break the loop
                    }
                });
                
                // If no direct link found, try to construct product URL using dynamic permalink
                if (!foundUrl && typeof vrstore_course_data !== 'undefined' && vrstore_course_data.site_url) {
                    // Get the configured product permalink slug (default: digital-product)
                    var productSlug = vrstore_course_data.product_permalink_slug || 'digital-product';
                    var titleSlug = productTitle.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
                    
                    // Construct URL using the configured permalink structure
                    foundUrl = vrstore_course_data.site_url + '/' + productSlug + '/' + titleSlug + '/';
                }
                
                return foundUrl;
            },
            
            /**
             * Initialize course content tabs
             */
            initTabs: function() {
                // Handle both old class (.vrstore-course-tab) and new class (.tab-button)
                var tabSelector = '.tab-button, .vrstore-course-tab';
                var contentSelector = '.tab-content, .vrstore-course-tab-content';
                
                $(tabSelector).on('click', function(e) {
                    e.preventDefault();
                    
                    var $tab = $(this);
                    var target = $tab.data('target') || $tab.data('tab');
                    
                    if (!target) {
                        console.error('No target found for tab:', $tab);
                        return;
                    }
                    
                    // Remove active class from all tabs and content
                    $(tabSelector).removeClass('active').css({
                        'border-bottom': 'none',
                        'color': '#666'
                    });
                    $(contentSelector).removeClass('active').hide();
                    
                    // Add active class to clicked tab and corresponding content
                    $tab.addClass('active').css({
                        'border-bottom': '2px solid #0073aa',
                        'color': '#0073aa'
                    });
                    
                    var $targetContent = $('#' + target);
                    if ($targetContent.length) {
                        $targetContent.addClass('active').show();
                    } else {
                        console.error('Tab content not found for ID:', target);
                    }
                    
                    // No URL hash updates - keep address bar clean
                    
                    // Trigger custom event
                    $(document).trigger('vrstore:tab:changed', [target]);
                });
                
                // Initialize first tab if none are active
                if (!$(tabSelector + '.active').length && $(tabSelector).length) {
                    $(tabSelector).first().trigger('click');
                }
                
                // Handle direct hash navigation
                this.handleHashNavigation();
                
                // Handle browser back/forward
                $(window).on('popstate', this.handleHashNavigation.bind(this));
            },

            /**
             * Handle hash navigation for tabs
             */
            handleHashNavigation: function() {
                var hash = window.location.hash.substring(1);
                if (hash) {
                    var $target = $('#' + hash);
                    if ($target.length && $target.hasClass('vrstore-course-tab-content')) {
                        var $tab = $('[data-target="' + hash + '"]');
                        if ($tab.length) {
                            $tab.click();
                        }
                    }
                } else {
                    // Show first tab by default
                    $('.vrstore-course-tab').first().click();
                }
            },

            /**
             * Initialize curriculum expansion/collapse
             */
            initCurriculum: function() {
                // This function is now handled by initModuleToggle() to avoid conflicts
                // Keeping this as placeholder for any curriculum-specific initialization
            },

            /**
             * Initialize video modal functionality
             */
            initVideoModal: function() {
                var self = this;
                
                // Course preview image click
                $('.course-image, [onclick="openPreviewModal()"]').off('click').on('click', function(e) {
                    e.preventDefault();
                    self.openPreviewModal();
                });
                
                // Lesson video play buttons
                $('.play-lesson-video').on('click', function(e) {
                    e.preventDefault();
                    var videoUrl = $(this).data('video-url');
                    var videoFile = $(this).data('video-file');
                    var title = $(this).data('lesson-title');
                    self.openVideoModal(videoUrl, videoFile, title);
                });
                
                // Lesson preview modal buttons
                $('.lesson-preview-modal').on('click', function(e) {
                    e.preventDefault();
                    var title = $(this).data('lesson-title');
                    var description = $(this).data('lesson-description');
                    var type = $(this).data('lesson-type');
                    var videoUrl = $(this).data('lesson-video-url');
                    var videoFile = $(this).data('lesson-video-file');
                    self.openLessonPreviewModal(title, description, type, videoUrl, videoFile);
                });
                
                // Make functions globally available
                window.openPreviewModal = function() {
                    self.openPreviewModal();
                };
                window.openVideoModal = function(videoUrl, videoFile, title) {
                    self.openVideoModal(videoUrl, videoFile, title);
                };
            },
            
            /**
             * Open course preview modal
             */
            openPreviewModal: function() {
                // Get course data from global or try to extract from page
                var courseData = window.vrstoreCourseData || {};
                var demoUrl = courseData.demoUrl || $('meta[name="course-demo-url"]').attr('content') || '';
                var title = courseData.title || $('.course-title').text() || 'Course Preview';
                
                if (demoUrl) {
                    this.openVideoModal(demoUrl, '', title + ' - Preview');
                } else {
                    // Try to find first free preview lesson
                    var $firstPreview = $('.play-lesson-video').first();
                    if ($firstPreview.length) {
                        $firstPreview.trigger('click');
                    } else {
                        alert('No preview video available for this course.');
                    }
                }
            },
            
            /**
             * Open video modal
             */
            openVideoModal: function(videoUrl, videoFile, title) {
                var self = this;
                title = title || 'Video';
                
                // Create modal if it doesn't exist
                var $modal = $('#vrstore-video-modal');
                if (!$modal.length) {
                    var modalHTML = '<div id="vrstore-video-modal" style="display: none;">' +
                        '<div class="video-modal-overlay" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.9); z-index: 999999; display: flex; align-items: center; justify-content: center; padding: 20px; box-sizing: border-box;">' +
                            '<div class="video-modal-content" style="width: 100%; max-width: 900px; background: #000; border-radius: 8px; overflow: hidden; position: relative;">' +
                                '<div class="video-modal-header" style="background: #333; padding: 15px 20px; display: flex; justify-content: space-between; align-items: center;">' +
                                    '<h3 class="video-modal-title" style="color: white; margin: 0; font-size: 18px;"></h3>' +
                                    '<button class="video-modal-close" style="background: none; border: none; color: white; font-size: 24px; cursor: pointer; line-height: 1;">&times;</button>' +
                                '</div>' +
                                '<div class="video-modal-body" style="aspect-ratio: 16/9; background: #000; display: flex; align-items: center; justify-content: center;">' +
                                    '<div class="video-container" style="width: 100%; height: 100%;"></div>' +
                                '</div>' +
                            '</div>' +
                        '</div>' +
                    '</div>';
                    
                    $('body').append(modalHTML);
                    $modal = $('#vrstore-video-modal');
                    
                    // Bind close events
                    $modal.find('.video-modal-close').on('click', function() {
                        self.closeVideoModal();
                    });
                    
                    $modal.find('.video-modal-overlay').on('click', function(e) {
                        if (e.target === e.currentTarget) {
                            self.closeVideoModal();
                        }
                    });
                    
                    // Close on escape key
                    $(document).on('keydown.videomodal', function(e) {
                        if (e.key === 'Escape' || e.keyCode === 27) {
                            self.closeVideoModal();
                        }
                    });
                }
                
                // Set title and load video
                $modal.find('.video-modal-title').text(title);
                
                var videoHTML = '';
                var finalVideoUrl = videoUrl || videoFile;
                
                if (finalVideoUrl) {
                    if (finalVideoUrl.includes('youtube.com') || finalVideoUrl.includes('youtu.be')) {
                        var videoId = this.extractYouTubeId(finalVideoUrl);
                        if (videoId) {
                            videoHTML = '<iframe width="100%" height="100%" src="https://www.youtube.com/embed/' + videoId + '?autoplay=1&rel=0" frameborder="0" allowfullscreen></iframe>';
                        }
                    } else if (finalVideoUrl.includes('vimeo.com')) {
                        var videoId = this.extractVimeoId(finalVideoUrl);
                        if (videoId) {
                            videoHTML = '<iframe width="100%" height="100%" src="https://player.vimeo.com/video/' + videoId + '?autoplay=1" frameborder="0" allowfullscreen></iframe>';
                        }
                    } else {
                        videoHTML = '<video width="100%" height="100%" controls autoplay><source src="' + finalVideoUrl + '" type="video/mp4">Your browser does not support the video tag.</video>';
                    }
                }
                
                $modal.find('.video-container').html(videoHTML);
                $modal.show();
                
                // Make close function globally available
                window.closeVideoModal = function() {
                    self.closeVideoModal();
                };
            },
            
            /**
             * Close video modal
             */
            closeVideoModal: function() {
                var $modal = $('#vrstore-video-modal');
                if ($modal.length) {
                    $modal.hide();
                    $modal.find('.video-container').empty();
                }
            },
            
            /**
             * Open lesson preview modal
             */
            openLessonPreviewModal: function(title, description, type, videoUrl, videoFile) {
                var self = this;
                title = title || 'Lesson Preview';
                description = description || 'No description available.';
                type = type || 'text';
                
                // Create modal if it doesn't exist
                var $modal = $('#vrstore-lesson-preview-modal');
                if (!$modal.length) {
                    var modalHTML = '<div id="vrstore-lesson-preview-modal" style="display: none;">' +
                        '<div class="lesson-modal-overlay" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.8); z-index: 999999; display: flex; align-items: center; justify-content: center; padding: 20px; box-sizing: border-box;">' +
                            '<div class="lesson-modal-content" style="width: 100%; max-width: 800px; background: #fff; border-radius: 8px; overflow: hidden; position: relative; max-height: 80vh; overflow-y: auto;">' +
                                '<div class="lesson-modal-header" style="background: #0073aa; padding: 20px; display: flex; justify-content: space-between; align-items: center;">' +
                                    '<h3 class="lesson-modal-title" style="color: white; margin: 0; font-size: 18px;"></h3>' +
                                    '<button class="lesson-modal-close" style="background: none; border: none; color: white; font-size: 24px; cursor: pointer; line-height: 1;">&times;</button>' +
                                '</div>' +
                                '<div class="lesson-video-container" style="display: none; position: relative; width: 100%; padding-bottom: 56.25%; height: 0; background: #000; overflow: hidden;"></div>' +
                                '<div class="lesson-modal-body" style="padding: 30px;">' +
                                    '<div class="lesson-type-badge" style="display: inline-block; background: #f0f0f0; color: #666; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 600; text-transform: uppercase; margin-bottom: 15px;"></div>' +
                                    '<div class="lesson-description" style="color: #333; line-height: 1.6; font-size: 14px;"></div>' +
                                    '<div class="preview-notice" style="margin-top: 20px; padding: 15px; background: #e7f3ff; border-left: 4px solid #0073aa; border-radius: 4px;">' +
                                        '<p style="margin: 0; color: #0073aa; font-size: 13px;"><strong>Free Preview:</strong> This is a limited preview of the lesson content. Enroll in the course to access the full lesson and materials.</p>' +
                                    '</div>' +
                                '</div>' +
                            '</div>' +
                        '</div>' +
                    '</div>';
                    
                    $('body').append(modalHTML);
                    $modal = $('#vrstore-lesson-preview-modal');
                    
                    // Close modal events
                    $modal.find('.lesson-modal-close, .lesson-modal-overlay').on('click', function(e) {
                        if (e.target === this) {
                            self.closeLessonPreviewModal();
                        }
                    });
                    
                    // Prevent modal content clicks from closing modal
                    $modal.find('.lesson-modal-content').on('click', function(e) {
                        e.stopPropagation();
                    });
                    
                    // ESC key to close
                    $(document).on('keydown.lessonModal', function(e) {
                        if (e.keyCode === 27) {
                            self.closeLessonPreviewModal();
                        }
                    });
                }
                
                // Update modal content
                $modal.find('.lesson-modal-title').text(title);
                $modal.find('.lesson-type-badge').text(type + ' lesson');
                $modal.find('.lesson-description').text(description || 'No description available for this lesson.');
                
                // Handle video content
                var $videoContainer = $modal.find('.lesson-video-container');
                $videoContainer.empty().hide();
                
                if (videoUrl || videoFile) {
                    var videoHtml = '';
                    
                    if (videoUrl) {
                        // Handle YouTube videos
                        var youtubeId = this.extractYouTubeId(videoUrl);
                        if (youtubeId) {
                            videoHtml = '<iframe src="https://www.youtube.com/embed/' + youtubeId + '?rel=0&showinfo=0&modestbranding=1&autoplay=0&controls=1" ' +
                                       'frameborder="0" allowfullscreen ' +
                                       'style="width: 100%; height: 100%; position: absolute; top: 0; left: 0;"></iframe>';
                        } else {
                            // Handle Vimeo videos
                            var vimeoId = this.extractVimeoId(videoUrl);
                            if (vimeoId) {
                                videoHtml = '<iframe src="https://player.vimeo.com/video/' + vimeoId + '?title=0&byline=0&portrait=0" ' +
                                           'frameborder="0" allowfullscreen ' +
                                           'style="width: 100%; height: 100%; position: absolute; top: 0; left: 0;"></iframe>';
                            } else {
                                // Generic video URL
                                videoHtml = '<video controls style="width: 100%; height: 100%; position: absolute; top: 0; left: 0;">' +
                                           '<source src="' + videoUrl + '" type="video/mp4">' +
                                           'Your browser does not support the video tag.' +
                                           '</video>';
                            }
                        }
                    } else if (videoFile) {
                        // Handle uploaded video file
                        videoHtml = '<video controls style="width: 100%; height: 100%; position: absolute; top: 0; left: 0;">' +
                                   '<source src="' + videoFile + '" type="video/mp4">' +
                                   'Your browser does not support the video tag.' +
                                   '</video>';
                    }
                    
                    if (videoHtml) {
                        $videoContainer.html(videoHtml).show();
                    }
                }
                
                // Show modal
                $modal.show();
                
                // Make close function globally available
                window.closeLessonPreviewModal = function() {
                    self.closeLessonPreviewModal();
                };
            },
            
            /**
             * Close lesson preview modal
             */
            closeLessonPreviewModal: function() {
                var $modal = $('#vrstore-lesson-preview-modal');
                if ($modal.length) {
                    $modal.hide();
                    $(document).off('keydown.lessonModal');
                }
            },
            
            /**
             * Extract YouTube video ID - using simple string operations
             */
            extractYouTubeId: function(url) {
                // Simple extraction without complex regex
                if (url.includes('youtu.be/')) {
                    var parts = url.split('youtu.be/');
                    if (parts.length > 1) {
                        var id = parts[1].split('?')[0];
                        return id.length === 11 ? id : null;
                    }
                } else if (url.includes('watch?v=')) {
                    var parts = url.split('watch?v=');
                    if (parts.length > 1) {
                        var id = parts[1].split('&')[0];
                        return id.length === 11 ? id : null;
                    }
                }
                return null;
            },
            
            /**
             * Extract Vimeo video ID - using simple string operations
             */
            extractVimeoId: function(url) {
                // Simple extraction without complex regex
                if (url.includes('vimeo.com/')) {
                    var parts = url.split('vimeo.com/');
                    if (parts.length > 1) {
                        var idPart = parts[1];
                        // Remove query parameters
                        if (idPart.includes('?')) {
                            idPart = idPart.split('?')[0];
                        }
                        // Check if it's numeric
                        if (/^\d+$/.test(idPart)) {
                            return idPart;
                        }
                    }
                }
                return null;
            },
            
            /**
             * Initialize social sharing functionality
             */
            initSocialShare: function() {
                // Copy link functionality - consolidated from course.php template
                window.copyCourseLink = function(event) {
                    event.preventDefault();
                    var currentUrl = window.location.href;
                    
                    // Try to use the Clipboard API first
                    if (navigator.clipboard && window.isSecureContext) {
                        navigator.clipboard.writeText(currentUrl).then(function() {
                            vrstoreCourse.showCopyMessage('Link copied to clipboard!');
                        }).catch(function() {
                            vrstoreCourse.fallbackCopyToClipboard(currentUrl);
                        });
                    } else {
                        vrstoreCourse.fallbackCopyToClipboard(currentUrl);
                    }
                };
            },
            
            /**
             * Fallback copy method (moved from course.php)
             */
            fallbackCopyToClipboard: function(text) {
                var textArea = document.createElement('textarea');
                textArea.value = text;
                textArea.style.position = 'fixed';
                textArea.style.left = '-999999px';
                textArea.style.top = '-999999px';
                document.body.appendChild(textArea);
                textArea.focus();
                textArea.select();
                
                try {
                    document.execCommand('copy');
                    this.showCopyMessage('Link copied to clipboard!');
                } catch (err) {
                    this.showCopyMessage('Unable to copy link. Please copy manually: ' + window.location.href);
                }
                
                textArea.remove();
            },
            
            /**
             * Show copy message notification (moved from course.php)
             */
            showCopyMessage: function(message) {
                // Create or update existing notification
                var notification = document.getElementById('copy-notification');
                if (!notification) {
                    notification = document.createElement('div');
                    notification.id = 'copy-notification';
                    notification.style.cssText = [
                        'position: fixed',
                        'top: 20px',
                        'right: 20px',
                        'background: #4CAF50',
                        'color: white',
                        'padding: 12px 20px',
                        'border-radius: 6px',
                        'font-size: 14px',
                        'font-weight: 500',
                        'box-shadow: 0 4px 12px rgba(0,0,0,0.15)',
                        'z-index: 10000',
                        'opacity: 0',
                        'transform: translateY(-10px)',
                        'transition: all 0.3s ease'
                    ].join('; ');
                    document.body.appendChild(notification);
                }
                
                notification.textContent = message;
                
                // Show notification
                setTimeout(function() {
                    notification.style.opacity = '1';
                    notification.style.transform = 'translateY(0)';
                }, 10);
                
                // Hide notification after 3 seconds
                setTimeout(function() {
                    notification.style.opacity = '0';
                    notification.style.transform = 'translateY(-10px)';
                    
                    setTimeout(function() {
                        if (notification && notification.parentNode) {
                            notification.remove();
                        }
                    }, 300);
                }, 3000);
            },
            
            /**
             * Initialize Buy Now functionality
             */
            initBuyNow: function() {
                var self = this;
                
                // Buy Now button
                $('.vrstore-buy-now').on('click', function(e) {
                    e.preventDefault();
                    
                    var $button = $(this);
                    var courseId = $button.data('course-id');
                    var price = $button.data('price');
                    var nonce = $button.data('nonce');
                    
                    if ($button.prop('disabled')) {
                        return;
                    }
                    
                    // Show loading state
                    $button.prop('disabled', true);
                    var $buttonText = $button.find('.button-text');
                    var $spinner = $button.find('.button-spinner');
                    
                    if ($buttonText.length) $buttonText.text('Processing...');
                    if ($spinner.length) $spinner.show();
                    
                    // Make AJAX request
                    $.ajax({
                        url: vrstore_course_frontend.ajax_url || '/wp-admin/admin-ajax.php',
                        type: 'POST',
                        data: {
                            action: 'vrstore_add_course_to_cart',
                            course_id: courseId,
                            price: price,
                            nonce: nonce
                        },
                        success: function(response) {
                            if (response.success) {
                                // Show success
                                if ($buttonText.length) $buttonText.text('Added to Cart!');
                                if ($spinner.length) $spinner.hide();
                                $button.css('background', 'linear-gradient(135deg, #4CAF50 0%, #45a049 100%)');
                                
                                // Redirect after delay
                                setTimeout(function() {
                                    if (response.data && response.data.checkout_url) {
                                        window.location.href = response.data.checkout_url;
                                    } else if (response.data && response.data.cart_url) {
                                        window.location.href = response.data.cart_url;
                                    }
                                }, 1000);
                            } else {
                                // Show error
                                alert(response.data || 'Failed to add course to cart. Please try again.');
                                self.resetButton($button, $buttonText, $spinner);
                            }
                        },
                        error: function() {
                            alert('An error occurred. Please try again.');
                            self.resetButton($button, $buttonText, $spinner);
                        }
                    });
                });
                
                // Free enrollment button
                $('.vrstore-enroll-free').on('click', function(e) {
                    e.preventDefault();
                    
                    var $button = $(this);
                    var courseId = $button.data('course-id');
                    var nonce = $button.data('nonce');
                    
                    if ($button.prop('disabled')) {
                        return;
                    }
                    
                    // Show loading state
                    $button.prop('disabled', true);
                    $button.html('<i class="dashicons dashicons-update" style="margin-right: 8px; animation: spin 1s linear infinite;"></i>Enrolling...');
                    
                    // Make AJAX request
                    $.ajax({
                        url: vrstore_course_frontend.ajax_url || '/wp-admin/admin-ajax.php',
                        type: 'POST',
                        data: {
                            action: 'vrstore_enroll_free_course',
                            course_id: courseId,
                            nonce: nonce
                        },
                        success: function(response) {
                            if (response.success) {
                                $button.html('<i class="dashicons dashicons-yes-alt" style="margin-right: 8px;"></i>Enrolled!');
                                $button.css('background', 'linear-gradient(135deg, #2e7d32 0%, #1b5e20 100%)');
                                
                                // Redirect or reload after delay
                                setTimeout(function() {
                                    if (response.data && response.data.redirect_url) {
                                        window.location.href = response.data.redirect_url;
                                    } else {
                                        location.reload();
                                    }
                                }, 1500);
                            } else {
                                // Check if we have a redirect URL (e.g., for login)
                                if (response.data && typeof response.data === 'object' && response.data.redirect_url) {
                                    // Show message with redirect option
                                    var message = response.data.message || 'Please log in or register to enroll in this course.';
                                    var redirectUrl = response.data.redirect_url;
                                    
                                    if (confirm(message + '\n\nClick OK to go to the login page.')) {
                                        window.location.href = redirectUrl;
                                    } else {
                                        // User cancelled, restore button
                                        $button.prop('disabled', false);
                                        $button.html('<i class="dashicons dashicons-yes-alt" style="margin-right: 8px;"></i>Enroll for Free');
                                    }
                                } else {
                                    // Regular error message
                                    var errorMessage = (response.data && response.data.message) ? response.data.message : (response.data || 'Failed to enroll. Please try again.');
                                    
                                    // Check if this is a product purchase requirement error
                                    if (response.data && response.data.redirect_type === 'product_purchase' && response.data.product_url) {
                                        // Show confirmation dialog with redirect option
                                        if (confirm(errorMessage + '\n\nClick OK to view the product page.')) {
                                            window.location.href = response.data.product_url;
                                        }
                                    } else if (errorMessage.includes('You must purchase') && errorMessage.includes('to access this course for free')) {
                                        // Fallback for legacy error format - extract product title from error message
                                        var productMatch = errorMessage.match(/You must purchase "([^"]+)"/);
                                        var productTitle = productMatch ? productMatch[1] : 'the required product';
                                        
                                        // Show confirmation dialog with redirect option
                                        if (confirm(errorMessage + '\n\nClick OK to view the product page.')) {
                                            // Try to find product URL or redirect to products page
                                            var productUrl = self.findProductUrl(productTitle);
                                            if (productUrl) {
                                                window.location.href = productUrl;
                                            } else {
                                                // Fallback to products page or home
                                                window.location.href = window.location.origin + '/products/';
                                            }
                                        }
                                    } else {
                                        alert(errorMessage);
                                    }
                                    
                                    $button.prop('disabled', false);
                                    $button.html('<i class="dashicons dashicons-yes-alt" style="margin-right: 8px;"></i>Enroll for Free');
                                }
                            }
                        },
                        error: function(xhr, status, error) {
                            console.error('Free enrollment AJAX error:', error);
                            alert('An error occurred. Please try again.');
                            $button.prop('disabled', false);
                            $button.html('<i class="dashicons dashicons-yes-alt" style="margin-right: 8px;"></i>Enroll for Free');
                        }
                    });
                });
            },
            
            /**
             * Reset button to original state
             */
            resetButton: function($button, $buttonText, $spinner) {
                $button.prop('disabled', false);
                if ($buttonText.length) $buttonText.text('Buy Now');
                if ($spinner.length) $spinner.hide();
                $button.css('background', 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)');
            },

            /**
             * Initialize course enrollment functionality
             */
            initEnrollment: function() {
                $('.vrstore-course-enroll-btn').on('click', function(e) {
                    e.preventDefault();
                    
                    var $button = $(this);
                    var courseId = $button.data('course-id');
                    
                    if ($button.hasClass('loading')) {
                        return;
                    }
                    
                    // Add loading state
                    $button.addClass('loading');
                    $button.html('<span class="spinner"></span>' + (vrstore_course_frontend.enrolling || 'Enrolling...'));
                    
                    // Make AJAX request
                    $.ajax({
                        url: vrstore_course_frontend.ajax_url,
                        type: 'POST',
                        data: {
                            action: 'vrstore_enroll_course',
                            course_id: courseId,
                            nonce: vrstore_course_frontend.nonce
                        },
                        success: function(response) {
                            if (response.success) {
                                // Show success message
                                vrstoreCourse.showMessage(response.data.message || vrstore_course_frontend.enrolled, 'success');
                                
                                // Update button state
                                $button.removeClass('loading');
                                $button.html(vrstore_course_frontend.enrolled || 'Enrolled');
                                $button.addClass('enrolled');
                                $button.prop('disabled', true);
                                
                                // Redirect if URL provided
                                if (response.data.redirect_url) {
                                    setTimeout(function() {
                                        window.location.href = response.data.redirect_url;
                                    }, 1500);
                                }
                            } else {
                                vrstoreCourse.showMessage(response.data || vrstore_course_frontend.enroll_error, 'error');
                                $button.removeClass('loading');
                                $button.html('Enroll Now');
                            }
                        },
                        error: function() {
                            vrstoreCourse.showMessage(vrstore_course_frontend.enroll_error || 'Enrollment failed. Please try again.', 'error');
                            $button.removeClass('loading');
                            $button.html('Enroll Now');
                        }
                    });
                });
            },

            /**
             * Show success/error messages
             */
            showMessage: function(message, type) {
                type = type || 'info';
                
                var $message = $('<div class="vrstore-course-message vrstore-course-' + type + '">' + message + '</div>');
                
                // Find the best place to insert the message
                var $container = $('.vrstore-course-sidebar').length ? 
                    $('.vrstore-course-sidebar') : 
                    $('.vrstore-course-container');
                
                $container.prepend($message);
                
                // Animate in
                $message.fadeIn(300);
                
                // Auto-remove after 5 seconds
                setTimeout(function() {
                    $message.fadeOut(300, function() {
                        $message.remove();
                    });
                }, 5000);
            },

            /**
             * Initialize module toggle functionality (consolidated from course.php template)
             */
            initModuleToggle: function() {
                var self = this;
                
                // Handle both old and new class names
                var moduleHeaderSelector = '.module-header, .vrstore-module-header';
                var moduleSelector = '.curriculum-module, .vrstore-curriculum-module';
                var lessonsSelector = '.module-lessons, .vrstore-module-lessons';
                var toggleSelector = '.module-toggle';
                
                // Remove any existing handlers to prevent conflicts
                $(document).off('click', moduleHeaderSelector);
                $(document).off('click', toggleSelector);
                
                // Handle toggle button clicks (specific toggle buttons)
                $(document).on('click', toggleSelector, function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    
                    var $toggle = $(this);
                    var $moduleHeader = $toggle.closest(moduleHeaderSelector);
                    var $module = $moduleHeader.closest(moduleSelector);
                    var $lessons = $module.find(lessonsSelector);
                    var $icon = $toggle.find('i');
                    
                    
                    if ($lessons.is(':visible')) {
                        $lessons.slideUp(300);
                        $moduleHeader.removeClass('expanded');
                        $lessons.removeClass('expanded');
                        $icon.removeClass('dashicons-minus').addClass('dashicons-plus-alt2');
                        
                        // Update ARIA attributes
                        $moduleHeader.attr('aria-expanded', 'false');
                        $lessons.attr('aria-hidden', 'true');
                        
                        // Track analytics
                        self.trackEvent('module_collapse', {
                            module: $moduleHeader.find('.module-title, .vrstore-module-title').text(),
                            timestamp: Date.now()
                        });
                    } else {
                        $lessons.slideDown(300);
                        $moduleHeader.addClass('expanded');
                        $lessons.addClass('expanded');
                        $icon.removeClass('dashicons-plus-alt2').addClass('dashicons-minus');
                        
                        // Update ARIA attributes
                        $moduleHeader.attr('aria-expanded', 'true');
                        $lessons.attr('aria-hidden', 'false');
                        
                        // Track analytics
                        self.trackEvent('module_expand', {
                            module: $moduleHeader.find('.module-title, .vrstore-module-title').text(),
                            timestamp: Date.now()
                        });
                    }
                });
                
                // Handle module header clicks (when no specific toggle button exists)
                $(document).on('click', moduleHeaderSelector, function(e) {
                    var $header = $(this);
                    var $toggle = $header.find(toggleSelector);
                    
                    // If there's a specific toggle button, use that instead
                    if ($toggle.length) {
                        e.preventDefault();
                        $toggle.trigger('click');
                        return;
                    }
                    
                    // Otherwise, handle as direct header click
                    e.preventDefault();
                    var $module = $header.closest(moduleSelector);
                    var $lessons = $module.find(lessonsSelector);
                    
                    
                    if ($lessons.is(':visible')) {
                        $lessons.slideUp(300);
                        $header.removeClass('expanded');
                        $lessons.removeClass('expanded');
                        $header.attr('aria-expanded', 'false');
                        $lessons.attr('aria-hidden', 'true');
                    } else {
                        $lessons.slideDown(300);
                        $header.addClass('expanded');
                        $lessons.addClass('expanded');
                        $header.attr('aria-expanded', 'true');
                        $lessons.attr('aria-hidden', 'false');
                    }
                });
                
                // Initialize first module as expanded after a delay
                setTimeout(function() {
                    var $firstModule = $(moduleSelector).first();
                    if ($firstModule.length) {
                        var $firstLessons = $firstModule.find(lessonsSelector);
                        var $firstHeader = $firstModule.find(moduleHeaderSelector);
                        var $firstIcon = $firstModule.find(toggleSelector + ' i');
                        
                        if ($firstLessons.length && !$firstLessons.is(':visible')) {
                            $firstLessons.show().addClass('expanded');
                            $firstHeader.addClass('expanded');
                            $firstIcon.removeClass('dashicons-plus-alt2').addClass('dashicons-minus');
                            
                            // Set ARIA attributes
                            $firstHeader.attr('aria-expanded', 'true');
                            $firstLessons.attr('aria-hidden', 'false');
                        }
                    }
                }, 200);
            },
            
            /**
             * Initialize continue learning button functionality
             */
            initContinueLearning: function() {
                $('.continue-learning-button').on('click', function(e) {
                    e.preventDefault();
                    
                    // Switch to curriculum tab and scroll to first module
                    var $curriculumTab = $('[data-tab="curriculum"]');
                    if ($curriculumTab.length) {
                        $curriculumTab.trigger('click');
                        
                        // Scroll to curriculum section after tab switch
                        setTimeout(function() {
                            var $curriculum = $('#curriculum');
                            if ($curriculum.length) {
                                $('html, body').animate({
                                    scrollTop: $curriculum.offset().top - 100
                                }, 800);
                            }
                        }, 300);
                    }
                });
            },

            /**
             * Initialize smooth scrolling for internal links
             */
            initSmoothScrolling: function() {
                $('a[href^="#"]').on('click', function(e) {
                    var target = $(this.getAttribute('href'));
                    if (target.length) {
                        e.preventDefault();
                        $('html, body').animate({
                            scrollTop: target.offset().top - 100
                        }, 800);
                    }
                });
            },

            /**
             * Initialize lazy loading for images
             */
            initLazyLoading: function() {
                // Simple lazy loading implementation
                var images = document.querySelectorAll('img[data-src]');
                
                if ('IntersectionObserver' in window) {
                    var imageObserver = new IntersectionObserver(function(entries, observer) {
                        entries.forEach(function(entry) {
                            if (entry.isIntersecting) {
                                var image = entry.target;
                                image.src = image.dataset.src;
                                image.classList.remove('lazy');
                                imageObserver.unobserve(image);
                            }
                        });
                    });

                    images.forEach(function(image) {
                        imageObserver.observe(image);
                    });
                } else {
                    // Fallback for older browsers
                    images.forEach(function(image) {
                        image.src = image.dataset.src;
                        image.classList.remove('lazy');
                    });
                }
            },

            /**
             * Initialize accessibility features
             */
            initAccessibility: function() {
                // Add ARIA labels to interactive elements
                $('.vrstore-course-tab').attr('role', 'tab');
                $('.vrstore-course-tab-content').attr('role', 'tabpanel');
                $('.vrstore-module-header').attr('role', 'button').attr('tabindex', '0');
                
                // Handle keyboard navigation for module headers
                $('.vrstore-module-header').on('keydown', function(e) {
                    if (e.keyCode === 13 || e.keyCode === 32) { // Enter or Space
                        e.preventDefault();
                        $(this).click();
                    }
                });
                
                // Focus management for tabs
                $('.vrstore-course-tab').on('keydown', function(e) {
                    var $tabs = $('.vrstore-course-tab');
                    var currentIndex = $tabs.index(this);
                    var $targetTab;
                    
                    switch (e.keyCode) {
                        case 37: // Left arrow
                        case 38: // Up arrow
                            e.preventDefault();
                            $targetTab = currentIndex > 0 ? $tabs.eq(currentIndex - 1) : $tabs.last();
                            break;
                        case 39: // Right arrow
                        case 40: // Down arrow
                            e.preventDefault();
                            $targetTab = currentIndex < $tabs.length - 1 ? $tabs.eq(currentIndex + 1) : $tabs.first();
                            break;
                    }
                    
                    if ($targetTab) {
                        $targetTab.focus().click();
                    }
                });
                
                // Skip links for better accessibility
                this.addSkipLinks();
            },

            /**
             * Add skip links for keyboard navigation
             */
            addSkipLinks: function() {
                var skipLinks = '<div class="vrstore-skip-links">' +
                    '<a href="#vrstore-course-content" class="screen-reader-text">Skip to course content</a>' +
                    '<a href="#vrstore-course-sidebar" class="screen-reader-text">Skip to course sidebar</a>' +
                    '</div>';
                
                $('.vrstore-course-container').prepend(skipLinks);
            },

            /**
             * Utility function to get URL parameters
             */
            getUrlParameter: function(name) {
                // Simple parameter extraction without regex
                var search = location.search.substring(1);
                var params = search.split('&');
                for (var i = 0; i < params.length; i++) {
                    var param = params[i].split('=');
                    if (param[0] === name) {
                        return decodeURIComponent(param[1] || '');
                    }
                }
                return '';
            },

            /**
             * Utility function to format currency
             */
            formatCurrency: function(amount, currency, symbol) {
                symbol = symbol || '$';
                var formatted = parseFloat(amount).toFixed(2);
                return symbol + formatted;
            },

            
            /**
             * Track course interactions for analytics
             */
            trackEvent: function(eventType, data) {
                data = data || {};
                data.course_id = $('.vrstore-course-container').data('course-id');
                
                // Send to Google Analytics if available
                if (typeof gtag !== 'undefined') {
                    gtag('event', eventType, {
                        custom_parameter: data
                    });
                }
                
                // Trigger custom event for other tracking systems
                $(document).trigger('vrstore:course:track', [eventType, data]);
            },
            
            /**
             * Initialize interactive star rating system
             */
            initStarRating: function() {
                $(document).on('click', '.vrstore-star-rating .star', function() {
                    var $star = $(this);
                    var rating = parseInt($star.data('rating'));
                    var $container = $star.closest('.vrstore-rating-field');
                    var $hiddenInput = $container.find('input[name="rating"]');
                    var $ratingText = $container.find('.rating-text');
                    
                    // Update hidden input value
                    $hiddenInput.val(rating);
                    
                    // Update visual stars
                    $container.find('.star').each(function(index) {
                        var $starElement = $(this);
                        if (index < rating) {
                            $starElement.css('color', '#ffa500'); // Gold color for selected stars
                        } else {
                            $starElement.css('color', '#ddd'); // Gray for unselected
                        }
                    });
                    
                    // Update rating text
                    var ratingLabels = {
                        1: 'Terrible',
                        2: 'Poor', 
                        3: 'Average',
                        4: 'Good',
                        5: 'Excellent'
                    };
                    
                    $ratingText.text('Selected: ' + rating + ' - ' + ratingLabels[rating]);
                    
                    console.log('Rating selected:', rating);
                });
                
                // Hover effects for better UX
                $(document).on('mouseenter', '.vrstore-star-rating .star', function() {
                    var $star = $(this);
                    var hoverRating = parseInt($star.data('rating'));
                    var $container = $star.closest('.vrstore-rating-field');
                    
                    // Highlight stars up to hover position
                    $container.find('.star').each(function(index) {
                        var $starElement = $(this);
                        if (index < hoverRating) {
                            $starElement.css('color', '#ffcc00'); // Lighter gold for hover
                        } else {
                            $starElement.css('color', '#ddd');
                        }
                    });
                });
                
                // Restore original rating on mouse leave
                $(document).on('mouseleave', '.vrstore-star-rating', function() {
                    var $container = $(this).closest('.vrstore-rating-field');
                    var currentRating = parseInt($container.find('input[name="rating"]').val());
                    
                    // Restore visual state based on current rating
                    $container.find('.star').each(function(index) {
                        var $starElement = $(this);
                        if (index < currentRating) {
                            $starElement.css('color', '#ffa500'); // Gold for current rating
                        } else {
                            $starElement.css('color', '#ddd');
                        }
                    });
                });
                
                // Initialize default rating (5 stars)
                setTimeout(function() {
                    $('.vrstore-star-rating .star[data-rating="5"]').trigger('click');
                }, 100);
            }
        };

        // Initialize course functionality
        vrstoreCourse.init();
        
        // Make course object globally accessible
        window.vrstoreCourse = vrstoreCourse;
        
        // Track page load
        vrstoreCourse.trackEvent('course_view', {
            timestamp: Date.now()
        });
        
        // Track tab changes
        $(document).on('vrstore:tab:changed', function(e, tabId) {
            vrstoreCourse.trackEvent('tab_change', {
                tab: tabId,
                timestamp: Date.now()
            });
        });
        
        // Track demo button clicks
        $('.vrstore-course-demo-btn').on('click', function() {
            vrstoreCourse.trackEvent('demo_click', {
                timestamp: Date.now()
            });
        });
        
        // Track instructor link clicks
        $('.vrstore-instructor-website').on('click', function() {
            vrstoreCourse.trackEvent('instructor_website_click', {
                url: $(this).attr('href'),
                timestamp: Date.now()
            });
        });
        
        // Initialize star rating system
        vrstoreCourse.initStarRating();
    });

    // Course-specific utility functions
    window.vrstoreCourseFunctions = {
        /**
         * Calculate total course duration from curriculum
         */
        calculateTotalDuration: function() {
            var totalMinutes = 0;
            $('.vrstore-lesson-duration').each(function() {
                var duration = $(this).text().trim();
                var minutes = parseFloat(duration);
                if (!isNaN(minutes)) {
                    totalMinutes += minutes;
                }
            });
            return totalMinutes;
        },

        /**
         * Get course progress (if user is enrolled)
         */
        getCourseProgress: function() {
            var completedLessons = $('.vrstore-lesson-item.completed').length;
            var totalLessons = $('.vrstore-lesson-item').length;
            return totalLessons > 0 ? (completedLessons / totalLessons) * 100 : 0;
        },

        /**
         * Show/hide course sections based on enrollment status
         */
        updateVisibilityForEnrollment: function(isEnrolled) {
            if (isEnrolled) {
                $('.vrstore-course-restricted').removeClass('restricted');
                $('.vrstore-course-enroll-section').hide();
            } else {
                $('.vrstore-course-content-restricted').addClass('restricted');
                $('.vrstore-course-enroll-section').show();
            }
        }
    };

})(jQuery);

// Global function for copy course link (moved from inline)
window.copyCourseLink = function(event) {
    if (event) {
        event.preventDefault();
    }

    var url = window.location.href;
    
    if (navigator.clipboard && window.isSecureContext) {
        // Modern way
        navigator.clipboard.writeText(url).then(function() {
            showCourseToast('Course link copied to clipboard!');
        }, function() {
            fallbackCopyTextToClipboard(url);
        });
    } else {
        // Fallback
        fallbackCopyTextToClipboard(url);
    }
};

// Fallback copy method
function fallbackCopyTextToClipboard(text) {
    var textArea = document.createElement("textarea");
    textArea.value = text;
    
    // Avoid scrolling to bottom
    textArea.style.top = "0";
    textArea.style.left = "0";
    textArea.style.position = "fixed";

    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();

    try {
        var successful = document.execCommand('copy');
        if (successful) {
            showCourseToast('Course link copied to clipboard!');
        } else {
            showCourseToast('Please copy the URL manually', 'error');
        }
    } catch (err) {
        console.error('Fallback copy failed', err);
        showCourseToast('Please copy the URL manually', 'error');
    }

    document.body.removeChild(textArea);
}

// Show toast notification
function showCourseToast(message, type) {
    type = type || 'success';
    
    // Remove existing toasts
    var existingToasts = document.querySelectorAll('.vrstore-toast');
    existingToasts.forEach(function(toast) {
        toast.remove();
    });

    var toast = document.createElement('div');
    toast.className = 'vrstore-toast vrstore-toast-' + type;
    toast.textContent = message;
    
    // Add styles
    toast.style.cssText = [
        'position: fixed',
        'top: 20px',
        'right: 20px',
        'background: ' + (type === 'success' ? '#4CAF50' : '#f44336'),
        'color: white',
        'padding: 12px 20px',
        'border-radius: 4px',
        'z-index: 9999',
        'font-size: 14px',
        'box-shadow: 0 4px 12px rgba(0,0,0,0.15)',
        'opacity: 0',
        'transform: translateX(100%)',
        'transition: all 0.3s ease'
    ].join(';');

    document.body.appendChild(toast);

    // Animate in
    setTimeout(function() {
        toast.style.opacity = '1';
        toast.style.transform = 'translateX(0)';
    }, 100);

    // Auto hide
    setTimeout(function() {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100%)';
        setTimeout(function() {
            if (toast.parentNode) {
                toast.parentNode.removeChild(toast);
            }
        }, 300);
    }, 3000);
}