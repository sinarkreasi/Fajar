/**
 * Content Restriction Admin JavaScript
 *
 * Handles the functionality for the content restriction metabox
 * in the WordPress post/page editor.
 *
 * @package Vira_Store
 * @since   1.0.0
 */

(function($) {
    'use strict';

    /**
     * Content Restriction Admin functionality
     */
    var ContentRestrictionAdmin = {
        
        /**
         * Initialize the functionality
         */
        init: function() {
            this.bindEvents();
            this.initEditor();
        },

        /**
         * Bind event handlers
         */
        bindEvents: function() {
            // Toggle restriction settings visibility
            $('#vrstore_content_restricted').on('change', this.toggleRestrictionSettings);
            
            // Format buttons for the simple editor
            $(document).on('click', '.vrstore-format-btn', this.handleFormatButton);
        },

        /**
         * Toggle restriction settings visibility
         */
        toggleRestrictionSettings: function() {
            var $checkbox = $(this);
            var $settings = $('#vrstore-restriction-settings');
            
            if ($checkbox.is(':checked')) {
                $settings.slideDown(300);
            } else {
                $settings.slideUp(300);
            }
        },

        /**
         * Initialize the simple content editor
         */
        initEditor: function() {
            var $textarea = $('#vrstore_restricted_content');
            
            // Add some basic styling to the textarea
            $textarea.css({
                'font-family': 'Consolas, Monaco, monospace',
                'font-size': '13px',
                'line-height': '1.5'
            });
        },

        /**
         * Handle format button clicks
         */
        handleFormatButton: function(e) {
            e.preventDefault();
            
            var $button = $(this);
            var format = $button.data('format');
            var targetId = $button.data('target');
            var $textarea = $('#' + targetId);
            var textarea = $textarea[0];
            
            // Get current selection
            var start = textarea.selectionStart;
            var end = textarea.selectionEnd;
            var selectedText = textarea.value.substring(start, end);
            var beforeText = textarea.value.substring(0, start);
            var afterText = textarea.value.substring(end);
            
            var newText = '';
            var newCursorPos = start;
            
            switch (format) {
                case 'bold':
                    if (selectedText) {
                        newText = '<strong>' + selectedText + '</strong>';
                        newCursorPos = start + newText.length;
                    } else {
                        newText = '<strong></strong>';
                        newCursorPos = start + 8; // Position cursor between tags
                    }
                    break;
                    
                case 'italic':
                    if (selectedText) {
                        newText = '<em>' + selectedText + '</em>';
                        newCursorPos = start + newText.length;
                    } else {
                        newText = '<em></em>';
                        newCursorPos = start + 4; // Position cursor between tags
                    }
                    break;
                    
                case 'link':
                    var url = prompt('Enter URL:', 'https://');
                    if (url && url !== 'https://') {
                        if (selectedText) {
                            newText = '<a href="' + url + '">' + selectedText + '</a>';
                            newCursorPos = start + newText.length;
                        } else {
                            var linkText = prompt('Enter link text:', 'Link Text');
                            if (linkText) {
                                newText = '<a href="' + url + '">' + linkText + '</a>';
                                newCursorPos = start + newText.length;
                            }
                        }
                    }
                    break;
                    
                case 'ul':
                    if (selectedText) {
                        var lines = selectedText.split('\n');
                        var listItems = lines.map(function(line) {
                            return line.trim() ? '<li>' + line.trim() + '</li>' : '';
                        }).filter(function(item) {
                            return item !== '';
                        });
                        newText = '<ul>\n' + listItems.join('\n') + '\n</ul>';
                    } else {
                        newText = '<ul>\n<li></li>\n</ul>';
                        newCursorPos = start + 9; // Position cursor in first list item
                    }
                    break;
                    
                case 'ol':
                    if (selectedText) {
                        var lines = selectedText.split('\n');
                        var listItems = lines.map(function(line) {
                            return line.trim() ? '<li>' + line.trim() + '</li>' : '';
                        }).filter(function(item) {
                            return item !== '';
                        });
                        newText = '<ol>\n' + listItems.join('\n') + '\n</ol>';
                    } else {
                        newText = '<ol>\n<li></li>\n</ol>';
                        newCursorPos = start + 9; // Position cursor in first list item
                    }
                    break;
            }
            
            if (newText) {
                // Update textarea content
                textarea.value = beforeText + newText + afterText;
                
                // Set cursor position
                textarea.focus();
                textarea.setSelectionRange(newCursorPos, newCursorPos);
                
                // Trigger change event
                $textarea.trigger('change');
            }
        }
    };

    /**
     * Initialize when document is ready
     */
    $(document).ready(function() {
        ContentRestrictionAdmin.init();
    });

})(jQuery);