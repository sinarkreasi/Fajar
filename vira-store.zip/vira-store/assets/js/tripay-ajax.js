/**
 * TriPay AJAX Payment Handler
 *
 * @package Vira_Store
 * @since 1.0.0
 *
 * ⚠️ DEPRECATED: This file has been disabled to prevent conflicts with tripay-checkout.js
 * The tripay-checkout.js file provides enhanced error handling and better user experience.
 *
 * If you need to re-enable this file, please disable tripay-checkout.js first
 * to avoid duplicate event handlers causing payment processing issues.
 *
 * Date Disabled: 2025-10-30
 * Reason: JavaScript redundancy - two handlers for same TriPay functionality
 */

/*
(function($) {
    'use strict';

    // DISABLED - See file header comment for details
    // This functionality is now handled by tripay-checkout.js

    var TriPayPayment = {

        init: function() {
            this.bindEvents();
        },

        bindEvents: function() {
            $(document).on('submit', '.vrstore-checkout-form', this.handleCheckoutSubmit);
        },

        handleCheckoutSubmit: function(e) {
            var paymentMethod = $('#vrstore_payment_method').val();

            if (paymentMethod !== 'tripay') {
                return;
            }

            var tripayMethod = $('#vrstore_tripay_method').val();
            if (!tripayMethod) {
                alert('Please select a TriPay payment method.');
                e.preventDefault();
                return false;
            }

            e.preventDefault();
            TriPayPayment.processCheckout($(this));
        },

        processCheckout: function($form) {
            var $submitBtn = $form.find('button[type="submit"]');
            var originalText = $submitBtn.text();
            $submitBtn.prop('disabled', true).text('Processing...');

            var formData = $form.serialize();
            formData += '&action=vrstore_process_tripay_payment';

            $.ajax({
                url: vrstore_ajax ? vrstore_ajax.ajax_url : ajaxurl,
                type: 'POST',
                data: formData,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        TriPayPayment.handlePaymentSuccess(response.data);
                    } else {
                        TriPayPayment.showMessage('error', response.data.message || 'Payment failed');
                        $submitBtn.prop('disabled', false).text(originalText);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('TriPay AJAX error:', error);
                    TriPayPayment.showMessage('error', 'Payment processing failed. Please try again.');
                    $submitBtn.prop('disabled', false).text(originalText);
                }
            });
        },

        handlePaymentSuccess: function(response) {
            console.log('TriPay payment success:', response);

            this.showMessage('success', response.message || 'Redirecting to payment...');

            if (response.redirect_url) {
                setTimeout(function() {
                    window.location.href = response.redirect_url;
                }, 1000);
            }
        },

        showMessage: function(type, message) {
            $('.vrstore-message').remove();

            var messageClass = 'vrstore-message vrstore-message-' + type;
            var messageHtml = '<div class="' + messageClass + '">' + message + '</div>';

            var $form = $('.vrstore-checkout-form');
            if ($form.length) {
                $form.prepend(messageHtml);
            } else {
                $('body').prepend(messageHtml);
            }

            if (type === 'success' || type === 'info') {
                setTimeout(function() {
                    $('.' + messageClass).fadeOut();
                }, 5000);
            }
        }
    };

    // DISABLED - Initialization commented out
    // $(document).ready(function() {
    //     TriPayPayment.init();
    // });

})(jQuery);
*/