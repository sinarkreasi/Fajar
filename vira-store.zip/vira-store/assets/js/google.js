/**
 * VR Store Google Login Module
 * Handles all Google OAuth login functionality
 * 
 * @version 1.0.0
 * @author VR Store Team
 */

(function($) {
    'use strict';

    /**
     * Google Login Class
     */
    class VRStoreGoogleLogin {
        constructor() {
            this.isInitialized = false;
            this.config = {
                accountButtonId: 'vrstore-google-login-btn',
                checkoutButtonId: 'vrstore-checkout-google-login-btn',
                traditionalLoginToggleId: 'vrstore-show-traditional-login',
                traditionalLoginFormsId: 'vrstore-traditional-login-forms',
                oauthEndpoint: 'https://accounts.google.com/oauth2/auth',
                scope: 'email profile',
                responseType: 'code',
                accessType: 'offline',
                prompt: 'select_account',
                redirectDelay: 750
            };
            this.buttons = [];
            this.storageKey = 'vrstorePostLoginRedirect';
            this.cookieKey = 'vrstore_post_login_redirect';
            
            // Bind methods to preserve context
            this.handleButtonClick = this.handleButtonClick.bind(this);
            this.handleTraditionalLoginToggle = this.handleTraditionalLoginToggle.bind(this);
            
            // Initialize when DOM is ready
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', () => this.init());
            } else {
                this.init();
            }
        }

        /**
         * Initialize Google Login functionality
         */
                init() {
                    if (this.isInitialized) {
                        return;
                    }

                    // Find and initialize all Google login buttons
                    this.initializeButtons();
                    
                    // Initialize traditional login toggle
                    this.initializeTraditionalLoginToggle();
                    
                    // Add required CSS for loading states
                    this.addRequiredCSS();
                    
                    // Handle pending redirect after login
                    this.handlePendingRedirect();
                    
                    // Mark as initialized
                    this.isInitialized = true;
        }

        /**
         * Find and initialize all Google login buttons
         */
        initializeButtons() {
            // Account page button
            const accountButton = document.getElementById(this.config.accountButtonId);
            if (accountButton) {
                this.setupButton(accountButton, 'account');
            }

            // Checkout page button
            const checkoutButton = document.getElementById(this.config.checkoutButtonId);
            if (checkoutButton) {
                this.setupButton(checkoutButton, 'checkout');
            }

                    // Also check for buttons that might be added dynamically
                    this.observeForDynamicButtons();
        }

        /**
         * Setup a Google login button with event listeners
         */
        setupButton(button, type = 'default') {
            if (!button) return;

            // Check if button is already initialized
            if (button.hasAttribute('data-vrstore-google-initialized')) {
                return;
            }

            // Validate required data attributes
            const clientId = button.getAttribute('data-client-id');
            const redirectUri = button.getAttribute('data-redirect-uri');

            if (!clientId || !redirectUri) {
                console.error('VRStoreGoogleLogin: Missing required data attributes on button', button);
                this.showButtonError(button, 'Configuration missing');
                return;
            }

            // Remove any existing event listeners
            button.removeEventListener('click', this.handleButtonClick);
            
            // Add fresh event listener
            button.addEventListener('click', this.handleButtonClick);
            
            // Mark as initialized
            button.setAttribute('data-vrstore-google-initialized', 'true');
            button.setAttribute('data-button-type', type);

                    // Store button reference
                    this.buttons.push({
                        element: button,
                        type: type,
                        clientId: clientId,
                        redirectUri: redirectUri
                    });
        }

        /**
         * Handle button click events
         */
        handleButtonClick(event) {
            event.preventDefault();
            event.stopPropagation();

                    const button = event.currentTarget;
                    const clientId = button.getAttribute('data-client-id');
                    const redirectUri = button.getAttribute('data-redirect-uri');

            // Validate configuration
            if (!clientId) {
                this.showNotification('Google login is not properly configured.', 'error');
                return;
            }

            if (!redirectUri) {
                this.showNotification('Google redirect URI is missing.', 'error');
                return;
            }

            // Prevent double-clicks
            if (button.disabled) {
                return;
            }

            this.preparePostLoginRedirect(button);

            // Start OAuth flow
            this.startOAuthFlow(button, clientId, redirectUri);
        }

        /**
         * Start the Google OAuth flow
         */
        startOAuthFlow(button, clientId, redirectUri) {
            try {
                        // Build OAuth URL
                        const authUrl = this.buildOAuthUrl(clientId, redirectUri);

                // Show loading state
                this.showButtonLoading(button);

                // Redirect after delay for user feedback
                setTimeout(() => {
                    window.location.href = authUrl;
                }, this.config.redirectDelay);

            } catch (error) {
                console.error('VRStoreGoogleLogin: Error starting OAuth flow', error);
                this.showNotification('Failed to start Google login. Please try again.', 'error');
                this.resetButton(button);
            }
        }

        /**
         * Build Google OAuth URL
         */
        buildOAuthUrl(clientId, redirectUri) {
            const params = new URLSearchParams({
                client_id: clientId,
                redirect_uri: redirectUri,
                response_type: this.config.responseType,
                scope: this.config.scope,
                access_type: this.config.accessType,
                prompt: this.config.prompt,
                state: btoa(JSON.stringify({
                    redirect_url: window.location.href,
                    timestamp: Date.now(),
                    version: '1.0'
                }))
            });

            return `${this.config.oauthEndpoint}?${params.toString()}`;
        }

        /**
         * Show loading state on button
         */
        showButtonLoading(button) {
            if (!button) return;

            // Store original content
            if (!button.hasAttribute('data-original-content')) {
                button.setAttribute('data-original-content', button.innerHTML);
            }

            // Show loading state
            button.innerHTML = `
                <div class="vrstore-google-btn-loading">
                    <div class="vrstore-google-spinner"></div>
                    <span>Redirecting...</span>
                </div>
            `;
            
                    button.disabled = true;
                    button.classList.add('vrstore-loading');
        }

        /**
         * Reset button to original state
         */
        resetButton(button) {
            if (!button) return;

            const originalContent = button.getAttribute('data-original-content');
            if (originalContent) {
                button.innerHTML = originalContent;
            }
            
                    button.disabled = false;
                    button.classList.remove('vrstore-loading');
        }

        /**
         * Show error state on button
         */
        showButtonError(button, message) {
            if (!button) return;

            button.innerHTML = `
                <div class="vrstore-google-btn-error">
                    <span class="error-icon">⚠</span>
                    <span>${message}</span>
                </div>
            `;
            
            button.disabled = true;
            button.classList.add('vrstore-error');

            // Reset after 3 seconds
            setTimeout(() => this.resetButton(button), 3000);
        }

        /**
         * Initialize traditional login toggle functionality
         */
        initializeTraditionalLoginToggle() {
            const toggleButton = document.getElementById(this.config.traditionalLoginToggleId);
            const formsContainer = document.getElementById(this.config.traditionalLoginFormsId);

                    if (toggleButton && formsContainer) {
                        toggleButton.addEventListener('click', this.handleTraditionalLoginToggle);
                    }
        }

        /**
         * Handle traditional login toggle click
         */
        handleTraditionalLoginToggle(event) {
            event.preventDefault();
            
            const formsContainer = document.getElementById(this.config.traditionalLoginFormsId);
            const toggleContainer = event.target.closest('.vrstore-traditional-login-toggle');

            if (formsContainer) {
                formsContainer.style.display = 'block';
                
                // Add smooth transition
                formsContainer.classList.add('vrstore-fade-in');
            }

                    if (toggleContainer) {
                        toggleContainer.style.display = 'none';
                    }
        }

        /**
         * Observe for dynamically added buttons
         */
        observeForDynamicButtons() {
            if (!window.MutationObserver) return;

            const observer = new MutationObserver((mutations) => {
                mutations.forEach((mutation) => {
                    mutation.addedNodes.forEach((node) => {
                        if (node.nodeType === Node.ELEMENT_NODE) {
                            // Check if the node itself is a Google login button
                            if (node.id === this.config.accountButtonId || node.id === this.config.checkoutButtonId) {
                                this.setupButton(node, node.id === this.config.checkoutButtonId ? 'checkout' : 'account');
                            }
                            
                            // Check for buttons within the added node
                            const accountButton = node.querySelector ? node.querySelector(`#${this.config.accountButtonId}`) : null;
                            const checkoutButton = node.querySelector ? node.querySelector(`#${this.config.checkoutButtonId}`) : null;
                            
                            if (accountButton) this.setupButton(accountButton, 'account');
                            if (checkoutButton) this.setupButton(checkoutButton, 'checkout');
                        }
                    });
                });
            });

                    observer.observe(document.body, {
                        childList: true,
                        subtree: true
                    });
        }

        /**
         * Add required CSS for loading states and animations
         */
        addRequiredCSS() {
            if (document.getElementById('vrstore-google-login-css')) {
                return; // Already added
            }

            const style = document.createElement('style');
            style.id = 'vrstore-google-login-css';
            style.textContent = `
                /* Google Login Loading States */
                .vrstore-google-btn-loading {
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    gap: 8px;
                    font-size: var(--vrstore-font-size-sm, 14px);
                    color: #5f6368;
                    font-weight: 500;
                }

                .vrstore-google-spinner {
                    width: 18px;
                    height: 18px;
                    border: 2px solid #e8eaed;
                    border-top: 2px solid #4285f4;
                    border-radius: 50%;
                    animation: vrstore-google-spin 1s linear infinite;
                    flex-shrink: 0;
                }

                @keyframes vrstore-google-spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }

                .vrstore-google-btn-error {
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    gap: 6px;
                    font-size: var(--vrstore-font-size-xs, 12px);
                    color: #d93025;
                }

                .vrstore-google-login-btn.vrstore-loading {
                    cursor: wait;
                }

                .vrstore-google-login-btn.vrstore-error {
                    border-color: #d93025;
                    background-color: #fce8e6;
                }

                .vrstore-fade-in {
                    animation: vrstore-fade-in 0.3s ease-in-out;
                }

                @keyframes vrstore-fade-in {
                    from {
                        opacity: 0;
                        transform: translateY(-10px);
                    }
                    to {
                        opacity: 1;
                        transform: translateY(0);
                    }
                }

                /* Accessibility improvements */
                @media (prefers-reduced-motion: reduce) {
                    .vrstore-google-spinner {
                        animation: none;
                        border: 2px solid #4285f4;
                        border-radius: 2px;
                    }
                    
                    .vrstore-fade-in {
                        animation: none;
                    }
                }
            `;

                    document.head.appendChild(style);
        }

        preparePostLoginRedirect(button) {
            try {
                const targetUrl = this.getPreferredRedirectUrl(button);
                if (targetUrl) {
                    this.setPostLoginRedirect(targetUrl);
                } else {
                    this.clearPostLoginRedirect();
                }
            } catch (error) {
                if (typeof console !== 'undefined' && console.warn) {
                    console.warn('VRStoreGoogleLogin: Unable to store post-login redirect', error);
                }
            }
        }

        getPreferredRedirectUrl() {
            const data = typeof window !== 'undefined' && window.vrstoreGoogleLoginData ? window.vrstoreGoogleLoginData : {};
            const checkoutUrl = typeof data.checkoutUrl === 'string' ? data.checkoutUrl : '';
            const cartCount = parseInt(data.cartCount, 10) || 0;

            if (cartCount > 0 && checkoutUrl && this.isSafeRedirect(checkoutUrl)) {
                return checkoutUrl;
            }

            const currentUrl = window.location.href;
            return this.isSafeRedirect(currentUrl) ? currentUrl : '';
        }

        handlePendingRedirect() {
            const redirectUrl = this.getPostLoginRedirect();
            if (!redirectUrl) {
                return;
            }

            if (!this.isUserLoggedIn() || !this.isSafeRedirect(redirectUrl)) {
                this.clearPostLoginRedirect();
                return;
            }

            const currentUrl = this.normalizeUrl(window.location.href);
            const targetUrl = this.normalizeUrl(redirectUrl);

            if (currentUrl === targetUrl) {
                this.clearPostLoginRedirect();
                return;
            }

            this.clearPostLoginRedirect();
            window.location.href = redirectUrl;
        }

        isUserLoggedIn() {
            if (typeof window !== 'undefined' && window.vrstoreGoogleLoginData && typeof window.vrstoreGoogleLoginData.loggedIn !== 'undefined') {
                return !!window.vrstoreGoogleLoginData.loggedIn;
            }

            if (document.body) {
                return document.body.classList.contains('logged-in');
            }

            return false;
        }

        storageAvailable(type) {
            try {
                const storage = window[type];
                const testKey = '__vrstore_storage_test__';
                storage.setItem(testKey, testKey);
                storage.removeItem(testKey);
                return true;
            } catch (error) {
                return false;
            }
        }

        setPostLoginRedirect(url) {
            if (!url || !this.isSafeRedirect(url)) {
                return;
            }

            if (this.storageAvailable('sessionStorage')) {
                try {
                    window.sessionStorage.setItem(this.storageKey, url);
                    return;
                } catch (error) {
                    // Fall back to cookie
                }
            }

            this.setCookie(this.cookieKey, url, 600);
        }

        getPostLoginRedirect() {
            let url = '';

            if (this.storageAvailable('sessionStorage')) {
                try {
                    url = window.sessionStorage.getItem(this.storageKey) || '';
                } catch (error) {
                    url = '';
                }
            }

            if (url) {
                return url;
            }

            return this.getCookie(this.cookieKey) || '';
        }

        clearPostLoginRedirect() {
            if (this.storageAvailable('sessionStorage')) {
                try {
                    window.sessionStorage.removeItem(this.storageKey);
                } catch (error) {
                    // Ignore
                }
            }

            this.deleteCookie(this.cookieKey);
        }

        setCookie(name, value, seconds) {
            if (!name || typeof document === 'undefined') {
                return;
            }

            const maxAge = typeof seconds === 'number' ? `; max-age=${seconds}` : '';
            const secure = window.location.protocol === 'https:' ? '; secure' : '';
            document.cookie = `${name}=${encodeURIComponent(value)}${maxAge}; path=/; SameSite=Lax${secure}`;
        }

        getCookie(name) {
            if (!name || typeof document === 'undefined') {
                return '';
            }

            const cookies = document.cookie ? document.cookie.split('; ') : [];
            for (let i = 0; i < cookies.length; i++) {
                const parts = cookies[i].split('=');
                const key = parts.shift();
                if (key === name) {
                    return decodeURIComponent(parts.join('='));
                }
            }

            return '';
        }

        deleteCookie(name) {
            if (!name || typeof document === 'undefined') {
                return;
            }

            const secure = window.location.protocol === 'https:' ? '; secure' : '';
            document.cookie = `${name}=; path=/; max-age=0; SameSite=Lax${secure}`;
        }

        normalizeUrl(url) {
            if (!url) {
                return '';
            }

            try {
                const parsed = new URL(url, window.location.origin);
                const normalizedPath = parsed.pathname.replace(/\/+$/, '') || '/';
                return `${parsed.origin}${normalizedPath}${parsed.search}`;
            } catch (error) {
                return url;
            }
        }

        isSafeRedirect(url) {
            if (!url || typeof url !== 'string') {
                return false;
            }

            try {
                const target = new URL(url, window.location.origin);
                return target.origin === window.location.origin;
            } catch (error) {
                return false;
            }
        }

        /**
         * Show notification to user
         */
        showNotification(message, type = 'info') {
            // Try to use existing notification system first
            if (typeof window.showNotification === 'function') {
                window.showNotification(message, type);
                return;
            }

                    // Show browser alert as fallback
            if (type === 'error') {
                alert(`Error: ${message}`);
            }
        }

        /**
         * Destroy the instance and clean up event listeners
         */
        destroy() {
            // Remove event listeners from buttons
            this.buttons.forEach(buttonInfo => {
                if (buttonInfo.element) {
                    buttonInfo.element.removeEventListener('click', this.handleButtonClick);
                    buttonInfo.element.removeAttribute('data-vrstore-google-initialized');
                }
            });

            // Clean up traditional login toggle
            const toggleButton = document.getElementById(this.config.traditionalLoginToggleId);
            if (toggleButton) {
                toggleButton.removeEventListener('click', this.handleTraditionalLoginToggle);
            }

                    // Reset state
                    this.buttons = [];
                    this.isInitialized = false;
        }

        /**
         * Get current configuration
         */
        getConfig() {
            return { ...this.config };
        }

        /**
         * Get initialized buttons
         */
        getButtons() {
            return [...this.buttons];
        }

        /**
         * Manually reinitialize if needed
         */
                reinitialize() {
                    this.destroy();
                    setTimeout(() => this.init(), 100);
                }
    }

    /**
     * Global instance and initialization
     */
    
    // Create global instance
    window.VRStoreGoogleLogin = VRStoreGoogleLogin;
    
            // Auto-initialize
            const googleLoginInstance = new VRStoreGoogleLogin();
            
            // Make instance available globally
            window.vrStoreGoogleLogin = googleLoginInstance;
            
            // jQuery integration for backward compatibility
            if (typeof $ !== 'undefined') {
                $.fn.vrStoreGoogleLogin = function(options) {
                    return this.each(function() {
                        const $this = $(this);
                        
                        if (this.id === googleLoginInstance.config.accountButtonId || 
                            this.id === googleLoginInstance.config.checkoutButtonId) {
                            
                            googleLoginInstance.setupButton(this, options && options.type ? options.type : 'default');
                        }
                    });
                };
            }

})(typeof jQuery !== 'undefined' ? jQuery : null);