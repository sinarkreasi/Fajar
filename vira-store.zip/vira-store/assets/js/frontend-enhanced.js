/**
 * Enhanced Vira Store Frontend JavaScript
 * 
 * @package Vira_Store
 * @since 1.0.0
 */

jQuery(document).ready(function($) {
    'use strict';

    /**
     * Dropdown System for Action Menus
     */
    const DropdownSystem = {
        init: function() {
            this.bindEvents();
        },

        bindEvents: function() {
            // Handle dropdown toggle clicks
            $(document).on('click', '.vrstore-dropdown-toggle', this.handleToggleClick);
            
            // Handle dropdown item clicks
            $(document).on('click', '.vrstore-dropdown-item', this.handleItemClick);
            
            // Close dropdowns when clicking outside
            $(document).on('click', this.handleOutsideClick);
            
            // Handle keyboard navigation
            $(document).on('keydown', '.vrstore-dropdown', this.handleKeydown);
        },

        handleToggleClick: function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const $dropdown = $(this).closest('.vrstore-dropdown');
            const $toggle = $(this);
            const isOpen = $dropdown.hasClass('vrstore-dropdown-open');
            
            // Close all other dropdowns
            $('.vrstore-dropdown').removeClass('vrstore-dropdown-open');
            $('.vrstore-dropdown-toggle').attr('aria-expanded', 'false');
            
            if (!isOpen) {
                $dropdown.addClass('vrstore-dropdown-open');
                $toggle.attr('aria-expanded', 'true');
                
                // Focus first menu item
                setTimeout(() => {
                    $dropdown.find('.vrstore-dropdown-item').first().focus();
                }, 100);
            }
        },

        handleItemClick: function(e) {
            // Don't prevent default for links
            if ($(this).is('a')) {
                return;
            }
            
            e.preventDefault();
            e.stopPropagation();
            
            // Close dropdown
            $(this).closest('.vrstore-dropdown').removeClass('vrstore-dropdown-open');
            $(this).closest('.vrstore-dropdown').find('.vrstore-dropdown-toggle').attr('aria-expanded', 'false');
        },

        handleOutsideClick: function(e) {
            if (!$(e.target).closest('.vrstore-dropdown').length) {
                $('.vrstore-dropdown').removeClass('vrstore-dropdown-open');
                $('.vrstore-dropdown-toggle').attr('aria-expanded', 'false');
            }
        },

        handleKeydown: function(e) {
            const $dropdown = $(this);
            const $items = $dropdown.find('.vrstore-dropdown-item');
            const $focused = $items.filter(':focus');
            
            switch (e.key) {
                case 'Escape':
                    e.preventDefault();
                    $dropdown.removeClass('vrstore-dropdown-open');
                    $dropdown.find('.vrstore-dropdown-toggle').attr('aria-expanded', 'false').focus();
                    break;
                    
                case 'ArrowDown':
                    e.preventDefault();
                    if ($focused.length === 0) {
                        $items.first().focus();
                    } else {
                        const nextIndex = ($items.index($focused) + 1) % $items.length;
                        $items.eq(nextIndex).focus();
                    }
                    break;
                    
                case 'ArrowUp':
                    e.preventDefault();
                    if ($focused.length === 0) {
                        $items.last().focus();
                    } else {
                        const prevIndex = ($items.index($focused) - 1 + $items.length) % $items.length;
                        $items.eq(prevIndex).focus();
                    }
                    break;
                    
                case 'Enter':
                case ' ':
                    if ($focused.length > 0) {
                        e.preventDefault();
                        $focused.click();
                    }
                    break;
            }
        }
    };

    /**
     * Enhanced Tab System for Customer Portal
     */
    const TabSystem = {
        init: function() {
            this.bindEvents();
            this.setActiveTab();
            this.handleHashChange();
        },

        bindEvents: function() {
            $(document).on('click', '.vrstore-tabs-nav a', this.handleTabClick);
            $(window).on('hashchange', this.handleHashChange.bind(this));
            // Handle "View All" links in dashboard
            $(document).on('click', '.vrstore-view-all', this.handleViewAllClick);
        },

        handleTabClick: function(e) {
            e.preventDefault();
            
            const $tab = $(this);
            const targetTab = $tab.attr('href').substring(1);
            
            // Remove URL hash instead of updating it
            if (history.pushState) {
                history.pushState(null, null, window.location.pathname + window.location.search);
            }
            
            TabSystem.switchTab(targetTab);
        },

        handleViewAllClick: function(e) {
            e.preventDefault();
            
            const targetTab = $(this).attr('href').substring(1);
            
            // Remove URL hash instead of updating it
            if (history.pushState) {
                history.pushState(null, null, window.location.pathname + window.location.search);
            }
            
            TabSystem.switchTab(targetTab);
        },

        handleHashChange: function() {
            // For product page, always keep description tab active and remove hash
            if ($('#vrstore-tab-description').length > 0) {
                this.switchTab('vrstore-tab-description');
                // Remove any hash from URL
                if (history.pushState && window.location.hash) {
                    history.pushState(null, null, window.location.pathname + window.location.search);
                }
            } else {
                // For other pages (like customer portal), handle hash changes normally
                const hash = window.location.hash.substring(1);
                if (hash && $('.vrstore-tab-content[id="' + hash + '"]').length > 0) {
                    this.switchTab(hash);
                } else if (hash === 'cart') {
                    this.switchTab('cart');
                }
            }
        },

        switchTab: function(targetTab) {
            const $nav = $('.vrstore-tabs-nav');
            const $content = $('.vrstore-tabs-content');
            
            // Update navigation
            $nav.find('a').removeClass('active');
            $nav.find('a[href="#' + targetTab + '"]').addClass('active');
            
            // Update content - use both CSS classes and display styles for maximum compatibility
            $content.find('.vrstore-tab-content')
                .removeClass('active vrstore-tab-active')
                .addClass('vrstore-tab-hidden')
                .hide()
                .css('display', 'none'); // Force hide
            
            // Show target tab with both methods for compatibility
            const $targetContent = $content.find('#' + targetTab);
            
            if ($targetContent.length === 0) {
                return;
            }
            
            $targetContent
                .removeClass('vrstore-tab-hidden')
                .addClass('active vrstore-tab-active')
                .show()
                .css('display', 'block'); // Force display block
            
            // Ensure the content is actually visible by removing any conflicting styles
            $targetContent.css({
                'opacity': '1',
                'visibility': 'visible',
                'pointer-events': 'auto'
            });
            
            
            // Store active tab in localStorage for tabs persistence
            const $tabContainer = $nav.closest('.vrstore-tabs');
            if ($tabContainer.length > 0) {
                try {
                    localStorage.setItem('vrstore_active_tab', '#' + targetTab);
                } catch (e) {
                    // Ignore localStorage errors
                }
            }
        },

        setActiveTab: function() {
            // For product page, always set description tab as active
            if ($('#vrstore-tab-description').length > 0) {
                this.switchTab('vrstore-tab-description');
                // Remove any hash from URL
                if (history.pushState && window.location.hash) {
                    history.pushState(null, null, window.location.pathname + window.location.search);
                }
            } else {
                // For other pages (like customer portal)
                let activeTab = null;
                
                // First check URL hash
                const hash = window.location.hash.substring(1);
                if (hash && $('.vrstore-tab-content[id="' + hash + '"]').length > 0) {
                    activeTab = hash;
                } else if (hash === 'cart') {
                    activeTab = 'cart';
                }
                
                // Check for saved tab state in localStorage if no URL hash
                if (!activeTab && $('.vrstore-tabs').length > 0) {
                    try {
                        const savedTab = localStorage.getItem('vrstore_active_tab');
                        if (savedTab) {
                            const savedTabId = savedTab.startsWith('#') ? savedTab.substring(1) : savedTab;
                            if ($('.vrstore-tab-content[id="' + savedTabId + '"]').length > 0) {
                                activeTab = savedTabId;
                            }
                        }
                    } catch (e) {
                        // Ignore localStorage errors
                    }
                }
                
                // If no saved state or URL hash, find the first available tab or use the one marked as active in HTML
                if (!activeTab) {
                    // Check if there's already an active tab in the HTML
                    const $activeNavTab = $('.vrstore-tabs-nav a.active');
                    if ($activeNavTab.length > 0) {
                        const htmlActiveTab = $activeNavTab.attr('href').substring(1);
                        if ($('.vrstore-tab-content[id="' + htmlActiveTab + '"]').length > 0) {
                            activeTab = htmlActiveTab;
                        }
                    }
                    
                    // If still no active tab, use the first available tab
                    if (!activeTab) {
                        const $firstTab = $('.vrstore-tabs-nav a').first();
                        if ($firstTab.length > 0) {
                            activeTab = $firstTab.attr('href').substring(1);
                        }
                    }
                }
                
                if (activeTab) {
                    this.switchTab(activeTab);
                }
            }
        }
    };

    /**
     * License Key Copy Functionality
     */
    const LicenseCopy = {
        init: function() {
            this.bindEvents();
        },

        bindEvents: function() {
            $(document).on('click', '.vrstore-copy-license-key', this.copyLicenseKey);
        },

        copyLicenseKey: function(e) {
            e.preventDefault();
            
            const $button = $(this);
            const $wrapper = $button.closest('.vrstore-license-key-wrapper');
            const $keyField = $wrapper.find('.vrstore-license-key');
            const licenseKey = $keyField.text().trim();
            
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(licenseKey).then(function() {
                    LicenseCopy.showCopySuccess($button);
                }).catch(function() {
                    LicenseCopy.fallbackCopy($keyField, $button);
                });
            } else {
                LicenseCopy.fallbackCopy($keyField, $button);
            }
        },

        fallbackCopy: function($keyField, $button) {
            // Create a temporary input field
            const $temp = $('<input>');
            $('body').append($temp);
            $temp.val($keyField.text().trim()).select();
            
            try {
                document.execCommand('copy');
                this.showCopySuccess($button);
            } catch (err) {
                this.showCopyError($button);
            }
            
            $temp.remove();
        },

        showCopySuccess: function($button) {
            const originalHtml = $button.html();
            
            $button.addClass('copied')
                   .html('Copied!')
                   .attr('title', 'Copied!');
            
            setTimeout(function() {
                $button.removeClass('copied')
                       .html(originalHtml)
                       .attr('title', 'Copy to clipboard');
            }, 2000);
        },

        showCopyError: function($button) {
            const originalHtml = $button.html();
            
            $button.addClass('error')
                   .html('Copy failed')
                   .attr('title', 'Copy failed');
            
            setTimeout(function() {
                $button.removeClass('error')
                       .html(originalHtml)
                       .attr('title', 'Copy to clipboard');
            }, 2000);
        }
    };

    /**
     * Enhanced Table Interactions
     */
    const TableEnhancements = {
        init: function() {
            this.bindEvents();
            this.setupResponsiveTables();
        },

        bindEvents: function() {
            $(document).on('mouseenter', '.vrstore-purchases-table tr, .vrstore-licenses-table tr, .vrstore-activations-table tr', this.handleRowHover);
            $(document).on('mouseleave', '.vrstore-purchases-table tr, .vrstore-licenses-table tr, .vrstore-activations-table tr', this.handleRowLeave);
        },

        handleRowHover: function() {
            $(this).addClass('hover-highlight');
        },

        handleRowLeave: function() {
            $(this).removeClass('hover-highlight');
        },

        setupResponsiveTables: function() {
            $('.vrstore-purchases-table, .vrstore-licenses-table, .vrstore-activations-table').each(function() {
                const $table = $(this);
                const $wrapper = $('<div class="vrstore-table-responsive"></div>');
                $table.wrap($wrapper);
            });
        }
    };

    /**
     * Authentication System
     */
    const AuthSystem = {
        init: function() {
            this.bindEvents();
        },

        bindEvents: function() {
            // Handle tab switching
            $(document).on('click', '.vrstore-auth-tab', this.handleTabSwitch);
            $(document).on('click', '.vrstore-auth-link[data-tab]', this.handleTabSwitch);
            
            // Handle form submissions
            $(document).on('submit', '#vrstore-forgot-password-form-element', this.handleForgotPassword);
            $(document).on('submit', '#vrstore-reset-password-form-element', this.handleResetPassword);
            
            // Handle message close buttons
            $(document).on('click', '.vrstore-message-close', this.handleMessageClose);
        },

        handleTabSwitch: function(e) {
            e.preventDefault();
            
            const $link = $(this);
            const targetTab = $link.data('tab');
            
            if (!targetTab) return;

            // For forgot-password, redirect to URL with parameter to show the form
            if (targetTab === 'forgot-password') {
                const newUrl = window.location.pathname + '?action=forgot-password';
                window.location.href = newUrl;
                return;
            }

            // Update active tab (only for actual tabs)
            $('.vrstore-auth-tab').removeClass('active');
            $link.addClass('active');
            
            // Update forms
            $('.vrstore-auth-form').removeClass('active');
            $('#vrstore-' + targetTab + '-form').addClass('active');
            
            // Update URL without page refresh
            if (targetTab !== 'signin') {
                const newUrl = window.location.pathname + '?action=' + targetTab;
                window.history.pushState({}, '', newUrl);
            } else {
                const newUrl = window.location.pathname;
                window.history.pushState({}, '', newUrl);
            }
        },

        handleForgotPassword: function(e) {
            e.preventDefault();
            
            const $form = $(this);
            const $submitBtn = $form.find('button[type="submit"]');
            const originalBtnText = $submitBtn.text();
            
            // Disable submit button and show loading
            $submitBtn.prop('disabled', true).text('Sending...');
            
            // Prepare form data
            const formData = new FormData(this);
            
            $.ajax({
                url: vrstore_frontend.ajax_url,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        AuthSystem.showMessage(response.data.message, 'success');
                        $form[0].reset();
                    } else {
                        AuthSystem.showMessage(response.data.message || 'An error occurred.', 'error');
                    }
                },
                error: function() {
                    AuthSystem.showMessage('Network error. Please try again.', 'error');
                },
                complete: function() {
                    $submitBtn.prop('disabled', false).text(originalBtnText);
                }
            });
        },

        handleResetPassword: function(e) {
            e.preventDefault();
            
            const $form = $(this);
            const $submitBtn = $form.find('button[type="submit"]');
            const originalBtnText = $submitBtn.text();
            const newPassword = $form.find('input[name="new_password"]').val();
            const confirmPassword = $form.find('input[name="confirm_password"]').val();
            
            // Client-side validation
            if (newPassword !== confirmPassword) {
                AuthSystem.showMessage('Passwords do not match.', 'error');
                return;
            }
            
            if (newPassword.length < 6) {
                AuthSystem.showMessage('Password must be at least 6 characters long.', 'error');
                return;
            }
            
            // Disable submit button and show loading
            $submitBtn.prop('disabled', true).text('Resetting...');
            
            // Prepare form data
            const formData = new FormData(this);
            
            $.ajax({
                url: vrstore_frontend.ajax_url,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        AuthSystem.showMessage(response.data.message, 'success');
                        setTimeout(function() {
                            // Redirect to login form
                            window.location.href = window.location.pathname;
                        }, 3000);
                    } else {
                        AuthSystem.showMessage(response.data.message || 'An error occurred.', 'error');
                    }
                },
                error: function() {
                    AuthSystem.showMessage('Network error. Please try again.', 'error');
                },
                complete: function() {
                    $submitBtn.prop('disabled', false).text(originalBtnText);
                }
            });
        },

        handleMessageClose: function(e) {
            e.preventDefault();
            $(this).closest('.vrstore-message').fadeOut();
        },

        showMessage: function(message, type) {
            // Remove existing messages
            $('.vrstore-auth-message').remove();
            
            // Create new message element
            const messageClass = type === 'success' ? 'vrstore-message-success' : 'vrstore-message-error';
            const messageHtml = `
                <div class="vrstore-auth-message vrstore-message ${messageClass}">
                    <span>${message}</span>
                    <button type="button" class="vrstore-message-close" aria-label="Close">&times;</button>
                </div>
            `;
            
            // Add message to the top of auth box
            $('.vrstore-auth-box').prepend(messageHtml);
            
            // Auto-hide success messages after 5 seconds
            if (type === 'success') {
                setTimeout(function() {
                    $('.vrstore-message-success').fadeOut();
                }, 5000);
            }
        }
    };

    /**
     * Form Enhancement System
     */
    const FormEnhancements = {
        init: function() {
            this.bindEvents();
            this.setupFormValidation();
        },

        bindEvents: function() {
            $(document).on('focus', '.vrstore-form-row input, .vrstore-checkout-form input, .vrstore-checkout-form select, .vrstore-checkout-form textarea', this.handleFocusIn);
            $(document).on('blur', '.vrstore-form-row input, .vrstore-checkout-form input, .vrstore-checkout-form select, .vrstore-checkout-form textarea', this.handleFocusOut);
            $(document).on('input', '.vrstore-form-row input, .vrstore-checkout-form input', this.handleInputChange);
        },

        handleFocusIn: function() {
            $(this).closest('.vrstore-form-row, .form-row').addClass('focused');
        },

        handleFocusOut: function() {
            const $field = $(this);
            const $wrapper = $field.closest('.vrstore-form-row, .form-row');
            
            $wrapper.removeClass('focused');
            
            if ($field.val().trim() !== '') {
                $wrapper.addClass('has-value');
            } else {
                $wrapper.removeClass('has-value');
            }
        },

        handleInputChange: function() {
            const $field = $(this);
            const value = $field.val().trim();
            
            if (value !== '') {
                $field.closest('.vrstore-form-row, .form-row').addClass('has-value');
            } else {
                $field.closest('.vrstore-form-row, .form-row').removeClass('has-value');
            }
        },

        setupFormValidation: function() {
            // Basic client-side validation
            $('.vrstore-checkout-form').on('submit', function(e) {
                const $form = $(this);
                let isValid = true;
                
                $form.find('input[required], select[required], textarea[required]').each(function() {
                    const $field = $(this);
                    const value = $field.val().trim();
                    
                    if (value === '') {
                        isValid = false;
                        $field.addClass('error');
                        $field.closest('.vrstore-form-row, .form-row').addClass('error');
                    } else {
                        $field.removeClass('error');
                        $field.closest('.vrstore-form-row, .form-row').removeClass('error');
                    }
                });
                
                if (!isValid) {
                    e.preventDefault();
                    FormEnhancements.showValidationMessage('Please fill in all required fields.');
                }
            });
        },

        showValidationMessage: function(message) {
            const $message = $('<div class="vrstore-message vrstore-message-error">' + message + '</div>');
            $('.vrstore-checkout').prepend($message);
            
            setTimeout(function() {
                $message.fadeOut(function() {
                    $message.remove();
                });
            }, 5000);
            
            // Scroll to top to show message
            $('html, body').animate({
                scrollTop: $message.offset().top - 20
            }, 500);
        }
    };

    /**
     * Message System Enhancements
     */
    const MessageSystem = {
        init: function() {
            this.setupAutoHide();
            this.bindEvents();
        },

        bindEvents: function() {
            $(document).on('click', '.vrstore-message', this.handleMessageClick);
        },

        setupAutoHide: function() {
            $('.vrstore-message').each(function() {
                const $message = $(this);
                
                // Add close button
                if (!$message.find('.vrstore-message-close').length) {
                    $message.append('<button type="button" class="vrstore-message-close" aria-label="Close">&times;</button>');
                }
                
                // Auto-hide after 8 seconds (except error messages)
                if (!$message.hasClass('vrstore-message-error')) {
                    setTimeout(function() {
                        if ($message.length) {
                            $message.fadeOut(function() {
                                $message.remove();
                            });
                        }
                    }, 8000);
                }
            });
        },

        handleMessageClick: function(e) {
            if ($(e.target).hasClass('vrstore-message-close')) {
                $(this).fadeOut(function() {
                    $(this).remove();
                });
            }
        }
    };

    /**
     * Smooth Scrolling for Internal Links
     */
    const SmoothScroll = {
        init: function() {
            this.bindEvents();
        },

        bindEvents: function() {
            $(document).on('click', 'a[href^="#"]:not(.vrstore-tabs-nav a)', this.handleSmoothScroll);
        },

        handleSmoothScroll: function(e) {
            const href = $(this).attr('href');
            const $target = $(href);
            
            if ($target.length) {
                e.preventDefault();
                
                $('html, body').animate({
                    scrollTop: $target.offset().top - 20
                }, 600);
            }
        }
    };

    /**
     * Loading States for Buttons (Selective Implementation)
     */
    const LoadingStates = {
        init: function() {
            this.bindEvents();
        },

        bindEvents: function() {
            // DISABLED: Only manual loading states now to prevent interference
            // Forms and buttons must explicitly call LoadingStates methods
        },

        handleButtonClick: function() {
            const $button = $(this);
            
            // Only proceed if explicitly requested
            if ($button.attr('data-loading') === 'true' && !$button.hasClass('no-loading')) {
                LoadingStates.setLoading($button);
            }
        },

        handleFormSubmit: function() {
            const $form = $(this);
            const $submitButton = $form.find('[type="submit"]').first();
            
            if ($submitButton.length && !$submitButton.hasClass('no-loading')) {
                LoadingStates.setLoading($submitButton);
            }
        },

        setLoading: function($button) {
            if ($button.hasClass('loading')) {
                return; // Already loading
            }
            
            const originalText = $button.html();
            $button.data('original-text', originalText)
                   .addClass('loading')
                   .prop('disabled', true)
                   .html('<span class="vrstore-spinner"></span> Processing...');
            
            // Remove loading state after reasonable time (failsafe)
            setTimeout(function() {
                LoadingStates.removeLoading($button);
            }, 30000);
        },

        removeLoading: function($button) {
            if (!$button.hasClass('loading')) {
                return;
            }
            
            const originalText = $button.data('original-text');
            $button.removeClass('loading')
                   .prop('disabled', false)
                   .html(originalText || ($button.attr('id') === 'vrstore-purchase-extended-support' ? 'Purchase' : 'Submit'));
        },

        // Enhanced Loading States
        showButtonLoading: function(button) {
            if (button) {
                $(button).addClass('loading').prop('disabled', true);
            }
        },

        hideButtonLoading: function(button) {
            if (button) {
                $(button).removeClass('loading').prop('disabled', false);
            }
        },

        showSpinner: function(container) {
            if (container) {
                const $container = $(container);
                const $spinner = $container.find('.vrstore-spinner, .vrstore-loading-spinner');
                if ($spinner.length) {
                    $spinner.addClass('is-active');
                } else {
                    // Create spinner if it doesn't exist
                    const spinnerHtml = `
                        <div class="vrstore-loading">
                            <div class="vrstore-spinner"></div>
                            <p>Loading...</p>
                        </div>
                    `;
                    $container.html(spinnerHtml);
                }
            }
        },

        hideSpinner: function(container) {
            if (container) {
                const $container = $(container);
                const $spinner = $container.find('.vrstore-spinner, .vrstore-loading-spinner');
                if ($spinner.length) {
                    $spinner.removeClass('is-active');
                }
                const $loadingContainer = $container.find('.vrstore-loading');
                if ($loadingContainer.length) {
                    $loadingContainer.remove();
                }
            }
        },

        showTabLoading: function(tabId) {
            const $tabContent = $('#' + tabId);
            if ($tabContent.length) {
                const loadingHtml = `
                    <div class="vrstore-loading">
                        <div class="vrstore-spinner"></div>
                        <p>Loading customer details...</p>
                    </div>
                `;
                $tabContent.html(loadingHtml);
            }
        },

        hideTabLoading: function(tabId, originalContent) {
            const $tabContent = $('#' + tabId);
            if ($tabContent.length && originalContent) {
                $tabContent.html(originalContent);
            }
        },
        
        // Clear all loading states
        clearAllLoading: function() {
            $('.loading').each(function() {
                LoadingStates.removeLoading($(this));
            });
            // Also clear any stuck processing text
            $('*:contains("Processing...")').each(function() {
                const $element = $(this);
                if ($element.children().length === 0) { // Only text nodes
                    const originalText = $element.data('original-text');
                    if (originalText) {
                        $element.html(originalText).removeClass('loading').prop('disabled', false);
                    }
                }
            });
        }
    };

    /**
     * Accessibility Enhancements
     */
    const AccessibilityEnhancements = {
        init: function() {
            this.setupKeyboardNavigation();
            this.setupFocusManagement();
            this.setupAriaLabels();
        },

        setupKeyboardNavigation: function() {
            // Tab navigation with keyboard
            $(document).on('keydown', '.vrstore-tabs-nav', function(e) {
                if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
                    e.preventDefault();
                    
                    const $current = $(this).find('a.active');
                    let $next;
                    
                    if (e.key === 'ArrowRight') {
                        $next = $current.parent().next().find('a');
                        if (!$next.length) {
                            $next = $(this).find('a').first();
                        }
                    } else {
                        $next = $current.parent().prev().find('a');
                        if (!$next.length) {
                            $next = $(this).find('a').last();
                        }
                    }
                    
                    if ($next.length) {
                        $next.focus().click();
                    }
                }
            });
        },

        setupFocusManagement: function() {
            // Focus management for modals and tabs
            $('.vrstore-tab-content').on('show', function() {
                $(this).find('input, button, select, textarea, a').first().focus();
            });
        },

        setupAriaLabels: function() {
            // Add ARIA labels where missing
            $('.vrstore-copy-license-key').each(function() {
                if (!$(this).attr('aria-label')) {
                    $(this).attr('aria-label', 'Copy license key to clipboard');
                }
            });
            
            $('.vrstore-tabs-nav a').each(function() {
                if (!$(this).attr('role')) {
                    $(this).attr('role', 'tab');
                }
            });
            
            $('.vrstore-tab-content').each(function() {
                if (!$(this).attr('role')) {
                    $(this).attr('role', 'tabpanel');
                }
            });
        }
    };

    /**
     * Performance Optimizations
     */
    const PerformanceOptimizations = {
        init: function() {
            this.lazyLoadImages();
            this.debounceEvents();
        },

        lazyLoadImages: function() {
            // Simple lazy loading for images
            if ('IntersectionObserver' in window) {
                const imageObserver = new IntersectionObserver((entries, observer) => {
                    entries.forEach(entry => {
                        if (entry.isIntersecting) {
                            const img = entry.target;
                            img.src = img.dataset.src;
                            img.classList.remove('lazy');
                            imageObserver.unobserve(img);
                        }
                    });
                });

                document.querySelectorAll('img[data-src]').forEach(img => {
                    imageObserver.observe(img);
                });
            }
        },

        debounceEvents: function() {
            // Debounce resize events
            let resizeTimer;
            $(window).on('resize', function() {
                clearTimeout(resizeTimer);
                resizeTimer = setTimeout(function() {
                    $(window).trigger('debouncedResize');
                }, 250);
            });
        }
    };

    
    
    // Unified Modal System - handles all modal functionality without conflicts
    const UnifiedModalSystem = {
        init: function() {
            // Handle modal open triggers
            $(document).on('click', '[data-modal]', this.openModal);
            $(document).on('click', '#vrstore-create-ticket-btn, #vrstore-create-ticket, #vrstore-create-first-ticket', this.openCreateTicketModal);
            $(document).on('click', '#vrstore-extended-support-btn', this.openExtendedSupportModal);
            
            // Handle modal close
            $(document).on('click', '.vrstore-modal-close', this.closeModal);
            $(document).on('click', '.vrstore-modal-overlay', this.closeModalByOverlay);
            
            // Handle ESC key
            $(document).on('keydown', this.handleEscapeKey);
        },
        
        openModal: function(e) {
            e.preventDefault();
            const modalId = $(this).data('modal');
            const $modal = $('#' + modalId);
            
            if ($modal.length) {
                $modal.show().css('opacity', '1').fadeIn(200);
                $('body').addClass('vrstore-modal-open');
                
                // Focus management for accessibility
                setTimeout(() => {
                    const $firstInput = $modal.find('input:not([type="hidden"]), textarea, select, button').first();
                    if ($firstInput.length) {
                        $firstInput.focus();
                    }
                }, 100);
            }
        },
        
        openCreateTicketModal: function(e) {
            e.preventDefault();
            const $modal = $('#vrstore-create-ticket-modal');
            
            if ($modal.length) {
                // Ensure modal is in correct state before showing
                $modal.css('display', 'none');
                $modal.show().fadeIn(200);
                $('body').addClass('vrstore-modal-open');
                
                // Focus first input
                setTimeout(() => {
                    $('#vrstore-ticket-subject').focus();
                }, 100);
            }
        },
        
        openExtendedSupportModal: function(e) {
            e.preventDefault();
            const $modal = $('#vrstore-extended-support-modal');
            
            if ($modal.length) {
                // Ensure modal is in correct state before showing
                $modal.css('display', 'none');
                $modal.show().fadeIn(200);
                $('body').addClass('vrstore-modal-open');
                
                // Ensure the purchase button has correct text - more comprehensive search
                setTimeout(() => {
                    // Find all possible purchase/submit buttons in the modal
                    const $buttons = $modal.find('button, input[type="submit"], .vrstore-btn');
                    $buttons.each(function() {
                        const $btn = $(this);
                        const buttonText = $btn.text().toLowerCase();
                        const buttonValue = $btn.val() ? $btn.val().toLowerCase() : '';
                        
                        // Check if this is a submit button that should be changed to Purchase
                        if (buttonText.includes('submit') || buttonValue.includes('submit')) {
                            // Handle different button structures
                            const $buttonText = $btn.find('.vrstore-button-text');
                            if ($buttonText.length) {
                                $buttonText.text('Purchase');
                            } else if ($btn.is('input[type="submit"]')) {
                                $btn.val('Purchase');
                            } else {
                                $btn.text('Purchase');
                            }
                        }
                    });
                }, 100);
            }
        },
        
        closeModal: function(e) {
            e.preventDefault();
            const $modal = $(this).closest('.vrstore-modal');
            UnifiedModalSystem.hideModal($modal);
        },
        
        closeModalByOverlay: function(e) {
            // Only close if clicking the overlay itself, not content within
            if (e.target === this || $(e.target).hasClass('vrstore-modal-overlay')) {
                const $modal = $(this).closest('.vrstore-modal');
                if ($modal.length) {
                    UnifiedModalSystem.hideModal($modal);
                }
            }
        },
        
        hideModal: function($modal) {
            if ($modal.length) {
                $modal.fadeOut(200, function() {
                    $(this).hide();
                });
                
                // Basic modal state cleanup - only remove body classes
                $('body').removeClass('vrstore-modal-open modal-open');
                
                // Only remove actual backdrop elements, not modal content
                // Be more specific to avoid removing modal content accidentally
                $('.vrstore-modal-backdrop, .modal-backdrop').not('.vrstore-modal-container, .vrstore-modal-content, .vrstore-modal-header, .vrstore-modal-body, .vrstore-modal-footer').each(function() {
                    const $element = $(this);
                    // Only remove if it's actually a backdrop (not inside a modal)
                    if (!$element.closest('.vrstore-modal-container, .vrstore-modal-content').length) {
                        $element.remove();
                    }
                });
                
                // Reset body styles more comprehensively
                const bodyResetStyles = {
                    'overflow': '',
                    'overflow-x': '',
                    'overflow-y': '',
                    'position': '',
                    'width': '',
                    'height': '',
                    'padding-right': '',
                    'margin-right': '',
                    'transform': '',
                    'filter': ''
                };
                
                $('body').removeAttr('style').css(bodyResetStyles);
                
                // Remove modal-related classes from html and body
                $('html, body').removeClass('vrstore-modal-open modal-open modal-backdrop-open');
                
                // Simple cleanup attempt after a short delay
                setTimeout(function() {
                    // Remove body classes again
                    $('body').removeClass('vrstore-modal-open modal-open');
                    
                    // Force body style reset again
                    $('body').css(bodyResetStyles);
                    
                    // Trigger resize to force layout recalculation
                    $(window).trigger('resize');
                }, 100);
            }
        },
        
        handleEscapeKey: function(e) {
            if (e.key === 'Escape' || e.keyCode === 27) {
                const $activeModal = $('.vrstore-modal:visible').last(); // Get the topmost modal
                if ($activeModal.length) {
                    UnifiedModalSystem.hideModal($activeModal);
                }
            }
        }
    };

    
    /**
     * Checkout Form Enhancement System
     */
    const CheckoutFormEnhancements = {
        init: function() {
            this.bindEvents();
            this.initLoginForms();
            this.initNonceRefresh();
        },

        bindEvents: function() {
            // Enhanced form submission with validation and double-submission protection
            $(document).on('submit', '.vrstore-checkout-form', this.handleFormSubmission);
            
            // Login/Register form interactions
            $(document).on('click', '#vrstore-show-login-form', this.showLoginForm);
            $(document).on('click', '#vrstore-show-register-form', this.showRegisterForm);
            $(document).on('click', '#vrstore-cancel-login', this.cancelLoginForm);
            $(document).on('click', '#vrstore-cancel-register', this.cancelRegisterForm);
            
            // Enhanced login form submission
            $(document).on('submit', '#vrstore-login-form-fields', this.handleLoginSubmission);
        },

        handleFormSubmission: function(e) {
            const $form = $(this);
            const $submitButton = $form.find('[type="submit"]');
            const paymentMethod = $('#vrstore_payment_method').val();
            
            // Prevent double submission
            if ($form.data('submitting')) {
                e.preventDefault();
                return false;
            }
            
            // Validate payment method
            if (!paymentMethod) {
                e.preventDefault();
                alert(vrstore_checkout_vars && vrstore_checkout_vars.select_payment_method ? 
                    vrstore_checkout_vars.select_payment_method : 'Please select a payment method before proceeding.');
                $('#vrstore_payment_method').focus();
                return false;
            }
            
            // Mark as submitting and update button
            $form.data('submitting', true);
            $submitButton.prop('disabled', true)
                        .text(vrstore_checkout_vars && vrstore_checkout_vars.processing ? 
                            vrstore_checkout_vars.processing : 'Processing...');
        },

        showLoginForm: function(e) {
            e.preventDefault();
            $('#vrstore-login-form').slideDown();
            $('#vrstore-register-form').slideUp();
            $('#vrstore_login_username').focus();
        },

        showRegisterForm: function(e) {
            e.preventDefault();
            $('#vrstore-register-form').slideDown();
            $('#vrstore-login-form').slideUp();
            $('#vrstore_reg_username').focus();
            $('.vrstore-checkout-form').show(); // Show checkout form for registration
        },

        cancelLoginForm: function(e) {
            e.preventDefault();
            $('#vrstore-login-form').slideUp();
            $('#vrstore-login-messages').empty();
        },

        cancelRegisterForm: function(e) {
            e.preventDefault();
            $('#vrstore-register-form').slideUp();
            $('.vrstore-checkout-form').hide(); // Hide checkout form
        },

        handleLoginSubmission: function(e) {
            e.preventDefault();
            
            const $form = $(this);
            const $submitBtn = $('#vrstore-login-submit');
            const $messages = $('#vrstore-login-messages');
            const username = $('#vrstore_login_username').val().trim();
            const password = $('#vrstore_login_password').val();
            const nonceField = $form.find('input[name*="nonce"]');
            
            // Clear previous messages
            $messages.empty();
            
            // Validate form data
            if (!username || !password) {
                $messages.html('<div class="vrstore-notice vrstore-notice-error">' + 
                    (vrstore_checkout_vars && vrstore_checkout_vars.enter_credentials ? 
                        vrstore_checkout_vars.enter_credentials : 'Please enter both username and password.') + '</div>');
                return;
            }
            
            if (nonceField.length === 0 || !nonceField.val()) {
                $messages.html('<div class="vrstore-notice vrstore-notice-error">' + 
                    (vrstore_checkout_vars && vrstore_checkout_vars.security_token_missing ? 
                        vrstore_checkout_vars.security_token_missing : 'Security token missing. Please refresh the page.') + '</div>');
                return;
            }
            
            // Disable submit button and show loading state
            $submitBtn.prop('disabled', true)
                     .text(vrstore_checkout_vars && vrstore_checkout_vars.logging_in ? 
                        vrstore_checkout_vars.logging_in : 'Logging in...');
            
            // Prepare form data with dynamic nonce field name
            const formData = {
                action: 'vrstore_custom_login',
                username: username,
                password: password,
                remember: $('#vrstore_login_remember').is(':checked') ? 'true' : 'false',
                nonce: nonceField.val()
            };
            
            // Submit AJAX login request with timeout and better error handling
            $.ajax({
                url: vrstore_ajax_vars ? vrstore_ajax_vars.ajax_url : '/wp-admin/admin-ajax.php',
                type: 'POST',
                data: formData,
                timeout: 15000, // 15 second timeout
                dataType: 'json',
                success: function(response) {
                    
                    if (response && response.success) {
                        // Login successful
                        $messages.html('<div class="vrstore-notice vrstore-notice-success">' + 
                            (response.data.message || (vrstore_checkout_vars && vrstore_checkout_vars.login_successful ? 
                                vrstore_checkout_vars.login_successful : 'Login successful! Redirecting...')) + '</div>');
                        
                        // Redirect to vrstore_account page or the specified redirect URL
                        setTimeout(function() {
                            const redirectUrl = response.data.redirect_url || window.location.href;
                            window.location.href = redirectUrl;
                        }, 1000);
                    } else {
                        // Login failed
                        const errorMsg = (response && response.data && response.data.message) ? 
                            response.data.message : 
                            (vrstore_checkout_vars && vrstore_checkout_vars.login_failed ? 
                                vrstore_checkout_vars.login_failed : 'Login failed. Please check your credentials.');
                        $messages.html('<div class="vrstore-notice vrstore-notice-error">' + errorMsg + '</div>');
                        $submitBtn.prop('disabled', false)
                                 .text(vrstore_checkout_vars && vrstore_checkout_vars.login ? 
                                    vrstore_checkout_vars.login : 'Login');
                    }
                },
                error: function(xhr, status, error) {
                    
                    let errorMessage;
                    if (status === 'timeout') {
                        errorMessage = vrstore_checkout_vars && vrstore_checkout_vars.login_timeout ? 
                            vrstore_checkout_vars.login_timeout : 'Login request timed out. Please try again.';
                    } else if (xhr.status === 0) {
                        errorMessage = vrstore_checkout_vars && vrstore_checkout_vars.connection_failed ? 
                            vrstore_checkout_vars.connection_failed : 'Connection failed. Please check your internet connection.';
                    } else if (xhr.status === 500) {
                        errorMessage = vrstore_checkout_vars && vrstore_checkout_vars.server_error ? 
                            vrstore_checkout_vars.server_error : 'Server error. Please try again later.';
                    } else {
                        errorMessage = vrstore_checkout_vars && vrstore_checkout_vars.error_occurred ? 
                            vrstore_checkout_vars.error_occurred : 'An error occurred. Please try again.';
                    }
                    
                    $messages.html('<div class="vrstore-notice vrstore-notice-error">' + errorMessage + '</div>');
                    $submitBtn.prop('disabled', false)
                             .text(vrstore_checkout_vars && vrstore_checkout_vars.login ? 
                                vrstore_checkout_vars.login : 'Login');
                }
            });
        },

        initLoginForms: function() {
            // Handle post-login state - ensure checkout form is visible
            if (window.location.search.indexOf('vrstore_login_success') > -1) {
                console.log('ViraStore: Post-login checkout initialization');
                $('.vrstore-checkout-form').show();
                $('#vrstore-login-form').hide();
                $('#vrstore-register-form').hide();
                
                // Remove the login success flag from URL without reloading
                if (window.history && window.history.replaceState) {
                    const cleanUrl = window.location.href.replace(/[?&]vrstore_login_success=1/, '');
                    window.history.replaceState({}, document.title, cleanUrl);
                }
                
                // Focus on payment method selection
                setTimeout(function() {
                    $('#vrstore_payment_method').focus();
                }, 500);
            }
        },

        initNonceRefresh: function() {
            // Enhanced nonce refresh with debugging for existing customers
            if ($('.vrstore-checkout-form').length && $('input[name="vrstore_user_id"]').val()) {
                console.log('ViraStore: Checkout nonce refresh initialized for logged-in user');
            }
        }
    };

    /**
     * Support Ticket Auto-Refresh System
     */
    const SupportTicketSystem = {
        init: function() {
            this.bindEvents();
            this.initTicketFormHandling();
        },

        bindEvents: function() {
            // Handle ticket submission success
            $(document).on('vrstore_ticket_submitted', this.handleTicketSubmission);
            $(document).on('submit', '.vrstore-create-ticket-form, #vrstore-create-ticket-form', this.handleTicketFormSubmission);
            
            // Listen for successful AJAX ticket creation responses
            $(document).on('vrstore_ticket_creation_success', this.handleTicketCreationSuccess);
        },

        initTicketFormHandling: function() {
            // Override any existing ticket form AJAX handlers to ensure auto-refresh
            const self = this;
            
            // Disable any existing handlers to prevent conflicts
            $(document).off('submit', '#vrstore-create-ticket-form');
            
            // Disable the frontend.js handler by removing its initialization if it exists
            if (typeof initSupportTicketHandlers === 'function') {
                console.log('ViraStore: Disabling existing ticket handlers to prevent conflicts');
            }
            
            $(document).on('submit', '#vrstore-create-ticket-form', function(e) {
                e.preventDefault();
                
                const $form = $(this);
                const $submitBtn = $('#vrstore-submit-ticket-btn');
                const $buttonText = $submitBtn.find('.vrstore-button-text');
                const $buttonSpinner = $submitBtn.find('.vrstore-button-spinner');
                
                // Validate form
                const subject = $('#vrstore-ticket-subject').val().trim();
                const message = $('#vrstore-ticket-message').val().trim();
                
                if (!subject || !message) {
                    alert('Please fill in all required fields.');
                    return;
                }
                
                if (subject.length < 5) {
                    alert('Subject must be at least 5 characters long.');
                    $('#vrstore-ticket-subject').focus();
                    return;
                }
                
                if (message.length < 20) {
                    alert('Message must be at least 20 characters long.');
                    $('#vrstore-ticket-message').focus();
                    return;
                }
                
                // Prevent any other handlers from running
                e.stopImmediatePropagation();
                
                // Show loading state
                $submitBtn.prop('disabled', true);
                if ($buttonText.length) {
                    $buttonText.hide();
                }
                if ($buttonSpinner.length) {
                    $buttonSpinner.show();
                } else {
                    // Fallback if spinner elements don't exist
                    $submitBtn.html('<span class="vrstore-spinner"></span> Creating...');
                }
                
                // Get form data
                const formData = {
                    action: 'vrstore_create_support_ticket',
                    subject: subject,
                    message: message,
                    product_id: $('#vrstore-ticket-product').val(),
                    priority: $('#vrstore-ticket-priority').val(),
                    nonce: vrstore_ajax_vars ? vrstore_ajax_vars.nonce : ''
                };
                
                console.log('ViraStore: Submitting support ticket...');
                
                // Submit ticket via AJAX
                $.ajax({
                    url: vrstore_ajax_vars ? vrstore_ajax_vars.ajax_url : '/wp-admin/admin-ajax.php',
                    type: 'POST',
                    data: formData,
                    timeout: 15000,
                    success: function(response) {
                        console.log('ViraStore: Ticket submission response:', response);
                        
                        // Always reset the button state first
                        $submitBtn.prop('disabled', false);
                        if ($buttonText.length && $buttonSpinner.length) {
                            $buttonText.show();
                            $buttonSpinner.hide();
                        } else {
                            // Restore original button text
                            $submitBtn.html('Submit Ticket');
                        }
                        
                        if (response && response.success) {
                            // Show success message
                            const successMsg = response.data.message || 'Ticket submitted successfully!';
                            
                            // Close modal using proper method
                            UnifiedModalSystem.hideModal($('#vrstore-create-ticket-modal'));
                            
                            // Clear form fields
                            $('#vrstore-ticket-subject').val('');
                            $('#vrstore-ticket-message').val('');
                            $('#vrstore-ticket-product').val('');
                            $('#vrstore-ticket-priority').val('normal');
                            
                            // Trigger auto-refresh with a slight delay to show success message
                            console.log('ViraStore: Ticket created successfully, triggering auto-refresh...');
                            setTimeout(function() {
                                // Reload the page without appending success message to URL
                                window.location.reload();
                            }, 500);
                            
                        } else {
                            // Handle error response
                            const errorData = {
                                message: response.data ? response.data.message : 'Unknown error occurred',
                                code: response.data ? response.data.code : 'unknown_error',
                                details: response.data ? response.data.details : null
                            };
                            self.showErrorMessage(errorData);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('ViraStore: Ticket submission error:', {
                            status: status,
                            error: error,
                            responseText: xhr.responseText
                        });
                        
                        let errorMessage = 'An error occurred while creating the ticket. Please try again.';
                        
                        if (status === 'timeout') {
                            errorMessage = 'Request timed out. Please check your connection and try again.';
                        } else if (xhr.status === 0) {
                            errorMessage = 'Connection failed. Please check your internet connection.';
                        } else if (xhr.status === 500) {
                            errorMessage = 'Server error. Please try again later.';
                        }
                        
                        self.showErrorMessage(errorMessage);
                        
                        // Reset form state
                        $submitBtn.prop('disabled', false);
                        if ($buttonText.length && $buttonSpinner.length) {
                            $buttonText.show();
                            $buttonSpinner.hide();
                        } else {
                            // Restore original button text
                            $submitBtn.html('Submit Ticket');
                        }
                    }
                });
            });
        },

        handleTicketSubmission: function(e, data) {
            console.log('ViraStore: Ticket submitted successfully, triggering auto-refresh');
            // Auto-refresh the page after successful ticket submission
            setTimeout(function() {
                window.location.reload();
            }, 2500); // 2.5 second delay to show success message
        },

        handleTicketFormSubmission: function(e) {
            const $form = $(this);
            // Add a flag to check for successful submission
            $form.data('submitted-timestamp', Date.now());
            console.log('ViraStore: Ticket form submission detected');
        },

        handleTicketCreationSuccess: function(e, data) {
            console.log('ViraStore: Ticket creation success event received', data);
            SupportTicketSystem.triggerAutoRefresh();
        },

        showSuccessMessage: function(message) {
            // Create and show success message
            const $successMsg = $('<div class="vrstore-notice vrstore-notice-success vrstore-ticket-success-message">' + 
                '<span class="dashicons dashicons-yes"></span> ' + message + 
                '</div>');
            
            $('body').append($successMsg);
            
            // Position the message
            $successMsg.css({
                position: 'fixed',
                top: '20px',
                right: '20px',
                zIndex: 999999,
                maxWidth: '400px',
                padding: '15px 20px',
                borderRadius: '8px',
                boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)',
                backgroundColor: '#d4edda',
                color: '#155724',
                border: '1px solid #c3e6cb'
            });
            
            // Auto-hide after 3 seconds
            setTimeout(function() {
                $successMsg.fadeOut(function() {
                    $successMsg.remove();
                });
            }, 3000);
        },

        showErrorMessage: function(message) {
            // Create and show error message
            const $errorMsg = $('<div class="vrstore-notice vrstore-notice-error vrstore-ticket-error-message">' + 
                '<span class="dashicons dashicons-warning"></span> ' + message + 
                '</div>');
            
            $('body').append($errorMsg);
            
            // Position the message
            $errorMsg.css({
                position: 'fixed',
                top: '20px',
                right: '20px',
                zIndex: 999999,
                maxWidth: '400px',
                padding: '15px 20px',
                borderRadius: '8px',
                boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)',
                backgroundColor: '#f8d7da',
                color: '#721c24',
                border: '1px solid #f5c6cb'
            });
            
            // Auto-hide after 5 seconds for errors
            setTimeout(function() {
                $errorMsg.fadeOut(function() {
                    $errorMsg.remove();
                });
            }, 5000);
        },

        // Method to trigger auto-refresh after AJAX ticket creation
        triggerAutoRefresh: function() {
            console.log('ViraStore: Starting auto-refresh countdown...');
            
            // Show countdown message
            const $countdown = $('<div class="vrstore-refresh-countdown">' + 
                'Page will refresh in <span class="countdown-number">3</span> seconds...' + 
                '</div>');
            
            $('body').append($countdown);
            
            $countdown.css({
                position: 'fixed',
                bottom: '20px',
                right: '20px',
                zIndex: 999998,
                padding: '10px 15px',
                backgroundColor: '#f8f9fa',
                color: '#495057',
                border: '1px solid #dee2e6',
                borderRadius: '6px',
                fontSize: '14px',
                boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)'
            });
            
            let countdown = 3;
            const countdownInterval = setInterval(function() {
                countdown--;
                $countdown.find('.countdown-number').text(countdown);
                
                if (countdown <= 0) {
                    clearInterval(countdownInterval);
                    $countdown.text('Refreshing...');
                    
                    setTimeout(function() {
                        // Auto-refresh the page after ticket submission
                        location.reload();
                    }, 3000);
                }
            }, 1000);
        }
    };

    // Initialize all systems
    DropdownSystem.init();
    TabSystem.init();
    LicenseCopy.init();
    TableEnhancements.init();
    AuthSystem.init();
    FormEnhancements.init();
    MessageSystem.init();
    SmoothScroll.init();
    CheckoutFormEnhancements.init();
    
    // Initialize UnifiedModalSystem first to prevent conflicts
    UnifiedModalSystem.init();
    
    // Initialize SupportTicketSystem with a delay to ensure it overrides any other handlers
    setTimeout(function() {
        SupportTicketSystem.init();
    }, 100);
    
    AccessibilityEnhancements.init();
    PerformanceOptimizations.init();

    // Ensure tabs are properly initialized after DOM is fully loaded
    setTimeout(function() {
        // Re-initialize tab system if needed
        if ($('.vrstore-tabs').length > 0 && $('.vrstore-tab-content.vrstore-tab-active:visible').length === 0) {
            TabSystem.setActiveTab();
        }
        

    }, 500);
    
    // Expose systems globally for debugging and hooks
    window.TabSystem = TabSystem;
    window.UnifiedModalSystem = UnifiedModalSystem;


    /**
     * Global utility functions
     */
    window.ViraStore = window.ViraStore || {};
    window.ViraStore.UnifiedModalSystem = UnifiedModalSystem;
    window.ViraStore.frontend = {
        showMessage: function(message, type) {
            type = type || 'info';
            const $message = $('<div class="vrstore-message vrstore-message-' + type + '">' + message + '</div>');
            $('body').first().prepend($message);
            MessageSystem.setupAutoHide.call({ 0: $message[0], length: 1 });
        },
        
        hideMessages: function() {
            $('.vrstore-message').fadeOut(function() {
                $(this).remove();
            });
        },
        
        copyToClipboard: function(text) {
            if (navigator.clipboard && navigator.clipboard.writeText) {
                return navigator.clipboard.writeText(text);
            } else {
                const $temp = $('<input>');
                $('body').append($temp);
                $temp.val(text).select();
                document.execCommand('copy');
                $temp.remove();
                return Promise.resolve();
            }
        },
        
        // Expose LoadingStates methods globally
        showButtonLoading: function(button) { return LoadingStates.showButtonLoading(button); },
        hideButtonLoading: function(button) { return LoadingStates.hideButtonLoading(button); },
        showSpinner: function(container) { return LoadingStates.showSpinner(container); },
        hideSpinner: function(container) { return LoadingStates.hideSpinner(container); },
        showTabLoading: function(tabId) { return LoadingStates.showTabLoading(tabId); },
        hideTabLoading: function(tabId, originalContent) { return LoadingStates.hideTabLoading(tabId, originalContent); },
        clearAllLoading: function() { return LoadingStates.clearAllLoading(); },
        
        // Modal methods using unified system
        openModal: function(modalId) {
            const $modal = $('#' + modalId);
            if ($modal.length) {
                $modal.show().fadeIn(200);
                $('body').addClass('vrstore-modal-open');
            }
        },
        
        closeModal: function(modalId) {
            const $modal = modalId ? $('#' + modalId) : $('.vrstore-modal:visible').last();
            if ($modal.length) {
                UnifiedModalSystem.hideModal($modal);
            }
        }
    };

    // Handle page load completion
    $(window).on('load', function() {
        // Clear any stuck loading states from previous page loads
        LoadingStates.clearAllLoading();
        
        // Add loaded class to body for CSS animations
        $('body').addClass('vrstore-loaded');
        
        // Trigger custom event for other scripts
        $(document).trigger('vrastore:loaded');
    });
    
    // Global wrapper function for copyToClipboard (used by inline onclick handlers)
    window.copyToClipboard = function(element) {
        const text = element.textContent || element.innerText;
        if (window.ViraStore && window.ViraStore.frontend && window.ViraStore.frontend.copyToClipboard) {
            window.ViraStore.frontend.copyToClipboard(text).then(function() {
                // Show success feedback
                const originalText = element.textContent;
                element.textContent = 'Copied!';
                element.style.backgroundColor = '#d4edda';
                element.style.color = '#155724';
                
                setTimeout(function() {
                    element.textContent = originalText;
                    element.style.backgroundColor = '';
                    element.style.color = '';
                }, 2000);
            }).catch(function(err) {
                console.warn('Copy to clipboard failed:', err);
                // Show error feedback
                const originalText = element.textContent;
                element.textContent = 'Copy failed';
                element.style.backgroundColor = '#f8d7da';
                element.style.color = '#721c24';
                
                setTimeout(function() {
                    element.textContent = originalText;
                    element.style.backgroundColor = '';
                    element.style.color = '';
                }, 2000);
            });
        } else {
            console.error('ViraStore copyToClipboard function not available');
        }
    };
    
    // Fallback: Add loaded class after DOM ready if not already added
    $(document).ready(function() {
        // Clear loading states immediately on DOM ready
        LoadingStates.clearAllLoading();
        
        setTimeout(function() {
            if (!$('body').hasClass('vrstore-loaded')) {
                $('body').addClass('vrstore-loaded');
            }
            // Clear loading states again after 1 second
            LoadingStates.clearAllLoading();
        }, 1000); // Wait 1 second for window.load, then fallback
    });

});
