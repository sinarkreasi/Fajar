/**
 * Customer Add Page JavaScript
 * Handles form interactions for adding new customers
 */

jQuery(document).ready(function($) {
    'use strict';
    
    // Generate password functionality
    $('#generate_password').on('click', function() {
        var password = generatePassword(12);
        $('#user_pass').val(password);
        $('#user_pass_confirm').val(password);
    });
    
    // Auto-generate display name from first and last name
    $('#first_name, #last_name').on('input', function() {
        var firstName = $('#first_name').val().trim();
        var lastName = $('#last_name').val().trim();
        var displayName = $('#display_name').val().trim();
        
        // Only auto-generate if display name is empty
        if (!displayName && (firstName || lastName)) {
            $('#display_name').val((firstName + ' ' + lastName).trim());
        }
    });
    
    // Password confirmation validation
    $('#user_pass_confirm').on('input', function() {
        var password = $('#user_pass').val();
        var confirmPassword = $(this).val();
        
        if (password !== confirmPassword) {
            $(this).css('border-color', '#dc3232');
        } else {
            $(this).css('border-color', '');
        }
    });
    
    // Form validation
    $('.customer-add-form').on('submit', function(e) {
        var password = $('#user_pass').val();
        var confirmPassword = $('#user_pass_confirm').val();
        
        if (password !== confirmPassword) {
            e.preventDefault();
            alert(vrstore_customer_add.password_mismatch);
            $('#user_pass_confirm').focus();
            return false;
        }
        
        if (password.length < 6) {
            e.preventDefault();
            alert(vrstore_customer_add.password_length);
            $('#user_pass').focus();
            return false;
        }
    });
    
    /**
     * Generate a random password
     * @param {number} length - The length of the password to generate
     * @returns {string} The generated password
     */
    function generatePassword(length) {
        var charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*';
        var password = '';
        for (var i = 0; i < length; i++) {
            password += charset.charAt(Math.floor(Math.random() * charset.length));
        }
        return password;
    }
});