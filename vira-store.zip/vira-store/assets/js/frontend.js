/**
 * Vira Store Frontend Scripts
 *
 * @package Vira_Store
 * @since 1.0.0
 */

(function($) {
    'use strict';
    
    /**
     * Global notification function
     */
    function showNotification(message, type) {
        // Remove existing notifications to prevent stacking
        $('.vrstore-global-notification').remove();
        
        var typeClass = 'vrstore-alert-' + (type || 'info');
        var iconClass = type === 'success' ? 'yes-alt' : (type === 'error' || type === 'danger') ? 'warning' : 'info';
        
        var $notification = $('<div class="vrstore-global-notification ' + typeClass + '" style="' +
            'position: fixed; top: 20px; right: 20px; z-index: 100002; max-width: 400px; ' +
            'padding: 15px; border-radius: 4px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); ' +
            'background: white; border-left: 4px solid; animation: slideInRight 0.3s ease-out; ' +
            'font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;">' +
            '<span class="dashicons dashicons-' + iconClass + '" style="margin-right: 8px; vertical-align: middle;"></span>' +
            '<span style="vertical-align: middle;">' + message + '</span>' +
            '<button class="vrstore-notification-close" style="float: right; background: none; border: none; cursor: pointer; ' +
            'color: inherit; opacity: 0.7; font-size: 18px; line-height: 1; margin-left: 10px;">&times;</button>' +
            '</div>');
        
        // Apply type-specific colors
        if (type === 'success') {
            $notification.css({
                'border-left-color': '#46b450',
                'color': '#155724',
                'background-color': '#d4edda'
            });
        } else if (type === 'error' || type === 'danger') {
            $notification.css({
                'border-left-color': '#dc3232',
                'color': '#721c24',
                'background-color': '#f8d7da'
            });
        } else if (type === 'warning') {
            $notification.css({
                'border-left-color': '#ffb900',
                'color': '#856404',
                'background-color': '#fff3cd'
            });
        } else {
            $notification.css({
                'border-left-color': '#00a0d2',
                'color': '#0c5460',
                'background-color': '#d1ecf1'
            });
        }
        
        $('body').append($notification);
        
        // Auto-hide after 5 seconds
        setTimeout(function() {
            $notification.fadeOut(300, function() { $(this).remove(); });
        }, 5000);
        
        // Manual close
        $notification.find('.vrstore-notification-close').on('click', function() {
            $notification.fadeOut(300, function() { $(this).remove(); });
        });
    }
    
    // Make showNotification globally accessible
    window.showNotification = showNotification;
    
    // Add slideInRight animation if not already present
    if (!$('#vrstore-notifications-css').length) {
        $('<style id="vrstore-notifications-css">@keyframes slideInRight { 0% { transform: translateX(100%); opacity: 0; } 100% { transform: translateX(0); opacity: 1; } }</style>').appendTo('head');
    }
    
    // Performance optimization: Cache frequently used selectors
    const $document = $(document);
    const $window = $(window);
    
    // Debounce function for performance
    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
    
    
    // Checkout Page Functions
    function initCheckoutPage() {
    
    // Initialize auth tabs
    function initAuthTabs() {
        
        const showRegisterBtn = document.getElementById('vrstore-show-register-form');
        const cancelRegisterBtn = document.getElementById('vrstore-cancel-register');
        const registerForm = document.getElementById('vrstore-register-form');
        const checkoutForm = document.querySelector('.vrstore-checkout-form');
        
        // Show/hide registration form
        if (showRegisterBtn) {
            showRegisterBtn.addEventListener('click', function() {
                registerForm.style.display = 'block';
                checkoutForm.style.display = 'block';
            });
        }
        
        if (cancelRegisterBtn) {
            cancelRegisterBtn.addEventListener('click', function() {
                registerForm.style.display = 'none';
                checkoutForm.style.display = 'none';
            });
        }
        
        // Payment method switching
        const paymentSelect = document.getElementById('vrstore_payment_method');
        const paymentFields = document.querySelectorAll('.vrstore-payment-method-fields');
        
        if (paymentSelect) {
            // Check if PayPal payment mode is active (from URL parameter)
            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.get('vrstore_payment') === 'paypal' && paymentSelect.value !== 'paypal') {
                // Auto-select PayPal if payment mode is active
                paymentSelect.value = 'paypal';
                paymentSelect.dispatchEvent(new Event('change'));
            }
            
            paymentSelect.addEventListener('change', function() {
                // Hide all payment method fields
                paymentFields.forEach(function(field) {
                    field.style.display = 'none';
                });
                
                // Show selected payment method fields
                if (this.value) {
                    const selectedField = document.getElementById('vrstore-payment-method-' + this.value);
                    if (selectedField) {
                        selectedField.style.display = 'block';
                    }
                }
            });
            
            // Trigger initial display if value is set
            if (paymentSelect.value) {
                paymentSelect.dispatchEvent(new Event('change'));
            }
        }
    }
    
    } // End of initCheckoutPage function
    
    // Thank You Page Functions
    function initThankYouPage() {
        const copyableElements = document.querySelectorAll('.vrstore-copyable');
        
        // Copy to clipboard functionality
        copyableElements.forEach(function(element) {
            element.addEventListener('click', function() {
                const text = element.textContent;
                if (navigator.clipboard) {
                    navigator.clipboard.writeText(text).then(function() {
                        // Show temporary feedback
                        const originalText = element.textContent;
                        element.textContent = '✓ Copied!';
                        element.style.color = '#28a745';
                        
                        setTimeout(function() {
                            element.textContent = originalText;
                            element.style.color = '';
                        }, 2000);
                    }).catch(function(err) {
                        console.error('Could not copy text: ', err);
                    });
                }
            });
        });
        
        // Close modal when clicking outside of it
        const modal = document.querySelector('.vrstore-modal');
        if (modal) {
            modal.addEventListener('click', function(event) {
                if (event.target === modal) {
                    modal.style.display = 'none';
                    document.body.style.overflow = 'auto';
                }
            });
        }
        
        // Initialize bank details toggle functionality
        initBankDetailsToggle();
    }
    
    // Bank Details Toggle Functionality
    function initBankDetailsToggle() {
        const toggle = document.querySelector('.vrstore-bank-details-toggle');
        if (toggle) {
            // Make clickable element focusable for accessibility
            toggle.setAttribute('tabindex', '0');
            toggle.setAttribute('role', 'button');
            toggle.setAttribute('aria-label', 'Toggle bank transfer details');
            
            // Handle click events
            toggle.addEventListener('click', vrstore_toggleBankDetails);
            
            // Handle keyboard events for accessibility
            toggle.addEventListener('keydown', function(e) {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    vrstore_toggleBankDetails();
                }
            });
        }
    }
    
    // Toggle Bank Details Function
    function vrstore_toggleBankDetails() {
        try {
            const bankDetails = document.getElementById('vrstore-bank-details');
            const toggle = document.querySelector('.vrstore-bank-details-toggle');
            const arrow = toggle ? toggle.querySelector('.dashicons') : null;
            
            if (!bankDetails || !toggle) {
                console.error('ViraStore: Bank details elements not found');
                return;
            }
            
            if (bankDetails.style.display === 'none' || bankDetails.style.display === '') {
                // Show bank details
                bankDetails.style.display = 'block';
                bankDetails.style.animation = 'vrstore-fade-in 0.3s ease-out';
                
                // Update arrow if it exists
                if (arrow) {
                    arrow.classList.remove('dashicons-arrow-down-alt2');
                    arrow.classList.add('dashicons-arrow-up-alt2');
                }
                
                // Smooth scroll to bank details with delay to allow animation
                setTimeout(() => {
                    // Check if smooth scrolling is supported
                    if ('scrollBehavior' in document.documentElement.style) {
                        bankDetails.scrollIntoView({
                            behavior: 'smooth',
                            block: 'start',
                            inline: 'nearest'
                        });
                    } else {
                        // Fallback for older browsers
                        const offset = bankDetails.offsetTop - 20;
                        window.scrollTo({
                            top: offset,
                            left: 0,
                            behavior: 'smooth'
                        });
                    }
                }, 150); // Increased delay for better animation coordination
                
            } else {
                // Hide bank details
                bankDetails.style.display = 'none';
                
                // Update arrow if it exists
                if (arrow) {
                    arrow.classList.remove('dashicons-arrow-up-alt2');
                    arrow.classList.add('dashicons-arrow-down-alt2');
                }
                
                // Smooth scroll back to payment method section
                const paymentSection = toggle.closest('.vrstore-order-info-item');
                if (paymentSection) {
                    if ('scrollBehavior' in document.documentElement.style) {
                        paymentSection.scrollIntoView({
                            behavior: 'smooth',
                            block: 'center',
                            inline: 'nearest'
                        });
                    } else {
                        // Fallback for older browsers
                        const offset = paymentSection.offsetTop - (window.innerHeight / 2);
                        window.scrollTo({
                            top: Math.max(0, offset),
                            left: 0,
                            behavior: 'smooth'
                        });
                    }
                }
            }
            
            // Add visual feedback for user interaction
            toggle.style.transform = 'scale(0.95)';
            setTimeout(() => {
                toggle.style.transform = '';
            }, 100);
            
        } catch (error) {
            console.error('ViraStore: Error toggling bank details:', error);
        }
    }

    // Check for checkout completion on page load
    function checkCheckoutCompletion() {
        // Check if we're on the customer portal and have checkout data
        if (window.location.href.indexOf('vrstore_checkout_completed=1') > -1 && 
            localStorage.getItem('vrstore_checkout_completed') === 'true') {
            
            // Clear the checkout completion flag
            localStorage.removeItem('vrstore_checkout_completed');
            
            // Check if the timestamp is recent (within last 5 minutes)
            const timestamp = parseInt(localStorage.getItem('vrstore_checkout_timestamp') || '0', 10);
            const now = Date.now();
            const fiveMinutes = 5 * 60 * 1000;
            
            if (now - timestamp < fiveMinutes) {
                // Show a welcome message if we have the user's name
                const username = localStorage.getItem('vrstore_checkout_username');
                if (username) {
                    const welcomeMessage = $('<div class="vrstore-welcome-message"></div>');
                    welcomeMessage.text('Welcome, ' + username + '! Your checkout has been completed successfully.');
                    $('.vrstore-checkout-completed-message').after(welcomeMessage);
                    
                    // Clean up localStorage
                    localStorage.removeItem('vrstore_checkout_username');
                    localStorage.removeItem('vrstore_checkout_email');
                    localStorage.removeItem('vrstore_checkout_timestamp');
                }
            }
        }
    }


    // Add to cart functionality
    function initAddToCart() {
        $(document).on('click', '.vrstore-add-to-cart', function(e) {
            e.preventDefault();
            
            const button = $(this);
            const productId = button.data('product-id');
            const originalText = button.text();
            const messageContainer = button.closest('.vrstore-product-actions, .vrstore-product-purchase-section, .vrstore-buy-button-wrapper');
            const targetContainer = messageContainer.length ? messageContainer : button.parent();
            
            // Get selected license type if available
            const licenseTypeSelect = $('#vrstore-license-type');
            // Check for license type from dropdown first, then from button data attribute
            const licenseType = licenseTypeSelect.length ? licenseTypeSelect.val() : (button.data('license-type') || '');
            
            const addingText = (vrstore_frontend && vrstore_frontend.adding_to_cart) ? vrstore_frontend.adding_to_cart : 'Adding to cart...';
            button.prop('disabled', true).text(addingText);
            
            // Check if vrstore_frontend is properly loaded
            if (typeof vrstore_frontend === 'undefined' || !vrstore_frontend.ajax_url) {
                targetContainer.find('.vrstore-message').remove();

                const message = $('<div class="vrstore-message vrstore-message-error"></div>');
                message.html(`<span class="vrstore-message-icon">✗</span> Plugin not properly initialized. Please refresh the page.`);
                targetContainer.prepend(message);
                button.prop('disabled', false).text(originalText);
                return;
            }
            
            $.ajax({
                url: vrstore_frontend.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrstore_add_to_cart',
                    product_id: productId,
                    license_type: licenseType,
                    nonce: vrstore_frontend.nonce
                },
                success: function(response) {
                    if (response.success) {
                        // Clear any existing messages first
                        targetContainer.find('.vrstore-message').remove();
                        
                        // Update cart count
                        $('.vrstore-cart-count').text(response.data.cart_count);
                        
                        // Check if redirect URL is provided
                        if (response.data.redirect_url) {
                            // Show success message briefly before redirect (single message)
                            const redirectingText = (vrstore_frontend && vrstore_frontend.redirecting) ? vrstore_frontend.redirecting : 'Redirecting...';
                            const message = $('<div class="vrstore-message vrstore-message-success"></div>');
                            message.html(`<span class="vrstore-message-icon">✓</span> ${response.data.message} ${redirectingText}`);
                            targetContainer.prepend(message);
                            
                            // Redirect after 1.5 seconds
                            setTimeout(function() {
                                window.location.href = response.data.redirect_url;
                            }, 1500);
                        } else {
                            // Show success message
                            const message = $('<div class="vrstore-message vrstore-message-success"></div>');
                            message.html(`<span class="vrstore-message-icon">✓</span> ${response.data.message}`);
                            targetContainer.prepend(message);
                            
                            // Remove message after 4 seconds
                            setTimeout(function() {
                                message.fadeOut(300, function() {
                                    $(this).remove();
                                });
                            }, 4000);
                        }
                    } else {
                        // Clear any existing messages first
                        targetContainer.find('.vrstore-message').remove();
                        
                        // Show error message
                        const message = $('<div class="vrstore-message vrstore-message-error"></div>');
                        message.html(`<span class="vrstore-message-icon">✗</span> ${response.data.message}`);
                        targetContainer.prepend(message);
                        
                        // Remove message after 5 seconds
                        setTimeout(function() {
                            message.fadeOut(300, function() {
                                $(this).remove();
                            });
                        }, 5000);
                    }
                },
                error: function() {
                    // Clear any existing messages first
                    targetContainer.find('.vrstore-message').remove();
                    
                    // Show error message
                    const errorText = (vrstore_frontend && vrstore_frontend.ajax_error) ? vrstore_frontend.ajax_error : 'An error occurred. Please try again.';
                    const message = $('<div class="vrstore-message vrstore-message-error"></div>');
                    message.html(`<span class="vrstore-message-icon">✗</span> ${errorText}`);
                    targetContainer.prepend(message);
                    
                    // Remove message after 5 seconds
                    setTimeout(function() {
                        message.fadeOut(300, function() {
                            $(this).remove();
                        });
                    }, 5000);
                },
                complete: function() {
                    button.prop('disabled', false).text(originalText);
                }
            });
        });
    }

    // Auth tab functionality is now handled by initAuthInterface() to prevent conflicts
    // This function is kept for backward compatibility but delegates to initAuthInterface
    function initAuthTabs() {
        // No longer needed - initAuthInterface handles all auth tab functionality
        // with unified class handling for both 'active' and 'vrstore-active' classes
        return;
    }
    
    // Initialize checkout functionality
    function initCheckoutValidation() {
        var customerCheckTimeout;
        
        // Handle payment method selection (unified handler)
        // Auto-select PayPal if payment mode is active
        $(document).ready(function() {
            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.get('vrstore_payment') === 'paypal') {
                const paymentSelect = $('#vrstore_payment_method');
                if (paymentSelect.length && paymentSelect.val() !== 'paypal') {
                    paymentSelect.val('paypal').trigger('change');
                }
            }
        });
        
        $(document).on('change', '#vrstore_payment_method', function() {
            var selectedMethod = $(this).val();
            
            // Hide all payment method fields and disable their required inputs
            $('.vrstore-payment-method-fields').hide().find('input[required], select[required]').prop('required', false);
            
            // Show selected payment method fields and enable their required inputs
            if (selectedMethod) {
                const selectedMethodDiv = $('#vrstore-payment-method-' + selectedMethod);
                selectedMethodDiv.show().find('input[data-required="true"], select[data-required="true"]').prop('required', true);
            }
        });
        
        // Validate form before submission
        $(document).on('submit', '.vrstore-checkout-form', function(e) {
            var paymentMethod = $('#vrstore_payment_method').val();
            var isLoggedIn = $('input[name="vrstore_is_logged_in"]').val() === '1';
            
            // Check if registration form is visible (user needs to register)
            var registrationFormVisible = $('#vrstore-register-form').is(':visible');
            
            // Skip registration validation for logged-in users
            if (!isLoggedIn && registrationFormVisible) {
                // Get registration form values
                var regUsername = $('#vrstore_reg_username').val();
                var regEmail = $('#vrstore_reg_email').val();
                var regPassword = $('#vrstore_reg_password').val();
                
                // Validate registration fields
                if (!regUsername || !regUsername.trim()) {
                    alert('Please enter a username.');
                    $('#vrstore_reg_username').focus();
                    e.preventDefault();
                    return false;
                }
                
                if (!regEmail || !regEmail.trim() || regEmail.indexOf('@') === -1) {
                    alert('Please enter a valid email address.');
                    $('#vrstore_reg_email').focus();
                    e.preventDefault();
                    return false;
                }
                
                if (!regPassword || regPassword.length < 6) {
                    alert('Password must be at least 6 characters long.');
                    $('#vrstore_reg_password').focus();
                    e.preventDefault();
                    return false;
                }
                

                
                // Copy registration data to hidden checkout form fields
                if (!$('#vrstore_username').length) {
                    $(this).append('<input type="hidden" id="vrstore_username" name="vrstore_username" value="">');
                }
                if (!$('#vrstore_email').length) {
                    $(this).append('<input type="hidden" id="vrstore_email" name="vrstore_email" value="">');
                }
                if (!$('#vrstore_password').length) {
                    $(this).append('<input type="hidden" id="vrstore_password" name="vrstore_password" value="">');
                }
                
                // Add registration-specific fields for the checkout processor
                if (!$('input[name="vrstore_reg_username"]').length) {
                    $(this).append('<input type="hidden" name="vrstore_reg_username" value="">');
                }
                if (!$('input[name="vrstore_reg_email"]').length) {
                    $(this).append('<input type="hidden" name="vrstore_reg_email" value="">');
                }
                if (!$('input[name="vrstore_reg_password"]').length) {
                    $(this).append('<input type="hidden" name="vrstore_reg_password" value="">');
                }
                
                // Ensure the action remains as checkout processing, not registration AJAX
                // The checkout processor will handle user registration
                
                $('#vrstore_username').val(regUsername);
                $('#vrstore_email').val(regEmail);
                $('#vrstore_password').val(regPassword);
                $('input[name="vrstore_reg_username"]').val(regUsername);
                $('input[name="vrstore_reg_email"]').val(regEmail);
                $('input[name="vrstore_reg_password"]').val(regPassword);
            }
            
            // Payment method validation (required for all users)
            if (!paymentMethod) {
                alert(vrstore_frontend.checkout_payment_method_required || 'Please select a payment method.');
                e.preventDefault();
                return false;
            }
            
            // Store form data in localStorage for potential redirect handling
            if (!isLoggedIn && email) {
                localStorage.setItem('vrstore_checkout_email', email);
                localStorage.setItem('vrstore_checkout_username', username);
                // Don't store the password for security reasons
                
                // Set a flag indicating that we're expecting a redirect to customer portal
                localStorage.setItem('vrstore_checkout_completed', 'true');
                localStorage.setItem('vrstore_checkout_timestamp', Date.now());
            }
            
            // Disable submit button to prevent double submission
            $(this).find('button[type="submit"]').prop('disabled', true).text(vrstore_frontend.processing || 'Processing...');
        });
        
        // Check if customer exists when email is entered (only for guest checkout)
        $(document).on('input', '#vrstore_email', function() {
            // Only run this for guest checkout (not logged in users)
            if ($('input[name="vrstore_is_logged_in"]').val() === '1') {
                return;
            }
            
            var email = $(this).val();
            var statusDiv = $('#vrstore_customer_status');
            var passwordRow = $('#vrstore_password_row');
            var passwordField = $('#vrstore_password');
            var passwordRequired = $('#vrstore_password_required');
            var passwordDescription = $('#vrstore_password_description');
            
            // Clear previous timeout
            if (customerCheckTimeout) {
                clearTimeout(customerCheckTimeout);
            }
            
            // Hide status initially
            statusDiv.hide();
            
            // Reset password field to required state
            passwordField.prop('required', true);
            passwordRequired.show();
            passwordDescription.text(vrstore_frontend.password_create_account || 'Minimum 6 characters. Registration will be completed for you.');
            
            if (email && email.indexOf('@') > -1) {
                // Debounce the check
                customerCheckTimeout = setTimeout(function() {
                    checkCustomerExists(email);
                }, 500);
            }
        });
        
        function checkCustomerExists(email) {
            $.ajax({
                url: vrstore_frontend.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrstore_check_customer_exists',
                    email: email,
                    nonce: vrstore_frontend.nonce
                },
                success: function(response) {
                    var statusDiv = $('#vrstore_customer_status');
                    var passwordField = $('#vrstore_password');
                    var passwordRequired = $('#vrstore_password_required');
                    var passwordDescription = $('#vrstore_password_description');
                    
                    if (response.success && response.data.exists) {
                        // Customer exists - make password optional
                        statusDiv.html('<span class="vrstore-customer-exists">' + (vrstore_frontend.checkout_customer_exists || 'Welcome back! Password is optional for existing customers.') + '</span>').show();
                        passwordField.prop('required', false);
                        passwordRequired.hide();
                        passwordDescription.text(vrstore_frontend.password_existing_account || 'Leave blank to use your existing profile, or enter password to verify.');
                    } else {
                        // New customer - password required
                        statusDiv.html('<span class="vrstore-customer-new">' + (vrstore_frontend.checkout_new_customer || 'New customer - registration will be completed for you.') + '</span>').show();
                        passwordField.prop('required', true);
                        passwordRequired.show();
                        passwordDescription.text(vrstore_frontend.password_create_account || 'Minimum 6 characters. Registration will be completed for you.');
                    }
                },
                error: function() {
                    // On error, assume new customer
                    var statusDiv = $('#vrstore_customer_status');
                    statusDiv.hide();
                }
            });
        }
    }

    // Payment method selection initialization
    function initPaymentMethodSelection() {
        // Trigger change on page load to initialize payment method fields
        setTimeout(function() {
            $('#vrstore_payment_method').trigger('change');
        }, 100);
    }

    // License activation
    function initLicenseActivation() {
        $('.vrstore-activate-license').on('click', function(e) {
            e.preventDefault();
            
            const button = $(this);
            const form = button.closest('.vrstore-license-form');
            const licenseKey = form.find('.vrstore-license-key').val();
            const domain = form.find('.vrstore-license-domain').val();
            const productId = form.data('product-id');
            const resultContainer = form.find('.vrstore-license-result');
            
            if (!licenseKey) {
                resultContainer.html('<div class="vrstore-message vrstore-message-error">' + vrstore_frontend.license_key_required + '</div>');
                return;
            }
            
            button.prop('disabled', true).text(vrstore_frontend.activating);
            
            $.ajax({
                url: vrstore_frontend.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrstore_activate_license',
                    license_key: licenseKey,
                    domain: domain,
                    product_id: productId,
                    nonce: vrstore_frontend.nonce
                },
                success: function(response) {
                    if (response.success) {
                        resultContainer.html('<div class="vrstore-message vrstore-message-success">' + response.data.message + '</div>');
                        
                        // Update license status
                        form.find('.vrstore-license-status').text(response.data.status);
                    } else {
                        resultContainer.html('<div class="vrstore-message vrstore-message-error">' + response.data.message + '</div>');
                    }
                },
                error: function() {
                    resultContainer.html('<div class="vrstore-message vrstore-message-error">' + vrstore_frontend.ajax_error + '</div>');
                },
                complete: function() {
                    button.prop('disabled', false).text(vrstore_frontend.activate);
                }
            });
        });
        
        // Deactivate license
        $('.vrstore-deactivate-license').on('click', function(e) {
            e.preventDefault();
            
            const button = $(this);
            const form = button.closest('.vrstore-license-form');
            const licenseKey = form.find('.vrstore-license-key').val();
            const domain = form.find('.vrstore-license-domain').val();
            const productId = form.data('product-id');
            const resultContainer = form.find('.vrstore-license-result');
            
            if (!licenseKey) {
                resultContainer.html('<div class="vrstore-message vrstore-message-error">' + vrstore_frontend.license_key_required + '</div>');
                return;
            }
            
            button.prop('disabled', true).text(vrstore_frontend.deactivating);
            
            $.ajax({
                url: vrstore_frontend.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrstore_deactivate_license',
                    license_key: licenseKey,
                    domain: domain,
                    product_id: productId,
                    nonce: vrstore_frontend.nonce
                },
                success: function(response) {
                    if (response.success) {
                        resultContainer.html('<div class="vrstore-message vrstore-message-success">' + response.data.message + '</div>');
                        
                        // Update license status
                        form.find('.vrstore-license-status').text(response.data.status);
                    } else {
                        resultContainer.html('<div class="vrstore-message vrstore-message-error">' + response.data.message + '</div>');
                    }
                },
                error: function() {
                    resultContainer.html('<div class="vrstore-message vrstore-message-error">' + vrstore_frontend.ajax_error + '</div>');
                },
                complete: function() {
                    button.prop('disabled', false).text(vrstore_frontend.deactivate);
                }
            });
        });
    }

    // Product tabs functionality - DISABLED
    // Tab functionality is now handled by frontend-enhanced.js TabSystem
    // to prevent conflicts and ensure consistent behavior
    function initProductTabs() {
        // Check if enhanced TabSystem is available
        if (typeof window.TabSystem !== 'undefined' || $('script[src*="frontend-enhanced.js"]').length > 0) {
            return; // Exit early to prevent conflicts
        }
        
        // Use event delegation for better performance
        $(document).on('click', '.vrstore-tabs-nav a', function(e) {
            e.preventDefault();
            
            const $clickedTab = $(this);
            const targetTab = $clickedTab.attr('href');
            const tabContainer = $clickedTab.closest('.vrstore-product-tabs, .vrstore-tabs');
            
            // Early return if already active
            if ($clickedTab.hasClass('active')) {
                return;
            }
            
            // Cache selectors for better performance
            const $navTabs = tabContainer.find('.vrstore-tabs-nav a');
            const $tabContents = tabContainer.find('.vrstore-tab-content');
            const $targetContent = tabContainer.find(targetTab);
            
            // Batch DOM updates
            $navTabs.removeClass('active');
            $clickedTab.addClass('active');
            
            // Use CSS classes instead of show/hide for better performance
            $tabContents.removeClass('vrstore-tab-active').addClass('vrstore-tab-hidden');
            $targetContent.removeClass('vrstore-tab-hidden').addClass('vrstore-tab-active');
            
            // Store active tab in localStorage for persistence
            if (tabContainer.hasClass('vrstore-tabs')) {
                try {
                    localStorage.setItem('vrstore_active_tab', targetTab);
                } catch (e) {
                    // Handle localStorage errors gracefully
                }
            }
        });
        
        // Initialize tabs on page load - Optimized
        function initializeTabContainers() {
            $('.vrstore-product-tabs, .vrstore-tabs').each(function() {
                const tabContainer = $(this);
                let activeTab = null;
                
                // Check for saved tab state if this is a tabs container
                if (tabContainer.hasClass('vrstore-tabs')) {
                    try {
                        const savedTab = localStorage.getItem('vrstore_active_tab');
                        if (savedTab && tabContainer.find('a[href="' + savedTab + '"]').length) {
                            activeTab = savedTab;
                        }
                    } catch (e) {
                        // Handle localStorage errors gracefully
                    }
                }
                
                // If no saved tab or not tabs container, use first tab
                if (!activeTab) {
                    const firstTab = tabContainer.find('.vrstore-tabs-nav a').first();
                    activeTab = firstTab.attr('href');
                }
                
                // Activate the determined tab with optimized selectors
                if (activeTab) {
                    const $navTabs = tabContainer.find('.vrstore-tabs-nav a');
                    const $tabContents = tabContainer.find('.vrstore-tab-content');
                    const $activeNavTab = tabContainer.find('a[href="' + activeTab + '"]');
                    const $activeContent = tabContainer.find(activeTab);
                    
                    // Batch DOM updates
                    $navTabs.removeClass('active');
                    $activeNavTab.addClass('active');
                    $tabContents.removeClass('vrstore-tab-active').addClass('vrstore-tab-hidden');
                    $activeContent.removeClass('vrstore-tab-hidden').addClass('vrstore-tab-active');
                }
            });
        }
        
        // Use requestAnimationFrame for smoother initialization
        requestAnimationFrame(initializeTabContainers);
    }
    
    // Copy license key functionality
    function initLicenseCopyFeature() {
        $(document).on('click', '.vrstore-copy-license-key', function(e) {
            e.preventDefault();
            
            const button = $(this);
            const licenseKey = button.data('license-key');
            const originalIcon = button.find('.dashicons');
            
            // Try to copy to clipboard
            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(licenseKey).then(function() {
                    // Show success feedback
                    originalIcon.removeClass('dashicons-clipboard').addClass('dashicons-yes');
                    button.addClass('copied');
                    
                    // Reset after 2 seconds
                    setTimeout(function() {
                        originalIcon.removeClass('dashicons-yes').addClass('dashicons-clipboard');
                        button.removeClass('copied');
                    }, 2000);
                }).catch(function() {
                    // Fallback for older browsers
                    fallbackCopyTextToClipboard(licenseKey, button, originalIcon);
                });
            } else {
                // Fallback for older browsers
                fallbackCopyTextToClipboard(licenseKey, button, originalIcon);
            }
        });
    }
    
    // Fallback copy function for older browsers
    function fallbackCopyTextToClipboard(text, button, originalIcon) {
        const textArea = document.createElement('textarea');
        textArea.value = text;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        textArea.style.top = '-999999px';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        
        try {
            const successful = document.execCommand('copy');
            if (successful) {
                // Show success feedback
                originalIcon.removeClass('dashicons-clipboard').addClass('dashicons-yes');
                button.addClass('copied');
                
                // Reset after 2 seconds
                setTimeout(function() {
                    originalIcon.removeClass('dashicons-yes').addClass('dashicons-clipboard');
                    button.removeClass('copied');
                }, 2000);
            }
        } catch (err) {
            console.error('Fallback: Could not copy text: ', err);
        }
        
        document.body.removeChild(textArea);
    }

    // Cart functionality
    function initCartFunctionality() {
        // Quantity buttons (+ and - buttons)
        $(document).on('click', '.vrstore-qty-minus', function() {
            const input = $(this).siblings('.vrstore-qty-input');
            const currentVal = parseInt(input.val()) || 1;
            if (currentVal > 1) {
                input.val(currentVal - 1);
                // Trigger change event to update cart via AJAX
                input.trigger('change');
            }
        });
        
        $(document).on('click', '.vrstore-qty-plus', function() {
            const input = $(this).siblings('.vrstore-qty-input');
            const currentVal = parseInt(input.val()) || 1;
            if (currentVal < 99) {
                input.val(currentVal + 1);
                // Trigger change event to update cart via AJAX
                input.trigger('change');
            }
        });
        
        // Remove item from cart
        $(document).on('click', '.vrstore-remove-item', function() {
            const cartKey = $(this).data('cart-key');
            const $cartItem = $(this).closest('.vrstore-cart-item');
            
            if (confirm(vrstore_ajax.remove_item_confirm || 'Are you sure you want to remove this item from your cart?')) {
                $cartItem.addClass('removing');
                
                $.ajax({
                    url: vrstore_ajax.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'vrstore_remove_cart_item',
                        cart_key: cartKey,
                        nonce: vrstore_ajax.nonce
                    },
                    success: function(response) {
                        if (response.success) {
                            $cartItem.fadeOut(300, function() {
                                $(this).remove();
                                updateCartTotals();
                                updateCartCount();
                            });
                        } else {
                            $cartItem.removeClass('removing');
                            alert(response.data || 'Failed to remove item from cart.');
                        }
                    },
                    error: function() {
                        $cartItem.removeClass('removing');
                        alert('Error removing item from cart. Please try again.');
                    }
                });
            }
        });
        
        // Update cart item quantity (for direct input changes)
        $(document).on('change', '.vrstore-qty-input, .vrstore-cart-quantity', function() {
            const input = $(this);
            const productId = input.data('product-id');
            const cartKey = input.data('cart-key') || input.closest('.vrstore-cart-item').data('cart-key');
            let quantity = parseInt(input.val());
            const row = input.closest('.vrstore-cart-item');
            
            // Ensure quantity is a valid number and at least 1
            if (isNaN(quantity) || quantity < 1) {
                quantity = 1;
                input.val(1);
            }
            
            // Use AJAX for real-time updates if available
            if (vrstore_frontend.ajax_url && (productId || cartKey)) {
                $.ajax({
                    url: vrstore_frontend.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'vrstore_update_cart',
                        product_id: productId,
                        cart_key: cartKey,
                        quantity: quantity,
                        nonce: vrstore_frontend.nonce
                    },
                    success: function(response) {
                        if (response.success) {
                            // Update item total
                            row.find('.vrstore-item-total, .vrstore-cart-subtotal').text(response.data.item_total || response.data.subtotal);
                            // Update cart total
                            $('.vrstore-cart-total, .vrstore-totals-table .vrstore-total-row td').text(response.data.cart_total);
                            // Update cart count
                            $('.vrstore-cart-count').text(response.data.cart_count);
                        }
                    }
                });
            }
        });
        
        // Remove cart item
        $(document).on('click', '.vrstore-remove-item', function(e) {
            e.preventDefault();
            
            const button = $(this);
            const productId = button.data('product-id');
            const cartKey = button.data('cart-key');
            const row = button.closest('.vrstore-cart-item');
            const productName = row.find('.vrstore-product-title').text().trim();
            
            // Enhanced confirmation dialog
            const confirmMessage = vrstore_frontend.confirm_remove_specific ? 
                vrstore_frontend.confirm_remove_specific.replace('%s', productName) : 
                vrstore_frontend.confirm_remove;
            
            if (confirm(confirmMessage)) {
                // Add loading state
                button.prop('disabled', true).addClass('vrstore-removing');
                button.find('.vrstore-remove-text').text(vrstore_frontend.removing || 'Removing...');
                row.addClass('vrstore-item-removing');
                
                // Check if we have AJAX capability
                if (vrstore_frontend.ajax_url && (productId || cartKey)) {
                    $.ajax({
                        url: vrstore_frontend.ajax_url,
                        type: 'POST',
                        data: {
                            action: 'vrstore_remove_cart_item',
                            product_id: productId,
                            cart_key: cartKey,
                            nonce: vrstore_frontend.nonce
                        },
                        success: function(response) {
                            if (response.success) {
                                // Show success message briefly
                                showCartMessage(vrstore_frontend.item_removed || 'Item removed from cart', 'success');
                                
                                row.addClass('vrstore-item-removed').fadeOut(400, function() {
                                    $(this).remove();
                                    
                                    // Update cart totals with animation
                                    updateCartTotals({
                                        cart_total: response.data.cart_total,
                                        cart_count: response.data.cart_count,
                                        subtotal: response.data.subtotal || response.data.cart_total
                                    });
                                    
                                    // Check if cart is empty
                                    if (response.data.cart_count == 0) {
                                        showEmptyCartState();
                                    }
                                });
                            } else {
                                // Handle error
                                showCartMessage(response.data.message || vrstore_frontend.ajax_error, 'error');
                                resetRemoveButton(button);
                                row.removeClass('vrstore-item-removing');
                            }
                        },
                        error: function() {
                            showCartMessage(vrstore_frontend.ajax_error, 'error');
                            resetRemoveButton(button);
                            row.removeClass('vrstore-item-removing');
                        }
                    });
                } else {
                    // Fallback to form submission for non-AJAX environments
                    const form = $('<form>', {
                        'method': 'POST',
                        'action': ''
                    }).append($('<input>', {
                        'type': 'hidden',
                        'name': 'remove_cart_item',
                        'value': cartKey || productId
                    })).append($('<input>', {
                        'type': 'hidden',
                        'name': 'vrstore_cart_nonce',
                        'value': $('[name="vrstore_cart_nonce"]').val()
                    }));
                    $('body').append(form);
                    form.submit();
                }
            }
        });
        
        // Helper function to reset remove button state
        function resetRemoveButton(button) {
            button.prop('disabled', false).removeClass('vrstore-removing');
            button.find('.vrstore-remove-text').text(vrstore_frontend.remove || 'Remove');
        }
        
        // Helper function to show empty cart state
        function showEmptyCartState() {
            const emptyMessage = `
                <div class="vrstore-empty-cart">
                    <h3>${vrstore_frontend.cart_empty_title || 'Your cart is empty'}</h3>
                    <p>${vrstore_frontend.cart_empty_message || 'Add some products to get started!'}</p>
                    <a href="${vrstore_frontend.shop_url || '/'}" class="vrstore-btn vrstore-btn-primary">
                        ${vrstore_frontend.continue_shopping || 'Continue Shopping'}
                    </a>
                </div>
            `;
            
            $('.vrstore-cart-table').fadeOut(300, function() {
                $(this).replaceWith(emptyMessage);
                $('.vrstore-empty-cart').hide().fadeIn(300);
            });
            $('.vrstore-cart-totals, .vrstore-cart-actions').fadeOut(300);
        }
        
        // Helper function to update cart totals with animation
        function updateCartTotals(data) {
            if (data.cart_total) {
                $('.vrstore-cart-total, .vrstore-totals-table .vrstore-total-row td').addClass('vrstore-updating').text(data.cart_total);
                setTimeout(() => $('.vrstore-updating').removeClass('vrstore-updating'), 300);
            }
            if (data.cart_count !== undefined) {
                $('.vrstore-cart-count').addClass('vrstore-updating').text(data.cart_count);
                setTimeout(() => $('.vrstore-cart-count.vrstore-updating').removeClass('vrstore-updating'), 300);
            }
            if (data.subtotal) {
                $('.vrstore-subtotal-amount').addClass('vrstore-updating').text(data.subtotal);
                setTimeout(() => $('.vrstore-subtotal-amount.vrstore-updating').removeClass('vrstore-updating'), 300);
            }
        }
        
        // Helper function to show cart messages
        function showCartMessage(message, type = 'info') {
            // Remove existing messages
            $('.vrstore-cart-message').remove();
            
            const messageHtml = `
                <div class="vrstore-cart-message vrstore-message-${type}">
                    <span class="vrstore-message-text">${message}</span>
                    <button type="button" class="vrstore-message-close">&times;</button>
                </div>
            `;
            
            $('.vrstore-cart').prepend(messageHtml);
            
            // Auto-hide success messages
            if (type === 'success') {
                setTimeout(() => {
                    $('.vrstore-cart-message').fadeOut(300, function() {
                        $(this).remove();
                    });
                }, 3000);
            }
        }
        
        // Close message handler
        $(document).on('click', '.vrstore-message-close', function() {
            $(this).closest('.vrstore-cart-message').fadeOut(300, function() {
                $(this).remove();
            });
        });
        
        // Enhanced Cart Features
        
        // Bulk Actions - Select All functionality
        $(document).on('change', '.vrstore-select-all, .vrstore-select-all-header', function() {
            const isChecked = $(this).is(':checked');
            $('.vrstore-item-select').prop('checked', isChecked);
            $('.vrstore-select-all, .vrstore-select-all-header').prop('checked', isChecked);
            updateBulkActionsState();
        });
        
        // Individual item selection
        $(document).on('change', '.vrstore-item-select', function() {
            const totalItems = $('.vrstore-item-select').length;
            const selectedItems = $('.vrstore-item-select:checked').length;
            
            $('.vrstore-select-all, .vrstore-select-all-header').prop('checked', selectedItems === totalItems);
            updateBulkActionsState();
        });
        
        // Update bulk actions state
        function updateBulkActionsState() {
            const selectedItems = $('.vrstore-item-select:checked').length;
            const bulkButton = $('#vrstore-apply-bulk');
            const bulkSelect = $('#vrstore-bulk-action');
            
            if (selectedItems > 0) {
                bulkButton.prop('disabled', false);
                bulkSelect.prop('disabled', false);
            } else {
                bulkButton.prop('disabled', true);
                bulkSelect.prop('disabled', true).val('');
            }
            
            // Update item count
            $('.vrstore-item-count').text(
                selectedItems > 0 
                    ? `${selectedItems} ${vrstore_frontend.items_selected || 'items selected'}`
                    : `${$('.vrstore-item-select').length} ${vrstore_frontend.items || 'items'}`
            );
        }
        
        // Apply bulk actions
        $(document).on('click', '#vrstore-apply-bulk', function() {
            const action = $('#vrstore-bulk-action').val();
            const selectedItems = $('.vrstore-item-select:checked');
            
            if (!action || selectedItems.length === 0) {
                return;
            }
            
            const cartKeys = selectedItems.map(function() {
                return $(this).val();
            }).get();
            
            if (action === 'remove') {
                const confirmMessage = vrstore_frontend.confirm_bulk_remove || 
                    `Are you sure you want to remove ${cartKeys.length} items from your cart?`;
                
                if (confirm(confirmMessage)) {
                    bulkRemoveItems(cartKeys);
                }
            } else if (action === 'save_later') {
                bulkSaveForLater(cartKeys);
            }
        });
        
        // Bulk remove items
        function bulkRemoveItems(cartKeys) {
            const button = $('#vrstore-apply-bulk');
            button.prop('disabled', true).text(vrstore_frontend.removing || 'Removing...');
            
            $.ajax({
                url: vrstore_frontend.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrstore_bulk_remove_items',
                    cart_keys: cartKeys,
                    nonce: vrstore_frontend.nonce
                },
                success: function(response) {
                    if (response.success) {
                        // Remove items with animation
                        cartKeys.forEach(function(cartKey) {
                            $(`.vrstore-cart-item[data-cart-key="${cartKey}"]`)
                                .addClass('vrstore-item-removing')
                                .fadeOut(300, function() {
                                    $(this).remove();
                                });
                        });
                        
                        // Update totals and UI
                        setTimeout(() => {
                            updateCartTotals(response.data);
                            
                            if ($('.vrstore-cart-item').length === 0) {
                                showEmptyCartState();
                            } else {
                                // Reset bulk actions
                                $('.vrstore-select-all, .vrstore-select-all-header').prop('checked', false);
                                updateBulkActionsState();
                            }
                        }, 300);
                        
                        showCartMessage(
                            vrstore_frontend.bulk_items_removed || `${cartKeys.length} items removed from cart`,
                            'success'
                        );
                    } else {
                        showCartMessage(
                            response.data || vrstore_frontend.error_removing_items || 'Error removing items',
                            'error'
                        );
                    }
                },
                error: function() {
                    showCartMessage(
                        vrstore_frontend.ajax_error || 'An error occurred. Please try again.',
                        'error'
                    );
                },
                complete: function() {
                    button.prop('disabled', false).text(vrstore_frontend.apply || 'Apply');
                }
            });
        }
        
        // Bulk save for later
        function bulkSaveForLater(cartKeys) {
            const button = $('#vrstore-apply-bulk');
            button.prop('disabled', true).text(vrstore_frontend.saving || 'Saving...');
            
            $.ajax({
                url: vrstore_frontend.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrstore_bulk_save_later',
                    cart_keys: cartKeys,
                    nonce: vrstore_frontend.nonce
                },
                success: function(response) {
                    if (response.success) {
                        // Remove items from cart with animation
                        cartKeys.forEach(function(cartKey) {
                            $(`.vrstore-cart-item[data-cart-key="${cartKey}"]`)
                                .addClass('vrstore-item-saved')
                                .fadeOut(300, function() {
                                    $(this).remove();
                                });
                        });
                        
                        // Update totals and UI
                        setTimeout(() => {
                            updateCartTotals(response.data);
                            
                            if ($('.vrstore-cart-item').length === 0) {
                                showEmptyCartState();
                            } else {
                                // Reset bulk actions
                                $('.vrstore-select-all, .vrstore-select-all-header').prop('checked', false);
                                updateBulkActionsState();
                            }
                        }, 300);
                        
                        showCartMessage(
                            vrstore_frontend.bulk_items_saved || `${cartKeys.length} items saved for later`,
                            'success'
                        );
                    } else {
                        showCartMessage(
                            response.data || vrstore_frontend.error_saving_items || 'Error saving items',
                            'error'
                        );
                    }
                },
                error: function() {
                    showCartMessage(
                        vrstore_frontend.ajax_error || 'An error occurred. Please try again.',
                        'error'
                    );
                },
                complete: function() {
                    button.prop('disabled', false).text(vrstore_frontend.apply || 'Apply');
                }
            });
        }
        
        // Individual Save for Later
        $(document).on('click', '.vrstore-save-later', function() {
            const button = $(this);
            const cartKey = button.data('cart-key');
            const productId = button.data('product-id');
            const row = button.closest('.vrstore-cart-item');
            
            button.prop('disabled', true).addClass('vrstore-saving');
            
            $.ajax({
                url: vrstore_frontend.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrstore_save_for_later',
                    cart_key: cartKey,
                    product_id: productId,
                    nonce: vrstore_frontend.nonce
                },
                success: function(response) {
                    if (response.success) {
                        row.addClass('vrstore-item-saved').fadeOut(300, function() {
                            $(this).remove();
                            
                            if ($('.vrstore-cart-item').length === 0) {
                                showEmptyCartState();
                            }
                        });
                        
                        updateCartTotals(response.data);
                        showCartMessage(
                            vrstore_frontend.item_saved_later || 'Item saved for later',
                            'success'
                        );
                    } else {
                        showCartMessage(
                            response.data || vrstore_frontend.error_saving_item || 'Error saving item',
                            'error'
                        );
                        button.prop('disabled', false).removeClass('vrstore-saving');
                    }
                },
                error: function() {
                    showCartMessage(
                        vrstore_frontend.ajax_error || 'An error occurred. Please try again.',
                        'error'
                    );
                    button.prop('disabled', false).removeClass('vrstore-saving');
                }
            });
        });
        
        // Quantity Validation and Auto-Update
        let quantityUpdateTimeout;
        
        $(document).on('input change', '.vrstore-qty-input', function() {
            const input = $(this);
            const cartKey = input.data('cart-key');
            const newQty = parseInt(input.val());
            const originalQty = parseInt(input.data('original-qty'));
            const validationDiv = input.siblings('.vrstore-qty-validation');
            
            // Clear previous timeout
            clearTimeout(quantityUpdateTimeout);
            
            // Validate quantity
            if (isNaN(newQty) || newQty < 1) {
                validationDiv.text(vrstore_frontend.qty_min_error || 'Minimum quantity is 1').show();
                input.addClass('vrstore-qty-error');
                return;
            }
            
            if (newQty > 99) {
                validationDiv.text(vrstore_frontend.qty_max_error || 'Maximum quantity is 99').show();
                input.addClass('vrstore-qty-error');
                return;
            }
            
            // Clear validation errors
            validationDiv.hide();
            input.removeClass('vrstore-qty-error');
            
            // Auto-update if quantity changed
            if (newQty !== originalQty) {
                input.addClass('vrstore-qty-updating');
                
                quantityUpdateTimeout = setTimeout(() => {
                    updateCartQuantity(cartKey, newQty, input);
                }, 1000); // 1 second delay
            }
        });
        
        // Quantity buttons
        $(document).on('click', '.vrstore-qty-btn', function() {
            const button = $(this);
            const input = button.siblings('.vrstore-qty-input');
            const currentQty = parseInt(input.val()) || 1;
            let newQty = currentQty;
            
            if (button.hasClass('vrstore-qty-plus')) {
                newQty = Math.min(currentQty + 1, 99);
            } else if (button.hasClass('vrstore-qty-minus')) {
                newQty = Math.max(currentQty - 1, 1);
            }
            
            if (newQty !== currentQty) {
                input.val(newQty).trigger('change');
            }
        });
        
        // Update cart quantity via AJAX
        function updateCartQuantity(cartKey, quantity, input) {
            $.ajax({
                url: vrstore_frontend.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrstore_update_cart_quantity',
                    cart_key: cartKey,
                    quantity: quantity,
                    nonce: vrstore_frontend.nonce
                },
                success: function(response) {
                    if (response.success) {
                        // Update original quantity
                        input.data('original-qty', quantity);
                        
                        // Update subtotal for this row
                        const row = input.closest('.vrstore-cart-item');
                        if (response.data.item_subtotal) {
                            row.find('.vrstore-cart-subtotal').addClass('vrstore-updating').text(response.data.item_subtotal);
                            setTimeout(() => row.find('.vrstore-cart-subtotal.vrstore-updating').removeClass('vrstore-updating'), 300);
                        }
                        
                        // Update cart totals
                        updateCartTotals(response.data);
                        
                        showCartMessage(
                            vrstore_frontend.qty_updated || 'Quantity updated',
                            'success'
                        );
                    } else {
                        // Revert to original quantity
                        input.val(input.data('original-qty'));
                        showCartMessage(
                            response.data || vrstore_frontend.error_updating_qty || 'Error updating quantity',
                            'error'
                        );
                    }
                },
                error: function() {
                    // Revert to original quantity
                    input.val(input.data('original-qty'));
                    showCartMessage(
                        vrstore_frontend.ajax_error || 'An error occurred. Please try again.',
                        'error'
                    );
                },
                complete: function() {
                    input.removeClass('vrstore-qty-updating');
                }
            });
        }
        
        // Handle coupon application
        $(document).on('click', '#vrstore-apply-coupon', function(e) {
            e.preventDefault();
            const $button = $(this);
            const $input = $('#vrstore-coupon-code');
            const couponCode = $input.val().trim();
            
            if (!couponCode) {
                showCouponMessage('Please enter a coupon code.', 'error');
                return;
            }
            
            $button.prop('disabled', true).text('Applying...');
            
            $.ajax({
                url: vrstore_frontend.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrstore_apply_coupon',
                    coupon_code: couponCode,
                    nonce: vrstore_frontend.nonce
                },
                success: function(response) {
                    if (response.success) {
                        showCouponMessage(response.data.message, 'success');
                        
                        // Simple solution: Reload the page to show updated totals
                        // This ensures all server-side calculations are properly reflected
                        setTimeout(function() {
                            window.location.reload();
                        }, 1500); // Give time to show success message
                    } else {
                        showCouponMessage(response.data.message, 'error');
                    }
                },
                error: function() {
                    showCouponMessage('An error occurred. Please try again.', 'error');
                },
                complete: function() {
                    $button.prop('disabled', false).text('Apply Coupon');
                }
            });
        });
        
        // Handle coupon removal
        $(document).on('click', '#vrstore-remove-coupon', function(e) {
            e.preventDefault();
            const $button = $(this);
            
            $button.prop('disabled', true).text('Removing...');
            
            $.ajax({
                url: vrstore_frontend.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrstore_remove_coupon',
                    nonce: vrstore_frontend.nonce
                },
                success: function(response) {
                    if (response.success) {
                        showCouponMessage(response.data.message, 'success');
                        
                        // Reload the page to show updated totals
                        setTimeout(function() {
                            window.location.reload();
                        }, 1500); // Give time to show success message
                    } else {
                        showCouponMessage('Failed to remove coupon.', 'error');
                    }
                },
                error: function() {
                    showCouponMessage('An error occurred. Please try again.', 'error');
                },
                complete: function() {
                    $button.prop('disabled', false).text('Remove');
                }
            });
        });
        
        // Handle Enter key in coupon input
        $(document).on('keypress', '#vrstore-coupon-code', function(e) {
            if (e.which === 13) {
                $('#vrstore-apply-coupon').click();
            }
        });
    }
    
    // Show coupon message
    function showCouponMessage(message, type) {
        const $messageDiv = $('#vrstore-coupon-message');
        
        // Clear any existing timeout
        if (window.couponMessageTimeout) {
            clearTimeout(window.couponMessageTimeout);
        }
        
        $messageDiv.removeClass('vrstore-message-success vrstore-message-error')
                   .addClass(`vrstore-message-${type}`)
                   .html(`<span class="vrstore-message-icon">${type === 'success' ? '✓' : '✗'}</span> ${message}`)
                   .stop(true, true)
                   .fadeIn(300);
        
        // Hide message after 4 seconds for success, 6 seconds for error
        const hideDelay = type === 'success' ? 4000 : 6000;
        window.couponMessageTimeout = setTimeout(() => {
            $messageDiv.fadeOut(300);
        }, hideDelay);
    }
    
    // Update cart totals display
    function updateCartTotals(cartData) {
        if (!cartData) return;
        
        // Update subtotal with animation
        if (cartData.subtotal !== undefined) {
            const $subtotal = $('.vrstore-subtotal-amount');
            if ($subtotal.length) {
                $subtotal.addClass('vrstore-updating').text(cartData.subtotal);
                setTimeout(() => $subtotal.removeClass('vrstore-updating'), 300);
            }
        }
        
        // Update discount
        if (cartData.raw_discount !== undefined) {
            if (cartData.raw_discount > 0 && cartData.coupon) {
                const existingDiscountRow = $('.vrstore-discount-row');
                
                // Show discount row if not exists
                if (existingDiscountRow.length === 0) {
                    const discountRow = `
                        <tr class="vrstore-discount-row">
                            <th>
                                Discount
                                <small>(${cartData.coupon.code})</small>
                            </th>
                            <td class="vrstore-discount-amount">-${cartData.discount}</td>
                        </tr>
                    `;
                    $('.vrstore-total-row').before(discountRow);
                    
                    // Animate the new row in
                    $('.vrstore-discount-row').hide().fadeIn(300);
                } else {
                    // Update existing discount row
                    const $discount = $('.vrstore-discount-amount');
                    const $discountCode = $('.vrstore-discount-row th small');
                    
                    $discount.addClass('vrstore-updating').text(`-${cartData.discount}`);
                    $discountCode.text(`(${cartData.coupon.code})`);
                    
                    setTimeout(() => $discount.removeClass('vrstore-updating'), 300);
                    
                    // Ensure the row is visible in case it was hidden
                    $('.vrstore-discount-row').show();
                }
            } else {
                $('.vrstore-discount-row').fadeOut(300, function() {
                    $(this).remove();
                });
            }
        }
        
        // Update total with animation
        if (cartData.total !== undefined) {
            const $total = $('.vrstore-total-amount strong');
            if ($total.length) {
                $total.addClass('vrstore-updating').text(cartData.total);
                setTimeout(() => $total.removeClass('vrstore-updating'), 300);
            }
        }
        
        // Update main cart total display with animation
        if (cartData.total !== undefined) {
            const $cartTotal = $('.vrstore-cart-total');
            if ($cartTotal.length) {
                $cartTotal.addClass('vrstore-updating').text(cartData.total);
                setTimeout(() => $cartTotal.removeClass('vrstore-updating'), 300);
            }
        }
        
        // Update cart count if available
        if (cartData.cart_count !== undefined) {
            const $cartCount = $('.vrstore-cart-count');
            if ($cartCount.length) {
                $cartCount.text(cartData.cart_count);
            }
        }
        
        // Force DOM reflow and repaint to ensure immediate visual update
        setTimeout(() => {
            document.body.offsetHeight;
            $('.vrstore-cart-summary').trigger('updated');
        }, 50);
    }
    
    // Helper function to convert amount if needed (USD to IDR)
    function convertAmountIfNeeded(amount) {
        // Check if currency conversion is enabled
        if (typeof vrstore_frontend !== 'undefined' && vrstore_frontend.enable_currency_conversion !== 'yes') {
            return amount; // Return original amount if conversion is disabled
        }
        
        const baseCurrency = vrstore_frontend.currency || 'USD';
        const currentCurrency = vrstore_frontend.current_currency || baseCurrency;
        const autoDetection = vrstore_frontend.auto_currency_detection || '';
        const usdToIdrRate = parseFloat(vrstore_frontend.usd_to_idr_rate) || 16000;
        
        // Convert USD to IDR if needed
        if (baseCurrency === 'USD' && currentCurrency === 'IDR' && autoDetection === 'on') {
            return amount * usdToIdrRate;
        }
        
        return amount;
    }
    
    // Format price according to currency settings
    function formatPrice(amount) {
        // Convert amount if needed
        const convertedAmount = convertAmountIfNeeded(amount);
        
        // Get currency settings from localized data
        const baseCurrency = vrstore_frontend.currency || 'USD';
        const currentCurrency = vrstore_frontend.current_currency || baseCurrency;
        const position = vrstore_frontend.currency_position || 'left';
        const symbol = vrstore_frontend.current_currency_symbol || vrstore_frontend.currency_symbol || '$';
        const decimals = parseInt(vrstore_frontend.decimal_number) || 2;
        const decimalSeparator = vrstore_frontend.decimal_separator || '.';
        const thousandSeparator = vrstore_frontend.thousand_separator || ',';
        
        // Format the number
        const formattedAmount = parseFloat(convertedAmount).toLocaleString('en-US', {
            minimumFractionDigits: decimals,
            maximumFractionDigits: decimals,
            useGrouping: true
        }).replace(/,/g, thousandSeparator).replace(/\./g, decimalSeparator);
        
        // Apply currency position
        switch (position) {
            case 'right':
                return formattedAmount + symbol;
            case 'left_space':
                return symbol + ' ' + formattedAmount;
            case 'right_space':
                return formattedAmount + ' ' + symbol;
            case 'left':
            default:
                return symbol + formattedAmount;
        }
    }

    // License activation functionality
    function initLicenseActivation() {
        // Enhanced license activation with better UI feedback
        $(document).on('click', '.vrstore-activate-license', function(e) {
            e.preventDefault();
            
            const button = $(this);
            const dropdown = button.closest('.vrstore-dropdown');
            const licenseRow = button.closest('tr');
            const licenseKey = button.data('license-key') || licenseRow.find('.license-key-text').text().trim();
            const productId = button.data('product-id');
            
            // Close dropdown
            dropdown.removeClass('vrstore-dropdown-open');
            dropdown.find('.vrstore-dropdown-toggle').attr('aria-expanded', 'false');
            
            // Show domain input modal or use current domain
            const domain = prompt('Enter the domain to activate this license for:', window.location.hostname);
            if (!domain) {
                return;
            }
            
            const originalText = button.text();
            const $toggle = dropdown.find('.vrstore-dropdown-toggle');
            const originalToggleText = $toggle.text();
            
            // Show loading state on both button and toggle
            button.prop('disabled', true).text('Activating...');
            $toggle.prop('disabled', true).addClass('loading').text('Processing...');
            
            $.ajax({
                url: vrstore_frontend.ajax_url,
                type: 'POST',
                timeout: 30000, // 30 second timeout
                data: {
                    action: 'vrstore_activate_license',
                    license_key: licenseKey,
                    domain: domain,
                    product_id: productId,
                    nonce: vrstore_frontend.nonce
                },
                success: function(response) {
                    if (response.success) {
                        showMessage(response.data.message || 'License activated successfully', 'success');
                        
                        // Update license status in the table if available
                        if (response.data.status) {
                            licenseRow.find('.license-status').text(response.data.status);
                        }
                        
                        // Refresh the page after a delay to show updated activation count
                        setTimeout(function() {
                            location.reload();
                        }, 1500);
                    } else {
                        showMessage(response.data.message || 'Failed to activate license', 'error');
                    }
                },
                error: function(xhr, status, error) {
                    let errorMessage = 'An error occurred while activating the license.';
                    if (status === 'timeout') {
                        errorMessage = 'Request timed out. Please try again.';
                    } else if (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
                        errorMessage = xhr.responseJSON.data.message;
                    }
                    showMessage(errorMessage, 'error');
                },
                complete: function() {
                    // Restore button states
                    button.prop('disabled', false).text(originalText);
                    $toggle.prop('disabled', false).removeClass('loading').text(originalToggleText);
                }
            });
        });
        
        // Enhanced license deactivation
        $(document).on('click', '.vrstore-deactivate-license', function(e) {
            e.preventDefault();
            
            const button = $(this);
            const dropdown = button.closest('.vrstore-dropdown');
            const licenseRow = button.closest('tr');
            const licenseKey = button.data('license-key') || licenseRow.find('.license-key-text').text().trim();
            const productId = button.data('product-id');
            
            // Close dropdown
            dropdown.removeClass('vrstore-dropdown-open');
            dropdown.find('.vrstore-dropdown-toggle').attr('aria-expanded', 'false');
            
            // Show domain input or use current domain
            const domain = prompt('Enter the domain to deactivate this license from:', window.location.hostname);
            if (!domain) {
                return;
            }
            
            const originalText = button.text();
            const $toggle = dropdown.find('.vrstore-dropdown-toggle');
            const originalToggleText = $toggle.text();
            
            // Show loading state on both button and toggle
            button.prop('disabled', true).text('Deactivating...');
            $toggle.prop('disabled', true).addClass('loading').text('Processing...');
            
            $.ajax({
                url: vrstore_frontend.ajax_url,
                type: 'POST',
                timeout: 30000, // 30 second timeout
                data: {
                    action: 'vrstore_deactivate_license',
                    license_key: licenseKey,
                    domain: domain,
                    product_id: productId,
                    nonce: vrstore_frontend.nonce
                },
                success: function(response) {
                    if (response.success) {
                        showMessage(response.data.message || 'License deactivated successfully', 'success');
                        
                        // Update license status in the table if available
                        if (response.data.status) {
                            licenseRow.find('.license-status').text(response.data.status);
                        }
                        
                        // Refresh the page after a delay to show updated activation count
                        setTimeout(function() {
                            location.reload();
                        }, 1500);
                    } else {
                        showMessage(response.data.message || 'Failed to deactivate license', 'error');
                    }
                },
                error: function(xhr, status, error) {
                    let errorMessage = 'An error occurred while deactivating the license.';
                    if (status === 'timeout') {
                        errorMessage = 'Request timed out. Please try again.';
                    } else if (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
                        errorMessage = xhr.responseJSON.data.message;
                    }
                    showMessage(errorMessage, 'error');
                },
                complete: function() {
                    // Restore button states
                    button.prop('disabled', false).text(originalText);
                    $toggle.prop('disabled', false).removeClass('loading').text(originalToggleText);
                }
            });
        });
    }
    
    // Show message
    function showMessage(message, type) {
        // Remove existing messages
        $('.vrstore-message').remove();
        
        // Create message element
        const messageEl = $('<div class="vrstore-message vrstore-message-' + type + '" style="margin: 20px 0; padding: 15px; border-radius: 5px;"></div>');
        messageEl.text(message);
        
        // Insert at the top of the container
        const container = $('.vrstore-container, .vrstore-content').first();
        if (container.length) {
            messageEl.prependTo(container);
        } else {
            messageEl.prependTo('body');
        }
        
        // Auto-hide success messages after 5 seconds
        if (type === 'success') {
            setTimeout(function() {
                messageEl.fadeOut(function() {
                    $(this).remove();
                });
            }, 5000);
        }
    }

    // Lightbox functionality for screenshot galleries
    function initScreenshotLightbox() {
        let currentImageIndex = 0;
        let galleryImages = [];
        let lightbox = null;
        
        // Create lightbox HTML structure
        function createLightbox() {
            const lightboxHTML = `
                <div id="vrstore-lightbox" class="vrstore-lightbox">
                    <div class="vrstore-lightbox-content">
                        <span class="vrstore-lightbox-close">&times;</span>
                        <img class="vrstore-lightbox-image" src="" alt="">
                        <div class="vrstore-lightbox-nav vrstore-lightbox-prev">&#10094;</div>
                        <div class="vrstore-lightbox-nav vrstore-lightbox-next">&#10095;</div>
                        <div class="vrstore-lightbox-counter"></div>
                        <div class="vrstore-lightbox-caption"></div>
                    </div>
                </div>
            `;
            $('body').append(lightboxHTML);
            lightbox = $('#vrstore-lightbox');
        }
        
        // Show lightbox with image
        function showLightbox(imageIndex) {
            if (!lightbox) {
                createLightbox();
            }
            
            if (galleryImages.length === 0) {
                return;
            }
            
            currentImageIndex = imageIndex;
            const image = galleryImages[currentImageIndex];
            
            // Update lightbox content
            const lightboxImage = lightbox.find('.vrstore-lightbox-image');
            const counter = lightbox.find('.vrstore-lightbox-counter');
            const caption = lightbox.find('.vrstore-lightbox-caption');
            const prevBtn = lightbox.find('.vrstore-lightbox-prev');
            const nextBtn = lightbox.find('.vrstore-lightbox-next');
            
            // Set image source to full size
            lightboxImage.attr('src', image.fullUrl).attr('alt', image.alt);
            
            // Update counter
            counter.text(`${currentImageIndex + 1} / ${galleryImages.length}`);
            
            // Update caption
            if (image.caption) {
                caption.text(image.caption).show();
            } else {
                caption.hide();
            }
            
            // Show/hide navigation buttons based on gallery size
            if (galleryImages.length > 1) {
                prevBtn.show();
                nextBtn.show();
            } else {
                prevBtn.hide();
                nextBtn.hide();
            }
            
            // Show lightbox
            lightbox.addClass('vrstore-lightbox-visible');
            $('body').addClass('vrstore-lightbox-open');
        }
        
        // Close lightbox
        function closeLightbox() {
            if (lightbox) {
                lightbox.removeClass('vrstore-lightbox-visible');
                $('body').removeClass('vrstore-lightbox-open');
            }
        }
        
        // Navigate to previous image
        function showPrevImage() {
            if (galleryImages.length > 1) {
                currentImageIndex = (currentImageIndex - 1 + galleryImages.length) % galleryImages.length;
                showLightbox(currentImageIndex);
            }
        }
        
        // Navigate to next image
        function showNextImage() {
            if (galleryImages.length > 1) {
                currentImageIndex = (currentImageIndex + 1) % galleryImages.length;
                showLightbox(currentImageIndex);
            }
        }
        
        // Get full size image URL
        function getFullSizeImageUrl(src) {
            // Remove WordPress image size suffixes to get original image
            return src.replace(/-\d+x\d+(?=\.[a-z]{2,4}$)/i, '');
        }
        
        // Extract gallery images from WordPress gallery
        function extractGalleryImages(galleryContainer) {
            const images = [];
            const galleryItems = galleryContainer.find('.gallery-item img, img');
            
            galleryItems.each(function() {
                const img = $(this);
                const src = img.attr('src');
                const alt = img.attr('alt') || '';
                const caption = img.closest('.gallery-item').find('.wp-caption-text').text() || 
                              img.attr('title') || '';
                
                if (src) {
                    images.push({
                        thumbUrl: src,
                        fullUrl: getFullSizeImageUrl(src),
                        alt: alt,
                        caption: caption
                    });
                }
            });
            
            return images;
        }
        
        // Initialize gallery click handlers
        $(document).on('click', '.vrstore-product-screenshots-gallery img', function(e) {
            e.preventDefault();
            
            const clickedImg = $(this);
            const galleryContainer = clickedImg.closest('.vrstore-product-screenshots-gallery');
            
            // Extract all images from this gallery
            galleryImages = extractGalleryImages(galleryContainer);
            
            if (galleryImages.length === 0) {
                return;
            }
            
            // Find the index of the clicked image
            const clickedSrc = clickedImg.attr('src');
            const clickedIndex = galleryImages.findIndex(img => 
                img.thumbUrl === clickedSrc || img.fullUrl === clickedSrc
            );
            
            // Show lightbox starting from clicked image
            showLightbox(clickedIndex >= 0 ? clickedIndex : 0);
        });
        
        // Lightbox event handlers
        $(document).on('click', '.vrstore-lightbox-close', closeLightbox);
        $(document).on('click', '.vrstore-lightbox-prev', showPrevImage);
        $(document).on('click', '.vrstore-lightbox-next', showNextImage);
        
        // Close lightbox when clicking on background
        $(document).on('click', '.vrstore-lightbox', function(e) {
            if (e.target === this) {
                closeLightbox();
            }
        });
        
        // Keyboard navigation
        $(document).on('keydown', function(e) {
            if (lightbox && lightbox.hasClass('vrstore-lightbox-visible')) {
                switch(e.key) {
                    case 'Escape':
                        closeLightbox();
                        break;
                    case 'ArrowLeft':
                        showPrevImage();
                        break;
                    case 'ArrowRight':
                        showNextImage();
                        break;
                }
            }
        });
        
        // Prevent body scroll when lightbox is open
        $('body').on('DOMNodeInserted', function() {
            if ($('body').hasClass('vrstore-lightbox-open')) {
                $('body').css('overflow', 'hidden');
            } else {
                $('body').css('overflow', '');
            }
        });
    }

    // Document ready
    $(document).ready(function() {
        initAddToCart();
        initCartFunctionality();
        initAuthTabs();
        initCheckoutValidation();
        initPaymentMethodSelection();
        initLicenseActivation();
        initProductTabs();
        initLicenseCopyFeature();
        // Account area functionality removed
        initScreenshotLightbox();
        initAuthInterface();

        
        // Initialize product page functionality
        initProductPage();
        
        // Initialize checkout page functionality
        initCheckoutPage();
        
        // Initialize thank you page functionality
        initThankYouPage();
        
        // Initialize currency switcher
        initCurrencySwitcher();
        
        // Initialize enhanced support ticket functionality
        initSupportTickets();
        
        // Initialize nonce refresh system
        initNonceRefresh();
        
        // Initialize edit profile form handler
        initEditProfileForm();
        
        // Check for auto-submit checkout flag after registration
        if (sessionStorage.getItem('vrstore_auto_submit_checkout') === '1') {
            // Clear the flag
            sessionStorage.removeItem('vrstore_auto_submit_checkout');
            
            // Wait for page to fully load, then auto-submit checkout
            setTimeout(function() {
                if ($('.vrstore-checkout-form').length > 0) {
                    
                    // Hide auth section if still visible
                    $('.vrstore-auth-section').hide();
                    $('.vrstore-checkout-form-container').show();
                    // Ensure the checkout form itself is visible (remove inline display:none)
                    $('.vrstore-checkout-form').show().css('display', 'block');
                    
                    // Trigger payment method selection to show payment fields
                    const paymentSelect = $('#vrstore_payment_method');
                    
                    if (paymentSelect.length && paymentSelect.find('option').length > 1) {
                        // Auto-select first available payment method
                        const firstOption = paymentSelect.find('option:not([value=""])').first().val();
                        paymentSelect.val(firstOption);
                        
                        // Trigger the change event to show payment fields
                        paymentSelect.trigger('change');
                        
                        // Wait a bit more for DOM updates, then submit
                        setTimeout(function() {
                            $('.vrstore-checkout-form').submit();
                        }, 800);
                    } else {
                        // No payment methods available, just submit
                        $('.vrstore-checkout-form').submit();
                    }
                } else {
                }
            }, 1500);
        }
        
        // Ensure container is visible (fallback for CSS loading issues)
        setTimeout(function() {
            if (!$('body').hasClass('vrstore-loaded') && $('.vrstore-container').length > 0) {
                $('body').addClass('vrstore-loaded');
            }
        }, 500);
    });

    /**
     * Initialize product page functionality
     */
    function initProductPage() {
        // Check if we're on a product page
        if (!$('.vrstore-single-product').length) {
            return;
        }
        
        // Initialize modal functionality
        initProductModals();
        
        // Initialize pricing functionality
        initProductPricing();
    }

    /**
     * Initialize product modals (video and license info) - Optimized
     */
    function initProductModals() {
        // Cache modal elements for better performance
        const $videoModal = $('#vrstore-video-modal');
        const $licenseModal = $('#vrstore-license-modal');
        const $body = $('body');
        
        // Video modal trigger
        $(document).on('click', '.vrstore-video-modal-trigger', function(e) {
            e.preventDefault();
            openModal($videoModal);
        });
        
        // License modal trigger
        $(document).on('click', '.vrstore-license-modal-trigger', function(e) {
            e.preventDefault();
            openModal($licenseModal);
        });
        
        // Close modals (consolidated handler)
        $(document).off('click.vrstore-modal-close').on('click.vrstore-modal-close', '.vrstore-modal-close', function(e) {
            e.preventDefault();
            e.stopPropagation();
            closeModal($(this).closest('.vrstore-modal'));
        });
        
        // Close modal when clicking outside (consolidated handler)
        $(document).off('click.vrstore-modal-overlay').on('click.vrstore-modal-overlay', '.vrstore-modal', function(e) {
            if (e.target === this) {
                e.stopPropagation();
                closeModal($(this));
            }
        });
        
        // Close any modal with Escape key (consolidated handler)
        $(document).off('keydown.vrstore-modal').on('keydown.vrstore-modal', function(e) {
            if (e.key === 'Escape') {
                const $activeModal = $('.vrstore-modal.vrstore-modal-visible, .vrstore-modal:visible');
                if ($activeModal.length) {
                    $activeModal.each(function() {
                        const $modal = $(this);
                        if ($modal.hasClass('vrstore-modal-visible')) {
                            closeModal($modal);
                        } else {
                            $modal.hide();
                        }
                    });
                }
            }
        });
        
        // Modal helper functions
        function openModal($modal) {
            if (!$modal.length) return;
            
            // Prevent body scroll
            $body.addClass('vrstore-modal-open');
            
            // Show modal with animation
            $modal.show();
            
            // Use requestAnimationFrame for smooth animation
            requestAnimationFrame(function() {
                $modal.addClass('vrstore-modal-visible');
            });
            
            // Focus management
            const $firstFocusable = $modal.find('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])').first();
            if ($firstFocusable.length) {
                setTimeout(function() {
                    $firstFocusable.focus();
                }, 300);
            }
        }
        
        function closeModal($modal) {
            if (!$modal.length) return;
            
            // Remove visible class first for animation
            $modal.removeClass('vrstore-modal-visible');
            
            // Hide modal after animation completes
            setTimeout(function() {
                $modal.hide();
                $body.removeClass('vrstore-modal-open');
            }, 300);
        }
    }

    /**
     * Initialize product pricing functionality
     */
    function initProductPricing() {
        const $licenseSelect = $('#vrstore-license-type');
        const $priceDisplay = $('#vrstore-product-price-display');
        
        if (!$licenseSelect.length || !$priceDisplay.length) {
            return;
        }
        
        // Listen for license type changes
        $licenseSelect.on('change', updatePriceDisplay);
        
        // Also re-render when global currency is switched
        $(document).on('vrstore_currency_switched', function(e, newCurrency, newSymbol) {
            if (newSymbol) {
                $licenseSelect.data('currency-symbol', newSymbol);
            }
            updatePriceDisplay();
        });
        
        // Initialize price display on page load - only if price display element is empty
        // This prevents overriding correctly formatted PHP prices with incorrect JavaScript formatting
        if ($priceDisplay.html().trim() === '') {
            updatePriceDisplay();
        }
        
        // Function to update price display
        function updatePriceDisplay() {
            const $selectedOption = $licenseSelect.find('option:selected');
            if (!$selectedOption.length) {
                return;
            }
            
            const price = $selectedOption.data('price');
            const salePrice = $selectedOption.data('sale-price');
            
            let priceHtml = '';
            
            if (salePrice !== null && salePrice !== '' && salePrice !== undefined) {
                // Show sale price
                priceHtml = '<span class="vrstore-product-regular-price" style="text-decoration: line-through;">' + formatPrice(price) + '</span> ';
                priceHtml += '<span class="vrstore-product-sale-price" style="color: #e74c3c; font-weight: bold;">' + formatPrice(salePrice) + '</span>';
            } else if (price !== null && price !== '' && price !== undefined) {
                // Show regular price
                priceHtml = '<span class="vrstore-product-regular-price" style="font-weight: bold; font-size: 1.2em;">' + formatPrice(price) + '</span>';
            } else {
                // No price set
                priceHtml = '<span class="vrstore-product-no-price" style="color: #999;">Price not set</span>';
            }
            
            $priceDisplay.html(priceHtml);
        }
        
        // Function to format price using settings (no K/M notation)
        // Note: Prices from license dropdown are already converted by PHP backend
        function formatPrice(price) {
            if (price === null || price === '' || price === undefined) {
                return '';
            }
            
            const numPrice = parseFloat(price);
            if (isNaN(numPrice)) {
                return '';
            }
            
            // Prices are already converted by PHP backend, just format them
            const convertedPrice = numPrice;
            
            // Get formatting settings from data attributes on the select element or fallback to localized data
            // Use consistent currency symbol priority: data attributes first, then localized data
            const baseCurrency = vrstore_frontend.currency || 'USD';
            const currentCurrency = vrstore_frontend.current_currency || baseCurrency;
            const currencySymbol = $licenseSelect.data('currency-symbol') || vrstore_frontend.currency_symbol || '$';
            const currencyPosition = $licenseSelect.data('currency-position') || vrstore_frontend.currency_position || 'left';
            const decimalSeparator = $licenseSelect.data('decimal-separator') || vrstore_frontend.decimal_separator || '.';
            const thousandSeparator = $licenseSelect.data('thousand-separator') || vrstore_frontend.thousand_separator || ',';
            const decimals = parseInt($licenseSelect.data('decimals') || vrstore_frontend.decimal_number || '2');
            
            // Regular number formatting for amounts
            let parts = convertedPrice.toFixed(decimals).split('.');
            parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, thousandSeparator);
            let formatted = parts.join(decimalSeparator);
            
            // Apply currency position
            switch (currencyPosition) {
                case 'right':
                    return formatted + currencySymbol;
                case 'left_space':
                    return currencySymbol + ' ' + formatted;
                case 'right_space':
                    return formatted + ' ' + currencySymbol;
                case 'left':
                default:
                    return currencySymbol + formatted;
            }
        }
    }

    // Initialize authentication interface functionality
    function initAuthInterface() {
        // Handle tab switching between Sign In and Create Account
        // Use event delegation to avoid conflicts with initAuthTabs
        $(document).off('click.authInterface', '.vrstore-auth-tab').on('click.authInterface', '.vrstore-auth-tab', function(e) {
            e.preventDefault();
            
            // Store current scroll position
            const scrollPos = window.scrollY || window.pageYOffset;
            
            const $clickedTab = $(this);
            const targetTab = $clickedTab.data('tab');
            // Handle both container types: .vrstore-auth-section (checkout) and .vrstore-auth-container (account page)
            const $authSection = $clickedTab.closest('.vrstore-auth-section, .vrstore-auth-container, .vrstore-auth-box');
            
            // Don't do anything if already active (check both class variations)
            if ($clickedTab.hasClass('active') || $clickedTab.hasClass('vrstore-active')) {
                return;
            }
            
            // Update tab buttons - handle both class variations for compatibility
            $authSection.find('.vrstore-auth-tab').removeClass('active vrstore-active');
            $clickedTab.addClass('active vrstore-active');
            
            // Update content visibility - handle both class variations
            $authSection.find('.vrstore-auth-content, .vrstore-auth-form').removeClass('active vrstore-active');
            
            // Map tab names to form selectors
            let formSelector = '';
            if (targetTab === 'signin' || targetTab === 'login') {
                formSelector = '#vrstore-signin-form, .vrstore-login-form';
            } else if (targetTab === 'signup' || targetTab === 'register') {
                formSelector = '#vrstore-signup-form, .vrstore-register-form';
            }
            
            // Show corresponding form
            if (formSelector) {
                $authSection.find(formSelector).addClass('active vrstore-active');
            }
            
            // Restore scroll position to prevent page jump
            window.scrollTo(0, scrollPos);
            
            // Focus on first input field without scrolling
            setTimeout(function() {
                // Store current scroll position again before focusing
                const currentScrollPos = window.scrollY || window.pageYOffset;
                
                const $activeForm = $authSection.find('.vrstore-auth-content.active, .vrstore-auth-form.active').first();
                if ($activeForm.length) {
                    const $firstInput = $activeForm.find('input:first');
                    if ($firstInput.length) {
                        try {
                            // Try with preventScroll option first
                            $firstInput.focus({ preventScroll: true });
                        } catch (e) {
                            // Fallback for browsers that don't support preventScroll
                            $firstInput.focus();
                            // Restore scroll position immediately after focus
                            window.scrollTo(0, currentScrollPos);
                        }
                    }
                }
                
                // Ensure scroll position is maintained
                window.scrollTo(0, currentScrollPos);
            }, 150);
            
            // Ensure checkout form remains hidden for guest users (checkout page compatibility)
            if (!$('input[name="vrstore_is_logged_in"]').val()) {
                $('.vrstore-checkout-form-container').hide();
                $('.vrstore-checkout-form').hide();
            }
        });
        
        // Handle AJAX form submissions
        $('#vrstore-login-form').on('submit', function(e) {
            e.preventDefault();
            handleLoginSubmission($(this));
        });
        
        $('#vrstore-register-form').on('submit', function(e) {
            e.preventDefault();
            handleRegistrationSubmission($(this));
        });
        
        // Login form handler
        function handleLoginSubmission($form) {
            const $submitBtn = $form.find('.vrstore-auth-submit');
            const originalBtnText = $submitBtn.text();
            
            // Basic validation
            const username = $form.find('input[name="username"]').val().trim();
            const password = $form.find('input[name="password"]').val();
            
            if (!username || !password) {
                showAuthMessage('Please enter both username and password.', 'error');
                return;
            }
            
            // Show loading state
            $form.addClass('loading');
            $submitBtn.prop('disabled', true).text('Signing in...');
            
            // Get form data
            const formData = {
                action: 'vrstore_custom_login',
                username: username,
                password: password,
                remember: $form.find('input[name="remember"]:checked').val() || 'false',
                redirect_to: $form.find('input[name="redirect_to"]').val(),
                nonce: $form.find('input[name="nonce"]').val(),
                math_captcha: $form.find('input[name="math_captcha"]').val() || 0,
                math_answer: $form.find('input[name="math_answer"]').val() || 0
            };
            
            // Submit via AJAX
            $.ajax({
                url: vrstore_frontend.ajax_url,
                type: 'POST',
                data: formData,
                success: function(response) {
                    if (response.success) {
                        showAuthMessage(response.data.message, 'success');
                        // Redirect after short delay
                        setTimeout(function() {
                            window.location.href = response.data.redirect_url;
                        }, 1500);
                    } else {
                        showAuthMessage(response.data.message, 'error');
                        // Reset form
                        $form.removeClass('loading');
                        $submitBtn.prop('disabled', false).text(originalBtnText);
                    }
                },
                error: function() {
                    showAuthMessage('An error occurred. Please try again.', 'error');
                    // Reset form
                    $form.removeClass('loading');
                    $submitBtn.prop('disabled', false).text(originalBtnText);
                }
            });
        }
        
        // Registration form handler
        function handleRegistrationSubmission($form) {
            const $submitBtn = $form.find('.vrstore-auth-submit');
            const originalBtnText = $submitBtn.text();
            
            // Basic validation
            const username = $form.find('input[name="username"]').val().trim();
            const email = $form.find('input[name="email"]').val().trim();
            const password = $form.find('input[name="password"]').val();
            const passwordConfirm = $form.find('input[name="password_confirm"]').val();
            
            // Client-side validation
            if (!username || !email || !password) {
                showAuthMessage('Please fill in all required fields.', 'error');
                return;
            }
            
            // Email validation
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(email)) {
                showAuthMessage('Please enter a valid email address.', 'error');
                return;
            }
            
            // Password validation
            if (password.length < 6) {
                showAuthMessage('Password must be at least 6 characters long.', 'error');
                return;
            }
            
            if (password !== passwordConfirm) {
                showAuthMessage('Passwords do not match.', 'error');
                return;
            }
            
            // Show loading state
            $form.addClass('loading');
            $submitBtn.prop('disabled', true).text('Processing registration...');
            
            // Get form data
            const formData = {
                action: 'vrstore_custom_register',
                username: username,
                email: email,
                password: password,
                password_confirm: passwordConfirm,
                nonce: $form.find('input[name="nonce"]').val(),
                math_captcha: $form.find('input[name="math_captcha"]').val() || 0,
                math_answer: $form.find('input[name="math_answer"]').val() || 0
            };
            
            // Submit via AJAX
            $.ajax({
                url: vrstore_frontend.ajax_url,
                type: 'POST',
                data: formData,
                success: function(response) {
                    if (response.success) {
                        showAuthMessage(response.data.message, 'success');
                        // Redirect after short delay
                        setTimeout(function() {
                            window.location.href = response.data.redirect_url;
                        }, 1500);
                    } else {
                        showAuthMessage(response.data.message, 'error');
                        // Reset form
                        $form.removeClass('loading');
                        $submitBtn.prop('disabled', false).text(originalBtnText);
                    }
                },
                error: function() {
                    showAuthMessage('Registration failed. Please try again.', 'error');
                    // Reset form
                    $form.removeClass('loading');
                    $submitBtn.prop('disabled', false).text(originalBtnText);
                }
            });
        }
        
        // Enhanced form field interactions
        $('.vrstore-checkout-form input, .vrstore-checkout-form select, .vrstore-checkout-form textarea, .vrstore-form-control').on('focus', function() {
            $(this).closest('.vrstore-form-group, .form-row').addClass('focused');
        }).on('blur', function() {
            $(this).closest('.vrstore-form-group, .form-row').removeClass('focused');
            
            if ($(this).val()) {
                $(this).closest('.vrstore-form-group, .form-row').addClass('has-value');
            } else {
                $(this).closest('.vrstore-form-group, .form-row').removeClass('has-value');
            }
        });
        
        // Initialize form states on load
        $('.vrstore-checkout-form input, .vrstore-checkout-form select, .vrstore-checkout-form textarea, .vrstore-form-control').each(function() {
            if ($(this).val()) {
                $(this).closest('.vrstore-form-group, .form-row').addClass('has-value');
            }
        });
        
        // Handle password visibility toggle (if needed)
        $(document).on('click', '.vrstore-toggle-password', function(e) {
            e.preventDefault();
            const $btn = $(this);
            const $field = $btn.siblings('input[type="password"], input[type="text"]');
            
            if ($field.attr('type') === 'password') {
                $field.attr('type', 'text');
                $btn.text('Hide');
            } else {
                $field.attr('type', 'password');
                $btn.text('Show');
            }
        });
        
        // Show auth messages
        function showAuthMessage(message, type) {
            const $container = $('.vrstore-auth-box');
            const $existingMessages = $container.find('.vrstore-auth-message');
            
            // Remove existing messages
            $existingMessages.fadeOut(function() {
                $(this).remove();
            });
            
            // Create and show new message
            const $message = $('<div class="vrstore-auth-message vrstore-message vrstore-message-' + type + '"></div>');
            $message.html('<span>' + message + '</span><button type="button" class="vrstore-message-close" aria-label="Close">&times;</button>');
            
            $message.prependTo($container).hide().slideDown();
            
            // Auto-remove message after 5 seconds
            setTimeout(function() {
                $message.fadeOut(function() {
                    $(this).remove();
                });
            }, 5000);
        }
        
        // Handle message close buttons
        $(document).on('click', '.vrstore-message-close', function() {
            $(this).closest('.vrstore-message').fadeOut(function() {
                $(this).remove();
            });
        });
        
        // Handle enter key navigation between forms
        $('.vrstore-auth-form input').on('keydown', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                const $nextInput = $(this).closest('.vrstore-form-group, .form-row').next('.vrstore-form-group, .form-row').find('input');
                if ($nextInput.length) {
                    $nextInput.focus();
                } else {
                    $(this).closest('form').find('.vrstore-auth-submit').click();
                }
            }
        });
        
        // Add subtle animations on form interactions
        $('.vrstore-auth-form').on('submit', function() {
            $(this).addClass('submitting');
        });
        
        // Handle URL parameters for showing registration form by default
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('action') === 'register') {
            $('.vrstore-auth-tab[data-tab="signup"]').click();
        }
        
        // Focus on first input when page loads
        setTimeout(function() {
            $('.vrstore-auth-form.active input:first').focus();
        }, 500);
    }
    

    
    // Registration form functionality
    function initRegistrationForm() {
        // Show/hide registration form
        $('#vrstore-show-register-form').on('click', function() {
            $('#vrstore-register-form').slideDown();
            $(this).hide();
            $('.vrstore-login-btn').hide();
            
            // Also show the checkout form with payment methods
            $('.vrstore-checkout-form-container').slideDown();
            $('.vrstore-checkout-form').show().css('display', 'block');
        });
        
        // Cancel registration
        $('#vrstore-cancel-register').on('click', function() {
            $('#vrstore-register-form').slideUp();
            $('#vrstore-show-register-form').show();
            $('.vrstore-login-btn').show();
            
            // Hide checkout form for non-logged-in users
            $('.vrstore-checkout-form-container').slideUp();
            $('.vrstore-checkout-form').hide();
            
            // Clear form
            $('#vrstore-registration-form')[0].reset();
            // Remove any error messages
            $('.vrstore-notice-error').remove();
        });
        
        // Add form validation for registration fields when checkout form is submitted
        // This will be handled by the main checkout form submission now
    }
    
    // Clear any stuck "Processing..." states immediately
    function clearProcessingStates() {
        // Remove loading classes and reset button states
        $('.loading').removeClass('loading').prop('disabled', false);
        
        // Clear buy button loading states specifically
        $('.vrstore-buy-button').prop('disabled', false);
        $('.vrstore-buy-button-loading.active').removeClass('active');
        
        // Find and fix any buttons/elements with "Processing..." text
        $('*').filter(function() {
            return $(this).text().trim() === 'Processing...' || 
                   $(this).html().indexOf('Processing...') !== -1 ||
                   $(this).text().trim() === 'Redirecting...';
        }).each(function() {
            const $element = $(this);
            const originalText = $element.data('original-text');
            
            if (originalText) {
                $element.html(originalText).removeClass('loading').prop('disabled', false);
            } else if ($element.is('button, input[type="button"], input[type="submit"]')) {
                // For buttons without stored original text, use appropriate text
                if ($element.hasClass('vrstore-show-downloads')) {
                    $element.html('Downloads').removeClass('loading').prop('disabled', false);
                } else if ($element.hasClass('vrstore-buy-button')) {
                    $element.html('Buy Now').removeClass('loading').prop('disabled', false);
                } else if ($element.hasClass('vrstore-checkout-button')) {
                    $element.html('Purchase and Register').removeClass('loading').prop('disabled', false);
                } else {
                    $element.html('Submit').removeClass('loading').prop('disabled', false);
                }
            }
        });
        
        // Clear any orphaned loading spinners or overlays
        $('.vrstore-loading').hide();
        $('.vrstore-spinner').hide();
    }

    // Bank Details Copy Functionality
    initCopyButtons();
    
    /**
     * Initialize copy to clipboard functionality for bank details
     */
    function initCopyButtons() {
        $(document).on('click', '.vrstore-copy-btn', function(e) {
            e.preventDefault();
            
            const $btn = $(this);
            const textToCopy = $btn.data('copy');
            const $icon = $btn.find('.dashicons');
            const originalTitle = $btn.attr('title');
            
            if (!textToCopy) {
                return;
            }
            
            // Try modern clipboard API first
            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(textToCopy)
                    .then(() => {
                        showCopySuccess($btn, $icon, originalTitle);
                    })
                    .catch(() => {
                        // Fallback to legacy method
                        fallbackCopyText(textToCopy, $btn, $icon, originalTitle);
                    });
            } else {
                // Use fallback method for older browsers
                fallbackCopyText(textToCopy, $btn, $icon, originalTitle);
            }
        });
    }
    
    /**
     * Fallback copy method for older browsers
     */
    function fallbackCopyText(text, $btn, $icon, originalTitle) {
        // Create a temporary textarea element
        const $temp = $('<textarea>');
        $('body').append($temp);
        $temp.val(text).select();
        
        try {
            const successful = document.execCommand('copy');
            if (successful) {
                showCopySuccess($btn, $icon, originalTitle);
            } else {
                showCopyError($btn, $icon, originalTitle);
            }
        } catch (err) {
            showCopyError($btn, $icon, originalTitle);
        }
        
        $temp.remove();
    }
    
    /**
     * Show copy success feedback
     */
    function showCopySuccess($btn, $icon, originalTitle) {
        // Change icon and add success class
        $icon.removeClass('dashicons-admin-page').addClass('dashicons-yes-alt');
        $btn.addClass('vrstore-copy-success');
        $btn.attr('title', 'Copied!');
        
        // Add visual feedback
        $btn.css({
            'background': 'var(--vrstore-success)',
            'color': 'var(--vrstore-white)',
            'transform': 'scale(1.1)'
        });
        
        // Reset after 2 seconds
        setTimeout(() => {
            $icon.removeClass('dashicons-yes-alt').addClass('dashicons-admin-page');
            $btn.removeClass('vrstore-copy-success');
            $btn.attr('title', originalTitle);
            $btn.css({
                'background': '',
                'color': '',
                'transform': ''
            });
        }, 2000);
    }
    
    /**
     * Show copy error feedback
     */
    function showCopyError($btn, $icon, originalTitle) {
        // Change icon and add error class
        $icon.removeClass('dashicons-admin-page').addClass('dashicons-dismiss');
        $btn.addClass('vrstore-copy-error');
        $btn.attr('title', 'Copy failed');
        
        // Add visual feedback
        $btn.css({
            'background': 'var(--vrstore-error)',
            'color': 'var(--vrstore-white)'
        });
        
        // Reset after 2 seconds
        setTimeout(() => {
            $icon.removeClass('dashicons-dismiss').addClass('dashicons-admin-page');
            $btn.removeClass('vrstore-copy-error');
            $btn.attr('title', originalTitle);
            $btn.css({
                'background': '',
                'color': ''
            });
        }, 2000);
    }

    // Copy to clipboard functionality
    $(document).on('click', '.vrstore-copy-btn', function(e) {
        e.preventDefault();
        const $this = $(this);
        const textToCopy = $this.siblings('.vrstore-detail-value').text().trim();
        
        // Modern clipboard API with fallback
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(textToCopy).then(function() {
                showCopyFeedback($this);
            }).catch(function() {
                fallbackCopyTextToClipboard(textToCopy, $this);
            });
        } else {
            fallbackCopyTextToClipboard(textToCopy, $this);
        }
    });

    // Fallback copy function for older browsers
    function fallbackCopyTextToClipboard(text, $button) {
        const $temp = $('<textarea>');
        $('body').append($temp);
        $temp.val(text).select();
        
        try {
            document.execCommand('copy');
            showCopyFeedback($button);
        } catch (err) {
            console.error('Copy failed:', err);
        }
        
        $temp.remove();
    }

    // Show copy feedback
    function showCopyFeedback($button) {
        const $icon = $button.find('.dashicons');
        const originalClass = $icon.attr('class');
        const originalTitle = $button.attr('title') || '';
        
        // Change icon to checkmark
        $icon.removeClass().addClass('dashicons dashicons-yes-alt');
        $button.attr('title', 'Copied!');
        
        // Reset after 2 seconds
        setTimeout(function() {
            $icon.removeClass().addClass(originalClass);
            $button.attr('title', originalTitle);
        }, 2000);
    }

    // Initialize all functions when document is ready
    $(document).ready(function() {
        // Clear any stuck processing states first
        clearProcessingStates();
        
        // Check for checkout completion first
        checkCheckoutCompletion();
        
        // Initialize other functions as needed
        initCheckoutValidation();
        initRegistrationForm();
        initThankYouPage();
        // Bank details modal now uses CSS-only approach

        // initDownloadsModal(); // Moved to customer-portal.js
        
        // DISABLED: Moved to customer-portal.js
        // No downloads handling in frontend.js anymore
        
        // Initialize other functions if they exist
        if (typeof initPaymentMethodSelection === 'function') {
            initPaymentMethodSelection();
        }
        
        if (typeof initLicenseActivation === 'function') {
            initLicenseActivation();
        }
        
        if (typeof initLicenseDeactivation === 'function') {
            initLicenseDeactivation();
        }
        
        if (typeof initLicenseDomainRefresh === 'function') {
            initLicenseDomainRefresh();
        }
        
        if (typeof initLicenseDomainAdd === 'function') {
            initLicenseDomainAdd();
        }
        
        // Account update functionality removed
        
        if (typeof initAuthInterface === 'function') {
            initAuthInterface();
        }
        

        
        // Clear processing states periodically to prevent sticking
        setInterval(clearProcessingStates, 5000);
        
        // Expose clearProcessingStates globally
        window.ViraStore = window.ViraStore || {};
        window.ViraStore.clearProcessingStates = clearProcessingStates;
        
        // Initialize buy button functionality
        initBuyButton();
        
        // Initialize domain timestamp refresh
        initDomainTimestampRefresh();
        
        // Initialize support ticket functionality
        initSupportTickets();
    });
    
    // Support ticket functionality
    function initSupportTickets() {
        var ajaxUrl = (typeof vrstore_ajax !== 'undefined' && vrstore_ajax.ajax_url) ? vrstore_ajax.ajax_url : (typeof ajaxurl !== 'undefined' ? ajaxurl : '');
        var nonce = $('#vrstore-nonce').val() || 
                   (typeof vrstore_frontend !== 'undefined' && vrstore_frontend.nonce) || 
                   $('meta[name="vrstore-nonce"]').attr('content') || '';

        function openModal(sel){ 
            $(sel).addClass('vrstore-modal-visible').show(); 
            $('body').addClass('vrstore-modal-open'); 
        }
        function closeModal(sel){ 
            $(sel).removeClass('vrstore-modal-visible').hide(); 
            $('body').removeClass('vrstore-modal-open'); 
        }

        // Check ticket lock status and show appropriate message or modal
        function checkTicketLockStatus(callback) {
            $.post(ajaxUrl, {
                action: 'vrstore_check_ticket_lock_status',
                nonce: nonce
            })
            .done(function(resp) {
                if (resp && resp.success) {
                    callback(resp.data);
                } else {
                    // If check fails, assume not locked
                    callback({locked: false, message: ''});
                }
            })
            .fail(function() {
                // If check fails, assume not locked
                callback({locked: false, message: ''});
            });
        }
        
        // Show Extended Support purchase notification
        function showExtendedSupportNotification(message) {
            var notification = '<div class="vrstore-alert vrstore-alert-warning" style="margin: 20px 0;">' +
                '<span class="dashicons dashicons-lock"></span>' +
                '<div style="margin-left: 10px;">' +
                '<strong>' + message + '</strong><br>' +
                '<button id="vrstore-purchase-extended-support-from-ticket" class="button button-primary" style="margin-top: 10px;">' +
                'Purchase Extended Support' +
                '</button>' +
                '</div>' +
                '</div>';
            
            showNotification(notification, 'warning');
            
            // Handle Extended Support purchase button click
            $(document).on('click', '#vrstore-purchase-extended-support-from-ticket', function(e) {
                e.preventDefault();
                // Trigger Extended Support modal if available
                if ($('#vrstore-extended-support-btn').length) {
                    $('#vrstore-extended-support-btn').click();
                } else {
                    showNotification('Extended Support is not available at this time.', 'danger');
                }
            });
        }
        
        // Open create ticket modal
        $(document).on('click', '#vrstore-create-ticket-btn, #vrstore-create-first-ticket', function(e){
            e.preventDefault();
            
            // Check if tickets are locked first
            checkTicketLockStatus(function(lockStatus) {
                if (lockStatus.locked) {
                    showExtendedSupportNotification(lockStatus.message);
                } else {
                    openModal('#vrstore-create-ticket-modal');
                }
            });
        });

        // Duplicate modal close handler removed - consolidated above

        // Enhanced form validation
        function validateTicketForm(data) {
            var errors = [];
            
            if (!data.subject || data.subject.length < 5) {
                errors.push('Subject must be at least 5 characters long.');
            }
            
            if (!data.message || data.message.length < 20) {
                errors.push('Message must be at least 20 characters long.');
            }
            
            return errors;
        }

        // Show notification
        function showNotification(message, type) {
            var className = 'vrstore-alert vrstore-alert-' + (type || 'info');
            var $notification = $('<div class="' + className + '" style="position: fixed; top: 20px; right: 20px; z-index: 100002; max-width: 400px; animation: slideInRight 0.3s ease-out;">' +
                '<span class="dashicons dashicons-' + (type === 'success' ? 'yes-alt' : type === 'danger' ? 'warning' : 'info') + '"></span>' +
                '<span>' + message + '</span>' +
                '<button class="vrstore-notification-close" style="float: right; background: none; border: none; cursor: pointer; color: inherit; opacity: 0.7;">&times;</button>' +
            '</div>');
            
            $('body').append($notification);
            
            // Auto-hide after 5 seconds
            setTimeout(function() {
                $notification.fadeOut(300, function() { $(this).remove(); });
            }, 5000);
            
            // Manual close
            $notification.find('.vrstore-notification-close').on('click', function() {
                $notification.fadeOut(300, function() { $(this).remove(); });
            });
        }

        // Enhanced button loading state
        function setButtonLoading($btn, loading) {
            if (loading) {
                $btn.addClass('loading').prop('disabled', true);
                $btn.find('.vrstore-button-text').hide();
                $btn.find('.vrstore-button-spinner').show();
            } else {
                $btn.removeClass('loading').prop('disabled', false);
                $btn.find('.vrstore-button-text').show();
                $btn.find('.vrstore-button-spinner').hide();
            }
        }

        // REMOVED: Duplicate ticket submission handler that was causing triple submissions.
        // The unified handler in initSupportTicketHandlers() handles ticket submissions properly.
        // All ticket submission logic is consolidated in the initSupportTicketHandlers() function.

        // Enhanced view ticket button with loading state
        $(document).on('click', '.vrstore-view-ticket', function(){
            var $btn = $(this);
            var ticketId = $btn.data('ticket-id');
            var ticketNo = $btn.data('ticket-number');
            
            // Prevent double-click
            if ($btn.hasClass('loading')) return;
            
            setButtonLoading($btn, true);
            
            $('#vrstore-ticket-modal-title').text('Ticket #' + ticketNo);
            $('#vrstore-ticket-content').hide().empty();
            $('#vrstore-ticket-loading').show();
            openModal('#vrstore-ticket-modal');

            $.post(ajaxUrl, {
                action: 'vrstore_get_my_ticket_details',
                nonce: nonce,
                ticket_id: ticketId
            })
            .done(function(resp){
                $('#vrstore-ticket-loading').hide();
                if(resp && resp.success){
                    $('#vrstore-ticket-content').html(resp.data.html).show();
                    bindReplyForm();
                    // Mark any unread notifications as read
                    markTicketAsRead(ticketId);
                }else{
                    var errorMsg = (resp && resp.data && resp.data.message) ? resp.data.message : 'Failed to load ticket.';
                    $('#vrstore-ticket-content').html('<div class="vrstore-alert vrstore-alert-danger"><span class="dashicons dashicons-warning"></span><span>' + errorMsg + '</span></div>').show();
                }
            })
            .fail(function(xhr, status, error){
                $('#vrstore-ticket-loading').hide();
                var errorMsg = 'Network error occurred.';
                if (xhr.status === 403) {
                    errorMsg = 'Permission denied. Please refresh the page and try again.';
                } else if (xhr.status >= 500) {
                    errorMsg = 'Server error occurred. Please try again later.';
                }
                $('#vrstore-ticket-content').html('<div class="vrstore-alert vrstore-alert-danger"><span class="dashicons dashicons-warning"></span><span>' + errorMsg + '</span></div>').show();
            })
            .always(function() {
                setButtonLoading($btn, false);
            });
        });

        // Mark ticket as read (remove unread indicators)
        function markTicketAsRead(ticketId) {
            $('.vrstore-view-ticket[data-ticket-id="' + ticketId + '"]').closest('tr, .vrstore-mobile-card').find('.vrstore-unread-badge').fadeOut(300, function() {
                $(this).remove();
            });
        }

        function bindReplyForm(){
            $('#vrstore-customer-reply-form').off('submit').on('submit', function(e){
                e.preventDefault();
                var $form = $(this);
                var $btn = $form.find('button[type="submit"]');
                var $textarea = $form.find('textarea[name="message"]');
                var message = $textarea.val().trim();
                var ticketId = $form.data('ticket-id');
                
                // Enhanced validation
                if(!message){
                    showNotification('Please enter your reply message.', 'danger');
                    $textarea.focus();
                    return;
                }
                
                if(message.length < 5){
                    showNotification('Reply message must be at least 5 characters long.', 'danger');
                    $textarea.focus();
                    return;
                }
                
                setButtonLoading($btn, true);

                $.post(ajaxUrl, {
                    action: 'vrstore_add_customer_ticket_reply',
                    nonce: nonce,
                    ticket_id: ticketId,
                    message: message
                })
                .done(function(resp){
                    if(resp && resp.success){
                        showNotification('Reply sent successfully!', 'success');
                        // Clear the form
                        $textarea.val('');
                        // Reload the ticket content to show the new reply
                        setTimeout(function() {
                            $('.vrstore-view-ticket[data-ticket-id="'+ticketId+'"]').click();
                        }, 500);
                    }else{
                        var errorMsg = (resp && resp.data && resp.data.message) ? resp.data.message : 'Failed to send reply.';
                        
                        // Check if this is a license lock error
                        if (resp && resp.data && resp.data.locked && resp.data.show_extended_support) {
                            closeModal('#vrstore-ticket-modal');
                            showExtendedSupportNotification(errorMsg);
                        } else {
                            showNotification(errorMsg, 'danger');
                        }
                    }
                })
                .fail(function(xhr, status, error){
                    var errorMsg = 'Network error occurred.';
                    if (xhr.status === 403) {
                        errorMsg = 'Permission denied. Please refresh the page and try again.';
                    } else if (xhr.status >= 500) {
                        errorMsg = 'Server error occurred. Please try again later.';
                    }
                    showNotification(errorMsg, 'danger');
                })
                .always(function(){
                    setButtonLoading($btn, false);
                });
            });
        }
    }
    
    // Buy Button Functionality
    function initBuyButton() {
        // Handle buy button clicks
        $(document).on('click', '.vrstore-buy-button', function(e) {
            e.preventDefault();
            
            var $button = $(this);
            var $container = $button.closest('.vrstore-buy-button-container');
            var $loading = $container.find('.vrstore-buy-button-loading');
            var productId = $button.data('product-id');
            
            // Get license type from dropdown or button data attribute
            var licenseType = $container.find('.vrstore-buy-button-license-dropdown').val() || $button.data('license-type') || '';
            
            // Show loading state
            $button.prop('disabled', true);
            $loading.addClass('active');
            
            // Store original button text
            var originalText = $button.text();
            $button.text('Processing...');
            
            // Get AJAX URL with fallback
            var ajaxUrl = (typeof vrstore_ajax !== 'undefined' && vrstore_ajax.ajax_url) 
                ? vrstore_ajax.ajax_url 
                : (typeof ajaxurl !== 'undefined' ? ajaxurl : '/wp-admin/admin-ajax.php');
            
            // Get nonce with fallback
            var nonce = (typeof vrstore_ajax !== 'undefined' && vrstore_ajax.nonce)
                ? vrstore_ajax.nonce
                : (typeof vrstore_frontend !== 'undefined' && vrstore_frontend.nonce)
                    ? vrstore_frontend.nonce
                    : $('#vrstore-nonce').val() || $('meta[name="vrstore-nonce"]').attr('content') || '';
            
            // AJAX request to add to cart
            $.ajax({
                url: ajaxUrl,
                type: 'POST',
                data: {
                    action: 'vrstore_add_to_cart',
                    product_id: productId,
                    license_type: licenseType,
                    nonce: nonce
                },
                timeout: 30000, // 30 second timeout
                success: function(response) {
                    if (response.success) {
                        // Redirect to checkout or show success message
                        if (response.data.redirect_url) {
                            $button.text('Redirecting...');
                            window.location.href = response.data.redirect_url;
                        } else {
                            // Show success message
                            resetButtonState();
                            $button.text('Added to Cart!');
                            setTimeout(function() {
                                $button.text(originalText).prop('disabled', false);
                            }, 2000);
                        }
                    } else {
                        // Show error message
                        resetButtonState();
                        alert(response.data.message || 'An error occurred. Please try again.');
                    }
                },
                error: function(xhr, status, error) {
                    resetButtonState();
                    var errorMessage = 'An error occurred. Please try again.';
                    
                    if (status === 'timeout') {
                        errorMessage = 'Request timed out. Please try again.';
                    } else if (xhr.status === 403) {
                        errorMessage = 'Permission denied. Please refresh the page and try again.';
                    } else if (xhr.status >= 500) {
                        errorMessage = 'Server error occurred. Please try again later.';
                    }
                    
                    alert(errorMessage);
                }
            });
            
            // Function to reset button state
            function resetButtonState() {
                $loading.removeClass('active');
                $button.prop('disabled', false).text(originalText);
            }
            
            // Failsafe: Reset button state after 35 seconds
            setTimeout(function() {
                if ($button.prop('disabled')) {
                    resetButtonState();
                }
            }, 35000);
        });
        
        // Initialize license dropdown price display on page load
        $('.vrstore-buy-button-license-dropdown').each(function() {
            var $dropdown = $(this);
            
            // Trigger change event to set initial price
            if ($dropdown.find('option:selected').length) {
                $dropdown.trigger('change');
            }
        });
        
        // Initialize single product license dropdown price display on page load
        $('#vrstore-license-type').each(function() {
            var $dropdown = $(this);
            
            // Trigger change event to set initial price
            if ($dropdown.find('option:selected').length) {
                $dropdown.trigger('change');
            }
        });
        
        // Handle license dropdown changes
        $(document).on('change', '.vrstore-buy-button-license-dropdown', function() {
            var $dropdown = $(this);
            var $container = $dropdown.closest('.vrstore-buy-button-container');
            var $priceDisplay = $container.find('.vrstore-buy-button-price');
            var selectedOption = $dropdown.find('option:selected');
            var regularPrice = selectedOption.data('price'); // This is already converted price
            var salePrice = selectedOption.data('sale-price'); // This is already converted price
            
            // Get currency formatting info from the dropdown
            var currencySymbol = $dropdown.data('currency-symbol') || '$';
            var currencyPosition = $dropdown.data('currency-position') || 'left';
            var decimals = parseInt($dropdown.data('decimals')) || 2;
            var decimalSeparator = $dropdown.data('decimal-separator') || '.';
            var thousandSeparator = $dropdown.data('thousand-separator') || ',';
            
            // Function to format price with proper currency
            function formatPrice(amount) {
                if (!amount || isNaN(amount)) return '';
                
                var num = parseFloat(amount);
                var formatted = num.toLocaleString('en-US', {
                    minimumFractionDigits: decimals,
                    maximumFractionDigits: decimals
                });
                
                // Apply custom separators if different from default
                if (decimalSeparator !== '.') {
                    formatted = formatted.replace('.', decimalSeparator);
                }
                if (thousandSeparator !== ',') {
                    formatted = formatted.replace(/,/g, thousandSeparator);
                }
                
                // Apply currency position
                switch (currencyPosition) {
                    case 'right':
                        return formatted + currencySymbol;
                    case 'left_space':
                        return currencySymbol + ' ' + formatted;
                    case 'right_space':
                        return formatted + ' ' + currencySymbol;
                    case 'left':
                    default:
                        return currencySymbol + formatted;
                }
            }
            
            if ((regularPrice || salePrice) && $priceDisplay.length) {
                var priceHtml = '';
                
                // If we have a sale price and it's different from regular price
                if (salePrice && salePrice !== '' && salePrice !== regularPrice && parseFloat(salePrice) > 0) {
                    // Show both regular (crossed out) and sale price
                    if (regularPrice && parseFloat(regularPrice) > 0) {
                        priceHtml = '<span class="vrstore-buy-button-regular-price">' + formatPrice(regularPrice) + '</span>';
                    }
                    priceHtml += '<span class="vrstore-buy-button-sale-price">' + formatPrice(salePrice) + '</span>';
                } else if (regularPrice && parseFloat(regularPrice) > 0) {
                    // Show only regular price
                    priceHtml = '<span class="vrstore-buy-button-price-single">' + formatPrice(regularPrice) + '</span>';
                } else if (salePrice && parseFloat(salePrice) > 0) {
                    // Only sale price available
                    priceHtml = '<span class="vrstore-buy-button-price-single">' + formatPrice(salePrice) + '</span>';
                }
                
                $priceDisplay.html(priceHtml);
            }
        });
    }
    
    // Account Domain Timestamp Refresh Functionality
    function initDomainTimestampRefresh() {
        var $timestampElement = $('.vrstore-domain-timestamp');
        if ($timestampElement.length && typeof vrstore_ajax !== 'undefined') {
            setTimeout(function() {
                $.ajax({
                    url: vrstore_ajax.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'vrstore_refresh_domain_timestamp',
                        nonce: $('meta[name="vrstore-nonce"]').attr('content') || $('#vrstore_nonce').val()
                    },
                    success: function(response) {
                        if (response.success && response.data.timestamp) {
                            $timestampElement.text(response.data.timestamp);
                        }
                    },
                    error: function() {
                        // Fallback: just update with current time
                        var now = new Date();
                        $timestampElement.text(now.toLocaleString());
                    }
                });
            }, 2000); // 2 second delay
        }
    }

    // Extended Support functionality
    function initExtendedSupport() {
        var ajaxUrl = (typeof vrstore_ajax !== 'undefined' && vrstore_ajax.ajax_url) ? vrstore_ajax.ajax_url : (typeof ajaxurl !== 'undefined' ? ajaxurl : '');
        var nonce = $('#vrstore-nonce').val() || 
                   (typeof vrstore_frontend !== 'undefined' && vrstore_frontend.nonce) || 
                   $('meta[name="vrstore-nonce"]').attr('content') || '';
        var isLoadingPricing = false; // Flag to prevent multiple requests

        function openModal(sel){ 
            $(sel).addClass('vrstore-modal-visible').show(); 
            $('body').addClass('vrstore-modal-open'); 
        }
        
        function closeModal(sel){ 
            // Handle both jQuery objects and selectors
            const $modal = (sel instanceof jQuery) ? sel : $(sel);
            $modal.removeClass('vrstore-modal-visible');
            
            // For Extended Support modal, ensure proper cleanup
            const modalId = (sel instanceof jQuery) ? $modal.attr('id') : sel.replace('#', '');
            if (modalId === 'vrstore-extended-support-modal' || sel === '#vrstore-extended-support-modal') {
                // Reset loading states
                $modal.find('#vrstore-extended-support-loading').hide();
                $modal.find('#vrstore-extended-support-content').show();
                $modal.find('.vrstore-modal-content').show();
            }
            
            $modal.hide(); 
            
            // Comprehensive backdrop cleanup for support modals
            $('body').removeClass('vrstore-modal-open modal-open');
            
            // Remove all possible backdrop elements
            const backdropSelectors = [
                '.vrstore-modal-backdrop',
                '.modal-backdrop', 
                '.vrstore-modal-overlay',
                '.modal-overlay',
                '.backdrop',
                '.overlay',
                '[class*="backdrop"]',
                '[class*="overlay"]',
                '[data-backdrop]'
            ];
            
            backdropSelectors.forEach(function(selector) {
                $(selector).each(function() {
                    const $element = $(this);
                    const zIndex = parseInt($element.css('z-index')) || 0;
                    const hasBackdropClass = $element.attr('class') && 
                        ($element.attr('class').includes('backdrop') || 
                         $element.attr('class').includes('overlay') ||
                         $element.attr('class').includes('modal'));
                    
                    if (hasBackdropClass || zIndex > 999) {
                        $element.remove();
                    }
                });
            });
            
            // Reset body styles
            const bodyResetStyles = {
                'overflow': '',
                'overflow-x': '',
                'overflow-y': '',
                'position': '',
                'width': '',
                'height': '',
                'padding-right': '',
                'margin-right': ''
            };
            
            $('body').css(bodyResetStyles);
            $('html, body').removeClass('vrstore-modal-open modal-open modal-backdrop-open');
            
            // Additional cleanup attempt after delay
            setTimeout(function() {
                backdropSelectors.forEach(function(selector) {
                    $(selector).remove();
                });
                $('body').removeClass('vrstore-modal-open modal-open').css(bodyResetStyles);
            }, 100);
        }

        // Show notification function
        function showNotification(message, type) {
            var className = 'vrstore-alert vrstore-alert-' + (type || 'info');
            var $notification = $('<div class="' + className + '" style="position: fixed; top: 20px; right: 20px; z-index: 100002; max-width: 400px; animation: slideInRight 0.3s ease-out;">' +
                '<span class="dashicons dashicons-' + (type === 'success' ? 'yes-alt' : type === 'danger' ? 'warning' : 'info') + '"></span>' +
                '<span>' + message + '</span>' +
                '<button class="vrstore-notification-close" style="float: right; background: none; border: none; cursor: pointer; color: inherit; opacity: 0.7;">&times;</button>' +
            '</div>');
            
            $('body').append($notification);
            
            // Auto-hide after 5 seconds
            setTimeout(function() {
                $notification.fadeOut(300, function() { $(this).remove(); });
            }, 5000);
            
            // Manual close
            $notification.find('.vrstore-notification-close').on('click', function() {
                $notification.fadeOut(300, function() { $(this).remove(); });
            });
        }

        // Extended Support button click
        $(document).on('click', '#vrstore-extended-support-btn', function(e){
            e.preventDefault();
            
            // Prevent multiple simultaneous requests
            if ($('#vrstore-extended-support-loading').is(':visible')) {
                return;
            }
            
            // Clear any previous state and reset modal
            const $modal = $('#vrstore-extended-support-modal');
            $modal.find('.vrstore-modal-content').show(); // Ensure content is visible
            $modal.removeClass('vrstore-modal-visible').show(); // Reset modal state
            
            openModal('#vrstore-extended-support-modal');
            loadExtendedSupportPricing();
        });

        // Duplicate modal close handler removed - consolidated above

        // Load Extended Support pricing based on customer's license types
        function loadExtendedSupportPricing() {
            // Prevent multiple simultaneous requests
            if (isLoadingPricing) {
                return;
            }
            
            isLoadingPricing = true;
            
            // Clear any existing content first to prevent duplication
            $('#vrstore-extended-support-content').empty().hide();
            $('#vrstore-extended-support-loading').show();
            $('#vrstore-purchase-extended-support').hide();
            
            // Clear any previous checkbox states or quantity values
            $('.vrstore-support-item-checkbox').prop('checked', false);
            $('.vrstore-quantity-input').val(1);
            var $pricingContainer = $('.vrstore-extended-support-pricing');
            var zeroFormatted = '0.00';
            if ($pricingContainer.length) {
                var currentCurrency = $pricingContainer.data('current-currency') || 'USD';
                var symbol = $pricingContainer.data('currency') || '$';
                zeroFormatted = formatPrice(0);
            }
            $('#vrstore-extended-support-total').text(zeroFormatted);
            
            // Remove any existing total wrappers to prevent duplication
            $('#vrstore-extended-support-footer .vrstore-extended-support-total-wrapper').remove();

            // Get nonce with multiple fallbacks for extended support
            var extendedSupportNonce = nonce || 
                                     (typeof vrstore_frontend !== 'undefined' ? vrstore_frontend.nonce : '') ||
                                     $('#vrstore-nonce').val() ||
                                     $('meta[name="vrstore-nonce"]').attr('content') ||
                                     '';
            
            $.post(ajaxUrl, {
                action: 'vrstore_get_extended_support_pricing',
                nonce: extendedSupportNonce
            })
            .done(function(response) {
                $('#vrstore-extended-support-loading').hide();
                if (response && response.success) {
                    $('#vrstore-extended-support-content').html(response.data.html).show();
                    // Remove any existing total wrapper before adding a new one
                    $('#vrstore-extended-support-footer .vrstore-extended-support-total-wrapper').remove();
                    // Add the total HTML to the footer only if it doesn't already exist
                    if ($('#vrstore-extended-support-footer .vrstore-extended-support-total-wrapper').length === 0) {
                        $('#vrstore-extended-support-footer').prepend(response.data.total_html);
                    }
                    $('#vrstore-purchase-extended-support').show();
                    initQuantityControls();
                } else {
                    var errorMsg = 'Failed to load pricing information.';
                    if (response && response.data) {
                        errorMsg = typeof response.data === 'string' ? response.data : (response.data.message || errorMsg);
                    }
                    $('#vrstore-extended-support-content').html('<div class="vrstore-error">' + errorMsg + '</div>').show();
                }
            })
            .fail(function() {
                $('#vrstore-extended-support-loading').hide();
                $('#vrstore-extended-support-content').html('<div class="vrstore-error">Failed to load pricing information. Please try again.</div>').show();
            })
            .always(function() {
                // Reset loading flag
                isLoadingPricing = false;
            });
        }

        // Initialize quantity controls and selection functionality
        function initQuantityControls() {
            // Handle checkbox selection
            $(document).on('change', '.vrstore-support-item-checkbox', function() {
                var $checkbox = $(this);
                var $item = $checkbox.closest('.vrstore-extended-support-item');
                var $controls = $item.find('.vrstore-quantity-controls');
                var $input = $item.find('.vrstore-quantity-input');
                
                if ($checkbox.is(':checked')) {
                    // Enable quantity controls
                    $controls.css({'opacity': '1', 'pointer-events': 'auto'});
                    $input.prop('disabled', false);
                } else {
                    // Disable quantity controls and reset to 1
                    $controls.css({'opacity': '0.5', 'pointer-events': 'none'});
                    $input.prop('disabled', true).val(1);
                }
                updateExtendedSupportTotal();
            });
            
            $(document).on('click', '.vrstore-quantity-btn', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var $input = $btn.siblings('.vrstore-quantity-input');
                var currentVal = parseInt($input.val()) || 1;
                var min = parseInt($input.attr('min')) || 1;
                var max = parseInt($input.attr('max')) || 999;
                
                if ($btn.hasClass('vrstore-quantity-minus')) {
                    if (currentVal > min) {
                        $input.val(currentVal - 1).trigger('change');
                    }
                } else if ($btn.hasClass('vrstore-quantity-plus')) {
                    if (currentVal < max) {
                        $input.val(currentVal + 1).trigger('change');
                    }
                }
            });

            // Update total price when quantity changes
            $(document).on('change input', '.vrstore-quantity-input', function() {
                updateExtendedSupportTotal();
            });
        }

        // Update total price calculation
        function updateExtendedSupportTotal() {
            var total = 0;
            $('.vrstore-extended-support-item').each(function() {
                var $item = $(this);
                var $checkbox = $item.find('.vrstore-support-item-checkbox');
                var price = parseFloat($item.data('price')) || 0;
                var quantity = parseInt($item.find('.vrstore-quantity-input').val()) || 0;
                
                if ($checkbox.is(':checked')) {
                    var itemTotal = price * quantity;
                    $item.find('.vrstore-item-total').text(formatPrice(itemTotal));
                    total += itemTotal;
                } else {
                    $item.find('.vrstore-item-total').text(formatPrice(0));
                }
            });
            $('#vrstore-extended-support-total').text(formatPrice(total));
        }

        // Convert amount if needed based on currency settings
        // NOTE: Extended Support prices are already converted by PHP backend
        // This function is kept for compatibility but should NOT convert Extended Support prices
        function convertAmountIfNeeded(amount) {
            // Check if currency conversion is enabled
            if (typeof vrstore_frontend !== 'undefined' && vrstore_frontend.enable_currency_conversion !== 'yes') {
                return amount; // Return original amount if conversion is disabled
            }
            
            // Check if this is Extended Support pricing (already converted by backend)
            const $pricingContainer = $('.vrstore-extended-support-pricing');
            if ($pricingContainer.length && $pricingContainer.data('converted')) {
                // Extended Support prices are already converted by PHP, return as-is
                return amount;
            }
            
            // For other components, apply conversion if needed
            const baseCurrency = (typeof vrstore_frontend !== 'undefined' && vrstore_frontend.currency) || 'USD';
            const currentCurrency = (typeof vrstore_frontend !== 'undefined' && vrstore_frontend.current_currency) || baseCurrency;
            
            if (baseCurrency !== currentCurrency) {
                const exchangeRate = parseFloat(vrstore_frontend.usd_to_idr_rate) || 16000;
                
                if (baseCurrency === 'USD' && currentCurrency === 'IDR') {
                    return amount * exchangeRate;
                } else if (baseCurrency === 'IDR' && currentCurrency === 'USD') {
                    return amount / exchangeRate;
                }
            }
            return amount;
        }

        // Format price with currency symbol - use consistent formatting with main system
        function formatPrice(amount) {
            // Get currency settings from Extended Support container or fallback to main system
            const $pricingContainer = $('.vrstore-extended-support-pricing');
            let currentCurrency;
            
            if ($pricingContainer.length) {
                currentCurrency = $pricingContainer.data('current-currency') || 'USD';
            } else {
                currentCurrency = (typeof vrstore_frontend !== 'undefined' && vrstore_frontend.current_currency) || 'USD';
            }
            
            // Use the main formatPriceWithCurrency function for consistency
            return formatPriceWithCurrency(amount, currentCurrency);
        }

        // Purchase Extended Support
        $(document).on('click', '#vrstore-purchase-extended-support', function(e) {
            e.preventDefault();
            var $btn = $(this);
            
            // Collect selected items
            var items = [];
            $('.vrstore-extended-support-item').each(function() {
                var $item = $(this);
                var $checkbox = $item.find('.vrstore-support-item-checkbox');
                var quantity = parseInt($item.find('.vrstore-quantity-input').val()) || 0;
                
                if ($checkbox.is(':checked') && quantity > 0) {
                    items.push({
                        license_id: $item.data('license-id'),
                        license_type: $item.data('license-type'),
                        months: quantity,
                        price: parseFloat($item.data('price')) || 0
                    });
                }
            });

            if (items.length === 0) {
                showNotification('Please select at least one license for extended support.', 'warning');
                return;
            }

            // Show loading state
            $btn.find('.vrstore-button-text').hide();
            $btn.find('.vrstore-button-spinner').show();
            $btn.prop('disabled', true);

            // Get nonce with multiple fallbacks for purchase
            var purchaseNonce = nonce || 
                               (typeof vrstore_frontend !== 'undefined' ? vrstore_frontend.nonce : '') ||
                               $('#vrstore-nonce').val() ||
                               $('meta[name="vrstore-nonce"]').attr('content') ||
                               '';
            
            $.post(ajaxUrl, {
                action: 'vrstore_purchase_extended_support',
                nonce: purchaseNonce,
                items: items
            })
            .done(function(response) {
                if (response && response.success) {
                    showNotification('Extended support purchase initiated successfully!', 'success');
                    closeModal('#vrstore-extended-support-modal');
                    // Redirect to payment if needed
                    if (response.data.redirect_url) {
                        window.location.href = response.data.redirect_url;
                    }
                } else {
                    var errorMsg = 'Failed to process extended support purchase.';
                    if (response && response.data) {
                        errorMsg = typeof response.data === 'string' ? response.data : (response.data.message || errorMsg);
                    }
                    showNotification(errorMsg, 'error');
                }
            })
            .fail(function() {
                showNotification('Failed to process extended support purchase. Please try again.', 'error');
            })
            .always(function() {
                // Reset button state
                $btn.find('.vrstore-button-text').show();
                $btn.find('.vrstore-button-spinner').hide();
                $btn.prop('disabled', false);
            });
        });
    }

    // Initialize Extended Support when document is ready
    $(document).ready(function() {
        initExtendedSupport();
    });

    /**
     * Currency switcher functionality
     */
    function initCurrencySwitcher() {
        // Handle currency switcher dropdown changes
        $(document).on('change', '#vrstore-currency-select', function() {
            const selectedCurrency = $(this).val();
            if (selectedCurrency) {
                switchCurrency(selectedCurrency);
            }
        });
        
        // Handle currency button clicks
        $(document).on('click', '.vrstore-currency-switcher .currency-button', function(e) {
            e.preventDefault();
            const currency = $(this).data('currency');
            if (currency) {
                switchCurrency(currency);
            }
        });
        
        // Alternative event handler for dropdowns within currency switcher containers
        $(document).on('change', '.vrstore-currency-switcher select', function() {
            const selectedCurrency = $(this).val();
            if (selectedCurrency) {
                switchCurrency(selectedCurrency);
            }
        });
    }
    
    /**
     * Switch currency and update prices via AJAX
     */
    function switchCurrency(currency) {
        // Check if currency conversion is enabled
        if (typeof vrstore_frontend === 'undefined' || vrstore_frontend.enable_currency_conversion !== 'yes') {
            return;
        }
        
        // Show loading indicator
        showCurrencyLoadingState(true);
        
        $.ajax({
            url: vrstore_frontend.ajax_url,
            type: 'POST',
            data: {
                action: 'vrstore_switch_currency',
                currency: currency,
                nonce: vrstore_frontend.nonce
            },
            success: function(response) {
                if (response.success) {
                    // Update currency in frontend data
                    vrstore_frontend.current_currency = currency;
                    vrstore_frontend.current_currency_symbol = response.data.symbol;
                    
                    // Update all prices on the page
                    updatePagePrices(response.data.rates);
                    
                    // Update currency selectors
                    updateCurrencySelectors(currency);
                    
                    // Trigger custom event so components (e.g., single product price) can re-render with new symbol
                    if (typeof jQuery !== 'undefined') {
                        jQuery(document).trigger('vrstore_currency_switched', [currency, response.data.symbol]);
                    }
                } else {
                    console.error('Currency switch failed:', response.data);
                }
            },
            error: function() {
                console.error('Currency switch request failed');
            },
            complete: function() {
                showCurrencyLoadingState(false);
            }
        });
    }
    
    /**
     * Format price with currency symbol for specific currency
     */
    function formatPriceWithCurrency(amount, currency) {
        // Get currency settings
        const position = (typeof vrstore_frontend !== 'undefined' && vrstore_frontend.currency_position) || 'left';
        const decimals = (currency === 'IDR') ? 0 : (typeof vrstore_frontend !== 'undefined' && parseInt(vrstore_frontend.decimal_number)) || 2;
        const decimalSeparator = (typeof vrstore_frontend !== 'undefined' && vrstore_frontend.decimal_separator) || '.';
        const thousandSeparator = (typeof vrstore_frontend !== 'undefined' && vrstore_frontend.thousand_separator) || ',';
        
        // Get currency symbol
        let symbol = '$';
        if (currency === 'IDR') {
            symbol = 'Rp';
        } else if (currency === 'USD') {
            symbol = '$';
        } else if (typeof vrstore_frontend !== 'undefined' && vrstore_frontend.current_currency_symbol) {
            symbol = vrstore_frontend.current_currency_symbol;
        }
        
        // Format the number
        const formattedAmount = parseFloat(amount).toLocaleString('en-US', {
            minimumFractionDigits: decimals,
            maximumFractionDigits: decimals,
            useGrouping: true
        }).replace(/,/g, thousandSeparator).replace(/\./g, decimalSeparator);
        
        // Apply currency position
        switch (position) {
            case 'right':
                return formattedAmount + symbol;
            case 'left_space':
                return symbol + ' ' + formattedAmount;
            case 'right_space':
                return formattedAmount + ' ' + symbol;
            case 'left':
            default:
                return symbol + formattedAmount;
        }
    }
    
    /**
     * Update all prices on the page with new currency rates
     */
    function updatePagePrices(rates) {
        // Update product prices
        $('.vrstore-price').each(function() {
            const $price = $(this);
            const baseAmount = parseFloat($price.data('base-amount')) || 0;
            const baseCurrency = $price.data('base-currency') || 'USD';
            const targetCurrency = vrstore_frontend.current_currency;
            const isAlreadyConverted = $price.data('converted') === true || $price.data('converted') === 'true';
            
            if (baseAmount > 0 && rates[targetCurrency]) {
                let convertedAmount;
                if (isAlreadyConverted && baseCurrency === targetCurrency) {
                    // Price is already in target currency, no conversion needed
                    convertedAmount = baseAmount;
                } else if (isAlreadyConverted && rates[targetCurrency] && rates[baseCurrency]) {
                    // Convert from current currency to target currency
                    convertedAmount = (baseAmount / rates[baseCurrency]) * rates[targetCurrency];
                } else {
                    // Standard conversion from base currency
                    convertedAmount = baseAmount * rates[targetCurrency];
                }
                const formattedPrice = formatPriceWithCurrency(convertedAmount, targetCurrency);
                $price.html(formattedPrice);
            }
        });
        
        // Update cart totals
        $('.vrstore-cart-total').each(function() {
            const $total = $(this);
            const baseAmount = parseFloat($total.data('base-amount')) || 0;
            
            if (baseAmount > 0 && rates[vrstore_frontend.current_currency]) {
                const convertedAmount = baseAmount * rates[vrstore_frontend.current_currency];
                const formattedPrice = formatPriceWithCurrency(convertedAmount, vrstore_frontend.current_currency);
                $total.html(formattedPrice);
            }
        });
    }
    
    /**
     * Update currency selector elements
     */
    function updateCurrencySelectors(currency) {
        $('#vrstore-currency-select').val(currency);
        $('.vrstore-currency-switcher select').val(currency);
        $('.vrstore-currency-switcher .currency-button').removeClass('active');
        $('.vrstore-currency-switcher .currency-button[data-currency="' + currency + '"]').addClass('active');
    }
    
    /**
     * Show/hide currency loading state
     */
    function showCurrencyLoadingState(show) {
        if (show) {
            $('.vrstore-currency-switcher').addClass('loading');
            $('.vrstore-price').addClass('updating');
        } else {
            $('.vrstore-currency-switcher').removeClass('loading');
            $('.vrstore-price').removeClass('updating');
        }
    }
    
    // Add currency switcher to document ready initialization
    // (will be initialized in the main document ready function)
    
    /**
     * Support Ticket Handlers - Clean integration without conflicts
     */
    function initSupportTicketHandlers() {
        // Prevent multiple initializations with stronger checks
        if (window.vrstoreTicketHandlersInitialized) {
            return;
        }
        window.vrstoreTicketHandlersInitialized = true;
        
        // Remove any existing handlers first to prevent duplicates
        $(document).off('submit', '#vrstore-create-ticket-form');
        
        // Create ticket form handler (enhanced to work with unified modal system)
        $(document).on('submit', '#vrstore-create-ticket-form', function(e) {
            e.preventDefault();
            e.stopPropagation();
            e.stopImmediatePropagation();
            
            const $form = $(this);
            const $submitBtn = $('#vrstore-submit-ticket-btn');
            const $buttonText = $submitBtn.find('.vrstore-button-text');
            const $buttonSpinner = $submitBtn.find('.vrstore-button-spinner');
            const originalText = $buttonText.text();
            
            // Strong duplicate submission prevention with timestamp
            const now = Date.now();
            const lastSubmit = $form.data('last-submit') || 0;
            
                if ($form.hasClass('submitting') || $submitBtn.prop('disabled') || $form.data('submitting') || (now - lastSubmit < 3000)) {
                    return false;
                }
            
            // Mark form as submitting with multiple indicators
            $form.addClass('submitting').data('submitting', true).data('last-submit', now);
            
            // Get form data with nonce fallback
            const supportTicketNonce = (typeof vrstore_frontend !== 'undefined' && vrstore_frontend.nonce) ||
                                      $('#vrstore-nonce').val() ||
                                      $('meta[name="vrstore-nonce"]').attr('content') ||
                                      nonce || '';
            
            const formData = {
                action: 'vrstore_create_support_ticket',
                subject: $('#vrstore-ticket-subject').val(),
                message: $('#vrstore-ticket-message').val(),
                product_id: $('#vrstore-ticket-product').val(),
                priority: $('#vrstore-ticket-priority').val(),
                nonce: supportTicketNonce
            };
            
            // Validate required fields
            if (!formData.subject || !formData.message) {
                showNotification('Please fill in all required fields.', 'error');
                return;
            }
            
            // Show loading state
            $submitBtn.prop('disabled', true);
            $buttonText.hide();
            $buttonSpinner.show();
            
            // Submit via AJAX
            $.ajax({
                url: vrstore_frontend.ajax_url,
                type: 'POST',
                data: formData,
                timeout: 30000,
                success: function(response) {
                    if (response.success) {
                        showNotification(
                            '✅ ' + (response.data.message || 'Support ticket created successfully!'),
                            'success'
                        );
                        
                        // Clear form
                        $form[0].reset();
                        
                        // Close modal using unified system
                        if (window.ViraStore && window.ViraStore.UnifiedModalSystem) {
                            window.ViraStore.UnifiedModalSystem.hideModal($('#vrstore-create-ticket-modal'));
                        } else {
                            $('#vrstore-create-ticket-modal').fadeOut();
                        }
                        
                        // Refresh support tab if on account page
                        if ($('#support').length) {
                            setTimeout(() => location.reload(), 1000);
                        }
                        
                    } else {
                        showNotification(
                            '❌ ' + (response.data?.message || 'Failed to create ticket. Please try again.'),
                            'error'
                        );
                    }
                },
                error: function(xhr, status, error) {
                    let errorMessage = 'Network error occurred. Please try again.';
                    if (status === 'timeout') {
                        errorMessage = 'Request timed out. Please try again.';
                    } else if (xhr.status === 403) {
                        errorMessage = 'Permission denied. Please refresh the page and try again.';
                    }
                    showNotification('❌ ' + errorMessage, 'error');
                },
                complete: function() {
                    // Restore button state
                    $submitBtn.prop('disabled', false);
                    $buttonText.show();
                    $buttonSpinner.hide();
                    
                    // Remove submitting indicators to allow future submissions
                    $form.removeClass('submitting').removeData('submitting');
                }
            });
        });
        
        // Customer reply form handler
        $(document).on('submit', '#vrstore-customer-reply-form', function(e) {
            e.preventDefault();
            
            const $form = $(this);
            const $submitBtn = $form.find('button[type="submit"]');
            const originalText = $submitBtn.text();
            const ticketId = $form.data('ticket-id');
            const message = $form.find('#vrstore-customer-reply-message').val();
            
            if (!message.trim()) {
                showNotification('Please enter a reply message.', 'error');
                return;
            }
            
            // Show loading state
            $submitBtn.prop('disabled', true).text('Sending Reply...');
            
            // Get nonce with fallback mechanism
            const replyNonce = (typeof vrstore_frontend !== 'undefined' && vrstore_frontend.nonce) ||
                              $('#vrstore-nonce').val() ||
                              $('meta[name="vrstore-nonce"]').attr('content') ||
                              nonce || '';
            
            $.ajax({
                url: vrstore_frontend.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrstore_add_customer_ticket_reply',
                    ticket_id: ticketId,
                    message: message,
                    nonce: replyNonce
                },
                success: function(response) {
                    if (response.success) {
                        showNotification(
                            '✅ ' + (response.data.message || 'Reply sent successfully!'),
                            'success'
                        );
                        
                        // Clear the message field
                        $form.find('#vrstore-customer-reply-message').val('');
                        
                        // Optionally reload ticket details to show new reply
                        setTimeout(() => {
                            if (typeof showTicketDetail === 'function') {
                                showTicketDetail(ticketId);
                            }
                        }, 1000);
                        
                    } else {
                        showNotification(
                            '❌ ' + (response.data?.message || 'Failed to send reply.'),
                            'error'
                        );
                    }
                },
                error: function() {
                    showNotification('❌ Network error occurred. Please try again.', 'error');
                },
                complete: function() {
                    $submitBtn.prop('disabled', false).text(originalText);
                }
            });
        });
    }

    /**
     * Initialize automatic nonce refresh to prevent security check failures
     */
    function initNonceRefresh() {
        // Refresh nonce every 20 hours (before 24-hour WordPress expiry)
        const refreshInterval = 20 * 60 * 60 * 1000; // 20 hours in milliseconds
        
        // Set up automatic refresh
        setInterval(function() {
            refreshNonce();
        }, refreshInterval);
        
        // Also refresh on page visibility change (when user returns to tab)
        if (typeof document.visibilityState !== 'undefined') {
            document.addEventListener('visibilitychange', function() {
                if (!document.hidden) {
                    // Check if nonce is older than 20 hours
                    const nonceAge = Date.now() - (window.vrstore_nonce_timestamp || 0);
                    if (nonceAge > refreshInterval) {
                        refreshNonce();
                    }
                }
            });
        }
        
        // Store initial nonce timestamp
        window.vrstore_nonce_timestamp = Date.now();
    }

    /**
     * Refresh the nonce via AJAX
     */
    function refreshNonce() {
        if (typeof vrstore_frontend === 'undefined' || !vrstore_frontend.ajax_url) {
            return;
        }
        
        $.ajax({
            url: vrstore_frontend.ajax_url,
            type: 'POST',
            data: {
                action: 'vrstore_refresh_nonce',
                nonce: vrstore_frontend.nonce
            },
            success: function(response) {
                if (response.success && response.data.nonce) {
                    // Update the global nonce
                    vrstore_frontend.nonce = response.data.nonce;
                    
                    // Update timestamp
                    window.vrstore_nonce_timestamp = Date.now();
                    
                    // Update any hidden nonce fields on the page
                    $('input[name="vrstore_nonce"], input[name="nonce"]').val(response.data.nonce);
                    
                    // Update meta tag if exists
                    $('meta[name="vrstore-nonce"]').attr('content', response.data.nonce);
                } else {
                    console.warn('ViraStore: Failed to refresh nonce', response);
                }
            },
            error: function(xhr, status, error) {
                console.warn('ViraStore: Nonce refresh error:', error);
            }
        });
    }

    /**
     * Initialize Edit Profile form handling
     */
    function initEditProfileForm() {
        // Handle Edit Profile form submission
        $(document).on('submit', '#vrstore-edit-profile-form', function(e) {
            e.preventDefault();
            
            const $form = $(this);
            const $submitBtn = $('#vrstore-save-profile-btn');
            const $buttonText = $submitBtn.find('.vrstore-button-text');
            const $buttonSpinner = $submitBtn.find('.vrstore-button-spinner');
            
            // Prevent double submission
            if ($submitBtn.prop('disabled') || $form.hasClass('submitting')) {
                return false;
            }
            
            // Basic validation
            const displayName = $form.find('input[name="display_name"]').val().trim();
            const email = $form.find('input[name="user_email"]').val().trim();
            
            if (!displayName) {
                showNotification('❌ Display name is required.', 'error');
                return false;
            }
            
            if (!email) {
                showNotification('❌ Email address is required.', 'error');
                return false;
            }
            
            // Email validation
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(email)) {
                showNotification('❌ Please enter a valid email address.', 'error');
                return false;
            }
            
            // Show loading state
            $form.addClass('submitting');
            $submitBtn.prop('disabled', true);
            $buttonText.hide();
            $buttonSpinner.show();
            
            // Prepare form data
            const formData = new FormData($form[0]);
            
            $.ajax({
                url: vrstore_frontend.ajax_url,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                timeout: 30000,
                success: function(response) {
                    if (response.success) {
                        showNotification('✅ ' + (response.data.message || 'Profile updated successfully!'), 'success');
                        
                        // Close the modal after successful update
                        setTimeout(function() {
                            $('#vrstore-edit-profile-modal').hide();
                            $('.vrstore-modal-overlay').hide();
                        }, 1500);
                        
                        // Optionally reload the page to show updated data
                        setTimeout(function() {
                            window.location.reload();
                        }, 2000);
                        
                    } else {
                        const errorMsg = response.data && response.data.message ? response.data.message : 'Failed to update profile. Please try again.';
                        showNotification('❌ ' + errorMsg, 'error');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Profile update error:', xhr, status, error);
                    let errorMessage = 'Network error occurred. Please try again.';
                    
                    if (status === 'timeout') {
                        errorMessage = 'Request timed out. Please try again.';
                    } else if (xhr.status === 403) {
                        errorMessage = 'Permission denied. Please refresh the page and try again.';
                    } else if (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
                        errorMessage = xhr.responseJSON.data.message;
                    }
                    
                    showNotification('❌ ' + errorMessage, 'error');
                },
                complete: function() {
                    // Restore button state
                    $form.removeClass('submitting');
                    $submitBtn.prop('disabled', false);
                    $buttonText.show();
                    $buttonSpinner.hide();
                }
            });
        });
        
        // Handle Edit Profile modal open button
        $(document).on('click', '#vrstore-edit-profile-btn, .vrstore-edit-profile-link', function(e) {
            e.preventDefault();
            $('#vrstore-edit-profile-modal').show();
        });
        
        // Handle modal close
        $(document).on('click', '#vrstore-edit-profile-modal .vrstore-modal-close, #vrstore-edit-profile-modal .vrstore-modal-overlay', function(e) {
            if (e.target === this) {
                $('#vrstore-edit-profile-modal').hide();
            }
        });
    }

    // Initialize all modules when document is ready
    $(document).ready(function() {
        // Initialize core functionality
        if (typeof initProductPage === 'function') initProductPage();
        if (typeof initProductModals === 'function') initProductModals();
        if (typeof initProductPricing === 'function') initProductPricing();
        if (typeof initScreenshotLightbox === 'function') initScreenshotLightbox();
        
        // Initialize auth and profile functionality
        if (typeof initAuthInterface === 'function') initAuthInterface();
        if (typeof initRegistrationForm === 'function') initRegistrationForm();
        if (typeof initEditProfileForm === 'function') initEditProfileForm();
        
        // Initialize e-commerce functionality
        if (typeof initAddToCart === 'function') initAddToCart();
        if (typeof initCartFunctionality === 'function') initCartFunctionality();
        if (typeof initBuyButton === 'function') initBuyButton();
        if (typeof initCurrencySwitcher === 'function') initCurrencySwitcher();
        
        // Initialize checkout related functionality
        if (typeof initCheckoutPage === 'function') initCheckoutPage();
        if (typeof initCheckoutValidation === 'function') initCheckoutValidation();
        if (typeof initPaymentMethodSelection === 'function') initPaymentMethodSelection();
        
        // Initialize license handling
        if (typeof initLicenseActivation === 'function') initLicenseActivation();
        if (typeof initLicenseCopyFeature === 'function') initLicenseCopyFeature();
        
        // Initialize support functionality
        if (typeof initSupportTickets === 'function') initSupportTickets();
        if (typeof initSupportTicketHandlers === 'function') initSupportTicketHandlers();
        if (typeof initExtendedSupport === 'function') initExtendedSupport();
        
        // Initialize utility functionality
        if (typeof initCopyButtons === 'function') initCopyButtons();
        if (typeof initNonceRefresh === 'function') initNonceRefresh();
        if (typeof initDomainTimestampRefresh === 'function') initDomainTimestampRefresh();
        
        // Fix for n-1 dropdown bug - ensures all options are visible
        $('#vrstore-license-type option, .vrstore-buy-button-license-dropdown option').each(function() {
            $(this).show().css({
                'display': '',
                'visibility': 'visible',
                'opacity': '1'
            });
        });
        
        // Ensure proper initialization with proper timing
        setTimeout(function() {
            $('#vrstore-license-type, .vrstore-buy-button-license-dropdown').each(function() {
                const $select = $(this);
                const optionCount = $select.find('option').length;
                const dropdownType = $select.attr('id') === 'vrstore-license-type' ? 'Product Shortcode' : 'Buy Button';
                
                // Skip automatic change event trigger for single product pages to prevent price reversion
                // Only trigger for buy-button dropdowns which might need initialization
                if (optionCount > 0 && !$select.is('#vrstore-license-type')) {
                    $select.trigger('change');
                }
            });
        }, 100);
    });

})(jQuery);
