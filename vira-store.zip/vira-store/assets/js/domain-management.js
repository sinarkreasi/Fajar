/**
 * Domain Management Frontend JavaScript
 * 
 * Handles interactive domain activation/deactivation functionality
 * for the Vira Store customer portal area.
 * 
 * @package Vira_Store
 * @since   1.0.0
 */

(function($) {
    'use strict';

    // Domain management object
    const VRStoreDomainManager = {
        
        // Configuration
        config: {
            selectors: {
                // Unified selectors for new approach
                addDomainBtn: '.vrstore-add-domain-unified',
                refreshDomainsBtn: '.vrstore-refresh-domains-unified', 
                deactivateDomainBtn: '.vrstore-deactivate-domain-unified',
                addDomainModal: '#vrstore-add-domain-unified-modal',
                deactivateModal: '#vrstore-deactivate-domain-unified-modal',
                addDomainForm: '#vrstore-add-domain-unified-form',
                domainInput: '#vrstore-domain-unified-input',
                domainsList: '#vrstore-domains-list-unified',
                activationLimitWarning: '#vrstore-activation-limit-unified-warning',
                
                // Legacy selectors for backward compatibility
                addDomainBtnLegacy: '.vrstore-add-domain',
                refreshDomainsBtnLegacy: '.vrstore-refresh-domains',
                deactivateDomainBtnLegacy: '.vrstore-deactivate-domain',
                manageLicenseBtn: '.vrstore-manage-license',
                addDomainModalLegacy: '#vrstore-add-domain-modal',
                deactivateModalLegacy: '#vrstore-deactivate-domain-modal',
                addDomainFormLegacy: '#vrstore-add-domain-form',
                domainInputLegacy: '#vrstore-domain-input',
                domainsListLegacy: '#vrstore-domains-list',
                activationLimitWarningLegacy: '#vrstore-activation-limit-warning',
                
                // Common selectors
                messagesContainer: '#vrstore-domain-messages',
                modalClose: '.vrstore-modal-close, .vrstore-modal-cancel',
                modalOverlay: '.vrstore-modal-overlay',
                progressFill: '.vrstore-progress-fill',
                progressText: '.vrstore-progress-text',
                tabsNav: '.vrstore-tabs-nav a',
                licensesTab: '#licenses',
                domainManagement: '.vrstore-domain-management, .vrstore-domain-management-section',
                domainActions: '.vrstore-domain-actions',
                domainHeader: '.vrstore-domain-header'
            },
            ajax: {
                url: vrstore_ajax?.ajax_url || ajaxurl,
                nonce: vrstore_ajax?.nonce || ''
            },
            customerId: vrstore_ajax?.customer_id || '',
            messages: {
                domainRequired: vrstore_domain_strings?.domain_required || 'Please enter a domain name.',
                domainInvalid: vrstore_domain_strings?.domain_invalid || 'Please enter a valid domain name.',
                activationSuccess: vrstore_domain_strings?.activation_success || 'Domain activated successfully!',
                deactivationSuccess: vrstore_domain_strings?.deactivation_success || 'Domain deactivated successfully!',
                activationError: vrstore_domain_strings?.activation_error || 'Failed to activate domain. Please try again.',
                deactivationError: vrstore_domain_strings?.deactivation_error || 'Failed to deactivate domain. Please try again.',
                refreshError: vrstore_domain_strings?.refresh_error || 'Failed to refresh domains. Please try again.',
                limitReached: vrstore_domain_strings?.limit_reached || 'Activation limit reached. Please deactivate a domain first.',
                processing: vrstore_domain_strings?.processing || 'Processing...',
                networkError: vrstore_domain_strings?.network_error || 'Network error. Please check your connection and try again.'
            }
        },

        // Current modal data
        currentModal: null,
        currentLicenseData: {},

        /**
         * Initialize the domain manager
         */
        init: function() {
            this.cleanUpRefreshParam();
            this.bindEvents();
            this.setupModalBackdropClose();
            this.handleInitialPageLoad();
        },

        /**
         * Clean up _refresh parameter from URL on page load
         */
        cleanUpRefreshParam: function() {
            const currentUrl = new URL(window.location.href);
            if (currentUrl.searchParams.has('_refresh')) {
                currentUrl.searchParams.delete('_refresh');
                // Use replaceState to update URL without page reload or adding to history
                window.history.replaceState(null, '', currentUrl.toString());
            }
        },

        /**
         * Handle initial page load for license management
         */
        handleInitialPageLoad: function() {
            const urlParams = new URLSearchParams(window.location.search);
            const licenseId = urlParams.get('license_id');
            
            if (licenseId) {
                this.activateLicensesTab();
                this.ensureDomainButtonsVisible();
            }
        },

        /**
         * Bind all event handlers
         */
        bindEvents: function() {
            const self = this;

            // Manage license button
            $(document).on('click', this.config.selectors.manageLicenseBtn, function(e) {
                const $button = $(this);
                const href = $button.attr('href');
                
                // Always prevent default and handle manually for consistency
                e.preventDefault();
                
                if (href && href.includes('license_id=')) {
                    // Navigate to the href
                    window.location.href = href + '#licenses';
                } else {
                    // Fallback: use data attributes
                    const licenseId = $button.data('license-id');
                    if (licenseId) {
                        const currentUrl = window.location.href.split('?')[0].split('#')[0];
                        const newUrl = currentUrl + '?license_id=' + encodeURIComponent(licenseId) + '#licenses';
                        window.location.href = newUrl;
                    }
                }
            });

            // Add domain button (unified and legacy)
            $(document).on('click', this.config.selectors.addDomainBtn + ', ' + this.config.selectors.addDomainBtnLegacy, function(e) {
                e.preventDefault();
                self.openAddDomainModal($(this));
            });

            // Refresh domains button (unified and legacy)
            $(document).on('click', this.config.selectors.refreshDomainsBtn + ', ' + this.config.selectors.refreshDomainsBtnLegacy, function(e) {
                e.preventDefault();
                self.refreshDomains($(this));
            });

            // Deactivate domain button (unified and legacy)
            $(document).on('click', this.config.selectors.deactivateDomainBtn + ', ' + this.config.selectors.deactivateDomainBtnLegacy, function(e) {
                e.preventDefault();
                self.openDeactivateModal($(this));
            });

            // Add domain form submission (unified and legacy)
            $(document).on('submit', this.config.selectors.addDomainForm + ', ' + this.config.selectors.addDomainFormLegacy, function(e) {
                e.preventDefault();
                self.submitAddDomain();
            });

            // Confirm deactivation (unified and legacy)
            $(document).on('click', '.vrstore-confirm-deactivate-unified, .vrstore-confirm-deactivate', function(e) {
                e.preventDefault();
                self.confirmDeactivation();
            });

            // Close modals
            $(document).on('click', this.config.selectors.modalClose, function(e) {
                e.preventDefault();
                self.closeModals();
            });

            // Domain input validation
            $(document).on('input', this.config.selectors.domainInput, function() {
                self.validateDomainInput($(this));
            });

            // Copy license key functionality (if exists)
            $(document).on('click', '.vrstore-copy-license-key', function(e) {
                e.preventDefault();
                self.copyLicenseKey($(this));
            });

            // Tab switching
            $(document).on('click', this.config.selectors.tabsNav, function(e) {
                const href = $(this).attr('href');
                if (href === '#licenses') {
                    setTimeout(function() {
                        self.ensureDomainButtonsVisible();
                    }, 100);
                }
            });

            // Escape key to close modals
            $(document).on('keyup', function(e) {
                if (e.keyCode === 27) { // ESC key
                    self.closeModals();
                }
            });

            // Handle URL changes
            $(window).on('popstate hashchange', function() {
                setTimeout(function() {
                    self.handleInitialPageLoad();
                }, 100);
            });

        },

        /**
         * Activate licenses tab
         */
        activateLicensesTab: function() {
            $(this.config.selectors.tabsNav).removeClass('active');
            $(this.config.selectors.tabsNav + '[href="#licenses"]').addClass('active');
            
            $('.vrstore-tab-content').removeClass('vrstore-tab-active');
            $(this.config.selectors.licensesTab).addClass('vrstore-tab-active');
        },

        /**
         * Ensure domain buttons are visible when license is selected
         */
        ensureDomainButtonsVisible: function() {
            const urlParams = new URLSearchParams(window.location.search);
            const licenseId = urlParams.get('license_id');
            
            if (!licenseId) {
                return;
            }

            const self = this;
            setTimeout(function() {
                const $domainActions = $(self.config.selectors.domainActions);
                const $addDomainBtn = $(self.config.selectors.addDomainBtn);
                const $domainManagement = $(self.config.selectors.domainManagement);
                
                if ($domainActions.length === 0 && $domainManagement.length > 0) {
                    self.createDomainActionButtons(licenseId);
                } else if ($addDomainBtn.length > 0) {
                    $addDomainBtn.css('display', 'inline-block');
                    $(self.config.selectors.refreshDomainsBtn).css('display', 'inline-block');
                }
            }, 200);
        },

        /**
         * Create domain action buttons if missing
         */
        createDomainActionButtons: function(licenseId) {
            let licenseKey = '';
            let productId = '';

            // Find license data from the license info or manage button
            $('.vrstore-license-info-value').each(function() {
                const text = $(this).text().trim();
                if (text.match(/^[A-Za-z0-9\-_]+$/) && text.length > 10) {
                    licenseKey = text;
                }
            });

            $('.vrstore-manage-license').each(function() {
                if ($(this).data('license-id') == licenseId) {
                    licenseKey = $(this).data('license-key') || licenseKey;
                    productId = $(this).data('product-id') || productId;
                    return false;
                }
            });

            const buttonsHTML = `
                <div class="vrstore-domain-actions">
                    <button class="vrstore-button vrstore-button-small vrstore-button-primary vrstore-add-domain" 
                            data-license-key="${licenseKey}" 
                            data-product-id="${productId}"
                            data-activation-limit="0">
                        Add Domain
                    </button>
                    <button class="vrstore-button vrstore-button-small vrstore-refresh-domains" 
                            data-license-key="${licenseKey}">
                        Refresh
                    </button>
                </div>
            `;

            const $domainHeader = $(this.config.selectors.domainHeader);
            if ($domainHeader.length && !$domainHeader.find('.vrstore-domain-actions').length) {
                $domainHeader.append(buttonsHTML);
            }
        },

        /**
         * Setup modal backdrop click to close
         */
        setupModalBackdropClose: function() {
            const self = this;
            $(document).on('click', this.config.selectors.modalOverlay, function(e) {
                if (e.target === this) {
                    self.closeModals();
                }
            });
        },

        /**
         * Open add domain modal
         */
        openAddDomainModal: function($btn) {
            // Get license data from button attributes - for unified approach, use different data structure
            const isUnified = $btn.hasClass('vrstore-add-domain-unified');
            
            if (isUnified) {
                // Unified approach - get total activation limit and current activations
                this.currentLicenseData = {
                    isUnified: true,
                    totalActivationLimit: parseInt($btn.data('activation-limit')) || 0,
                    currentActivations: parseInt($btn.data('current-activations')) || 0
                };
                
                // Check if total limit is reached for unified approach
                if (this.currentLicenseData.totalActivationLimit > 0 && 
                    this.currentLicenseData.currentActivations >= this.currentLicenseData.totalActivationLimit) {
                    
                    $(this.config.selectors.activationLimitWarning).show();
                    $('.vrstore-add-domain-unified-submit').prop('disabled', true);
                } else {
                    $(this.config.selectors.activationLimitWarning).hide();
                    $('.vrstore-add-domain-unified-submit').prop('disabled', false);
                }
                
                // Clear form and open unified modal
                $(this.config.selectors.addDomainForm)[0] && $(this.config.selectors.addDomainForm)[0].reset();
                this.openModal(this.config.selectors.addDomainModal);
                
                // Focus on domain input
                setTimeout(() => {
                    $(this.config.selectors.domainInput).focus();
                }, 300);
                
            } else {
                // Legacy approach - individual license management
                this.currentLicenseData = {
                    isUnified: false,
                    licenseKey: $btn.data('license-key'),
                    productId: $btn.data('product-id'),
                    activationLimit: parseInt($btn.data('activation-limit')) || 0
                };

                // Check if individual license limit is reached
                const currentActivations = $(this.config.selectors.domainsListLegacy + ' tr').length;
                if (this.currentLicenseData.activationLimit > 0 && 
                    currentActivations >= this.currentLicenseData.activationLimit) {
                    
                    $(this.config.selectors.activationLimitWarningLegacy).show();
                    $('.vrstore-add-domain-submit').prop('disabled', true);
                } else {
                    $(this.config.selectors.activationLimitWarningLegacy).hide();
                    $('.vrstore-add-domain-submit').prop('disabled', false);
                }

                // Clear form and open legacy modal
                $(this.config.selectors.addDomainFormLegacy)[0] && $(this.config.selectors.addDomainFormLegacy)[0].reset();
                this.openModal(this.config.selectors.addDomainModalLegacy);
                
                // Focus on domain input
                setTimeout(() => {
                    $(this.config.selectors.domainInputLegacy).focus();
                }, 300);
            }
        },

        /**
         * Open deactivation confirmation modal
         */
        openDeactivateModal: function($btn) {
            // Check if this is unified or legacy approach
            const isUnified = $btn.hasClass('vrstore-deactivate-domain-unified');
            
            // Get domain data from button attributes (sanitize)
            let licenseKey = $btn.data('license-key') || $btn.attr('data-license-key') || '';
            let domain = $btn.data('domain') || $btn.attr('data-domain') || '';
            
            // Validate data exists
            if (!licenseKey || !domain) {
                this.showMessage('error', 'Missing required information to deactivate domain');
                return;
            }
            
            // Sanitize and validate
            licenseKey = this.escapeHtml(String(licenseKey).trim());
            domain = this.escapeHtml(String(domain).trim());
            
            if (!licenseKey || !domain) {
                this.showMessage('error', 'Invalid license key or domain');
                return;
            }
            
            // Get domain data from button attributes
            if (isUnified) {
                this.currentLicenseData = {
                    isUnified: true,
                    licenseKey: licenseKey,
                    domain: domain
                };
            } else {
                const productId = $btn.data('product-id') || $btn.attr('data-product-id') || '';
                this.currentLicenseData = {
                    isUnified: false,
                    licenseKey: licenseKey,
                    productId: productId,
                    domain: domain
                };
            }

            // Set domain name in confirmation message (already escaped)
            const $domainNameEl = $('#vrstore-deactivate-domain-unified-name, #vrstore-deactivate-domain-name');
            if ($domainNameEl.length) {
                $domainNameEl.html('<strong>' + domain + '</strong>');
            }
            
            // Set license info if element exists
            const $licenseInfoEl = $('#vrstore-deactivate-license-unified-info');
            if ($licenseInfoEl.length && licenseKey) {
                const maskedKey = licenseKey.length > 12 ? licenseKey.substring(0, 12) + '...' : licenseKey;
                $licenseInfoEl.text('License: ' + maskedKey);
            }

            // Open appropriate modal
            if (isUnified) {
                this.openModal(this.config.selectors.deactivateModal);
            } else {
                this.openModal(this.config.selectors.deactivateModalLegacy || this.config.selectors.deactivateModal);
            }
        },

        /**
         * Open a modal with animation
         */
        openModal: function(modalSelector) {
            this.currentModal = modalSelector;
            const $modal = $(modalSelector);
            
            if ($modal.length > 0) {
                $modal.show().addClass('vrstore-modal-visible');
                $('body').addClass('vrstore-modal-open');
                
                // Trigger the animation
                setTimeout(() => {
                    $modal.css('opacity', '1');
                }, 10);
            }
        },

        /**
         * Close a specific modal
         */
        closeModal: function(modalSelector) {
            const $modal = $(modalSelector);
            
            if ($modal.length > 0) {
                $modal.removeClass('vrstore-modal-visible');
                $modal.css('opacity', '0');
                
                setTimeout(() => {
                    $modal.hide();
                }, 300);
                
                $('body').removeClass('vrstore-modal-open');
                if (this.currentModal === modalSelector) {
                    this.currentModal = null;
                }
            }
        },

        /**
         * Close all modals
         */
        closeModals: function() {
            if (this.currentModal) {
                this.closeModal(this.currentModal);
            } else {
                // Fallback: close any visible modals
                $('.vrstore-modal-overlay').each((index, element) => {
                    const $modal = $(element);
                    if ($modal.is(':visible')) {
                        $modal.removeClass('vrstore-modal-visible');
                        $modal.css('opacity', '0');
                        
                        setTimeout(() => {
                            $modal.hide();
                        }, 300);
                    }
                });
                
                $('body').removeClass('vrstore-modal-open');
                this.currentModal = null;
            }
        },

        /**
         * Submit add domain form
         */
        submitAddDomain: function() {
            if (!this.currentLicenseData) {
                console.error('No license data available');
                return;
            }

            const self = this;
            let $form, $domainInput, $submitBtn, domain;
            
            // Get elements based on unified or legacy approach
            if (this.currentLicenseData.isUnified) {
                $form = $(this.config.selectors.addDomainForm);
                $domainInput = $(this.config.selectors.domainInput);
                $submitBtn = $('.vrstore-add-domain-unified-submit');
            } else {
                $form = $(this.config.selectors.addDomainFormLegacy);
                $domainInput = $(this.config.selectors.domainInputLegacy);
                $submitBtn = $('.vrstore-add-domain-submit');
            }
            
            // Check if already submitting (prevent race condition)
            if ($submitBtn.data('submitting')) {
                return; // Already processing
            }
            
            domain = $domainInput.val().trim();
            
            // Validate domain
            if (!domain) {
                this.showMessage('error', this.config.messages.domainRequired || 'Please enter a domain');
                $domainInput.focus();
                return;
            }
            
            // Clean domain before validation to match server-side processing
            const cleanedDomain = this.cleanDomain(domain);
            
            if (!this.isValidDomain(cleanedDomain)) {
                this.showMessage('error', this.config.messages.domainInvalid || 'Please enter a valid domain');
                $domainInput.focus();
                return;
            }
            
            // Use cleaned domain for submission
            domain = cleanedDomain;
            
            // Disable submit button and show processing (prevent double submission)
            const $buttonText = $submitBtn.find('.vrstore-button-text');
            const originalText = $buttonText.length ? $buttonText.text() : $submitBtn.text();
            $submitBtn.data('submitting', true).prop('disabled', true);
            
            // Update button text and spinner
            if ($buttonText.length) {
                $buttonText.text(this.config.messages.processing || 'Processing...');
                $submitBtn.find('.vrstore-button-spinner').show();
            } else {
                $submitBtn.text(this.config.messages.processing || 'Processing...');
            }
            
            // Prepare AJAX data based on approach
            let ajaxData = {
                nonce: this.config.ajax.nonce,
                domain: domain
            };
            
            if (this.currentLicenseData.isUnified) {
                // For unified approach, we need to handle multiple licenses
                ajaxData.action = 'vrstore_activate_domain_unified';
                // customer_id is passed but server validates using current user (security)
                if (this.config.customerId) {
                    ajaxData.customer_id = this.config.customerId;
                }
            } else {
                // Legacy approach for individual license
                ajaxData.action = 'vrstore_activate_domain';
                ajaxData.license_key = this.currentLicenseData.licenseKey || '';
                ajaxData.product_id = this.currentLicenseData.productId || '';
            }
            
            // Submit via AJAX with timeout
            $.ajax({
                url: this.config.ajax.url,
                method: 'POST',
                data: ajaxData,
                timeout: 30000, // 30 second timeout
                dataType: 'json',
                success: function(response) {
                    if (response && response.success) {
                        self.showMessage('success', response.data?.message || self.config.messages.activationSuccess || 'Domain activated successfully');
                        
                        // Reset form and close modal
                        $form[0].reset();
                        self.closeModals();
                        
                        // Refresh domains list after short delay
                        setTimeout(function() {
                            self.refreshDomainsList();
                        }, 500);
                    } else {
                        const errorMessage = response?.data?.message || 
                                           response?.data?.error || 
                                           self.config.messages.activationError || 
                                           'Failed to activate domain';
                        self.showMessage('error', errorMessage);
                        $domainInput.focus();
                    }
                },
                error: function(xhr, status, error) {
                    let errorMessage = self.config.messages.networkError || 'Network error occurred';
                    
                    // Provide more specific error messages
                    if (status === 'timeout') {
                        errorMessage = 'Request timed out. Please try again.';
                    } else if (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
                        errorMessage = xhr.responseJSON.data.message;
                    } else if (xhr.status === 0) {
                        errorMessage = 'No internet connection. Please check your network and try again.';
                    } else if (xhr.status >= 500) {
                        errorMessage = 'Server error occurred. Please try again later.';
                    } else if (xhr.status === 403) {
                        errorMessage = 'Permission denied. Please refresh the page and try again.';
                    }
                    
                    self.showMessage('error', errorMessage);
                    
                    // Log error for debugging (only in development)
                    if (typeof console !== 'undefined' && console.error) {
                        console.error('Domain activation error:', {
                            status: status,
                            error: error,
                            response: xhr.responseJSON || xhr.responseText
                        });
                    }
                },
                complete: function() {
                    // Re-enable submit button and remove submitting flag
                    const $buttonText = $submitBtn.find('.vrstore-button-text');
                    $submitBtn.removeData('submitting');
                    $submitBtn.prop('disabled', false);
                    
                    if ($buttonText.length) {
                        $buttonText.text(originalText);
                        $submitBtn.find('.vrstore-button-spinner').hide();
                    } else {
                        $submitBtn.text(originalText);
                    }
                }
            });
        },

        /**
         * Confirm deactivation
         */
        confirmDeactivation: function() {
            if (!this.currentLicenseData) {
                console.error('No license data available for deactivation');
                return;
            }
            
            const self = this;
            const $confirmBtn = $('.vrstore-confirm-deactivate-unified, .vrstore-confirm-deactivate');
            
            // Check if already submitting (prevent race condition)
            if ($confirmBtn.data('submitting')) {
                return;
            }
            
            // Validate required data
            if (!this.currentLicenseData.licenseKey || !this.currentLicenseData.domain) {
                this.showMessage('error', 'Missing required information for deactivation');
                return;
            }
            
            // Disable button and show processing
            const originalText = $confirmBtn.find('.vrstore-button-text').text();
            $confirmBtn.data('submitting', true).prop('disabled', true);
            $confirmBtn.find('.vrstore-button-text').text(this.config.messages.processing || 'Processing...');
            $confirmBtn.find('.vrstore-button-spinner').show();
            
            // Prepare AJAX data based on approach
            let ajaxData = {
                nonce: this.config.ajax.nonce,
                license_key: this.escapeHtml(this.currentLicenseData.licenseKey).trim(),
                domain: this.escapeHtml(this.currentLicenseData.domain).trim()
            };
            
            if (this.currentLicenseData.isUnified) {
                // Unified approach - may need different action or parameters
                ajaxData.action = 'vrstore_deactivate_domain_unified';
                // customer_id is passed but server validates using current user (security)
                if (this.config.customerId) {
                    ajaxData.customer_id = this.config.customerId;
                }
            } else {
                // Legacy approach
                ajaxData.action = 'vrstore_deactivate_domain';
                ajaxData.product_id = this.currentLicenseData.productId || '';
            }
            
            // Submit via AJAX with timeout
            $.ajax({
                url: this.config.ajax.url,
                method: 'POST',
                data: ajaxData,
                timeout: 30000, // 30 second timeout
                dataType: 'json',
                success: function(response) {
                    if (response && response.success) {
                        self.showMessage('success', response.data?.message || self.config.messages.deactivationSuccess || 'Domain deactivated successfully');
                        
                        // Close modal
                        self.closeModals();
                        
                        // Refresh domains list after short delay
                        setTimeout(function() {
                            self.refreshDomainsList();
                        }, 500);
                    } else {
                        const errorMessage = response?.data?.message || 
                                           response?.data?.error || 
                                           self.config.messages.deactivationError || 
                                           'Failed to deactivate domain';
                        self.showMessage('error', errorMessage);
                    }
                },
                error: function(xhr, status, error) {
                    let errorMessage = self.config.messages.networkError || 'Network error occurred';
                    
                    // Provide more specific error messages
                    if (status === 'timeout') {
                        errorMessage = 'Request timed out. Please try again.';
                    } else if (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
                        errorMessage = xhr.responseJSON.data.message;
                    } else if (xhr.status === 0) {
                        errorMessage = 'No internet connection. Please check your network and try again.';
                    } else if (xhr.status >= 500) {
                        errorMessage = 'Server error occurred. Please try again later.';
                    } else if (xhr.status === 403) {
                        errorMessage = 'Permission denied. Please refresh the page and try again.';
                    }
                    
                    self.showMessage('error', errorMessage);
                    
                    // Log error for debugging (only in development)
                    if (typeof console !== 'undefined' && console.error) {
                        console.error('Domain deactivation error:', {
                            status: status,
                            error: error,
                            response: xhr.responseJSON || xhr.responseText
                        });
                    }
                },
                complete: function() {
                    // Re-enable button and remove submitting flag
                    $confirmBtn.removeData('submitting');
                    $confirmBtn.prop('disabled', false);
                    $confirmBtn.find('.vrstore-button-text').text(originalText);
                    $confirmBtn.find('.vrstore-button-spinner').hide();
                }
            });
        },

        /**
         * Refresh domains list
         */
        refreshDomainsList: function() {
            const self = this;
            
            // Add a visible loading indicator
            const $refreshBtn = $('.vrstore-refresh-domains-unified, .vrstore-refresh-domains');
            
            // Check if already refreshing (prevent race condition)
            if ($refreshBtn.data('refreshing')) {
                return;
            }
            
            const originalText = $refreshBtn.text();
            $refreshBtn.data('refreshing', true).prop('disabled', true).text('Refreshing...');
            
            // First, force a backend refresh to ensure all timestamps are updated
            $.ajax({
                url: this.config.ajax.url,
                method: 'POST',
                data: {
                    action: 'vrstore_force_domain_status_refresh',
                    nonce: this.config.ajax.nonce,
                    customer_id: this.config.customerId || '' // Optional, server validates using current user
                },
                timeout: 30000, // 30 second timeout
                dataType: 'json',
                success: function(response) {
                    // Simply reload the page without URL parameters for clean refresh
                    setTimeout(function() {
                        self.cleanReload();
                    }, 1000); // Increased delay to ensure backend processing is complete
                },
                error: function(xhr, status, error) {
                    // Even if the AJAX fails, still reload to show any updates
                    // But show error message first
                    if (status !== 'timeout' && xhr.status !== 0) {
                        // Only show error if it's not a timeout or connection issue
                        setTimeout(function() {
                            self.cleanReload();
                        }, 500);
                    } else {
                        // For timeout/connection issues, reload anyway to show cached data
                        setTimeout(function() {
                            self.cleanReload();
                        }, 500);
                        // Re-enable button in case reload doesn't happen
                        $refreshBtn.removeData('refreshing').prop('disabled', false).text(originalText);
                    }
                },
                complete: function() {
                    // Reset button state (though page will reload anyway if successful)
                    if (!$refreshBtn.data('refreshing')) {
                        $refreshBtn.removeData('refreshing').prop('disabled', false).text(originalText);
                    }
                }
            });
        },

        /**
         * Refresh domains button handler
         */
        refreshDomains: function($btn) {
            // Check if this is unified or legacy approach
            const isUnified = $btn.hasClass('vrstore-refresh-domains-unified');
            
            if (isUnified) {
                // For unified approach, we don't need specific license data
                this.currentLicenseData = {
                    isUnified: true
                };
            } else {
                // Legacy approach - get license data from button attributes
                this.currentLicenseData = {
                    isUnified: false,
                    licenseKey: $btn.data('license-key'),
                    productId: $btn.data('product-id')
                };
            }
            
            this.refreshDomainsList();
        },


        /**
         * Clean reload without URL parameters
         */
        cleanReload: function() {
            // Get current URL without search parameters
            const currentUrl = new URL(window.location.href);
            const cleanUrl = currentUrl.origin + currentUrl.pathname + currentUrl.hash;
            
            // Use replace to avoid adding to browser history
            window.location.replace(cleanUrl);
        },

        /**
         * Show message in messages container
         */
        showMessage: function(type, message) {
            const $container = $(this.config.selectors.messagesContainer);
            const alertClass = type === 'success' ? 'notice-success' : 'notice-error';
            
            $container.html(
                '<div class="notice ' + alertClass + ' is-dismissible">' +
                '<p>' + this.escapeHtml(message) + '</p>' +
                '<button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button>' +
                '</div>'
            ).show();
            
            // Auto-hide messages after 5 seconds
            setTimeout(() => {
                $container.fadeOut();
            }, 5000);
        },

        /**
         * Validate domain input
         */
        validateDomainInput: function($input) {
            const domain = $input.val().trim();
            const isValid = domain === '' || this.isValidDomain(domain);
            
            if (isValid) {
                $input.removeClass('vrstore-input-error');
            } else {
                $input.addClass('vrstore-input-error');
            }
        },

        /**
         * Validate domain format (matches server-side validation)
         */
        isValidDomain: function(domain) {
            if (!domain || typeof domain !== 'string') {
                return false;
            }
            
            // Clean the domain first (match server-side cleaning)
            const cleaned = this.cleanDomain(domain);
            
            // Check length (domain must be between 4 and 253 characters)
            if (cleaned.length < 4 || cleaned.length > 253) {
                return false;
            }
            
            // Must contain at least one dot (TLD required)
            if (cleaned.indexOf('.') === -1) {
                return false;
            }
            
            // Enhanced domain validation regex (matches server-side pattern)
            // Pattern: [a-z0-9]([a-z0-9\-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9\-]{0,61}[a-z0-9])?)*
            const domainRegex = /^[a-z0-9]([a-z0-9\-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9\-]{0,61}[a-z0-9])?)*$/;
            
            if (!domainRegex.test(cleaned)) {
                return false;
            }
            
            // Additional validation: not an IP address
            // Simple IP check (matches server-side filter_var with FILTER_VALIDATE_IP)
            const ipPattern = /^(\d{1,3}\.){3}\d{1,3}$/;
            if (ipPattern.test(cleaned)) {
                return false; // IP addresses are not valid domains
            }
            
            // Check that TLD is at least 2 characters
            const parts = cleaned.split('.');
            if (parts.length < 2) {
                return false;
            }
            const tld = parts[parts.length - 1];
            if (tld.length < 2 || tld.length > 63) {
                return false;
            }
            
            return true;
        },

        /**
         * Clean domain input (remove protocols, www, etc.) - matches server-side cleaning
         */
        cleanDomain: function(domain) {
            if (!domain || typeof domain !== 'string') {
                return '';
            }
            
            let cleaned = domain.toLowerCase().trim();
            
            // Remove protocol (http:// or https://)
            cleaned = cleaned.replace(/^https?:\/\//i, '');
            
            // Remove www. prefix
            cleaned = cleaned.replace(/^www\./, '');
            
            // Remove port numbers
            cleaned = cleaned.replace(/:\d+$/, '');
            
            // Remove path and query strings
            cleaned = cleaned.split('/')[0];
            cleaned = cleaned.split('?')[0];
            cleaned = cleaned.split('#')[0];
            
            return cleaned.trim();
        },

        /**
         * Copy license key to clipboard
         */
        copyLicenseKey: function($btn) {
            const licenseKey = $btn.data('license-key');
            
            if (!licenseKey) return;

            // Try to use modern clipboard API
            if (navigator.clipboard) {
                navigator.clipboard.writeText(licenseKey).then(() => {
                    this.showMessage('success', 'License key copied to clipboard!');
                }).catch(() => {
                    this.fallbackCopyLicenseKey(licenseKey);
                });
            } else {
                this.fallbackCopyLicenseKey(licenseKey);
            }
        },

        /**
         * Fallback copy method for older browsers
         */
        fallbackCopyLicenseKey: function(licenseKey) {
            const textArea = document.createElement('textarea');
            textArea.value = licenseKey;
            textArea.style.position = 'fixed';
            textArea.style.left = '-999999px';
            textArea.style.top = '-999999px';
            document.body.appendChild(textArea);
            textArea.focus();
            textArea.select();

            try {
                document.execCommand('copy');
                this.showMessage('success', 'License key copied to clipboard!');
            } catch (err) {
                this.showMessage('error', 'Failed to copy license key. Please copy manually.');
            }

            document.body.removeChild(textArea);
        },

        /**
         * Format date for display
         */
        formatDate: function(dateString) {
            try {
                const date = new Date(dateString);
                return date.toLocaleDateString();
            } catch (e) {
                return dateString;
            }
        },

        /**
         * Escape HTML to prevent XSS
         */
        escapeHtml: function(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
    };

    // Initialize when document is ready
    $(document).ready(function() {
        // Check if we're on a page that needs domain management
        if ($('.vrstore-domain-management').length > 0 || 
            $('#licenses').length > 0 || 
            $('.vrstore-licenses-table').length > 0) {
            VRStoreDomainManager.init();
        }
    });
    
    // Also initialize after window loads to catch dynamically loaded content
    $(window).on('load', function() {
        if ($('.vrstore-domain-management').length > 0) {
            VRStoreDomainManager.ensureDomainButtonsVisible();
        }
    });

    // Make available globally for debugging
    window.VRStoreDomainManager = VRStoreDomainManager;

})(jQuery);