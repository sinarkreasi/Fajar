/**
 * SIMPLE DOWNLOADS FIX - GUARANTEED TO WORK
 * No complex logic, no conflicts, just works
 */

// SIMPLE DOWNLOADS - Clean Version

// Utility function to format file sizes
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Error modal function
function showErrorModal(title, message) {
    // Remove any existing error modal
    $('#vrstore-error-modal').remove();
    
    const modalHTML = `
        <div id="vrstore-error-modal" style="
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0,0,0,0.7); z-index: 99999; display: flex;
            align-items: center; justify-content: center;
        ">
            <div style="
                background: white; padding: 25px; border-radius: 8px;
                max-width: 450px; width: 90%; box-shadow: 0 4px 20px rgba(0,0,0,0.5);
                border-left: 4px solid #dc3545;
            ">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                    <h3 style="margin: 0; color: #dc3545;">${title}</h3>
                    <button onclick="$('#vrstore-error-modal').remove()" style="
                        background: none; border: none; font-size: 24px;
                        cursor: pointer; padding: 0; color: #999;
                    ">&times;</button>
                </div>
                <div style="margin-bottom: 20px; color: #333; line-height: 1.5;">
                    ${message}
                </div>
                <div style="text-align: center;">
                    <button onclick="$('#vrstore-error-modal').remove()" style="
                        padding: 10px 20px; background: #dc3545; color: white;
                        border: none; border-radius: 4px; cursor: pointer;
                    ">Close</button>
                </div>
            </div>
        </div>
    `;
    
    $('body').append(modalHTML);
    
    // Close modal when clicking outside
    $('#vrstore-error-modal').on('click', function(e) {
        if (e.target === this) {
            $(this).remove();
        }
    });
}

jQuery(document).ready(function($) {
    
    // Remove ALL existing handlers first
    $(document).off('click', '.vrstore-show-downloads');
    $(document).off('click.downloads-handler');
    $(document).off('click.downloads-backup');
    
    // TARGETED handler - Only catch specific elements with download functionality
    $(document).on('click', '.vrstore-show-downloads', function(e) {
        e.preventDefault();
        
        const $this = $(this);
        
        // Get data attributes
        const productId = $this.data('product-id') || $this.attr('data-product-id');
        const orderId = $this.data('order-id') || $this.attr('data-order-id');
        const productTitle = $this.data('product-title') || $this.attr('data-product-title') || 'Product';
        
        if (productId && orderId) {
            showDownloadsNow(productTitle, productId, orderId);
        } else {
            showErrorModal('Download Error', 'Unable to retrieve download information. Please try again or contact support.');
        }
    });
    
    // Additional fallback handler for buttons/elements with data attributes
    $(document).on('click', '[data-product-id][data-order-id]', function(e) {
        const $this = $(this);
        
        // Skip if already handled by the primary handler
        if ($this.hasClass('vrstore-show-downloads')) {
            return;
        }
        
        // Don't handle regular links
        if ($this.is('a[href]') && $this.attr('href') !== '#') {
            return;
        }
        
        e.preventDefault();
        
        const productId = $this.data('product-id') || $this.attr('data-product-id');
        const orderId = $this.data('order-id') || $this.attr('data-order-id');
        const productTitle = $this.data('product-title') || $this.attr('data-product-title') || 'Product';
        
        if (productId && orderId) {
            showDownloadsNow(productTitle, productId, orderId);
        }
    });
    
    // Show downloads function
    function showDownloadsNow(title, productId, orderId) {
        // Validate inputs
        if (!productId || !orderId) {
            showErrorModal('Download Error', 'Missing product or order information.');
            return;
        }
        
        // Show loading state
        const loadingHtml = `
            <div id="vrstore-loading" style="
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0,0,0,0.6);
                z-index: 9999;
                display: flex;
                align-items: center;
                justify-content: center;
                font-family: Arial, sans-serif;
            ">
                <div style="
                    background: white;
                    padding: 30px;
                    border-radius: 8px;
                    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
                    text-align: center;
                    min-width: 200px;
                ">
                    <div style="margin-bottom: 15px;">🔄</div>
                    <div>Loading downloads...</div>
                </div>
            </div>
        `;
        $('body').append(loadingHtml);
        
        // Call improved fetchFiles function
        fetchFiles(productId, orderId, title);
    }
    
    // Improved AJAX call with better security and error handling
    function fetchFiles(productId, orderId, title = 'Product') {
        // Remove any existing loading indicators
        $('#vrstore-loading').remove();
        
        // Try to get the correct AJAX URL
        let ajaxUrl = '/wp-admin/admin-ajax.php';
        
        if (typeof vrstore_frontend !== 'undefined' && vrstore_frontend.ajax_url) {
            ajaxUrl = vrstore_frontend.ajax_url;
        } else if (typeof vrstore_ajax !== 'undefined' && vrstore_ajax.url) {
            ajaxUrl = vrstore_ajax.url;
        } else if (typeof ajaxurl !== 'undefined') {
            ajaxUrl = ajaxurl;
        } else {
            // Fallback: construct URL based on current location
            const protocol = window.location.protocol;
            const hostname = window.location.hostname;
            const port = window.location.port ? ':' + window.location.port : '';
            ajaxUrl = `${protocol}//${hostname}${port}/wp-admin/admin-ajax.php`;
        }
        
        // Get nonce from multiple possible sources
        let nonce = '';
        if (typeof vrstore_frontend !== 'undefined' && vrstore_frontend.nonce) {
            nonce = vrstore_frontend.nonce;
        } else if (typeof vrstore_ajax !== 'undefined' && vrstore_ajax.nonce) {
            nonce = vrstore_ajax.nonce;
        } else {
            // Try to get nonce from DOM elements
            nonce = $('meta[name="vrstore-nonce"]').attr('content') || 
                   $('#vrstore-nonce').val() || 
                   $('input[name="vrstore_nonce"]').val() ||
                   window.vrstore_ajax_nonce || 
                   '';
        }
        

        
        // Show loading state
        const loadingHtml = `
            <div id="vrstore-loading" style="
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0,0,0,0.6);
                z-index: 9999;
                display: flex;
                align-items: center;
                justify-content: center;
                font-family: Arial, sans-serif;
            ">
                <div style="
                    background: white;
                    padding: 30px;
                    border-radius: 8px;
                    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
                    text-align: center;
                    min-width: 200px;
                ">
                    <div style="margin-bottom: 15px;">🔄</div>
                    <div>Loading ${title} downloads...</div>
                </div>
            </div>
        `;
        $('body').append(loadingHtml);
        
        // Prepare AJAX data
        const ajaxData = {
            action: 'vrstore_get_product_downloads',
            product_id: productId,
            order_id: orderId
        };
        
        if (nonce) {
            ajaxData.nonce = nonce;
        }
        
        $.ajax({
            url: ajaxUrl,
            type: 'POST',
            data: ajaxData,
            timeout: 30000, // 30 second timeout
            success: function(response) {
                $('#vrstore-loading').remove();
                // Parse the response
                let files = [];
                let errorMessage = '';
                
                if (response && response.success && response.data && response.data.files) {
                    files = response.data.files;
                } else if (response && !response.success && response.data && response.data.message) {
                    errorMessage = response.data.message;
                } else if (Array.isArray(response)) {
                    files = response;
                } else if (response && response.message) {
                    errorMessage = response.message;
                } else {
                    errorMessage = 'Unexpected response format from server.';
                }
                
                if (errorMessage) {
                    showErrorModal('Download Error', errorMessage);
                    return;
                }
                
                if (files && files.length > 0) {
                    // Track download validation based on file count
                    trackDownloadValidation(productId, orderId, files.length);
                    
                    // Handle single vs multiple files
                    if (files.length === 1) {
                        handleSingleFileDownload(files[0], productId, orderId);
                    } else {
                        showModal(productId, orderId, files, title);
                    }
                } else {
                    showErrorModal('No Downloads', 'No download files found for this product. Please contact support if you believe this is an error.');
                }
            },
            error: function(xhr, status, error) {
                $('#vrstore-loading').remove();

                
                let errorMsg = 'Failed to load downloads. ';
                
                if (xhr.status === 403) {
                    errorMsg = 'Access denied. Please make sure you are logged in and have permission to download this product.';
                } else if (xhr.status === 404) {
                    errorMsg = 'Download service not found. The server may be experiencing issues.';
                } else if (xhr.status === 0) {
                    errorMsg = 'Network error. Please check your internet connection and try again.';
                } else if (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
                    errorMsg += xhr.responseJSON.data.message;
                } else if (xhr.responseText) {
                    try {
                        const response = JSON.parse(xhr.responseText);
                        if (response.data && response.data.message) {
                            errorMsg += response.data.message;
                        } else {
                            errorMsg += 'Please try again or contact support.';
                        }
                    } catch (e) {
                        errorMsg += 'Please try again or contact support.';
                    }
                } else {
                    errorMsg += 'Please try again or contact support.';
                }
                
                showErrorModal('Connection Error', errorMsg);
            }
        });
    }
    
    
    // Show modal with files
    function showModal(productId, orderId, files, title = 'Product Downloads') {
        
        // Remove any existing modal
        $('#downloads-modal').remove();
        
        // Create modal HTML
        let filesHTML = '';
        files.forEach(function(file, index) {
            const fileName = file.name || 'Download ' + (index + 1);
            const fileUrl = file.url || file.file || '#';
            const fileType = file.type || 'unknown';
            const hasError = file.error && file.error !== '';
            
            let fileTypeLabel = 'Secure Download';
            if (fileType === 'upload') {
                fileTypeLabel = 'Main File';
            } else if (fileType === 'url') {
                fileTypeLabel = 'Additional File';
            }
            
            let downloadButtonHTML = '';
            if (hasError) {
                downloadButtonHTML = `<span style="display: inline-block; padding: 8px 16px; background: #dc3545; color: white; border-radius: 4px;">${file.error}</span>`;
            } else if (fileUrl === '#' || fileUrl === '') {
                downloadButtonHTML = `<span style="display: inline-block; padding: 8px 16px; background: #6c757d; color: white; border-radius: 4px;">No URL Available</span>`;
            } else {
                downloadButtonHTML = `<a href="${fileUrl}" target="_blank" style="display: inline-block; padding: 8px 16px; background: #0073aa; color: white; text-decoration: none; border-radius: 4px;">Download</a>`;
            }
            
            let sizeInfo = '';
            if (file.size && file.size > 0) {
                sizeInfo = `<div style="font-size: 11px; color: #999; margin-bottom: 5px;">Size: ${formatFileSize(file.size)}</div>`;
            }
            
            filesHTML += `
                <div style="margin-bottom: 15px; padding: 12px; border: 1px solid #ddd; border-radius: 5px; background: #f9f9f9;">
                    <div style="font-weight: bold; margin-bottom: 5px;">${fileName}</div>
                    <div style="font-size: 12px; color: #666; margin-bottom: 5px;">${fileTypeLabel}</div>
                    ${sizeInfo}
                    ${downloadButtonHTML}
                </div>
            `;
        });
        
        const modalHTML = `
            <div id="downloads-modal" style="
                position: fixed; top: 0; left: 0; width: 100%; height: 100%;
                background: rgba(0,0,0,0.7); z-index: 99999; display: flex;
                align-items: center; justify-content: center;
            ">
                <div style="
                    background: white; padding: 20px; border-radius: 8px;
                    max-width: 500px; width: 90%; max-height: 80vh; overflow-y: auto;
                    box-shadow: 0 4px 20px rgba(0,0,0,0.5);
                ">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                        <h3 style="margin: 0; color: #333;">${title}</h3>
                        <button class="close-modal" style="
                            background: none; border: none; font-size: 24px;
                            cursor: pointer; padding: 5px; color: #666;
                        ">×</button>
                    </div>
                    <div>
                        ${filesHTML}
                    </div>
                    <div style="text-align: center; margin-top: 20px;">
                        <button class="close-modal" style="
                            padding: 8px 16px; background: #666; color: white;
                            border: none; border-radius: 4px; cursor: pointer;
                        ">Close</button>
                    </div>
                </div>
            </div>
        `;
        
        $('body').append(modalHTML);
        
        // Close modal when clicking close buttons
        $('.close-modal').on('click', function(e) {
            e.preventDefault();
            $('#downloads-modal').remove();
        });
        
        // Close modal when clicking outside
        $('#downloads-modal').on('click', function(e) {
            if (e.target === this) {
                $(this).remove();
            }
        });
        
        // Close modal with Escape key
        $(document).on('keydown.downloads-modal', function(e) {
            if (e.key === 'Escape') {
                $('#downloads-modal').remove();
                $(document).off('keydown.downloads-modal');
            }
        });
    }
    
    /**
     * Track download validation for analytics
     * @param {string} productId Product ID
     * @param {string} orderId Order ID 
     * @param {number} fileCount Number of files
     */
    function trackDownloadValidation(productId, orderId, fileCount) {
        const downloadType = fileCount === 1 ? 'single' : 'multiple';
        const downloadProcess = fileCount === 1 ? 'immediate' : 'modal';
        

        
        // Track in browser storage for analytics
        try {
            const validationData = {
                productId: productId,
                orderId: orderId,
                fileCount: fileCount,
                downloadType: downloadType,
                downloadProcess: downloadProcess,
                timestamp: Date.now(),
                userAgent: navigator.userAgent
            };
            
            // Store in session storage for current session tracking
            const existingData = JSON.parse(sessionStorage.getItem('vrstore_download_validations') || '[]');
            existingData.push(validationData);
            sessionStorage.setItem('vrstore_download_validations', JSON.stringify(existingData));
            
        } catch (e) {
            // Silently handle storage errors
        }
    }
    
    /**
     * Handle single file download with immediate action
     * @param {object} file File object
     * @param {string} productId Product ID
     * @param {string} orderId Order ID
     */
    function handleSingleFileDownload(file, productId, orderId) {
        
        // Track single file download
        trackSingleFileDownload(file, productId, orderId);
        
        // For single files, we can either:
        // 1. Show a minimal modal with just one file
        // 2. Trigger download immediately 
        // 3. Show a simple confirmation
        
        // Option 1: Show minimal modal (current behavior)
        showModal(productId, orderId, [file]);
        
        // Option 2: Immediate download (uncomment to use)
        // window.open(file.url, '_blank');
        
        // Option 3: Show confirmation dialog (uncomment to use)
        // if (confirm('Download ' + file.name + '?')) {
        //     window.open(file.url, '_blank');
        // }
    }
    
    /**
     * Track individual single file download action
     * @param {object} file File object
     * @param {string} productId Product ID
     * @param {string} orderId Order ID
     */
    function trackSingleFileDownload(file, productId, orderId) {

        
        // Additional tracking for single files
        try {
            const singleDownloadData = {
                fileName: file.name,
                fileType: file.type,
                fileUrl: file.url,
                productId: productId,
                orderId: orderId,
                downloadType: 'single',
                downloadProcess: 'immediate',
                timestamp: Date.now()
            };
            
            // Store in local storage for persistent tracking
            const existingDownloads = JSON.parse(localStorage.getItem('vrstore_single_downloads') || '[]');
            existingDownloads.push(singleDownloadData);
            
            // Keep only last 100 records to prevent storage bloat
            if (existingDownloads.length > 100) {
                existingDownloads.splice(0, existingDownloads.length - 100);
            }
            
            localStorage.setItem('vrstore_single_downloads', JSON.stringify(existingDownloads));
            
        } catch (e) {
            // Silently handle storage errors
        }
    }
    
    
    // Add utility function for file size formatting
    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
    
});
