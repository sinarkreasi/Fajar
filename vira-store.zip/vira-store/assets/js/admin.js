/**
 * Vira Store Admin Scripts (Cleaned)
 *
 * @package Vira_Store
 * @since 1.0.0
 */

(function($) {
    'use strict';

    var vrstoreAdmin = {
        init: function() {
            this.initColorPicker();
            this.initProductFiles();
            this.initGallerySelection();
            this.initProductVideo();
            this.initDuplicateProduct();
            this.initReports();
            this.initCurrencyManagement();
            this.initOrdersPage();
            this.initLicenseAvailability();
            this.initProductVisibility();
            this.initProductTabs();
            this.initPluginUpdates();
        },

        initColorPicker: function() {
            if ($.fn.wpColorPicker) {
                $('.vrstore-color-picker').wpColorPicker();
            }
        },


        initProductFiles: function() {

            
            // Ensure media uploader is available
            if (typeof wp === 'undefined' || typeof wp.media === 'undefined') {
                return;
            }
            
            // Add new file row
            $(document).on('click', '.vrstore-add-file', function(e) {
                e.preventDefault();
                
                var container = $('.vrstore-product-files-list');
                var index = container.find('.vrstore-product-file').length;
                
                var newFile = $('<div class="vrstore-product-file" data-index="' + index + '">');  
                newFile.append(
                    '<div class="vrstore-file-row">' +
                    '<input type="text" name="vrstore_product_files[' + index + '][name]" placeholder="File Name" class="vrstore-file-name" />' +
                    '<select name="vrstore_product_files[' + index + '][type]" class="vrstore-file-type">' +
                    '<option value="url">External URL</option>' +
                    '<option value="upload">Upload File</option>' +
                    '</select>' +
                    '<button type="button" class="button vrstore-remove-file">Remove</button>' +
                    '</div>' +
                    '<div class="vrstore-file-input-row">' +
                    '<input type="text" name="vrstore_product_files[' + index + '][url]" placeholder="File URL or select upload" class="vrstore-file-url large-text" />' +
                    '<button type="button" class="button vrstore-upload-file" data-index="' + index + '">Upload File</button>' +
                    '<button type="button" class="button vrstore-select-media" data-index="' + index + '">Select from Media</button>' +
                    '</div>' +
                    '</div>'
                );
                
                container.append(newFile);
            });
            
            // Remove file row
            $(document).on('click', '.vrstore-remove-file', function(e) {
                e.preventDefault();
                $(this).closest('.vrstore-product-file').remove();
            });
            
            // Upload file button
            $(document).on('click', '.vrstore-upload-file', function(e) {
                e.preventDefault();
                
                var button = $(this);
                var index = button.data('index');
                var urlField = $('input[name="vrstore_product_files[' + index + '][url]"]');
                var nameField = $('input[name="vrstore_product_files[' + index + '][name]"]');
                
                var frame = wp.media({
                    title: 'Select File to Upload',
                    button: {
                        text: 'Select File'
                    },
                    multiple: false
                });
                
                frame.on('select', function() {
                    var attachment = frame.state().get('selection').first().toJSON();
                    urlField.val(attachment.url);
                    if (!nameField.val()) {
                        nameField.val(attachment.filename);
                    }
                    
                    // Update file preview
                    var filePreview = button.closest('.vrstore-product-file').find('.vrstore-file-preview');
                    if (filePreview.length) {
                        filePreview.remove();
                    }
                    
                    var preview = $('<div class="vrstore-file-preview"><small><strong>Current file:</strong> <a href="' + attachment.url + '" target="_blank">' + attachment.filename + '</a></small></div>');
                    button.closest('.vrstore-product-file').append(preview);
                });
                
                frame.open();
            });
            
            // Select from media button
            $(document).on('click', '.vrstore-select-media', function(e) {
                e.preventDefault();
                
                var button = $(this);
                var index = button.data('index');
                var urlField = $('input[name="vrstore_product_files[' + index + '][url]"]');
                var nameField = $('input[name="vrstore_product_files[' + index + '][name]"]');
                
                var frame = wp.media({
                    title: 'Select File from Media Library',
                    button: {
                        text: 'Select File'
                    },
                    multiple: false,
                    library: {
                        type: 'application'
                    }
                });
                
                frame.on('select', function() {
                    var attachment = frame.state().get('selection').first().toJSON();
                    urlField.val(attachment.url);
                    if (!nameField.val()) {
                        nameField.val(attachment.filename);
                    }
                    
                    // Update file preview
                    var filePreview = button.closest('.vrstore-product-file').find('.vrstore-file-preview');
                    if (filePreview.length) {
                        filePreview.remove();
                    }
                    
                    var preview = $('<div class="vrstore-file-preview"><small><strong>Current file:</strong> <a href="' + attachment.url + '" target="_blank">' + attachment.filename + '</a></small></div>');
                    button.closest('.vrstore-product-file').append(preview);
                });
                
                frame.open();
            });
            
            // Handle file type change
            $(document).on('change', '.vrstore-file-type', function() {
                var select = $(this);
                var fileRow = select.closest('.vrstore-product-file');
                var inputRow = fileRow.find('.vrstore-file-input-row');
                var urlInput = inputRow.find('.vrstore-file-url');
                var uploadBtn = inputRow.find('.vrstore-upload-file');
                var mediaBtn = inputRow.find('.vrstore-select-media');
                
                if (select.val() === 'url') {
                    urlInput.attr('placeholder', 'Enter external URL (e.g., https://drive.google.com/...)');
                    uploadBtn.hide();
                    mediaBtn.hide();
                } else {
                    urlInput.attr('placeholder', 'File URL will be populated when you select a file');
                    uploadBtn.show();
                    mediaBtn.show();
                }
            });
        },
        
        exportCoursesCSV: function() {
            var $button = $('#vrstore-export-courses-csv');
            
            if ($button.length === 0) {
                return;
            }
            
            var originalText = $button.text();
            
            // Set loading state
            $button.prop('disabled', true).text('Exporting...');
            
            // Check if required variables are available
            if (typeof ajaxurl === 'undefined') {
                $button.prop('disabled', false).text(originalText);
                return;
            }
            
            if (typeof vrstore_admin === 'undefined' || !vrstore_admin.nonce) {
                $button.prop('disabled', false).text(originalText);
                return;
            }
            
            // Make AJAX request
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'vrstore_export_courses_csv',
                    nonce: vrstore_admin.nonce
                },
                success: function(response) {
                    if (response.success) {
                        // Show success message
                        vrstoreReports.showExportMessage(response.data.message, 'success');
                        
                        // Trigger download if URL provided
                        if (response.data.download_url) {
                            vrstoreReports.downloadFile(response.data.download_url, response.data.filename);
                        }
                    } else {
                        vrstoreReports.showExportMessage('Export Error: ' + (response.data.message || 'Courses CSV export failed. Please try again.'), 'error');
                    }
                },
                error: function(xhr, status, error) {
                    vrstoreReports.showExportMessage('Export Error: Network error occurred. Please try again.', 'error');
                },
                complete: function() {
                    // Reset button state
                    $button.prop('disabled', false).text(originalText);
                }
            });
        },

        initGallerySelection: function() {

            
            // Handle Select Images button for Screenshots gallery
            $(document).on('click', '.vrstore-select-gallery', function(e) {
                e.preventDefault();
                
                var button = $(this);
                var targetField = button.data('target');
                var inputField = $('#' + targetField);
                
                if (!inputField.length) {
                    return;
                }
                
                // Create media frame for multiple image selection
                var frame = wp.media({
                    title: 'Select Images for Product Gallery',
                    button: {
                        text: 'Add to Gallery'
                    },
                    multiple: true,
                    library: {
                        type: 'image'
                    }
                });
                
                frame.on('select', function() {
                    var selection = frame.state().get('selection');
                    var attachmentIds = [];
                    
                    selection.each(function(attachment) {
                        attachmentIds.push(attachment.get('id'));
                    });
                    
                    if (attachmentIds.length > 0) {
                        // Update the input field with comma-separated IDs
                        inputField.val(attachmentIds.join(','));
                        
                        // Show a preview of selected images
                        var previewContainer = inputField.closest('td').find('.vrstore-gallery-preview');
                        if (!previewContainer.length) {
                            previewContainer = $('<div class="vrstore-gallery-preview" style="margin-top: 10px; display: flex; flex-wrap: wrap; gap: 5px;"></div>');
                            inputField.closest('td').append(previewContainer);
                        }
                        
                        previewContainer.empty();
                        
                        selection.each(function(attachment) {
                            var thumbnail = attachment.get('sizes') && attachment.get('sizes').thumbnail 
                                ? attachment.get('sizes').thumbnail.url 
                                : attachment.get('url');
                            
                            var preview = $('<div style="width: 60px; height: 60px; border: 1px solid #ddd; border-radius: 3px; overflow: hidden;">' +
                                '<img src="' + thumbnail + '" style="width: 100%; height: 100%; object-fit: cover;" title="' + attachment.get('title') + '" />' +
                                '</div>');
                            
                            previewContainer.append(preview);
                        });
                    }
                });
                
                frame.open();
            });
            
            // Clear gallery button
            $(document).on('click', '.vrstore-clear-gallery', function(e) {
                e.preventDefault();
                
                var button = $(this);
                var targetField = button.data('target');
                var inputField = $('#' + targetField);
                var previewContainer = inputField.closest('td').find('.vrstore-gallery-preview');
                
                inputField.val('');
                previewContainer.remove();
            });
        },

        initProductVideo: function() {

            
            // Video type change handler
            $(document).on('change', '#vrstore_product_video_type', function() {
                var videoType = $(this).val();
                
                // Hide all video input rows
                $('#youtube-url-row, #video-upload-row').hide();
                
                // Show relevant row based on selection
                if (videoType === 'youtube') {
                    $('#youtube-url-row').show();
                } else if (videoType === 'upload') {
                    $('#video-upload-row').show();
                }
            });
            
            // Upload video button
            $(document).on('click', '#vrstore-upload-video', function(e) {
                e.preventDefault();
                
                var button = $(this);
                var hiddenField = $('#vrstore_product_video_upload');
                var urlField = $('#vrstore_product_video_upload_url');
                var removeBtn = $('#vrstore-remove-video');
                
                var frame = wp.media({
                    title: 'Select Video File',
                    button: {
                        text: 'Select Video'
                    },
                    multiple: false,
                    library: {
                        type: 'video'
                    }
                });
                
                frame.on('select', function() {
                    var attachment = frame.state().get('selection').first().toJSON();
                    hiddenField.val(attachment.id);
                    urlField.val(attachment.url);
                    removeBtn.show();
                });
                
                frame.open();
            });
            
            // Remove video button
            $(document).on('click', '#vrstore-remove-video', function(e) {
                e.preventDefault();
                
                $('#vrstore_product_video_upload').val('');
                $('#vrstore_product_video_upload_url').val('');
                $(this).hide();
            });
            
            // Initialize video type visibility on page load
            $('#vrstore_product_video_type').trigger('change');
        },
        
        initDuplicateProduct: function() {
            // Handle duplicate product clicks (both buttons and row actions)
            $(document).on('click', '.vrstore-duplicate-product', function(e) {
                e.preventDefault();
                
                var $element = $(this);
                var productId = $element.data('product-id');
                var nonce = $element.data('nonce');
                var isLink = $element.is('a');
                var originalText = isLink ? $element.text() : $element.html();
                
                // Validation
                if (!productId) {
                    alert(vrstore_admin.duplicate_error || 'Error: Product ID is missing.');
                    return;
                }
                
                if (!nonce) {
                    alert(vrstore_admin.duplicate_error || 'Error: Security nonce is missing.');
                    return;
                }
                
                // Confirm duplication
                var confirmMessage = vrstore_admin.confirm_duplicate || 'Are you sure you want to duplicate this product?';
                if (!confirm(confirmMessage)) {
                    return;
                }
                
                // Check if AJAX URL is available
                var ajaxUrl = vrstore_admin.ajax_url || ajaxurl;
                if (typeof ajaxUrl === 'undefined') {
                    alert(vrstore_admin.duplicate_error || 'Error: AJAX URL is not available.');
                    return;
                }
                
                // Set loading state based on element type
                if (isLink) {
                    $element.text(vrstore_admin.duplicating || 'Duplicating...')
                           .css('pointer-events', 'none')
                           .addClass('processing');
                } else {
                    $element.prop('disabled', true)
                           .html('<span class="dashicons dashicons-update-alt" style="animation: spin 1s linear infinite; vertical-align: middle; margin-right: 3px;"></span>' + (vrstore_admin.duplicating || 'Duplicating...'));
                }
                
                // Make AJAX request
                $.ajax({
                    url: ajaxUrl,
                    type: 'POST',
                    data: {
                        action: 'vrstore_duplicate_product',
                        product_id: productId,
                        nonce: nonce
                    },
                    success: function(response) {
                        if (response && response.success) {
                            // Show success message
                            var message = response.data.message || vrstore_admin.duplicate_success || 'Product duplicated successfully!';
                            alert(message);
                            
                            // Always redirect back to the product list page after successful duplication
                            var productListUrl = 'edit.php?post_type=vrstore_product';
                            
                            // Check if we have the admin URL available
                            if (typeof vrstore_admin.admin_url !== 'undefined') {
                                productListUrl = vrstore_admin.admin_url + productListUrl;
                            } else if (window.location.href.indexOf('wp-admin') !== -1) {
                                // Extract admin URL from current location
                                var currentUrl = window.location.href;
                                var adminIndex = currentUrl.indexOf('wp-admin');
                                if (adminIndex !== -1) {
                                    var adminUrl = currentUrl.substring(0, adminIndex + 9); // Include 'wp-admin/'
                                    productListUrl = adminUrl + productListUrl;
                                }
                            }
                            
                            // Redirect to product list page
                            window.location.href = productListUrl;
                        } else {
                            var errorMsg = (response && response.data && response.data.message) 
                                ? response.data.message 
                                : (vrstore_admin.duplicate_error || 'Failed to duplicate product');
                            alert('Error: ' + errorMsg);
                            
                            // Reset element state
                            if (isLink) {
                                $element.text(originalText)
                                       .css('pointer-events', 'auto')
                                       .removeClass('processing');
                            } else {
                                $element.prop('disabled', false).html(originalText);
                            }
                        }
                    },
                    error: function(xhr, status, error) {
                        var errorMsg = vrstore_admin.duplicate_error || 'Network error occurred. Please try again.';
                        alert(errorMsg);
                        
                        // Reset element state
                        if (isLink) {
                            $element.text(originalText)
                                   .css('pointer-events', 'auto')
                                   .removeClass('processing');
                        } else {
                            $element.prop('disabled', false).html(originalText);
                        }
                    }
                });
            });
        },
        
        initReports: function() {
            // Only initialize on reports page
            if (!$('.vrstore-admin-page').length || !$('.vrstore-report-tab').length) {
                return;
            }
            
            this.initReportTabs();
            this.initReportCharts();
            this.initDateFilter();
            this.initCourseDataReset();
        },
        
        initCourseDataReset: function() {
            var self = this;
            
            // Show/hide reset options
            $(document).on('click', '#vrstore-reset-course-data, #vrstore-reset-all-course-data', function(e) {
                e.preventDefault();
                var $button = $(this);
                var $options = $('.vrstore-reset-options');
                
                if ($button.attr('id') === 'vrstore-reset-all-course-data') {
                    // Check all options for "Reset All"
                    $options.find('input[type="checkbox"]').prop('checked', true);
                }
                
                $options.slideToggle();
            });
            
            // Cancel reset
            $(document).on('click', '#vrstore-cancel-reset', function(e) {
                e.preventDefault();
                $('.vrstore-reset-options').slideUp();
            });
            
            // Confirm reset
            $(document).on('click', '#vrstore-confirm-reset', function(e) {
                e.preventDefault();
                
                var selectedOptions = [];
                $('.vrstore-reset-options input[type="checkbox"]:checked').each(function() {
                    selectedOptions.push($(this).attr('id'));
                });
                
                if (selectedOptions.length === 0) {
                    alert(vrstore_admin.no_options_selected || 'Please select at least one option to reset.');
                    return;
                }
                
                var confirmMessage = vrstore_admin.confirm_course_reset || 
                    'Are you sure you want to reset the selected course data? This action cannot be undone.';
                
                if (!confirm(confirmMessage)) {
                    return;
                }
                
                self.performCourseDataReset(selectedOptions);
            });
        },
        
        performCourseDataReset: function(options) {
            var $button = $('#vrstore-confirm-reset');
            var originalText = $button.text();
            
            // Set loading state
            $button.prop('disabled', true)
                   .html('<span class="dashicons dashicons-update-alt" style="animation: spin 1s linear infinite;"></span> ' + 
                         (vrstore_admin.resetting || 'Resetting...'));
            
            $.ajax({
                url: vrstore_admin.ajax_url || ajaxurl,
                type: 'POST',
                data: {
                    action: 'vrstore_reset_course_data',
                    reset_options: options,
                    nonce: vrstore_admin.course_reset_nonce || vrstore_admin.nonce || ''
                },
                success: function(response) {
                    if (response && response.success) {
                        alert(response.data.message || vrstore_admin.reset_success || 'Course data reset successfully!');
                        $('.vrstore-reset-options').slideUp();
                        
                        // Optionally reload the page to refresh data
                        if (response.data.reload) {
                            window.location.reload();
                        }
                    } else {
                        var errorMsg = (response && response.data && response.data.message) 
                            ? response.data.message 
                            : (vrstore_admin.reset_error || 'Failed to reset course data');
                        alert('Error: ' + errorMsg);
                    }
                },
                error: function(xhr, status, error) {
                    alert(vrstore_admin.reset_error || 'Network error occurred. Please try again.');
                },
                complete: function() {
                    // Reset button state
                    $button.prop('disabled', false).text(originalText);
                }
            });
        },
        
        initReportTabs: function() {
            // Tab switching functionality without page reload
            $('.nav-tab').on('click', function(e) {
                e.preventDefault();
                var targetTab = $(this).data('tab');
                
                // Update active tab
                $('.nav-tab').removeClass('nav-tab-active');
                $(this).addClass('nav-tab-active');
                
                // Show/hide tab content
                $('.vrstore-report-tab').removeClass('active').hide();
                $('#' + targetTab).addClass('active').show();
                
                // Update URL without reload
                if (history.pushState) {
                    var currentUrl = new URL(window.location.href);
                    currentUrl.searchParams.set('tab', targetTab);
                    history.pushState(null, '', currentUrl.toString());
                }
            });
            
            // Handle browser back/forward buttons
            $(window).on('popstate', function(e) {
                var urlParams = new URLSearchParams(window.location.search);
                var tab = urlParams.get('tab') || 'sales-report';
                
                $('.nav-tab').removeClass('nav-tab-active');
                $('.nav-tab[data-tab="' + tab + '"]').addClass('nav-tab-active');
                $('.vrstore-report-tab').removeClass('active').hide();
                $('#' + tab).addClass('active').show();
            });
            
            // Initialize the correct tab on page load
            var urlParams = new URLSearchParams(window.location.search);
            var currentTab = urlParams.get('tab') || 'sales-report';
            $('.vrstore-report-tab').removeClass('active').hide();
            $('#' + currentTab).addClass('active').show();
        },
        
        initReportCharts: function() {
            // Chart initialization is now handled by vrstoreReports object
            // This function is kept for backwards compatibility but does nothing
        },
        
        initDateFilter: function() {
            // Initialize date filter functionality
            $('#apply-date-filter').on('click', function() {
                var dateFrom = $('#date-from').val();
                var dateTo = $('#date-to').val();
                
                if (dateFrom && dateTo) {
                    var currentUrl = new URL(window.location.href);
                    currentUrl.searchParams.set('date_from', dateFrom);
                    currentUrl.searchParams.set('date_to', dateTo);
                    window.location.href = currentUrl.toString();
                }
            });
        },

        /**
         * Initialize Orders Page functionality
         */
        initOrdersPage: function() {
            // Handle CSV export button
            $(document).on('click', '#export-orders-csv', function(e) {
                e.preventDefault();
                
                var $button = $(this);
                var originalText = $button.html();
                
                // Show loading state
                $button.prop('disabled', true).html('<span class="dashicons dashicons-update-alt" style="animation: spin 1s linear infinite; vertical-align: middle; margin-right: 5px;"></span>Exporting...');
                
                // Make AJAX request
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'vrstore_export_orders_csv',
                        nonce: vrstore_admin.nonce
                    },
                    success: function(response) {
                        if (response.success) {
                            // Create temporary download link
                            var link = document.createElement('a');
                            link.href = response.data.download_url;
                            link.download = response.data.filename;
                            document.body.appendChild(link);
                            link.click();
                            document.body.removeChild(link);
                            
                            // Show success message
                            if (typeof vrstoreAdmin.showNotice === 'function') {
                                vrstoreAdmin.showNotice(response.data.message, 'success');
                            } else {
                                alert(response.data.message);
                            }
                        } else {
                            // Show error message
                            var errorMessage = response.data && response.data.message ? 
                                response.data.message : 'Export failed. Please try again.';
                            if (typeof vrstoreAdmin.showNotice === 'function') {
                                vrstoreAdmin.showNotice(errorMessage, 'error');
                            } else {
                                alert(errorMessage);
                            }
                        }
                    },
                    error: function(xhr, status, error) {
                        var errorMessage = 'Export failed due to a network error. Please try again.';
                        if (typeof vrstoreAdmin.showNotice === 'function') {
                            vrstoreAdmin.showNotice(errorMessage, 'error');
                        } else {
                            alert(errorMessage);
                        }
                    },
                    complete: function() {
                        // Restore button state
                        $button.prop('disabled', false).html(originalText);
                    }
                });
            });

            // Handle bulk actions dropdown
            $(document).on('change', '#bulk-action-selector-top', function() {
                var selectedAction = $(this).val();
                if (selectedAction) {
                    $('#bulk-action-hidden').val(selectedAction);
                }
            });

            // Handle "Select All" checkbox
            $(document).on('change', '#cb-select-all-1', function() {
                var isChecked = $(this).prop('checked');
                $('input[name="order_ids[]"]').prop('checked', isChecked);
                $('input[name="affiliate[]"]').prop('checked', isChecked);
            });

            // Handle individual checkboxes
            $(document).on('change', 'input[name="order_ids[]"], input[name="affiliate[]"]', function() {
                var orderCheckboxes = $('input[name="order_ids[]"]');
                var affiliateCheckboxes = $('input[name="affiliate[]"]');
                
                if (orderCheckboxes.length > 0) {
                    var totalOrderCheckboxes = orderCheckboxes.length;
                    var checkedOrderCheckboxes = orderCheckboxes.filter(':checked').length;
                    $('#cb-select-all-1').prop('checked', totalOrderCheckboxes === checkedOrderCheckboxes);
                } else if (affiliateCheckboxes.length > 0) {
                    var totalAffiliateCheckboxes = affiliateCheckboxes.length;
                    var checkedAffiliateCheckboxes = affiliateCheckboxes.filter(':checked').length;
                    $('#cb-select-all-1').prop('checked', totalAffiliateCheckboxes === checkedAffiliateCheckboxes);
                }
            });

            // Handle bulk action apply button
            $(document).on('click', '#doaction', function(e) {
                var selectedAction = $('#bulk-action-selector-top').val();
                var checkedOrders = $('input[name="order_ids[]"]:checked');
                var checkedAffiliates = $('input[name="affiliate[]"]:checked');
                
                if (!selectedAction || selectedAction === '-1') {
                    e.preventDefault();
                    alert(vrstoreAdmin.i18n.selectBulkAction || 'Please select a bulk action.');
                    return false;
                }
                
                // Check if we're on orders page or affiliates page
                if (checkedOrders.length === 0 && checkedAffiliates.length === 0) {
                    e.preventDefault();
                    var message = checkedOrders.length >= 0 ? 
                        (vrstoreAdmin.i18n.selectOrders || 'Please select at least one order.') :
                        (vrstoreAdmin.i18n.selectAffiliates || 'Please select at least one affiliate.');
                    alert(message);
                    return false;
                }
                
                // Confirm delete action
                if (selectedAction === 'delete') {
                    var confirmMessage = checkedOrders.length > 0 ?
                        (vrstoreAdmin.i18n.confirmDelete || 'Are you sure you want to delete the selected orders? This action cannot be undone.') :
                        (vrstoreAdmin.i18n.confirmDeleteAffiliates || 'Are you sure you want to delete the selected affiliates? This action cannot be undone.');
                    if (!confirm(confirmMessage)) {
                        e.preventDefault();
                        return false;
                    }
                }
                
                // Set the bulk action and submit form for orders
                if (checkedOrders.length > 0) {
                    $('#bulk-action-hidden').val(selectedAction);
                    $('#vrstore-orders-table-form').submit();
                }
                // For affiliates, the form will submit naturally since we don't prevent default
            });

            // Handle CSV export button
            $(document).on('click', '#export-csv-btn', function(e) {
                e.preventDefault();
                
                // Create a temporary form for CSV export
                var form = $('<form>', {
                    method: 'POST',
                    action: window.location.href
                });
                
                // Add nonce field
                form.append($('<input>', {
                    type: 'hidden',
                    name: 'vrstore_bulk_nonce',
                    value: $('#vrstore_bulk_nonce').val()
                }));
                
                // Add export CSV flag
                form.append($('<input>', {
                    type: 'hidden',
                    name: 'export_csv',
                    value: '1'
                }));
                
                // Add current filters
                var currentStatus = $('select[name="status"]').val();
                var currentSearch = $('input[name="search"]').val();
                
                if (currentStatus) {
                    form.append($('<input>', {
                        type: 'hidden',
                        name: 'status',
                        value: currentStatus
                    }));
                }
                
                if (currentSearch) {
                    form.append($('<input>', {
                        type: 'hidden',
                        name: 'search',
                        value: currentSearch
                    }));
                }
                
                // Submit form
                form.appendTo('body').submit().remove();
            });
        },

        // License availability toggle functionality (moved from class-product.php)
        initLicenseAvailability: function() {
            // Handle license availability checkbox changes
            $(document).on("change", ".license-availability-checkbox", function() {
                var licenseSlug = $(this).data("license-slug");
                var isChecked = $(this).is(":checked");
                var licenseGroup = $(".license-pricing-group[data-license-slug=\"" + licenseSlug + "\"]");
                var priceInputs = licenseGroup.find(".license-price-input");
                
                if (isChecked) {
                    // Enable the license type
                    licenseGroup.css("opacity", "1");
                    priceInputs.prop("disabled", false);
                } else {
                    // Disable the license type
                    licenseGroup.css("opacity", "0.6");
                    priceInputs.prop("disabled", true);
                }
            });
            
            // Initialize availability states on page load
            $(".license-availability-checkbox").each(function() {
                var licenseSlug = $(this).data("license-slug");
                var isChecked = $(this).is(":checked");
                var licenseGroup = $(".license-pricing-group[data-license-slug=\"" + licenseSlug + "\"]");
                var priceInputs = licenseGroup.find(".license-price-input");
                
                if (!isChecked) {
                    licenseGroup.css("opacity", "0.6");
                    priceInputs.prop("disabled", true);
                }
            });
        },

        // Product visibility functionality (moved from class-product.php)
        initProductVisibility: function() {
            // Handle visibility edit link click
            $('.edit-visibility').on('click', function(e) {
                e.preventDefault();
                $('#vrstore-visibility-select').slideDown('fast');
                $(this).hide();
            });
            
            // Handle visibility cancel
            $('.cancel-post-visibility').on('click', function(e) {
                e.preventDefault();
                $('#vrstore-visibility-select').slideUp('fast');
                $('.edit-visibility').show();
            });
            
            // Handle visibility save
            $('.save-post-visibility').on('click', function(e) {
                e.preventDefault();
                
                var selectedVisibility = $('input[name="vrstore_product_visibility"]:checked').val();
                var visibilityLabel = $('input[name="vrstore_product_visibility"]:checked').next('label').text();
                
                // Show password field if password is selected
                if (selectedVisibility === 'password') {
                    $('#vrstore-password-span').show();
                } else {
                    $('#vrstore-password-span').hide();
                }
                
                // Update display
                $('#vrstore-visibility-display').text(visibilityLabel);
                $('#vrstore-visibility-select').slideUp('fast');
                $('.edit-visibility').show();
            });
            
            // Handle password visibility radio selection
            $('input[name="vrstore_product_visibility"]').on('change', function() {
                if ($(this).val() === 'password') {
                    $('#vrstore-password-span').show();
                } else {
                    $('#vrstore-password-span').hide();
                }
            });
        },

        initProductTabs: function() {
            var $wrappers = $('.vrstore-product-tab-wrapper');

            if (!$wrappers.length) {
                return;
            }

            $wrappers.each(function() {
                var $wrapper = $(this);
                var defaultTab = $wrapper.data('default-tab');
                var $buttons = $wrapper.find('.vrstore-tab-button');
                var $panels = $wrapper.find('.vrstore-tab-panel');

                if (!$buttons.filter('.is-active').length && defaultTab) {
                    $buttons.filter('[data-tab-target="' + defaultTab + '"]').addClass('is-active');
                    $panels.removeClass('is-active');
                    $panels.filter('[data-tab="' + defaultTab + '"]').addClass('is-active');
                }
            });

            $(document).off('click.vrstoreTabs', '.vrstore-tab-button').on('click.vrstoreTabs', '.vrstore-tab-button', function(e) {
                e.preventDefault();

                var $button = $(this);
                var target = $button.data('tab-target');
                var $wrapper = $button.closest('.vrstore-product-tab-wrapper');
                var $panels = $wrapper.find('.vrstore-tab-panel');

                $wrapper.find('.vrstore-tab-button').removeClass('is-active');
                $button.addClass('is-active');

                $panels.removeClass('is-active');
                $panels.filter('[data-tab="' + target + '"]').addClass('is-active');
            });
        },

        // Plugin updates functionality (moved from class-product.php)
        initPluginUpdates: function() {
            // Toggle plugin fields visibility
            $('#vrstore_is_plugin_product').on('change', function() {
                if ($(this).is(':checked')) {
                    $('.vrstore-plugin-field').show();
                } else {
                    $('.vrstore-plugin-field').hide();
                }
            });

            // Add new version functionality
            $('#vrstore-add-plugin-version').on('click', function() {
                var timestamp = Date.now();
                var versionHtml = '<div class="vrstore-plugin-version-item" style="border: 1px solid #ddd; padding: 15px; margin: 10px 0; background: #f9f9f9;">';
                versionHtml += '<table class="form-table">';
                versionHtml += '<tr><th><label>Version Number</label></th><td><input type="text" name="vrstore_plugin_versions[new_' + timestamp + '][version]" class="regular-text" placeholder="1.0.1" /></td></tr>';
                versionHtml += '<tr><th><label>File</label></th><td><input type="file" name="vrstore_plugin_version_files[new_' + timestamp + ']" accept=".zip" /></td></tr>';
                versionHtml += '<tr><th><label>Changelog</label></th><td><textarea name="vrstore_plugin_versions[new_' + timestamp + '][changelog]" rows="3" class="large-text" placeholder="- Bug fixes\n- New features"></textarea></td></tr>';
                versionHtml += '<tr><th><label>License Tiers</label></th><td>';
                
                // Add license tier checkboxes - get from global data if available
                if (typeof vrstore_admin.license_types !== 'undefined' && vrstore_admin.license_types.length > 0) {
                    for (var i = 0; i < vrstore_admin.license_types.length; i++) {
                        var licenseType = vrstore_admin.license_types[i];
                        versionHtml += '<label><input type="checkbox" name="vrstore_plugin_versions[new_' + timestamp + '][license_tiers][]" value="' + licenseType.slug + '" /> ' + licenseType.name + '</label><br>';
                    }
                } else {
                    versionHtml += '<p style="color: #d63638;">No license types configured. Please configure custom license types in Settings > License to enable license tier access control.</p>';
                }
                
                versionHtml += '</td></tr>';
                versionHtml += '</table>';
                versionHtml += '<button type="button" class="button vrstore-remove-version" style="color: #d63638;">Remove Version</button>';
                versionHtml += '</div>';
                
                $('#vrstore-plugin-versions-list').append(versionHtml);
            });

            // Remove plugin version functionality (handles both new and existing versions)
            $(document).on('click', '.vrstore-remove-version', function() {
                var $button = $(this);
                var versionId = $button.data('version-id');
                
                // If it's an existing version, confirm deletion
                if (versionId) {
                    var confirmMessage = vrstore_admin.confirm_delete_version || 'Are you sure you want to remove this version? This action cannot be undone.';
                    if (!confirm(confirmMessage)) {
                        return;
                    }
                }
                
                $button.closest('.vrstore-plugin-version-item').remove();
            });

            // Legacy support for old class name
            $(document).on('click', '.vrstore-remove-plugin-version', function() {
                $(this).closest('.vrstore-plugin-version-item').remove();
            });
        },

        // Currency Management functionality - placeholder function
        initCurrencyManagement: function() {
            // Currency management functionality can be added here when needed
            // This function exists to prevent the "initCurrencyManagement is not a function" error
        }

    };

    var vrstoreDocumentation = {
        init: function() {
            this.bindEvents();
            this.handleInitialHash();
        },
        
        bindEvents: function() {
            // Handle navigation clicks
            $('.vrstore-doc-nav a').on('click', this.handleNavClick);
            
            // Handle scroll to update active nav
            $('.vrstore-documentation-content').on('scroll', this.handleScroll);
        },
        
        handleNavClick: function(e) {
            e.preventDefault();
            
            var target = $(this).attr('href');
            var targetElement = $(target);
            
            if (targetElement.length) {
                // Update active state
                $('.vrstore-doc-nav a').removeClass('active');
                $(this).addClass('active');
                
                // Scroll to section
                $('.vrstore-documentation-content').animate({
                    scrollTop: targetElement.offset().top - 
                              $('.vrstore-documentation-content').offset().top + 
                              $('.vrstore-documentation-content').scrollTop() - 20
                }, 500);
            }
        },
        
        handleScroll: function() {
            var scrollTop = $(this).scrollTop();
            var sections = $('.vrstore-doc-section');
            var navLinks = $('.vrstore-doc-nav a');
            
            sections.each(function() {
                var section = $(this);
                var sectionTop = section.position().top;
                var sectionBottom = sectionTop + section.outerHeight();
                
                if (scrollTop >= sectionTop - 50 && scrollTop < sectionBottom - 50) {
                    var id = section.attr('id');
                    navLinks.removeClass('active');
                    $('.vrstore-doc-nav a[href="#' + id + '"]').addClass('active');
                    return false;
                }
            });
        },
        
        handleInitialHash: function() {
            if (window.location.hash) {
                var hash = window.location.hash;
                var targetElement = $(hash);
                
                if (targetElement.length) {
                    // Update active state
                    $('.vrstore-doc-nav a').removeClass('active');
                    $('.vrstore-doc-nav a[href="' + hash + '"]').addClass('active');
                    
                    // Scroll to section after a short delay to ensure DOM is ready
                    setTimeout(function() {
                        $('.vrstore-documentation-content').animate({
                            scrollTop: targetElement.offset().top - 
                                      $('.vrstore-documentation-content').offset().top + 
                                      $('.vrstore-documentation-content').scrollTop() - 20
                        }, 500);
                    }, 100);
                }
            }
        }
    };

    var vrstoreReports = {
        init: function() {
            // Get data from JSON script tag
            var dataScript = document.getElementById('vrstore-reports-data');
            if (dataScript) {
                try {
                    window.vrstoreReportsData = JSON.parse(dataScript.textContent);
                } catch (e) {
                    console.error('Error parsing reports data:', e);
                    return;
                }
            }
            
            this.bindEvents();
            
            // Check which tab is currently active based on URL
            var urlParams = new URLSearchParams(window.location.search);
            var activeTab = urlParams.get('tab') || 'sales-report';
            
            this.initializeCharts(activeTab);
            this.initializeFilters();
            this.initializeCSVExports();
            
            // Initialize certification downloads if on courses tab
            if (activeTab === 'courses-report') {
                this.initCertificationDownloads();
                this.initCertificationDownloadsTab();
            }
        },
        
        bindEvents: function() {
            var self = this;
            
            // Tab switching
            $('.nav-tab').on('click', this.handleTabClick);
            
            // Courses CSV export
            $(document).on('click', '#vrstore-export-courses-csv', function(e) {
                e.preventDefault();
                console.log('Courses CSV export button clicked from vrstoreReports');
                self.exportCoursesCSV();
            });
        },
        
        handleTabClick: function(e) {
            e.preventDefault();
            
            var targetTab = $(this).data('tab');
            
            // Update active states
            $('.nav-tab').removeClass('nav-tab-active');
            $(this).addClass('nav-tab-active');
            
            // Show/hide tab content
            $('.vrstore-report-tab').hide();
            $('#' + targetTab).show();
            
            // Initialize charts for the active tab
            vrstoreReports.initializeCharts(targetTab);
            
            // Initialize certification downloads for download-monitor tab
            if (targetTab === 'download-monitor') {
                vrstoreReports.initCertificationDownloadsTab();
            }
        },
        
        initializeCharts: function(activeTab) {
            if (typeof Chart === 'undefined') {
                return;
            }
            
            // Always clean up any existing chart instances first
            this.destroyAllCharts();
            
            if (activeTab === 'sales-report') {
                this.initializeSalesChart();
            } else if (activeTab === 'products-report') {
                // Products now use simple stats cards instead of charts
            } else if (activeTab === 'customers-report') {
                // Payment methods now use CSS visualization instead of Chart.js
            } else if (activeTab === 'download-monitor') {
                this.initializeDownloadMonitor();
                this.initCertificationDownloadsTab();
            }
        },
        
        destroyAllCharts: function() {
            // Destroy salesChart instances
            if (window.salesChartInstance && typeof window.salesChartInstance.destroy === 'function') {
                window.salesChartInstance.destroy();
                window.salesChartInstance = null;
            }
            
            // Destroy any charts tracked by Chart.js registry
            if (Chart.getChart) {
                var salesChart = Chart.getChart('salesChart');
                if (salesChart) {
                    salesChart.destroy();
                }
            }
        },
        
        exportCoursesCSV: function() {
            var $button = $('#vrstore-export-courses-csv');
            var originalText = $button.text();
            
            // Set loading state
            $button.prop('disabled', true).text('Exporting...');
            
            // Make AJAX request
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'vrstore_export_courses_csv',
                    nonce: vrstore_admin.nonce
                },
                success: function(response) {
                    if (response.success) {
                        // Show success message
                        vrstoreReports.showExportMessage(response.data.message, 'success');
                        
                        // Trigger download if URL provided
                        if (response.data.download_url) {
                            vrstoreReports.downloadFile(response.data.download_url, response.data.filename);
                        }
                    } else {
                        vrstoreReports.showExportMessage('Export Error: ' + (response.data.message || 'Courses CSV export failed. Please try again.'), 'error');
                    }
                },
                error: function(xhr, status, error) {
                    vrstoreReports.showExportMessage('Export Error: Network error occurred. Please try again.', 'error');
                },
                complete: function() {
                    // Reset button state
                    $button.prop('disabled', false).text(originalText);
                }
            });
        },
        
        initializeSalesChart: function() {
            var ctx = document.getElementById('salesChart');
            if (!ctx || !window.vrstoreReportsData) return;
            
            var salesData = window.vrstoreReportsData.dailySales;
            var currency = window.vrstoreReportsData.currency;
            
            // Store chart instance globally for proper cleanup
            window.salesChartInstance = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: salesData.map(function(item) {
                        return new Date(item.date).toLocaleDateString();
                    }),
                    datasets: [{
                        label: window.vrstoreReportsData.strings.sales,
                        data: salesData.map(function(item) {
                            return parseFloat(item.sales);
                        }),
                        borderColor: '#0073aa',
                        backgroundColor: 'rgba(0, 115, 170, 0.1)',
                        tension: 0.1
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        title: {
                            display: true,
                            text: window.vrstoreReportsData.strings.dailySales
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: function(value) {
                                    return vrstoreReports.formatCurrency(value, currency);
                                }
                            }
                        }
                    }
                }
            });
        },
        
        // Products chart removed - now using simple stats cards
        
        formatCurrency: function(value, currency) {
            var symbol = this.getCurrencySymbol(currency.symbol);
            var numValue = parseFloat(value);
            var formatted;
            
            // Apply K/M formatting for large numbers
            if (numValue >= 1000000) {
                // Millions
                var millions = numValue / 1000000;
                var formattedMillions = millions.toFixed(2).replace(/\.?0+$/, ''); // Remove trailing zeros
                formatted = formattedMillions + 'M';
            } else if (numValue >= 1000) {
                // Thousands
                var thousands = numValue / 1000;
                var formattedThousands = thousands.toFixed(2).replace(/\.?0+$/, ''); // Remove trailing zeros
                formatted = formattedThousands + 'K';
            } else {
                // Regular formatting for amounts less than 1000
                formatted = numValue.toFixed(2);
            }
            
            switch(currency.position) {
                case 'right':
                    return formatted + symbol;
                case 'left_space':
                    return symbol + ' ' + formatted;
                case 'right_space':
                    return formatted + ' ' + symbol;
                case 'left':
                default:
                    return symbol + formatted;
            }
        },
        
        getCurrencySymbol: function(code) {
            var symbols = {
                'USD': '$',
                'EUR': '€',
                'GBP': '£',
                'JPY': '¥',
                'IDR': 'Rp',
                'AUD': '$',
                'BRL': 'R$',
                'CAD': '$',
                'CNY': '¥',
                'HKD': '$',
                'INR': '₹',
                'MXN': '$',
                'MYR': 'RM',
                'NZD': '$',
                'PHP': '₱',
                'SGD': '$',
                'THB': '฿',
                'VND': '₫',
                'ZAR': 'R'
            };
            return symbols[code] || code;
        },
        
        initializeDownloadMonitor: function() {
            // Download monitor functionality
            this.initializeDownloadFilters();
            this.initializeDownloadModals();
        },
        
        initializeDownloadFilters: function() {
            var self = this;
            
            // Filter functionality
            $('#apply-download-filter').on('click', function() {
                self.applyDownloadFilters();
            });
            
            $('#reset-download-filter').on('click', function() {
                self.resetDownloadFilters();
            });
            
            // Export functionality
            $('#export-download-data').on('click', function() {
                self.exportDownloadData();
            });
            
            // Clear all downloads functionality
            $('#clear-all-downloads').on('click', function() {
                self.clearAllDownloadData();
            });
            
            // Apply filters on Enter key
            $('.vrstore-download-filters input, .vrstore-download-filters select').on('keypress', function(e) {
                if (e.which === 13) {
                    self.applyDownloadFilters();
                }
            });
            
            // Update active filters display
            self.updateActiveFiltersDisplay();
            
            // Auto-refresh functionality (optional)
            var autoRefresh = localStorage.getItem('vrstore_downloads_auto_refresh');
            if (autoRefresh === 'true') {
                setTimeout(function() {
                    location.reload();
                }, 30000); // 30 seconds
            }
            
            // Add auto-refresh toggle
            var refreshToggle = $(
                '<label style="margin-left: 15px; font-size: 12px;">' +
                '<input type="checkbox" id="auto-refresh-toggle" ' + (autoRefresh === 'true' ? 'checked' : '') + '>' +
                'Auto-refresh (30s)' +
                '</label>'
            );
            
            if ($('.filter-actions').length > 0) {
                $('.filter-actions').append(refreshToggle);
                
                $('#auto-refresh-toggle').on('change', function() {
                    localStorage.setItem('vrstore_downloads_auto_refresh', this.checked);
                    if (this.checked) {
                        setTimeout(function() {
                            location.reload();
                        }, 30000);
                    }
                });
            }
        },
        
        initializeDownloadModals: function() {
            var self = this;
            
            // Download details modal functionality using event delegation
            $(document).on('click', '.view-download-details', function() {
                var productId = $(this).data('product-id');
                var orderId = $(this).data('order-id');
                var customerEmail = $(this).data('customer-email');
                
                self.showDownloadDetailsModal(productId, orderId, customerEmail);
            });
            
            // Close modal functionality
            $(document).on('click', '.vrstore-modal-close', function(e) {
                e.preventDefault();
                e.stopPropagation();
                self.closeDownloadDetailsModal();
            });
            
            // Close modal on overlay click
            $(document).on('click', '#download-details-modal', function(e) {
                if (e.target === this) {
                    self.closeDownloadDetailsModal();
                }
            });
            
            // Close modal on escape key
            $(document).on('keydown', function(e) {
                if (e.keyCode === 27) { // Escape key
                    self.closeDownloadDetailsModal();
                }
            });
        },
        
        applyDownloadFilters: function() {
            var filters = {};
            
            // Get all filter values
            var dateFrom = $('#download-date-from').val();
            var dateTo = $('#download-date-to').val();
            var downloadType = $('#download-type-filter').val();
            var fileType = $('#file-type-filter').val();
            var productId = $('#product-filter').val();
            var customerEmail = $('#user-filter').val();
            var ipAddress = $('#ip-filter').val();
            var perPage = $('#per-page-filter').val();
            
            // Build query parameters
            if (dateFrom) filters.date_from = dateFrom;
            if (dateTo) filters.date_to = dateTo;
            if (downloadType) filters.download_type = downloadType;
            if (fileType) filters.file_type = fileType;
            if (productId) filters.product_id = productId;
            if (customerEmail) filters.customer_email = customerEmail;
            if (ipAddress) filters.ip_address = ipAddress;
            if (perPage && perPage !== '20') filters.per_page = perPage;
            
            // Add current page and tab
            filters.page = 'vrstore-reports';
            filters.tab = 'download-monitor';
            
            // Redirect with filters
            var url = new URL(window.location.href.split('?')[0]);
            Object.keys(filters).forEach(function(key) {
                url.searchParams.set(key, filters[key]);
            });
            
            window.location.href = url.toString();
        },
        
        resetDownloadFilters: function() {
            // Redirect to clean URL
            var baseUrl = window.location.href.split('?')[0];
            window.location.href = baseUrl + '?page=vrstore-reports&tab=download-monitor';
        },
        
        updateActiveFiltersDisplay: function() {
            var activeFilters = [];
            var urlParams = new URLSearchParams(window.location.search);
            
            // Check each filter type
            if (urlParams.get('date_from')) {
                activeFilters.push('From: ' + urlParams.get('date_from'));
            }
            if (urlParams.get('date_to')) {
                activeFilters.push('To: ' + urlParams.get('date_to'));
            }
            if (urlParams.get('download_type')) {
                var type = urlParams.get('download_type');
                activeFilters.push('Type: ' + (type === 'single' ? 'Single File' : 'Multiple Files'));
            }
            if (urlParams.get('file_type')) {
                var type = urlParams.get('file_type');
                activeFilters.push('File: ' + (type === 'upload' ? 'Uploaded' : 'External URL'));
            }
            if (urlParams.get('product_id')) {
                var productName = $('#product-filter option:selected').text();
                if (productName && productName !== 'All Products') {
                    activeFilters.push('Product: ' + productName);
                }
            }
            if (urlParams.get('customer_email')) {
                activeFilters.push('Email: ' + urlParams.get('customer_email'));
            }
            if (urlParams.get('ip_address')) {
                activeFilters.push('IP: ' + urlParams.get('ip_address'));
            }
            if (urlParams.get('per_page') && urlParams.get('per_page') !== '20') {
                activeFilters.push('Show: ' + urlParams.get('per_page') + ' records');
            }
            
            var $activeFilters = $('#active-filters');
            var $activeFiltersList = $('#active-filters-list');
            
            if ($activeFilters.length && $activeFiltersList.length) {
                if (activeFilters.length > 0) {
                    $activeFilters.show();
                    $activeFiltersList.html(activeFilters.map(function(filter) {
                        return '<span style="display: inline-block; background: #0073aa; color: white; padding: 3px 8px; margin: 2px; border-radius: 3px; font-size: 11px;">' + filter + '</span>';
                    }).join(''));
                } else {
                    $activeFilters.hide();
                }
            }
        },
        
        exportDownloadData: function() {
            var filters = {};
            var urlParams = new URLSearchParams(window.location.search);
            
            // Get current filters
            ['date_from', 'date_to', 'download_type', 'file_type', 'product_id', 'customer_email', 'ip_address'].forEach(function(param) {
                if (urlParams.get(param)) {
                    filters[param] = urlParams.get(param);
                }
            });
            
            // Add export parameter
            filters.action = 'vrstore_export_downloads';
            filters.nonce = typeof vrstore_admin_nonce !== 'undefined' ? vrstore_admin_nonce : '';
            
            // Create form and submit
            var form = $('<form>', {
                method: 'POST',
                action: ajaxurl,
                target: '_blank'
            });
            
            Object.keys(filters).forEach(function(key) {
                form.append($('<input>', {
                    type: 'hidden',
                    name: key,
                    value: filters[key]
                }));
            });
            
            $('body').append(form);
            form.submit();
            form.remove();
        },
        
        clearAllDownloadData: function() {
            // Show confirmation dialog
            var confirmed = confirm(
                'Are you sure you want to clear ALL download tracking data?\n\n' +
                'This action will permanently delete:\n' +
                '• All download tracking records\n' +
                '• All download validation data\n\n' +
                'This action cannot be undone. Continue?'
            );
            
            if (!confirmed) {
                return;
            }
            
            // Show loading state
            var $button = $('#clear-all-downloads');
            var originalText = $button.html();
            $button.prop('disabled', true).html('<span class="dashicons dashicons-update-alt" style="vertical-align: middle; margin-right: 5px; animation: spin 1s linear infinite;"></span>Clearing Data...');
            
            // Make AJAX request
            $.post(ajaxurl, {
                action: 'vrstore_clear_all_downloads',
                nonce: vrstore_admin.nonce || ''
            })
            .done(function(response) {
                if (response.success) {
                    alert('All download tracking data has been cleared successfully!');
                    
                    // Reload the page to show updated statistics
                    window.location.reload();
                } else {
                    alert('Error: ' + (response.data && response.data.message ? response.data.message : 'Unknown error occurred'));
                }
            })
            .fail(function() {
                alert('Request failed. Please try again.');
            })
            .always(function() {
                // Restore button state
                $button.prop('disabled', false).html(originalText);
            });
        },
        
        showDownloadDetailsModal: function(productId, orderId, customerEmail) {
            var $modal = $('#download-details-modal');
            var $loading = $('#modal-loading');
            var $content = $('#modal-content');
            var $title = $('#modal-title');
            
            if ($modal.length === 0) {
                return;
            }
            
            // Show modal with unified system
            $modal.show().addClass('vrstore-modal-visible');
            $('body').addClass('vrstore-modal-open');
            if ($loading.length > 0) $loading.show();
            if ($content.length > 0) $content.hide();
            
            // Make AJAX request to get detailed download information
            $.post(ajaxurl, {
                action: 'vrstore_get_download_details',
                product_id: productId,
                order_id: orderId,
                customer_email: customerEmail,
                nonce: vrstore_admin.nonce || ''
            })
            .done(function(response) {
                if (response.success) {
                    if ($content.length > 0) $content.html(response.data.html || '');
                    if ($title.length > 0) $title.text(response.data.title || 'Download Details');
                    if ($loading.length > 0) $loading.hide();
                    if ($content.length > 0) $content.show();
                } else {
                    var errorMsg = response.data && response.data.message ? response.data.message : 'Failed to load download details';
                    if ($content.length > 0) $content.html('<div class="notice notice-error"><p>' + errorMsg + '</p></div>');
                    if ($loading.length > 0) $loading.hide();
                    if ($content.length > 0) $content.show();
                }
            })
            .fail(function() {
                if ($content.length > 0) $content.html('<div class="notice notice-error"><p>Failed to load download details. Please try again.</p></div>');
                if ($loading.length > 0) $loading.hide();
                if ($content.length > 0) $content.show();
            });
        },
        
        closeDownloadDetailsModal: function() {
            var $modal = $('#download-details-modal');
            if ($modal.length > 0) {
                $modal.removeClass('vrstore-modal-visible');
                $('body').removeClass('vrstore-modal-open');
                
                // Clear modal content to prevent scrollbar issues
                setTimeout(function() {
                    $modal.hide();
                    $('#modal-content').empty();
                    $('#modal-loading').show();
                }, 200);
            }
        },
        
        initializeFilters: function() {
            var self = this;
            
            // Sales date filter
            $('#apply-date-filter').on('click', function(e) {
                e.preventDefault();
                self.applySalesDateFilter();
            });
            
            // Allow Enter key to trigger filter
            $('#start_date, #end_date').on('keypress', function(e) {
                if (e.which === 13) {
                    self.applySalesDateFilter();
                }
            });
            
            // CSV export handlers
            this.initializeCSVExports();
        },
        
        applySalesDateFilter: function() {
            var dateFrom = $('#start_date').val();
            var dateTo = $('#end_date').val();
            
            if (!dateFrom || !dateTo) {
                alert('Please select both start and end dates.');
                return;
            }
            
            if (new Date(dateFrom) > new Date(dateTo)) {
                alert('Start date cannot be after end date.');
                return;
            }
            
            // Build URL with date filters
            var url = new URL(window.location.href);
            url.searchParams.set('date_from', dateFrom);
            url.searchParams.set('date_to', dateTo);
            url.searchParams.set('page', 'vrstore-reports');
            
            // Stay on current tab or default to sales-report
            var currentTab = new URLSearchParams(window.location.search).get('tab') || 'sales-report';
            url.searchParams.set('tab', currentTab);
            
            // Redirect to apply filters
            window.location.href = url.toString();
        },
        
        initializeCSVExports: function() {
            var self = this;
            
            // Reports CSV export
            $(document).on('click', '#export-csv', function(e) {
                e.preventDefault();
                self.exportReportsCSV();
            });
            
            // Customers CSV export
            $(document).on('click', '#export-customers-csv', function(e) {
                e.preventDefault();
                self.exportCustomersCSV();
            });
            
            // Note: Courses CSV export is handled by the vrstoreReports object
        },
        
        exportReportsCSV: function() {
            var $button = $('#export-csv');
            var originalText = $button.text();
            
            // Get date range values
            var startDate = $('#start_date').val() || '';
            var endDate = $('#end_date').val() || '';
            
            if (!startDate || !endDate) {
                this.showExportMessage('Please select both start and end dates before exporting.', 'error');
                return;
            }
            
            // Set loading state
            $button.prop('disabled', true).text('Exporting...');
            
            // Make AJAX request
            $.ajax({
                url: ajaxurl || (typeof vrstore_admin !== 'undefined' ? vrstore_admin.ajax_url : ''),
                type: 'POST',
                data: {
                    action: 'vrstore_export_csv',
                    nonce: (typeof vrstore_admin !== 'undefined' ? vrstore_admin.nonce : ''),
                    start_date: startDate,
                    end_date: endDate
                },
                success: function(response) {
                    if (response.success) {
                        // Show success message
                        vrstoreReports.showExportMessage(response.data.message, 'success');
                        
                        // Trigger download if URL provided
                        if (response.data.download_url) {
                            vrstoreReports.downloadFile(response.data.download_url, response.data.filename);
                        }
                    } else {
                        vrstoreReports.showExportMessage('Export Error: ' + (response.data.message || 'Reports CSV export failed. Please try again.'), 'error');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('CSV Export Error:', error);
                    vrstoreReports.showExportMessage('Export Error: Network error occurred. Please try again.', 'error');
                },
                complete: function() {
                    // Reset button state
                    $button.prop('disabled', false).text(originalText);
                }
            });
        },
        
        exportCustomersCSV: function() {
            var $button = $('#export-customers-csv');
            var originalText = $button.text();
            
            // Set loading state
            $button.prop('disabled', true).text('Exporting...');
            
            // Make AJAX request
            $.ajax({
                url: ajaxurl || (typeof vrstore_admin !== 'undefined' ? vrstore_admin.ajax_url : ''),
                type: 'POST',
                data: {
                    action: 'vrstore_export_customers_csv',
                    nonce: (typeof vrstore_admin !== 'undefined' ? vrstore_admin.nonce : '')
                },
                success: function(response) {
                    if (response.success) {
                        // Show success message
                        vrstoreReports.showExportMessage(response.data.message, 'success');
                        
                        // Trigger download if URL provided
                        if (response.data.download_url) {
                            vrstoreReports.downloadFile(response.data.download_url, response.data.filename);
                        }
                    } else {
                        vrstoreReports.showExportMessage('Export Error: ' + (response.data.message || 'Customer CSV export failed. Please try again.'), 'error');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Customer CSV Export Error:', error);
                    vrstoreReports.showExportMessage('Export Error: Network error occurred. Please try again.', 'error');
                },
                complete: function() {
                    // Reset button state
                    $button.prop('disabled', false).text(originalText);
                }
            });
        },
        
        showExportMessage: function(message, type) {
            // Remove existing messages
            $('.vrstore-export-message').remove();
            
            // Create message element
            var messageClass = type === 'success' ? 'notice-success' : 'notice-error';
            var $message = $('<div class="notice ' + messageClass + ' vrstore-export-message is-dismissible" style="margin: 10px 0;"><p>' + message + '</p></div>');
            
            // Find appropriate container and insert message
            var $container = $('.vrstore-export-section, .wrap h1').first();
            if ($container.length > 0) {
                if ($container.hasClass('wrap') || $container.is('h1')) {
                    $container.after($message);
                } else {
                    $container.prepend($message);
                }
            } else {
                // Fallback: show alert
                alert(message);
                return;
            }
            
            // Auto-remove success messages after 5 seconds
            if (type === 'success') {
                setTimeout(function() {
                    $message.fadeOut(function() {
                        $message.remove();
                    });
                }, 5000);
            }
            
            // Add dismiss functionality
            $message.on('click', '.notice-dismiss', function() {
                $message.remove();
            });
        },
        
        downloadFile: function(url, filename) {
            try {
                // Create temporary link and trigger download
                var $link = $('<a>', {
                    href: url,
                    download: filename || 'export.csv',
                    style: 'display: none;'
                });
                
                $('body').append($link);
                $link[0].click();
                $link.remove();
            } catch (error) {
                console.error('Download error:', error);
                // Fallback: open in new window
                window.open(url, '_blank');
            }
        },

        // Certification Downloads functionality (moved from reports.php)
        initCertificationDownloads: function() {
            var self = this;
            
            // Date filter functionality
            $('#cert-date-filter').on('change', function() {
                self.loadCertificationDownloads();
            });
            
            // CSV Export functionality
            $('#export-cert-csv').on('click', function(e) {
                e.preventDefault();
                self.exportCertificationCSV();
            });
            
            // View certificate details
            $(document).on('click', '.view-certificate', function(e) {
                e.preventDefault();
                var certificateId = $(this).data('certificate-id');
                self.viewCertificateDetails(certificateId);
            });
            
            // Close modal
            $(document).on('click', '.vrstore-modal-close, .vrstore-modal-overlay', function(e) {
                if (e.target === this) {
                    $('.vrstore-modal').hide();
                }
            });
            
            // Load initial data
            this.loadCertificationDownloads();
        },
        
        loadCertificationDownloads: function() {
            var dateFilter = $('#cert-date-filter').val();
            var $container = $('#certification-downloads-content');
            
            // Show loading state
            $container.html('<div class="vrstore-loading">Loading certification downloads...</div>');
            
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'vrstore_load_certification_downloads',
                    date_filter: dateFilter,
                    nonce: window.vrstoreReportsData ? window.vrstoreReportsData.nonce : ''
                },
                success: function(response) {
                    if (response.success) {
                        $container.html(response.data.html);
                        
                        // Update statistics
                        if (response.data.stats) {
                            $('#cert-total-downloads').text(response.data.stats.total_downloads);
                            $('#cert-unique-users').text(response.data.stats.unique_users);
                            $('#cert-avg-per-day').text(response.data.stats.avg_per_day);
                        }
                        
                        // Show notification
                        vrstoreReports.showNotification('Certification downloads loaded successfully', 'success');
                    } else {
                        $container.html('<div class="vrstore-error">Error loading certification downloads: ' + (response.data || 'Unknown error') + '</div>');
                        vrstoreReports.showNotification('Error loading certification downloads', 'error');
                    }
                },
                error: function() {
                    $container.html('<div class="vrstore-error">Failed to load certification downloads. Please try again.</div>');
                    vrstoreReports.showNotification('Failed to load certification downloads', 'error');
                }
            });
        },
        
        exportCertificationCSV: function() {
            var dateFilter = $('#cert-date-filter').val();
            var $button = $('#export-cert-csv');
            
            // Show loading state
            $button.prop('disabled', true).text('Exporting...');
            
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'vrstore_export_certification_csv',
                    date_filter: dateFilter,
                    nonce: window.vrstoreReportsData ? window.vrstoreReportsData.nonce : ''
                },
                success: function(response) {
                    if (response.success && response.data.download_url) {
                        // Trigger download
                        var link = document.createElement('a');
                        link.href = response.data.download_url;
                        link.download = response.data.filename || 'certification-downloads.csv';
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                        
                        vrstoreReports.showNotification('CSV export completed successfully', 'success');
                    } else {
                        vrstoreReports.showNotification('Error exporting CSV: ' + (response.data || 'Unknown error'), 'error');
                    }
                },
                error: function() {
                    vrstoreReports.showNotification('Failed to export CSV. Please try again.', 'error');
                },
                complete: function() {
                    // Reset button state
                    $button.prop('disabled', false).text('Export CSV');
                }
            });
        },
        
        viewCertificateDetails: function(certificateId) {
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'vrstore_get_certificate_details',
                    certificate_id: certificateId,
                    nonce: window.vrstoreReportsData ? window.vrstoreReportsData.nonce : ''
                },
                success: function(response) {
                    if (response.success) {
                        // Show modal with certificate details
                        var modalHtml = '<div class="vrstore-modal" id="certificate-modal">';
                        modalHtml += '<div class="vrstore-modal-overlay"></div>';
                        modalHtml += '<div class="vrstore-modal-content">';
                        modalHtml += '<div class="vrstore-modal-header">';
                        modalHtml += '<h3>Certificate Details</h3>';
                        modalHtml += '<button class="vrstore-modal-close">&times;</button>';
                        modalHtml += '</div>';
                        modalHtml += '<div class="vrstore-modal-body">';
                        modalHtml += response.data.html;
                        modalHtml += '</div>';
                        modalHtml += '</div>';
                        modalHtml += '</div>';
                        
                        $('body').append(modalHtml);
                        $('#certificate-modal').show();
                    } else {
                        vrstoreReports.showNotification('Error loading certificate details: ' + (response.data || 'Unknown error'), 'error');
                    }
                },
                error: function() {
                    vrstoreReports.showNotification('Failed to load certificate details', 'error');
                }
            });
        },
        
        showNotification: function(message, type) {
            type = type || 'info';
            var notificationClass = 'vrstore-notification-' + type;
            
            var $notification = $('<div class="vrstore-notification ' + notificationClass + '">' + message + '</div>');
            $('body').append($notification);
            
            // Show notification
            setTimeout(function() {
                $notification.addClass('show');
            }, 100);
            
            // Hide notification after 3 seconds
            setTimeout(function() {
                $notification.removeClass('show');
                setTimeout(function() {
                    $notification.remove();
                }, 300);
            }, 3000);
        },

        // ========================================
        // CERTIFICATION DOWNLOADS TAB FUNCTIONALITY
        // (Moved from reports.php inline JavaScript)
        // ========================================

        initCertificationDownloadsTab: function() {
            var self = this;
            
            // Apply date filter for certification downloads
            $('#apply-cert-date-filter').on('click', function() {
                var startDate = $('#cert_start_date').val();
                var endDate = $('#cert_end_date').val();
                
                if (!startDate || !endDate) {
                    alert('Please select both start and end dates.');
                    return;
                }
                
                if (new Date(startDate) > new Date(endDate)) {
                    alert('Start date cannot be later than end date.');
                    return;
                }
                
                self.loadCertificationDownloadsWithFilter(startDate, endDate);
            });
            
            // Export certification downloads to CSV
            $('#export-cert-csv').on('click', function() {
                var startDate = $('#cert_start_date').val();
                var endDate = $('#cert_end_date').val();
                var button = $(this);
                var originalText = button.html();
                
                button.prop('disabled', true).html('<span class="dashicons dashicons-update spin"></span> ' + (window.vrstoreReportsData ? window.vrstoreReportsData.strings.exportingCsv : 'Exporting CSV...'));
                
                $.ajax({
                    url: window.vrstoreReportsData ? window.vrstoreReportsData.ajax_url : ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'vrstore_export_cert_downloads',
                        start_date: startDate,
                        end_date: endDate,
                        nonce: window.vrstoreReportsData ? window.vrstoreReportsData.nonce : (vrstore_admin ? vrstore_admin.nonce : '')
                    },
                    success: function(response) {
                        if (response.success && response.data.download_url) {
                            // Create temporary download link
                            var link = document.createElement('a');
                            link.href = response.data.download_url;
                            link.download = response.data.filename || 'certification-downloads.csv';
                            document.body.appendChild(link);
                            link.click();
                            document.body.removeChild(link);
                            
                            // Show success message
                            self.showNotification(window.vrstoreReportsData ? window.vrstoreReportsData.strings.exportComplete : 'Export completed successfully!', 'success');
                        } else {
                            self.showNotification(response.data?.message || (window.vrstoreReportsData ? window.vrstoreReportsData.strings.exportError : 'Error exporting data. Please try again.'), 'error');
                        }
                    },
                    error: function() {
                        self.showNotification(window.vrstoreReportsData ? window.vrstoreReportsData.strings.exportError : 'Error exporting data. Please try again.', 'error');
                    },
                    complete: function() {
                        button.prop('disabled', false).html(originalText);
                    }
                });
            });
            
            // View certificate details
            $(document).on('click', '.view-cert-details', function() {
                var certId = $(this).data('id');
                
                $.ajax({
                    url: window.vrstoreReportsData ? window.vrstoreReportsData.ajax_url : ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'vrstore_get_cert_details',
                        cert_id: certId,
                        nonce: window.vrstoreReportsData ? window.vrstoreReportsData.nonce : (vrstore_admin ? vrstore_admin.nonce : '')
                    },
                    success: function(response) {
                        if (response.success) {
                            self.showCertificateModal(response.data);
                        } else {
                            alert(response.data?.message || 'Error loading certificate details.');
                        }
                    },
                    error: function() {
                        alert('Error loading certificate details.');
                    }
                });
            });
        },
        
        // Load certification downloads with date filter
        loadCertificationDownloadsWithFilter: function(startDate, endDate) {
            var tbody = $('#certification-downloads-tbody');
            tbody.html('<tr><td colspan="7" class="loading">' + (window.vrstoreReportsData ? window.vrstoreReportsData.strings.loadingData : 'Loading data...') + '</td></tr>');
            
            $.ajax({
                url: window.vrstoreReportsData ? window.vrstoreReportsData.ajax_url : ajaxurl,
                type: 'POST',
                data: {
                    action: 'vrstore_load_cert_downloads',
                    start_date: startDate,
                    end_date: endDate,
                    nonce: window.vrstoreReportsData ? window.vrstoreReportsData.nonce : (vrstore_admin ? vrstore_admin.nonce : '')
                },
                success: function(response) {
                    if (response.success) {
                        tbody.html(response.data.html);
                        vrstoreReports.updateCertificationStats(response.data.stats);
                    } else {
                        tbody.html('<tr><td colspan="7" class="no-data">' + (response.data?.message || (window.vrstoreReportsData ? window.vrstoreReportsData.strings.noDataFound : 'No data found.')) + '</td></tr>');
                    }
                },
                error: function() {
                    tbody.html('<tr><td colspan="7" class="no-data">Error loading data. Please try again.</td></tr>');
                }
            });
        },
        
        // Update certification statistics
        updateCertificationStats: function(stats) {
            if (stats) {
                $('.vrstore-stats-cards .vrstore-stat-card:nth-child(1) h3').text(stats.total || '0');
                $('.vrstore-stats-cards .vrstore-stat-card:nth-child(2) h3').text(stats.today || '0');
                $('.vrstore-stats-cards .vrstore-stat-card:nth-child(3) h3').text(stats.month || '0');
            }
        },
        
        // Show certificate details modal
        showCertificateModal: function(data) {
            var modal = $('<div class="vrstore-modal-overlay"><div class="vrstore-modal"><div class="vrstore-modal-header"><h3>Certificate Download Details</h3><button class="vrstore-modal-close">&times;</button></div><div class="vrstore-modal-body"></div></div></div>');
            
            var modalBody = modal.find('.vrstore-modal-body');
            modalBody.html(`
                <table class="vrstore-details-table">
                    <tr><td><strong>Download Date:</strong></td><td>${data.download_date}</td></tr>
                    <tr><td><strong>User:</strong></td><td>${data.user_name} (${data.user_email})</td></tr>
                    <tr><td><strong>Course:</strong></td><td>${data.course_title}</td></tr>
                    <tr><td><strong>Certificate Type:</strong></td><td>${data.certificate_type}</td></tr>
                    <tr><td><strong>IP Address:</strong></td><td>${data.ip_address}</td></tr>
                    <tr><td><strong>User Agent:</strong></td><td>${data.user_agent}</td></tr>
                    ${data.file_path ? `<tr><td><strong>File Path:</strong></td><td>${data.file_path}</td></tr>` : ''}
                </table>
            `);
            
            $('body').append(modal);
            
            // Close modal handlers
            modal.find('.vrstore-modal-close, .vrstore-modal-overlay').on('click', function(e) {
                if (e.target === this) {
                    modal.remove();
                }
            });
        }
    };
    
    var vrstoreCoupons = {
        init: function() {
            this.bindEvents();
        },
        
        bindEvents: function() {
            // Unbind previous events to prevent duplicates - use namespace for easier cleanup
            $(document).off('click.vrstoreCoupons', '#add-new-coupon, #add-first-coupon');
            $(document).off('click.vrstoreCoupons', '.edit-coupon');
            $(document).off('click.vrstoreCoupons', '#close-coupon-modal, #cancel-coupon');
            $(document).off('keydown.vrstoreCoupons');
            $(document).off('click.vrstoreCoupons', '#coupon-modal');
            $(document).off('change.vrstoreCoupons', '#coupon-type');
            $(document).off('input.vrstoreCoupons', '#coupon-code, #coupon-amount');
            $(document).off('submit.vrstoreCoupons', '#coupon-form');
            $(document).off('click.vrstoreCoupons', '#save-coupon');
            
            // Open add coupon modal - use delegation for dynamic elements
            $(document).on('click.vrstoreCoupons', '#add-new-coupon, #add-first-coupon', this.openAddModal);
            
            // Open edit coupon modal - already using delegation
            $(document).on('click.vrstoreCoupons', '.edit-coupon', this.openEditModal);
            
            // Close modal - use delegation
            $(document).on('click.vrstoreCoupons', '#close-coupon-modal, #cancel-coupon', this.closeModal);
            
            // Close modal on escape key
            $(document).on('keydown.vrstoreCoupons', vrstoreCoupons.handleEscapeKey);
            
            // Close modal on outside click
            $(document).on('click.vrstoreCoupons', '#coupon-modal', vrstoreCoupons.handleOutsideClick);
            
            // Update amount description based on type - bind to form element
            $(document).on('change.vrstoreCoupons', '#coupon-type', vrstoreCoupons.updateAmountDescription);
            
            // Validate coupon code input - bind to form element
            $(document).on('input.vrstoreCoupons', '#coupon-code', vrstoreCoupons.validateCouponCode);
            
            // Validate discount amount - bind to form element
            $(document).on('input.vrstoreCoupons', '#coupon-amount', vrstoreCoupons.validateDiscountAmount);
            
            // Save coupon - bind to form
            $(document).on('submit.vrstoreCoupons', '#coupon-form', vrstoreCoupons.saveCoupon);
            $(document).on('click.vrstoreCoupons', '#save-coupon', vrstoreCoupons.triggerFormSubmit);
        },
        
        openAddModal: function(e) {
            if (e) {
                e.preventDefault();
                e.stopPropagation();
            }
            
            // Reset form and modal state
            vrstoreCoupons.resetModal();
            
            // Set modal title for add mode
            $('#coupon-modal-title').text((vrstore_admin && vrstore_admin.strings) ? vrstore_admin.strings.add_new_coupon : 'Add New Coupon');
            $('#save-coupon .button-text').text((vrstore_admin && vrstore_admin.strings) ? vrstore_admin.strings.save_coupon : 'Save Coupon');
            
            // Show modal with animation
            vrstoreCoupons.showModal();
            
            // Focus on first input
            setTimeout(function() {
                $('#coupon-code').focus();
            }, 100);
        },
        
        openEditModal: function(e) {
            if (e) {
                e.preventDefault();
                e.stopPropagation();
            }
            
            var $btn = $(this);
            var couponId = $btn.data('coupon-id');
            
            if (!couponId) {
                alert((vrstore_admin && vrstore_admin.strings) ? vrstore_admin.strings.error_invalid_coupon : 'Invalid coupon ID');
                return;
            }
            
            // Show loading state
            var originalText = $btn.text();
            $btn.text((vrstore_admin && vrstore_admin.strings) ? vrstore_admin.strings.loading : 'Loading...');
            
            // Load coupon data
            $.post(vrstore_admin.ajax_url, {
                action: 'vrstore_get_coupon',
                coupon_id: couponId,
                nonce: vrstore_admin.nonce
            })
            .done(function(response) {
                if (response.success) {
                    vrstoreCoupons.populateEditForm(response.data);
                } else {
                    alert(response.data.message || (vrstore_admin.strings ? vrstore_admin.strings.error_loading_coupon : 'Error loading coupon data'));
                }
            })
            .fail(function() {
                alert(vrstore_admin.strings ? vrstore_admin.strings.error_try_again : 'Error loading coupon. Please try again.');
            })
            .always(function() {
                $btn.text((vrstore_admin && vrstore_admin.strings) ? vrstore_admin.strings.edit : originalText || 'Edit');
            });
        },
        
        populateEditForm: function(coupon) {
            // Reset modal first
            vrstoreCoupons.resetModal();
            
            // Set modal title for edit mode
            $('#coupon-modal-title').text(vrstore_admin.strings ? vrstore_admin.strings.edit_coupon : 'Edit Coupon');
            $('#save-coupon .button-text').text(vrstore_admin.strings ? vrstore_admin.strings.update_coupon : 'Update Coupon');
            
            // Populate form fields
            $('#coupon-id').val(coupon.id);
            $('#coupon-code').val(coupon.code);
            $('#coupon-type').val(coupon.discount_type);
            $('#coupon-amount').val(coupon.discount_value);
            $('#coupon-minimum').val(coupon.minimum_amount || '');
            $('#coupon-usage-limit').val(coupon.usage_limit || '');
            $('#coupon-description').val(coupon.description || '');
            
            // Handle expiry date conversion
            if (coupon.end_date && coupon.end_date !== '0000-00-00 00:00:00') {
                var date = new Date(coupon.end_date);
                var formattedDate = date.getFullYear() + '-' + 
                    String(date.getMonth() + 1).padStart(2, '0') + '-' + 
                    String(date.getDate()).padStart(2, '0') + 'T' + 
                    String(date.getHours()).padStart(2, '0') + ':' + 
                    String(date.getMinutes()).padStart(2, '0');
                $('#coupon-expires').val(formattedDate);
            }
            
            // Update amount description
            vrstoreCoupons.updateAmountDescription.call($('#coupon-type')[0]);
            
            // Show modal
            vrstoreCoupons.showModal();
            
            // Focus on first editable field
            setTimeout(function() {
                $('#coupon-code').focus().select();
            }, 100);
        },
        
        resetModal: function() {
            $('#coupon-form')[0].reset();
            $('#coupon-id').val('');
            
            // Clear error states
            $('.vrstore-form-error').removeClass('vrstore-form-error');
            $('.field-error-message').remove();
        },
        
        showModal: function() {
            var $modal = $('#coupon-modal');
            // Ensure modal is visible with proper display
            $modal.css('display', 'flex').addClass('vrstore-modal-visible');
            $('body').addClass('vrstore-modal-open');
            
            // Scroll modal content to top
            var $modalBody = $modal.find('.vrstore-modal-body');
            if ($modalBody.length) {
                $modalBody.scrollTop(0);
            }
        },
        
        closeModal: function() {
            var $modal = $('#coupon-modal');
            
            // Add fade out animation
            $modal.removeClass('vrstore-modal-visible');
            $('body').removeClass('vrstore-modal-open');
            
            setTimeout(function() {
                $modal.css('display', 'none');
            }, 200);
        },
        
        handleEscapeKey: function(e) {
            if (e.keyCode === 27 && $('#coupon-modal').hasClass('vrstore-modal-visible')) {
                vrstoreCoupons.closeModal();
            }
        },
        
        handleOutsideClick: function(e) {
            // Close modal when clicking on the backdrop (the modal itself, not its content)
            var $modal = $('#coupon-modal');
            // Only close if clicking directly on the modal backdrop, not on its children
            if ($(e.target).is('#coupon-modal')) {
                e.preventDefault();
                e.stopPropagation();
                vrstoreCoupons.closeModal();
            }
        },
        
        updateAmountDescription: function() {
            var type = $(this).val();
            var $description = $('#amount-description');
            var $amountInput = $('#coupon-amount');
            
            if (type === 'percentage') {
                $description.text(vrstore_admin.strings ? vrstore_admin.strings.percentage_description : 'Enter the discount percentage (0-100)');
                $amountInput.attr('max', '100');
            } else {
                $description.text(vrstore_admin.strings ? vrstore_admin.strings.fixed_description : 'Enter the fixed discount amount');
                $amountInput.removeAttr('max');
            }
        },
        
        validateCouponCode: function() {
            var $input = $(this);
            var code = $input.val().trim().toUpperCase();
            
            // Auto-format to uppercase
            $input.val(code);
            
            // Remove previous error
            $input.removeClass('vrstore-form-error');
            $input.next('.field-error-message').remove();
            
            // Basic validation
            if (code.length > 0 && !/^[A-Z0-9_-]+$/.test(code)) {
                vrstoreCoupons.showFieldError($input, vrstore_admin.strings ? vrstore_admin.strings.invalid_coupon_code : 'Coupon code can only contain letters, numbers, hyphens and underscores');
            }
        },
        
        validateDiscountAmount: function() {
            var $input = $(this);
            var amount = parseFloat($input.val());
            var type = $('#coupon-type').val();
            
            // Remove previous error
            $input.removeClass('vrstore-form-error');
            $input.next('.field-error-message').remove();
            
            // Validate based on discount type
            if (!isNaN(amount)) {
                if (type === 'percentage' && (amount < 0 || amount > 100)) {
                    vrstoreCoupons.showFieldError($input, vrstore_admin.strings ? vrstore_admin.strings.invalid_percentage : 'Percentage must be between 0 and 100');
                } else if (type === 'fixed' && amount < 0) {
                    vrstoreCoupons.showFieldError($input, vrstore_admin.strings ? vrstore_admin.strings.invalid_amount : 'Amount must be greater than 0');
                }
            }
        },
        
        showFieldError: function($field, message) {
            $field.addClass('vrstore-form-error');
            $('<div class="field-error-message">' + message + '</div>').insertAfter($field);
        },
        
        validateForm: function() {
            var isValid = true;
            var $form = $('#coupon-form');
            
            // Clear previous errors
            $('.vrstore-form-error').removeClass('vrstore-form-error');
            $('.field-error-message').remove();
            
            // Validate required fields
            $form.find('[required]').each(function() {
                var $field = $(this);
                var value = $field.val().trim();
                
                if (!value) {
                    vrstoreCoupons.showFieldError($field, vrstore_admin.strings ? vrstore_admin.strings.field_required : 'This field is required');
                    isValid = false;
                }
            });
            
            // Validate coupon code format
            var code = $('#coupon-code').val().trim();
            if (code && !/^[A-Z0-9_-]+$/.test(code)) {
                vrstoreCoupons.showFieldError($('#coupon-code'), vrstore_admin.strings ? vrstore_admin.strings.invalid_coupon_code : 'Invalid coupon code format');
                isValid = false;
            }
            
            // Validate discount amount
            var amount = parseFloat($('#coupon-amount').val());
            var type = $('#coupon-type').val();
            if (!isNaN(amount)) {
                if (type === 'percentage' && (amount < 0 || amount > 100)) {
                    vrstoreCoupons.showFieldError($('#coupon-amount'), vrstore_admin.strings ? vrstore_admin.strings.invalid_percentage : 'Percentage must be between 0 and 100');
                    isValid = false;
                } else if (type === 'fixed' && amount < 0) {
                    vrstoreCoupons.showFieldError($('#coupon-amount'), vrstore_admin.strings ? vrstore_admin.strings.invalid_amount : 'Amount must be greater than 0');
                    isValid = false;
                }
            }
            
            return isValid;
        },
        
        triggerFormSubmit: function(e) {
            e.preventDefault();
            $('#coupon-form').trigger('submit');
        },
        
        saveCoupon: function(e) {
            e.preventDefault();
            
            // Validate form before submission
            if (!vrstoreCoupons.validateForm()) {
                return;
            }
            
            var $saveBtn = $('#save-coupon');
            var $spinner = $saveBtn.find('.spinner');
            var $buttonText = $saveBtn.find('.button-text');
            var originalText = $buttonText.text();
            
            // Set loading state
            $saveBtn.prop('disabled', true).addClass('loading');
            $spinner.show();
            $buttonText.text(vrstore_admin.strings ? vrstore_admin.strings.saving : 'Saving...');
            
            // Prepare form data
            var $form = $('#coupon-form');
            var formData = $form.serialize();
            formData += '&action=vrstore_save_coupon&nonce=' + vrstore_admin.nonce;
            
            // Submit form using proper content type
            $.ajax({
                url: vrstore_admin.ajax_url,
                type: 'POST',
                data: formData,
                dataType: 'json',
                cache: false
            })
                .done(function(response) {
                    if (response.success) {
                        // Show success message
                        vrstoreCoupons.showNotice('success', response.data.message || (vrstore_admin.strings ? vrstore_admin.strings.coupon_saved : 'Coupon saved successfully!'));
                        
                        // Close modal and reload page after short delay
                        setTimeout(function() {
                            vrstoreCoupons.closeModal();
                            location.reload();
                        }, 1000);
                    } else {
                        var errorMsg = response.data && response.data.message 
                            ? response.data.message 
                            : (vrstore_admin.strings ? vrstore_admin.strings.error_saving : 'Error saving coupon.');
                        vrstoreCoupons.showNotice('error', errorMsg);
                    }
                })
                .fail(function(xhr) {
                    var message = vrstore_admin.strings ? vrstore_admin.strings.error_try_again : 'Error saving coupon. Please try again.';
                    if (xhr.responseJSON && xhr.responseJSON.data) {
                        if (xhr.responseJSON.data.message) {
                            message = xhr.responseJSON.data.message;
                        }
                    } else if (xhr.responseText) {
                        try {
                            var response = JSON.parse(xhr.responseText);
                            if (response.data && response.data.message) {
                                message = response.data.message;
                            }
                        } catch(e) {
                            // Silent fail - use default message
                        }
                    }
                    vrstoreCoupons.showNotice('error', message);
                })
                .always(function() {
                    // Reset button state
                    $saveBtn.prop('disabled', false).removeClass('loading');
                    $spinner.hide();
                    $buttonText.text(originalText);
                });
        },
        
        showNotice: function(type, message) {
            // Remove existing notices
            $('.vrstore-modal-notice').remove();
            
            // Create notice element
            var noticeClass = type === 'success' ? 'notice-success' : 'notice-error';
            var $notice = $('<div class="notice ' + noticeClass + ' vrstore-modal-notice"><p>' + message + '</p></div>');
            
            // Insert notice at top of modal body
            $('.vrstore-modal-body').prepend($notice);
            
            // Auto-remove error notices after 5 seconds
            if (type === 'error') {
                setTimeout(function() {
                    $notice.fadeOut(function() {
                        $notice.remove();
                    });
                }, 5000);
            }
        }
    };
    
    var vrstoreDomainActivations = {
        init: function() {
            this.bindEvents();
        },
        
        bindEvents: function() {
            // View activation details
            $('.view-activation-details').on('click', this.viewDetails);
            
            // Close modal
            $('#close-activation-modal, #close-activation-details').on('click', this.closeModal);
            
            // Close modal on outside click
            $(window).on('click', this.handleOutsideClick);
        },
        
        viewDetails: function(e) {
            e.preventDefault();
            
            var activationId = $(this).data('activation-id');
            
            $('#activation-details-content').html(
                '<div class="vrstore-loading">' +
                '<span class="spinner is-active"></span>' +
                '<p>' + (vrstore_admin.strings ? vrstore_admin.strings.loading_details : 'Loading activation details...') + '</p>' +
                '</div>'
            );
            
            // Show modal with unified system
            const $modal = $('#activation-details-modal');
            $modal.show().addClass('vrstore-modal-visible');
            $('body').addClass('vrstore-modal-open');
            
            $.post(vrstore_admin.ajax_url, {
                action: 'vrstore_get_activation_details',
                activation_id: activationId,
                nonce: vrstore_admin.nonce
            })
            .done(function(response) {
                if (response.success) {
                    $('#activation-details-content').html(response.data);
                } else {
                    $('#activation-details-content').html(
                        '<div class="notice notice-error"><p>' + 
                        (response.data.message || (vrstore_admin.strings ? vrstore_admin.strings.error_loading_details : 'Error loading activation details.')) + 
                        '</p></div>'
                    );
                }
            })
            .fail(function() {
                $('#activation-details-content').html(
                    '<div class="notice notice-error"><p>' +
                    (vrstore_admin.strings ? vrstore_admin.strings.error_try_again : 'Error loading activation details. Please try again.') +
                    '</p></div>'
                );
            });
        },
        
        closeModal: function() {
            const $modal = $('#activation-details-modal');
            $modal.removeClass('vrstore-modal-visible');
            $('body').removeClass('vrstore-modal-open');
            
            setTimeout(function() {
                $modal.hide();
            }, 200);
        },
        
        handleOutsideClick: function(e) {
            if ($(e.target).is('#activation-details-modal')) {
                vrstoreDomainActivations.closeModal();
            }
        }
    };

    var vrstoreLicenseTypes = {
        init: function() {
            this.licenseTypeIndex = $('#vrstore-license-types-container .license-type-row').length || 1;
            this.bindEvents();
            this.updatePreview();
        },
        
        bindEvents: function() {
            // Add new license type
            $(document).on('click', '#add-license-type', this.addLicenseType.bind(this));
            
            // Remove license type
            $(document).on('click', '.remove-license-type', this.removeLicenseType.bind(this));
            
            // Update preview when inputs change
            $(document).on('input', '.license-preview-trigger', this.updatePreview.bind(this));
            
            // Add preview trigger class to existing inputs
            $('input[name*="[label]"]').addClass('license-preview-trigger');
            $('input[name*="[regular_price]"]').addClass('license-preview-trigger');
            $('input[name*="[sale_price]"]').addClass('license-preview-trigger');
        },
        
        addLicenseType: function(e) {
            e.preventDefault();
            
            var fieldName = $('#vrstore-license-types-container').data('field-name') || 'vrstore_settings[custom_license_types]';
            
            // Ensure vrstore_admin object exists with fallback values
            var labels = window.vrstore_admin || {};
            var licenseTypeLabel = labels.licenseTypeLabel || 'License Type Label';
            var regularPrice = labels.regularPrice || 'Regular Price';
            var salePrice = labels.salePrice || 'Sale Price';
            var expirationMonths = labels.expirationMonths || 'Expiration (months)';
            var maxActivations = labels.maxActivations || 'Max Activations';
            var extendedSupportConfig = labels.extendedSupportConfig || 'Extended Support Configuration';
            var extendedSupportPrice = labels.extendedSupportPrice || 'Extended Support Price';
            var lockTicketsOnExpiry = labels.lockTicketsOnExpiry || 'Lock Ticket Support on Expiry';
            var extendedSupportDesc = labels.extendedSupportDesc || 'Configure extended support options when license expires. Leave empty to disable extended support for this license type.';
            var extendedSupportPriceDesc = labels.extendedSupportPriceDesc || 'Price for the extended support period';
            var lockTicketsDesc = labels.lockTicketsDesc || 'When enabled, customers with expired licenses will not be able to create new tickets or reply to existing tickets until they purchase Extended Support.';

            var removeText = labels.remove || 'Remove';
            
            var newRow = $('<div class="license-type-row" data-index="' + this.licenseTypeIndex + '" style="background: #f9f9f9; padding: 15px; margin: 10px 0; border-radius: 4px;">' +
                '<table class="form-table">' +
                    '<tr>' +
                        '<td><label><strong>' + licenseTypeLabel + '</strong></label></td>' +
                        '<td><input type="text" name="' + fieldName + '[' + this.licenseTypeIndex + '][label]" placeholder="e.g., Unlimited, Whitelabel" class="regular-text license-preview-trigger" /></td>' +
                    '</tr>' +
                    '<tr>' +
                        '<td><label>' + regularPrice + '</label></td>' +
                        '<td><input type="number" name="' + fieldName + '[' + this.licenseTypeIndex + '][regular_price]" min="0" step="0.01" class="small-text license-preview-trigger" placeholder="0.00" /></td>' +
                    '</tr>' +
                    '<tr>' +
                        '<td><label>' + salePrice + '</label></td>' +
                        '<td><input type="number" name="' + fieldName + '[' + this.licenseTypeIndex + '][sale_price]" min="0" step="0.01" class="small-text license-preview-trigger" placeholder="0.00" /></td>' +
                    '</tr>' +
                    '<tr>' +
                        '<td><label>' + expirationMonths + '</label></td>' +
                        '<td><input type="number" name="' + fieldName + '[' + this.licenseTypeIndex + '][expiry_months]" min="0" step="1" class="small-text" placeholder="0 = Lifetime" /></td>' +
                    '</tr>' +
                    '<tr>' +
                        '<td><label>' + maxActivations + '</label></td>' +
                        '<td><input type="number" name="' + fieldName + '[' + this.licenseTypeIndex + '][max_activations]" min="1" step="1" class="small-text" placeholder="1" /></td>' +
                    '</tr>' +
                    '<tr class="vrstore-extended-support-header">' +
                        '<td colspan="2"><hr style="margin: 15px 0 10px 0;"><h4 style="margin: 0; color: #0073aa;">' + extendedSupportConfig + '</h4><p class="description" style="margin: 5px 0 10px 0;">' + extendedSupportDesc + '</p></td>' +
                    '</tr>' +
                    '<tr class="vrstore-extended-support-field">' +
                        '<td><label>' + extendedSupportPrice + '</label></td>' +
                        '<td><input type="number" name="' + fieldName + '[' + this.licenseTypeIndex + '][extended_support_price]" min="0" step="0.01" class="small-text" placeholder="0.00" /><span class="description" style="margin-left: 10px;">' + extendedSupportPriceDesc + '</span></td>' +
                    '</tr>' +
                    '<tr class="vrstore-extended-support-field">' +
                        '<td><label>' + lockTicketsOnExpiry + '</label></td>' +
                        '<td><input type="checkbox" name="' + fieldName + '[' + this.licenseTypeIndex + '][lock_tickets_on_expiry]" value="1" /> Enable<span class="description" style="margin-left: 10px; display: block; margin-top: 5px;">' + lockTicketsDesc + '</span></td>' +
                    '</tr>' +
                    '<tr>' +
                        '<td colspan="2"><button type="button" class="remove-license-type button button-link-delete">' + removeText + '</button></td>' +
                    '</tr>' +
                '</table>' +
            '</div>');
            
            $('#vrstore-license-types-container').append(newRow);
            this.licenseTypeIndex++;
            this.updatePreview();
        },
        
        removeLicenseType: function(e) {
            e.preventDefault();
            $(e.target).closest('.license-type-row').remove();
            this.updatePreview();
        },
        
        updatePreview: function() {
            var previewContainer = $('#license-preview-container');
            if (!previewContainer.length) return;
            
            var hasLicenseTypes = false;
            var previewHtml = '';
            
            $('.license-type-row').each(function() {
                var label = $(this).find('input[name*="[label]"]').val();
                var regularPrice = $(this).find('input[name*="[regular_price]"]').val() || '0.00';
                var salePrice = $(this).find('input[name*="[sale_price]"]').val() || '';
                
                if (label) {
                    hasLicenseTypes = true;
                    previewHtml += '<tr>' +
                        '<td style="width: 150px; padding: 8px 10px;"><strong>' + label + '</strong></td>' +
                        '<td style="padding: 8px 10px;">' +
                            '<span style="color: #666; font-size: 12px;">Regular Price:</span> <input type="text" value="' + regularPrice + '" style="width: 80px; margin-right: 10px;" readonly /> ' +
                            '<span style="color: #666; font-size: 12px;">Sale Price:</span> <input type="text" value="' + salePrice + '" style="width: 80px;" readonly />' +
                        '</td>' +
                    '</tr>';
                }
            });
            
            if (hasLicenseTypes) {
                 previewContainer.html('<table class="form-table" style="margin: 0;">' + previewHtml + '</table>');
             } else {
                 var labels = window.vrstore_admin || {};
                 var noLicenseText = labels.noLicenseTypesConfigured || 'No license types configured yet. Add license types above to see the preview.';
                 previewContainer.html('<p style="color: #666; font-style: italic;">' + noLicenseText + '</p>');
             }
        }
    };
    
    
    // Unified modal system for all admin modals
    var vrstoreUnifiedModals = {
        init: function() {
            this.bindEvents();
        },
        
        bindEvents: function() {
            var self = this;
            
            // Close modal on escape key
            $(document).on('keydown', function(e) {
                if (e.keyCode === 27) {
                    self.closeVisibleModals();
                }
            });
            
            // Close modal on overlay click
            $(document).on('click', '.vrstore-modal', function(e) {
                if (e.target === this) {
                    self.closeModal($(this));
                }
            });
            
            // Close modal on close button click
            $(document).on('click', '.vrstore-modal-close', function(e) {
                e.preventDefault();
                var $modal = $(this).closest('.vrstore-modal');
                self.closeModal($modal);
            });
        },
        
        closeModal: function($modal) {
            if ($modal.hasClass('vrstore-modal-visible')) {
                $modal.removeClass('vrstore-modal-visible');
                $('body').removeClass('vrstore-modal-open');
                
                setTimeout(function() {
                    $modal.hide();
                }, 200);
            }
        },
        
        closeVisibleModals: function() {
            var self = this;
            $('.vrstore-modal.vrstore-modal-visible').each(function() {
                self.closeModal($(this));
            });
        }
    };
    
    var vrstoreCustomerDetail = {
        init: function() {
            this.bindEvents();
            this.ensureOrderModal();
        },
        
        bindEvents: function() {
            // Copy license key functionality
            $(document).on('click', '.copy-license-key', this.copyLicenseKey);
            
            // View order functionality  
            $(document).on('click', '.vrstore-view-order', this.viewOrderDetails);
        },
        
        ensureOrderModal: function() {
            if ($('#vrstore-order-modal').length === 0) {
                var modalHtml = '<div id="vrstore-order-modal" class="vrstore-modal" style="display: none;">' +
                    '<div class="vrstore-modal-content">' +
                        '<div class="vrstore-modal-header">' +
                            '<h2>Order Details</h2>' +
                            '<span class="vrstore-modal-close">&times;</span>' +
                        '</div>' +
                        '<div class="vrstore-modal-body" id="vrstore-order-modal-body">' +
                            '<div class="vrstore-loading">' +
                                '<span class="spinner is-active"></span>' +
                                '<p>Loading order details...</p>' +
                            '</div>' +
                        '</div>' +
                    '</div>' +
                '</div>';
                $('body').append(modalHtml);
            }
        },
        
        viewOrderDetails: function(e) {
            e.preventDefault();
            var orderId = $(this).data('order-id');
            if (!orderId) return;
            
            var $modal = $('#vrstore-order-modal');
            var $body = $('#vrstore-order-modal-body');
            
            // Use the unified modal system
            $body.html('<div class="vrstore-loading"><span class="spinner is-active"></span><p>Loading order details...</p></div>');
            $modal.show().addClass('vrstore-modal-visible');
            $('body').addClass('vrstore-modal-open');
            
            $.post(ajaxurl, {
                action: 'vrstore_get_order_details',
                nonce: (window.vrstore_admin && vrstore_admin.nonce) ? vrstore_admin.nonce : '',
                order_id: orderId
            })
            .done(function(response) {
                if (response.success) {
                    $body.html(response.data);
                } else {
                    $body.html('<div class="notice notice-error"><p>' + (response.data && response.data.message ? response.data.message : 'Error loading order details.') + '</p></div>');
                }
            })
            .fail(function() {
                $body.html('<div class="notice notice-error"><p>Error loading order details. Please try again.</p></div>');
            });
        },
        
        copyLicenseKey: function(e) {
            e.preventDefault();
            
            var $button = $(this);
            var licenseKey = $button.data('license-key');
            
            if (!licenseKey) {
                alert('No license key found');
                return;
            }
            
            // Create temporary textarea to copy text
            var $temp = $('<textarea>');
            $('body').append($temp);
            $temp.val(licenseKey).select();
            
            try {
                var successful = document.execCommand('copy');
                if (successful) {
                    // Show success feedback
                    var originalHTML = $button.html();
                    $button.html('<span class="dashicons dashicons-yes"></span>');
                    $button.addClass('copied');
                    
                    setTimeout(function() {
                        $button.html(originalHTML);
                        $button.removeClass('copied');
                    }, 2000);
                } else {
                    // Fallback: show the full license key in a prompt
                    prompt('Copy this license key:', licenseKey);
                }
            } catch (err) {
                // Fallback: show the full license key in a prompt
                prompt('Copy this license key:', licenseKey);
            }
            
            $temp.remove();
        }
    };
    
    
    // Document ready
    $(document).ready(function() {
        vrstoreAdmin.init();
        vrstoreUnifiedModals.init();
        
        // Initialize page-specific modules
        if ($('.vrstore-report-tab').length) {
            vrstoreReports.init();
        }
        
        // Initialize coupon functionality if modal exists
        if ($('#coupon-modal').length) {
            vrstoreCoupons.init();
        }
        
        if ($('#activation-details-modal').length) {
            vrstoreDomainActivations.init();
        }
        
        // Initialize customer detail functionality
        if ($('.customer-detail-cards').length) {
            vrstoreCustomerDetail.init();
        }
        
        // Initialize license types management
        if ($('#vrstore-license-types-container').length) {
            vrstoreLicenseTypes.init();
        }
        
        // Database repair confirmation
        $('input[name="vrstore_repair_database"]').on('click', function(e) {
            var labels = window.vrstore_admin || {};
            var confirmText = labels.repairDatabaseConfirm || 'Are you sure you want to repair the database? This will recreate missing tables.';
            if (!confirm(confirmText)) {
                e.preventDefault();
                return false;
            }
        });
        
        // Enhanced customer deletion confirmation with proper scope
        $(document).on('click', '.vrstore-delete-customer', function(e) {
            e.preventDefault();
            
            var $link = $(this);
            var customerId = $link.data('customer-id');
            var customerName = $link.data('customer-name');
            var customerEmail = $link.data('customer-email');
            var deleteUrl = $link.attr('href');
            
            // Get customer deletion details via AJAX
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'vrstore_get_customer_deletion_details',
                    customer_id: customerId,
                    nonce: (typeof vrstore_admin !== 'undefined' && vrstore_admin.nonce) ? vrstore_admin.nonce : ''
                },
                success: function(response) {
                    if (response.success) {
                        var data = response.data;
                        var message = 'Are you sure you want to delete customer "' + customerName + '" (' + customerEmail + ')?\n\n';
                        message += 'This will permanently delete:\n';
                        message += '• Customer account and profile\n';
                        if (data.licenses_count > 0) {
                            message += '• ' + data.licenses_count + ' license(s)\n';
                        }
                        if (data.domain_activations_count > 0) {
                            message += '• ' + data.domain_activations_count + ' domain activation(s)\n';
                        }
                        if (data.orders_count > 0) {
                            message += '• ' + data.orders_count + ' order(s)\n';
                        }
                        if (data.download_tracking_count > 0) {
                            message += '• ' + data.download_tracking_count + ' download tracking record(s)\n';
                        }
                        message += '• All payment logs and download history\n';
                        message += '• All related logs and data\n\n';
                        message += 'This action cannot be undone!';
                        
                        if (confirm(message)) {
                            window.location.href = deleteUrl;
                        }
                    } else {
                        // Fallback to simple confirmation
                        var fallbackMessage = 'Are you sure you want to delete customer "' + customerName + '"?\n\n';
                        fallbackMessage += 'This will permanently delete the customer account and all related data including:\n';
                        fallbackMessage += '• Domain activations and license keys\n';
                        fallbackMessage += '• Download tracking history\n';
                        fallbackMessage += '• Payment records and logs\n\n';
                        fallbackMessage += 'This action cannot be undone!';
                        
                        if (confirm(fallbackMessage)) {
                            window.location.href = deleteUrl;
                        }
                    }
                },
                error: function() {
                    // Fallback to simple confirmation on AJAX error
                    var fallbackMessage = 'Are you sure you want to delete customer "' + customerName + '"?\n\n';
                    fallbackMessage += 'This will permanently delete the customer account and all related data including domain activations.\n\n';
                    fallbackMessage += 'This action cannot be undone!';
                    
                    if (confirm(fallbackMessage)) {
                        window.location.href = deleteUrl;
                    }
                }
            });
        });
        
        // License Type Filter Functionality
        var $filterDropdown = $('#vrstore-license-filter-dropdown');
        var $pricingGroups = $('.license-pricing-group');
        
        if ($filterDropdown.length && $pricingGroups.length) {
            $filterDropdown.on('change', function() {
                var selectedLicense = $(this).val();
                
                if (selectedLicense === 'all') {
                    // Show all license pricing groups
                    $pricingGroups.show();
                } else {
                    // Hide all groups first
                    $pricingGroups.hide();
                    
                    // Show only the selected license type
                    $pricingGroups.filter('[data-license-slug="' + selectedLicense + '"]').show();
                }
            });
            
            // Add visual feedback for better UX
            $filterDropdown.on('change', function() {
                var selectedText = $(this).find('option:selected').text();
                var $pricingSection = $('#license-pricing-section');
                
                // Update pricing section title to reflect filter
                var $title = $pricingSection.find('h4');
                if ($(this).val() === 'all') {
                    $title.text($title.data('original-text') || 'Product Pricing');
                } else {
                    if (!$title.data('original-text')) {
                        $title.data('original-text', $title.text());
                    }
                    $title.text('Product Pricing - ' + selectedText);
                }
            });
        }
        
        // Add error handling for forms reset to prevent TypeError
        if (typeof HTMLButtonElement !== 'undefined' && HTMLButtonElement.prototype.resetForms) {
            // Override resetForms to add error checking
            var originalResetForms = HTMLButtonElement.prototype.resetForms;
            HTMLButtonElement.prototype.resetForms = function() {
                try {
                    if (typeof originalResetForms === 'function') {
                        return originalResetForms.call(this);
                    }
                } catch (e) {
                    console.warn('resetForms error handled:', e.message);
                }
                return undefined;
            };
        }
    });

})(jQuery);

// Payment Testing Functions - Global scope for WordPress admin callbacks
window.vrstore_run_payment_test = function() {
    var gateway = jQuery('#test_gateway').val();
    var amount = jQuery('#test_amount').val();
    var testType = jQuery('#test_type').val();
    var statusEl = jQuery('#test_status');
    var resultsEl = jQuery('#test_results');
    var resultsContent = jQuery('#test_results_content');
    
    if (!gateway || !amount || !testType) {
        alert('Please select all required fields.');
        return;
    }
    
    statusEl.html('<span style="color: #0073aa;">Running test...</span>');
    resultsEl.hide();
    
    jQuery.ajax({
        url: ajaxurl,
        type: 'POST',
        data: {
            action: 'vrstore_run_payment_test',
            gateway: gateway,
            amount: amount,
            test_type: testType,
            nonce: (typeof vrstore_admin_vars !== 'undefined' && vrstore_admin_vars.nonce) ? vrstore_admin_vars.nonce : ''
        },
        success: function(response) {
            if (response.success) {
                statusEl.html('<span style="color: #46b450;">✓ Test completed</span>');
                resultsContent.html(
                    '<div style="color: #46b450; margin-bottom: 10px;"><strong>✓ Success</strong></div>' +
                    '<div><strong>Gateway:</strong> ' + gateway + '</div>' +
                    '<div><strong>Amount:</strong> $' + parseFloat(amount).toFixed(2) + '</div>' +
                    '<div><strong>Test Type:</strong> ' + testType + '</div>' +
                    '<div><strong>Message:</strong> ' + (response.data.message || 'Test completed successfully') + '</div>' +
                    '<div><strong>Transaction ID:</strong> ' + (response.data.transaction_id || 'N/A') + '</div>'
                );
                resultsEl.show();
            } else {
                statusEl.html('<span style="color: #dc3232;">✗ Test failed</span>');
                resultsContent.html(
                    '<div style="color: #dc3232; margin-bottom: 10px;"><strong>✗ Test Failed</strong></div>' +
                    '<div><strong>Error:</strong> ' + (response.data.message || 'Unknown error occurred') + '</div>'
                );
                resultsEl.show();
            }
        },
        error: function(xhr, status, error) {
            statusEl.html('<span style="color: #dc3232;">✗ Connection error</span>');
            resultsContent.html(
                '<div style="color: #dc3232; margin-bottom: 10px;"><strong>✗ Connection Error</strong></div>' +
                '<div><strong>Error:</strong> Failed to connect to payment gateway</div>' +
                '<div><strong>Details:</strong> ' + error + '</div>'
            );
            resultsEl.show();
        }
    });
};

window.vrstore_reset_test = function() {
    jQuery('#test_status').html('Ready');
    jQuery('#test_results').hide();
    jQuery('#test_gateway').val('');
    jQuery('#test_amount').val('');
    jQuery('#test_type').val('');
};

// Affiliate Edit Page JavaScript
jQuery(document).ready(function($) {
    // Initialize affiliate edit page functionality
    function initializeAffiliateEdit() {
        // Withdrawal action buttons
        $('.withdrawal-action-btn').on('click', function() {
            const action = $(this).data('action');
            const withdrawalId = $(this).data('withdrawal-id');
            const amount = $(this).data('amount');
            const paymentMethod = $(this).data('payment-method');
            
            // Set modal title and action
            const actionTitles = {
                'approve': 'Approve Withdrawal',
                'reject': 'Reject Withdrawal',
                'mark_paid': 'Mark as Paid'
            };
            
            $('#withdrawal-modal-title').text(actionTitles[action]);
            $('#withdrawal-action').val(action);
            $('#withdrawal-id').val(withdrawalId);
            
            // Show/hide fields based on action
            if (action === 'mark_paid') {
                $('.payment-details-group').show();
                $('.admin-notes-group label').text('Payment Notes (Optional):');
            } else {
                $('.payment-details-group').hide();
                $('.admin-notes-group label').text(action === 'approve' ? 'Approval Notes (Optional):' : 'Rejection Reason:');
            }
            
            // Show modal
            $('#withdrawal-modal').show();
        });
        
        // Close modal
        $('.vrstore-modal-close, .cancel-btn').on('click', function() {
            $('#withdrawal-modal').hide();
            $('#withdrawal-form')[0].reset();
        });
        
        // Handle form submission
        $('#withdrawal-form').on('submit', function(e) {
            e.preventDefault();
            
            const $form = $(this);
            const $submitBtn = $form.find('.submit-btn');
            const originalText = $submitBtn.text();
            
            // Show loading state
            $submitBtn.prop('disabled', true).text('Processing...');
            
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: $form.serialize() + '&action=vrstore_process_withdrawal',
                success: function(response) {
                    if (response.success) {
                        // Show success message
                        alert('Withdrawal request processed successfully!');
                        // Reload page to show updated status
                        location.reload();
                    } else {
                        alert('Error: ' + (response.data || 'Unknown error occurred'));
                    }
                },
                error: function() {
                    alert('An error occurred while processing the request.');
                },
                complete: function() {
                    $submitBtn.prop('disabled', false).text(originalText);
                    $('#withdrawal-modal').hide();
                    $form[0].reset();
                }
            });
        });
        
        // Close modal when clicking outside
        $('#withdrawal-modal').on('click', function(e) {
            if (e.target === this) {
                $(this).hide();
                $('#withdrawal-form')[0].reset();
            }
        });
    }

    // Initialize affiliate edit functionality if on the correct page
    if ($('.affiliate-withdrawal-requests').length > 0) {
        initializeAffiliateEdit();
    }
});

// Affiliate Settings Page JavaScript
jQuery(document).ready(function($) {
    // Initialize affiliate settings page functionality
    function initializeAffiliateSettings() {
        // Toggle short URL settings visibility
        $('#use_short_urls').change(function() {
            if ($(this).is(':checked')) {
                $('#short_url_provider_row').show();
                $('#short_url_provider').trigger('change');
            } else {
                $('#short_url_provider_row').hide();
                $('.provider-settings').hide();
            }
        });
        
        // Toggle provider-specific settings
        $('#short_url_provider').change(function() {
            $('.provider-settings').hide();
            var provider = $(this).val();
            if (provider === 'dns') {
                $('#dns_settings').show();
            } else if (provider === 'rebrandly') {
                $('#rebrandly_settings, #rebrandly_domain_settings').show();
            } else if (provider === 'bitly') {
                $('#bitly_settings, #bitly_domain_settings').show();
            }
        });
        
        // Toggle Join Affiliate Requirement visibility based on Enable Affiliate Registration
        $('#enable_affiliate_registration').on('change', function(e) {
            console.log('Checkbox changed:', $(this).is(':checked'));
            if ($(this).is(':checked')) {
                $('#join_affiliate_requirement_row').show();
            } else {
                $('#join_affiliate_requirement_row').hide();
            }
        });
        
        // Initialize on page load
        if ($('#use_short_urls').is(':checked')) {
            $('#short_url_provider').trigger('change');
        }
        
        // Initialize Join Affiliate Requirement visibility on page load
        if ($('#enable_affiliate_registration').is(':checked')) {
            $('#join_affiliate_requirement_row').show();
        } else {
            $('#join_affiliate_requirement_row').hide();
        }
    }

    // Initialize affiliate settings functionality if on the correct page
    if ($('#use_short_urls').length > 0 || $('#enable_affiliate_registration').length > 0) {
        initializeAffiliateSettings();
    }
});
