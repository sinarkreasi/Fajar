/**
 * ViraStore Customer Portal JavaScript - Emergency Fix
 * Minimal, bulletproof downloads functionality
 * 
 * @package ViraStore
 * @version 1.0.1
 */

(function($) {
    'use strict';
    
    // Error modal function for portal
    function showPortalError(title, message) {
        // Remove any existing error modal
        $('#vrstore-portal-error-modal').remove();
        
        const modalHTML = `
            <div id="vrstore-portal-error-modal" style="
                position: fixed; top: 0; left: 0; width: 100%; height: 100%;
                background: rgba(0,0,0,0.7); z-index: 99999; display: flex;
                align-items: center; justify-content: center;
            ">
                <div style="
                    background: white; padding: 25px; border-radius: 8px;
                    max-width: 450px; width: 90%; box-shadow: 0 4px 20px rgba(0,0,0,0.5);
                    border-left: 4px solid #dc3545;
                ">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                        <h3 style="margin: 0; color: #dc3545;">${title}</h3>
                        <button onclick="$('#vrstore-portal-error-modal').remove()" style="
                            background: none; border: none; font-size: 24px;
                            cursor: pointer; padding: 0; color: #999;
                        ">&times;</button>
                    </div>
                    <div style="margin-bottom: 20px; color: #333; line-height: 1.5;">
                        ${message}
                    </div>
                    <div style="text-align: center;">
                        <button onclick="$('#vrstore-portal-error-modal').remove()" style="
                            padding: 10px 20px; background: #dc3545; color: white;
                            border: none; border-radius: 4px; cursor: pointer;
                        ">Close</button>
                    </div>
                </div>
            </div>
        `;
        
        $('body').append(modalHTML);
        
        // Close modal when clicking outside
        $('#vrstore-portal-error-modal').on('click', function(e) {
            if (e.target === this) {
                $(this).remove();
            }
        });
    }

    // Working downloads handler
    function handleDownloadsClick(e) {
        
        try {
            e.preventDefault();
            e.stopPropagation();
            
            const $btn = $(e.target).closest('button, a, .vrstore-show-downloads');
            
            if ($btn.length === 0) {
                return false;
            }
            
            // Get data from button
            const productId = $btn.data('product-id') || $btn.attr('data-product-id');
            const orderId = $btn.data('order-id') || $btn.attr('data-order-id');
            const productTitle = $btn.data('product-title') || $btn.attr('data-product-title');
            
            
            if (!productId || !orderId) {
                const debugInfo = 'Button Debug Info:\\n' +
                    'Element: ' + $btn[0].tagName + '\\n' +
                    'Classes: ' + ($btn.attr('class') || 'none') + '\\n' +
                    'Text: ' + $btn.text() + '\\n' +
                    'Product ID: ' + (productId || 'missing') + '\\n' +
                    'Order ID: ' + (orderId || 'missing') + '\\n' +
                    'All data attributes: ' + JSON.stringify($btn.data());
                
                console.error('Download button missing data:', debugInfo);
                showPortalError('Missing Download Data', 'This download button is missing required information. Please refresh the page and try again.');
                return false;
            }
            
            // Create and show simple modal
            showDownloadsModal(productTitle, productId, orderId);
            
        } catch (error) {
            console.error('Download click error:', error);
            showPortalError('Download Error', 'An unexpected error occurred: ' + error.message);
        }
        
        return false;
    }
    
    // Simple modal function
    function showDownloadsModal(productTitle, productId, orderId) {
        // Remove existing modal
        $('#emergency-downloads-modal').remove();
        
        // Create simple modal HTML
        const modalHTML = `
            <div id="emergency-downloads-modal" style="
                position: fixed; top: 0; left: 0; width: 100%; height: 100%;
                background: rgba(0,0,0,0.5); z-index: 99999; display: flex;
                align-items: center; justify-content: center;
            ">
                <div style="
                    background: white; padding: 20px; border-radius: 8px;
                    max-width: 500px; width: 90%; max-height: 80vh; overflow-y: auto;
                    box-shadow: 0 4px 20px rgba(0,0,0,0.3);
                ">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                        <h3 style="margin: 0;">Downloads - ${productTitle || 'Product'}</h3>
                        <button onclick="$('#emergency-downloads-modal').remove()" style="
                            background: none; border: none; font-size: 24px;
                            cursor: pointer; padding: 0; line-height: 1;
                        ">&times;</button>
                    </div>
                    <div id="downloads-content">
                        <div style="text-align: center; padding: 20px;">
                            <div class="loading-spinner" style="
                                width: 20px; height: 20px; border: 2px solid #f3f3f3;
                                border-top: 2px solid #0073aa; border-radius: 50%;
                                animation: spin 1s linear infinite; display: inline-block;
                                margin-right: 10px;
                            "></div>
                            Loading downloads...
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        // Add spinner CSS
        if (!$('#spinner-css').length) {
            $('head').append(`
                <style id="spinner-css">
                    @keyframes spin {
                        0% { transform: rotate(0deg); }
                        100% { transform: rotate(360deg); }
                    }
                </style>
            `);
        }
        
        $('body').append(modalHTML);
        
        // Fetch downloads
        fetchDownloadsData(productId, orderId);
    }
    
    // Fetch downloads data
    function fetchDownloadsData(productId, orderId) {
        const ajaxUrl = (typeof vrstore_frontend !== 'undefined' && vrstore_frontend.ajax_url) ? 
                       vrstore_frontend.ajax_url : '/wp-admin/admin-ajax.php';
        
        $.ajax({
            url: ajaxUrl,
            type: 'POST',
            data: {
                action: 'vrstore_get_product_downloads',
                product_id: productId,
                order_id: orderId
            },
            timeout: 15000,
            success: function(response) {
                
                let files = [];
                if (response && response.success && response.data && response.data.files) {
                    files = response.data.files;
                } else if (Array.isArray(response)) {
                    files = response;
                }
                
                displayDownloadFiles(files);
            },
            error: function(xhr, status, error) {
                console.error('AJAX download error:', xhr, status, error);
                const errorMsg = xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message 
                    ? xhr.responseJSON.data.message 
                    : 'Failed to load downloads: ' + status;
                displayDownloadError(errorMsg);
            }
        });
    }
    
    // Display files in modal
    function displayDownloadFiles(files) {
        const $content = $('#downloads-content');
        
        if (!files || files.length === 0) {
            $content.html('<div style="text-align: center; padding: 20px; color: #666;">No download files available.</div>');
            return;
        }
        
        let html = '';
        files.forEach((file, index) => {
            const fileName = file.name || `Download ${index + 1}`;
            const fileUrl = file.url || file.file || '#';
            
            html += `
                <div style="
                    display: flex; align-items: center; padding: 12px;
                    border: 1px solid #ddd; border-radius: 4px;
                    margin-bottom: 8px; background: #f9f9f9;
                ">
                    <div style="flex: 1;">
                        <div style="font-weight: bold; margin-bottom: 4px;">${fileName}</div>
                        <div style="font-size: 12px; color: #666;">${fileUrl.substring(0, 50)}...</div>
                    </div>
                    <div>
                        <a href="${fileUrl}" target="_blank" style="
                            display: inline-block; padding: 8px 16px;
                            background: #0073aa; color: white; text-decoration: none;
                            border-radius: 4px; font-size: 14px;
                        ">Download</a>
                    </div>
                </div>
            `;
        });
        
        $content.html(html);
    }
    
    // Display error in modal
    function displayDownloadError(message) {
        $('#downloads-content').html(`
            <div style="text-align: center; padding: 20px; color: #d63638;">
                <strong>Error:</strong> ${message}
            </div>
        `);
    }
    
    // Global URL cleanup function
    function cleanUpUrlParams() {
        const currentUrl = new URL(window.location.href);
        let hasCleanup = false;
        
        // Remove refresh-related parameters
        if (currentUrl.searchParams.has('_refresh')) {
            currentUrl.searchParams.delete('_refresh');
            hasCleanup = true;
        }
        
        // Apply cleanup if needed
        if (hasCleanup) {
            window.history.replaceState(null, '', currentUrl.toString());
        }
    }
    
    // Document ready
    $(document).ready(function() {
        
        // Clean up URL parameters first
        cleanUpUrlParams();
        
        // Remove any existing event handlers first
        $(document).off('click', '.vrstore-show-downloads');
        $(document).off('click.debug-downloads');
        $(document).off('click.downloads-handler');
        
        // Add primary event handler
        $(document).on('click.downloads-handler', '.vrstore-show-downloads', handleDownloadsClick);
        
        // Backup handler for any element with download-related attributes or text
        $(document).on('click.downloads-backup', '[data-product-id][data-order-id], button:contains("Download"), a:contains("Download")', function(e) {
            const $el = $(this);
            
            // Check if this should be handled as a downloads button
            if ($el.hasClass('vrstore-show-downloads') || 
                ($el.data('product-id') && $el.data('order-id')) ||
                $el.text().toLowerCase().includes('download')) {
                
                handleDownloadsClick(e);
            }
        });
        
        // Check what we found
        setTimeout(function() {
            const $downloadsButtons = $('.vrstore-show-downloads');
            const $dataButtons = $('[data-product-id][data-order-id]');
            const $downloadTextButtons = $('button:contains("Download"), a:contains("Download")');
            
            
        }, 2000);
        
    });
    
    /**
     * ViraStore Customer Portal Main Object
     */
    const ViraStoreCustomerPortal = {
        
        // Configuration
        config: {
            selectors: {
                downloadsButton: '.vrstore-show-downloads',
                downloadsModal: '#vrstore-downloads-modal',
                downloadsModalTitle: '#vrstore-downloads-modal-title',
                downloadsList: '#vrstore-downloads-list',
                modalClose: '.vrstore-modal-close'
            },
            ajax: {
                timeout: 30000,
                retries: 3
            }
        },

        /**
         * Initialize the customer portal
         */
        init: function() {
            this.bindEvents();
            this.initDownloadsModal();
            this.clearStuckStates();
        },

        /**
         * Bind all portal events
         */
        bindEvents: function() {
            // Downloads modal events
            $(document).on('click', this.config.selectors.downloadsButton, this.handleDownloadsButtonClick.bind(this));
            $(document).on('click', this.config.selectors.modalClose, this.handleModalClose.bind(this));
            $(document).on('click', this.config.selectors.downloadsModal, this.handleModalOverlayClick.bind(this));
            
            // Keyboard events
            $(document).on('keydown', this.handleKeyboardEvents.bind(this));
        },

        /**
         * Handle downloads button click
         */
        handleDownloadsButtonClick: function(e) {
            e.preventDefault();
            e.stopPropagation();


            const $button = $(e.currentTarget);
            const productId = $button.data('product-id');
            const orderId = $button.data('order-id');
            const productTitle = $button.data('product-title');


            // Validate required data
            if (!productId || !orderId) {
                this.showError('Invalid download request. Missing product or order information.');
                return;
            }

            // Ensure button stays functional
            $button.removeClass('loading').prop('disabled', false);

            // Show modal
            this.openDownloadsModal(productTitle);

            // Fetch downloads
            this.fetchDownloads(productId, orderId, $button);
        },

        /**
         * Open the downloads modal
         */
        openDownloadsModal: function(productTitle) {
            const $modal = $(this.config.selectors.downloadsModal);
            const $title = $(this.config.selectors.downloadsModalTitle);
            const $list = $(this.config.selectors.downloadsList);

            if ($modal.length === 0) {
                this.createDownloadsModal();
                return;
            }

            // Update title
            $title.text('Downloads - ' + (productTitle || 'Product'));

            // Show loading state
            $list.html(this.getLoadingHTML());

            // Show modal
            $modal.show().css({
                'display': 'flex',
                'align-items': 'center',
                'justify-content': 'center'
            });

        },

        /**
         * Fetch downloads via AJAX
         */
        fetchDownloads: function(productId, orderId, $button) {

            const ajaxUrl = this.getAjaxUrl();
            
            $.ajax({
                url: ajaxUrl,
                type: 'POST',
                data: {
                    action: 'vrstore_get_product_downloads',
                    product_id: productId,
                    order_id: orderId
                },
                timeout: this.config.ajax.timeout,
                success: this.handleAjaxSuccess.bind(this, orderId),
                error: this.handleAjaxError.bind(this, $button, orderId)
            });
        },

        /**
         * Handle AJAX success response
         */
        handleAjaxSuccess: function(orderId, response) {

            let files = null;
            
            // Parse response structure
            if (response && response.success && response.data && response.data.files) {
                files = response.data.files;
            } else if (Array.isArray(response)) {
                files = response;
            } else if (response && response.files && Array.isArray(response.files)) {
                files = response.files;
            }

            if (files && files.length > 0) {
                this.displayDownloads(files);
            } else {
                const message = (response && response.data && response.data.message) || 'No download files found';
                this.showError(message);
            }
        },

        /**
         * Handle AJAX error
         */
        handleAjaxError: function($button, orderId, xhr, status, error) {
            
            // Try fallback data
            const fallbackData = $button.data('files');
            if (fallbackData) {
                try {
                    const files = typeof fallbackData === 'string' ? JSON.parse(fallbackData) : fallbackData;
                    if (Array.isArray(files) && files.length > 0) {
                        this.displayDownloads(files);
                        return;
                    }
                } catch (e) {
                }
            }

            // Show error
            const errorMessage = this.getErrorMessage(xhr, status);
            this.showError(errorMessage);
        },

        /**
         * Display downloads in modal
         */
        displayDownloads: function(files) {
            const $list = $(this.config.selectors.downloadsList);
            
            if (!files || files.length === 0) {
                $list.html('<div class="vrstore-no-downloads">No download files available.</div>');
                return;
            }

            let html = '<div class="vrstore-downloads-grid">';
            
            files.forEach((file, index) => {
                const fileName = file.name || `Download ${index + 1}`;
                const fileUrl = file.url || file.file || '#';
                const fileType = file.type || 'file';
                
                html += this.getDownloadItemHTML(fileName, fileUrl, fileType);
            });
            
            html += '</div>';
            html += this.getDownloadNoteHTML();
            
            $list.html(html);
        },

        /**
         * Show error message in modal
         */
        showError: function(message) {
            const $list = $(this.config.selectors.downloadsList);
            const html = `
                <div class="vrstore-downloads-error" style="text-align: center; padding: 20px; color: #d63638;">
                    <span class="dashicons dashicons-warning"></span>
                    <span style="margin-left: 8px;">${this.escapeHtml(message)}</span>
                </div>
            `;
            $list.html(html);
        },

        /**
         * Handle modal close
         */
        handleModalClose: function(e) {
            e.preventDefault();
            $(this.config.selectors.downloadsModal).hide();
        },

        /**
         * Handle modal overlay click
         */
        handleModalOverlayClick: function(e) {
            if (e.target === e.currentTarget) {
                $(this.config.selectors.downloadsModal).hide();
            }
        },

        /**
         * Handle keyboard events
         */
        handleKeyboardEvents: function(e) {
            if (e.key === 'Escape') {
                $(this.config.selectors.downloadsModal + ':visible').hide();
            }
        },

        /**
         * Initialize downloads modal if missing
         */
        initDownloadsModal: function() {
            if ($(this.config.selectors.downloadsModal).length === 0) {
                this.createDownloadsModal();
            }
        },

        /**
         * Create downloads modal HTML
         */
        createDownloadsModal: function() {
            const modalHTML = `
                <div id="vrstore-downloads-modal" class="vrstore-modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999;">
                    <div class="vrstore-modal-content" style="background: white; max-width: 600px; border-radius: 8px; box-shadow: 0 10px 25px rgba(0,0,0,0.3); margin: 5% auto; max-height: 80vh; overflow: auto;">
                        <div class="vrstore-modal-header" style="padding: 20px; border-bottom: 1px solid #ddd; display: flex; justify-content: space-between; align-items: center;">
                            <h3 id="vrstore-downloads-modal-title">Product Downloads</h3>
                            <button class="vrstore-modal-close" style="background: none; border: none; font-size: 24px; cursor: pointer;">&times;</button>
                        </div>
                        <div class="vrstore-modal-body" style="padding: 20px;">
                            <div id="vrstore-downloads-list"></div>
                        </div>
                    </div>
                </div>
            `;
            
            $('body').append(modalHTML);
        },

        /**
         * Clear stuck loading states
         */
        clearStuckStates: function() {
            // Clear any loading states on downloads buttons
            $(this.config.selectors.downloadsButton).removeClass('loading').prop('disabled', false);
            
            // Fix any buttons with "Processing..." text
            $('*:contains("Processing...")').filter((i, el) => {
                return $(el).text().trim() === 'Processing...';
            }).each((i, el) => {
                const $el = $(el);
                if ($el.hasClass('vrstore-show-downloads')) {
                    $el.html('Downloads').removeClass('loading').prop('disabled', false);
                }
            });
        },

        /**
         * Utility functions
         */
        getAjaxUrl: function() {
            if (typeof vrstore_frontend !== 'undefined' && vrstore_frontend.ajax_url) {
                return vrstore_frontend.ajax_url;
            }
            if (typeof ajaxurl !== 'undefined') {
                return ajaxurl;
            }
            return '/wp-admin/admin-ajax.php';
        },

        getErrorMessage: function(xhr, status) {
            if (status === 'timeout') return 'Request timed out. Please try again.';
            if (xhr.status === 403) return 'Access denied. Please log in again.';
            if (xhr.status === 404) return 'Download service not found.';
            return `Failed to load downloads. Status: ${status} (${xhr.status})`;
        },

        getLoadingHTML: function() {
            return `
                <div class="vrstore-loading" style="text-align: center; padding: 40px;">
                    <div class="vrstore-spinner" style="width: 20px; height: 20px; border: 2px solid #f3f3f3; border-top: 2px solid #0073aa; border-radius: 50%; animation: spin 1s linear infinite; display: inline-block;"></div>
                    <p style="margin-top: 10px;">Loading downloads...</p>
                </div>
            `;
        },

        getDownloadItemHTML: function(fileName, fileUrl, fileType) {
            return `
                <div class="vrstore-download-item" style="display: flex; align-items: center; gap: 12px; padding: 12px; border: 1px solid #ddd; border-radius: 6px; background: #f9f9f9; margin-bottom: 8px;">
                    <div class="vrstore-download-icon" style="color: #0073aa;">
                        <span class="dashicons dashicons-download"></span>
                    </div>
                    <div class="vrstore-download-info" style="flex: 1;">
                        <div class="vrstore-download-name" style="font-weight: 600; color: #333;">${this.escapeHtml(fileName)}</div>
                        ${fileType === 'url' ? `<div class="vrstore-download-url" style="font-size: 12px; color: #666; word-break: break-all;">${this.escapeHtml(fileUrl.substring(0, 60))}${fileUrl.length > 60 ? '...' : ''}</div>` : ''}
                    </div>
                    <div class="vrstore-download-action">
                        <a href="${this.escapeHtml(fileUrl)}" class="vrstore-btn vrstore-btn-primary vrstore-btn-sm" target="_blank" rel="noopener" style="display: inline-block; padding: 8px 16px; background: #0073aa; color: white; text-decoration: none; border-radius: 4px;">
                            <span class="dashicons dashicons-download"></span> Download
                        </a>
                    </div>
                </div>
            `;
        },

        getDownloadNoteHTML: function() {
            return `
                <div class="vrstore-downloads-note" style="margin-top: 16px; padding: 12px; background: #e7f3ff; border-left: 4px solid #0073aa; border-radius: 3px; font-size: 13px; color: #333;">
                    <strong>📥 Download Note:</strong> All files are associated with your purchase. External links will open in a new tab.
                </div>
            `;
        },

        escapeHtml: function(text) {
            const map = {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            };
            return text.toString().replace(/[&<>"']/g, m => map[m]);
        }
    };

    // Helper functions for Edit Profile
    function validateEditProfileForm($form) {
        let isValid = true;
        
        // Clear previous errors
        $('.vrstore-form-error').remove();
        
        // Validate required fields
        $form.find('[required]').each(function() {
            const $field = $(this);
            const value = $field.val().trim();
            
            if (!value) {
                isValid = false;
                $field.after('<div class="vrstore-form-error">This field is required.</div>');
            }
        });
        
        // Validate email format
        const $emailField = $form.find('input[type="email"]');
        if ($emailField.length && $emailField.val()) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test($emailField.val())) {
                isValid = false;
                $emailField.after('<div class="vrstore-form-error">Please enter a valid email address.</div>');
            }
        }
        
        return isValid;
    }

    function showEditProfileMessage(type, message) {
        const $modalBody = $('#vrstore-edit-profile-modal .vrstore-modal-body');
        const $existingMessage = $modalBody.find('.vrstore-modal-success, .vrstore-modal-error');
        
        // Remove existing messages
        $existingMessage.remove();
        
        // Create new message
        const messageClass = type === 'success' ? 'vrstore-modal-success' : 'vrstore-modal-error';
        const iconClass = type === 'success' ? 'dashicons-yes-alt' : 'dashicons-warning';
        
        const $message = $('<div class="' + messageClass + '">' +
            '<span class="dashicons ' + iconClass + '"></span>' +
            '<span>' + message + '</span>' +
            '</div>');
        
        $modalBody.prepend($message);
        
        // Auto-remove error messages after 5 seconds
        if (type === 'error') {
            setTimeout(function() {
                $message.fadeOut(300, function() {
                    $(this).remove();
                });
            }, 5000);
        }
    }

    /**
     * Initialize on document ready
     */
    $(document).ready(function() {
        // Only initialize on customer portal pages
        if ($('.vrstore-customer-portal, [data-vrstore-portal]').length > 0 || 
            $('.vrstore-show-downloads').length > 0) {
            ViraStoreCustomerPortal.init();
        }

        // Handle Edit Profile form submission using unified modal system
        $(document).on('submit', '#vrstore-edit-profile-form', function(e) {
            e.preventDefault();
            
            const $form = $(this);
            const $saveBtn = $form.find('.vrstore-save-profile-btn');
            
            // Validate form
            if (!validateEditProfileForm($form)) {
                return;
            }
            
            // Show loading state
            $saveBtn.prop('disabled', true);
            $saveBtn.find('.vrstore-button-text').hide();
            $saveBtn.find('.vrstore-button-spinner').show();
            
            // Prepare form data
            const formData = new FormData($form[0]);
            formData.append('action', 'vrstore_update_customer_profile');
            
            // Submit via AJAX
            $.ajax({
                url: vrstore_ajax.ajax_url,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        showEditProfileMessage('success', response.data.message || 'Profile updated successfully!');
                        
                        // Update the greeting text if display name changed
                        const newDisplayName = $('#profile_display_name').val();
                        if (newDisplayName) {
                            $('.vrstore-user-greeting').text('Hello, ' + newDisplayName);
                        }
                        
                        // Close modal after a delay
                        setTimeout(() => {
                            $('#vrstore-edit-profile-modal').removeClass('vrstore-modal-visible').hide();
                            $('body').removeClass('vrstore-modal-open');
                        }, 2000);
                    } else {
                        showEditProfileMessage('error', response.data || 'Failed to update profile.');
                    }
                },
                error: function() {
                    showEditProfileMessage('error', 'Network error occurred. Please try again.');
                },
                complete: function() {
                    // Reset button state
                    $saveBtn.prop('disabled', false);
                    $saveBtn.find('.vrstore-button-text').show();
                    $saveBtn.find('.vrstore-button-spinner').hide();
                }
            });
        });

        // Expose globally for debugging
        window.ViraStoreCustomerPortal = ViraStoreCustomerPortal;
    });

})(jQuery);
