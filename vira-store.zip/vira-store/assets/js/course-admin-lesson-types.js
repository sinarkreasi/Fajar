/**
 * Course Admin - Lesson Types Handler
 * Handles switching between different lesson types (video upload, video URL, shortcode)
 */

jQuery(document).ready(function ($) {
    'use strict';

    // Handle lesson type changes
    $(document).on('change', '.lesson-type', function () {
        var $this = $(this);
        var selectedType = $this.val();
        var $lessonItem = $this.closest('.vrstore-curriculum-lesson');

        // Hide all type-specific fields first
        $lessonItem.find('.lesson-video-upload-fields').hide();
        $lessonItem.find('.lesson-video-url-fields').hide();
        $lessonItem.find('.lesson-shortcode-fields').hide();

        // Show the appropriate fields based on selected type
        switch (selectedType) {
            case 'video_upload':
                $lessonItem.find('.lesson-video-upload-fields').show();
                break;
            case 'video_url':
                $lessonItem.find('.lesson-video-url-fields').show();
                break;
            case 'shortcode':
                $lessonItem.find('.lesson-shortcode-fields').show();
                break;
        }
    });

    // Initialize lesson type fields on page load
    $('.lesson-type').each(function () {
        $(this).trigger('change');
    });

    // Handle adding new lessons - ensure proper initialization
    $(document).on('click', '.vrstore-add-lesson', function () {
        setTimeout(function () {
            $('.lesson-type').each(function () {
                var $this = $(this);
                if (!$this.data('initialized')) {
                    $this.trigger('change');
                    $this.data('initialized', true);
                }
            });
        }, 100);
    });

    // Handle shortcode validation
    $(document).on('blur', 'textarea[name*="[shortcode_content]"]', function () {
        var $this = $(this);
        var shortcodeContent = $this.val().trim();

        if (shortcodeContent && !shortcodeContent.match(/^\[.*\]$/)) {
            // Basic shortcode format validation
            var $warning = $this.siblings('.shortcode-warning');
            if ($warning.length === 0) {
                $this.after('<div class="shortcode-warning" style="color: #d63638; font-size: 12px; margin-top: 5px;">⚠️ Make sure your shortcode is properly formatted (e.g., [shortcode param="value"])</div>');
            }
        } else {
            $this.siblings('.shortcode-warning').remove();
        }
    });

    // Add shortcode examples helper
    $(document).on('focus', 'textarea[name*="[shortcode_content]"]', function () {
        var $this = $(this);
        var $helper = $this.siblings('.shortcode-helper');

        if ($helper.length === 0 && $this.val().trim() === '') {
            $this.after('<div class="shortcode-helper" style="color: #666; font-size: 11px; margin-top: 3px; font-style: italic;">Examples: [video src="url"], [gallery ids="1,2,3"], [embed]url[/embed], [your_plugin_shortcode]</div>');
        }
    });

    $(document).on('blur', 'textarea[name*="[shortcode_content]"]', function () {
        var $this = $(this);
        if ($this.val().trim() !== '') {
            $this.siblings('.shortcode-helper').remove();
        }
    });
});