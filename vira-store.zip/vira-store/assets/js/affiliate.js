/**
 * Affiliate System JavaScript
 * 
 * @package Vira_Store
 * @since 1.0.0
 */

(function($) {
    'use strict';

    /**
     * Affiliate System Class
     */
    class VRStoreAffiliate {
        constructor() {
            this.init();
        }

        /**
         * Initialize the affiliate system
         */
        init() {
            this.bindEvents();
            this.initCopyLinks();
        }

        /**
         * Bind event handlers
         */
        bindEvents() {
            // Affiliate registration form
            $(document).on('submit', '#affiliate-registration-form', this.handleRegistration.bind(this));
            
            // Copy affiliate link
            $(document).on('click', '.vrstore-copy-link', this.copyAffiliateLink.bind(this));
            $(document).on('click', '.compact-copy-btn', this.copyCompactLink.bind(this));
            
            // Refresh stats
            $(document).on('click', '.vrstore-refresh-stats', this.refreshStats.bind(this));
            
            // Link type change for dynamic URL generation
            $(document).on('change', '#link_type', this.handleLinkTypeChange.bind(this));
            
            // Payment History
            $(document).on('click', '.vrstore-payment-history', this.showPaymentHistory.bind(this));
            
            // Withdrawal Request
            $(document).on('click', '.vrstore-withdrawal-btn:not(:disabled)', this.requestWithdrawal.bind(this));
            
            // Modal close functionality
            $(document).on('click', '.vrstore-modal-close', this.closeModal.bind(this));
            $(document).on('click', '.vrstore-modal', function(e) {
                if (e.target === this) {
                    $('.vrstore-modal').css('display', 'none');
                }
            });
            
            // Admin copy code functionality (for affiliate detail page)
            $(document).on('click', '.copy-code', this.copyReferralCode.bind(this));
            
            // Performance Analytics Tab Switching
            $(document).on('click', '.perf-tab', this.handlePerformanceTabSwitch.bind(this));
            
            // Auto-refresh stats every 30 seconds
            setInterval(() => {
                this.refreshStats(null, true); // Silent refresh
            }, 30000);
        }

        /**
         * Initialize copy link functionality
         */
        initCopyLinks() {
            // Check if clipboard API is supported
            if (!navigator.clipboard) {
                $('.vrstore-copy-link').prop('disabled', true).text('Not Supported');
            }
        }

        /**
         * Handle affiliate registration
         */
        async handleRegistration(e) {
            e.preventDefault();
            
            const $form = $(e.target);
            const $button = $form.find('button[type="submit"]');
            const originalText = $button.find('.btn-text').text() || $button.text();
            
            // Show loading state
            this.setLoadingState($button, true);
            $button.find('.btn-text').hide();
            $button.find('.btn-loading').show();
            
            // Collect form data
            const formData = new FormData($form[0]);
            const requestData = {
                nonce: formData.get('vrstore_affiliate_nonce'),
                affiliate_name: formData.get('affiliate_name'),
                affiliate_email: formData.get('affiliate_email'),
                website_url: formData.get('website_url'),
                promotion_methods: formData.get('promotion_methods'),
                payment_method: formData.get('payment_method'),
                payment_details: formData.get('payment_details'),
                agree_terms: formData.get('agree_terms')
            };
            
            try {
                const response = await this.makeAjaxRequest('register_affiliate', requestData);
                
                if (response.success) {
                    this.showMessage(response.data.message || 'Registration successful! Please wait for approval.', 'success');
                    
                    // Reload the page after successful registration
                    setTimeout(() => {
                        window.location.reload();
                    }, 2000);
                } else {
                    this.showMessage(response.data || 'Registration failed. Please try again.', 'error');
                }
            } catch (error) {
                this.showMessage('An error occurred. Please try again.', 'error');
                console.error('Affiliate registration error:', error);
            } finally {
                this.setLoadingState($button, false, originalText);
                $button.find('.btn-loading').hide();
                $button.find('.btn-text').show();
            }
        }

        /**
         * Copy affiliate link to clipboard
         */
        async copyAffiliateLink(e) {
            e.preventDefault();
            
            const $button = $(e.target);
            const $input = $button.siblings('input[type="text"]');
            const link = $input.val();
            
            if (!link) {
                this.showMessage('No link to copy.', 'error');
                return;
            }
            
            try {
                await navigator.clipboard.writeText(link);
                
                // Visual feedback
                const originalText = $button.text();
                $button.text('Copied!').addClass('vrstore-copy-success');
                
                setTimeout(() => {
                    $button.text(originalText).removeClass('vrstore-copy-success');
                }, 2000);
                
                this.showMessage('Affiliate link copied to clipboard!', 'success');
            } catch (error) {
                // Fallback for older browsers
                this.fallbackCopyText(link);
                console.error('Clipboard API failed, using fallback:', error);
            }
        }

        /**
         * Fallback copy method for older browsers
         */
        fallbackCopyText(text) {
            const textArea = document.createElement('textarea');
            textArea.value = text;
            textArea.style.position = 'fixed';
            textArea.style.left = '-999999px';
            textArea.style.top = '-999999px';
            document.body.appendChild(textArea);
            textArea.focus();
            textArea.select();
            
            try {
                document.execCommand('copy');
                this.showMessage('Affiliate link copied to clipboard!', 'success');
            } catch (error) {
                this.showMessage('Failed to copy link. Please copy manually.', 'error');
            }
            
            document.body.removeChild(textArea);
        }

        /**
         * Copy compact affiliate link
         */
        async copyCompactLink(e) {
            e.preventDefault();
            
            const $button = $(e.target).closest('.compact-copy-btn');
            const targetSelector = $button.data('target');
            const $input = $(targetSelector);
            const link = $input.val();
            
            if (!link) {
                this.showMessage('No link to copy.', 'error');
                return;
            }
            
            try {
                await navigator.clipboard.writeText(link);
                
                // Visual feedback
                const originalIcon = $button.find('.dashicons').attr('class');
                $button.find('.dashicons').attr('class', 'dashicons dashicons-yes-alt');
                $button.addClass('copied');
                
                setTimeout(() => {
                    $button.find('.dashicons').attr('class', originalIcon);
                    $button.removeClass('copied');
                }, 2000);
                
                this.showMessage('Link copied to clipboard!', 'success');
            } catch (error) {
                // Fallback for older browsers
                this.fallbackCopyText(link);
                console.error('Clipboard API failed, using fallback:', error);
            }
        }

        /**
         * Handle link type change for dynamic URL generation
         */
        async handleLinkTypeChange(e) {
            const linkType = $(e.target).val();
            const $regularInput = $('#affiliate-link-regular');
            const $shortInput = $('#affiliate-link-short');
            
            // Show loading state
            $regularInput.addClass('loading');
            if ($shortInput.length) {
                $shortInput.addClass('loading');
            }
            
            try {
                const response = await this.makeAjaxRequest('generate_affiliate_links', {
                    nonce: vrstore_affiliate_ajax.nonce,
                    link_type: linkType
                });
                
                if (response.success) {
                    // Update regular link
                    $regularInput.val(response.data.regular_link);
                    
                    // Update short link if available
                    if (response.data.short_link && $shortInput.length) {
                        $shortInput.val(response.data.short_link);
                        
                        // Update provider badge if available
                        if (response.data.provider) {
                            const $badge = $shortInput.siblings('.link-badge');
                            $badge.removeClass('provider-dns provider-bitly provider-rebrandly')
                                  .addClass('provider-' + response.data.provider);
                            
                            // Update badge text
                            switch (response.data.provider) {
                                case 'bitly':
                                    $badge.text('Bitly');
                                    break;
                                case 'rebrandly':
                                    $badge.text('Rebrandly');
                                    break;
                                default:
                                    $badge.text('Short');
                                    break;
                            }
                        }
                    }
                } else {
                    this.showMessage(response.data.message || 'Failed to generate links.', 'error');
                }
            } catch (error) {
                this.showMessage('An error occurred while generating links.', 'error');
                console.error('Link generation error:', error);
            } finally {
                $regularInput.removeClass('loading');
                if ($shortInput.length) {
                    $shortInput.removeClass('loading');
                }
            }
        }

        /**
         * Refresh affiliate statistics
         */
        async refreshStats(e = null, silent = false) {
            let $button = null;
            let originalText = '';
            
            if (e && e.target) {
                $button = $(e.target);
                originalText = $button.text();
                this.setLoadingState($button, true);
            }
            
            try {
                const response = await this.makeAjaxRequest('refresh_affiliate_stats', {
                    nonce: vrstore_affiliate_ajax.nonce
                });
                
                if (response.success) {
                    this.updateStatsDisplay(response.data.stats);
                    if (!silent) {
                        this.showMessage('Statistics refreshed successfully!', 'success');
                    }
                } else {
                    if (!silent) {
                        this.showMessage(response.data.message || 'Failed to refresh statistics.', 'error');
                    }
                }
            } catch (error) {
                if (!silent) {
                    this.showMessage('An error occurred while refreshing statistics.', 'error');
                }
                console.error('Stats refresh error:', error);
            } finally {
                if ($button) {
                    this.setLoadingState($button, false, originalText);
                }
            }
        }

        /**
         * Handle performance analytics tab switching
         */
        handlePerformanceTabSwitch(e) {
            e.preventDefault();
            
            const $clickedTab = $(e.target);
            const period = $clickedTab.data('period');
            
            // Update active tab
            $('.perf-tab').removeClass('active');
            $clickedTab.addClass('active');
            
            // Show/hide chart containers
            $('.performance-chart').hide();
            $(`#performance-chart-${period}`).show();
            
            // Load performance data for selected period
            this.loadPerformanceData(period);
        }

        /**
         * Load performance data for specific period
         */
        async loadPerformanceData(period) {
            const $chartContainer = $(`#performance-chart-${period}`);
            
            try {
                const response = await this.makeAjaxRequest('get_affiliate_performance', {
                    nonce: vrstore_affiliate_ajax.nonce,
                    period: period
                });
                
                if (response.success) {
                    this.updatePerformanceChart(period, response.data);
                    // Update performance summary with currency formatting
                    if (response.data.summary) {
                        this.updatePerformanceSummary(response.data.summary);
                    }
                } else {
                    $chartContainer.html('<div class="chart-error">Failed to load performance data</div>');
                }
            } catch (error) {
                $chartContainer.html('<div class="chart-error">Error loading performance data</div>');
                console.error('Performance data error:', error);
            }
        }

        /**
         * Update performance chart display
         */
        updatePerformanceChart(period, data) {
            const $chartContainer = $(`#performance-chart-${period}`);
            
            if (data && data.length > 0) {
                // Simple chart implementation - you can enhance this with Chart.js if needed
                let chartHTML = '<div class="simple-chart">';
                
                data.forEach((item, index) => {
                    const height = Math.max(10, (item.value / Math.max(...data.map(d => d.value))) * 100);
                    chartHTML += `<div class="chart-bar" style="height: ${height}%" title="${item.label}: ${item.value}"></div>`;
                });
                
                chartHTML += '</div>';
                $chartContainer.html(chartHTML);
            } else {
                $chartContainer.html('<div class="chart-placeholder"><p>No performance data available for this period</p></div>');
            }
        }

        /**
         * Update statistics display
         */
        updateStatsDisplay(stats) {
            const $statsContainer = $('.vrstore-affiliate-stats-grid');
            
            if (stats && $statsContainer.length) {
                // Update individual stat values
                Object.keys(stats).forEach(key => {
                    const $statElement = $statsContainer.find(`[data-stat="${key}"]`);
                    if ($statElement.length) {
                        // Special handling for earnings which comes pre-formatted from backend
                        if (key === 'earnings') {
                            $statElement.text(stats[key]);
                        } else {
                            // For numeric values, use animation
                            this.animateNumber($statElement, stats[key]);
                        }
                    }
                });
            }
        }

        /**
         * Animate number changes
         */
        animateNumber($element, newValue) {
            const currentValue = parseInt($element.text()) || 0;
            const increment = (newValue - currentValue) / 20;
            let current = currentValue;
            
            const timer = setInterval(() => {
                current += increment;
                if ((increment > 0 && current >= newValue) || (increment < 0 && current <= newValue)) {
                    current = newValue;
                    clearInterval(timer);
                }
                $element.text(Math.round(current));
            }, 50);
        }

        /**
         * Make AJAX request
         */
        async makeAjaxRequest(action, data = {}) {
            const requestData = {
                action: `vrstore_${action}`,
                ...data
            };
            
            return new Promise((resolve, reject) => {
                $.ajax({
                    url: vrstore_affiliate_ajax.ajax_url,
                    type: 'POST',
                    data: requestData,
                    timeout: 30000,
                    success: resolve,
                    error: (xhr, status, error) => {
                        reject(new Error(`AJAX Error: ${status} - ${error}`));
                    }
                });
            });
        }

        /**
         * Set loading state for buttons
         */
        setLoadingState($button, loading, originalText = '') {
            if (loading) {
                $button.prop('disabled', true).addClass('vrstore-loading');
                if (originalText) {
                    $button.data('original-text', originalText);
                }
            } else {
                $button.prop('disabled', false).removeClass('vrstore-loading');
                if (originalText) {
                    $button.text(originalText);
                }
            }
        }

        /**
         * Show message to user
         */
        showMessage(message, type = 'info') {
            const $messagesContainer = $('#affiliate-messages');
            if (!$messagesContainer.length) {
                return;
            }
            
            const messageClass = `affiliate-message affiliate-message-${type}`;
            const $message = $(`<div class="${messageClass}">${message}</div>`);
            
            $messagesContainer.empty().append($message);
            
            // Auto-hide after 5 seconds
            setTimeout(() => {
                $message.fadeOut(() => {
                    $message.remove();
                });
            }, 5000);
        }

        /**
         * Show payment history
         */
        async showPaymentHistory(e) {
            e.preventDefault();
            
            const $button = $(e.target);
            const affiliateId = $button.data('affiliate-id');
            
            // Show modal with proper display method
            const $modal = $('#payment-history-modal');
            $modal.css('display', 'flex');
            
            // Show loading state
            $('#payment-history-content').html('<div class="vrstore-loading">Loading payment history...</div>');
            
            try {
                const response = await this.makeAjaxRequest('get_payment_history', {
                    nonce: vrstore_affiliate_ajax.nonce,
                    affiliate_id: affiliateId
                });
                
                if (response.success) {
                    this.renderPaymentHistory(response.data.payments);
                } else {
                    $('#payment-history-content').html('<div class="error">Failed to load payment history.</div>');
                }
            } catch (error) {
                $('#payment-history-content').html('<div class="error">Error loading payment history.</div>');
                console.error('Payment history error:', error);
            }
        }

        /**
         * Render payment history in modal
         */
        renderPaymentHistory(payments) {
            let html = '';
            
            if (payments && payments.length > 0) {
                html = `
                    <table class="vrstore-payment-table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Amount</th>
                                <th>Method</th>
                                <th>Status</th>
                                <th>Reference</th>
                            </tr>
                        </thead>
                        <tbody>
                `;
                
                payments.forEach(payment => {
                    html += `
                        <tr>
                            <td>${payment.date}</td>
                            <td>${payment.amount}</td>
                            <td>${payment.method}</td>
                            <td><span class="payment-status status-${payment.status}">${payment.status}</span></td>
                            <td>${payment.reference || '—'}</td>
                        </tr>
                    `;
                });
                
                html += `
                        </tbody>
                    </table>
                `;
            } else {
                html = '<div class="no-payments">No payment history found.</div>';
            }
            
            $('#payment-history-content').html(html);
        }

        /**
         * Request withdrawal
         */
        async requestWithdrawal(e) {
            e.preventDefault();
            
            const $button = $(e.target);
            const affiliateId = $button.data('affiliate-id');
            const currentEarnings = parseFloat($button.data('current-earnings'));
            const minimumPayout = parseFloat($button.data('minimum-payout'));
            
            // Get formatted currency strings for display
            let availableFormatted, minimumFormatted;
            
            try {
                // Try to get formatted currency from server
                const currencyResponse = await this.makeAjaxRequest('format_currency_amounts', {
                    nonce: vrstore_affiliate_ajax.nonce,
                    amounts: [currentEarnings, minimumPayout]
                });
                
                if (currencyResponse.success && currencyResponse.data) {
                    availableFormatted = currencyResponse.data[0] || `$${currentEarnings.toFixed(2)}`;
                    minimumFormatted = currencyResponse.data[1] || `$${minimumPayout.toFixed(2)}`;
                } else {
                    // Fallback to USD format
                    availableFormatted = `$${currentEarnings.toFixed(2)}`;
                    minimumFormatted = `$${minimumPayout.toFixed(2)}`;
                }
            } catch (error) {
                // Fallback to USD format on error
                availableFormatted = `$${currentEarnings.toFixed(2)}`;
                minimumFormatted = `$${minimumPayout.toFixed(2)}`;
                console.warn('Currency formatting failed, using fallback:', error);
            }
            
            if (currentEarnings < minimumPayout) {
                this.showMessage(`Minimum withdrawal amount is ${minimumFormatted}`, 'error');
                return;
            }
            
            const amount = prompt(`Enter withdrawal amount (Available: ${availableFormatted}):`);
            
            if (!amount || isNaN(amount)) {
                return;
            }
            
            const withdrawalAmount = parseFloat(amount);
            
            if (withdrawalAmount < minimumPayout) {
                this.showMessage(`Minimum withdrawal amount is ${minimumFormatted}`, 'error');
                return;
            }
            
            if (withdrawalAmount > currentEarnings) {
                this.showMessage('Withdrawal amount exceeds available earnings.', 'error');
                return;
            }
            
            // Show loading state
            this.setLoadingState($button, true);
            
            try {
                const response = await this.makeAjaxRequest('request_withdrawal', {
                    nonce: vrstore_affiliate_ajax.nonce,
                    affiliate_id: affiliateId,
                    amount: withdrawalAmount
                });
                
                if (response.success) {
                    this.showMessage(response.data.message || 'Withdrawal request submitted successfully!', 'success');
                    // Refresh stats to update earnings
                    setTimeout(() => {
                        this.refreshStats(null, true);
                    }, 1000);
                } else {
                    this.showMessage(response.data.message || 'Failed to submit withdrawal request.', 'error');
                }
            } catch (error) {
                this.showMessage('An error occurred while submitting withdrawal request.', 'error');
                console.error('Withdrawal request error:', error);
            } finally {
                this.setLoadingState($button, false);
            }
        }

        /**
         * Close modal
         */
        closeModal(e) {
            e.preventDefault();
            $('.vrstore-modal').css('display', 'none');
        }

        /**
         * Update performance summary with properly formatted currency
         */
        async updatePerformanceSummary(summary) {
            if (summary) {
                // Update best day
                if (summary.bestDay) {
                    $('[data-metric="best-day"]').text(summary.bestDay);
                }
                
                // Update average daily with currency formatting
                if (summary.avgDaily !== undefined) {
                    try {
                        const currencyResponse = await this.makeAjaxRequest('format_currency_amounts', {
                            nonce: vrstore_affiliate_ajax.nonce,
                            amounts: [summary.avgDaily]
                        });
                        
                        const formattedAmount = (currencyResponse.success && currencyResponse.data) 
                            ? currencyResponse.data[0] 
                            : `$${parseFloat(summary.avgDaily).toFixed(2)}`;
                            
                        $('[data-metric="avg-daily"]').text(formattedAmount);
                    } catch (error) {
                        // Fallback formatting
                        $('[data-metric="avg-daily"]').text(`$${parseFloat(summary.avgDaily).toFixed(2)}`);
                        console.warn('Currency formatting failed for avg daily:', error);
                    }
                }
                
                // Update growth percentage
                if (summary.growth !== undefined) {
                    $('[data-metric="growth"]').text(`${parseFloat(summary.growth).toFixed(1)}%`);
                }
            }
        }

        /**
         * Copy referral code
         */
        async copyReferralCode(e) {
            e.preventDefault();
            const $button = $(e.target);
            const code = $button.data('code');
            
            try {
                await navigator.clipboard.writeText(code);
                const originalText = $button.text();
                $button.text('Copied!');
                
                setTimeout(() => {
                    $button.text(originalText);
                }, 2000);
            } catch (error) {
                console.error('Failed to copy code:', error);
            }
        }
    }

    // Initialize when document is ready
    $(document).ready(function() {
        new VRStoreAffiliate();
    });

})(jQuery);