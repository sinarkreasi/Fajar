/**
 * Taxonomy Restriction Admin JavaScript
 *
 * Handles the functionality for the taxonomy restriction fields
 * in the WordPress taxonomy editor (edit-tags.php).
 *
 * @package Vira_Store
 * @since   1.0.0
 */

(function($) {
    'use strict';

    /**
     * Taxonomy Restriction Admin functionality
     */
    var TaxonomyRestrictionAdmin = {
        
        /**
         * Initialize the functionality
         */
        init: function() {
            this.bindEvents();
            this.initializeFields();
        },

        /**
         * Bind event handlers
         */
        bindEvents: function() {
            // Toggle restriction settings visibility
            $(document).on('change', '#vrstore_taxonomy_restricted', this.toggleRestrictionSettings);
            
            // Handle form submission to ensure proper validation
            $(document).on('submit', '#addtag, #edittag', this.validateForm);
            
            // Initialize on page load for edit forms
            $(document).ready(function() {
                TaxonomyRestrictionAdmin.toggleRestrictionSettings();
            });
        },

        /**
         * Initialize fields on page load
         */
        initializeFields: function() {
            // Set initial state for restriction settings
            this.toggleRestrictionSettings();
            
            // Style the multi-select dropdowns
            this.styleMultiSelects();
        },

        /**
         * Toggle restriction settings visibility
         */
        toggleRestrictionSettings: function() {
            var $checkbox = $('#vrstore_taxonomy_restricted');
            var $settings = $('#vrstore-taxonomy-restriction-settings, .term-restriction-settings');
            
            if ($checkbox.is(':checked')) {
                $settings.slideDown(300);
            } else {
                $settings.slideUp(300);
            }
        },

        /**
         * Style multi-select dropdowns
         */
        styleMultiSelects: function() {
            var $selects = $('#vrstore_required_products, #vrstore_required_courses');
            
            $selects.css({
                'border': '1px solid #ddd',
                'border-radius': '4px',
                'padding': '5px',
                'font-size': '13px'
            });
        },

        /**
         * Validate form before submission
         */
        validateForm: function(e) {
            var $restrictedCheckbox = $('#vrstore_taxonomy_restricted');
            
            if ($restrictedCheckbox.is(':checked')) {
                var $products = $('#vrstore_required_products');
                var $courses = $('#vrstore_required_courses');
                
                var hasProducts = $products.val() && $products.val().length > 0;
                var hasCourses = $courses.val() && $courses.val().length > 0;
                
                if (!hasProducts && !hasCourses) {
                    alert('Please select at least one required product or course for the restriction, or disable content restriction.');
                    e.preventDefault();
                    return false;
                }
            }
            
            return true;
        },

        /**
         * Show success message after saving
         */
        showSuccessMessage: function(message) {
            var $notice = $('<div class="notice notice-success is-dismissible"><p>' + message + '</p></div>');
            $('.wrap h1').after($notice);
            
            // Auto-dismiss after 3 seconds
            setTimeout(function() {
                $notice.fadeOut();
            }, 3000);
        },

        /**
         * Show error message
         */
        showErrorMessage: function(message) {
            var $notice = $('<div class="notice notice-error is-dismissible"><p>' + message + '</p></div>');
            $('.wrap h1').after($notice);
        }
    };

    // Initialize when document is ready
    $(document).ready(function() {
        TaxonomyRestrictionAdmin.init();
    });

    // Make it globally available
    window.TaxonomyRestrictionAdmin = TaxonomyRestrictionAdmin;

})(jQuery);