/**
 * TriPay Checkout JavaScript
 * 
 * Handles TriPay payment method selection and form submission
 * 
 * @package Vira_Store
 * @since 1.0.0
 */

(function($) {
    'use strict';

    // TriPay payment methods configuration
    const tripayMethods = {
        'MYBVA': 'Maybank Virtual Account',
        'PERMATAVA': 'Permata Virtual Account',
        'BNIVA': 'BNI Virtual Account',
        'BRIVA': 'BRI Virtual Account',
        'MANDIRIVA': 'Mandiri Virtual Account',
        'BCAVA': 'BCA Virtual Account',
        'SMSVA': 'SMS Banking Virtual Account',
        'MUAMALAT': 'Muamalat Virtual Account',
        'CIMBVA': 'CIMB Virtual Account',
        'BSIVA': 'BSI Virtual Account',
        'ALFAMART': 'Alfamart',
        'INDOMARET': 'Indomaret',
        'OVO': 'OVO E-Wallet',
        'DANA': 'DANA E-Wallet',
        'SHOPEEPAY': 'ShopeePay E-Wallet',
        'LINKAJA': 'LinkAja E-Wallet',
        'QRIS': 'QRIS'
    };

    // TriPay Checkout Handler
    window.VrStore_TriPay = {
        
        /**
         * Initialize TriPay payment method handling
         */
        init: function() {
            this.bindEvents();
        },

        /**
         * Bind event listeners
         */
        bindEvents: function() {
            // Listen for payment method changes
            $(document).on('change', 'select[name="vrstore_payment_method"]', this.handlePaymentMethodChange.bind(this));
            
            // Handle form submission for TriPay
            $(document).on('submit', '.vrstore-checkout-form', this.handleFormSubmission.bind(this));
        },

        /**
         * Handle payment method selection changes
         */
        handlePaymentMethodChange: function(e) {
            const paymentMethod = e.target.value;
            
            if (paymentMethod === 'tripay') {
                this.showTriPayOptions();
            } else {
                this.hideTriPayOptions();
            }
        },

        /**
         * Show TriPay payment options
         */
        showTriPayOptions: function() {
            // TriPay options are already shown in the form
            // This function can be used for additional UI enhancements if needed
        },

        /**
         * Hide TriPay payment options
         */
        hideTriPayOptions: function() {
            // TriPay options are part of the form
            // This function can be used for additional UI enhancements if needed
        },

        /**
         * Handle form submission for TriPay payments
         */
        handleFormSubmission: function(e) {
            const form = e.target;
            const formData = new FormData(form);
            const paymentMethod = formData.get('vrstore_payment_method');
            
            if (paymentMethod === 'tripay') {
                const selectedTripayMethod = $('#tripay_method').val();
                
                if (!selectedTripayMethod) {
                    e.preventDefault();
                    this.showError('Silakan pilih metode pembayaran TriPay.');
                    return false;
                }
                
                // Prevent default form submission
                e.preventDefault();
                
                // Process payment via AJAX
                this.processTripayPayment(form, selectedTripayMethod);
                
                console.log('[ViraStore TriPay] Processing payment with method:', selectedTripayMethod);
                
                return false;
            }
        },

        /**
         * Process TriPay payment via AJAX
         */
        processTripayPayment: function(form, paymentMethod) {
            // Show loading state
            const $submitBtn = $(form).find('button[type="submit"]');
            const originalText = $submitBtn.text();
            $submitBtn.prop('disabled', true).text('Processing...');
            
            // Prepare form data
            const formData = new FormData(form);
            formData.append('action', 'vrstore_process_tripay_payment');
            formData.append('tripay_method', paymentMethod);
            
            const ajaxUrl = (typeof vrstore_ajax !== 'undefined' && vrstore_ajax.ajax_url)
                ? vrstore_ajax.ajax_url
                : (typeof ajaxurl !== 'undefined' ? ajaxurl : '/wp-admin/admin-ajax.php');

            // Make AJAX request
            $.ajax({
                url: ajaxUrl,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                dataType: 'text',
                success: function(rawResponse) {
                    let response = null;

                    if (rawResponse) {
                        try {
                            response = JSON.parse(rawResponse);
                        } catch (parseError) {
                            console.error('TriPay AJAX parse error:', parseError, rawResponse);
                            VrStore_TriPay.showError('Payment processing failed. Please refresh the page and try again.');
                            $submitBtn.prop('disabled', false).text(originalText);
                            return;
                        }
                    }

                    if (response && response.success) {
                        // Redirect to payment URL
                        if (response.data.redirect_url) {
                            window.location.href = response.data.redirect_url;
                        } else {
                            VrStore_TriPay.showError('No payment URL received');
                            $submitBtn.prop('disabled', false).text(originalText);
                        }
                    } else {
                        const message = response && response.data && response.data.message
                            ? response.data.message
                            : 'Payment failed';
                        VrStore_TriPay.showError(message);
                        $submitBtn.prop('disabled', false).text(originalText);
                    }
                },
                error: function(xhr, status, error) {
                    const responseText = xhr && xhr.responseText ? xhr.responseText.trim() : '';
                    console.error('TriPay AJAX error:', error, responseText);
                    let message = 'Payment processing failed. Please try again.';

                    if (responseText) {
                        try {
                            const payload = JSON.parse(responseText);
                            if (payload && payload.data && payload.data.message) {
                                message = payload.data.message;
                            }
                        } catch (parseError) {
                            // leave default message
                        }
                    }

                    VrStore_TriPay.showError(message);
                    $submitBtn.prop('disabled', false).text(originalText);
                }
            });
        },

        /**
         * Show error message
         */
        showError: function(message) {
            // Remove existing error messages
            $('.vrstore-error-message').remove();
            
            // Create and show error message
            const errorHtml = `
                <div class="vrstore-error-message" style="background: #f8d7da; color: #721c24; padding: 12px; border-radius: 5px; margin: 15px 0; border: 1px solid #f5c6cb;">
                    ${message}
                </div>
            `;
            
            $('.vrstore-checkout-form').prepend(errorHtml);
            
            // Scroll to error message
            $('html, body').animate({
                scrollTop: $('.vrstore-error-message').offset().top - 100
            }, 500);
            
            // Auto-remove error after 5 seconds
            setTimeout(function() {
                $('.vrstore-error-message').fadeOut();
            }, 5000);
        }
    };

    // Handle TriPay method selection styling
    $(document).on('change', 'input[name="tripay_payment_method"]', function() {
        // Remove selected styling from all options
        $('.tripay-method-option').css({
            'border-color': '#e1e5e9',
            'background': 'transparent'
        });
        
        // Add selected styling to chosen option
        $(this).closest('.tripay-method-option').css({
            'border-color': '#007cba',
            'background': '#f0f6fc'
        });
    });

    // Initialize when document is ready
    $(document).ready(function() {
        // Initialize TriPay if payment method is already selected
        if ($('input[name="vrstore_payment_method"][value="tripay"]').is(':checked')) {
            VrStore_TriPay.init();
            VrStore_TriPay.showTriPayOptions();
        } else {
            VrStore_TriPay.init();
        }
        

    });

})(jQuery);
