/**
 * Pre-order Buy Button Handler
 * Handles pre-order specific functionality for buy buttons
 */

jQuery(document).ready(function($) {
    'use strict';

    // Handle pre-order button clicks
    $(document).on('click', '.vrstore-preorder-button', function(e) {
        var $button = $(this);
        var $container = $button.closest('.vrstore-buy-button-container');
        var isPreorder = $container.data('is-preorder') === '1' || $button.data('is-preorder') === '1';
        
        if (isPreorder) {
            // Add visual feedback for pre-order
            $button.addClass('vrstore-preorder-processing');
            
            // Show pre-order confirmation if needed
            var confirmMessage = vrstore_preorder_vars.confirm_preorder || 'Are you sure you want to place this pre-order?';
            
            if (!confirm(confirmMessage)) {
                e.preventDefault();
                $button.removeClass('vrstore-preorder-processing');
                return false;
            }
        }
    });

    // Enhanced loading state for pre-order buttons
    $(document).on('vrstore_cart_adding', function(e, data) {
        if (data.isPreorder) {
            var $button = $('.vrstore-preorder-button[data-product-id="' + data.productId + '"]');
            $button.html('<i class="dashicons dashicons-update" style="animation: spin 1s linear infinite;"></i> ' + 
                        (data.addingText || 'Adding Pre-order...'));
        }
    });

    // Handle successful pre-order addition
    $(document).on('vrstore_cart_added', function(e, data) {
        if (data.isPreorder) {
            var $button = $('.vrstore-preorder-button[data-product-id="' + data.productId + '"]');
            
            // Show success state
            $button.removeClass('vrstore-preorder-processing')
                   .addClass('vrstore-preorder-success')
                   .html('<i class="dashicons dashicons-yes-alt"></i> Pre-order Added!');
            
            // Show success message
            if (data.message) {
                showPreorderNotification(data.message, 'success');
            }
            
            // Reset button after delay
            setTimeout(function() {
                $button.removeClass('vrstore-preorder-success')
                       .html(data.originalText || 'Pre-order Now');
            }, 3000);
        }
    });

    // Handle pre-order errors
    $(document).on('vrstore_cart_error', function(e, data) {
        if (data.isPreorder) {
            var $button = $('.vrstore-preorder-button[data-product-id="' + data.productId + '"]');
            
            $button.removeClass('vrstore-preorder-processing')
                   .addClass('vrstore-preorder-error')
                   .html('<i class="dashicons dashicons-warning"></i> Error');
            
            // Show error message
            if (data.message) {
                showPreorderNotification(data.message, 'error');
            }
            
            // Reset button after delay
            setTimeout(function() {
                $button.removeClass('vrstore-preorder-error')
                       .html(data.originalText || 'Pre-order Now');
            }, 3000);
        }
    });

    // Pre-order notification system
    function showPreorderNotification(message, type) {
        var notificationClass = 'vrstore-preorder-notification-' + type;
        var iconClass = type === 'success' ? 'dashicons-yes-alt' : 'dashicons-warning';
        var bgColor = type === 'success' ? '#d4edda' : '#f8d7da';
        var textColor = type === 'success' ? '#155724' : '#721c24';
        var borderColor = type === 'success' ? '#c3e6cb' : '#f5c6cb';
        
        var $notification = $('<div class="vrstore-preorder-notification ' + notificationClass + '" style="' +
            'position: fixed; top: 20px; right: 20px; z-index: 999999; ' +
            'background: ' + bgColor + '; color: ' + textColor + '; ' +
            'border: 1px solid ' + borderColor + '; border-radius: 8px; ' +
            'padding: 15px 20px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); ' +
            'max-width: 350px; font-size: 14px; line-height: 1.4; ' +
            'transform: translateX(100%); transition: transform 0.3s ease;' +
            '">' +
            '<i class="dashicons ' + iconClass + '" style="margin-right: 8px; font-size: 16px; vertical-align: middle;"></i>' +
            '<span>' + message + '</span>' +
            '<button class="vrstore-notification-close" style="' +
                'background: none; border: none; color: inherit; ' +
                'float: right; font-size: 18px; cursor: pointer; ' +
                'margin-left: 10px; padding: 0; line-height: 1;' +
            '">×</button>' +
            '</div>');
        
        $('body').append($notification);
        
        // Animate in
        setTimeout(function() {
            $notification.css('transform', 'translateX(0)');
        }, 100);
        
        // Auto-hide after 5 seconds
        setTimeout(function() {
            hideNotification($notification);
        }, 5000);
        
        // Handle close button
        $notification.find('.vrstore-notification-close').on('click', function() {
            hideNotification($notification);
        });
    }
    
    function hideNotification($notification) {
        $notification.css('transform', 'translateX(100%)');
        setTimeout(function() {
            $notification.remove();
        }, 300);
    }

    // Add CSS for animations if not already present
    if (!$('#vrstore-preorder-animations').length) {
        $('head').append(`
            <style id="vrstore-preorder-animations">
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
                
                .vrstore-preorder-processing {
                    opacity: 0.8;
                    pointer-events: none;
                }
                
                .vrstore-preorder-success {
                    background: linear-gradient(135deg, #28a745 0%, #20c997 100%) !important;
                }
                
                .vrstore-preorder-error {
                    background: linear-gradient(135deg, #dc3545 0%, #e74c3c 100%) !important;
                }
                
                .vrstore-preorder-notification {
                    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
                }
            </style>
        `);
    }

    // Initialize pre-order countdown timers (if not already handled in template)
    $('.countdown-timer[data-release-date]').each(function() {
        var $timer = $(this);
        var releaseDate = $timer.data('release-date');
        
        if (releaseDate && !$timer.data('initialized')) {
            $timer.data('initialized', true);
            initializeCountdown($timer, releaseDate);
        }
    });
    
    function initializeCountdown($timer, releaseDate) {
        var targetDate = new Date(releaseDate).getTime();
        
        function updateTimer() {
            var now = new Date().getTime();
            var distance = targetDate - now;
            
            if (distance < 0) {
                $timer.html('Released!').addClass('countdown-expired');
                return;
            }
            
            var days = Math.floor(distance / (1000 * 60 * 60 * 24));
            var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            var seconds = Math.floor((distance % (1000 * 60)) / 1000);
            
            var parts = [];
            if (days > 0) parts.push(days + 'd');
            if (hours > 0 || days > 0) parts.push(hours + 'h');
            if (minutes > 0 || hours > 0 || days > 0) parts.push(minutes + 'm');
            parts.push(seconds + 's');
            
            $timer.html(parts.join(' '));
        }
        
        updateTimer();
        setInterval(updateTimer, 1000);
    }
});