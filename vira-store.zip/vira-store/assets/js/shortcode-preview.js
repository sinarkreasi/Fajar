/**
 * Shortcode Preview Handler
 * Handles preview functionality for shortcode lessons
 */

jQuery(document).ready(function($) {
    'use strict';

    // Handle shortcode preview modal
    $(document).on('click', '.lesson-preview-modal[data-lesson-type="shortcode"]', function(e) {
        e.preventDefault();
        
        var $button = $(this);
        var lessonTitle = $button.data('lesson-title');
        var shortcodeContent = $button.data('lesson-shortcode');
        
        if (!shortcodeContent) {
            alert('No shortcode content available for preview.');
            return;
        }
        
        // Create modal HTML
        var modalHtml = `
            <div id="vrstore-shortcode-preview-modal" style="
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.8);
                z-index: 999999;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 20px;
                box-sizing: border-box;
            ">
                <div style="
                    background: white;
                    border-radius: 8px;
                    max-width: 90%;
                    max-height: 90%;
                    overflow: auto;
                    position: relative;
                    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
                ">
                    <div style="
                        padding: 20px;
                        border-bottom: 1px solid #eee;
                        display: flex;
                        justify-content: space-between;
                        align-items: center;
                        background: #f8f9fa;
                        border-radius: 8px 8px 0 0;
                    ">
                        <h3 style="margin: 0; color: #333; font-size: 18px;">
                            <i class="dashicons dashicons-shortcode" style="color: #9c27b0; margin-right: 8px;"></i>
                            Preview: ${lessonTitle}
                        </h3>
                        <button id="close-shortcode-preview" style="
                            background: none;
                            border: none;
                            font-size: 24px;
                            cursor: pointer;
                            color: #666;
                            padding: 0;
                            width: 30px;
                            height: 30px;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            border-radius: 50%;
                            transition: all 0.3s ease;
                        " onmouseover="this.style.background='#f0f0f0'" onmouseout="this.style.background='none'">
                            ×
                        </button>
                    </div>
                    <div style="
                        padding: 20px;
                        min-height: 200px;
                        background: white;
                    ">
                        <div style="
                            background: #f8f9fa;
                            border: 1px solid #dee2e6;
                            border-radius: 4px;
                            padding: 15px;
                            margin-bottom: 15px;
                            font-family: 'Courier New', Courier, monospace;
                            font-size: 13px;
                            color: #495057;
                            word-break: break-all;
                        ">
                            <strong>Shortcode:</strong> ${shortcodeContent}
                        </div>
                        <div style="
                            border: 1px solid #dee2e6;
                            border-radius: 4px;
                            padding: 15px;
                            background: white;
                            min-height: 150px;
                        ">
                            <div id="shortcode-preview-content" style="text-align: center; color: #666; padding: 40px 20px;">
                                <i class="dashicons dashicons-update" style="font-size: 24px; animation: spin 1s linear infinite;"></i>
                                <p style="margin: 10px 0 0 0;">Loading preview...</p>
                            </div>
                        </div>
                        <div style="
                            margin-top: 15px;
                            padding: 10px;
                            background: #fff3cd;
                            border: 1px solid #ffeaa7;
                            border-radius: 4px;
                            font-size: 12px;
                            color: #856404;
                        ">
                            <strong>Note:</strong> This is a preview of the shortcode content. Some interactive features may not work in preview mode.
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        // Add modal to page
        $('body').append(modalHtml);
        
        // Prevent body scroll
        $('body').css('overflow', 'hidden');
        
        // Load shortcode content via AJAX
        $.ajax({
            url: vrstore_course_frontend.ajax_url,
            type: 'POST',
            data: {
                action: 'vrstore_preview_shortcode',
                nonce: vrstore_course_frontend.nonce,
                shortcode: shortcodeContent
            },
            success: function(response) {
                if (response.success) {
                    $('#shortcode-preview-content').html(response.data.content);
                } else {
                    $('#shortcode-preview-content').html(`
                        <div style="text-align: center; color: #dc3545; padding: 20px;">
                            <i class="dashicons dashicons-warning" style="font-size: 24px; margin-bottom: 10px; display: block;"></i>
                            <p style="margin: 0;">Failed to load shortcode preview.</p>
                            <small style="color: #6c757d; margin-top: 5px; display: block;">${response.data || 'Unknown error'}</small>
                        </div>
                    `);
                }
            },
            error: function() {
                $('#shortcode-preview-content').html(`
                    <div style="text-align: center; color: #dc3545; padding: 20px;">
                        <i class="dashicons dashicons-warning" style="font-size: 24px; margin-bottom: 10px; display: block;"></i>
                        <p style="margin: 0;">Error loading shortcode preview.</p>
                    </div>
                `);
            }
        });
    });
    
    // Close modal handlers
    $(document).on('click', '#close-shortcode-preview, #vrstore-shortcode-preview-modal', function(e) {
        if (e.target === this) {
            $('#vrstore-shortcode-preview-modal').remove();
            $('body').css('overflow', '');
        }
    });
    
    // Close modal on escape key
    $(document).on('keydown', function(e) {
        if (e.keyCode === 27 && $('#vrstore-shortcode-preview-modal').length) {
            $('#vrstore-shortcode-preview-modal').remove();
            $('body').css('overflow', '');
        }
    });
    
    // Add spin animation for loading
    if (!$('#vrstore-spin-animation').length) {
        $('head').append(`
            <style id="vrstore-spin-animation">
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
            </style>
        `);
    }
});