/**
 * Vira Store Admin Menu JavaScript
 *
 * @package Vira_Store
 * @since 1.0.0
 */

(function($) {
    'use strict';
    
    // Early dependency check
    $(document).ready(function() {
        if (typeof vrstore_admin === 'undefined') {
            // Create a fallback object with default values
            window.vrstore_admin = {
                ajax_url: (typeof ajaxurl !== 'undefined') ? ajaxurl : '/wp-admin/admin-ajax.php',
                nonce: '',
                error_email_required: 'Customer email is required.',
                generating_text: 'Generating...',
                license_generated: 'License generated successfully!',
                license_key_label: 'License Key:',
                error_label: 'Error:',
                error_generating: 'Error generating license. Please try again.',
                error_loading_details: 'Error loading license details.',
                loading: 'Loading...',
                confirm_delete: 'Are you sure you want to delete this license? This action cannot be undone.'
            };
        }
    });

    /**
     * License Management
     */
    const LicenseManager = {
        
        init: function() {
            this.bindEvents();
        },

        bindEvents: function() {
            // Generate license button
            $(document).on('click', '#vrstore-generate-license', this.openGenerateModal);
            
            // Generate license form submission
            $(document).on('submit', '#vrstore-generate-license-form', this.handleGenerateSubmit);
            
            // Cancel generate license
            $(document).on('click', '#vrstore-cancel-generate', this.closeGenerateModal);
            
            // View license details
            $(document).on('click', '.vrstore-view-license', this.openDetailsModal);
            
            // Delete license with confirmation
            $(document).on('click', '.delete-license', this.handleDeleteLicense);
            
            // Close modals
            $(document).on('click', '.vrstore-modal-close, .vrstore-modal', this.closeModal);
            
            // Prevent modal close when clicking inside modal content
            $(document).on('click', '.vrstore-modal-content', this.preventModalClose);
            
            // License type change handler
            $(document).on('change', '#license_type', this.handleLicenseTypeChange);
        },

        openGenerateModal: function(e) {
            e.preventDefault();
            
            // Hide any existing modals first
            $('.vrstore-modal').hide();
            
            // Show generate modal
            $('#vrstore-generate-license-modal').show();
            
            // Focus on customer email field
            setTimeout(function() {
                $('#customer_email_select').focus();
            }, 100);
        },

        closeGenerateModal: function(e) {
            e.preventDefault();
            $('#vrstore-generate-license-modal').hide();
            
            // Reset form
            const $form = $('#vrstore-generate-license-form');
            if ($form.length) {
                $form[0].reset();
            }
            $('#license-type-info').hide();
        },

        handleGenerateSubmit: function(e) {
            e.preventDefault();
            
            const $form = $(this);
            const $submitBtn = $('#vrstore-submit-generate');
            const $cancelBtn = $('#vrstore-cancel-generate');
            const originalText = $submitBtn.text();
            
            // Prevent multiple submissions
            if ($submitBtn.prop('disabled')) {
                return;
            }
            
            // Check if vrstore_admin is available
            if (typeof vrstore_admin === 'undefined') {
                alert('Error: Admin scripts not loaded properly. Please refresh the page.');
                return;
            }
            
            // Validate required fields
            const customerEmailValue = $('#customer_email_select').val();
            const customerEmail = customerEmailValue ? customerEmailValue.trim() : '';
            if (!customerEmail) {
                alert(vrstore_admin.error_email_required || 'Customer email is required.');
                $('#customer_email_select').focus();
                return;
            }
            
            // Disable buttons and show loading
            $submitBtn.prop('disabled', true).text(vrstore_admin.generating_text);
            $cancelBtn.prop('disabled', true);
            
            // Collect form data
            const formData = {
                action: 'vrstore_generate_license',
                nonce: vrstore_admin.nonce,
                customer_email: customerEmail,
                product_id: $('#product_id').val(),
                license_type: $('#license_type').val(),
                custom_activation_limit: $('#custom_activation_limit').val(),
                custom_expiry_date: $('#custom_expiry_date').val()
            };
            
            // Send AJAX request
            $.post(vrstore_admin.ajax_url, formData)
                .done(function(response) {
                    if (response.success) {
                        // Show success message - use response data with fallbacks
                        const licenseKey = response.data.license_key || '';
                        const successMessage = response.data.message || 
                                              (vrstore_admin.license_generated || 'License generated successfully!');
                        const keyLabel = vrstore_admin.license_key_label || 'License Key:';
                        const message = successMessage + '\n\n' + keyLabel + ' ' + licenseKey;
                        alert(message);
                        
                        // Close modal and refresh page
                        LicenseManager.closeGenerateModal(e);
                        location.reload();
                    } else {
                        let errorMsg = 'Unknown error occurred.';
                        
                        if (response.data) {
                            if (typeof response.data === 'string') {
                                errorMsg = response.data;
                            } else if (response.data.message) {
                                errorMsg = response.data.message;
                            } else if (typeof response.data === 'object') {
                                errorMsg = 'Server returned an error object: ' + JSON.stringify(response.data);
                            }
                        } else if (response.message) {
                            errorMsg = response.message;
                        }
                        
                        console.error('License generation error:', response);
                        alert((vrstore_admin.error_label || 'Error:') + ' ' + errorMsg);
                        
                        // Show help section if it contains database error
                        if (errorMsg.toLowerCase().includes('database') || errorMsg.toLowerCase().includes('table')) {
                            $('#vrstore-license-error-help').show();
                        }
                    }
                })
                .fail(function(xhr, status, error) {
                    console.error('AJAX request failed:', xhr, status, error);
                    let errorMsg = vrstore_admin.error_generating || 'Error generating license. Please try again.';
                    
                    if (xhr.responseText) {
                        try {
                            const response = JSON.parse(xhr.responseText);
                            if (response.data && response.data.message) {
                                errorMsg += ' Details: ' + response.data.message;
                            }
                        } catch (e) {
                            errorMsg += ' Server response: ' + xhr.responseText.substring(0, 200);
                        }
                    }
                    
                    alert(errorMsg);
                })
                .always(function() {
                    // Re-enable buttons
                    $submitBtn.prop('disabled', false).text(originalText);
                    $cancelBtn.prop('disabled', false);
                });
        },

        openDetailsModal: function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const licenseId = $(this).data('license-id');
            if (!licenseId) {
                console.error('License ID not found');
                return;
            }
            
            // Hide any existing modals first
            $('.vrstore-modal').hide().removeClass('vrstore-modal-visible');
            
            // Show details modal with loading
            const $modal = $('#vrstore-license-modal');
            $modal.show().addClass('vrstore-modal-visible');
            $('body').addClass('vrstore-modal-open');
            $('#vrstore-license-details').html('<div class="vrstore-loading"><p>' + 
                (vrstore_admin.loading || 'Loading...') + '</p></div>');
            
            // Load license details via AJAX
            $.post(vrstore_admin.ajax_url, {
                action: 'vrstore_get_license_details',
                license_id: licenseId,
                nonce: vrstore_admin.nonce
            })
            .done(function(response) {
                if (response.success) {
                    $('#vrstore-license-details').html(response.data);
                } else {
                    $('#vrstore-license-details').html('<p class="error">' + 
                        (response.data && response.data.message ? response.data.message : (response.data || vrstore_admin.error_loading_details || 'Error loading license details.')) + '</p>');
                }
            })
            .fail(function(xhr, status, error) {
                console.error('License details load failed:', xhr, status, error);
                $('#vrstore-license-details').html('<p class="error">' + 
                    (vrstore_admin.error_loading_details || 'Error loading license details. Please try again.') + '</p>');
            });
        },

        handleDeleteLicense: function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const $link = $(this);
            const action = $link.data('action');
            const confirmMessage = vrstore_admin.confirm_delete_license || 
                'Are you sure you want to delete this license? This action cannot be undone.';
            
            if (!confirm(confirmMessage)) {
                return false;
            }
            
            // Show loading state
            $link.text(vrstore_admin.loading || 'Deleting...').prop('disabled', true);
            
            // Get the delete URL
            const deleteUrl = $link.attr('href');
            if (!deleteUrl) {
                alert('Delete URL not found.');
                $link.text('Delete').prop('disabled', false);
                return false;
            }
            
            // Redirect to delete URL (nonce-protected)
            window.location.href = deleteUrl;
            
            return false;
        },

        closeModal: function(e) {
            // Handle close button click
            if ($(e.target).hasClass('vrstore-modal-close')) {
                $('.vrstore-modal').hide().removeClass('vrstore-modal-visible');
                $('body').removeClass('vrstore-modal-open');
                return;
            }
            
            // Handle backdrop click
            if (e.target === this && $(this).hasClass('vrstore-modal')) {
                $('.vrstore-modal').hide().removeClass('vrstore-modal-visible');
                $('body').removeClass('vrstore-modal-open');
                
                // Reset forms with a small delay to prevent flashing
                setTimeout(function() {
                    const $form = $('#vrstore-generate-license-form');
                    if ($form.length) {
                        $form[0].reset();
                    }
                    
                    // Clear license type config display
                    $('#license-type-info').hide();
                }, 200);
            }
        },

        preventModalClose: function(e) {
            e.stopPropagation();
        },

        handleLicenseTypeChange: function() {
            const productId = $('#product_id').val();
            const licenseType = $('#license_type').val();
            const $configDiv = $('#license-type-info');
            const $activationLimit = $('#config-activation-limit');
            const $expiryDate = $('#config-expiry-date');
            
            if (!productId || !licenseType) {
                $configDiv.hide();
                return;
            }
            
            // Show loading state
            $configDiv.show();
            $activationLimit.text('Loading...');
            $expiryDate.text('Loading...');
            
            // Fetch license type configuration
            $.post(vrstore_admin.ajax_url, {
                action: 'vrstore_get_license_type_config',
                product_id: productId,
                license_type: licenseType,
                nonce: vrstore_admin.nonce
            })
            .done(function(response) {
                if (response.success && response.data) {
                    const config = response.data;
                    
                    // Update activation limit
                    if (config.activation_limit) {
                        $activationLimit.text(config.activation_limit === -1 ? 'Unlimited' : config.activation_limit);
                    } else {
                        $activationLimit.text('Not set');
                    }
                    
                    // Update expiry date
                    if (config.expiry_date) {
                        $expiryDate.text(config.expiry_date);
                    } else if (config.expiry_days) {
                        const days = config.expiry_days;
                        if (days === -1) {
                            $expiryDate.text('Never expires');
                        } else {
                            const expiryDate = new Date();
                            expiryDate.setDate(expiryDate.getDate() + parseInt(days));
                            $expiryDate.text(expiryDate.toLocaleDateString());
                        }
                    } else {
                        $expiryDate.text('Not set');
                    }
                } else {
                    $activationLimit.text('Error loading');
                    $expiryDate.text('Error loading');
                }
            })
            .fail(function() {
                $activationLimit.text('Error loading');
                $expiryDate.text('Error loading');
            });
        }
    };

    /**
     * Plugin Versions Manager
     */
    const PluginVersionsManager = {
        
        init: function() {
            this.bindEvents();
        },

        bindEvents: function() {
            // Prevent duplicate event binding
            if (this.eventsbound) {
                return;
            }
            this.eventsbound = true;
            
            // Add Version Modal
            $(document).on('click', '.add-version-btn', this.openAddVersionModal);
            
            // Manage Versions Modal
            $(document).on('click', '.manage-versions-btn', this.openManageVersionsModal);
            
            // Close Modal
            $(document).on('click', '.vrstore-modal-close, .vrstore-modal', this.closeModal);
            
            // Prevent modal close when clicking inside modal content
            $(document).on('click', '.vrstore-modal-content', this.preventModalClose);
            
            // Form submission validation
            $(document).on('submit', '#add-version-form', this.validateVersionForm);
            
            // Version management actions
            $(document).on('click', '#save-version-btn', this.saveVersion);
            $(document).on('click', '.edit-version-btn', this.editVersion);
            $(document).on('click', '.delete-version-btn', this.deleteVersion);
        },

        openAddVersionModal: function(e) {
            e.preventDefault();
            const productId = $(this).data('product-id');
            
            if (!productId) {
                alert('Product ID not found');
                return;
            }
            
            // Clear form and set product ID
            const $form = $('#add-version-form');
            if ($form.length) {
                $form[0].reset();
            }
            const $productId = $('#add-product-id');
            if ($productId.length) {
                $productId.val(productId);
            }
            
            // Load license types for this modal
            PluginVersionsManager.loadLicenseTypes(productId);
            $('#add-version-modal').show();
        },

        openManageVersionsModal: function(e) {
            e.preventDefault();
            const productId = $(this).data('product-id');
            let productTitle = $(this).data('product-title');
            
            if (!productId) {
                alert('Product ID not found');
                return;
            }
            
            // Fallback to get title from DOM if not available in data attribute
            if (!productTitle) {
                productTitle = $(this).closest('.vrstore-product-card').find('h3').text();
            }
            
            $('#manage-product-title').text(productTitle);
            PluginVersionsManager.loadVersionsList(productId);
            $('#manage-versions-modal').show();
        },

        closeModal: function(e) {
            if (e.target === this || $(e.target).hasClass('vrstore-modal-close')) {
                $('.vrstore-modal').hide();
                PluginVersionsManager.resetForms();
            }
        },

        preventModalClose: function(e) {
            e.stopPropagation();
        },

        validateVersionForm: function(e) {
            e.preventDefault();
            
            const versionValue = $('#version-number').val();
            const downloadUrlValue = $('#download-url').val();
            const version = versionValue ? versionValue.trim() : '';
            const downloadUrl = downloadUrlValue ? downloadUrlValue.trim() : '';
            
            if (!version.match(/^[0-9]+\.[0-9]+\.[0-9]+$/)) {
                alert(vrstore_admin.version_validation_error || 'Please enter a valid version number (e.g., 1.0.0)');
                return false;
            }
        },

        resetForms: function() {
            $('#add-version-form')[0].reset();
            $('#manage-versions-form')[0].reset();
        },

        loadVersionsList: function(productId) {
            const $versionsList = $('#versions-list');
            $versionsList.html('<div class="loading">Loading versions...</div>');
            $('#manage-versions-modal').data('product-id', productId);
            $('#versions-list-container').html('<div class="loading">' + (vrstore_admin.loading || 'Loading versions...') + '</div>');
            
            $.ajax({
                url: vrstore_admin.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrstore_load_plugin_versions',
                    product_id: productId,
                    nonce: vrstore_admin.nonce
                },
                success: function(response) {
                    if (response.success) {
                        PluginVersionsManager.renderVersionsList(response.data.versions);
                        // Store license types for later use
                        $('#manage-versions-modal').data('license-types', response.data.license_types);
                        // Load license types for the add version form within this modal
                        PluginVersionsManager.loadLicenseTypes(productId);
                    } else {
                        $('#versions-list-container').html('<div class="error">Error loading versions: ' + (response.data || 'Unknown error') + '</div>');
                    }
                },
                error: function() {
                    $('#versions-list-container').html('<div class="error">Failed to load versions</div>');
                }
            });
        },

        loadLicenseTypes: function(productId) {
            // For Add Version modal, get license types via AJAX
            // For Manage Versions modal, use stored data
            const isManageModal = $('#manage-versions-modal').is(':visible');
            
            if (isManageModal) {
                const licenseTypes = $('#manage-versions-modal').data('license-types');
                const licenseContainer = $('#license-tiers-container');
                
                if (licenseTypes && licenseTypes.length > 0) {
                    let html = '';
                    licenseTypes.forEach(function(type) {
                        html += '<label><input type="checkbox" name="license_tiers[]" value="' + 
                                type.slug + '"> ' + type.label + '</label><br>';
                    });
                    licenseContainer.html(html);
                } else {
                    licenseContainer.html('<p>No license types configured. Please configure license types in Settings.</p>');
                }
            } else {
                // For Add Version modal, load license types via AJAX
                $.ajax({
                    url: vrstore_admin.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'vrstore_load_plugin_versions',
                        product_id: productId,
                        nonce: vrstore_admin.nonce
                    },
                    success: function(response) {
                        if (response.success && response.data.license_types) {
                            const licenseContainer = $('.license-tiers-checkboxes');
                            let html = '';
                            
                            response.data.license_types.forEach(function(type) {
                                html += '<label class="checkbox-label">';
                                html += '<input type="checkbox" name="license_tiers[]" value="' + type.slug + '">';
                                html += type.label;
                                html += '</label>';
                            });
                            
                            licenseContainer.html(html);
                        }
                    }
                });
            }
        },

        renderVersionsList: function(versions) {
            let html = '';
            
            if (!versions || versions.length === 0) {
                html = '<div class="no-versions"><span class="dashicons dashicons-info"></span>No versions found</div>';
            } else {
                html = '<div class="versions-table-wrapper">';
                html += '<table class="versions-table wp-list-table widefat fixed striped">';
                html += '<thead><tr>';
                html += '<th class="manage-column column-version">Version</th>';
                html += '<th class="manage-column column-license">License Tiers</th>';
                html += '<th class="manage-column column-date">Date Added</th>';
                html += '<th class="manage-column column-actions">Actions</th>';
                html += '</tr></thead><tbody>';
                
                versions.forEach(function(version) {
                    const licenseDisplay = version.license_tiers && version.license_tiers.length > 0 
                        ? version.license_tiers.join(', ') 
                        : '<span class="all-tiers">All tiers</span>';
                    
                    // Format the date properly
                    let formattedDate = 'Unknown';
                    const dateValue = version.release_date || version.created_at;
                    if (dateValue) {
                        try {
                            const date = new Date(dateValue);
                            if (!isNaN(date.getTime())) {
                                formattedDate = date.toLocaleDateString('en-US', {
                                    year: 'numeric',
                                    month: 'short',
                                    day: 'numeric'
                                });
                            }
                        } catch (e) {
                            formattedDate = dateValue;
                        }
                    }
                    
                    html += '<tr>';
                    html += '<td class="column-version"><strong>' + version.version + '</strong></td>';
                    html += '<td class="column-license">' + licenseDisplay + '</td>';
                    html += '<td class="column-date">' + formattedDate + '</td>';
                    html += '<td class="column-actions">';
                    html += '<button class="button button-small delete-version-btn" data-version-key="' + version.id + '"><span class="dashicons dashicons-trash"></span> Delete</button>';
                    html += '</td>';
                    html += '</tr>';
                });
                
                html += '</tbody></table></div>';
            }
            
            $('#versions-list-container').html(html);
        },

        saveVersion: function(e) {
            e.preventDefault();
            
            const productId = $('#manage-versions-modal').data('product-id');
            const formData = new FormData($('#version-form')[0]);
            formData.append('action', 'vrstore_update_plugin_version');
            formData.append('product_id', productId);
            formData.append('nonce', vrstore_admin.nonce);

            // Get selected license tiers
            const licenseTiers = [];
            $('input[name="license_tiers[]"]:checked').each(function() {
                licenseTiers.push($(this).val());
            });
            
            // Remove existing license_tiers entries and add new ones
            formData.delete('license_tiers[]');
            licenseTiers.forEach(function(tier) {
                formData.append('license_tiers[]', tier);
            });

            $.ajax({
                url: vrstore_admin.ajax_url,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        alert('Version saved successfully');
                        $('#add-version-modal').hide();
                        PluginVersionsManager.loadVersionsList(productId);
                    } else {
                        alert('Error saving version: ' + (response.data || 'Unknown error'));
                    }
                },
                error: function() {
                    alert('Failed to save version');
                }
            });
        },

        editVersion: function(e) {
            e.preventDefault();
            const versionKey = $(this).data('version-key');
            const productId = $('#manage-versions-modal').data('product-id');
            
            // This would need to be implemented to populate the form with existing version data
            alert('Edit functionality to be implemented');
        },

        deleteVersion: function(e) {
            e.preventDefault();
            const versionKey = $(this).data('version-key');
            const productId = $('#manage-versions-modal').data('product-id');
            
            if (!confirm('Are you sure you want to delete this version?')) {
                return;
            }

            $.ajax({
                url: vrstore_admin.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrstore_delete_plugin_version',
                    product_id: productId,
                    version_key: versionKey,
                    nonce: vrstore_admin.nonce
                },
                success: function(response) {
                    if (response.success) {
                        alert('Version deleted successfully');
                        PluginVersionsManager.loadVersionsList(productId);
                    } else {
                        alert('Error deleting version: ' + (response.data || 'Unknown error'));
                    }
                },
                error: function() {
                    alert('Failed to delete version');
                }
            });
        }
    };

    /**
     * Initialize when document is ready
     */
    $(document).ready(function() {
        // Check for Vira Store admin pages by multiple methods
        const isVRStorePageByPagenow = window.pagenow && (window.pagenow.indexOf('vrstore') !== -1 || window.pagenow.indexOf('vira-store') !== -1);
        const isVRStorePageByURL = window.location.href.indexOf('page=vrstore-') !== -1;
        const hasVRStoreElements = $('#vrstore-generate-license, [class*="vrstore-view-license"], .delete-license, .vrstore-stat-card, .view-order, .change-order-status').length > 0;
        
        // Initialize on Vira Store admin pages
        if (isVRStorePageByPagenow || isVRStorePageByURL || hasVRStoreElements) {
            LicenseManager.init();
            PluginVersionsManager.init();
        }
    });

})(jQuery);

/**
 * Vira Store Admin Menu JavaScript
 *
 * @package Vira_Store
 * @since 1.0.0
 */

(function($) {
    'use strict';
    
    // Early dependency check
    $(document).ready(function() {
        if (typeof vrstore_admin === 'undefined') {
            // Create a fallback object with default values
            window.vrstore_admin = {
                ajax_url: (typeof ajaxurl !== 'undefined') ? ajaxurl : '/wp-admin/admin-ajax.php',
                nonce: '',
                error_email_required: 'Customer email is required.',
                generating_text: 'Generating...',
                license_generated: 'License generated successfully!',
                license_key_label: 'License Key:',
                error_label: 'Error:',
                error_generating: 'Error generating license. Please try again.',
                error_loading_details: 'Error loading license details.',
                loading: 'Loading...',
                confirm_delete: 'Are you sure you want to delete this license? This action cannot be undone.'
            };
        }
    });



    /**
     * General Admin Enhancements
     */
    const AdminEnhancements = {
        
        init: function() {
            this.enhanceCards();
            this.enhanceButtons();
            this.handleTooltips();
        },

        enhanceCards: function() {
            // Add hover animations to cards
            $('.vrstore-stat-card, .vrstore-dashboard-card, .license-stat-card, .vrstore-service-card')
                .hover(
                    function() {
                        $(this).addClass('vrstore-card-hover');
                    },
                    function() {
                        $(this).removeClass('vrstore-card-hover');
                    }
                );
        },

        enhanceButtons: function() {
            // Add loading state to buttons with data-loading attribute
            $(document).on('click', '[data-loading]', function() {
                const $btn = $(this);
                const loadingText = $btn.data('loading') || 'Loading...';
                const originalText = $btn.html();
                
                $btn.prop('disabled', true)
                    .data('original-text', originalText)
                    .html('<span class="vrstore-spinner"></span> ' + loadingText);
                
                // Auto-restore after 5 seconds if no other action
                setTimeout(function() {
                    if ($btn.prop('disabled')) {
                        $btn.prop('disabled', false).html(originalText);
                    }
                }, 5000);
            });
        },

        handleTooltips: function() {
            // Add simple tooltips to elements with title attributes
            // Exclude course-related elements that have their own CSS tooltips
            $('[title]:not(.course-free-with-product):not(.course-free):not(.course-level)').hover(
                function() {
                    const title = $(this).attr('title');
                    if (title) {
                        $(this).data('original-title', title).removeAttr('title');
                        
                        const tooltip = $('<div class="vrstore-tooltip">' + title + '</div>')
                            .appendTo('body')
                            .fadeIn(200);
                        
                        const updatePosition = () => {
                            const offset = $(this).offset();
                            const height = $(this).outerHeight();
                            
                            tooltip.css({
                                top: offset.top + height + 10,
                                left: offset.left + ($(this).outerWidth() / 2) - (tooltip.outerWidth() / 2)
                            });
                        };
                        
                        updatePosition();
                        $(this).data('tooltip', tooltip);
                    }
                },
                function() {
                    const tooltip = $(this).data('tooltip');
                    const originalTitle = $(this).data('original-title');
                    
                    if (tooltip) {
                        tooltip.fadeOut(100, function() {
                            tooltip.remove();
                        });
                    }
                    
                    if (originalTitle) {
                        $(this).attr('title', originalTitle);
                    }
                }
            );
        }
    };

    /**
     * Order Management
     */
    const OrderManager = {
        
        modalOpening: false, // Flag to prevent multiple rapid modal opens
        
        init: function() {
            this.bindEvents();
            this.checkUrlParams();
        },

        bindEvents: function() {
            // Prevent duplicate event binding
            if (this.eventsbound) {
                return;
            }
            this.eventsbound = true;
            
            // View order details
            $(document).on('click', '.view-order', this.openOrderModal);
            
            // Change order status
            $(document).on('click', '.change-order-status', this.openStatusModal);
            
            // Update order status form submission
            $(document).on('submit', '#vrstore-update-status-form', this.handleStatusUpdate);
            
            // Cancel status update
            $(document).on('click', '#vrstore-cancel-status', this.closeStatusModal);
        },

        openOrderModal: function(e) {
            e.preventDefault();
            e.stopImmediatePropagation(); // Prevent other handlers
            
            const orderId = $(this).data('order-id');
            if (!orderId) {
                return;
            }
            
            // Hide any existing modals first
            $('.vrstore-modal').hide().removeClass('vrstore-modal-visible');
            
            // Create modal if it doesn't exist
            if (!$('#vrstore-order-modal').length) {
                OrderManager.createOrderModal();
            }
            
            // Show modal with unified system
            const $modal = $('#vrstore-order-modal');
            $modal.show().addClass('vrstore-modal-visible');
            $('body').addClass('vrstore-modal-open');
            
            // Load order details via AJAX
            $('#vrstore-order-details').html('<div class="vrstore-loading"><p>' + 
                (vrstore_admin.loading || 'Loading...') + '</p></div>');
            
            $.post(vrstore_admin.ajax_url, {
                action: 'vrstore_get_order_details',
                order_id: orderId,
                nonce: vrstore_admin.nonce
            })
            .done(function(response) {
                if (response.success) {
                    $('#vrstore-order-details').html(response.data);
                } else {
                    $('#vrstore-order-details').html('<p class="error">Error loading order details.</p>');
                }
            })
            .fail(function() {
                $('#vrstore-order-details').html('<p class="error">Error loading order details.</p>');
            });
        },

        openStatusModal: function(e) {
            e.preventDefault();
            e.stopImmediatePropagation(); // Prevent other handlers
            
            // Prevent multiple rapid modal opens
            if (OrderManager.modalOpening) {
                return;
            }
            
            // Check if modal is already visible
            const $existingModal = $('#vrstore-status-modal');
            if ($existingModal.length && $existingModal.hasClass('vrstore-modal-visible')) {
                return;
            }
            
            const orderId = $(this).data('order-id');
            const currentStatus = $(this).data('current-status');
            const paymentStatus = $(this).data('payment-status');
            
            if (!orderId) {
                return;
            }
            
            // Set flag to prevent multiple opens
            OrderManager.modalOpening = true;
            
            // Hide any existing modals first
            $('.vrstore-modal').hide().removeClass('vrstore-modal-visible');
            
            // Create modal if it doesn't exist
            if (!$('#vrstore-status-modal').length) {
                OrderManager.createStatusModal();
            }
            
            // Set form values
            $('#status-order-id').val(orderId);
            $('#order-status-select').val(currentStatus);
            $('#payment-status-select').val(paymentStatus);
            $('#order-notes').val('');
            
            // Show modal with unified system
            const $modal = $('#vrstore-status-modal');
            $modal.show().addClass('vrstore-modal-visible');
            $('body').addClass('vrstore-modal-open');
            
            // Reset the modal opening flag after a short delay
            setTimeout(function() {
                OrderManager.modalOpening = false;
            }, 500);
        },

        handleStatusUpdate: function(e) {
            e.preventDefault();
            
            const $form = $(this);
            const $submitBtn = $('#vrstore-submit-status');
            const originalText = $submitBtn.text();
            
            // Disable submit button and show loading
            $submitBtn.prop('disabled', true).text('Updating...');
            
            // Collect form data
            const formData = {
                action: 'vrstore_update_order_status',
                nonce: vrstore_admin.nonce,
                order_id: $('#status-order-id').val(),
                order_status: $('#order-status-select').val(),
                payment_status: $('#payment-status-select').val(),
                order_notes: $('#order-notes').val()
            };
            
            // Send AJAX request
            $.post(vrstore_admin.ajax_url, formData)
                .done(function(response) {
                    if (response.success) {
                        alert('Order status updated successfully!');
                        
                        // Close modal and reload page
                        OrderManager.closeStatusModal();
                        window.location.reload();
                    } else {
                        const errorMsg = response.data && response.data.message ? 
                                        response.data.message : 
                                        'Error updating order status.';
                        alert('Error: ' + errorMsg);
                    }
                })
                .fail(function() {
                    alert('Error updating order status. Please try again.');
                })
                .always(function() {
                    // Re-enable submit button
                    $submitBtn.prop('disabled', false).text(originalText);
                });
        },

        closeStatusModal: function() {
            const $form = $('#vrstore-update-status-form');
            if ($form.length) {
                $form[0].reset();
            }
            const $modal = $('#vrstore-status-modal');
            $modal.removeClass('vrstore-modal-visible');
            $('body').removeClass('vrstore-modal-open');
            
            // Reset the modal opening flag
            OrderManager.modalOpening = false;
            
            setTimeout(function() {
                $modal.hide();
            }, 200);
        },

        createOrderModal: function() {
            const modalHtml = `
                <div id="vrstore-order-modal" class="vrstore-modal" style="display: none;">
                    <div class="vrstore-modal-content">
                        <div class="vrstore-modal-header">
                            <h2>Order Details</h2>
                            <span class="vrstore-modal-close">&times;</span>
                        </div>
                        <div class="vrstore-modal-body">
                            <div id="vrstore-order-details"></div>
                        </div>
                    </div>
                </div>
            `;
            $('body').append(modalHtml);
        },

        createStatusModal: function() {
            const modalHtml = `
                <div id="vrstore-status-modal" class="vrstore-modal" style="display: none;">
                    <div class="vrstore-modal-content">
                        <div class="vrstore-modal-header">
                            <h2>Change Order Status</h2>
                            <span class="vrstore-modal-close">&times;</span>
                        </div>
                        <div class="vrstore-modal-body">
                            <form id="vrstore-update-status-form">
                                <input type="hidden" id="status-order-id" name="order_id">
                                
                                <div class="vrstore-form-row">
                                    <label for="order-status-select">Order Status:</label>
                                    <select id="order-status-select" name="order_status" required>
                                        <option value="pending">Pending</option>
                                        <option value="processing">Processing</option>
                                        <option value="completed">Completed</option>
                                        <option value="failed">Failed</option>
                                        <option value="cancelled">Cancelled</option>
                                    </select>
                                </div>
                                
                                <div class="vrstore-form-row">
                                    <label for="payment-status-select">Payment Status:</label>
                                    <select id="payment-status-select" name="payment_status" required>
                                        <option value="pending">Pending</option>
                                        <option value="completed">Completed</option>
                                        <option value="failed">Failed</option>
                                        <option value="refunded">Refunded</option>
                                    </select>
                                </div>
                                
                                <div class="vrstore-form-row">
                                    <label for="order-notes">Add Note:</label>
                                    <textarea id="order-notes" name="order_notes" rows="3" placeholder="Optional note about this status change..."></textarea>
                                </div>
                                
                                <div class="vrstore-modal-actions">
                                    <button type="submit" id="vrstore-submit-status" class="button button-primary">Update Status</button>
                                    <button type="button" id="vrstore-cancel-status" class="button">Cancel</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            `;
            $('body').append(modalHtml);
        },

        checkUrlParams: function() {
            // Check for URL parameters that should trigger modals
            const urlParams = new URLSearchParams(window.location.search);
            
            // Auto-open view modal if view_order parameter is present
            const viewOrderId = urlParams.get('view_order');
            if (viewOrderId) {
                // Wait a moment for DOM to be ready
                setTimeout(function() {
                    // Create a fake click event with the order ID
                    const fakeElement = { data: function() { return viewOrderId; } };
                    OrderManager.openOrderModal.call(fakeElement, { preventDefault: function() {} });
                    
                    // Clean up URL by removing the parameter
                    const newUrl = new URL(window.location);
                    newUrl.searchParams.delete('view_order');
                    window.history.replaceState({}, '', newUrl);
                }, 100);
            }
            
            // Auto-open status modal if change_status parameter is present
            const changeStatusId = urlParams.get('change_status');
            if (changeStatusId) {
                // We need to find the current status from the table row
                setTimeout(function() {
                    // Check if modal is already visible to prevent double opening
                    const $existingModal = $('#vrstore-status-modal');
                    if ($existingModal.length && $existingModal.hasClass('vrstore-modal-visible')) {
                        return;
                    }
                    
                    const $orderRow = $('a.change-order-status[data-order-id="' + changeStatusId + '"]');
                    if ($orderRow.length) {
                        $orderRow.trigger('click');
                    } else {
                        // Fallback: create a fake element with minimal data only if no existing element found
                        const fakeElement = { 
                            data: function(key) { 
                                if (key === 'order-id') return changeStatusId;
                                if (key === 'current-status') return 'pending';
                                if (key === 'payment-status') return 'pending';
                                return '';
                            } 
                        };
                        OrderManager.openStatusModal.call(fakeElement, { 
                            preventDefault: function() {}, 
                            stopImmediatePropagation: function() {} 
                        });
                    }
                    
                    // Clean up URL by removing the parameter
                    const newUrl = new URL(window.location);
                    newUrl.searchParams.delete('change_status');
                    window.history.replaceState({}, '', newUrl);
                }, 100);
            }
        }
    };

    /**
     * Initialize when document is ready
     */
    $(document).ready(function() {
        // Check for Vira Store admin pages by multiple methods
        const isVRStorePageByPagenow = window.pagenow && (window.pagenow.indexOf('vrstore') !== -1 || window.pagenow.indexOf('vira-store') !== -1);
        const isVRStorePageByURL = window.location.href.indexOf('page=vrstore-') !== -1;
        const hasVRStoreElements = $('#vrstore-generate-license, [class*="vrstore-view-license"], .delete-license, .vrstore-stat-card, .view-order, .change-order-status').length > 0;
        
        // Initialize on Vira Store admin pages
        if (isVRStorePageByPagenow || isVRStorePageByURL || hasVRStoreElements) {
            OrderManager.init();
            AdminEnhancements.init();
        }
    });

})(jQuery);
