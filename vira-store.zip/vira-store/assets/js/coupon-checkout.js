/**
 * Coupon functionality for checkout page
 * 
 * @package Vira_Store
 * @since 1.0.0
 */

(function($) {
    'use strict';

    // Wait for document ready
    $(document).ready(function() {
        initCouponFunctionality();
    });

    /**
     * Initialize coupon functionality
     */
    function initCouponFunctionality() {
        // Bind coupon apply event
        $(document).on('click', '#vrstore-apply-coupon', handleApplyCoupon);
        
        // Bind coupon remove event  
        $(document).on('click', '#vrstore-remove-coupon', handleRemoveCoupon);
        
        // Bind enter key in coupon input
        $(document).on('keypress', '#vrstore-coupon-code', function(e) {
            if (e.which === 13) { // Enter key
                e.preventDefault();
                handleApplyCoupon();
            }
        });

        // Auto-hide messages after 5 seconds
        setTimeout(function() {
            $('.vrstore-coupon-message').fadeOut();
        }, 5000);
    }

    /**
     * Handle coupon application
     */
    function handleApplyCoupon() {
        const couponInput = $('#vrstore-coupon-code');
        const applyButton = $('#vrstore-apply-coupon');
        const messageContainer = $('#vrstore-coupon-message');
        const couponCode = couponInput.val().trim();

        // Validate coupon code input
        if (!couponCode) {
            showMessage(vrstore_frontend.required_field || 'Please enter a coupon code.', 'error');
            couponInput.focus();
            return;
        }

        // Set loading state
        setLoadingState(applyButton, true);
        couponInput.prop('disabled', true);

        // Get cart data for validation
        const cartData = getCartData();

        // Make AJAX request to apply coupon
        $.ajax({
            url: vrstore_frontend.ajax_url,
            type: 'POST',
            data: {
                action: 'vrstore_apply_coupon',
                nonce: vrstore_frontend.nonce,
                coupon_code: couponCode,
                subtotal: cartData.subtotal,
                product_ids: cartData.product_ids
            },
            success: function(response) {
                if (response.success) {
                    // Show success message
                    showMessage(response.data.message || 'Coupon applied successfully!', 'success');
                    
                    // Update checkout page with new totals
                    updateCheckoutTotals(response.data.cart_data);
                    
                    // Switch to applied coupon view
                    switchToAppliedView(response.data.cart_data.coupon);
                    
                } else {
                    // Show error message
                    showMessage(response.data.message || 'Failed to apply coupon.', 'error');
                    couponInput.focus().select();
                }
            },
            error: function() {
                showMessage(vrstore_frontend.ajax_error || 'Network error. Please try again.', 'error');
                couponInput.focus();
            },
            complete: function() {
                // Reset loading state
                setLoadingState(applyButton, false);
                couponInput.prop('disabled', false);
            }
        });
    }

    /**
     * Handle coupon removal
     */
    function handleRemoveCoupon() {
        const removeButton = $('#vrstore-remove-coupon');
        const messageContainer = $('#vrstore-coupon-message');

        // Set loading state
        setLoadingState(removeButton, true);

        // Make AJAX request to remove coupon
        $.ajax({
            url: vrstore_frontend.ajax_url,
            type: 'POST',
            data: {
                action: 'vrstore_remove_coupon',
                nonce: vrstore_frontend.nonce
            },
            success: function(response) {
                if (response.success) {
                    // Show success message
                    showMessage(response.data.message || 'Coupon removed successfully!', 'info');
                    
                    // Update checkout page with new totals
                    updateCheckoutTotals(response.data.cart_data);
                    
                    // Switch to input view
                    switchToInputView();
                    
                } else {
                    // Show error message
                    showMessage(response.data.message || 'Failed to remove coupon.', 'error');
                }
            },
            error: function() {
                showMessage(vrstore_frontend.ajax_error || 'Network error. Please try again.', 'error');
            },
            complete: function() {
                // Reset loading state
                setLoadingState(removeButton, false);
            }
        });
    }

    /**
     * Get cart data for coupon validation
     */
    function getCartData() {
        // Try to get subtotal from the order summary
        const subtotalText = $('#vrstore-subtotal-value').text() || '';
        let subtotal = 0;

        // Extract numeric value from formatted price
        if (subtotalText) {
            const numericValue = subtotalText.replace(/[^\d.,]/g, '').replace(',', '.');
            subtotal = parseFloat(numericValue) || 0;
        }

        // Get product IDs from hidden inputs or data attributes if available
        const productIds = [];
        $('.vrstore-order-item').each(function() {
            const productId = $(this).data('product-id');
            if (productId) {
                // Handle both numeric product IDs and Extended Support string IDs
                if (typeof productId === 'string' && productId.indexOf('extended_support') === 0) {
                    productIds.push(productId); // Keep Extended Support IDs as strings
                } else if (!isNaN(parseInt(productId))) {
                    productIds.push(parseInt(productId));
                }
            }
        });

        return {
            subtotal: subtotal,
            product_ids: productIds
        };
    }

    /**
     * Update checkout totals after coupon operation
     */
    function updateCheckoutTotals(cartData) {
        if (!cartData) return;

        // Update subtotal
        if (cartData.subtotal && $('#vrstore-subtotal-value').length) {
            $('#vrstore-subtotal-value').text(cartData.subtotal);
        }

        // Update discount section
        const discountSection = $('#vrstore-discount-section');
        const discountValue = $('#vrstore-discount-value');
        const discountCode = $('#vrstore-discount-code');

        if (cartData.discount && parseFloat(cartData.raw_discount) > 0) {
            // Show discount section
            discountSection.show();
            discountValue.text('-' + cartData.discount);
            
            if (cartData.coupon && cartData.coupon.code) {
                discountCode.text('(' + cartData.coupon.code + ')');
            }
        } else {
            // Hide discount section
            discountSection.hide();
            discountValue.text('');
            discountCode.text('');
        }

        // Update total
        if (cartData.total && $('#vrstore-total-value').length) {
            $('#vrstore-total-value').html('<strong>' + cartData.total + '</strong>');
        }

        // Animate the changes
        animateValueChange($('#vrstore-subtotal-value'));
        animateValueChange($('#vrstore-discount-value'));
        animateValueChange($('#vrstore-total-value'));
    }

    /**
     * Switch to applied coupon view
     */
    function switchToAppliedView(coupon) {
        const couponSection = $('.vrstore-coupon-section');
        const inputSection = $('.vrstore-coupon-input-section');
        const appliedSection = $('.vrstore-coupon-applied-section');

        if (inputSection.length && appliedSection.length && coupon) {
            // Hide input section
            inputSection.slideUp(300, function() {
                // Update applied section content
                $('.vrstore-coupon-code').text(coupon.code);
                
                // Update coupon description
                let description = '';
                if (coupon.discount_type === 'percentage') {
                    description = coupon.discount_value + '% off';
                } else {
                    // For fixed discount, we'll show the formatted amount if available
                    description = (vrstore_frontend.currency_symbol || '$') + coupon.discount_value + ' off';
                }
                $('.vrstore-coupon-description').text(description);
                
                // Show applied section
                appliedSection.slideDown(300);
            });
        }
    }

    /**
     * Switch to coupon input view
     */
    function switchToInputView() {
        const inputSection = $('.vrstore-coupon-input-section');
        const appliedSection = $('.vrstore-coupon-applied-section');

        if (inputSection.length && appliedSection.length) {
            // Hide applied section
            appliedSection.slideUp(300, function() {
                // Clear and show input section
                $('#vrstore-coupon-code').val('');
                inputSection.slideDown(300);
            });
        }
    }

    /**
     * Show message to user
     */
    function showMessage(message, type) {
        const messageContainer = $('#vrstore-coupon-message');
        
        if (messageContainer.length) {
            messageContainer
                .removeClass('success error info')
                .addClass(type)
                .html(message)
                .slideDown(200);

            // Auto-hide after 5 seconds
            setTimeout(function() {
                messageContainer.slideUp(200);
            }, 5000);
        }
    }

    /**
     * Set loading state for buttons
     */
    function setLoadingState(button, isLoading) {
        if (isLoading) {
            button
                .addClass('loading')
                .prop('disabled', true)
                .find('.vrstore-remove-icon').hide();
        } else {
            button
                .removeClass('loading')
                .prop('disabled', false)
                .find('.vrstore-remove-icon').show();
        }
    }

    /**
     * Animate value changes
     */
    function animateValueChange(element) {
        if (element.length) {
            element
                .css('opacity', 0.5)
                .animate({ opacity: 1 }, 300);
        }
    }

    /**
     * Helper function to convert amount if needed (USD to IDR)
     * @param {number} amount - The amount to convert
     * @returns {number} Converted amount
     */
    function convertAmountIfNeeded(amount) {
        if (typeof vrstore_frontend === 'undefined') {
            return amount;
        }
        
        // Check if currency conversion is enabled
        if (vrstore_frontend.enable_currency_conversion !== 'yes') {
            return amount; // Return original amount if conversion is disabled
        }
        
        const baseCurrency = vrstore_frontend.currency || 'USD';
        const currentCurrency = vrstore_frontend.current_currency || baseCurrency;
        const autoDetection = vrstore_frontend.auto_currency_detection || '';
        const usdToIdrRate = parseFloat(vrstore_frontend.usd_to_idr_rate) || 16000;
        
        // Convert USD to IDR if needed
        if (baseCurrency === 'USD' && currentCurrency === 'IDR' && autoDetection === 'on') {
            return amount * usdToIdrRate;
        }
        
        return amount;
    }

    /**
     * Format price with currency symbol
     * @param {number} amount - The price amount
     * @returns {string} Formatted price string
     */
    function formatPrice(amount) {
        // Convert amount if needed
        const convertedAmount = convertAmountIfNeeded(amount);
        
        if (typeof vrstore_frontend !== 'undefined' && vrstore_frontend.currency_symbol) {
            const baseCurrency = vrstore_frontend.currency || 'USD';
            const currentCurrency = vrstore_frontend.current_currency || baseCurrency;
            const symbol = vrstore_frontend.current_currency_symbol || vrstore_frontend.currency_symbol;
            const position = vrstore_frontend.currency_position || 'left';
            const decimals = parseInt(vrstore_frontend.decimal_number) || 2;
            const decimalSep = vrstore_frontend.decimal_separator || '.';
            const thousandSep = vrstore_frontend.thousand_separator || ',';

            // Format the number
            const formattedAmount = parseFloat(convertedAmount)
                .toFixed(decimals)
                .replace('.', decimalSep)
                .replace(/\B(?=(\d{3})+(?!\d))/g, thousandSep);

            // Return with currency symbol
            return position === 'left' ? symbol + formattedAmount : formattedAmount + symbol;
        }

        // Fallback formatting
        return '$' + parseFloat(convertedAmount).toFixed(2);
    }

})(jQuery);
