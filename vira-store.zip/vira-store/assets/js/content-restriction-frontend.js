/**
 * Content Restriction Frontend JavaScript
 *
 * Handles the overlay functionality for restricted content
 * and copy functionality for unlocked content on the frontend.
 *
 * @package Vira_Store
 * @since   1.0.0
 */

(function($) {
    'use strict';

    /**
     * Content Restriction Frontend functionality
     */
    var ContentRestrictionFrontend = {
        
        /**
         * Initialize the functionality
         */
        init: function() {
            this.bindEvents();
            this.initOverlays();
            this.initCopyFunctionality();
        },

        /**
         * Bind event handlers
         */
        bindEvents: function() {
            // Handle purchase button clicks
            $(document).on('click', '.vrstore-purchase-btn', this.handlePurchaseClick);
            
            // Handle overlay close (if needed)
            $(document).on('click', '.vrstore-overlay-close', this.closeOverlay);
            
            // Handle copy button clicks
            $(document).on('click', '.vrstore-copy-button', this.handleCopyClick);
        },

        /**
         * Initialize copy functionality
         */
        initCopyFunctionality: function() {
            // Add accessibility attributes to copy buttons
            $('.vrstore-copy-button').each(function() {
                $(this).attr({
                    'role': 'button',
                    'tabindex': '0',
                    'aria-label': 'Copy content to clipboard'
                });
            });

            // Add keyboard support for copy buttons
            $(document).on('keydown', '.vrstore-copy-button', function(e) {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    $(this).trigger('click');
                }
            });
        },

        /**
         * Handle copy button clicks
         */
        handleCopyClick: function(e) {
            e.preventDefault();
            
            var $button = $(this);
            var $contentContainer = $button.closest('.vrstore-restricted-content');
            
            if (!$contentContainer.length) {
                console.error('Content container not found');
                return;
            }

            var $contentBody = $contentContainer.find('.vrstore-restricted-content-body');
            if (!$contentBody.length) {
                console.error('Content body not found');
                return;
            }

            // Get the text content
            var textContent = $contentBody.text().trim();
            
            if (!textContent) {
                ContentRestrictionFrontend.showNotification('No content to copy', 'error');
                return;
            }

            // Try to copy to clipboard
            if (navigator.clipboard && window.isSecureContext) {
                // Modern clipboard API
                navigator.clipboard.writeText(textContent).then(function() {
                    ContentRestrictionFrontend.handleCopySuccess($button);
                }).catch(function(err) {
                    console.error('Failed to copy text: ', err);
                    ContentRestrictionFrontend.fallbackCopyTextToClipboard(textContent, $button);
                });
            } else {
                // Fallback for older browsers
                ContentRestrictionFrontend.fallbackCopyTextToClipboard(textContent, $button);
            }
        },

        /**
         * Fallback copy method for older browsers
         */
        fallbackCopyTextToClipboard: function(text, $button) {
            var $textArea = $('<textarea>')
                .val(text)
                .css({
                    'position': 'fixed',
                    'top': '0',
                    'left': '0',
                    'opacity': '0'
                })
                .appendTo('body');
            
            $textArea[0].focus();
            $textArea[0].select();
            
            try {
                var successful = document.execCommand('copy');
                if (successful) {
                    this.handleCopySuccess($button);
                } else {
                    this.showNotification('Failed to copy content', 'error');
                }
            } catch (err) {
                console.error('Fallback: Oops, unable to copy', err);
                this.showNotification('Failed to copy content', 'error');
            }
            
            $textArea.remove();
        },

        /**
         * Handle successful copy operation
         */
        handleCopySuccess: function($button) {
            var originalText = $button.text();
            var copiedText = 'Copied!';
            
            $button.text(copiedText).addClass('copied');
            
            // Show success notification
            this.showNotification('Content copied to clipboard!', 'success');
            
            // Reset button after 2 seconds
            setTimeout(function() {
                $button.text(originalText).removeClass('copied');
            }, 2000);
        },

        /**
         * Show notification message
         */
        showNotification: function(message, type) {
            // Remove existing notifications
            $('.vrstore-copy-notification').remove();

            // Create notification element
            var $notification = $('<div>')
                .addClass('vrstore-copy-notification')
                .text(message);
            
            if (type === 'error') {
                $notification.css('background', '#dc3545');
            }
            
            $('body').append($notification);
            
            // Trigger animation
            setTimeout(function() {
                $notification.addClass('show');
            }, 10);
            
            // Remove notification after 3 seconds
            setTimeout(function() {
                $notification.removeClass('show');
                setTimeout(function() {
                    $notification.remove();
                }, 300);
            }, 3000);
        },

        /**
         * Initialize overlays for restricted content
         */
        initOverlays: function() {
            $('.vrstore-restricted-content').each(function() {
                var $container = $(this);
                var $overlay = $container.find('.vrstore-content-overlay');
                
                if ($overlay.length) {
                    // Add some basic styling to ensure overlay works
                    $container.css({
                        'position': 'relative',
                        'overflow': 'hidden'
                    });
                    
                    $overlay.css({
                        'position': 'absolute',
                        'top': '0',
                        'left': '0',
                        'right': '0',
                        'bottom': '0',
                        'background': 'rgba(255, 255, 255, 0.95)',
                        'display': 'flex',
                        'align-items': 'center',
                        'justify-content': 'center',
                        'z-index': '10',
                        'backdrop-filter': 'blur(2px)'
                    });
                }
            });
        },

        /**
         * Handle purchase button clicks
         */
        handlePurchaseClick: function(e) {
            e.preventDefault();
            
            var $button = $(this);
            var productId = $button.data('product-id');
            var courseId = $button.data('course-id');
            var redirectUrl = $button.attr('href');
            
            // Add loading state
            $button.addClass('loading').prop('disabled', true);
            
            // If we have a redirect URL, use it
            if (redirectUrl && redirectUrl !== '#') {
                window.location.href = redirectUrl;
                return;
            }
            
            // Handle taxonomy restriction purchase buttons
            if (productId || courseId) {
                ContentRestrictionFrontend.handleTaxonomyPurchase($button, productId, courseId);
                return;
            }
            
            // Remove loading state if no action taken
            $button.removeClass('loading').prop('disabled', false);
            
            // Fallback - redirect to shop or account page
            if (typeof vrstore_ajax !== 'undefined' && vrstore_ajax.home_url) {
                window.location.href = vrstore_ajax.home_url;
            } else {
                window.location.href = '/';
            }
        },

        /**
         * Handle taxonomy restriction purchase
         */
        handleTaxonomyPurchase: function($button, productId, courseId) {
            var purchaseUrl = '';
            var itemType = '';
            var itemId = '';
            
            if (productId) {
                itemType = 'product';
                itemId = productId;
                // Check if vrstore_ajax is available for proper URL construction
                if (typeof vrstore_ajax !== 'undefined' && vrstore_ajax.home_url) {
                    purchaseUrl = vrstore_ajax.home_url + '?vrstore_action=add_to_cart&product_id=' + productId;
                } else {
                    // Fallback URL construction
                    purchaseUrl = window.location.origin + '?vrstore_action=add_to_cart&product_id=' + productId;
                }
            } else if (courseId) {
                itemType = 'course';
                itemId = courseId;
                // Check if vrstore_ajax is available for proper URL construction
                if (typeof vrstore_ajax !== 'undefined' && vrstore_ajax.home_url) {
                    purchaseUrl = vrstore_ajax.home_url + '?vrstore_action=add_to_cart&course_id=' + courseId;
                } else {
                    // Fallback URL construction
                    purchaseUrl = window.location.origin + '?vrstore_action=add_to_cart&course_id=' + courseId;
                }
            }
            
            if (purchaseUrl) {
                // Show purchase confirmation if needed
                if (ContentRestrictionFrontend.shouldShowPurchaseConfirmation()) {
                    ContentRestrictionFrontend.showPurchaseConfirmation($button, itemType, itemId, purchaseUrl);
                } else {
                    // Direct redirect to purchase
                    window.location.href = purchaseUrl;
                }
            } else {
                // Remove loading state and show error
                $button.removeClass('loading').prop('disabled', false);
                ContentRestrictionFrontend.showNotification('Unable to process purchase. Please try again.', 'error');
            }
        },

        /**
         * Check if purchase confirmation should be shown
         */
        shouldShowPurchaseConfirmation: function() {
            // You can add logic here to determine when to show confirmation
            // For now, we'll skip confirmation for better UX
            return false;
        },

        /**
         * Show purchase confirmation dialog
         */
        showPurchaseConfirmation: function($button, itemType, itemId, purchaseUrl) {
            var itemName = $button.closest('.vrstore-purchase-item').find('h6').text() || 'this item';
            var confirmMessage = 'Are you sure you want to purchase ' + itemName + '?';
            
            if (confirm(confirmMessage)) {
                window.location.href = purchaseUrl;
            } else {
                // Remove loading state if user cancels
                $button.removeClass('loading').prop('disabled', false);
            }
        },

        /**
         * Enhanced notification system for taxonomy restrictions
         */
        showTaxonomyNotification: function(message, type, duration) {
            duration = duration || 4000;
            
            // Remove existing notifications
            $('.vrstore-taxonomy-notification').remove();

            // Create notification element with better styling
            var $notification = $('<div>')
                .addClass('vrstore-taxonomy-notification')
                .html('<span class="vrstore-notification-icon"></span><span class="vrstore-notification-text">' + message + '</span>');
            
            // Add type-specific classes and icons
            switch(type) {
                case 'success':
                    $notification.addClass('vrstore-notification-success');
                    $notification.find('.vrstore-notification-icon').html('✓');
                    break;
                case 'error':
                    $notification.addClass('vrstore-notification-error');
                    $notification.find('.vrstore-notification-icon').html('✕');
                    break;
                case 'info':
                    $notification.addClass('vrstore-notification-info');
                    $notification.find('.vrstore-notification-icon').html('ℹ');
                    break;
                default:
                    $notification.addClass('vrstore-notification-default');
                    $notification.find('.vrstore-notification-icon').html('•');
            }
            
            // Add notification styles
            $notification.css({
                'position': 'fixed',
                'top': '20px',
                'right': '20px',
                'padding': '12px 20px',
                'border-radius': '8px',
                'color': '#fff',
                'font-weight': '500',
                'z-index': '9999',
                'transform': 'translateX(100%)',
                'transition': 'transform 0.3s ease',
                'box-shadow': '0 4px 12px rgba(0,0,0,0.15)',
                'max-width': '300px',
                'word-wrap': 'break-word'
            });
            
            // Type-specific colors
            if (type === 'success') {
                $notification.css('background', '#28a745');
            } else if (type === 'error') {
                $notification.css('background', '#dc3545');
            } else if (type === 'info') {
                $notification.css('background', '#17a2b8');
            } else {
                $notification.css('background', '#6c757d');
            }
            
            $('body').append($notification);
            
            // Trigger slide-in animation
            setTimeout(function() {
                $notification.css('transform', 'translateX(0)');
            }, 10);
            
            // Remove notification after specified duration
            setTimeout(function() {
                $notification.css('transform', 'translateX(100%)');
                setTimeout(function() {
                    $notification.remove();
                }, 300);
            }, duration);
        },

        /**
         * Close overlay (if close functionality is needed)
         */
        closeOverlay: function(e) {
            e.preventDefault();
            
            var $overlay = $(this).closest('.vrstore-content-overlay');
            $overlay.fadeOut(300);
        }
    };

    // Make ContentRestrictionFrontend globally accessible
    window.ContentRestrictionFrontend = ContentRestrictionFrontend;

    /**
     * Initialize when document is ready
     */
    $(document).ready(function() {
        // Initialize regardless of vrstore_ajax for testing purposes
        ContentRestrictionFrontend.init();
    });

})(jQuery);