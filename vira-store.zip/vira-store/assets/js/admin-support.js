/**
 * Admin Support Tickets JavaScript
 */

jQuery(document).ready(function($) {
    'use strict';
    
    // Check if we have the required globals
    if (typeof ajaxurl === 'undefined') {
        console.error('VRStore Support: ajaxurl is not defined');
        return;
    }
    
    // Get nonce from vrstore_admin (standard admin nonce)
    var adminNonce = '';
    if (typeof vrstore_admin !== 'undefined' && vrstore_admin.nonce) {
        adminNonce = vrstore_admin.nonce;
    } else if (typeof vrstoreAjax !== 'undefined' && vrstoreAjax.nonce) {
        adminNonce = vrstoreAjax.nonce;
    } else {
        // Try to find nonce in the page
        var nonceInput = $('input[name*="nonce"], input[id*="nonce"]').first();
        if (nonceInput.length) {
            adminNonce = nonceInput.val();
        }
    }
    
    // Warn if no nonce is available
    if (!adminNonce) {
        console.warn('VRStore Support: No valid admin nonce found');
    }
    
    
    // Support ticket functionality
    
    // Show error message in modal content
    function showTicketError($content, message) {
        $content.html('<div class="notice notice-error inline"><p>' + message + '</p></div>').show();
    }
    
    // Show success message in modal
    function showTicketMessage(message, type) {
        var className = type === 'success' ? 'notice-success' : 'notice-error';
        var html = '<div class="notice ' + className + ' inline is-dismissible"><p>' + message + '</p></div>';
        $('#vrstore-ticket-detail-content').prepend(html);
        
        // Auto remove after 3 seconds
        setTimeout(function() {
            $('#vrstore-ticket-detail-content .notice').fadeOut();
        }, 3000);
    }
    
    // Modal close handlers
    $(document).on('click', '.vrstore-modal-close, #vrstore-tickets-close, #vrstore-ticket-detail-close', function(e) {
        e.preventDefault();
        $(this).closest('.vrstore-modal').hide();
        $('body').removeClass('modal-open');
    });
    
    // Close modal on overlay click
    $(document).on('click', '.vrstore-modal', function(e) {
        if (e.target === this) {
            $(this).hide();
            $('body').removeClass('modal-open');
        }
    });
    
    // Close modal on escape key
    $(document).on('keydown', function(e) {
        if (e.key === 'Escape') {
            $('.vrstore-modal:visible').hide();
            $('body').removeClass('modal-open');
        }
    });
    
    // Handle viewing customer tickets
    $(document).on('click', '.vrstore-view-tickets', function(e) {
        e.preventDefault();
        var customerId = $(this).data('customer-id');
        var customerName = $(this).data('customer-name');
        
        if (!customerId) {
            alert('Invalid customer ID');
            return;
        }
        
        showTicketsModal(customerId);
    });
    
    // Show tickets modal
    function showTicketsModal(customerId) {
        var $modal = $('#vrstore-tickets-modal');
        var $loading = $('#vrstore-tickets-loading');
        var $content = $('#vrstore-tickets-content');
        
        if ($modal.length === 0) {
            alert('Modal container not found. Please refresh the page.');
            return;
        }
        
        if (!adminNonce) {
            showTicketError($content, 'Security token not found. Please refresh the page.');
            $modal.show();
            $loading.hide();
            $content.show();
            return;
        }
        
        // Show modal and loading state
        $modal.show();
        $loading.show();
        $content.hide();
        
        // Prevent body scrolling
        $('body').addClass('modal-open');
        
        // Load customer tickets
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'vrstore_get_customer_tickets',
                customer_id: customerId,
                nonce: adminNonce
            },
            timeout: 15000,
            success: function(response) {
                if (response && response.success) {
                    $('#vrstore-tickets-modal-title').text(response.data.title || 'Customer Support Tickets');
                    $content.html(response.data.html || '<p>No ticket data received</p>');
                    $loading.hide();
                    $content.show();
                    
                    // Initialize ticket detail handlers
                    initializeTicketDetailHandlers();
                } else {
                    var errorMsg = (response && response.data && response.data.message) ? 
                                  response.data.message : 'Failed to load tickets';
                    showTicketError($content, errorMsg);
                    $loading.hide();
                }
            },
            error: function(xhr, textStatus, errorThrown) {
                var errorMsg = 'Network error occurred';
                if (xhr.status === 403) {
                    errorMsg = 'Permission denied. Please refresh the page and try again.';
                } else if (xhr.status === 500) {
                    errorMsg = 'Server error occurred.';
                } else if (textStatus === 'timeout') {
                    errorMsg = 'Request timeout. Please try again.';
                }
                
                showTicketError($content, errorMsg);
                $loading.hide();
            }
        });
    }
    
    // Initialize ticket detail handlers
    function initializeTicketDetailHandlers() {
        $('.vrstore-view-ticket-details').off('click').on('click', function(e) {
            e.preventDefault();
            
            var ticketId = $(this).data('ticket-id');
            showTicketDetail(ticketId);
        });
    }
    
    // Show individual ticket detail
    function showTicketDetail(ticketId) {
        var $modal = $('#vrstore-ticket-detail-modal');
        var $loading = $('#vrstore-ticket-detail-loading');
        var $content = $('#vrstore-ticket-detail-content');
        
        // Show modal and loading state
        $modal.show();
        $loading.show();
        $content.hide();
        
        // Load ticket details
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'vrstore_get_ticket_details',
                ticket_id: ticketId,
                nonce: adminNonce
            },
            success: function(response) {
                if (response && response.success) {
                    $('#vrstore-ticket-detail-title').text(response.data.title || 'Ticket Details');
                    $content.html(response.data.html || '<p>No ticket details received</p>');
                    $loading.hide();
                    $content.show();
                    
                    // Initialize form handlers
                    initializeTicketFormHandlers();
                } else {
                    var errorMsg = (response && response.data && response.data.message) ? 
                                  response.data.message : 'Failed to load ticket details';
                    showTicketError($content, errorMsg);
                    $loading.hide();
                }
            },
            error: function(xhr, textStatus, errorThrown) {
                showTicketError($content, 'Network error occurred while loading ticket details');
                $loading.hide();
            }
        });
    }
    
    // Initialize ticket form handlers (status, priority, reply)
    function initializeTicketFormHandlers() {
        // Status and priority change handlers
        $('#vrstore-ticket-status, #vrstore-ticket-priority').off('change').on('change', function() {
            var $select = $(this);
            var ticketId = $select.data('ticket-id');
            var field = $select.attr('id').replace('vrstore-ticket-', '');
            var value = $select.val();
            var originalValue = $select.find('option[selected]').val();
            
            if (value === originalValue) return;
            
            // Show loading state
            $select.prop('disabled', true);
            
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'vrstore_update_ticket_status',
                    ticket_id: ticketId,
                    field: field,
                    value: value,
                    nonce: adminNonce
                },
                success: function(response) {
                    if (response && response.success) {
                        // Update the selected attribute
                        $select.find('option').removeAttr('selected');
                        $select.find('option[value="' + value + '"]').attr('selected', 'selected');
                        
                        showTicketMessage(response.data.message || 'Updated successfully', 'success');
                    } else {
                        // Revert to original value
                        $select.val(originalValue);
                        var errorMsg = (response && response.data && response.data.message) ? 
                                      response.data.message : 'Failed to update ticket';
                        showTicketMessage(errorMsg, 'error');
                    }
                },
                error: function() {
                    // Revert to original value
                    $select.val(originalValue);
                    showTicketMessage('Network error occurred', 'error');
                },
                complete: function() {
                    $select.prop('disabled', false);
                }
            });
        });
        
        // Reply form handler
        $('#vrstore-ticket-reply-form').off('submit').on('submit', function(e) {
            e.preventDefault();
            
            var $form = $(this);
            var $submitBtn = $form.find('button[type="submit"]');
            var $messageField = $form.find('#vrstore-reply-message');
            var ticketId = $form.data('ticket-id');
            var message = $messageField.val().trim();
            var isPrivate = $form.find('input[name="is_private"]:checked').length > 0 ? 1 : 0;
            
            if (!message) {
                showTicketMessage('Please enter a reply message', 'error');
                return;
            }
            
            // Show loading state
            $submitBtn.prop('disabled', true).text('Sending...');
            
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'vrstore_add_ticket_reply',
                    ticket_id: ticketId,
                    message: message,
                    is_private: isPrivate,
                    nonce: adminNonce
                },
                success: function(response) {
                    if (response && response.success) {
                        showTicketMessage(response.data.message || 'Reply sent successfully', 'success');
                        
                        // Clear form
                        $messageField.val('');
                        $form.find('input[name="is_private"]').prop('checked', false);
                        
                        // Reload ticket details if requested
                        if (response.data.reload_ticket) {
                            setTimeout(function() {
                                showTicketDetail(ticketId);
                            }, 1000);
                        }
                    } else {
                        var errorMsg = (response && response.data && response.data.message) ? 
                                      response.data.message : 'Failed to send reply';
                        showTicketMessage(errorMsg, 'error');
                    }
                },
                error: function() {
                    showTicketMessage('Network error occurred', 'error');
                },
                complete: function() {
                    $submitBtn.prop('disabled', false).text('Send Reply');
                }
            });
        });
    }
    
    // Show ticket error
    function showTicketError($container, message) {
        var errorHtml = '<div class="notice notice-error"><p><strong>Error:</strong> ' + 
                       $('<div>').text(message).html() + '</p></div>';
        $container.html(errorHtml).show();
    }
    
    // Show ticket message
    function showTicketMessage(message, type) {
        var $message = $('<div class="notice notice-' + (type || 'info') + ' is-dismissible"><p>' + 
                        $('<div>').text(message).html() + '</p></div>');
        
        // Find a good container for the message
        var $container = $('#vrstore-ticket-detail-content .ticket-header, #vrstore-tickets-content .vrstore-tickets-summary').first();
        if (!$container.length) {
            $container = $('#vrstore-ticket-detail-content, #vrstore-tickets-content').first();
        }
        
        if ($container.length) {
            $container.prepend($message);
            
            // Auto-remove after 3 seconds
            setTimeout(function() {
                $message.fadeOut(function() {
                    $message.remove();
                });
            }, 3000);
        }
    }
    
    // Modal close handlers
    $(document).on('click', '.vrstore-modal-close, #vrstore-tickets-close, #vrstore-ticket-detail-close', function() {
        $(this).closest('.vrstore-modal').hide();
        $('body').removeClass('modal-open');
    });
    
    // Close modal when clicking outside
    $(document).on('click', '.vrstore-modal', function(e) {
        if (e.target === this) {
            $(this).hide();
            $('body').removeClass('modal-open');
        }
    });
    
    // ESC key to close modals
    $(document).on('keydown', function(e) {
        if (e.keyCode === 27 && $('.vrstore-modal:visible').length) {
            $('.vrstore-modal:visible').hide();
            $('body').removeClass('modal-open');
        }
    });
    
});
