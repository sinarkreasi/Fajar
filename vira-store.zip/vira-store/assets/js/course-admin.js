/**
 * Course Admin JavaScript
 *
 * @package Vira_Store
 */

(function ($) {
    'use strict';

    $(document).ready(function () {
        var vrstoreCourseAdmin = {

            /**
             * Initialize all course admin functionality
             */
            init: function () {
                this.initCurriculumManagement();
                this.initInstructorAvatarUpload();
                this.initPricingToggle();
                this.initDuplicateCourse();
                this.initFormValidation();
                this.initModuleMoveControls();
                this.initKeyboardNavigation();
                this.initAutoSave();
                this.initVideoFields();
                this.initLessonTypeChanges();
                this.initMaterialFields();
                this.initAccessControlMetabox();
                this.initSignatureUpload();
                this.initCertificationToggle();
                this.initCoursePricing();
            },

            /**
             * Initialize curriculum management (add/remove modules and lessons)
             */
            initCurriculumManagement: function () {
                var self = this;

                // Add new module
                $(document).on('click', '.vrstore-add-module', function (e) {
                    e.preventDefault();
                    self.addModule();
                });

                // Remove module with confirmation
                $(document).on('click', '.vrstore-remove-module', function (e) {
                    e.preventDefault();
                    var $module = $(this).closest('.vrstore-curriculum-module');

                    if (confirm(vrstore_course_admin.remove_module || 'Are you sure you want to remove this module?')) {
                        $module.fadeOut(300, function () {
                            $module.remove();
                            self.updateModuleIndexes();
                        });
                    }
                });

                // Add new lesson
                $(document).on('click', '.vrstore-add-lesson', function (e) {
                    e.preventDefault();
                    var moduleIndex = $(this).data('module');
                    self.addLesson(moduleIndex);
                });

                // Remove lesson with confirmation
                $(document).on('click', '.vrstore-remove-lesson', function (e) {
                    e.preventDefault();
                    var $lesson = $(this).closest('.vrstore-curriculum-lesson');

                    if (confirm(vrstore_course_admin.remove_lesson || 'Are you sure you want to remove this lesson?')) {
                        $lesson.fadeOut(300, function () {
                            $lesson.remove();
                        });
                    }
                });

                // Update lesson indexes when modules change
                this.updateModuleIndexes();
            },

            /**
             * Add new curriculum module
             */
            addModule: function () {
                var moduleCount = $('.vrstore-curriculum-module').length;
                var moduleHtml = this.getModuleHtml(moduleCount);

                $('.vrstore-curriculum-list').append(moduleHtml);

                // Focus on the new module title field
                $('.vrstore-curriculum-module').last().find('.module-title').focus();

                // Update all indexes
                this.updateModuleIndexes();

                // Trigger custom event
                $(document).trigger('vrstore:module:added', [moduleCount]);
            },

            /**
             * Add new lesson to a module
             */
            addLesson: function (moduleIndex) {
                var $module = $('.vrstore-curriculum-module[data-index="' + moduleIndex + '"]');
                var lessonCount = $module.find('.vrstore-curriculum-lesson').length;
                var lessonHtml = this.getLessonHtml(moduleIndex, lessonCount);

                $module.find('.module-lessons').append(lessonHtml);

                // Focus on the new lesson title field
                $module.find('.vrstore-curriculum-lesson').last().find('.lesson-title').focus();

                // Trigger custom event
                $(document).trigger('vrstore:lesson:added', [moduleIndex, lessonCount]);
            },

            /**
             * Generate HTML for a new module
             */
            getModuleHtml: function (index) {
                return '<div class="vrstore-curriculum-module" data-index="' + index + '">' +
                    '<div class="module-header">' +
                    '<div class="module-controls">' +
                    '<button type="button" class="button button-small vrstore-move-module-top" data-index="' + index + '" title="Move to top">' +
                    '<span class="dashicons dashicons-arrow-up-alt2"></span></button>' +
                    '<button type="button" class="button button-small vrstore-move-module-bottom" data-index="' + index + '" title="Move to bottom">' +
                    '<span class="dashicons dashicons-arrow-down-alt2"></span></button>' +
                    '</div>' +
                    '<input type="text" name="vrstore_course_curriculum[' + index + '][title]" value="" placeholder="Module Title" class="module-title" required />' +
                    '<button type="button" class="button vrstore-remove-module">Remove Module</button>' +
                    '</div>' +
                    '<div class="module-lessons"></div>' +
                    '<button type="button" class="button vrstore-add-lesson" data-module="' + index + '">Add Lesson</button>' +
                    '</div>';
            },

            /**
             * Generate HTML for a new lesson
             */
            getLessonHtml: function (moduleIndex, lessonIndex) {
                return '<div class="vrstore-curriculum-lesson" data-lesson-index="' + lessonIndex + '">' +
                    '<div class="lesson-row">' +
                    '<input type="text" name="vrstore_course_curriculum[' + moduleIndex + '][lessons][' + lessonIndex + '][title]" value="" placeholder="Lesson Title" class="lesson-title" style="width: 30%;" required />' +
                    '<div style="margin: 10px 0; clear: both;">' +
                    '<label style="display: block; margin-bottom: 5px; font-weight: 600; color: #23282d; font-size: 13px;">Lesson Description</label>' +
                    '<textarea name="vrstore_course_curriculum[' + moduleIndex + '][lessons][' + lessonIndex + '][description]" placeholder="Brief description of what students will learn in this lesson..." class="lesson-description" style="width: 100%; min-height: 80px; padding: 8px 12px; border: 1px solid #ddd; border-radius: 4px; font-size: 13px; line-height: 1.4; resize: vertical; box-sizing: border-box;"></textarea>' +
                    '</div>' +
                    '<input type="text" name="vrstore_course_curriculum[' + moduleIndex + '][lessons][' + lessonIndex + '][duration]" value="" placeholder="5 min" class="lesson-duration" style="width: 15%;" />' +
                    '<select name="vrstore_course_curriculum[' + moduleIndex + '][lessons][' + lessonIndex + '][type]" class="lesson-type" style="width: 20%;">' +
                    '<option value="video_upload">Video Upload</option>' +
                    '<option value="video_url">Video URL</option>' +
                    '</select>' +
                    '<button type="button" class="button vrstore-remove-lesson">Remove</button>' +
                    '</div>' +

                    // Video Upload Fields
                    '<div class="lesson-video-upload-fields" style="display: block; margin-top: 10px; padding: 10px; background: #f9f9f9; border-radius: 4px; border-left: 4px solid #28a745;">' +
                    '<h4 style="margin: 0 0 10px 0; color: #28a745; font-size: 14px;">Video Upload</h4>' +
                    '<input type="hidden" name="vrstore_course_curriculum[' + moduleIndex + '][lessons][' + lessonIndex + '][video_file]" value="" class="lesson-video-file-id" />' +
                    '<div class="lesson-video-preview"></div>' +
                    '<button type="button" class="button select-video-file" data-module="' + moduleIndex + '" data-lesson="' + lessonIndex + '">Select Video File</button>' +
                    '</div>' +

                    // Video URL Fields
                    '<div class="lesson-video-url-fields" style="display: none; margin-top: 10px; padding: 10px; background: #f9f9f9; border-radius: 4px; border-left: 4px solid #dc3545;">' +
                    '<h4 style="margin: 0 0 10px 0; color: #dc3545; font-size: 14px;">Video URL (YouTube, Vimeo, etc.)</h4>' +
                    '<div style="margin-bottom: 10px;">' +
                    '<label style="display: block; margin-bottom: 5px; font-weight: 600;">Video URL</label>' +
                    '<input type="url" name="vrstore_course_curriculum[' + moduleIndex + '][lessons][' + lessonIndex + '][video_url]" value="" placeholder="https://www.youtube.com/watch?v=... or https://vimeo.com/..." style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;" />' +
                    '<small style="color: #666; font-size: 12px; display: block; margin-top: 5px;">Supports YouTube, Vimeo, and other video platform URLs</small>' +
                    '</div>' +
                    '</div>' +


                    // Free preview option
                    '<div style="margin-top: 10px;">' +
                    '<label style="display: flex; align-items: center; gap: 8px;">' +
                    '<input type="checkbox" name="vrstore_course_curriculum[' + moduleIndex + '][lessons][' + lessonIndex + '][is_free_preview]" value="1" />' +
                    '<span style="font-weight: 600; color: #0073aa;">Free Preview - Allow non-enrolled users to watch this lesson</span>' +
                    '</label>' +
                    '</div>' +

                    // Material fields
                    '<div class="lesson-material-fields" style="margin-top: 10px; padding: 10px; background: #f0f8ff; border-radius: 4px; border-left: 4px solid #0073aa;">' +
                    '<h4 style="margin: 0 0 10px 0; color: #0073aa; font-size: 14px;">Lesson Materials</h4>' +
                    '<div style="margin-bottom: 10px;">' +
                    '<label style="display: block; margin-bottom: 5px; font-weight: 600;">Material URL (external link)</label>' +
                    '<input type="url" name="vrstore_course_curriculum[' + moduleIndex + '][lessons][' + lessonIndex + '][material_url]" value="" placeholder="https://example.com/resource" style="width: 100%;" />' +
                    '</div>' +
                    '<div style="margin-bottom: 10px;">' +
                    '<label style="display: block; margin-bottom: 5px; font-weight: 600;">Or Upload Material File</label>' +
                    '<input type="hidden" name="vrstore_course_curriculum[' + moduleIndex + '][lessons][' + lessonIndex + '][material_file]" value="" class="lesson-material-file-id" />' +
                    '<div class="lesson-material-preview"></div>' +
                    '<button type="button" class="button select-material-file" data-module="' + moduleIndex + '" data-lesson="' + lessonIndex + '">Select Material File</button>' +
                    '</div>' +
                    '</div>' +
                    '</div>';
            },

            /**
             * Update module and lesson indexes after changes
             */
            updateModuleIndexes: function () {
                $('.vrstore-curriculum-module').each(function (moduleIndex) {
                    var $module = $(this);
                    $module.attr('data-index', moduleIndex);

                    // Update module input names
                    $module.find('.module-title').attr('name', 'vrstore_course_curriculum[' + moduleIndex + '][title]');
                    $module.find('.vrstore-add-lesson').attr('data-module', moduleIndex);

                    // Update lesson input names
                    $module.find('.vrstore-curriculum-lesson').each(function (lessonIndex) {
                        var $lesson = $(this);
                        $lesson.attr('data-lesson-index', lessonIndex);

                        $lesson.find('.lesson-title').attr('name', 'vrstore_course_curriculum[' + moduleIndex + '][lessons][' + lessonIndex + '][title]');
                        $lesson.find('.lesson-description').attr('name', 'vrstore_course_curriculum[' + moduleIndex + '][lessons][' + lessonIndex + '][description]');
                        $lesson.find('.lesson-duration').attr('name', 'vrstore_course_curriculum[' + moduleIndex + '][lessons][' + lessonIndex + '][duration]');
                        $lesson.find('.lesson-type').attr('name', 'vrstore_course_curriculum[' + moduleIndex + '][lessons][' + lessonIndex + '][type]');
                        $lesson.find('input[name*="[video_url]"]').attr('name', 'vrstore_course_curriculum[' + moduleIndex + '][lessons][' + lessonIndex + '][video_url]');
                        $lesson.find('input[name*="[video_file]"]').attr('name', 'vrstore_course_curriculum[' + moduleIndex + '][lessons][' + lessonIndex + '][video_file]');
                        $lesson.find('input[name*="[is_free_preview]"]').attr('name', 'vrstore_course_curriculum[' + moduleIndex + '][lessons][' + lessonIndex + '][is_free_preview]');
                        $lesson.find('input[name*="[material_url]"]').attr('name', 'vrstore_course_curriculum[' + moduleIndex + '][lessons][' + lessonIndex + '][material_url]');
                        $lesson.find('input[name*="[material_file]"]').attr('name', 'vrstore_course_curriculum[' + moduleIndex + '][lessons][' + lessonIndex + '][material_file]');
                        $lesson.find('.select-video-file').attr('data-module', moduleIndex).attr('data-lesson', lessonIndex);
                        $lesson.find('.remove-video-file').attr('data-module', moduleIndex).attr('data-lesson', lessonIndex);
                        $lesson.find('.select-material-file').attr('data-module', moduleIndex).attr('data-lesson', lessonIndex);
                        $lesson.find('.remove-material-file').attr('data-module', moduleIndex).attr('data-lesson', lessonIndex);
                    });
                });

                // Update move button states after reindexing
                this.updateMoveButtonStates();
            },

            /**
             * Initialize instructor avatar upload functionality
             */
            initInstructorAvatarUpload: function () {
                // Select avatar button
                $('#select-instructor-avatar').on('click', function (e) {
                    e.preventDefault();

                    var mediaUploader = wp.media({
                        title: 'Select Instructor Avatar',
                        button: {
                            text: 'Use this image'
                        },
                        multiple: false,
                        library: {
                            type: 'image'
                        }
                    });

                    mediaUploader.on('select', function () {
                        var attachment = mediaUploader.state().get('selection').first().toJSON();

                        $('#vrstore_course_instructor_avatar').val(attachment.id);
                        $('#instructor-avatar-preview').html('<img src="' + attachment.url + '" style="max-width: 100px; height: auto; border-radius: 50%; border: 3px solid #ddd;" />');
                        $('#remove-instructor-avatar').show();
                    });

                    mediaUploader.open();
                });

                // Remove avatar button
                $('#remove-instructor-avatar').on('click', function (e) {
                    e.preventDefault();

                    $('#vrstore_course_instructor_avatar').val('');
                    $('#instructor-avatar-preview').html('');
                    $(this).hide();
                });
            },

            /**
             * Initialize pricing section toggle
             */
            initPricingToggle: function () {
                $('#vrstore_course_is_free').on('change', function () {
                    var $pricingFields = $('#course-pricing-fields');

                    if ($(this).is(':checked')) {
                        $pricingFields.slideUp(300);
                        // Clear price values when marked as free
                        $pricingFields.find('input[type="number"]').val('');
                    } else {
                        $pricingFields.slideDown(300);
                    }
                });

                // Initialize state on page load
                if ($('#vrstore_course_is_free').is(':checked')) {
                    $('#course-pricing-fields').hide();
                }
            },

            /**
             * Initialize course duplication functionality
             */
            initDuplicateCourse: function () {
                $(document).on('click', '.vrstore-duplicate-course', function (e) {
                    e.preventDefault();

                    if (!confirm(vrstore_course_admin.confirm_duplicate || 'Are you sure you want to duplicate this course?')) {
                        return;
                    }

                    var $link = $(this);
                    var courseId = $link.data('course-id');
                    var originalText = $link.text();

                    // Show loading state
                    $link.text(vrstore_course_admin.duplicating || 'Duplicating...');
                    $link.css('pointer-events', 'none');

                    $.ajax({
                        url: vrstore_course_admin.ajax_url,
                        type: 'POST',
                        data: {
                            action: 'vrstore_duplicate_course',
                            course_id: courseId,
                            nonce: vrstore_course_admin.nonce
                        },
                        success: function (response) {
                            if (response.success) {
                                // Show success message
                                vrstoreCourseAdmin.showMessage(response.data.message || vrstore_course_admin.duplicate_success, 'success');

                                // Redirect to edit the new course
                                if (response.data.edit_url) {
                                    setTimeout(function () {
                                        window.location.href = response.data.edit_url;
                                    }, 1500);
                                } else {
                                    // Refresh the page
                                    setTimeout(function () {
                                        location.reload();
                                    }, 1500);
                                }
                            } else {
                                vrstoreCourseAdmin.showMessage(response.data || vrstore_course_admin.duplicate_error, 'error');
                                $link.text(originalText);
                                $link.css('pointer-events', 'auto');
                            }
                        },
                        error: function () {
                            vrstoreCourseAdmin.showMessage(vrstore_course_admin.duplicate_error || 'Failed to duplicate course. Please try again.', 'error');
                            $link.text(originalText);
                            $link.css('pointer-events', 'auto');
                        }
                    });
                });
            },

            /**
             * Initialize form validation
             */
            initFormValidation: function () {
                var self = this;

                // Real-time validation for required fields
                $(document).on('blur', '.module-title, .lesson-title', function () {
                    self.validateField($(this));
                });

                // Form submission validation
                $('#post').on('submit', function (e) {
                    var hasErrors = false;

                    // Validate all required curriculum fields
                    $('.module-title, .lesson-title').each(function () {
                        if (!self.validateField($(this))) {
                            hasErrors = true;
                        }
                    });

                    // Validate access control settings
                    if (!self.validateAccessControlSettings()) {
                        hasErrors = true;
                    }

                    if (hasErrors) {
                        e.preventDefault();
                        self.showMessage('Please fix all validation errors before saving.', 'error');

                        // Focus on first error field
                        $('.vrstore-field-error').first().focus();
                    }
                });
            },

            /**
             * Validate individual field
             */
            validateField: function ($field) {
                var isValid = true;
                var value = $field.val().trim();

                // Remove existing error state
                $field.removeClass('vrstore-field-error');
                $field.next('.vrstore-error-message').remove();

                // Check if required field is empty
                if ($field.prop('required') && !value) {
                    isValid = false;
                    $field.addClass('vrstore-field-error');
                    $field.after('<div class="vrstore-error-message">This field is required.</div>');
                }

                return isValid;
            },

            /**
             * Initialize module move controls
             */
            initModuleMoveControls: function () {
                var self = this;

                // Move module to top
                $(document).on('click', '.vrstore-move-module-top', function (e) {
                    e.preventDefault();
                    var $module = $(this).closest('.vrstore-curriculum-module');
                    var $firstModule = $('.vrstore-curriculum-module').first();

                    if (!$module.is($firstModule)) {
                        $module.fadeOut(200, function () {
                            $module.insertBefore($firstModule);
                            $module.fadeIn(200, function () {
                                self.updateModuleIndexes();
                            });
                        });
                    }
                });

                // Move module to bottom
                $(document).on('click', '.vrstore-move-module-bottom', function (e) {
                    e.preventDefault();
                    var $module = $(this).closest('.vrstore-curriculum-module');
                    var $lastModule = $('.vrstore-curriculum-module').last();

                    if (!$module.is($lastModule)) {
                        $module.fadeOut(200, function () {
                            $module.insertAfter($lastModule);
                            $module.fadeIn(200, function () {
                                self.updateModuleIndexes();
                            });
                        });
                    }
                });

                // Update button states
                this.updateMoveButtonStates();
            },

            /**
             * Update move button states based on module position
             */
            updateMoveButtonStates: function () {
                var $modules = $('.vrstore-curriculum-module');

                $modules.each(function (index) {
                    var $module = $(this);
                    var $topButton = $module.find('.vrstore-move-module-top');
                    var $bottomButton = $module.find('.vrstore-move-module-bottom');

                    // Update data-index attribute
                    $module.attr('data-index', index);
                    $topButton.attr('data-index', index);
                    $bottomButton.attr('data-index', index);

                    // Disable/enable buttons based on position
                    if (index === 0) {
                        // First module - disable top button
                        $topButton.prop('disabled', true).addClass('disabled');
                    } else {
                        $topButton.prop('disabled', false).removeClass('disabled');
                    }

                    if (index === $modules.length - 1) {
                        // Last module - disable bottom button
                        $bottomButton.prop('disabled', true).addClass('disabled');
                    } else {
                        $bottomButton.prop('disabled', false).removeClass('disabled');
                    }
                });
            },

            /**
             * Initialize keyboard navigation improvements
             */
            initKeyboardNavigation: function () {
                // Add keyboard support for module/lesson management
                $(document).on('keydown', '.vrstore-add-module, .vrstore-add-lesson, .vrstore-remove-module, .vrstore-remove-lesson', function (e) {
                    if (e.keyCode === 13 || e.keyCode === 32) { // Enter or Space
                        e.preventDefault();
                        $(this).click();
                    }
                });

                // Tab navigation improvements
                $(document).on('keydown', '.module-title, .lesson-title', function (e) {
                    if (e.keyCode === 13) { // Enter key
                        e.preventDefault();

                        var $current = $(this);
                        var $next;

                        if ($current.hasClass('module-title')) {
                            // If it's a module title, focus on first lesson or add lesson button
                            $next = $current.closest('.vrstore-curriculum-module').find('.lesson-title').first();
                            if (!$next.length) {
                                $next = $current.closest('.vrstore-curriculum-module').find('.vrstore-add-lesson');
                            }
                        } else {
                            // If it's a lesson title, focus on next lesson or add lesson button
                            $next = $current.closest('.vrstore-curriculum-lesson').next().find('.lesson-title');
                            if (!$next.length) {
                                $next = $current.closest('.vrstore-curriculum-module').find('.vrstore-add-lesson');
                            }
                        }

                        if ($next.length) {
                            $next.focus();
                        }
                    }
                });
            },

            /**
             * Initialize auto-save functionality
             */
            initAutoSave: function () {
                var saveTimeout;

                // Auto-save when curriculum data changes
                $(document).on('input', '.module-title, .lesson-title, .lesson-duration', function () {
                    clearTimeout(saveTimeout);
                    saveTimeout = setTimeout(function () {
                        if (typeof wp !== 'undefined' && wp.autosave) {
                            wp.autosave.server.triggerSave();
                        }
                    }, 3000); // Save after 3 seconds of inactivity
                });
            },

            /**
             * Show admin messages
             */
            showMessage: function (message, type) {
                type = type || 'info';

                var $message = $('<div class="notice notice-' + type + ' is-dismissible vrstore-course-message ' + type + '">' +
                    '<p>' + message + '</p>' +
                    '<button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button>' +
                    '</div>');

                // Insert after the page title
                if ($('.wrap h1').length) {
                    $('.wrap h1').after($message);
                } else {
                    $('.wrap').prepend($message);
                }

                // Handle dismiss button
                $message.find('.notice-dismiss').on('click', function () {
                    $message.fadeOut(300, function () {
                        $message.remove();
                    });
                });

                // Auto-remove after 5 seconds
                setTimeout(function () {
                    $message.fadeOut(300, function () {
                        $message.remove();
                    });
                }, 5000);
            },

            /**
             * Calculate total course duration
             */
            calculateTotalDuration: function () {
                var totalMinutes = 0;
                $('.lesson-duration').each(function () {
                    var duration = $(this).val().trim();
                    var minutes = parseFloat(duration);
                    if (!isNaN(minutes)) {
                        totalMinutes += minutes;
                    }
                });
                return totalMinutes;
            },

            /**
             * Update course statistics
             */
            updateCourseStats: function () {
                var moduleCount = $('.vrstore-curriculum-module').length;
                var lessonCount = $('.vrstore-curriculum-lesson').length;
                var totalDuration = this.calculateTotalDuration();

                // Update stats display if it exists
                $('.course-module-count').text(moduleCount);
                $('.course-lesson-count').text(lessonCount);
                $('.course-total-duration').text(totalDuration + ' minutes');

                // Trigger custom event
                $(document).trigger('vrstore:course:stats:updated', [moduleCount, lessonCount, totalDuration]);
            },

            /**
             * Import curriculum from JSON
             */
            importCurriculum: function (jsonData) {
                try {
                    var curriculum = JSON.parse(jsonData);

                    // Clear existing curriculum
                    $('.vrstore-curriculum-list').empty();

                    // Add modules from imported data
                    curriculum.forEach(function (module, moduleIndex) {
                        vrstoreCourseAdmin.addModule();
                        var $module = $('.vrstore-curriculum-module').last();

                        // Set module title
                        $module.find('.module-title').val(module.title);

                        // Add lessons
                        if (module.lessons && module.lessons.length > 0) {
                            module.lessons.forEach(function (lesson, lessonIndex) {
                                vrstoreCourseAdmin.addLesson(moduleIndex);
                                var $lesson = $module.find('.vrstore-curriculum-lesson').last();

                                $lesson.find('.lesson-title').val(lesson.title);
                                $lesson.find('.lesson-duration').val(lesson.duration);
                                $lesson.find('.lesson-type').val(lesson.type);
                            });
                        }
                    });

                    this.showMessage('Curriculum imported successfully!', 'success');
                } catch (e) {
                    this.showMessage('Invalid curriculum data. Please check the JSON format.', 'error');
                }
            },

            /**
             * Export curriculum to JSON
             */
            exportCurriculum: function () {
                var curriculum = [];

                $('.vrstore-curriculum-module').each(function () {
                    var $module = $(this);
                    var module = {
                        title: $module.find('.module-title').val(),
                        lessons: []
                    };

                    $module.find('.vrstore-curriculum-lesson').each(function () {
                        var $lesson = $(this);
                        module.lessons.push({
                            title: $lesson.find('.lesson-title').val(),
                            duration: $lesson.find('.lesson-duration').val(),
                            type: $lesson.find('.lesson-type').val()
                        });
                    });

                    curriculum.push(module);
                });

                return JSON.stringify(curriculum, null, 2);
            },

            /**
             * Initialize video field functionality
             */
            initVideoFields: function () {
                var self = this;

                // Handle video file selection
                $(document).on('click', '.select-video-file', function (e) {
                    e.preventDefault();

                    var $button = $(this);
                    var moduleIndex = $button.data('module');
                    var lessonIndex = $button.data('lesson');

                    var mediaUploader = wp.media({
                        title: 'Select Video File',
                        button: {
                            text: 'Use this video'
                        },
                        multiple: false,
                        library: {
                            type: ['video']
                        }
                    });

                    mediaUploader.on('select', function () {
                        var attachment = mediaUploader.state().get('selection').first().toJSON();

                        // Find the lesson container
                        var $lesson = $button.closest('.vrstore-curriculum-lesson');

                        // Update hidden input
                        $lesson.find('input[name*="[video_file]"]').val(attachment.id);

                        // Update preview within the video upload section
                        var $videoUploadSection = $lesson.find('.lesson-video-upload-fields');
                        var $preview = $videoUploadSection.find('.lesson-video-preview');
                        $preview.html('<div style="padding: 10px; background: white; border: 1px solid #ddd; border-radius: 4px; margin-bottom: 10px;">' +
                            '<i class="dashicons dashicons-video-alt3" style="color: #28a745; font-size: 20px; vertical-align: middle; margin-right: 8px;"></i>' +
                            '<strong>' + attachment.title + '</strong><br>' +
                            '<small style="color: #666;">' + attachment.url + '</small>' +
                            '</div>');

                        // Show remove button
                        var $removeButton = $videoUploadSection.find('.remove-video-file');
                        if ($removeButton.length === 0) {
                            $button.after(' <button type="button" class="button remove-video-file" data-module="' + moduleIndex + '" data-lesson="' + lessonIndex + '">Remove File</button>');
                        } else {
                            $removeButton.show();
                        }
                    });

                    mediaUploader.open();
                });

                // Handle video file removal
                $(document).on('click', '.remove-video-file', function (e) {
                    e.preventDefault();

                    var $button = $(this);
                    var moduleIndex = $button.data('module');
                    var lessonIndex = $button.data('lesson');

                    // Find the lesson container
                    var $lesson = $button.closest('.vrstore-curriculum-lesson');
                    var $videoUploadSection = $lesson.find('.lesson-video-upload-fields');

                    // Clear hidden input
                    $lesson.find('input[name*="[video_file]"]').val('');

                    // Clear preview
                    $videoUploadSection.find('.lesson-video-preview').html('');

                    // Hide remove button
                    $button.hide();
                });
            },

            /**
             * Initialize lesson type change handlers
             */
            initLessonTypeChanges: function () {
                var self = this;

                // Handle lesson type changes
                $(document).on('change', '.lesson-type', function () {
                    var $select = $(this);
                    var lessonType = $select.val();
                    var $lesson = $select.closest('.vrstore-curriculum-lesson');

                    self.toggleLessonVideoFields($lesson, lessonType);
                });

                // Initialize state on page load
                $('.lesson-type').each(function () {
                    var $select = $(this);
                    var lessonType = $select.val();
                    var $lesson = $select.closest('.vrstore-curriculum-lesson');

                    self.toggleLessonVideoFields($lesson, lessonType);
                });

                // Handle new lessons added dynamically
                $(document).on('vrstore:lesson:added', function (e, moduleIndex, lessonIndex) {
                    setTimeout(function () {
                        var $newLesson = $('.vrstore-curriculum-module[data-index="' + moduleIndex + '"] .vrstore-curriculum-lesson').last();
                        var lessonType = $newLesson.find('.lesson-type').val();
                        self.toggleLessonVideoFields($newLesson, lessonType);
                    }, 100);
                });
            },

            /**
             * Toggle lesson video fields based on lesson type
             */
            toggleLessonVideoFields: function ($lesson, lessonType) {
                // Hide all video field types
                $lesson.find('.lesson-video-upload-fields').hide();
                $lesson.find('.lesson-video-url-fields').hide();

                // Show the appropriate field type
                if (lessonType === 'video_upload') {
                    $lesson.find('.lesson-video-upload-fields').slideDown(300);
                } else if (lessonType === 'video_url') {
                    $lesson.find('.lesson-video-url-fields').slideDown(300);
                }
            },

            /**
             * Initialize material field functionality
             */
            initMaterialFields: function () {
                var self = this;

                // Handle material file selection
                $(document).on('click', '.select-material-file', function (e) {
                    e.preventDefault();

                    var $button = $(this);
                    var moduleIndex = $button.data('module');
                    var lessonIndex = $button.data('lesson');

                    var mediaUploader = wp.media({
                        title: 'Select Material File',
                        button: {
                            text: 'Use this file'
                        },
                        multiple: false,
                        library: {
                            type: ['application', 'text']
                        }
                    });

                    mediaUploader.on('select', function () {
                        var attachment = mediaUploader.state().get('selection').first().toJSON();

                        // Update hidden input
                        $('input[name="vrstore_course_curriculum[' + moduleIndex + '][lessons][' + lessonIndex + '][material_file]"]').val(attachment.id);

                        // Create file info display
                        var fileExt = attachment.filename ? attachment.filename.split('.').pop().toUpperCase() : 'FILE';
                        var fileSize = attachment.filesizeHumanReadable || 'Unknown size';

                        // Update preview
                        var $preview = $button.siblings('.lesson-material-preview');
                        $preview.html('<div style="padding: 10px; background: white; border: 1px solid #ddd; border-radius: 4px; display: flex; align-items: center; gap: 10px;"><i class="dashicons dashicons-media-document" style="color: #0073aa; font-size: 20px;"></i><div style="flex: 1;"><strong>' + attachment.title + '</strong><br><small style="color: #666;">' + fileExt + ' • ' + fileSize + '</small></div></div>');

                        // Show remove button
                        var $removeButton = $button.siblings('.remove-material-file');
                        if ($removeButton.length === 0) {
                            $button.after(' <button type="button" class="button remove-material-file" data-module="' + moduleIndex + '" data-lesson="' + lessonIndex + '">Remove File</button>');
                        } else {
                            $removeButton.show();
                        }
                    });

                    mediaUploader.open();
                });

                // Handle material file removal
                $(document).on('click', '.remove-material-file', function (e) {
                    e.preventDefault();

                    var $button = $(this);
                    var moduleIndex = $button.data('module');
                    var lessonIndex = $button.data('lesson');

                    // Clear hidden input
                    $('input[name="vrstore_course_curriculum[' + moduleIndex + '][lessons][' + lessonIndex + '][material_file]"]').val('');

                    // Clear preview
                    $button.siblings('.lesson-material-preview').html('');

                    // Hide remove button
                    $button.hide();
                });
            },

            /**
             * Initialize Course Access Control metabox functionality
             */
            initAccessControlMetabox: function () {
                var self = this;

                // Handle access period type changes
                $('input[name="vrstore_course_access_period_type"]').on('change', function () {
                    var accessType = $(this).val();
                    var $limitedSettings = $('.vrstore-limited-period-settings input, .vrstore-limited-period-settings select');

                    if (accessType === 'limited') {
                        $limitedSettings.prop('disabled', false);
                    } else {
                        $limitedSettings.prop('disabled', true);
                    }
                });

                // Handle content dripping toggle
                $('input[name="vrstore_course_content_drip_enabled"]').on('change', function () {
                    var $dripSettings = $('#drip-settings');
                    if ($(this).is(':checked')) {
                        $dripSettings.slideDown(300);
                    } else {
                        $dripSettings.slideUp(300);
                    }
                });

                // Handle trial access toggle
                $('input[name="vrstore_course_trial_enabled"]').on('change', function () {
                    var $trialSettings = $('#trial-settings');
                    if ($(this).is(':checked')) {
                        $trialSettings.slideDown(300);
                    } else {
                        $trialSettings.slideUp(300);
                    }
                });

                // Handle course visibility password toggle
                $('input[name="vrstore_course_visibility"]').on('change', function () {
                    var $passwordField = $('#visibility-password-field');
                    var selectedVisibility = $(this).val();

                    if (selectedVisibility === 'password') {
                        $passwordField.slideDown(300);
                    } else {
                        $passwordField.slideUp(300);
                    }
                });

                // Validate access period settings
                $('input[name="vrstore_course_access_period_value"]').on('input', function () {
                    var value = parseInt($(this).val());
                    var $warning = $(this).siblings('.access-period-warning');

                    // Remove existing warnings
                    $warning.remove();

                    if (isNaN(value) || value < 1) {
                        $(this).after('<span class="access-period-warning" style="color: #d63638; font-size: 12px; margin-left: 5px;">Please enter a valid number greater than 0</span>');
                    }
                });

                // Validate trial period
                $('input[name="vrstore_course_trial_period"]').on('input', function () {
                    var value = parseInt($(this).val());
                    var $warning = $(this).siblings('.trial-period-warning');

                    // Remove existing warnings
                    $warning.remove();

                    if (isNaN(value) || value < 1) {
                        $(this).after('<span class="trial-period-warning" style="color: #d63638; font-size: 12px; margin-left: 5px;">Please enter a valid number greater than 0</span>');
                    } else if (value > 365) {
                        $(this).after('<span class="trial-period-warning" style="color: #d63638; font-size: 12px; margin-left: 5px;">Trial period should not exceed 365 days</span>');
                    }
                });

                // Validate max students
                $('input[name="vrstore_course_max_students"]').on('input', function () {
                    var value = parseInt($(this).val());
                    var $warning = $(this).siblings('.max-students-warning');

                    // Remove existing warnings
                    $warning.remove();

                    if (value && (isNaN(value) || value < 1)) {
                        $(this).after('<span class="max-students-warning" style="color: #d63638; font-size: 12px; margin-left: 5px;">Please enter a valid number greater than 0, or leave empty for unlimited</span>');
                    }
                });

                // Initialize states on page load
                setTimeout(function () {
                    // Initialize access period state
                    var selectedAccessType = $('input[name="vrstore_course_access_period_type"]:checked').val();
                    if (selectedAccessType !== 'limited') {
                        $('.vrstore-limited-period-settings input, .vrstore-limited-period-settings select')
                            .prop('disabled', true);
                    }

                    // Initialize content dripping state
                    if (!$('input[name="vrstore_course_content_drip_enabled"]').is(':checked')) {
                        $('#drip-settings').hide();
                    }

                    // Initialize trial access state
                    if (!$('input[name="vrstore_course_trial_enabled"]').is(':checked')) {
                        $('#trial-settings').hide();
                    }

                    // Initialize visibility password field state
                    var selectedVisibility = $('input[name="vrstore_course_visibility"]:checked').val();
                    if (selectedVisibility !== 'password') {
                        $('#visibility-password-field').hide();
                    }
                }, 100);

                // Add help tooltips for complex settings
                self.addAccessControlTooltips();
            },

            /**
             * Add tooltips for access control settings
             */
            addAccessControlTooltips: function () {
                // Add tooltip for content dripping
                var $dripLabel = $('label[for="vrstore_course_content_drip_enabled"]');
                if ($dripLabel.length && !$dripLabel.find('.vrstore-course-tooltip').length) {
                    $dripLabel.append('<span class="vrstore-course-tooltip" title="Content dripping releases course content gradually over time, keeping students engaged and preventing information overload.">?</span>');
                }

                // Add tooltip for trial access
                var $trialLabel = $('label[for="vrstore_course_trial_enabled"]');
                if ($trialLabel.length && !$trialLabel.find('.vrstore-course-tooltip').length) {
                    $trialLabel.append('<span class="vrstore-course-tooltip" title="Trial access allows users to preview the course content for a limited time before requiring payment.">?</span>');
                }

                // Style tooltips with more specific selector to avoid conflicts
                var tooltipCSS =
                    '.vrstore-course-tooltip { ' +
                    'display: inline-block; ' +
                    'width: 16px; ' +
                    'height: 16px; ' +
                    'line-height: 16px; ' +
                    'text-align: center; ' +
                    'background: #0073aa; ' +
                    'color: white; ' +
                    'border-radius: 50%; ' +
                    'font-size: 12px; ' +
                    'margin-left: 8px; ' +
                    'cursor: help; ' +
                    '}';

                if (!$('#vrstore-access-control-tooltips').length) {
                    $('<style id="vrstore-access-control-tooltips">' + tooltipCSS + '</style>').appendTo('head');
                }
            },

            /**
             * Validate access control settings before save
             */
            validateAccessControlSettings: function () {
                var isValid = true;
                var errors = [];

                // Check limited access period settings
                if ($('input[name="vrstore_course_access_period_type"]:checked').val() === 'limited') {
                    var periodValue = parseInt($('input[name="vrstore_course_access_period_value"]').val());
                    if (isNaN(periodValue) || periodValue < 1) {
                        errors.push('Access period value must be greater than 0.');
                        isValid = false;
                    }
                }

                // Check content dripping settings
                if ($('input[name="vrstore_course_content_drip_enabled"]').is(':checked')) {
                    var dripInterval = parseInt($('input[name="vrstore_course_drip_interval_value"]').val());
                    if (isNaN(dripInterval) || dripInterval < 1) {
                        errors.push('Content drip interval must be greater than 0.');
                        isValid = false;
                    }
                }

                // Check trial period settings
                if ($('input[name="vrstore_course_trial_enabled"]').is(':checked')) {
                    var trialPeriod = parseInt($('input[name="vrstore_course_trial_period"]').val());
                    if (isNaN(trialPeriod) || trialPeriod < 1) {
                        errors.push('Trial period must be greater than 0.');
                        isValid = false;
                    } else if (trialPeriod > 365) {
                        errors.push('Trial period should not exceed 365 days.');
                        isValid = false;
                    }
                }

                // Check max students setting
                var maxStudents = $('input[name="vrstore_course_max_students"]').val();
                if (maxStudents && (isNaN(parseInt(maxStudents)) || parseInt(maxStudents) < 1)) {
                    errors.push('Maximum students must be a positive number or left empty for unlimited.');
                    isValid = false;
                }

                if (!isValid) {
                    this.showMessage('Course Access Control validation errors:\n• ' + errors.join('\n• '), 'error');
                }

                return isValid;
            },

            /**
             * Initialize signature upload functionality
             */
            initSignatureUpload: function () {
                var self = this;

                // Upload signature button
                $(document).on('click', '#vrstore_upload_signature', function (e) {
                    e.preventDefault();

                    var mediaUploader = wp.media({
                        title: 'Select Instructor Signature',
                        button: {
                            text: 'Use this signature'
                        },
                        library: {
                            type: 'image'
                        },
                        multiple: false
                    });

                    mediaUploader.on('select', function () {
                        var attachment = mediaUploader.state().get('selection').first().toJSON();

                        // Set the attachment ID
                        $('#vrstore_course_signature_image').val(attachment.id);

                        // Show preview
                        var previewHtml = '<img src="' + attachment.url + '" style="max-width: 200px; max-height: 100px; border: 1px solid #ddd; padding: 5px;" />';
                        $('#vrstore_signature_preview').html(previewHtml);

                        // Show remove button
                        $('#vrstore_remove_signature').show();
                    });

                    mediaUploader.open();
                });

                // Remove signature button
                $(document).on('click', '#vrstore_remove_signature', function (e) {
                    e.preventDefault();

                    if (confirm('Are you sure you want to remove the signature?')) {
                        $('#vrstore_course_signature_image').val('');
                        $('#vrstore_signature_preview').empty();
                        $(this).hide();
                    }
                });
            },

            /**
             * Initialize certification toggle functionality
             */
            initCertificationToggle: function () {
                // Show/hide signature field based on certification checkbox
                $(document).on('change', '#vrstore_course_certification', function () {
                    var $signatureRow = $('#vrstore_signature_row');

                    if ($(this).is(':checked')) {
                        $signatureRow.show();
                    } else {
                        $signatureRow.hide();
                    }
                });

                // Initialize on page load
                var $certificationCheckbox = $('#vrstore_course_certification');
                var $signatureRow = $('#vrstore_signature_row');

                if ($certificationCheckbox.length && $signatureRow.length) {
                    if ($certificationCheckbox.is(':checked')) {
                        $signatureRow.show();
                    } else {
                        $signatureRow.hide();
                    }
                }
            },

            /**
             * Initialize course pricing functionality
             */
            initCoursePricing: function () {
                var self = this;

                // Function to toggle visibility based on selected pricing type
                function togglePricingFields() {
                    var selectedType = $('input[name="vrstore_course_pricing_type"]:checked').val();

                    if (selectedType === 'free') {
                        $('#course-pricing-fields').hide();
                        $('#product-selection-fields').hide();
                    } else if (selectedType === 'paid') {
                        $('#course-pricing-fields').show();
                        $('#product-selection-fields').hide();
                    } else if (selectedType === 'product') {
                        $('#course-pricing-fields').hide();
                        $('#product-selection-fields').show();
                    }
                }

                // Handle pricing type changes
                $(document).on('change', 'input[name="vrstore_course_pricing_type"]', function () {
                    togglePricingFields();
                });

                // Initialize on page load
                setTimeout(function () {
                    togglePricingFields();
                }, 100);
            }
        };

        // Initialize course admin functionality
        vrstoreCourseAdmin.init();

        // Make admin object globally accessible
        window.vrstoreCourseAdmin = vrstoreCourseAdmin;

        // Update course stats when curriculum changes
        $(document).on('vrstore:module:added vrstore:lesson:added', function () {
            vrstoreCourseAdmin.updateCourseStats();
        });

        // Handle curriculum export (if export button exists)
        $(document).on('click', '#export-curriculum', function (e) {
            e.preventDefault();
            var curriculumJson = vrstoreCourseAdmin.exportCurriculum();

            // Create download link
            var blob = new Blob([curriculumJson], { type: 'application/json' });
            var url = URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url;
            a.download = 'course-curriculum.json';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        });

        // Handle curriculum import (if import button exists)
        $(document).on('change', '#import-curriculum', function () {
            var file = this.files[0];
            if (file) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    vrstoreCourseAdmin.importCurriculum(e.target.result);
                };
                reader.readAsText(file);
            }
        });

        // Initialize stats on page load
        vrstoreCourseAdmin.updateCourseStats();
    });

})(jQuery);

// Additional standalone functions that don't require jQuery
(function () {
    'use strict';

    /**
     * Course preview functionality
     */
    function initCoursePreview() {
        var previewButton = document.querySelector('#preview-course');
        if (!previewButton) return;

        previewButton.addEventListener('click', function (e) {
            e.preventDefault();

            // Get course data from form
            var courseData = {
                title: document.querySelector('#title').value,
                content: document.querySelector('#content').value,
                // Add more fields as needed
            };

            // Open preview in new window
            var previewWindow = window.open('', '_blank', 'width=1200,height=800');
            previewWindow.document.write('<h1>Course Preview</h1><p>Loading...</p>');

            // You could make an AJAX request to generate preview HTML
            console.log('Course preview data:', courseData);
        });
    }

    /**
     * Bulk actions for course management
     */
    function initBulkActions() {
        var bulkSelect = document.querySelector('#bulk-action-selector-top');
        var applyButton = document.querySelector('#doaction');

        if (!bulkSelect || !applyButton) return;

        applyButton.addEventListener('click', function (e) {
            var action = bulkSelect.value;
            var checkedBoxes = document.querySelectorAll('input[name="post[]"]:checked');

            if (action === 'duplicate' && checkedBoxes.length > 0) {
                if (!confirm('Are you sure you want to duplicate ' + checkedBoxes.length + ' course(s)?')) {
                    e.preventDefault();
                }
            }
        });
    }

    /**
     * Course analytics tracking
     */
    function initCourseAnalytics() {
        // Track admin actions for analytics
        document.addEventListener('click', function (e) {
            var target = e.target;

            if (target.classList.contains('vrstore-add-module')) {
                trackCourseEvent('admin_module_added');
            } else if (target.classList.contains('vrstore-add-lesson')) {
                trackCourseEvent('admin_lesson_added');
            } else if (target.classList.contains('vrstore-duplicate-course')) {
                trackCourseEvent('admin_course_duplicated');
            }
        });
    }

    /**
     * Track course admin events
     */
    function trackCourseEvent(eventName, data) {
        data = data || {};
        data.timestamp = Date.now();
        data.page = 'course_admin';

        // Send to analytics service
        if (typeof gtag !== 'undefined') {
            gtag('event', eventName, data);
        }

        // Trigger custom event
        document.dispatchEvent(new CustomEvent('vrstore:course:admin:track', {
            detail: { event: eventName, data: data }
        }));
    }

    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () {
            initCoursePreview();
            initBulkActions();
            initCourseAnalytics();
        });
    } else {
        initCoursePreview();
        initBulkActions();
        initCourseAnalytics();
    }

})();