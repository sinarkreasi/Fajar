<?php
/**
 * Single Lesson Template
 *
 * @package Vira_Store
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Get lesson parameters from URL
$lesson_id = get_query_var('lesson_id');
$course_id = get_query_var('course_id') ?: get_the_ID();
$module_index = (int) get_query_var('module_index', 0);
$lesson_index = (int) get_query_var('lesson_index', 0);

// Get course data
$course_data = [];
if (class_exists('VRSTORE_Course')) {
    $course_instance = VRSTORE_Course::get_instance();
    $course_data = $course_instance->get_course_data($course_id);
}

// Get curriculum for navigation
$curriculum = get_post_meta($course_id, '_vrstore_course_curriculum', true) ?: [];

// Find current lesson data
$lesson_data = null;
$prev_lesson = null;
$next_lesson = null;

if (!empty($curriculum) && isset($curriculum[$module_index]['lessons'][$lesson_index])) {
    $lesson_data = $curriculum[$module_index]['lessons'][$lesson_index];
    
    // Add computed fields
    $lesson_data['id'] = $course_id . '_' . $module_index . '_' . $lesson_index;
    $lesson_data['course_id'] = $course_id;
    $lesson_data['module_index'] = $module_index;
    $lesson_data['lesson_index'] = $lesson_index;
    $lesson_data['module_title'] = $curriculum[$module_index]['title'] ?? 'Module ' . ($module_index + 1);
    
    // Check if lesson is completed
    $user_id = get_current_user_id();
    $completed_lessons = get_user_meta($user_id, '_vrstore_completed_lessons_' . $course_id, true);
    if (!is_array($completed_lessons)) {
        $completed_lessons = [];
    }
    $lesson_id = $module_index . '_' . $lesson_index;
    $lesson_data['is_completed'] = in_array($lesson_id, $completed_lessons);
    $lesson_data['is_accessible'] = true; // TODO: Implement access control
    
    // Find previous/next lessons
    $all_lessons = [];
    foreach ($curriculum as $mod_idx => $module) {
        if (!empty($module['lessons'])) {
            foreach ($module['lessons'] as $les_idx => $lesson) {
                $all_lessons[] = [
                    'module_index' => $mod_idx,
                    'lesson_index' => $les_idx,
                    'lesson' => $lesson
                ];
            }
        }
    }
    
    $current_position = -1;
    foreach ($all_lessons as $pos => $item) {
        if ($item['module_index'] == $module_index && $item['lesson_index'] == $lesson_index) {
            $current_position = $pos;
            break;
        }
    }
    
    if ($current_position > 0) {
        $prev_lesson = $all_lessons[$current_position - 1];
    }
    if ($current_position >= 0 && $current_position < count($all_lessons) - 1) {
        $next_lesson = $all_lessons[$current_position + 1];
    }
}

if (!$lesson_data) {
    wp_die('Lesson not found.', 'Lesson Not Found', ['response' => 404]);
}

// Calculate total lessons and progress
$total_lessons = 0;
$completed_lessons_count = 0;
$user_id = get_current_user_id();
$completed_lessons = get_user_meta($user_id, '_vrstore_completed_lessons_' . $course_id, true);
if (!is_array($completed_lessons)) {
    $completed_lessons = [];
}

foreach ($curriculum as $module) {
    if (!empty($module['lessons'])) {
        $total_lessons += count($module['lessons']);
    }
}
$completed_lessons_count = count($completed_lessons);
$progress_percentage = $total_lessons > 0 ? round(($completed_lessons_count / $total_lessons) * 100) : 0;

?>

<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo esc_html($lesson_data['title'] . ' - ' . ($course_data['title'] ?? get_the_title($course_id))); ?></title>
    <?php 
    // Enqueue dashicons for frontend (needed for lesson icons)
    wp_enqueue_style('dashicons');
    
    // Enqueue lesson-specific assets
    wp_enqueue_style(
        'vrstore-lesson-frontend',
        plugin_dir_url(__FILE__) . '../../assets/css/lesson.css',
        ['dashicons'],
        '1.0.0'
    );
    
    wp_enqueue_script(
        'vrstore-lesson-frontend',
        plugin_dir_url(__FILE__) . '../../assets/js/lesson.js',
        ['jquery'],
        '1.0.0',
        true
    );
    
    // Localize lesson data for JavaScript
    wp_localize_script(
        'vrstore-lesson-frontend',
        'vrstoreLessonData',
        [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('vrstore_lesson_nonce'),
            'courseId' => $course_id,
            'moduleIndex' => $module_index,
            'lessonIndex' => $lesson_index,
            'trackingEnabled' => true
        ]
    );
    
    wp_head(); 
    ?>
</head>
<body>
    <div class="vrstore-lesson-container">
        <!-- Floating Lesson List Sidebar -->
        <div class="lesson-sidebar" id="lessonSidebar">
            <!-- Course Header -->
            <div class="sidebar-course-header">
                <h3 class="sidebar-course-title">
                    <a href="<?php echo esc_url(get_permalink($course_id)); ?>" style="color: inherit; text-decoration: none;">
                        <?php echo esc_html($course_data['title'] ?? get_the_title($course_id)); ?>
                    </a>
                </h3>
                <div class="sidebar-course-progress">
                    <?php echo esc_html(sprintf('%d%% Complete • %d of %d lessons', $progress_percentage, $completed_lessons_count, $total_lessons)); ?>
                </div>
                <div class="progress-bar-mini">
                    <div class="progress-fill-mini" style="width: <?php echo esc_attr($progress_percentage); ?>%"></div>
                </div>
            </div>
            
            <!-- Lesson List -->
            <div class="lesson-list">
                <?php foreach ($curriculum as $mod_idx => $module): ?>
                    <div class="module-section">
                        <div class="module-header">
                            <span><?php echo esc_html($module['title'] ?? 'Module ' . ($mod_idx + 1)); ?></span>
                            <span><?php echo esc_html(count($module['lessons'] ?? [])); ?> lessons</span>
                        </div>
                        
                        <?php if (!empty($module['lessons'])): ?>
                            <div class="module-lessons">
                                <?php foreach ($module['lessons'] as $les_idx => $lesson): ?>
                                    <?php 
                                    $lesson_id_check = $mod_idx . '_' . $les_idx;
                                    $is_lesson_completed = in_array($lesson_id_check, $completed_lessons);
                                    $current_class = ($mod_idx == $module_index && $les_idx == $lesson_index) ? 'current' : '';
                                    $completed_class = $is_lesson_completed ? 'completed' : '';
                                    ?>
                                    <div class="lesson-item <?php echo esc_attr($current_class . ' ' . $completed_class); ?>" 
                                         data-module="<?php echo esc_attr($mod_idx); ?>" 
                                         data-lesson="<?php echo esc_attr($les_idx); ?>">
                                        <i class="lesson-icon dashicons dashicons-<?php 
                                            $lesson_type = $lesson['type'] ?? 'video_upload';
                                            if (in_array($lesson_type, ['video_upload', 'video_url'])) {
                                                echo 'video-alt3';
                                            } elseif ($lesson_type === 'shortcode') {
                                                echo 'shortcode';
                                            } elseif ($lesson_type === 'quiz') {
                                                echo 'forms';
                                            } else {
                                                echo 'text-page';
                                            }
                                        ?>"></i>
                                        <span class="lesson-title"><?php echo esc_html($lesson['title'] ?? 'Lesson ' . ($les_idx + 1)); ?></span>
                                        <?php if (!empty($lesson['duration'])): ?>
                                            <span class="lesson-duration"><?php echo esc_html($lesson['duration']); ?>min</span>
                                        <?php endif; ?>
                                        <i class="completion-check dashicons dashicons-yes-alt"></i>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="lesson-main">
            <!-- Video Section -->
            <div class="lesson-video-section">
                <div class="video-container" style="position: relative; width: 100%; padding-bottom: 56.25%; height: 0; background: #000; overflow: hidden;">
                    <?php 
                    $lesson_type = $lesson_data['type'] ?? 'video_upload';
                    $video_url = $lesson_data['video_url'] ?? '';
                    $video_file = $lesson_data['video_file'] ?? '';
                    $shortcode_content = $lesson_data['shortcode_content'] ?? '';
                    $video_file_url = $video_file ? wp_get_attachment_url($video_file) : '';
                    
                    if ($lesson_type === 'shortcode' && !empty($shortcode_content)):
                        // Handle shortcode content
                    ?>
                        <div class="shortcode-content" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: #f5f5f5; overflow: auto; padding: 20px; box-sizing: border-box;">
                            <div style="max-width: 100%; height: 100%; display: flex; align-items: center; justify-content: center;">
                                <div style="width: 100%; max-height: 100%; overflow: auto;">
                                    <?php echo do_shortcode($shortcode_content); ?>
                                </div>
                            </div>
                        </div>
                    <?php
                    elseif (!empty($video_url)):
                        // Handle YouTube videos
                        if (preg_match('/(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]+)/', $video_url, $matches)):
                            $video_id = $matches[1];
                    ?>
                            <iframe 
                                src="https://www.youtube.com/embed/<?php echo esc_attr($video_id); ?>?rel=0&showinfo=0&modestbranding=1&autoplay=0&controls=1&disablekb=1&fs=0&iv_load_policy=3&cc_load_policy=0&playsinline=1" 
                                frameborder="0" 
                                allowfullscreen
                                title="<?php echo esc_attr($lesson_data['title']); ?>"
                                style="width: 100%; height: 100%; position: absolute; top: 0; left: 0;"
                                oncontextmenu="return false;"
                                ondragstart="return false;"
                                onselectstart="return false;"
                            ></iframe>
                    <?php
                        // Handle Vimeo videos
                        elseif (preg_match('/vimeo\.com\/([0-9]+)/', $video_url, $matches)):
                            $video_id = $matches[1];
                    ?>
                            <iframe 
                                src="https://player.vimeo.com/video/<?php echo esc_attr($video_id); ?>?title=0&byline=0&portrait=0&badge=0&autopause=0&player_id=0&app_id=58479" 
                                frameborder="0" 
                                allowfullscreen
                                title="<?php echo esc_attr($lesson_data['title']); ?>"
                                style="width: 100%; height: 100%; position: absolute; top: 0; left: 0;"
                                oncontextmenu="return false;"
                                ondragstart="return false;"
                                onselectstart="return false;"
                            ></iframe>
                    <?php
                        // Handle direct video URLs
                        else:
                            // Detect video type from URL extension
                            $video_type = 'video/mp4'; // default
                            $extension = strtolower(pathinfo($video_url, PATHINFO_EXTENSION));
                            switch ($extension) {
                                case 'webm':
                                    $video_type = 'video/webm';
                                    break;
                                case 'ogg':
                                case 'ogv':
                                    $video_type = 'video/ogg';
                                    break;
                                case 'avi':
                                    $video_type = 'video/x-msvideo';
                                    break;
                                case 'mov':
                                    $video_type = 'video/quicktime';
                                    break;
                            }
                    ?>
                            <video 
                                controls 
                                preload="metadata" 
                                style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: contain; background: #000;"
                                oncontextmenu="return false;"
                                ondragstart="return false;"
                                onselectstart="return false;"
                                controlslist="nodownload nofullscreen noremoteplayback"
                                disablepictureinpicture>
                                <source src="<?php echo esc_url($video_url); ?>" type="<?php echo esc_attr($video_type); ?>">
                                Your browser does not support the video tag.
                            </video>
                    <?php
                        endif;
                    elseif (!empty($video_file_url)):
                        // Get proper MIME type for uploaded file
                        $mime_type = get_post_mime_type($video_file);
                        if (!$mime_type || strpos($mime_type, 'video/') !== 0) {
                            // Fallback - detect from file extension
                            $extension = strtolower(pathinfo($video_file_url, PATHINFO_EXTENSION));
                            switch ($extension) {
                                case 'mp4':
                                    $mime_type = 'video/mp4';
                                    break;
                                case 'webm':
                                    $mime_type = 'video/webm';
                                    break;
                                case 'ogg':
                                case 'ogv':
                                    $mime_type = 'video/ogg';
                                    break;
                                case 'avi':
                                    $mime_type = 'video/x-msvideo';
                                    break;
                                case 'mov':
                                    $mime_type = 'video/quicktime';
                                    break;
                                default:
                                    $mime_type = 'video/mp4';
                            }
                        }
                        
                    ?>
                        <video 
                            controls 
                            preload="metadata" 
                            width="100%" 
                            height="100%"
                            style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: contain; background: #000;"
                            oncontextmenu="return false;"
                            ondragstart="return false;"
                            onselectstart="return false;"
                            controlslist="nodownload nofullscreen noremoteplayback"
                            disablepictureinpicture>
                            
                            <source src="<?php echo esc_url($video_file_url); ?>" type="<?php echo esc_attr($mime_type); ?>">
                            
                            <?php if ($mime_type !== 'video/mp4'): ?>
                                <source src="<?php echo esc_url($video_file_url); ?>" type="video/mp4">
                            <?php endif; ?>
                            
                            <p style="color: #fff; text-align: center; padding: 20px;">
                                Your browser does not support the video tag.<br>
                                <a href="<?php echo esc_url($video_file_url); ?>" download style="color: #fff; text-decoration: underline;">
                                    Download video file
                                </a>
                            </p>
                        </video>
                    <?php else: ?>
                        <div class="content-placeholder" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: #f5f5f5; display: flex; align-items: center; justify-content: center;">
                            <div style="text-align: center; color: #999;">
                                <?php if ($lesson_type === 'shortcode'): ?>
                                    <i class="dashicons dashicons-shortcode" style="font-size: 48px; margin-bottom: 15px; display: block;"></i>
                                    <p style="margin: 0; font-size: 16px;">No shortcode content available for this lesson</p>
                                <?php else: ?>
                                    <i class="dashicons dashicons-video-alt3" style="font-size: 48px; margin-bottom: 15px; display: block;"></i>
                                    <p style="margin: 0; font-size: 16px;">No video available for this lesson</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Lesson Content -->
            <div class="lesson-content-section">
                <!-- Lesson Header -->
                <div class="lesson-header">
                    <div class="lesson-breadcrumb">
                        <a href="<?php echo esc_url(get_permalink($course_id)); ?>" class="breadcrumb-link">
                            <?php echo esc_html($course_data['title'] ?? get_the_title($course_id)); ?>
                        </a>
                        <span class="breadcrumb-separator">›</span>
                        <span class="breadcrumb-link"><?php echo esc_html($lesson_data['module_title']); ?></span>
                        <span class="breadcrumb-separator">›</span>
                        <span><?php echo esc_html($lesson_data['title']); ?></span>
                    </div>
                    
                    <h1 class="lesson-title-main"><?php echo esc_html($lesson_data['title']); ?></h1>
                    
                    <div class="lesson-meta">
                        <?php if (!empty($lesson_data['duration'])): ?>
                            <div class="lesson-meta-item">
                                <i class="dashicons dashicons-clock"></i>
                                <span><?php echo esc_html($lesson_data['duration']); ?> minutes</span>
                            </div>
                        <?php endif; ?>
                        
                        <div class="lesson-meta-item">
                            <i class="dashicons dashicons-<?php 
                                $lesson_type = $lesson_data['type'] ?? 'video_upload';
                                if (in_array($lesson_type, ['video_upload', 'video_url'])) {
                                    echo 'video-alt3';
                                } elseif ($lesson_type === 'shortcode') {
                                    echo 'shortcode';
                                } elseif ($lesson_type === 'quiz') {
                                    echo 'forms';
                                } else {
                                    echo 'text-page';
                                }
                            ?>"></i>
                            <span><?php 
                                $lesson_type = $lesson_data['type'] ?? 'video_upload';
                                $lesson_type_display = ucfirst(str_replace('_', ' ', $lesson_type));
                                echo esc_html($lesson_type_display);
                            ?> Lesson</span>
                        </div>
                        
                        <?php if (!empty($lesson_data['is_free_preview'])): ?>
                            <div class="lesson-meta-item">
                                <i class="dashicons dashicons-unlock"></i>
                                <span style="color: #4caf50; font-weight: 600;">Free Preview</span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Lesson Tabs -->
                <div class="lesson-tabs">
                    <button class="lesson-tab active" data-tab="description">Description</button>
                    <button class="lesson-tab" data-tab="materials">Materials</button>
                </div>
                
                <!-- Tab Content -->
                <div class="lesson-tab-content active" id="description">
                    <div class="lesson-description">
                        <?php if (!empty($lesson_data['description'])): ?>
                            <?php echo wp_kses_post(wpautop($lesson_data['description'])); ?>
                        <?php else: ?>
                            <p>No description available for this lesson.</p>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="lesson-tab-content" id="materials">
                    <?php 
                    $has_materials = false;
                    $material_url = $lesson_data['material_url'] ?? '';
                    $material_file = $lesson_data['material_file'] ?? '';
                    $material_file_url = $material_file ? wp_get_attachment_url($material_file) : '';
                    ?>
                    
                    <div class="materials-section">
                        <?php if (!empty($material_url) || !empty($material_file_url)): ?>
                            <ul class="materials-list">
                                <?php if (!empty($material_url)): 
                                    $has_materials = true;
                                ?>
                                    <li class="material-item">
                                        <i class="material-icon dashicons dashicons-admin-links"></i>
                                        <div class="material-info">
                                            <div class="material-name">External Resource</div>
                                            <div class="material-size">External Link</div>
                                        </div>
                                        <a href="<?php echo esc_url($material_url); ?>" target="_blank" class="material-download">
                                            <i class="dashicons dashicons-external"></i>
                                            Visit Link
                                        </a>
                                    </li>
                                <?php endif; ?>
                                
                                <?php if (!empty($material_file_url)): 
                                    $has_materials = true;
                                    $file_name = get_the_title($material_file);
                                    $file_path = get_attached_file($material_file);
                                    $file_size = $file_path ? size_format(filesize($file_path)) : 'Unknown size';
                                    $file_ext = pathinfo($material_file_url, PATHINFO_EXTENSION);
                                    
                                    // Generate secure download URL using file protection system
                                    $secure_download_url = '#';
                                    $download_error = '';
                                    
                                    if (class_exists('VRSTORE_File_Protection') && $material_file) {
                                        try {
                                            $file_protection = VRSTORE_File_Protection::get_instance();
                                            $current_user_id = get_current_user_id();
                                            
                                            // Create a temporary "course material" product structure for secure downloads
                                            $material_data = [
                                                'id' => 'course_material_' . $course_id . '_' . $module_index . '_' . $lesson_index,
                                                'type' => 'upload',
                                                'name' => $file_name,
                                                'file' => $material_file,
                                                'url' => $material_file_url
                                            ];
                                            
                                            // Generate secure download token (expires in 1 hour)
                                            $expires = time() + HOUR_IN_SECONDS;
                                            $secure_token = $file_protection->generate_download_token(
                                                $course_id, // Use course ID as "product ID"
                                                0, // File index (always 0 for single material)
                                                $current_user_id,
                                                $expires
                                            );
                                            
                                            $secure_download_url = add_query_arg([
                                                'vrstore_course_material_download' => $secure_token,
                                                'course_id' => $course_id,
                                                'material_file' => $material_file
                                            ], home_url());
                                            
                                        } catch (Exception $e) {
                                            $download_error = 'Secure download temporarily unavailable';
                                            // Fallback to direct download with warning
                                            $secure_download_url = $material_file_url;
                                        }
                                    } else {
                                        // Fallback to direct download if file protection not available
                                        $secure_download_url = $material_file_url;
                                    }
                                ?>
                                    <li class="material-item">
                                        <i class="material-icon dashicons dashicons-media-document"></i>
                                        <div class="material-info">
                                            <div class="material-name"><?php echo esc_html($file_name); ?></div>
                                            <div class="material-size">
                                                <?php echo esc_html(strtoupper($file_ext) . ' • ' . $file_size); ?>
                                                <?php if ($download_error): ?>
                                                    <span style="color: #ff9800; font-size: 11px; display: block;">
                                                        <i class="dashicons dashicons-warning" style="font-size: 11px;"></i>
                                                        <?php echo esc_html($download_error); ?>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <a href="<?php echo esc_url($secure_download_url); ?>" class="material-download vrstore-secure-material-download" data-material-id="<?php echo esc_attr($material_file); ?>" data-course-id="<?php echo esc_attr($course_id); ?>">
                                            <i class="dashicons dashicons-download"></i>
                                            <?php echo class_exists('VRSTORE_File_Protection') ? __('Secure Download', 'vira-store') : __('Download', 'vira-store'); ?>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        <?php else: ?>
                            <p>No materials available for this lesson.</p>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Lesson Navigation -->
                <div class="lesson-navigation">
                    <div>
                        <?php if ($prev_lesson): ?>
                            <a href="?course_id=<?php echo esc_attr($course_id); ?>&module_index=<?php echo esc_attr($prev_lesson['module_index']); ?>&lesson_index=<?php echo esc_attr($prev_lesson['lesson_index']); ?>" class="nav-button">
                                <i class="dashicons dashicons-arrow-left-alt2"></i>
                                Previous Lesson
                            </a>
                        <?php endif; ?>
                    </div>
                    
                    <div>
                        <?php if (!$lesson_data['is_completed']): ?>
                            <button class="complete-button" onclick="markLessonComplete()">
                                Mark as Complete
                            </button>
                        <?php else: ?>
                            <span style="color: #4caf50; font-weight: 600;">
                                <i class="dashicons dashicons-yes-alt"></i>
                                Completed
                            </span>
                        <?php endif; ?>
                    </div>
                    
                    <div>
                        <?php if ($next_lesson): ?>
                            <a href="?course_id=<?php echo esc_attr($course_id); ?>&module_index=<?php echo esc_attr($next_lesson['module_index']); ?>&lesson_index=<?php echo esc_attr($next_lesson['lesson_index']); ?>" class="nav-button">
                                Next Lesson
                                <i class="dashicons dashicons-arrow-right-alt2"></i>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Pass lesson data to JavaScript (used by lesson.js)
        window.vrstoreLessonData = {
            courseId: <?php echo json_encode($course_id); ?>,
            moduleIndex: <?php echo json_encode($module_index); ?>,
            lessonIndex: <?php echo json_encode($lesson_index); ?>,
            lessonId: <?php echo json_encode($course_id . '_' . $module_index . '_' . $lesson_index); ?>,
            lessonType: <?php echo json_encode($lesson_type); ?>,
            ajaxUrl: <?php echo json_encode(admin_url('admin-ajax.php')); ?>,
            nonce: <?php echo json_encode(wp_create_nonce('vrstore_lesson_nonce')); ?>,
            trackingEnabled: true,
            videoUrl: <?php echo json_encode($video_url ?: $video_file_url); ?>
        };
    </script>

    <?php wp_footer(); ?>
</body>
</html>
