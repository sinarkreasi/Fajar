<?php
/**
 * Courses Listing Template
 *
 * @package Vira_Store
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Get courses query
global $wp_query;
$courses = $wp_query;

// Helper function for price formatting
if (!function_exists('vrstore_format_course_price')) {
    function vrstore_format_course_price($price, $currency = 'USD') {
        if (function_exists('vrstore_format_price')) {
            return vrstore_format_price($price);
        }
        $symbols = ['USD' => '$', 'EUR' => '€', 'GBP' => '£'];
        $symbol = $symbols[$currency] ?? $currency;
        return $symbol . number_format((float) $price, 2);
    }
}

?>

<div class="vrstore-courses-listing">
    <!-- Filters and Search -->
    <div class="courses-filters">
        <div class="filters-row">
            <!-- Search Form -->
            <div class="course-search">
                <form role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>">
                    <input type="hidden" name="post_type" value="vrstore_course" />
                    <input 
                        type="search" 
                        name="s" 
                        value="<?php echo esc_attr(get_search_query()); ?>" 
                        placeholder="<?php esc_attr_e('Search courses...', 'vira-store'); ?>"
                        class="search-input"
                    />
                    <button type="submit" class="search-button">
                        <i class="dashicons dashicons-search"></i>
                        <span class="screen-reader-text"><?php esc_html_e('Search', 'vira-store'); ?></span>
                    </button>
                </form>
            </div>

            <!-- Category Filter -->
            <div class="category-filter">
                <?php
                $categories = get_terms([
                    'taxonomy' => 'vrstore_course_cat',
                    'hide_empty' => true,
                    'orderby' => 'name',
                    'order' => 'ASC',
                ]);
                
                if (!empty($categories) && !is_wp_error($categories)): ?>
                    <select onchange="location = this.value;">
                        <option value="<?php echo esc_url(get_post_type_archive_link('vrstore_course')); ?>">
                            <?php esc_html_e('All Categories', 'vira-store'); ?>
                        </option>
                        <?php foreach ($categories as $category): ?>
                            <option 
                                value="<?php echo esc_url(get_term_link($category)); ?>"
                                <?php selected(is_tax('vrstore_course_cat', $category->term_id)); ?>
                            >
                                <?php echo esc_html($category->name); ?> (<?php echo esc_html($category->count); ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                <?php endif; ?>
            </div>

            <!-- Results Count -->
            <div class="results-count">
                <?php
                $total = $courses->found_posts;
                $paged = max(1, get_query_var('paged'));
                $per_page = get_query_var('posts_per_page');
                $start = (($paged - 1) * $per_page) + 1;
                $end = min($total, $paged * $per_page);
                
                if ($total > 0):
                    printf(
                        esc_html(_n('Showing %1$s of %2$s course', 'Showing %1$s-%3$s of %4$s courses', $total, 'vira-store')),
                        '<strong>' . esc_html($start) . '</strong>',
                        '<strong>' . esc_html($total) . '</strong>',
                        '<strong>' . esc_html($end) . '</strong>',
                        '<strong>' . esc_html($total) . '</strong>'
                    );
                endif;
                ?>
            </div>
        </div>
    </div>

    <!-- Courses Grid -->
    <div class="courses-grid">
        <?php if ($courses->have_posts()): ?>
            <?php while ($courses->have_posts()): $courses->the_post(); ?>
                <?php
                $course_id = get_the_ID();
                $duration = get_post_meta($course_id, '_vrstore_course_duration', true);
                $level = get_post_meta($course_id, '_vrstore_course_level', true);
                $language = get_post_meta($course_id, '_vrstore_course_language', true);
                $is_free = get_post_meta($course_id, '_vrstore_course_is_free', true);
                $price = get_post_meta($course_id, '_vrstore_course_price', true);
                $sale_price = get_post_meta($course_id, '_vrstore_course_sale_price', true);
                $currency = get_post_meta($course_id, '_vrstore_course_currency', true) ?: 'USD';
                // Get course data using the updated method
                if (class_exists('VRSTORE_Course')) {
                    $course_instance = VRSTORE_Course::get_instance();
                    $course_data = $course_instance->get_course_data($course_id);
                    $instructor_name = $course_data['instructor']['name'];
                    $instructor_user_id = $course_data['instructor']['user_id'] ?? 0;
                } else {
                    $instructor_name = get_the_author();
                    $instructor_user_id = get_the_author_meta('ID');
                }
                $curriculum = get_post_meta($course_id, '_vrstore_course_curriculum', true);
                
                // Calculate lessons count
                $total_lessons = 0;
                if (!empty($curriculum) && is_array($curriculum)) {
                    foreach ($curriculum as $module) {
                        if (!empty($module['lessons']) && is_array($module['lessons'])) {
                            $total_lessons += count($module['lessons']);
                        }
                    }
                }
                ?>
                
                <div class="course-card">
                    <!-- Course Image -->
                    <div class="course-image">
                        <a href="<?php the_permalink(); ?>">
                            <?php if (has_post_thumbnail()): ?>
                                <?php the_post_thumbnail('medium', ['alt' => get_the_title()]); ?>
                            <?php else: ?>
                                <div class="course-placeholder">
                                    <i class="dashicons dashicons-welcome-learn-more"></i>
                                </div>
                            <?php endif; ?>
                        </a>
                        
                        <!-- Course Level Badge -->
                        <?php if (!empty($level)): ?>
                            <span class="course-level-badge course-level-<?php echo esc_attr($level); ?>">
                                <?php echo esc_html(ucfirst($level)); ?>
                            </span>
                        <?php endif; ?>
                        
                        <!-- Free Badge -->
                        <?php if ($is_free): ?>
                            <span class="course-free-badge">
                                <?php esc_html_e('Free', 'vira-store'); ?>
                            </span>
                        <?php endif; ?>
                    </div>

                    <!-- Course Content -->
                    <div class="course-content">
                        <!-- Course Title -->
                        <h3 class="course-title">
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </h3>

                        <!-- Course Categories with Pricing -->
                        <?php
                        $categories = get_the_terms($course_id, 'vrstore_course_cat');
                        if ($categories && !is_wp_error($categories)):
                        ?>
                            <div class="course-categories-with-pricing">
                                <div class="course-categories">
                                    <?php foreach ($categories as $category): ?>
                                        <a href="<?php echo esc_url(get_term_link($category)); ?>" class="category-tag">
                                            <?php echo esc_html($category->name); ?>
                                        </a>
                                    <?php endforeach; ?>
                                </div>
                           </div>
                        <?php endif; ?>

                        <!-- Course Excerpt -->
                        <div class="course-excerpt">
                            <?php 
                            if (has_excerpt()) {
                                echo wp_trim_words(get_the_excerpt(), 15);
                            } else {
                                echo wp_trim_words(get_the_content(), 15);
                            }
                            ?>
                        </div>
                    </div>
                </div>

            <?php endwhile; ?>
            
        <?php else: ?>
            <!-- No Courses Found -->
            <div class="no-courses-found">
                <div class="no-courses-content">
                    <i class="dashicons dashicons-welcome-learn-more"></i>
                    <h3><?php esc_html_e('No courses found', 'vira-store'); ?></h3>
                    <p>
                        <?php 
                        if (is_search()) {
                            esc_html_e('Sorry, no courses matched your search criteria. Try adjusting your search terms.', 'vira-store');
                        } elseif (is_tax()) {
                            esc_html_e('No courses found in this category yet.', 'vira-store');
                        } else {
                            esc_html_e('No courses are available at the moment. Please check back later.', 'vira-store');
                        }
                        ?>
                    </p>
                    
                    <?php if (is_search() || is_tax()): ?>
                        <a href="<?php echo esc_url(get_post_type_archive_link('vrstore_course')); ?>" class="btn-browse-all">
                            <?php esc_html_e('Browse All Courses', 'vira-store'); ?>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- Pagination -->
    <?php if ($courses->max_num_pages > 1): ?>
        <div class="courses-pagination">
            <?php
            echo paginate_links([
                'base' => str_replace(999999999, '%#%', esc_url(get_pagenum_link(999999999))),
                'format' => '?paged=%#%',
                'current' => max(1, get_query_var('paged')),
                'total' => $courses->max_num_pages,
                'prev_text' => '<i class="dashicons dashicons-arrow-left-alt2"></i> ' . esc_html__('Previous', 'vira-store'),
                'next_text' => esc_html__('Next', 'vira-store') . ' <i class="dashicons dashicons-arrow-right-alt2"></i>',
                'mid_size' => 2,
                'end_size' => 1,
                'type' => 'plain',
            ]);
            ?>
        </div>
    <?php endif; ?>
</div>

<?php
// Reset global $post object
wp_reset_postdata();
?>