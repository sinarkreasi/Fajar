<?php
/**
 * Single Course Template
 *
 * @package Vira_Store
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Get course data
$course_id = get_the_ID();

// Track affiliate visit if referral code is present
if (isset($_GET['ref']) && class_exists('VRSTORE_Affiliate')) {
    $affiliate = VRSTORE_Affiliate::get_instance();
    $affiliate->track_visit($_GET['ref'], $course_id, 'course');
}

// Check course visibility
$visibility = get_post_meta($course_id, '_vrstore_course_visibility', true) ?: 'public';
$visibility_password = get_post_meta($course_id, '_vrstore_course_visibility_password', true) ?: '';

// Handle visibility restrictions
$can_view_course = true;
$visibility_message = '';

switch ($visibility) {
    case 'private':
        // Check if user is enrolled or is admin
        $user_id = get_current_user_id();
        $is_enrolled = false;
        
        if ($user_id && class_exists('VRSTORE_Course')) {
            $course_instance = VRSTORE_Course::get_instance();
            $is_enrolled = $course_instance->user_has_course_access($user_id, $course_id);
        }
        
        if (!$is_enrolled && !current_user_can('manage_options')) {
            $can_view_course = false;
            $visibility_message = __('This course is private and only available to enrolled students.', 'vira-store');
        }
        break;
        
    case 'password':
        // Check if password has been provided
        $provided_password = $_POST['course_password'] ?? $_SESSION['course_password_' . $course_id] ?? '';
        
        if ($provided_password !== $visibility_password && !current_user_can('manage_options')) {
            $can_view_course = false;
            $visibility_message = __('This course is password protected.', 'vira-store');
        } else if ($provided_password === $visibility_password) {
            // Store password in session for this course
            if (!isset($_SESSION)) {
                session_start();
            }
            $_SESSION['course_password_' . $course_id] = $provided_password;
        }
        break;
}

// If course cannot be viewed, show password form or access denied message
if (!$can_view_course) {
    ?>
    <div class="vrstore-course-access-restricted">
        <div class="vrstore-access-message">
            <h3><?php echo esc_html($visibility_message); ?></h3>
            
            <?php if ($visibility === 'password'): ?>
                <form method="post" class="vrstore-password-form">
                    <p>
                        <label for="course_password"><?php _e('Enter Password:', 'vira-store'); ?></label>
                        <input type="password" name="course_password" id="course_password" required />
                        <input type="submit" value="<?php _e('Access Course', 'vira-store'); ?>" class="button" />
                    </p>
                </form>
            <?php elseif ($visibility === 'private'): ?>
                <p><?php _e('Please enroll in this course to view its content.', 'vira-store'); ?></p>
            <?php endif; ?>
        </div>
    </div>
    <?php
    return;
}

$course_data = [];

if (class_exists('VRSTORE_Course')) {
    $course_instance = VRSTORE_Course::get_instance();
    $course_data = $course_instance->get_course_data($course_id);
}

// Get video configuration
$video_config = get_post_meta($course_id, '_vrstore_course_video_config', true);

// Ensure video_config is an array with default values
if (!is_array($video_config)) {
    $video_config = [
        'type' => 'none',
        'youtube_url' => '',
        'video_id' => '',
    ];
}

// Check if we have video to display
$has_video = ($video_config['type'] !== 'none' && 
    (($video_config['type'] === 'youtube' && !empty($video_config['youtube_url'])) ||
     ($video_config['type'] === 'upload' && !empty($video_config['video_id']))));

// Check if we should show the links section
$course_demo_url = get_post_meta($course_id, '_vrstore_course_demo_url', true);
$show_links = !empty($course_demo_url) || $has_video;

// Fallback course data if class method is not available
if (empty($course_data)) {
    $course_data = [
        'id' => $course_id,
        'title' => get_the_title($course_id),
        'content' => get_post($course_id) ? get_post($course_id)->post_content : '',
        'excerpt' => get_post_field('post_excerpt', $course_id),
        'duration' => get_post_meta($course_id, '_vrstore_course_duration', true),
        'level' => get_post_meta($course_id, '_vrstore_course_level', true),
        'language' => get_post_meta($course_id, '_vrstore_course_language', true),
        'max_students' => get_post_meta($course_id, '_vrstore_course_max_students', true),
        'prerequisites' => get_post_meta($course_id, '_vrstore_course_prerequisites', true),
        'objectives' => get_post_meta($course_id, '_vrstore_course_objectives', true),
        'demo_url' => get_post_meta($course_id, '_vrstore_course_demo_url', true),
        'certification' => get_post_meta($course_id, '_vrstore_course_certification', true),
        'curriculum' => get_post_meta($course_id, '_vrstore_course_curriculum', true),
        'instructor' => [
            'name' => get_post_meta($course_id, '_vrstore_course_instructor_name', true),
            'bio' => get_post_meta($course_id, '_vrstore_course_instructor_bio', true),
            'avatar' => get_post_meta($course_id, '_vrstore_course_instructor_avatar', true),
            'website' => get_post_meta($course_id, '_vrstore_course_instructor_website', true),
        ],
        'is_free' => get_post_meta($course_id, '_vrstore_course_is_free', true),
        'price' => get_post_meta($course_id, '_vrstore_course_price', true),
        'sale_price' => get_post_meta($course_id, '_vrstore_course_sale_price', true),
        'currency' => get_post_meta($course_id, '_vrstore_course_currency', true) ?: 'USD',
        'featured_image' => get_post_thumbnail_id($course_id),
        'thumbnail' => get_the_post_thumbnail_url($course_id, 'full'),
        'permalink' => get_permalink($course_id),
    ];
}

// Get currency converter instance for proper integration
$currency_converter = class_exists('VRSTORE_Currency_Converter') ? VRSTORE_Currency_Converter::get_instance() : null;
$user_currency = $currency_converter ? $currency_converter->get_user_currency() : 'USD';
$base_currency = $currency_converter ? $currency_converter->get_base_currency() : 'USD';

// Helper function for price formatting with currency conversion
if (!function_exists('vrstore_format_course_price')) {
    function vrstore_format_course_price($price, $currency_converter = null, $user_currency = 'USD') {
        if ($currency_converter) {
            return $currency_converter->format_price(floatval($price), '', false);
        }
        
        if (function_exists('vrstore_format_price')) {
            return vrstore_format_price($price);
        }
        
        $symbols = ['USD' => '$', 'EUR' => '€', 'GBP' => '£', 'IDR' => 'Rp'];
        $symbol = $symbols[$currency_converter ? $user_currency : 'USD'] ?? $user_currency;
        return $symbol . number_format((float) $price, 2);
    }
}

// Calculate lessons and materials from curriculum
$total_lessons = 0;
$total_materials = 0;
$formatted_duration = '';

if (!empty($course_data['curriculum']) && is_array($course_data['curriculum'])) {
    foreach ($course_data['curriculum'] as $module) {
        if (!empty($module['lessons']) && is_array($module['lessons'])) {
            $total_lessons += count($module['lessons']);
            foreach ($module['lessons'] as $lesson) {
                // Count materials (either URL or file)
                if (!empty($lesson['material_url']) || !empty($lesson['material_file'])) {
                    $total_materials++;
                }
            }
        }
    }
}

// Use duration from course details meta box
if (!empty($course_data['duration'])) {
    $formatted_duration = $course_data['duration'];
}

?>

<div class="vrstore-course-single">
    <div class="vrstore-course-content">
        <!-- Main Content -->
        <div class="course-main-content">
            <!-- Breadcrumb Navigation -->
            <div class="course-breadcrumb" style="margin-bottom: 15px;">
                <?php
                // Generate breadcrumb navigation
                $breadcrumbs = [];
                
                // Get settings
                $settings = get_option('vrstore_settings', []);
                $course_permalink_slug = !empty($settings['course_permalink_slug']) ? $settings['course_permalink_slug'] : 'courses';
                
                // Home link
                $breadcrumbs[] = '<a href="' . esc_url(home_url('/')) . '" style="color: #666; text-decoration: none; font-size: 13px;">Home</a>';
                
                // Courses link - use post type archive URL which respects custom permalink slug
                $courses_text = ucfirst($course_permalink_slug); // Capitalize first letter for display
                
                // Primary method: Use post type archive URL (this respects the custom permalink slug)
                $courses_url = get_post_type_archive_link('vrstore_course');
                
                // Fallback methods if archive URL is not available
                if (!$courses_url) {
                    // Method 1: Look for page with the custom slug
                    $courses_page = get_page_by_path($course_permalink_slug);
                    if ($courses_page) {
                        $courses_url = get_permalink($courses_page->ID);
                    } else {
                        // Method 2: Look for page with course shortcode
                        $pages_with_shortcode = get_posts([
                            'post_type' => 'page',
                            'post_status' => 'publish',
                            'posts_per_page' => 1,
                            's' => '[vrstore_courses]'
                        ]);
                        
                        if (!empty($pages_with_shortcode)) {
                            $courses_url = get_permalink($pages_with_shortcode[0]->ID);
                        }
                    }
                }
                
                if ($courses_url) {
                    $breadcrumbs[] = '<a href="' . esc_url($courses_url) . '" style="color: #666; text-decoration: none; font-size: 13px;">' . esc_html($courses_text) . '</a>';
                } else {
                    $breadcrumbs[] = '<span style="color: #666; font-size: 13px;">' . esc_html($courses_text) . '</span>';
                }
                
                // Course category
                $course_categories = wp_get_post_terms($course_id, 'vrstore_course_cat', ['number' => 1]);
                if (!empty($course_categories) && !is_wp_error($course_categories)) {
                    $main_category = $course_categories[0];
                    $breadcrumbs[] = '<a href="' . esc_url(get_term_link($main_category)) . '" style="color: #666; text-decoration: none; font-size: 13px;">' . esc_html($main_category->name) . '</a>';
                }
                
                // Current course (no link)
                $breadcrumbs[] = '<span style="color: #333; font-size: 13px; font-weight: 500;">' . esc_html($course_data['title']) . '</span>';
                
                // Output breadcrumb
                echo implode(' <span style="color: #999; font-size: 13px; margin: 0 8px;">›</span> ', $breadcrumbs);
                ?>
            </div>
            
            <?php
            // Check for access denied message
            if (isset($_GET['access_denied']) && $_GET['access_denied'] === '1'):
            ?>
                <div class="vrstore-access-denied-notice" style="background: #f8d7da; color: #721c24; padding: 12px 16px; border: 1px solid #f5c6cb; border-radius: 4px; margin-bottom: 20px; font-size: 14px;">
                    <i class="dashicons dashicons-warning" style="margin-right: 8px; vertical-align: middle;"></i>
                    <?php esc_html_e('Access denied. You need to enroll in this course to view that lesson.', 'vira-store'); ?>
                </div>
            <?php endif; ?>
            
            <div class="course-header-main">
                <h1 class="course-title"><?php echo esc_html($course_data['title']); ?></h1>
                
                <div class="course-meta">
                    <?php if (!empty($course_data['level'])): ?>
                        <span class="course-level">
                            <?php echo esc_html(ucfirst($course_data['level'])); ?>
                        </span>
                    <?php endif; ?>
                    
                    <?php 
                    // Get enrollment data - calculate actual count
                    $course_instance = VRSTORE_Course::get_instance();
                    $total_enrolled = $course_instance->sync_enrollment_count($course_id);
                    $max_students = !empty($course_data['max_students']) ? absint($course_data['max_students']) : 0;
                    
                    // Display enrollment count with limit
                    if ($max_students > 0):
                    ?>
                        <span class="course-enrollment-limit">
                            <i class="dashicons dashicons-groups"></i>
                            <?php echo esc_html(sprintf(__('Max %d/%d Users', 'vira-store'), $total_enrolled, $max_students)); ?>
                        </span>
                    <?php elseif ($total_enrolled > 0): ?>
                        <span class="course-enrolled">
                            <i class="dashicons dashicons-groups"></i>
                            <?php echo esc_html(number_format($total_enrolled) . ' ' . _n('Student', 'Students', $total_enrolled, 'vira-store')); ?>
                        </span>
                    <?php endif; ?>
                    
                    <?php 
                    // Get course categories
                    $course_categories = wp_get_post_terms($course_id, 'vrstore_course_cat', ['number' => 1]);
                    if (!empty($course_categories) && !is_wp_error($course_categories)):
                        $main_category = $course_categories[0];
                    ?>
                        <span class="course-category">
                            <i class="dashicons dashicons-category"></i>
                            <?php echo esc_html($main_category->name); ?>
                        </span>
                    <?php endif; ?>
                    
                    <!-- Last Update -->
                    <?php 
                    $last_modified = get_post_modified_time('U', false, $course_id);
                    if ($last_modified) {
                        $formatted_date = date_i18n('d/m/Y', $last_modified);
                    ?>
                        <span class="course-last-update" style="display: inline-flex; align-items: center; gap: 5px; white-space: nowrap;">
                            <i class="dashicons dashicons-calendar-alt" style="font-size: 14px;"></i>
                            <span><?php echo esc_html($formatted_date); ?></span>
                        </span>
                    <?php } ?>
                </div>
            </div>
            
            <!-- Tab Navigation -->
            <div class="course-tabs-nav" style="display: flex; border-bottom: 2px solid #eee; margin-bottom: 25px;">
                <button class="tab-button active" data-tab="overview" style="background: none; border: none; padding: 15px 20px; cursor: pointer; font-size: 16px; border-bottom: 2px solid #0073aa; color: #0073aa;"><?php esc_html_e('Overview', 'vira-store'); ?></button>
                <button class="tab-button" data-tab="curriculum" style="background: none; border: none; padding: 15px 20px; cursor: pointer; font-size: 16px; color: #666;"><?php esc_html_e('Lessons', 'vira-store'); ?></button>
                <?php if (!empty($course_data['instructor']['name'])): ?>
                    <button class="tab-button" data-tab="instructor" style="background: none; border: none; padding: 15px 20px; cursor: pointer; font-size: 16px; color: #666;"><?php esc_html_e('Instructor', 'vira-store'); ?></button>
                <?php endif; ?>
                <?php 
                // Get comment count for this course
                $comment_count = wp_count_comments($course_id);
                $approved_comments = $comment_count->approved;
                ?>
                <button class="tab-button" data-tab="reviews" style="background: none; border: none; padding: 15px 20px; cursor: pointer; font-size: 16px; color: #666;"><?php echo sprintf(esc_html__('Reviews (%d)', 'vira-store'), $approved_comments); ?></button>
                
                <?php 
                // Show Resources tab only for enrolled users
                $current_user_id = get_current_user_id();
                $user_has_access = false;
                
                if ($current_user_id > 0 && class_exists('VRSTORE_Course')) {
                    $course_instance = VRSTORE_Course::get_instance();
                    $user_has_access = $course_instance->user_has_course_access($course_id, $current_user_id);
                }
                
                if ($user_has_access): ?>
                    <button class="tab-button" data-tab="resources" style="background: none; border: none; padding: 15px 20px; cursor: pointer; font-size: 16px; color: #666;"><?php esc_html_e('Resources', 'vira-store'); ?></button>
                <?php endif; ?>
            </div>

            <!-- Tab Content -->
            <div class="course-tabs-content" style="min-height: 400px;">
                <div class="tab-content active" id="overview" style="display: block;">
                    <div class="course-description" style="margin-bottom: 30px; line-height: 1.6; color: #333;">
                        <?php echo wp_kses_post($course_data['content']); ?>
                    </div>

                    <?php if (!empty($course_data['objectives'])): ?>
                        <div class="course-objectives" style="margin-bottom: 30px;">
                            <h3 style="font-size: 1.3em; margin-bottom: 15px; color: #333;"><?php esc_html_e('What You\'ll Learn', 'vira-store'); ?></h3>
                            <div class="objectives-content" style="background: #f9f9f9; padding: 20px; border-radius: 8px; line-height: 1.6;">
                                <?php echo wp_kses_post(wpautop($course_data['objectives'])); ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($course_data['prerequisites'])): ?>
                        <div class="course-prerequisites" style="margin-bottom: 30px;">
                            <h3 style="font-size: 1.3em; margin-bottom: 15px; color: #333;"><?php esc_html_e('Prerequisites', 'vira-store'); ?></h3>
                            <div class="prerequisites-content" style="background: #fff3cd; padding: 20px; border-radius: 8px; border-left: 4px solid #ffc107; line-height: 1.6;">
                                <?php echo wp_kses_post(wpautop($course_data['prerequisites'])); ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="tab-content" id="curriculum" style="display: none;">
                    <?php if (!empty($course_data['curriculum']) && is_array($course_data['curriculum'])): ?>
                        <div class="course-curriculum">
                            <?php foreach ($course_data['curriculum'] as $module_index => $module): ?>
                                <div class="curriculum-module" style="margin-bottom: 20px; border: 1px solid #e0e0e0; border-radius: 8px; overflow: hidden;">
                                    <div class="module-header" style="background: #f8f9fa; padding: 15px; cursor: pointer; display: flex; justify-content: space-between; align-items: center;">
                                        <h3 class="module-title" style="margin: 0; font-size: 1.1em; color: #333;">
                                            <span class="module-number" style="color: #0073aa; margin-right: 8px;"><?php echo esc_html($module_index + 1); ?>.</span>
                                            <?php echo esc_html($module['title'] ?? 'Module ' . ($module_index + 1)); ?>
                                        </h3>
                                        <button class="module-toggle" type="button" style="background: none; border: none; cursor: pointer; font-size: 18px; color: #666;">
                                            <i class="dashicons dashicons-plus-alt2"></i>
                                        </button>
                                    </div>
                                    
                                    <?php if (!empty($module['lessons']) && is_array($module['lessons'])): ?>
                                        <div class="module-lessons" style="background: white;">
                                            <?php foreach ($module['lessons'] as $lesson_index => $lesson): ?>
                                                <?php
                                                $lesson_type = $lesson['type'] ?? 'video_upload';
                                                $is_free_preview = !empty($lesson['is_free_preview']) && $lesson['is_free_preview'] === '1';
                                                $has_video = !empty($lesson['video_url']) || !empty($lesson['video_file']);
                                                $has_shortcode = !empty($lesson['shortcode_content']);
                                                $has_material = !empty($lesson['material_url']) || !empty($lesson['material_file']);
                                                $icon_class = 'dashicons-video-alt3';
                                                
                                                // Set icon based on lesson type
                                                switch ($lesson_type) {
                                                    case 'video_upload':
                                                    case 'video_url':
                                                        $icon_class = 'dashicons-video-alt3';
                                                        break;
                                                    case 'shortcode':
                                                        $icon_class = 'dashicons-shortcode';
                                                        break;
                                                    case 'text':
                                                        $icon_class = 'dashicons-text-page';
                                                        break;
                                                    case 'quiz':
                                                        $icon_class = 'dashicons-forms';
                                                        break;
                                                    case 'assignment':
                                                        $icon_class = 'dashicons-clipboard';
                                                        break;
                                                    default:
                                                        $icon_class = 'dashicons-video-alt3';
                                                }
                                                ?>
                                                <div class="lesson-item" style="padding: 12px 20px; border-bottom: 1px solid #f0f0f0; display: flex; justify-content: space-between; align-items: center; position: relative;">
                                                    <div class="lesson-info" style="display: flex; align-items: center; gap: 10px; flex: 1;">
                                                        <i class="lesson-icon dashicons <?php echo esc_attr($icon_class); ?>" style="color: #666; font-size: 16px;"></i>
                                                        <div class="lesson-details" style="flex: 1;">
                                                            <div style="display: flex; align-items: center; gap: 10px;">
                                                                <span class="lesson-title" style="color: #333; font-weight: 500;"><?php echo esc_html($lesson['title'] ?? 'Lesson ' . ($lesson_index + 1)); ?></span>
                                                                <?php if ($is_free_preview): ?>
                                                                    <span class="free-preview-badge" style="background: #4CAF50; color: white; padding: 2px 8px; border-radius: 10px; font-size: 11px; font-weight: 600; text-transform: uppercase;">
                                                                        <?php esc_html_e('Free', 'vira-store'); ?>
                                                                    </span>
                                                                <?php endif; ?>
                                                            </div>
                                                            
                                                            <!-- Lesson Access Control for ALL lesson types -->
                                                            <div class="lesson-access-info" style="margin-top: 5px;">
                                                                <?php if ($is_free_preview): ?>
                                                                    <!-- Free preview - show appropriate button based on lesson type -->
                                                                    <?php if (in_array($lesson_type, ['video_upload', 'video_url']) && $has_video): ?>
                                                                        <button type="button" class="play-lesson-video" 
                                                                                data-video-url="<?php echo esc_attr($lesson['video_url'] ?? ''); ?>"
                                                                                data-video-file="<?php echo esc_attr($lesson['video_file'] ?? ''); ?>"
                                                                                data-lesson-title="<?php echo esc_attr($lesson['title']); ?>"
                                                                                style="background: none; border: none; color: #0073aa; font-size: 12px; cursor: pointer; padding: 0; text-decoration: underline; margin-right: 10px;">
                                                                            <i class="dashicons dashicons-controls-play" style="font-size: 12px; margin-right: 3px;"></i>
                                                                            <?php esc_html_e('Play Preview', 'vira-store'); ?>
                                                                        </button>
                                                                    <?php elseif ($lesson_type === 'shortcode' && $has_shortcode): ?>
                                                                        <button type="button" class="lesson-preview-modal" 
                                                                                data-lesson-title="<?php echo esc_attr($lesson['title']); ?>"
                                                                                data-lesson-description="<?php echo esc_attr(wp_strip_all_tags($lesson['description'] ?? '')); ?>"
                                                                                data-lesson-type="<?php echo esc_attr($lesson_type); ?>"
                                                                                data-lesson-shortcode="<?php echo esc_attr($lesson['shortcode_content'] ?? ''); ?>"
                                                                                style="background: none; border: none; color: #9c27b0; font-size: 12px; cursor: pointer; padding: 0; text-decoration: underline; display: inline-flex; align-items: center; gap: 3px;"
                                                                                title="<?php esc_attr_e('Preview Shortcode Content', 'vira-store'); ?>">
                                                                            <i class="dashicons dashicons-shortcode" style="font-size: 12px;"></i>
                                                                            <?php esc_html_e('Preview Shortcode', 'vira-store'); ?>
                                                                        </button>
                                                                    <?php else: ?>
                                                        <!-- For other free preview lessons, show general preview modal button -->
                                                        <button type="button" class="lesson-preview-modal" 
                                                                data-lesson-title="<?php echo esc_attr($lesson['title']); ?>"
                                                                data-lesson-description="<?php echo esc_attr(wp_strip_all_tags($lesson['description'] ?? '')); ?>"
                                                                data-lesson-type="<?php echo esc_attr($lesson_type); ?>"
                                                                data-lesson-video-url="<?php echo esc_attr($lesson['video_url'] ?? ''); ?>"
                                                                data-lesson-video-file="<?php echo esc_attr($lesson['video_file'] ?? ''); ?>"
                                                                data-lesson-shortcode="<?php echo esc_attr($lesson['shortcode_content'] ?? ''); ?>"
                                                                style="background: none; border: none; color: #28a745; font-size: 12px; cursor: pointer; padding: 0; text-decoration: underline; display: inline-flex; align-items: center; gap: 3px;"
                                                                title="<?php esc_attr_e('Preview Lesson Content', 'vira-store'); ?>">
                                                            <i class="dashicons dashicons-visibility" style="font-size: 12px;"></i>
                                                            <?php esc_html_e('Preview Content', 'vira-store'); ?>
                                                        </button>
                                                    <?php endif; ?>
                                                                <?php else: ?>
                                                    <?php 
                                                    // Check if user has access to this course using proper verification
                                                    $user_id = get_current_user_id();
                                                    $has_access = false;
                                                    
                                                    if ($user_id > 0) {
                                                        // Use the proper access checking function
                                                        if (class_exists('VRSTORE_Course')) {
                                                            $course_instance = VRSTORE_Course::get_instance();
                                                            $has_access = $course_instance->user_has_course_access($course_id, $user_id);
                                                        }
                                                    }
                                                    ?>
                                                                    
                                                                    <?php if ($has_access): ?>
                                                                        <?php 
                                                                        // Generate lesson URL
                                                                        $lesson_url = add_query_arg([
                                                                            'course_id' => $course_id,
                                                                            'module_index' => $module_index,
                                                                            'lesson_index' => $lesson_index
                                                                        ], home_url('/lesson/'));
                                                                        ?>
                                                                        <a href="<?php echo esc_url($lesson_url); ?>" 
                                                                           class="lesson-access-link"
                                                                           style="color: #0073aa; font-size: 12px; text-decoration: none; display: inline-flex; align-items: center; gap: 3px;"
                                                                           title="<?php echo esc_attr('Course ID: ' . $course_id . ', Module: ' . $module_index . ', Lesson: ' . $lesson_index); ?>">
                                                                            <i class="dashicons dashicons-arrow-right-alt2" style="font-size: 12px;"></i>
                                                                            <?php esc_html_e('Access Lesson', 'vira-store'); ?>
                                                                        </a>
                                                                    <?php else: ?>
                                                                        <span class="lesson-access-locked" style="color: #666; font-size: 12px; display: inline-flex; align-items: center; gap: 3px;">
                                                                            <i class="dashicons dashicons-lock" style="font-size: 12px;"></i>
                                                                            <?php esc_html_e('Premium Content', 'vira-store'); ?>
                                                                        </span>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            </div>
                                                            
                                                            <?php if ($has_material): ?>
                                                                <div class="lesson-material-info" style="margin-top: 5px;">
                                                                    <span style="color: #666; font-size: 12px; display: flex; align-items: center; gap: 3px;">
                                                                        <i class="dashicons dashicons-media-document" style="font-size: 12px;"></i>
                                                                        <?php esc_html_e('Material Included', 'vira-store'); ?>
                                                                    </span>
                                                                </div>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                    <div class="lesson-meta" style="display: flex; align-items: center; gap: 15px;">
                                                        <?php if (!empty($lesson['duration'])): ?>
                                                            <span class="lesson-duration" style="color: #666; font-size: 14px; display: flex; align-items: center; gap: 3px;">
                                                                <i class="dashicons dashicons-clock" style="font-size: 14px;"></i>
                                                                <?php echo esc_html($lesson['duration'] . ' min'); ?>
                                                            </span>
                                                        <?php endif; ?>
                                                        <?php if (!$is_free_preview): ?>
                                                            <i class="dashicons dashicons-lock" style="color: #999; font-size: 14px;" title="<?php esc_attr_e('Premium Content', 'vira-store'); ?>"></i>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <p style="color: #666; text-align: center; padding: 40px 0;"><?php esc_html_e('Curriculum details will be available soon.', 'vira-store'); ?></p>
                    <?php endif; ?>
                </div>
                
                <?php if (!empty($course_data['instructor']['name'])): ?>
                    <div class="tab-content" id="instructor" style="display: none;">
                        <div class="instructor-info" style="display: flex; gap: 20px; align-items: flex-start;">
                            <div class="instructor-avatar" style="flex-shrink: 0;">
                                <?php if (!empty($course_data['instructor']['avatar'])): ?>
                                    <div style="width: 100px; height: 100px; border-radius: 50%; overflow: hidden; border: 3px solid #e0e0e0;">
                                        <?php echo wp_get_attachment_image($course_data['instructor']['avatar'], 'thumbnail', false, ['alt' => esc_attr($course_data['instructor']['name']), 'style' => 'width: 100%; height: 100%; object-fit: cover;']); ?>
                                    </div>
                                <?php elseif (!empty($course_data['instructor']['user_id'])): ?>
                                    <!-- Use WordPress avatar system -->
                                    <div style="width: 100px; height: 100px; border-radius: 50%; overflow: hidden; border: 3px solid #e0e0e0;">
                                        <?php echo get_avatar($course_data['instructor']['user_id'], 100, '', esc_attr($course_data['instructor']['name']), ['style' => 'width: 100%; height: 100%; object-fit: cover;']); ?>
                                    </div>
                                <?php else: ?>
                                    <div class="default-avatar" style="width: 100px; height: 100px; border-radius: 50%; background: #f0f0f0; display: flex; align-items: center; justify-content: center; border: 3px solid #e0e0e0;">
                                        <i class="dashicons dashicons-admin-users" style="font-size: 40px; color: #999;"></i>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="instructor-details" style="flex: 1;">
                                <h3 class="instructor-name" style="margin: 0 0 15px 0; font-size: 1.4em; color: #333;"><?php echo esc_html($course_data['instructor']['name']); ?></h3>
                                
                                <?php if (!empty($course_data['instructor']['bio'])): ?>
                                    <div class="instructor-bio" style="line-height: 1.6; color: #666; margin-bottom: 15px;">
                                        <?php echo wp_kses_post(wpautop($course_data['instructor']['bio'])); ?>
                                    </div>
                                <?php endif; ?>
                                
                                <?php if (!empty($course_data['instructor']['website'])): ?>
                                    <div class="instructor-website">
                                        <a href="<?php echo esc_url($course_data['instructor']['website']); ?>" target="_blank" rel="noopener" style="display: inline-flex; align-items: center; gap: 5px; color: #0073aa; text-decoration: none; font-weight: 500;">
                                            <?php esc_html_e('Visit Website', 'vira-store'); ?>
                                            <i class="dashicons dashicons-external" style="font-size: 16px;"></i>
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                
                <div class="tab-content" id="reviews" style="display: none;">
                    <div class="course-reviews">
                             
                        <?php if ($approved_comments > 0): ?>
                            <div class="reviews-summary" style="background: #f9f9f9; padding: 20px; border-radius: 8px; margin-bottom: 30px; text-align: center;">
                                <div class="review-count" style="color: #666; font-size: 1.1em;"><?php echo sprintf(esc_html(_n('Based on %d review', 'Based on %d reviews', $approved_comments, 'vira-store')), $approved_comments); ?></div>
                            </div>
                        <?php endif; ?>
                        
                        <!-- WordPress Comments Integration -->
                        <div class="course-comments-section">
                            <?php
                            // Get comments for this course
                            $comments = get_comments([
                                'post_id' => $course_id,
                                'status' => 'approve',
                                'type' => 'comment',
                                'order' => 'DESC',
                                'number' => 10 // Limit to 10 most recent reviews
                            ]);
                            
                            if (!empty($comments)): ?>
                                <div class="reviews-list">
                                    <?php foreach ($comments as $comment): ?>
                                        <div class="review-item" style="background: #fff; border: 1px solid #e0e0e0; border-radius: 8px; padding: 20px; margin-bottom: 15px;">
                                            <div class="review-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                                                <div class="reviewer-info" style="display: flex; align-items: center; gap: 10px;">
                                        <?php echo get_avatar($comment->comment_author_email, 40, '', '', ['style' => 'border-radius: 50%;']); ?>
                                        <div>
                                            <strong style="color: #333; font-size: 14px;"><?php echo esc_html($comment->comment_author); ?></strong>
                                        </div>
                                    </div>
                                                <div class="review-date" style="color: #666; font-size: 12px;">
                                                    <?php echo esc_html(human_time_diff(strtotime($comment->comment_date), current_time('timestamp')) . ' ago'); ?>
                                                </div>
                                            </div>
                                            <div class="review-content" style="color: #555; line-height: 1.6;">
                                                <?php echo wp_kses_post(wpautop($comment->comment_content)); ?>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                                
                                <?php if ($approved_comments > 10): ?>
                                    <div style="text-align: center; margin-top: 20px;">
                                        <button class="load-more-reviews" style="background: #0073aa; color: white; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer;">
                                            <?php esc_html_e('Load More Reviews', 'vira-store'); ?>
                                        </button>
                                    </div>
                                <?php endif; ?>
                            <?php else: ?>
                                <div class="no-reviews" style="text-align: center; padding: 40px 0; color: #666;">
                                    <i class="dashicons dashicons-star-empty" style="font-size: 48px; margin-bottom: 15px;"></i>
                                    <p style="font-size: 16px; margin-bottom: 10px;"><?php esc_html_e('No reviews yet', 'vira-store'); ?></p>
                                    <p style="font-size: 14px;"><?php esc_html_e('Be the first to review this course', 'vira-store'); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Review Form for Enrolled Users -->
                        <?php 
                        $current_user_id = get_current_user_id();
                        $user_has_access = false;
                        
                        if ($current_user_id > 0 && class_exists('VRSTORE_Course')) {
                            $course_instance = VRSTORE_Course::get_instance();
                            $user_has_access = $course_instance->user_has_course_access($course_id, $current_user_id);
                        }
                        ?>
                        
                        <?php if ($user_has_access): ?>
                            <!-- Show comment form for enrolled users -->
                            <div class="review-form-section" style="margin-top: 30px; padding: 20px; background: #f9f9f9; border-radius: 8px;">
                                <h4 style="margin-bottom: 15px; color: #333;"><?php esc_html_e('Leave a Review', 'vira-store'); ?></h4>
                                <?php
                                $comment_form_args = [
                                    'title_reply' => '',
                                    'logged_in_as' => '',
                                    'comment_notes_before' => '',
                                    'comment_notes_after' => '',
                                    'fields' => [],
                                    'comment_field' => '<div style="margin-bottom: 15px;"><label for="comment" style="display: block; margin-bottom: 5px; font-weight: 500;">' . esc_html__('Your Review', 'vira-store') . '</label><textarea id="comment" name="comment" rows="5" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; resize: vertical;" required></textarea></div>',
                                    'submit_button' => '<button type="submit" class="submit-review" style="background: #0073aa; color: white; border: none; padding: 12px 24px; border-radius: 5px; cursor: pointer; font-weight: 500;">' . esc_html__('Submit Review', 'vira-store') . '</button>',
                                    'label_submit' => esc_html__('Submit Review', 'vira-store')
                                ];
                                
                                comment_form($comment_form_args, $course_id);
                                ?>
                            </div>
                        <?php else: ?>
                            <div class="reviews-cta" style="text-align: center; margin-top: 30px; padding: 20px; background: #f0f8ff; border-radius: 8px;">
                                <p style="margin-bottom: 15px; color: #333;"><?php esc_html_e('Purchase this course to leave a review', 'vira-store'); ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <?php if ($user_has_access): ?>
                    <div class="tab-content" id="resources" style="display: none;">
                        <div class="course-resources">
                            <div class="resources-intro" style="margin-bottom: 30px; padding: 20px; background: #f0f8ff; border-radius: 8px; border-left: 4px solid #0073aa;">
                                <h3 style="margin: 0 0 10px 0; color: #333;"><?php esc_html_e('Course Resources', 'vira-store'); ?></h3>
                                <p style="margin: 0; color: #555; line-height: 1.6;"><?php esc_html_e('Access all course materials, downloads, and supplementary resources for this course.', 'vira-store'); ?></p>
                            </div>
                            
                            <?php 
                            // Check if course offers certification and user has completed it
                            $offers_certification = get_post_meta($course_id, '_vrstore_course_certification', true);
                            $certificate_instance = VRSTORE_PDF_Certificate::get_instance();
                            $is_course_completed = $certificate_instance->is_course_completed($course_id, $current_user_id);
                            
                            if ($offers_certification && $is_course_completed): 
                                // Generate secure certificate download URL
                                $certificate_instance = VRSTORE_PDF_Certificate::get_instance();
                                $secure_cert_url = $certificate_instance->generate_secure_certificate_url($course_id, $current_user_id);
                                
                                // Get current theme colors for consistency
                                $primary_color = get_theme_mod('primary_color', '#0073aa');
                                $secondary_color = get_theme_mod('secondary_color', '#28a745');
                                
                                // Get site logo for consistency
                                $custom_logo_id = get_theme_mod('custom_logo');
                                $logo_url = $custom_logo_id ? wp_get_attachment_image_url($custom_logo_id, 'medium') : '';
                                ?>
                                <div class="certification-section" style="margin-bottom: 30px; padding: 25px; background: linear-gradient(135deg, #e8f5e8 0%, #f0f8f0 100%); border-radius: 12px; border-left: 5px solid <?php echo esc_attr($secondary_color); ?>;">
                                    <h4 style="margin: 0 0 15px 0; color: #155724; font-size: 1.2em; display: flex; align-items: center; gap: 10px;">
                                        <?php if ($logo_url): ?>
                                            <img src="<?php echo esc_url($logo_url); ?>" alt="<?php esc_attr_e('Site Logo', 'vira-store'); ?>" style="height: 24px; width: auto; margin-right: 5px;" />
                                        <?php endif; ?>
                                        <i class="dashicons dashicons-awards" style="font-size: 24px; color: <?php echo esc_attr($secondary_color); ?>;"></i>
                                        <?php esc_html_e('Course Completion Certificate', 'vira-store'); ?>
                                    </h4>
                                    <p style="margin: 0 0 20px 0; color: #155724; line-height: 1.6;">
                                        <?php esc_html_e('Congratulations! You have successfully completed this course. Download your certificate of completion below.', 'vira-store'); ?>
                                    </p>
                                    <a href="<?php echo esc_url($secure_cert_url ?: '#'); ?>" 
                                       class="btn-download-certificate" 
                                       style="display: inline-flex; align-items: center; gap: 10px; background: linear-gradient(135deg, <?php echo esc_attr($secondary_color); ?> 0%, <?php echo esc_attr($primary_color); ?> 100%); color: white; padding: 12px 24px; border-radius: 25px; text-decoration: none; font-weight: 600; transition: all 0.3s ease; box-shadow: 0 4px 15px rgba(40, 167, 69, 0.3);"
                                       onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 6px 20px rgba(40, 167, 69, 0.4)';"
                                       onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 4px 15px rgba(40, 167, 69, 0.3)';"
                                       <?php if (!$secure_cert_url): ?>onclick="alert('<?php esc_js_e('Certificate download temporarily unavailable.', 'vira-store'); ?>'); return false;"<?php endif; ?>>
                                        <i class="dashicons dashicons-download" style="font-size: 18px;"></i>
                                        <?php esc_html_e('Download Certificate', 'vira-store'); ?>
                                    </a>
                                </div>
                            <?php elseif ($offers_certification && !$is_course_completed): ?>
                                <div class="certification-pending" style="margin-bottom: 30px; padding: 25px; background: linear-gradient(135deg, #fff3cd 0%, #fef9e7 100%); border-radius: 12px;">
                                    <h4 style="margin: 0 0 15px 0; color: #856404; font-size: 1em; display: flex; align-items: center; gap: 10px;">
                                        <i class="dashicons dashicons-clock" style="font-size: 20px;"></i>
                                        <?php esc_html_e('Certificate Available Upon Completion', 'vira-store'); ?>
                                    </h4>
                                    <p style="margin: 0; color: #856404; line-height: 1.6;">
                                        <?php esc_html_e('Complete all lessons in this course to unlock your certificate of completion.', 'vira-store'); ?>
                                    </p>
                                </div>
                            <?php endif; ?>
                            
                            <?php 
                            // Collect all resources from the curriculum
                            $all_resources = [];
                            
                            if (!empty($course_data['curriculum']) && is_array($course_data['curriculum'])) {
                                foreach ($course_data['curriculum'] as $module_index => $module) {
                                    if (!empty($module['lessons']) && is_array($module['lessons'])) {
                                        foreach ($module['lessons'] as $lesson_index => $lesson) {
                                            $lesson_title = $lesson['title'] ?? 'Lesson ' . ($lesson_index + 1);
                                            $module_title = $module['title'] ?? 'Module ' . ($module_index + 1);
                                            
                                            // Check for materials in this lesson
                                            if (!empty($lesson['material_url']) || !empty($lesson['material_file'])) {
                                                $resource = [
                                                    'title' => $lesson_title,
                                                    'module' => $module_title,
                                                    'type' => 'material',
                                                    'url' => $lesson['material_url'] ?? '',
                                                    'file_id' => $lesson['material_file'] ?? '',
                                                    'module_index' => $module_index,
                                                    'lesson_index' => $lesson_index
                                                ];
                                                $all_resources[] = $resource;
                                            }
                                        }
                                    }
                                }
                            }
                            ?>
                            
                            <?php if (!empty($all_resources)): ?>
                                <!-- Resources Grid (3-column layout matching Dashboard) -->
                                <div class="resources-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin-bottom: 30px;">
                                    <?php foreach ($all_resources as $resource): ?>
                                        <div class="resource-card" style="background: white; border: 1px solid #e0e0e0; border-radius: 8px; padding: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); transition: all 0.3s ease;">
                                            <div class="resource-header" style="display: flex; align-items: flex-start; gap: 15px; margin-bottom: 15px;">
                                                <div class="resource-icon" style="flex-shrink: 0; width: 40px; height: 40px; background: #f0f8ff; border-radius: 8px; display: flex; align-items: center; justify-content: center;">
                                                    <i class="dashicons dashicons-media-document" style="color: #0073aa; font-size: 20px;"></i>
                                                </div>
                                                <div class="resource-info" style="flex: 1; min-width: 0;">
                                                    <h4 style="margin: 0 0 5px 0; font-size: 16px; font-weight: 600; color: #333; line-height: 1.3;"><?php echo esc_html($resource['title']); ?></h4>
                                                    <p style="margin: 0; font-size: 12px; color: #666; text-transform: uppercase; letter-spacing: 0.5px;"><?php echo esc_html($resource['module']); ?></p>
                                                </div>
                                            </div>
                                            
                                            <div class="resource-description" style="margin-bottom: 15px;">
                                                <p style="margin: 0; color: #555; font-size: 14px; line-height: 1.5;">
                                                    <?php esc_html_e('Course material and resources for', 'vira-store'); ?> <?php echo esc_html($resource['title']); ?>
                                                </p>
                                            </div>
                                            
                                            <div class="resource-actions" style="display: flex; gap: 10px;">
                                                <?php if (!empty($resource['url'])): ?>
                                                    <a href="<?php echo esc_url($resource['url']); ?>" 
                                                       target="_blank" 
                                                       rel="noopener" 
                                                       class="resource-button" 
                                                       style="display: inline-flex; align-items: center; gap: 5px; background: #0073aa; color: white; padding: 8px 16px; border-radius: 5px; text-decoration: none; font-size: 14px; font-weight: 500; transition: background 0.3s ease;"
                                                       onmouseover="this.style.background='#005a87'" 
                                                       onmouseout="this.style.background='#0073aa'">
                                                        <i class="dashicons dashicons-external" style="font-size: 14px;"></i>
                                                        <?php esc_html_e('Open Link', 'vira-store'); ?>
                                                    </a>
                                                <?php endif; ?>
                                                
                                                <?php if (!empty($resource['file_id'])): 
                                                    $file_url = wp_get_attachment_url($resource['file_id']);
                                                    $file_title = get_the_title($resource['file_id']);
                                                    $file_path = get_attached_file($resource['file_id']);
                                                    
                                                    // Generate secure download URL using file protection system
                                                    $secure_download_url = '#';
                                                    $download_error = '';
                                                    
                                                    if (class_exists('VRSTORE_File_Protection') && $resource['file_id'] && $file_url) {
                                                        try {
                                                            $file_protection = VRSTORE_File_Protection::get_instance();
                                                            $current_user_id = get_current_user_id();
                                                            
                                                            // Generate secure download token (expires in 1 hour)
                                                            $expires = time() + HOUR_IN_SECONDS;
                                                            $secure_token = $file_protection->generate_download_token(
                                                                $course_id, // Use course ID as "product ID"
                                                                0, // File index (always 0 for single material)
                                                                $current_user_id,
                                                                $expires
                                                            );
                                                            
                                                            $secure_download_url = add_query_arg([
                                                                'vrstore_course_material_download' => $secure_token,
                                                                'course_id' => $course_id,
                                                                'material_file' => $resource['file_id']
                                                            ], home_url());
                                                            
                                                        } catch (Exception $e) {
                                                            $download_error = 'Secure download temporarily unavailable';
                                                            // Fallback to direct download with warning
                                                            $secure_download_url = $file_url;
                                                        }
                                                    } else {
                                                        // Fallback to direct download if file protection not available
                                                        $secure_download_url = $file_url;
                                                    }
                                                    
                                                    if ($file_url): ?>
                                                        <a href="<?php echo esc_url($secure_download_url); ?>" 
                                                           class="resource-button secondary vrstore-secure-resource-download" 
                                                           data-material-id="<?php echo esc_attr($resource['file_id']); ?>" 
                                                           data-course-id="<?php echo esc_attr($course_id); ?>"
                                                           style="display: inline-flex; align-items: center; gap: 5px; background: #f0f0f0; color: #333; padding: 8px 16px; border-radius: 5px; text-decoration: none; font-size: 14px; font-weight: 500; border: 1px solid #ddd; transition: all 0.3s ease;"
                                                           onmouseover="this.style.background='#e5e5e5'; this.style.borderColor='#ccc'" 
                                                           onmouseout="this.style.background='#f0f0f0'; this.style.borderColor='#ddd'"
                                                           title="<?php echo esc_attr($file_title); ?>">
                                                            <i class="dashicons dashicons-download" style="font-size: 14px;"></i>
                                                            <?php echo class_exists('VRSTORE_File_Protection') ? esc_html__('Secure Download', 'vira-store') : esc_html__('Download', 'vira-store'); ?>
                                                            <?php if ($download_error): ?>
                                                                <span style="color: #ff9800; font-size: 11px; display: block; margin-top: 2px;">
                                                                    <i class="dashicons dashicons-warning" style="font-size: 11px;"></i>
                                                                    <?php echo esc_html($download_error); ?>
                                                                </span>
                                                            <?php endif; ?>
                                                        </a>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </div>
                                            
                                            <!-- Resource metadata -->
                                            <div class="resource-meta" style="margin-top: 15px; padding-top: 15px; border-top: 1px solid #f0f0f0; display: flex; justify-content: between; align-items: center;">
                                                <span class="resource-type" style="font-size: 12px; color: #666; text-transform: uppercase; letter-spacing: 0.5px;">
                                                    <?php esc_html_e('Lesson Resource', 'vira-store'); ?>
                                                </span>
                                                <?php if (!empty($resource['file_id'])): 
                                                    $file_path = get_attached_file($resource['file_id']);
                                                    if ($file_path && file_exists($file_path)): 
                                                        $file_size = size_format(filesize($file_path));
                                                        $file_ext = strtoupper(pathinfo($file_path, PATHINFO_EXTENSION));
                                                ?>
                                                    <span class="resource-size" style="font-size: 12px; color: #666;">
                                                        <?php echo esc_html($file_ext . ' • ' . $file_size); ?>
                                                    </span>
                                                <?php endif; endif; ?>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                                                               
                            <?php else: ?>
                                <!-- No Resources Message -->
                                <div class="no-resources" style="text-align: center; padding: 60px 20px; background: #f9f9f9; border-radius: 8px;">
                                    <div style="margin-bottom: 20px;">
                                        <i class="dashicons dashicons-portfolio" style="font-size: 48px; color: #ccc;"></i>
                                    </div>
                                    <h3 style="margin: 0 0 10px 0; color: #333; font-size: 18px;"><?php esc_html_e('No Resources Available', 'vira-store'); ?></h3>
                                    <p style="margin: 0; color: #666; font-size: 14px; line-height: 1.6;">
                                        <?php esc_html_e('This course doesn\'t have any downloadable resources or materials at the moment. Check back later as the instructor may add resources in the future.', 'vira-store'); ?>
                                    </p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Sidebar -->
        <div class="course-sidebar" style="position: sticky; top: 20px;">
            <!-- Course Image -->
            <?php if (!empty($course_data['featured_image'])): ?>
                <div class="course-image" style="margin-bottom: 25px; border-radius: 10px; overflow: hidden; box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1); position: relative; cursor: pointer;" onclick="openPreviewModal()">
                    <?php echo wp_get_attachment_image($course_data['featured_image'], 'large', false, ['alt' => esc_attr($course_data['title']), 'style' => 'width: 100%; height: auto; display: block;']); ?>
                    <!-- Play Button Overlay -->
                    <div class="video-play-overlay" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); background: rgba(0, 0, 0, 0.7); border-radius: 50%; width: 80px; height: 80px; display: flex; align-items: center; justify-content: center; transition: all 0.3s ease;">
                        <div class="play-icon" style="width: 0; height: 0; border-left: 25px solid white; border-top: 15px solid transparent; border-bottom: 15px solid transparent; margin-left: 5px;"></div>
                    </div>
                    <!-- Preview Badge -->
                    <div class="preview-badge" style="position: absolute; top: 15px; right: 15px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 6px 12px; border-radius: 15px; font-size: 12px; font-weight: 600; text-transform: uppercase;">
                        <?php esc_html_e('Preview', 'vira-store'); ?>
                    </div>
                </div>
            <?php endif; ?>
            
            <!-- Pricing Box -->
            <div class="course-pricing" style="background: white; border: 2px solid #e0e0e0; border-radius: 12px; padding: 25px; margin-bottom: 25px; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);">
                <div class="price-info" style="text-align: center; margin-bottom: 20px;">
                    <?php 
                    $is_free = !empty($course_data['is_free']);
                    $has_sale_price = !empty($course_data['sale_price']) && (float) $course_data['sale_price'] > 0;
                    $regular_price = !empty($course_data['price']) ? $course_data['price'] : 0;
                    $sale_price = !empty($course_data['sale_price']) ? $course_data['sale_price'] : 0;
                    
                    // Format prices with currency conversion
                    $formatted_regular_price = vrstore_format_course_price($regular_price, $currency_converter, $user_currency);
                    $formatted_sale_price = vrstore_format_course_price($sale_price, $currency_converter, $user_currency);
                    
                    if ($is_free || ($regular_price == 0 && $sale_price == 0)):
                    ?>
                        <div class="free-price" style="font-size: 2.2em; font-weight: bold; color: #2e7d32; margin-bottom: 5px;">
                            <?php esc_html_e('FREE', 'vira-store'); ?>
                        </div>
                    <?php else: ?>
                        <?php if ($has_sale_price): ?>
                            <div class="sale-price vrstore-price" 
                                 style="font-size: 2.2em; font-weight: bold; color: #2e7d32; margin-bottom: 5px;"
                                 data-base-amount="<?php echo esc_attr($sale_price); ?>"
                                 data-base-currency="<?php echo esc_attr($base_currency); ?>">
                                <?php echo esc_html($formatted_sale_price); ?>
                            </div>
                            <div class="original-price vrstore-price" 
                                 style="font-size: 1.1em; color: #999; text-decoration: line-through; margin-bottom: 10px;"
                                 data-base-amount="<?php echo esc_attr($regular_price); ?>"
                                 data-base-currency="<?php echo esc_attr($base_currency); ?>">
                                <?php echo esc_html($formatted_regular_price); ?>
                            </div>
                            <?php 
                                $discount = round((((float) $regular_price - (float) $sale_price) / (float) $regular_price) * 100);
                            ?>
                            <div class="discount-badge" style="display: inline-block; background: #f44336; color: white; padding: 4px 12px; border-radius: 15px; font-size: 12px; font-weight: 600;">
                                <?php echo esc_html($discount . '% OFF'); ?>
                            </div>
                        <?php else: ?>
                            <div class="current-price vrstore-price" 
                                 style="font-size: 2.2em; font-weight: bold; color: #2e7d32; margin-bottom: 5px;"
                                 data-base-amount="<?php echo esc_attr($regular_price); ?>"
                                 data-base-currency="<?php echo esc_attr($base_currency); ?>">
                                <?php echo esc_html($formatted_regular_price); ?>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
                
                <div class="enrollment-actions" style="margin-bottom: 20px;">
                    <?php 
                    // Check if current user has access to this course
                    $current_user_id = get_current_user_id();
                    $user_has_access = false;
                    
                    if ($current_user_id > 0 && class_exists('VRSTORE_Course')) {
                        $course_instance = VRSTORE_Course::get_instance();
                        $user_has_access = $course_instance->user_has_course_access($course_id, $current_user_id);
                    }
                    
                    // Check enrollment limit
                    $max_students = !empty($course_data['max_students']) ? absint($course_data['max_students']) : 0;
                    $enrollment_limit_reached = false;
                    $current_enrolled = 0;
                    
                    if ($max_students > 0 && class_exists('VRSTORE_Course')) {
                        $course_instance = VRSTORE_Course::get_instance();
                        $current_enrolled = $course_instance->sync_enrollment_count($course_id);
                        $enrollment_limit_reached = ($current_enrolled >= $max_students);
                    }
                    ?>
                    
                    <?php if ($user_has_access): ?>
                        <!-- User already has access - show enrolled/purchased state -->
                        <div class="course-access-granted" style="width: 100%; background: linear-gradient(135deg, #2e7d32 0%, #1b5e20 100%); color: white; border: none; padding: 15px 20px; font-size: 16px; font-weight: 600; border-radius: 8px; margin-bottom: 15px; text-align: center; display: flex; align-items: center; justify-content: center;">
                            <i class="dashicons dashicons-yes-alt" style="margin-right: 8px;"></i>
                            <?php 
                            if ($is_free || ($regular_price == 0 && $sale_price == 0)) {
                                esc_html_e('Enrolled', 'vira-store');
                            } else {
                                esc_html_e('Purchased', 'vira-store');
                            }
                            ?>
                        </div>
                        
                        <!-- Add a "Continue Learning" button -->
                        <a href="#curriculum" class="continue-learning-button" style="width: 100%; background: transparent; color: #0073aa; border: 2px solid #0073aa; padding: 12px 20px; font-size: 14px; font-weight: 500; border-radius: 8px; cursor: pointer; transition: all 0.3s ease; text-decoration: none; display: flex; align-items: center; justify-content: center;">
                            <i class="dashicons dashicons-controls-play" style="margin-right: 8px;"></i>
                            <?php esc_html_e('Continue Learning', 'vira-store'); ?>
                        </a>
                        
                    <?php elseif ($is_free || ($regular_price == 0 && $sale_price == 0)): ?>
                        <!-- Free course enrollment -->
                        <?php if ($enrollment_limit_reached): ?>
                            <!-- Enrollment limit reached - show disabled button with notice -->
                            <div class="enrollment-limit-reached" style="width: 100%; background: #f5f5f5; color: #666; border: 2px solid #ddd; padding: 15px 20px; font-size: 16px; font-weight: 600; border-radius: 8px; margin-bottom: 15px; text-align: center; display: flex; align-items: center; justify-content: center;">
                                <i class="dashicons dashicons-warning" style="margin-right: 8px; color: #ff9800;"></i>
                                <?php esc_html_e('Enrollment Max Reached', 'vira-store'); ?>
                            </div>
                            <div class="enrollment-limit-notice" style="text-align: center; margin-bottom: 15px;">
                                <small style="color: #666; font-size: 12px; display: block;">
                                    <?php echo sprintf(
                                        esc_html__('This course is full (%d/%d students enrolled)', 'vira-store'),
                                        $current_enrolled,
                                        $max_students
                                    ); ?>
                                </small>
                            </div>
                        <?php else: ?>
                            <button class="enroll-button vrstore-enroll-free" 
                                    data-course-id="<?php echo esc_attr($course_id); ?>"
                                    data-nonce="<?php echo wp_create_nonce('vrstore_course_enroll_' . $course_id); ?>"
                                    style="width: 100%; background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%); color: white; border: none; padding: 15px 20px; font-size: 16px; font-weight: 600; border-radius: 8px; cursor: pointer; margin-bottom: 15px; transition: all 0.3s ease;">
                                <i class="dashicons dashicons-yes-alt" style="margin-right: 8px;"></i>
                                <?php esc_html_e('Enroll for Free', 'vira-store'); ?>
                            </button>
                        <?php endif; ?>
                        
                        <?php
                        // Check if this course requires a product purchase for free enrollment
                        $free_with_product = get_post_meta($course_id, '_vrstore_course_free_with_product', true);
                        $required_product_id = get_post_meta($course_id, '_vrstore_course_required_product_id', true);
                        
                        if ($free_with_product && $required_product_id):
                            $product_title = get_the_title($required_product_id);
                        ?>
                            <div class="course-product-requirement" style="text-align: center; margin-top: 10px;">
                                <small style="color: #666; font-size: 12px; display: block;">
                                    <?php echo sprintf(
                                        esc_html__('Free enroll with purchase: %s', 'vira-store'),
                                        '<strong>' . esc_html($product_title) . '</strong>'
                                    ); ?>
                                </small>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <!-- Paid course purchase -->
                        <?php if ($enrollment_limit_reached): ?>
                            <!-- Enrollment limit reached - show disabled button with notice -->
                            <div class="enrollment-limit-reached" style="width: 100%; background: #f5f5f5; color: #666; border: 2px solid #ddd; padding: 15px 20px; font-size: 16px; font-weight: 600; border-radius: 8px; margin-bottom: 15px; text-align: center; display: flex; align-items: center; justify-content: center;">
                                <i class="dashicons dashicons-warning" style="margin-right: 8px; color: #ff9800;"></i>
                                <?php esc_html_e('Enrollment Max Reached', 'vira-store'); ?>
                            </div>
                            <div class="enrollment-limit-notice" style="text-align: center; margin-bottom: 15px;">
                                <small style="color: #666; font-size: 12px; display: block;">
                                    <?php echo sprintf(
                                        esc_html__('This course is full (%d/%d students enrolled)', 'vira-store'),
                                        $current_enrolled,
                                        $max_students
                                    ); ?>
                                </small>
                            </div>
                        <?php else: ?>
                            <?php 
                            $button_price = $has_sale_price ? $sale_price : $regular_price;
                            $converted_button_price = $currency_converter ? $currency_converter->convert_price($button_price) : $button_price;
                            ?>
                            <button class="enroll-button vrstore-buy-now" 
                                    data-course-id="<?php echo esc_attr($course_id); ?>"
                                    data-price="<?php echo esc_attr($converted_button_price); ?>"
                                    data-base-price="<?php echo esc_attr($button_price); ?>"
                                    data-base-currency="<?php echo esc_attr($base_currency); ?>"
                                    data-user-currency="<?php echo esc_attr($user_currency); ?>"
                                    data-nonce="<?php echo wp_create_nonce('vrstore_add_to_cart'); ?>"
                                    style="width: 100%; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; padding: 15px 20px; font-size: 16px; font-weight: 600; border-radius: 8px; cursor: pointer; margin-bottom: 15px; transition: all 0.3s ease;">
                                <i class="dashicons dashicons-cart" style="margin-right: 8px;"></i>
                                <span class="button-text"><?php esc_html_e('Enroll Now', 'vira-store'); ?></span>
                                <i class="dashicons dashicons-update button-spinner" style="display: none; margin-left: 8px; animation: spin 1s linear infinite;"></i>
                            </button>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Course Info -->
            <div class="course-details" style="background: white; border: 2px solid #e0e0e0; border-radius: 12px; padding: 20px; margin-bottom: 25px; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);">
                <h3 style="margin-bottom: 20px; color: #333; font-size: 1em;"><?php esc_html_e('Course Includes', 'vira-store'); ?></h3>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <!-- Column 1: Duration, Lessons, Materials -->
                    <div class="course-info-column">
                        <?php if ($formatted_duration): ?>
                            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; color: #555;">
                                <i class="dashicons dashicons-clock" style="color: #0073aa; font-size: 18px;"></i>
                                <div style="font-size: 14px;">
                                    <strong><?php esc_html_e('Duration:', 'vira-store'); ?></strong>
                                    <span><?php echo esc_html($formatted_duration); ?></span>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($total_lessons > 0): ?>
                            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; color: #555;">
                                <i class="dashicons dashicons-playlist-video" style="color: #0073aa; font-size: 18px;"></i>
                                <div style="font-size: 14px;">
                                    <strong><?php esc_html_e('Lessons:', 'vira-store'); ?></strong>
                                    <span><?php echo esc_html($total_lessons . ' ' . _n('lesson', 'lessons', $total_lessons, 'vira-store')); ?></span>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($total_materials > 0): ?>
                            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; color: #555;">
                                <i class="dashicons dashicons-media-document" style="color: #0073aa; font-size: 18px;"></i>
                                <div style="font-size: 14px;">
                                    <strong><?php esc_html_e('Materials:', 'vira-store'); ?></strong>
                                    <span><?php echo esc_html($total_materials . ' ' . _n('resource', 'resources', $total_materials, 'vira-store')); ?></span>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Column 2: Language, Periods, Certification -->
                    <div class="course-info-column">
                        <?php if (!empty($course_data['language'])): ?>
                            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; color: #555;">
                                <i class="dashicons dashicons-translation" style="color: #0073aa; font-size: 18px;"></i>
                                <div style="font-size: 14px;">
                                    <strong><?php esc_html_e('Language:', 'vira-store'); ?></strong>
                                    <span><?php echo esc_html($course_data['language']); ?></span>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <?php 
                        // Get access period information
                        $access_period_type = get_post_meta($course_id, '_vrstore_course_access_period_type', true) ?: 'lifetime';
                        $access_period_value = get_post_meta($course_id, '_vrstore_course_access_period_value', true);
                        $access_period_unit = get_post_meta($course_id, '_vrstore_course_access_period_unit', true) ?: 'months';
                        
                        $access_text = __('Lifetime', 'vira-store');
                        if ($access_period_type === 'limited' && $access_period_value) {
                            $access_text = $access_period_value . ' ' . __($access_period_unit, 'vira-store');
                        }
                        ?>
                        <div>
                            <i class="dashicons dashicons-calendar-alt"></i>
                            <div>
                                <strong><?php esc_html_e('Access Period:', 'vira-store'); ?></strong>
                                <span><?php echo esc_html($access_text); ?></span>
                            </div>
                        </div>
                        
                        <?php 
                        $certification_enabled = get_post_meta($course_id, '_vrstore_course_certification', true);
                        ?>
                        <div>
                            <i class="dashicons dashicons-awards"></i>
                            <div>
                                <strong><?php esc_html_e('Certificate:', 'vira-store'); ?></strong>
                                <span><?php echo esc_html($certification_enabled ? __('Yes', 'vira-store') : __('No', 'vira-store')); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Social Media Share -->
            <div class="course-social-share">
                <h3><?php esc_html_e('Share This Course', 'vira-store'); ?></h3>
                <div class="social-share-buttons">
                    <?php 
                    $course_url = urlencode(get_permalink($course_id));
                    $course_title = urlencode(get_the_title($course_id));
                    $course_excerpt = urlencode(wp_trim_words(get_the_excerpt($course_id), 20));
                    ?>
                    
                    <!-- LinkedIn Share -->
                    <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo $course_url; ?>" 
                       target="_blank" 
                       rel="noopener noreferrer"
                       style="background: #0077B5;"
                       title="<?php esc_attr_e('Share on LinkedIn', 'vira-store'); ?>">
                        in
                    </a>
                    
                    <!-- Facebook Share -->
                    <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $course_url; ?>" 
                       target="_blank" 
                       rel="noopener noreferrer"
                       style="background: #1877F2;"
                       title="<?php esc_attr_e('Share on Facebook', 'vira-store'); ?>">
                        f
                    </a>
                    
                    <!-- Twitter Share -->
                    <a href="https://twitter.com/intent/tweet?url=<?php echo $course_url; ?>&text=<?php echo $course_title; ?>%20-%20<?php echo $course_excerpt; ?>" 
                       target="_blank" 
                       rel="noopener noreferrer"
                       style="background: #1DA1F2;"
                       title="<?php esc_attr_e('Share on Twitter', 'vira-store'); ?>">
                        𝕏
                    </a>
                    
                    <!-- Copy Link Button -->
                    <button onclick="copyCourseLink(event)" 
                            style="background: #6B7280;"
                            title="<?php esc_attr_e('Copy Link', 'vira-store'); ?>">
                        🔗
                    </button>
                </div>
                
            </div>
            
            <!-- Course Categories -->
            <?php 
            $course_categories = wp_get_post_terms(get_the_ID(), 'course_category');
            if (!empty($course_categories) && !is_wp_error($course_categories)):
            ?>
                <div class="course-categories">
                    <h4><?php esc_html_e('Categories', 'vira-store'); ?></h4>
                    <div class="category-tags">
                        <?php foreach ($course_categories as $category): ?>
                            <a href="<?php echo esc_url(get_term_link($category)); ?>" class="category-tag">
                                <?php echo esc_html($category->name); ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

