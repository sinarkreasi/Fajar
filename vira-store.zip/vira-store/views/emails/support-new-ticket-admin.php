<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Support Ticket</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .header {
            text-align: center;
            border-bottom: 2px solid #e1e1e1;
            padding-bottom: 20px;
            margin-bottom: 30px;
            background-color: #dc3545;
            color: white;
            padding: 20px;
            border-radius: 6px 6px 0 0;
            margin: -30px -30px 30px -30px;
        }
        .header h1 {
            margin: 0;
            color: white;
        }
        .content {
            color: #333;
        }
        .ticket-info {
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 6px;
            padding: 20px;
            margin: 20px 0;
        }
        .info-row {
            display: flex;
            margin-bottom: 10px;
            align-items: center;
        }
        .info-label {
            font-weight: bold;
            min-width: 100px;
            color: #495057;
        }
        .info-value {
            color: #333;
        }
        .priority-high {
            background-color: #dc3545;
            color: white;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: bold;
        }
        .priority-normal {
            background-color: #17a2b8;
            color: white;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: bold;
        }
        .priority-low {
            background-color: #28a745;
            color: white;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: bold;
        }
        .priority-urgent {
            background-color: #e74c3c;
            color: white;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: bold;
            animation: blink 1s linear infinite;
        }
        @keyframes blink {
            0%, 50% { opacity: 1; }
            51%, 100% { opacity: 0.5; }
        }
        .ticket-message {
            background: #ffffff;
            border: 1px solid #dee2e6;
            border-left: 4px solid #007cba;
            border-radius: 6px;
            padding: 20px;
            margin: 20px 0;
        }
        .ticket-message h4 {
            margin-top: 0;
            color: #007cba;
        }
        .button {
            display: inline-block;
            padding: 12px 24px;
            background-color: #007cba;
            color: #fff !important;
            text-decoration: none;
            border-radius: 5px;
            margin: 15px 0;
            font-weight: bold;
        }
        .button:hover {
            background-color: #005a8b;
        }
        .footer {
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #e1e1e1;
            font-size: 14px;
            color: #666;
            text-align: center;
        }
        .urgent-notice {
            background-color: #fff3cd;
            border: 1px solid #ffeeba;
            color: #856404;
            padding: 12px;
            border-radius: 4px;
            margin: 15px 0;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🎫 New Support Ticket</h1>
            <p style="margin: 5px 0 0 0;">Ticket #{ticket_number}</p>
        </div>
        
        <div class="content">
            <?php if (strtolower($priority) === 'urgent'): ?>
                <div class="urgent-notice">
                    ⚠️ <strong>URGENT TICKET</strong> - This ticket requires immediate attention!
                </div>
            <?php endif; ?>
            
            <p>Hello,</p>
            
            <p>A new support ticket has been submitted and requires your attention.</p>
            
            <div class="ticket-info">
                <div class="info-row">
                    <span class="info-label">Ticket #:</span>
                    <span class="info-value"><strong>{ticket_number}</strong></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Subject:</span>
                    <span class="info-value"><strong>{ticket_subject}</strong></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Customer:</span>
                    <span class="info-value">{customer_name}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Email:</span>
                    <span class="info-value"><a href="mailto:{customer_email}">{customer_email}</a></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Product:</span>
                    <span class="info-value">{product_title}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Priority:</span>
                    <span class="info-value">
                        <span class="priority-{priority}">{ticket_priority}</span>
                    </span>
                </div>
                <div class="info-row">
                    <span class="info-label">Created:</span>
                    <span class="info-value">{created_date}</span>
                </div>
            </div>
            
            <div class="ticket-message">
                <h4>Customer Message:</h4>
                <div style="white-space: pre-wrap;">{ticket_message}</div>
            </div>
            
            <div style="text-align: center; margin: 25px 0;">
                <a href="{admin_ticket_url}" class="button">📋 View & Respond to Ticket</a>
            </div>
            
            <p><strong>Quick Actions:</strong></p>
            <ul>
                <li>Click the button above to view full ticket details</li>
                <li>Respond directly from the admin panel</li>
                <li>Update ticket status and priority as needed</li>
                <li>Customer will be automatically notified of your response</li>
            </ul>
        </div>
        
        <div class="footer">
            <p>&copy; <?php echo date('Y'); ?> {site_name}. All rights reserved.</p>
            <p>This is an automated notification from your support ticket system.</p>
        </div>
    </div>
</body>
</html>
