<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Support Ticket Confirmation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .header {
            text-align: center;
            border-bottom: 2px solid #e1e1e1;
            padding-bottom: 20px;
            margin-bottom: 30px;
            background-color: #28a745;
            color: white;
            padding: 20px;
            border-radius: 6px 6px 0 0;
            margin: -30px -30px 30px -30px;
        }
        .header h1 {
            margin: 0;
            color: white;
        }
        .content {
            color: #333;
        }
        .ticket-info {
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            border-left: 4px solid #28a745;
            border-radius: 6px;
            padding: 20px;
            margin: 20px 0;
        }
        .info-row {
            display: flex;
            margin-bottom: 10px;
            align-items: center;
        }
        .info-label {
            font-weight: bold;
            min-width: 100px;
            color: #495057;
        }
        .info-value {
            color: #333;
        }
        .priority-high, .priority-urgent {
            background-color: #dc3545;
            color: white;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: bold;
        }
        .priority-normal {
            background-color: #17a2b8;
            color: white;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: bold;
        }
        .priority-low {
            background-color: #28a745;
            color: white;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: bold;
        }
        .ticket-message {
            background: #ffffff;
            border: 1px solid #dee2e6;
            border-left: 4px solid #007cba;
            border-radius: 6px;
            padding: 20px;
            margin: 20px 0;
        }
        .ticket-message h4 {
            margin-top: 0;
            color: #007cba;
        }
        .button {
            display: inline-block;
            padding: 12px 24px;
            background-color: #007cba;
            color: #fff !important;
            text-decoration: none;
            border-radius: 5px;
            margin: 15px 0;
            font-weight: bold;
        }
        .button:hover {
            background-color: #005a8b;
        }
        .footer {
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #e1e1e1;
            font-size: 14px;
            color: #666;
            text-align: center;
        }
        .success-notice {
            background-color: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
            padding: 15px;
            border-radius: 4px;
            margin: 15px 0;
            text-align: center;
            font-weight: bold;
        }
        .next-steps {
            background-color: #e2e3e5;
            border: 1px solid #d6d8db;
            border-radius: 6px;
            padding: 20px;
            margin: 20px 0;
        }
        .next-steps h4 {
            margin-top: 0;
            color: #495057;
        }
        .next-steps ul {
            margin: 10px 0;
            padding-left: 20px;
        }
        .next-steps li {
            margin-bottom: 8px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>✅ Support Ticket Received</h1>
            <p style="margin: 5px 0 0 0;">Ticket #{ticket_number}</p>
        </div>
        
        <div class="content">
            <div class="success-notice">
                🎫 Your support ticket has been successfully submitted!
            </div>
            
            <p>Hello {customer_name},</p>
            
            <p>Thank you for contacting {site_name} support. We have received your ticket and our support team will review it shortly.</p>
            
            <div class="ticket-info">
                <div class="info-row">
                    <span class="info-label">Ticket #:</span>
                    <span class="info-value"><strong>{ticket_number}</strong></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Subject:</span>
                    <span class="info-value"><strong>{ticket_subject}</strong></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Product:</span>
                    <span class="info-value">{product_title}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Priority:</span>
                    <span class="info-value">
                        <span class="priority-{priority}">{ticket_priority}</span>
                    </span>
                </div>
                <div class="info-row">
                    <span class="info-label">Created:</span>
                    <span class="info-value">{created_date}</span>
                </div>
            </div>
            
            <div class="ticket-message">
                <h4>Your Message:</h4>
                <div style="white-space: pre-wrap; font-style: italic; color: #666;">{ticket_message}</div>
            </div>
            
            <div class="next-steps">
                <h4>📋 What Happens Next?</h4>
                <ul>
                    <li><strong>Our support team will review your ticket</strong> - We typically respond within 24 hours during business days</li>
                    <li><strong>You'll receive email notifications</strong> - We'll email you when we respond or update your ticket</li>
                    <li><strong>Track your ticket progress</strong> - Use the button below to view your ticket anytime</li>
                    <li><strong>Add additional information</strong> - You can reply to this ticket if you need to provide more details</li>
                </ul>
            </div>
            
            <div style="text-align: center; margin: 25px 0;">
                <a href="{customer_ticket_url}" class="button">🎫 View My Tickets</a>
            </div>
            
            <p><strong>Need urgent assistance?</strong> If this is a critical issue, please reply to this email or create a new high-priority ticket.</p>
            
            <p>We appreciate your business and will respond to your request as soon as possible.</p>
            
            <p style="margin-top: 30px;">
                Best regards,<br>
                <strong>The {site_name} Support Team</strong>
            </p>
        </div>
        
        <div class="footer">
            <p>&copy; <?php echo date('Y'); ?> {site_name}. All rights reserved.</p>
            <p>This email was sent to {customer_email} regarding your support ticket.</p>
            <p><small>Please do not reply directly to this email. Use your customer portal to respond to the ticket.</small></p>
        </div>
    </div>
</body>
</html>
