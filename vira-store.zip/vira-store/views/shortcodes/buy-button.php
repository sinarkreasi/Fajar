<?php
/**
 * Buy Button Shortcode Template
 *
 * This template displays a buy button for a specific product.
 *
 * @package Vira_Store
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Get currency converter for proper integration
$currency_converter = VRSTORE_Currency_Converter::get_instance();
$user_currency = $currency_converter->get_user_currency();
$base_currency = $currency_converter->get_base_currency();

// Validate redirect type
$valid_redirects = array( 'cart', 'checkout' );
if ( ! in_array( $redirect, $valid_redirects, true ) ) {
	$redirect = 'cart';
}

// Get cart and checkout page URLs
$cart_page = get_option( 'vrstore_cart_page' );
$cart_url = $cart_page ? get_permalink( $cart_page ) : home_url();

$checkout_page = get_option( 'vrstore_checkout_page' );
$checkout_url = $checkout_page ? get_permalink( $checkout_page ) : home_url();

// Determine redirect URL based on setting
$redirect_url = ( 'checkout' === $redirect ) ? $checkout_url : $cart_url;

?>
<?php
// Detect post type if not set
if ( ! isset( $post_type ) ) {
	$post_type = get_post_type( $product_id );
}
$is_course = ( 'vrstore_course' === $post_type );

// Check if this is a pre-order product (only for products, not courses)
$is_preorder = false;
$preorder_available = false;
$preorder_message = '';
$preorder_release_date = '';
$preorder_discount = 0;
$preorder_count = 0;
$preorder_limit = 0;
$preorder_released = false;
$preorder_open = false;

if ( ! $is_course && class_exists( 'VRSTORE_Product' ) ) {
	$is_preorder = VRSTORE_Product::is_preorder_product( $product_id );
	$preorder_available = VRSTORE_Product::is_preorder_available( $product_id );
	$preorder_message = VRSTORE_Product::get_preorder_message( $product_id );
	$preorder_release_date = VRSTORE_Product::get_preorder_release_date( $product_id );
	$preorder_discount = get_post_meta( $product_id, '_vrstore_product_preorder_discount', true );
	$preorder_count = VRSTORE_Product::get_preorder_count( $product_id );
	$preorder_limit = get_post_meta( $product_id, '_vrstore_product_preorder_limit', true );
	$preorder_released = $is_preorder ? VRSTORE_Product::is_preorder_released( $product_id ) : false;
	$preorder_open = $is_preorder && $preorder_available && ! $preorder_released;
	
	// Apply pre-order discount to prices if applicable
	if ( $preorder_open && ! empty( $preorder_discount ) && $preorder_discount > 0 ) {
		if ( ! empty( $price ) && is_numeric( $price ) ) {
			$original_price = $price;
			$price = VRSTORE_Product::get_preorder_price( $product_id, $price );
			$display_price = $price;
		}
		if ( ! empty( $sale_price ) && is_numeric( $sale_price ) ) {
			$original_sale_price = $sale_price;
			$sale_price = VRSTORE_Product::get_preorder_price( $product_id, $sale_price );
			$display_sale_price = $sale_price;
		}
		
		// Re-format prices with discount applied
		if ( isset( $display_price ) ) {
			$formatted_price = $currency_converter->format_price( floatval( $display_price ), '', false );
		}
		if ( isset( $display_sale_price ) ) {
			$formatted_sale_price = $currency_converter->format_price( floatval( $display_sale_price ), '', false );
		}
	}
}
?>
<div class="vrstore-buy-button-container" data-product-id="<?php echo esc_attr( $product_id ); ?>" data-post-type="<?php echo esc_attr( $post_type ); ?>" data-is-preorder="<?php echo esc_attr( $preorder_open ? '1' : '0' ); ?>" data-preorder-released="<?php echo esc_attr( $preorder_released ? '1' : '0' ); ?>">
	
	<?php if ( $preorder_open ) : ?>
		<!-- Pre-order Information -->
		<div class="vrstore-preorder-info">
			<h4>
				<i class="dashicons dashicons-clock" style="margin-right: 5px;"></i>
				<?php esc_html_e( 'Pre-order Available', 'vira-store' ); ?>
				<span class="vrstore-preorder-badge"><?php esc_html_e( 'Pre-order', 'vira-store' ); ?></span>
			</h4>
			<p><?php echo wp_kses_post( $preorder_message ); ?></p>
			
			<?php if ( ! empty( $preorder_release_date ) ) : ?>
				<div class="vrstore-preorder-countdown">
					<h4><?php esc_html_e( 'Release Date', 'vira-store' ); ?></h4>
					<div class="countdown-timer" data-release-date="<?php echo esc_attr( $preorder_release_date ); ?>">
						<?php echo esc_html( date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $preorder_release_date ) ) ); ?>
					</div>
				</div>
			<?php endif; ?>
			
			<?php if ( ! empty( $preorder_discount ) && $preorder_discount > 0 ) : ?>
				<div class="vrstore-preorder-discount" style="background: #d4edda; border: 1px solid #c3e6cb; border-radius: 5px; padding: 10px; margin: 10px 0; text-align: center;">
					<strong style="color: #155724;">
						<i class="dashicons dashicons-tag" style="margin-right: 5px;"></i>
						<?php echo sprintf( esc_html__( 'Pre-order Discount: %d%% OFF', 'vira-store' ), $preorder_discount ); ?>
					</strong>
				</div>
			<?php endif; ?>
			
			<?php if ( ! empty( $preorder_limit ) && $preorder_limit > 0 ) : ?>
				<div class="vrstore-preorder-limit" style="font-size: 12px; color: #666; text-align: center; margin: 5px 0;">
					<?php echo sprintf( esc_html__( 'Limited: %d of %d pre-orders available', 'vira-store' ), max( 0, $preorder_limit - $preorder_count ), $preorder_limit ); ?>
				</div>
			<?php endif; ?>
		</div>
	<?php elseif ( $is_preorder && $preorder_released ) : ?>
		<div class="vrstore-preorder-released" style="background: #e3f6ff; border: 1px solid #b6e0fe; border-radius: 5px; padding: 15px; margin: 10px 0; text-align: center;">
			<h4 style="margin: 0 0 10px 0; color: #055160;">
				<i class="dashicons dashicons-yes" style="margin-right: 5px;"></i>
				<?php esc_html_e( 'Now Available', 'vira-store' ); ?>
			</h4>
			<p style="margin: 0; color: #055160;">
				<?php esc_html_e( 'The pre-order period has ended. You can purchase and access this product immediately.', 'vira-store' ); ?>
			</p>
		</div>
	<?php elseif ( $is_preorder && ! $preorder_open && ! $preorder_released ) : ?>
		<!-- Pre-order No Longer Available -->
		<div class="vrstore-preorder-unavailable" style="background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 5px; padding: 15px; margin: 10px 0; text-align: center;">
			<h4 style="margin: 0 0 10px 0; color: #721c24;">
				<i class="dashicons dashicons-warning" style="margin-right: 5px;"></i>
				<?php esc_html_e( 'Pre-order No Longer Available', 'vira-store' ); ?>
			</h4>
			<p style="margin: 0; color: #721c24;">
				<?php 
				if ( ! empty( $preorder_limit ) && $preorder_count >= $preorder_limit ) {
					esc_html_e( 'Pre-order limit has been reached.', 'vira-store' );
				} elseif ( ! empty( $preorder_release_date ) ) {
					esc_html_e( 'The pre-order window has closed ahead of the release date.', 'vira-store' );
				} else {
					esc_html_e( 'Pre-order is no longer available for this product.', 'vira-store' );
				}
				?>
			</p>
		</div>
	<?php endif; ?>

	<?php if ( $show_price && ( ! empty( $formatted_price ) || ! empty( $formatted_sale_price ) ) ) : ?>
		<div class="vrstore-buy-button-price">
			<?php if ( $preorder_open && ! empty( $preorder_discount ) && $preorder_discount > 0 ) : ?>
				<!-- Pre-order pricing with discount -->
				<?php if ( ! empty( $formatted_sale_price ) ) : ?>
					<span class="vrstore-buy-button-original-price" style="text-decoration: line-through; color: #999; font-size: 0.9em;">
						<?php echo esc_html( $currency_converter->format_price( floatval( isset( $original_sale_price ) ? $original_sale_price : $sale_price ), '', false ) ); ?>
					</span>
					<span class="vrstore-buy-button-preorder-price vrstore-price" 
					      data-base-amount="<?php echo esc_attr( isset( $display_sale_price ) ? $display_sale_price : $sale_price ); ?>" 
					      data-base-currency="<?php echo esc_attr( $base_currency ); ?>"
					      style="color: #28a745; font-weight: bold; font-size: 1.1em;">
						<?php echo esc_html( $formatted_sale_price ); ?>
					</span>
				<?php elseif ( ! empty( $formatted_price ) ) : ?>
					<span class="vrstore-buy-button-original-price" style="text-decoration: line-through; color: #999; font-size: 0.9em;">
						<?php echo esc_html( $currency_converter->format_price( floatval( isset( $original_price ) ? $original_price : $price ), '', false ) ); ?>
					</span>
					<span class="vrstore-buy-button-preorder-price vrstore-price" 
					      data-base-amount="<?php echo esc_attr( isset( $display_price ) ? $display_price : $price ); ?>" 
					      data-base-currency="<?php echo esc_attr( $base_currency ); ?>"
					      style="color: #28a745; font-weight: bold; font-size: 1.1em;">
						<?php echo esc_html( $formatted_price ); ?>
					</span>
				<?php endif; ?>
			<?php else : ?>
				<!-- Regular pricing -->
				<?php if ( ! empty( $formatted_sale_price ) ) : ?>
					<span class="vrstore-buy-button-regular-price vrstore-price" 
					      data-base-amount="<?php echo esc_attr( isset( $display_price ) ? $display_price : $price ); ?>" 
					      data-base-currency="<?php echo esc_attr( $base_currency ); ?>"><?php echo esc_html( $formatted_price ); ?></span>
					<span class="vrstore-buy-button-sale-price vrstore-price" 
					      data-base-amount="<?php echo esc_attr( isset( $display_sale_price ) ? $display_sale_price : $sale_price ); ?>" 
					      data-base-currency="<?php echo esc_attr( $base_currency ); ?>"><?php echo esc_html( $formatted_sale_price ); ?></span>
				<?php elseif ( ! empty( $formatted_price ) ) : ?>
					<span class="vrstore-buy-button-price-single vrstore-price" 
					      data-base-amount="<?php echo esc_attr( isset( $display_price ) ? $display_price : $price ); ?>" 
					      data-base-currency="<?php echo esc_attr( $base_currency ); ?>"><?php echo esc_html( $formatted_price ); ?></span>
				<?php endif; ?>
			<?php endif; ?>
		</div>
	<?php endif; ?>

	<div class="vrstore-buy-button-wrapper">
	<?php if ( $is_preorder && ! $preorder_open && ! $preorder_released ) : ?>
			<!-- Pre-order not available - show disabled button -->
			<button 
				class="vrstore-buy-button vrstore-btn vrstore-btn-disabled <?php echo esc_attr( $button_class ); ?>" 
				<?php if ( ! empty( $button_style ) ) : ?>style="<?php echo esc_attr( $button_style ); ?> opacity: 0.6; cursor: not-allowed;"<?php endif; ?>
				disabled
				>
			<?php 
			if ( ! empty( $preorder_limit ) && $preorder_count >= $preorder_limit ) {
				esc_html_e( 'Pre-order limit reached', 'vira-store' );
			} else {
				esc_html_e( 'Pre-order unavailable', 'vira-store' );
			}
			?>
			</button>
		<?php elseif ( ! empty( $selected_license_type ) ) : ?>
			<!-- Fixed license type buy button -->
		<?php 
		// Get license type label for display
			$license_type_label = '';
			if ( ! empty( $custom_license_types ) ) {
				foreach ( $custom_license_types as $type ) {
					$type_slug = isset( $type['slug'] ) ? $type['slug'] : sanitize_title( $type['label'] );
					if ( $type_slug === $selected_license_type ) {
						$license_type_label = $type['label'] ?? ucfirst( $selected_license_type );
						break;
					}
				}
			}
			
			// Adjust button text for pre-order
		$final_button_text = $button_text;
		if ( $preorder_open ) {
				$final_button_text = sprintf( esc_html__( 'Pre-order %s', 'vira-store' ), $button_text );
			}
			?>
		<button 
			class="vrstore-buy-button vrstore-btn vrstore-btn-primary <?php echo esc_attr( $button_class ); ?> <?php echo $preorder_open ? 'vrstore-preorder-button' : ''; ?>" 
				<?php if ( ! empty( $button_style ) ) : ?>style="<?php echo esc_attr( $button_style ); ?>"<?php endif; ?>
				data-product-id="<?php echo esc_attr( $product_id ); ?>"
				data-license-type="<?php echo esc_attr( $selected_license_type ); ?>"
				data-redirect="<?php echo esc_attr( $redirect ); ?>"
				data-redirect-url="<?php echo esc_url( $redirect_url ); ?>"
			data-adding-text="<?php echo esc_attr( $preorder_open ? __( 'Adding Pre-order...', 'vira-store' ) : __( 'Adding...', 'vira-store' ) ); ?>"
				data-original-text="<?php echo esc_attr( $final_button_text ); ?>"
			data-is-preorder="<?php echo esc_attr( $preorder_open ? '1' : '0' ); ?>"
				>
				<?php echo esc_html( $final_button_text ); ?>
			</button>
		<?php elseif ( ! empty( $custom_license_types ) && count( $custom_license_types ) > 1 ) : ?>
			<!-- Multiple license types - show dropdown and button -->
			<div class="vrstore-buy-button-license-selection">
				<select 
					class="vrstore-buy-button-license-dropdown"
					data-product-id="<?php echo esc_attr( $product_id ); ?>"
					data-currency-symbol="<?php echo esc_attr( $currency_symbol ); ?>"
					data-currency-position="<?php echo esc_attr( $settings ? $settings->get_setting( 'currency_position', 'left' ) : 'left' ); ?>"
					data-decimal-separator="<?php echo esc_attr( $settings ? $settings->get_setting( 'decimal_separator', '.' ) : '.' ); ?>"
					data-thousand-separator="<?php echo esc_attr( $settings ? $settings->get_setting( 'thousand_separator', ',' ) : ',' ); ?>"
					data-decimals="<?php echo esc_attr( $settings ? $settings->get_setting( 'decimal_number', 2 ) : 2 ); ?>"
					data-current-currency="<?php echo esc_attr( $user_currency ); ?>"
					data-base-currency="<?php echo esc_attr( $base_currency ); ?>"
					>
					<?php foreach ( $custom_license_types as $type ) : 
						$type_slug = isset( $type['slug'] ) ? $type['slug'] : sanitize_title( $type['label'] );
						$type_label = $type['label'] ?? ucfirst( $type_slug );
						
						// Get pricing for this license type
						$license_price = null;
						$license_sale_price = null;
						
						// Check for per-product license pricing override
						if ( isset( $license_pricing_data[ $type_slug ] ) && is_array( $license_pricing_data[ $type_slug ] ) ) {
							$license_price = $license_pricing_data[ $type_slug ]['price'] ?? $price;
							$license_sale_price = $license_pricing_data[ $type_slug ]['sale_price'] ?? $sale_price;
						} elseif ( isset( $custom_license_pricing[ $type_slug ] ) && is_array( $custom_license_pricing[ $type_slug ] ) ) {
							$license_price = $custom_license_pricing[ $type_slug ]['price'] ?? $price;
							$license_sale_price = $custom_license_pricing[ $type_slug ]['sale_price'] ?? $sale_price;
						} else {
							$license_price = $type['regular_price'] ?? $price;
							$license_sale_price = $type['sale_price'] ?? $sale_price;
						}
						
						// Format the display price for the dropdown option - use same approach as product.php
						$price_text = '';
						if ( $license_price !== null && is_numeric( $license_price ) ) {
							$price_to_use = ( ! empty( $license_sale_price ) && is_numeric( $license_sale_price ) ) ? $license_sale_price : $license_price;
							// Use same approach as product.php - single format_price call
							$price_text = $currency_converter->format_price( floatval( $price_to_use ), '', false );
						}
						
						$display_text = $type_label;
						if ( ! empty( $price_text ) ) {
							$display_text .= ' - ' . $price_text;
						}
					?>
						<option 
							value="<?php echo esc_attr( $type_slug ); ?>"
							data-price="<?php echo esc_attr( $license_price !== null ? $license_price : $price ); ?>"
							data-sale-price="<?php echo esc_attr( $license_sale_price !== null ? $license_sale_price : '' ); ?>"
							>
							<?php echo esc_html( $display_text ); ?>
						</option>
					<?php endforeach; ?>
				</select>
				
	<?php
	// Adjust button text for pre-order
	$final_button_text = $button_text;
	if ( $preorder_open ) {
		$final_button_text = sprintf( esc_html__( 'Pre-order %s', 'vira-store' ), $button_text );
	}
	?>
	<button
		class="vrstore-buy-button vrstore-btn vrstore-btn-primary <?php echo esc_attr( $button_class ); ?> <?php echo $preorder_open ? 'vrstore-preorder-button' : ''; ?>"
		<?php if ( ! empty( $button_style ) ) : ?>style="<?php echo esc_attr( $button_style ); ?>"<?php endif; ?>
		data-product-id="<?php echo esc_attr( $product_id ); ?>"
		data-redirect="<?php echo esc_attr( $redirect ); ?>"
		data-redirect-url="<?php echo esc_url( $redirect_url ); ?>"
		data-adding-text="<?php echo esc_attr( $preorder_open ? __( 'Adding Pre-order...', 'vira-store' ) : __( 'Adding...', 'vira-store' ) ); ?>"
		data-original-text="<?php echo esc_attr( $final_button_text ); ?>"
		data-is-preorder="<?php echo esc_attr( $preorder_open ? '1' : '0' ); ?>"
	>
		<?php echo esc_html( $final_button_text ); ?>
	</button>
			</div>
		<?php else : ?>
			<!-- Simple buy button (no license types or single license type) -->
	<?php
	// Adjust button text for pre-order
	$final_button_text = $button_text;
	if ( $preorder_open ) {
				$final_button_text = sprintf( esc_html__( 'Pre-order %s', 'vira-store' ), $button_text );
			}
			?>
			<button 
		class="vrstore-buy-button vrstore-btn vrstore-btn-primary <?php echo esc_attr( $button_class ); ?> <?php echo $preorder_open ? 'vrstore-preorder-button' : ''; ?>" 
				<?php if ( ! empty( $button_style ) ) : ?>style="<?php echo esc_attr( $button_style ); ?>"<?php endif; ?>
				data-product-id="<?php echo esc_attr( $product_id ); ?>"
				data-redirect="<?php echo esc_attr( $redirect ); ?>"
				data-redirect-url="<?php echo esc_url( $redirect_url ); ?>"
		data-adding-text="<?php echo esc_attr( $preorder_open ? __( 'Adding Pre-order...', 'vira-store' ) : __( 'Adding...', 'vira-store' ) ); ?>"
				data-original-text="<?php echo esc_attr( $final_button_text ); ?>"
		data-is-preorder="<?php echo esc_attr( $preorder_open ? '1' : '0' ); ?>"
				>
				<?php echo esc_html( $final_button_text ); ?>
			</button>
		<?php endif; ?>
	</div>
	
	<!-- Loading indicator -->
	<div class="vrstore-buy-button-loading" style="display: none;">
		<span class="vrstore-spinner"></span>
		<?php echo esc_html( $preorder_open ? __( 'Adding pre-order to cart...', 'vira-store' ) : __( 'Adding to cart...', 'vira-store' ) ); ?>
	</div>
</div>

<?php if ( $preorder_open && ! empty( $preorder_release_date ) ) : ?>
<!-- Pre-order Countdown Script -->
<script>
jQuery(document).ready(function($) {
	var releaseDate = '<?php echo esc_js( $preorder_release_date ); ?>';
	var $countdown = $('.countdown-timer[data-release-date="' + releaseDate + '"]');
	
	if ($countdown.length && releaseDate) {
		var targetDate = new Date(releaseDate).getTime();
		
		function updateCountdown() {
			var now = new Date().getTime();
			var distance = targetDate - now;
			
			if (distance < 0) {
				$countdown.html('<?php esc_html_e( 'Released!', 'vira-store' ); ?>');
				// Optionally reload the page to update the button state
				setTimeout(function() {
					location.reload();
				}, 2000);
				return;
			}
			
			var days = Math.floor(distance / (1000 * 60 * 60 * 24));
			var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
			var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
			var seconds = Math.floor((distance % (1000 * 60)) / 1000);
			
			var countdownText = '';
			if (days > 0) {
				countdownText += days + 'd ';
			}
			if (hours > 0 || days > 0) {
				countdownText += hours + 'h ';
			}
			if (minutes > 0 || hours > 0 || days > 0) {
				countdownText += minutes + 'm ';
			}
			countdownText += seconds + 's';
			
			$countdown.html(countdownText);
		}
		
		// Update immediately and then every second
		updateCountdown();
		setInterval(updateCountdown, 1000);
	}
});
</script>
<?php endif; ?>
