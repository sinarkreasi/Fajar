<?php
/**
 * Thank You page template.
 *
 * @package Vira_Store
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Define untranslated strings for thank you template
if ( ! defined( 'VRSTORE_THANKYOU_LABELS' ) ) {
	define( 'VRSTORE_THANKYOU_LABELS', [
		'thank_you_title' => 'Thank You for Your Purchase!',
		'thank_you_message' => 'Your order has been received and is now being processed.',
		'order_details' => 'Order Details',
		'order_number' => 'Order Number:',
		'date' => 'Date:',
		'total' => 'Total:',
		'payment_method' => 'Payment Method:',
		'status' => 'Status:',
		'product' => 'Product',
		'download_product' => 'Download Product',
		'license_information' => 'License Information',
		'license_key' => 'License Key:',
		'activations' => 'Activations:',
		'expiry_date' => 'Expiry Date:',
		'never' => 'Never',
		'how_to_use_license' => 'How to Use Your License',
		'install_product' => 'Install the product on your website.',
		'navigate_license_page' => 'Navigate to the license activation page.',
		'enter_license_activate' => 'Enter your license key and activate it.',
		'enjoy_features' => 'Enjoy all premium features and updates!',
		'view_account' => 'View Your Account',
		'browse_products' => 'Browse More Products',
		'order_not_found' => 'Order Not Found',
		'order_not_found_message' => 'Sorry, we could not find your order. Please contact support if you believe this is an error.',
		'return_home' => 'Return to Home',
	]);
}

if ( ! function_exists( 'vrstore_get_thankyou_labels_translated' ) ) {
	function vrstore_get_thankyou_labels_translated() {
		$translated = [];
		foreach ( VRSTORE_THANKYOU_LABELS as $key => $label ) {
			$translated[ $key ] = is_textdomain_loaded('vira-store') ? esc_html__( $label, 'vira-store' ) : esc_html( $label );
		}
		return $translated;
	}
}
$thankyou_labels = vrstore_get_thankyou_labels_translated();
// Variables available: $order_id, $order_data, $license_data, $currency_converter.
// Get user currency from the currency converter instance that was passed from shortcode
$user_currency = $currency_converter->get_user_currency();
$product_instance = VRSTORE_Product::get_instance();
$currency_symbol = $product_instance->get_currency_symbol( $user_currency );

// Enhanced debugging for Extended Support currency issues
if ( ! empty( $order_data ) ) {
	// Always show debug info for Extended Support issues (not just WP_DEBUG)
	echo "<!-- VR Store Debug Info -->";
	echo "<!-- User Currency: {$user_currency} -->";
	echo "<!-- Order Currency: {$order_data['currency']} -->";
	echo "<!-- Raw Order Price: {$order_data['price']} -->";
	echo "<!-- Product Title: {$order_data['product_title']} -->";
	echo "<!-- Product ID: {$order_data['product_id']} -->";
	
	// Enhanced Extended Support detection
	$is_extended_support_debug = (
		($order_data['product_id'] == 0 || is_string($order_data['product_id'])) && 
		!empty($order_data['product_title']) && 
		strpos($order_data['product_title'], 'Extended Support') !== false
	);
	echo "<!-- Extended Support Detected: " . ($is_extended_support_debug ? 'YES' : 'NO') . " -->";
	
	// Show what conversion would happen
	if ($is_extended_support_debug) {
		echo "<!-- Extended Support: Will format {$order_data['price']} as {$order_data['currency']} -->";
		$test_formatted = $currency_converter->format_converted_price( floatval($order_data['price']), $order_data['currency'] );
		echo "<!-- Extended Support: Formatted result: {$test_formatted} -->";
	} else {
		echo "<!-- Regular Order: Currency matching logic will apply -->";
	}
	echo "<!-- End Debug Info -->";
	
	// Debug information only shown in HTML comments (not visible to users)
	if ($is_extended_support_debug && defined('WP_DEBUG') && WP_DEBUG) {
		echo "<!-- Extended Support Debug Info: Raw Price: {$order_data['price']}, Order Currency: {$order_data['currency']}, User Currency: {$user_currency} -->";
	}
}
?>
<div class="vrstore-thank-you-container">
	<?php if ( ! empty( $order_data ) ) : ?>
		<div class="vrstore-thank-you-header">
			<h1 class="vrstore-thank-you-title"><?php echo $thankyou_labels['thank_you_title']; ?></h1>
			<p class="vrstore-thank-you-message"><?php echo $thankyou_labels['thank_you_message']; ?></p>
			
			<?php
			// Check if account was created during checkout using session manager
			$checkout_completed = false;
			if (class_exists('VRSTORE_Session_Manager')) {
				$session_manager = VRSTORE_Session_Manager::get_instance();
				$checkout_completed = $session_manager->get_session_data('vrstore_checkout_completed', false);
				if ($checkout_completed) {
					// Clear the flag
					$session_manager->set_session_data('vrstore_checkout_completed', null);
				}
			} else {
				// Fallback using global helper functions
				$checkout_completed = vrstore_get_session_data('vrstore_checkout_completed', false);
				if ($checkout_completed) {
					vrstore_set_session_data('vrstore_checkout_completed', null);
				}
			}
			
			if ($checkout_completed) {
				
				$checkout_completed_message = is_textdomain_loaded('vira-store') 
					? __('🎉 Checkout completed successfully!', 'vira-store')
					: '🎉 Checkout completed successfully!';
				?>
				<div class="vrstore-checkout-completed-notice">
					<p><?php echo esc_html($checkout_completed_message); ?></p>
					<p>You can now access your customer portal to manage your licenses and downloads.</p>
				</div>
				<?php
			}
			?>
		</div>
		
		<div class="vrstore-order-details">
			<h2><?php echo $thankyou_labels['order_details']; ?></h2>
			
			<div class="vrstore-order-info vrstore-order-info-grid">
				<!-- First Row: Order Number | Date -->
				<div class="vrstore-order-info-row">
					<div class="vrstore-order-info-item">
						<span class="vrstore-order-info-label"><?php echo $thankyou_labels['order_number']; ?></span>
						<span class="vrstore-order-info-value"><?php echo esc_html( !empty($order_data['order_number']) ? $order_data['order_number'] : $order_data['id'] ); ?></span>
					</div>
					
					<div class="vrstore-order-info-item">
						<span class="vrstore-order-info-label"><?php echo $thankyou_labels['date']; ?></span>
						<span class="vrstore-order-info-value"><?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $order_data['date'] ) ) ); ?></span>
					</div>
				</div>
				
				<!-- Second Row: Total | Status -->
				<div class="vrstore-order-info-row">
					<div class="vrstore-order-info-item">
						<span class="vrstore-order-info-label"><?php echo $thankyou_labels['total']; ?></span>
						<span class="vrstore-order-info-value"><?php 
							// Detect Extended Support orders by checking product_id and product_title
							$is_extended_support = (
								($order_data['product_id'] == 0 || is_string($order_data['product_id'])) && 
								!empty($order_data['product_title']) && 
								strpos($order_data['product_title'], 'Extended Support') !== false
							);
							
							$order_currency = isset($order_data['currency']) ? $order_data['currency'] : 'USD';
							$order_price = floatval( $order_data['price'] );
							
						// Extended Support orders: try different formatting approach to avoid double conversion
						if ( $is_extended_support ) {
							// Extended Support prices are already converted and stored in the order's currency
							// Use the currency converter's format_converted_price to display in the stored currency
							$formatted_price = $currency_converter->format_converted_price( $order_price, $order_currency );
							echo esc_html( $formatted_price );
							echo "<!-- Extended Support: Used format_converted_price({$order_price}, {$order_currency}) = {$formatted_price} -->";
						} else {
								// Regular orders: check if conversion is needed
								if ( $order_currency === $user_currency ) {
									// Order is already in user currency, just format without conversion
									echo esc_html( $currency_converter->format_converted_price( $order_price, $user_currency ) );
								} else {
									// Order is in different currency, convert from order currency to user currency
									$converted_price = $currency_converter->convert_amount( $order_price, $order_currency, $user_currency );
									echo esc_html( $currency_converter->format_converted_price( $converted_price, $user_currency ) );
								}
							}
						?></span>
					</div>
					
					<div class="vrstore-order-info-item">
						<span class="vrstore-order-info-label"><?php echo $thankyou_labels['status']; ?></span>
						<span class="vrstore-order-info-value">
							<span class="vrstore-order-status vrstore-order-status-<?php echo esc_attr( strtolower( $order_data['status'] ) ); ?>">
								<?php echo esc_html( $order_data['status'] ); ?>
							</span>
						</span>
					</div>
				</div>
				
				<!-- Third Row: Payment Method (full width) -->
				<div class="vrstore-order-info-row vrstore-order-info-row-full">
					<div class="vrstore-order-info-item">
						<span class="vrstore-order-info-label"><?php echo $thankyou_labels['payment_method']; ?></span>
						<span class="vrstore-order-info-value">
							<?php
							// Get payment method display name
							$payment_methods = [
								'tripay' => is_textdomain_loaded('vira-store') ? __('TriPay', 'vira-store') : 'TriPay',
								'manual' => is_textdomain_loaded('vira-store') ? __('Transfer Bank', 'vira-store') : 'Transfer Bank'
							];
							
							$payment_method_name = '';
							if (class_exists('VRSTORE_Payment')) {
								$payment = VRSTORE_Payment::get_instance();
								$gateways = $payment->get_available_gateways();
								if ( isset( $gateways[ $order_data['payment_gateway'] ] ) ) {
									$payment_method_name = $gateways[ $order_data['payment_gateway'] ]['name'];
								} elseif ( isset( $payment_methods[ $order_data['payment_gateway'] ] ) ) {
									$payment_method_name = $payment_methods[ $order_data['payment_gateway'] ];
								} else {
									$payment_method_name = ucfirst( $order_data['payment_gateway'] );
								}
							} elseif ( isset( $payment_methods[ $order_data['payment_gateway'] ] ) ) {
								$payment_method_name = $payment_methods[ $order_data['payment_gateway'] ];
							} else {
								$payment_method_name = ucfirst( $order_data['payment_gateway'] );
							}
							
							// Display payment method with toggle link for Transfer Bank
							if ( 'manual' === $order_data['payment_gateway'] ) {
								echo '<span class="vrstore-bank-details-toggle" style="color: var(--vrstore-primary); cursor: pointer; text-decoration: underline;">' . esc_html( $payment_method_name ) . ' <span class="dashicons dashicons-arrow-down-alt2" style="font-size: 14px; vertical-align: middle;"></span></span>';
							} else {
								echo esc_html( $payment_method_name );
							}
							?>
						</span>
					</div>
				</div>
			</div>
			
			<div class="vrstore-order-product">
				<h3><?php echo $thankyou_labels['product']; ?></h3>
				<div class="vrstore-order-product-item">
					<div class="vrstore-order-product-name">
						<?php echo esc_html( $order_data['product_title'] ); ?>
					</div>
					<div class="vrstore-order-product-price">
						<?php 
						// Detect Extended Support orders by checking product_id and product_title
						$is_extended_support = (
							($order_data['product_id'] == 0 || is_string($order_data['product_id'])) && 
							!empty($order_data['product_title']) && 
							strpos($order_data['product_title'], 'Extended Support') !== false
						);
						
						$order_currency = isset($order_data['currency']) ? $order_data['currency'] : 'USD';
						$order_price = floatval( $order_data['price'] );
						
						// Extended Support orders: try different formatting approach to avoid double conversion
						if ( $is_extended_support ) {
							// Extended Support prices are already converted and stored in the order's currency
							// Use the currency converter's format_converted_price to display in the stored currency
							$formatted_price = $currency_converter->format_converted_price( $order_price, $order_currency );
							echo esc_html( $formatted_price );
							echo "<!-- Extended Support Product: Used format_converted_price({$order_price}, {$order_currency}) = {$formatted_price} -->";
						} else {
							// Regular orders: check if conversion is needed
							if ( $order_currency === $user_currency ) {
								// Order is already in user currency, just format without conversion
								echo esc_html( $currency_converter->format_converted_price( $order_price, $user_currency ) );
							} else {
								// Order is in different currency, convert from order currency to user currency
								$converted_price = $currency_converter->convert_amount( $order_price, $order_currency, $user_currency );
								echo esc_html( $currency_converter->format_converted_price( $converted_price, $user_currency ) );
							}
						}
						?>
					</div>
				</div>
				
	<?php else : ?>
		<div class="vrstore-error-message vrstore-card vrstore-text-center vrstore-p-8">
			<h2 class="vrstore-text-xl vrstore-font-bold vrstore-text-red-600 vrstore-mb-4"><?php echo $thankyou_labels['order_not_found']; ?></h2>
			<p class="vrstore-text-gray-600"><?php echo $thankyou_labels['order_not_found_message']; ?></p>
			<div class="vrstore-thank-you-actions vrstore-mt-6">
				<a href="<?php echo esc_url( home_url() ); ?>" class="vrstore-btn vrstore-btn-primary vrstore-btn-lg">
					<?php echo $thankyou_labels['return_home']; ?>
				</a>
			</div>
		</div>
	<?php endif; ?>
	
<?php if ( ! empty( $order_data ) && 'manual' === $order_data['payment_gateway'] ) :
// Bank Details for Transfer Bank Payment Method - Simplified version
// Get settings from main vrstore_settings option
$vrstore_settings = get_option( 'vrstore_settings', array() );

// Extract simplified bank details from settings
$bank_details = !empty($vrstore_settings['manual_bank_details']) ? $vrstore_settings['manual_bank_details'] : '';
$additional_info = !empty($vrstore_settings['manual_additional_info']) ? $vrstore_settings['manual_additional_info'] : '';
$whatsapp_number = !empty($vrstore_settings['manual_whatsapp_number']) ? $vrstore_settings['manual_whatsapp_number'] : '';

// Prepare WhatsApp message with order details
$whatsapp_message = '';
if ( ! empty( $whatsapp_number ) ) {
	$order_reference = !empty($order_data['order_number']) ? $order_data['order_number'] : $order_data['id'];
	$product_title = !empty($order_data['product_title']) ? $order_data['product_title'] : 'Product';
	$order_total = !empty($order_data['price']) ? $order_data['price'] : '0';
	$order_currency = !empty($order_data['currency']) ? $order_data['currency'] : 'USD';
	
	$whatsapp_text = sprintf(
		'Hi! I have completed a bank transfer for my order. Order Reference: %s | Product: %s | Amount: %s %s | Please confirm my payment.',
		$order_reference,
		$product_title,
		$order_total,
		$order_currency
	);
	$whatsapp_message = 'https://wa.me/' . preg_replace('/[^0-9]/', '', $whatsapp_number) . '?text=' . urlencode($whatsapp_text);
}
?>

	<!-- Bank Transfer Details - Simplified version -->
	<div id="vrstore-bank-details" class="vrstore-bank-transfer-details" style="display: none; margin-top: var(--vrstore-space-lg); text-align: center;">
			<?php if ( ! empty( $bank_details ) ) : ?>
				<div class="vrstore-bank-account-section">
					<div class="vrstore-bank-details-grid">
						<div class="vrstore-bank-detail-item vrstore-bank-details-main">
							<span class="vrstore-bank-detail-label"><?php echo is_textdomain_loaded('vira-store') ? esc_html__('Bank Details:', 'vira-store') : esc_html('Bank Details:'); ?></span>
							<center><span class="vrstore-bank-detail-value"><?php echo esc_html( $bank_details ); ?></span></center>
							<button class="vrstore-copy-btn" data-copy="<?php echo esc_attr( $bank_details ); ?>" title="<?php echo is_textdomain_loaded('vira-store') ? esc_attr__('Copy to clipboard', 'vira-store') : esc_attr('Copy to clipboard'); ?>">
								<span class="dashicons dashicons-admin-page"></span>
							</button>
						</div>
					</div>
				</div>
			<?php endif; ?>
			
			<div class="vrstore-order-reference-section">
				<div class="vrstore-order-reference">
					<div class="vrstore-reference-content">
						<div class="vrstore-reference-label">
							<span class="dashicons dashicons-tag"></span>
							<strong><?php echo is_textdomain_loaded('vira-store') ? esc_html__('Order Reference (Use in Bank Transfer):', 'vira-store') : esc_html('Order Reference (Use in Bank Transfer):'); ?></strong>
						</div>
						<?php
						// Use the actual order number from database for bank transfer reference
						$display_order_id = !empty($order_data['order_number']) ? $order_data['order_number'] : $order_data['id'];
						?>
						<div class="vrstore-reference-value">
							<span class="vrstore-order-id"><?php echo esc_html( $display_order_id ); ?></span>
							<button class="vrstore-copy-btn" data-copy="<?php echo esc_attr( $display_order_id ); ?>" title="<?php echo is_textdomain_loaded('vira-store') ? esc_attr__('Copy Order Reference', 'vira-store') : esc_attr('Copy Order Reference'); ?>">
								<span class="dashicons dashicons-admin-page"></span>
							</button>
						</div>
					</div>
					<div class="vrstore-reference-note">
						<small><?php echo is_textdomain_loaded('vira-store') ? esc_html__('💡 Include this reference in your bank transfer memo/description', 'vira-store') : esc_html('💡 Include this reference in your bank transfer memo/description'); ?></small>
					</div>
					
					<?php if ( ! empty( $whatsapp_message ) ) : ?>
						<div class="vrstore-whatsapp-button-container" style="margin-top: 15px; padding-top: 15px; border-top: 1px solid #e0e0e0;">
							<p class="vrstore-whatsapp-description" style="margin-bottom: 10px; font-size: 14px;">
								<?php echo is_textdomain_loaded('vira-store') ? esc_html__('After completing your bank transfer, please confirm via WhatsApp below:', 'vira-store') : esc_html('After completing your bank transfer, please confirm via WhatsApp below:'); ?>
							</p>
							<a href="<?php echo esc_url( $whatsapp_message ); ?>" target="_blank" class="vrstore-whatsapp-btn vrstore-btn vrstore-btn-success">
								<span class="vrstore-whatsapp-icon">💬</span>
								<?php echo is_textdomain_loaded('vira-store') ? esc_html__('Confirm Payment via WhatsApp', 'vira-store') : esc_html('Confirm Payment via WhatsApp'); ?>
							</a></div><hr>
							<?php echo wp_kses_post( nl2br( $additional_info ) ); ?>
						<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
<?php endif; ?>
</div>