<?php
/**
 * Account shortcode template.
 *
 * @package Vira_Store
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Check for success message from checkout
$success_message = '';
if (isset($_GET['vrstore_success']) && !empty($_GET['vrstore_success'])) {
    $success_message = sanitize_text_field(urldecode($_GET['vrstore_success']));
}

// Check if account was just created during checkout
$checkout_completed = isset($_GET['vrstore_checkout_completed']) && $_GET['vrstore_checkout_completed'] === '1';

// Display success message if available
if (!empty($success_message)) {
    echo '<div class="vrstore-success-message">' . esc_html($success_message) . '</div>';
}

// Display checkout completion message if applicable
if ($checkout_completed) {
    echo '<div class="vrstore-checkout-completed-message">' . (vrstore_is_textdomain_ready() ? esc_html__('Checkout completed successfully!', 'vira-store') : esc_html('Checkout completed successfully!')) . '</div>';
}

// Variables available: $user_id, $purchases, $licenses.

// Get user data.
$user = get_userdata( $user_id );

if ( ! $user ) {
	return;
}

// Get product instance for formatting functions
$product_instance = VRSTORE_Product::get_instance();

// Get global currency setting for fallback
$settings = VRSTORE_Settings::get_instance();
// Use base currency for customer account
$global_currency = $settings ? $settings->get_setting('currency', 'USD') : 'USD';
?>
<!-- VRSTORE: Nonce for AJAX security -->
<meta name="vrstore-nonce" content="<?php echo wp_create_nonce( 'vrstore_frontend_nonce' ); ?>">
<input type="hidden" id="vrstore-nonce" name="vrstore_nonce" value="<?php echo wp_create_nonce( 'vrstore_frontend_nonce' ); ?>">

<?php
// JavaScript functionality moved to assets/js/frontend.js for better performance and maintainability
// Domain timestamp refresh is now handled externally
?>

<div class="vrstore-account-container vrstore-animate-fade-in">
	
	<?php if ( isset( $_GET['account_updated'] ) && 'true' === $_GET['account_updated'] ) : ?>
	<div class="vrstore-message vrstore-message-success">
		<p><?php esc_html_e( 'Your account information has been updated successfully.', 'vira-store' ); ?></p>
	</div>
	<?php endif; ?>
	
	<div class="vrstore-account-tabs vrstore-mb-6">
		<div class="vrstore-tabs-nav">
			<a href="#dashboard" class="vrstore-btn vrstore-btn-tab active"><?php echo isset($account_labels['tab_dashboard']) ? $account_labels['tab_dashboard'] : (vrstore_is_textdomain_ready() ? __( 'Dashboard', 'vira-store' ) : 'Dashboard'); ?></a>
			<a href="#purchases" class="vrstore-btn vrstore-btn-tab"><?php echo $account_labels['tab_purchases']; ?></a>
			<a href="#licenses" class="vrstore-btn vrstore-btn-tab"><?php echo $account_labels['tab_licenses']; ?></a>
			<a href="#resources" class="vrstore-btn vrstore-btn-tab"><?php echo vrstore_is_textdomain_ready() ? __( 'Resources', 'vira-store' ) : 'Resources'; ?></a>
			<a href="#support" class="vrstore-btn vrstore-btn-tab"><?php echo vrstore_is_textdomain_ready() ? __( 'Support', 'vira-store' ) : 'Support'; ?></a>
		</div>
		
		<div class="vrstore-tabs-content">
			<div id="dashboard" class="vrstore-tab-content vrstore-tab-active">
				<div class="vrstore-dashboard-overview">
					<div class="vrstore-dashboard-stats vrstore-grid vrstore-grid-cols-1 vrstore-md:grid-cols-3 vrstore-gap-6 vrstore-mb-8">
					<div class="vrstore-stat-card vrstore-card vrstore-p-4 vrstore-text-center">
						<div class="vrstore-stat-icon vrstore-mb-3">
							<span class="dashicons dashicons-cart vrstore-text-primary vrstore-text-2xl"></span>
						</div>
						<div class="vrstore-stat-content">
							<h3 class="vrstore-text-2xl vrstore-font-bold vrstore-mb-1"><?php echo esc_html( count( $purchases ) ); ?></h3>
							<p class="vrstore-text-gray-600"><?php echo vrstore_is_textdomain_ready() ? esc_html__( 'Total Purchases', 'vira-store' ) : 'Total Purchases'; ?></p>
						</div>
					</div>
						
						<div class="vrstore-stat-card vrstore-card vrstore-p-4 vrstore-text-center">
							<div class="vrstore-stat-icon vrstore-mb-3">
								<span class="dashicons dashicons-admin-network vrstore-text-primary vrstore-text-2xl"></span>
							</div>
							<div class="vrstore-stat-content">
								<h3 class="vrstore-text-2xl vrstore-font-bold vrstore-mb-1"><?php echo esc_html( count( $licenses ) ); ?></h3>
								<p class="vrstore-text-gray-600"><?php echo vrstore_is_textdomain_ready() ? esc_html__( 'Active Licenses', 'vira-store' ) : 'Active Licenses'; ?></p>
							</div>
						</div>
						
						<?php 
						// Calculate total spent
						$total_spent = 0;
						foreach ( $purchases as $purchase ) {
							if ( isset( $purchase['total'] ) && ( !isset( $purchase['status'] ) || strtolower( $purchase['status'] ) === 'completed' ) ) {
								$total_spent += floatval( $purchase['total'] );
							}
						}
						
						// Convert total spent to user's currency
						$user_currency = $currency_converter->get_user_currency();
						$converted_total_spent = 0;
						foreach ( $purchases as $purchase ) {
							if ( isset( $purchase['total'] ) && ( !isset( $purchase['status'] ) || strtolower( $purchase['status'] ) === 'completed' ) ) {
								$purchase_currency = $purchase['currency'] ?? $currency_converter->get_base_currency();
								$converted_amount = $currency_converter->convert_amount(
									floatval( $purchase['total'] ), 
									$purchase_currency, 
									$user_currency
								);
								$converted_total_spent += $converted_amount;
							}
						}
						?>
						<div class="vrstore-stat-card vrstore-card vrstore-p-4 vrstore-text-center">
							<div class="vrstore-stat-icon vrstore-mb-3">
								<span class="dashicons dashicons-money-alt vrstore-text-primary vrstore-text-2xl"></span>
							</div>
							<div class="vrstore-stat-content">
								<h3 class="vrstore-text-2xl vrstore-font-bold vrstore-mb-1"><?php echo esc_html( $currency_converter->format_converted_price( $converted_total_spent ) ); ?></h3>
								<p class="vrstore-text-gray-600"><?php echo vrstore_is_textdomain_ready() ? esc_html__( 'Total Spent', 'vira-store' ) : 'Total Spent'; ?></p>
							</div>
						</div>
					</div>
					
					<div class="vrstore-dashboard-sections vrstore-grid vrstore-grid-cols-1 vrstore-lg:grid-cols-2 vrstore-gap-6">
						<div class="vrstore-dashboard-section vrstore-card vrstore-p-6">
							<h3 class="vrstore-text-lg vrstore-font-semibold vrstore-mb-4"><?php echo vrstore_is_textdomain_ready() ? esc_html__( 'Recent Purchases', 'vira-store' ) : 'Recent Purchases'; ?></h3>
							<?php if ( ! empty( $purchases ) ) : ?>
								<div class="vrstore-dashboard-purchases vrstore-space-y-3">
									<?php 
									// Show only the 3 most recent purchases
									$recent_purchases = array_slice( $purchases, 0, 3 );
									foreach ( $recent_purchases as $purchase ) : ?>
										<div class="vrstore-dashboard-purchase-item vrstore-border vrstore-border-gray-200 vrstore-rounded-lg vrstore-p-4">
											<div class="vrstore-purchase-info">
												<h4 class="vrstore-font-medium vrstore-mb-2"><?php echo esc_html( $purchase['product_title'] ?? (vrstore_is_textdomain_ready() ? __( 'Unknown Product', 'vira-store' ) : 'Unknown Product') ); ?></h4>
												<div class="vrstore-purchase-meta vrstore-flex vrstore-gap-4 vrstore-text-sm vrstore-text-gray-600">
													<span class="vrstore-purchase-date">
														<?php 
														if ( ! empty( $purchase['date'] ) ) {
															echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $purchase['date'] ) ) );
														} else {
															echo vrstore_is_textdomain_ready() ? esc_html__( 'N/A', 'vira-store' ) : esc_html( 'N/A' );
														}
														?>
													</span>
													<span class="vrstore-purchase-price">
														<?php 
														$purchase_currency = $purchase['currency'] ?? $currency_converter->get_base_currency();
														$user_currency = $currency_converter->get_user_currency();
														$converted_purchase_total = $currency_converter->convert_amount(
															floatval($purchase['total']), 
															$purchase_currency, 
															$user_currency
														);
														echo esc_html($currency_converter->format_converted_price($converted_purchase_total, $user_currency));
														?>
													</span>
												</div>
											</div>
											<div class="vrstore-purchase-status vrstore-mt-2">
												<span class="vrstore-order-status vrstore-badge vrstore-order-status-<?php echo esc_attr( strtolower( $purchase['status'] ?? 'unknown' ) ); ?>">
													<?php echo esc_html( ucfirst( $purchase['status'] ?? (is_textdomain_loaded('vira-store') ? __( 'Unknown', 'vira-store' ) : 'Unknown') ) ); ?>
												</span>
											</div>
										</div>
									<?php endforeach; ?>
								</div>
								<div class="vrstore-dashboard-actions vrstore-mt-4">
									<a href="#purchases" class="vrstore-btn vrstore-btn-secondary vrstore-btn-sm">
										<?php echo is_textdomain_loaded('vira-store') ? esc_html__( 'View All Purchases', 'vira-store' ) : 'View All Purchases'; ?>
									</a>
								</div>
							<?php else : ?>
								<div class="vrstore-dashboard-empty vrstore-text-center vrstore-p-8">
									<p class="vrstore-text-gray-600"><?php echo is_textdomain_loaded('vira-store') ? esc_html__( 'No purchases yet.', 'vira-store' ) : 'No purchases yet.'; ?></p>
								</div>
							<?php endif; ?>
						</div>
						
						<div class="vrstore-dashboard-section vrstore-card vrstore-p-6">
							<h3 class="vrstore-text-lg vrstore-font-semibold vrstore-mb-4"><?php echo is_textdomain_loaded('vira-store') ? esc_html__( 'Active Licenses', 'vira-store' ) : 'Active Licenses'; ?></h3>
							<?php if ( ! empty( $licenses ) ) : ?>
								<div class="vrstore-dashboard-licenses vrstore-space-y-3">
									<?php 
									// Show only the 3 most recent licenses
									$recent_licenses = array_slice( $licenses, 0, 3 );
									foreach ( $recent_licenses as $license ) : ?>
										<div class="vrstore-dashboard-license-item vrstore-border vrstore-border-gray-200 vrstore-rounded-lg vrstore-p-4">
											<div class="vrstore-license-info">
												<h4 class="vrstore-font-medium vrstore-mb-2"><?php echo esc_html( $license['product_title'] ?? (is_textdomain_loaded('vira-store') ? __( 'Unknown Product', 'vira-store' ) : 'Unknown Product') ); ?></h4>
												<div class="vrstore-license-meta vrstore-flex vrstore-gap-4 vrstore-text-sm vrstore-text-gray-600">
													<span class="vrstore-license-key-display">
														<?php echo esc_html( substr( $license['license_key'], 0, 8 ) . '...' ); ?>
													</span>
													<?php if ( ! empty( $license['expiry_date'] ) ) : ?>
														<span class="vrstore-license-expiry">
															<?php 
															$expiry_date = strtotime( $license['expiry_date'] );
															if ( $expiry_date < time() ) {
																echo '<span class="vrstore-expired">' . (is_textdomain_loaded('vira-store') ? esc_html__( 'Expired', 'vira-store' ) : 'Expired') . '</span>';
															} else {
																echo esc_html( date_i18n( get_option( 'date_format' ), $expiry_date ) );
															}
															?>
														</span>
													<?php endif; ?>
												</div>
											</div>
											<div class="vrstore-license-status-badge vrstore-mt-2">
												<span class="vrstore-license-status vrstore-badge vrstore-license-status-<?php echo esc_attr( strtolower( $license['status'] ?? 'unknown' ) ); ?>">
													<?php echo esc_html( ucfirst( $license['status'] ?? (is_textdomain_loaded('vira-store') ? __( 'Unknown', 'vira-store' ) : 'Unknown') ) ); ?>
												</span>
											</div>
										</div>
									<?php endforeach; ?>
								</div>
								<div class="vrstore-dashboard-actions vrstore-mt-4">
									<a href="#licenses" class="vrstore-btn vrstore-btn-secondary vrstore-btn-sm">
										<?php echo is_textdomain_loaded('vira-store') ? esc_html__( 'View All Licenses', 'vira-store' ) : 'View All Licenses'; ?>
									</a>
								</div>
							<?php else : ?>
								<div class="vrstore-dashboard-empty vrstore-text-center vrstore-p-8">
									<p class="vrstore-text-gray-600"><?php echo is_textdomain_loaded('vira-store') ? esc_html__( 'No licenses yet.', 'vira-store' ) : 'No licenses yet.'; ?></p>
								</div>
							<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
			
			<div id="purchases" class="vrstore-tab-content">
				<div class="vrstore-purchases-overview">
					<?php if ( ! empty( $purchases ) ) : ?>
					<div class="vrstore-table-container">
						<!-- Desktop Table -->
						<table class="vrstore-table vrstore-purchases-table">
							<thead class="vrstore-table-header">
								<tr>
									<th class="vrstore-table-th"><?php echo $account_labels['order']; ?></th>
									<th class="vrstore-table-th"><?php echo $account_labels['date']; ?></th>
									<th class="vrstore-table-th"><?php echo $account_labels['product']; ?></th>
									<th class="vrstore-table-th"><?php echo $account_labels['total']; ?></th>
									<th class="vrstore-table-th"><?php echo $account_labels['status']; ?></th>
									<th class="vrstore-table-th"><?php _e('Invoice', 'vira-store'); ?></th>
									<th class="vrstore-table-th"><?php echo $account_labels['actions']; ?></th>
								</tr>
							</thead>
							<tbody>
							<?php foreach ( $purchases as $purchase ) : ?>
									<tr class="vrstore-table-row">
										<td class="vrstore-table-td" data-label="<?php echo esc_attr($account_labels['order']); ?>"><?php echo esc_html( $purchase['order_id'] ?? (is_textdomain_loaded('vira-store') ? __( 'N/A', 'vira-store' ) : 'N/A') ); ?></td>
										<td class="vrstore-table-td" data-label="<?php echo esc_attr($account_labels['date']); ?>"><?php 
									if ( ! empty( $purchase['date'] ) ) {
										echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $purchase['date'] ) ) );
									} else {
										echo is_textdomain_loaded('vira-store') ? esc_html__( 'N/A', 'vira-store' ) : esc_html( 'N/A' );
									}
								?></td>
										<td class="vrstore-table-td" data-label="<?php echo esc_attr($account_labels['product']); ?>"><?php echo esc_html( $purchase['product_title'] ?? (is_textdomain_loaded('vira-store') ? __( 'Unknown Product', 'vira-store' ) : 'Unknown Product') ); ?></td>
										<td class="vrstore-table-td" data-label="<?php echo esc_attr($account_labels['total']); ?>">
											<?php 
											$purchase_currency = $purchase['currency'] ?? $currency_converter->get_base_currency();
											$user_currency = $currency_converter->get_user_currency();
											$converted_purchase_total = $currency_converter->convert_amount(
												floatval($purchase['total']), 
												$purchase_currency, 
												$user_currency
											);
											echo esc_html($currency_converter->format_converted_price($converted_purchase_total, $user_currency));
											?>
										</td>
										<td class="vrstore-table-td" data-label="<?php echo esc_attr($account_labels['status']); ?>">
											<span class="vrstore-order-status vrstore-badge vrstore-order-status-<?php echo esc_attr( strtolower( $purchase['status'] ?? 'unknown' ) ); ?>">
												<?php echo esc_html( ucfirst( $purchase['status'] ?? (is_textdomain_loaded('vira-store') ? __( 'Unknown', 'vira-store' ) : 'Unknown') ) ); ?>
											</span>
										</td>
										<td class="vrstore-table-td" data-label="<?php _e('Invoice', 'vira-store'); ?>">
											<?php 
											// Only show invoice actions for completed orders
											if ( 'completed' === strtolower( $purchase['payment_status'] ?? '' ) && 'completed' === strtolower( $purchase['order_status'] ?? '' ) ) :
												// Check if Invoice class is available
												if ( class_exists( 'VRSTORE_Invoice' ) ):
													$invoice_instance = VRSTORE_Invoice::get_instance();
													// Get the actual order ID for invoice generation
													$order_id_for_invoice = null;
													// Check if we have numeric order ID or need to find it by order number
													if ( isset( $purchase['order_id'] ) && is_numeric( $purchase['order_id'] ) ) {
														$order_id_for_invoice = intval( $purchase['order_id'] );
													} else {
														// Find order ID by order number
														global $wpdb;
														$orders_table = $wpdb->prefix . 'vrstore_orders';
														$order_record = $wpdb->get_row( $wpdb->prepare(
															"SELECT id FROM $orders_table WHERE order_number = %s",
															$purchase['order_id']
														) );
														if ( $order_record ) {
															$order_id_for_invoice = intval( $order_record->id );
														}
													}
													
													if ( $order_id_for_invoice ):
														$view_url = $invoice_instance->get_invoice_url( $order_id_for_invoice, 'view' );
														$download_url = $invoice_instance->get_invoice_url( $order_id_for_invoice, 'download' );
												?>
													<div class="vrstore-invoice-actions">
														<a href="<?php echo esc_url( $view_url ); ?>" class="vrstore-btn vrstore-btn-secondary vrstore-btn-xs" target="_blank" title="<?php esc_attr_e( 'View Invoice', 'vira-store' ); ?>">
															<span class="dashicons dashicons-visibility"></span>
														</a>
														<a href="<?php echo esc_url( $download_url ); ?>" class="vrstore-btn vrstore-btn-primary vrstore-btn-xs" title="<?php esc_attr_e( 'Download Invoice', 'vira-store' ); ?>">
															<span class="dashicons dashicons-download"></span>
														</a>
													</div>
													<?php 
													else:
													?>
														<span class="vrstore-na"><?php _e( 'N/A', 'vira-store' ); ?></span>
													<?php 
													endif;
												else:
												?>
													<span class="vrstore-na"><?php _e( 'N/A', 'vira-store' ); ?></span>
												<?php 
												endif;
											else:
											?>
												<span class="vrstore-pending"><?php _e( 'Pending', 'vira-store' ); ?></span>
											<?php endif; ?>
										</td>
										<td class="vrstore-table-td" data-label="<?php echo esc_attr($account_labels['actions']); ?>">
											<div class="vrstore-purchase-actions vrstore-flex vrstore-gap-2 vrstore-items-center">
													<?php if ( 'completed' === strtolower( $purchase['payment_status'] ?? '' ) || 'completed' === strtolower( $purchase['order_status'] ?? '' ) ) : ?>
														<?php 
														// Get all downloadable files for this product
														$product_id = $purchase['product_id'] ?? 0;
														$download_files = [];
														
														if ( $product_id ) {
															$download_files = get_post_meta( $product_id, '_vrstore_product_files', true );
															if ( ! is_array( $download_files ) ) {
																$download_files = [];
															}
														}
														?>
														<div class="vrstore-purchase-actions-row">
															<?php if ( ! empty( $download_files ) ) : ?>
																<button class="vrstore-btn vrstore-btn-primary vrstore-btn-sm vrstore-show-downloads" 
																		data-product-id="<?php echo esc_attr( $product_id ); ?>"
																		data-order-id="<?php echo esc_attr( $purchase['order_id'] ); ?>"
																		data-product-title="<?php echo esc_attr( $purchase['product_title'] ); ?>"
																		data-file-count="<?php echo esc_attr( count( $download_files ) ); ?>">
																	<span class="dashicons dashicons-download"></span>
																						<?php 
																						if ( count( $download_files ) === 1 ) {
																							echo $account_labels['download'];
																						} else {
																							printf( is_textdomain_loaded('vira-store') ? esc_html__( 'Downloads (%d)', 'vira-store' ) : esc_html( 'Downloads (%d)' ), count( $download_files ) );
																						}
																						?>
																					</button>
																<?php else : ?>
																	<small class="vrstore-text-muted"><?php echo is_textdomain_loaded('vira-store') ? esc_html__( 'No files available', 'vira-store' ) : esc_html( 'No files available' ); ?></small>
																<?php endif; ?>
																
														</div>
														<?php if ( ! empty( $purchase['license_key'] ) ) : ?>
															<!-- License key content would go here -->
														<?php else : ?>
												<small class="vrstore-text-muted"><?php esc_html_e( 'License will be available after payment confirmation', 'vira-store' ); ?></small>
														<?php endif; ?>
													<?php else : ?>
														<small class="vrstore-order-pending"><?php esc_html_e( 'Pending', 'vira-store' ); ?></small>
													<?php endif; ?>
												</div>
											</td>
										</tr>
									<?php endforeach; ?>
							</tbody>
						</table>
						
						<!-- Mobile Cards (hidden on desktop) -->
						<div class="vrstore-mobile-cards" style="display: none;">
						<?php foreach ( $purchases as $purchase ) : ?>
							<div class="vrstore-mobile-card">
								<div class="vrstore-mobile-card-header">
									<h4 class="vrstore-mobile-card-title"><?php echo esc_html( $purchase['product_title'] ?? (is_textdomain_loaded('vira-store') ? __( 'Unknown Product', 'vira-store' ) : 'Unknown Product') ); ?></h4>
									<span class="vrstore-mobile-card-status">
										<span class="vrstore-order-status vrstore-badge vrstore-order-status-<?php echo esc_attr( strtolower( $purchase['status'] ?? 'unknown' ) ); ?>">
											<?php echo esc_html( ucfirst( $purchase['status'] ?? (is_textdomain_loaded('vira-store') ? __( 'Unknown', 'vira-store' ) : 'Unknown') ) ); ?>
										</span>
									</span>
								</div>
								<div class="vrstore-mobile-card-body">
									<div class="vrstore-mobile-card-row">
										<span class="vrstore-mobile-card-label"><?php echo $account_labels['order']; ?></span>
										<span class="vrstore-mobile-card-value"><?php echo esc_html( $purchase['order_id'] ?? (is_textdomain_loaded('vira-store') ? __( 'N/A', 'vira-store' ) : 'N/A') ); ?></span>
									</div>
									<div class="vrstore-mobile-card-row">
										<span class="vrstore-mobile-card-label"><?php echo $account_labels['date']; ?></span>
										<span class="vrstore-mobile-card-value"><?php 
										if ( ! empty( $purchase['date'] ) ) {
											echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $purchase['date'] ) ) );
										} else {
											echo is_textdomain_loaded('vira-store') ? esc_html__( 'N/A', 'vira-store' ) : esc_html( 'N/A' );
										}
									?></span>
									</div>
									<div class="vrstore-mobile-card-row">
										<span class="vrstore-mobile-card-label"><?php echo $account_labels['total']; ?></span>
										<span class="vrstore-mobile-card-value">
											<?php 
											$purchase_currency = $purchase['currency'] ?? $currency_converter->get_base_currency();
											$user_currency = $currency_converter->get_user_currency();
											$converted_mobile_purchase_total = $currency_converter->convert_amount(
												floatval($purchase['total']), 
												$purchase_currency, 
												$user_currency
											);
											echo esc_html($currency_converter->format_converted_price($converted_mobile_purchase_total, $user_currency));
											?>
										</span>
									</div>
								</div>
								<?php if ( 'completed' === strtolower( $purchase['payment_status'] ?? '' ) || 'completed' === strtolower( $purchase['order_status'] ?? '' ) ) : ?>
									<div class="vrstore-mobile-card-actions">
										<?php 
										// Get all downloadable files for this product
										$product_id = $purchase['product_id'] ?? 0;
										$download_files = [];
										
										if ( $product_id ) {
											$download_files = get_post_meta( $product_id, '_vrstore_product_files', true );
											if ( ! is_array( $download_files ) ) {
												$download_files = [];
											}
										}
										
										if ( ! empty( $download_files ) ) : ?>
											<button class="vrstore-btn vrstore-btn-primary vrstore-btn-sm vrstore-show-downloads" 
													data-product-id="<?php echo esc_attr( $product_id ); ?>"
													data-order-id="<?php echo esc_attr( $purchase['order_id'] ); ?>"
													data-product-title="<?php echo esc_attr( $purchase['product_title'] ); ?>"
													data-file-count="<?php echo esc_attr( count( $download_files ) ); ?>">
												<span class="dashicons dashicons-download"></span>
																	<?php 
																	if ( count( $download_files ) === 1 ) {
																		echo $account_labels['download'];
																	} else {
																		printf( is_textdomain_loaded('vira-store') ? esc_html__( 'Downloads (%d)', 'vira-store' ) : esc_html( 'Downloads (%d)' ), count( $download_files ) );
																	}
																	?>
																</button>
															<?php else : ?>
																<small class="vrstore-text-muted"><?php echo is_textdomain_loaded('vira-store') ? esc_html__( 'No files available', 'vira-store' ) : esc_html( 'No files available' ); ?></small>
															<?php endif; ?>
										</div>
								<?php endif; ?>
							</div>
						<?php endforeach; ?>
						</div>
					</div>
					<?php else : ?>
						<div class="vrstore-card vrstore-p-8 vrstore-text-center">
							<div class="vrstore-empty-state">
								<div class="vrstore-empty-icon vrstore-mb-4">
									<span class="dashicons dashicons-cart vrstore-text-4xl vrstore-text-gray-400"></span>
								</div>
								<h3 class="vrstore-text-xl vrstore-font-bold vrstore-mb-2 vrstore-text-gray-800"><?php echo vrstore_is_textdomain_ready() ? esc_html__( 'No Purchases Yet', 'vira-store' ) : 'No Purchases Yet'; ?></h3>
								<p class="vrstore-text-gray-600 vrstore-mb-4"><?php echo $account_labels['no_purchases']; ?></p>
								<div class="vrstore-empty-actions">
									<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="vrstore-btn vrstore-btn-primary">
										<?php echo vrstore_is_textdomain_ready() ? esc_html__( 'Browse Products', 'vira-store' ) : 'Browse Products'; ?>
									</a>
								</div>
							</div>
						</div>
					<?php endif; ?>
				</div>
			</div>
			
			<div id="resources" class="vrstore-tab-content">
				<div class="vrstore-resources-overview">
					<?php
					// Get user's enrolled courses
					global $wpdb;
					$enrolled_courses = [];
					
					// Check user meta for course enrollments - both possible formats
					$course_enrollments = get_user_meta($user_id, '_vrstore_course_enrollments', true);
					if (is_array($course_enrollments)) {
						$enrolled_courses = $course_enrollments;
					}
					
					// Also check the standard enrolled courses meta used by the course system
					$enrolled_courses_alt = get_user_meta($user_id, '_vrstore_enrolled_courses', true);
					if (is_array($enrolled_courses_alt)) {
						foreach ($enrolled_courses_alt as $course_id) {
							// Convert to course_data format for consistency
							$enrollment_date = get_user_meta($user_id, '_vrstore_course_enrollment_date_' . $course_id, true);
							$course_data = [
								'course_id' => $course_id,
								'course_title' => get_the_title($course_id),
								'enrolled_date' => $enrollment_date ?: '',
								'order_id' => ''
							];
							
							// Check if already in enrolled courses
							$already_enrolled = false;
							foreach ($enrolled_courses as $enrolled) {
								if (isset($enrolled['course_id']) && $enrolled['course_id'] == $course_id) {
									$already_enrolled = true;
									break;
								}
							}
							
							if (!$already_enrolled) {
								$enrolled_courses[] = $course_data;
							}
						}
					}
					
					// Also check for courses from completed orders
					if (!empty($purchases)) {
						foreach ($purchases as $purchase) {
							if (isset($purchase['product_id']) && 
								('completed' === strtolower($purchase['payment_status'] ?? '') || 
								 'completed' === strtolower($purchase['order_status'] ?? ''))) {
								
								$product_id = $purchase['product_id'];
								$post_type = get_post_type($product_id);
								$is_course = ($post_type === 'vrstore_course') || get_post_meta($product_id, '_vrstore_is_course', true);
								
								if ($is_course) {
									$course_data = [
										'course_id' => $product_id,
										'course_title' => $purchase['product_title'],
										'enrolled_date' => $purchase['date'],
										'order_id' => $purchase['order_id']
									];
									
									// Check if already in enrolled courses
									$already_enrolled = false;
									foreach ($enrolled_courses as $enrolled) {
										if (isset($enrolled['course_id']) && $enrolled['course_id'] == $product_id) {
											$already_enrolled = true;
											break;
										}
									}
									
									if (!$already_enrolled) {
										$enrolled_courses[] = $course_data;
									}
								}
							}
						}
					}
					
					// Get course resources for each enrolled course
					$course_resources = [];
					foreach ($enrolled_courses as $course) {
						if (isset($course['course_id'])) {
							$course_id = $course['course_id'];
							$course_post = get_post($course_id);
							
							if ($course_post) {
								// Get course resources/files
								$course_files = get_post_meta($course_id, '_vrstore_product_files', true) ?: [];
								$course_lessons = get_post_meta($course_id, '_vrstore_course_lessons', true) ?: [];
								$course_thumbnail = get_the_post_thumbnail_url($course_id, 'medium') ?: '';
								
								$course_resources[] = [
									'id' => $course_id,
									'title' => $course_post->post_title,
									'description' => wp_trim_words($course_post->post_content, 20),
									'thumbnail' => $course_thumbnail,
									'files' => $course_files,
									'lessons' => $course_lessons,
									'enrolled_date' => $course['enrolled_date'] ?? '',
									'permalink' => get_permalink($course_id)
								];
							}
						}
					}
					?>
								
					<?php if (!empty($course_resources)): ?>
						<!-- 3-Column Course Resources Grid -->
						<div class="vrstore-resources-grid vrstore-grid vrstore-grid-cols-1 vrstore-md:grid-cols-2 vrstore-lg:grid-cols-3 vrstore-gap-6">
							<?php foreach ($course_resources as $course): ?>
								<div class="vrstore-resource-card vrstore-card vrstore-p-6 vrstore-hover:shadow-lg vrstore-transition-shadow">
									<!-- Course Thumbnail -->
									<?php if (!empty($course['thumbnail'])): ?>
										<div class="vrstore-resource-thumbnail vrstore-mb-4">
											<img src="<?php echo esc_url($course['thumbnail']); ?>" 
												 alt="<?php echo esc_attr($course['title']); ?>" 
												 class="vrstore-w-full vrstore-h-32 vrstore-object-cover vrstore-rounded-lg">
										</div>
									<?php else: ?>
										<div class="vrstore-resource-placeholder vrstore-mb-4 vrstore-bg-gray-100 vrstore-h-32 vrstore-rounded-lg vrstore-flex vrstore-items-center vrstore-justify-center">
											<span class="dashicons dashicons-welcome-learn-more vrstore-text-gray-400 vrstore-text-2xl"></span>
										</div>
									<?php endif; ?>
									
									<!-- Course Info -->
									<div class="vrstore-resource-info">
										<h4 class="vrstore-text-lg vrstore-font-semibold vrstore-mb-2 vrstore-text-gray-900">
											<?php echo esc_html($course['title']); ?>
										</h4>
										
										<?php if (!empty($course['description'])): ?>
											<p class="vrstore-text-sm vrstore-text-gray-600 vrstore-mb-4">
												<?php echo esc_html($course['description']); ?>
											</p>
										<?php endif; ?>
										
										<!-- Course Stats -->
										<div class="vrstore-resource-stats vrstore-flex vrstore-gap-4 vrstore-text-sm vrstore-text-gray-500 vrstore-mb-4">
											<?php if (!empty($course['lessons']) && is_array($course['lessons'])): ?>
												<span class="vrstore-flex vrstore-items-center">
													<span class="dashicons dashicons-video-alt3 vrstore-mr-1"></span>
													<?php printf(vrstore_is_textdomain_ready() ? esc_html__('%d lessons', 'vira-store') : '%d lessons', count($course['lessons'])); ?>
												</span>
											<?php endif; ?>
											
											<?php if (!empty($course['files']) && is_array($course['files'])): ?>
												<span class="vrstore-flex vrstore-items-center">
													<span class="dashicons dashicons-download vrstore-mr-1"></span>
													<?php printf(vrstore_is_textdomain_ready() ? esc_html__('%d files', 'vira-store') : '%d files', count($course['files'])); ?>
												</span>
											<?php endif; ?>
											
											<?php if (!empty($course['enrolled_date'])): ?>
												<span class="vrstore-flex vrstore-items-center">
													<span class="dashicons dashicons-calendar-alt vrstore-mr-1"></span>
													<?php echo esc_html(date_i18n(get_option('date_format'), strtotime($course['enrolled_date']))); ?>
												</span>
											<?php endif; ?>
										</div>
										
										<!-- Course Actions -->
										<div class="vrstore-resource-actions vrstore-flex vrstore-gap-2">
											<a href="<?php echo esc_url($course['permalink']); ?>" 
											   class="vrstore-btn vrstore-btn-primary vrstore-btn-sm vrstore-flex-1">
												<span class="dashicons dashicons-welcome-learn-more"></span>
												<?php echo vrstore_is_textdomain_ready() ? esc_html__('Access Course', 'vira-store') : 'Access Course'; ?>
											</a>
											
											<?php if (!empty($course['files']) && is_array($course['files'])): ?>
												<button class="vrstore-btn vrstore-btn-secondary vrstore-btn-sm vrstore-show-downloads" 
														data-product-id="<?php echo esc_attr($course['id']); ?>"
														data-product-title="<?php echo esc_attr($course['title']); ?>"
														data-file-count="<?php echo esc_attr(count($course['files'])); ?>"
														title="<?php echo vrstore_is_textdomain_ready() ? esc_attr__('Download Course Materials', 'vira-store') : 'Download Course Materials'; ?>">
													<span class="dashicons dashicons-download"></span>
												</button>
											<?php endif; ?>
										</div>
									</div>
								</div>
							<?php endforeach; ?>
						</div>
					<?php else: ?>
						<!-- Empty State -->
						<div class="vrstore-card vrstore-p-8 vrstore-text-center">
							<div class="vrstore-empty-state">
								<div class="vrstore-empty-icon vrstore-mb-4">
									<span class="dashicons dashicons-welcome-learn-more vrstore-text-4xl vrstore-text-gray-400"></span>
								</div>
								<h3 class="vrstore-text-xl vrstore-font-bold vrstore-mb-2 vrstore-text-gray-800">
									<?php echo vrstore_is_textdomain_ready() ? esc_html__( 'No Course Resources Yet', 'vira-store' ) : 'No Course Resources Yet'; ?>
								</h3>
								<p class="vrstore-text-gray-600 vrstore-mb-4">
									<?php echo vrstore_is_textdomain_ready() ? esc_html__( 'You haven\'t enrolled in any courses yet. Browse and purchase courses to access exclusive learning materials and resources.', 'vira-store' ) : 'You haven\'t enrolled in any courses yet. Browse and purchase courses to access exclusive learning materials and resources.'; ?>
								</p>
								<div class="vrstore-empty-actions">
									<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="vrstore-btn vrstore-btn-primary">
										<span class="dashicons dashicons-search"></span>
										<?php echo vrstore_is_textdomain_ready() ? esc_html__( 'Browse Courses', 'vira-store' ) : 'Browse Courses'; ?>
									</a>
								</div>
							</div>
						</div>
					<?php endif; ?>
				</div>
			</div>
			
			<div id="support" class="vrstore-tab-content">
				<div class="vrstore-support-overview">
					<?php
					// Get customer's support tickets
					global $wpdb;
					$tickets_table = $wpdb->prefix . 'vrstore_support_tickets';
					$replies_table = $wpdb->prefix . 'vrstore_support_replies';
					
					$customer_tickets = $wpdb->get_results($wpdb->prepare(
						"SELECT st.*, p.post_title as product_title 
						 FROM $tickets_table st
						 LEFT JOIN {$wpdb->posts} p ON st.product_id = p.ID
						 WHERE st.customer_id = %d 
						 ORDER BY st.created_at DESC",
						$user_id
					));
					
					// Get available products for ticket creation
					$customer_products = array();
					if (!empty($purchases)) {
						foreach ($purchases as $purchase) {
							if (!empty($purchase['product_id']) && !empty($purchase['product_title'])) {
								$customer_products[$purchase['product_id']] = $purchase['product_title'];
							}
						}
					}
					$customer_products = array_unique($customer_products, SORT_REGULAR);
					?>
					
					<!-- Support Header -->
					<div class="vrstore-support-header vrstore-flex vrstore-justify-between vrstore-items-center vrstore-mb-6">
						<div class="vrstore-support-stats">
							<?php 
							$open_tickets = 0;
							$unread_count = 0;
							foreach ($customer_tickets as $ticket) {
								if (in_array($ticket->status, ['open', 'pending', 'in_progress'])) {
									$open_tickets++;
								}
								if ($ticket->customer_unread_count > 0) {
									$unread_count += $ticket->customer_unread_count;
								}
							}
							?>
							<h3 class="vrstore-text-xl vrstore-font-bold vrstore-mb-2"><?php _e('Support Center', 'vira-store'); ?></h3>
							<p class="vrstore-text-gray-600">
								<?php printf(
									__('You have %d total tickets, %d open tickets', 'vira-store'),
									count($customer_tickets),
									$open_tickets
								); ?>
								<?php if ($unread_count > 0): ?>
									<span class="vrstore-unread-indicator"><?php printf(__(' - %d unread', 'vira-store'), $unread_count); ?></span>
								<?php endif; ?>
								👋 <?php _e('Hello', 'vira-store'); ?>, <strong><?php echo esc_html($user->display_name); ?></strong> / 
								<a href="#" id="vrstore-edit-profile-btn" class="vrstore-edit-profile-link" data-modal="vrstore-edit-profile-modal"><?php _e('Edit Profile', 'vira-store'); ?></a> / 
								<a href="<?php echo esc_url(wp_logout_url(get_permalink())); ?>" class="vrstore-logout-link"><?php _e('Logout', 'vira-store'); ?></a>
							</p>
						</div>
						<div class="vrstore-support-actions">
							<a href="#" class="vrstore-btn vrstore-btn-primary vrstore-btn-sm" id="vrstore-create-ticket-btn">
								<span class="dashicons dashicons-plus-alt2"></span>
								<?php _e('New Ticket', 'vira-store'); ?>
							</a>
							<a href="#" class="vrstore-btn vrstore-btn-primary vrstore-btn-sm" id="vrstore-extended-support-btn">
								<span class="dashicons dashicons-clock"></span>
								<?php _e('Extended Support', 'vira-store'); ?>
							</a>
						</div>
					</div>
					
					<!-- Tickets List -->
					<?php if (!empty($customer_tickets)): ?>
						<div class="vrstore-tickets-container">
							<!-- Desktop Table -->
							<table class="vrstore-table vrstore-support-tickets-table">
								<thead class="vrstore-table-header">
									<tr>
										<th class="vrstore-table-th"><?php _e('Ticket #', 'vira-store'); ?></th>
										<th class="vrstore-table-th"><?php _e('Subject', 'vira-store'); ?></th>
										<th class="vrstore-table-th"><?php _e('Product', 'vira-store'); ?></th>
										<th class="vrstore-table-th"><?php _e('Status', 'vira-store'); ?></th>
										<th class="vrstore-table-th"><?php _e('Priority', 'vira-store'); ?></th>
										<th class="vrstore-table-th"><?php _e('Last Updated', 'vira-store'); ?></th>
										<th class="vrstore-table-th"><?php _e('Actions', 'vira-store'); ?></th>
									</tr>
								</thead>
								<tbody>
									<?php foreach ($customer_tickets as $ticket): ?>
										<?php 
										$status_class = 'vrstore-ticket-status-' . $ticket->status;
										$priority_class = 'vrstore-ticket-priority-' . $ticket->priority;
										?>
										<tr class="vrstore-table-row">
											<td class="vrstore-table-td" data-label="<?php _e('Ticket #', 'vira-store'); ?>">
												<strong><?php echo esc_html($ticket->ticket_number); ?></strong>
											</td>
											<td class="vrstore-table-td" data-label="<?php _e('Subject', 'vira-store'); ?>">
												<strong><?php echo esc_html($ticket->subject); ?></strong>
												<?php if ($ticket->customer_unread_count > 0): ?>
													<span class="vrstore-unread-badge"><?php echo esc_html($ticket->customer_unread_count); ?></span>
												<?php endif; ?>
											</td>
											<td class="vrstore-table-td" data-label="<?php _e('Product', 'vira-store'); ?>">
												<?php echo esc_html($ticket->product_title ?: __('General', 'vira-store')); ?>
											</td>
											<td class="vrstore-table-td" data-label="<?php _e('Status', 'vira-store'); ?>">
												<span class="vrstore-status-badge <?php echo esc_attr($status_class); ?>">
													<?php echo esc_html(ucfirst($ticket->status)); ?>
												</span>
											</td>
											<td class="vrstore-table-td" data-label="<?php _e('Priority', 'vira-store'); ?>">
												<span class="vrstore-priority-badge <?php echo esc_attr($priority_class); ?>">
													<?php echo esc_html(ucfirst($ticket->priority)); ?>
												</span>
											</td>
											<td class="vrstore-table-td" data-label="<?php _e('Last Updated', 'vira-store'); ?>">
												<?php echo esc_html(mysql2date('M j, Y g:i A', $ticket->last_reply_at)); ?>
											</td>
											<td class="vrstore-table-td" data-label="<?php _e('Actions', 'vira-store'); ?>">
												<a href="#" class="vrstore-btn vrstore-btn-primary vrstore-btn-sm vrstore-view-ticket" data-ticket-id="<?php echo esc_attr($ticket->id); ?>" data-ticket-number="<?php echo esc_attr($ticket->ticket_number); ?>">
													<span class="dashicons dashicons-visibility"></span>
													<?php _e('View', 'vira-store'); ?>
												</a>
											</td>
										</tr>
									<?php endforeach; ?>
								</tbody>
							</table>
							
							<!-- Mobile Cards (hidden on desktop) -->
							<div class="vrstore-mobile-cards" style="display: none;">
								<?php foreach ($customer_tickets as $ticket): ?>
									<?php 
									$status_class = 'vrstore-ticket-status-' . $ticket->status;
									$priority_class = 'vrstore-ticket-priority-' . $ticket->priority;
									?>
									<div class="vrstore-mobile-card">
										<div class="vrstore-mobile-card-header">
											<h4 class="vrstore-mobile-card-title">
												<?php echo esc_html($ticket->subject); ?>
												<?php if ($ticket->customer_unread_count > 0): ?>
													<span class="vrstore-unread-badge"><?php echo esc_html($ticket->customer_unread_count); ?></span>
												<?php endif; ?>
											</h4>
											<div class="vrstore-mobile-card-badges">
												<span class="vrstore-status-badge <?php echo esc_attr($status_class); ?>">
													<?php echo esc_html(ucfirst($ticket->status)); ?>
												</span>
												<span class="vrstore-priority-badge <?php echo esc_attr($priority_class); ?>">
													<?php echo esc_html(ucfirst($ticket->priority)); ?>
												</span>
											</div>
										</div>
										<div class="vrstore-mobile-card-body">
											<div class="vrstore-mobile-card-row">
												<span class="vrstore-mobile-card-label"><?php _e('Ticket #', 'vira-store'); ?></span>
												<span class="vrstore-mobile-card-value"><?php echo esc_html($ticket->ticket_number); ?></span>
											</div>
											<div class="vrstore-mobile-card-row">
												<span class="vrstore-mobile-card-label"><?php _e('Product', 'vira-store'); ?></span>
												<span class="vrstore-mobile-card-value"><?php echo esc_html($ticket->product_title ?: __('General', 'vira-store')); ?></span>
											</div>
											<div class="vrstore-mobile-card-row">
												<span class="vrstore-mobile-card-label"><?php _e('Last Updated', 'vira-store'); ?></span>
												<span class="vrstore-mobile-card-value"><?php echo esc_html(mysql2date('M j, Y g:i A', $ticket->last_reply_at)); ?></span>
											</div>
										</div>
										<div class="vrstore-mobile-card-actions">
											<a href="#" class="vrstore-btn vrstore-btn-primary vrstore-btn-sm vrstore-view-ticket" data-ticket-id="<?php echo esc_attr($ticket->id); ?>" data-ticket-number="<?php echo esc_attr($ticket->ticket_number); ?>">
												<span class="dashicons dashicons-visibility"></span>
												<?php _e('View', 'vira-store'); ?>
											</a>
										</div>
									</div>
								<?php endforeach; ?>
							</div>
						</div>
					<?php else: ?>
						<!-- Empty State -->
						<div class="vrstore-card vrstore-p-8 vrstore-text-center">
							<div class="vrstore-empty-state">
								<div class="vrstore-empty-icon vrstore-mb-4">
									<span class="dashicons dashicons-sos vrstore-text-4xl vrstore-text-gray-400"></span>
								</div>
								<h3 class="vrstore-text-xl vrstore-font-bold vrstore-mb-2 vrstore-text-gray-800"><?php _e('No Support Tickets', 'vira-store'); ?></h3>
								<p class="vrstore-text-gray-600 vrstore-mb-4"><?php _e('You haven\'t created any support tickets yet. Need help? Use the buttons above to create your first ticket or get extended support!', 'vira-store'); ?></p>
							</div>
						</div>
					<?php endif; ?>
				</div>
			</div>
			
			<div id="licenses" class="vrstore-tab-content">
				<div class="vrstore-licenses-overview">
					<?php
					// Check if user has any pending payments that would have licenses
					$has_pending_payments = false;
					if ( ! empty( $purchases ) ) {
						foreach ( $purchases as $purchase ) {
							if ( strtolower( $purchase['payment_status'] ?? '' ) === 'pending' || 
								 strtolower( $purchase['order_status'] ?? '' ) === 'pending' ) {
								$has_pending_payments = true;
								break;
							}
						}
					}
					
					// Only show notice if there are pending payments
					if ( $has_pending_payments ) : ?>
						<div class="vrstore-alert vrstore-alert-warning vrstore-mb-6">
							<p class="vrstore-mb-0">
								<strong>Note:</strong> Licenses are issued after payment is confirmed. If your payment is still pending, the license will appear here once it's processed.
							</p>
						</div>
					<?php endif; ?>
				
				<?php 
				// Note: Products without license generation are intentionally excluded from the Licenses tab
				// as they don't actually have licenses to manage. Only products with actual licenses should appear here.
				
				$has_license_data = ! empty( $licenses ) && is_array( $licenses );
				$has_actual_licenses = ! empty( $licenses ) && is_array( $licenses );
				?>
				
				<?php if ( $has_license_data ) : ?>
					<div class="vrstore-table-container">
						<!-- Desktop Table -->
						<table class="vrstore-table vrstore-licenses-table">
							<thead class="vrstore-table-header">
								<tr>
									<th class="vrstore-table-th"><?php echo $account_labels['product']; ?></th>
									<th class="vrstore-table-th"><?php echo $account_labels['license_key']; ?></th>
									<th class="vrstore-table-th"><?php echo $account_labels['license_type']; ?></th>
									<th class="vrstore-table-th"><?php echo $account_labels['status']; ?></th>
									<th class="vrstore-table-th"><?php echo $account_labels['activations']; ?></th>
									<th class="vrstore-table-th"><?php echo $account_labels['expiry_date']; ?></th>
								</tr>
							</thead>
							<tbody>
								<?php if ( ! empty( $licenses ) && is_array( $licenses ) ) : ?>
									<?php foreach ( $licenses as $license ) : ?>
									<tr class="vrstore-table-row">
									<td class="vrstore-table-td" data-label="<?php echo esc_attr($account_labels['product']); ?>"><?php echo esc_html( $license['product_title'] ?? (is_textdomain_loaded('vira-store') ? __( 'Unknown Product', 'vira-store' ) : 'Unknown Product') ); ?></td>
									<td class="vrstore-table-td" data-label="<?php echo esc_attr($account_labels['license_key']); ?>">
										<div class="vrstore-license-key-wrapper vrstore-flex vrstore-items-center vrstore-gap-2">
											<code class="vrstore-license-key license-key-text vrstore-font-mono vrstore-text-sm vrstore-bg-gray-100 vrstore-px-2 vrstore-py-1 vrstore-rounded"><?php echo esc_html( $license['license_key'] ?? '' ); ?></code>
											<?php if ( ! empty( $license['license_key'] ) ) : ?>
												<button class="vrstore-copy-license-key vrstore-btn vrstore-btn-ghost vrstore-btn-xs" data-license-key="<?php echo esc_attr( $license['license_key'] ); ?>"
														title="<?php esc_attr_e( 'Copy license key', 'vira-store' ); ?>">
													<span class="dashicons dashicons-clipboard"></span>
												</button>
											<?php endif; ?>
										</div>
									</td>
									<td class="vrstore-table-td" data-label="<?php echo esc_attr($account_labels['license_type']); ?>">
										<?php 
										// Display license type
										$license_type_slug = $license['license_type_slug'] ?? '';
										if (!empty($license_type_slug)) {
											// Get license type label from settings
											$vrstore_settings = get_option('vrstore_settings', array());
											$custom_license_types = isset($vrstore_settings['custom_license_types']) && is_array($vrstore_settings['custom_license_types']) ? $vrstore_settings['custom_license_types'] : array();
											
											$license_type_label = ucfirst(str_replace('_', ' ', $license_type_slug));
											
											// Find the proper label from custom license types
											foreach ($custom_license_types as $type) {
												if (($type['slug'] ?? '') === $license_type_slug) {
													$license_type_label = $type['label'] ?? $license_type_label;
													break;
												}
											}
											
											echo '<span class="vrstore-license-type vrstore-license-type-' . esc_attr($license_type_slug) . '">' . esc_html($license_type_label) . '</span>';
									} else {
										echo '<span class="vrstore-license-type vrstore-license-type-custom">Custom License</span>';
									}
										?>
									</td>
									<td class="vrstore-table-td" data-label="<?php echo esc_attr($account_labels['status']); ?>">
										<?php
										// Check if license is expired
										$is_expired = false;
										if ( ! empty( $license['expiry_date'] ) ) {
											$expiry_date = strtotime( $license['expiry_date'] );
											$is_expired = $expiry_date < time();
										}
										
										if ( $is_expired ) :
											// Show Renew link for expired licenses
											$product_id = $license['product_id'] ?? 0;
											$product_url = '';
											
											// Try to get the product URL for renewal
											if ( $product_id ) {
												$product_post = get_post( $product_id );
												if ( $product_post ) {
													$product_url = get_permalink( $product_id );
												}
											}
											
											if ( $product_url ) : ?>
												<a href="<?php echo esc_url( $product_url ); ?>" class="vrstore-btn vrstore-btn-primary vrstore-btn-sm vrstore-renew-license">
													<?php echo is_textdomain_loaded('vira-store') ? esc_html__( 'Renew', 'vira-store' ) : 'Renew'; ?>
												</a>
											<?php else : ?>
												<span class="vrstore-license-status vrstore-badge license-status vrstore-license-status-expired">
													<?php echo is_textdomain_loaded('vira-store') ? esc_html__( 'Expired', 'vira-store' ) : 'Expired'; ?>
												</span>
											<?php endif;
										else : ?>
											<span class="vrstore-license-status vrstore-badge license-status vrstore-license-status-<?php echo esc_attr( strtolower( $license['status'] ?? 'unknown' ) ); ?>">
												<?php echo esc_html( $license['status'] ?? (is_textdomain_loaded('vira-store') ? __( 'Unknown', 'vira-store' ) : 'Unknown') ); ?>
											</span>
										<?php endif; ?>
									</td>
									<td class="vrstore-table-td" data-label="<?php echo esc_attr($account_labels['activations']); ?>">
										<?php
										$activations = ! empty( $license['activations'] ) ? count( $license['activations'] ) : ( $license['activation_count'] ?? 0 );
										$activation_limit = ! empty( $license['activation_limit'] ) ? $license['activation_limit'] : 0;
										
										if ( $activation_limit > 0 ) {
											echo esc_html( sprintf( $account_labels['activations_limit'], $activations, $activation_limit ) );
										} else {
											echo esc_html( sprintf( $account_labels['unlimited'], $activations ) );
										}
										?>
									</td>
									<td class="vrstore-table-td" data-label="<?php echo esc_attr($account_labels['expiry_date']); ?>">
										<?php
										if ( ! empty( $license['expiry_date'] ) ) {
											echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $license['expiry_date'] ) ) );
										} else {
											echo $account_labels['never'];
										}
										?>
									</td>
									</tr>
									<?php endforeach; ?>
								<?php endif; ?>
							</tbody>
						</table>
						
						<!-- Mobile Cards (hidden on desktop) -->
						<div class="vrstore-mobile-cards" style="display: none;">
							<?php if ( ! empty( $licenses ) && is_array( $licenses ) ) : ?>
								<?php foreach ( $licenses as $license ) : ?>
									<div class="vrstore-mobile-card">
										<div class="vrstore-mobile-card-header">
											<h4 class="vrstore-mobile-card-title"><?php echo esc_html( $license['product_title'] ?? (is_textdomain_loaded('vira-store') ? __( 'Unknown Product', 'vira-store' ) : 'Unknown Product') ); ?></h4>
											<span class="vrstore-mobile-card-status">
												<?php
												// Check if license is expired
												$is_expired = false;
												if ( ! empty( $license['expiry_date'] ) ) {
													$expiry_date = strtotime( $license['expiry_date'] );
													$is_expired = $expiry_date < time();
												}
												
												if ( $is_expired ) :
													// Show Renew link for expired licenses
													$product_id = $license['product_id'] ?? 0;
													$product_url = '';
													
													// Try to get the product URL for renewal
													if ( $product_id ) {
														$product_post = get_post( $product_id );
														if ( $product_post ) {
															$product_url = get_permalink( $product_id );
														}
													}
													
													if ( $product_url ) : ?>
														<a href="<?php echo esc_url( $product_url ); ?>" class="vrstore-btn vrstore-btn-primary vrstore-btn-sm vrstore-renew-license">
															<?php echo is_textdomain_loaded('vira-store') ? esc_html__( 'Renew', 'vira-store' ) : 'Renew'; ?>
														</a>
													<?php else : ?>
														<span class="vrstore-license-status vrstore-badge license-status vrstore-license-status-expired">
															<?php echo is_textdomain_loaded('vira-store') ? esc_html__( 'Expired', 'vira-store' ) : 'Expired'; ?>
														</span>
													<?php endif;
												else : ?>
													<span class="vrstore-license-status vrstore-badge license-status vrstore-license-status-<?php echo esc_attr( strtolower( $license['status'] ?? 'unknown' ) ); ?>">
														<?php echo esc_html( $license['status'] ?? (is_textdomain_loaded('vira-store') ? __( 'Unknown', 'vira-store' ) : 'Unknown') ); ?>
													</span>
												<?php endif; ?>
											</span>
										</div>
										<div class="vrstore-mobile-card-body">
											<div class="vrstore-mobile-card-row">
												<span class="vrstore-mobile-card-label"><?php echo $account_labels['license_key']; ?></span>
												<div class="vrstore-mobile-card-value">
													<div class="vrstore-license-key-wrapper">
														<code class="vrstore-license-key license-key-text"><?php echo esc_html( $license['license_key'] ?? '' ); ?></code>
														<?php if ( ! empty( $license['license_key'] ) ) : ?>
															<button class="vrstore-copy-license-key vrstore-btn vrstore-btn-ghost vrstore-btn-xs" data-license-key="<?php echo esc_attr( $license['license_key'] ); ?>" title="<?php esc_attr_e( 'Copy license key', 'vira-store' ); ?>">
																<span class="dashicons dashicons-clipboard"></span>
															</button>
														<?php endif; ?>
													</div>
												</div>
											</div>
											<div class="vrstore-mobile-card-row">
												<span class="vrstore-mobile-card-label"><?php echo $account_labels['license_type']; ?></span>
												<span class="vrstore-mobile-card-value">
													<?php 
													// Display license type
													$license_type_slug = $license['license_type_slug'] ?? '';
													if (!empty($license_type_slug)) {
														// Get license type label from settings
														$vrstore_settings = get_option('vrstore_settings', array());
														$custom_license_types = isset($vrstore_settings['custom_license_types']) && is_array($vrstore_settings['custom_license_types']) ? $vrstore_settings['custom_license_types'] : array();
														
														$license_type_label = ucfirst(str_replace('_', ' ', $license_type_slug));
														
														// Find the proper label from custom license types
														foreach ($custom_license_types as $type) {
															if (($type['slug'] ?? '') === $license_type_slug) {
																$license_type_label = $type['label'] ?? $license_type_label;
																break;
															}
														}
														
														echo '<span class="vrstore-license-type vrstore-license-type-' . esc_attr($license_type_slug) . '">' . esc_html($license_type_label) . '</span>';
													} else {
														echo '<span class="vrstore-license-type vrstore-license-type-custom">Custom License</span>';
													}
													?>
												</span>
											</div>
											<div class="vrstore-mobile-card-row">
												<span class="vrstore-mobile-card-label"><?php echo $account_labels['activations']; ?></span>
												<span class="vrstore-mobile-card-value">
													<?php
													$activations = ! empty( $license['activations'] ) ? count( $license['activations'] ) : ( $license['activation_count'] ?? 0 );
													$activation_limit = ! empty( $license['activation_limit'] ) ? $license['activation_limit'] : 0;
													
													if ( $activation_limit > 0 ) {
														echo esc_html( sprintf( $account_labels['activations_limit'], $activations, $activation_limit ) );
													} else {
														echo esc_html( sprintf( $account_labels['unlimited'], $activations ) );
													}
													?>
												</span>
											</div>
											<div class="vrstore-mobile-card-row">
												<span class="vrstore-mobile-card-label"><?php echo $account_labels['expiry_date']; ?></span>
												<span class="vrstore-mobile-card-value">
													<?php
													if ( ! empty( $license['expiry_date'] ) ) {
														echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $license['expiry_date'] ) ) );
													} else {
														echo $account_labels['never'];
													}
													?>
												</span>
											</div>
										</div>
									</div>
								<?php endforeach; ?>
							<?php endif; ?>
						</div>
					
					<?php 
					// Calculate total activation limit across all licenses
					$total_activation_limit = 0;
					$total_current_activations = 0;
					$all_license_keys = array();
					
					foreach ($licenses as $license) {
						$total_activation_limit += intval($license['activation_limit'] ?? 1);
						$total_current_activations += intval($license['activation_count'] ?? 0);
						$all_license_keys[] = $license['license_key'];
					}
					
					// Get all domain activations for this customer
					$all_domain_activations = array();
					if (class_exists('VRSTORE_Domain_Monitor') && !empty($all_license_keys)) {
						// Get fresh data directly from database to avoid cache issues
						global $wpdb;
						$database_instance = VRSTORE_Database::get_instance();
						
						// Check if table exists before querying
						if (!$database_instance->table_exists('license_domain_activations')) {
							// Table doesn't exist yet, skip domain activations
							$all_domain_activations = array();
						} else {
							$activations_table = $database_instance->get_table_name('license_domain_activations');
							
							// Validate and sanitize license keys
							$sanitized_keys = array();
							foreach ($all_license_keys as $key) {
								$sanitized_key = sanitize_text_field($key);
								if (!empty($sanitized_key) && strlen($sanitized_key) >= 10 && strlen($sanitized_key) <= 100) {
									$sanitized_keys[] = $sanitized_key;
								}
							}
							
							if (!empty($sanitized_keys)) {
								// Get fresh data directly from database with proper SQL injection prevention
								$license_keys_placeholders = implode(',', array_fill(0, count($sanitized_keys), '%s'));
								$query = "SELECT * FROM $activations_table WHERE license_key IN ($license_keys_placeholders) AND status = 'active' ORDER BY activated_at DESC";
								$prepared_query = $wpdb->prepare($query, ...$sanitized_keys);
								$fresh_activations = $wpdb->get_results($prepared_query, ARRAY_A);
							} else {
								$fresh_activations = array();
							}
						}
						
						if (!empty($fresh_activations) && is_array($fresh_activations)) {
							foreach ($fresh_activations as $activation) {
								// Sanitize activation data
								$domain = isset($activation['domain']) ? sanitize_text_field($activation['domain']) : '';
								if (empty($domain)) {
									continue; // Skip invalid activations
								}
								
								// Avoid duplicate domains (in case there are multiple activations for same domain)
								if (!isset($all_domain_activations[$domain])) {
									$all_domain_activations[$domain] = array(
										'domain' => esc_html($domain),
										'license_key' => isset($activation['license_key']) ? esc_html($activation['license_key']) : '',
										'status' => isset($activation['status']) ? esc_html($activation['status']) : 'active',
										'activated_at' => isset($activation['activated_at']) ? esc_html($activation['activated_at']) : '',
										'last_checked' => isset($activation['last_checked']) ? esc_html($activation['last_checked']) : '',
										'domain_accessible' => isset($activation['domain_accessible']) ? (bool)$activation['domain_accessible'] : null
									);
								}
							}
						}
					}
					
					// Use actual count from domain activations
					$actual_activations = count($all_domain_activations);
					?>
					<?php if ( $has_actual_licenses ) : ?>
						<!-- Unified Domain Management Section -->
						<div class="vrstore-domain-management-section vrstore-mt-8">
						<div class="vrstore-card vrstore-p-6">
							<div class="vrstore-domain-header vrstore-flex vrstore-justify-between vrstore-items-center vrstore-mb-4">
								<h3 class="vrstore-text-lg vrstore-font-semibold"><?php esc_html_e( 'Domain Management', 'vira-store' ); ?></h3>
								<div class="vrstore-domain-actions">
									<button class="vrstore-btn vrstore-btn-primary vrstore-btn-sm vrstore-add-domain-unified" 
											data-activation-limit="<?php echo esc_attr( $total_activation_limit ); ?>"
											data-current-activations="<?php echo esc_attr( $actual_activations ); ?>">
										<?php esc_html_e( 'Add Domain', 'vira-store' ); ?>
									</button>
									<button class="vrstore-btn vrstore-btn-secondary vrstore-btn-sm vrstore-refresh-domains-unified">
										<?php esc_html_e( 'Refresh', 'vira-store' ); ?>
									</button>
								</div>
							</div>
							
							<!-- Domain Activation Limit Info -->
							<div class="vrstore-domain-limit-info vrstore-mb-4">
								<div class="vrstore-activation-progress">
									<div class="vrstore-progress-bar-container">
										<div class="vrstore-progress-bar">
											<div class="vrstore-progress-fill" style="width: <?php echo $total_activation_limit > 0 ? min(100, ($actual_activations / $total_activation_limit) * 100) : 0; ?>%;"></div>
										</div>
									</div>
									<div class="vrstore-progress-text">
										<?php if ( $total_activation_limit > 0 ) : ?>
											<?php printf( is_textdomain_loaded('vira-store') ? esc_html__( '%1$d of %2$d total domain activations used', 'vira-store' ) : esc_html( '%1$d of %2$d total domain activations used' ), $actual_activations, $total_activation_limit ); ?>
										<?php else : ?>
											<?php printf( is_textdomain_loaded('vira-store') ? esc_html__( '%d domains activated (Unlimited)', 'vira-store' ) : esc_html( '%d domains activated (Unlimited)' ), $actual_activations ); ?>
										<?php endif; ?>
										<p class="vrstore-text-sm vrstore-text-gray-600 vrstore-mt-1">
											<?php printf( is_textdomain_loaded('vira-store') ? esc_html__( 'Based on %d license(s) in your account', 'vira-store' ) : esc_html( 'Based on %d license(s) in your account' ), count($licenses) ); ?>
										</p>
									</div>
								</div>
							</div>
							
							<!-- Domain Activations Table -->
							<div class="vrstore-domains-container">
								<?php if ( ! empty( $all_domain_activations ) ) : ?>
									<!-- Desktop Table -->
									<table class="vrstore-table vrstore-activations-table">
										<thead class="vrstore-table-header">
										<tr>
											<th class="vrstore-table-th"><?php esc_html_e( 'Domain', 'vira-store' ); ?></th>
											<th class="vrstore-table-th"><?php esc_html_e( 'License Key', 'vira-store' ); ?></th>
											<th class="vrstore-table-th"><?php esc_html_e( 'Status', 'vira-store' ); ?></th>
											<th class="vrstore-table-th"><?php esc_html_e( 'Activated', 'vira-store' ); ?></th>
											<th class="vrstore-table-th"><?php esc_html_e( 'Actions', 'vira-store' ); ?></th>
										</tr>
									</thead>
										<tbody id="vrstore-domains-list-unified">
											<?php foreach ( $all_domain_activations as $activation ) : ?>
												<tr data-domain="<?php echo esc_attr( $activation['domain'] ); ?>" data-license-key="<?php echo esc_attr( $activation['license_key'] ); ?>">
											<td class="vrstore-domain-name vrstore-table-td" data-label="<?php esc_html_e( 'Domain', 'vira-store' ); ?>">
												<strong><?php echo esc_html( $activation['domain'] ); ?></strong>
											</td>
											<td class="vrstore-license-key vrstore-table-td" data-label="<?php esc_html_e( 'License Key', 'vira-store' ); ?>">
												<code class="vrstore-font-mono vrstore-text-sm"><?php echo esc_html( substr($activation['license_key'], 0, 12) . '...' ); ?></code>
											</td>
											<td class="vrstore-domain-status vrstore-table-td" data-label="<?php esc_html_e( 'Status', 'vira-store' ); ?>">
															<?php 
															$status = $activation['status'] ?? 'active';
															$status_class = 'vrstore-status-' . strtolower( $status );
															$status_icon = $status === 'active' ? 'dashicons-yes-alt' : 'dashicons-warning';
															$status_text = ucfirst( $status );
															
															// Show domain accessibility status if available
															if ( isset( $activation['domain_accessible'] ) ) {
																if ( $activation['domain_accessible'] ) {
																	$status_text .= ' (' . (is_textdomain_loaded('vira-store') ? esc_html__( 'Online', 'vira-store' ) : 'Online') . ')';
																} else {
																	$status_text .= ' (' . (is_textdomain_loaded('vira-store') ? esc_html__( 'Offline', 'vira-store' ) : 'Offline') . ')';
																	$status_icon = 'dashicons-warning';
																}
															}
															?>
															<span class="vrstore-status-badge <?php echo esc_attr( $status_class ); ?>">
																<span class="dashicons <?php echo esc_attr( $status_icon ); ?>"></span> <?php echo esc_html( $status_text ); ?>
															</span>
														</td>
														<td class="vrstore-domain-date vrstore-table-td" data-label="<?php esc_html_e( 'Activated', 'vira-store' ); ?>">
											<?php 
											$activation_date = $activation['activated_at'] ?? '';
											if ( $activation_date ) {
												echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $activation_date ) ) );
											} else {
												echo is_textdomain_loaded('vira-store') ? esc_html__( 'N/A', 'vira-store' ) : 'N/A';
											}
											?>
										</td>
										<td class="vrstore-domain-actions vrstore-table-td" data-label="<?php esc_html_e( 'Actions', 'vira-store' ); ?>">
															<button class="vrstore-btn vrstore-btn-danger vrstore-btn-sm vrstore-deactivate-domain-unified"
																	data-license-key="<?php echo esc_attr( $activation['license_key'] ); ?>"
																	data-domain="<?php echo esc_attr( $activation['domain'] ); ?>"
																	title="<?php esc_attr_e( 'Deactivate this domain', 'vira-store' ); ?>">
																<span class="dashicons dashicons-dismiss"></span> <?php esc_html_e( 'Deactivate', 'vira-store' ); ?>
															</button>
														</td>
												</tr>
											<?php endforeach; ?>
										</tbody>
									</table>
									
									<!-- Mobile Cards (hidden on desktop) -->
									<div class="vrstore-mobile-cards" style="display: none;" id="vrstore-domains-list-unified-mobile">
										<?php foreach ( $all_domain_activations as $activation ) : ?>
											<div class="vrstore-mobile-card" data-domain="<?php echo esc_attr( $activation['domain'] ); ?>" data-license-key="<?php echo esc_attr( $activation['license_key'] ); ?>">
												<div class="vrstore-mobile-card-header">
													<h4 class="vrstore-mobile-card-title"><?php echo esc_html( $activation['domain'] ); ?></h4>
													<span class="vrstore-mobile-card-status">
														<?php 
														$status = $activation['status'] ?? 'active';
														$status_class = 'vrstore-status-' . strtolower( $status );
														$status_icon = $status === 'active' ? 'dashicons-yes-alt' : 'dashicons-warning';
														$status_text = ucfirst( $status );
														
														// Show domain accessibility status if available
														if ( isset( $activation['domain_accessible'] ) ) {
															if ( $activation['domain_accessible'] ) {
																$status_text .= ' (' . (is_textdomain_loaded('vira-store') ? esc_html__( 'Online', 'vira-store' ) : 'Online') . ')';
															} else {
																$status_text .= ' (' . (is_textdomain_loaded('vira-store') ? esc_html__( 'Offline', 'vira-store' ) : 'Offline') . ')';
																$status_icon = 'dashicons-warning';
															}
														}
														?>
														<span class="vrstore-status-badge <?php echo esc_attr( $status_class ); ?>">
															<span class="dashicons <?php echo esc_attr( $status_icon ); ?>"></span> <?php echo esc_html( $status_text ); ?>
														</span>
													</span>
	
												</div>
												<div class="vrstore-mobile-card-body">
													<div class="vrstore-mobile-card-row">
														<span class="vrstore-mobile-card-label"><?php esc_html_e( 'License Key', 'vira-store' ); ?></span>
														<span class="vrstore-mobile-card-value">
															<code class="vrstore-font-mono vrstore-text-sm"><?php echo esc_html( substr($activation['license_key'], 0, 12) . '...' ); ?></code>
														</span>
													</div>
													<div class="vrstore-mobile-card-row">
														<span class="vrstore-mobile-card-label"><?php esc_html_e( 'Activated', 'vira-store' ); ?></span>
														<span class="vrstore-mobile-card-value">
															<?php 
															$activation_date = $activation['activated_at'] ?? '';
															if ( $activation_date ) {
																echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $activation_date ) ) );
															} else {
																echo is_textdomain_loaded('vira-store') ? esc_html__( 'N/A', 'vira-store' ) : 'N/A';
															}
															?>
														</span>
													</div>
												</div>
												<div class="vrstore-mobile-card-actions">
													<button class="vrstore-btn vrstore-btn-danger vrstore-btn-sm vrstore-deactivate-domain-unified"
															data-license-key="<?php echo esc_attr( $activation['license_key'] ); ?>"
															data-domain="<?php echo esc_attr( $activation['domain'] ); ?>"
															title="<?php esc_attr_e( 'Deactivate this domain', 'vira-store' ); ?>">
														<span class="dashicons dashicons-dismiss"></span> <?php esc_html_e( 'Deactivate', 'vira-store' ); ?>
													</button>
												</div>
											</div>
										<?php endforeach; ?>
									</div>
								<?php else : ?>
									<div class="vrstore-no-domains">
										<div class="vrstore-empty-state vrstore-text-center vrstore-p-8">
											<div class="vrstore-empty-icon vrstore-mb-4">
												<span class="dashicons dashicons-admin-site-alt3 vrstore-text-4xl vrstore-text-gray-400"></span>
											</div>
											<h5 class="vrstore-text-lg vrstore-font-semibold vrstore-mb-2"><?php esc_html_e( 'No Active Domains', 'vira-store' ); ?></h5>
											<p class="vrstore-text-gray-600 vrstore-mb-4"><?php esc_html_e( 'You have not activated your licenses on any domains yet.', 'vira-store' ); ?></p>
											<button class="vrstore-btn vrstore-btn-primary vrstore-add-domain-unified" 
													data-activation-limit="<?php echo esc_attr( $total_activation_limit ); ?>"
													data-current-activations="0">
												<?php esc_html_e( 'Activate First Domain', 'vira-store' ); ?>
											</button>
										</div>
									</div>
								<?php endif; ?>
							</div>
						</div>
					</div>
				<?php endif; ?>
				<?php else : ?>
					<div class="vrstore-no-licenses vrstore-card vrstore-p-8">
						<div class="vrstore-empty-state vrstore-text-center">
							<div class="vrstore-empty-icon vrstore-mb-4">
								<span class="dashicons dashicons-admin-network vrstore-text-4xl vrstore-text-gray-400"></span>
							</div>
							<h3 class="vrstore-text-xl vrstore-font-bold vrstore-mb-2 vrstore-text-gray-800"><?php esc_html_e( 'No Licenses Found', 'vira-store' ); ?></h3>
							<p class="vrstore-text-gray-600 vrstore-mb-4"><?php esc_html_e( 'You do not have any licenses yet. Purchase a product to get your first license!', 'vira-store' ); ?></p>
							<div class="vrstore-empty-actions">
								<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="vrstore-btn vrstore-btn-primary">
									<?php esc_html_e( 'Browse Products', 'vira-store' ); ?>
								</a>
							</div>
							<?php 
							// Debug info removed for security reasons - sensitive user data should not be exposed in frontend
							?>
						</div>
					</div>
				<?php endif; ?>
				</div>
			</div>
	</div>
	
	<!-- Unified Domain Management Modals -->
	<!-- Add Domain Modal -->
	<div id="vrstore-add-domain-unified-modal" class="vrstore-modal" style="display: none;">
		<div class="vrstore-modal-overlay"></div>
		<div class="vrstore-modal-content vrstore-card">
			<div class="vrstore-modal-header vrstore-p-6 vrstore-border-b vrstore-border-gray-200">
				<h3 class="vrstore-text-xl vrstore-font-bold"><?php esc_html_e( 'Activate Domain', 'vira-store' ); ?></h3>
				<button class="vrstore-modal-close vrstore-btn vrstore-btn-ghost vrstore-btn-sm">
					<span class="dashicons dashicons-no-alt"></span>
				</button>
			</div>
			<div class="vrstore-modal-body vrstore-p-6">
				<form id="vrstore-add-domain-unified-form" class="vrstore-domain-form vrstore-space-y-4">
					<div class="vrstore-form-row">
						<label for="vrstore-domain-unified-input" class="vrstore-label"><?php esc_html_e( 'Domain Name', 'vira-store' ); ?></label>
						<input type="text" id="vrstore-domain-unified-input" name="domain" 
							   placeholder="<?php esc_attr_e( 'example.com or https://example.com', 'vira-store' ); ?>"
							   class="vrstore-input" required>
						<small class="vrstore-text-sm vrstore-text-gray-600 vrstore-mt-1">
							<?php esc_html_e( 'Enter the domain where you want to activate one of your licenses. The system will automatically use an available license.', 'vira-store' ); ?>
						</small>
					</div>
					
					<div class="vrstore-domain-limit-warning" id="vrstore-activation-limit-unified-warning" style="display: none;">
						<div class="vrstore-alert vrstore-alert-warning">
							<span class="dashicons dashicons-warning"></span>
							<span class="vrstore-alert-text">
								<?php esc_html_e( 'You have reached your total activation limit. Please deactivate a domain before activating a new one.', 'vira-store' ); ?>
							</span>
						</div>
					</div>
				</form>
			</div>
			<div class="vrstore-modal-footer vrstore-p-6 vrstore-border-t vrstore-border-gray-200 vrstore-flex vrstore-gap-3 vrstore-justify-end">
				<button type="button" class="vrstore-btn vrstore-btn-secondary vrstore-modal-cancel">
					<?php esc_html_e( 'Cancel', 'vira-store' ); ?>
				</button>
				<button type="submit" form="vrstore-add-domain-unified-form" class="vrstore-btn vrstore-btn-primary vrstore-add-domain-unified-submit">
					<span class="vrstore-button-text"><?php esc_html_e( 'Activate Domain', 'vira-store' ); ?></span>
					<span class="vrstore-button-spinner" style="display: none;">
						<span class="dashicons dashicons-update spin"></span>
					</span>
				</button>
			</div>
		</div>
	</div>

	<!-- Confirm Deactivation Modal -->
	<div id="vrstore-deactivate-domain-unified-modal" class="vrstore-modal" style="display: none;">
		<div class="vrstore-modal-overlay"></div>
		<div class="vrstore-modal-content vrstore-card">
			<div class="vrstore-modal-header vrstore-p-6 vrstore-border-b vrstore-border-gray-200">
				<h3 class="vrstore-text-xl vrstore-font-bold"><?php esc_html_e( 'Confirm Domain Deactivation', 'vira-store' ); ?></h3>
				<button class="vrstore-modal-close vrstore-btn vrstore-btn-ghost vrstore-btn-sm">
					<span class="dashicons dashicons-no-alt"></span>
				</button>
			</div>
			<div class="vrstore-modal-body vrstore-p-6">
				<div class="vrstore-alert vrstore-alert-danger">
					<span class="dashicons dashicons-warning"></span>
					<div class="vrstore-alert-content">
						<p class="vrstore-font-medium"><strong><?php esc_html_e( 'Are you sure you want to deactivate this domain?', 'vira-store' ); ?></strong></p>
						<p id="vrstore-deactivate-domain-unified-name" class="vrstore-font-mono vrstore-text-sm vrstore-bg-gray-100 vrstore-px-2 vrstore-py-1 vrstore-rounded vrstore-my-2"></p>
						<p id="vrstore-deactivate-license-unified-info" class="vrstore-text-sm vrstore-text-gray-600 vrstore-mb-2"></p>
						<p class="vrstore-text-sm vrstore-text-gray-600"><?php esc_html_e( 'This action will immediately deactivate the license on this domain. The domain can be reactivated later if you have available activations.', 'vira-store' ); ?></p>
					</div>
				</div>
			</div>
			<div class="vrstore-modal-footer vrstore-p-6 vrstore-border-t vrstore-border-gray-200 vrstore-flex vrstore-gap-3 vrstore-justify-end">
				<button type="button" class="vrstore-btn vrstore-btn-secondary vrstore-modal-cancel">
					<?php esc_html_e( 'Cancel', 'vira-store' ); ?>
				</button>
				<button type="button" class="vrstore-btn vrstore-btn-danger vrstore-confirm-deactivate-unified">
					<span class="vrstore-button-text"><?php esc_html_e( 'Deactivate Domain', 'vira-store' ); ?></span>
					<span class="vrstore-button-spinner" style="display: none;">
						<span class="dashicons dashicons-update spin"></span>
					</span>
				</button>
			</div>
			</div>
		</div>

	<!-- Downloads Modal -->
	<div id="vrstore-downloads-modal" class="vrstore-modal" style="display: none;">
		<div class="vrstore-modal-overlay"></div>
		<div class="vrstore-modal-content vrstore-card" style="max-width: 600px;">
			<div class="vrstore-modal-header vrstore-p-6 vrstore-border-b vrstore-border-gray-200">
				<h3 class="vrstore-text-xl vrstore-font-bold" id="vrstore-downloads-modal-title"><?php echo is_textdomain_loaded('vira-store') ? esc_html__('Product Downloads', 'vira-store') : esc_html('Product Downloads'); ?></h3>
				<button class="vrstore-modal-close vrstore-btn vrstore-btn-ghost vrstore-btn-sm">
					<span class="dashicons dashicons-no-alt"></span>
				</button>
			</div>
			<div class="vrstore-modal-body vrstore-p-6">
				<div class="vrstore-downloads-list" id="vrstore-downloads-list">
					<!-- Downloads will be populated via JavaScript -->
					<div class="vrstore-loading">
						<span class="dashicons dashicons-update spin"></span>
						<span><?php echo is_textdomain_loaded('vira-store') ? esc_html__('Loading downloads...', 'vira-store') : esc_html('Loading downloads...'); ?></span>
					</div>
				</div>
			</div>
			<div class="vrstore-modal-footer vrstore-p-6 vrstore-border-t vrstore-border-gray-200 vrstore-flex vrstore-gap-3 vrstore-justify-end">
				<button type="button" class="vrstore-btn vrstore-btn-secondary vrstore-modal-close">
					<?php echo is_textdomain_loaded('vira-store') ? esc_html__('Close', 'vira-store') : esc_html('Close'); ?>
				</button>
			</div>
		</div>
	</div>

	<!-- Success/Error Messages Container -->
	<div id="vrstore-domain-messages" class="vrstore-messages-container" style="display: none;"></div>

	<!-- Support: Create Ticket Modal -->
	<div id="vrstore-create-ticket-modal" class="vrstore-modal">
		<div class="vrstore-modal-overlay">
			<div class="vrstore-modal-container vrstore-modal-large">
				<div class="vrstore-modal-header">
					<h3 class="vrstore-modal-title"><?php _e('Create Support Ticket', 'vira-store'); ?></h3>
					<button class="vrstore-modal-close" type="button" aria-label="<?php esc_attr_e('Close modal', 'vira-store'); ?>">
						<span class="dashicons dashicons-no-alt"></span>
					</button>
				</div>
				<div class="vrstore-modal-body">
					<form id="vrstore-create-ticket-form" class="vrstore-modal-form">
						<div class="vrstore-form-group">
							<label for="vrstore-ticket-subject" class="vrstore-form-label"><?php _e('Subject', 'vira-store'); ?></label>
							<input type="text" id="vrstore-ticket-subject" name="subject" class="vrstore-form-input" required 
							       placeholder="<?php esc_attr_e('Briefly describe your issue', 'vira-store'); ?>"
							       autocomplete="off">
						</div>
						<div class="vrstore-form-group">
							<label for="vrstore-ticket-product" class="vrstore-form-label"><?php _e('Related Product (optional)', 'vira-store'); ?></label>
							<select id="vrstore-ticket-product" name="product_id" class="vrstore-form-select">
								<option value=""><?php _e('General (no specific product)', 'vira-store'); ?></option>
								<?php foreach ($customer_products as $pid => $ptitle): ?>
									<option value="<?php echo esc_attr($pid); ?>"><?php echo esc_html($ptitle); ?></option>
								<?php endforeach; ?>
							</select>
						</div>
						<div class="vrstore-form-group">
							<label for="vrstore-ticket-priority" class="vrstore-form-label"><?php _e('Priority', 'vira-store'); ?></label>
							<select id="vrstore-ticket-priority" name="priority" class="vrstore-form-select">
								<option value="normal"><?php _e('Normal', 'vira-store'); ?></option>
								<option value="low"><?php _e('Low', 'vira-store'); ?></option>
								<option value="high"><?php _e('High', 'vira-store'); ?></option>
								<option value="urgent"><?php _e('Urgent', 'vira-store'); ?></option>
							</select>
						</div>
						<div class="vrstore-form-group">
							<label for="vrstore-ticket-message" class="vrstore-form-label"><?php _e('Describe your issue', 'vira-store'); ?></label>
							<textarea id="vrstore-ticket-message" name="message" class="vrstore-form-textarea" rows="6" required 
							          placeholder="<?php esc_attr_e('Provide as much detail as possible. You can include steps to reproduce, expected vs actual behavior, etc.', 'vira-store'); ?>"></textarea>
						</div>
					</form>
				</div>
				<div class="vrstore-modal-footer">
					<button type="button" class="vrstore-btn vrstore-btn-secondary vrstore-modal-close"><?php _e('Cancel', 'vira-store'); ?></button>
					<button type="submit" form="vrstore-create-ticket-form" class="vrstore-btn vrstore-btn-primary" id="vrstore-submit-ticket-btn">
						<span class="vrstore-button-text"><?php _e('Submit Ticket', 'vira-store'); ?></span>
						<span class="vrstore-button-spinner" style="display:none;">
							<span class="vrstore-spinner"></span>
							<?php _e('Creating...', 'vira-store'); ?>
						</span>
					</button>
				</div>
			</div>
		</div>
	</div>

	<!-- Support: View Ticket Modal -->
	<div id="vrstore-ticket-modal" class="vrstore-modal">
		<div class="vrstore-modal-overlay">
			<div class="vrstore-modal-container vrstore-modal-large">
				<div class="vrstore-modal-header">
					<h3 id="vrstore-ticket-modal-title" class="vrstore-modal-title"><?php _e('Ticket', 'vira-store'); ?></h3>
					<button class="vrstore-modal-close" type="button" aria-label="<?php esc_attr_e('Close modal', 'vira-store'); ?>">
						<span class="dashicons dashicons-no-alt"></span>
					</button>
				</div>
				<div class="vrstore-modal-body">
					<div id="vrstore-ticket-loading" class="vrstore-modal-loading" style="display:none;">
						<span class="vrstore-spinner"></span>
						<span><?php _e('Loading ticket...', 'vira-store'); ?></span>
					</div>
					<div id="vrstore-ticket-content" style="display:none;"></div>
				</div>
				<div class="vrstore-modal-footer">
					<button type="button" class="vrstore-btn vrstore-btn-secondary vrstore-modal-close"><?php _e('Close', 'vira-store'); ?></button>
				</div>
			</div>
		</div>
	</div>

	<!-- Extended Support Modal -->
	<div id="vrstore-extended-support-modal" class="vrstore-modal vrstore-extended-support-modal">
		<div class="vrstore-modal-overlay">
			<div class="vrstore-modal-container vrstore-modal-medium">
				<div class="vrstore-modal-header">
					<h3 class="vrstore-modal-title"><?php _e('Extended Support', 'vira-store'); ?></h3>
					<button class="vrstore-modal-close" type="button" aria-label="<?php esc_attr_e('Close modal', 'vira-store'); ?>">
						<span class="dashicons dashicons-no-alt"></span>
					</button>
				</div>
				<div class="vrstore-modal-body">
					<div id="vrstore-extended-support-loading" class="vrstore-modal-loading" style="display:none;">
						<span class="vrstore-spinner"></span>
						<span><?php _e('Loading pricing...', 'vira-store'); ?></span>
					</div>
					<div id="vrstore-extended-support-content" class="vrstore-extended-support-content" style="display:none;">
						<!-- Content will be loaded dynamically -->
					</div>
				</div>
				<div class="vrstore-modal-footer" id="vrstore-extended-support-footer">
					<button type="button" class="vrstore-btn vrstore-btn-primary vrstore-btn-sm" id="vrstore-purchase-extended-support" style="display:none;">
						<span class="vrstore-button-text"><?php _e('Purchase', 'vira-store'); ?></span>
						<span class="vrstore-button-spinner" style="display:none;">
							<span class="vrstore-spinner"></span>
							<?php _e('Processing...', 'vira-store'); ?>
						</span>
					</button>
				</div>
			</div>
		</div>
	</div>

	<!-- Edit Profile Modal -->
	<div id="vrstore-edit-profile-modal" class="vrstore-modal" style="display: none;">
		<div class="vrstore-modal-overlay"></div>
		<div class="vrstore-modal-content vrstore-modal-medium">
			<div class="vrstore-modal-header">
				<h3 class="vrstore-modal-title"><?php _e('Edit Profile', 'vira-store'); ?></h3>
				<button class="vrstore-modal-close" type="button" aria-label="<?php esc_attr_e('Close modal', 'vira-store'); ?>">
					<span class="dashicons dashicons-no-alt"></span>
				</button>
			</div>
			<div class="vrstore-modal-body">
				<form id="vrstore-edit-profile-form" class="vrstore-edit-profile-form">
					<?php wp_nonce_field('vrstore_edit_profile', 'vrstore_profile_nonce'); ?>
					<input type="hidden" name="action" value="vrstore_update_customer_profile">
					<input type="hidden" name="user_id" value="<?php echo esc_attr($user_id); ?>">
					
					<div class="vrstore-form-group">
						<label for="profile_display_name"><?php _e('Display Name', 'vira-store'); ?></label>
						<input type="text" id="profile_display_name" name="display_name" value="<?php echo esc_attr($user->display_name); ?>" class="vrstore-form-control" required>
					</div>
					
					<div class="vrstore-form-group">
						<label for="profile_email"><?php _e('Email Address', 'vira-store'); ?></label>
						<input type="email" id="profile_email" name="user_email" value="<?php echo esc_attr($user->user_email); ?>" class="vrstore-form-control" required>
					</div>
					
					<div class="vrstore-form-group">
						<label for="profile_first_name"><?php _e('First Name', 'vira-store'); ?></label>
						<input type="text" id="profile_first_name" name="first_name" value="<?php echo esc_attr(get_user_meta($user_id, 'first_name', true)); ?>" class="vrstore-form-control">
					</div>
					
					<div class="vrstore-form-group">
						<label for="profile_last_name"><?php _e('Last Name', 'vira-store'); ?></label>
						<input type="text" id="profile_last_name" name="last_name" value="<?php echo esc_attr(get_user_meta($user_id, 'last_name', true)); ?>" class="vrstore-form-control">
					</div>
					
					<div class="vrstore-form-group">
						<label for="profile_phone"><?php _e('Phone Number', 'vira-store'); ?></label>
						<input type="tel" id="profile_phone" name="billing_phone" value="<?php echo esc_attr(get_user_meta($user_id, 'billing_phone', true)); ?>" class="vrstore-form-control">
					</div>
					
					<div class="vrstore-form-group">
						<label for="profile_city"><?php _e('City', 'vira-store'); ?></label>
						<input type="text" id="profile_city" name="billing_city" value="<?php echo esc_attr(get_user_meta($user_id, 'billing_city', true)); ?>" class="vrstore-form-control">
					</div>
					
					<div class="vrstore-form-group">
						<label for="profile_username"><?php _e('Username', 'vira-store'); ?></label>
						<input type="text" id="profile_username" name="user_login" value="<?php echo esc_attr($user->user_login); ?>" class="vrstore-form-control" readonly>
						<small class="vrstore-form-help"><?php _e('Username cannot be changed after registration.', 'vira-store'); ?></small>
					</div>
				</form>
			</div>
			<div class="vrstore-modal-footer">
				<button type="button" class="vrstore-btn vrstore-btn-secondary vrstore-modal-close"><?php _e('Cancel', 'vira-store'); ?></button>
				<button type="submit" form="vrstore-edit-profile-form" class="vrstore-btn vrstore-btn-primary vrstore-save-profile-btn" id="vrstore-save-profile-btn">
					<span class="vrstore-button-text"><?php _e('Save Changes', 'vira-store'); ?></span>
					<span class="vrstore-button-spinner" style="display:none;">
						<span class="vrstore-spinner"></span>
						<?php _e('Saving...', 'vira-store'); ?>
					</span>
				</button>
			</div>
		</div>
	</div>

<?php
// Support ticket JavaScript functionality moved to assets/js/frontend.js for better performance and maintainability
// Modal handling, form validation, AJAX requests, and notifications are now handled externally
?>

<script>
// Pass AJAX variables to JavaScript for ticket support functionality
window.vrstore_ajax_vars = window.vrstore_ajax_vars || {};
Object.assign(window.vrstore_ajax_vars, {
	ajax_url: '<?php echo admin_url('admin-ajax.php'); ?>',
	nonce: '<?php echo wp_create_nonce('vrstore_frontend_nonce'); ?>',
	user_id: '<?php echo get_current_user_id(); ?>'
});
</script>
	
</div>