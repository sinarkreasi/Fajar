<?php
/**
 * Single product shortcode template.
 *
 * @package Vira_Store
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Variables available: $product, $product_id.

// Track affiliate visit if referral code is present
if (isset($_GET['ref']) && class_exists('VRSTORE_Affiliate')) {
    $affiliate = VRSTORE_Affiliate::get_instance();
    $affiliate->track_visit($_GET['ref'], $product_id, 'product');
}

// Get product meta.
$price = get_post_meta( $product_id, '_vrstore_product_price', true );
$sale_price = get_post_meta( $product_id, '_vrstore_product_sale_price', true );
$license_pricing = get_post_meta( $product_id, '_vrstore_product_license_pricing', true );

// Check if price exists
if ( empty( $price ) || !is_numeric( $price ) ) {
	$price = ''; // Empty price instead of '0' for better display
}

// Get user currency from currency converter for proper symbol display
$settings = VRSTORE_Settings::get_instance();
$currency_converter = VRSTORE_Currency_Converter::get_instance();
$user_currency = $currency_converter->get_user_currency();
$product_instance = VRSTORE_Product::get_instance();
$currency_symbol = $product_instance->get_currency_symbol( $user_currency );

// Get custom license types from settings FIRST (before pricing calculations)
$custom_license_types = $settings->get_setting( 'custom_license_types', [] );
if ( ! is_array( $custom_license_types ) ) {
	$custom_license_types = [];
}

// Get license type availability settings for this product
$license_availability = get_post_meta( $product_id, '_vrstore_product_license_availability', true );
if ( ! is_array( $license_availability ) ) {
	$license_availability = [];
}

// Filter license types based on availability
if ( ! empty( $license_availability ) ) {
	$available_license_types = [];
	foreach ( $custom_license_types as $type ) {
		$slug = isset( $type['slug'] ) ? $type['slug'] : sanitize_title( $type['label'] );
		// Show license type if it's explicitly enabled OR if no availability setting exists (default to available)
		if ( ! isset( $license_availability[ $slug ] ) || $license_availability[ $slug ] === true ) {
			$available_license_types[] = $type;
		}
	}
	$custom_license_types = $available_license_types;
}

// Get custom license pricing data
$custom_license_pricing = get_post_meta( $product_id, '_vrstore_product_custom_license_pricing', true );
if ( ! is_array( $custom_license_pricing ) ) {
	$custom_license_pricing = [];
}

// Prepare license pricing data for JavaScript
$license_pricing_data = [];
if ( is_array( $license_pricing ) && ! empty( $license_pricing ) ) {
	$license_pricing_data = $license_pricing;
}

// Find the lowest price from available license types (like products.php does)
$lowest_price = null;
$lowest_sale_price = null;
$formatted_price = '';
$formatted_sale_price = '';

if ( ! empty( $custom_license_types ) ) {
	foreach ( $custom_license_types as $type ) {
		$slug = isset( $type['slug'] ) ? $type['slug'] : sanitize_title( $type['label'] );
		$license_price = null;
		$license_sale_price = null;
		
		// Check for product-specific pricing first
		if ( isset( $license_pricing_data[ $slug ] ) && is_array( $license_pricing_data[ $slug ] ) ) {
			$license_price = isset( $license_pricing_data[ $slug ]['price'] ) ? $license_pricing_data[ $slug ]['price'] : null;
			$license_sale_price = isset( $license_pricing_data[ $slug ]['sale_price'] ) ? $license_pricing_data[ $slug ]['sale_price'] : null;
		} elseif ( isset( $custom_license_pricing[ $slug ] ) && is_array( $custom_license_pricing[ $slug ] ) ) {
			$license_price = isset( $custom_license_pricing[ $slug ]['price'] ) ? $custom_license_pricing[ $slug ]['price'] : null;
			$license_sale_price = isset( $custom_license_pricing[ $slug ]['sale_price'] ) ? $custom_license_pricing[ $slug ]['sale_price'] : null;
		} else {
			// Use global settings defaults
			$license_price = isset( $type['regular_price'] ) ? $type['regular_price'] : null;
			$license_sale_price = isset( $type['sale_price'] ) ? $type['sale_price'] : null;
		}
		
		// Track lowest prices
		if ( $license_price !== null && is_numeric( $license_price ) ) {
			if ( $lowest_price === null || floatval( $license_price ) < floatval( $lowest_price ) ) {
				$lowest_price = $license_price;
			}
		}
		
		if ( $license_sale_price !== null && is_numeric( $license_sale_price ) ) {
			if ( $lowest_sale_price === null || floatval( $license_sale_price ) < floatval( $lowest_sale_price ) ) {
				$lowest_sale_price = $license_sale_price;
			}
		}
	}
}

// Format the lowest prices if available, otherwise fall back to basic price
// Use explicit no K/M formatting to ensure consistency with buy button dropdown
if ( $lowest_price !== null && is_numeric( $lowest_price ) ) {
	$formatted_price = $currency_converter->format_price( floatval( $lowest_price ), '', false );
} elseif ( ! empty( $price ) && is_numeric( $price ) ) {
	$formatted_price = $currency_converter->format_price( floatval( $price ), '', false );
}

if ( $lowest_sale_price !== null && is_numeric( $lowest_sale_price ) ) {
	$formatted_sale_price = $currency_converter->format_price( floatval( $lowest_sale_price ), '', false );
} elseif ( ! empty( $sale_price ) && is_numeric( $sale_price ) ) {
	$formatted_sale_price = $currency_converter->format_price( floatval( $sale_price ), '', false );
}

// FALLBACK: If still no formatted price but we have basic pricing, use it
if ( empty( $formatted_price ) && ! empty( $price ) && is_numeric( $price ) && $price > 0 ) {
	$formatted_price = $currency_converter->format_price( floatval( $price ), '', false );
}

if ( empty( $formatted_sale_price ) && ! empty( $sale_price ) && is_numeric( $sale_price ) && $sale_price > 0 ) {
	$formatted_sale_price = $currency_converter->format_price( floatval( $sale_price ), '', false );
}

// Get final price for calculations
$final_price = ! empty( $lowest_sale_price ) ? $lowest_sale_price : ( ! empty( $lowest_price ) ? $lowest_price : ( ! empty( $sale_price ) ? $sale_price : $price ) );

// Get pricing mode
$pricing_mode = get_post_meta( $product_id, '_vrstore_pricing_mode', true );
if ( empty( $pricing_mode ) ) {
	$pricing_mode = 'product'; // Default to product pricing
}

// Get all product meta fields.
$features = get_post_meta( $product_id, '_vrstore_product_features', true );
$screenshots = get_post_meta( $product_id, '_vrstore_product_screenshots', true );
$demo_url = get_post_meta( $product_id, '_vrstore_product_demo_url', true );
$documentation_url = get_post_meta( $product_id, '_vrstore_product_documentation_url', true );
// Removed compatibility meta
$installation_instructions = get_post_meta( $product_id, '_vrstore_product_install_instructions', true );
$faq = get_post_meta( $product_id, '_vrstore_product_faq', true );
$changelog = get_post_meta( $product_id, '_vrstore_product_changelog', true );

// Get video configuration
$video_config = get_post_meta( $product_id, '_vrstore_product_video_config', true );

// Ensure video_config is an array with default values
if ( ! is_array( $video_config ) ) {
	$video_config = array(
		'type' => 'none',
		'youtube_url' => '',
		'video_id' => '',
		'license_info' => ''
	);

}

// Check if we have video or license info to display
$has_video = ( $video_config['type'] !== 'none' && 
	( ( $video_config['type'] === 'youtube' && ! empty( $video_config['youtube_url'] ) ) ||
	  ( $video_config['type'] === 'upload' && ! empty( $video_config['video_id'] ) ) ) );
$has_license_info = ! empty( $video_config['license_info'] );

// Check if we should show the links section
$show_links = ! empty( $demo_url ) || ! empty( $documentation_url ) || $has_video || $has_license_info;

// Define untranslated labels as a constant array
if ( ! defined( 'VRSTORE_PRODUCT_LABELS' ) ) {
	define( 'VRSTORE_PRODUCT_LABELS', [
		'add_to_cart'           => 'Buy Now',
		'description'           => 'Description',
		'features'              => 'Features',
	'screenshots'           => 'Screenshots',
		'faq'                   => 'FAQ',
		'changelog'             => 'Changelog',
		'related_products'      => 'Related Products',
		'view_details'          => 'View Details',
		'version'               => 'Version',
		'demo'                  => 'Demo',
		'documentation'         => 'Documentation',

	] );
}

if ( ! function_exists( 'vrstore_get_product_labels_translated' ) ) :
function vrstore_get_product_labels_translated() {
	$labels = [];
	foreach ( VRSTORE_PRODUCT_LABELS as $key => $label ) {
		$labels[ $key ] = is_textdomain_loaded('vira-store') ? esc_html__( $label, 'vira-store' ) : esc_html( $label );
	}
	return $labels;
}
endif;

$labels = vrstore_get_product_labels_translated();
?>
<div class="vrstore-single-product vrstore-animate-fade-in">
	<div class="vrstore-product-header vrstore-card">
		<div class="vrstore-product-image">
			<?php if ( has_post_thumbnail( $product_id ) ) : ?>
				<?php echo get_the_post_thumbnail( $product_id, 'large' ); ?>
			<?php else : ?>
				<img src="<?php echo esc_url( VRSTORE_PLUGIN_URL . 'assets/images/placeholder.svg' ); ?>" alt="<?php echo esc_attr( get_the_title( $product_id ) ); ?>">
			<?php endif; ?>
		</div>
		<div class="vrstore-product-summary">
			<h1 class="vrstore-product-title"><?php echo esc_html( get_the_title( $product_id ) ); ?></h1>
			
			<div class="vrstore-product-price" id="vrstore-product-price-display">
				<?php if ( ! empty( $formatted_price ) ) : ?>
					<?php if ( ! empty( $custom_license_types ) && count( $custom_license_types ) > 1 ) : ?>
						<span class="vrstore-price-from"><?php esc_html_e( 'from', 'vira-store' ); ?> </span>
					<?php endif; ?>
					<?php if ( ! empty( $formatted_sale_price ) ) : ?>
						<span class="vrstore-product-regular-price" style="text-decoration: line-through;"><?php echo esc_html( $formatted_price ); ?></span>
						<span class="vrstore-product-sale-price" style="color: #e74c3c; font-weight: bold;"><?php echo esc_html( $formatted_sale_price ); ?></span>
					<?php else : ?>
						<span class="vrstore-product-regular-price" style="font-weight: bold; font-size: 1.2em;"><?php echo esc_html( $formatted_price ); ?></span>
					<?php endif; ?>
				<?php else : ?>
					<span class="vrstore-product-price-empty" style="color: #999;"><?php esc_html_e( 'Price on request', 'vira-store' ); ?></span>
				<?php endif; ?>
			</div>
			
			<div class="vrstore-product-short-description">
				<?php 
				$short_description = get_post_meta( $product_id, '_vrstore_product_short_description', true );
				if ( ! empty( $short_description ) ) {
					echo wp_kses_post( wpautop( $short_description ) );
				} else {
					echo wp_kses_post( get_the_excerpt( $product_id ) );
				}
				?>
			</div>
			
			<?php if ( ! empty( $version ) ) : ?>
				<div class="vrstore-product-version">
					<strong><?php echo $labels['version']; ?>:</strong> <?php echo esc_html( $version ); ?>
				</div>
			<?php endif; ?>
			
			<?php // Removed compatibility section ?>
			
			<!-- License Type and Add to Cart Section -->
			<div class="vrstore-product-purchase-section">
				<div class="vrstore-license-cart-row">
					<div class="vrstore-license-selection">
						<label for="vrstore-license-type"><?php esc_html_e( 'Select Type:', 'vira-store' ); ?></label>
						<select id="vrstore-license-type" name="vrstore_license_type" class="vrstore-license-dropdown vrstore-form-select"
							data-currency-symbol="<?php echo esc_attr( $currency_symbol ); ?>"
							data-currency-position="<?php echo esc_attr( $settings->get_setting( 'currency_position', 'left' ) ); ?>"
							data-decimal-separator="<?php echo esc_attr( $settings->get_setting( 'decimal_separator', '.' ) ); ?>"
							data-thousand-separator="<?php echo esc_attr( $settings->get_setting( 'thousand_separator', ',' ) ); ?>"
							data-decimals="<?php echo esc_attr( $settings->get_setting( 'decimal_number', 2 ) ); ?>">
							<?php
							// Build options from custom license types (settings + per-product overrides)
							$built_any = false;
							if ( is_array( $custom_license_types ) && ! empty( $custom_license_types ) ) :
								foreach ( $custom_license_types as $type ) :
									$slug = isset( $type['slug'] ) ? $type['slug'] : sanitize_title( $type['label'] );
									$label = $type['label'] ?? ucfirst( $slug );
									// Determine effective price: per-product override -> settings -> product price fallback
									$license_price = null;
									$license_sale_price = null;
									$display_price = '';
									// Per-product license pricing override (from admin meta box)
									if ( isset( $license_pricing_data[ $slug ] ) && is_array( $license_pricing_data[ $slug ] ) ) {
										$license_price = isset( $license_pricing_data[ $slug ]['price'] ) ? $license_pricing_data[ $slug ]['price'] : null;
										$license_sale_price = isset( $license_pricing_data[ $slug ]['sale_price'] ) ? $license_pricing_data[ $slug ]['sale_price'] : null;
									// Fallback to custom license pricing if available
									} elseif ( isset( $custom_license_pricing[ $slug ] ) && is_array( $custom_license_pricing[ $slug ] ) ) {
										$license_price = isset( $custom_license_pricing[ $slug ]['price'] ) ? $custom_license_pricing[ $slug ]['price'] : null;
										$license_sale_price = isset( $custom_license_pricing[ $slug ]['sale_price'] ) ? $custom_license_pricing[ $slug ]['sale_price'] : null;
									} else {
										// Use settings defaults
										$license_price = isset( $type['regular_price'] ) ? $type['regular_price'] : null;
										$license_sale_price = isset( $type['sale_price'] ) ? $type['sale_price'] : null;
									}
									// Determine display price
									$price_text = '';
									
									if ( $license_price !== null ) {
										$price_to_use = ! empty( $license_sale_price ) ? $license_sale_price : $license_price;
										$price_text = $currency_converter->format_price( $price_to_use );
									} elseif ( ! empty( $price ) ) {
										$price_to_use = ! empty( $sale_price ) ? $sale_price : $price;
										$price_text = $currency_converter->format_price( $price_to_use );
									}
									
									if ( ! empty( $price_text ) && trim( $price_text ) !== '' ) {
										$display_price = ' - ' . $price_text;
									} else {
										$display_price = '';
									}
							?>
								<option value="<?php echo esc_attr( $slug ); ?>"
									data-price="<?php echo esc_attr( $license_price !== null ? $currency_converter->convert_price( $license_price ) : ( ! empty( $price ) ? $currency_converter->convert_price( $price ) : '' ) ); ?>"
									data-sale-price="<?php echo esc_attr( $license_sale_price !== null ? $currency_converter->convert_price( $license_sale_price ) : ( $license_price !== null ? '' : ( ! empty( $sale_price ) ? $currency_converter->convert_price( $sale_price ) : '' ) ) ); ?>">
									<?php echo esc_html( $label ); ?>
									<?php echo esc_html( $display_price ); ?>
								</option>
								<?php $built_any = true; ?>
								<?php endforeach; ?>
							<?php endif; ?>
							<?php // Removed standard license fallback ?>
						</select>
					</div>
					<div class="vrstore-product-actions">
					<button class="vrstore-btn vrstore-btn-primary vrstore-btn-lg vrstore-add-to-cart" data-product-id="<?php echo esc_attr( $product_id ); ?>">
							<?php echo $labels['add_to_cart']; ?>
						</button>
					</div>
				</div>
				
				<!-- Demo, Documentation, Video and License Links -->
				<?php if ( $show_links ) : ?>
					<div class="vrstore-product-links-small">
						<?php if ( ! empty( $demo_url ) ) : ?>
							<a href="<?php echo esc_url( $demo_url ); ?>" target="_blank" class="vrstore-btn vrstore-btn-link vrstore-btn-sm"><?php echo strtolower( $labels['demo'] ); ?></a>
						<?php endif; ?>
						<?php if ( ! empty( $documentation_url ) ) : ?>
							<?php if ( ! empty( $demo_url ) ) : ?><span class="vrstore-link-separator"> | </span><?php endif; ?>
							<a href="<?php echo esc_url( $documentation_url ); ?>" target="_blank" class="vrstore-btn vrstore-btn-link vrstore-btn-sm"><?php echo strtolower( $labels['documentation'] ); ?></a>
						<?php endif; ?>
						<?php if ( $has_video ) : ?>
							<?php if ( ! empty( $demo_url ) || ! empty( $documentation_url ) ) : ?><span class="vrstore-link-separator"> | </span><?php endif; ?>
							<a href="#" class="vrstore-btn vrstore-btn-link vrstore-btn-sm vrstore-video-modal-trigger"><?php esc_html_e( 'video', 'vira-store' ); ?></a>
						<?php endif; ?>
						<?php if ( $has_license_info ) : ?>
							<?php if ( ! empty( $demo_url ) || ! empty( $documentation_url ) || $has_video ) : ?><span class="vrstore-link-separator"> | </span><?php endif; ?>
							<a href="#" class="vrstore-btn vrstore-btn-link vrstore-btn-sm vrstore-license-modal-trigger"><?php esc_html_e( 'license info', 'vira-store' ); ?></a>
						<?php endif; ?>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
	
	<div class="vrstore-product-tabs vrstore-card">
		<div class="vrstore-tabs-nav">
			<a href="#vrstore-tab-description" class="active"><?php echo $labels['description']; ?></a>
			<?php if ( ! empty( $features ) ) : ?>
				<a href="#vrstore-tab-features"><?php echo $labels['features']; ?></a>
			<?php endif; ?>
			<?php if ( ! empty( $screenshots ) ) : ?>
				<a href="#vrstore-tab-screenshots"><?php echo $labels['screenshots']; ?></a>
			<?php endif; ?>
			<?php if ( ! empty( $faq ) ) : ?>
				<a href="#vrstore-tab-faq"><?php echo $labels['faq']; ?></a>
			<?php endif; ?>
			<?php if ( ! empty( $changelog ) ) : ?>
				<a href="#vrstore-tab-changelog"><?php echo $labels['changelog']; ?></a>
			<?php endif; ?>
		</div>
		
		<div class="vrstore-tabs-content">
			<div id="vrstore-tab-description" class="vrstore-tab-content">
				<?php echo wp_kses_post( wpautop( $product->post_content ) ); ?>
			</div>
			
			<?php if ( ! empty( $features ) ) : ?>
				<div id="vrstore-tab-features" class="vrstore-tab-content" style="display: none;">
					<ul class="vrstore-product-features-list<?php echo count($features) >= 5 ? ' vrstore-features-two-column' : ''; ?>">
						<?php foreach ( $features as $feature ) : ?>
							<li><?php echo wp_kses_post( $feature ); ?></li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endif; ?>
			
			<?php if ( ! empty( $screenshots ) ) : ?>
				<div id="vrstore-tab-screenshots" class="vrstore-tab-content" style="display: none;">
					<div class="vrstore-product-screenshots-gallery">
						<?php
						// Screenshots can be either an array of attachment IDs or a gallery shortcode
						if ( is_array( $screenshots ) && ! empty( $screenshots ) ) {
							// If it's an array of attachment IDs, create a gallery
							$gallery_ids = implode( ',', array_filter( $screenshots, 'is_numeric' ) );
							if ( ! empty( $gallery_ids ) ) {
								echo do_shortcode( '[gallery ids="' . esc_attr( $gallery_ids ) . '" columns="3" size="medium" link="file"]' );
							}
						} elseif ( is_string( $screenshots ) ) {
							// If it's a string, check if it's a gallery shortcode or process as HTML
							if ( strpos( $screenshots, '[gallery' ) !== false ) {
								// It's already a gallery shortcode
								echo do_shortcode( $screenshots );
							} else {
								// Process as HTML content
								echo wp_kses_post( $screenshots );
							}
						}
						?>
					</div>
				</div>
			<?php endif; ?>
			
			<?php if ( ! empty( $faq ) ) : ?>
				<div id="vrstore-tab-faq" class="vrstore-tab-content" style="display: none;">
					<div class="vrstore-product-faq">
						<?php if ( is_array( $faq ) ) : ?>
							<?php foreach ( $faq as $faq_item ) : ?>
								<div class="vrstore-faq-item" style="margin-bottom: 20px; border-bottom: 1px solid #eee; padding-bottom: 15px;">
									<h4 class="vrstore-faq-question" style="margin-bottom: 10px; font-weight: 600; color: #333;"><?php echo esc_html( $faq_item['question'] ); ?></h4>
									<div class="vrstore-faq-answer" style="color: #666; line-height: 1.6;"><?php echo wp_kses_post( wpautop( $faq_item['answer'] ) ); ?></div>
								</div>
							<?php endforeach; ?>
						<?php else : ?>
							<?php echo wp_kses_post( wpautop( $faq ) ); ?>
						<?php endif; ?>
					</div>
				</div>
			<?php endif; ?>
			
			<?php if ( ! empty( $changelog ) ) : ?>
				<div id="vrstore-tab-changelog" class="vrstore-tab-content" style="display: none;">
					<div class="vrstore-product-changelog">
						<?php echo wp_kses_post( wpautop( $changelog ) ); ?>
					</div>
				</div>
			<?php endif; ?>
		</div>
	</div>
	
	<?php
// Get related products.
$related_args = array(
	'post_type'      => 'vrstore_product',
	'posts_per_page' => 3,
	'post__not_in'   => array( $product_id ),
	'post_status'    => array('publish'), // Only published products
	'orderby'        => 'rand',
);
	
	// Get product categories.
	$product_cats = wp_get_post_terms( $product_id, 'vrstore_product_category', array( 'fields' => 'ids' ) );
	
	// If product has categories, get related products from same categories.
	if ( ! empty( $product_cats ) ) {
	$related_args['tax_query'] = array(
		array(
			'taxonomy' => 'vrstore_product_category',
			'field'    => 'term_id',
			'terms'    => $product_cats,
		),
	);
}

// Apply visibility filters to related products
if (class_exists('VRSTORE_Product')) {
	$related_args = VRSTORE_Product::apply_visibility_filters($related_args, 'catalog');
}

$related_products = new WP_Query( $related_args );
	
	// Show related products if any.
	if ( $related_products->have_posts() ) :
		?>
		<div class="vrstore-related-products">
			<h2><?php echo $labels['related_products']; ?></h2>
			
			<div class="vrstore-products-grid vrstore-columns-3">
				<?php while ( $related_products->have_posts() ) : $related_products->the_post(); ?>
					<?php
					$related_id = get_the_ID();
					$related_price = get_post_meta( $related_id, '_vrstore_product_price', true );
					$related_sale_price = get_post_meta( $related_id, '_vrstore_product_sale_price', true );
					
					// Format prices.
					$related_formatted_price = $currency_converter->format_price( $related_price );
					$related_formatted_sale_price = ! empty( $related_sale_price ) ? $currency_converter->format_price( $related_sale_price ) : '';
					?>
					<div class="vrstore-product vrstore-card">
						<div class="vrstore-product-image">
							<a href="<?php the_permalink(); ?>">
								<?php if ( has_post_thumbnail() ) : ?>
									<?php the_post_thumbnail( 'medium' ); ?>
								<?php else : ?>
									<img src="<?php echo esc_url( VRSTORE_PLUGIN_URL . 'assets/images/placeholder.svg' ); ?>" alt="<?php the_title_attribute(); ?>">
								<?php endif; ?>
							</a>
						</div>
						<div class="vrstore-product-content">
							<h3 class="vrstore-product-title">
								<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
							</h3>
							<div class="vrstore-product-price">
								<?php if ( ! empty( $related_sale_price ) ) : ?>
									<span class="vrstore-product-regular-price"><?php echo esc_html( $related_formatted_price ); ?></span>
									<span class="vrstore-product-sale-price"><?php echo esc_html( $related_formatted_sale_price ); ?></span>
								<?php else : ?>
									<span class="vrstore-product-regular-price"><?php echo esc_html( $related_formatted_price ); ?></span>
								<?php endif; ?>
							</div>
							<div class="vrstore-product-actions">
								<a href="<?php the_permalink(); ?>" class="vrstore-btn vrstore-btn-secondary vrstore-btn-sm"><?php echo $labels['view_details']; ?></a>
								<button class="vrstore-btn vrstore-btn-primary vrstore-btn-sm vrstore-add-to-cart" data-product-id="<?php echo esc_attr( $related_id ); ?>"><?php echo $labels['add_to_cart']; ?></button>
							</div>
						</div>
					</div>
				<?php endwhile; ?>
				<?php wp_reset_postdata(); ?>
			</div>
		</div>
	<?php endif; ?>
</div>

<!-- Video Modal -->
<?php if ( $has_video ) : ?>
<div id="vrstore-video-modal" class="vrstore-modal vrstore-video-modal" style="display: none;">
	<div class="vrstore-modal-content">
		<div class="vrstore-modal-header">
			<h3><?php echo esc_html( get_the_title() ); ?> - <?php esc_html_e( 'Product Video', 'vira-store' ); ?></h3>
			<span class="vrstore-modal-close">&times;</span>
		</div>
		<div class="vrstore-modal-body">
		<div class="vrstore-video-container">
			<?php if ( $video_config['type'] === 'youtube' && ! empty( $video_config['youtube_url'] ) ) : ?>
				<?php 
				// Extract YouTube video ID from URL
				preg_match('/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/', $video_config['youtube_url'], $matches);
				$youtube_id = isset($matches[1]) ? $matches[1] : '';
				?>
				<?php if ( ! empty( $youtube_id ) ) : ?>
					<div class="vrstore-youtube-container" id="vrstore-youtube-container">
						<!-- Primary iframe attempt -->
						<iframe 
							id="vrstore-youtube-iframe"
							src="https://www.youtube-nocookie.com/embed/<?php echo esc_attr( $youtube_id ); ?>?rel=0&modestbranding=1&playsinline=1" 
							width="100%" 
							height="100%"
							frameborder="0" 
							allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen" 
							allowfullscreen
							title="<?php echo esc_attr( get_the_title() ); ?> - Product Video"
							referrerpolicy="strict-origin-when-cross-origin"
							style="border: none; background: #000;">
						</iframe>
						
						<!-- Fallback link if iframe fails -->
						<div class="vrstore-youtube-fallback" style="display: none; text-align: center; padding: 40px; background: #f5f5f5; border-radius: 6px;">
							<p style="margin-bottom: 15px; color: #666;"><?php esc_html_e( 'Unable to load video player. Click the link below to watch on YouTube:', 'vira-store' ); ?></p>
							<a href="<?php echo esc_url( $video_config['youtube_url'] ); ?>" target="_blank" class="vrstore-btn vrstore-btn-primary" style="display: inline-block;">
								📺 <?php esc_html_e( 'Watch on YouTube', 'vira-store' ); ?>
							</a>
						</div>
					</div>
					
				<?php endif; ?>
			<?php elseif ( $video_config['type'] === 'upload' && ! empty( $video_config['video_id'] ) ) : ?>
				<?php $video_url = wp_get_attachment_url( $video_config['video_id'] ); ?>
				<?php if ( $video_url ) : ?>
					<video controls>
						<source src="<?php echo esc_url( $video_url ); ?>" type="video/mp4">
						<?php esc_html_e( 'Your browser does not support the video tag.', 'vira-store' ); ?>
					</video>
				<?php endif; ?>
			<?php endif; ?>
		</div>
		</div>
	</div>
</div>
<?php endif; ?>

<!-- License Info Modal -->
<?php if ( $has_license_info ) : ?>
<div id="vrstore-license-modal" class="vrstore-modal" style="display: none;">
	<div class="vrstore-modal-content">
		<div class="vrstore-modal-header">
			<h3><?php esc_html_e( 'License Information', 'vira-store' ); ?></h3>
			<span class="vrstore-modal-close">&times;</span>
		</div>
		<div class="vrstore-modal-body">
			<div class="vrstore-license-content">
				<?php echo wp_kses_post( wpautop( $video_config['license_info'] ) ); ?>
			</div>
		</div>
	</div>
</div>
<?php endif; ?>