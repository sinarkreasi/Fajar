<?php
/**
 * License shortcode template.
 *
 * @package Vira_Store
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Define untranslated strings for license template
if ( ! defined( 'VRSTORE_LICENSE_LABELS' ) ) {
	define( 'VRSTORE_LICENSE_LABELS', [
		'check_license_status' => 'Check License Status',
		'license_key' => 'License Key',
		'enter_license_key' => 'Enter your license key',
		'check_license' => 'Check License',
		'license_details' => 'License Details',
		'product' => 'Product:',
		'license_key_label' => 'License Key:',
		'status' => 'Status:',
		'customer' => 'Customer:',
		'email' => 'Email:',
		'activations' => 'Activations:',
		'expiry_date' => 'Expiry Date:',
		'never' => 'Never',
		'active_sites' => 'Active Sites',
		'site' => 'Site',
		'activation_date' => 'Activation Date',
		'activate_license' => 'Activate License',
		'site_url' => 'Site URL',
		'enter_site_url' => 'Enter site URL',
		'activation_limit_reached' => 'You have reached the maximum number of activations for this license.',
		'deactivate_before_new' => 'Please deactivate a site before activating a new one.',
		'check_another_license' => 'Check Another License',
		'no_license_found' => 'No license found.',
	]);
}

function vrstore_get_license_labels_translated() {
	$translated = [];
	foreach ( VRSTORE_LICENSE_LABELS as $key => $label ) {
		$translated[ $key ] = vrstore_is_textdomain_ready() ? esc_html__( $label, 'vira-store' ) : esc_html( $label );
	}
	return $translated;
}
$license_labels = vrstore_get_license_labels_translated();

// Variables available: $license_key, $license_data.

// Check if license data is available.
if ( empty( $license_data ) ) {
	// Show license key form.
	?>
	<div class="vrstore-license-check-container">
		<h2><?php echo $license_labels['check_license_status']; ?></h2>
		
		<form class="vrstore-license-check-form" method="post" action="">
			<div class="vrstore-form-row">
				<label for="vrstore_license_key"><?php echo $license_labels['license_key']; ?></label>
				<input type="text" id="vrstore_license_key" name="vrstore_license_key" value="<?php echo esc_attr( $license_key ); ?>" placeholder="<?php echo $license_labels['enter_license_key']; ?>" required>
			</div>
			
			<div class="vrstore-form-submit">
				<?php wp_nonce_field( 'vrstore_check_license_nonce', 'vrstore_check_license_nonce' ); ?>
				<button type="submit" class="vrstore-button vrstore-button-primary"><?php echo $license_labels['check_license']; ?></button>
			</div>
		</form>
	</div>
	<?php
} else {
	// Show license details.
	?>
	<div class="vrstore-license-details-container">
		<h2><?php echo $license_labels['license_details']; ?></h2>
		
		<div class="vrstore-license-details">
			<div class="vrstore-license-info">
				<div class="vrstore-license-info-item">
					<span class="vrstore-license-info-label"><?php echo $license_labels['product']; ?></span>
					<span class="vrstore-license-info-value"><?php echo esc_html( $license_data['product_title'] ); ?></span>
				</div>
				
				<div class="vrstore-license-info-item">
					<span class="vrstore-license-info-label"><?php echo $license_labels['license_key_label']; ?></span>
					<span class="vrstore-license-info-value">
						<code class="vrstore-license-key"><?php echo esc_html( $license_data['license_key'] ); ?></code>
						<button class="vrstore-copy-license-key" data-license-key="<?php echo esc_attr( $license_data['license_key'] ); ?>">
							<span class="dashicons dashicons-clipboard"></span>
						</button>
					</span>
				</div>
				
				<div class="vrstore-license-info-item">
					<span class="vrstore-license-info-label"><?php echo $license_labels['status']; ?></span>
					<span class="vrstore-license-info-value">
						<span class="vrstore-license-status vrstore-license-status-<?php echo esc_attr( strtolower( $license_data['status'] ) ); ?>">
							<?php echo esc_html( $license_data['status'] ); ?>
						</span>
					</span>
				</div>
				
				<div class="vrstore-license-info-item">
					<span class="vrstore-license-info-label"><?php echo $license_labels['customer']; ?></span>
					<span class="vrstore-license-info-value"><?php echo esc_html( $license_data['customer_name'] ); ?></span>
				</div>
				
				<div class="vrstore-license-info-item">
					<span class="vrstore-license-info-label"><?php echo $license_labels['email']; ?></span>
					<span class="vrstore-license-info-value"><?php echo esc_html( $license_data['customer_email'] ); ?></span>
				</div>
				
				<div class="vrstore-license-info-item">
					<span class="vrstore-license-info-label"><?php echo $license_labels['activations']; ?></span>
					<span class="vrstore-license-info-value">
						<?php
						$activations = ! empty( $license_data['activations'] ) ? count( $license_data['activations'] ) : 0;
						$activation_limit = ! empty( $license_data['activation_limit'] ) ? $license_data['activation_limit'] : 0;
						
						if ( $activation_limit > 0 ) {
							$format_text = vrstore_is_textdomain_ready() ? __( '%1$s / %2$s', 'vira-store' ) : '%1$s / %2$s';
							echo esc_html( sprintf( $format_text, $activations, $activation_limit ) );
						} else {
							$format_text = vrstore_is_textdomain_ready() ? __( '%s (Unlimited)', 'vira-store' ) : '%s (Unlimited)';
							echo esc_html( sprintf( $format_text, $activations ) );
						}
						?>
					</span>
				</div>
				
				<div class="vrstore-license-info-item">
					<span class="vrstore-license-info-label"><?php echo $license_labels['expiry_date']; ?></span>
					<span class="vrstore-license-info-value">
						<?php
						if ( ! empty( $license_data['expiry_date'] ) ) {
							echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $license_data['expiry_date'] ) ) );
						} else {
							echo $license_labels['never'];
						}
						?>
					</span>
				</div>
			</div>
			
			<?php if ( ! empty( $license_data['activations'] ) ) : ?>
				<div class="vrstore-license-activations">
					<h3><?php echo $license_labels['active_sites']; ?></h3>
					
					<table class="vrstore-activations-table">
						<thead>
							<tr>
								<th><?php echo $license_labels['site']; ?></th>
								<th><?php echo $license_labels['activation_date']; ?></th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ( $license_data['activations'] as $activation ) : ?>
								<tr>
									<td><?php echo esc_html( $activation['site'] ); ?></td>
									<td><?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $activation['date'] ) ) ); ?></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			<?php endif; ?>
			
			<?php if ( 'active' === strtolower( $license_data['status'] ) ) : ?>
				<div class="vrstore-license-activation">
					<h3><?php echo $license_labels['activate_license']; ?></h3>
					
					<?php
					$activations = ! empty( $license_data['activations'] ) ? count( $license_data['activations'] ) : 0;
					$activation_limit = ! empty( $license_data['activation_limit'] ) ? $license_data['activation_limit'] : 0;
					
					// Check if activation limit is reached.
					$can_activate = ( $activation_limit === 0 || $activations < $activation_limit );
					
					if ( $can_activate ) :
						?>
						<form class="vrstore-license-activation-form" method="post" action="">
							<div class="vrstore-form-row">
								<label for="vrstore_site_url"><?php echo $license_labels['site_url']; ?></label>
								<input type="text" id="vrstore_site_url" name="vrstore_site_url" value="<?php echo esc_attr( home_url() ); ?>" placeholder="<?php echo $license_labels['enter_site_url']; ?>" required>
							</div>
							
							<div class="vrstore-form-submit">
								<input type="hidden" name="vrstore_license_key" value="<?php echo esc_attr( $license_data['license_key'] ); ?>">
								<?php wp_nonce_field( 'vrstore_activate_license_nonce', 'vrstore_activate_license_nonce' ); ?>
								<button type="submit" class="vrstore-button vrstore-button-primary"><?php echo $license_labels['activate_license']; ?></button>
							</div>
						</form>
						<?php
					else :
						?>
						<p class="vrstore-activation-limit-reached">
							<?php echo $license_labels['activation_limit_reached']; ?>
							<?php echo $license_labels['deactivate_before_new']; ?>
						</p>
						<?php
					endif;
					?>
				</div>
			<?php endif; ?>
			
			<div class="vrstore-license-actions">
				<a href="<?php echo esc_url( remove_query_arg( 'vrstore_license_key', get_permalink() ) ); ?>" class="vrstore-button"><?php echo $license_labels['check_another_license']; ?></a>
			</div>
		</div>
	</div>
	<?php
}