<?php
/**
 * Products shortcode template.
 *
 * @package Vira_Store
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Define untranslated strings for products template
if ( ! defined( 'VRSTORE_PRODUCTS_LABELS' ) ) {
	define( 'VRSTORE_PRODUCTS_LABELS', [
		'all_categories' => 'All Categories',
		'search_products' => 'Search products...',
		'view_details' => 'View Details',
		'add_to_cart' => 'Buy Now',
		'no_products_found' => 'No products found.',
	]);
}

// Check if function exists to prevent redeclaration
if (!function_exists('vrstore_get_products_labels_translated')) {
	function vrstore_get_products_labels_translated() {
		$translated = [];
		foreach ( VRSTORE_PRODUCTS_LABELS as $key => $label ) {
			$translated[ $key ] = vrstore_is_textdomain_ready() ? esc_html__( $label, 'vira-store' ) : esc_html( $label );
		}
		return $translated;
	}
}
$products_labels = vrstore_get_products_labels_translated();
// Variables available: $products, $columns, $show_filter, $show_search.
?>
<div class="vrstore-products-container">

	<div class="vrstore-spinner" style="display: none;">
		<div class="vrstore-spinner-inner"></div>
	</div>

	<div class="vrstore-products-grid vrstore-columns-<?php echo esc_attr( $columns ); ?>">
		<?php if ( $products->have_posts() ) : ?>
			<?php while ( $products->have_posts() ) : $products->the_post(); ?>
				<?php
				$product_id = get_the_ID();
				
				// Get settings and product instances
				$settings = VRSTORE_Settings::get_instance();
				$currency_converter = VRSTORE_Currency_Converter::get_instance();
				$currency = $settings->get_current_currency();
				$product_instance = VRSTORE_Product::get_instance();
				
				// Get license pricing data
				$license_pricing = get_post_meta( $product_id, '_vrstore_product_license_pricing', true );
				if ( ! is_array( $license_pricing ) ) {
					$license_pricing = [];
				}
				
				// Get custom license types from settings
				$custom_license_types = $settings->get_setting( 'custom_license_types', [] );
				if ( ! is_array( $custom_license_types ) ) {
					$custom_license_types = [];
				}
				
				// Get license type availability settings for this product
				$license_availability = get_post_meta( $product_id, '_vrstore_product_license_availability', true );
				if ( ! is_array( $license_availability ) ) {
					$license_availability = [];
				}
				
				// Filter license types based on availability
				if ( ! empty( $license_availability ) ) {
					$available_license_types = [];
					foreach ( $custom_license_types as $type ) {
						$slug = isset( $type['slug'] ) ? $type['slug'] : sanitize_title( $type['label'] );
						// Show license type if it's explicitly enabled
						// Note: The admin saves false for disabled types, so we only check for explicit true
						if ( isset( $license_availability[ $slug ] ) && $license_availability[ $slug ] === true ) {
							$available_license_types[] = $type;
						}
						// If no availability setting exists for this slug, show it by default (backward compatibility)
						elseif ( ! isset( $license_availability[ $slug ] ) ) {
							$available_license_types[] = $type;
						}
					}
					$custom_license_types = $available_license_types;
				}
				
				// Find the lowest price from available license types and get base license type
				$lowest_price = null;
				$lowest_sale_price = null;
				$formatted_price = '';
				$formatted_sale_price = '';
				$base_license_type = ''; // First available license type for buy button
				
				if ( ! empty( $custom_license_types ) ) {
					$first_license = true;
					foreach ( $custom_license_types as $type ) {
						$slug = isset( $type['slug'] ) ? $type['slug'] : sanitize_title( $type['label'] );
						
						// Set the first available license type as the base license type
						if ( $first_license ) {
							$base_license_type = $slug;
							$first_license = false;
						}
						
						$license_price = null;
						$license_sale_price = null;
						
						// Check for product-specific pricing first
						if ( isset( $license_pricing[ $slug ] ) && is_array( $license_pricing[ $slug ] ) ) {
							$license_price = isset( $license_pricing[ $slug ]['price'] ) ? $license_pricing[ $slug ]['price'] : null;
							$license_sale_price = isset( $license_pricing[ $slug ]['sale_price'] ) ? $license_pricing[ $slug ]['sale_price'] : null;
						} else {
							// Use global settings defaults
							$license_price = isset( $type['regular_price'] ) ? $type['regular_price'] : null;
							$license_sale_price = isset( $type['sale_price'] ) ? $type['sale_price'] : null;
						}
						
						// Track lowest prices
						if ( $license_price !== null && is_numeric( $license_price ) ) {
							if ( $lowest_price === null || floatval( $license_price ) < floatval( $lowest_price ) ) {
								$lowest_price = $license_price;
							}
						}
						
						if ( $license_sale_price !== null && is_numeric( $license_sale_price ) ) {
							if ( $lowest_sale_price === null || floatval( $license_sale_price ) < floatval( $lowest_sale_price ) ) {
								$lowest_sale_price = $license_sale_price;
							}
						}
					}
				}
				
				// Format the lowest prices - use currency converter for proper conversion
				if ( $lowest_price !== null && is_numeric( $lowest_price ) ) {
					$formatted_price = $currency_converter->format_price( floatval( $lowest_price ) );
				}
				
				if ( $lowest_sale_price !== null && is_numeric( $lowest_sale_price ) ) {
					$formatted_sale_price = $currency_converter->format_price( floatval( $lowest_sale_price ) );
				}
				?>
				<div class="vrstore-product vrstore-card vrstore-animate-fade-in">
					<div class="vrstore-product-image">
						<a href="<?php the_permalink(); ?>">
							<?php if ( has_post_thumbnail() ) : ?>
								<?php the_post_thumbnail( 'medium' ); ?>
							<?php else : ?>
								<img src="<?php echo esc_url( VRSTORE_PLUGIN_URL . 'assets/images/placeholder.svg' ); ?>" alt="<?php the_title_attribute(); ?>">
							<?php endif; ?>
						</a>
					</div>
					<div class="vrstore-product-content">
						<h3 class="vrstore-product-title">
							<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
						</h3>
						<div class="vrstore-product-price">
							<?php if ( ! empty( $formatted_price ) ) : ?>
								<span class="vrstore-price-from"><?php esc_html_e( 'from', 'vira-store' ); ?> </span>
								<?php if ( ! empty( $formatted_sale_price ) ) : ?>
									<span class="vrstore-product-regular-price vrstore-price" style="text-decoration: line-through;" data-base-amount="<?php echo esc_attr( $lowest_price ); ?>" data-base-currency="<?php echo esc_attr( $currency_converter->get_base_currency() ); ?>"><?php echo esc_html( $formatted_price ); ?></span>
									<span class="vrstore-product-sale-price vrstore-price" style="color: #e74c3c; font-weight: bold;" data-base-amount="<?php echo esc_attr( $lowest_sale_price ); ?>" data-base-currency="<?php echo esc_attr( $currency_converter->get_base_currency() ); ?>"><?php echo esc_html( $formatted_sale_price ); ?></span>
								<?php else : ?>
									<span class="vrstore-product-regular-price vrstore-price" data-base-amount="<?php echo esc_attr( $lowest_price ); ?>" data-base-currency="<?php echo esc_attr( $currency_converter->get_base_currency() ); ?>"><?php echo esc_html( $formatted_price ); ?></span>
								<?php endif; ?>
							<?php else : ?>
								<span class="vrstore-product-price-empty"><?php esc_html_e( 'Price on request', 'vira-store' ); ?></span>
							<?php endif; ?>
						</div>
						<div class="vrstore-product-actions">
							<a href="<?php the_permalink(); ?>" class="vrstore-btn vrstore-btn-secondary vrstore-btn-sm"><?php echo $products_labels['view_details']; ?></a>
							<button class="vrstore-btn vrstore-btn-primary vrstore-btn-sm vrstore-add-to-cart" data-product-id="<?php echo esc_attr( $product_id ); ?>" data-license-type="<?php echo esc_attr( $base_license_type ); ?>"><?php echo $products_labels['add_to_cart']; ?></button>
						</div>
					</div>
				</div>
			<?php endwhile; ?>
			<?php wp_reset_postdata(); ?>
		<?php else : ?>
			<div class="vrstore-no-products vrstore-card vrstore-text-center vrstore-p-4">
				<p class="vrstore-text-muted"><?php echo $products_labels['no_products_found']; ?></p>
			</div>
		<?php endif; ?>
	</div>
</div>