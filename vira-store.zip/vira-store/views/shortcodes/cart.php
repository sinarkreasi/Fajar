<?php
/**
 * Cart shortcode template.
 *
 * @package Vira_Store
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Variables available: $cart_items, $settings, $product_instance, $pending_orders
?>

<div class="vrstore-cart vrstore-animate-fade-in">
    
    <!-- Pending Orders Section -->
    <?php if ( ! empty( $pending_orders ) ) : ?>
        <div class="vrstore-pending-orders vrstore-card vrstore-mb-4">
            <h3 class="vrstore-text-lg vrstore-font-semibold vrstore-mb-3"><?php esc_html_e( 'Incomplete Payments', 'vira-store' ); ?></h3>
            <p class="vrstore-pending-notice">
                <span class="vrstore-warning-icon">⚠️</span>
                <?php esc_html_e( 'You have orders waiting for payment completion. Click "Complete Payment" to finish your purchase.', 'vira-store' ); ?>
            </p>
            
            <div class="vrstore-pending-orders-list">
                <?php foreach ( $pending_orders as $order ) : 
                    $product = get_post( $order['product_id'] );
                    $product_title = $product ? $product->post_title : __( 'Unknown Product', 'vira-store' );
                ?>
                <div class="vrstore-pending-order-item vrstore-card vrstore-mb-3">
                    <div class="vrstore-pending-order-info">
                        <h4><?php echo esc_html( $product_title ); ?></h4>
                        <div class="vrstore-pending-order-meta">
                            <span class="vrstore-order-id"><?php printf( esc_html__( 'Order #%s', 'vira-store' ), esc_html( $order['order_number'] ?: $order['id'] ) ); ?></span>
                            <span class="vrstore-order-date"><?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $order['created_at'] ) ) ); ?></span>
                            <span class="vrstore-order-amount"><?php echo esc_html( $product_instance->format_price( $order['product_price'], $order['currency'] ?: 'USD' ) ); ?></span>
                        </div>
                    </div>
                    <div class="vrstore-pending-order-actions">
                        <span class="vrstore-order-status vrstore-status-pending"><?php esc_html_e( 'Pending Payment', 'vira-store' ); ?></span>
                        <a href="<?php echo esc_url( home_url( '/checkout/?order_id=' . $order['id'] ) ); ?>" class="vrstore-btn vrstore-btn-primary vrstore-btn-sm">
                            <?php esc_html_e( 'Complete Payment', 'vira-store' ); ?>
                        </a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>
    
    <?php if ( empty( $cart_items ) && empty( $pending_orders ) ) : ?>
        <div class="vrstore-cart-empty vrstore-card vrstore-text-center vrstore-p-8">
            <p class="vrstore-text-gray-600 vrstore-mb-4"><?php esc_html_e( 'Your cart is currently empty.', 'vira-store' ); ?></p>
            <a href="<?php echo esc_url( home_url() ); ?>" class="vrstore-btn vrstore-btn-primary">
                <?php esc_html_e( 'Continue Shopping', 'vira-store' ); ?>
            </a>
        </div>
    <?php endif; ?>
    
    <?php if ( ! empty( $cart_items ) ) : ?>

        <form class="vrstore-cart-form" method="post">
            <?php wp_nonce_field( 'vrstore_update_cart', 'vrstore_cart_nonce' ); ?>
            
            <div class="vrstore-cart-items">
                    <?php 
                    // Get currency setting for price formatting
                    $currency = $settings->get_setting( 'currency', 'USD' );
                    $product_instance = VRSTORE_Product::get_instance();
                    $cart_instance = VRSTORE_Cart::get_instance();
                    $total_subtotal = 0;
                    
                    // Get current user currency from converter
                    $user_currency = $currency_converter->get_user_currency();
                    
                    foreach ( $cart_items as $cart_key => $item ) :
                        // Handle Extended Support items differently (they don't have real post IDs)
                        $is_extended_support = isset( $item['product_id'] ) && is_string( $item['product_id'] ) && strpos( $item['product_id'], 'extended_support' ) === 0;
                        
                        if ( $is_extended_support ) {
                            // For Extended Support, we don't need a WordPress post
                            $product = null;
                        } else {
                            $product = get_post( $item['product_id'] );
                            if ( ! $product ) continue;
                        }
                        
                        // Get price using cart's pricing logic (includes license type pricing)
                        $price = $cart_instance->get_item_price( $item );
                        $quantity = intval( $item['quantity'] );
                        
                        // Extended Support items already store the full total price
                        if ( isset( $item['product_id'] ) && is_string( $item['product_id'] ) && strpos( $item['product_id'], 'extended_support' ) === 0 ) {
                            $subtotal = $price; // Already the total amount
                            // Extended Support prices are already converted - no need to convert again
                            $converted_price = $price;
                            $converted_subtotal = $subtotal;
                            $total_subtotal += $subtotal; // Add converted price for Extended Support
                        } else {
                            $subtotal = $price * $quantity;
                            // Regular products AND courses need currency conversion
                            $converted_price = $currency_converter->convert_price( $price, $user_currency );
                            $converted_subtotal = $currency_converter->convert_price( $subtotal, $user_currency );
                            $total_subtotal += $subtotal; // Add base price for regular items (will be converted later)
                        }
                        
                        // Determine currency for this item - use user currency
                        $item_currency = $user_currency;
                    ?>
                <div class="vrstore-cart-item vrstore-card" data-cart-key="<?php echo esc_attr( $cart_key ); ?>" data-product-id="<?php echo esc_attr( $item['product_id'] ); ?>">
                    <div class="vrstore-cart-item-content">
                            
                            <div class="vrstore-cart-item-image">
                                <?php 
                                // Handle Extended Support items differently for thumbnails
                                if ( $is_extended_support ) {
                                    // Extended Support items don't have thumbnails, show support icon
                                    ?>
                                    <div class="vrstore-product-image-circle vrstore-no-image">
                                        <span class="vrstore-product-icon">🛠️</span>
                                    </div>
                                    <?php
                                } else {
                                    $thumbnail = get_the_post_thumbnail( $item['product_id'], 'thumbnail' );
                                    if ( $thumbnail ) :
                                    ?>
                                        <div class="vrstore-product-image-circle">
                                            <?php echo $thumbnail; ?>
                                        </div>
                                    <?php else : ?>
                                        <div class="vrstore-product-image-circle vrstore-no-image">
                                            <span class="vrstore-product-icon">📦</span>
                                        </div>
                                    <?php endif;
                                }
                                ?>
                            </div>
                            
                            <div class="vrstore-cart-item-details">
                                <h4 class="vrstore-cart-item-name">
                                    <?php 
                                    // Add item type indicator and display name
                                    if ( $is_extended_support ) {
                                        echo '<span class="vrstore-item-type-badge vrstore-support-badge">🛠️ ' . esc_html__('Extended Support', 'vira-store') . '</span> ';
                                        echo esc_html( $item['product_name'] ?? __('Extended Support', 'vira-store') );
                                    } else {
                                        if ( is_numeric($item['product_id']) ) {
                                            $post_type = get_post_type($item['product_id']);
                                            if ($post_type === 'vrstore_course') {
                                                echo '<span class="vrstore-item-type-badge vrstore-course-badge">📚 ' . esc_html__('Course', 'vira-store') . '</span> ';
                                            } elseif ($post_type === 'vrstore_product') {
                                                echo '<span class="vrstore-item-type-badge vrstore-product-badge">📦 ' . esc_html__('Product', 'vira-store') . '</span> ';
                                            }
                                        }
                                        echo esc_html( $product->post_title ); 
                                    }
                                    ?>
                                </h4>
                                <?php if ( ! empty( $item['license_type'] ) ) : ?>
                                    <?php
                                    // Get license type display name from unified custom licensing system
                                    $vrstore_options = get_option( 'vrstore_settings', [] );
                                    $custom_license_types = $vrstore_options['custom_license_types'] ?? [];
                                    $license_display = ucfirst( str_replace( '-', ' ', $item['license_type'] ) ); // Default fallback
                                    
                                    // Look for custom license type with matching slug
                                    foreach ( $custom_license_types as $custom_type ) {
                                        $type_slug = isset( $custom_type['slug'] ) ? $custom_type['slug'] : sanitize_title( $custom_type['label'] ?? '' );
                                        if ( $type_slug === $item['license_type'] && ! empty( $custom_type['label'] ) ) {
                                            $license_display = $custom_type['label'];
                                            break;
                                        }
                                    }
                                    ?>
                                    <div class="vrstore-cart-item-license">
                                        <span class="vrstore-license-type"><?php echo esc_html( $license_display ); ?></span>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="vrstore-cart-item-price">
                                <?php 
								// Use converted prices for display
								if ( isset( $item['product_id'] ) && is_string( $item['product_id'] ) && strpos( $item['product_id'], 'extended_support' ) === 0 ) {
									// For Extended Support: show per-month price instead of total
									if ( isset( $item['months'] ) && $item['months'] > 0 ) {
										$price_per_month = $converted_price / $item['months'];
										echo esc_html( $currency_converter->format_converted_price( $price_per_month, $user_currency ) . '/month' );
									} else {
										echo esc_html( $currency_converter->format_converted_price( $converted_price, $user_currency ) );
									}
								} else {
									echo esc_html( $currency_converter->format_converted_price( $converted_price, $user_currency ) );
								}
                                ?>
                            </div>
                            
                            <div class="vrstore-cart-item-quantity">
                                <div class="vrstore-qty-controls">
                                    <button type="button" class="vrstore-qty-btn vrstore-qty-minus" data-cart-key="<?php echo esc_attr( $cart_key ); ?>" aria-label="<?php esc_attr_e( 'Decrease quantity', 'vira-store' ); ?>">-</button>
                                    <input 
                                        type="number" 
                                        id="qty-<?php echo esc_attr( $cart_key ); ?>" 
                                        name="cart_quantity[<?php echo esc_attr( $cart_key ); ?>]" 
                                        value="<?php echo esc_attr( $quantity ); ?>" 
                                        min="1" 
                                        max="99" 
                                        class="vrstore-qty-input" 
                                        data-cart-key="<?php echo esc_attr( $cart_key ); ?>" 
                                        data-product-id="<?php echo esc_attr( $item['product_id'] ); ?>"
                                        aria-label="<?php esc_attr_e( 'Quantity', 'vira-store' ); ?>"
                                    >
                                    <button type="button" class="vrstore-qty-btn vrstore-qty-plus" data-cart-key="<?php echo esc_attr( $cart_key ); ?>" aria-label="<?php esc_attr_e( 'Increase quantity', 'vira-store' ); ?>">+</button>
                                </div>
                            </div>
                            
                            <div class="vrstore-cart-item-subtotal">
                                <?php 
								// Use converted subtotal for display
								echo esc_html( $currency_converter->format_converted_price( $converted_subtotal, $user_currency ) );
                                ?>
                            </div>
                            
                            <div class="vrstore-cart-item-actions">
                                <button type="button" class="vrstore-btn vrstore-btn-sm vrstore-btn-secondary vrstore-remove-item" data-cart-key="<?php echo esc_attr( $cart_key ); ?>">
                                    <?php esc_html_e( 'Remove', 'vira-store' ); ?>
                                </button>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
            </div>
        </form>
        
        <div class="vrstore-cart-totals vrstore-card">
            <h3 class="vrstore-text-lg vrstore-font-semibold vrstore-mb-4"><?php esc_html_e( 'Cart Totals', 'vira-store' ); ?></h3>
            
            <!-- Coupon Form -->
            <?php 
            $cart_instance = VRSTORE_Cart::get_instance();
            $applied_coupon = $cart_instance->get_applied_coupon();
            $discount_amount = $cart_instance->get_discount_amount();
            $final_total = $cart_instance->get_cart_total_with_discount();
            ?>
            
            <div class="vrstore-coupon-form">
                <?php if ( ! $applied_coupon ) : ?>
                    <div class="vrstore-coupon-input vrstore-flex vrstore-gap-2">
                        <input type="text" id="vrstore-coupon-code" class="vrstore-form-input vrstore-flex-1" placeholder="<?php esc_attr_e( 'Coupon code', 'vira-store' ); ?>" />
                        <button type="button" id="vrstore-apply-coupon" class="vrstore-btn vrstore-btn-secondary">
                            <?php esc_html_e( 'Apply Coupon', 'vira-store' ); ?>
                        </button>
                    </div>
                <?php else : ?>
                    <div class="vrstore-applied-coupon">
                        <span class="vrstore-coupon-info">
                            <?php 
                            $coupon_format = vrstore_is_textdomain_ready() ? esc_html__( 'Coupon "%s" applied', 'vira-store' ) : 'Coupon "%s" applied';
                            printf( 
                                $coupon_format,
                                esc_html( $applied_coupon['code'] )
                            ); 
                            ?>
                        </span>
                        <button type="button" id="vrstore-remove-coupon" class="vrstore-btn vrstore-btn-link">
                            <?php esc_html_e( 'Remove', 'vira-store' ); ?>
                        </button>
                    </div>
                <?php endif; ?>
                <div id="vrstore-coupon-message" class="vrstore-message" style="display: none;"></div>
            </div>
            
            <table class="vrstore-totals-table vrstore-w-full">
                <tr>
                    <th><?php esc_html_e( 'Subtotal', 'vira-store' ); ?></th>
                    <td class="vrstore-subtotal-amount vrstore-cart-total" data-base-amount="<?php echo esc_attr( $cart_total ); ?>"><?php 
                        // Get cart total and handle Extended Support items
                        $cart_total = $cart_instance->get_cart_total();
                        
                        // Check if cart has Extended Support items (courses are treated as regular products)
                        $has_extended_support = false;
                        $has_only_converted_items = true;
                        
                        foreach ($cart_items as $item) {
                            if (isset($item['product_id']) && is_string($item['product_id']) && strpos($item['product_id'], 'extended_support') === 0) {
                                $has_extended_support = true;
                            } else {
                                $has_only_converted_items = false;
                            }
                        }
                        
                        // Only skip conversion if cart has ONLY Extended Support items
                        if ($has_extended_support && $has_only_converted_items) {
                            $converted_cart_total = $cart_total;
                        } else {
                            $converted_cart_total = $currency_converter->convert_price( $cart_total, $user_currency );
                        }
                        
echo esc_html( $currency_converter->format_converted_price( $converted_cart_total, $user_currency ) );
                    ?></td>
                </tr>
                <?php if ( $applied_coupon && $discount_amount > 0 ) : ?>
                <tr class="vrstore-discount-row">
                    <th>
                        <?php esc_html_e( 'Discount', 'vira-store' ); ?>
                        <small>(<?php echo esc_html( $applied_coupon['code'] ); ?>)</small>
                    </th>
                    <td class="vrstore-discount-amount">-<?php 
                        // Handle discount conversion based on cart content
                        if ($has_extended_support && $has_only_converted_items) {
                            $converted_discount = $discount_amount;
                        } else {
                            $converted_discount = $currency_converter->convert_price( $discount_amount, $user_currency );
                        }
echo esc_html( $currency_converter->format_converted_price( $converted_discount, $user_currency ) );
                    ?></td>
                </tr>
                <?php endif; ?>
                <tr class="vrstore-total-row">
                    <th><?php esc_html_e( 'Total', 'vira-store' ); ?></th>
                    <td class="vrstore-total-amount vrstore-cart-total" data-base-amount="<?php echo esc_attr( $final_total ); ?>"><strong><?php 
                        // Handle final total conversion based on cart content
                        if ($has_extended_support && $has_only_converted_items) {
                            $converted_final_total = $final_total;
                        } else {
                            $converted_final_total = $currency_converter->convert_price( $final_total, $user_currency );
                        }
echo esc_html( $currency_converter->format_converted_price( $converted_final_total, $user_currency ) );
                    ?></strong></td>
                </tr>
            </table>
            
            <div class="vrstore-proceed-checkout">
                <?php 
                $checkout_page_id = $settings->get_setting( 'checkout_page' );
                $checkout_url = $checkout_page_id ? get_permalink( $checkout_page_id ) : home_url( '/checkout/' );
                ?>
                <a href="<?php echo esc_url( $checkout_url ); ?>" class="vrstore-btn vrstore-btn-primary vrstore-btn-lg vrstore-w-full">
                    <?php esc_html_e( 'Proceed to Checkout', 'vira-store' ); ?>
                </a>
            </div>
        </div>
    <?php endif; ?>
</div>