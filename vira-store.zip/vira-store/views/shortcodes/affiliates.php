<?php
/**
 * Affiliate Shortcode Template
 *
 * @package Vira_Store
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Enable error reporting for debugging (only in development)
if (WP_DEBUG) {
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
}

try {

// Safety check for WordPress functions
if (!function_exists('wp_get_current_user') || !function_exists('is_user_logged_in')) {
    throw new Exception('WordPress user functions not available');
}

// Safety check for affiliate class
if (!class_exists('VRSTORE_Affiliate')) {
    throw new Exception('VRSTORE_Affiliate class not found');
}

// Get current user
$current_user = wp_get_current_user();
$is_logged_in = is_user_logged_in();

// If no affiliate_data is provided by shortcode, determine the view ourselves (legacy fallback)
if (!isset($affiliate_data)) {
    // Get affiliate instance
    $affiliate_system = VRSTORE_Affiliate::get_instance();
    
    // Check if user is already an affiliate
    $is_affiliate = false;
    $affiliate_data = null;
    if ($is_logged_in) {
        $affiliate_data = $affiliate_system->get_affiliate_by_user_id($current_user->ID);
        $is_affiliate = !empty($affiliate_data);
    }
    
    // Determine view based on attributes and user status
    $view = $atts['view'] ?? 'auto';
    if ($view === 'auto') {
        if (!$is_logged_in) {
            $view = 'login_required';
        } elseif (!$is_affiliate) {
            $view = 'registration';
        } else {
            $view = 'dashboard';
        }
    }
} else {
    // Use the shortcode's display control
    if (!$is_logged_in) {
        $view = 'login_required';
    } elseif ($affiliate_data === false) {
        // false means logged-in user who needs registration
        $view = 'registration';
        $is_affiliate = false;
    } elseif ($affiliate_data !== null) {
        // affiliate data provided means show dashboard
        $view = 'dashboard';
        $is_affiliate = true;
    } else {
        $view = 'login_required';
    }
}

// Enforce Join Affiliate Requirement
$registration_enabled = get_option('vrstore_affiliate_enable_registration', '1') === '1';
$join_requirement = get_option('vrstore_affiliate_join_requirement', 'free');

if ($is_logged_in && ($view === 'registration')) {
    if (!$registration_enabled) {
        $view = 'registration_closed';
    } elseif ($join_requirement === 'purchase_required') {
        // Ensure affiliate_system is always defined
        if (!isset($affiliate_system)) {
            $affiliate_system = VRSTORE_Affiliate::get_instance();
        }
        $eligible = $affiliate_system->is_user_eligible_for_affiliate($current_user->ID);
        if (!$eligible) {
            $view = 'purchase_required';
        }
    }
}
?>

<div class="vrstore-affiliates-container" id="vrstore-affiliates">
    <?php if ($view === 'login_required'): ?>
        <!-- Login Required View - Improved Layout -->
        <div style="max-width: 500px; margin: 20px auto; padding: 30px; border: 1px solid #ddd; border-radius: 8px; background: #f9f9f9; text-align: center; font-family: Arial, sans-serif;">
            <div style="background: #d1ecf1; border: 1px solid #bee5eb; border-radius: 4px; padding: 20px; margin-bottom: 20px;">
                <h3 style="margin: 0 0 15px 0; color: #0c5460; font-size: 18px;">
                    🔐 <?php _e('Login Required', 'vira-store'); ?>
                </h3>
                <p style="margin: 0 0 15px 0; color: #0c5460; line-height: 1.5;">
                    <?php _e('You must be logged in to access the affiliate program.', 'vira-store'); ?>
                </p>
            </div>
            <a href="<?php echo wp_login_url(get_permalink()); ?>" 
               style="display: inline-block; background: #0073aa; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px; font-weight: bold; font-size: 16px;">
                🚀 <?php _e('Login', 'vira-store'); ?>
            </a>
        </div>

    <?php elseif ($view === 'registration'): ?>
        <!-- Registration View - Improved Layout -->
        <div style="max-width: 800px; margin: 20px auto; font-family: inherit;">
            <!-- Benefits Section -->
            <div style="background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 8px; padding: 25px; margin-bottom: 25px; text-align: center;">
                <?php
                // Get affiliate settings directly from individual options
                $benefits_title = get_option('vrstore_affiliate_benefits_section_title', __('Why Join Our Affiliate Program?', 'vira-store'));
                $program_description = get_option('vrstore_affiliate_program_description', __('Make money by promoting our products to your audience.', 'vira-store'));
                
                // Default benefits if not set
                $default_benefits = array(
                    __('Earn up to 30% commission on every sale', 'vira-store'),
                    __('Real-time tracking and reporting', 'vira-store'),
                    __('Monthly payouts via PayPal or bank transfer', 'vira-store'),
                    __('Marketing materials and support', 'vira-store'),
                    __('No minimum payout threshold', 'vira-store')
                );
                
                $program_benefits = get_option('vrstore_affiliate_program_benefits', implode("\n", $default_benefits));
                $benefits_array = array_filter(array_map('trim', explode("\n", $program_benefits)));
                ?>
                
                <h2 style="margin: 0 0 15px 0; color: #333; font-size: 24px;">
                    🎯 <?php echo esc_html($benefits_title); ?>
                </h2>
                
                <?php if (!empty($program_description)): ?>
                    <p style="margin: 0 0 20px 0; color: #666; font-size: 16px; line-height: 1.5;">
                        <?php echo esc_html($program_description); ?>
                    </p>
                <?php endif; ?>
                
                <div style="background: white; border-radius: 6px; padding: 20px; margin: 15px 0;">
                    <?php foreach ($benefits_array as $index => $benefit): ?>
                        <div style="display: flex; align-items: center; justify-content: flex-start; margin: 12px 0; padding: 8px; <?php echo $index % 2 === 0 ? 'background: #f8f9fa;' : ''; ?> border-radius: 4px;">
                            <span style="color: #28a745; font-size: 18px; margin-right: 12px;">✓</span>
                            <span style="color: #333; font-size: 14px; font-weight: 500;"><?php echo esc_html($benefit); ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Registration Form -->
            <div style="background: white; border: 1px solid #dee2e6; border-radius: 8px; padding: 30px;">                
                <form id="affiliate-registration-form" style="max-width: 100%;">
                    <?php wp_nonce_field('vrstore_affiliate_nonce', 'vrstore_affiliate_nonce'); ?>
                    
                    <div style="margin-bottom: 20px;">
                        <label for="affiliate_name" style="display: block; margin-bottom: 6px; font-weight: bold; color: #333; font-size: 14px;">
                            <?php _e('Full Name', 'vira-store'); ?> <span style="color: #e74c3c;">*</span>
                        </label>
                        <input type="text" id="affiliate_name" name="affiliate_name" 
                               value="<?php echo esc_attr($current_user->display_name); ?>" required
                               style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 4px; font-size: 14px; box-sizing: border-box;" />
                    </div>
    
                    <div style="margin-bottom: 20px;">
                        <label for="affiliate_email" style="display: block; margin-bottom: 6px; font-weight: bold; color: #333; font-size: 14px;">
                            <?php _e('Email Address', 'vira-store'); ?> <span style="color: #e74c3c;">*</span>
                        </label>
                        <input type="email" id="affiliate_email" name="affiliate_email" 
                               value="<?php echo esc_attr($current_user->user_email); ?>" required
                               style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 4px; font-size: 14px; box-sizing: border-box;" />
                        <small style="color: #666; font-size: 12px; display: block; margin-top: 5px;">
                            <?php _e('This will be your affiliate account email.', 'vira-store'); ?>
                        </small>
                    </div>
    
                    <div style="margin-bottom: 20px;">
                        <label for="website_url" style="display: block; margin-bottom: 6px; font-weight: bold; color: #333; font-size: 14px;">
                            <?php _e('Website/Blog URL', 'vira-store'); ?>
                        </label>
                        <input type="url" id="website_url" name="website_url" 
                               placeholder="https://yourwebsite.com"
                               style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 4px; font-size: 14px; box-sizing: border-box;" />
                        <small style="color: #666; font-size: 12px; display: block; margin-top: 5px;">
                            <?php _e('Your website, blog, or main social media profile.', 'vira-store'); ?>
                        </small>
                    </div>
    
                    <div style="margin-bottom: 20px;">
                        <label for="promotion_methods" style="display: block; margin-bottom: 6px; font-weight: bold; color: #333; font-size: 14px;">
                            <?php _e('How will you promote our products?', 'vira-store'); ?>
                        </label>
                        <textarea id="promotion_methods" name="promotion_methods" rows="4" 
                                  placeholder="<?php _e('Describe your marketing channels (blog, social media, email list, YouTube, etc.)', 'vira-store'); ?>"
                                  style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 4px; font-size: 14px; resize: vertical; box-sizing: border-box; font-family: Arial, sans-serif;"></textarea>
                    </div>
    
                    <div style="margin-bottom: 20px;">
                        <label for="payment_method" style="display: block; margin-bottom: 6px; font-weight: bold; color: #333; font-size: 14px;">
                            <?php _e('Preferred Payment Method', 'vira-store'); ?>
                        </label>
                        <select id="payment_method" name="payment_method" 
                                style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 4px; font-size: 14px; box-sizing: border-box; background: white;">
                            <option value="paypal"><?php _e('PayPal', 'vira-store'); ?></option>
                            <option value="bank_transfer"><?php _e('Bank Transfer', 'vira-store'); ?></option>
                            <option value="check"><?php _e('Check', 'vira-store'); ?></option>
                        </select>
                    </div>
    
                    <div style="margin-bottom: 25px;">
                        <label for="payment_details" style="display: block; margin-bottom: 6px; font-weight: bold; color: #333; font-size: 14px;">
                            <?php _e('Payment Details', 'vira-store'); ?>
                        </label>
                        <textarea id="payment_details" name="payment_details" rows="3" 
                                  placeholder="<?php _e('PayPal email, bank account details, or mailing address for checks', 'vira-store'); ?>"
                                  style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 4px; font-size: 14px; resize: vertical; box-sizing: border-box; font-family: Arial, sans-serif;"></textarea>
                        <small style="color: #666; font-size: 12px; display: block; margin-top: 5px;">
                            <?php _e('Provide the necessary details for your chosen payment method.', 'vira-store'); ?>
                        </small>
                    </div>
    
                    <div style="margin-bottom: 25px; padding: 15px; background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 4px;">
                        <label style="display: flex; align-items: flex-start; cursor: pointer; font-size: 14px; color: #333;">
                            <input type="checkbox" id="agree_terms" name="agree_terms" required 
                                   style="margin-right: 10px; margin-top: 3px;" />
                            <span>
                                <?php _e('I agree to the affiliate program terms and conditions.', 'vira-store'); ?>
                            </span>
                        </label>
                    </div>
    
                    <div style="text-align: center; margin-top: 30px;">
                        <button type="submit" 
                                style="background: #28a745; color: white; padding: 15px 40px; border: none; border-radius: 4px; font-weight: bold; font-size: 16px; cursor: pointer; transition: background-color 0.3s; min-width: 200px;" 
                                onmouseover="this.style.backgroundColor='#218838'" 
                                onmouseout="this.style.backgroundColor='#28a745'">
                            <span class="btn-text"><?php _e('Apply to Affiliate Program', 'vira-store'); ?></span>
                            <span class="btn-loading" style="display: none;">⏳ <?php _e('Processing...', 'vira-store'); ?></span>
                        </button>
                    </div>
                    
                    <p style="margin: 25px 0 0 0; font-size: 12px; color: #999; text-align: center; line-height: 1.4;">
                        <?php _e('We\'ll review your application within 24-48 hours and send you an email with the approval status.', 'vira-store'); ?>
                    </p>
                </form>
            </div>
        </div>

    <?php elseif ($view === 'dashboard' && $is_affiliate): ?>
        <!-- Dashboard View -->
        <div class="vrstore-affiliate-dashboard">
            <!-- Status Notice -->
            <div class="affiliate-status-notice">
                <?php 
                // Handle empty status as pending
                $current_status = !empty($affiliate_data->status) ? $affiliate_data->status : 'pending';
                ?>
                <?php if ($current_status === 'pending'): ?>
                    <div class="vrstore-affiliate-notice">
                        <strong><?php _e('Application Pending', 'vira-store'); ?></strong>
                        <p><?php _e('Your affiliate application is currently under review. You will be notified once it\'s approved.', 'vira-store'); ?></p>
                    </div>
                <?php elseif ($current_status === 'suspended'): ?>
                    <div class="vrstore-affiliate-notice vrstore-affiliate-notice-error">
                        <strong><?php _e('Account Suspended', 'vira-store'); ?></strong>
                        <p><?php _e('Your affiliate account has been suspended. Please contact support if you have any questions or would like to reapply.', 'vira-store'); ?></p>
                    </div>
                <?php elseif ($current_status === 'active'): ?>
                    <div class="vrstore-affiliate-notice">
                        <strong><?php _e('Account Active', 'vira-store'); ?></strong>
                        <p><?php _e('Congratulations! Your affiliate account is active and ready to earn commissions.', 'vira-store'); ?></p>
                    </div>
                <?php endif; ?>
            </div>

            <?php if ($current_status === 'active'): ?>
                <!-- Statistics Cards -->
                <div class="vrstore-affiliate-stats-grid" id="affiliate-stats">
                    <div class="vrstore-stat-card">
                        <div class="card-icon">
                            <span class="dashicons dashicons-visibility"></span>
                        </div>
                        <div class="card-content">
                            <div class="stat-number" data-stat="visits">0</div>
                            <div class="stat-label"><?php _e('Total Visits', 'vira-store'); ?></div>
                        </div>
                    </div>
                    <div class="vrstore-stat-card">
                        <div class="card-icon">
                            <span class="dashicons dashicons-cart"></span>
                        </div>
                        <div class="card-content">
                            <div class="stat-number" data-stat="conversions">0</div>
                            <div class="stat-label"><?php _e('Conversions', 'vira-store'); ?></div>
                        </div>
                    </div>
                    <div class="vrstore-stat-card">
                        <div class="card-icon">
                            <span class="dashicons dashicons-money-alt"></span>
                        </div>
                        <div class="card-content">
                            <div class="stat-number" data-stat="earnings">
                                <?php 
                                // Get affiliate earnings from the system
                                $affiliate_system = VRSTORE_Affiliate::get_instance();
                                $affiliate_stats = $affiliate_system->get_affiliate_statistics($affiliate_data->id);
                                $total_earnings = $affiliate_stats['paid_commissions'] + $affiliate_stats['approved_commissions'] + $affiliate_stats['pending_commissions'];
                                
                                // Use currency converter for user-facing display
                                if (class_exists('VRSTORE_Currency_Converter')) {
                                    $currency_converter = VRSTORE_Currency_Converter::get_instance();
                                    // For frontend, we convert from base currency to user's preferred currency
                                    echo esc_html($currency_converter->format_price($total_earnings));
                                } else {
                                    // Fallback without currency converter
                                    echo '$' . number_format($total_earnings, 2);
                                }
                                ?>
                            </div>
                            <div class="stat-label"><?php _e('Total Earnings', 'vira-store'); ?></div>
                        </div>
                    </div>
                    <div class="vrstore-stat-card">
                        <div class="card-icon">
                            <span class="dashicons dashicons-chart-line"></span>
                        </div>
                        <div class="card-content">
                            <div class="stat-number" data-stat="rate"><?php echo esc_html($affiliate_data->commission_rate); ?>%</div>
                            <div class="stat-label"><?php _e('Commission Rate', 'vira-store'); ?></div>
                        </div>
                    </div>
                </div>

                <!-- Two Column Layout -->
                <div class="vrstore-affiliate-content-grid">
                    <!-- Left Column: Compact Affiliate Links -->
                    <div class="vrstore-affiliate-links-compact">
                        <h3><?php _e('Your Affiliate Links', 'vira-store'); ?></h3>
                        
                        <div class="compact-form-group">
                            <select id="link_type" class="compact-select">
                                <option value="home"><?php _e('Home Page', 'vira-store'); ?></option>
                                <option value="shop"><?php _e('Shop Page', 'vira-store'); ?></option>
                                <option value="products"><?php _e('Products', 'vira-store'); ?></option>
                                <option value="blog"><?php _e('Blog', 'vira-store'); ?></option>
                                <option value="contact"><?php _e('Contact', 'vira-store'); ?></option>
                            </select>
                        </div>

                        <!-- Compact Link Generator -->
                        <div class="compact-link-group">
                            <div class="link-input-wrapper">
                                <input type="text" 
                                       id="affiliate-link-regular" 
                                       value="<?php echo esc_attr(home_url('?ref=' . $affiliate_data->affiliate_code)); ?>"
                                       readonly
                                       class="compact-link-input">
                                <button type="button" class="compact-copy-btn" data-target="#affiliate-link-regular">
                                    <span class="dashicons dashicons-admin-page"></span>
                                </button>
                            </div>
                            
                            <?php 
                            $use_short_urls = get_option('vrstore_affiliate_use_short_urls', '0');
                            $short_url_provider = get_option('vrstore_affiliate_short_url_provider', 'dns');
                            
                            if ($use_short_urls): 
                                $affiliate_system = VRSTORE_Affiliate::get_instance();
                                $short_url = $affiliate_system->generate_short_affiliate_link($affiliate_data->affiliate_code, home_url());
                                
                                // Determine provider badge text
                                $provider_badge = '';
                                switch ($short_url_provider) {
                                    case 'bitly':
                                        $provider_badge = 'Bitly';
                                        break;
                                    case 'rebrandly':
                                        $provider_badge = 'Rebrandly';
                                        break;
                                    case 'dns':
                                    default:
                                        $provider_badge = 'Short';
                                        break;
                                }
                            ?>
                            <div class="link-input-wrapper">
                                <input type="text" 
                                       id="affiliate-link-short" 
                                       value="<?php echo esc_attr($short_url); ?>"
                                       readonly
                                       class="compact-link-input"
                                       data-provider="<?php echo esc_attr($short_url_provider); ?>">
                                <button type="button" class="compact-copy-btn" data-target="#affiliate-link-short">
                                    <span class="dashicons dashicons-admin-page"></span>
                                </button>
                                <span class="link-badge provider-<?php echo esc_attr($short_url_provider); ?>"><?php echo esc_html($provider_badge); ?></span>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Right Column: Performance Data -->
                    <div class="vrstore-affiliate-performance">
                        <h3><?php _e('Performance Analytics', 'vira-store'); ?></h3>
                        
                        <div class="performance-tabs">
                            <button type="button" class="perf-tab active" data-period="weekly"><?php _e('Weekly', 'vira-store'); ?></button>
                            <button type="button" class="perf-tab" data-period="monthly"><?php _e('Monthly', 'vira-store'); ?></button>
                        </div>
                        
                        <div class="performance-content">
                            <div class="performance-chart" id="performance-chart-weekly">
                                <div class="chart-placeholder">
                                    <span class="dashicons dashicons-chart-line"></span>
                                    <p><?php _e('Weekly performance data will be displayed here', 'vira-store'); ?></p>
                                </div>
                            </div>
                            <div class="performance-chart" id="performance-chart-monthly" style="display: none;">
                                <div class="chart-placeholder">
                                    <span class="dashicons dashicons-chart-area"></span>
                                    <p><?php _e('Monthly performance data will be displayed here', 'vira-store'); ?></p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="performance-summary">
                            <div class="perf-item">
                                <span class="perf-label"><?php _e('Best Day:', 'vira-store'); ?></span>
                                <span class="perf-value" data-metric="best-day">-</span>
                            </div>
                            <div class="perf-item">
                                <span class="perf-label"><?php _e('Avg. Daily:', 'vira-store'); ?></span>
                                <span class="perf-value" data-metric="avg-daily">$0.00</span>
                            </div>
                            <div class="perf-item">
                                <span class="perf-label"><?php _e('Growth:', 'vira-store'); ?></span>
                                <span class="perf-value" data-metric="growth">0%</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Compact Quick Actions -->
                <div class="affiliate-actions-compact">
                    <button type="button" class="vrstore-btn-compact vrstore-btn-primary vrstore-refresh-stats" title="<?php _e('Refresh Statistics', 'vira-store'); ?>">
                        <span class="dashicons dashicons-update"></span>
                        <span class="btn-text"><?php _e('Refresh', 'vira-store'); ?></span>
                    </button>
                    
                    <button type="button" class="vrstore-btn-compact vrstore-payment-history" data-affiliate-id="<?php echo esc_attr($affiliate_data->id); ?>" title="<?php _e('Payment History', 'vira-store'); ?>">
                        <span class="dashicons dashicons-list-view"></span>
                        <span class="btn-text"><?php _e('History', 'vira-store'); ?></span>
                    </button>
                    
                    <?php
                    // Get minimum payout amount directly from option
                    $minimum_payout = floatval(get_option('vrstore_affiliate_minimum_payout', '50'));
                    
                    // Use unpaid_commissions from database (correct field for withdrawals)
                    // Calculate total earnings from stats for display only
                    $affiliate_system = VRSTORE_Affiliate::get_instance();
                    $affiliate_stats = $affiliate_system->get_affiliate_statistics($affiliate_data->id);
                    $total_earnings = $affiliate_stats['paid_commissions'] + $affiliate_stats['approved_commissions'] + $affiliate_stats['pending_commissions'];
                    
                    // For withdrawal eligibility, use unpaid_commissions from database
                    $unpaid_commissions = floatval($affiliate_data->unpaid_commissions ?? 0);
                    
                    // Check if withdrawal is available (use unpaid_commissions, not total earnings)
                    $can_withdraw = $unpaid_commissions >= $minimum_payout;
                    
                    // Format minimum payout with currency converter
                    $minimum_payout_formatted = '$' . number_format($minimum_payout, 0);
                    if (class_exists('VRSTORE_Currency_Converter')) {
                        $currency_converter = VRSTORE_Currency_Converter::get_instance();
                        $minimum_payout_formatted = $currency_converter->format_price($minimum_payout, false); // no decimals for minimum
                    }
                    ?>
                    
                    <button type="button" 
                            class="vrstore-btn-compact <?php echo $can_withdraw ? 'vrstore-btn-success' : 'vrstore-btn-disabled'; ?> vrstore-withdrawal-btn" 
                            data-affiliate-id="<?php echo esc_attr($affiliate_data->id); ?>"
                            data-current-earnings="<?php echo esc_attr($unpaid_commissions); ?>"
                            data-minimum-payout="<?php echo esc_attr($minimum_payout); ?>"
                            <?php echo !$can_withdraw ? 'disabled' : ''; ?>
                            title="<?php echo $can_withdraw ? __('Request Withdrawal', 'vira-store') : sprintf(__('Minimum: %s', 'vira-store'), $minimum_payout_formatted); ?>">
                        <span class="dashicons dashicons-money-alt"></span>
                        <span class="btn-text">
                            <?php echo $can_withdraw ? __('Withdraw', 'vira-store') : __('Withdraw', 'vira-store'); ?>
                        </span>
                        <?php if (!$can_withdraw): ?>
                        <span class="btn-min-amount"><?php echo esc_html(str_replace('.00', '', $minimum_payout_formatted)); ?></span>
                        <?php endif; ?>
                    </button>
                </div>

                <!-- Payment History Modal -->
                <div id="payment-history-modal" class="vrstore-modal">
                    <div class="vrstore-modal-content">
                        <div class="vrstore-modal-header">
                            <h3><?php _e('Payment History', 'vira-store'); ?></h3>
                            <span class="vrstore-modal-close">&times;</span>
                        </div>
                        <div class="vrstore-modal-body">
                            <div id="payment-history-content">
                                <div class="vrstore-loading"><?php _e('Loading payment history...', 'vira-store'); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>

    <?php elseif ($view === 'purchase_required'): ?>
        <!-- Purchase Required View - Improved Layout -->
        <div style="max-width: 600px; margin: 20px auto; padding: 30px; border: 1px solid #ddd; border-radius: 8px; background: #f9f9f9; text-align: center; font-family: Arial, sans-serif;">
            <div style="background: #fff3cd; border: 1px solid #ffeaa7; border-radius: 4px; padding: 15px; margin-bottom: 20px;">
                <h3 style="margin: 0 0 10px 0; color: #856404; font-size: 18px;">
                    🛒 <?php _e('Purchase Required', 'vira-store'); ?>
                </h3>
                <?php
                $required_products = get_option('vrstore_affiliate_required_products', array());
                if (!is_array($required_products)) {
                    $required_products = array();
                }
                
                if (!empty($required_products)) {
                    // Show specific products/courses required
                    $product_links = array();
                    
                    echo '<p style="margin: 0 0 15px 0; color: #856404; line-height: 1.5;">';
                    echo count($required_products) === 1 ? 
                        __('To join our affiliate program, you need to purchase this item:', 'vira-store') :
                        __('To join our affiliate program, you need to purchase one of these items:', 'vira-store');
                    echo '</p>';
                    
                    echo '<div style="background: white; border-radius: 4px; padding: 15px; margin: 15px 0;">';
                    foreach ($required_products as $index => $product_id) {
                        $post = get_post($product_id);
                        if ($post) {
                            $product_url = get_permalink($product_id);
                            echo '<div style="margin: 8px 0; padding: 8px; border: 1px solid #e0e0e0; border-radius: 4px;">';
                            echo '<a href="' . esc_url($product_url) . '" style="text-decoration: none; color: #0073aa; font-weight: bold; display: inline-block;">';
                            echo '📦 ' . esc_html($post->post_title);
                            echo '</a>';
                            echo '</div>';
                        }
                    }
                    echo '</div>';
                } else {
                    // Generic message for any purchase
                    echo '<p style="margin: 0; color: #856404; line-height: 1.5;">' . __('To join our affiliate program, you need to have at least one completed purchase on your account.', 'vira-store') . '</p>';
                }
                ?>
            </div>
            
            <div style="margin: 20px 0;">
                <?php
                // Determine products page URL
                $products_page = get_option('vrstore_products_page');
                $products_url = $products_page ? get_permalink($products_page) : home_url('/products/');
                ?>
                <a href="<?php echo esc_url($products_url); ?>" 
                   style="display: inline-block; background: #0073aa; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px; font-weight: bold; font-size: 16px; margin: 10px;">
                    🛍️ <?php _e('Browse Products', 'vira-store'); ?>
                </a>
            </div>
            
            <p style="margin: 20px 0 0 0; font-size: 14px; color: #666; line-height: 1.4;">
                💡 <em><?php _e('After completing your purchase, return to this page to register as an affiliate.', 'vira-store'); ?></em>
            </p>
        </div>

    <?php elseif ($view === 'registration_closed'): ?>
        <!-- Registration Closed View - Improved Layout -->
        <div style="max-width: 500px; margin: 20px auto; padding: 30px; border: 1px solid #ddd; border-radius: 8px; background: #f9f9f9; text-align: center; font-family: Arial, sans-serif;">
            <div style="background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 4px; padding: 20px;">
                <h3 style="margin: 0 0 15px 0; color: #721c24; font-size: 18px;">
                    🚫 <?php _e('Registration Closed', 'vira-store'); ?>
                </h3>
                <p style="margin: 0; color: #721c24; line-height: 1.5;">
                    <?php _e('Affiliate registration is currently closed. Please check back later.', 'vira-store'); ?>
                </p>
            </div>
        </div>

    <?php else: ?>
        <!-- Fallback View -->
        <div class="vrstore-error-message">
            <p><?php _e('Unable to load affiliate content. Please try again later.', 'vira-store'); ?></p>
        </div>
    <?php endif; ?>

    <!-- Messages Container -->
    <div id="affiliate-messages" class="affiliate-messages"></div>
</div>

<?php
} catch (Exception $e) {
    // Handle any errors that might cause a blank page
    if (WP_DEBUG) {
        echo '<div class="vrstore-error-message">';
        echo '<h3>Debug Error</h3>';
        echo '<p><strong>Error:</strong> ' . esc_html($e->getMessage()) . '</p>';
        echo '<p><strong>File:</strong> ' . esc_html($e->getFile()) . ':' . $e->getLine() . '</p>';
        echo '</div>';
        error_log('Affiliate shortcode error: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
    } else {
        echo '<div class="vrstore-error-message">';
        echo '<p>' . __('An error occurred while loading the affiliate content. Please try again later.', 'vira-store') . '</p>';
        echo '</div>';
        error_log('Affiliate shortcode error (production): ' . $e->getMessage());
    }
} catch (Error $e) {
    // Handle PHP fatal errors
    if (WP_DEBUG) {
        echo '<div class="vrstore-error-message">';
        echo '<h3>Debug Fatal Error</h3>';
        echo '<p><strong>Error:</strong> ' . esc_html($e->getMessage()) . '</p>';
        echo '<p><strong>File:</strong> ' . esc_html($e->getFile()) . ':' . $e->getLine() . '</p>';
        echo '</div>';
        error_log('Affiliate shortcode fatal error: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
    } else {
        echo '<div class="vrstore-error-message">';
        echo '<p>' . __('A system error occurred. Please contact support if this persists.', 'vira-store') . '</p>';
        echo '</div>';
        error_log('Affiliate shortcode fatal error (production): ' . $e->getMessage());
    }
}
?>
