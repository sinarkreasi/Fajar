<?php
/**
 * Checkout shortcode template.
 *
 * @package Vira_Store
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Variables available: $cart_items, $payment_gateways.
// PayPal payment mode variables: $vrstore_paypal_payment_mode, $vrstore_paypal_payment_data

// Initialize PayPal payment mode variables if not set (safety check)
if (!isset($vrstore_paypal_payment_mode)) {
    $vrstore_paypal_payment_mode = false;
}
if (!isset($vrstore_paypal_payment_data)) {
    $vrstore_paypal_payment_data = null;
}

// Get cart instance for proper total calculation with coupons
$cart_instance = VRSTORE_Cart::get_instance();

// If PayPal payment mode is active and cart is empty, get totals from payment data instead
if (isset($vrstore_paypal_payment_mode) && $vrstore_paypal_payment_mode && isset($vrstore_paypal_payment_data)) {
    // Use payment data for totals (order already created, amounts already calculated)
    $cart_subtotal = isset($vrstore_paypal_payment_data['amount']) ? floatval($vrstore_paypal_payment_data['amount']) : 0;
    $discount_amount = 0; // Discount already applied when order was created
    $cart_total = $cart_subtotal;
    $applied_coupon = null;
} else {
    // Normal cart totals
    $cart_subtotal = $cart_instance->get_cart_total();
    $applied_coupon = $cart_instance->get_applied_coupon();
    $discount_amount = $cart_instance->get_discount_amount();
    $cart_total = $cart_instance->get_cart_total_with_discount();
}

// Get user currency from converter
$user_currency = $currency_converter->get_user_currency();

// Check if cart has Extended Support items to handle conversion correctly
// Courses are treated as regular products and need conversion
$has_extended_support = false;
$has_only_converted_items = true;

// Only check cart items if they exist (might be empty in PayPal payment mode)
if (!empty($cart_items)) {
    foreach ($cart_items as $item) {
        if (isset($item['product_id']) && is_string($item['product_id']) && strpos($item['product_id'], 'extended_support') === 0) {
            $has_extended_support = true;
        } else {
            $has_only_converted_items = false;
        }
    }
}

// Handle currency conversion based on cart content
// For PayPal payment mode, amounts are already in correct currency
if (isset($vrstore_paypal_payment_mode) && $vrstore_paypal_payment_mode && isset($vrstore_paypal_payment_data)) {
    $paypal_currency = isset($vrstore_paypal_payment_data['currency']) ? $vrstore_paypal_payment_data['currency'] : $user_currency;
    // PayPal payment data amounts are already in the correct currency - no conversion needed
    $converted_cart_subtotal = $cart_subtotal;
    $converted_discount_amount = $discount_amount;
    $converted_cart_total = $cart_total;
} elseif ($has_extended_support && $has_only_converted_items) {
    // All Extended Support items - already converted, so totals are also converted
    $converted_cart_subtotal = $cart_subtotal;
    $converted_discount_amount = $discount_amount;
    $converted_cart_total = $cart_total;
} else {
    // Regular items (including courses) need conversion
    $converted_cart_subtotal = $currency_converter->convert_price( $cart_subtotal, $user_currency );
    $converted_discount_amount = $currency_converter->convert_price( $discount_amount, $user_currency );
    $converted_cart_total = $currency_converter->convert_price( $cart_total, $user_currency );
}

$product_instance = VRSTORE_Product::get_instance();

// Format cart total using converted amount - no double conversion
$formatted_cart_total = $currency_converter->format_converted_price( $converted_cart_total, $user_currency );

// Get thank you page URL.
$thank_you_page = get_option( 'vrstore_thank_you_page' );
$thank_you_url = $thank_you_page ? get_permalink( $thank_you_page ) : home_url();

// Generate order ID.
$order_id = 'VRSTORE-' . time() . '-' . wp_rand( 1000, 9999 );

// Check if user is logged in.
$is_logged_in = is_user_logged_in();

// Define untranslated labels for checkout UI
if ( ! defined( 'VRSTORE_CHECKOUT_LABELS' ) ) {
	define( 'VRSTORE_CHECKOUT_LABELS', array(
		'checkout' => 'Checkout',
		'billing_details' => 'Billing Details',
		'first_name' => 'First Name',
		'last_name' => 'Last Name',
		'email_address' => 'Email Address',
		'phone' => 'Phone',
		'company_name' => 'Company Name',
		'country' => 'Country',
		'select_country' => 'Select a country',
		'payment_method' => 'Payment Method',
		'select_payment_method' => 'Select a payment method',
		'card_number' => 'Card Number',
		'expiry_date' => 'Expiry Date',
		'cvc' => 'CVC',
		'payment_channel' => 'Payment Channel',
		'select_payment_channel' => 'Select a payment channel',
		'bri_va' => 'BRI Virtual Account',
		'bni_va' => 'BNI Virtual Account',
		'mandiri_va' => 'Mandiri Virtual Account',
		'bca_va' => 'BCA Virtual Account',
		'ovo' => 'OVO',
		'dana' => 'DANA',
		'qris' => 'QRIS',
		'no_payment_methods' => 'No payment methods available. Please contact the administrator.',
		'additional_info' => 'Additional Information',
		'order_notes' => 'Order Notes',
		'place_order' => 'Place Order',
		'order_summary' => 'Order Summary',
		'order_id' => 'Order ID',
		'product' => 'Item',
		'quantity' => 'Quantity',
		'price' => 'Price',
		'total' => 'Total',
		'grand_total' => 'Grand Total',
	));
}

// Function to get translated labels
function vrstore_get_checkout_labels_translated() {
	$labels = VRSTORE_CHECKOUT_LABELS;
	$translated = array();
	foreach ( $labels as $key => $value ) {
		$translated[ $key ] = vrstore_is_textdomain_ready() ? esc_html__( $value, 'vira-store' ) : esc_html( $value );
	}
	return $translated;
}

$checkout_labels = vrstore_get_checkout_labels_translated();
?>
<div class="vrstore-checkout-container vrstore-animate-fade-in">
	<div class="vrstore-checkout-main-content">
		<div class="vrstore-checkout-content">
		<!-- Authentication Section for Guest Users -->
		<?php if ( ! $is_logged_in ) : ?>
		<div class="vrstore-auth-section vrstore-card vrstore-mb-6">
			<h2 class="vrstore-auth-section-title vrstore-text-lg vrstore-font-semibold vrstore-mb-3"><?php esc_html_e( 'Account', 'vira-store' ); ?></h2>
			<p class="vrstore-auth-description"><?php esc_html_e( 'Create an account or log in to complete your purchase', 'vira-store' ); ?></p>
			
			<?php if ( isset( $google_login_enabled ) && $google_login_enabled && ! empty( $google_client_id ) ) : ?>
				<!-- Google Login for Checkout -->
				<div class="vrstore-checkout-google-login vrstore-mb-4">
					<button type="button" id="vrstore-checkout-google-login-btn" class="vrstore-google-login-btn vrstore-w-full" 
						data-client-id="<?php echo esc_attr( $google_client_id ); ?>"
						data-redirect-uri="<?php echo esc_attr( $google_redirect_uri ); ?>">
						<svg class="vrstore-google-icon" width="18" height="18" viewBox="0 0 18 18">
							<path fill="#4285F4" d="M18 9.2c0-.6-.1-1.3-.1-1.9H9.2v3.6h5c-.2 1.1-.9 2.1-1.9 2.8v2.3h3.1c1.8-1.7 2.8-4.1 2.8-7z"/>
							<path fill="#34A853" d="M9.2 18c2.6 0 4.7-.9 6.3-2.4l-3.1-2.3c-.9.6-2 1-3.2 1-2.5 0-4.6-1.7-5.3-4h-3.2v2.4C2.8 15.8 5.7 18 9.2 18z"/>
							<path fill="#FBBC04" d="M3.9 10.7c-.2-.6-.3-1.2-.3-1.8s.1-1.2.3-1.8V4.7H.7C.2 6 0 7.6 0 9.2s.2 3.2.7 4.5l3.2-2.5z"/>
							<path fill="#EA4335" d="M9.2 3.6c1.4 0 2.7.5 3.7 1.4l2.8-2.8C14.1.5 11.9 0 9.2 0 5.7 0 2.8 2.2 1.7 5.3l3.2 2.5c.7-2.3 2.8-4 5.3-4z"/>
						</svg>
						<span><?php esc_html_e( 'Continue with Google', 'vira-store' ); ?></span>
					</button>
					
					<div class="vrstore-divider vrstore-my-4">
						<span><?php esc_html_e( 'or', 'vira-store' ); ?></span>
					</div>
				</div>
			<?php endif; ?>
			
			<div class="vrstore-auth-buttons vrstore-flex vrstore-gap-3">
				<button type="button" class="vrstore-btn vrstore-btn-secondary vrstore-login-btn vrstore-flex-1" id="vrstore-show-login-form">
					<?php esc_html_e( 'Login to Existing Account', 'vira-store' ); ?>
				</button>
				<button type="button" class="vrstore-btn vrstore-btn-primary vrstore-register-btn vrstore-flex-1" id="vrstore-show-register-form">
					<?php esc_html_e( 'Create New Account', 'vira-store' ); ?>
				</button>
			</div>
			
			<!-- Login Form (Initially Hidden) -->
			<div class="vrstore-login-form vrstore-card vrstore-mt-4" id="vrstore-login-form" style="display: none;">
				<h3><?php esc_html_e( 'Login to Your Account', 'vira-store' ); ?></h3>
				<p class="vrstore-login-instructions"><?php esc_html_e( 'Enter your login credentials to continue with checkout.', 'vira-store' ); ?></p>
				
				<div id="vrstore-login-messages"></div>
				
				<form id="vrstore-login-form-fields">
					<?php wp_nonce_field('vrstore_login', 'vrstore_login_nonce'); ?>
					
					<div class="vrstore-form-row vrstore-mb-4">
						<label for="vrstore_login_username" class="vrstore-form-label"><?php esc_html_e( 'Username or Email', 'vira-store' ); ?> <span class="required">*</span></label>
						<input type="text" id="vrstore_login_username" name="vrstore_login_username" class="vrstore-form-input" required>
					</div>
					
					<div class="vrstore-form-row vrstore-mb-4">
						<label for="vrstore_login_password" class="vrstore-form-label"><?php esc_html_e( 'Password', 'vira-store' ); ?> <span class="required">*</span></label>
						<input type="password" id="vrstore_login_password" name="vrstore_login_password" class="vrstore-form-input" required>
					</div>
					
					<div class="vrstore-form-row vrstore-mb-4">
						<label class="vrstore-checkbox-label">
							<input type="checkbox" id="vrstore_login_remember" name="vrstore_login_remember" value="1">
							<span class="vrstore-checkbox-text"><?php esc_html_e( 'Remember Me', 'vira-store' ); ?></span>
						</label>
					</div>
					
					<div class="vrstore-form-actions vrstore-flex vrstore-gap-3">
						<button type="submit" class="vrstore-btn vrstore-btn-primary" id="vrstore-login-submit"><?php esc_html_e( 'Login', 'vira-store' ); ?></button>
						<button type="button" class="vrstore-btn vrstore-btn-link" id="vrstore-cancel-login"><?php esc_html_e( 'Cancel', 'vira-store' ); ?></button>
					</div>
					
					<div class="vrstore-login-help vrstore-mt-3">
						<p><small><a href="<?php echo esc_url( wp_lostpassword_url( get_permalink() ) ); ?>" target="_blank"><?php esc_html_e( 'Forgot your password?', 'vira-store' ); ?></a></small></p>
					</div>
				</form>
			</div>
			
			<!-- Registration Form (Initially Hidden) -->
			<div class="vrstore-register-form vrstore-card vrstore-mt-4" id="vrstore-register-form" style="display: none;">
				<h3><?php esc_html_e( 'Create Your Account', 'vira-store' ); ?></h3>
				<p class="vrstore-register-instructions"><?php esc_html_e( 'Fill in the information below and then click "Purchase and Register" to complete your order and create your account.', 'vira-store' ); ?></p>
				<form id="vrstore-registration-form">
					<?php wp_nonce_field('vrstore_register', 'vrstore_register_nonce'); ?>
					
					<div class="vrstore-form-row vrstore-mb-4">
						<label for="vrstore_reg_username" class="vrstore-form-label"><?php esc_html_e( 'Username', 'vira-store' ); ?> <span class="required">*</span></label>
						<input type="text" id="vrstore_reg_username" name="vrstore_reg_username" class="vrstore-form-input" required>
					</div>
					
					<div class="vrstore-form-row vrstore-mb-4">
						<label for="vrstore_reg_email" class="vrstore-form-label"><?php esc_html_e( 'Email Address', 'vira-store' ); ?> <span class="required">*</span></label>
						<input type="email" id="vrstore_reg_email" name="vrstore_reg_email" class="vrstore-form-input" required>
					</div>
					
					<div class="vrstore-form-row vrstore-mb-4">
						<label for="vrstore_reg_password" class="vrstore-form-label"><?php esc_html_e( 'Password', 'vira-store' ); ?> <span class="required">*</span></label>
						<input type="password" id="vrstore_reg_password" name="vrstore_reg_password" class="vrstore-form-input" minlength="6" required>
					</div>
					
					<div class="vrstore-form-row vrstore-mb-4">
						<label for="vrstore_reg_password_confirm" class="vrstore-form-label"><?php esc_html_e( 'Confirm Password', 'vira-store' ); ?> <span class="required">*</span></label>
						<input type="password" id="vrstore_reg_password_confirm" name="vrstore_reg_password_confirm" class="vrstore-form-input" minlength="6" required>
					</div>
					
					<div class="vrstore-form-actions">
						<button type="button" class="vrstore-btn vrstore-btn-link" id="vrstore-cancel-register"><?php esc_html_e( 'Cancel', 'vira-store' ); ?></button>
					</div>
				</form>
			</div>
		</div>
		<?php endif; ?>
		
		<div class="vrstore-checkout-form-container">
			<?php
			// Display success/error messages
			if (isset($_GET['vrstore_success'])) {
				echo '<div class="vrstore-notice vrstore-notice-success">' . esc_html(urldecode($_GET['vrstore_success'])) . '</div>';
			}
			if (isset($_GET['vrstore_error'])) {
				echo '<div class="vrstore-notice vrstore-notice-error">' . esc_html(urldecode($_GET['vrstore_error'])) . '</div>';
			}
			?>
			
			<?php 
			// Show form if user is logged in OR if PayPal payment mode is active (order already created)
			$should_show_form = $is_logged_in || (isset($vrstore_paypal_payment_mode) && $vrstore_paypal_payment_mode);
			?>
			<?php 
			// Prevent form submission if PayPal payment mode is active (PayPal button handles payment)
			$form_action = (isset($vrstore_paypal_payment_mode) && $vrstore_paypal_payment_mode) 
				? 'javascript:void(0);' 
				: admin_url('admin-post.php');
			$form_onclick = (isset($vrstore_paypal_payment_mode) && $vrstore_paypal_payment_mode)
				? 'onsubmit="return false;"'
				: '';
			?>
			<form class="vrstore-checkout-form" method="post" action="<?php echo esc_url( $form_action ); ?>" <?php echo ! $should_show_form ? 'style="display: none;"' : ''; ?> id="vrstore-main-checkout-form" <?php echo $form_onclick; ?>>
				<?php wp_nonce_field('vrstore_checkout', 'vrstore_checkout_nonce'); ?>
				<input type="hidden" name="action" value="vrstore_process_checkout">
				<input type="hidden" name="vrstore_order_id" value="<?php echo esc_attr( $order_id ); ?>">
				<input type="hidden" name="vrstore_cart_total" value="<?php echo esc_attr( $cart_total ); ?>">
				<input type="hidden" name="vrstore_currency" value="<?php echo esc_attr( $currency ); ?>">
				<input type="hidden" name="vrstore_thank_you_url" value="<?php echo esc_url( $thank_you_url ); ?>">
				
				<!-- Checkout form enhanced by frontend-enhanced.js -->
				<?php if ($is_logged_in): ?>
				<script>
				// Pass checkout variables to JavaScript
				window.vrstore_checkout_vars = {
					userId: '<?php echo get_current_user_id(); ?>',
					select_payment_method: '<?php esc_html_e("Please select a payment method before proceeding.", "vira-store"); ?>',
					processing: '<?php esc_html_e("Processing...", "vira-store"); ?>'
				};
				</script>
				<?php endif; ?>
				
				<!-- Login/Register Form Interactions handled by frontend-enhanced.js -->
				<?php if (!$is_logged_in): ?>
				<script>
				// Pass checkout variables to JavaScript for guest users
				window.vrstore_checkout_vars = window.vrstore_checkout_vars || {};
				Object.assign(window.vrstore_checkout_vars, {
					enter_credentials: '<?php esc_html_e("Please enter both username and password.", "vira-store"); ?>',
					security_token_missing: '<?php esc_html_e("Security token missing. Please refresh the page.", "vira-store"); ?>',
					logging_in: '<?php esc_html_e("Logging in...", "vira-store"); ?>',
					login_successful: '<?php esc_html_e("Login successful! Redirecting...", "vira-store"); ?>',
					login_failed: '<?php esc_html_e("Login failed. Please check your credentials.", "vira-store"); ?>',
					login: '<?php esc_html_e("Login", "vira-store"); ?>',
					login_timeout: '<?php esc_html_e("Login request timed out. Please try again.", "vira-store"); ?>',
					connection_failed: '<?php esc_html_e("Connection failed. Please check your internet connection.", "vira-store"); ?>',
					server_error: '<?php esc_html_e("Server error. Please try again later.", "vira-store"); ?>',
					error_occurred: '<?php esc_html_e("An error occurred. Please try again.", "vira-store"); ?>'
				});
				
				// Pass AJAX variables
				window.vrstore_ajax_vars = {
					ajax_url: '<?php echo admin_url('admin-ajax.php'); ?>'
				};
				</script>
				<?php endif; ?>

				
				<?php 
				// Get current user information
				$current_user = wp_get_current_user();
				?>
				
				<?php if ( $is_logged_in ) : ?>
			<div class="vrstore-checkout-section vrstore-card vrstore-mb-6">
				<!-- Logged-in user information -->
				<h2 class="vrstore-checkout-section-title vrstore-text-lg vrstore-font-semibold vrstore-mb-4"><?php esc_html_e( 'Account Information', 'vira-store' ); ?></h2>
					
					<div class="vrstore-logged-in-user-info">
						<div class="vrstore-user-welcome">
							<p class="vrstore-welcome-message">
								<strong><?php 
									$welcome_format = vrstore_is_textdomain_ready() ? esc_html__( 'Welcome back, %s!', 'vira-store' ) : 'Welcome back, %s!';
									printf( $welcome_format, esc_html( $current_user->display_name ) ); 
								?></strong>
								<br><small><?php echo esc_html( $current_user->user_email ); ?></small>
							</p>
							<?php
							$user_roles = $current_user->roles;
							$role_display = '';
							if ( in_array( 'administrator', $user_roles ) ) {
								$admin_text = vrstore_is_textdomain_ready() ? esc_html__( 'Administrator', 'vira-store' ) : 'Administrator';
								$role_display = '<span class="vrstore-admin-badge vrstore-user-badge">' . $admin_text . '</span>';
							} elseif ( in_array( 'customer', $user_roles ) ) {
								$customer_text = vrstore_is_textdomain_ready() ? esc_html__( 'Customer', 'vira-store' ) : 'Customer';
								$role_display = '<span class="vrstore-customer-badge vrstore-user-badge">' . $customer_text . '</span>';
							} else {
								$role_display = '<span class="vrstore-user-badge">' . esc_html( ucfirst( $user_roles[0] ?? 'User' ) ) . '</span>';
							}
							echo $role_display;
							?>
						</div>
						
						<!-- Hidden fields for logged-in user data -->
						<input type="hidden" id="vrstore_username" name="vrstore_username" value="<?php echo esc_attr( $current_user->user_login ); ?>">
						<input type="hidden" id="vrstore_email" name="vrstore_email" value="<?php echo esc_attr( $current_user->user_email ); ?>">
						<input type="hidden" name="vrstore_user_id" value="<?php echo esc_attr( $current_user->ID ); ?>">
						<input type="hidden" name="vrstore_is_logged_in" value="1">
						
						<div class="vrstore-checkout-user-actions">
							<p class="vrstore-user-actions">
								<small>
									<?php esc_html_e( 'Not you?', 'vira-store' ); ?> 
									<a href="<?php echo esc_url( wp_logout_url( get_permalink() ) ); ?>" class="vrstore-logout-link">
										<?php esc_html_e( 'Log out and checkout as different user', 'vira-store' ); ?>
									</a>
									</small>
								</p>
							</div>
						</div>
				</div>
                <?php endif; ?>
                
                <?php 
                // Check if cart total is zero (free course)
                $is_free_order = ($converted_cart_total <= 0);
                ?>
                
                <?php if (!$is_free_order): // Only show payment section for paid orders ?>
                <div class="vrstore-checkout-section vrstore-card vrstore-mb-6">
                <h2 class="vrstore-checkout-section-title vrstore-text-lg vrstore-font-semibold vrstore-mb-4"><?php echo $checkout_labels['payment_method']; ?></h2>
                    
                    <?php if ( ! empty( $payment_gateways ) ) : ?>
						<div class="vrstore-form-row vrstore-mb-4">
						<select id="vrstore_payment_method" name="vrstore_payment_method" class="vrstore-payment-method-select vrstore-form-select" required>
								<option value=""><?php echo $checkout_labels['select_payment_method']; ?></option>
								<?php 
								// Check if PayPal payment mode is active (from redirect)
								$paypal_selected = false;
								if (isset($vrstore_paypal_payment_mode) && $vrstore_paypal_payment_mode && isset($_GET['vrstore_payment']) && $_GET['vrstore_payment'] === 'paypal') {
									$paypal_selected = true;
								}
								foreach ( $payment_gateways as $gateway_id => $gateway ) : 
									$selected = ($gateway_id === 'paypal' && $paypal_selected) ? 'selected="selected"' : '';
								?>
									<option value="<?php echo esc_attr( $gateway_id ); ?>" <?php echo $selected; ?>><?php echo esc_html( $gateway['name'] ); ?></option>
								<?php endforeach; ?>
							</select>
						</div>
						
						<?php foreach ( $payment_gateways as $gateway_id => $gateway ) : ?>
							<?php 
							// Show PayPal fields by default if PayPal payment mode is active
							$field_display = '';
							if ($gateway_id === 'paypal' && isset($vrstore_paypal_payment_mode) && $vrstore_paypal_payment_mode) {
								$field_display = 'style="display: block;"';
							}
							?>
							<div id="vrstore-payment-method-<?php echo esc_attr( $gateway_id ); ?>" class="vrstore-payment-method-fields" <?php echo $field_display; ?>>
								<div class="vrstore-payment-method-description">
									<?php if ( ! empty( $gateway['icon'] ) && filter_var( $gateway['icon'], FILTER_VALIDATE_URL ) ) : ?>
										<img src="<?php echo esc_url( $gateway['icon'] ); ?>" alt="<?php echo esc_attr( $gateway['name'] ); ?>" class="vrstore-payment-method-icon">
									<?php endif; ?>
									<p><?php echo esc_html( $gateway['description'] ); ?></p>
								</div>
								
								<?php if ( 'tripay' === $gateway_id ) : ?>
									<!-- TriPay payment fields - Dynamic channel fetching -->
							<div class="vrstore-form-row vrstore-mb-4">
								<label for="tripay_method" class="vrstore-form-label"><?php esc_html_e( 'Payment Channel', 'vira-store' ); ?> <span class="required">*</span></label>
								<select id="tripay_method" name="tripay_method" class="vrstore-form-select" data-required="true">
											<option value=""><?php esc_html_e( 'Select a payment channel', 'vira-store' ); ?></option>
											<?php
											// Fetch dynamic payment channels from TriPay API
											// Always fetch fresh - don't rely on cached errors
											if ( class_exists( 'VRSTORE_Payment' ) ) {
												$payment_instance = VRSTORE_Payment::get_instance();
												if ( method_exists( $payment_instance, 'get_tripay_payment_channels' ) ) {
													// Always fetch fresh - clear any cached errors
													delete_option('vrstore_tripay_ip_whitelist_error');
													delete_transient('vrstore_tripay_ip_whitelist_error');
													$tripay_channels = $payment_instance->get_tripay_payment_channels();

													if ( ! is_wp_error( $tripay_channels ) && is_array( $tripay_channels ) ) {
														// Group channels by type for better UX
														$channel_groups = array(
															'Virtual Account' => array(),
															'E-Wallet' => array(),
															'Retail' => array(),
															'Other' => array()
														);

														foreach ( $tripay_channels as $channel ) {
															$code = $channel['code'] ?? '';
															$name = $channel['name'] ?? '';
															$group = $channel['group'] ?? 'Other';

															if ( ! empty( $code ) && ! empty( $name ) ) {
																if ( isset( $channel_groups[ $group ] ) ) {
																	$channel_groups[ $group ][] = array(
																		'code' => $code,
																		'name' => $name
																	);
																} else {
																	$channel_groups['Other'][] = array(
																		'code' => $code,
																		'name' => $name
																	);
																}
															}
														}

														// Output grouped channels
														foreach ( $channel_groups as $group_name => $channels ) {
															if ( ! empty( $channels ) ) {
																echo '<optgroup label="' . esc_attr( $group_name ) . '">';
																foreach ( $channels as $channel ) {
																	printf(
																		'<option value="%s">%s</option>',
																		esc_attr( $channel['code'] ),
																		esc_html( $channel['name'] )
																	);
																}
																echo '</optgroup>';
															}
														}
													} else {
														// Show error message for IP whitelist issues
														if ( is_wp_error( $tripay_channels ) && $tripay_channels->get_error_code() === 'tripay_ip_whitelist_error' ) {
															// Get IP error info from transient or option (fallback)
															$ip_error = get_transient('vrstore_tripay_ip_whitelist_error');
															if (false === $ip_error) {
																$ip_error = get_option('vrstore_tripay_ip_whitelist_error', []);
															}
															
															$server_ip = isset($ip_error['ip']) ? $ip_error['ip'] : 'unknown';
															$error_message = isset($ip_error['message']) ? $ip_error['message'] : $tripay_channels->get_error_message();
															
															// Try to extract IP from error message if available
															if (preg_match('/IP \((.+?)\)/', $error_message, $matches)) {
																$server_ip = $matches[1];
															}
															?>
															<option value="" disabled><?php esc_html_e( '⚠️ Payment channels unavailable - IP whitelist required', 'vira-store' ); ?></option>
															<?php
															// Show admin notice if user is admin
															if ( current_user_can( 'manage_options' ) ) {
																echo '<div class="vrstore-tripay-admin-notice" style="background: #fff3cd; border: 1px solid #ffc107; border-radius: 4px; padding: 12px; margin: 10px 0; color: #856404;">';
																echo '<strong>' . esc_html__( 'Admin Notice:', 'vira-store' ) . '</strong><br>';
																echo esc_html__( 'TriPay API requires IP whitelisting. Please add your server IP to TriPay dashboard:', 'vira-store' ) . ' <code style="background: #fff; padding: 2px 6px; border-radius: 3px; font-weight: bold;">' . esc_html( $server_ip ) . '</code><br>';
																echo '<small>' . esc_html__( 'Go to TriPay Dashboard → Settings → Whitelist IP and add this IP address.', 'vira-store' ) . '</small><br>';
																echo '<small style="color: #666; margin-top: 8px; display: block;">';
																echo esc_html__( 'If you already added the IP, click the button below to refresh and retry:', 'vira-store' );
																echo '</small>';
																echo '<button type="button" id="vrstore-retry-tripay-channels" class="button button-secondary" style="margin-top: 8px;">';
																echo esc_html__( '🔄 Refresh Payment Channels', 'vira-store' );
																echo '</button>';
																?>
																<script>
																(function() {
																	var btn = document.getElementById('vrstore-retry-tripay-channels');
																	if (btn) {
																		btn.addEventListener('click', function() {
																			btn.disabled = true;
																			btn.textContent = '<?php esc_html_e( 'Refreshing...', 'vira-store' ); ?>';
																			
																			var formData = new FormData();
																			formData.append('action', 'vrstore_refresh_tripay_channels');
																			formData.append('nonce', '<?php echo wp_create_nonce('vrstore_refresh_tripay_channels'); ?>');
																			
																			fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
																				method: 'POST',
																				body: formData
																			})
																			.then(response => response.json())
																			.then(data => {
																				if (data.success) {
																					// Reload page to show updated channels
																					location.reload();
																				} else {
																					alert('<?php esc_html_e( 'Error: ', 'vira-store' ); ?>' + (data.data.message || '<?php esc_html_e( 'Failed to refresh channels', 'vira-store' ); ?>'));
																					btn.disabled = false;
																					btn.textContent = '<?php esc_html_e( '🔄 Refresh Payment Channels', 'vira-store' ); ?>';
																				}
																			})
																			.catch(error => {
																				console.error('Error:', error);
																				alert('<?php esc_html_e( 'Network error. Please try again.', 'vira-store' ); ?>');
																				btn.disabled = false;
																				btn.textContent = '<?php esc_html_e( '🔄 Refresh Payment Channels', 'vira-store' ); ?>';
																			});
																		});
																	}
																})();
																</script>
																<?php
																echo '</div>';
															} else {
																// For non-admin users, show a simpler message
																echo '<div class="vrstore-tripay-user-notice" style="background: #fff3cd; border: 1px solid #ffc107; border-radius: 4px; padding: 12px; margin: 10px 0; color: #856404;">';
																echo '<small>' . esc_html__( 'Payment channels are temporarily unavailable. Please contact the administrator or try again later.', 'vira-store' ) . '</small>';
																echo '</div>';
															}
														}
														
														// Fallback to static channels if API fails (for non-IP-whitelist errors or when admin needs to test)
														// Only show static channels if not IP whitelist error
														if ( ! is_wp_error( $tripay_channels ) || $tripay_channels->get_error_code() !== 'tripay_ip_whitelist_error' ) {
															?>
															<option value="BRIVA"><?php esc_html_e( 'BRI Virtual Account', 'vira-store' ); ?></option>
															<option value="BNIVA"><?php esc_html_e( 'BNI Virtual Account', 'vira-store' ); ?></option>
															<option value="MANDIRIVA"><?php esc_html_e( 'Mandiri Virtual Account', 'vira-store' ); ?></option>
															<option value="BCAVA"><?php esc_html_e( 'BCA Virtual Account', 'vira-store' ); ?></option>
															<option value="OVO"><?php esc_html_e( 'OVO', 'vira-store' ); ?></option>
															<option value="DANA"><?php esc_html_e( 'DANA', 'vira-store' ); ?></option>
															<option value="QRIS"><?php esc_html_e( 'QRIS', 'vira-store' ); ?></option>
															<?php
														}
														
														// Log the error for debugging
														if ( is_wp_error( $tripay_channels ) ) {
															error_log( 'ViraStore TriPay: Failed to fetch payment channels - ' . $tripay_channels->get_error_message() );
														}
													}
												}
											}
											?>
										</select>
										<p class="vrstore-field-description" style="font-size: 12px; color: #666; margin-top: 5px;">
											<?php esc_html_e( 'Choose your preferred payment method', 'vira-store' ); ?>
										</p>
									</div>
								<?php elseif ( 'paypal' === $gateway_id ) : ?>
									<!-- PayPal payment integration -->
									<div class="vrstore-paypal-form-container">
										<?php 
										// Check if PayPal payment mode is active and we have payment data
										if (isset($vrstore_paypal_payment_mode) && $vrstore_paypal_payment_mode && isset($vrstore_paypal_payment_data)) {
											// Render PayPal payment form using addon's payment form class
											if (class_exists('ViraStore_PayPal_Payment_Form')) {
												$paypal_form = new ViraStore_PayPal_Payment_Form();
												$paypal_form->render($vrstore_paypal_payment_data);
											} else {
												// Fallback: show button container (will be initialized by JavaScript)
												echo '<div id="vrstore-paypal-button-container"></div>';
												echo '<p class="vrstore-paypal-description">';
												esc_html_e( 'You will be redirected to PayPal to complete your payment securely.', 'vira-store' );
												echo '</p>';
											}
										} else {
											// Normal mode: show placeholder container
											echo '<div id="vrstore-paypal-button-container"></div>';
											echo '<p class="vrstore-paypal-description">';
											esc_html_e( 'You will be redirected to PayPal to complete your payment securely.', 'vira-store' );
											echo '</p>';
										}
										?>
									</div>
								<?php elseif ( 'xendit' === $gateway_id ) : ?>
									<!-- Xendit payment integration -->
									<div class="vrstore-xendit-form-container">
										<?php
										// Get enabled Xendit payment methods from settings
										$xendit_payment_methods = get_option( 'virastore_xendit_payment_methods', array() );
										
										// Check if any payment methods are enabled
										if ( ! empty( $xendit_payment_methods ) ) :
										?>
											<!-- Payment Channel Selection -->
											<div class="vrstore-form-row vrstore-mb-4">
												<label for="xendit_payment_channel" class="vrstore-form-label">
													<?php esc_html_e( 'Payment Method', 'vira-store' ); ?> <span class="required">*</span>
												</label>
												<select id="xendit_payment_channel" name="xendit_payment_channel" class="vrstore-form-select" data-required="true">
													<option value=""><?php esc_html_e( 'Select a payment method', 'vira-store' ); ?></option>
													<?php if ( isset( $xendit_payment_methods['credit_card'] ) && $xendit_payment_methods['credit_card'] === 'on' ) : ?>
														<option value="credit_card"><?php esc_html_e( 'Credit Card', 'virastore-xendit' ); ?></option>
													<?php endif; ?>
													<?php if ( isset( $xendit_payment_methods['bank_transfer'] ) && $xendit_payment_methods['bank_transfer'] === 'on' ) : ?>
														<option value="bank_transfer"><?php esc_html_e( 'Bank Transfer', 'virastore-xendit' ); ?></option>
													<?php endif; ?>
													<?php if ( isset( $xendit_payment_methods['e_wallet'] ) && $xendit_payment_methods['e_wallet'] === 'on' ) : ?>
														<option value="e_wallet"><?php esc_html_e( 'E-Wallet', 'virastore-xendit' ); ?></option>
													<?php endif; ?>
													<?php if ( isset( $xendit_payment_methods['retail'] ) && $xendit_payment_methods['retail'] === 'on' ) : ?>
														<option value="retail"><?php esc_html_e( 'Retail Outlet', 'virastore-xendit' ); ?></option>
													<?php endif; ?>
												</select>
												<p class="vrstore-field-description" style="font-size: 12px; color: #666; margin-top: 5px;">
													<?php esc_html_e( 'Choose your preferred Xendit payment method', 'virastore-xendit' ); ?>
												</p>
											</div>
											
											<!-- Credit Card Fields -->
											<div id="vrstore-xendit-credit_card-fields" class="vrstore-xendit-method-fields" style="display: none;">
												<div class="vrstore-form-row vrstore-mb-4">
													<label for="xendit_card_number" class="vrstore-form-label">
														<?php esc_html_e( 'Card Number', 'virastore-xendit' ); ?> <span class="required">*</span>
													</label>
													<input type="text" id="xendit_card_number" name="xendit_card_number" class="vrstore-form-input" placeholder="1234 5678 9012 3456" autocomplete="cc-number" maxlength="19">
												</div>
												
												<div class="vrstore-form-row vrstore-mb-4">
													<div class="vrstore-form-row-inline">
														<div class="vrstore-form-col-half">
															<label for="xendit_card_expiry" class="vrstore-form-label">
																<?php esc_html_e( 'Expiry Date (MM/YY)', 'virastore-xendit' ); ?> <span class="required">*</span>
															</label>
															<input type="text" id="xendit_card_expiry" name="xendit_card_expiry" class="vrstore-form-input" placeholder="MM/YY" autocomplete="cc-exp" maxlength="5">
														</div>
														<div class="vrstore-form-col-half">
															<label for="xendit_card_cvc" class="vrstore-form-label">
																<?php esc_html_e( 'CVC', 'virastore-xendit' ); ?> <span class="required">*</span>
															</label>
															<input type="text" id="xendit_card_cvc" name="xendit_card_cvc" class="vrstore-form-input" placeholder="123" autocomplete="cc-csc" maxlength="4">
														</div>
													</div>
												</div>
											</div>
											
											<!-- Bank Transfer Fields -->
											<div id="vrstore-xendit-bank_transfer-fields" class="vrstore-xendit-method-fields" style="display: none;">
												<div class="vrstore-form-row vrstore-mb-4">
													<label class="vrstore-form-label">
														<?php esc_html_e( 'Select Bank', 'virastore-xendit' ); ?> <span class="required">*</span>
													</label>
													<div class="vrstore-xendit-bank-options">
														<label class="vrstore-bank-option">
															<input type="radio" name="xendit_bank" value="bca" checked>
															<span>BCA</span>
														</label>
														<label class="vrstore-bank-option">
															<input type="radio" name="xendit_bank" value="bni">
															<span>BNI</span>
														</label>
														<label class="vrstore-bank-option">
															<input type="radio" name="xendit_bank" value="bri">
															<span>BRI</span>
														</label>
														<label class="vrstore-bank-option">
															<input type="radio" name="xendit_bank" value="mandiri">
															<span>Mandiri</span>
														</label>
														<label class="vrstore-bank-option">
															<input type="radio" name="xendit_bank" value="permata">
															<span>Permata</span>
														</label>
													</div>
												</div>
											</div>
											
											<!-- E-Wallet Fields -->
											<div id="vrstore-xendit-e_wallet-fields" class="vrstore-xendit-method-fields" style="display: none;">
												<div class="vrstore-form-row vrstore-mb-4">
													<label class="vrstore-form-label">
														<?php esc_html_e( 'Select E-Wallet', 'virastore-xendit' ); ?> <span class="required">*</span>
													</label>
													<div class="vrstore-xendit-ewallet-options">
														<label class="vrstore-ewallet-option">
															<input type="radio" name="xendit_ewallet" value="ovo" checked>
															<span>OVO</span>
														</label>
														<label class="vrstore-ewallet-option">
															<input type="radio" name="xendit_ewallet" value="dana">
															<span>DANA</span>
														</label>
														<label class="vrstore-ewallet-option">
															<input type="radio" name="xendit_ewallet" value="linkaja">
															<span>LinkAja</span>
														</label>
														<label class="vrstore-ewallet-option">
															<input type="radio" name="xendit_ewallet" value="shopeepay">
															<span>ShopeePay</span>
														</label>
													</div>
												</div>
												<div class="vrstore-form-row vrstore-mb-4">
													<label for="xendit_phone_number" class="vrstore-form-label">
														<?php esc_html_e( 'Phone Number', 'virastore-xendit' ); ?> <span class="required">*</span>
													</label>
													<input type="text" id="xendit_phone_number" name="xendit_phone_number" class="vrstore-form-input" placeholder="08123456789" required>
												</div>
											</div>
											
											<!-- Retail Outlet Fields -->
											<div id="vrstore-xendit-retail-fields" class="vrstore-xendit-method-fields" style="display: none;">
												<div class="vrstore-form-row vrstore-mb-4">
													<label class="vrstore-form-label">
														<?php esc_html_e( 'Select Retail Outlet', 'virastore-xendit' ); ?> <span class="required">*</span>
													</label>
													<div class="vrstore-xendit-retail-options">
														<label class="vrstore-retail-option">
															<input type="radio" name="xendit_retail" value="alfamart" checked>
															<span>Alfamart</span>
														</label>
														<label class="vrstore-retail-option">
															<input type="radio" name="xendit_retail" value="indomaret">
															<span>Indomaret</span>
														</label>
													</div>
												</div>
											</div>
										<?php else : ?>
											<p class="vrstore-no-payment-methods">
												<?php esc_html_e( 'No Xendit payment methods are currently available. Please try again later or contact the site administrator.', 'virastore-xendit' ); ?>
											</p>
											<?php endif; ?>
									</div>
								<?php elseif ( 'moota' === $gateway_id ) : ?>
									<!-- Moota payment integration -->
									<div class="vrstore-moota-form-container">
										<?php
										// Check if Moota gateway is available
										if ( class_exists( 'ViraStore_Moota_Gateway' ) ) {
											$moota_gateway = ViraStore_Moota_Gateway::get_instance();
											
											if ( $moota_gateway->is_enabled() ) {
												// Render payment form using Moota gateway's method
												$moota_gateway->render_payment_form();
											} else {
												echo '<div class="vrstore-error">';
												echo esc_html__( 'Moota payment gateway is not enabled.', 'vira-store' );
												echo '</div>';
											}
										} else {
											echo '<div class="vrstore-error">';
											echo esc_html__( 'Moota payment gateway is not available.', 'vira-store' );
											echo '</div>';
										}
										?>
									</div>
								<?php elseif ( 'manual' === $gateway_id ) : ?>
                                    <?php
                                    // Get simplified bank transfer settings
                                    $vrstore_settings = get_option( 'vrstore_settings', array() );
                                    $bank_details = $vrstore_settings['manual_bank_details'] ?? '';
                                    $additional_info = $vrstore_settings['manual_additional_info'] ?? '';
                                    $whatsapp_number = $vrstore_settings['manual_whatsapp_number'] ?? '';
                                    $default_instructions = vrstore_is_textdomain_ready() ? esc_html__( 'Please transfer the total amount to the bank account details provided above. Include your Order ID in the transfer reference for faster processing. After completing the transfer, please contact us with your payment confirmation.', 'vira-store' ) : 'Please transfer the total amount to the bank account details provided above. Include your Order ID in the transfer reference for faster processing. After completing the transfer, please contact us with your payment confirmation.';
                                    $instructions = !empty($vrstore_settings['manual_instructions']) ? $vrstore_settings['manual_instructions'] : $default_instructions;
                                    ?>
                                    <!-- Enhanced Transfer Bank payment instructions -->
                                    <div class="vrstore-form-row vrstore-bank-transfer-instructions vrstore-card vrstore-p-4" style="text-align: center;">
                                        <div class="vrstore-bank-transfer-header">
                                            <h3><?php esc_html_e( '🏦 Bank Transfer Payment', 'vira-store' ); ?></h3>
                                            <p class="vrstore-bank-transfer-description"><?php esc_html_e( 'Complete your payment total amount to our detail bank account on the next step.', 'vira-store' ); ?></p>
                                        <br><div class="vrstore-important-note">
                                          <strong><?php esc_html_e( 'Important:', 'vira-store' ); ?></strong>
                                            <?php esc_html_e( 'Please include your Order ID in the transfer reference for quickly processing.', 'vira-store' ); ?>
                                        </div>
										</div>                                        
                                    </div>
                                <?php endif; ?>
							</div>
						<?php endforeach; ?>
                    <?php else : ?>
                        <p class="vrstore-no-payment-methods"><?php esc_html_e( 'No payment methods available. Please contact the administrator.', 'vira-store' ); ?></p>
                    <?php endif; ?>
                </div>
                <?php else: // Free course message ?>
                    <div class="vrstore-free-course-section vrstore-card vrstore-mb-6">
                        <div class="vrstore-free-course-header" style="text-align: center; padding: 30px 20px; background: linear-gradient(135deg, #4CAF50, #45a049); color: white; border-radius: 8px 8px 0 0; margin: -20px -20px 20px -20px;">
                            <div style="font-size: 48px; margin-bottom: 10px;">🎉</div>
                            <h2 style="margin: 0 0 10px 0; font-size: 24px;"><?php esc_html_e( 'Free Course!', 'vira-store' ); ?></h2>
                            <p style="margin: 0; font-size: 16px; opacity: 0.9;"><?php esc_html_e( 'This course is completely free. No payment required!', 'vira-store' ); ?></p>
                        </div>
                        <div class="vrstore-free-course-benefits" style="padding: 0 20px;">
                            <h3 style="color: #333; margin-bottom: 15px;"><?php esc_html_e( 'What you get:', 'vira-store' ); ?></h3>
                            <ul style="list-style: none; padding: 0; color: #555;">
                                <li style="padding: 5px 0; display: flex; align-items: center;"><span style="color: #4CAF50; margin-right: 10px; font-size: 18px;">✓</span><?php esc_html_e( 'Full access to all course content', 'vira-store' ); ?></li>
                                <li style="padding: 5px 0; display: flex; align-items: center;"><span style="color: #4CAF50; margin-right: 10px; font-size: 18px;">✓</span><?php esc_html_e( 'Downloadable course materials', 'vira-store' ); ?></li>
                                <li style="padding: 5px 0; display: flex; align-items: center;"><span style="color: #4CAF50; margin-right: 10px; font-size: 18px;">✓</span><?php esc_html_e( 'Lifetime access to the course', 'vira-store' ); ?></li>
                                <li style="padding: 5px 0; display: flex; align-items: center;"><span style="color: #4CAF50; margin-right: 10px; font-size: 18px;">✓</span><?php esc_html_e( 'Certificate of completion', 'vira-store' ); ?></li>
                            </ul>
                        </div>
                    </div>
                <?php endif; // End payment section conditional ?>
                
                <div class="vrstore-checkout-submit vrstore-mt-6">
                    <?php 
                    // Hide submit button if PayPal payment mode is active (PayPal button handles submission)
                    if (isset($vrstore_paypal_payment_mode) && $vrstore_paypal_payment_mode) {
                        // PayPal form handles submission, but show a note
                        echo '<p class="vrstore-paypal-payment-note" style="text-align: center; padding: 15px; background: #f0f8ff; border: 1px solid #b3d9ff; border-radius: 5px; color: #0066cc; margin: 20px 0;">';
                        esc_html_e( 'Please complete payment using the PayPal button above.', 'vira-store' );
                        echo '</p>';
                    } else {
                        // Normal checkout submit button
                    ?>
                    <button type="submit" class="vrstore-btn vrstore-btn-primary vrstore-btn-lg vrstore-w-full vrstore-checkout-button">
                        <?php echo $is_free_order ? esc_html__( 'Enroll for Free', 'vira-store' ) : esc_html__( 'Purchase and Register', 'vira-store' ); ?>
                    </button>
                    <?php } ?>
                </div>
                
                <!-- Hidden field to indicate free order -->
                <?php if ($is_free_order): ?>
                    <input type="hidden" name="vrstore_free_order" value="1">
                <?php endif; ?>
            </form>
		</div>
		</div>
	</div>
	
	<!-- Order Summary - Right Sidebar -->
	<div class="vrstore-checkout-sidebar">
		<div class="vrstore-order-summary vrstore-card">
			<h2 class="vrstore-order-summary-title vrstore-text-lg vrstore-font-semibold vrstore-mb-4"><?php echo $checkout_labels['order_summary']; ?></h2>
			
			<div class="vrstore-order-items">
				<?php foreach ( $cart_items as $item ) : ?>
					<?php
					$product_id = $item['product_id'];
					$quantity = $item['quantity'];
					
					// Handle Extended Support items which have custom product names
					if ( isset( $item['product_name'] ) && is_string( $product_id ) && strpos( $product_id, 'extended_support' ) === 0 ) {
						$product_title = $item['product_name'];
					} else {
						$product_title = get_the_title( $product_id );
					}
					
					// Get price using cart's pricing logic (includes license type pricing)
					$cart_instance = VRSTORE_Cart::get_instance();
					$final_price = $cart_instance->get_item_price( $item );
					
					// Calculate item total - Extended Support items already store the full total
					$is_extended_support = isset( $item['product_id'] ) && is_string( $item['product_id'] ) && strpos( $item['product_id'], 'extended_support' ) === 0;
					
					if ( $is_extended_support ) {
						// For Extended Support: final_price is total for all months, calculate per-month for display
						$item_total = $final_price; // Already the total amount
						
						// Calculate per-month price for display purposes
						if ( isset( $item['months'] ) && $item['months'] > 0 ) {
							$price_per_month = $final_price / $item['months'];
							$display_price = $price_per_month; // Show per-month price
						} else {
							$display_price = $final_price; // Fallback to total
						}
					} else {
						$display_price = $final_price;
						$item_total = $final_price * $quantity;
						
					}
					
					// Handle currency conversion for Extended Support vs regular items (including courses)
					if ( $is_extended_support ) {
						// Extended Support prices are already converted - no conversion needed
						$converted_display_price = $display_price;
						$converted_item_total = $item_total;
					} else {
						// Regular items AND courses need currency conversion
						$converted_display_price = $currency_converter->convert_price( $display_price, $user_currency );
						$converted_item_total = $currency_converter->convert_price( $item_total, $user_currency );
					}
					
					// Format prices using currency converter - no double conversion
					$formatted_price = $currency_converter->format_converted_price( $converted_display_price, $user_currency );
					$formatted_item_total = $currency_converter->format_converted_price( $converted_item_total, $user_currency );
					?>
					<div class="vrstore-order-item vrstore-border-b vrstore-pb-3 vrstore-mb-3" data-product-id="<?php echo esc_attr( $product_id ); ?>">
						<div class="vrstore-order-item-details">
							<div class="vrstore-order-item-title">
								<?php 
								// Add item type indicator
								if ( $is_extended_support ) {
									echo '<span class="vrstore-item-type-badge vrstore-support-badge">🛠️ ' . esc_html__('Extended Support', 'vira-store') . '</span> ';
								} elseif ( is_numeric($product_id) ) {
									$post_type = get_post_type($product_id);
									if ($post_type === 'vrstore_course') {
										echo '<span class="vrstore-item-type-badge vrstore-course-badge">📚 ' . esc_html__('Course', 'vira-store') . '</span> ';
									} elseif ($post_type === 'vrstore_product') {
										echo '<span class="vrstore-item-type-badge vrstore-product-badge">📦 ' . esc_html__('Product', 'vira-store') . '</span> ';
									}
								}
								echo esc_html( $product_title ); 
								?>
							</div>
							<?php if ( ! empty( $item['license_type'] ) ) : ?>
								<?php
								// Get license type display name from unified custom licensing system
								$settings = get_option( 'vrstore_settings', [] );
								$custom_license_types = $settings['custom_license_types'] ?? [];
								$license_display = ucfirst( str_replace( '-', ' ', $item['license_type'] ) ); // Default fallback
								
								// Look for custom license type with matching slug
								foreach ( $custom_license_types as $custom_type ) {
									$type_slug = isset( $custom_type['slug'] ) ? $custom_type['slug'] : sanitize_title( $custom_type['label'] ?? '' );
									if ( $type_slug === $item['license_type'] && ! empty( $custom_type['label'] ) ) {
										$license_display = $custom_type['label'];
										break;
									}
								}
								?>
								<div class="vrstore-order-item-license"><?php 
								$license_format = vrstore_is_textdomain_ready() ? __( 'License: %s', 'vira-store' ) : 'License: %s';
								echo esc_html( sprintf( $license_format, $license_display ) ); 
							?></div>
							<?php endif; ?>
							<div class="vrstore-order-item-quantity"><?php 
						$quantity_format = vrstore_is_textdomain_ready() ? __( 'Quantity: %s', 'vira-store' ) : 'Quantity: %s';
						echo esc_html( sprintf( $quantity_format, $quantity ) ); 
					?></div>
				<div class="vrstore-order-item-price"><?php 
						if ( $is_extended_support && isset( $item['months'] ) ) {
							$price_format = vrstore_is_textdomain_ready() ? __( 'Price: %s/month (%d months)', 'vira-store' ) : 'Price: %s/month (%d months)';
							echo esc_html( sprintf( $price_format, $formatted_price, $item['months'] ) );
						} else {
							$price_format = vrstore_is_textdomain_ready() ? __( 'Price: %s', 'vira-store' ) : 'Price: %s';
							echo esc_html( sprintf( $price_format, $formatted_price ) );
						}
					?></div>
						</div>
						<div class="vrstore-order-item-total"><?php echo esc_html( $formatted_item_total ); ?></div>
					</div>
				<?php endforeach; ?>
			</div>
			
			<!-- Coupon Section -->
			<div class="vrstore-coupon-section vrstore-border-t vrstore-pt-4 vrstore-mt-4">
				<?php if ( ! $applied_coupon ) : ?>
					<div class="vrstore-coupon-input-section">
						<label for="vrstore-coupon-code" class="vrstore-coupon-label">
							<?php esc_html_e( 'Coupon Code', 'vira-store' ); ?>
						</label>
						<div class="vrstore-coupon-input-group">
							<input type="text" id="vrstore-coupon-code" class="vrstore-coupon-input" placeholder="<?php esc_attr_e( 'Enter coupon code', 'vira-store' ); ?>" maxlength="50">
							<button type="button" class="vrstore-coupon-apply-btn" id="vrstore-apply-coupon">
								<?php esc_html_e( 'Apply', 'vira-store' ); ?>
							</button>
						</div>
						<div class="vrstore-coupon-message" id="vrstore-coupon-message" style="display: none;"></div>
					</div>
				<?php else : ?>
					<div class="vrstore-coupon-applied-section">
						<div class="vrstore-applied-coupon">
							<span class="vrstore-coupon-icon">🎟️</span>
							<span class="vrstore-coupon-code"><?php echo esc_html( $applied_coupon['code'] ); ?></span>
							<span class="vrstore-coupon-description">
								<?php 
								if ( $applied_coupon['discount_type'] === 'percentage' ) {
									printf(
										esc_html__( '%s%% off', 'vira-store' ),
										number_format( $applied_coupon['discount_value'], 0 )
									);
								} else {
									printf(
										esc_html__( '%s off', 'vira-store' ),
										$product_instance->format_price( $applied_coupon['discount_value'], $currency )
									);
								}
								?>
							</span>
							<button type="button" class="vrstore-coupon-remove-btn" id="vrstore-remove-coupon" title="<?php esc_attr_e( 'Remove coupon', 'vira-store' ); ?>">
								<span class="vrstore-remove-icon">✖</span>
							</button>
						</div>
						<div class="vrstore-coupon-message" id="vrstore-coupon-message" style="display: none;"></div>
					</div>
				<?php endif; ?>
			</div>
			
			<div class="vrstore-order-totals">
				<div class="vrstore-order-subtotal">
					<div class="vrstore-order-total-label"><?php esc_html_e( 'Subtotal', 'vira-store' ); ?></div>
					<div class="vrstore-order-total-value" id="vrstore-subtotal-value"><?php 
						echo esc_html( $currency_converter->format_converted_price( $converted_cart_subtotal, $user_currency ) );
					?></div>
				</div>
				<div class="vrstore-order-discount" id="vrstore-discount-section" <?php echo ( ! $applied_coupon || $discount_amount <= 0 ) ? 'style="display: none;"' : ''; ?>>
					<div class="vrstore-order-total-label">
						<?php esc_html_e( 'Discount', 'vira-store' ); ?>
						<small id="vrstore-discount-code"><?php echo $applied_coupon ? '(' . esc_html( $applied_coupon['code'] ) . ')' : ''; ?></small>
					</div>
					<div class="vrstore-order-total-value" id="vrstore-discount-value">-<?php echo esc_html( $currency_converter->format_converted_price( $converted_discount_amount, $user_currency ) ); ?></div>
				</div>
				<div class="vrstore-order-total">
					<div class="vrstore-order-total-label"><strong><?php esc_html_e( 'Total', 'vira-store' ); ?></strong></div>
					<div class="vrstore-order-total-value" id="vrstore-total-value"><strong><?php 
						echo esc_html( $currency_converter->format_converted_price( $converted_cart_total, $user_currency ) );
					?></strong></div>
				</div>
			</div>
		</div>
	</div>
</div>
