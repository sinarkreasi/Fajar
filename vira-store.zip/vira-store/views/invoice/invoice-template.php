<?php
/**
 * Invoice Template
 *
 * This template can be overridden by copying it to yourtheme/vira-store/invoice/invoice-template.php.
 *
 * @package Vira_Store
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// Get currency converter instance for price conversion
$currency_converter = null;
if (class_exists('VRSTORE_Currency_Converter')) {
    $currency_converter = VRSTORE_Currency_Converter::get_instance();
}

// Format currency with conversion if available
if ($currency_converter && method_exists($currency_converter, 'convert_amount') && method_exists($currency_converter, 'format_converted_price')) {
    // Get the stored currency (fallback to base currency if not set)
    $stored_currency = $invoice_data['currency'] ?? $currency_converter->get_base_currency();
    $user_currency = $currency_converter->get_user_currency();
    
    // Convert from stored currency to user's currency
    $converted_price = $currency_converter->convert_amount(
        floatval($invoice_data['product_price']), 
        $stored_currency, 
        $user_currency
    );
    $formatted_price = $currency_converter->format_converted_price($converted_price, $user_currency);
} else {
    // Fallback to original formatting
    $formatted_price = vrstore_format_price( $invoice_data['product_price'] );
}

// Format dates
$invoice_date = date_i18n( get_option( 'date_format' ), strtotime( $invoice_data['invoice_date'] ) );
$order_date = date_i18n( get_option( 'date_format' ), strtotime( $invoice_data['order_date'] ) );
?>
<!DOCTYPE html>
<html lang="<?php echo esc_attr( get_locale() ); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo esc_html( sprintf( __( 'Invoice %s', 'vira-store' ), $invoice_data['invoice_number'] ) ); ?></title>
    <style>
        /* Use WordPress admin.css inspired styling for consistency */
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
            font-size: 13px;
            line-height: 1.4em;
            color: #23282d;
            background: #fff;
            margin: 0;
            padding: 20px;
        }

        .invoice-container {
            max-width: 800px;
            margin: 0 auto;
            background: #fff;
            border: 1px solid #c3c4c7;
            box-shadow: 0 1px 3px rgba(0,0,0,.13);
            border-radius: 3px;
        }

        .invoice-header {
            background: #f6f7f7;
            border-bottom: 1px solid #c3c4c7;
            padding: 20px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .invoice-header .logo {
            max-height: 60px;
            max-width: 200px;
        }

        .invoice-header .company-info {
            text-align: right;
        }

        .invoice-header .company-name {
            font-size: 24px;
            font-weight: 600;
            margin: 0;
            color: #1d2327;
        }

        .invoice-header .company-description {
            font-size: 14px;
            color: #646970;
            margin: 5px 0 0 0;
        }

        .invoice-content {
            padding: 30px;
        }

        .invoice-title {
            font-size: 32px;
            font-weight: 400;
            color: #1d2327;
            margin: 0 0 20px 0;
            text-align: center;
        }

        .invoice-details {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 40px;
            margin-bottom: 30px;
        }

        .detail-group h3 {
            font-size: 14px;
            font-weight: 600;
            color: #1d2327;
            margin: 0 0 10px 0;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .detail-group p {
            margin: 0 0 5px 0;
            color: #3c434a;
            line-height: 1.5;
        }

        .invoice-table {
            width: 100%;
            border-collapse: collapse;
            margin: 30px 0;
            border: 1px solid #c3c4c7;
        }

        .invoice-table th,
        .invoice-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #c3c4c7;
        }

        .invoice-table th {
            background: #f6f7f7;
            font-weight: 600;
            color: #1d2327;
            text-transform: uppercase;
            font-size: 12px;
            letter-spacing: 0.5px;
        }

        .invoice-table td {
            color: #3c434a;
        }

        .invoice-table tr:last-child td {
            border-bottom: none;
        }

        .price-column {
            text-align: right;
            font-weight: 600;
            color: #1d2327;
        }

        .total-section {
            margin-top: 30px;
            text-align: right;
        }

        .total-row {
            display: flex;
            justify-content: flex-end;
            align-items: center;
            margin-bottom: 10px;
            padding: 10px 0;
        }

        .total-row.grand-total {
            border-top: 2px solid #1d2327;
            font-weight: 600;
            font-size: 16px;
            color: #1d2327;
        }

        .total-label {
            margin-right: 50px;
            min-width: 100px;
        }

        .total-amount {
            font-weight: 600;
            min-width: 120px;
        }

        .invoice-footer {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #c3c4c7;
            font-size: 12px;
            color: #646970;
            text-align: center;
        }

        .license-info {
            background: #f0f6fc;
            border: 1px solid #c3e6fc;
            border-radius: 3px;
            padding: 15px;
            margin: 20px 0;
        }

        .license-info h4 {
            margin: 0 0 10px 0;
            color: #0073aa;
            font-size: 14px;
        }

        .license-key {
            font-family: Monaco, Consolas, 'Courier New', monospace;
            background: #fff;
            padding: 8px 12px;
            border: 1px solid #c3c4c7;
            border-radius: 3px;
            font-size: 12px;
            word-break: break-all;
        }

        .status-badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 3px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .status-completed {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        @media print {
            body {
                background: #fff;
                padding: 0;
            }
            
            .invoice-container {
                box-shadow: none;
                border: none;
                border-radius: 0;
            }
        }

        @media (max-width: 768px) {
            body {
                padding: 10px;
            }
            
            .invoice-content {
                padding: 20px;
            }
            
            .invoice-details {
                grid-template-columns: 1fr;
                gap: 20px;
            }
            
            .invoice-header {
                flex-direction: column;
                text-align: center;
                gap: 20px;
            }
            
            .invoice-header .company-info {
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <div class="invoice-container">
        <div class="invoice-header">
            <div class="logo-section">
                <?php if ( ! empty( $invoice_data['logo_url'] ) ) : ?>
                    <img src="<?php echo esc_url( $invoice_data['logo_url'] ); ?>" alt="<?php echo esc_attr( $invoice_data['site_name'] ); ?>" class="logo">
                <?php endif; ?>
            </div>
            <div class="company-info">
                <h1 class="company-name"><?php echo esc_html( $invoice_data['site_name'] ); ?></h1>
                <?php if ( ! empty( $invoice_data['site_description'] ) ) : ?>
                    <p class="company-description"><?php echo esc_html( $invoice_data['site_description'] ); ?></p>
                <?php endif; ?>
                <p class="company-url"><?php echo esc_html( $invoice_data['site_url'] ); ?></p>
            </div>
        </div>

        <div class="invoice-content">

            <div class="invoice-details">
                <div class="detail-group">
                    <h3><?php _e( 'Invoice Details', 'vira-store' ); ?></h3>
                    <p><strong><?php _e( 'Invoice Number:', 'vira-store' ); ?></strong> <?php echo esc_html( $invoice_data['invoice_number'] ); ?></p>
                    <p><strong><?php _e( 'Invoice Date:', 'vira-store' ); ?></strong> <?php echo esc_html( $invoice_date ); ?></p>
                    <p><strong><?php _e( 'Order Number:', 'vira-store' ); ?></strong> <?php echo esc_html( $invoice_data['order_number'] ); ?></p>
                    <p><strong><?php _e( 'Order Date:', 'vira-store' ); ?></strong> <?php echo esc_html( $order_date ); ?></p>
                    <p><strong><?php _e( 'Payment Status:', 'vira-store' ); ?></strong> 
                        <span class="status-badge status-<?php echo esc_attr( strtolower( $invoice_data['payment_status'] ) ); ?>">
                            <?php echo esc_html( ucfirst( $invoice_data['payment_status'] ) ); ?>
                        </span>
                    </p>
                </div>

                <div class="detail-group">
                    <h3><?php _e( 'Customer Information', 'vira-store' ); ?></h3>
                    <p><strong><?php _e( 'Name:', 'vira-store' ); ?></strong> <?php echo esc_html( $invoice_data['customer_name'] ); ?></p>
                    <p><strong><?php _e( 'Email:', 'vira-store' ); ?></strong> <?php echo esc_html( $invoice_data['customer_email'] ); ?></p>
                    <p><strong><?php _e( 'Payment Method:', 'vira-store' ); ?></strong> <?php echo esc_html( ucfirst( str_replace( '_', ' ', $invoice_data['payment_method'] ) ) ); ?></p>
                    <?php if ( ! empty( $invoice_data['product_id'] ) ) : ?>
                        <p><strong><?php _e( 'Product ID:', 'vira-store' ); ?></strong> <code style="background: #f6f7f7; padding: 2px 6px; border: 1px solid #c3c4c7; border-radius: 3px; font-size: 12px;"><?php echo esc_html( $invoice_data['product_id'] ); ?></code></p>
                    <?php endif; ?>
                </div>
            </div>

            <table class="invoice-table">
                <thead>
                    <tr>
                        <th><?php _e( 'Description', 'vira-store' ); ?></th>
                        <th><?php _e( 'Quantity', 'vira-store' ); ?></th>
                        <th class="price-column"><?php _e( 'Amount', 'vira-store' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo esc_html( $invoice_data['product_name'] ); ?></td>
                        <td>1</td>
                        <td class="price-column"><?php echo esc_html( $formatted_price ); ?></td>
                    </tr>
                </tbody>
            </table>

            <div class="total-section">
                <div class="total-row grand-total">
                    <div class="total-label"><?php _e( 'Total:', 'vira-store' ); ?></div>
                    <div class="total-amount"><?php echo esc_html( $formatted_price ); ?></div>
                </div>
            </div>

            <?php if ( ! empty( $invoice_data['license_key'] ) && ! $invoice_data['disable_license_generation'] ) : ?>
                <div class="license-info">
                    <h4><?php _e( 'License Information', 'vira-store' ); ?></h4>
                    <p><strong><?php _e( 'License Key:', 'vira-store' ); ?></strong></p>
                    <div class="license-key"><?php echo esc_html( $invoice_data['license_key'] ); ?></div>
                    <?php if ( ! empty( $invoice_data['product_id'] ) ) : ?>
                        <p style="margin-top: 10px;"><strong><?php _e( 'Product ID:', 'vira-store' ); ?></strong> <code style="background: #fff; padding: 2px 6px; border: 1px solid #c3c4c7; border-radius: 3px;"><?php echo esc_html( $invoice_data['product_id'] ); ?></code></p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="invoice-footer">
                <p><?php echo sprintf( __( 'Thank you for your purchase from %s', 'vira-store' ), esc_html( $invoice_data['site_name'] ) ); ?></p>
                <p><?php echo sprintf( __( 'Generated on %s', 'vira-store' ), date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) ) ); ?></p>
            </div>
        </div>
    </div>
</body>
</html>
