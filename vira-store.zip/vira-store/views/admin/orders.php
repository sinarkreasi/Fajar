<?php
/**
 * Orders admin page template
 *
 * @package Vira_Store
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Handle bulk actions and CSV export
if (isset($_POST['vrstore_bulk_nonce']) && wp_verify_nonce($_POST['vrstore_bulk_nonce'], 'vrstore_bulk_actions')) {
    if (isset($_POST['bulk_action']) && !empty($_POST['order_ids'])) {
        $bulk_action = sanitize_text_field($_POST['bulk_action']);
        $order_ids = array_map('intval', $_POST['order_ids']);
        
        switch ($bulk_action) {
            case 'delete':
                foreach ($order_ids as $order_id) {
                    wp_delete_post($order_id, true);
                }
                $message = sprintf(__('%d orders deleted successfully.', 'vira-store'), count($order_ids));
                break;
                
            case 'mark_completed':
                foreach ($order_ids as $order_id) {
                    update_post_meta($order_id, '_vrstore_order_status', 'completed');
                }
                $message = sprintf(__('%d orders marked as completed.', 'vira-store'), count($order_ids));
                break;
                
            case 'mark_pending':
                foreach ($order_ids as $order_id) {
                    update_post_meta($order_id, '_vrstore_order_status', 'pending');
                }
                $message = sprintf(__('%d orders marked as pending.', 'vira-store'), count($order_ids));
                break;
                
            case 'mark_cancelled':
                foreach ($order_ids as $order_id) {
                    update_post_meta($order_id, '_vrstore_order_status', 'cancelled');
                }
                $message = sprintf(__('%d orders marked as cancelled.', 'vira-store'), count($order_ids));
                break;
        }
        
        if (isset($message)) {
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html($message) . '</p></div>';
        }
    }
}

// Handle CSV export
if (isset($_POST['export_csv']) && wp_verify_nonce($_POST['vrstore_bulk_nonce'], 'vrstore_bulk_actions')) {
    // Set headers for CSV download
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=orders-' . date('Y-m-d') . '.csv');
    header('Pragma: no-cache');
    header('Expires: 0');
    
    // Create file pointer
    $output = fopen('php://output', 'w');
    
    // Add CSV headers
    fputcsv($output, [
        __('Order Number', 'vira-store'),
        __('Customer Name', 'vira-store'),
        __('Customer Email', 'vira-store'),
        __('Type', 'vira-store'),
        __('Amount', 'vira-store'),
        __('Payment Method', 'vira-store'),
        __('Status', 'vira-store'),
        __('Date', 'vira-store')
    ]);
    
    // Add order data
    foreach ($orders['orders'] as $order) {
        // Get admin menu instance to access helper method
        $admin_menu = VRSTORE_Admin_Menu::get_instance();
        $item_info = $admin_menu->get_item_type_and_tooltip($order['product_id'], $order['product_title']);
        
        fputcsv($output, [
            $order['order_number'],
            $order['customer_name'],
            $order['customer_email'],
            $item_info['type'],
            $order['amount'],
            $order['payment_method'],
            $order['status'],
            $order['date']
        ]);
    }
    
    fclose($output);
    exit;
}

$page_title = __('Orders', 'vira-store');

// Get current filter values
$current_status = sanitize_text_field($_GET['status'] ?? '');
$current_search = sanitize_text_field($_GET['search'] ?? '');
$current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;

// Status filter options
$status_options = [
    '' => __('All Statuses', 'vira-store'),
    'pending' => __('Pending', 'vira-store'),
    'completed' => __('Completed', 'vira-store'),
    'failed' => __('Failed', 'vira-store'),
    'cancelled' => __('Cancelled', 'vira-store')
];
?>

<div class="wrap vrstore-admin-page">
    <div class="vrstore-page-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <h1><?php esc_html_e('Orders', 'vira-store'); ?></h1>
        <button type="button" id="export-orders-csv" class="button button-secondary">
            <span class="dashicons dashicons-download" style="vertical-align: middle; margin-right: 5px;"></span>
            <?php esc_html_e('Export to CSV', 'vira-store'); ?>
        </button>
    </div>
    
    <?php if (!empty($orders['orders'])): ?>
        <!-- Filters and Actions -->
        <div class="tablenav top">
            <div class="alignleft actions">
                <form method="get" action="" style="display: inline-block;">
                    <input type="hidden" name="page" value="vrstore-orders">
                    <input type="hidden" name="search" value="<?php echo esc_attr($current_search); ?>">
                    
                    <select name="status" id="status-filter">
                        <?php foreach ($status_options as $value => $label): ?>
                            <option value="<?php echo esc_attr($value); ?>" <?php selected($current_status, $value); ?>>
                                <?php echo esc_html($label); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    
                    <input type="submit" class="button" value="<?php esc_attr_e('Filter', 'vira-store'); ?>">
                </form>
                
                <!-- Bulk Actions - positioned right next to status filter -->
                <form method="post" action="" id="vrstore-bulk-actions-form" style="display: inline-block; margin-left: 10px;">
                    <?php wp_nonce_field('vrstore_bulk_actions', 'vrstore_bulk_nonce'); ?>
                    <select name="bulk_action" id="bulk-action-selector-top">
                        <option value=""><?php _e('Bulk Actions', 'vira-store'); ?></option>
                        <option value="delete"><?php _e('Delete', 'vira-store'); ?></option>
                        <option value="mark_completed"><?php _e('Mark as Completed', 'vira-store'); ?></option>
                        <option value="mark_pending"><?php _e('Mark as Pending', 'vira-store'); ?></option>
                        <option value="mark_cancelled"><?php _e('Mark as Cancelled', 'vira-store'); ?></option>
                    </select>
                    <input type="submit" class="button action" value="<?php esc_attr_e('Apply', 'vira-store'); ?>" onclick="return vrstore_confirm_bulk_action();">
                </form>
            </div>
            
            <div class="alignright actions">
                <form method="get" action="">
                    <input type="hidden" name="page" value="vrstore-orders">
                    <?php if (!empty($current_status)): ?>
                        <input type="hidden" name="status" value="<?php echo esc_attr($current_status); ?>">
                    <?php endif; ?>
                    
                    <label for="order-search" class="screen-reader-text"><?php _e('Search orders', 'vira-store'); ?></label>
                    <input type="search" id="order-search" name="search" value="<?php echo esc_attr($current_search); ?>" placeholder="<?php esc_attr_e('Search orders...', 'vira-store'); ?>">
                    <input type="submit" class="button" value="<?php esc_attr_e('Search', 'vira-store'); ?>">
                </form>
            </div>
        </div>

        <!-- Statistics Cards -->
        <div class="vrstore-stats-cards" style="margin: 20px 0;">
            <div class="vrstore-stat-card">
                <h3><?php _e('Total Orders', 'vira-store'); ?></h3>
                <div class="stat-number"><?php echo esc_html($orders['total'] ?? 0); ?></div>
            </div>
            <div class="vrstore-stat-card">
                <h3><?php _e('Pending Orders', 'vira-store'); ?></h3>
                <div class="stat-number"><?php echo esc_html($orders['pending'] ?? 0); ?></div>
            </div>
            <div class="vrstore-stat-card">
                <h3><?php _e('Completed Orders', 'vira-store'); ?></h3>
                <div class="stat-number"><?php echo esc_html($orders['completed'] ?? 0); ?></div>
            </div>
            <div class="vrstore-stat-card">
                <h3><?php _e('Failed Orders', 'vira-store'); ?></h3>
                <div class="stat-number"><?php echo esc_html($orders['failed'] ?? 0); ?></div>
            </div>
        </div>

        <!-- Orders Table -->
        <form method="post" action="" id="vrstore-orders-table-form">
            <?php wp_nonce_field('vrstore_bulk_actions', 'vrstore_bulk_nonce'); ?>
            <input type="hidden" name="bulk_action" id="bulk-action-hidden">
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <td class="manage-column column-cb check-column">
                            <label class="screen-reader-text" for="cb-select-all-1"><?php _e('Select All', 'vira-store'); ?></label>
                            <input id="cb-select-all-1" type="checkbox">
                        </td>
                        <th scope="col" class="manage-column column-order"><?php _e('Order', 'vira-store'); ?></th>
                        <th scope="col" class="manage-column column-customer"><?php _e('Customer', 'vira-store'); ?></th>
                        <th scope="col" class="manage-column column-product"><?php _e('Type', 'vira-store'); ?></th>
                        <th scope="col" class="manage-column column-amount"><?php _e('Amount', 'vira-store'); ?></th>
                        <th scope="col" class="manage-column column-payment"><?php _e('Payment', 'vira-store'); ?></th>
                        <th scope="col" class="manage-column column-status"><?php _e('Status', 'vira-store'); ?></th>
                        <th scope="col" class="manage-column column-date"><?php _e('Date', 'vira-store'); ?></th>
                        <th scope="col" class="manage-column column-invoice"><?php _e('Invoice', 'vira-store'); ?></th>
                        <th scope="col" class="manage-column column-actions"><?php _e('Actions', 'vira-store'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders['orders'] as $order): ?>
                        <tr>
                            <th scope="row" class="check-column">
                                <label class="screen-reader-text" for="cb-select-<?php echo esc_attr($order['id']); ?>">
                                    <?php printf(__('Select order %s', 'vira-store'), $order['order_number']); ?>
                                </label>
                                <input id="cb-select-<?php echo esc_attr($order['id']); ?>" type="checkbox" name="order_ids[]" value="<?php echo esc_attr($order['id']); ?>">
                            </th>
                        <td class="column-order">
                            <strong>#<?php echo esc_html($order['order_number']); ?></strong>
                        </td>
                        <td class="column-customer">
                            <strong><?php echo esc_html($order['customer_name'] ?: $order['customer_email']); ?></strong>
                            <br><small><?php echo esc_html($order['customer_email']); ?></small>
                        </td>
                        <td class="column-product">
                            <?php 
                            // Get admin menu instance to access helper method
                            $admin_menu = VRSTORE_Admin_Menu::get_instance();
                            $item_info = $admin_menu->get_item_type_and_tooltip($order['product_id'], $order['product_name']);
                            ?>
                            <div class="vrstore-tooltip">
                                <span class="vrstore-item-type">
                                    <?php echo esc_html($item_info['type']); ?>
                                </span>
                                <span class="vrstore-tooltiptext"><?php echo esc_html($item_info['tooltip']); ?></span>
                            </div>
                        </td>
                        <td class="column-amount">
                            <?php 
                            // Format price with Extended Support awareness
                            if (class_exists('VRSTORE_Settings')) {
                                $settings_instance = VRSTORE_Settings::get_instance();
                                
                                // Check if this is an Extended Support order
                                $is_extended_support = (is_string($order['product_id']) && strpos($order['product_id'], 'extended_support_') === 0) ||
                                                      (strpos($order['product_name'], 'Extended Support') !== false);
                                
                                if ($is_extended_support) {
                                    // For Extended Support orders, use the Extended Support aware formatting
                                    $formatted_price = $settings_instance->format_admin_extended_support_price($order['product_price'], false);
                                } else {
                                    // For regular orders, use the original currency or fallback to global
                                    $global_currency = $settings_instance->get_setting('currency', 'USD');
                                    $order_currency = !empty($order['currency']) ? $order['currency'] : $global_currency;
                                    if (class_exists('VRSTORE_Product')) {
                                        $product_instance = VRSTORE_Product::get_instance();
                                        $formatted_price = $product_instance->format_price($order['product_price'], $order_currency);
                                    } else {
                                        $formatted_price = $settings_instance->format_admin_extended_support_price($order['product_price'], false);
                                    }
                                }
                                echo '<strong>' . esc_html($formatted_price) . '</strong>';
                            } else {
                                // Fallback if classes are not available
                                $settings = get_option('vrstore_settings', []);
                                
                                // Try to use order currency first
                                if (!empty($order['currency'])) {
                                    // Use order-specific currency if available
                                    $currency_symbol = $order['currency']; // Simple fallback
                                    $currency_position = 'left'; // Default position
                                } else {
                                    // Use global settings
                                    $currency_symbol = $settings['currency_symbol'] ?? '$';
                                    $currency_position = $settings['currency_position'] ?? 'left';
                                }
                                
                                $formatted_price = number_format((float) $order['product_price'], 2);
                                if ($currency_position === 'left') {
                                    echo '<strong>' . esc_html($currency_symbol . $formatted_price) . '</strong>';
                                } else {
                                    echo '<strong>' . esc_html($formatted_price . $currency_symbol) . '</strong>';
                                }
                            }
                            ?>
                        </td>
                        <td class="column-payment">
                            <?php
                            // Convert payment method ID to display name
                            $payment_methods = [
                                'tripay' => __('TriPay', 'vira-store'),
                                'manual' => __('Transfer Bank', 'vira-store')
                            ];
                            $payment_method_name = $payment_methods[$order['payment_method']] ?? ucfirst($order['payment_method']) ?: __('N/A', 'vira-store');
                            ?>
                            <span class="payment-method"><?php echo esc_html($payment_method_name); ?></span>
                            <br><span class="payment-status payment-status-<?php echo esc_attr($order['payment_status']); ?>">
                                <?php echo esc_html(ucfirst($order['payment_status'])); ?>
                            </span>
                        </td>
                        <td class="column-status">
                            <span class="order-status order-status-<?php echo esc_attr($order['order_status']); ?>">
                                <?php echo esc_html(ucfirst($order['order_status'])); ?>
                            </span>
                        </td>
                        <td class="column-date">
                            <?php echo esc_html(mysql2date('M j, Y g:i A', $order['created_at'])); ?>
                        </td>
                        <td class="column-invoice">
                            <?php 
                            // Only show invoice actions for completed orders
                            if (strtolower($order['payment_status']) === 'completed' && strtolower($order['order_status']) === 'completed'):
                                // Check if Invoice class is available
                                if (class_exists('VRSTORE_Invoice')):
                                    $invoice_instance = VRSTORE_Invoice::get_instance();
                                    $view_url = $invoice_instance->get_invoice_url($order['id'], 'view');
                                    $download_url = $invoice_instance->get_invoice_url($order['id'], 'download');
                            ?>
                                <div class="vrstore-invoice-actions">
                                    <a href="<?php echo esc_url($view_url); ?>" class="vrstore-btn vrstore-btn-sm vrstore-btn-secondary" target="_blank" title="<?php esc_attr_e('View Invoice', 'vira-store'); ?>">
                                        <span class="dashicons dashicons-visibility"></span>
                                    </a>
                                    <a href="<?php echo esc_url($download_url); ?>" class="vrstore-btn vrstore-btn-sm vrstore-btn-primary" title="<?php esc_attr_e('Download Invoice', 'vira-store'); ?>">
                                        <span class="dashicons dashicons-download"></span>
                                    </a>
                                </div>
                            <?php 
                                else:
                            ?>
                                <span class="vrstore-na"><?php _e('N/A', 'vira-store'); ?></span>
                            <?php 
                                endif;
                            else:
                            ?>
                                <span class="vrstore-pending"><?php _e('Pending', 'vira-store'); ?></span>
                            <?php endif; ?>
                        </td>
                        <td class="column-actions">
                            <div class="row-actions">
                                <span class="view">
                                    <a href="#" class="vrstore-action-link view-order" data-order-id="<?php echo esc_attr($order['id']); ?>">
                                        <?php _e('View', 'vira-store'); ?>
                                    </a>
                                </span>
                                | <span class="status">
                                    <a href="#" class="vrstore-action-link change-order-status" 
                                       data-order-id="<?php echo esc_attr($order['id']); ?>"
                                       data-current-status="<?php echo esc_attr($order['order_status']); ?>"
                                       data-payment-status="<?php echo esc_attr($order['payment_status']); ?>">
                                        <?php _e('Change Status', 'vira-store'); ?>
                                    </a>
                                </span>
                                <?php if (!empty($order['license_key'])): ?>
                                    | <span class="license">
                                        <a href="<?php echo admin_url('admin.php?page=vrstore-licenses&search=' . urlencode($order['license_key'])); ?>" class="vrstore-action-link">
                                            <?php _e('View License', 'vira-store'); ?>
                                        </a>
                                    </span>
                                <?php endif; ?>
                                | <span class="delete">
                                    <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=vrstore-orders&action=delete&order_id=' . $order['id']), 'vrstore_order_action'); ?>" 
                                       class="vrstore-action-link vrstore-delete-order"
                                       onclick="return confirm('<?php esc_attr_e('Are you sure you want to delete this order? This action cannot be undone!', 'vira-store'); ?>')">
                                        <?php _e('Delete', 'vira-store'); ?>
                                    </a>
                                </span>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </form>

        <!-- Pagination -->
        <?php if ($orders['total'] > 20): ?>
            <div class="tablenav bottom">
                <div class="tablenav-pages">
                    <?php
                    $total_pages = ceil($orders['total'] / 20);
                    $pagination_args = [
                        'base' => add_query_arg('paged', '%#%'),
                        'format' => '',
                        'prev_text' => __('&laquo; Previous', 'vira-store'),
                        'next_text' => __('Next &raquo;', 'vira-store'),
                        'current' => $current_page,
                        'total' => $total_pages
                    ];
                    echo paginate_links($pagination_args);
                    ?>
                </div>
            </div>
        <?php endif; ?>

    <?php else: ?>
        <!-- No orders found -->
        <div class="vrstore-empty-state">
            <div class="vrstore-empty-icon">
                <span class="dashicons dashicons-cart"></span>
            </div>
            <h2><?php _e('No orders found', 'vira-store'); ?></h2>
            <p><?php _e('Orders will appear here once customers start purchasing your products.', 'vira-store'); ?></p>
        </div>
    <?php endif; ?>
</div>
