<?php
/**
 * Affiliate Settings Admin Page Template
 *
 * @package Vira_Store
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap">
    <h1 class="wp-heading-inline"><?php _e('Affiliate Settings', 'vira-store'); ?></h1>
    
    <hr class="wp-header-end">

    <!-- Tab Navigation -->
    <nav class="nav-tab-wrapper">
        <a href="<?php echo admin_url('admin.php?page=vrstore-affiliates&tab=affiliates'); ?>" 
           class="nav-tab <?php echo ($current_tab === 'affiliates') ? 'nav-tab-active' : ''; ?>">
            <?php _e('Affiliates', 'vira-store'); ?>
        </a>
        <a href="<?php echo admin_url('admin.php?page=vrstore-affiliates&tab=settings'); ?>" 
           class="nav-tab <?php echo ($current_tab === 'settings') ? 'nav-tab-active' : ''; ?>">
            <?php _e('Settings', 'vira-store'); ?>
        </a>
    </nav>

    <div class="affiliate-settings-container">
        <form method="post" action="<?php echo admin_url('admin.php?page=vrstore-affiliates&tab=settings'); ?>">
            <?php wp_nonce_field('vrstore_affiliate_settings'); ?>
            <input type="hidden" name="action" value="save_affiliate_settings">
            
            <div class="settings-sections">
                <!-- General Settings -->
                <div class="settings-section">
                    <h2><?php _e('General Settings', 'vira-store'); ?></h2>
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="default_commission_rate"><?php _e('Default Commission Rate (%)', 'vira-store'); ?></label>
                            </th>
                            <td>
                                <input type="number" 
                                       id="default_commission_rate" 
                                       name="default_commission_rate" 
                                       value="<?php echo esc_attr($settings['default_commission_rate']); ?>" 
                                       min="0" 
                                       max="100" 
                                       step="0.01" 
                                       class="small-text">
                                <p class="description"><?php _e('Default commission rate for new affiliates (0-100%).', 'vira-store'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="auto_approve_affiliates"><?php _e('Auto-Approve Affiliates', 'vira-store'); ?></label>
                            </th>
                            <td>
                                <input type="checkbox" 
                                       id="auto_approve_affiliates" 
                                       name="auto_approve_affiliates" 
                                       value="1" 
                                       <?php checked($settings['auto_approve_affiliates'], '1'); ?>>
                                <label for="auto_approve_affiliates"><?php _e('Automatically approve new affiliate applications', 'vira-store'); ?></label>
                                <p class="description"><?php _e('When enabled, new affiliates will be automatically approved without manual review.', 'vira-store'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="enable_affiliate_registration"><?php _e('Enable Affiliate Registration', 'vira-store'); ?></label>
                            </th>
                            <td>
                                <input type="checkbox" 
                                       id="enable_affiliate_registration" 
                                       name="enable_affiliate_registration" 
                                       value="1" 
                                       <?php checked($settings['enable_affiliate_registration'], '1'); ?>>
                                <label for="enable_affiliate_registration"><?php _e('Allow new affiliate registrations', 'vira-store'); ?></label>
                                <p class="description"><?php _e('Disable this to stop accepting new affiliate applications.', 'vira-store'); ?></p>
                            </td>
                        </tr>
                        <tr id="join_affiliate_requirement_row" style="<?php echo ($settings['enable_affiliate_registration'] === '1') ? '' : 'display: none;'; ?>">
                            <th scope="row">
                                <label for="join_affiliate_requirement"><?php _e('Join Affiliate Requirement', 'vira-store'); ?></label>
                            </th>
                            <td>
                                <select id="join_affiliate_requirement" name="join_affiliate_requirement">
                                    <option value="free" <?php selected($settings['join_affiliate_requirement'], 'free'); ?>>
                                        <?php _e('Free for anyone', 'vira-store'); ?>
                                    </option>
                                    <option value="purchase_required" <?php selected($settings['join_affiliate_requirement'], 'purchase_required'); ?>>
                                        <?php _e('Required purchase', 'vira-store'); ?>
                                    </option>
                                </select>
                                <p class="description"><?php _e('Choose whether affiliate registration is free for anyone or requires a purchase first.', 'vira-store'); ?></p>
                            </td>
                        </tr>
                        <tr id="required_products_row" style="<?php echo (($settings['enable_affiliate_registration'] === '1') && ($settings['join_affiliate_requirement'] === 'purchase_required')) ? '' : 'display: none;'; ?>">
                            <th scope="row">
                                <label for="required_products"><?php _e('Required Products/Courses', 'vira-store'); ?></label>
                            </th>
                            <td>
                                <?php
                                $required_products = $settings['required_products'] ?? array();
                                if (!is_array($required_products)) {
                                    $required_products = array();
                                }
                                
                                $product_commissions = $settings['product_commissions'] ?? array();
                                if (!is_array($product_commissions)) {
                                    $product_commissions = array();
                                }
                                
                                // Get all published products
                                $products = get_posts(array(
                                    'post_type' => 'vrstore_product',
                                    'post_status' => 'publish',
                                    'numberposts' => -1,
                                    'orderby' => 'title',
                                    'order' => 'ASC'
                                ));
                                
                                // Get all published courses
                                $courses = get_posts(array(
                                    'post_type' => 'vrstore_course',
                                    'post_status' => 'publish', 
                                    'numberposts' => -1,
                                    'orderby' => 'title',
                                    'order' => 'ASC'
                                ));
                                
                                $all_items = array_merge($products, $courses);
                                $item_count = count($all_items);
                                $max_height = $item_count > 5 ? '200px' : 'auto';
                                ?>
                                <div class="required-products-selection">
                                    <div style="max-height: <?php echo $max_height; ?>; overflow-y: <?php echo $item_count > 5 ? 'auto' : 'visible'; ?>; border: 1px solid #ddd; padding: 10px; background: #f9f9f9;">
                                        <label style="display: block; margin-bottom: 10px; font-weight: bold; position: sticky; top: 0; background: #f9f9f9; z-index: 10;">
                                            <input type="checkbox" id="select_all_required" style="margin-right: 5px;">
                                            <?php _e('Select All', 'vira-store'); ?>
                                        </label>
                                        
                                        <div class="scrollable-content">
                                            <?php if (!empty($products)): ?>
                                                <h4 style="margin: 10px 0 5px 0; color: #0073aa;"><?php _e('Products', 'vira-store'); ?></h4>
                                                <?php foreach ($products as $product): ?>
                                                    <div style="display: flex; align-items: center; margin-bottom: 8px; padding: 5px; border: 1px solid #e1e1e1; background: #fff; border-radius: 3px;">
                                                        <label style="display: flex; align-items: center; flex: 1; margin: 0;">
                                                            <input type="checkbox" 
                                                                   name="required_products[]" 
                                                                   value="<?php echo esc_attr($product->ID); ?>"
                                                                   class="required-product-checkbox"
                                                                   style="margin-right: 8px;"
                                                                   <?php checked(in_array($product->ID, $required_products)); ?>>
                                                            <span style="flex: 1;"><?php echo esc_html($product->post_title); ?></span>
                                                        </label>
                                                        <div style="margin-left: 10px; display: flex; align-items: center;">
                                                            <label style="margin-right: 5px; font-size: 12px; color: #666;"><?php _e('Commission:', 'vira-store'); ?></label>
                                                            <input type="number" 
                                                                   name="product_commissions[<?php echo esc_attr($product->ID); ?>]" 
                                                                   value="<?php echo esc_attr($product_commissions[$product->ID] ?? $settings['default_commission_rate'] ?? '10'); ?>"
                                                                   min="0" 
                                                                   max="100" 
                                                                   step="0.01" 
                                                                   style="width: 60px; font-size: 12px;"
                                                                   placeholder="<?php echo esc_attr($settings['default_commission_rate'] ?? '10'); ?>">
                                                            <span style="margin-left: 3px; font-size: 12px; color: #666;">%</span>
                                                        </div>
                                                    </div>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                            
                                            <?php if (!empty($courses)): ?>
                                                <h4 style="margin: 10px 0 5px 0; color: #0073aa;"><?php _e('Courses', 'vira-store'); ?></h4>
                                                <?php foreach ($courses as $course): ?>
                                                    <div style="display: flex; align-items: center; margin-bottom: 8px; padding: 5px; border: 1px solid #e1e1e1; background: #fff; border-radius: 3px;">
                                                        <label style="display: flex; align-items: center; flex: 1; margin: 0;">
                                                            <input type="checkbox" 
                                                                   name="required_products[]" 
                                                                   value="<?php echo esc_attr($course->ID); ?>"
                                                                   class="required-product-checkbox"
                                                                   style="margin-right: 8px;"
                                                                   <?php checked(in_array($course->ID, $required_products)); ?>>
                                                            <span style="flex: 1;"><?php echo esc_html($course->post_title); ?></span>
                                                        </label>
                                                        <div style="margin-left: 10px; display: flex; align-items: center;">
                                                            <label style="margin-right: 5px; font-size: 12px; color: #666;"><?php _e('Commission:', 'vira-store'); ?></label>
                                                            <input type="number" 
                                                                   name="product_commissions[<?php echo esc_attr($course->ID); ?>]" 
                                                                   value="<?php echo esc_attr($product_commissions[$course->ID] ?? $settings['default_commission_rate'] ?? '10'); ?>"
                                                                   min="0" 
                                                                   max="100" 
                                                                   step="0.01" 
                                                                   style="width: 60px; font-size: 12px;"
                                                                   placeholder="<?php echo esc_attr($settings['default_commission_rate'] ?? '10'); ?>">
                                                            <span style="margin-left: 3px; font-size: 12px; color: #666;">%</span>
                                                        </div>
                                                    </div>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                            
                                            <?php if (empty($products) && empty($courses)): ?>
                                                <p><em><?php _e('No products or courses found. Create some products/courses first.', 'vira-store'); ?></em></p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <p class="description">
                                    <?php _e('Select specific products/courses that must be purchased to qualify for affiliate registration. Leave empty to allow any completed purchase.', 'vira-store'); ?><br>
                                    <strong><?php _e('Note:', 'vira-store'); ?></strong> <?php _e('Users must have purchased at least ONE of the selected items. You can set different commission rates for affiliates who purchase specific products.', 'vira-store'); ?>
                                </p>
                                
                                <script type="text/javascript">
                                jQuery(document).ready(function($) {
                                    // Toggle required products row based on join requirement
                                    function toggleRequiredProducts() {
                                        var requirement = $('#join_affiliate_requirement').val();
                                        var registrationEnabled = $('#enable_affiliate_registration').is(':checked');
                                        if (registrationEnabled && requirement === 'purchase_required') {
                                            $('#required_products_row').show();
                                        } else {
                                            $('#required_products_row').hide();
                                        }
                                    }
                                    
                                    $('#join_affiliate_requirement, #enable_affiliate_registration').change(toggleRequiredProducts);
                                    
                                    // Select all functionality with improved handling
                                    $('#select_all_required').change(function() {
                                        var isChecked = $(this).is(':checked');
                                        $('.required-product-checkbox').prop('checked', isChecked);
                                        
                                        // Also update the commission rates based on default when selecting all
                                        if (isChecked) {
                                            var defaultCommission = $('#default_commission_rate').val() || '10';
                                            $('.required-product-checkbox').each(function() {
                                                var productId = $(this).val();
                                                var commissionInput = $('input[name="product_commissions[' + productId + ']"]');
                                                if (commissionInput.length && !commissionInput.val()) {
                                                    commissionInput.val(defaultCommission);
                                                }
                                            });
                                        }
                                    });
                                    
                                    // Update select all when individual checkboxes change
                                    $('.required-product-checkbox').change(function() {
                                        var total = $('.required-product-checkbox').length;
                                        var checked = $('.required-product-checkbox:checked').length;
                                        $('#select_all_required').prop('checked', total === checked);
                                        $('#select_all_required').prop('indeterminate', checked > 0 && checked < total);
                                    });
                                    
                                    // Initialize indeterminate state on page load
                                    var total = $('.required-product-checkbox').length;
                                    var checked = $('.required-product-checkbox:checked').length;
                                    if (checked > 0 && checked < total) {
                                        $('#select_all_required').prop('indeterminate', true);
                                    }
                                    
                                    // Auto-populate commission rate when product is selected
                                    $('.required-product-checkbox').change(function() {
                                        var productId = $(this).val();
                                        var commissionInput = $('input[name="product_commissions[' + productId + ']"]');
                                        var defaultCommission = $('#default_commission_rate').val() || '10';
                                        
                                        if ($(this).is(':checked') && commissionInput.length && !commissionInput.val()) {
                                            commissionInput.val(defaultCommission);
                                        }
                                    });
                                });
                                </script>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="cookie_duration"><?php _e('Cookie Duration (Days)', 'vira-store'); ?></label>
                            </th>
                            <td>
                                <input type="number" 
                                       id="cookie_duration" 
                                       name="cookie_duration" 
                                       value="<?php echo esc_attr($settings['cookie_duration']); ?>" 
                                       min="1" 
                                       max="365" 
                                       class="small-text">
                                <p class="description"><?php _e('How long affiliate referral cookies should last (1-365 days).', 'vira-store'); ?></p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Payout Settings -->
                <div class="settings-section">
                    <h2><?php _e('Payout Settings', 'vira-store'); ?></h2>
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="minimum_payout_amount"><?php _e('Minimum Payout Amount', 'vira-store'); ?></label>
                            </th>
                            <td>
                                <input type="number" 
                                       id="minimum_payout_amount" 
                                       name="minimum_payout_amount" 
                                       value="<?php echo esc_attr($settings['minimum_payout_amount']); ?>" 
                                       min="0" 
                                       step="0.01" 
                                       class="small-text">
                                <p class="description"><?php _e('Minimum amount required before affiliates can request a payout.', 'vira-store'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label><?php _e('Payout Methods', 'vira-store'); ?></label>
                            </th>
                            <td>
                                <fieldset>
                                    <legend class="screen-reader-text"><?php _e('Payout Methods', 'vira-store'); ?></legend>
                                    <label>
                                        <input type="checkbox" 
                                               name="payout_methods[]" 
                                               value="paypal" 
                                               <?php checked(in_array('paypal', $settings['payout_methods'])); ?>>
                                        <?php _e('PayPal', 'vira-store'); ?>
                                    </label><br>
                                    <label>
                                        <input type="checkbox" 
                                               name="payout_methods[]" 
                                               value="bank_transfer" 
                                               <?php checked(in_array('bank_transfer', $settings['payout_methods'])); ?>>
                                        <?php _e('Bank Transfer', 'vira-store'); ?>
                                    </label><br>
                                    <label>
                                        <input type="checkbox" 
                                               name="payout_methods[]" 
                                               value="check" 
                                               <?php checked(in_array('check', $settings['payout_methods'])); ?>>
                                        <?php _e('Check', 'vira-store'); ?>
                                    </label>
                                </fieldset>
                                <p class="description"><?php _e('Select available payout methods for affiliates.', 'vira-store'); ?></p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Terms & Conditions -->
                <div class="settings-section">
                    <h2><?php _e('Terms & Conditions', 'vira-store'); ?></h2>
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="affiliate_terms_page"><?php _e('Affiliate Terms Page', 'vira-store'); ?></label>
                            </th>
                            <td>
                                <?php
                                wp_dropdown_pages([
                                    'name' => 'affiliate_terms_page',
                                    'id' => 'affiliate_terms_page',
                                    'selected' => $settings['affiliate_terms_page'],
                                    'show_option_none' => __('Select a page', 'vira-store'),
                                    'option_none_value' => '',
                                ]);
                                ?>
                                <p class="description"><?php _e('Select the page containing affiliate terms and conditions.', 'vira-store'); ?></p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Short URL Settings -->
                <div class="settings-section">
                    <h2><?php _e('Short URL Settings', 'vira-store'); ?></h2>
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="use_short_urls"><?php _e('Enable Short URLs', 'vira-store'); ?></label>
                            </th>
                            <td>
                                <input type="checkbox" 
                                       id="use_short_urls" 
                                       name="use_short_urls" 
                                       value="1" 
                                       <?php checked($settings['use_short_urls'] ?? '0', '1'); ?>>
                                <label for="use_short_urls"><?php _e('Enable short URLs for affiliate links', 'vira-store'); ?></label>
                                <p class="description"><?php _e('When enabled, affiliates will get both regular and short URLs', 'vira-store'); ?></p>
                            </td>
                        </tr>
                        <tr id="short_url_provider_row" style="<?php echo ($settings['use_short_urls'] ?? '0') === '1' ? '' : 'display: none;'; ?>">
                            <th scope="row">
                                <label for="short_url_provider"><?php _e('Short URL Provider', 'vira-store'); ?></label>
                            </th>
                            <td>
                                <select id="short_url_provider" name="short_url_provider">
                                    <option value="dns" <?php selected($settings['short_url_provider'] ?? 'dns', 'dns'); ?>>
                                        <?php _e('DNS (Custom Domain)', 'vira-store'); ?>
                                    </option>
                                    <option value="rebrandly" <?php selected($settings['short_url_provider'] ?? 'dns', 'rebrandly'); ?>>
                                        <?php _e('Rebrandly', 'vira-store'); ?>
                                    </option>
                                    <option value="bitly" <?php selected($settings['short_url_provider'] ?? 'dns', 'bitly'); ?>>
                                        <?php _e('Bit.ly', 'vira-store'); ?>
                                    </option>
                                </select>
                                <p class="description"><?php _e('Choose your preferred short URL service provider.', 'vira-store'); ?></p>
                            </td>
                        </tr>
                        
                        <!-- DNS Provider Settings -->
                        <tr id="dns_settings" class="provider-settings" style="<?php echo (($settings['use_short_urls'] ?? '0') === '1' && ($settings['short_url_provider'] ?? 'dns') === 'dns') ? '' : 'display: none;'; ?>">
                            <th scope="row">
                                <label for="short_domain"><?php _e('Short Domain', 'vira-store'); ?></label>
                            </th>
                            <td>
                                <input type="text" 
                                       id="short_domain" 
                                       name="short_domain" 
                                       value="<?php echo esc_attr($settings['short_domain'] ?? ''); ?>" 
                                       class="regular-text" 
                                       placeholder="dmn.to">
                                <p class="description">
                                    <?php _e('Enter your short domain (without http://) for affiliate short URLs. Example: dmn.to', 'vira-store'); ?><br>
                                    <strong><?php _e('Note:', 'vira-store'); ?></strong> <?php _e('You need to configure DNS and server settings to point this domain to your WordPress installation.', 'vira-store'); ?>
                                </p>
                            </td>
                        </tr>
                        
                        <!-- Rebrandly Provider Settings -->
                        <tr id="rebrandly_settings" class="provider-settings" style="<?php echo (($settings['use_short_urls'] ?? '0') === '1' && ($settings['short_url_provider'] ?? 'dns') === 'rebrandly') ? '' : 'display: none;'; ?>">
                            <th scope="row">
                                <label for="rebrandly_api_key"><?php _e('Rebrandly API Key', 'vira-store'); ?></label>
                            </th>
                            <td>
                                <input type="password" 
                                       id="rebrandly_api_key" 
                                       name="rebrandly_api_key" 
                                       value="<?php echo esc_attr($settings['rebrandly_api_key'] ?? ''); ?>" 
                                       class="regular-text">
                                <p class="description">
                                    <?php _e('Enter your Rebrandly API key. You can get this from your Rebrandly dashboard.', 'vira-store'); ?><br>
                                    <a href="https://app.rebrandly.com/account/api-keys" target="_blank"><?php _e('Get your API key here', 'vira-store'); ?></a>
                                </p>
                            </td>
                        </tr>
                        <tr id="rebrandly_domain_settings" class="provider-settings" style="<?php echo (($settings['use_short_urls'] ?? '0') === '1' && ($settings['short_url_provider'] ?? 'dns') === 'rebrandly') ? '' : 'display: none;'; ?>">
                            <th scope="row">
                                <label for="rebrandly_domain"><?php _e('Rebrandly Domain', 'vira-store'); ?></label>
                            </th>
                            <td>
                                <input type="text" 
                                       id="rebrandly_domain" 
                                       name="rebrandly_domain" 
                                       value="<?php echo esc_attr($settings['rebrandly_domain'] ?? ''); ?>" 
                                       class="regular-text" 
                                       placeholder="rebrand.ly">
                                <p class="description"><?php _e('Enter your Rebrandly domain (optional). Leave empty to use the default rebrand.ly domain.', 'vira-store'); ?></p>
                            </td>
                        </tr>
                        
                        <!-- Bit.ly Provider Settings -->
                        <tr id="bitly_settings" class="provider-settings" style="<?php echo (($settings['use_short_urls'] ?? '0') === '1' && ($settings['short_url_provider'] ?? 'dns') === 'bitly') ? '' : 'display: none;'; ?>">
                            <th scope="row">
                                <label for="bitly_access_token"><?php _e('Bit.ly Access Token', 'vira-store'); ?></label>
                            </th>
                            <td>
                                <input type="password" 
                                       id="bitly_access_token" 
                                       name="bitly_access_token" 
                                       value="<?php echo esc_attr($settings['bitly_access_token'] ?? ''); ?>" 
                                       class="regular-text">
                                <p class="description">
                                    <?php _e('Enter your Bit.ly access token. You can generate this from your Bit.ly settings.', 'vira-store'); ?><br>
                                    <a href="https://app.bitly.com/settings/api/" target="_blank"><?php _e('Get your access token here', 'vira-store'); ?></a>
                                </p>
                            </td>
                        </tr>
                        <tr id="bitly_domain_settings" class="provider-settings" style="<?php echo (($settings['use_short_urls'] ?? '0') === '1' && ($settings['short_url_provider'] ?? 'dns') === 'bitly') ? '' : 'display: none;'; ?>">
                            <th scope="row">
                                <label for="bitly_domain"><?php _e('Bit.ly Custom Domain', 'vira-store'); ?></label>
                            </th>
                            <td>
                                <input type="text" 
                                       id="bitly_domain" 
                                       name="bitly_domain" 
                                       value="<?php echo esc_attr($settings['bitly_domain'] ?? ''); ?>" 
                                       class="regular-text" 
                                       placeholder="bit.ly">
                                <p class="description"><?php _e('Enter your Bit.ly custom domain (optional). Leave empty to use the default bit.ly domain.', 'vira-store'); ?></p>
                            </td>
                        </tr>
                        <tr id="bitly_group_guid_settings" class="provider-settings" style="<?php echo (($settings['use_short_urls'] ?? '0') === '1' && ($settings['short_url_provider'] ?? 'dns') === 'bitly') ? '' : 'display: none;'; ?>">
                            <th scope="row">
                                <label for="bitly_group_guid"><?php _e('Bit.ly Group GUID', 'vira-store'); ?></label>
                            </th>
                            <td>
                                <input type="text" 
                                       id="bitly_group_guid" 
                                       name="bitly_group_guid" 
                                       value="<?php echo esc_attr($settings['bitly_group_guid'] ?? ''); ?>" 
                                       class="regular-text" 
                                       placeholder="Auto-detected">
                                <p class="description"><?php _e('Your Bit.ly group GUID (optional). Leave empty to auto-detect from your account.', 'vira-store'); ?></p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Notification Settings -->
                <div class="settings-section">
                    <h2><?php _e('Notification Settings', 'vira-store'); ?></h2>
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="email_notifications"><?php _e('Email Notifications', 'vira-store'); ?></label>
                            </th>
                            <td>
                                <input type="checkbox" 
                                       id="email_notifications" 
                                       name="email_notifications" 
                                       value="1" 
                                       <?php checked($settings['email_notifications'], '1'); ?>>
                                <label for="email_notifications"><?php _e('Send email notifications to affiliates', 'vira-store'); ?></label>
                                <p class="description"><?php _e('Enable email notifications for affiliate status changes, commission updates, etc.', 'vira-store'); ?></p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Program Benefits Settings -->
                <div class="settings-section">
                    <h2><?php _e('Program Benefits', 'vira-store'); ?></h2>
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="benefits_section_title"><?php _e('Benefits Section Title', 'vira-store'); ?></label>
                            </th>
                            <td>
                                <input type="text" 
                                       id="benefits_section_title" 
                                       name="benefits_section_title" 
                                       value="<?php echo esc_attr($settings['benefits_section_title'] ?? __('Why Join Our Affiliate Program?', 'vira-store')); ?>" 
                                       class="regular-text">
                                <p class="description"><?php _e('Title displayed above the benefits list on the affiliate registration page.', 'vira-store'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="program_benefits"><?php _e('Program Benefits', 'vira-store'); ?></label>
                            </th>
                            <td>
                                <textarea id="program_benefits" 
                                          name="program_benefits" 
                                          rows="8" 
                                          class="large-text"
                                          placeholder="<?php _e('Enter each benefit on a new line', 'vira-store'); ?>"><?php 
                                // Default benefits if not set
                                $default_benefits = array(
                                    __('Earn up to 30% commission on every sale', 'vira-store'),
                                    __('Real-time tracking and reporting', 'vira-store'),
                                    __('Monthly payouts via PayPal or bank transfer', 'vira-store'),
                                    __('Marketing materials and support', 'vira-store'),
                                    __('No minimum payout threshold', 'vira-store')
                                );
                                $current_benefits = $settings['program_benefits'] ?? implode("\n", $default_benefits);
                                echo esc_textarea($current_benefits);
                                ?></textarea>
                                <p class="description"><?php _e('Enter each benefit on a separate line. These will be displayed as bullet points on the affiliate registration page.', 'vira-store'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="program_description"><?php _e('Program Description', 'vira-store'); ?></label>
                            </th>
                            <td>
                                <textarea id="program_description" 
                                          name="program_description" 
                                          rows="3" 
                                          class="large-text"
                                          placeholder="<?php _e('Brief description of your affiliate program', 'vira-store'); ?>"><?php 
                                echo esc_textarea($settings['program_description'] ?? __('Earn commissions by promoting our products to your audience.', 'vira-store'));
                                ?></textarea>
                                <p class="description"><?php _e('Short description displayed at the top of the affiliate registration page.', 'vira-store'); ?></p>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>

            <p class="submit">
                <input type="submit" class="button button-primary" value="<?php _e('Save Settings', 'vira-store'); ?>">
            </p>
        </form>
    </div>
</div>