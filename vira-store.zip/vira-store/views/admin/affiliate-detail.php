<?php
/**
 * Affiliate Detail Admin Page Template
 *
 * @package Vira_Store
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap">
    <h1 class="wp-heading-inline">
        <?php _e('Affiliate Details', 'vira-store'); ?>
        <a href="<?php echo admin_url('admin.php?page=vrstore-affiliates'); ?>" class="page-title-action">
            <?php _e('Back to Affiliates', 'vira-store'); ?>
        </a>
    </h1>
    
    <hr class="wp-header-end">

    <div class="affiliate-detail-container">
        <div class="affiliate-info-card">
            <h2><?php _e('Affiliate Information', 'vira-store'); ?></h2>
            
            <table class="form-table">
                <tr>
                    <th scope="row"><?php _e('Name', 'vira-store'); ?></th>
                    <td><?php echo esc_html($affiliate['name']); ?></td>
                </tr>
                <tr>
                    <th scope="row"><?php _e('Email', 'vira-store'); ?></th>
                    <td><?php echo esc_html($affiliate['email']); ?></td>
                </tr>
                <tr>
                    <th scope="row"><?php _e('Status', 'vira-store'); ?></th>
                    <td>
                        <span class="status-badge status-<?php echo esc_attr($affiliate['status']); ?>">
                            <?php echo esc_html(ucfirst($affiliate['status'])); ?>
                        </span>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php _e('Commission Rate', 'vira-store'); ?></th>
                    <td><?php echo esc_html($affiliate['commission_rate']); ?>%</td>
                </tr>
                <tr>
                    <th scope="row"><?php _e('Referral Code', 'vira-store'); ?></th>
                    <td>
                        <code><?php echo esc_html($affiliate['affiliate_code']); ?></code>
                        <button type="button" class="button button-small copy-code" data-code="<?php echo esc_attr($affiliate['affiliate_code']); ?>">
                            <?php _e('Copy', 'vira-store'); ?>
                        </button>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php _e('Registered', 'vira-store'); ?></th>
                    <td><?php echo esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($affiliate['created_at']))); ?></td>
                </tr>
            </table>

            <?php if ($affiliate['status'] === 'pending'): ?>
                <div class="affiliate-actions">
                    <form method="post" style="display: inline;">
                        <?php wp_nonce_field('vrstore_affiliate_action'); ?>
                        <input type="hidden" name="action" value="approve_affiliate">
                        <input type="hidden" name="affiliate_id" value="<?php echo esc_attr($affiliate['id']); ?>">
                        <input type="submit" class="button button-primary" value="<?php _e('Approve Affiliate', 'vira-store'); ?>">
                    </form>
                    
                    <form method="post" style="display: inline; margin-left: 10px;">
                        <?php wp_nonce_field('vrstore_affiliate_action'); ?>
                        <input type="hidden" name="action" value="reject_affiliate">
                        <input type="hidden" name="affiliate_id" value="<?php echo esc_attr($affiliate['id']); ?>">
                        <input type="submit" class="button button-secondary" value="<?php _e('Reject Affiliate', 'vira-store'); ?>" onclick="return confirm('<?php _e('Are you sure you want to reject this affiliate?', 'vira-store'); ?>')">
                    </form>
                </div>
            <?php endif; ?>
        </div>

        <div class="affiliate-stats-card">
            <h2><?php _e('Performance Statistics', 'vira-store'); ?></h2>
            
            <div class="stats-grid">
                <div class="stat-item">
                    <div class="stat-number"><?php echo esc_html($stats['total_visits']); ?></div>
                    <div class="stat-label"><?php _e('Total Visits', 'vira-store'); ?></div>
                </div>
                
                <div class="stat-item">
                    <div class="stat-number"><?php echo esc_html($stats['total_commissions']); ?></div>
                    <div class="stat-label"><?php _e('Total Commissions', 'vira-store'); ?></div>
                </div>
                
                <div class="stat-item">
                    <div class="stat-number">
                        <?php 
                        // Get currency converter and settings for admin display
                        $settings = VRSTORE_Settings::get_instance();
                        $base_currency = $settings->get_setting('currency', 'USD');
                        
                        // Total earnings are already stored in base currency from commissions
                        $total_earnings = floatval($stats['total_earnings'] ?? 0);
                        
                        // Admin views should always show base currency for consistency
                        if (class_exists('VRSTORE_Currency_Converter')) {
                            $currency_converter = VRSTORE_Currency_Converter::get_instance();
                            // Use format_price since amounts are already in base currency
                            echo esc_html($currency_converter->format_price($total_earnings));
                        } else {
                            // Fallback without currency converter
                            echo '$' . esc_html(number_format($total_earnings, 2));
                        }
                        ?>
                    </div>
                    <div class="stat-label"><?php _e('Total Earnings', 'vira-store'); ?></div>
                </div>
                
                <div class="stat-item">
                    <div class="stat-number">
                        <?php 
                        $unpaid_commissions = floatval($stats['unpaid_commissions'] ?? 0);
                        // Admin views should always show base currency for consistency
                        // Unpaid commissions are stored in base currency
                        if (class_exists('VRSTORE_Currency_Converter')) {
                            $currency_converter = VRSTORE_Currency_Converter::get_instance();
                            // Use format_price since amounts are already in base currency
                            echo esc_html($currency_converter->format_price($unpaid_commissions));
                        } else {
                            // Fallback without currency converter
                            echo '$' . esc_html(number_format($unpaid_commissions, 2));
                        }
                        ?>
                    </div>
                    <div class="stat-label"><?php _e('Unpaid Commissions', 'vira-store'); ?></div>
                </div>
                
                <div class="stat-item">
                    <div class="stat-number">
                        <?php 
                        $conversion_rate = $stats['total_visits'] > 0 ? ($stats['total_commissions'] / $stats['total_visits']) * 100 : 0;
                        echo esc_html(number_format($conversion_rate, 2)); 
                        ?>%
                    </div>
                    <div class="stat-label"><?php _e('Conversion Rate', 'vira-store'); ?></div>
                </div>
            </div>
            
            <!-- URL Shortener Analytics -->
            <?php
            // Get URL shortener statistics for this affiliate
            global $wpdb;
            $affiliate_visits_table = $wpdb->prefix . 'vrstore_affiliate_visits';
            
            // Check if shortener tracking columns exist
            $shortener_columns_exist = $wpdb->get_results($wpdb->prepare(
                "SHOW COLUMNS FROM {$affiliate_visits_table} LIKE %s",
                'visit_source'
            ));
            
            if (!empty($shortener_columns_exist)) {
                $shortener_stats = $wpdb->get_results($wpdb->prepare(
                    "SELECT 
                        visit_source,
                        short_url_provider,
                        COUNT(*) as visits,
                        SUM(converted) as conversions
                     FROM {$affiliate_visits_table} 
                     WHERE affiliate_id = %d 
                     GROUP BY visit_source, short_url_provider
                     ORDER BY visits DESC",
                    $affiliate['id']
                ));
                
                if (!empty($shortener_stats)):
            ?>
            <h3><?php _e('URL Shortener Performance', 'vira-store'); ?></h3>
            <div class="shortener-stats">
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php _e('URL Type', 'vira-store'); ?></th>
                            <th><?php _e('Provider', 'vira-store'); ?></th>
                            <th><?php _e('Visits', 'vira-store'); ?></th>
                            <th><?php _e('Conversions', 'vira-store'); ?></th>
                            <th><?php _e('Conversion Rate', 'vira-store'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($shortener_stats as $stat): 
                            $conv_rate = $stat->visits > 0 ? ($stat->conversions / $stat->visits) * 100 : 0;
                            $provider = $stat->short_url_provider ?: __('N/A', 'vira-store');
                            $visit_source = ucfirst(str_replace('_', ' ', $stat->visit_source));
                        ?>
                            <tr>
                                <td><strong><?php echo esc_html($visit_source); ?></strong></td>
                                <td><?php echo esc_html(ucfirst($provider)); ?></td>
                                <td><?php echo esc_html($stat->visits); ?></td>
                                <td><?php echo esc_html($stat->conversions); ?></td>
                                <td><?php echo esc_html(number_format($conv_rate, 1)); ?>%</td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php 
                endif;
            }
            ?>
        </div>

        <div class="affiliate-commission-card">
            <h2><?php _e('Commission Settings', 'vira-store'); ?></h2>
            
            <form method="post">
                <?php wp_nonce_field('vrstore_affiliate_action'); ?>
                <input type="hidden" name="action" value="update_commission">
                <input type="hidden" name="affiliate_id" value="<?php echo esc_attr($affiliate['id']); ?>">
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="commission_rate"><?php _e('Commission Rate (%)', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <input type="number" 
                                   id="commission_rate" 
                                   name="commission_rate" 
                                   value="<?php echo esc_attr($affiliate['commission_rate']); ?>"
                                   min="0" 
                                   max="100" 
                                   step="0.01" 
                                   class="small-text">
                            <p class="description"><?php _e('Enter the commission rate as a percentage (0-100).', 'vira-store'); ?></p>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <input type="submit" class="button button-primary" value="<?php _e('Update Commission Rate', 'vira-store'); ?>">
                </p>
            </form>
        </div>
    </div>
</div>