<?php
/**
 * Affiliates Admin Page Template
 *
 * @package Vira_Store
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap">
    <h1 class="wp-heading-inline"><?php _e('Affiliates', 'vira-store'); ?></h1>
    
    <hr class="wp-header-end">

    <!-- Tab Navigation -->
    <nav class="nav-tab-wrapper">
        <a href="<?php echo admin_url('admin.php?page=vrstore-affiliates&tab=affiliates'); ?>" 
           class="nav-tab <?php echo ($current_tab === 'affiliates') ? 'nav-tab-active' : ''; ?>">
            <?php _e('Affiliates', 'vira-store'); ?>
        </a>
        <a href="<?php echo admin_url('admin.php?page=vrstore-affiliates&tab=settings'); ?>" 
           class="nav-tab <?php echo ($current_tab === 'settings') ? 'nav-tab-active' : ''; ?>">
            <?php _e('Settings', 'vira-store'); ?>
        </a>
    </nav>

    <div class="affiliate-content-wrapper">

    <?php if (empty($affiliates)): ?>
        <div class="notice notice-info">
            <p><?php _e('No affiliates found. Affiliates will appear here once users register through the affiliate shortcode.', 'vira-store'); ?></p>
        </div>
    <?php else: ?>
        <form method="post" action="">
            <?php wp_nonce_field('vrstore_affiliate_bulk_action', 'vrstore_bulk_nonce'); ?>
            <input type="hidden" name="action" value="bulk_affiliate_action" />
            <input type="hidden" id="bulk-action-hidden" name="bulk_action_hidden" value="" />
            
            <div class="tablenav top">
                <div class="alignleft actions bulkactions">
                    <label for="bulk-action-selector-top" class="screen-reader-text"><?php _e('Select bulk action', 'vira-store'); ?></label>
                    <select name="bulk_action" id="bulk-action-selector-top">
                        <option value="-1"><?php _e('Bulk Actions', 'vira-store'); ?></option>
                        <option value="approve"><?php _e('Approve', 'vira-store'); ?></option>
                        <option value="reject"><?php _e('Reject', 'vira-store'); ?></option>
                        <option value="delete"><?php _e('Delete', 'vira-store'); ?></option>
                    </select>
                    <input type="submit" id="doaction" class="button action" value="<?php _e('Apply', 'vira-store'); ?>">
                </div>
            </div>

        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <td id="cb" class="manage-column column-cb check-column">
                        <label class="screen-reader-text" for="cb-select-all-1"><?php _e('Select All', 'vira-store'); ?></label>
                        <input id="cb-select-all-1" type="checkbox">
                    </td>
                    <th scope="col" class="manage-column column-name column-primary">
                        <?php _e('Affiliate', 'vira-store'); ?>
                    </th>
                    <th scope="col" class="manage-column column-email">
                        <?php _e('Email', 'vira-store'); ?>
                    </th>
                    <th scope="col" class="manage-column column-status">
                        <?php _e('Status', 'vira-store'); ?>
                    </th>
                    <th scope="col" class="manage-column column-commission">
                        <?php _e('Commission Rate', 'vira-store'); ?>
                    </th>
                    <th scope="col" class="manage-column column-visits">
                        <?php _e('Visits', 'vira-store'); ?>
                    </th>
                    <th scope="col" class="manage-column column-commissions">
                        <?php _e('Commissions', 'vira-store'); ?>
                    </th>
                    <th scope="col" class="manage-column column-earnings">
                        <?php _e('Total Earnings', 'vira-store'); ?>
                    </th>
                    <th scope="col" class="manage-column column-date">
                        <?php _e('Registered', 'vira-store'); ?>
                    </th>
                </tr>
            </thead>
            <tbody id="the-list">
                <?php foreach ($affiliates as $affiliate): ?>
                    <tr>
                        <th scope="row" class="check-column">
                            <input type="checkbox" name="affiliate[]" value="<?php echo esc_attr($affiliate['id']); ?>">
                        </th>
                        <td class="column-name column-primary">
                            <strong>
                                <a href="<?php echo admin_url('admin.php?page=vrstore-affiliates&action=view&affiliate_id=' . $affiliate['id']); ?>">
                                    <?php echo esc_html($affiliate['name']); ?>
                                </a>
                            </strong>
                            <div class="row-actions">
                                <span class="view">
                                    <a href="<?php echo admin_url('admin.php?page=vrstore-affiliates&action=view&affiliate_id=' . $affiliate['id']); ?>">
                                        <?php _e('View', 'vira-store'); ?>
                                    </a> |
                                </span>
                                <span class="edit">
                                    <a href="<?php echo admin_url('admin.php?page=vrstore-affiliates&action=edit&affiliate_id=' . $affiliate['id']); ?>">
                                        <?php _e('Edit', 'vira-store'); ?>
                                    </a>
                                </span>
                                <?php if ($affiliate['status'] === 'pending'): ?>
                                    | <span class="approve">
                                        <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=vrstore-affiliates&action=approve&affiliate_id=' . $affiliate['id']), 'vrstore_affiliate_action'); ?>" class="approve-link">
                                            <?php _e('Approve', 'vira-store'); ?>
                                        </a>
                                    </span>
                                    | <span class="reject">
                                        <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=vrstore-affiliates&action=reject&affiliate_id=' . $affiliate['id']), 'vrstore_affiliate_action'); ?>" class="reject-link">
                                            <?php _e('Reject', 'vira-store'); ?>
                                        </a>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td class="column-email">
                            <?php echo esc_html($affiliate['email']); ?>
                        </td>
                        <td class="column-status">
                            <span class="status-badge status-<?php echo esc_attr($affiliate['status']); ?>">
                                <?php echo esc_html(ucfirst($affiliate['status'])); ?>
                            </span>
                        </td>
                        <td class="column-commission">
                            <?php echo esc_html($affiliate['commission_rate']); ?>%
                        </td>
                        <td class="column-visits">
                            <?php echo esc_html($affiliate['total_visits']); ?>
                        </td>
                        <td class="column-commissions">
                            <?php echo esc_html($affiliate['total_commissions']); ?>
                        </td>
                        <td class="column-earnings">
                            <?php 
                            // Get currency converter and settings for admin display
                            $settings = VRSTORE_Settings::get_instance();
                            $base_currency = $settings->get_setting('currency', 'USD');
                            
                            // Calculate total earnings (sum of all commissions)
                            $total_earnings = floatval($affiliate['total_earnings'] ?? 0);
                            
                            // Admin views should always show base currency for consistency
                            if (class_exists('VRSTORE_Currency_Converter')) {
                                $currency_converter = VRSTORE_Currency_Converter::get_instance();
                                // Use format_price with base currency (since earnings are already in base currency)
                                echo esc_html($currency_converter->format_price($total_earnings));
                            } else {
                                // Fallback without currency converter
                                echo '$' . esc_html(number_format($total_earnings, 2));
                            }
                            ?>
                            <?php if (!empty($affiliate['unpaid_commissions']) && floatval($affiliate['unpaid_commissions']) > 0): ?>
                                <br><small style="color: #666;">
                                    <?php 
                                    $unpaid = floatval($affiliate['unpaid_commissions']);
                                    echo sprintf(__('Unpaid: %s', 'vira-store'), 
                                        class_exists('VRSTORE_Currency_Converter') 
                                            ? $currency_converter->format_price($unpaid)
                                            : '$' . number_format($unpaid, 2)
                                    ); 
                                    ?>
                                </small>
                            <?php endif; ?>
                        </td>
                        <td class="column-date">
                            <?php echo esc_html(date_i18n(get_option('date_format'), strtotime($affiliate['created_at']))); ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        </form>
    <?php endif; ?>
    </div>
</div>