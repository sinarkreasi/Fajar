<?php
/**
 * Domain Activations admin page template
 *
 * @package Vira_Store
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

$page_title = __('Domain Activations', 'vira-store');

// Get current filter values
$current_status = sanitize_text_field($_GET['status'] ?? '');
$current_search = sanitize_text_field($_GET['search'] ?? '');
$current_license_key = sanitize_text_field($_GET['license_key'] ?? '');
$current_license_type = sanitize_text_field($_GET['license_type'] ?? '');
$current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;

// Status filter options
$status_options = [
    '' => __('All Statuses', 'vira-store'),
    'active' => __('Active', 'vira-store'),
    'inactive' => __('Inactive', 'vira-store')
];

// Get statistics
$stats = $activations['statistics'] ?? [];
?>

<div class="wrap vrstore-admin-page">
    <h1 class="wp-heading-inline"><?php echo esc_html($page_title); ?></h1>
    
    <?php if (!empty($activations['activations']) || !empty($current_search) || !empty($current_status)): ?>
        
        <!-- Statistics Cards -->
        <?php if (!empty($stats)): ?>
        <div class="vrstore-stats-cards vrstore-domain-stats">
            <div class="vrstore-stat-card">
                <h3><?php _e('Total Activations', 'vira-store'); ?></h3>
                <div class="stat-number"><?php echo esc_html($stats['total_activations'] ?? 0); ?></div>
            </div>
            <div class="vrstore-stat-card">
                <h3><?php _e('Active Domains', 'vira-store'); ?></h3>
                <div class="stat-number"><?php echo esc_html($stats['status_counts']['active'] ?? 0); ?></div>
            </div>
            <div class="vrstore-stat-card">
                <h3><?php _e('Today\'s Attempts', 'vira-store'); ?></h3>
                <div class="stat-number"><?php echo esc_html($stats['today_attempts'] ?? 0); ?></div>
            </div>
            <div class="vrstore-stat-card">
                <h3><?php _e('Failed Attempts', 'vira-store'); ?></h3>
                <div class="stat-number"><?php echo esc_html($stats['failed_attempts'] ?? 0); ?></div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Filters -->
        <div class="tablenav top">
            <div class="alignleft actions">
                <form method="get" action="">
                    <input type="hidden" name="page" value="vrstore-domain-activations">
                    
                    <label for="status-filter" class="screen-reader-text"><?php _e('Filter by status', 'vira-store'); ?></label>
                    <select name="status" id="status-filter">
                        <?php foreach ($status_options as $value => $label): ?>
                            <option value="<?php echo esc_attr($value); ?>" <?php selected($current_status, $value); ?>>
                                <?php echo esc_html($label); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    
                    <?php if (!empty($activations['license_types'])): ?>
                        <label for="license-type-filter" class="screen-reader-text"><?php _e('Filter by license type', 'vira-store'); ?></label>
                        <select name="license_type" id="license-type-filter">
                            <option value=""><?php _e('All License Types', 'vira-store'); ?></option>
                            <?php foreach ($activations['license_types'] as $license_type): ?>
                                <option value="<?php echo esc_attr($license_type['slug']); ?>" <?php selected($current_license_type, $license_type['slug']); ?>>
                                    <?php echo esc_html($license_type['label']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    <?php endif; ?>
                    
                    <input type="submit" class="button" value="<?php esc_attr_e('Filter', 'vira-store'); ?>">
                </form>
            </div>
            
            <div class="alignright actions">
                <form method="get" action="">
                    <input type="hidden" name="page" value="vrstore-domain-activations">
                    <?php if (!empty($current_status)): ?>
                        <input type="hidden" name="status" value="<?php echo esc_attr($current_status); ?>">
                    <?php endif; ?>
                    <?php if (!empty($current_license_type)): ?>
                        <input type="hidden" name="license_type" value="<?php echo esc_attr($current_license_type); ?>">
                    <?php endif; ?>
                    
                    <label for="activation-search" class="screen-reader-text"><?php _e('Search activations', 'vira-store'); ?></label>
                    <input type="search" id="activation-search" name="search" value="<?php echo esc_attr($current_search); ?>" placeholder="<?php esc_attr_e('Search domains or license keys...', 'vira-store'); ?>">
                    
                    <label for="license-key-filter" class="screen-reader-text"><?php _e('Filter by license key', 'vira-store'); ?></label>
                    <input type="text" id="license-key-filter" name="license_key" value="<?php echo esc_attr($current_license_key); ?>" placeholder="<?php esc_attr_e('License Key', 'vira-store'); ?>">
                    
                    <input type="submit" class="button" value="<?php esc_attr_e('Search', 'vira-store'); ?>">
                </form>
            </div>
        </div>

        <?php if (!empty($activations['activations'])): ?>
        <!-- Domain Activations Table -->
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th scope="col" class="manage-column column-domain"><?php _e('Domain', 'vira-store'); ?></th>
                    <th scope="col" class="manage-column column-license"><?php _e('License Key', 'vira-store'); ?></th>
                    <th scope="col" class="manage-column column-product"><?php _e('Product', 'vira-store'); ?></th>
                    <th scope="col" class="manage-column column-license-type"><?php _e('License Type', 'vira-store'); ?></th>
                    <th scope="col" class="manage-column column-status"><?php _e('Status', 'vira-store'); ?></th>
                    <th scope="col" class="manage-column column-activated"><?php _e('Activated', 'vira-store'); ?></th>
                    <th scope="col" class="manage-column column-last-check"><?php _e('Last Check', 'vira-store'); ?></th>
                    <th scope="col" class="manage-column column-actions"><?php _e('Actions', 'vira-store'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($activations['activations'] as $activation): ?>
                    <tr>
                        <td class="column-domain">
                            <strong><?php echo esc_html($activation['domain']); ?></strong>
                            <?php if (!empty($activation['activation_ip'])): ?>
                                <br><small>IP: <?php echo esc_html($activation['activation_ip']); ?></small>
                            <?php endif; ?>
                            <?php if (isset($activation['domain_accessible'])): ?>
                                <br><small class="<?php echo $activation['domain_accessible'] ? 'text-success' : 'text-error'; ?>">
                                    <?php echo $activation['domain_accessible'] ? __('Accessible', 'vira-store') : __('Not Accessible', 'vira-store'); ?>
                                </small>
                            <?php endif; ?>
                        </td>
                        <td class="column-license">
                            <code><?php echo esc_html(substr($activation['license_key'], 0, 12) . '...'); ?></code>
                            <?php if (!empty($activation['customer_id'])): ?>
                                <br><small>Customer ID: <?php echo esc_html($activation['customer_id']); ?></small>
                            <?php endif; ?>
                        </td>
                        <td class="column-product">
                            <?php 
                            if (!empty($activation['product_id'])) {
                                $product_title = get_the_title($activation['product_id']);
                                echo $product_title ? esc_html($product_title) : __('Unknown Product', 'vira-store');
                            } else {
                                echo '<em>' . __('No product', 'vira-store') . '</em>';
                            }
                            ?>
                        </td>
                        <td class="column-license-type">
                            <?php if (!empty($activation['license_type_label'])): ?>
                                <?php 
                                $type_color = $activation['license_type_color'] ?? '#0073aa';
                                ?>
                                <span class="license-type-badge" style="background-color: <?php echo esc_attr($type_color); ?>; color: white; padding: 3px 8px; border-radius: 3px; font-size: 11px; font-weight: bold;">
                                    <?php echo esc_html($activation['license_type_label']); ?>
                                </span>
                                <?php if (!empty($activation['expires_at']) && $activation['expires_at'] !== '0000-00-00 00:00:00'): ?>
                                    <?php 
                                    $expires_date = new DateTime($activation['expires_at']);
                                    $now = new DateTime();
                                    $days_until_expiry = $now->diff($expires_date)->days;
                                    $is_expired = $expires_date < $now;
                                    $is_expiring_soon = !$is_expired && $days_until_expiry <= 30;
                                    ?>
                                    <br><small class="<?php echo $is_expired ? 'text-error' : ($is_expiring_soon ? 'text-warning' : 'text-muted'); ?>">
                                        <?php if ($is_expired): ?>
                                            <?php _e('Expired', 'vira-store'); ?> <?php echo esc_html($expires_date->format('M j, Y')); ?>
                                        <?php else: ?>
                                            <?php _e('Expires', 'vira-store'); ?> <?php echo esc_html($expires_date->format('M j, Y')); ?>
                                            <?php if ($is_expiring_soon): ?>
                                                (<?php printf(__('%d days', 'vira-store'), $days_until_expiry); ?>)
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </small>
                                <?php endif; ?>
                            <?php else: ?>
                                <em><?php _e('No type', 'vira-store'); ?></em>
                            <?php endif; ?>
                        </td>
                        <td class="column-status">
                            <span class="activation-status activation-status-<?php echo esc_attr($activation['status']); ?>">
                                <?php echo esc_html(ucfirst($activation['status'])); ?>
                            </span>
                            <?php if (!empty($activation['deactivation_reason']) && $activation['status'] === 'inactive'): ?>
                                <br><small><?php echo esc_html($activation['deactivation_reason']); ?></small>
                            <?php endif; ?>
                        </td>
                        <td class="column-activated">
                            <?php echo esc_html(mysql2date('M j, Y g:i A', $activation['activated_at'])); ?>
                            <?php if (!empty($activation['last_response_time'])): ?>
                                <br><small><?php echo esc_html($activation['last_response_time']); ?>ms</small>
                            <?php endif; ?>
                        </td>
                        <td class="column-last-check">
                            <?php 
                            if (!empty($activation['last_checked']) && $activation['last_checked'] !== '0000-00-00 00:00:00') {
                                echo esc_html(mysql2date('M j, Y g:i A', $activation['last_checked']));
                            } else {
                                echo '<em>' . __('Never', 'vira-store') . '</em>';
                            }
                            ?>
                        </td>
                        <td class="column-actions">
                            <div class="row-actions">
                                <?php if ($activation['status'] === 'active'): ?>
                                    <span class="deactivate">
                                        <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=vrstore-domain-activations&action=deactivate&activation_id=' . $activation['id']), 'vrstore_domain_activation_action'); ?>" 
                                           class="vrstore-action-link" 
                                           onclick="return confirm('<?php esc_attr_e('Are you sure you want to deactivate this domain activation?', 'vira-store'); ?>')">
                                            <?php _e('Deactivate', 'vira-store'); ?>
                                        </a>
                                    </span> |
                                <?php endif; ?>
                                
                                <?php if ($activation['status'] === 'inactive'): ?>
                                    <span class="delete">
                                        <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=vrstore-domain-activations&action=delete&activation_id=' . $activation['id']), 'vrstore_domain_activation_action'); ?>" 
                                           class="vrstore-action-link vrstore-delete-activation" 
                                           data-domain="<?php echo esc_attr($activation['domain']); ?>" 
                                           onclick="return confirm('<?php esc_attr_e('Are you sure you want to permanently delete this inactive domain activation? This action cannot be undone.', 'vira-store'); ?>')">
                                            <?php _e('Delete', 'vira-store'); ?>
                                        </a>
                                    </span> |
                                <?php endif; ?>
                                
                                <span class="refresh">
                                    <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=vrstore-domain-activations&action=refresh&activation_id=' . $activation['id']), 'vrstore_domain_activation_action'); ?>" 
                                       class="vrstore-action-link">
                                        <?php _e('Refresh Status', 'vira-store'); ?>
                                    </a>
                                </span> |
                                
                                <span class="view">
                                    <a href="#" class="vrstore-action-link view-activation-details" data-activation-id="<?php echo esc_attr($activation['id']); ?>">
                                        <?php _e('View Details', 'vira-store'); ?>
                                    </a>
                                </span>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Pagination -->
        <?php if ($activations['total_pages'] > 1): ?>
            <div class="tablenav bottom">
                <div class="tablenav-pages">
                    <?php
                    $pagination_args = [
                        'base' => add_query_arg('paged', '%#%'),
                        'format' => '',
                        'prev_text' => __('&laquo; Previous', 'vira-store'),
                        'next_text' => __('Next &raquo;', 'vira-store'),
                        'current' => $current_page,
                        'total' => $activations['total_pages']
                    ];
                    echo paginate_links($pagination_args);
                    ?>
                </div>
            </div>
        <?php endif; ?>

        <?php else: ?>
            <!-- No activations found -->
            <div class="vrstore-empty-search">
                <p><?php _e('No domain activations found matching your search criteria.', 'vira-store'); ?></p>
                <a href="<?php echo admin_url('admin.php?page=vrstore-domain-activations'); ?>" class="button">
                    <?php _e('Clear Filters', 'vira-store'); ?>
                </a>
            </div>
        <?php endif; ?>

    <?php else: ?>
        <!-- No activations found -->
        <div class="vrstore-empty-state">
            <div class="vrstore-empty-icon">
                <span class="dashicons dashicons-admin-network"></span>
            </div>
            <h2><?php _e('No domain activations found', 'vira-store'); ?></h2>
            <p><?php _e('When customers activate licenses on their domains, they will appear here for monitoring and management.', 'vira-store'); ?></p>
        </div>
    <?php endif; ?>
</div>

<!-- View Activation Details Modal -->
<div id="activation-details-modal" class="vrstore-modal">
    <div class="vrstore-modal-content">
        <div class="vrstore-modal-header">
            <h2><?php _e('Activation Details', 'vira-store'); ?></h2>
            <button type="button" class="vrstore-modal-close" id="close-activation-modal">&times;</button>
        </div>
        
        <div class="vrstore-modal-body" id="activation-details-content">
            <div class="vrstore-loading">
                <span class="spinner is-active"></span>
                <p><?php _e('Loading activation details...', 'vira-store'); ?></p>
            </div>
        </div>
        
        <!-- Enhanced Modal Tabs -->
        <div class="vrstore-modal-tabs" id="activation-modal-tabs" style="display: none;">
            <nav class="vrstore-tabs-nav">
                <a href="#activation-info" class="vrstore-tab-link active"><?php _e('Activation Info', 'vira-store'); ?></a>
                <a href="#license-analytics" class="vrstore-tab-link"><?php _e('License Analytics', 'vira-store'); ?></a>
                <a href="#api-security" class="vrstore-tab-link"><?php _e('API Security', 'vira-store'); ?></a>
                <a href="#api-monitoring" class="vrstore-tab-link"><?php _e('API Monitoring', 'vira-store'); ?></a>
            </nav>
            
            <div class="vrstore-tab-content">
                <!-- Activation Info Tab -->
                <div id="activation-info" class="vrstore-tab-pane active">
                    <div id="activation-basic-info">
                        <!-- Basic activation details will be loaded here -->
                    </div>
                </div>
                
                <!-- License Analytics Tab -->
                <div id="license-analytics" class="vrstore-tab-pane">
                    <div class="vrstore-analytics-section">
                        <h4><?php _e('Usage Analytics', 'vira-store'); ?></h4>
                        <div class="vrstore-analytics-grid">
                            <div class="vrstore-metric-card">
                                <span class="metric-label"><?php _e('API Calls Today', 'vira-store'); ?></span>
                                <span class="metric-value" id="api-calls-today">-</span>
                            </div>
                            <div class="vrstore-metric-card">
                                <span class="metric-label"><?php _e('Last Activity', 'vira-store'); ?></span>
                                <span class="metric-value" id="last-activity">-</span>
                            </div>
                            <div class="vrstore-metric-card">
                                <span class="metric-label"><?php _e('Total Requests', 'vira-store'); ?></span>
                                <span class="metric-value" id="total-requests">-</span>
                            </div>
                            <div class="vrstore-metric-card">
                                <span class="metric-label"><?php _e('Success Rate', 'vira-store'); ?></span>
                                <span class="metric-value" id="success-rate">-</span>
                            </div>
                        </div>
                        <div class="vrstore-chart-container">
                            <canvas id="license-usage-chart" width="400" height="200"></canvas>
                        </div>
                    </div>
                </div>
                
                <!-- API Security Tab -->
                <div id="api-security" class="vrstore-tab-pane">
                    <div class="vrstore-security-section">
                        <h4><?php _e('Security Status', 'vira-store'); ?></h4>
                        <div class="vrstore-security-grid">
                            <div class="vrstore-security-item">
                                <span class="security-icon dashicons dashicons-shield-alt"></span>
                                <div class="security-info">
                                    <strong><?php _e('SSL Status', 'vira-store'); ?></strong>
                                    <span id="ssl-status" class="security-status">-</span>
                                </div>
                            </div>
                            <div class="vrstore-security-item">
                                <span class="security-icon dashicons dashicons-lock"></span>
                                <div class="security-info">
                                    <strong><?php _e('Authentication', 'vira-store'); ?></strong>
                                    <span id="auth-status" class="security-status">-</span>
                                </div>
                            </div>
                            <div class="vrstore-security-item">
                                <span class="security-icon dashicons dashicons-warning"></span>
                                <div class="security-info">
                                    <strong><?php _e('Threat Level', 'vira-store'); ?></strong>
                                    <span id="threat-level" class="security-status">-</span>
                                </div>
                            </div>
                            <div class="vrstore-security-item">
                                <span class="security-icon dashicons dashicons-admin-network"></span>
                                <div class="security-info">
                                    <strong><?php _e('IP Reputation', 'vira-store'); ?></strong>
                                    <span id="ip-reputation" class="security-status">-</span>
                                </div>
                            </div>
                        </div>
                        <div class="vrstore-security-logs">
                            <h5><?php _e('Recent Security Events', 'vira-store'); ?></h5>
                            <div id="security-events-list" class="vrstore-events-list">
                                <div class="vrstore-loading-small">
                                    <span class="spinner is-active"></span>
                                    <span><?php _e('Loading security events...', 'vira-store'); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- API Monitoring Tab -->
                <div id="api-monitoring" class="vrstore-tab-pane">
                    <div class="vrstore-monitoring-section">
                        <h4><?php _e('API Performance', 'vira-store'); ?></h4>
                        <div class="vrstore-monitoring-grid">
                            <div class="vrstore-monitor-card">
                                <span class="monitor-label"><?php _e('Response Time', 'vira-store'); ?></span>
                                <span class="monitor-value" id="response-time">-</span>
                                <span class="monitor-unit">ms</span>
                            </div>
                            <div class="vrstore-monitor-card">
                                <span class="monitor-label"><?php _e('Uptime', 'vira-store'); ?></span>
                                <span class="monitor-value" id="uptime">-</span>
                                <span class="monitor-unit">%</span>
                            </div>
                            <div class="vrstore-monitor-card">
                                <span class="monitor-label"><?php _e('Error Rate', 'vira-store'); ?></span>
                                <span class="monitor-value" id="error-rate">-</span>
                                <span class="monitor-unit">%</span>
                            </div>
                            <div class="vrstore-monitor-card">
                                <span class="monitor-label"><?php _e('Bandwidth', 'vira-store'); ?></span>
                                <span class="monitor-value" id="bandwidth-usage">-</span>
                                <span class="monitor-unit">MB</span>
                            </div>
                        </div>
                        <div class="vrstore-monitoring-chart">
                            <h5><?php _e('Performance Trends', 'vira-store'); ?></h5>
                            <canvas id="performance-chart" width="400" height="200"></canvas>
                        </div>
                        <div class="vrstore-api-logs">
                            <h5><?php _e('Recent API Calls', 'vira-store'); ?></h5>
                            <div id="api-calls-list" class="vrstore-logs-list">
                                <div class="vrstore-loading-small">
                                    <span class="spinner is-active"></span>
                                    <span><?php _e('Loading API logs...', 'vira-store'); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="vrstore-modal-footer">
            <button type="button" class="button" id="close-activation-details"><?php _e('Close', 'vira-store'); ?></button>
            <button type="button" class="button button-primary" id="refresh-activation-data"><?php _e('Refresh Data', 'vira-store'); ?></button>
        </div>
    </div>
</div>