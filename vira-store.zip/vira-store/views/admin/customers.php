<?php
/**
 * Customers admin page template
 *
 * @package Vira_Store
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

$page_title = __('Customers', 'vira-store');
$add_new_url = admin_url('admin.php?page=vrstore-customers&action=add');

// Get current filter values
$current_status = sanitize_text_field($_GET['status'] ?? '');
$current_search = sanitize_text_field($_GET['search'] ?? '');
$current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;

// Status filter options
$status_options = [
    '' => __('All Statuses', 'vira-store'),
    'active' => __('Active', 'vira-store'),
    'inactive' => __('Inactive', 'vira-store'),
    'pending' => __('Pending', 'vira-store')
];
?>

<div class="wrap vrstore-admin-page vrstore-customers-page">
    <div class="vrstore-page-header">
        <h1 class="wp-heading-inline"><?php echo esc_html($page_title); ?></h1>
        <div class="vrstore-page-actions">
            <button type="button" id="export-customers-csv" class="button button-secondary">
                <span class="dashicons dashicons-download"></span>
                <span class="button-text"><?php _e('Export to CSV', 'vira-store'); ?></span>
            </button>
            <a href="<?php echo esc_url($add_new_url); ?>" class="button button-primary vrstore-btn-primary">
                <span class="dashicons dashicons-plus-alt2"></span>
                <?php _e('Add New Customer', 'vira-store'); ?>
            </a>
        </div>
    </div>
    
    <?php if (!empty($customers['customers'])): ?>
        <!-- Filters -->
        <div class="tablenav top">
            <div class="alignleft actions">
                <form method="get" action="">
                    <input type="hidden" name="page" value="vrstore-customers">
                    
                    <label for="status-filter" class="screen-reader-text"><?php _e('Filter by status', 'vira-store'); ?></label>
                    <select name="status" id="status-filter">
                        <?php foreach ($status_options as $value => $label): ?>
                            <option value="<?php echo esc_attr($value); ?>" <?php selected($current_status, $value); ?>>
                                <?php echo esc_html($label); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    
                    <input type="submit" class="button" value="<?php esc_attr_e('Filter', 'vira-store'); ?>">
                </form>
            </div>
            
            <div class="alignright actions">
                <form method="get" action="">
                    <input type="hidden" name="page" value="vrstore-customers">
                    <?php if (!empty($current_status)): ?>
                        <input type="hidden" name="status" value="<?php echo esc_attr($current_status); ?>">
                    <?php endif; ?>
                    
                    <label for="customer-search" class="screen-reader-text"><?php _e('Search customers', 'vira-store'); ?></label>
                    <input type="search" id="customer-search" name="search" value="<?php echo esc_attr($current_search); ?>" placeholder="<?php esc_attr_e('Search customers...', 'vira-store'); ?>">
                    <input type="submit" class="button" value="<?php esc_attr_e('Search', 'vira-store'); ?>">
                </form>
            </div>
        </div>

        <!-- Statistics Cards -->
        <div class="vrstore-stats-cards">
            <div class="vrstore-stat-card">
                <h3><?php _e('Total Customers', 'vira-store'); ?></h3>
                <div class="stat-number"><?php echo esc_html($customers['total_items'] ?? 0); ?></div>
            </div>
            <div class="vrstore-stat-card">
                <h3><?php _e('Active Customers', 'vira-store'); ?></h3>
                <div class="stat-number"><?php echo esc_html(count(array_filter($customers['customers'] ?? [], function($c) { return ($c['status'] ?? 'active') === 'active'; }))); ?></div>
            </div>
            <div class="vrstore-stat-card">
                <h3><?php _e('Total Orders', 'vira-store'); ?></h3>
                <div class="stat-number"><?php echo esc_html(array_sum(array_column($customers['customers'] ?? [], 'total_orders'))); ?></div>
            </div>
            <div class="vrstore-stat-card">
                <h3><?php _e('Total Revenue', 'vira-store'); ?></h3>
                <div class="stat-number"><?php echo esc_html(vrstore_format_price(array_sum(array_column($customers['customers'] ?? [], 'total_spent')))); ?></div>
            </div>
        </div>

        <!-- Customers Table -->
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th scope="col" class="manage-column column-name"><?php _e('Name', 'vira-store'); ?></th>
                    <th scope="col" class="manage-column column-email"><?php _e('Email', 'vira-store'); ?></th>
                    <th scope="col" class="manage-column column-orders"><?php _e('Orders', 'vira-store'); ?></th>
                    <th scope="col" class="manage-column column-licenses"><?php _e('Licenses', 'vira-store'); ?></th>
                    <th scope="col" class="manage-column column-support" style="width: 120px;"><?php _e('Support', 'vira-store'); ?></th>
                    <th scope="col" class="manage-column column-spent"><?php _e('Total Spent', 'vira-store'); ?></th>
                    <th scope="col" class="manage-column column-registered"><?php _e('Registered', 'vira-store'); ?></th>
                    <th scope="col" class="manage-column column-status"><?php _e('Status', 'vira-store'); ?></th>
                    <th scope="col" class="manage-column column-actions"><?php _e('Actions', 'vira-store'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($customers['customers'] as $customer): ?>
                    <tr>
                        <td class="column-name">
                            <strong>
                                <a href="<?php echo esc_url(admin_url('admin.php?page=vrstore-customers&action=view&customer_id=' . $customer['ID'])); ?>">
                                    <?php echo esc_html($customer['display_name'] ?: $customer['user_login']); ?>
                                </a>
                            </strong>
                        </td>
                        <td class="column-email">
                            <a href="mailto:<?php echo esc_attr($customer['user_email']); ?>">
                                <?php echo esc_html($customer['user_email']); ?>
                            </a>
                        </td>
                        <td class="column-orders">
                            <span class="count"><?php echo esc_html($customer['total_orders'] ?? 0); ?></span>
                        </td>
                        <td class="column-licenses">
                            <span class="count"><?php echo esc_html($customer['total_licenses'] ?? 0); ?></span>
                        </td>
                        <td class="column-support">
                            <?php 
                            // Get support ticket stats for this customer
                            global $wpdb;
                            $tickets_table = $wpdb->prefix . 'vrstore_support_tickets';
                            $customer_id = $customer['ID'];
                            
                            // Check if table exists, create if it doesn't
                            if ($wpdb->get_var("SHOW TABLES LIKE '$tickets_table'") != $tickets_table) {
                                if (class_exists('VRSTORE_Database')) {
                                    $db = VRSTORE_Database::get_instance();
                                    $db->check_database_version();
                                }
                            }
                            
                            // Initialize counters
                            $open_tickets = 0;
                            $unread_count = 0;
                            $total_tickets = 0;
                            
                            // Only query if table exists
                            if ($wpdb->get_var("SHOW TABLES LIKE '$tickets_table'") == $tickets_table) {
                                // Count open/pending tickets
                                $open_tickets = $wpdb->get_var($wpdb->prepare(
                                    "SELECT COUNT(*) FROM $tickets_table WHERE customer_id = %d AND status IN ('open', 'pending', 'in_progress')",
                                    $customer_id
                                ));
                                
                                // Count unread admin messages
                                $unread_count = $wpdb->get_var($wpdb->prepare(
                                    "SELECT SUM(admin_unread_count) FROM $tickets_table WHERE customer_id = %d AND admin_unread_count > 0",
                                    $customer_id
                                ));
                                
                                $total_tickets = $wpdb->get_var($wpdb->prepare(
                                    "SELECT COUNT(*) FROM $tickets_table WHERE customer_id = %d",
                                    $customer_id
                                ));
                            }
                            
                            $unread_count = intval($unread_count);
                            $open_tickets = intval($open_tickets);
                            $total_tickets = intval($total_tickets);
                            ?>
                            <div class="vrstore-support-summary">
                                <?php if ($total_tickets > 0): ?>
                                    <button type="button" class="button button-small vrstore-view-tickets" 
                                            data-customer-id="<?php echo esc_attr($customer_id); ?>"
                                            data-customer-name="<?php echo esc_attr($customer['display_name']); ?>"
                                            data-customer-email="<?php echo esc_attr($customer['user_email']); ?>">
                                        <span class="dashicons dashicons-tickets-alt"></span>
                                        <?php echo esc_html($total_tickets); ?> 
                                        <?php if ($open_tickets > 0): ?>
                                            <span class="vrstore-open-tickets">(<?php echo esc_html($open_tickets); ?> open)</span>
                                        <?php endif; ?>
                                        <?php if ($unread_count > 0): ?>
                                            <span class="vrstore-unread-badge"><?php echo esc_html($unread_count); ?></span>
                                        <?php endif; ?>
                                    </button>
                                <?php else: ?>
                                    <span class="vrstore-no-tickets">
                                        <span class="dashicons dashicons-tickets-alt"></span>
                                        <?php _e('No tickets', 'vira-store'); ?>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td class="column-spent">
                            <span class="amount"><?php echo esc_html(vrstore_format_price($customer['total_spent'] ?? 0)); ?></span>
                        </td>
                        <td class="column-registered">
                            <?php echo esc_html(date_i18n(get_option('date_format'), strtotime($customer['user_registered']))); ?>
                        </td>
                        <td class="column-status">
                            <?php 
                            $status = $customer['status'] ?? 'active';
                            $status_class = 'status-' . $status;
                            $status_label = ucfirst($status);
                            ?>
                            <span class="vrstore-status <?php echo esc_attr($status_class); ?>">
                                <?php echo esc_html($status_label); ?>
                            </span>
                        </td>
                        <td class="column-actions">
                            <div class="row-actions">
                                <span class="view">
                                    <a href="<?php echo esc_url(admin_url('admin.php?page=vrstore-customers&action=view&customer_id=' . $customer['ID'])); ?>">
                                        <?php _e('View', 'vira-store'); ?>
                                    </a> |
                                </span>
                                <span class="edit">
                                    <a href="<?php echo esc_url(admin_url('admin.php?page=vrstore-customers&action=edit&customer_id=' . $customer['ID'])); ?>">
                                        <?php _e('Edit', 'vira-store'); ?>
                                    </a> |
                                </span>
                                <?php if (($customer['status'] ?? 'active') === 'active'): ?>
                                    <span class="deactivate">
                                        <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?page=vrstore-customers&action=deactivate&customer_id=' . $customer['ID']), 'vrstore_customer_action')); ?>" 
                                           onclick="return confirm('<?php esc_attr_e('Are you sure you want to deactivate this customer?', 'vira-store'); ?>')">
                                            <?php _e('Deactivate', 'vira-store'); ?>
                                        </a> |
                                    </span>
                                <?php else: ?>
                                    <span class="activate">
                                        <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?page=vrstore-customers&action=activate&customer_id=' . $customer['ID']), 'vrstore_customer_action')); ?>">
                                            <?php _e('Activate', 'vira-store'); ?>
                                        </a> |
                                    </span>
                                <?php endif; ?>
                                <span class="delete">
                                    <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?page=vrstore-customers&action=delete&customer_id=' . $customer['ID']), 'vrstore_customer_action')); ?>" 
                                       class="submitdelete vrstore-delete-customer" 
                                       data-customer-id="<?php echo esc_attr($customer['ID']); ?>"
                                       data-customer-name="<?php echo esc_attr($customer['display_name']); ?>"
                                       data-customer-email="<?php echo esc_attr($customer['user_email']); ?>"
                                       onclick="return confirm('<?php esc_attr_e('Are you sure you want to delete this customer? This will permanently remove:\n\n• Customer account and profile\n• All orders and licenses\n• Domain activations and license keys\n• Download tracking history\n• Payment records\n\nThis action cannot be undone!', 'vira-store'); ?>')">
                                        <?php _e('Delete', 'vira-store'); ?>
                                    </a>
                                </span>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Pagination -->
        <?php if ($customers['total_pages'] > 1): ?>
            <div class="tablenav bottom">
                <div class="tablenav-pages">
                    <?php
                    $pagination_args = [
                        'base' => add_query_arg('paged', '%#%'),
                        'format' => '',
                        'prev_text' => __('&laquo; Previous', 'vira-store'),
                        'next_text' => __('Next &raquo;', 'vira-store'),
                        'total' => $customers['total_pages'],
                        'current' => $current_page,
                        'type' => 'plain'
                    ];
                    echo paginate_links($pagination_args);
                    ?>
                </div>
            </div>
        <?php endif; ?>

    <?php else: ?>
        <!-- Empty State -->
        <div class="vrstore-empty-state">
            <div class="vrstore-empty-icon">
                <span class="dashicons dashicons-groups"></span>
            </div>
            <h3><?php _e('No customers found', 'vira-store'); ?></h3>
            <p><?php _e('You haven\'t added any customers yet. Start by adding your first customer.', 'vira-store'); ?></p>
            <a href="<?php echo esc_url($add_new_url); ?>" class="button button-primary">
                <?php _e('Add New Customer', 'vira-store'); ?>
            </a>
        </div>
    <?php endif; ?>
</div>

<!-- Support Tickets Modal -->
<div id="vrstore-tickets-modal" class="vrstore-modal" style="display: none;">
    <div class="vrstore-modal-content vrstore-modal-large">
        <div class="vrstore-modal-header">
            <h2 id="vrstore-tickets-modal-title"><?php _e('Customer Support Tickets', 'vira-store'); ?></h2>
            <span class="vrstore-modal-close">&times;</span>
        </div>
        <div class="vrstore-modal-body">
            <div id="vrstore-tickets-loading" class="vrstore-loading">
                
            </div>
            <div id="vrstore-tickets-content" style="display: none;">
                <!-- Tickets will be loaded here via AJAX -->
            </div>
        </div>
        <div class="vrstore-modal-footer">
            <button type="button" class="button" id="vrstore-tickets-close"><?php _e('Close', 'vira-store'); ?></button>
        </div>
    </div>
</div>

<!-- Individual Ticket Modal -->
<div id="vrstore-ticket-detail-modal" class="vrstore-modal" style="display: none;">
    <div class="vrstore-modal-content vrstore-modal-large">
        <div class="vrstore-modal-header">
            <h2 id="vrstore-ticket-detail-title"><?php _e('Support Ticket Details', 'vira-store'); ?></h2>
            <span class="vrstore-modal-close">&times;</span>
        </div>
        <div class="vrstore-modal-body">
            <div id="vrstore-ticket-detail-loading" class="vrstore-loading">
                
            </div>
            <div id="vrstore-ticket-detail-content" style="display: none;">
                <!-- Ticket details and conversation will be loaded here -->
            </div>
        </div>
        <div class="vrstore-modal-footer">
            <button type="button" class="button button-primary" id="vrstore-ticket-reply-btn"><?php _e('Add Reply', 'vira-store'); ?></button>
            <button type="button" class="button" id="vrstore-ticket-detail-close"><?php _e('Close', 'vira-store'); ?></button>
        </div>
    </div>
</div>
