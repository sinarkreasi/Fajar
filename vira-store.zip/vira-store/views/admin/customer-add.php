<?php
/**
 * Customer Add View
 * 
 * @package Vira_Store
 * @since 1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap">
    <h1 class="wp-heading-inline">
        <?php echo esc_html__('Add New Customer', 'vira-store'); ?>
    </h1>
    
    <a href="<?php echo esc_url(admin_url('admin.php?page=vrstore-customers')); ?>" class="page-title-action">
        <?php echo esc_html__('← Back to Customers', 'vira-store'); ?>
    </a>
    
    <hr class="wp-header-end">
    
    <form method="post" action="" class="customer-add-form">
        <?php wp_nonce_field('vrstore_add_customer', 'vrstore_customer_nonce'); ?>
        <input type="hidden" name="action" value="add_customer">
        
        <div class="customer-add-sections">
            <!-- Required Information -->
            <div class="add-section">
                <h3><?php echo esc_html__('Required Information', 'vira-store'); ?></h3>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="user_login"><?php echo esc_html__('Username', 'vira-store'); ?> <span class="required">*</span></label>
                        </th>
                        <td>
                            <input type="text" id="user_login" name="user_login" value="" class="regular-text" required>
                            <p class="description"><?php echo esc_html__('Username for customer login. Must be unique and cannot be changed later.', 'vira-store'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="user_email"><?php echo esc_html__('Email Address', 'vira-store'); ?> <span class="required">*</span></label>
                        </th>
                        <td>
                            <input type="email" id="user_email" name="user_email" value="" class="regular-text" required>
                            <p class="description"><?php echo esc_html__('Customer\'s email address for communication and login.', 'vira-store'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="user_pass"><?php echo esc_html__('Password', 'vira-store'); ?> <span class="required">*</span></label>
                        </th>
                        <td>
                            <input type="password" id="user_pass" name="user_pass" value="" class="regular-text" required>
                            <button type="button" id="generate_password" class="button button-secondary">
                                <?php echo esc_html__('Generate Password', 'vira-store'); ?>
                            </button>
                            <p class="description"><?php echo esc_html__('Customer password. Click Generate Password for a secure random password.', 'vira-store'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="user_pass_confirm"><?php echo esc_html__('Confirm Password', 'vira-store'); ?> <span class="required">*</span></label>
                        </th>
                        <td>
                            <input type="password" id="user_pass_confirm" name="user_pass_confirm" value="" class="regular-text" required>
                            <p class="description"><?php echo esc_html__('Re-enter the password to confirm.', 'vira-store'); ?></p>
                        </td>
                    </tr>
                </table>
            </div>
            
            <!-- Basic Information -->
            <div class="add-section">
                <h3><?php echo esc_html__('Basic Information', 'vira-store'); ?></h3>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="first_name"><?php echo esc_html__('First Name', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="first_name" name="first_name" value="" class="regular-text">
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="last_name"><?php echo esc_html__('Last Name', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="last_name" name="last_name" value="" class="regular-text">
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="display_name"><?php echo esc_html__('Display Name', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="display_name" name="display_name" value="" class="regular-text">
                            <p class="description"><?php echo esc_html__('The name displayed publicly. If left empty, will be generated from first and last name.', 'vira-store'); ?></p>
                        </td>
                    </tr>
                </table>
            </div>
            
            <!-- Account Settings -->
            <div class="add-section">
                <h3><?php echo esc_html__('Account Settings', 'vira-store'); ?></h3>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="customer_status"><?php echo esc_html__('Status', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <select id="customer_status" name="customer_status" class="regular-text">
                                <option value="active"><?php echo esc_html__('Active', 'vira-store'); ?></option>
                                <option value="inactive"><?php echo esc_html__('Inactive', 'vira-store'); ?></option>
                                <option value="suspended"><?php echo esc_html__('Suspended', 'vira-store'); ?></option>
                            </select>
                            <p class="description"><?php echo esc_html__('Initial account status for the new customer.', 'vira-store'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="user_role"><?php echo esc_html__('User Role', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <select id="user_role" name="user_role" class="regular-text">
                                <option value="customer" selected><?php echo esc_html__('Customer', 'vira-store'); ?></option>
                                <option value="subscriber"><?php echo esc_html__('Subscriber', 'vira-store'); ?></option>
                                <?php if (current_user_can('promote_users')) : ?>
                                    <option value="editor"><?php echo esc_html__('Editor', 'vira-store'); ?></option>
                                    <option value="administrator"><?php echo esc_html__('Administrator', 'vira-store'); ?></option>
                                <?php endif; ?>
                            </select>
                            <p class="description"><?php echo esc_html__('WordPress user role for this customer.', 'vira-store'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="send_notification"><?php echo esc_html__('Send Welcome Email', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <label>
                                <input type="checkbox" id="send_notification" name="send_notification" value="1" checked>
                                <?php echo esc_html__('Send welcome email with login credentials to the customer', 'vira-store'); ?>
                            </label>
                        </td>
                    </tr>
                </table>
            </div>
            
            <!-- Contact Information -->
            <div class="add-section">
                <h3><?php echo esc_html__('Contact Information', 'vira-store'); ?></h3>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="billing_phone"><?php echo esc_html__('Phone Number', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <input type="tel" id="billing_phone" name="billing_phone" value="" class="regular-text">
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="billing_company"><?php echo esc_html__('Company', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="billing_company" name="billing_company" value="" class="regular-text">
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="billing_address_1"><?php echo esc_html__('Address Line 1', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="billing_address_1" name="billing_address_1" value="" class="regular-text">
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="billing_address_2"><?php echo esc_html__('Address Line 2', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="billing_address_2" name="billing_address_2" value="" class="regular-text">
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="billing_city"><?php echo esc_html__('City', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="billing_city" name="billing_city" value="" class="regular-text">
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="billing_state"><?php echo esc_html__('State/Province', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="billing_state" name="billing_state" value="" class="regular-text">
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="billing_postcode"><?php echo esc_html__('Postal Code', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="billing_postcode" name="billing_postcode" value="" class="regular-text">
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="billing_country"><?php echo esc_html__('Country', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="billing_country" name="billing_country" value="" class="regular-text">
                        </td>
                    </tr>
                </table>
            </div>
            
            <!-- Customer Notes -->
            <div class="add-section">
                <h3><?php echo esc_html__('Customer Notes', 'vira-store'); ?></h3>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="customer_notes"><?php echo esc_html__('Admin Notes', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <textarea id="customer_notes" name="customer_notes" rows="5" class="large-text"></textarea>
                            <p class="description"><?php echo esc_html__('Internal notes about this customer (not visible to customer).', 'vira-store'); ?></p>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        
        <p class="submit">
            <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php echo esc_attr__('Add Customer', 'vira-store'); ?>">
            <a href="<?php echo esc_url(admin_url('admin.php?page=vrstore-customers')); ?>" class="button">
                <?php echo esc_html__('Cancel', 'vira-store'); ?>
            </a>
        </p>
    </form>
</div>