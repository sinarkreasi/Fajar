<?php
/**
 * Customer Detail View
 * 
 * @package Vira_Store
 * @since 1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

$customer_id = isset($_GET['customer_id']) ? intval($_GET['customer_id']) : 0;
$customer = $customer ?? null;
$orders = $orders ?? [];
$licenses = $licenses ?? [];

if (!$customer) {
    echo '<div class="notice notice-error"><p>' . esc_html__('Customer not found.', 'vira-store') . '</p></div>';
    return;
}
?>

<div class="wrap">
    <h1 class="wp-heading-inline">
        <?php echo esc_html__('Customer Details', 'vira-store'); ?>
        <span class="customer-name"><?php echo esc_html($customer['display_name']); ?></span>
    </h1>
    
    <a href="<?php echo esc_url(admin_url('admin.php?page=vrstore-customers')); ?>" class="page-title-action">
        <?php echo esc_html__('← Back to Customers', 'vira-store'); ?>
    </a>
    
    <a href="<?php echo esc_url(admin_url('admin.php?page=vrstore-customers&action=edit&customer_id=' . $customer_id)); ?>" class="page-title-action">
        <?php echo esc_html__('Edit Customer', 'vira-store'); ?>
    </a>
    
    <hr class="wp-header-end">
    
    <!-- Customer Information Cards -->
    <div class="customer-detail-cards">
        <div class="customer-info-card">
            <h3><?php echo esc_html__('Customer Information', 'vira-store'); ?></h3>
            <table class="form-table">
                <tr>
                    <th scope="row"><?php echo esc_html__('Name', 'vira-store'); ?></th>
                    <td><?php echo esc_html($customer['display_name']); ?></td>
                </tr>
                <tr>
                    <th scope="row"><?php echo esc_html__('Email', 'vira-store'); ?></th>
                    <td><a href="mailto:<?php echo esc_attr($customer['user_email']); ?>"><?php echo esc_html($customer['user_email']); ?></a></td>
                </tr>
                <tr>
                    <th scope="row"><?php echo esc_html__('Username', 'vira-store'); ?></th>
                    <td><?php echo esc_html($customer['user_login']); ?></td>
                </tr>
                <tr>
                    <th scope="row"><?php echo esc_html__('Registration Date', 'vira-store'); ?></th>
                    <td><?php echo esc_html(date_i18n(get_option('date_format'), strtotime($customer['user_registered']))); ?></td>
                </tr>
                <tr>
                    <th scope="row"><?php echo esc_html__('Status', 'vira-store'); ?></th>
                    <td>
                        <span class="customer-status status-<?php echo esc_attr($customer['status']); ?>">
                            <?php echo esc_html(ucfirst($customer['status'])); ?>
                        </span>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php echo esc_html__('Total Orders', 'vira-store'); ?></th>
                    <td><?php echo esc_html($customer['total_orders']); ?></td>
                </tr>
                <tr>
                    <th scope="row"><?php echo esc_html__('Total Licenses', 'vira-store'); ?></th>
                    <td><?php echo esc_html($customer['total_licenses']); ?></td>
                </tr>
                <tr>
                    <th scope="row"><?php echo esc_html__('Total Spent', 'vira-store'); ?></th>
                    <td>
                        <?php 
                        // Display total spent
                        if (class_exists('VRSTORE_Product') && class_exists('VRSTORE_Settings')) {
                            $product_instance = VRSTORE_Product::get_instance();
                            $settings_instance = VRSTORE_Settings::get_instance();
                            $global_currency = $settings_instance->get_setting('currency', 'USD');
                            $formatted_total = $product_instance->format_price($customer['total_spent'], $global_currency);
                            echo esc_html($formatted_total);
                        } else {
                            // Fallback if classes not available
                            $global_currency = get_option('vrstore_settings', [])['currency'] ?? 'USD';
                            echo esc_html($global_currency . ' ' . number_format($customer['total_spent'], 2));
                        }
                        ?>
                    </td>
                </tr>
                <?php 
                $phone = get_user_meta($customer_id, 'billing_phone', true);
                $city = get_user_meta($customer_id, 'billing_city', true);
                if (!empty($phone)) : ?>
                <tr>
                    <th scope="row"><?php echo esc_html__('Phone Number', 'vira-store'); ?></th>
                    <td><?php echo esc_html($phone); ?></td>
                </tr>
                <?php endif; ?>
                <?php if (!empty($city)) : ?>
                <tr>
                    <th scope="row"><?php echo esc_html__('City', 'vira-store'); ?></th>
                    <td><?php echo esc_html($city); ?></td>
                </tr>
                <?php endif; ?>
            </table>
        </div>
        
        <div class="customer-stats-card">
            <h3><?php echo esc_html__('Customer Statistics', 'vira-store'); ?></h3>
            <div class="stats-grid">
                <div class="stat-item">
                    <span class="stat-number"><?php echo esc_html($customer['total_orders']); ?></span>
                    <span class="stat-label"><?php echo esc_html__('Orders', 'vira-store'); ?></span>
                </div>
                <div class="stat-item">
                    <span class="stat-number"><?php echo esc_html($customer['total_licenses']); ?></span>
                    <span class="stat-label"><?php echo esc_html__('Licenses', 'vira-store'); ?></span>
                </div>
                <div class="stat-item">
                    <span class="stat-number">
                        <?php 
                        // Display total spent
                        if (class_exists('VRSTORE_Product') && class_exists('VRSTORE_Settings')) {
                            $product_instance = VRSTORE_Product::get_instance();
                            $settings_instance = VRSTORE_Settings::get_instance();
                            $global_currency = $settings_instance->get_setting('currency', 'USD');
                            $formatted_total = $product_instance->format_price($customer['total_spent'], $global_currency);
                            echo esc_html($formatted_total);
                        } else {
                            // Fallback if classes not available
                            $global_currency = get_option('vrstore_settings', [])['currency'] ?? 'USD';
                            echo esc_html($global_currency . ' ' . number_format($customer['total_spent'], 2));
                        }
                        ?>
                    </span>
                    <span class="stat-label"><?php echo esc_html__('Total Spent', 'vira-store'); ?></span>
                </div>
                <div class="stat-item">
                    <span class="stat-number"><?php echo esc_html($customer['active_licenses']); ?></span>
                    <span class="stat-label"><?php echo esc_html__('Active Licenses', 'vira-store'); ?></span>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Customer Orders -->
    <div class="customer-orders-section">
        <h3><?php echo esc_html__('Recent Orders', 'vira-store'); ?></h3>
        <?php if (!empty($orders)) : ?>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th scope="col"><?php echo esc_html__('Order', 'vira-store'); ?></th>
                        <th scope="col"><?php echo esc_html__('Date', 'vira-store'); ?></th>
                        <th scope="col"><?php echo esc_html__('Product', 'vira-store'); ?></th>
                        <th scope="col"><?php echo esc_html__('Total', 'vira-store'); ?></th>
                        <th scope="col"><?php echo esc_html__('Status', 'vira-store'); ?></th>
                        <th scope="col"><?php echo esc_html__('Invoice', 'vira-store'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $order) : ?>
                        <tr>
                            <td>
                                <strong>
                                    <a href="<?php echo esc_url(admin_url('admin.php?page=vrstore-orders&search=' . urlencode($order['order_id'] ?? 'N/A'))); ?>">
                                        <?php echo esc_html($order['order_id'] ?? 'N/A'); ?>
                                    </a>
                                </strong>
                            </td>
                            <td>
                                <?php 
                                if (!empty($order['date'])) {
                                    echo esc_html(date_i18n(get_option('date_format'), strtotime($order['date'])));
                                } else {
                                    echo esc_html__('N/A', 'vira-store');
                                }
                                ?>
                            </td>
                            <td><?php echo esc_html($order['product_title'] ?? ($order['product_name'] ?? 'Unknown Product')); ?></td>
                            <td>
                                <?php 
                                // Use order-specific currency (fallback to global)
                                if (class_exists('VRSTORE_Product') && class_exists('VRSTORE_Settings')) {
                                    $product_instance = VRSTORE_Product::get_instance();
                                    $settings_instance = VRSTORE_Settings::get_instance();
                                    $global_currency = $settings_instance->get_setting('currency', 'USD');
                                    
                                    // Use order currency if available, fallback to global currency
                                    $order_currency = !empty($order['currency']) ? $order['currency'] : $global_currency;
                                    $formatted_total = $product_instance->format_price($order['total'] ?? 0, $order_currency);
                                    echo esc_html($formatted_total);
                                } else {
                                    // Fallback if classes not available
                                    $settings = get_option('vrstore_settings', []);
                                    
                                    // Try to use order currency first
                                    if (!empty($order['currency'])) {
                                        // Use order-specific currency if available
                                        $currency_symbol = $order['currency']; // Simple fallback
                                        $currency_position = 'left'; // Default position
                                    } else {
                                        // Use global settings
                                        $currency_symbol = $settings['currency_symbol'] ?? '$';
                                        $currency_position = $settings['currency_position'] ?? 'left';
                                    }
                                    
                                    $formatted_price = number_format((float) ($order['total'] ?? 0), 2);
                                    if ($currency_position === 'left') {
                                        echo esc_html($currency_symbol . $formatted_price);
                                    } else {
                                        echo esc_html($formatted_price . $currency_symbol);
                                    }
                                }
                                ?>
                            </td>
                            <td>
                                <span class="order-status status-<?php echo esc_attr(strtolower($order['status'] ?? 'unknown')); ?>">
                                    <?php echo esc_html(ucfirst($order['status'] ?? 'Unknown')); ?>
                                </span>
                            </td>
                            <td>
                                <?php 
                                // Only show invoice actions for completed orders
                                if ('completed' === strtolower($order['payment_status'] ?? '') && 'completed' === strtolower($order['order_status'] ?? '')) :
                                    // Check if Invoice class is available
                                    if (class_exists('VRSTORE_Invoice')):
                                        $invoice_instance = VRSTORE_Invoice::get_instance();
                                    // Get the actual order ID for invoice generation
                                        $order_id_for_invoice = null;
                                        // Check if we have numeric order ID or need to find it by order number
                                        if (isset($order['order_id']) && is_numeric($order['order_id'])) {
                                            $order_id_for_invoice = intval($order['order_id']);
                                        } else {
                                            // Find order ID by order number
                                            global $wpdb;
                                            $orders_table = $wpdb->prefix . 'vrstore_orders';
                                            $order_record = $wpdb->get_row($wpdb->prepare(
                                                "SELECT id FROM $orders_table WHERE order_number = %s",
                                                $order['order_id']
                                            ));
                                            if ($order_record) {
                                                $order_id_for_invoice = intval($order_record->id);
                                            }
                                        }
                                        
                                        if ($order_id_for_invoice):
                                            $view_url = $invoice_instance->get_invoice_url($order_id_for_invoice, 'view');
                                            $download_url = $invoice_instance->get_invoice_url($order_id_for_invoice, 'download');
                                        ?>
                                            <div class="vrstore-invoice-actions">
                                                <a href="<?php echo esc_url($view_url); ?>" class="vrstore-btn vrstore-btn-sm vrstore-btn-secondary" target="_blank" title="<?php esc_attr_e('View Invoice', 'vira-store'); ?>">
                                                    <span class="dashicons dashicons-visibility"></span>
                                                </a>
                                                <a href="<?php echo esc_url($download_url); ?>" class="vrstore-btn vrstore-btn-sm vrstore-btn-primary" title="<?php esc_attr_e('Download Invoice', 'vira-store'); ?>">
                                                    <span class="dashicons dashicons-download"></span>
                                                </a>
                                            </div>
                                        <?php 
                                        else:
                                        ?>
                                            <span class="na"><?php esc_html_e('N/A', 'vira-store'); ?></span>
                                        <?php 
                                        endif;
                                    else:
                                    ?>
                                        <span class="na"><?php esc_html_e('N/A', 'vira-store'); ?></span>
                                    <?php 
                                    endif;
                                else:
                                ?>
                                    <span class="pending"><?php esc_html_e('Pending', 'vira-store'); ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else : ?>
            <div class="notice notice-info inline">
                <p><?php echo esc_html__('No orders found for this customer.', 'vira-store'); ?></p>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Customer Licenses -->
    <div class="customer-licenses-section">
        <h3><?php echo esc_html__('Customer Licenses', 'vira-store'); ?></h3>
        <?php 
        // Only check for actual licenses, not products without licenses
        $has_actual_licenses = !empty($licenses) && is_array($licenses);
        ?>
        
        <?php if ($has_actual_licenses) : ?>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th scope="col"><?php echo esc_html__('Product', 'vira-store'); ?></th>
                        <th scope="col"><?php echo esc_html__('License Key', 'vira-store'); ?></th>
                        <th scope="col"><?php echo esc_html__('License Type', 'vira-store'); ?></th>
                        <th scope="col"><?php echo esc_html__('Status', 'vira-store'); ?></th>
                        <th scope="col"><?php echo esc_html__('Activations', 'vira-store'); ?></th>
                        <th scope="col"><?php echo esc_html__('Expiry Date', 'vira-store'); ?></th>
                        <th scope="col"><?php echo esc_html__('Actions', 'vira-store'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($licenses) && is_array($licenses)) : ?>
                        <?php foreach ($licenses as $license) : ?>
                            <tr>
                                <td><?php echo esc_html($license['product_title'] ?? ($license['product_name'] ?? 'Unknown Product')); ?></td>
                                <td>
                                    <div class="license-key-wrapper">
                                        <code class="license-key-display" title="<?php echo esc_attr($license['license_key']); ?>" style="font-family: monospace; background: #f0f0f0; padding: 2px 4px; border-radius: 3px;">
                                            <?php echo esc_html($license['license_key'] ?? ''); ?>
                                        </code>
                                        <?php if (!empty($license['license_key'])) : ?>
                                            <button class="button button-small copy-license-key" data-license-key="<?php echo esc_attr($license['license_key']); ?>" title="<?php esc_attr_e('Copy license key', 'vira-store'); ?>" style="margin-left: 5px;">
                                                <span class="dashicons dashicons-clipboard"></span>
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td>
                                    <?php 
                                    // Display license type
                                    $license_type_slug = $license['license_type_slug'] ?? '';
                                    if (!empty($license_type_slug)) {
                                        // Get license type label from settings
                                        $vrstore_settings = get_option('vrstore_settings', array());
                                        $custom_license_types = isset($vrstore_settings['custom_license_types']) && is_array($vrstore_settings['custom_license_types']) ? $vrstore_settings['custom_license_types'] : array();
                                        
                                        $license_type_label = ucfirst(str_replace('_', ' ', $license_type_slug));
                                        
                                        // Find the proper label from custom license types
                                        foreach ($custom_license_types as $type) {
                                            if (($type['slug'] ?? '') === $license_type_slug) {
                                                $license_type_label = $type['label'] ?? $license_type_label;
                                                break;
                                            }
                                        }
                                        
                                        echo '<span class="license-type license-type-' . esc_attr($license_type_slug) . '">' . esc_html($license_type_label) . '</span>';
                                    } else {
                                        echo '<span class="license-type license-type-custom">Custom License</span>';
                                    }
                                    ?>
                                </td>
                                <td>
                                    <span class="license-status status-<?php echo esc_attr(strtolower($license['status'] ?? 'unknown')); ?>">
                                        <?php echo esc_html($license['status'] ?? 'Unknown'); ?>
                                    </span>
                                </td>
                                <td>
                                    <?php
                                    $activations = !empty($license['activations']) ? count($license['activations']) : ($license['activation_count'] ?? 0);
                                    $activation_limit = !empty($license['activation_limit']) ? $license['activation_limit'] : 0;
                                    
                                    if ($activation_limit > 0) {
                                        printf(esc_html__('%1$d / %2$d', 'vira-store'), $activations, $activation_limit);
                                    } else {
                                        printf(esc_html__('%d (Unlimited)', 'vira-store'), $activations);
                                    }
                                    ?>
                                </td>
                                <td>
                                    <?php
                                    // Check for expiry date - prioritize expires_at (database field) over expiry_date (alias)
                                    $expiry_date = $license['expires_at'] ?? $license['expiry_date'] ?? null;
                                    
                                    if (!empty($expiry_date) && $expiry_date !== '0000-00-00 00:00:00' && $expiry_date !== '0000-00-00') {
                                        $expiry_timestamp = strtotime($expiry_date);
                                        if ($expiry_timestamp && $expiry_timestamp !== false) {
                                            echo esc_html(date_i18n(get_option('date_format'), $expiry_timestamp));
                                            // Show expiry status
                                            if ($expiry_timestamp < time()) {
                                                echo ' <span class="expired" style="color: #dc3232; font-weight: bold;">' . esc_html__('(Expired)', 'vira-store') . '</span>';
                                            } elseif ($expiry_timestamp < strtotime('+30 days')) {
                                                echo ' <span class="expiring-soon" style="color: #d68500; font-weight: bold;">' . esc_html__('(Expiring Soon)', 'vira-store') . '</span>';
                                            }
                                        } else {
                                            echo '<span class="never">' . esc_html__('Never', 'vira-store') . '</span>';
                                        }
                                    } else {
                                        echo '<span class="never">' . esc_html__('Never', 'vira-store') . '</span>';
                                    }
                                    ?>
                                </td>
                                <td>
                                    <a href="<?php echo esc_url(admin_url('admin.php?page=vrstore-licenses&action=view&license_id=' . $license['id'])); ?>" class="button button-small">
                                        <?php echo esc_html__('View', 'vira-store'); ?>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        <?php else : ?>
            <div class="notice notice-info inline">
                <p><?php echo esc_html__('No licenses found for this customer. Purchase a product to get your first license!', 'vira-store'); ?></p>
            </div>
        <?php endif; ?>
    </div>
</div>