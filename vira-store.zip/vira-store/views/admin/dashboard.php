<?php
/**
 * Dashboard Admin Page Template
 *
 * @package Vira_Store
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Get settings instance
$settings = VRSTORE_Settings::get_instance();
$product = VRSTORE_Product::get_instance();
?>
<div class="wrap">
    <h1 class="wp-heading-inline"><?php _e('Dashboard', 'vira-store'); ?></h1>
    
    <div class="vrstore-dashboard">
        <!-- Dashboard Stats -->
        <div class="vrstore-stats-cards">
            <div class="vrstore-stats-card">
                <div class="card-icon">
                    <span class="dashicons dashicons-products"></span>
                </div>
                <div class="card-content">
                    <h3><?php echo esc_html($stats['total_products']); ?></h3>
                    <p><?php _e('Total Products', 'vira-store'); ?></p>
                </div>
            </div>
            
            <div class="vrstore-stats-card">
                <div class="card-icon">
                    <span class="dashicons dashicons-cart"></span>
                </div>
                <div class="card-content">
                    <h3><?php echo esc_html($stats['total_orders']); ?></h3>
                    <p><?php _e('Total Orders', 'vira-store'); ?></p>
                </div>
            </div>
            
            <div class="vrstore-stats-card">
                <div class="card-icon">
                    <span class="dashicons dashicons-money-alt"></span>
                </div>
                <div class="card-content">
                    <h3>
                        <?php 
                        // Total sales for admin dashboard - handle Extended Support properly
                        echo esc_html($settings->format_admin_extended_support_price($stats['total_sales'], true));
                        ?>
                    </h3>
                    <p><?php _e('Total Sales', 'vira-store'); ?></p>
                </div>
            </div>
            
            <div class="vrstore-stats-card">
                <div class="card-icon">
                    <span class="dashicons dashicons-admin-network"></span>
                </div>
                <div class="card-content">
                    <h3><?php echo esc_html($stats['active_licenses']); ?>/<?php echo esc_html($stats['total_licenses']); ?></h3>
                    <p><?php _e('Active Licenses', 'vira-store'); ?></p>
                </div>
            </div>
        </div>

        <!-- Dashboard Tables -->
        <div class="vrstore-dashboard-content">
            <!-- Recent Orders -->
            <div class="vrstore-dashboard-widget">
                <h3><?php _e('Recent Orders', 'vira-store'); ?></h3>
                <?php if (!empty($stats['recent_orders'])) : ?>
                    <div class="vrstore-licenses-table">
                        <table class="wp-list-table widefat fixed striped">
                            <thead>
                                <tr>
                                    <th scope="col"><?php _e('Order #', 'vira-store'); ?></th>
                                    <th scope="col"><?php _e('Customer', 'vira-store'); ?></th>
                                    <th scope="col"><?php _e('Type', 'vira-store'); ?></th>
                                    <th scope="col"><?php _e('Amount', 'vira-store'); ?></th>
                                    <th scope="col"><?php _e('Status', 'vira-store'); ?></th>
                                    <th scope="col"><?php _e('Date', 'vira-store'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($stats['recent_orders'] as $order) : 
                                    // Get admin menu instance to access helper method
                                    $admin_menu = VRSTORE_Admin_Menu::get_instance();
                                    $item_info = $admin_menu->get_item_type_and_tooltip($order['product_id'], $order['product_name']);
                                ?>
                                    <tr>
                                        <td><?php echo esc_html($order['order_number']); ?></td>
                                        <td><?php echo esc_html($order['customer_email']); ?></td>
                                        <td>
                                            <div class="vrstore-tooltip">
                                                <span class="vrstore-item-type">
                                                    <?php echo esc_html($item_info['type']); ?>
                                                </span>
                                                <span class="vrstore-tooltiptext"><?php echo esc_html($item_info['tooltip']); ?></span>
                                            </div>
                                        </td>
                                        <td>
                                            <?php 
                                            // Admin dashboard - handle Extended Support properly
                                            echo esc_html($settings->format_admin_extended_support_price($order['product_price'], true));
                                            ?>
                                        </td>
                                        <td>
                                            <span class="license-status license-status-<?php echo esc_attr($order['order_status']); ?>">
                                                <?php echo esc_html(ucfirst($order['order_status'])); ?>
                                            </span>
                                        </td>
                                        <td><?php echo esc_html(mysql2date('M j, Y', $order['created_at'])); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else : ?>
                    <div class="vrstore-empty-state">
                        <span class="dashicons dashicons-cart"></span>
                        <h3><?php _e('No Orders Yet', 'vira-store'); ?></h3>
                        <p><?php _e('No orders found.', 'vira-store'); ?></p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Top Products -->
            <div class="vrstore-dashboard-widget">
                <h3><?php _e('Top Products', 'vira-store'); ?></h3>
                <?php if (!empty($stats['top_products'])) : ?>
                    <div class="vrstore-licenses-table">
                        <table class="wp-list-table widefat fixed striped">
                            <thead>
                                <tr>
                                    <th scope="col"><?php _e('Orders', 'vira-store'); ?></th>
                                    <th scope="col"><?php _e('Type', 'vira-store'); ?></th>
                                    <th scope="col"><?php _e('Total Sales', 'vira-store'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($stats['top_products'] as $product_stat) : 
                                    // Get admin menu instance to access helper method
                                    $admin_menu = VRSTORE_Admin_Menu::get_instance();
                                    $item_info = $admin_menu->get_item_type_and_tooltip($product_stat['product_id'], $product_stat['product_name']);
                                ?>
                                    <tr>
                                        <td><?php echo esc_html($product_stat['order_count']); ?></td>
                                        <td>
                                            <div class="vrstore-tooltip">
                                                <span class="vrstore-item-type">
                                                    <?php echo esc_html($item_info['type']); ?>
                                                </span>
                                                <span class="vrstore-tooltiptext"><?php echo esc_html($item_info['tooltip']); ?></span>
                                            </div>
                                        </td>
                                        <td>
                            <?php 
                            // Top product sales - handle Extended Support properly
                            echo esc_html($settings->format_admin_extended_support_price($product_stat['total_sales'], true));
                            ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else : ?>
                    <div class="vrstore-empty-state">
                        <span class="dashicons dashicons-products"></span>
                        <h3><?php _e('No Product Data', 'vira-store'); ?></h3>
                        <p><?php _e('No product sales data available.', 'vira-store'); ?></p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Affiliates Summary -->
            <div class="vrstore-dashboard-widget">
                <h3><?php _e('Affiliates Report Summary', 'vira-store'); ?></h3>
                <div class="vrstore-stats-cards">
                    <div class="vrstore-stats-card">
                        <div class="card-icon">
                            <span class="dashicons dashicons-groups"></span>
                        </div>
                        <div class="card-content">
                            <h3><?php echo esc_html($stats['total_affiliates']); ?></h3>
                            <p><?php _e('Total Affiliates', 'vira-store'); ?></p>
                        </div>
                    </div>
                    
                    <div class="vrstore-stats-card">
                        <div class="card-icon">
                            <span class="dashicons dashicons-yes-alt"></span>
                        </div>
                        <div class="card-content">
                            <h3><?php echo esc_html($stats['active_affiliates']); ?></h3>
                            <p><?php _e('Active Affiliates', 'vira-store'); ?></p>
                        </div>
                    </div>
                                       
                    <div class="vrstore-stats-card">
                        <div class="card-icon">
                            <span class="dashicons dashicons-money-alt"></span>
                        </div>
                        <div class="card-content">
                            <h3>
                                <?php 
                                echo esc_html($settings->format_admin_extended_support_price($stats['total_affiliate_commissions'], true));
                                ?>
                            </h3>
                            <p><?php _e('Total Payouts', 'vira-store'); ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Domain Activations Summary -->
            <div class="vrstore-dashboard-widget">
                <h3><?php _e('Domain Activations Summary', 'vira-store'); ?></h3>
                <div class="vrstore-stats-cards">
                    <div class="vrstore-stats-card">
                        <div class="card-icon">
                            <span class="dashicons dashicons-admin-site-alt3"></span>
                        </div>
                        <div class="card-content">
                            <h3><?php echo esc_html($stats['total_domain_activations']); ?></h3>
                            <p><?php _e('Total Activations', 'vira-store'); ?></p>
                        </div>
                    </div>
                    
                    <div class="vrstore-stats-card">
                        <div class="card-icon">
                            <span class="dashicons dashicons-yes-alt"></span>
                        </div>
                        <div class="card-content">
                            <h3><?php echo esc_html($stats['active_domain_activations']); ?></h3>
                            <p><?php _e('Active Domains', 'vira-store'); ?></p>
                        </div>
                    </div>
                    
                    <div class="vrstore-stats-card">
                        <div class="card-icon">
                            <span class="dashicons dashicons-dismiss"></span>
                        </div>
                        <div class="card-content">
                            <h3><?php echo esc_html($stats['inactive_domain_activations']); ?></h3>
                            <p><?php _e('Inactive Domains', 'vira-store'); ?></p>
                        </div>
                    </div>
                </div>
                
                <?php if (!empty($stats['recent_domain_activations'])) : ?>
                    <h4><?php _e('Recent Domain Activations', 'vira-store'); ?></h4>
                    <div class="vrstore-licenses-table">
                        <table class="wp-list-table widefat fixed striped">
                            <thead>
                                <tr>
                                    <th scope="col"><?php _e('Domain', 'vira-store'); ?></th>
                                    <th scope="col"><?php _e('License Key', 'vira-store'); ?></th>
                                    <th scope="col"><?php _e('Customer', 'vira-store'); ?></th>
                                    <th scope="col"><?php _e('Status', 'vira-store'); ?></th>
                                    <th scope="col"><?php _e('Activated', 'vira-store'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($stats['recent_domain_activations'] as $activation) : ?>
                                    <tr>
                                        <td><?php echo esc_html($activation['domain']); ?></td>
                                        <td><code><?php echo esc_html(substr($activation['license_key'], 0, 20) . '...'); ?></code></td>
                                        <td><?php echo esc_html($activation['customer_email'] ?? 'N/A'); ?></td>
                                        <td>
                                            <span class="license-status license-status-<?php echo esc_attr($activation['status']); ?>">
                                                <?php echo esc_html(ucfirst($activation['status'])); ?>
                                            </span>
                                        </td>
                                        <td><?php echo esc_html(mysql2date('M j, Y', $activation['activated_at'])); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else : ?>
                <?php endif; ?>
            </div>
        </div>
