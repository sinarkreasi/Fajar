<?php
/**
 * Licenses Admin Page Template
 *
 * @package Vira_Store
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}
?>
<div class="wrap">
    <h1 class="wp-heading-inline"><?php _e('Licenses', 'vira-store'); ?></h1>
    <a href="#" class="page-title-action" id="vrstore-generate-license"><?php _e('Generate License', 'vira-store'); ?></a>
    
    <div class="vrstore-licenses-page">
        <!-- License Stats -->
        <div class="vrstore-license-stats">
            <div class="license-stat-card">
                <div class="stat-number"><?php echo esc_html($licenses['total']); ?></div>
                <div class="stat-label"><?php _e('Total Licenses', 'vira-store'); ?></div>
            </div>
            <div class="license-stat-card">
                <div class="stat-number"><?php echo esc_html($licenses['active']); ?></div>
                <div class="stat-label"><?php _e('Active Licenses', 'vira-store'); ?></div>
            </div>
            <div class="license-stat-card">
                <div class="stat-number"><?php echo esc_html($licenses['inactive']); ?></div>
                <div class="stat-label"><?php _e('Inactive Licenses', 'vira-store'); ?></div>
            </div>
            <div class="license-stat-card">
                <div class="stat-number"><?php echo esc_html($licenses['expired']); ?></div>
                <div class="stat-label"><?php _e('Expired Licenses', 'vira-store'); ?></div>
            </div>
        </div>

        <!-- Licenses Table -->
        <div class="vrstore-licenses-table">
            <?php if (!empty($licenses['licenses'])) : ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th scope="col"><?php _e('License Key', 'vira-store'); ?></th>
                            <th scope="col"><?php _e('Product', 'vira-store'); ?></th>
                            <th scope="col"><?php _e('License Type', 'vira-store'); ?></th>
                            <th scope="col"><?php _e('Customer', 'vira-store'); ?></th>
                            <th scope="col"><?php _e('Status', 'vira-store'); ?></th>
                            <th scope="col"><?php _e('Activations', 'vira-store'); ?></th>
                            <th scope="col"><?php _e('Created', 'vira-store'); ?></th>
                            <th scope="col"><?php _e('Actions', 'vira-store'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($licenses['licenses'] as $license) : ?>
                            <tr>
                                <td>
                                    <code><?php echo esc_html($license['license_key']); ?></code>
                                </td>
                                <td>
                                    <?php if ($license['product_name']) : ?>
                                        <strong><?php echo esc_html($license['product_name']); ?></strong>
                                    <?php else : ?>
                                        <em><?php _e('Product not found', 'vira-store'); ?></em>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php 
                                    // Display license type
                                    $license_type_slug = $license['license_type_slug'] ?? '';
                                    if (!empty($license_type_slug)) {
                                        // Get license type label from settings
                                        $settings = get_option('vrstore_settings', array());
                                        $custom_license_types = isset($settings['custom_license_types']) && is_array($settings['custom_license_types']) ? $settings['custom_license_types'] : array();
                                        
                                        $license_type_label = ucfirst(str_replace('_', ' ', $license_type_slug));
                                        
                                        // Find the proper label from custom license types
                                        foreach ($custom_license_types as $type) {
                                            if (($type['slug'] ?? '') === $license_type_slug) {
                                                $license_type_label = $type['label'] ?? $license_type_label;
                                                break;
                                            }
                                        }
                                        
                                        echo '<span class="license-type-badge license-type-' . esc_attr($license_type_slug) . '">' . esc_html($license_type_label) . '</span>';
                                    } else {
                                        echo '<span class="license-type-badge license-type-custom">Custom License</span>';
                                    }
                                    ?>
                                </td>
                                <td>
                                    <?php echo esc_html($license['customer_email']); ?>
                                </td>
                                <td>
                                    <span class="license-status license-status-<?php echo esc_attr($license['status']); ?>">
                                        <?php echo esc_html(ucfirst($license['status'])); ?>
                                    </span>
                                </td>
                                <td>
                                    <?php echo esc_html($license['activation_count']); ?>
                                    <?php if ($license['activation_limit'] > 0) : ?>
                                        / <?php echo esc_html($license['activation_limit']); ?>
                                    <?php else : ?>
                                        / <?php _e('Unlimited', 'vira-store'); ?>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo esc_html(mysql2date('M j, Y', $license['created_at'])); ?>
                                </td>
                                <td>
                                    <div class="row-actions">
                                        <?php if ($license['status'] === 'active') : ?>
                                            <a href="<?php echo wp_nonce_url(
                                                admin_url('admin.php?page=vrstore-licenses&action=deactivate&license_id=' . $license['id']),
                                                'vrstore_license_action'
                                            ); ?>" class="vrstore-license-action" data-action="deactivate">
                                                <?php _e('Deactivate', 'vira-store'); ?>
                                            </a> |
                                        <?php else : ?>
                                            <a href="<?php echo wp_nonce_url(
                                                admin_url('admin.php?page=vrstore-licenses&action=activate&license_id=' . $license['id']),
                                                'vrstore_license_action'
                                            ); ?>" class="vrstore-license-action" data-action="activate">
                                                <?php _e('Activate', 'vira-store'); ?>
                                            </a> |
                                        <?php endif; ?>
                                        <a href="#" class="vrstore-view-license" data-license-id="<?php echo esc_attr($license['id']); ?>">
                                            <?php _e('View Details', 'vira-store'); ?>
                                        </a> |
                                        <a href="<?php echo wp_nonce_url(
                                            admin_url('admin.php?page=vrstore-licenses&action=delete&license_id=' . $license['id']),
                                            'vrstore_license_action'
                                        ); ?>" class="vrstore-license-action delete-license" data-action="delete">
                                            <?php _e('Delete', 'vira-store'); ?>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <!-- Pagination -->
                <?php
                $total_pages = ceil($licenses['total'] / 20);
                $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
                
                if ($total_pages > 1) :
                ?>
                    <div class="tablenav">
                        <div class="tablenav-pages">
                            <?php
                            echo paginate_links([
                                'base' => add_query_arg('paged', '%#%'),
                                'format' => '',
                                'prev_text' => '&laquo;',
                                'next_text' => '&raquo;',
                                'total' => $total_pages,
                                'current' => $current_page
                            ]);
                            ?>
                        </div>
                    </div>
                <?php endif; ?>
            <?php else : ?>
                <div class="vrstore-empty-state">
                    <p><?php _e('No licenses found.', 'vira-store'); ?></p>
                    <p><?php _e('Licenses will appear here when customers purchase your products.', 'vira-store'); ?></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Generate License Modal -->
<div id="vrstore-generate-license-modal" class="vrstore-modal">
    <div class="vrstore-modal-content">
        <div class="vrstore-modal-header">
            <h2><?php _e('Generate License', 'vira-store'); ?></h2>
            <span class="vrstore-modal-close">&times;</span>
        </div>
        <div class="vrstore-modal-body">
            <form id="vrstore-generate-license-form">
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="product_id"><?php _e('Product', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <select id="product_id" name="product_id" class="regular-text">
                                <option value=""><?php _e('Select a product (optional)', 'vira-store'); ?></option>
                                <?php
                                $products = get_posts([
                                    'post_type' => 'vrstore_product',
                                    'post_status' => 'publish',
                                    'numberposts' => -1,
                                    'orderby' => 'title',
                                    'order' => 'ASC'
                                ]);
                                foreach ($products as $product) :
                                ?>
                                    <option value="<?php echo esc_attr($product->ID); ?>"><?php echo esc_html($product->post_title); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="license_type"><?php _e('License Type', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <select id="license_type" name="license_type" class="regular-text">
                                <option value=""><?php _e('Select license type (optional)', 'vira-store'); ?></option>
                                <?php
                                // Get custom license types from settings
                                $settings = get_option('vrstore_settings', array());
                                $custom_license_types = isset($settings['custom_license_types']) && is_array($settings['custom_license_types']) ? $settings['custom_license_types'] : array();
                                
                                if (!empty($custom_license_types)) {
                                    foreach ($custom_license_types as $license_type) :
                                        $slug = isset($license_type['slug']) ? $license_type['slug'] : sanitize_title($license_type['label']);
                                        $label = $license_type['label'] ?? ucfirst($slug);
                                        $price_info = '';
                                        
                                        // Add price info to label if available
                                        if (isset($license_type['regular_price']) && !empty($license_type['regular_price'])) {
                                            // Get currency symbol from settings
                                            $currency = $settings['currency'] ?? 'USD';
                                            $currency_symbol = '';
                                            
                                            // Get currency symbol based on currency code
                                            switch ($currency) {
                                                case 'USD':
                                                    $currency_symbol = '$';
                                                    break;
                                                case 'EUR':
                                                    $currency_symbol = '€';
                                                    break;
                                                case 'GBP':
                                                    $currency_symbol = '£';
                                                    break;
                                                case 'JPY':
                                                    $currency_symbol = '¥';
                                                    break;
                                                case 'IDR':
                                                    $currency_symbol = 'Rp';
                                                    break;
                                                default:
                                                    $currency_symbol = $currency . ' ';
                                            }
                                            
                                            if (isset($license_type['sale_price']) && !empty($license_type['sale_price'])) {
                                                $price_info = ' - ' . $currency_symbol . number_format($license_type['sale_price'], 2) . ' (Sale)';
                                            } else {
                                                $price_info = ' - ' . $currency_symbol . number_format($license_type['regular_price'], 2);
                                            }
                                        }
                                ?>
                                        <option value="<?php echo esc_attr($slug); ?>"><?php echo esc_html($label . $price_info); ?></option>
                                <?php 
                                    endforeach;
                                } else {
                                    // No custom license types defined - show message to configure
                                    echo '<option value="" disabled>' . (vrstore_is_textdomain_ready() ? esc_html__('No license types configured - please add them in Settings > License', 'vira-store') : esc_html('No license types configured - please add them in Settings > License')) . '</option>';
                                }
                                ?>
                            </select>
                            <p class="description"><?php _e('Select the type of license to generate.', 'vira-store'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="customer_email_select"><?php _e('Customer', 'vira-store'); ?> *</label>
                        </th>
                        <td>
                            <select id="customer_email_select" name="customer_email_select" class="regular-text" required>
                                <option value=""><?php _e('Select a user', 'vira-store'); ?></option>
                                <?php
                                $users = get_users(['fields' => ['ID', 'user_email', 'display_name', 'roles']]);
                                foreach ($users as $user) {
                                    $role = !empty($user->roles) ? ucfirst($user->roles[0]) : __('None', 'vira-store');
                                    $label = esc_html($user->display_name . ' (' . $user->user_email . ') [' . $role . ']');
                                    echo '<option value="' . esc_attr($user->user_email) . '">' . $label . '</option>';
                                }
                                ?>
                            </select>
                            <p class="description"><?php _e('Select the license holder (email and role).', 'vira-store'); ?></p>
                        </td>
                    </tr>
                    <tr id="license-type-info" style="display: none;">
                        <th scope="row">
                            <label><?php _e('License Configuration', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <div id="license-config-display" class="vrstore-license-config-info">
                                <p class="description"><?php _e('Activation limit and expiry date will be set automatically based on the selected license type.', 'vira-store'); ?></p>
                                <div id="license-config-details" style="margin-top: 10px; padding: 10px; background: #f9f9f9; border-left: 4px solid #0073aa; display: none;">
                                    <strong><?php _e('Selected License Type Configuration:', 'vira-store'); ?></strong><br>
                                    <span id="config-activation-limit"></span><br>
                                    <span id="config-expiry-date"></span>
                                </div>
                            </div>
                        </td>
                    </tr>
                </table>
                
                <div class="vrstore-modal-footer">
                    <button type="button" class="button" id="vrstore-cancel-generate"><?php _e('Cancel', 'vira-store'); ?></button>
                    <button type="submit" class="button button-primary" id="vrstore-submit-generate"><?php _e('Generate License', 'vira-store'); ?></button>
                </div>
                
                <div id="vrstore-license-error-help" style="display: none; margin-top: 15px; padding: 10px; background: #fff3cd; border-left: 4px solid #ffc107;">
                    <p><strong><?php _e('Having trouble generating licenses?', 'vira-store'); ?></strong></p>
                    <p><?php _e('If you see database errors, try repairing the database:', 'vira-store'); ?></p>
                    <a href="<?php echo admin_url('admin.php?page=vrstore-settings&tab=tools'); ?>" class="button button-secondary" target="_blank">
                        <?php _e('Database Tools', 'vira-store'); ?>
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- License Details Modal -->
<div id="vrstore-license-modal" class="vrstore-modal">
    <div class="vrstore-modal-content">
        <div class="vrstore-modal-header">
            <h2><?php _e('License Details', 'vira-store'); ?></h2>
            <span class="vrstore-modal-close">&times;</span>
        </div>
        <div class="vrstore-modal-body">
            <div id="vrstore-license-details">
                <!-- License details will be loaded here -->
            </div>
        </div>
    </div>
</div>
