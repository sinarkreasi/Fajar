<?php
/**
 * Coupons admin page template
 *
 * @package Vira_Store
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

$page_title = __('Coupons', 'vira-store');
$add_new_url = admin_url('admin.php?page=vrstore-coupons&action=add');

// Get current filter values
$current_status = sanitize_text_field($_GET['status'] ?? '');
$current_search = sanitize_text_field($_GET['search'] ?? '');
$current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;

// Status filter options
$status_options = [
    '' => __('All Statuses', 'vira-store'),
    'active' => __('Active', 'vira-store'),
    'inactive' => __('Inactive', 'vira-store'),
    'expired' => __('Expired', 'vira-store')
];
?>

<div class="wrap vrstore-admin-page vrstore-coupons-page">
    <div class="vrstore-page-header">
        <h1 class="wp-heading-inline"><?php echo esc_html($page_title); ?></h1>
        <div class="vrstore-page-actions">
            <a href="#" class="button button-primary vrstore-btn-primary" id="add-new-coupon">
                <span class="dashicons dashicons-plus-alt2"></span>
                <?php _e('Add New Coupon', 'vira-store'); ?>
            </a>
        </div>
    </div>
    
    <?php if (!empty($coupons['coupons'])): ?>
        <!-- Filters -->
        <div class="tablenav top">
            <div class="alignleft actions">
                <form method="get" action="">
                    <input type="hidden" name="page" value="vrstore-coupons">
                    
                    <label for="status-filter" class="screen-reader-text"><?php _e('Filter by status', 'vira-store'); ?></label>
                    <select name="status" id="status-filter">
                        <?php foreach ($status_options as $value => $label): ?>
                            <option value="<?php echo esc_attr($value); ?>" <?php selected($current_status, $value); ?>>
                                <?php echo esc_html($label); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    
                    <input type="submit" class="button" value="<?php esc_attr_e('Filter', 'vira-store'); ?>">
                </form>
            </div>
            
            <div class="alignright actions">
                <form method="get" action="">
                    <input type="hidden" name="page" value="vrstore-coupons">
                    <?php if (!empty($current_status)): ?>
                        <input type="hidden" name="status" value="<?php echo esc_attr($current_status); ?>">
                    <?php endif; ?>
                    
                    <label for="coupon-search" class="screen-reader-text"><?php _e('Search coupons', 'vira-store'); ?></label>
                    <input type="search" id="coupon-search" name="search" value="<?php echo esc_attr($current_search); ?>" placeholder="<?php esc_attr_e('Search coupons...', 'vira-store'); ?>">
                    <input type="submit" class="button" value="<?php esc_attr_e('Search', 'vira-store'); ?>">
                </form>
            </div>
        </div>

        <!-- Statistics Cards -->
        <div class="vrstore-stats-cards">
            <div class="vrstore-stat-card">
                <h3><?php _e('Total Coupons', 'vira-store'); ?></h3>
                <div class="stat-number"><?php echo esc_html($coupons['total_items'] ?? 0); ?></div>
            </div>
            <div class="vrstore-stat-card">
                <h3><?php _e('Active Coupons', 'vira-store'); ?></h3>
                <div class="stat-number"><?php echo esc_html(array_sum(array_column(array_filter($coupons['coupons'] ?? [], function($c) { return $c['status'] === 'active'; }), 'id')) ? count(array_filter($coupons['coupons'] ?? [], function($c) { return $c['status'] === 'active'; })) : 0); ?></div>
            </div>
        </div>

        <!-- Coupons Table -->
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th scope="col" class="manage-column column-code"><?php _e('Code', 'vira-store'); ?></th>
                    <th scope="col" class="manage-column column-type"><?php _e('Type', 'vira-store'); ?></th>
                    <th scope="col" class="manage-column column-amount"><?php _e('Amount', 'vira-store'); ?></th>
                    <th scope="col" class="manage-column column-usage"><?php _e('Usage', 'vira-store'); ?></th>
                    <th scope="col" class="manage-column column-expiry"><?php _e('Expires', 'vira-store'); ?></th>
                    <th scope="col" class="manage-column column-status"><?php _e('Status', 'vira-store'); ?></th>
                    <th scope="col" class="manage-column column-actions"><?php _e('Actions', 'vira-store'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($coupons['coupons'] as $coupon): ?>
                    <tr>
                        <td class="column-code">
                            <strong><code><?php echo esc_html($coupon['code']); ?></code></strong>
                            <?php if (!empty($coupon['description'])): ?>
                                <br><em><?php echo esc_html($coupon['description']); ?></em>
                            <?php endif; ?>
                        </td>
                        <td class="column-type">
                            <?php 
                            $type_labels = [
                                'percentage' => __('Percentage', 'vira-store'),
                                'fixed' => __('Fixed Amount', 'vira-store')
                            ];
                            echo esc_html($type_labels[$coupon['discount_type']] ?? $coupon['discount_type']);
                            ?>
                        </td>
                        <td class="column-amount">
                            <?php 
                            if ($coupon['discount_type'] === 'percentage') {
                                echo esc_html($coupon['discount_value']) . '%';
                            } else {
                                // Use proper currency formatting from settings
                                if (class_exists('VRSTORE_Settings')) {
                                    $settings = VRSTORE_Settings::get_instance();
                                    echo esc_html($settings->format_price($coupon['discount_value']));
                                } else {
                                    echo '$' . number_format($coupon['discount_value'], 2);
                                }
                            }
                            ?>
                        </td>
                        <td class="column-usage">
                            <?php 
                            $usage_count = intval($coupon['usage_count'] ?? 0);
                            $usage_limit = intval($coupon['usage_limit'] ?? 0);
                            
                            // Get detailed usage statistics
                            $usage_stats = [];
                            if (class_exists('VRSTORE_Coupon') && $usage_count > 0) {
                                $coupon_class = VRSTORE_Coupon::get_instance();
                                $usage_stats = $coupon_class->get_coupon_usage_stats($coupon['id']);
                            }
                            
                            // Display usage count with limit
                            if ($usage_limit > 0) {
                                $usage_percentage = ($usage_count / $usage_limit) * 100;
                                $progress_class = $usage_percentage >= 90 ? 'high' : ($usage_percentage >= 70 ? 'medium' : 'low');
                                echo '<div class="vrstore-usage-display">';
                                echo '<strong>' . esc_html($usage_count . ' / ' . $usage_limit) . '</strong>';
                                echo '<div class="vrstore-usage-progress vrstore-usage-' . $progress_class . '" style="width: 100%; height: 4px; background: #f0f0f0; margin: 2px 0; border-radius: 2px;">';
                                echo '<div style="width: ' . min(100, $usage_percentage) . '%; height: 100%; background: ' . ($progress_class === 'high' ? '#dc3232' : ($progress_class === 'medium' ? '#ffb900' : '#46b450')) . '; border-radius: 2px;"></div>';
                                echo '</div>';
                            } else {
                                echo '<div class="vrstore-usage-display">';
                                echo '<strong>' . esc_html($usage_count . ' / ' . __('Unlimited', 'vira-store')) . '</strong>';
                            }
                            
                            // Display additional statistics if available
                            if (!empty($usage_stats) && $usage_stats['total_usage'] > 0) {
                                echo '<div class="vrstore-usage-stats" style="font-size: 11px; color: #666; margin-top: 4px;">';
                                
                                // Total discount given
                                if ($usage_stats['total_discount'] > 0) {
                                    if (class_exists('VRSTORE_Settings')) {
                                        $settings = VRSTORE_Settings::get_instance();
                                        $formatted_discount = $settings->format_price($usage_stats['total_discount']);
                                    } else {
                                        $formatted_discount = '$' . number_format($usage_stats['total_discount'], 2);
                                    }
                                    echo '<div title="' . esc_attr__('Total discount amount given', 'vira-store') . '">';
                                    echo '💰 ' . esc_html($formatted_discount);
                                    echo '</div>';
                                }
                                
                                // Unique users
                                if ($usage_stats['unique_users'] > 0) {
                                    echo '<div title="' . esc_attr__('Number of unique users', 'vira-store') . '">';
                                    echo '👥 ' . esc_html($usage_stats['unique_users']) . ' ' . _n('user', 'users', $usage_stats['unique_users'], 'vira-store');
                                    echo '</div>';
                                }
                                
                                echo '</div>';
                            }
                            
                            echo '</div>';
                            ?>
                        </td>
                        <td class="column-expiry">
                            <?php 
                            if (!empty($coupon['end_date']) && $coupon['end_date'] !== '0000-00-00 00:00:00') {
                                echo esc_html(mysql2date('M j, Y', $coupon['end_date']));
                            } else {
                                echo '<em>' . __('No expiry', 'vira-store') . '</em>';
                            }
                            ?>
                        </td>
                        <td class="column-status">
                            <span class="coupon-status coupon-status-<?php echo esc_attr($coupon['status']); ?>">
                                <?php echo esc_html(ucfirst($coupon['status'])); ?>
                            </span>
                        </td>
                        <td class="column-actions">
                            <div class="row-actions">
                                <?php if ($coupon['status'] === 'active'): ?>
                                    <span class="deactivate">
                                        <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=vrstore-coupons&action=deactivate&coupon_id=' . $coupon['id']), 'vrstore_coupon_action'); ?>" 
                                           class="vrstore-action-link" 
                                           onclick="return confirm('<?php esc_attr_e('Are you sure you want to deactivate this coupon?', 'vira-store'); ?>')">
                                            <?php _e('Deactivate', 'vira-store'); ?>
                                        </a>
                                    </span> |
                                <?php else: ?>
                                    <span class="activate">
                                        <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=vrstore-coupons&action=activate&coupon_id=' . $coupon['id']), 'vrstore_coupon_action'); ?>" 
                                           class="vrstore-action-link">
                                            <?php _e('Activate', 'vira-store'); ?>
                                        </a>
                                    </span> |
                                <?php endif; ?>
                                
                                <span class="edit">
                                    <a href="#" class="vrstore-action-link edit-coupon" data-coupon-id="<?php echo esc_attr($coupon['id']); ?>">
                                        <?php _e('Edit', 'vira-store'); ?>
                                    </a>
                                </span> |
                                
                                <span class="delete">
                                    <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=vrstore-coupons&action=delete&coupon_id=' . $coupon['id']), 'vrstore_coupon_action'); ?>" 
                                       class="vrstore-action-link vrstore-delete-link" 
                                       onclick="return confirm('<?php esc_attr_e('Are you sure you want to delete this coupon? This action cannot be undone.', 'vira-store'); ?>')">
                                        <?php _e('Delete', 'vira-store'); ?>
                                    </a>
                                </span>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Pagination -->
        <?php if ($coupons['total_pages'] > 1): ?>
            <div class="tablenav bottom">
                <div class="tablenav-pages">
                    <?php
                    $pagination_args = [
                        'base' => add_query_arg('paged', '%#%'),
                        'format' => '',
                        'prev_text' => __('&laquo; Previous', 'vira-store'),
                        'next_text' => __('Next &raquo;', 'vira-store'),
                        'current' => $current_page,
                        'total' => $coupons['total_pages']
                    ];
                    echo paginate_links($pagination_args);
                    ?>
                </div>
            </div>
        <?php endif; ?>

    <?php else: ?>
        <!-- No coupons found -->
        <div class="vrstore-empty-state">
            <div class="vrstore-empty-icon">
                <span class="dashicons dashicons-tag"></span>
            </div>
            <h2><?php _e('No coupons found', 'vira-store'); ?></h2>
            <p><?php _e('Create your first coupon to start offering discounts to your customers.', 'vira-store'); ?></p>
            <a href="#" class="button button-primary" id="add-first-coupon"><?php _e('Create Your First Coupon', 'vira-store'); ?></a>
        </div>
    <?php endif; ?>
</div>

<!-- Add/Edit Coupon Modal -->
<div id="coupon-modal" class="vrstore-modal" style="display: none;">
    <div class="vrstore-modal-content">
        <div class="vrstore-modal-header">
            <h2 id="coupon-modal-title"><?php _e('Add New Coupon', 'vira-store'); ?></h2>
            <div class="vrstore-modal-header-actions">
                <button type="button" class="button" id="cancel-coupon"><?php _e('Cancel', 'vira-store'); ?></button>
                <button type="submit" class="button button-primary" id="save-coupon" form="coupon-form">
                    <span class="button-text"><?php _e('Save Coupon', 'vira-store'); ?></span>
                    <span class="spinner"></span>
                </button>
                <button type="button" class="vrstore-modal-close" id="close-coupon-modal">&times;</button>
            </div>
        </div>
        
        <form id="coupon-form">
            <div class="vrstore-modal-body">
                <input type="hidden" id="coupon-id" name="coupon_id" value="">
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="coupon-code"><?php _e('Coupon Code', 'vira-store'); ?> <span class="required">*</span></label>
                        </th>
                        <td>
                            <input type="text" id="coupon-code" name="code" class="regular-text" required>
                            <p class="description"><?php _e('Enter a unique coupon code (e.g., SAVE20, WELCOME)', 'vira-store'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="coupon-type"><?php _e('Discount Type', 'vira-store'); ?> <span class="required">*</span></label>
                        </th>
                        <td>
                            <select id="coupon-type" name="discount_type" required>
                                <option value="percentage"><?php _e('Percentage', 'vira-store'); ?></option>
                                <option value="fixed"><?php _e('Fixed Amount', 'vira-store'); ?></option>
                            </select>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="coupon-amount"><?php _e('Discount Amount', 'vira-store'); ?> <span class="required">*</span></label>
                        </th>
                        <td>
                            <input type="number" id="coupon-amount" name="discount_amount" class="small-text" min="0" step="0.01" required>
                            <p class="description" id="amount-description">
                                <?php 
                                $currency_symbol = '$'; // default
                                if (class_exists('VRSTORE_Settings')) {
                                    $settings = VRSTORE_Settings::get_instance();
                                    $currency = $settings->get_setting('currency', 'USD');
                                    $currency_symbol = VRSTORE_Product::get_currency_symbol($currency);
                                }
                                printf(__('Enter the discount percentage (0-100) or fixed amount (in %s)', 'vira-store'), $currency_symbol);
                                ?>
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="coupon-minimum"><?php _e('Minimum Amount', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <input type="number" id="coupon-minimum" name="minimum_amount" class="regular-text" min="0" step="0.01">
                            <p class="description"><?php _e('Minimum order amount required to use this coupon', 'vira-store'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="coupon-usage-limit"><?php _e('Usage Limit', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <input type="number" id="coupon-usage-limit" name="usage_limit" class="small-text" min="0">
                            <p class="description"><?php _e('Maximum number of times this coupon can be used (leave empty for unlimited)', 'vira-store'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="coupon-expires"><?php _e('Expiry Date', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <input type="datetime-local" id="coupon-expires" name="expires_at" class="regular-text">
                            <p class="description"><?php _e('When this coupon expires (leave empty for no expiry)', 'vira-store'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="coupon-description"><?php _e('Description', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <textarea id="coupon-description" name="description" class="large-text" rows="3"></textarea>
                            <p class="description"><?php _e('Optional description for internal use', 'vira-store'); ?></p>
                        </td>
                    </tr>
                </table>
            </div>
        </form>
    </div>
</div>
