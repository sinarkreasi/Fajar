<?php
/**
 * Customer Edit View
 * 
 * @package Vira_Store
 * @since 1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

$customer_id = isset($_GET['customer_id']) ? intval($_GET['customer_id']) : 0;
$customer = $customer ?? null;

if (!$customer) {
    echo '<div class="notice notice-error"><p>' . esc_html__('Customer not found.', 'vira-store') . '</p></div>';
    return;
}
?>

<div class="wrap">
    <h1 class="wp-heading-inline">
        <?php echo esc_html__('Edit Customer', 'vira-store'); ?>
        <span class="customer-name"><?php echo esc_html($customer['display_name']); ?></span>
    </h1>
    
    <a href="<?php echo esc_url(admin_url('admin.php?page=vrstore-customers&action=view&customer_id=' . $customer_id)); ?>" class="page-title-action">
        <?php echo esc_html__('← Back to Customer', 'vira-store'); ?>
    </a>
    
    <a href="<?php echo esc_url(admin_url('admin.php?page=vrstore-customers')); ?>" class="page-title-action">
        <?php echo esc_html__('All Customers', 'vira-store'); ?>
    </a>
    
    <hr class="wp-header-end">
    
    <form method="post" action="" class="customer-edit-form">
        <?php wp_nonce_field('vrstore_edit_customer', 'vrstore_customer_nonce'); ?>
        <input type="hidden" name="action" value="edit_customer">
        <input type="hidden" name="customer_id" value="<?php echo esc_attr($customer_id); ?>">
        
        <div class="customer-edit-sections">
            <!-- Basic Information -->
            <div class="edit-section">
                <h3><?php echo esc_html__('Basic Information', 'vira-store'); ?></h3>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="display_name"><?php echo esc_html__('Display Name', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="display_name" name="display_name" value="<?php echo esc_attr($customer['display_name']); ?>" class="regular-text" required>
                            <p class="description"><?php echo esc_html__('The name displayed publicly for this customer.', 'vira-store'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="user_email"><?php echo esc_html__('Email Address', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <input type="email" id="user_email" name="user_email" value="<?php echo esc_attr($customer['user_email']); ?>" class="regular-text" required>
                            <p class="description"><?php echo esc_html__('Customer\'s email address for communication and login.', 'vira-store'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="user_login"><?php echo esc_html__('Username', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="user_login" name="user_login" value="<?php echo esc_attr($customer['user_login']); ?>" class="regular-text" readonly>
                            <p class="description"><?php echo esc_html__('Username cannot be changed after registration.', 'vira-store'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="first_name"><?php echo esc_html__('First Name', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="first_name" name="first_name" value="<?php echo esc_attr(get_user_meta($customer_id, 'first_name', true)); ?>" class="regular-text">
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="last_name"><?php echo esc_html__('Last Name', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="last_name" name="last_name" value="<?php echo esc_attr(get_user_meta($customer_id, 'last_name', true)); ?>" class="regular-text">
                        </td>
                    </tr>
                </table>
            </div>
            
            <!-- Account Status -->
            <div class="edit-section">
                <h3><?php echo esc_html__('Account Status', 'vira-store'); ?></h3>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="customer_status"><?php echo esc_html__('Status', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <?php 
                            // Get customer status - fallback to 'active' if not set
                            $customer_status = $customer['status'] ?? $customer['user_status'] ?? 'active';
                            ?>
                            <select id="customer_status" name="customer_status" class="regular-text">
                                <option value="active" <?php selected($customer_status, 'active'); ?>>
                                    <?php echo esc_html__('Active', 'vira-store'); ?>
                                </option>
                                <option value="inactive" <?php selected($customer_status, 'inactive'); ?>>
                                    <?php echo esc_html__('Inactive', 'vira-store'); ?>
                                </option>
                                <option value="suspended" <?php selected($customer_status, 'suspended'); ?>>
                                    <?php echo esc_html__('Suspended', 'vira-store'); ?>
                                </option>
                            </select>
                            <p class="description"><?php echo esc_html__('Customer account status affects their ability to access services.', 'vira-store'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="user_role"><?php echo esc_html__('User Role', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <?php 
                            $user = get_user_by('id', $customer_id);
                            $user_roles = $user ? $user->roles : ['customer'];
                            $current_role = !empty($user_roles) ? $user_roles[0] : 'customer';
                            ?>
                            <select id="user_role" name="user_role" class="regular-text">
                                <option value="customer" <?php selected($current_role, 'customer'); ?>>
                                    <?php echo esc_html__('Customer', 'vira-store'); ?>
                                </option>
                                <option value="subscriber" <?php selected($current_role, 'subscriber'); ?>>
                                    <?php echo esc_html__('Subscriber', 'vira-store'); ?>
                                </option>
                                <?php if (current_user_can('promote_users')) : ?>
                                    <option value="editor" <?php selected($current_role, 'editor'); ?>>
                                        <?php echo esc_html__('Editor', 'vira-store'); ?>
                                    </option>
                                    <option value="administrator" <?php selected($current_role, 'administrator'); ?>>
                                        <?php echo esc_html__('Administrator', 'vira-store'); ?>
                                    </option>
                                <?php endif; ?>
                            </select>
                            <p class="description"><?php echo esc_html__('WordPress user role for this customer.', 'vira-store'); ?></p>
                        </td>
                    </tr>
                </table>
            </div>
            
            <!-- Contact Information -->
            <div class="edit-section">
                <h3><?php echo esc_html__('Contact Information', 'vira-store'); ?></h3>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="billing_phone"><?php echo esc_html__('Phone Number', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <input type="tel" id="billing_phone" name="billing_phone" value="<?php echo esc_attr(get_user_meta($customer_id, 'billing_phone', true)); ?>" class="regular-text">
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="billing_company"><?php echo esc_html__('Company', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="billing_company" name="billing_company" value="<?php echo esc_attr(get_user_meta($customer_id, 'billing_company', true)); ?>" class="regular-text">
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="billing_address_1"><?php echo esc_html__('Address Line 1', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="billing_address_1" name="billing_address_1" value="<?php echo esc_attr(get_user_meta($customer_id, 'billing_address_1', true)); ?>" class="regular-text">
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="billing_address_2"><?php echo esc_html__('Address Line 2', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="billing_address_2" name="billing_address_2" value="<?php echo esc_attr(get_user_meta($customer_id, 'billing_address_2', true)); ?>" class="regular-text">
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="billing_city"><?php echo esc_html__('City', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="billing_city" name="billing_city" value="<?php echo esc_attr(get_user_meta($customer_id, 'billing_city', true)); ?>" class="regular-text">
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="billing_state"><?php echo esc_html__('State/Province', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="billing_state" name="billing_state" value="<?php echo esc_attr(get_user_meta($customer_id, 'billing_state', true)); ?>" class="regular-text">
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="billing_postcode"><?php echo esc_html__('Postal Code', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="billing_postcode" name="billing_postcode" value="<?php echo esc_attr(get_user_meta($customer_id, 'billing_postcode', true)); ?>" class="regular-text">
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="billing_country"><?php echo esc_html__('Country', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="billing_country" name="billing_country" value="<?php echo esc_attr(get_user_meta($customer_id, 'billing_country', true)); ?>" class="regular-text">
                        </td>
                    </tr>
                </table>
            </div>
            
            <!-- Customer Notes -->
            <div class="edit-section">
                <h3><?php echo esc_html__('Customer Notes', 'vira-store'); ?></h3>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="customer_notes"><?php echo esc_html__('Admin Notes', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <textarea id="customer_notes" name="customer_notes" rows="5" class="large-text"><?php echo esc_textarea(get_user_meta($customer_id, 'vrstore_customer_notes', true)); ?></textarea>
                            <p class="description"><?php echo esc_html__('Internal notes about this customer (not visible to customer).', 'vira-store'); ?></p>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        
        <p class="submit">
            <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php echo esc_attr__('Update Customer', 'vira-store'); ?>">
            <a href="<?php echo esc_url(admin_url('admin.php?page=vrstore-customers&action=view&customer_id=' . $customer_id)); ?>" class="button">
                <?php echo esc_html__('Cancel', 'vira-store'); ?>
            </a>
        </p>
    </form>
</div>