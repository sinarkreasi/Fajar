<?php
/**
 * Affiliate Edit Admin Page Template
 *
 * @package Vira_Store
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap">
    <h1 class="wp-heading-inline">
        <?php _e('Edit Affiliate', 'vira-store'); ?>
        <a href="<?php echo admin_url('admin.php?page=vrstore-affiliates'); ?>" class="page-title-action">
            <?php _e('Back to Affiliates', 'vira-store'); ?>
        </a>
    </h1>
    
    <hr class="wp-header-end">

    <form method="post" action="<?php echo admin_url('admin.php?page=vrstore-affiliates'); ?>">
        <?php wp_nonce_field('vrstore_affiliate_action'); ?>
        <input type="hidden" name="action" value="update_affiliate">
        <input type="hidden" name="affiliate_id" value="<?php echo esc_attr($affiliate['id']); ?>">
        
        <div class="affiliate-edit-container">
            <div class="affiliate-basic-info">
                <h2><?php _e('Basic Information', 'vira-store'); ?></h2>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="affiliate_name"><?php _e('Name', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <input type="text" 
                                   id="affiliate_name" 
                                   name="affiliate_name" 
                                   value="<?php echo esc_attr($affiliate['name']); ?>" 
                                   class="regular-text" 
                                   required>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="affiliate_email"><?php _e('Email', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <input type="email" 
                                   id="affiliate_email" 
                                   name="affiliate_email" 
                                   value="<?php echo esc_attr($affiliate['email']); ?>" 
                                   class="regular-text" 
                                   required>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="affiliate_status"><?php _e('Status', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <select id="affiliate_status" name="affiliate_status">
                                <option value="pending" <?php selected($affiliate['status'], 'pending'); ?>>
                                    <?php _e('Pending', 'vira-store'); ?>
                                </option>
                                <option value="active" <?php selected($affiliate['status'], 'active'); ?>>
                                    <?php _e('Active', 'vira-store'); ?>
                                </option>
                                <option value="suspended" <?php selected($affiliate['status'], 'suspended'); ?>>
                                    <?php _e('Suspended', 'vira-store'); ?>
                                </option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="commission_rate"><?php _e('Commission Rate (%)', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <input type="number" 
                                   id="commission_rate" 
                                   name="commission_rate" 
                                   value="<?php echo esc_attr($affiliate['commission_rate']); ?>" 
                                   min="0" 
                                   max="100" 
                                   step="0.01" 
                                   class="small-text">
                            <p class="description"><?php _e('Enter the commission rate as a percentage (0-100).', 'vira-store'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="affiliate_code"><?php _e('Referral Code', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <input type="text" 
                                   id="affiliate_code" 
                                   name="affiliate_code" 
                                   value="<?php echo esc_attr($affiliate['affiliate_code']); ?>"
                                   class="regular-text" 
                                   readonly>
                            <p class="description"><?php _e('Referral code cannot be changed after creation.', 'vira-store'); ?></p>
                        </td>
                    </tr>
                </table>
            </div>

            <div class="affiliate-additional-info">
                <h2><?php _e('Additional Information', 'vira-store'); ?></h2>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="payment_method"><?php _e('Payment Method', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <select id="payment_method" name="payment_method">
                                <option value="paypal" <?php selected($affiliate['payment_method'] ?? '', 'paypal'); ?>>
                                    <?php _e('PayPal', 'vira-store'); ?>
                                </option>
                                <option value="bank_transfer" <?php selected($affiliate['payment_method'] ?? '', 'bank_transfer'); ?>>
                                    <?php _e('Bank Transfer', 'vira-store'); ?>
                                </option>
                                <option value="check" <?php selected($affiliate['payment_method'] ?? '', 'check'); ?>>
                                    <?php _e('Check', 'vira-store'); ?>
                                </option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="payment_details"><?php _e('Payment Details', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <textarea id="payment_details" 
                                      name="payment_details" 
                                      rows="4" 
                                      cols="50" 
                                      class="large-text"
                                      placeholder="<?php _e('Enter payment details (PayPal email, bank account info, etc.)', 'vira-store'); ?>"><?php echo esc_textarea($affiliate['payment_details'] ?? ''); ?></textarea>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="notes"><?php _e('Admin Notes', 'vira-store'); ?></label>
                        </th>
                        <td>
                            <textarea id="notes" 
                                      name="notes" 
                                      rows="6" 
                                      cols="50" 
                                      class="large-text"
                                      placeholder="<?php _e('Internal notes about this affiliate...', 'vira-store'); ?>"><?php 
                            // Display promotion methods first if they exist and notes is empty, or existing notes
                            $notes_content = $affiliate['notes'] ?? '';
                            $promotion_methods = $affiliate['promotion_methods'] ?? '';
                            
                            // If notes is empty but promotion_methods exist, pre-populate notes with promotion methods
                            if (empty($notes_content) && !empty($promotion_methods)) {
                                $notes_content = __('Promotion Methods (from registration):', 'vira-store') . "\n" . $promotion_methods . "\n\n" . __('Admin Notes:', 'vira-store') . "\n";
                            }
                            
                            echo esc_textarea($notes_content);
                            ?></textarea>
                            <?php if (!empty($affiliate['promotion_methods'])): ?>
                            <p class="description">
                                <strong><?php _e('Original promotion methods from registration:', 'vira-store'); ?></strong><br>
                                <?php echo esc_html($affiliate['promotion_methods']); ?>
                            </p>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
            </div>
        </div>

        <p class="submit">
            <input type="submit" class="button button-primary" value="<?php _e('Update Affiliate', 'vira-store'); ?>">
            <a href="<?php echo admin_url('admin.php?page=vrstore-affiliates&action=view&affiliate_id=' . $affiliate['id']); ?>" class="button button-secondary">
                <?php _e('Cancel', 'vira-store'); ?>
            </a>
        </p>
    </form>

    <!-- Withdrawal Requests Section -->
    <div class="affiliate-withdrawal-requests">
        <h2><?php _e('Withdrawal Requests', 'vira-store'); ?></h2>
        
        <?php
        // Get withdrawal requests for this affiliate
        global $wpdb;
        $withdrawals_table = $wpdb->prefix . 'vrstore_affiliate_withdrawals';
        $withdrawals = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$withdrawals_table} WHERE affiliate_id = %d ORDER BY requested_at DESC",
            $affiliate['id']
        ));
        ?>
        
        <?php if (!empty($withdrawals)): ?>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th scope="col"><?php _e('Amount', 'vira-store'); ?></th>
                        <th scope="col"><?php _e('Status', 'vira-store'); ?></th>
                        <th scope="col"><?php _e('Payment Method', 'vira-store'); ?></th>
                        <th scope="col"><?php _e('Requested', 'vira-store'); ?></th>
                        <th scope="col"><?php _e('Processed', 'vira-store'); ?></th>
                        <th scope="col"><?php _e('Actions', 'vira-store'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($withdrawals as $withdrawal): ?>
                        <tr>
                            <td>
                                <strong>
                                    <?php 
                                    // Format amount with currency (amounts stored in base currency)
                                    if (class_exists('VRSTORE_Currency_Converter')) {
                                        $currency_converter = VRSTORE_Currency_Converter::get_instance();
                                        // Use format_price since amounts are already in base currency
                                        echo esc_html($currency_converter->format_price($withdrawal->amount));
                                    } else {
                                        echo '$' . esc_html(number_format($withdrawal->amount, 2));
                                    }
                                    ?>
                                </strong>
                            </td>
                            <td>
                                <span class="withdrawal-status withdrawal-status-<?php echo esc_attr($withdrawal->status); ?>">
                                    <?php echo esc_html(ucfirst($withdrawal->status)); ?>
                                </span>
                            </td>
                            <td>
                                <?php echo esc_html(ucfirst(str_replace('_', ' ', $withdrawal->payment_method ?: 'Not specified'))); ?>
                            </td>
                            <td>
                                <?php echo esc_html(mysql2date('M j, Y g:i A', $withdrawal->requested_at)); ?>
                            </td>
                            <td>
                                <?php 
                                if ($withdrawal->processed_at) {
                                    echo esc_html(mysql2date('M j, Y g:i A', $withdrawal->processed_at));
                                } else {
                                    echo '<em>' . __('Not processed', 'vira-store') . '</em>';
                                }
                                ?>
                            </td>
                            <td>
                                <?php if ($withdrawal->status === 'pending'): ?>
                                    <div class="withdrawal-actions">
                                        <button type="button" 
                                                class="button button-small approve-withdrawal" 
                                                data-withdrawal-id="<?php echo esc_attr($withdrawal->id); ?>"
                                                data-affiliate-id="<?php echo esc_attr($affiliate['id']); ?>"
                                                data-action="approve_withdrawal">
                                            <?php _e('Approve', 'vira-store'); ?>
                                        </button>
                                        <button type="button" 
                                                class="button button-small reject-withdrawal" 
                                                data-withdrawal-id="<?php echo esc_attr($withdrawal->id); ?>"
                                                data-affiliate-id="<?php echo esc_attr($affiliate['id']); ?>"
                                                data-action="reject_withdrawal">
                                            <?php _e('Reject', 'vira-store'); ?>
                                        </button>
                                    </div>
                                <?php elseif ($withdrawal->status === 'approved'): ?>
                                    <button type="button" 
                                            class="button button-small mark-paid-withdrawal" 
                                            data-withdrawal-id="<?php echo esc_attr($withdrawal->id); ?>"
                                            data-affiliate-id="<?php echo esc_attr($affiliate['id']); ?>"
                                            data-action="mark_paid_withdrawal">
                                        <?php _e('Mark as Paid', 'vira-store'); ?>
                                    </button>
                                <?php elseif ($withdrawal->status === 'cancelled'): ?>
                                    <span class="description"><?php _e('Cancelled', 'vira-store'); ?></span>
                                <?php elseif ($withdrawal->status === 'paid'): ?>
                                    <span class="description"><?php _e('Paid', 'vira-store'); ?></span>
                                <?php else: ?>
                                    <em><?php _e('No actions available', 'vira-store'); ?></em>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php if (!empty($withdrawal->admin_notes)): ?>
                            <tr class="withdrawal-notes-row">
                                <td colspan="6">
                                    <div class="withdrawal-admin-notes">
                                        <strong><?php _e('Admin Notes:', 'vira-store'); ?></strong>
                                        <p><?php echo esc_html($withdrawal->admin_notes); ?></p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                        <?php if (!empty($withdrawal->payment_details)): ?>
                            <tr class="withdrawal-details-row">
                                <td colspan="6">
                                    <div class="withdrawal-payment-details">
                                        <strong><?php _e('Payment Details:', 'vira-store'); ?></strong>
                                        <p><?php echo esc_html($withdrawal->payment_details); ?></p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="vrstore-empty-state">
                <p><?php _e('No withdrawal requests found for this affiliate.', 'vira-store'); ?></p>
            </div>
        <?php endif; ?>
    </div>

    <!-- Withdrawal Action Modal -->
    <div id="withdrawal-action-modal" class="vrstore-modal" style="display: none;">
        <div class="vrstore-modal-overlay"></div>
        <div class="vrstore-modal-content">
            <div class="vrstore-modal-header">
                <h3 id="modal-title"><?php _e('Process Withdrawal', 'vira-store'); ?></h3>
                <button type="button" class="vrstore-modal-close">&times;</button>
            </div>
            <div class="vrstore-modal-body">
                <form id="withdrawal-action-form">
                    <input type="hidden" id="withdrawal-id" name="withdrawal_id" value="">
                    <input type="hidden" id="affiliate-id" name="affiliate_id" value="">
                    <input type="hidden" id="withdrawal-action" name="action" value="">
                    
                    <div class="form-group">
                        <label for="admin-notes"><?php _e('Admin Notes (Optional)', 'vira-store'); ?></label>
                        <textarea id="admin-notes" 
                                  name="admin_notes" 
                                  rows="4" 
                                  cols="50" 
                                  class="large-text"
                                  placeholder="<?php _e('Add notes about this withdrawal action...', 'vira-store'); ?>"></textarea>
                    </div>
                    
                    <div class="form-group" id="payment-details-group" style="display: none;">
                        <label for="payment-details"><?php _e('Payment Details', 'vira-store'); ?></label>
                        <textarea id="payment-details" 
                                  name="payment_details" 
                                  rows="3" 
                                  cols="50" 
                                  class="large-text"
                                  placeholder="<?php _e('Transaction ID, payment reference, etc...', 'vira-store'); ?>"></textarea>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="button button-primary" id="confirm-action">
                            <?php _e('Confirm', 'vira-store'); ?>
                        </button>
                        <button type="button" class="button button-secondary cancel-action">
                            <?php _e('Cancel', 'vira-store'); ?>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>