<?php
/**
 * Plugin Versions Management Admin Page
 *
 * @package Vira_Store
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Get available license types (legacy taxonomy support)
$license_types = get_terms([
    'taxonomy' => 'vrstore_license_type',
    'hide_empty' => false,
]);

// Get custom license types from settings
$settings = get_option('vrstore_settings', []);
$custom_license_types = $settings['custom_license_types'] ?? [];
?>

<div class="wrap">
    <h1 class="wp-heading-inline"><?php esc_html_e('Plugin Version Management', 'vira-store'); ?></h1>
    
    <div class="vrstore-plugin-versions-container">
        <div class="vrstore-admin-header">
            <p class="description">
                <?php esc_html_e('Manage plugin versions and their associated license tier requirements. Upload new versions, set changelog information, and configure which license tiers have access to each version. Only products with "Enable Plugin Updates" checked are shown here.', 'vira-store'); ?>
            </p>
        </div>

        <?php if (empty($products)): ?>
            <div class="notice notice-info">
                <p><?php esc_html_e('No products with plugin updates enabled found. Please enable "Plugin Updates" in your product settings first.', 'vira-store'); ?></p>
            </div>
        <?php else: ?>
            
            <div class="vrstore-products-grid">
                <?php foreach ($products as $product): ?>
                    <?php
                    // Get versions from database table (not post meta)
                    global $wpdb;
                    $versions_table = $wpdb->prefix . 'vrstore_plugin_versions';
                    $version_count = 0;
                    $versions = [];
                    
                    // Check if table exists
                    if ($wpdb->get_var("SHOW TABLES LIKE '$versions_table'") === $versions_table) {
                        $version_count = $wpdb->get_var($wpdb->prepare(
                            "SELECT COUNT(*) FROM {$versions_table} WHERE product_id = %d",
                            $product->ID
                        ));
                        
                        // Get recent versions for display (last 3)
                        $versions_data = $wpdb->get_results($wpdb->prepare(
                            "SELECT version, release_date, created_at 
                             FROM {$versions_table} 
                             WHERE product_id = %d 
                             ORDER BY release_date DESC, created_at DESC 
                             LIMIT 3",
                            $product->ID
                        ), ARRAY_A);
                        
                        // Format for template compatibility
                        foreach ($versions_data as $v) {
                            $versions[$v['version']] = [
                                'version' => $v['version'],
                                'created_at' => $v['created_at'] ?: $v['release_date']
                            ];
                        }
                    }
                    ?>
                    
                    <div class="vrstore-product-card" data-product-id="<?php echo esc_attr($product->ID); ?>">
                        <div class="product-header">
                            <h3><?php echo esc_html($product->post_title); ?></h3>
                            <span class="version-count"><?php echo sprintf(esc_html__('%d versions', 'vira-store'), $version_count); ?></span>
                        </div>
                        
                        <div class="product-actions">
                            <button type="button" class="button button-primary add-version-btn" data-product-id="<?php echo esc_attr($product->ID); ?>">
                                <span class="dashicons dashicons-plus-alt"></span>
                                <?php esc_html_e('Add Version', 'vira-store'); ?>
                            </button>
                            <button type="button" class="button manage-versions-btn" data-product-id="<?php echo esc_attr($product->ID); ?>">
                                <span class="dashicons dashicons-admin-settings"></span>
                                <?php esc_html_e('Manage Versions', 'vira-store'); ?>
                            </button>
                        </div>
                        
                        <?php if (!empty($versions)): ?>
                            <div class="versions-summary">
                                <h4><?php esc_html_e('Recent Versions:', 'vira-store'); ?></h4>
                                <ul class="version-list">
                                    <?php
                                    // Sort versions by creation date (newest first)
                                    uasort($versions, function($a, $b) {
                                        return strtotime($b['created_at'] ?? '0') - strtotime($a['created_at'] ?? '0');
                                    });
                                    
                                    $recent_versions = array_slice($versions, 0, 3, true);
                                    foreach ($recent_versions as $version => $data):
                                    ?>
                                        <li>
                                            <strong><?php echo esc_html($version); ?></strong>
                                            <span class="version-date">
                                                <?php echo esc_html(date_i18n(get_option('date_format'), strtotime($data['created_at'] ?? ''))); ?>
                                            </span>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                <?php endforeach; ?>
            </div>
            
        <?php endif; ?>
    </div>
</div>

<!-- Add Version Modal -->
<div id="add-version-modal" class="vrstore-modal" style="display: none;">
    <div class="vrstore-modal-content">
        <div class="vrstore-modal-header">
            <h2><?php esc_html_e('Add New Version', 'vira-store'); ?></h2>
            <button type="button" class="vrstore-modal-close">&times;</button>
        </div>
        
        <form id="add-version-form" method="post" enctype="multipart/form-data">
            <?php wp_nonce_field('vrstore_plugin_version_action', 'vrstore_plugin_version_nonce'); ?>
            <input type="hidden" name="action" value="add_version">
            <input type="hidden" name="product_id" id="add-product-id" value="">
            
            <div class="vrstore-form-row">
                <label for="add-version"><?php esc_html_e('Version Number', 'vira-store'); ?> <span class="required">*</span></label>
                <input type="text" id="add-version" name="version" required placeholder="1.0.0" pattern="[0-9]+\.[0-9]+\.[0-9]+">
                <p class="description"><?php esc_html_e('Use semantic versioning (e.g., 1.0.0)', 'vira-store'); ?></p>
            </div>
            
            <div class="vrstore-form-row">
                <label for="add-plugin-file"><?php esc_html_e('Plugin File', 'vira-store'); ?></label>
                <input type="file" id="add-plugin-file" name="plugin_file" accept=".zip">
                <p class="description"><?php esc_html_e('Upload the plugin ZIP file (optional)', 'vira-store'); ?></p>
            </div>
            
            <div class="vrstore-form-row">
                <label for="add-changelog"><?php esc_html_e('Changelog', 'vira-store'); ?></label>
                <textarea id="add-changelog" name="changelog" rows="5" placeholder="<?php esc_attr_e('What\'s new in this version...', 'vira-store'); ?>"></textarea>
            </div>
            
            <div class="vrstore-form-row">
                <label><?php esc_html_e('License Tier Access', 'vira-store'); ?></label>
                <div class="license-tiers-checkboxes">
                    <?php 
                    // Display custom license types from settings first (preferred)
                    if (!empty($custom_license_types)): ?>
                        <?php foreach ($custom_license_types as $custom_type): ?>
                            <?php 
                            $slug = $custom_type['slug'] ?? sanitize_title($custom_type['label'] ?? '');
                            $label = $custom_type['label'] ?? ucfirst($slug);
                            ?>
                            <label class="checkbox-label">
                                <input type="checkbox" name="license_tiers[]" value="<?php echo esc_attr($slug); ?>">
                                <?php echo esc_html($label); ?>
                            </label>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    
                    <?php 
                    // Display legacy taxonomy license types if no custom types are configured
                    if (empty($custom_license_types) && !empty($license_types) && !is_wp_error($license_types)): ?>
                        <?php foreach ($license_types as $license_type): ?>
                            <label class="checkbox-label">
                                <input type="checkbox" name="license_tiers[]" value="<?php echo esc_attr($license_type->slug); ?>">
                                <?php echo esc_html($license_type->name); ?>
                            </label>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    
                    <?php if (empty($custom_license_types) && (empty($license_types) || is_wp_error($license_types))): ?>
                        <p class="description" style="color: #d63638;">
                            <?php esc_html_e('No license types configured. Please configure custom license types in Settings > License to enable license tier access control.', 'vira-store'); ?>
                        </p>
                    <?php endif; ?>
                </div>
                <p class="description"><?php esc_html_e('Select which license tiers can access this version. If no license types are selected, the version will be available to all license holders.', 'vira-store'); ?></p>
            </div>
            
            <div class="vrstore-modal-footer">
                <button type="button" class="button vrstore-modal-close"><?php esc_html_e('Cancel', 'vira-store'); ?></button>
                <button type="submit" class="button button-primary"><?php esc_html_e('Add Version', 'vira-store'); ?></button>
            </div>
        </form>
    </div>
</div>

<!-- Manage Versions Modal -->
<div id="manage-versions-modal" class="vrstore-modal" style="display: none;">
    <div class="vrstore-modal-content large">
        <div class="vrstore-modal-header">
            <h2><?php esc_html_e('Manage Versions', 'vira-store'); ?> - <span id="manage-product-title"></span></h2>
            <button type="button" class="vrstore-modal-close">&times;</button>
        </div>
        
        <div id="versions-list-container">
            <!-- Versions will be loaded here via JavaScript -->
        </div>
    </div>
</div>