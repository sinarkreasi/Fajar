<?php
/**
 * Plugin Name: ViraStore PayPal Payment Gateway
 * Plugin URI: https://virastore.com/paypal
 * Description: PayPal payment gateway integration for ViraStore plugin.
 * Version: 1.0.0
 * Author: ViraStore
 * Author URI: https://virastore.com
 * Text Domain: virastore-paypal
 * Domain Path: /languages
 * Requires at least: 5.6
 * Requires PHP: 8.2
 *
 * @package ViraStore_PayPal
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Define plugin constants.
define( 'VIRASTORE_PAYPAL_VERSION', '1.0.0' );
define( 'VIRASTORE_PAYPAL_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'VIRASTORE_PAYPAL_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'VIRASTORE_PAYPAL_PLUGIN_FILE', __FILE__ );

/**
 * Check if ViraStore plugin is active.
 *
 * @since 1.0.0
 */
function virastore_paypal_check_virastore() {
	// Check multiple ways to determine if main plugin is active:
	// 1. Check if main plugin file is active (most reliable)
	// 2. Check if main plugin class exists (Vira_Store loads early)
	// 3. Check if VRSTORE_Payment class exists (loads later on wp_loaded)
	
	$is_plugin_active = is_plugin_active( 'vira-store/vira-store.php' );
	$has_main_class = class_exists( 'Vira_Store' );
	$has_payment_class = class_exists( 'VRSTORE_Payment' );
	
	// Plugin is active if any of these checks pass
	// Note: VRSTORE_Payment loads later on wp_loaded, so we check main plugin file/class first
	if ( ! $is_plugin_active && ! $has_main_class && ! $has_payment_class ) {
		add_action( 'admin_notices', 'virastore_paypal_missing_virastore_notice' );
		return false;
	}
	
	return true;
}

/**
 * Admin notice for missing ViraStore plugin.
 *
 * @since 1.0.0
 */
function virastore_paypal_missing_virastore_notice() {
	$message = sprintf(
		/* translators: %s: ViraStore plugin link */
		__( 'ViraStore PayPal Payment Gateway requires ViraStore plugin to be installed and activated. Please %s plugin.', 'virastore-paypal' ),
		'<a href="' . esc_url( admin_url( 'plugin-install.php?s=virastore&tab=search&type=term' ) ) . '">' . __( 'install', 'virastore-paypal' ) . '</a>'
	);

	echo '<div class="notice notice-error"><p>' . wp_kses_post( $message ) . '</p></div>';
}

/**
 * Initialize plugin.
 *
 * @since 1.0.0
 */
function virastore_paypal_init() {
	// First check: Basic plugin activation check (doesn't require classes to be loaded)
	if ( ! is_plugin_active( 'vira-store/vira-store.php' ) && ! class_exists( 'Vira_Store' ) ) {
		// Main plugin not active - show notice and abort
		add_action( 'admin_notices', 'virastore_paypal_missing_virastore_notice' );
		return;
	}

	// Include main plugin class.
	require_once VIRASTORE_PAYPAL_PLUGIN_DIR . 'includes/class-virastore-paypal.php';

	// Include required files.
	require_once VIRASTORE_PAYPAL_PLUGIN_DIR . 'includes/class-payment-processor.php';
	require_once VIRASTORE_PAYPAL_PLUGIN_DIR . 'includes/class-payment-form.php';
	require_once VIRASTORE_PAYPAL_PLUGIN_DIR . 'includes/class-settings.php';
	require_once VIRASTORE_PAYPAL_PLUGIN_DIR . 'includes/class-webhook-handler.php';
	require_once VIRASTORE_PAYPAL_PLUGIN_DIR . 'includes/class-hooks.php';

	// Initialize plugin - MUST happen early to register gateway filter before main plugin initializes gateways
	// Priority 5 ensures this runs before default priority 10, allowing gateway registration to happen in time
	ViraStore_PayPal::get_instance();

	$payment_form = new ViraStore_PayPal_Payment_Form();

	new ViraStore_PayPal_Settings();
	new ViraStore_PayPal_Webhook_Handler();
	new ViraStore_PayPal_Hooks( $payment_form );
}
// Use priority 5 to ensure PayPal addon initializes before main plugin processes gateways
// This is critical for the gateway registration filter to be active when init_gateways() runs
add_action( 'plugins_loaded', 'virastore_paypal_init', 5 );