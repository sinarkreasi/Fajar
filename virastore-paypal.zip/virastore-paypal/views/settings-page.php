<?php
/**
 * Settings Page Template
 *
 * @package ViraStore_PayPal
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Get test mode.
$test_mode = get_option( 'virastore_paypal_test_mode', false );
?>

<div class="wrap">
	<h1><?php esc_html_e( 'PayPal Settings', 'virastore-paypal' ); ?></h1>
	
	<?php settings_errors(); ?>
	
	<div class="virastore-paypal-settings-section">
		<form method="post" action="options.php">
			<?php
			// Output security fields
			settings_fields( 'virastore-paypal-settings' );
			
			// Output setting sections
			do_settings_sections( 'virastore-paypal-settings' );
			
			// Output submit button
			submit_button();
			?>
		</form>
	</div>
	
	<div class="virastore-paypal-settings-section">
		<h2><?php esc_html_e( 'PayPal Webhook Setup', 'virastore-paypal' ); ?></h2>
		<p><?php esc_html_e( 'To receive payment notifications, you need to set up a webhook in your PayPal account.', 'virastore-paypal' ); ?></p>
		
		<div class="virastore-paypal-settings-field">
			<label><?php esc_html_e( 'Webhook URL', 'virastore-paypal' ); ?></label>
			<input type="text" readonly value="<?php echo esc_url( home_url( '/virastore-paypal-webhook' ) ); ?>" class="regular-text" onclick="this.select();" />
			<p class="description"><?php esc_html_e( 'Copy this URL and add it to your PayPal webhook settings.', 'virastore-paypal' ); ?></p>
		</div>
		
		<div class="virastore-paypal-settings-field">
			<label><?php esc_html_e( 'Events to Subscribe', 'virastore-paypal' ); ?></label>
			<ul>
				<li><?php esc_html_e( 'PAYMENT.CAPTURE.COMPLETED', 'virastore-paypal' ); ?></li>
				<li><?php esc_html_e( 'PAYMENT.CAPTURE.DENIED', 'virastore-paypal' ); ?></li>
				<li><?php esc_html_e( 'PAYMENT.CAPTURE.REFUNDED', 'virastore-paypal' ); ?></li>
			</ul>
		</div>
	</div>
	
	<div class="virastore-paypal-settings-section">
		<h2><?php esc_html_e( 'Documentation', 'virastore-paypal' ); ?></h2>
		<p><?php esc_html_e( 'For more information on how to set up and use the PayPal payment gateway, please refer to the documentation.', 'virastore-paypal' ); ?></p>
		<p><a href="https://developer.paypal.com/docs/" target="_blank" class="button"><?php esc_html_e( 'PayPal Developer Documentation', 'virastore-paypal' ); ?></a></p>
	</div>
</div>