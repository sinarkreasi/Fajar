<?php
/**
 * Payment Instructions Template
 *
 * @package ViraStore_PayPal
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Get order data.
$order_id = isset( $order_data['order_id'] ) ? $order_data['order_id'] : 0;
$transaction_id = isset( $order_data['transaction_id'] ) ? $order_data['transaction_id'] : '';
$status = isset( $order_data['status'] ) ? $order_data['status'] : '';

// Get test mode.
$test_mode = get_option( 'virastore_paypal_test_mode', false );
?>

<div class="virastore-paypal-payment-instructions">
	<h3><?php esc_html_e( 'Payment Details', 'virastore-paypal' ); ?></h3>
	
	<?php if ( $test_mode ) : ?>
		<div class="virastore-paypal-test-mode-notice">
			<p><?php esc_html_e( 'Test Mode: This payment was processed in sandbox mode.', 'virastore-paypal' ); ?></p>
		</div>
	<?php endif; ?>
	
	<ul class="virastore-paypal-payment-details">
		<li>
			<strong><?php esc_html_e( 'Payment Method:', 'virastore-paypal' ); ?></strong>
			<?php esc_html_e( 'PayPal', 'virastore-paypal' ); ?>
		</li>
		
		<?php if ( ! empty( $transaction_id ) ) : ?>
			<li>
				<strong><?php esc_html_e( 'Transaction ID:', 'virastore-paypal' ); ?></strong>
				<?php echo esc_html( $transaction_id ); ?>
			</li>
		<?php endif; ?>
		
		<?php if ( ! empty( $status ) ) : ?>
			<li>
				<strong><?php esc_html_e( 'Payment Status:', 'virastore-paypal' ); ?></strong>
				<?php echo esc_html( $status ); ?>
			</li>
		<?php endif; ?>
	</ul>
	
	<?php if ( 'completed' === $status ) : ?>
		<div class="virastore-paypal-payment-success">
			<p><?php esc_html_e( 'Your payment has been processed successfully.', 'virastore-paypal' ); ?></p>
		</div>
	<?php elseif ( 'pending' === $status ) : ?>
		<div class="virastore-paypal-payment-pending">
			<p><?php esc_html_e( 'Your payment is pending. We will update your order status once the payment is completed.', 'virastore-paypal' ); ?></p>
		</div>
	<?php elseif ( 'failed' === $status ) : ?>
		<div class="virastore-paypal-payment-failed">
			<p><?php esc_html_e( 'Your payment has failed. Please try again or contact us for assistance.', 'virastore-paypal' ); ?></p>
		</div>
	<?php endif; ?>
</div>