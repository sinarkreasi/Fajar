<?php
/**
 * Payment Form Template
 *
 * @package ViraStore_PayPal
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Get test mode.
$test_mode = get_option( 'virastore_paypal_test_mode', false );

// Get client ID.
$client_id = $test_mode
	? get_option( 'virastore_paypal_sandbox_client_id', '' )
	: get_option( 'virastore_paypal_client_id', '' );

// Check if client ID is set.
if ( empty( $client_id ) ) {
	echo '<div class="virastore-paypal-error">';
	echo esc_html__( 'PayPal is not configured properly. Please contact the site administrator.', 'virastore-paypal' );
	echo '</div>';
	return;
}

// Get order data.
$order_id = isset( $payment_data['order_id'] ) ? $payment_data['order_id'] : 0;
$amount = isset( $payment_data['amount'] ) ? $payment_data['amount'] : 0;
$currency = isset( $payment_data['currency'] ) ? $payment_data['currency'] : 'USD';
$return_url = isset( $payment_data['return_url'] ) ? $payment_data['return_url'] : home_url();
$cancel_url = isset( $payment_data['cancel_url'] ) ? $payment_data['cancel_url'] : home_url();

// Get payment description.
$description = get_option( 'virastore_paypal_description', __( 'Pay via PayPal; you can pay with your credit card if you don\'t have a PayPal account.', 'virastore-paypal' ) );
?>

<div class="virastore-paypal-payment-form">
	<?php if ( $description ) : ?>
		<p class="virastore-paypal-description"><?php echo wp_kses_post( $description ); ?></p>
	<?php endif; ?>

	<?php if ( $test_mode ) : ?>
		<div class="virastore-paypal-test-mode-notice">
			<p><?php esc_html_e( 'PayPal is in test mode. You can use the sandbox account to test payments.', 'virastore-paypal' ); ?></p>
		</div>
	<?php endif; ?>

	<div id="vrstore-paypal-button-container"></div>

	<div id="virastore-paypal-processing" style="display: none;">
		<p><?php esc_html_e( 'Processing payment, please wait...', 'virastore-paypal' ); ?></p>
	</div>

	<div id="virastore-paypal-error" class="virastore-paypal-error" style="display: none;"></div>

	<script>
		document.addEventListener('DOMContentLoaded', function() {
			// Load PayPal SDK.
			var script = document.createElement('script');
			script.src = 'https://www.paypal.com/sdk/js?client-id=<?php echo esc_js( $client_id ); ?>&currency=<?php echo esc_js( $currency ); ?>';
			script.setAttribute('data-namespace', 'paypalSDK');
			script.onload = function() {
				// Initialize PayPal buttons.
				paypalSDK.Buttons({
					// Set up the transaction.
					createOrder: function(data, actions) {
						return actions.order.create({
							purchase_units: [{
								amount: {
									value: '<?php echo esc_js( $amount ); ?>',
									currency_code: '<?php echo esc_js( $currency ); ?>'
								},
								custom_id: '<?php echo esc_js( $order_id ); ?>'
							}]
						});
					},
					// Finalize the transaction.
					onApprove: function(data, actions) {
						// Show processing message.
						document.getElementById('vrstore-paypal-button-container').style.display = 'none';
						document.getElementById('virastore-paypal-processing').style.display = 'block';

						// Submit form with PayPal order ID.
						var formData = new FormData();
						formData.append('action', 'virastore_paypal_process_payment');
						formData.append('nonce', '<?php echo esc_js( wp_create_nonce( 'virastore_paypal_nonce' ) ); ?>');
						formData.append('payment_data', JSON.stringify({
							order_id: '<?php echo esc_js( $order_id ); ?>',
							amount: '<?php echo esc_js( $amount ); ?>',
							paypal_order_id: data.orderID
						}));

						// Send AJAX request.
						fetch(virastore_paypal.ajax_url, {
							method: 'POST',
							body: formData
						})
						.then(function(response) {
							return response.json();
						})
						.then(function(result) {
							if (result.success) {
								// Redirect to thank you page.
								window.location.href = result.data.redirect_url || '<?php echo esc_js( $return_url ); ?>';
							} else {
								// Show error message.
								document.getElementById('virastore-paypal-processing').style.display = 'none';
								var errorElement = document.getElementById('virastore-paypal-error');
								errorElement.textContent = result.data.message || 'Payment failed.';
							errorElement.style.display = 'block';
							document.getElementById('vrstore-paypal-button-container').style.display = 'block';
							}
						})
						.catch(function(error) {
							// Show error message.
							document.getElementById('virastore-paypal-processing').style.display = 'none';
							var errorElement = document.getElementById('virastore-paypal-error');
							errorElement.textContent = 'Error: ' + error;
							errorElement.style.display = 'block';
							document.getElementById('vrstore-paypal-button-container').style.display = 'block';
						});
					},
					onCancel: function() {
						// Redirect to cancel URL.
						window.location.href = '<?php echo esc_js( $cancel_url ); ?>';
					},
					onError: function(err) {
						// Show error message.
						var errorElement = document.getElementById('virastore-paypal-error');
						errorElement.textContent = 'Error: ' + err;
						errorElement.style.display = 'block';
					}
				}).render('#vrstore-paypal-button-container');
			};
			document.head.appendChild(script);
		});
	</script>
</div>