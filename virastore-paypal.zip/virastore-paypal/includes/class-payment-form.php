<?php
/**
 * Payment Form Class
 *
 * @package ViraStore_PayPal
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ViraStore_PayPal_Payment_Form
 *
 * Handles the payment form rendering and processing.
 *
 * @since 1.0.0
 */
class ViraStore_PayPal_Payment_Form {

	/**
	 * Render payment form.
	 *
	 * @since 1.0.0
	 * @param array $payment_data Payment form arguments.
	 */
	public function render( $payment_data ) {
		$defaults = array(
			'order_id'   => 0,
			'amount'     => 0,
			'currency'   => 'USD',
			'return_url' => home_url(),
			'cancel_url' => home_url(),
		);

		$payment_data = wp_parse_args( (array) $payment_data, $defaults );

		include VIRASTORE_PAYPAL_PLUGIN_DIR . 'views/payment-form.php';
	}
}