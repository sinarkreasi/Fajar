<?php
/**
 * Payment Processor Class
 *
 * @package ViraStore_PayPal
 */

// Exit if accessed directly.
if (!defined("ABSPATH")) {
    exit();
}

/**
 * ViraStore_PayPal_Payment_Processor Class
 *
 * @since 1.0.0
 */
class ViraStore_PayPal_Payment_Processor
{
    /**
     * API base URL.
     *
     * @since 1.0.0
     * @var string
     */
    private $api_url;

    /**
     * Client ID.
     *
     * @since 1.0.0
     * @var string
     */
    private $client_id;

    /**
     * Client secret.
     *
     * @since 1.0.0
     * @var string
     */
    private $client_secret;

    /**
     * Test mode.
     *
     * @since 1.0.0
     * @var bool
     */
    private $test_mode;

    /**
     * Constructor.
     *
     * @since 1.0.0
     */
    public function __construct()
    {
        // Get test mode.
        $this->test_mode = get_option("virastore_paypal_test_mode", false);

        // Set API URL based on test mode.
        $this->api_url = $this->test_mode
            ? "https://api-m.sandbox.paypal.com"
            : "https://api-m.paypal.com";

        // Set client ID and secret based on test mode.
        if ($this->test_mode) {
            $this->client_id = get_option(
                "virastore_paypal_sandbox_client_id",
                "",
            );
            $this->client_secret = get_option(
                "virastore_paypal_sandbox_client_secret",
                "",
            );
        } else {
            $this->client_id = get_option("virastore_paypal_client_id", "");
            $this->client_secret = get_option(
                "virastore_paypal_client_secret",
                "",
            );
        }
    }

    /**
     * Process payment.
     *
     * @since 1.0.0
     * @param array $payment_data Payment data.
     * @return array
     */
    public function process($payment_data)
    {
        // Log the incoming payment data for debugging
        error_log(
            "ViraStore PayPal Processor: Received payment data: " .
                print_r($payment_data, true),
        );

        // Check if client ID and secret are set.
        if (empty($this->client_id) || empty($this->client_secret)) {
            error_log("ViraStore PayPal ERROR: API credentials not configured");
            return [
                "success" => false,
                "message" => __(
                    "PayPal API credentials are not configured. Please contact the administrator.",
                    "virastore-paypal",
                ),
            ];
        }

        // Check if this is a capture request (has paypal_order_id) or initial setup
        if (isset($payment_data["paypal_order_id"])) {
            error_log(
                "ViraStore PayPal: Processing payment CAPTURE for PayPal Order ID: " .
                    $payment_data["paypal_order_id"],
            );
            return $this->capture_payment_flow($payment_data);
        } else {
            error_log(
                "ViraStore PayPal: Processing INITIAL payment setup (showing PayPal button)",
            );
            return $this->initial_payment_flow($payment_data);
        }
    }

    /**
     * Handle initial payment flow - prepare data for PayPal button display.
     *
     * @since 1.0.0
     * @param array $payment_data Payment data.
     * @return array
     */
    private function initial_payment_flow($payment_data)
    {
        // Validate required data for initial flow
        if (!isset($payment_data["order_id"])) {
            error_log(
                "ViraStore PayPal ERROR: order_id missing in payment data",
            );
            return [
                "success" => false,
                "message" => __("Order ID is required.", "virastore-paypal"),
            ];
        }

        // Get amount - check multiple field names with better handling
        // Priority: amount > total > order_total > order_data[total]
        $raw_amount = null;
        if (isset($payment_data["amount"]) && !empty($payment_data["amount"])) {
            $raw_amount = $payment_data["amount"];
        } elseif (isset($payment_data["total"]) && !empty($payment_data["total"])) {
            $raw_amount = $payment_data["total"];
        } elseif (isset($payment_data["order_total"]) && !empty($payment_data["order_total"])) {
            $raw_amount = $payment_data["order_total"];
        } elseif (isset($payment_data["order_data"]["total"]) && !empty($payment_data["order_data"]["total"])) {
            $raw_amount = $payment_data["order_data"]["total"];
        } else {
            // Final fallback: try to get from order directly if order_id is available
            if (isset($payment_data["order_id"])) {
                $order_id = absint($payment_data["order_id"]);
                if ($order_id > 0 && class_exists("VRSTORE_Order")) {
                    $order = VRSTORE_Order::get_order($order_id);
                    if ($order && isset($order["total"])) {
                        $raw_amount = $order["total"];
                        error_log(
                            "ViraStore PayPal Processor: Retrieved amount from order - Order ID: " .
                                $order_id .
                                ", Amount: " .
                                $raw_amount,
                        );
                    }
                }
            }
        }

        error_log(
            "ViraStore PayPal Processor: Raw amount data: " .
                var_export($raw_amount, true) .
                " (type: " .
                gettype($raw_amount) .
                ")",
        );

        // Handle potential array or complex data from currency conversion
        if (is_array($raw_amount)) {
            // Currency converter might return array, extract numeric value
            if (isset($raw_amount[0]) && is_numeric($raw_amount[0])) {
                $amount = floatval($raw_amount[0]);
            } elseif (
                isset($raw_amount["amount"]) &&
                is_numeric($raw_amount["amount"])
            ) {
                $amount = floatval($raw_amount["amount"]);
            } elseif (
                isset($raw_amount["total"]) &&
                is_numeric($raw_amount["total"])
            ) {
                $amount = floatval($raw_amount["total"]);
            } else {
                $amount = 0;
            }
            error_log(
                "ViraStore PayPal Processor: Extracted amount from array: " .
                    $amount,
            );
        } elseif (is_string($raw_amount) && is_numeric($raw_amount)) {
            $amount = floatval($raw_amount);
        } elseif (is_numeric($raw_amount)) {
            $amount = floatval($raw_amount);
        } else {
            $amount = 0;
        }

        if ($amount <= 0) {
            error_log(
                "ViraStore PayPal ERROR: Invalid amount - Raw data: " .
                    var_export($raw_amount, true) .
                    ", Processed amount: " .
                    var_export($amount, true) .
                    ", Full payment data: " .
                    print_r($payment_data, true),
            );
            return [
                "success" => false,
                "message" => __(
                    "Invalid payment amount. Please refresh the page and try again.",
                    "virastore-paypal",
                ),
            ];
        }

        $order_id = absint($payment_data["order_id"]);
        $currency = isset($payment_data["currency"])
            ? $payment_data["currency"]
            : "USD";

        error_log(
            sprintf(
                "ViraStore PayPal: Initial flow - Order ID: %d, Amount: %.2f %s",
                $order_id,
                $amount,
                $currency,
            ),
        );

        // Return success with instruction to show PayPal button
        // This tells the system to display the payment form instead of trying to capture
        return [
            "success" => true,
            "show_form" => true,
            "order_id" => $order_id,
            "amount" => $amount,
            "currency" => $currency,
            "return_url" => $this->get_thank_you_url($order_id),
            "cancel_url" => isset($payment_data["cancel_url"])
                ? $payment_data["cancel_url"]
                : home_url(),
            "message" => __(
                "Please complete payment using PayPal.",
                "virastore-paypal",
            ),
        ];
    }

    /**
     * Handle payment capture flow - called after user approves payment on PayPal.
     *
     * @since 1.0.0
     * @param array $payment_data Payment data including paypal_order_id.
     * @return array
     */
    private function capture_payment_flow($payment_data)
    {
        // Validate required fields
        if (
            !isset($payment_data["order_id"]) ||
            !isset($payment_data["paypal_order_id"])
        ) {
            error_log(
                "ViraStore PayPal ERROR: Missing order_id or paypal_order_id for capture",
            );
            return [
                "success" => false,
                "message" => __(
                    "Required payment information is missing.",
                    "virastore-paypal",
                ),
            ];
        }

        $order_id = sanitize_text_field($payment_data["order_id"]);
        $paypal_order_id = sanitize_text_field(
            $payment_data["paypal_order_id"],
        );

        error_log(
            sprintf(
                "ViraStore PayPal: Capturing payment - Order ID: %s, PayPal Order ID: %s",
                $order_id,
                $paypal_order_id,
            ),
        );

        // Capture the payment.
        $response = $this->capture_payment($paypal_order_id);

        // Check if payment was successful.
        if (isset($response["status"]) && "COMPLETED" === $response["status"]) {
            // Get transaction ID.
            $transaction_id = isset(
                $response["purchase_units"][0]["payments"]["captures"][0]["id"],
            )
                ? $response["purchase_units"][0]["payments"]["captures"][0][
                    "id"
                ]
                : "";

            error_log(
                sprintf(
                    "ViraStore PayPal SUCCESS: Payment captured - Transaction ID: %s",
                    $transaction_id,
                ),
            );

            // Update order status.
            $this->update_order_status($order_id, "completed", $transaction_id);

            return [
                "success" => true,
                "message" => __(
                    "Payment completed successfully.",
                    "virastore-paypal",
                ),
                "transaction_id" => $transaction_id,
                "redirect_url" => $this->get_thank_you_url($order_id),
            ];
        } else {
            // Get error message.
            $error_message = isset($response["message"])
                ? $response["message"]
                : __("Payment failed.", "virastore-paypal");

            error_log(
                "ViraStore PayPal ERROR: Payment capture failed - " .
                    $error_message,
            );
            error_log(
                "ViraStore PayPal ERROR: Full response: " .
                    print_r($response, true),
            );

            return [
                "success" => false,
                "message" => $error_message,
            ];
        }
    }

    /**
     * Get access token.
     *
     * @since 1.0.0
     * @return string|WP_Error
     */
    private function get_access_token()
    {
        // Check if we have a cached token.
        $token = get_transient("virastore_paypal_access_token");
        if ($token) {
            return $token;
        }

        // Prepare request.
        $args = [
            "method" => "POST",
            "headers" => [
                "Authorization" =>
                    "Basic " .
                    base64_encode(
                        $this->client_id . ":" . $this->client_secret,
                    ),
                "Content-Type" => "application/x-www-form-urlencoded",
            ],
            "body" => "grant_type=client_credentials",
        ];

        // Make request.
        $response = wp_remote_post($this->api_url . "/v1/oauth2/token", $args);

        // Check for errors.
        if (is_wp_error($response)) {
            return $response;
        }

        // Parse response.
        $body = json_decode(wp_remote_retrieve_body($response), true);

        // Check if we got an access token.
        if (!isset($body["access_token"])) {
            return new WP_Error(
                "paypal_error",
                __("Failed to get access token.", "virastore-paypal"),
            );
        }

        // Cache token.
        $expires_in = isset($body["expires_in"])
            ? intval($body["expires_in"])
            : 3600;
        set_transient(
            "virastore_paypal_access_token",
            $body["access_token"],
            $expires_in - 60,
        );

        return $body["access_token"];
    }

    /**
     * Capture payment.
     *
     * @since 1.0.0
     * @param string $order_id PayPal order ID.
     * @return array|WP_Error
     */
    private function capture_payment($order_id)
    {
        // Get access token.
        $token = $this->get_access_token();
        if (is_wp_error($token)) {
            return [
                "success" => false,
                "message" => $token->get_error_message(),
            ];
        }

        // Prepare request.
        $args = [
            "method" => "POST",
            "headers" => [
                "Authorization" => "Bearer " . $token,
                "Content-Type" => "application/json",
            ],
        ];

        // Make request.
        $response = wp_remote_post(
            $this->api_url . "/v2/checkout/orders/" . $order_id . "/capture",
            $args,
        );

        // Check for errors.
        if (is_wp_error($response)) {
            return [
                "success" => false,
                "message" => $response->get_error_message(),
            ];
        }

        // Parse response.
        $body = json_decode(wp_remote_retrieve_body($response), true);

        return $body;
    }

    /**
     * Update order status.
     *
     * @since 1.0.0
     * @param string $order_id      Order ID.
     * @param string $status        Order status.
     * @param string $transaction_id Transaction ID.
     */
    private function update_order_status($order_id, $status, $transaction_id)
    {
        // Check if VRSTORE_Order class exists.
        if (!class_exists("VRSTORE_Order")) {
            return;
        }

        // Update order status using static method
        VRSTORE_Order::update_order_status(absint($order_id), $status);

        // Add transaction ID and payment method to order meta using WordPress post meta
        // (VRSTORE_Order doesn't have update_meta method, so use WP post meta directly)
        $order_id_int = absint($order_id);
        if ($order_id_int > 0) {
            update_post_meta($order_id_int, "vrstore_transaction_id", sanitize_text_field($transaction_id));
            update_post_meta($order_id_int, "vrstore_payment_method", "paypal");
        }
    }

    /**
     * Get thank you URL.
     *
     * @since 1.0.0
     * @param string $order_id Order ID.
     * @return string
     */
    private function get_thank_you_url($order_id)
    {
        // Get thank you page URL - no need to instantiate VRSTORE_Order
        $thank_you_page_id = get_option("vrstore_thank_you_page", 0);
        if ($thank_you_page_id) {
            $thank_you_url = get_permalink($thank_you_page_id);
            if ($thank_you_url) {
                $thank_you_url = add_query_arg(
                    "order_id",
                    absint($order_id),
                    $thank_you_url,
                );
                return $thank_you_url;
            }
        }

        return home_url();
    }
}
