<?php
/**
 * Settings Class
 *
 * @package ViraStore_PayPal
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ViraStore_PayPal_Settings Class
 *
 * @since 1.0.0
 */
class ViraStore_PayPal_Settings {

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		// Register settings.
		add_action( 'admin_init', array( $this, 'register_settings' ) );
	}

	/**
	 * Register settings.
	 *
	 * @since 1.0.0
	 */
	public function register_settings() {
		// Register settings section.
		add_settings_section(
			'virastore_paypal_settings',
			__( 'PayPal Settings', 'virastore-paypal' ),
			array( $this, 'settings_section_callback' ),
			'virastore-paypal-settings'
		);

		// Register settings fields.
		$this->register_settings_fields();
	}

	/**
	 * Settings section callback.
	 *
	 * @since 1.0.0
	 */
	public function settings_section_callback() {
		echo '<p>' . esc_html__( 'Configure your PayPal payment gateway settings below.', 'virastore-paypal' ) . '</p>';
	}

	/**
	 * Register settings fields.
	 *
	 * @since 1.0.0
	 */
	private function register_settings_fields() {
		// Enable/disable payment method.
		register_setting(
			'virastore-paypal-settings',
			'virastore_paypal_enabled',
			array(
				'type'              => 'boolean',
				'sanitize_callback' => 'rest_sanitize_boolean',
				'default'           => false,
			)
		);

		add_settings_field(
			'virastore_paypal_enabled',
			__( 'Enable PayPal', 'virastore-paypal' ),
			array( $this, 'checkbox_field_callback' ),
			'virastore-paypal-settings',
			'virastore_paypal_settings',
			array(
				'id'          => 'virastore_paypal_enabled',
				'description' => __( 'Enable PayPal as a payment method.', 'virastore-paypal' ),
			)
		);

		// Test mode.
		register_setting(
			'virastore-paypal-settings',
			'virastore_paypal_test_mode',
			array(
				'type'              => 'boolean',
				'sanitize_callback' => 'rest_sanitize_boolean',
				'default'           => true,
			)
		);

		add_settings_field(
			'virastore_paypal_test_mode',
			__( 'Test Mode', 'virastore-paypal' ),
			array( $this, 'checkbox_field_callback' ),
			'virastore-paypal-settings',
			'virastore_paypal_settings',
			array(
				'id'          => 'virastore_paypal_test_mode',
				'description' => __( 'Enable test mode to use PayPal sandbox for testing.', 'virastore-paypal' ),
			)
		);

		// Live credentials.
		register_setting(
			'virastore-paypal-settings',
			'virastore_paypal_client_id',
			array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
				'default'           => '',
			)
		);

		add_settings_field(
			'virastore_paypal_client_id',
			__( 'Live Client ID', 'virastore-paypal' ),
			array( $this, 'text_field_callback' ),
			'virastore-paypal-settings',
			'virastore_paypal_settings',
			array(
				'id'          => 'virastore_paypal_client_id',
				'description' => __( 'Enter your PayPal live client ID.', 'virastore-paypal' ),
				'class'       => 'regular-text',
			)
		);

		register_setting(
			'virastore-paypal-settings',
			'virastore_paypal_client_secret',
			array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
				'default'           => '',
			)
		);

		add_settings_field(
			'virastore_paypal_client_secret',
			__( 'Live Client Secret', 'virastore-paypal' ),
			array( $this, 'password_field_callback' ),
			'virastore-paypal-settings',
			'virastore_paypal_settings',
			array(
				'id'          => 'virastore_paypal_client_secret',
				'description' => __( 'Enter your PayPal live client secret.', 'virastore-paypal' ),
				'class'       => 'regular-text',
			)
		);

		// Sandbox credentials.
		register_setting(
			'virastore-paypal-settings',
			'virastore_paypal_sandbox_client_id',
			array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
				'default'           => '',
			)
		);

		add_settings_field(
			'virastore_paypal_sandbox_client_id',
			__( 'Sandbox Client ID', 'virastore-paypal' ),
			array( $this, 'text_field_callback' ),
			'virastore-paypal-settings',
			'virastore_paypal_settings',
			array(
				'id'          => 'virastore_paypal_sandbox_client_id',
				'description' => __( 'Enter your PayPal sandbox client ID.', 'virastore-paypal' ),
				'class'       => 'regular-text',
			)
		);

		register_setting(
			'virastore-paypal-settings',
			'virastore_paypal_sandbox_client_secret',
			array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
				'default'           => '',
			)
		);

		add_settings_field(
			'virastore_paypal_sandbox_client_secret',
			__( 'Sandbox Client Secret', 'virastore-paypal' ),
			array( $this, 'password_field_callback' ),
			'virastore-paypal-settings',
			'virastore_paypal_settings',
			array(
				'id'          => 'virastore_paypal_sandbox_client_secret',
				'description' => __( 'Enter your PayPal sandbox client secret.', 'virastore-paypal' ),
				'class'       => 'regular-text',
			)
		);

		// Payment title.
		register_setting(
			'virastore-paypal-settings',
			'virastore_paypal_title',
			array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
				'default'           => __( 'PayPal', 'virastore-paypal' ),
			)
		);

		add_settings_field(
			'virastore_paypal_title',
			__( 'Payment Title', 'virastore-paypal' ),
			array( $this, 'text_field_callback' ),
			'virastore-paypal-settings',
			'virastore_paypal_settings',
			array(
				'id'          => 'virastore_paypal_title',
				'description' => __( 'This controls the title which the user sees during checkout.', 'virastore-paypal' ),
				'class'       => 'regular-text',
			)
		);

		// Payment description.
		register_setting(
			'virastore-paypal-settings',
			'virastore_paypal_description',
			array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_textarea_field',
				'default'           => __( 'Pay via PayPal; you can pay with your credit card if you don\'t have a PayPal account.', 'virastore-paypal' ),
			)
		);

		add_settings_field(
			'virastore_paypal_description',
			__( 'Payment Description', 'virastore-paypal' ),
			array( $this, 'textarea_field_callback' ),
			'virastore-paypal-settings',
			'virastore_paypal_settings',
			array(
				'id'          => 'virastore_paypal_description',
				'description' => __( 'This controls the description which the user sees during checkout.', 'virastore-paypal' ),
				'class'       => 'regular-text',
			)
		);
	}

	/**
	 * Checkbox field callback.
	 *
	 * @since 1.0.0
	 * @param array $args Field arguments.
	 */
	public function checkbox_field_callback( $args ) {
		$id          = $args['id'];
		$description = isset( $args['description'] ) ? $args['description'] : '';
		$value       = get_option( $id, false );
		?>
		<label for="<?php echo esc_attr( $id ); ?>">
			<input type="checkbox" name="<?php echo esc_attr( $id ); ?>" id="<?php echo esc_attr( $id ); ?>" value="1" <?php checked( $value, true ); ?> />
			<?php echo esc_html( $description ); ?>
		</label>
		<?php
	}

	/**
	 * Text field callback.
	 *
	 * @since 1.0.0
	 * @param array $args Field arguments.
	 */
	public function text_field_callback( $args ) {
		$id          = $args['id'];
		$class       = isset( $args['class'] ) ? $args['class'] : 'regular-text';
		$description = isset( $args['description'] ) ? $args['description'] : '';
		$value       = get_option( $id, '' );
		?>
		<input type="text" name="<?php echo esc_attr( $id ); ?>" id="<?php echo esc_attr( $id ); ?>" value="<?php echo esc_attr( $value ); ?>" class="<?php echo esc_attr( $class ); ?>" />
		<?php if ( $description ) : ?>
			<p class="description"><?php echo esc_html( $description ); ?></p>
		<?php endif; ?>
		<?php
	}

	/**
	 * Password field callback.
	 *
	 * @since 1.0.0
	 * @param array $args Field arguments.
	 */
	public function password_field_callback( $args ) {
		$id          = $args['id'];
		$class       = isset( $args['class'] ) ? $args['class'] : 'regular-text';
		$description = isset( $args['description'] ) ? $args['description'] : '';
		$value       = get_option( $id, '' );
		?>
		<input type="password" name="<?php echo esc_attr( $id ); ?>" id="<?php echo esc_attr( $id ); ?>" value="<?php echo esc_attr( $value ); ?>" class="<?php echo esc_attr( $class ); ?>" />
		<?php if ( $description ) : ?>
			<p class="description"><?php echo esc_html( $description ); ?></p>
		<?php endif; ?>
		<?php
	}

	/**
	 * Textarea field callback.
	 *
	 * @since 1.0.0
	 * @param array $args Field arguments.
	 */
	public function textarea_field_callback( $args ) {
		$id          = $args['id'];
		$class       = isset( $args['class'] ) ? $args['class'] : 'regular-text';
		$description = isset( $args['description'] ) ? $args['description'] : '';
		$value       = get_option( $id, '' );
		?>
		<textarea name="<?php echo esc_attr( $id ); ?>" id="<?php echo esc_attr( $id ); ?>" class="<?php echo esc_attr( $class ); ?>" rows="5"><?php echo esc_textarea( $value ); ?></textarea>
		<?php if ( $description ) : ?>
			<p class="description"><?php echo esc_html( $description ); ?></p>
		<?php endif; ?>
		<?php
	}

	/**
	 * Render settings page.
	 *
	 * @since 1.0.0
	 */
	public function render_settings_page() {
		// Check user capabilities.
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		// Add settings errors.
		settings_errors( 'virastore-paypal-settings' );
		?>
		<div class="wrap">
			<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
			<form action="options.php" method="post">
				<?php
				// Output security fields.
				settings_fields( 'virastore-paypal-settings' );

				// Output setting sections.
				do_settings_sections( 'virastore-paypal-settings' );

				// Output save settings button.
				submit_button( __( 'Save Settings', 'virastore-paypal' ) );
				?>
			</form>
		</div>
		<?php
	}
}