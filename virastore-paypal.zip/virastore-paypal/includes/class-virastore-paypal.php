<?php
/**
 * Main ViraStore PayPal Class
 *
 * @package ViraStore_PayPal
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ViraStore_PayPal Class
 *
 * @since 1.0.0
 */
class ViraStore_PayPal {

	/**
	 * Instance of this class.
	 *
	 * @since 1.0.0
	 * @var ViraStore_PayPal
	 */
	protected static $instance = null;

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		// Register hooks for payment gateway with higher priority to ensure it runs before gateway initialization
		// Priority 5 ensures this runs before default priority 10 hooks
		add_filter( 'vrstore_payment_gateways', array( $this, 'register_payment_gateway' ), 5 );

		// Load text domain.
		add_action( 'init', array( $this, 'load_textdomain' ) );
	}

	/**
	 * Get instance of this class.
	 *
	 * @since 1.0.0
	 * @return ViraStore_PayPal
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Register PayPal payment gateway.
	 *
	 * @since 1.0.0
	 * @param array $gateways Payment gateways.
	 * @return array
	 */
	public function register_payment_gateway( $gateways ) {
		// Check if icon file exists, fallback to 'paypal' string if not
		$icon_path = VIRASTORE_PAYPAL_PLUGIN_DIR . 'assets/images/paypal.svg';
		$icon_url = VIRASTORE_PAYPAL_PLUGIN_URL . 'assets/images/paypal.svg';
		
		// Use 'paypal' string as fallback if icon file doesn't exist (matches main plugin pattern)
		$icon = file_exists( $icon_path ) ? $icon_url : 'paypal';
		
		$gateways['paypal'] = array(
			'name'        => $this->get_translated_text( 'PayPal' ),
			'description' => $this->get_translated_text( 'Pay securely with your PayPal account or credit card.' ),
			'icon'        => $icon,
			'enabled'     => true, // Always mark as enabled when addon is active
			'callback'    => array( $this, 'process_payment' ),
			'form'        => 'virastore_paypal_payment_form',
		);

		return $gateways;
	}

	/**
	 * Get translated text with conditional loading check.
	 *
	 * @since 1.0.0
	 * @param string $text The text to translate.
	 * @return string
	 */
	public function get_translated_text( $text ) {
		if ( function_exists( 'vrstore_is_textdomain_ready' ) && vrstore_is_textdomain_ready() ) {
			return esc_html__( $text, 'virastore-paypal' );
		}
		return esc_html( $text );
	}

	/**
	 * Load plugin text domain.
	 *
	 * @since 1.0.0
	 */
	public function load_textdomain() {
		load_plugin_textdomain( 'virastore-paypal', false, dirname( plugin_basename( VIRASTORE_PAYPAL_PLUGIN_FILE ) ) . '/languages' );
	}

	/**
	 * Process PayPal payment.
	 *
	 * @since 1.0.0
	 * @param array $payment_data Payment data.
	 * @return array
	 */
	public function process_payment( $payment_data ) {
		// Get payment processor instance.
		$payment_processor = new ViraStore_PayPal_Payment_Processor();

		// Process payment.
		return $payment_processor->process( $payment_data );
	}
}