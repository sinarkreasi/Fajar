<?php
/**
 * Hooks Class
 *
 * @package ViraStore_PayPal
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ViraStore_PayPal_Hooks
 *
 * Handles the integration with ViraStore plugin through hooks.
 *
 * @since 1.0.0
 */
class ViraStore_PayPal_Hooks {

	/**
	 * Payment form handler instance.
	 *
	 * @since 1.0.0
	 * @var ViraStore_PayPal_Payment_Form
	 */
	private $payment_form;

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct( ViraStore_PayPal_Payment_Form $payment_form = null ) {
		$this->payment_form = $payment_form ?: new ViraStore_PayPal_Payment_Form();

		// Register hooks for payment gateway with higher priority
		// NOTE: Gateway registration is now handled by ViraStore_PayPal class to avoid duplicates
		// This class focuses on other integration hooks
		// add_filter( 'vrstore_payment_gateways', array( $this, 'register_payment_gateway' ) );

		// Register hooks for payment form.
		add_action( 'virastore_payment_form_paypal', array( $this, 'render_payment_form' ) );

		// Register hooks for payment processing.
		add_filter( 'vrstore_process_payment_paypal', array( $this, 'process_payment' ), 10, 2 );

		// Register hooks for payment instructions.
		add_action( 'virastore_payment_instructions_paypal', array( $this, 'render_payment_instructions' ) );

		// Register hooks for admin menu.
		add_action( 'admin_menu', array( $this, 'add_admin_menu' ), 20 );

		// Register hooks for AJAX handlers.
		add_action( 'wp_ajax_virastore_paypal_process_payment', array( $this, 'ajax_process_payment' ) );
		add_action( 'wp_ajax_nopriv_virastore_paypal_process_payment', array( $this, 'ajax_process_payment' ) );

		// Register hooks for script enqueuing.
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ) );
	}

	/**
	 * Register PayPal payment gateway.
	 *
	 * @since 1.0.0
	 * @param array $gateways Payment gateways.
	 * @return array
	 */
	public function register_payment_gateway( $gateways ) {
		$gateways['paypal'] = array(
			'name'        => __( 'PayPal', 'virastore-paypal' ),
			'description' => __( 'Pay securely with your PayPal account or credit card.', 'virastore-paypal' ),
			'icon'        => VIRASTORE_PAYPAL_PLUGIN_URL . 'assets/images/paypal.svg',
			'callback'    => array( $this, 'process_payment' ),
			'form'        => array( $this, 'render_payment_form' ),
		);

		return $gateways;
	}

	/**
	 * Render payment form.
	 *
	 * @since 1.0.0
	 * @param string $payment_method Payment method.
	 */
	public function render_payment_form( $payment_data ) {
		$this->payment_form->render( $payment_data );
	}

	/**
	 * Process payment.
	 *
	 * @since 1.0.0
	 * @param array $payment_data Payment data.
	 * @return array
	 */
	public function process_payment( $payment_data, $order_id = null ) {
		$payment_data = (array) $payment_data;

		if ( null !== $order_id && ! isset( $payment_data['order_id'] ) ) {
			$payment_data['order_id'] = $order_id;
		}

		$payment_processor = new ViraStore_PayPal_Payment_Processor();

		return $payment_processor->process( $payment_data );
	}

	/**
	 * AJAX process payment.
	 *
	 * @since 1.0.0
	 */
	public function ajax_process_payment() {
		// Check nonce.
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'virastore_paypal_nonce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid nonce.', 'virastore-paypal' ) ) );
		}

		// Check payment data.
		if ( ! isset( $_POST['payment_data'] ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid payment data.', 'virastore-paypal' ) ) );
		}

		// Get payment data.
		$payment_data = wp_json_decode( wp_unslash( $_POST['payment_data'] ), true );

		if ( ! is_array( $payment_data ) ) {
			wp_send_json_error( array( 'message' => __( 'Unable to parse payment details.', 'virastore-paypal' ) ) );
		}

		// Process payment.
		$result = $this->process_payment( $payment_data );

		// Send response.
		if ( isset( $result['success'] ) && $result['success'] ) {
			wp_send_json_success( $result );
		} else {
			wp_send_json_error( $result );
		}
	}

	/**
	 * Render payment instructions.
	 *
	 * @since 1.0.0
	 * @param array $order_data Order data.
	 */
	public function render_payment_instructions( $order_data ) {
		// Include payment instructions template
		include VIRASTORE_PAYPAL_PLUGIN_DIR . 'views/payment-instructions.php';
	}

	/**
	 * Add admin menu
	 */
	public function add_admin_menu() {
		// Only add submenu if parent menu exists (main plugin admin menu)
		// Check if parent menu page exists before adding submenu
		global $submenu;
		
		if ( ! isset( $submenu['vrstore-dashboard'] ) ) {
			// Parent menu doesn't exist yet - main plugin might not have loaded admin menu
			// This shouldn't happen if initialization works, but add safety check
			return;
		}
		
		add_submenu_page(
			'vrstore-dashboard',
			__( 'PayPal Settings', 'virastore-paypal' ),
			__( 'PayPal Settings', 'virastore-paypal' ),
			'manage_options',
			'virastore-paypal-settings',
			array( $this, 'render_settings_page' )
		);
	}

	/**
	 * Render settings page
	 */
	public function render_settings_page() {
		// Include settings page template
		include VIRASTORE_PAYPAL_PLUGIN_DIR . 'views/settings-page.php';
	}

	/**
	 * Enqueue scripts
	 */
	public function enqueue_scripts() {
		// Enqueue styles
		wp_enqueue_style(
			'virastore-paypal',
			VIRASTORE_PAYPAL_PLUGIN_URL . 'assets/css/style.css',
			array(),
			VIRASTORE_PAYPAL_VERSION
		);

		// Enqueue scripts
		wp_enqueue_script(
			'virastore-paypal',
			VIRASTORE_PAYPAL_PLUGIN_URL . 'assets/js/script.js',
			array( 'jquery' ),
			VIRASTORE_PAYPAL_VERSION,
			true
		);

		// Get PayPal client ID
		$test_mode = get_option( 'virastore_paypal_test_mode', false );
		$client_id = $test_mode ? get_option( 'virastore_paypal_sandbox_client_id', '' ) : get_option( 'virastore_paypal_client_id', '' );

		// Localize script
		wp_localize_script(
			'virastore-paypal',
			'virastore_paypal',
			array(
				'ajax_url'        => admin_url( 'admin-ajax.php' ),
				'nonce'          => wp_create_nonce( 'virastore_paypal_nonce' ),
				'client_id'      => $client_id,
				'test_mode'      => $test_mode,
				'currency'       => 'USD', // You might want to make this configurable
				'loading_text'    => __( 'Loading PayPal...', 'virastore-paypal' ),
				'processing_text' => __( 'Processing payment...', 'virastore-paypal' ),
				'error_text'      => __( 'An error occurred. Please try again.', 'virastore-paypal' ),
			)
		);

		// Enqueue PayPal SDK only if client ID is available
		if ( ! empty( $client_id ) ) {
			wp_enqueue_script(
				'paypal-sdk',
				'https://www.paypal.com/sdk/js?client-id=' . $client_id . '&currency=USD',
				array(),
				null,
				true
			);
		}
	}

	/**
	 * Enqueue admin scripts
	 *
	 * @param string $hook Current admin page.
	 */
	public function admin_enqueue_scripts( $hook ) {
		// Only enqueue on PayPal settings page
		if ( $hook !== 'vrstore-dashboard_page_virastore-paypal-settings' ) {
			return;
		}

		// Enqueue admin styles
		wp_enqueue_style(
			'virastore-paypal-admin',
			VIRASTORE_PAYPAL_PLUGIN_URL . 'assets/css/admin.css',
			array(),
			VIRASTORE_PAYPAL_VERSION
		);

		// Enqueue admin scripts
		wp_enqueue_script(
			'virastore-paypal-admin',
			VIRASTORE_PAYPAL_PLUGIN_URL . 'assets/js/admin.js',
			array( 'jquery' ),
			VIRASTORE_PAYPAL_VERSION,
			true
		);
	}
}