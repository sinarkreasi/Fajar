<?php
/**
 * Webhook Handler Class
 *
 * @package ViraStore_PayPal
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ViraStore_PayPal_Webhook_Handler Class
 *
 * @since 1.0.0
 */
class ViraStore_PayPal_Webhook_Handler {

	/**
	 * API base URL.
	 *
	 * @since 1.0.0
	 * @var string
	 */
	private $api_url;

	/**
	 * Client ID.
	 *
	 * @since 1.0.0
	 * @var string
	 */
	private $client_id;

	/**
	 * Client secret.
	 *
	 * @since 1.0.0
	 * @var string
	 */
	private $client_secret;

	/**
	 * Test mode.
	 *
	 * @since 1.0.0
	 * @var bool
	 */
	private $test_mode;

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		// Get test mode.
		$this->test_mode = get_option( 'virastore_paypal_test_mode', false );

		// Set API URL based on test mode.
		$this->api_url = $this->test_mode
			? 'https://api-m.sandbox.paypal.com'
			: 'https://api-m.paypal.com';

		// Set client ID and secret based on test mode.
		if ( $this->test_mode ) {
			$this->client_id     = get_option( 'virastore_paypal_sandbox_client_id', '' );
			$this->client_secret = get_option( 'virastore_paypal_sandbox_client_secret', '' );
		} else {
			$this->client_id     = get_option( 'virastore_paypal_client_id', '' );
			$this->client_secret = get_option( 'virastore_paypal_client_secret', '' );
		}

		// Register webhook endpoint.
		add_action( 'init', array( $this, 'register_webhook_endpoint' ) );
	}

	/**
	 * Register webhook endpoint.
	 *
	 * @since 1.0.0
	 */
	public function register_webhook_endpoint() {
		add_rewrite_rule(
			'^virastore-paypal-webhook/?$',
			'index.php?virastore_paypal_webhook=1',
			'top'
		);

		add_rewrite_tag( '%virastore_paypal_webhook%', '([^&]+)' );

		// Handle webhook request.
		add_action( 'template_redirect', array( $this, 'handle_webhook_request' ) );
	}

	/**
	 * Handle webhook request.
	 *
	 * @since 1.0.0
	 */
	public function handle_webhook_request() {
		// Check if this is a webhook request.
		if ( ! get_query_var( 'virastore_paypal_webhook' ) ) {
			return;
		}

		// Get request data.
		$request_body = file_get_contents( 'php://input' );
		$headers     = getallheaders();

		// Log webhook request.
		$this->log_webhook_request( $request_body, $headers );

		// Verify webhook signature.
		if ( ! $this->verify_webhook_signature( $request_body, $headers ) ) {
			status_header( 401 );
			die( 'Invalid webhook signature' );
		}

		// Parse request body.
		$event = json_decode( $request_body, true );

		// Check if event is valid.
		if ( ! isset( $event['event_type'] ) ) {
			status_header( 400 );
			die( 'Invalid webhook event' );
		}

		// Process event.
		$this->process_event( $event );

		// Return success.
		status_header( 200 );
		die( 'Webhook processed successfully' );
	}

	/**
	 * Log webhook request.
	 *
	 * @since 1.0.0
	 * @param string $request_body Request body.
	 * @param array  $headers      Request headers.
	 */
	private function log_webhook_request( $request_body, $headers ) {
		// Check if logging is enabled.
		if ( ! defined( 'WP_DEBUG' ) || ! WP_DEBUG ) {
			return;
		}

		// Create log directory if it doesn't exist.
		$log_dir = VIRASTORE_PAYPAL_PLUGIN_DIR . '/logs';
		if ( ! file_exists( $log_dir ) ) {
			mkdir( $log_dir, 0755, true );
		}

		// Create log file.
		$log_file = $log_dir . '/webhook-' . date( 'Y-m-d' ) . '.log';

		// Log request.
		$log = '=== ' . date( 'Y-m-d H:i:s' ) . ' ===' . PHP_EOL;
		$log .= 'Headers: ' . print_r( $headers, true ) . PHP_EOL;
		$log .= 'Body: ' . $request_body . PHP_EOL;
		$log .= PHP_EOL;

		// Write to log file.
		file_put_contents( $log_file, $log, FILE_APPEND );
	}

	/**
	 * Verify webhook signature.
	 *
	 * @since 1.0.0
	 * @param string $request_body Request body.
	 * @param array  $headers      Request headers.
	 * @return bool
	 */
	private function verify_webhook_signature( $request_body, $headers ) {
		// Check if webhook ID is set.
		$webhook_id = $this->test_mode
			? get_option( 'virastore_paypal_sandbox_webhook_id', '' )
			: get_option( 'virastore_paypal_webhook_id', '' );

		if ( empty( $webhook_id ) ) {
			// If webhook ID is not set, skip verification.
			return true;
		}

		// Check if required headers are present.
		if ( ! isset( $headers['Paypal-Transmission-Id'] ) ||
			! isset( $headers['Paypal-Transmission-Time'] ) ||
			! isset( $headers['Paypal-Transmission-Sig'] ) ||
			! isset( $headers['Paypal-Cert-Url'] ) ||
			! isset( $headers['Paypal-Auth-Algo'] ) ) {
			return false;
		}

		// Get access token.
		$token = $this->get_access_token();
		if ( is_wp_error( $token ) ) {
			return false;
		}

		// Prepare request.
		$args = array(
			'method'  => 'POST',
			'headers' => array(
				'Authorization'  => 'Bearer ' . $token,
				'Content-Type'  => 'application/json',
				'Accept'        => 'application/json',
			),
			'body'    => wp_json_encode(
				array(
					'transmission_id'   => $headers['Paypal-Transmission-Id'],
					'transmission_time' => $headers['Paypal-Transmission-Time'],
					'cert_url'          => $headers['Paypal-Cert-Url'],
					'auth_algo'         => $headers['Paypal-Auth-Algo'],
					'transmission_sig'  => $headers['Paypal-Transmission-Sig'],
					'webhook_id'        => $webhook_id,
					'webhook_event'     => json_decode( $request_body ),
				)
			),
		);

		// Make request.
		$response = wp_remote_post( $this->api_url . '/v1/notifications/verify-webhook-signature', $args );

		// Check for errors.
		if ( is_wp_error( $response ) ) {
			return false;
		}

		// Parse response.
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		// Check if verification was successful.
		return isset( $body['verification_status'] ) && 'SUCCESS' === $body['verification_status'];
	}

	/**
	 * Process event.
	 *
	 * @since 1.0.0
	 * @param array $event Event data.
	 */
	private function process_event( $event ) {
		// Get event type.
		$event_type = $event['event_type'];

		// Process event based on type.
		switch ( $event_type ) {
			case 'PAYMENT.CAPTURE.COMPLETED':
				$this->process_payment_capture_completed( $event );
				break;

			case 'PAYMENT.CAPTURE.DENIED':
				$this->process_payment_capture_denied( $event );
				break;

			case 'PAYMENT.CAPTURE.REFUNDED':
				$this->process_payment_capture_refunded( $event );
				break;

			default:
				// Do nothing for other event types.
				break;
		}

		// Allow other plugins to process the event.
		do_action( 'virastore_paypal_webhook_' . $event_type, $event );
	}

	/**
	 * Process payment capture completed event.
	 *
	 * @since 1.0.0
	 * @param array $event Event data.
	 */
	private function process_payment_capture_completed( $event ) {
		// Get resource data.
		$resource = $event['resource'];

		// Get custom ID (order ID).
		$custom_id = isset( $resource['custom_id'] ) ? $resource['custom_id'] : '';

		// Check if order ID is valid.
		if ( empty( $custom_id ) ) {
			return;
		}

		// Check if VRSTORE_Order class exists.
		if ( ! class_exists( 'VRSTORE_Order' ) ) {
			return;
		}

		// Get order instance.
		$order = new VRSTORE_Order( $custom_id );

		// Check if order exists.
		if ( ! $order->exists() ) {
			return;
		}

		// Check if order is already completed.
		if ( 'completed' === $order->get_status() ) {
			return;
		}

		// Get transaction ID.
		$transaction_id = isset( $resource['id'] ) ? $resource['id'] : '';

		// Update order status.
		$order->update_status( 'completed' );

		// Add transaction ID to order meta.
		$order->update_meta( 'transaction_id', $transaction_id );

		// Add payment method to order meta.
		$order->update_meta( 'payment_method', 'paypal' );
	}

	/**
	 * Process payment capture denied event.
	 *
	 * @since 1.0.0
	 * @param array $event Event data.
	 */
	private function process_payment_capture_denied( $event ) {
		// Get resource data.
		$resource = $event['resource'];

		// Get custom ID (order ID).
		$custom_id = isset( $resource['custom_id'] ) ? $resource['custom_id'] : '';

		// Check if order ID is valid.
		if ( empty( $custom_id ) ) {
			return;
		}

		// Check if VRSTORE_Order class exists.
		if ( ! class_exists( 'VRSTORE_Order' ) ) {
			return;
		}

		// Get order instance.
		$order = new VRSTORE_Order( $custom_id );

		// Check if order exists.
		if ( ! $order->exists() ) {
			return;
		}

		// Update order status.
		$order->update_status( 'failed' );

		// Add note to order.
		$order->add_note( __( 'Payment denied by PayPal.', 'virastore-paypal' ) );
	}

	/**
	 * Process payment capture refunded event.
	 *
	 * @since 1.0.0
	 * @param array $event Event data.
	 */
	private function process_payment_capture_refunded( $event ) {
		// Get resource data.
		$resource = $event['resource'];

		// Get custom ID (order ID).
		$custom_id = isset( $resource['custom_id'] ) ? $resource['custom_id'] : '';

		// Check if order ID is valid.
		if ( empty( $custom_id ) ) {
			return;
		}

		// Check if VRSTORE_Order class exists.
		if ( ! class_exists( 'VRSTORE_Order' ) ) {
			return;
		}

		// Get order instance.
		$order = new VRSTORE_Order( $custom_id );

		// Check if order exists.
		if ( ! $order->exists() ) {
			return;
		}

		// Update order status.
		$order->update_status( 'refunded' );

		// Add note to order.
		$order->add_note( __( 'Payment refunded by PayPal.', 'virastore-paypal' ) );
	}

	/**
	 * Get access token.
	 *
	 * @since 1.0.0
	 * @return string|WP_Error
	 */
	private function get_access_token() {
		// Check if we have a cached token.
		$token = get_transient( 'virastore_paypal_access_token' );
		if ( $token ) {
			return $token;
		}

		// Prepare request.
		$args = array(
			'method'  => 'POST',
			'headers' => array(
				'Authorization' => 'Basic ' . base64_encode( $this->client_id . ':' . $this->client_secret ),
				'Content-Type' => 'application/x-www-form-urlencoded',
			),
			'body'    => 'grant_type=client_credentials',
		);

		// Make request.
		$response = wp_remote_post( $this->api_url . '/v1/oauth2/token', $args );

		// Check for errors.
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		// Parse response.
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		// Check if we got an access token.
		if ( ! isset( $body['access_token'] ) ) {
			return new WP_Error( 'paypal_error', __( 'Failed to get access token.', 'virastore-paypal' ) );
		}

		// Cache token.
		$expires_in = isset( $body['expires_in'] ) ? intval( $body['expires_in'] ) : 3600;
		set_transient( 'virastore_paypal_access_token', $body['access_token'], $expires_in - 60 );

		return $body['access_token'];
	}
}