/**
 * Frontend script for PayPal payment form
 *
 * @package ViraStore_PayPal
 */

(function($) {
    'use strict';

    // PayPal payment form handler
    var PayPalPaymentForm = {
        /**
         * Initialize
         */
        init: function() {
            // Listen for payment form submission
            $(document).on('submit', '.virastore-paypal-payment-form form', this.handleFormSubmit);
        },

        /**
         * Handle form submission
         * 
         * @param {Event} e Event object
         */
        handleFormSubmit: function(e) {
            e.preventDefault();
            
            // Show processing message
            $('#virastore-paypal-processing').show();
            $('#virastore-paypal-error').hide();
            
            // Get form data
            var formData = new FormData($(this)[0]);
            formData.append('action', 'virastore_paypal_process_payment');
            formData.append('nonce', virastore_paypal.nonce);
            
            // Send AJAX request
            $.ajax({
                url: virastore_paypal.ajax_url,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        // Redirect to thank you page
                        window.location.href = response.data.redirect_url || virastore_paypal.return_url;
                    } else {
                        // Show error message
                        $('#virastore-paypal-processing').hide();
                        $('#virastore-paypal-error').text(response.data.message || 'Payment failed.').show();
                    }
                },
                error: function(xhr, status, error) {
                    // Show error message
                    $('#virastore-paypal-processing').hide();
                    $('#virastore-paypal-error').text('Error: ' + error).show();
                }
            });
        }
    };

    // Initialize on document ready
    $(document).ready(function() {
        PayPalPaymentForm.init();
    });

})(jQuery);