/**
 * ViraStore PayPal Payment Gateway Admin Scripts
 *
 * @package ViraStore_PayPal
 */

(function($) {
    'use strict';

    // Toggle API key visibility.
    $('.virastore-paypal-api-key-toggle').on('click', function() {
        var $input = $(this).prev('input');
        var type = $input.attr('type');
        
        if (type === 'password') {
            $input.attr('type', 'text');
            $(this).text(virastore_paypal_admin.hide_text);
        } else {
            $input.attr('type', 'password');
            $(this).text(virastore_paypal_admin.show_text);
        }
    });

    // Toggle test mode fields.
    $('#virastore_paypal_test_mode').on('change', function() {
        var isChecked = $(this).is(':checked');
        
        if (isChecked) {
            $('.virastore-paypal-live-field').hide();
            $('.virastore-paypal-sandbox-field').show();
        } else {
            $('.virastore-paypal-live-field').show();
            $('.virastore-paypal-sandbox-field').hide();
        }
    }).trigger('change');

})(jQuery);