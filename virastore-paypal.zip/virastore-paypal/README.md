# ViraStore PayPal Payment Gateway

## Description

ViraStore PayPal Payment Gateway is a WordPress plugin that integrates PayPal payment processing with the ViraStore e-commerce platform. This plugin allows customers to pay for their orders using PayPal, including credit card payments through the PayPal interface.

## Features

- Seamless integration with ViraStore e-commerce platform
- Support for both live and sandbox (test) environments
- PayPal Standard Checkout integration
- Webhook support for automatic order status updates
- Detailed transaction logging
- Customizable payment title and description
- Responsive payment buttons
- Comprehensive settings page in WordPress admin

## Requirements

- WordPress 5.6 or higher
- PHP 8.2 or higher
- ViraStore plugin installed and activated
- PayPal Business or PayPal Developer account

## Installation

1. Upload the `virastore-paypal` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Navigate to ViraStore > PayPal Settings to configure the plugin

## Configuration

### PayPal API Credentials

1. Log in to your PayPal Developer account at [developer.paypal.com](https://developer.paypal.com/)
2. Create a new REST API app to get your Client ID and Secret
3. For sandbox testing, use your sandbox credentials
4. For live payments, use your live credentials

### Plugin Settings

1. Enable/disable the payment gateway
2. Toggle test mode (sandbox) on/off
3. Enter your API credentials (Client ID and Secret)
4. Customize the payment title and description shown to customers

## Webhook Setup

To ensure automatic order updates when payment status changes:

1. Log in to your PayPal Developer account
2. Navigate to your app settings
3. Add a webhook with the URL: `https://your-site.com/virastore-paypal-webhook/`
4. Subscribe to these events:
   - PAYMENT.CAPTURE.COMPLETED
   - PAYMENT.CAPTURE.DENIED
   - PAYMENT.CAPTURE.REFUNDED

## Frequently Asked Questions

### Does this plugin work with PayPal Standard?

This plugin uses PayPal's newer REST API for improved security and features, not the legacy PayPal Standard.

### Can customers pay without a PayPal account?

Yes, customers can pay with credit/debit cards without creating a PayPal account.

### Is this plugin compatible with other payment gateways?

Yes, this plugin can be used alongside other payment gateways integrated with ViraStore.

## Support

For support, please contact the plugin developer or submit issues through the plugin's support channels.

## License

GPL v2 or later