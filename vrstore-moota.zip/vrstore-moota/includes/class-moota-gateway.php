<?php
/**
 * Moota Payment Gateway Class
 *
 * @package ViraStore_Moota
 * @since 1.0.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * ViraStore_Moota_Gateway Class
 *
 * Handles Moota payment gateway integration with bank account monitoring.
 *
 * @since 1.0.0
 */
class ViraStore_Moota_Gateway {

    /**
     * Instance of this class
     *
     * @var ViraStore_Moota_Gateway|null
     */
    private static ?ViraStore_Moota_Gateway $instance = null;

    /**
     * Moota API base URL
     *
     * @var string
     */
    private string $api_base_url = 'https://app.moota.co/api/v2/';

    /**
     * Plugin settings
     *
     * @var array
     */
    private array $settings = array();

    /**
     * Get singleton instance
     *
     * @return ViraStore_Moota_Gateway
     */
    public static function get_instance(): ViraStore_Moota_Gateway {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        $this->load_settings();
        $this->init_hooks();
    }

    /**
     * Load plugin settings
     */
    private function load_settings(): void {
        $this->settings = get_option('vrstore_moota_settings', array(
            'enabled'     => 'no',
            'api_key'     => '',
            'webhook_url' => '',
            'test_mode'   => 'yes',
            'bank_accounts' => array(),
        ));
    }

    /**
     * Initialize hooks
     */
    private function init_hooks(): void {
        // AJAX handlers for payment processing
        add_action('wp_ajax_vrstore_moota_process_payment', array($this, 'ajax_process_payment'));
        add_action('wp_ajax_nopriv_vrstore_moota_process_payment', array($this, 'ajax_process_payment'));
        
        // AJAX handlers for checking payment status
        add_action('wp_ajax_vrstore_moota_check_payment', array($this, 'ajax_check_payment'));
        add_action('wp_ajax_nopriv_vrstore_moota_check_payment', array($this, 'ajax_check_payment'));

        // Add payment form fields
        add_action('vrstore_payment_form_moota', array($this, 'render_payment_form'));
        
        // Process payment when order is created
        add_action('vrstore_order_created', array($this, 'process_order_payment'), 10, 2);
    }

    /**
     * Check if gateway is enabled
     *
     * @return bool
     */
    public function is_enabled(): bool {
        return isset($this->settings['enabled']) && $this->settings['enabled'] === 'yes';
    }

    /**
     * Get API key
     *
     * @return string
     */
    private function get_api_key(): string {
        return $this->settings['api_key'] ?? '';
    }

    /**
     * Get configured bank accounts
     *
     * @return array
     */
    public function get_bank_accounts(): array {
        return $this->settings['bank_accounts'] ?? array();
    }

    /**
     * Render payment form for Moota
     *
     * @param array $args Form arguments
     */
    public function render_payment_form(array $args = array()): void {
        if (!$this->is_enabled()) {
            return;
        }

        $bank_accounts = $this->get_bank_accounts();
        
        if (empty($bank_accounts)) {
            echo '<div class="vrstore-error">';
            echo esc_html__('No bank accounts configured. Please contact administrator.', 'vrstore-moota');
            echo '</div>';
            return;
        }

        // Get cart total if available
        $cart_total = 0;
        if (class_exists('VRSTORE_Cart')) {
            $cart = VRSTORE_Cart::get_instance();
            $cart_total = $cart->get_cart_total_with_discount();
        }

        ?>
        <div id="vrstore-payment-method-moota" class="vrstore-payment-method-fields" style="display: none;">
            <div class="vrstore-moota-payment-form">
                <h4><?php esc_html_e('Bank Transfer Instructions', 'vrstore-moota'); ?></h4>
                
                <div id="vrstore-moota-bank-accounts" class="vrstore-moota-bank-accounts">
                    <p><?php esc_html_e('Please transfer to one of the following bank accounts:', 'vrstore-moota'); ?></p>
                    
                    <?php 
                    $bank_index = 0;
                    foreach ($bank_accounts as $account): 
                        $bank_id = $account['moota_bank_id'] ?? ($account['account_number'] ?? '');
                        $is_first = $bank_index === 0;
                    ?>
                        <div class="vrstore-moota-bank-account">
                            <label class="vrstore-moota-bank-option">
                                <input type="radio" 
                                       name="vrstore_moota_bank" 
                                       id="vrstore_moota_bank_<?php echo esc_attr($bank_index); ?>" 
                                       value="<?php echo esc_attr($bank_id); ?>" 
                                       <?php checked($is_first, true); ?>
                                       required>
                                <div class="bank-info">
                                    <strong><?php echo esc_html($account['bank_name'] ?? ''); ?></strong>
                                    <br>
                                    <span class="account-number"><?php echo esc_html($account['account_number'] ?? ''); ?></span>
                                    <br>
                                    <span class="account-name"><?php echo esc_html($account['account_name'] ?? ''); ?></span>
                                </div>
                            </label>
                            <button type="button" class="vrstore-moota-copy-btn" data-account="<?php echo esc_attr($account['account_number'] ?? ''); ?>">
                                <?php esc_html_e('Copy Account Number', 'vrstore-moota'); ?>
                            </button>
                        </div>
                    <?php 
                        $bank_index++;
                    endforeach; 
                    ?>
                </div>

                <div class="vrstore-moota-instructions">
                    <h5><?php esc_html_e('Payment Instructions:', 'vrstore-moota'); ?></h5>
                    <ol>
                        <li><?php esc_html_e('Transfer the exact amount to one of the bank accounts above', 'vrstore-moota'); ?></li>
                        <li><?php esc_html_e('Use your order ID as the transfer reference/note', 'vrstore-moota'); ?></li>
                        <li><?php esc_html_e('Payment will be automatically verified within 5-10 minutes', 'vrstore-moota'); ?></li>
                        <li><?php esc_html_e('You will receive email confirmation once payment is verified', 'vrstore-moota'); ?></li>
                    </ol>
                </div>

                <div class="vrstore-moota-amount-display" style="background: #f0f0f0; padding: 15px; border-radius: 5px; margin-top: 15px;">
                    <p style="margin: 0;"><strong><?php esc_html_e('Amount to Transfer:', 'vrstore-moota'); ?></strong> 
                    <span id="vrstore-moota-amount" class="vrstore-moota-amount-value"><?php 
                        if ($cart_total > 0 && function_exists('vrstore_format_price')) {
                            echo vrstore_format_price($cart_total);
                        }
                    ?></span></p>
                </div>

                <input type="hidden" name="vrstore_moota_selected_bank" id="vrstore_moota_selected_bank" value="<?php echo esc_attr(reset($bank_accounts)['moota_bank_id'] ?? (reset($bank_accounts)['account_number'] ?? '')); ?>">
            </div>
        </div>
        <?php
    }

    /**
     * Process payment via AJAX
     */
    public function ajax_process_payment(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_moota_nonce')) {
            wp_send_json_error(array(
                'message' => __('Security check failed.', 'vrstore-moota')
            ));
        }

        $order_id = absint($_POST['order_id'] ?? 0);
        $amount = floatval($_POST['amount'] ?? 0);

        if (!$order_id || !$amount) {
            wp_send_json_error(array(
                'message' => __('Invalid order data.', 'vrstore-moota')
            ));
        }

        // Create payment record
        $payment_data = array(
            'order_id' => $order_id,
            'amount' => $amount,
            'status' => 'pending',
            'gateway' => 'moota',
            'created_at' => current_time('mysql'),
        );

        // Store payment data
        update_post_meta($order_id, 'vrstore_moota_payment_data', $payment_data);
        update_post_meta($order_id, 'vrstore_payment_status', 'pending');
        update_post_meta($order_id, 'vrstore_payment_gateway', 'moota');

        wp_send_json_success(array(
            'message' => __('Payment initiated. Please complete the bank transfer.', 'vrstore-moota'),
            'order_id' => $order_id,
        ));
    }

    /**
     * Check payment status via AJAX
     */
    public function ajax_check_payment(): void {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'vrstore_moota_nonce')) {
            wp_send_json_error(array(
                'message' => __('Security check failed.', 'vrstore-moota')
            ));
        }

        $order_id = absint($_POST['order_id'] ?? 0);

        if (!$order_id) {
            wp_send_json_error(array(
                'message' => __('Invalid order ID.', 'vrstore-moota')
            ));
        }

        $payment_status = get_post_meta($order_id, 'vrstore_payment_status', true);
        
        wp_send_json_success(array(
            'status' => $payment_status,
            'message' => $this->get_status_message($payment_status),
        ));
    }

    /**
     * Get status message for payment status
     *
     * @param string $status Payment status
     * @return string Status message
     */
    private function get_status_message(string $status): string {
        switch ($status) {
            case 'completed':
                return __('Payment verified successfully!', 'vrstore-moota');
            case 'pending':
                return __('Waiting for payment verification...', 'vrstore-moota');
            case 'failed':
                return __('Payment verification failed.', 'vrstore-moota');
            default:
                return __('Unknown payment status.', 'vrstore-moota');
        }
    }

    /**
     * Process order payment when order is created
     *
     * @param int   $order_id Order ID
     * @param array $order_data Order data
     */
    public function process_order_payment(int $order_id, array $order_data): void {
        // Only process if payment method is Moota
        if (($order_data['payment_method'] ?? '') !== 'moota') {
            return;
        }

        // Set initial payment status
        update_post_meta($order_id, 'vrstore_payment_status', 'pending');
        update_post_meta($order_id, 'vrstore_payment_gateway', 'moota');
        
        // Store Moota-specific data
        $moota_data = array(
            'order_id' => $order_id,
            'amount' => $order_data['total'] ?? 0,
            'status' => 'pending',
            'created_at' => current_time('mysql'),
            'expected_amount' => $order_data['total'] ?? 0,
        );
        
        update_post_meta($order_id, 'vrstore_moota_payment_data', $moota_data);
    }

    /**
     * Make API request to Moota
     *
     * @param string $endpoint API endpoint
     * @param array  $data Request data
     * @param string $method HTTP method
     * @return array|WP_Error API response
     */
    public function make_api_request(string $endpoint, array $data = array(), string $method = 'GET') {
        $api_key = $this->get_api_key();
        
        if (empty($api_key)) {
            return new WP_Error('no_api_key', __('Moota API key not configured.', 'vrstore-moota'));
        }

        $url = $this->api_base_url . ltrim($endpoint, '/');
        
        $args = array(
            'method' => $method,
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json',
                'Accept' => 'application/json',
            ),
            'timeout' => 30,
        );

        if (!empty($data) && in_array($method, array('POST', 'PUT', 'PATCH'))) {
            $args['body'] = wp_json_encode($data);
        }

        $response = wp_remote_request($url, $args);

        if (is_wp_error($response)) {
            return $response;
        }

        $body = wp_remote_retrieve_body($response);
        $status_code = wp_remote_retrieve_response_code($response);

        if ($status_code >= 400) {
            return new WP_Error(
                'api_error',
                sprintf(__('Moota API error: %s', 'vrstore-moota'), $status_code)
            );
        }

        $decoded = json_decode($body, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            return new WP_Error('json_error', __('Invalid JSON response from Moota API.', 'vrstore-moota'));
        }

        return $decoded;
    }

    /**
     * Get bank account transactions
     *
     * @param string $bank_id Bank account ID
     * @param array  $params Query parameters
     * @return array|WP_Error Transactions data
     */
    public function get_transactions(string $bank_id, array $params = array()) {
        $endpoint = "bank/{$bank_id}/mutation";
        
        if (!empty($params)) {
            $endpoint .= '?' . http_build_query($params);
        }

        return $this->make_api_request($endpoint);
    }

    /**
     * Verify payment by checking transactions
     *
     * @param int    $order_id Order ID
     * @param float  $amount Expected amount
     * @param string $reference Reference/note to match
     * @return bool True if payment found and verified
     */
    public function verify_payment(int $order_id, float $amount, string $reference = ''): bool {
        $bank_accounts = $this->get_bank_accounts();
        
        if (empty($bank_accounts)) {
            return false;
        }

        // Use order ID as reference if not provided
        if (empty($reference)) {
            $reference = (string) $order_id;
        }

        foreach ($bank_accounts as $account) {
            if (empty($account['moota_bank_id'])) {
                continue;
            }

            // Get recent transactions
            $params = array(
                'start_date' => date('Y-m-d', strtotime('-1 day')),
                'end_date' => date('Y-m-d'),
                'type' => 'CR', // Credit transactions only
            );

            $transactions = $this->get_transactions($account['moota_bank_id'], $params);
            
            if (is_wp_error($transactions) || empty($transactions['data'])) {
                continue;
            }

            // Check each transaction
            foreach ($transactions['data'] as $transaction) {
                $tx_amount = floatval($transaction['amount'] ?? 0);
                $tx_note = $transaction['description'] ?? '';
                
                // Match amount and reference
                if (abs($tx_amount - $amount) < 0.01 && 
                    (strpos($tx_note, $reference) !== false || strpos($tx_note, (string) $order_id) !== false)) {
                    
                    // Payment found and verified
                    $this->mark_payment_completed($order_id, $transaction);
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Mark payment as completed
     *
     * @param int   $order_id Order ID
     * @param array $transaction Transaction data
     */
    private function mark_payment_completed(int $order_id, array $transaction): void {
        // Use Vira Store's order methods if available
        if (class_exists('VRSTORE_Order')) {
            VRSTORE_Order::update_payment_status($order_id, 'completed');
            VRSTORE_Order::update_order_status($order_id, 'completed');
            
            // Store transaction ID if available
            if (!empty($transaction['id'])) {
                update_post_meta($order_id, '_vrstore_transaction_id', sanitize_text_field($transaction['id']));
            }
        } else {
            // Fallback to direct post meta updates
            update_post_meta($order_id, 'vrstore_payment_status', 'completed');
            update_post_meta($order_id, '_vrstore_payment_status', 'completed');
            update_post_meta($order_id, '_vrstore_order_status', 'completed');
        }
        
        // Store transaction data
        update_post_meta($order_id, 'vrstore_moota_transaction', $transaction);
        update_post_meta($order_id, '_vrstore_moota_transaction', $transaction);
        
        // Update Moota payment data
        $moota_data = get_post_meta($order_id, 'vrstore_moota_payment_data', true);
        if (empty($moota_data)) {
            $moota_data = get_post_meta($order_id, '_vrstore_moota_payment_data', true);
        }
        
        if (is_array($moota_data)) {
            $moota_data['status'] = 'completed';
            $moota_data['completed_at'] = current_time('mysql');
            $moota_data['transaction_id'] = $transaction['id'] ?? '';
            update_post_meta($order_id, 'vrstore_moota_payment_data', $moota_data);
            update_post_meta($order_id, '_vrstore_moota_payment_data', $moota_data);
        }

        // Trigger order completion actions
        do_action('vrstore_moota_payment_completed', $order_id, $transaction);
        do_action('vrstore_payment_completed', $order_id, 'moota');
    }

    /**
     * Handle webhook notification from Moota
     *
     * @param array $webhook_data Webhook data
     * @return bool True if processed successfully
     */
    public function handle_webhook(array $webhook_data): bool {
        // Validate webhook data
        if (empty($webhook_data['bank_id']) || empty($webhook_data['mutation'])) {
            return false;
        }

        $mutation = $webhook_data['mutation'];
        $amount = floatval($mutation['amount'] ?? 0);
        $description = $mutation['description'] ?? '';
        $type = $mutation['type'] ?? '';

        // Only process credit transactions (incoming payments)
        if ($type !== 'CR' || $amount <= 0) {
            return false;
        }

        // Try to find matching order
        $order_id = $this->find_order_by_reference($description, $amount);
        
        if (!$order_id) {
            return false;
        }

        // Check if payment is still pending (check both meta keys)
        $current_status = get_post_meta($order_id, 'vrstore_payment_status', true);
        if (empty($current_status)) {
            $current_status = get_post_meta($order_id, '_vrstore_payment_status', true);
        }
        
        if ($current_status !== 'pending') {
            return false;
        }

        // Mark payment as completed
        $this->mark_payment_completed($order_id, $mutation);
        
        return true;
    }

    /**
     * Find order by reference in transaction description
     *
     * @param string $description Transaction description
     * @param float  $amount Transaction amount
     * @return int|false Order ID if found, false otherwise
     */
    private function find_order_by_reference(string $description, float $amount) {
        // Extract potential order IDs from description
        preg_match_all('/\b\d+\b/', $description, $matches);
        
        if (empty($matches[0])) {
            return false;
        }

        foreach ($matches[0] as $potential_id) {
            $order_id = absint($potential_id);
            
            if ($order_id <= 0) {
                continue;
            }

            // Check if this is a valid Vira Store order
            $post = get_post($order_id);
            if (!$post || $post->post_type !== 'vrstore_order') {
                continue;
            }

            // Check if payment method is Moota (check both meta keys)
            $payment_method = get_post_meta($order_id, 'vrstore_payment_method', true);
            if (empty($payment_method)) {
                $payment_method = get_post_meta($order_id, '_vrstore_payment_method', true);
            }
            
            if ($payment_method !== 'moota') {
                continue;
            }

            // Check if payment is still pending (check both meta keys)
            $payment_status = get_post_meta($order_id, 'vrstore_payment_status', true);
            if (empty($payment_status)) {
                $payment_status = get_post_meta($order_id, '_vrstore_payment_status', true);
            }
            
            if ($payment_status !== 'pending') {
                continue;
            }

            // Check if amount matches (with small tolerance) - check both meta keys
            $order_total = floatval(get_post_meta($order_id, 'vrstore_order_total', true));
            if (empty($order_total) || $order_total <= 0) {
                $order_total = floatval(get_post_meta($order_id, '_vrstore_order_total', true));
            }
            
            if (abs($order_total - $amount) < 0.01) {
                return $order_id;
            }
        }

        return false;
    }
}