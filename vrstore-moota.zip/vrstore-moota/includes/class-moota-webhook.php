<?php
/**
 * Moota Webhook Handler Class
 *
 * @package ViraStore_Moota
 * @since 1.0.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * ViraStore_Moota_Webhook Class
 *
 * Handles webhook notifications from Moota API for payment verification.
 *
 * @since 1.0.0
 */
class ViraStore_Moota_Webhook {

    /**
     * Instance of this class
     *
     * @var ViraStore_Moota_Webhook|null
     */
    private static ?ViraStore_Moota_Webhook $instance = null;

    /**
     * Webhook endpoint namespace
     *
     * @var string
     */
    private string $namespace = 'vrstore-moota/v1';

    /**
     * Get singleton instance
     *
     * @return ViraStore_Moota_Webhook
     */
    public static function get_instance(): ViraStore_Moota_Webhook {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        $this->init_hooks();
    }

    /**
     * Initialize hooks
     */
    private function init_hooks(): void {
        // Register REST API endpoints
        add_action('rest_api_init', array($this, 'register_webhook_endpoints'));
        
        // Schedule periodic payment verification
        add_action('init', array($this, 'schedule_payment_verification'));
        add_action('vrstore_moota_verify_payments', array($this, 'verify_pending_payments'));
    }

    /**
     * Register webhook REST API endpoints
     */
    public function register_webhook_endpoints(): void {
        // Main webhook endpoint for Moota notifications
        register_rest_route(
            $this->namespace,
            '/webhook',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array($this, 'handle_webhook'),
                'permission_callback' => '__return_true', // We'll verify signature manually
                'args'                => array(),
            )
        );

        // Manual verification endpoint (for testing)
        register_rest_route(
            $this->namespace,
            '/verify/(?P<order_id>\d+)',
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array($this, 'manual_verify_payment'),
                'permission_callback' => array($this, 'verify_manual_permission'),
                'args'                => array(
                    'order_id' => array(
                        'required'          => true,
                        'validate_callback' => function($param) {
                            return is_numeric($param);
                        },
                        'sanitize_callback' => 'absint',
                    ),
                ),
            )
        );
    }

    /**
     * Handle webhook notification from Moota
     *
     * @param WP_REST_Request $request Full data about the request
     * @return WP_Error|WP_REST_Response
     */
    public function handle_webhook(WP_REST_Request $request) {
        // Log webhook received (for debugging)
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Moota webhook received: ' . $request->get_body());
        }

        // Get the request body
        $payload = $request->get_body();
        
        if (empty($payload)) {
            return new WP_Error(
                'moota_webhook_error',
                __('Empty payload received.', 'vrstore-moota'),
                array('status' => 400)
            );
        }

        // Verify webhook signature if configured
        $signature_valid = $this->verify_webhook_signature($request, $payload);
        if (is_wp_error($signature_valid)) {
            return $signature_valid;
        }

        try {
            $webhook_data = json_decode($payload, true);

            if (json_last_error() !== JSON_ERROR_NONE) {
                return new WP_Error(
                    'moota_webhook_error',
                    __('Invalid JSON payload.', 'vrstore-moota'),
                    array('status' => 400)
                );
            }

            // Process the webhook
            $result = $this->process_webhook_data($webhook_data);

            if (is_wp_error($result)) {
                return $result;
            }

            return new WP_REST_Response(
                array(
                    'success' => true,
                    'message' => __('Webhook processed successfully.', 'vrstore-moota'),
                ),
                200
            );

        } catch (Exception $e) {
            return new WP_Error(
                'moota_webhook_error',
                sprintf(__('Webhook processing failed: %s', 'vrstore-moota'), $e->getMessage()),
                array('status' => 500)
            );
        }
    }

    /**
     * Verify webhook signature
     *
     * @param WP_REST_Request $request Request object
     * @param string          $payload Request payload
     * @return bool|WP_Error True if valid, WP_Error if invalid
     */
    private function verify_webhook_signature(WP_REST_Request $request, string $payload) {
        // Get signature from headers
        $received_signature = $request->get_header('X-Moota-Signature');
        
        if (empty($received_signature)) {
            // Try alternative header names
            $received_signature = $request->get_header('X-Signature') ?: $request->get_header('Signature');
        }

        // If no signature header, we'll allow it for now (Moota might not send signatures)
        if (empty($received_signature)) {
            return true;
        }

        // Get webhook secret from settings
        $settings = get_option('vrstore_moota_settings', array());
        $webhook_secret = $settings['webhook_secret'] ?? '';

        if (empty($webhook_secret)) {
            // If no secret configured, skip verification
            return true;
        }

        // Calculate expected signature
        $calculated_signature = hash_hmac('sha256', $payload, $webhook_secret);
        
        if (!hash_equals($calculated_signature, $received_signature)) {
            return new WP_Error(
                'moota_webhook_error',
                __('Invalid webhook signature.', 'vrstore-moota'),
                array('status' => 401)
            );
        }

        return true;
    }

    /**
     * Process webhook data
     *
     * @param array $webhook_data Webhook data from Moota
     * @return bool|WP_Error True if processed successfully, WP_Error on failure
     */
    private function process_webhook_data(array $webhook_data) {
        // Check if this is a mutation (transaction) webhook
        if (!isset($webhook_data['bank_id']) || !isset($webhook_data['mutation'])) {
            return new WP_Error(
                'moota_webhook_error',
                __('Invalid webhook data structure.', 'vrstore-moota'),
                array('status' => 400)
            );
        }

        $bank_id = sanitize_text_field($webhook_data['bank_id']);
        $mutation = $webhook_data['mutation'];

        // Validate mutation data
        if (!is_array($mutation) || empty($mutation['amount']) || empty($mutation['type'])) {
            return new WP_Error(
                'moota_webhook_error',
                __('Invalid mutation data.', 'vrstore-moota'),
                array('status' => 400)
            );
        }

        // Only process credit transactions (incoming payments)
        if ($mutation['type'] !== 'CR') {
            return true; // Not an error, just not relevant
        }

        // Get gateway instance and process
        $gateway = ViraStore_Moota_Gateway::get_instance();
        $processed = $gateway->handle_webhook($webhook_data);

        if (!$processed) {
            // Log for debugging but don't return error (might be unrelated transaction)
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Moota webhook: No matching order found for transaction');
            }
        }

        return true;
    }

    /**
     * Manual payment verification endpoint
     *
     * @param WP_REST_Request $request Full data about the request
     * @return WP_Error|WP_REST_Response
     */
    public function manual_verify_payment(WP_REST_Request $request) {
        $order_id = $request->get_param('order_id');

        // Verify order exists and is a Vira Store order
        $post = get_post($order_id);
        if (!$post || $post->post_type !== 'vrstore_order') {
            return new WP_Error(
                'invalid_order',
                __('Invalid order ID.', 'vrstore-moota'),
                array('status' => 404)
            );
        }

        // Check if payment method is Moota
        $payment_method = get_post_meta($order_id, 'vrstore_payment_method', true);
        if ($payment_method !== 'moota') {
            return new WP_Error(
                'invalid_payment_method',
                __('Order does not use Moota payment method.', 'vrstore-moota'),
                array('status' => 400)
            );
        }

        // Check current payment status
        $current_status = get_post_meta($order_id, 'vrstore_payment_status', true);
        if ($current_status === 'completed') {
            return new WP_REST_Response(
                array(
                    'success' => true,
                    'message' => __('Payment already verified.', 'vrstore-moota'),
                    'status'  => 'completed',
                ),
                200
            );
        }

        // Get order total
        $order_total = floatval(get_post_meta($order_id, 'vrstore_order_total', true));

        // Attempt to verify payment
        $gateway = ViraStore_Moota_Gateway::get_instance();
        $verified = $gateway->verify_payment($order_id, $order_total);

        if ($verified) {
            return new WP_REST_Response(
                array(
                    'success' => true,
                    'message' => __('Payment verified successfully!', 'vrstore-moota'),
                    'status'  => 'completed',
                ),
                200
            );
        } else {
            return new WP_REST_Response(
                array(
                    'success' => false,
                    'message' => __('Payment not found or verification failed.', 'vrstore-moota'),
                    'status'  => 'pending',
                ),
                200
            );
        }
    }

    /**
     * Verify permission for manual verification
     *
     * @param WP_REST_Request $request Full data about the request
     * @return bool True if user has permission
     */
    public function verify_manual_permission(WP_REST_Request $request): bool {
        // Allow logged-in users to verify their own orders
        if (!is_user_logged_in()) {
            return false;
        }

        $order_id = $request->get_param('order_id');
        $order_user_id = get_post_meta($order_id, 'vrstore_customer_id', true);
        $current_user_id = get_current_user_id();

        // Allow if user owns the order or is admin
        return ($order_user_id == $current_user_id) || current_user_can('manage_options');
    }

    /**
     * Schedule periodic payment verification
     */
    public function schedule_payment_verification(): void {
        if (!wp_next_scheduled('vrstore_moota_verify_payments')) {
            wp_schedule_event(time(), 'hourly', 'vrstore_moota_verify_payments');
        }
    }

    /**
     * Verify pending payments periodically
     */
    public function verify_pending_payments(): void {
        // Get pending Moota orders from the last 24 hours
        $args = array(
            'post_type'      => 'vrstore_order',
            'post_status'    => 'publish',
            'posts_per_page' => 50,
            'meta_query'     => array(
                'relation' => 'AND',
                array(
                    'key'   => 'vrstore_payment_method',
                    'value' => 'moota',
                ),
                array(
                    'key'   => 'vrstore_payment_status',
                    'value' => 'pending',
                ),
            ),
            'date_query'     => array(
                array(
                    'after' => '24 hours ago',
                ),
            ),
        );

        $orders = get_posts($args);

        if (empty($orders)) {
            return;
        }

        $gateway = ViraStore_Moota_Gateway::get_instance();

        foreach ($orders as $order) {
            $order_id = $order->ID;
            $order_total = floatval(get_post_meta($order_id, 'vrstore_order_total', true));

            // Try to verify payment
            $verified = $gateway->verify_payment($order_id, $order_total);

            if ($verified) {
                // Log successful verification
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log("Moota: Payment verified for order #{$order_id}");
                }
            }

            // Add small delay to avoid API rate limits
            usleep(500000); // 0.5 seconds
        }
    }

    /**
     * Get webhook URL
     *
     * @return string Webhook URL
     */
    public static function get_webhook_url(): string {
        return rest_url('vrstore-moota/v1/webhook');
    }

    /**
     * Get manual verification URL
     *
     * @param int $order_id Order ID
     * @return string Manual verification URL
     */
    public static function get_manual_verify_url(int $order_id): string {
        return rest_url("vrstore-moota/v1/verify/{$order_id}");
    }
}