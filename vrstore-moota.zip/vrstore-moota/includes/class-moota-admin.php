<?php
/**
 * Moota Admin Settings Class
 *
 * @package ViraStore_Moota
 * @since 1.0.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * ViraStore_Moota_Admin Class
 *
 * Handles admin settings and configuration for Moota payment gateway.
 *
 * @since 1.0.0
 */
class ViraStore_Moota_Admin {

    /**
     * Instance of this class
     *
     * @var ViraStore_Moota_Admin|null
     */
    private static ?ViraStore_Moota_Admin $instance = null;

    /**
     * Settings page slug
     *
     * @var string
     */
    private string $page_slug = 'vrstore-moota-settings';

    /**
     * Get singleton instance
     *
     * @return ViraStore_Moota_Admin
     */
    public static function get_instance(): ViraStore_Moota_Admin {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        $this->init_hooks();
    }

    /**
     * Initialize hooks
     */
    private function init_hooks(): void {
        // Add settings page to Vira Store menu
        add_action('admin_menu', array($this, 'add_admin_menu'), 20);
        
        // Register settings
        add_action('admin_init', array($this, 'register_settings'));
        
        // Enqueue admin assets
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        
        // AJAX handlers
        add_action('wp_ajax_vrstore_moota_test_connection', array($this, 'ajax_test_connection'));
        add_action('wp_ajax_vrstore_moota_fetch_banks', array($this, 'ajax_fetch_banks'));
        add_action('wp_ajax_vrstore_moota_save_bank_account', array($this, 'ajax_save_bank_account'));
        add_action('wp_ajax_vrstore_moota_delete_bank_account', array($this, 'ajax_delete_bank_account'));
    }

    /**
     * Add admin menu
     */
    public function add_admin_menu(): void {
        // Add as submenu under Vira Store Dashboard
        add_submenu_page(
            'vrstore-dashboard',
            __('Moota Payment Settings', 'vrstore-moota'),
            __('Moota', 'vrstore-moota'),
            'manage_options',
            $this->page_slug,
            array($this, 'render_settings_page')
        );
    }

    /**
     * Register settings
     */
    public function register_settings(): void {
        register_setting(
            'vrstore_moota_settings_group',
            'vrstore_moota_settings',
            array(
                'sanitize_callback' => array($this, 'sanitize_settings'),
            )
        );

        // General Settings Section
        add_settings_section(
            'vrstore_moota_general',
            __('General Settings', 'vrstore-moota'),
            array($this, 'render_general_section'),
            $this->page_slug
        );

        // API Settings Section
        add_settings_section(
            'vrstore_moota_api',
            __('API Configuration', 'vrstore-moota'),
            array($this, 'render_api_section'),
            $this->page_slug
        );

        // Bank Accounts Section
        add_settings_section(
            'vrstore_moota_banks',
            __('Bank Accounts', 'vrstore-moota'),
            array($this, 'render_banks_section'),
            $this->page_slug
        );

        // Add settings fields
        $this->add_settings_fields();
    }

    /**
     * Add settings fields
     */
    private function add_settings_fields(): void {
        // Enable/Disable
        add_settings_field(
            'enabled',
            __('Enable Moota', 'vrstore-moota'),
            array($this, 'render_checkbox_field'),
            $this->page_slug,
            'vrstore_moota_general',
            array(
                'field' => 'enabled',
                'description' => __('Enable Moota payment gateway', 'vrstore-moota'),
            )
        );

        // Test Mode
        add_settings_field(
            'test_mode',
            __('Test Mode', 'vrstore-moota'),
            array($this, 'render_checkbox_field'),
            $this->page_slug,
            'vrstore_moota_general',
            array(
                'field' => 'test_mode',
                'description' => __('Enable test mode for development', 'vrstore-moota'),
            )
        );

        // API Key
        add_settings_field(
            'api_key',
            __('API Key', 'vrstore-moota'),
            array($this, 'render_text_field'),
            $this->page_slug,
            'vrstore_moota_api',
            array(
                'field' => 'api_key',
                'type' => 'password',
                'description' => __('Your Moota API key from dashboard', 'vrstore-moota'),
                'class' => 'regular-text',
            )
        );

        // Webhook URL (read-only)
        add_settings_field(
            'webhook_url',
            __('Webhook URL', 'vrstore-moota'),
            array($this, 'render_webhook_field'),
            $this->page_slug,
            'vrstore_moota_api',
            array(
                'description' => __('Copy this URL to your Moota webhook settings', 'vrstore-moota'),
            )
        );
    }

    /**
     * Render settings page
     */
    public function render_settings_page(): void {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'vrstore-moota'));
        }

        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            
            <?php settings_errors(); ?>
            
            <form method="post" action="options.php" id="vrstore-moota-settings-form">
                <?php
                settings_fields('vrstore_moota_settings_group');
                do_settings_sections($this->page_slug);
                ?>
                
                <div class="vrstore-moota-bank-accounts-section">
                    <h2><?php esc_html_e('Bank Accounts Management', 'vrstore-moota'); ?></h2>
                    <div id="vrstore-moota-bank-accounts-list">
                        <?php $this->render_bank_accounts_list(); ?>
                    </div>
                    <button type="button" id="vrstore-moota-add-bank" class="button">
                        <?php esc_html_e('Add Bank Account', 'vrstore-moota'); ?>
                    </button>
                </div>

                <?php submit_button(); ?>
            </form>

            <!-- Bank Account Modal -->
            <div id="vrstore-moota-bank-modal" class="vrstore-modal" style="display: none;">
                <div class="vrstore-modal-content">
                    <div class="vrstore-modal-header">
                        <h3><?php esc_html_e('Add/Edit Bank Account', 'vrstore-moota'); ?></h3>
                        <span class="vrstore-modal-close">&times;</span>
                    </div>
                    <div class="vrstore-modal-body">
                        <form id="vrstore-moota-bank-form">
                            <table class="form-table">
                                <tr>
                                    <th scope="row">
                                        <label for="bank_name"><?php esc_html_e('Bank Name', 'vrstore-moota'); ?></label>
                                    </th>
                                    <td>
                                        <input type="text" id="bank_name" name="bank_name" class="regular-text" required>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="account_number"><?php esc_html_e('Account Number', 'vrstore-moota'); ?></label>
                                    </th>
                                    <td>
                                        <input type="text" id="account_number" name="account_number" class="regular-text" required>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="account_name"><?php esc_html_e('Account Name', 'vrstore-moota'); ?></label>
                                    </th>
                                    <td>
                                        <input type="text" id="account_name" name="account_name" class="regular-text" required>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label for="moota_bank_id"><?php esc_html_e('Moota Bank ID', 'vrstore-moota'); ?></label>
                                    </th>
                                    <td>
                                        <select id="moota_bank_id" name="moota_bank_id" class="regular-text">
                                            <option value=""><?php esc_html_e('Select from Moota...', 'vrstore-moota'); ?></option>
                                        </select>
                                        <button type="button" id="fetch-moota-banks" class="button">
                                            <?php esc_html_e('Fetch from Moota', 'vrstore-moota'); ?>
                                        </button>
                                        <p class="description">
                                            <?php esc_html_e('Select the corresponding bank account from your Moota dashboard', 'vrstore-moota'); ?>
                                        </p>
                                    </td>
                                </tr>
                            </table>
                            <input type="hidden" id="bank_index" name="bank_index" value="">
                        </form>
                    </div>
                    <div class="vrstore-modal-footer">
                        <button type="button" id="save-bank-account" class="button-primary">
                            <?php esc_html_e('Save', 'vrstore-moota'); ?>
                        </button>
                        <button type="button" class="button vrstore-modal-close">
                            <?php esc_html_e('Cancel', 'vrstore-moota'); ?>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <?php
    }

    /**
     * Render general section description
     */
    public function render_general_section(): void {
        echo '<p>' . esc_html__('Configure general Moota payment gateway settings.', 'vrstore-moota') . '</p>';
    }

    /**
     * Render API section description
     */
    public function render_api_section(): void {
        echo '<p>' . esc_html__('Configure your Moota API credentials and webhook settings.', 'vrstore-moota') . '</p>';
    }

    /**
     * Render banks section description
     */
    public function render_banks_section(): void {
        echo '<p>' . esc_html__('Manage bank accounts for receiving payments.', 'vrstore-moota') . '</p>';
    }

    /**
     * Render checkbox field
     *
     * @param array $args Field arguments
     */
    public function render_checkbox_field(array $args): void {
        $settings = get_option('vrstore_moota_settings', array());
        $field = $args['field'];
        $value = $settings[$field] ?? 'no';
        $checked = $value === 'yes' ? 'checked' : '';

        echo '<label>';
        echo '<input type="checkbox" name="vrstore_moota_settings[' . esc_attr($field) . ']" value="yes" ' . $checked . '>';
        echo ' ' . esc_html($args['description'] ?? '');
        echo '</label>';
    }

    /**
     * Render text field
     *
     * @param array $args Field arguments
     */
    public function render_text_field(array $args): void {
        $settings = get_option('vrstore_moota_settings', array());
        $field = $args['field'];
        $value = $settings[$field] ?? '';
        $type = $args['type'] ?? 'text';
        $class = $args['class'] ?? 'regular-text';

        echo '<input type="' . esc_attr($type) . '" name="vrstore_moota_settings[' . esc_attr($field) . ']" ';
        echo 'value="' . esc_attr($value) . '" class="' . esc_attr($class) . '">';
        
        if (!empty($args['description'])) {
            echo '<p class="description">' . esc_html($args['description']) . '</p>';
        }

        // Add test connection button for API key
        if ($field === 'api_key') {
            echo '<br><button type="button" id="test-moota-connection" class="button" style="margin-top: 5px;">';
            echo esc_html__('Test Connection', 'vrstore-moota');
            echo '</button>';
            echo '<span id="connection-status" style="margin-left: 10px;"></span>';
        }
    }

    /**
     * Render webhook field
     *
     * @param array $args Field arguments
     */
    public function render_webhook_field(array $args): void {
        $webhook_url = home_url('/wp-json/vrstore-moota/v1/webhook');
        
        echo '<input type="text" value="' . esc_attr($webhook_url) . '" class="regular-text" readonly>';
        echo '<button type="button" id="copy-webhook-url" class="button" style="margin-left: 5px;">';
        echo esc_html__('Copy', 'vrstore-moota');
        echo '</button>';
        
        if (!empty($args['description'])) {
            echo '<p class="description">' . esc_html($args['description']) . '</p>';
        }
    }

    /**
     * Render bank accounts list
     */
    private function render_bank_accounts_list(): void {
        $settings = get_option('vrstore_moota_settings', array());
        $bank_accounts = $settings['bank_accounts'] ?? array();

        if (empty($bank_accounts)) {
            echo '<p>' . esc_html__('No bank accounts configured yet.', 'vrstore-moota') . '</p>';
            return;
        }

        foreach ($bank_accounts as $index => $account) {
            ?>
            <div class="vrstore-bank-account" data-index="<?php echo esc_attr($index); ?>">
                <h4><?php echo esc_html($account['bank_name'] ?? ''); ?></h4>
                <p><strong><?php esc_html_e('Account Number:', 'vrstore-moota'); ?></strong> <?php echo esc_html($account['account_number'] ?? ''); ?></p>
                <p><strong><?php esc_html_e('Account Name:', 'vrstore-moota'); ?></strong> <?php echo esc_html($account['account_name'] ?? ''); ?></p>
                <p><strong><?php esc_html_e('Moota Bank ID:', 'vrstore-moota'); ?></strong> <?php echo esc_html($account['moota_bank_id'] ?? __('Not set', 'vrstore-moota')); ?></p>
                
                <div class="vrstore-bank-account-actions">
                    <button type="button" class="button edit-bank-account" data-index="<?php echo esc_attr($index); ?>">
                        <?php esc_html_e('Edit', 'vrstore-moota'); ?>
                    </button>
                    <button type="button" class="button delete-bank-account" data-index="<?php echo esc_attr($index); ?>">
                        <?php esc_html_e('Delete', 'vrstore-moota'); ?>
                    </button>
                </div>
            </div>
            <?php
        }
    }

    /**
     * Sanitize settings
     *
     * @param array $input Input settings
     * @return array Sanitized settings
     */
    public function sanitize_settings(array $input): array {
        $sanitized = array();

        // Sanitize checkbox fields
        $checkbox_fields = array('enabled', 'test_mode');
        foreach ($checkbox_fields as $field) {
            $sanitized[$field] = isset($input[$field]) && $input[$field] === 'yes' ? 'yes' : 'no';
        }

        // Sanitize text fields
        $text_fields = array('api_key', 'webhook_url');
        foreach ($text_fields as $field) {
            $sanitized[$field] = sanitize_text_field($input[$field] ?? '');
        }

        // Preserve bank accounts (handled separately via AJAX)
        $current_settings = get_option('vrstore_moota_settings', array());
        $sanitized['bank_accounts'] = $current_settings['bank_accounts'] ?? array();

        return $sanitized;
    }

    /**
     * AJAX: Test API connection
     */
    public function ajax_test_connection(): void {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Insufficient permissions.', 'vrstore-moota')));
        }

        $api_key = sanitize_text_field($_POST['api_key'] ?? '');
        
        if (empty($api_key)) {
            wp_send_json_error(array('message' => __('API key is required.', 'vrstore-moota')));
        }

        // Test API connection
        $response = wp_remote_get('https://app.moota.co/api/v2/bank', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Accept' => 'application/json',
            ),
            'timeout' => 15,
        ));

        if (is_wp_error($response)) {
            wp_send_json_error(array('message' => $response->get_error_message()));
        }

        $status_code = wp_remote_retrieve_response_code($response);
        
        if ($status_code === 200) {
            wp_send_json_success(array('message' => __('Connection successful!', 'vrstore-moota')));
        } else {
            wp_send_json_error(array('message' => sprintf(__('Connection failed with status code: %d', 'vrstore-moota'), $status_code)));
        }
    }

    /**
     * AJAX: Fetch banks from Moota
     */
    public function ajax_fetch_banks(): void {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Insufficient permissions.', 'vrstore-moota')));
        }

        $settings = get_option('vrstore_moota_settings', array());
        $api_key = $settings['api_key'] ?? '';

        if (empty($api_key)) {
            wp_send_json_error(array('message' => __('API key not configured.', 'vrstore-moota')));
        }

        $response = wp_remote_get('https://app.moota.co/api/v2/bank', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Accept' => 'application/json',
            ),
            'timeout' => 15,
        ));

        if (is_wp_error($response)) {
            wp_send_json_error(array('message' => $response->get_error_message()));
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            wp_send_json_error(array('message' => __('Invalid response from Moota API.', 'vrstore-moota')));
        }

        wp_send_json_success($data);
    }

    /**
     * AJAX: Save bank account
     */
    public function ajax_save_bank_account(): void {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Insufficient permissions.', 'vrstore-moota')));
        }

        $bank_data = array(
            'bank_name' => sanitize_text_field($_POST['bank_name'] ?? ''),
            'account_number' => sanitize_text_field($_POST['account_number'] ?? ''),
            'account_name' => sanitize_text_field($_POST['account_name'] ?? ''),
            'moota_bank_id' => sanitize_text_field($_POST['moota_bank_id'] ?? ''),
        );

        $index = isset($_POST['bank_index']) && $_POST['bank_index'] !== '' ? absint($_POST['bank_index']) : null;

        $settings = get_option('vrstore_moota_settings', array());
        $bank_accounts = $settings['bank_accounts'] ?? array();

        if ($index !== null && isset($bank_accounts[$index])) {
            // Update existing account
            $bank_accounts[$index] = $bank_data;
        } else {
            // Add new account
            $bank_accounts[] = $bank_data;
        }

        $settings['bank_accounts'] = $bank_accounts;
        update_option('vrstore_moota_settings', $settings);

        wp_send_json_success(array('message' => __('Bank account saved successfully.', 'vrstore-moota')));
    }

    /**
     * AJAX: Delete bank account
     */
    public function ajax_delete_bank_account(): void {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Insufficient permissions.', 'vrstore-moota')));
        }

        $index = absint($_POST['bank_index'] ?? 0);

        $settings = get_option('vrstore_moota_settings', array());
        $bank_accounts = $settings['bank_accounts'] ?? array();

        if (isset($bank_accounts[$index])) {
            unset($bank_accounts[$index]);
            $bank_accounts = array_values($bank_accounts); // Re-index array
            
            $settings['bank_accounts'] = $bank_accounts;
            update_option('vrstore_moota_settings', $settings);

            wp_send_json_success(array('message' => __('Bank account deleted successfully.', 'vrstore-moota')));
        } else {
            wp_send_json_error(array('message' => __('Bank account not found.', 'vrstore-moota')));
        }
    }

    /**
     * Enqueue admin assets
     */
    public function enqueue_admin_assets(): void {
        $screen = get_current_screen();
        
        // Only enqueue on Moota settings page
        if (!$screen || $screen->id !== 'vira-store_page_vrstore-moota-settings') {
            return;
        }

        wp_enqueue_script(
            'vrstore-moota-admin',
            VRSTORE_MOOTA_PLUGIN_URL . 'assets/js/moota-admin.js',
            array('jquery'),
            VRSTORE_MOOTA_VERSION,
            true
        );

        wp_enqueue_style(
            'vrstore-moota-admin',
            VRSTORE_MOOTA_PLUGIN_URL . 'assets/css/moota-admin.css',
            array(),
            VRSTORE_MOOTA_VERSION
        );

        // Localize script
        wp_localize_script('vrstore-moota-admin', 'vrstore_moota_admin', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('vrstore_moota_admin_nonce'),
            'messages' => array(
                'testing_connection' => __('Testing API connection...', 'vrstore-moota'),
                'connection_success' => __('API connection successful!', 'vrstore-moota'),
                'connection_failed'  => __('API connection failed. Please check your settings.', 'vrstore-moota'),
                'loading_banks'      => __('Loading banks...', 'vrstore-moota'),
                'banks_loaded'       => __('Banks loaded successfully!', 'vrstore-moota'),
                'saving_bank'        => __('Saving bank account...', 'vrstore-moota'),
                'bank_saved'         => __('Bank account saved successfully!', 'vrstore-moota'),
                'deleting_bank'      => __('Deleting bank account...', 'vrstore-moota'),
                'bank_deleted'       => __('Bank account deleted successfully!', 'vrstore-moota'),
                'confirm_delete'     => __('Are you sure you want to delete this bank account?', 'vrstore-moota'),
            ),
        ));
    }
}