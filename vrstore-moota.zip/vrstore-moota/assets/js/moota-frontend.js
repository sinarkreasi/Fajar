/**
 * Moota Frontend JavaScript
 *
 * Handles Moota payment method interactions and bank transfer instructions.
 *
 * @package ViraStore_Moota
 * @since 1.0.0
 */

(function($) {
    'use strict';

    /**
     * Moota Payment Handler
     */
    const MootaPayment = {
        
        /**
         * Initialize Moota payment functionality
         */
        init: function() {
            this.bindEvents();
            this.handlePaymentMethodChange();
        },

        /**
         * Bind event handlers
         */
        bindEvents: function() {
            // Handle payment method selection change
            $(document).on('change', '#vrstore_payment_method', this.handlePaymentMethodChange.bind(this));
            
            // Handle Moota payment form submission
            $(document).on('submit', '.vrstore-checkout-form', this.handleFormSubmission.bind(this));
            
            // Handle manual payment verification
            $(document).on('click', '.vrstore-moota-verify-payment', this.verifyPayment.bind(this));
            
            // Handle copy bank details
            $(document).on('click', '.vrstore-moota-copy-btn', this.copyBankDetails.bind(this));
            
            // Auto-refresh payment status
            this.startPaymentStatusCheck();
        },

        /**
         * Handle payment method selection change
         */
        handlePaymentMethodChange: function() {
            const selectedMethod = $('#vrstore_payment_method').val();
            
            // Hide all payment method fields
            $('.vrstore-payment-method-fields').hide();
            
            // Show selected method fields
            if (selectedMethod) {
                const targetElement = `#vrstore-payment-method-${selectedMethod}`;
                $(targetElement).show();
                
                // Handle Moota-specific setup
                if (selectedMethod === 'moota') {
                    // Update amount display if cart total is available
                    this.updateAmountDisplay();
                    
                    // Sync selected bank with hidden input
                    $('input[name="vrstore_moota_bank"]').on('change', function() {
                        $('#vrstore_moota_selected_bank').val($(this).val());
                    });
                    
                    // Set initial value
                    const firstBank = $('input[name="vrstore_moota_bank"]:checked').val();
                    if (firstBank) {
                        $('#vrstore_moota_selected_bank').val(firstBank);
                    }
                }
            }
        },
        
        /**
         * Update amount display for Moota payment
         */
        updateAmountDisplay: function() {
            // Try to get amount from checkout form
            const $checkoutForm = $('.vrstore-checkout-form');
            if ($checkoutForm.length) {
                // Amount might be in order summary
                const $totalElement = $('.vrstore-order-total, .vrstore-cart-total, #vrstore-cart-total');
                if ($totalElement.length) {
                    const totalText = $totalElement.text().trim();
                    $('#vrstore-moota-amount').text(totalText);
                }
            }
        },

        /**
         * Load available bank accounts for Moota payment
         */
        loadBankAccounts: function() {
            const $bankContainer = $('#vrstore-moota-bank-accounts');
            
            if ($bankContainer.length === 0) {
                return;
            }

            // Show loading state
            $bankContainer.html('<div class="vrstore-moota-loading">' + 
                '<span class="spinner"></span> ' + 
                (vrstore_moota.messages.loading_banks || 'Loading bank accounts...') + 
                '</div>');

            // Make AJAX request to get bank accounts
            $.ajax({
                url: vrstore_moota.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrstore_get_moota_banks',
                    nonce: vrstore_moota.nonce
                },
                success: function(response) {
                    if (response.success && response.data.banks) {
                        MootaPayment.renderBankAccounts(response.data.banks);
                    } else {
                        $bankContainer.html('<div class="vrstore-moota-error">' + 
                            (response.data.message || 'Failed to load bank accounts.') + 
                            '</div>');
                    }
                },
                error: function() {
                    $bankContainer.html('<div class="vrstore-moota-error">' + 
                        (vrstore_moota.messages.error_occurred || 'An error occurred while loading bank accounts.') + 
                        '</div>');
                }
            });
        },

        /**
         * Render bank accounts selection
         *
         * @param {Array} banks Array of bank account objects
         */
        renderBankAccounts: function(banks) {
            const $bankContainer = $('#vrstore-moota-bank-accounts');
            
            if (banks.length === 0) {
                $bankContainer.html('<div class="vrstore-moota-notice">' + 
                    'No bank accounts configured. Please contact administrator.' + 
                    '</div>');
                return;
            }

            let html = '<div class="vrstore-moota-bank-selection">';
            html += '<h4>Select Bank Account for Transfer:</h4>';
            html += '<div class="vrstore-moota-banks-list">';

            banks.forEach(function(bank, index) {
                const isSelected = index === 0 ? 'checked' : '';
                html += `
                    <div class="vrstore-moota-bank-option">
                        <input type="radio" 
                               id="moota_bank_${bank.id}" 
                               name="vrstore_moota_bank" 
                               value="${bank.id}" 
                               ${isSelected}
                               required>
                        <label for="moota_bank_${bank.id}" class="vrstore-moota-bank-label">
                            <div class="vrstore-moota-bank-info">
                                <div class="vrstore-moota-bank-name">${bank.bank_name}</div>
                                <div class="vrstore-moota-account-details">
                                    <span class="vrstore-moota-account-number">${bank.account_number}</span>
                                    <span class="vrstore-moota-account-name">${bank.account_name}</span>
                                </div>
                            </div>
                            <button type="button" class="vrstore-moota-copy-btn" 
                                    data-account="${bank.account_number}" 
                                    title="Copy Account Number">
                                📋
                            </button>
                        </label>
                    </div>
                `;
            });

            html += '</div>';
            html += '<div class="vrstore-moota-instructions">';
            html += '<h5>Payment Instructions:</h5>';
            html += '<ol>';
            html += '<li>Transfer the exact amount to the selected bank account</li>';
            html += '<li>Use your order number as the transfer reference/note</li>';
            html += '<li>Payment will be automatically verified within 5-10 minutes</li>';
            html += '<li>You will receive confirmation once payment is verified</li>';
            html += '</ol>';
            html += '</div>';
            html += '</div>';

            $bankContainer.html(html);
        },

        /**
         * Handle form submission for Moota payment
         *
         * @param {Event} e Form submission event
         */
        handleFormSubmission: function(e) {
            const selectedMethod = $('#vrstore_payment_method').val();
            
            if (selectedMethod !== 'moota') {
                return; // Let other payment methods handle normally
            }

            e.preventDefault();
            
            // Validate Moota-specific fields
            if (!this.validateMootaPayment()) {
                return false;
            }

            // Process Moota payment
            this.processMootaPayment($(e.target));
        },

        /**
         * Validate Moota payment form
         *
         * @return {boolean} True if valid
         */
        validateMootaPayment: function() {
            const selectedBank = $('input[name="vrstore_moota_bank"]:checked').val();
            
            if (!selectedBank) {
                alert('Please select a bank account for transfer.');
                return false;
            }

            return true;
        },

        /**
         * Process Moota payment
         *
         * @param {jQuery} $form Form element
         */
        processMootaPayment: function($form) {
            const $submitBtn = $form.find('button[type="submit"]');
            const originalText = $submitBtn.text();
            
            // Set loading state
            $submitBtn.prop('disabled', true)
                     .text(vrstore_moota.messages.processing || 'Processing payment...');

            // Prepare form data
            const formData = new FormData($form[0]);
            formData.append('action', 'vrstore_process_moota_payment');
            formData.append('nonce', vrstore_moota.nonce);

            // Make AJAX request
            $.ajax({
                url: vrstore_moota.ajax_url,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        // Redirect to thank you page or show success message
                        if (response.data.redirect_url) {
                            window.location.href = response.data.redirect_url;
                        } else {
                            MootaPayment.showPaymentInstructions(response.data);
                        }
                    } else {
                        alert(response.data.message || 'Payment processing failed.');
                        $submitBtn.prop('disabled', false).text(originalText);
                    }
                },
                error: function() {
                    alert(vrstore_moota.messages.error_occurred || 'An error occurred. Please try again.');
                    $submitBtn.prop('disabled', false).text(originalText);
                }
            });
        },

        /**
         * Show payment instructions after order creation
         *
         * @param {Object} data Response data
         */
        showPaymentInstructions: function(data) {
            const $form = $('.vrstore-checkout-form');
            
            let html = '<div class="vrstore-moota-payment-instructions">';
            html += '<div class="vrstore-moota-success-header">';
            html += '<h3>✅ Order Created Successfully!</h3>';
            html += `<p>Order #${data.order_id} - Total: ${data.formatted_total}</p>`;
            html += '</div>';
            
            if (data.bank_details) {
                html += '<div class="vrstore-moota-transfer-details">';
                html += '<h4>Complete Your Payment:</h4>';
                html += '<div class="vrstore-moota-bank-details">';
                html += `<div class="vrstore-moota-detail-row">`;
                html += `<span class="label">Bank:</span>`;
                html += `<span class="value">${data.bank_details.bank_name}</span>`;
                html += `</div>`;
                html += `<div class="vrstore-moota-detail-row">`;
                html += `<span class="label">Account Number:</span>`;
                html += `<span class="value">${data.bank_details.account_number}</span>`;
                html += `<button type="button" class="vrstore-moota-copy-btn" data-account="${data.bank_details.account_number}">📋</button>`;
                html += `</div>`;
                html += `<div class="vrstore-moota-detail-row">`;
                html += `<span class="label">Account Name:</span>`;
                html += `<span class="value">${data.bank_details.account_name}</span>`;
                html += `</div>`;
                html += `<div class="vrstore-moota-detail-row">`;
                html += `<span class="label">Amount:</span>`;
                html += `<span class="value highlight">${data.formatted_total}</span>`;
                html += `</div>`;
                html += `<div class="vrstore-moota-detail-row">`;
                html += `<span class="label">Reference:</span>`;
                html += `<span class="value">Order #${data.order_id}</span>`;
                html += `</div>`;
                html += '</div>';
                html += '</div>';
            }
            
            html += '<div class="vrstore-moota-actions">';
            html += `<button type="button" class="vrstore-moota-verify-payment" data-order-id="${data.order_id}">`;
            html += 'Check Payment Status';
            html += '</button>';
            html += '</div>';
            
            html += '<div id="vrstore-moota-payment-status"></div>';
            html += '</div>';
            
            $form.html(html);
            
            // Start auto-checking payment status
            this.startPaymentStatusCheck(data.order_id);
        },

        /**
         * Verify payment status
         *
         * @param {Event} e Click event
         */
        verifyPayment: function(e) {
            e.preventDefault();
            
            const $btn = $(e.target);
            const orderId = $btn.data('order-id');
            const originalText = $btn.text();
            
            $btn.prop('disabled', true)
                .text(vrstore_moota.messages.checking_payment || 'Checking payment...');

            $.ajax({
                url: vrstore_moota.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrstore_check_moota_payment',
                    order_id: orderId,
                    nonce: vrstore_moota.nonce
                },
                success: function(response) {
                    const $statusDiv = $('#vrstore-moota-payment-status');
                    
                    if (response.success) {
                        if (response.data.status === 'completed') {
                            $statusDiv.html('<div class="vrstore-moota-status-success">' + 
                                (vrstore_moota.messages.payment_verified || 'Payment verified successfully!') + 
                                '</div>');
                            $btn.hide();
                            
                            // Redirect after a delay
                            setTimeout(function() {
                                if (response.data.redirect_url) {
                                    window.location.href = response.data.redirect_url;
                                }
                            }, 2000);
                        } else {
                            $statusDiv.html('<div class="vrstore-moota-status-pending">' + 
                                (vrstore_moota.messages.payment_pending || 'Payment is still pending.') + 
                                '</div>');
                        }
                    } else {
                        $statusDiv.html('<div class="vrstore-moota-status-error">' + 
                            (response.data.message || vrstore_moota.messages.payment_failed) + 
                            '</div>');
                    }
                    
                    $btn.prop('disabled', false).text(originalText);
                },
                error: function() {
                    $('#vrstore-moota-payment-status').html('<div class="vrstore-moota-status-error">' + 
                        (vrstore_moota.messages.error_occurred || 'An error occurred.') + 
                        '</div>');
                    $btn.prop('disabled', false).text(originalText);
                }
            });
        },

        /**
         * Copy bank account details to clipboard
         *
         * @param {Event} e Click event
         */
        copyBankDetails: function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const $btn = $(e.target);
            const accountNumber = $btn.data('account');
            
            if (navigator.clipboard) {
                navigator.clipboard.writeText(accountNumber).then(function() {
                    MootaPayment.showCopyFeedback($btn, 'Copied!');
                }).catch(function() {
                    MootaPayment.fallbackCopyText(accountNumber, $btn);
                });
            } else {
                MootaPayment.fallbackCopyText(accountNumber, $btn);
            }
        },

        /**
         * Fallback copy method for older browsers
         *
         * @param {string} text Text to copy
         * @param {jQuery} $btn Button element
         */
        fallbackCopyText: function(text, $btn) {
            const textArea = document.createElement('textarea');
            textArea.value = text;
            textArea.style.position = 'fixed';
            textArea.style.left = '-999999px';
            textArea.style.top = '-999999px';
            document.body.appendChild(textArea);
            textArea.focus();
            textArea.select();
            
            try {
                document.execCommand('copy');
                this.showCopyFeedback($btn, 'Copied!');
            } catch (err) {
                this.showCopyFeedback($btn, 'Failed');
            }
            
            document.body.removeChild(textArea);
        },

        /**
         * Show copy feedback
         *
         * @param {jQuery} $btn Button element
         * @param {string} message Feedback message
         */
        showCopyFeedback: function($btn, message) {
            const originalText = $btn.text();
            $btn.text(message);
            
            setTimeout(function() {
                $btn.text(originalText);
            }, 1500);
        },

        /**
         * Start automatic payment status checking
         *
         * @param {number} orderId Order ID to check
         */
        startPaymentStatusCheck: function(orderId) {
            if (!orderId) {
                return;
            }

            // Check every 30 seconds for 10 minutes
            let checkCount = 0;
            const maxChecks = 20;
            
            const checkInterval = setInterval(function() {
                checkCount++;
                
                if (checkCount > maxChecks) {
                    clearInterval(checkInterval);
                    return;
                }

                $.ajax({
                    url: vrstore_moota.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'vrstore_check_moota_payment',
                        order_id: orderId,
                        nonce: vrstore_moota.nonce
                    },
                    success: function(response) {
                        if (response.success && response.data.status === 'completed') {
                            clearInterval(checkInterval);
                            
                            const $statusDiv = $('#vrstore-moota-payment-status');
                            $statusDiv.html('<div class="vrstore-moota-status-success">' + 
                                (vrstore_moota.messages.payment_verified || 'Payment verified successfully!') + 
                                '</div>');
                            
                            $('.vrstore-moota-verify-payment').hide();
                            
                            // Redirect after a delay
                            setTimeout(function() {
                                if (response.data.redirect_url) {
                                    window.location.href = response.data.redirect_url;
                                }
                            }, 2000);
                        }
                    }
                });
            }, 30000); // Check every 30 seconds
        }
    };

    /**
     * Initialize when document is ready
     */
    $(document).ready(function() {
        MootaPayment.init();
    });

})(jQuery);