/**
 * Moota Admin JavaScript
 *
 * Handles admin interface interactions for Moota settings.
 *
 * @package ViraStore_Moota
 * @since 1.0.0
 */

(function($) {
    'use strict';

    /**
     * Moota Admin Handler
     */
    const MootaAdmin = {
        
        /**
         * Initialize admin functionality
         */
        init: function() {
            this.bindEvents();
            this.initTooltips();
        },

        /**
         * Bind event handlers
         */
        bindEvents: function() {
            // Test API connection
            $(document).on('click', '#test-moota-connection', this.testConnection.bind(this));
            
            // Fetch banks from Moota API
            $(document).on('click', '#fetch-moota-banks', this.fetchBanks.bind(this));
            
            // Add new bank account (open modal)
            $(document).on('click', '#vrstore-moota-add-bank', this.addBankRow.bind(this));
            
            // Edit bank account (open modal)
            $(document).on('click', '.edit-bank-account', this.editBankAccount.bind(this));
            
            // Delete bank account
            $(document).on('click', '.delete-bank-account', this.deleteBankAccount.bind(this));
            
            // Save bank account (from modal)
            $(document).on('click', '#save-bank-account', this.saveBankAccountModal.bind(this));
            
            // Close modal
            $(document).on('click', '.vrstore-modal-close', this.closeModal.bind(this));
            
            // Copy webhook URL
            $(document).on('click', '#copy-webhook-url', this.copyWebhookUrl.bind(this));
            
            // Close modal when clicking outside
            $(document).on('click', '.vrstore-modal', function(e) {
                if (e.target === this) {
                    MootaAdmin.closeModal();
                }
            });
        },

        /**
         * Initialize tooltips
         */
        initTooltips: function() {
            $('.vrstore-moota-tooltip').each(function() {
                const $this = $(this);
                const title = $this.attr('title');
                
                if (title) {
                    $this.removeAttr('title');
                    $this.on('mouseenter', function() {
                        MootaAdmin.showTooltip($this, title);
                    }).on('mouseleave', function() {
                        MootaAdmin.hideTooltip();
                    });
                }
            });
        },

        /**
         * Show tooltip
         *
         * @param {jQuery} $element Element to show tooltip for
         * @param {string} text Tooltip text
         */
        showTooltip: function($element, text) {
            const $tooltip = $('<div class="vrstore-moota-tooltip-popup">' + text + '</div>');
            $('body').append($tooltip);
            
            const offset = $element.offset();
            const elementHeight = $element.outerHeight();
            
            $tooltip.css({
                top: offset.top + elementHeight + 5,
                left: offset.left,
                position: 'absolute',
                zIndex: 9999
            }).fadeIn(200);
        },

        /**
         * Hide tooltip
         */
        hideTooltip: function() {
            $('.vrstore-moota-tooltip-popup').fadeOut(200, function() {
                $(this).remove();
            });
        },

        /**
         * Test API connection
         *
         * @param {Event} e Click event
         */
        testConnection: function(e) {
            e.preventDefault();
            
            const $btn = $(e.target);
            const $status = $('#vrstore-moota-connection-status');
            const originalText = $btn.text();
            
            // Get API key
            const apiKey = $('#vrstore_moota_settings_api_key').val();
            
            if (!apiKey) {
                this.showMessage($status, 'error', 'Please enter API key first.');
                return;
            }
            
            // Set loading state
            $btn.prop('disabled', true)
                .text(vrstore_moota_admin.messages.testing_connection || 'Testing...');
            
            // Make AJAX request
            $.ajax({
                url: vrstore_moota_admin.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrstore_moota_test_connection',
                    api_key: apiKey,
                    nonce: vrstore_moota_admin.nonce
                },
                success: function(response) {
                    if (response.success) {
                        MootaAdmin.showMessage($status, 'success', 
                            vrstore_moota_admin.messages.connection_success || 'Connection successful!');
                    } else {
                        MootaAdmin.showMessage($status, 'error', 
                            response.data.message || vrstore_moota_admin.messages.connection_failed);
                    }
                },
                error: function() {
                    MootaAdmin.showMessage($status, 'error', 
                        vrstore_moota_admin.messages.connection_failed || 'Connection failed.');
                },
                complete: function() {
                    $btn.prop('disabled', false).text(originalText);
                }
            });
        },

        /**
         * Load banks from Moota API
         *
         * @param {Event} e Click event
         */
        loadBanks: function(e) {
            e.preventDefault();
            
            const $btn = $(e.target);
            const $container = $('#vrstore-moota-banks-container');
            const originalText = $btn.text();
            
            // Set loading state
            $btn.prop('disabled', true)
                .text(vrstore_moota_admin.messages.loading_banks || 'Loading...');
            
            // Make AJAX request
            $.ajax({
                url: vrstore_moota_admin.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrstore_moota_fetch_banks',
                    nonce: vrstore_moota_admin.nonce
                },
                success: function(response) {
                    if (response.success && response.data.banks) {
                        MootaAdmin.renderBanksTable(response.data.banks);
                        MootaAdmin.showNotice('success', 
                            vrstore_moota_admin.messages.banks_loaded || 'Banks loaded successfully!');
                    } else {
                        MootaAdmin.showNotice('error', 
                            response.data.message || 'Failed to load banks.');
                    }
                },
                error: function() {
                    MootaAdmin.showNotice('error', 'Failed to load banks from API.');
                },
                complete: function() {
                    $btn.prop('disabled', false).text(originalText);
                }
            });
        },

        /**
         * Render banks table
         *
         * @param {Array} banks Array of bank objects
         */
        renderBanksTable: function(banks) {
            const $container = $('#vrstore-moota-banks-container');
            
            if (banks.length === 0) {
                $container.html('<p>No banks found in your Moota account.</p>');
                return;
            }
            
            let html = '<table class="wp-list-table widefat fixed striped">';
            html += '<thead>';
            html += '<tr>';
            html += '<th>Bank Name</th>';
            html += '<th>Account Number</th>';
            html += '<th>Account Name</th>';
            html += '<th>Balance</th>';
            html += '<th>Status</th>';
            html += '<th>Actions</th>';
            html += '</tr>';
            html += '</thead>';
            html += '<tbody>';
            
            banks.forEach(function(bank) {
                const isEnabled = bank.enabled ? 'checked' : '';
                const statusClass = bank.is_active ? 'active' : 'inactive';
                const statusText = bank.is_active ? 'Active' : 'Inactive';
                
                html += '<tr data-bank-id="' + bank.id + '">';
                html += '<td>' + bank.bank_name + '</td>';
                html += '<td><code>' + bank.account_number + '</code></td>';
                html += '<td>' + bank.account_name + '</td>';
                html += '<td>' + (bank.balance || 'N/A') + '</td>';
                html += '<td><span class="vrstore-moota-status ' + statusClass + '">' + statusText + '</span></td>';
                html += '<td>';
                html += '<label class="vrstore-moota-switch">';
                html += '<input type="checkbox" class="vrstore-moota-bank-toggle" ' + isEnabled + ' data-bank-id="' + bank.id + '">';
                html += '<span class="vrstore-moota-slider"></span>';
                html += '</label>';
                html += '<button type="button" class="button vrstore-moota-save-bank" data-bank-id="' + bank.id + '">Save</button>';
                html += '<button type="button" class="button vrstore-moota-delete-bank" data-bank-id="' + bank.id + '">Delete</button>';
                html += '</td>';
                html += '</tr>';
            });
            
            html += '</tbody>';
            html += '</table>';
            
            $container.html(html);
        },

        /**
         * Save bank account settings
         *
         * @param {Event} e Click event
         */
        saveBankAccount: function(e) {
            e.preventDefault();
            
            const $btn = $(e.target);
            const bankId = $btn.data('bank-id');
            const $row = $btn.closest('tr');
            const enabled = $row.find('.vrstore-moota-bank-toggle').is(':checked');
            const originalText = $btn.text();
            
            // Set loading state
            $btn.prop('disabled', true)
                .text(vrstore_moota_admin.messages.saving_bank || 'Saving...');
            
            // Make AJAX request
            $.ajax({
                url: vrstore_moota_admin.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrstore_moota_save_bank',
                    bank_id: bankId,
                    enabled: enabled ? 1 : 0,
                    nonce: vrstore_moota_admin.nonce
                },
                success: function(response) {
                    if (response.success) {
                        MootaAdmin.showNotice('success', 
                            vrstore_moota_admin.messages.bank_saved || 'Bank account saved!');
                    } else {
                        MootaAdmin.showNotice('error', 
                            response.data.message || 'Failed to save bank account.');
                    }
                },
                error: function() {
                    MootaAdmin.showNotice('error', 'Failed to save bank account.');
                },
                complete: function() {
                    $btn.prop('disabled', false).text(originalText);
                }
            });
        },

        /**
         * Delete bank account
         *
         * @param {Event} e Click event
         */
        deleteBankAccount: function(e) {
            e.preventDefault();
            
            if (!confirm(vrstore_moota_admin.messages.confirm_delete || 'Are you sure?')) {
                return;
            }
            
            const $btn = $(e.target);
            const bankId = $btn.data('bank-id');
            const $row = $btn.closest('tr');
            const originalText = $btn.text();
            
            // Set loading state
            $btn.prop('disabled', true)
                .text(vrstore_moota_admin.messages.deleting_bank || 'Deleting...');
            
            // Make AJAX request
            $.ajax({
                url: vrstore_moota_admin.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrstore_moota_delete_bank',
                    bank_id: bankId,
                    nonce: vrstore_moota_admin.nonce
                },
                success: function(response) {
                    if (response.success) {
                        $row.fadeOut(300, function() {
                            $(this).remove();
                        });
                        MootaAdmin.showNotice('success', 
                            vrstore_moota_admin.messages.bank_deleted || 'Bank account deleted!');
                    } else {
                        MootaAdmin.showNotice('error', 
                            response.data.message || 'Failed to delete bank account.');
                        $btn.prop('disabled', false).text(originalText);
                    }
                },
                error: function() {
                    MootaAdmin.showNotice('error', 'Failed to delete bank account.');
                    $btn.prop('disabled', false).text(originalText);
                }
            });
        },

        /**
         * Open bank account modal for adding new account
         *
         * @param {Event} e Click event
         */
        addBankRow: function(e) {
            e.preventDefault();
            
            // Clear form
            $('#vrstore-moota-bank-form')[0].reset();
            $('#bank_index').val('');
            
            // Clear Moota bank select
            $('#moota_bank_id').empty().append('<option value="">Select from Moota...</option>');
            
            // Show modal
            $('#vrstore-moota-bank-modal').show();
        },

        /**
         * Fetch banks from Moota API for modal dropdown
         *
         * @param {Event} e Click event
         */
        fetchBanks: function(e) {
            e.preventDefault();
            
            const $button = $(e.target);
            const $select = $('#moota_bank_id');
            const originalText = $button.text();
            
            $button.prop('disabled', true).text(vrstore_moota_admin.messages.loading_banks || 'Loading...');
            
            $.ajax({
                url: vrstore_moota_admin.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrstore_moota_fetch_banks',
                    nonce: vrstore_moota_admin.nonce
                },
                success: function(response) {
                    if (response.success && response.data.banks) {
                        $select.empty().append('<option value="">Select from Moota...</option>');
                        
                        response.data.banks.forEach(function(bank) {
                            $select.append('<option value="' + bank.id + '">' + bank.bank_name + ' - ' + bank.account_number + '</option>');
                        });
                        
                        MootaAdmin.showNotice('success', vrstore_moota_admin.messages.banks_loaded || 'Banks loaded successfully!', 3000);
                    } else {
                        MootaAdmin.showNotice('error', response.data ? response.data.message : 'Failed to load banks');
                    }
                },
                error: function() {
                    MootaAdmin.showNotice('error', 'Failed to load banks');
                },
                complete: function() {
                    $button.prop('disabled', false).text(originalText);
                }
            });
        },

        /**
         * Edit bank account (open modal with data)
         *
         * @param {Event} e Click event
         */
        editBankAccount: function(e) {
            e.preventDefault();
            
            const $button = $(e.target);
            const index = $button.data('index');
            const $bankDiv = $button.closest('.vrstore-bank-account');
            
            // Extract data from the bank account div
            const bankName = $bankDiv.find('h4').text();
            const accountNumber = $bankDiv.find('p:contains("Account Number:")').text().replace('Account Number: ', '');
            const accountName = $bankDiv.find('p:contains("Account Name:")').text().replace('Account Name: ', '');
            const mootaBankId = $bankDiv.find('p:contains("Moota Bank ID:")').text().replace('Moota Bank ID: ', '');
            
            // Fill form
            $('#bank_name').val(bankName);
            $('#account_number').val(accountNumber);
            $('#account_name').val(accountName);
            $('#bank_index').val(index);
            
            // Set Moota bank ID if available
            if (mootaBankId && mootaBankId !== 'Not set') {
                $('#moota_bank_id').append('<option value="' + mootaBankId + '" selected>' + mootaBankId + '</option>');
            }
            
            // Show modal
            $('#vrstore-moota-bank-modal').show();
        },

        /**
         * Save bank account from modal
         *
         * @param {Event} e Click event
         */
        saveBankAccountModal: function(e) {
            e.preventDefault();
            
            const $button = $(e.target);
            const originalText = $button.text();
            
            // Validate required fields
            const bankName = $('#bank_name').val();
            const accountNumber = $('#account_number').val();
            const accountName = $('#account_name').val();
            
            if (!bankName || !accountNumber || !accountName) {
                MootaAdmin.showNotice('error', 'Please fill in all required fields');
                return;
            }
            
            $button.prop('disabled', true).text(vrstore_moota_admin.messages.saving_bank || 'Saving...');
            
            $.ajax({
                url: vrstore_moota_admin.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrstore_moota_save_bank_account',
                    nonce: vrstore_moota_admin.nonce,
                    bank_name: bankName,
                    account_number: accountNumber,
                    account_name: accountName,
                    moota_bank_id: $('#moota_bank_id').val(),
                    bank_index: $('#bank_index').val()
                },
                success: function(response) {
                    if (response.success) {
                        MootaAdmin.showNotice('success', vrstore_moota_admin.messages.bank_saved || 'Bank account saved successfully!');
                        MootaAdmin.closeModal();
                        location.reload(); // Reload to show updated list
                    } else {
                        MootaAdmin.showNotice('error', response.data ? response.data.message : 'Failed to save bank account');
                    }
                },
                error: function() {
                    MootaAdmin.showNotice('error', 'Failed to save bank account');
                },
                complete: function() {
                    $button.prop('disabled', false).text(originalText);
                }
            });
        },

        /**
         * Close modal
         */
        closeModal: function() {
            $('#vrstore-moota-bank-modal').hide();
        },

        /**
         * Copy webhook URL to clipboard
         *
         * @param {Event} e Click event
         */
        copyWebhookUrl: function(e) {
            e.preventDefault();
            
            const $input = $(e.target).prev('input');
            $input.select();
            document.execCommand('copy');
            
            const $button = $(e.target);
            const originalText = $button.text();
            $button.text('Copied!');
            
            setTimeout(function() {
                $button.text(originalText);
            }, 2000);
        },

        /**
         * Toggle test mode settings visibility
         *
         * @param {Event} e Change event
         */
        toggleTestMode: function(e) {
            const isTestMode = $(e.target).is(':checked');
            const $testSettings = $('.vrstore-moota-test-settings');
            
            if (isTestMode) {
                $testSettings.slideDown();
            } else {
                $testSettings.slideUp();
            }
        },

        /**
         * Auto-save settings on change
         *
         * @param {Event} e Change event
         */
        autoSaveSettings: function(e) {
            const $field = $(e.target);
            const fieldName = $field.attr('name');
            const fieldValue = $field.val();
            
            // Debounce the save operation
            clearTimeout(this.saveTimeout);
            this.saveTimeout = setTimeout(function() {
                MootaAdmin.saveFieldValue(fieldName, fieldValue);
            }, 1000);
        },

        /**
         * Save individual field value
         *
         * @param {string} fieldName Field name
         * @param {string} fieldValue Field value
         */
        saveFieldValue: function(fieldName, fieldValue) {
            $.ajax({
                url: vrstore_moota_admin.ajax_url,
                type: 'POST',
                data: {
                    action: 'vrstore_moota_save_field',
                    field_name: fieldName,
                    field_value: fieldValue,
                    nonce: vrstore_moota_admin.nonce
                },
                success: function(response) {
                    if (response.success) {
                        MootaAdmin.showNotice('success', 'Settings saved automatically.', 2000);
                    }
                }
            });
        },

        /**
         * Show message in status container
         *
         * @param {jQuery} $container Status container
         * @param {string} type Message type (success, error, warning)
         * @param {string} message Message text
         */
        showMessage: function($container, type, message) {
            const className = 'vrstore-moota-message-' + type;
            $container.html('<div class="' + className + '">' + message + '</div>');
            
            // Auto-hide after 5 seconds
            setTimeout(function() {
                $container.fadeOut(300, function() {
                    $(this).empty().show();
                });
            }, 5000);
        },

        /**
         * Show admin notice
         *
         * @param {string} type Notice type (success, error, warning)
         * @param {string} message Notice message
         * @param {number} duration Auto-hide duration in ms (optional)
         */
        showNotice: function(type, message, duration) {
            const $notice = $('<div class="notice notice-' + type + ' is-dismissible"><p>' + message + '</p></div>');
            $('.wrap h1').after($notice);
            
            // Add dismiss functionality
            $notice.on('click', '.notice-dismiss', function() {
                $notice.fadeOut(300, function() {
                    $(this).remove();
                });
            });
            
            // Auto-hide if duration specified
            if (duration) {
                setTimeout(function() {
                    $notice.fadeOut(300, function() {
                        $(this).remove();
                    });
                }, duration);
            }
        }
    };

    /**
     * Initialize when document is ready
     */
    $(document).ready(function() {
        MootaAdmin.init();
    });

})(jQuery);