<?php
/**
 * Plugin Name: ViraStore Moota
 * Plugin URI: https://viraloka.com/pro/vrstore-moota
 * Description: Moota payment gateway integration for Vira Store - automated bank transfer monitoring and payment processing.
 * Version: 1.0.0
 * Author: Viraloka
 * Author URI: https://viraloka.com
 * Text Domain: vrstore-moota
 * Domain Path: /languages
 * Requires at least: 6.0
 * Requires PHP: 8.2
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * 
 * Requires Plugins: vira-store
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('VRSTORE_MOOTA_VERSION', '1.0.0');
define('VRSTORE_MOOTA_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('VRSTORE_MOOTA_PLUGIN_URL', plugin_dir_url(__FILE__));
define('VRSTORE_MOOTA_PLUGIN_BASENAME', plugin_basename(__FILE__));
define('VRSTORE_MOOTA_PLUGIN_FILE', __FILE__);

/**
 * Main ViraStore Moota class
 */
final class ViraStore_Moota {
    /**
     * Singleton instance
     *
     * @var ViraStore_Moota|null
     */
    private static ?ViraStore_Moota $instance = null;

    /**
     * Get singleton instance
     *
     * @return ViraStore_Moota
     */
    public static function get_instance(): ViraStore_Moota {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        // Check if Vira Store is active
        add_action('plugins_loaded', array($this, 'init'));
        
        // Activation and deactivation hooks
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
    }

    /**
     * Initialize the plugin
     */
    public function init(): void {
        // Check if Vira Store is active
        if (!$this->is_vira_store_active()) {
            add_action('admin_notices', array($this, 'vira_store_missing_notice'));
            return;
        }

        // Load text domain
        $this->load_textdomain();

        // Include required files
        $this->include_files();

        // Initialize hooks
        $this->init_hooks();
    }

    /**
     * Check if Vira Store plugin is active
     *
     * @return bool
     */
    private function is_vira_store_active(): bool {
        return class_exists('Vira_Store') || function_exists('vrstore_get_version');
    }

    /**
     * Load plugin text domain
     */
    private function load_textdomain(): void {
        load_plugin_textdomain(
            'vrstore-moota',
            false,
            dirname(plugin_basename(__FILE__)) . '/languages'
        );
    }

    /**
     * Include required files
     */
    private function include_files(): void {
        require_once VRSTORE_MOOTA_PLUGIN_DIR . 'includes/class-moota-gateway.php';
        require_once VRSTORE_MOOTA_PLUGIN_DIR . 'includes/class-moota-admin.php';
        require_once VRSTORE_MOOTA_PLUGIN_DIR . 'includes/class-moota-webhook.php';
    }

    /**
     * Initialize hooks
     */
    private function init_hooks(): void {
        // Add Moota gateway to Vira Store payment gateways
        add_filter('vrstore_payment_gateways', array($this, 'add_moota_gateway'));
        
        // Initialize admin settings
        if (is_admin()) {
            ViraStore_Moota_Admin::get_instance();
        }

        // Initialize webhook handler
        ViraStore_Moota_Webhook::get_instance();

        // Enqueue scripts and styles
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_assets'));
        
        // Handle AJAX payment processing
        add_action('wp_ajax_vrstore_process_moota_payment', array($this, 'handle_ajax_payment'));
        add_action('wp_ajax_nopriv_vrstore_process_moota_payment', array($this, 'handle_ajax_payment'));
        
        // Handle AJAX payment status check
        add_action('wp_ajax_vrstore_check_moota_payment', array($this, 'handle_ajax_status_check'));
        add_action('wp_ajax_nopriv_vrstore_check_moota_payment', array($this, 'handle_ajax_status_check'));

        // Handle AJAX bank account retrieval
        add_action('wp_ajax_vrstore_get_moota_banks', array($this, 'handle_ajax_get_banks'));
        add_action('wp_ajax_nopriv_vrstore_get_moota_banks', array($this, 'handle_ajax_get_banks'));
    }

    /**
     * Add Moota gateway to available payment gateways
     *
     * @param array $gateways Existing gateways
     * @return array Modified gateways
     */
    public function add_moota_gateway(array $gateways): array {
        // Check if Moota is enabled in Moota plugin settings
        $moota_settings = get_option('vrstore_moota_settings', array());
        $moota_enabled = isset($moota_settings['enabled']) && $moota_settings['enabled'] === 'yes';

        // Check if Moota is enabled in Vira Store main settings
        $vrstore_settings = get_option('vrstore_settings', array());
        $enabled_gateways = isset($vrstore_settings['enabled_gateways'])
            ? $vrstore_settings['enabled_gateways']
            : get_option('vrstore_enabled_gateways', array());
        
        // Convert to array of enabled keys
        $enabled_gateway_keys = array();
        if (is_array($enabled_gateways)) {
            foreach ($enabled_gateways as $key => $value) {
                if ($value === 'on' || $value === true || $value === '1' || $value === 1) {
                    $enabled_gateway_keys[] = $key;
                }
            }
        }

        // Only add Moota if enabled in both Moota settings AND Vira Store settings
        if ($moota_enabled && in_array('moota', $enabled_gateway_keys, true)) {
            $gateways['moota'] = array(
                'name'        => __('Bank Transfer (Moota)', 'vrstore-moota'),
                'description' => __('Pay via bank transfer with automatic verification through Moota.', 'vrstore-moota'),
                'icon'        => 'bank',
                'enabled'     => true,
            );
        }

        return $gateways;
    }

    /**
     * Plugin activation
     */
    public function activate(): void {
        // Check PHP version
        if (version_compare(PHP_VERSION, '8.2', '<')) {
            deactivate_plugins(plugin_basename(__FILE__));
            wp_die(
                esc_html__('ViraStore Moota requires PHP 8.2 or higher.', 'vrstore-moota'),
                esc_html__('Plugin Activation Error', 'vrstore-moota'),
                array('back_link' => true)
            );
        }

        // Check if Vira Store is active
        if (!$this->is_vira_store_active()) {
            deactivate_plugins(plugin_basename(__FILE__));
            wp_die(
                esc_html__('ViraStore Moota requires Vira Store plugin to be active.', 'vrstore-moota'),
                esc_html__('Plugin Activation Error', 'vrstore-moota'),
                array('back_link' => true)
            );
        }

        // Create default settings
        $default_settings = array(
            'enabled'     => 'no',
            'api_key'     => '',
            'webhook_url' => '',
            'test_mode'   => 'yes',
        );

        add_option('vrstore_moota_settings', $default_settings);

        // Flush rewrite rules
        flush_rewrite_rules();
    }

    /**
     * Handle AJAX payment processing
     */
    public function handle_ajax_payment(): void {
        $gateway = ViraStore_Moota_Gateway::get_instance();
        $gateway->ajax_process_payment();
    }

    /**
     * Handle AJAX payment status check
     */
    public function handle_ajax_status_check(): void {
        $gateway = ViraStore_Moota_Gateway::get_instance();
        $gateway->ajax_check_payment();
    }

    /**
     * Handle AJAX bank accounts retrieval
     */
    public function handle_ajax_get_banks(): void {
        $nonce = $_POST['nonce'] ?? '';

        if (!wp_verify_nonce($nonce, 'vrstore_moota_nonce')) {
            wp_send_json_error(
                array(
                    'message' => __('Security check failed.', 'vrstore-moota'),
                ),
                403
            );
        }

        $gateway = ViraStore_Moota_Gateway::get_instance();
        $accounts = $gateway->get_bank_accounts();

        $banks = array();

        foreach ($accounts as $account) {
            $banks[] = array(
                'id'             => sanitize_text_field($account['moota_bank_id'] ?? ($account['account_number'] ?? '')),
                'bank_name'      => sanitize_text_field($account['bank_name'] ?? ''),
                'account_number' => sanitize_text_field($account['account_number'] ?? ''),
                'account_name'   => sanitize_text_field($account['account_name'] ?? ''),
            );
        }

        wp_send_json_success(
            array(
                'banks' => $banks,
            )
        );
    }

    /**
     * Initialize admin settings
     */
    public function init_admin(): void {
        if (is_admin()) {
            ViraStore_Moota_Admin::get_instance();
        }
    }

    /**
     * Initialize webhook handler
     */
    public function init_webhook(): void {
        ViraStore_Moota_Webhook::get_instance();
    }

    /**
     * Enqueue frontend assets
     */
    public function enqueue_frontend_assets(): void {
        // Only enqueue on checkout pages or where Vira Store is active
        if (!$this->should_enqueue_assets()) {
            return;
        }

        wp_enqueue_script(
            'vrstore-moota-frontend',
            VRSTORE_MOOTA_PLUGIN_URL . 'assets/js/moota-frontend.js',
            array('jquery'),
            VRSTORE_MOOTA_VERSION,
            true
        );

        wp_enqueue_style(
            'vrstore-moota-frontend',
            VRSTORE_MOOTA_PLUGIN_URL . 'assets/css/moota-frontend.css',
            array(),
            VRSTORE_MOOTA_VERSION
        );

        // Localize script with necessary data
        wp_localize_script('vrstore-moota-frontend', 'vrstore_moota', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('vrstore_moota_nonce'),
            'messages' => array(
                'processing'        => __('Processing payment...', 'vrstore-moota'),
                'checking_payment'  => __('Checking payment status...', 'vrstore-moota'),
                'payment_verified'  => __('Payment verified successfully!', 'vrstore-moota'),
                'payment_pending'   => __('Payment is still pending. Please complete the transfer.', 'vrstore-moota'),
                'payment_failed'    => __('Payment verification failed. Please try again.', 'vrstore-moota'),
                'error_occurred'    => __('An error occurred. Please try again.', 'vrstore-moota'),
                'loading_banks'     => __('Loading bank accounts...', 'vrstore-moota'),
            ),
        ));
    }

    /**
     * Check if assets should be enqueued
     *
     * @return bool True if assets should be enqueued
     */
    private function should_enqueue_assets(): bool {
        // Check if we're on a page that uses Vira Store checkout
        global $post;
        
        if (!$post) {
            return false;
        }

        // Check for Vira Store shortcodes
        $content = $post->post_content;
        if (has_shortcode($content, 'vrstore_checkout') || 
            has_shortcode($content, 'vrstore_product') ||
            has_shortcode($content, 'vrstore_account')) {
            return true;
        }

        // Check if current page is a Vira Store product page
        if ($post->post_type === 'vrstore_product') {
            return true;
        }

        return false;
    }

    /**
     * Plugin deactivation
     */
    public function deactivate(): void {
        // Flush rewrite rules
        flush_rewrite_rules();
    }

    /**
     * Show admin notice when Vira Store is missing
     */
    public function vira_store_missing_notice(): void {
        ?>
        <div class="notice notice-error">
            <p>
                <?php
                printf(
                    /* translators: %s: Plugin name */
                    esc_html__('%s requires Vira Store plugin to be installed and activated.', 'vrstore-moota'),
                    '<strong>' . esc_html__('ViraStore Moota', 'vrstore-moota') . '</strong>'
                );
                ?>
            </p>
        </div>
        <?php
    }
}

// Initialize the plugin
ViraStore_Moota::get_instance();