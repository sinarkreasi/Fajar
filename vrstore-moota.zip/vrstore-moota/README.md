# ViraStore Moota Payment Gateway

A WordPress plugin addon that integrates Moota payment gateway with ViraStore, enabling automated bank transfer monitoring and payment verification.

## Features

- **Automated Bank Transfer Monitoring**: Real-time monitoring of bank account transactions through Moota API
- **Multiple Bank Account Support**: Configure and manage multiple bank accounts for payment processing
- **Webhook Integration**: Automatic payment verification through Moota webhooks
- **Admin Dashboard**: Comprehensive admin interface for configuration and management
- **Test Mode**: Safe testing environment with sandbox API endpoints
- **Order Status Automation**: Automatic order status updates upon payment confirmation
- **Security**: Proper nonce verification, input sanitization, and output escaping

## Requirements

- WordPress 6.0 or higher
- PHP 8.2 or higher
- ViraStore plugin (active)
- Moota account with API access
- SSL certificate (recommended for webhook security)

## Installation

1. Download the plugin files
2. Upload to `/wp-content/plugins/vrstore-moota/` directory
3. Activate the plugin through the 'Plugins' menu in WordPress
4. Configure the settings under ViraStore > Moota Settings

## Configuration

### 1. API Settings

1. Navigate to **ViraStore > Moota Settings**
2. Enter your Moota API Key
3. Configure webhook URL (automatically generated)
4. Test the API connection

### 2. Bank Account Setup

1. Click "Load Banks from API" to fetch your Moota bank accounts
2. Enable/disable specific bank accounts for payment processing
3. Save the configuration

### 3. Test Mode

- Enable test mode for development and testing
- Use sandbox API endpoints
- Test payments without affecting live transactions

## Usage

### For Customers

1. Select "Moota Bank Transfer" as payment method during checkout
2. Choose from available bank accounts
3. Complete the bank transfer using provided details
4. Payment will be automatically verified within minutes

### For Administrators

1. Monitor payments in real-time through the admin dashboard
2. View transaction logs and payment status
3. Manually verify payments if needed
4. Configure webhook settings for automatic updates

## Webhook Configuration

The plugin automatically generates a webhook URL:
```
https://yoursite.com/wp-json/vrstore-moota/v1/webhook
```

Add this URL to your Moota dashboard webhook settings to enable automatic payment verification.

## API Endpoints

### REST API Endpoints

- `POST /wp-json/vrstore-moota/v1/webhook` - Webhook endpoint for Moota notifications
- `POST /wp-json/vrstore-moota/v1/verify-payment` - Manual payment verification

### AJAX Endpoints

- `vrstore_process_moota_payment` - Process Moota payment
- `vrstore_check_moota_payment` - Check payment status
- `vrstore_moota_test_connection` - Test API connection
- `vrstore_moota_fetch_banks` - Fetch bank accounts
- `vrstore_moota_save_bank` - Save bank account settings
- `vrstore_moota_delete_bank` - Delete bank account

## File Structure

```
vrstore-moota/
├── assets/
│   ├── css/
│   │   ├── moota-frontend.css
│   │   └── moota-admin.css
│   └── js/
│       ├── moota-frontend.js
│       └── moota-admin.js
├── includes/
│   ├── class-moota-gateway.php
│   ├── class-moota-admin.php
│   └── class-moota-webhook.php
├── languages/
├── vrstore-moota.php
└── README.md
```

## Hooks and Filters

### Actions

- `vrstore_moota_payment_completed` - Fired when payment is completed
- `vrstore_moota_payment_failed` - Fired when payment fails
- `vrstore_moota_webhook_received` - Fired when webhook is received

### Filters

- `vrstore_moota_api_request_args` - Modify API request arguments
- `vrstore_moota_webhook_signature_valid` - Custom webhook signature validation
- `vrstore_moota_payment_amount_match` - Custom payment amount matching logic

## Security Features

- **Nonce Verification**: All AJAX requests include nonce verification
- **Input Sanitization**: All user inputs are properly sanitized
- **Output Escaping**: All outputs are properly escaped
- **Capability Checks**: Admin functions require proper user capabilities
- **Webhook Signature Verification**: Webhooks are verified using Moota signatures

## Troubleshooting

### Common Issues

1. **API Connection Failed**
   - Verify API key is correct
   - Check internet connection
   - Ensure Moota API is accessible

2. **Webhook Not Working**
   - Verify webhook URL is correctly configured in Moota dashboard
   - Check SSL certificate is valid
   - Ensure WordPress REST API is accessible

3. **Payment Not Detected**
   - Check bank account is enabled in settings
   - Verify payment amount matches exactly
   - Check webhook logs for errors

### Debug Mode

Enable WordPress debug mode to see detailed error logs:

```php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
```

Check `/wp-content/debug.log` for Moota-related errors.

## Support

For support and bug reports:

1. Check the troubleshooting section
2. Enable debug mode and check logs
3. Contact plugin support with detailed error information

## Changelog

### Version 1.0.0
- Initial release
- Basic Moota integration
- Admin settings interface
- Webhook support
- Multiple bank account management
- Test mode functionality

## License

This plugin is licensed under the GPL v2 or later.

## Credits

Developed for ViraStore integration with Moota payment gateway.